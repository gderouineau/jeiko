from django.views import View
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
import datetime
from django.shortcuts import render, redirect, get_object_or_404
from .forms import GoogleCalendarConfigForm, AvailabilityForm
from .models import GoogleCalendarConfig, Availability, AppointmentType, Appointment, Slot
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache
from django.utils import timezone
from django.http import JsonResponse
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from datetime import timedelta
from django.views.decorators.csrf import csrf_exempt
import json
from django.db import transaction


@method_decorator(never_cache, name='dispatch')
class GoogleCalendarConfigView(LoginRequiredMixin, UserPassesTestMixin, View):
    def test_func(self):
        return self.request.user.is_superuser

    def get(self, request):
        config, _ = GoogleCalendarConfig.objects.get_or_create(name="Primary")
        form = GoogleCalendarConfigForm(instance=config)
        return render(request, "calendars/admin_config.html", {"form": form})

    def post(self, request):
        config, _ = GoogleCalendarConfig.objects.get_or_create(name="Primary")
        form = GoogleCalendarConfigForm(request.POST, instance=config)
        if form.is_valid():
            form.save()
            messages.success(request, "Clé Google Calendar enregistrée avec succès !")
            return redirect("jeiko_administration_calendars:google_config")
        return render(request, "calendars/admin_config.html", {"form": form})


@method_decorator(never_cache, name='dispatch')
class GoogleCalendarAdminListView(LoginRequiredMixin, UserPassesTestMixin, View):
    def test_func(self):
        return self.request.user.is_superuser

    def get(self, request):
        config = GoogleCalendarConfig.objects.first()
        events = []
        error = None

        if config and config.credentials_json:
            try:
                creds = Credentials.from_service_account_info(config.credentials_json)
                service = build('calendar', 'v3', credentials=creds)
                now = datetime.datetime.utcnow().isoformat() + 'Z'
                result = service.events().list(
                    calendarId='guillaume.derouineau@gmail.com',
                    timeMin=(datetime.datetime.utcnow() - datetime.timedelta(days=90)).isoformat() + 'Z',
                    maxResults=20,
                    singleEvents=True,
                    orderBy='startTime'
                ).execute()
                events = result.get('items', [])
            except Exception as e:
                error = f"Erreur lors de la récupération des événements : {e}"

        context = {
            "events": events,
            "error": error
        }
        return render(request, "calendars/calendar_list.html", context)


@method_decorator(never_cache, name='dispatch')
class AvailabilityListView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    model = Availability
    template_name = "calendars/availability_list.html"
    context_object_name = "availabilities"
    def test_func(self):
        return self.request.user.is_superuser

@method_decorator(never_cache, name='dispatch')
class AvailabilityCreateView(LoginRequiredMixin, UserPassesTestMixin, CreateView):
    model = Availability
    form_class = AvailabilityForm
    template_name = "calendars/availability_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")
    def test_func(self):
        return self.request.user.is_superuser




@method_decorator(never_cache, name='dispatch')
class AvailabilityUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Availability
    form_class = AvailabilityForm
    template_name = "calendars/availability_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")
    def test_func(self):
        return self.request.user.is_superuser

    def get_initial(self):
        initial = super().get_initial()
        print("get_initial:", initial)
        return initial

@method_decorator(never_cache, name='dispatch')
class AvailabilityDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Availability
    template_name = "calendars/availability_confirm_delete.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")
    def test_func(self):
        return self.request.user.is_superuser

class AppointmentCancelView(View):
    template_name = "calendars/appointment_cancel_confirm.html"

    def get(self, request, pk):
        appt = get_object_or_404(Appointment, pk=pk)
        return render(request, self.template_name, {"appointment": appt})

    def post(self, request, pk):
        appt = get_object_or_404(Appointment, pk=pk)
        appt.cancel()  # méthode vue plus haut dans le modèle
        messages.success(request, "Votre rendez-vous a bien été annulé.")
        return render(request, "calendars/appointment_cancel_done.html")


@method_decorator(never_cache, name="dispatch")
class APIAvailabilitiesView(View):
    def get(self, request):
        appointment_type_id = request.GET.get("type")
        slots = Slot.objects.filter(
            is_available=True,
            start__gte=timezone.now(),
            remaining_places__gt=0,
        )
        if appointment_type_id:
            slots = slots.filter(type_id=appointment_type_id)

        data = []
        for slot in slots.order_by('start'):
            display = f"{slot.start.strftime('%A %d %B à %Hh%M')} ({int((slot.end-slot.start).total_seconds()//60)} min)"
            data.append({
                "id": slot.id,
                "availability_id": slot.availability_id,
                "start": slot.start.isoformat(),
                "end": slot.end.isoformat(),
                "display": display,
                "type": slot.type.name,
                "slot_minutes": int((slot.end-slot.start).total_seconds()//60),
                "remaining_places": slot.remaining_places,
            })
        return JsonResponse(data, safe=False)


@method_decorator(csrf_exempt, name='dispatch')
class APIBookAppointmentView(View):
    @transaction.atomic
    def post(self, request):
        try:
            data = json.loads(request.body)
            slot_id = data.get('slot_id')
            email = data.get('email', '').strip()

            slot = Slot.objects.select_for_update().filter(
                id=slot_id,
                is_available=True,
                remaining_places__gt=0,
                start__gte=timezone.now()
            ).first()
            if not slot:
                return JsonResponse({'success': False, 'message': "Créneau non disponible ou déjà réservé."}, status=400)

            # Double check pour éviter le surbooking
            if slot.remaining_places <= 0 or not slot.is_available:
                return JsonResponse({'success': False, 'message': "Ce créneau vient d'être réservé."}, status=400)

            # Création du rendez-vous
            appt = Appointment.objects.create(
                type=slot.type,
                slot=slot,
                start=slot.start,
                end=slot.end,
                email=email,
            )

            # Mise à jour du slot
            slot.remaining_places -= 1
            if slot.remaining_places <= 0:
                slot.is_available = False
            slot.save(update_fields=["remaining_places", "is_available"])

            # (Option) envoyer email, synchroniser Google, etc.

            return JsonResponse({'success': True, 'message': "Rendez-vous réservé avec succès !"})

        except Exception as e:
            return JsonResponse({'success': False, 'message': f"Erreur serveur : {str(e)}"}, status=500)
