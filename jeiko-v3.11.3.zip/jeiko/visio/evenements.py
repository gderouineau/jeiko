"""
Les événements du LiveKit du site (VISIO-03 — audit V-02 en entier, V-15).

Le problème
-----------
Exclure quelqu'un n'invalide pas son jeton LiveKit : il pouvait revenir avec,
et seul le rattrapage (`acces.reconcilier`, toutes les 20 s quand l'hôte est
là, 5 minutes sinon) le retirait. Et la présence se notait à la DÉLIVRANCE du
jeton : une personne dont la caméra refusait de s'ouvrir était « venue ».

LiveKit prévient le site de chaque arrivée et de chaque départ (son
`webhook`, réglé par 15_visio.sh). Ici :

* `participant_joined` — qui n'a plus de lien valable, ou n'est pas à sa place
  (séance terminée, groupe qui n'est pas le sien), est retiré À L'INSTANT ;
  sinon son passage s'ouvre, à l'heure que donne LiveKit ;
* `participant_left` — son passage se referme ;
* `room_finished` — les passages encore ouverts de la salle se referment.

Ce que ce module vérifie : la SIGNATURE. LiveKit signe chaque envoi d'un JWT
(HS256, la clé et le secret du site) qui porte l'empreinte SHA-256 du corps ;
sans elle, n'importe qui pourrait fermer des passages ou faire retirer des
gens. Un événement déjà reçu (même identifiant) n'est pas rejoué.

Ce qu'il ne fait pas : se passer du rattrapage. Un événement perdu (site en
maintenance, LiveKit relancé) n'est pas renvoyé indéfiniment ; `reconcilier`
reste le filet. Et sans événements — un site dont le LiveKit n'a pas encore
été reconfiguré —, la présence se note comme avant, à l'entrée (`actifs`).
"""
import base64
import hashlib
import hmac
import json
import logging
from datetime import datetime, timedelta, timezone as tz

import jwt
from django.db import IntegrityError, transaction
from django.utils import timezone

from . import livekit
from .models import EvenementLiveKit, Invitation, Presence, Salle, SousSalle

logger = logging.getLogger(__name__)

#: Un événement reçu depuis moins longtemps : la présence se fonde sur eux.
FRAICHEUR = timedelta(days=30)


class SignatureInvalide(Exception):
    """L'envoi ne vient pas du LiveKit du site."""


def verifier(corps, entete):
    """
    Le document de l'événement, si `entete` (Authorization) est un jeton signé
    du secret du site, émis par sa clé, qui porte l'empreinte de `corps`.
    Lève SignatureInvalide sinon.
    """
    try:
        cle, secret, _api = livekit.configuration()
    except livekit.LiveKitIndisponible as erreur:
        raise SignatureInvalide("visio non configurée") from erreur
    jeton = (entete or "").strip()
    if jeton.lower().startswith("bearer "):
        jeton = jeton[7:].strip()
    if not jeton:
        raise SignatureInvalide("jeton absent")
    try:
        revendications = jwt.decode(jeton, secret, algorithms=["HS256"], issuer=cle, leeway=30,
                                    options={"require": ["iss", "exp"], "verify_aud": False})
    except jwt.PyJWTError as erreur:
        raise SignatureInvalide(f"jeton refusé : {erreur}") from erreur
    attendue = base64.b64encode(hashlib.sha256(corps).digest()).decode()
    if not hmac.compare_digest(str(revendications.get("sha256", "")), attendue):
        raise SignatureInvalide("empreinte du corps différente")
    try:
        document = json.loads(corps)
    except ValueError as erreur:
        raise SignatureInvalide("corps illisible") from erreur
    if not isinstance(document, dict):
        raise SignatureInvalide("corps illisible")
    return document


def actifs():
    """Les événements arrivent-ils ? (le plus récent a moins de 30 jours)"""
    return EvenementLiveKit.objects.filter(recu_le__gte=timezone.now() - FRAICHEUR).exists()


def _champ(document, *noms):
    """LiveKit écrit ses champs en camelCase (protojson) ; on accepte aussi la forme snake_case."""
    for nom in noms:
        if nom in document:
            return document[nom]
    return None


def _horodatage(document):
    """L'heure de l'événement (secondes Unix, souvent en texte) ; maintenant à défaut."""
    brut = _champ(document, "createdAt", "created_at")
    try:
        secondes = int(brut)
    except (TypeError, ValueError):
        return timezone.now()
    if secondes > 10 ** 11:  # en millisecondes
        secondes //= 1000
    quand = datetime.fromtimestamp(secondes, tz=tz.utc)
    # Une horloge déréglée ne place pas un passage dans le futur.
    return min(quand, timezone.now())


def _lieu(nom_livekit):
    """(salle, groupe ou None) d'un nom de salle LiveKit — (None, None) s'il n'est pas d'ici."""
    salle = Salle.objects.filter(nom_livekit=nom_livekit).first() if _uuid(nom_livekit) else None
    if salle is not None:
        return salle, None
    groupe = (SousSalle.objects.select_related("salle").filter(nom_livekit=nom_livekit).first()
              if _uuid(nom_livekit) else None)
    return (groupe.salle, groupe) if groupe is not None else (None, None)


def _uuid(texte):
    import uuid

    try:
        uuid.UUID(str(texte))
    except ValueError:
        return False
    return True


def _a_sa_place(salle, groupe, invitation):
    """La même règle que `acces.reconcilier`, pour UNE personne qui arrive."""
    from . import groupes

    if invitation is None or salle.terminee:
        return False
    if groupe is None:
        return True
    if not groupes.en_cours(salle) or groupe not in groupes.actuels(salle):
        return False
    return invitation.est_hote or invitation.sous_salle_id == groupe.pk


def traiter(document):
    """
    Applique un événement vérifié. Rend ce qui a été fait, en un mot (pour le
    journal et les tests) : `deja`, `ignore`, `inconnue`, `retire`, `arrivee`,
    `depart`, `ailleurs`, `fin`.
    """
    sorte = str(_champ(document, "event") or "")
    identifiant = str(_champ(document, "id") or "")[:64]
    salle_doc = _champ(document, "room") or {}
    salle, groupe = _lieu(_champ(salle_doc, "name") or "")
    if identifiant:
        try:
            with transaction.atomic():
                EvenementLiveKit.objects.create(identifiant=identifiant, sorte=sorte[:40], salle=salle)
        except IntegrityError:
            return "deja"
    if sorte not in ("participant_joined", "participant_left", "room_finished"):
        return "ignore"
    if salle is None:
        return "inconnue"
    nom_livekit = groupe.identifiant_livekit if groupe else salle.identifiant_livekit
    quand = _horodatage(document)

    if sorte == "room_finished":
        if groupe is None:
            Presence.objects.filter(invitation__salle=salle, sortie__isnull=True).update(sortie=quand)
        return "fin"

    identite = str(_champ(_champ(document, "participant") or {}, "identity") or "")
    invitation = None
    if identite.startswith("i") and identite[1:].isdigit():
        invitation = salle.invitations_actives().filter(pk=int(identite[1:])).first()

    if sorte == "participant_left":
        if invitation is None:
            invitation = salle.invitations.filter(pk=int(identite[1:])).first() if identite[1:].isdigit() else None
        if invitation is not None:
            from .acces import lieu

            # Passer de la salle principale à son groupe, c'est partir de
            # l'une et arriver dans l'autre — deux envois qui peuvent arriver
            # dans le désordre. Un départ d'un lieu qui n'est plus le sien ne
            # ferme pas le passage en cours.
            if lieu(invitation)[1] != nom_livekit:
                return "ailleurs"
            Presence.objects.filter(invitation=invitation, sortie__isnull=True).update(sortie=quand)
            Invitation.objects.filter(pk=invitation.pk).update(sortie_le=quand)
        return "depart"

    # participant_joined
    if not _a_sa_place(salle, groupe, invitation):
        try:
            livekit.retirer(nom_livekit, identite)
        except livekit.LiveKitIndisponible as panne:
            logger.info("Visio : retrait de %s remis au rattrapage — %s", identite, panne)
        return "retire"
    if not Presence.objects.filter(invitation=invitation, sortie__isnull=True).exists():
        Presence.objects.create(invitation=invitation, arrivee=quand)
    Invitation.objects.filter(pk=invitation.pk).update(
        arrivee_le=invitation.arrivee_le or quand, derniere_arrivee_le=quand)
    return "arrivee"


def purger():
    """cron_24h : les identifiants de plus de 30 jours ne servent plus à rien."""
    return EvenementLiveKit.objects.filter(recu_le__lt=timezone.now() - FRAICHEUR).delete()[0]
