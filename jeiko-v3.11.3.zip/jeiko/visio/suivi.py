"""
Avant et après une séance (VISIO-01, V2) : les rappels, le rapport de
présence, le message aux invités.

* RAPPELS — la veille (24 h avant) et une heure avant, à chaque invité qui a
  une adresse, pour les séances créées à la main : celles du calendrier ont
  les rappels des rendez-vous. Un rappel n'est jamais envoyé deux fois, ni
  pour une séance terminée, ni à un lien révoqué. Lancé toutes les 5 minutes
  (cron_5m).
* PRÉSENCE — par invité : arrivée, sortie, temps passé (somme des passages,
  `Presence`) ; les absents. Pour l'écran, le CSV et l'API.
* MESSAGE — l'organisateur écrit aux invités de la séance, aux absents
  seulement ou à ceux qui sont venus (replay, support, prochaine date), avec
  des documents : chacun les télécharge par son lien personnel, la séance
  finie. Chaque envoi est gardé (onglet Suivi de la fiche).
"""
import logging
from datetime import timedelta

from django.utils import formats, timezone

logger = logging.getLogger(__name__)


def _date(salle):
    return formats.date_format(timezone.localtime(salle.debut), "l j F Y \\à H\\hi")


def envoyer_les_rappels():
    """Rend le nombre de rappels envoyés."""
    from jeiko.emailing.admin_alerts import _lien_absolu
    from jeiko.emailing.services import send_email

    from .models import Invitation
    from .vente import paragraphe_de_desinscription

    maintenant = timezone.now()
    base = (Invitation.objects
            .filter(revoquee_le__isnull=True, salle__terminee_le__isnull=True, salle__rappels=True,
                    salle__rendez_vous__isnull=True, salle__creneau__isnull=True,
                    salle__debut__gt=maintenant)
            .exclude(email="").select_related("salle", "user"))
    fenetres = (
        ("rappel_veille_le", maintenant + timedelta(hours=1), maintenant + timedelta(hours=24), "demain"),
        ("rappel_heure_le", maintenant, maintenant + timedelta(hours=1), "dans une heure"),
    )
    envoyes = 0
    for champ, apres, avant, quand in fenetres:
        for invitation in base.filter(**{f"{champ}__isnull": True, "salle__debut__gt": apres,
                                         "salle__debut__lte": avant}):
            # Invité il y a moins de 12 h : l'invitation vaut rappel de la veille.
            if (champ == "rappel_veille_le" and invitation.envoyee_le
                    and invitation.envoyee_le > maintenant - timedelta(hours=12)):
                Invitation.objects.filter(pk=invitation.pk).update(**{champ: maintenant})
                continue
            # Une séance prévue aujourd'hui n'est pas « demain ».
            libelle = quand if champ == "rappel_heure_le" or (
                timezone.localdate(invitation.salle.debut) != timezone.localdate(maintenant)) else "aujourd'hui"
            try:
                ok, _raison = send_email("visio_rappel", invitation.email, {
                    "invite_nom": invitation.nom, "titre": invitation.salle.titre,
                    "date": _date(invitation.salle), "quand": libelle,
                    "lien_action": _lien_absolu("jeiko_visio:salle", invitation.code),
                    "lien_desinscription": paragraphe_de_desinscription(invitation),
                }, user=invitation.user)
            except Exception:
                logger.exception("Rappel visio de l'invitation #%s", invitation.pk)
                ok = False
            # Marqué s'il est parti, ou si le modèle est désactivé (une décision,
            # pas une panne). Une panne d'envoi est retentée au passage suivant,
            # tant que la fenêtre du rappel dure (audit V-18).
            if ok or not _modele_actif("visio_rappel"):
                Invitation.objects.filter(pk=invitation.pk).update(**{champ: maintenant})
            envoyes += int(bool(ok))
    return envoyes


def _modele_actif(code):
    from jeiko.emailing.models import EmailTemplate

    modele = EmailTemplate.objects.filter(code=code).first()
    return modele is None or modele.active


def presence(salle):
    """[{invitation, venue, arrivee, sortie, minutes}] — toutes les invitations, absents compris."""
    lignes = []
    for invitation in salle.invitations.order_by("role", "nom").prefetch_related("presences"):
        passages = list(invitation.presences.all())
        duree = sum((p.duree() for p in passages), timedelta(0))
        lignes.append({
            "invitation": invitation, "venue": bool(passages),
            "arrivee": passages[0].arrivee if passages else None,
            "sortie": max((p.sortie for p in passages if p.sortie), default=None),
            "minutes": int(duree.total_seconds() // 60),
        })
    return lignes


def lien_du_document(invitation, fichier):
    """L'adresse absolue d'un document partagé, par le lien personnel de l'invité."""
    from django.urls import reverse

    from jeiko.emailing.render import absolute_url

    return absolute_url(reverse("jeiko_visio:document", args=[invitation.code, fichier.pk]))


def _liste_des_documents(invitation, documents):
    from django.utils.html import format_html, format_html_join

    if not documents:
        return ""
    # En français, comme tout le contenu des e-mails (I-05).
    return format_html("<p><strong>Documents :</strong></p><ul>{}</ul>", format_html_join(
        "", '<li><a href="{}">{}</a></li>', ((lien_du_document(invitation, f), f.nom) for f in documents)))


def ecrire_aux_invites(salle, *, objet, message, destinataires="absents", documents=(), par=None):
    """
    `destinataires` : « absents », « presents » ou « tous » — jamais l'équipe
    (hôtes) ni un lien révoqué. `documents` : des fichiers de la salle
    principale, partagés du même geste ; chaque invité reçoit SES liens (par
    son code personnel). L'envoi est gardé (`EnvoiDeSuivi`). Rend le nombre
    d'e-mails envoyés.

    Les liens partent DANS le message et non dans une variable à part : un
    modèle d'e-mail déjà personnalisé ne cite pas une variable qui n'existait
    pas, les documents s'y seraient perdus.
    """
    from django.utils.html import escape, linebreaks

    from jeiko.emailing.services import send_email

    from .fichiers import partageables
    from .models import EnvoiDeSuivi

    if destinataires not in ("absents", "presents", "tous"):
        raise ValueError(destinataires)
    documents = list(partageables(salle).filter(pk__in=[getattr(d, "pk", d) for d in documents]))
    for document in documents:
        if not document.partage:
            document.partage = True
            document.save(update_fields=["partage"])
    envoyes = 0
    for ligne in presence(salle):
        invitation = ligne["invitation"]
        if invitation.revoquee or invitation.est_hote or not invitation.email:
            continue
        if (destinataires == "absents" and ligne["venue"]) or (destinataires == "presents" and not ligne["venue"]):
            continue
        try:
            ok, _raison = send_email("visio_message", invitation.email, {
                "invite_nom": invitation.nom, "titre": salle.titre, "objet": objet,
                # Le texte saisi est échappé puis mis en paragraphes : jamais du HTML brut.
                "message": linebreaks(escape(message)) + _liste_des_documents(invitation, documents),
            }, user=invitation.user)
        except Exception:
            logger.exception("Message visio à l'invitation #%s", invitation.pk)
            ok = False
        envoyes += int(bool(ok))
    envoi = EnvoiDeSuivi.objects.create(salle=salle, objet=objet, message=message, destinataires=destinataires,
                                        nombre=envoyes, envoye_par=par)
    envoi.documents.set(documents)
    return envoyes
