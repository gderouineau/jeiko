from django import forms
from django.utils.translation import gettext_lazy as _

from .models import Invitation, Salle

_DATE = forms.DateTimeInput(attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M")


class SalleForm(forms.ModelForm):
    class Meta:
        model = Salle
        fields = ["titre", "format", "debut", "fin", "description", "ouverture_avant", "salle_d_attente",
                  "verrouillee", "rappels", "qualite", "son"]
        widgets = {"debut": _DATE, "fin": _DATE, "description": forms.Textarea(attrs={"rows": 3})}

    def clean(self):
        donnees = super().clean()
        debut, fin = donnees.get("debut"), donnees.get("fin")
        if debut and fin and fin <= debut:
            self.add_error("fin", _("La fin doit venir après le début."))
        return donnees


class MessageForm(forms.Form):
    destinataires = forms.ChoiceField(label=_("À qui"), choices=[
        ("absents", _("Les absents")), ("presents", _("Ceux qui sont venus")), ("tous", _("Tous les invités"))])
    objet = forms.CharField(label=_("Objet"), max_length=200)
    message = forms.CharField(label=_("Message"), widget=forms.Textarea(attrs={"rows": 5}), max_length=5000,
                              help_text=_("Un lien de replay, un support, la prochaine date… Les hôtes ne le reçoivent pas."))


class InvitationForm(forms.Form):
    nom = forms.CharField(label=_("Nom"), max_length=200, required=False,
                          help_text=_("Vide : le nom du compte, ou le début de l'adresse."))
    email = forms.EmailField(label=_("E-mail"))
    role = forms.ChoiceField(label=_("Rôle"), choices=Invitation.Role.choices, initial=Invitation.Role.PARTICIPANT)
    envoyer = forms.BooleanField(label=_("Envoyer l'invitation par e-mail"), required=False, initial=True)


class InscriptionsForm(forms.ModelForm):
    """V2-E — la séance à inscription : places, prix, liste d'attente, remboursement."""
    grille = forms.CharField(
        label=_("Remboursement à la désinscription"), required=False, max_length=200,
        help_text=_("« 48:100, 24:50 » : remboursé à 100 % jusqu'à 48 h avant le début, à 50 % jusqu'à 24 h, "
                    "rien ensuite. « toujours » : en entier jusqu'au début. Vide : jamais. Séance payante seulement."))

    grille_annulation = forms.CharField(
        label=_("Remboursement si vous annulez la séance"), required=False, max_length=200,
        help_text=_("Mêmes paliers, comptés au moment où vous annulez : « 168:100, 24:50 » rend tout jusqu'à "
                    "une semaine avant, la moitié jusqu'à 24 h. « toujours » (le défaut) : tout est rendu. "
                    "La grille acceptée à l'achat reste celle de l'acheteur."))

    class Meta:
        model = Salle
        fields = ["inscriptions", "places", "prix", "liste_d_attente"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from .vente import grille_en_texte

        self.fields["grille"].initial = grille_en_texte(self.instance.remboursement)
        self.fields["grille_annulation"].initial = grille_en_texte(self.instance.remboursement_annulation)

    def _grille(self, champ):
        from .vente import lire_la_grille

        try:
            return lire_la_grille(self.cleaned_data.get(champ))
        except ValueError:
            raise forms.ValidationError(_("Écrivez des paliers « heures:pourcentage » séparés par des virgules, "
                                          "par exemple « 48:100, 24:50 »."))

    def clean_grille(self):
        return self._grille("grille")

    def clean_grille_annulation(self):
        return self._grille("grille_annulation")

    def save(self, commit=True):
        self.instance.remboursement = self.cleaned_data["grille"]
        self.instance.remboursement_annulation = self.cleaned_data["grille_annulation"]
        return super().save(commit)


class AnnulationForm(forms.Form):
    motif = forms.CharField(label=_("Motif, dit aux invités"), max_length=500, required=False,
                            widget=forms.Textarea(attrs={"rows": 2}))
    confirmer = forms.BooleanField(label=_("J'annule la séance pour tout le monde"))
