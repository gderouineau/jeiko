"""
La salle, ouverte par le lien personnel `/visio/<code>/` (VISIO-01).

Une page, et les appels qu'elle fait en JSON : entrer (ou attendre), le chat,
les gestes de l'hôte, la sortie. Le code du lien est la seule preuve
d'identité — d'où : jamais de référent transmis, jamais de cache, jamais
dans les statistiques (`stats/middleware.py`), et un plafond sur le chat.
"""
import json
import logging

from django.http import Http404, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.utils import timezone
from django.utils.translation import gettext as _
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie
from django.views.decorators.http import require_GET, require_POST

from jeiko import throttling

from . import acces, fichiers, groupes, livekit, sondages
from .models import Invitation

logger = logging.getLogger(__name__)


def _invitation(code):
    invitation = acces.trouver(code)
    if invitation is None:
        raise Http404
    return invitation


def _prive(reponse):
    reponse["Referrer-Policy"] = "no-referrer"
    reponse["X-Robots-Tag"] = "noindex, nofollow"
    return reponse


def _corps(request):
    """
    Le corps JSON d'un geste, ou `Refus` (400) : un corps illisible, ou qui
    n'est pas un objet, était lu comme vide — ou faisait une erreur 500
    (VISIO-03).
    """
    try:
        corps = json.loads(request.body or b"{}")
    except ValueError:
        raise acces.Refus(_("Requête illisible : un objet JSON est attendu."))
    if not isinstance(corps, dict):
        raise acces.Refus(_("Requête illisible : un objet JSON est attendu."))
    return corps


def _entier(corps, cle):
    """Un entier du corps (0 s'il manque), ou `Refus` : « abc » faisait une erreur 500."""
    valeur = corps.get(cle) or 0
    if isinstance(valeur, bool):
        raise acces.Refus(_("« %(cle)s » : un nombre entier est attendu.") % {"cle": cle})
    try:
        return int(valeur)
    except (TypeError, ValueError):
        raise acces.Refus(_("« %(cle)s » : un nombre entier est attendu.") % {"cle": cle})


def _indisponible(erreur):
    logger.warning("Visio : LiveKit indisponible — %s", erreur)
    return JsonResponse({"etat": "indisponible",
                         "message": _("La visio est momentanément indisponible. Réessayez dans un instant.")},
                        status=503)


def textes():
    """Les phrases de la salle, traduites ici : le JavaScript n'en écrit aucune."""
    return {
        "permission_refusee": _("Caméra ou micro inaccessibles : autorisez-les dans votre navigateur, "
                                "ou entrez sans eux."),
        "appareil": _("Appareil"),
        "trop_tot": _("La salle ouvre à %(heure)s (dans %(minutes)s min). Vous entrerez automatiquement : "
                      "laissez cette page ouverte."),
        "lien_invalide": _("Ce lien n'est plus valable. Demandez-en un nouveau à l'organisateur."),
        "attente": _("Vous êtes en salle d'attente : l'hôte va vous faire entrer."),
        "connexion": _("Ce lien d'hôte s'ouvre avec votre compte."),
        "se_connecter": _("Se connecter"),
        "terminee": _("La séance est terminée."),
        "verrouillee": _("La salle est verrouillée pour le moment."),
        "indisponible": _("La visio est momentanément indisponible. Nouvel essai dans un instant…"),
        "connexion_en_cours": _("Connexion…"),
        "complet": _("La salle est complète."),
        "connexion_impossible": _("Connexion impossible. Vérifiez votre réseau et réessayez."),
        "parole_donnee": _("Vous avez la parole : activez votre micro."),
        "parole_reprise": _("L'hôte a repris la parole."),
        "deconnecte": _("La connexion a été perdue."),
        "exclu": _("Vous avez été retiré de la séance."),
        "parti": _("Vous avez quitté la séance."),
        "vous": _("vous"),
        "ecran_de": _("Écran de"),
        "pas_la_parole": _("Levez la main : l'hôte vous donnera la parole."),
        "appareil_indisponible": _("Cet appareil est indisponible."),
        "role_hote": _("Hôte"),
        "role_intervenant": _("Intervenant"),
        "role_spectateur": _("Spectateur"),
        "role_participant": _("Participant"),
        "verrouiller": _("Verrouiller la salle"),
        "deverrouiller": _("Déverrouiller la salle"),
        "terminer_pour_tous": _("Terminer pour tous"),
        "confirmer_terminer": _("Terminer la séance pour tout le monde ?"),
        "en_attente": _("En attente"),
        "admettre": _("Admettre"),
        "refuser": _("Refuser"),
        "dans_la_salle": _("Dans la salle"),
        "donner_parole": _("Donner la parole"),
        "reprendre_parole": _("Reprendre la parole"),
        "couper_micro": _("Couper le micro"),
        "exclure": _("Exclure"),
        "confirmer_exclure": _("Exclure %(nom)s ? Son lien ne fonctionnera plus."),
        "quelquun_attend": _("%(nom)s attend d'entrer."),
        "envoi_fichier": _("Envoi du fichier…"),
        "sondages": _("Sondages"),
        "question": _("Question"),
        "choix_une_ligne": _("Un choix par ligne (2 à 8)"),
        "plusieurs": _("Plusieurs réponses possibles"),
        "lancer": _("Lancer"),
        "preparer": _("Préparer"),
        "clore": _("Clore"),
        "voter": _("Voter"),
        "merci_vote": _("Merci, votre réponse est enregistrée. Vous pouvez la changer tant que le sondage est ouvert."),
        "resultats": _("Résultats"),
        "votants": _("votant(s)"),
        "aucun_sondage": _("Aucun sondage pour le moment."),
        "fermer": _("Fermer"),
        "etat_prepare": _("préparé"),
        "etat_ouvert": _("en cours"),
        "etat_clos": _("clos"),
        "groupes": _("Groupes"),
        "groupe": _("Groupe"),
        "nombre_de_groupes": _("Nombre de groupes"),
        "duree_minutes": _("Durée (minutes, 0 = sans limite)"),
        "a_la_main": _("Répartir à la main"),
        "ouvrir_groupes": _("Ouvrir les groupes"),
        "fermer_groupes": _("Fermer les groupes"),
        "rejoindre": _("Rejoindre"),
        "salle_principale": _("Salle principale"),
        "annonce_groupes": _("Message à tous les groupes"),
        "envoyer": _("Envoyer"),
        "personne_presente": _("Personne n'est présent à répartir."),
        "reste": _("reste"),
        "vers_groupe": _("Vous passez dans votre groupe de travail…"),
        "retour_principale": _("Retour dans la salle principale…"),
        "trop_lourd": _("Fichier trop lourd : %(max)s Mo au plus."),
        "navigateur": _("Ce navigateur ne permet pas la visio. Essayez un navigateur récent (Chrome, Firefox, "
                        "Safari, Edge)."),
    }


@never_cache
@ensure_csrf_cookie
@require_GET
def salle(request, code):
    invitation = acces.trouver(code)
    if invitation is None:
        # Un lien révoqué ou mal recopié : une page qui le dit, pas une erreur brute.
        return _prive(render(request, "visio/lien_invalide.html", status=404))
    s = invitation.salle
    urls = {
        "entrer": reverse("jeiko_visio:entrer", args=[code]),
        "sortie": reverse("jeiko_visio:sortie", args=[code]),
        "chat": reverse("jeiko_visio:chat", args=[code]),
        "attente": reverse("jeiko_visio:attente", args=[code]),
        "geste": reverse("jeiko_visio:geste", args=[code, "GESTE"]),
        "deposer": reverse("jeiko_visio:deposer", args=[code]),
        "fichier": reverse("jeiko_visio:telecharger", args=[code, 0]).replace("/0/", "/FICHIER/"),
        "sondages": reverse("jeiko_visio:sondages", args=[code]),
        "voter": reverse("jeiko_visio:voter", args=[code, 0]).replace("/0/", "/SONDAGE/"),
        "connexion": f"{reverse('account_login')}?next={request.path}",
    }
    config = {
        "urls": urls,
        "salle": {"titre": s.titre, "format": s.format, "qualite": s.qualite, "son": s.son,
                  "debut": timezone.localtime(s.debut).isoformat(), "fin": timezone.localtime(s.fin).isoformat()},
        "textes": textes(),
        "moi": {"nom": invitation.nom, "role": invitation.role, "identite": invitation.identite,
                "hote": invitation.est_hote},
        "fichier_mo": fichiers.plafond_mo(),
    }
    return _prive(render(request, "visio/salle.html", {"invitation": invitation, "salle": s, "config": config}))


@never_cache
@require_POST
def entrer(request, code):
    invitation = _invitation(code)
    try:
        return JsonResponse(acces.entrer(invitation, request.user, livekit.adresse_publique(request)))
    except livekit.LiveKitIndisponible as erreur:
        return _indisponible(erreur)


@csrf_exempt  # navigator.sendBeacon ne porte pas d'en-tête : le code du lien suffit.
@require_POST
def sortie(request, code):
    invitation = acces.trouver(code)
    if invitation is not None:
        acces.sortir(invitation)
    return HttpResponse(status=204)


#: Un événement LiveKit pèse quelques kilo-octets ; au-delà, ce n'en est pas un.
TAILLE_D_UN_EVENEMENT = 64 * 1024


@csrf_exempt
@require_POST
def evenements_livekit(request):
    """
    Les arrivées et les départs, envoyés par le LiveKit du site (VISIO-03).
    Rien n'est lu ni écrit avant la vérification de la signature (`evenements`).
    """
    from . import evenements

    if int(request.META.get("CONTENT_LENGTH") or 0) > TAILLE_D_UN_EVENEMENT:
        return HttpResponse(status=413)
    corps = request.body
    try:
        document = evenements.verifier(corps, request.headers.get("Authorization", ""))
    except evenements.SignatureInvalide as refus:
        logger.warning("Visio : événement LiveKit refusé — %s", refus)
        return HttpResponse(status=401)
    resultat = evenements.traiter(document)
    logger.info("Visio : événement LiveKit %s → %s", document.get("event"), resultat)
    return HttpResponse(status=200)


def _dans_la_salle(request, invitation):
    """Le chat et les gestes ne servent qu'à qui peut être dans la salle."""
    if acces.etat_d_entree(invitation, request.user) is not None:
        raise Http404


@never_cache
def chat(request, code):
    invitation = _invitation(code)
    _dans_la_salle(request, invitation)
    if request.method == "POST":
        if throttling.hit("visio:chat", invitation.pk, 30, 60):
            return JsonResponse({"erreur": _("Trop de messages : patientez un instant.")}, status=429)
        try:
            message = acces.ecrire(invitation, _corps(request).get("texte"))
        except acces.Refus as refus:
            return JsonResponse({"erreur": str(refus)}, status=400)
        except livekit.LiveKitIndisponible as erreur:
            return _indisponible(erreur)
        return JsonResponse(message.en_donnees(), status=201)
    groupe, _nom = acces.lieu(invitation)
    # Les 500 DERNIERS, remis dans l'ordre : à la reconnexion, ce sont les
    # récents qui comptent (audit V-17).
    messages = (invitation.salle.messages.filter(sous_salle=groupe).select_related("auteur", "fichier")
                .order_by("-envoye_le", "-pk")[:500])
    return JsonResponse({"messages": [m.en_donnees() for m in reversed(messages)]})


def _hote(request, code):
    invitation = _invitation(code)
    _dans_la_salle(request, invitation)
    if not invitation.est_hote:
        raise Http404
    return invitation


@never_cache
@require_GET
def attente(request, code):
    hote = _hote(request, code)
    s = hote.salle
    groupes.en_cours(s)  # ferme les groupes dont l'heure est passée
    # Le rattrapage côté LiveKit (audit V-02), au plus toutes les 20 s par séance.
    from django.core.cache import cache

    if cache.add(f"jeiko:visio:rattrapage:{s.pk}", 1, 20):
        acces.reconcilier(s)
    return JsonResponse({
        "attente": [{"identite": i.identite, "nom": i.nom} for i in acces.en_attente(s)],
        "verrouillee": s.verrouillee,
        "groupes": groupes.etat(s),
    })


GESTES = ("admettre", "refuser", "parole", "couper", "exclure", "verrouiller", "terminer",
          "preparer_sondage", "lancer_sondage", "clore_sondage",
          "ouvrir_groupes", "fermer_groupes", "visiter_groupe", "annoncer_aux_groupes")


@never_cache
@require_POST
def geste(request, code, nom):
    hote = _hote(request, code)
    if nom not in GESTES:
        raise Http404
    s = hote.salle
    try:
        corps = _corps(request)
        if nom == "verrouiller":
            s.verrouillee = bool(corps.get("valeur"))
            s.save(update_fields=["verrouillee"])
        elif nom == "terminer":
            acces.terminer(s)
        elif nom == "preparer_sondage":
            sondage = sondages.preparer(s, corps.get("question"), corps.get("choix"), corps.get("plusieurs"))
            if corps.get("lancer"):
                sondages.lancer(sondage)
            return JsonResponse({"ok": True, "sondage": sondage.en_donnees(avec_resultats=True)})
        elif nom == "ouvrir_groupes":
            repartition = corps.get("repartition")
            etat = groupes.ouvrir(s, corps.get("nombre"), corps.get("duree") or 0,
                                  repartition if isinstance(repartition, dict) else None)
            return JsonResponse({"ok": True, "groupes": etat})
        elif nom == "fermer_groupes":
            groupes.fermer(s)
        elif nom == "visiter_groupe":
            groupes.visiter(s, hote, _entier(corps, "groupe"))
        elif nom == "annoncer_aux_groupes":
            groupes.annoncer_aux_groupes(s, corps.get("texte"))
        elif nom in ("lancer_sondage", "clore_sondage"):
            sondage = get_object_or_404(s.sondages, pk=_entier(corps, "sondage"))
            (sondages.lancer if nom == "lancer_sondage" else sondages.clore)(sondage)
        else:
            cible = acces.cible(s, corps.get("identite"))
            if nom == "admettre":
                acces.admettre(s, cible)
            elif nom == "refuser":
                acces.revoquer(cible)
            elif nom == "parole":
                acces.donner_la_parole(s, cible, bool(corps.get("valeur")))
            elif nom == "couper":
                livekit.couper(s.identifiant_livekit, cible.identite, str(corps.get("piste") or ""))
            elif nom == "exclure":
                acces.exclure(s, cible)
    except acces.Refus as refus:
        return JsonResponse({"erreur": str(refus)}, status=400)
    except livekit.LiveKitIndisponible as erreur:
        return _indisponible(erreur)
    return JsonResponse({"ok": True})


@never_cache
def liste_des_sondages(request, code):
    """Hôte : tous, avec les totaux en direct. Les autres : ouverts et clos, avec leur propre vote."""
    invitation = _invitation(code)
    _dans_la_salle(request, invitation)
    s = invitation.salle
    tous = s.sondages.prefetch_related("votes") if invitation.est_hote else s.sondages.exclude(etat="prepare")
    mes_votes = dict(invitation.votes.filter(sondage__salle=s).values_list("sondage_id", "choix"))
    return JsonResponse({"sondages": [{**p.en_donnees(avec_resultats=invitation.est_hote),
                                       "mon_vote": mes_votes.get(p.pk, [])} for p in tous]})


@never_cache
@require_POST
def voter(request, code, sondage_id):
    invitation = _invitation(code)
    _dans_la_salle(request, invitation)
    sondage = get_object_or_404(invitation.salle.sondages, pk=sondage_id)
    try:
        sondages.voter(sondage, invitation, _corps(request).get("choix"))
    except acces.Refus as refus:
        return JsonResponse({"erreur": str(refus)}, status=400)
    return JsonResponse({"ok": True})


@never_cache
@require_POST
def deposer(request, code):
    invitation = _invitation(code)
    _dans_la_salle(request, invitation)
    # Dans un groupe de travail, tout le monde parle — et dépose (audit V-16).
    if not (invitation.peut_publier() or acces.lieu(invitation)[0] is not None):
        raise Http404
    if throttling.hit("visio:fichier", invitation.pk, 20, 3600):
        return JsonResponse({"erreur": _("Trop de fichiers : patientez un peu.")}, status=429)
    televerse = request.FILES.get("fichier")
    if televerse is None:
        return JsonResponse({"erreur": _("Aucun fichier.")}, status=400)
    try:
        message = fichiers.deposer(invitation, televerse)
    except fichiers.FichierRefuse as refus:
        return JsonResponse({"erreur": str(refus)}, status=400)
    except livekit.LiveKitIndisponible as erreur:
        return _indisponible(erreur)
    return JsonResponse(message.en_donnees(), status=201)


@never_cache
@require_GET
def telecharger(request, code, fichier_id):
    invitation = _invitation(code)
    _dans_la_salle(request, invitation)
    fichier = get_object_or_404(invitation.salle.fichiers, pk=fichier_id)
    if not fichiers.peut_telecharger(invitation, fichier):
        raise Http404
    return _prive(fichiers.servir(fichier))


@never_cache
@require_GET
def document(request, code, fichier_id):
    """
    Un document partagé au suivi, par le lien personnel de l'invité — sans
    entrer dans la salle, la séance finie. Seulement ce qui a été partagé, de
    la salle principale ; jamais pour un lien révoqué.
    """
    invitation = _invitation(code)
    fichier = get_object_or_404(invitation.salle.fichiers, pk=fichier_id, partage=True, sous_salle__isnull=True)
    return _prive(fichiers.servir(fichier))


__all__ = ["salle", "entrer", "sortie", "chat", "attente", "geste", "Invitation"]
