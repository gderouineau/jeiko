from django.urls import path

from . import vues_inscription, vues_publiques as vues

app_name = "jeiko_visio"

urlpatterns = [
    # Avant « <code>/… » : « livekit » n'est pas un code de lien.
    path("livekit/evenements/", vues.evenements_livekit, name="evenements_livekit"),
    path("seance/<uuid:jeton>/", vues_inscription.seance, name="seance"),
    path("seance/<uuid:jeton>/confirmer/<str:cle>/", vues_inscription.confirmer, name="confirmer"),
    path("<str:code>/desinscrire/", vues_inscription.desinscrire, name="desinscrire"),
    path("<str:code>/", vues.salle, name="salle"),
    path("<str:code>/entrer/", vues.entrer, name="entrer"),
    path("<str:code>/sortie/", vues.sortie, name="sortie"),
    path("<str:code>/chat/", vues.chat, name="chat"),
    path("<str:code>/fichiers/", vues.deposer, name="deposer"),
    path("<str:code>/sondages/", vues.liste_des_sondages, name="sondages"),
    path("<str:code>/sondages/<int:sondage_id>/voter/", vues.voter, name="voter"),
    path("<str:code>/fichiers/<int:fichier_id>/", vues.telecharger, name="telecharger"),
    path("<str:code>/documents/<int:fichier_id>/", vues.document, name="document"),
    path("<str:code>/hote/attente/", vues.attente, name="attente"),
    path("<str:code>/hote/<str:nom>/", vues.geste, name="geste"),
]
