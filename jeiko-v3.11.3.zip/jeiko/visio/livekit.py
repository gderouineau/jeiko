"""
Parler à LiveKit, le serveur qui transporte le son et l'image (VISIO-01).

Deux choses seulement, et pas de bibliothèque de plus :

* le JETON D'ACCÈS qu'un navigateur présente à LiveKit pour entrer dans une
  salle — un JWT HS256 signé avec le secret de la clé du site (PyJWT est déjà
  là pour allauth). Ses droits disent tout ce que la personne peut faire :
  JEIKO ne le délivre qu'après avoir vérifié le lien, le rôle, la salle
  d'attente et le verrou ;
* l'API SERVEUR (Twirp en JSON, `/twirp/livekit.RoomService/<Méthode>`) pour
  les gestes de l'hôte : donner la parole, couper un micro, exclure, diffuser
  un message de chat, fermer la salle. Ces appels portent un jeton
  `roomAdmin` qui ne quitte jamais le serveur.

Ce que ce module ne fait pas : décider qui a le droit de quoi (`acces.py`),
ni rien enregistrer (`models.py`). Une panne de LiveKit lève `LiveKitIndisponible`
— à l'appelant de dire quelque chose d'utile plutôt qu'une page 500.
"""
import base64
import json
import time

import jwt
import requests
from django.conf import settings

#: Plafond en dur, décidé par Guillaume le 12/10/2026 : au-delà, il faudrait
#: une diffusion (HLS) et un serveur dimensionné pour.
MAX_PARTICIPANTS = 50

#: Durée d'un jeton d'entrée : il ne sert qu'à OUVRIR la connexion — LiveKit
#: renouvelle ensuite lui-même celui d'une personne connectée.
DUREE_DU_JETON = 10 * 60

DELAI_API = 5


class LiveKitIndisponible(Exception):
    """LiveKit n'est pas configuré, ou ne répond pas comme prévu."""


def configuration():
    """(clé, secret, adresse de l'API) — ou lève si la visio n'est pas réglée."""
    cle = getattr(settings, "JEIKO_VISIO_CLE", "") or ""
    secret = getattr(settings, "JEIKO_VISIO_SECRET", "") or ""
    if not (cle and secret):
        raise LiveKitIndisponible("JEIKO_VISIO_CLE et JEIKO_VISIO_SECRET ne sont pas réglés.")
    api = (getattr(settings, "JEIKO_VISIO_API", "") or "http://127.0.0.1:7880").rstrip("/")
    return cle, secret, api


def est_configure():
    try:
        configuration()
    except LiveKitIndisponible:
        return False
    return True


def adresse_publique(request):
    """L'adresse websocket que le NAVIGATEUR ouvre : celle du site, sauf réglage contraire."""
    reglee = getattr(settings, "JEIKO_VISIO_URL", "") or ""
    if reglee:
        return reglee
    schema = "wss" if request.is_secure() else "ws"
    return f"{schema}://{request.get_host()}/visio-rtc"


def _signer(identite, video, *, nom="", metadonnees=None, duree=DUREE_DU_JETON):
    cle, secret, _api = configuration()
    maintenant = int(time.time())
    revendications = {
        "iss": cle, "sub": identite, "nbf": maintenant - 5, "exp": maintenant + duree,
        "video": video,
    }
    if nom:
        revendications["name"] = nom
    if metadonnees is not None:
        revendications["metadata"] = json.dumps(metadonnees)
    return jwt.encode(revendications, secret, algorithm="HS256")


def jeton_d_entree(salle_livekit, identite, *, nom, publier, sources=None, metadonnees=None):
    """
    Le jeton qu'un navigateur présente pour entrer. `publier` : peut-il montrer
    son image et sa voix ; `sources` : lesquelles (camera, microphone,
    screen_share, screen_share_audio). Le canal de données reste ouvert à
    tous (mains levées) ; le chat, lui, ne passe que par JEIKO.
    """
    video = {
        "room": salle_livekit, "roomJoin": True, "canSubscribe": True,
        "canPublish": bool(publier), "canPublishData": True, "canUpdateOwnMetadata": False,
    }
    if publier and sources:
        video["canPublishSources"] = list(sources)
    return _signer(identite, video, nom=nom, metadonnees=metadonnees)


def _appeler(methode, corps, salle_livekit=""):
    cle, _secret, api = configuration()
    video = {"roomAdmin": True, "roomCreate": True, "roomList": True}
    if salle_livekit:
        video["room"] = salle_livekit
    jeton = _signer("jeiko", video, duree=60)
    try:
        reponse = requests.post(
            f"{api}/twirp/livekit.RoomService/{methode}", json=corps, timeout=DELAI_API,
            headers={"Authorization": f"Bearer {jeton}"},
        )
    except requests.RequestException as erreur:
        raise LiveKitIndisponible(f"LiveKit ne répond pas ({api}) : {erreur}") from erreur
    if reponse.status_code == 404 and methode != "ListRooms":
        # Twirp répond 404 « not_found » quand la salle ou la personne n'est
        # plus là : rien à faire, ce n'est pas une panne.
        return {}
    if reponse.status_code != 200:
        raise LiveKitIndisponible(f"LiveKit a refusé {methode} : {reponse.status_code} {reponse.text[:200]}")
    return reponse.json() if reponse.content else {}


def ouvrir_la_salle(salle_livekit):
    """Crée la salle (ou la retrouve) avec le plafond de participants."""
    return _appeler("CreateRoom", {
        "name": salle_livekit, "max_participants": MAX_PARTICIPANTS,
        "empty_timeout": 10 * 60, "departure_timeout": 60,
    })


def permissions(salle_livekit, identite, *, publier, sources=None):
    """Donner ou reprendre la parole à une personne connectée."""
    permission = {"can_subscribe": True, "can_publish": bool(publier), "can_publish_data": True}
    if publier and sources:
        permission["can_publish_sources"] = [s.upper() for s in sources]
    return _appeler("UpdateParticipant", {"room": salle_livekit, "identity": identite,
                                          "permission": permission}, salle_livekit)


def couper(salle_livekit, identite, piste):
    return _appeler("MutePublishedTrack", {"room": salle_livekit, "identity": identite,
                                           "track_sid": piste, "muted": True}, salle_livekit)


def retirer(salle_livekit, identite):
    return _appeler("RemoveParticipant", {"room": salle_livekit, "identity": identite}, salle_livekit)


def diffuser(salle_livekit, sujet, donnees):
    """Envoie `donnees` (JSON) à toute la salle, sur le canal fiable, sous `sujet`."""
    charge = base64.b64encode(json.dumps(donnees).encode()).decode()
    return _appeler("SendData", {"room": salle_livekit, "data": charge, "kind": "RELIABLE",
                                 "topic": sujet}, salle_livekit)


def fermer(salle_livekit):
    return _appeler("DeleteRoom", {"room": salle_livekit}, salle_livekit)


def participants(salle_livekit):
    return _appeler("ListParticipants", {"room": salle_livekit}, salle_livekit).get("participants", [])


def tester():
    """Pour l'écran Réglages : LiveKit répond-il avec cette clé ? Rend le nombre de salles ouvertes."""
    return len(_appeler("ListRooms", {}).get("rooms", []))
