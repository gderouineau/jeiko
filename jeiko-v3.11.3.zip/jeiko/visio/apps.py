from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class VisioConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "jeiko.visio"
    label = "visio"
    verbose_name = _("Conférence")
