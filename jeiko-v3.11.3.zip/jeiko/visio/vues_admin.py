"""
Conférence, dans l'administration (VISIO-01) : les séances, leurs invités,
et l'état du serveur de visio.

Droits : ceux du modèle `Salle` (voir, ajouter, modifier, supprimer). Inviter
ou renvoyer un lien, c'est modifier la séance.
"""
import logging

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.exceptions import PermissionDenied
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _
from django.views import View
from django.views.decorators.cache import never_cache

from jeiko.listes import paginer

from . import acces, emails, livekit, suivi, vente
from . import fichiers as suivi_fichiers
from .forms import AnnulationForm, InscriptionsForm, InvitationForm, MessageForm, SalleForm
from .models import EvenementLiveKit, FichierDeSalle, Invitation, RemboursementDePlace, Salle

logger = logging.getLogger(__name__)

VOIR, AJOUTER, MODIFIER, SUPPRIMER = "visio.view_salle", "visio.add_salle", "visio.change_salle", "visio.delete_salle"


@method_decorator(never_cache, name="dispatch")
class _Acces(LoginRequiredMixin, PermissionRequiredMixin, View):
    raise_exception = True
    permission_required = VOIR
    onglet_actif = "seances"

    def rendre(self, gabarit, **contexte):
        contexte.setdefault("onglet", self.onglet_actif)
        contexte.setdefault("peut_modifier", self.request.user.has_perm(MODIFIER))
        contexte.setdefault("visio_configuree", livekit.est_configure())
        return render(self.request, gabarit, contexte)

    def exiger(self, permission):
        if not self.request.user.has_perm(permission):
            raise PermissionDenied


class Seances(_Acces):
    def get(self, request):
        passees = request.GET.get("quand") == "passees"
        maintenant = timezone.now()
        salles = Salle.objects.annotate(
            nb_invites=Count("invitations", filter=Q(invitations__revoquee_le__isnull=True)),
            nb_venus=Count("invitations", filter=Q(invitations__arrivee_le__isnull=False)))
        if passees:
            salles = salles.filter(Q(fin__lt=maintenant) | Q(terminee_le__isnull=False)).order_by("-debut")
        else:
            salles = salles.filter(fin__gte=maintenant, terminee_le__isnull=True).order_by("debut")
        objets, pagination = paginer(request, salles)
        return self.rendre("visio/admin/seances.html", salles=objets, passees=passees,
                           peut_ajouter=request.user.has_perm(AJOUTER), **pagination)


class NouvelleSeance(_Acces):
    permission_required = AJOUTER

    def get(self, request):
        debut = (timezone.localtime() + timezone.timedelta(days=1)).replace(minute=0, second=0, microsecond=0)
        form = SalleForm(initial={"debut": debut, "fin": debut + timezone.timedelta(hours=1)})
        return self.rendre("visio/admin/nouvelle.html", form=form)

    def post(self, request):
        form = SalleForm(request.POST)
        if not form.is_valid():
            return self.rendre("visio/admin/nouvelle.html", form=form)
        champs = {k: v for k, v in form.cleaned_data.items() if k not in ("titre", "debut", "fin")}
        salle = acces.creer_salle(titre=form.cleaned_data["titre"], debut=form.cleaned_data["debut"],
                                  fin=form.cleaned_data["fin"], cree_par=request.user, **champs)
        messages.success(request, _("Séance créée. Invitez maintenant les participants."))
        return redirect(salle)


class Fiche(_Acces):
    def contexte(self, salle, form=None, form_invitation=None, form_inscriptions=None):
        from jeiko.payments.models import PaymentGateway
        from jeiko.shop.models import ShopSettings

        invitations = salle.invitations.select_related("user", "contact").order_by("revoquee_le", "role", "nom")
        return {
            "form_inscriptions": form_inscriptions or InscriptionsForm(instance=salle),
            "inscrits": salle.invitations.filter(inscrite=True).select_related("commande").order_by("revoquee_le", "cree_le"),
            "attentes": salle.attentes.all(),
            "places_restantes": vente.places_restantes(salle),
            "lien_public": self.request.build_absolute_uri(reverse("jeiko_visio:seance", args=[salle.jeton_public])),
            "boutique_ouverte": ShopSettings.get_solo().is_online,
            "stripe_actif": PaymentGateway.objects.filter(code="stripe", is_active=True).exists(),
            "salle": salle, "form": form or SalleForm(instance=salle),
            "form_invitation": form_invitation or InvitationForm(),
            "invitations": invitations,
            "messages_chat": salle.messages.select_related("fichier").order_by("envoye_le")[:500],
            "max_participants": livekit.MAX_PARTICIPANTS,
            "nb_actives": salle.invitations_actives().count(),
            "mon_invitation": salle.invitations_actives().filter(user=self.request.user).first(),
            "presence": suivi.presence(salle),
            "sondages": [(p, list(zip(p.choix, p.resultats()))) for p in salle.sondages.prefetch_related("votes")],
            "form_message": MessageForm(),
            # L'onglet Suivi : les documents à partager, ce qui est déjà parti.
            "documents": suivi_fichiers.partageables(salle).select_related("auteur"),
            "envois": salle.envois.select_related("envoye_par").prefetch_related("documents"),
            "plafond_mo": suivi_fichiers.plafond_mo(),
            "annulable": not salle.terminee and salle.debut > timezone.now(),
            "form_annulation": AnnulationForm(),
            "places_payees": vente.places_payees(salle).count(),
        }

    def get(self, request, pk):
        salle = get_object_or_404(Salle, pk=pk)
        return self.rendre("visio/admin/fiche.html", **self.contexte(salle))

    def post(self, request, pk):
        self.exiger(MODIFIER)
        salle = get_object_or_404(Salle, pk=pk)
        form = SalleForm(request.POST, instance=salle)
        if not form.is_valid():
            return self.rendre("visio/admin/fiche.html", **self.contexte(salle, form=form))
        form.save()
        if salle.produit_id:
            vente.synchroniser(salle)
        messages.success(request, _("Séance enregistrée."))
        return redirect(salle)


class Inscriptions(_Acces):
    """V2-E — l'onglet « Inscriptions » : la séance ouverte au public, gratuite ou vendue."""

    permission_required = MODIFIER

    def post(self, request, pk):
        salle = get_object_or_404(Salle, pk=pk)
        form = InscriptionsForm(request.POST, instance=salle)
        if not form.is_valid():
            fiche = Fiche(request=request)
            return fiche.rendre("visio/admin/fiche.html",
                                **fiche.contexte(salle, form_inscriptions=form))
        salle = form.save()
        vente.synchroniser(salle)
        messages.success(request, _("Inscriptions enregistrées."))
        return redirect(reverse("jeiko_visio_admin:fiche", args=[salle.pk]) + "#inscriptions")


class Inviter(_Acces):
    permission_required = MODIFIER

    def post(self, request, pk):
        salle = get_object_or_404(Salle, pk=pk)
        form = InvitationForm(request.POST)
        if not form.is_valid():
            return Fiche(request=request).rendre("visio/admin/fiche.html",
                                                 **Fiche(request=request).contexte(salle, form_invitation=form))
        try:
            invitation = acces.inviter(salle, nom=form.cleaned_data["nom"], email=form.cleaned_data["email"],
                                       role=form.cleaned_data["role"])
        except acces.Refus as refus:
            messages.error(request, str(refus))
            return redirect(salle)
        if form.cleaned_data["envoyer"]:
            envoye, raison = emails.envoyer_l_invitation(invitation)
            if envoye:
                messages.success(request, _("%(nom)s est invité(e) ; le lien est parti par e-mail.") % {"nom": invitation.nom})
            else:
                messages.warning(request, _("%(nom)s est invité(e), mais l'e-mail n'est pas parti (%(raison)s). "
                                            "Copiez-lui son lien.") % {"nom": invitation.nom, "raison": raison})
        else:
            messages.success(request, _("%(nom)s est invité(e). Copiez-lui son lien.") % {"nom": invitation.nom})
        return redirect(salle)


class ActionSurUneInvitation(_Acces):
    permission_required = MODIFIER

    def post(self, request, pk, invitation_pk, action):
        invitation = get_object_or_404(Invitation, pk=invitation_pk, salle_id=pk)
        if action == "renvoyer":
            envoye, raison = emails.envoyer_l_invitation(invitation)
            if envoye:
                messages.success(request, _("Lien renvoyé à %(email)s.") % {"email": invitation.email})
            else:
                messages.error(request, _("E-mail non envoyé : %(raison)s") % {"raison": raison})
        elif action == "revoquer":
            if invitation.est_hote and invitation.user_id == request.user.pk:
                messages.error(request, _("Vous ne pouvez pas révoquer votre propre lien d'hôte."))
            else:
                acces.revoquer(invitation)
                # Salle principale et groupe ; LiveKit injoignable : le rattrapage suit (audit V-03).
                acces.retirer_partout(invitation.salle, invitation)
                messages.success(request, _("Lien de %(nom)s révoqué.") % {"nom": invitation.nom})
        return redirect(invitation.salle)


class Entrer(_Acces):
    """« Entrer dans la salle » depuis la fiche : le lien d'hôte de la personne connectée, créé au besoin."""

    def post(self, request, pk):
        salle = get_object_or_404(Salle, pk=pk)
        invitation = salle.invitations_actives().filter(user=request.user).first()
        if invitation is None:
            self.exiger(MODIFIER)
            try:
                invitation = acces.inviter(salle, user=request.user, role=Invitation.Role.HOTE)
            except acces.Refus as refus:
                messages.error(request, str(refus))
                return redirect(salle)
        return redirect(invitation)


class PresenceCsv(_Acces):
    """Le rapport de présence, pour un tableur (Excel français : point-virgule, BOM)."""

    def get(self, request, pk):
        import csv

        from django.http import HttpResponse

        from jeiko.shop.facturation_export import _texte as cellule

        salle = get_object_or_404(Salle, pk=pk)
        reponse = HttpResponse(content_type="text/csv; charset=utf-8")
        reponse["Content-Disposition"] = f'attachment; filename="presence-seance-{salle.pk}.csv"'
        reponse.write("\ufeff")
        ecrire = csv.writer(reponse, delimiter=";")
        ecrire.writerow([_("Nom"), _("E-mail"), _("Rôle"), _("Venu"), _("Arrivée"), _("Sortie"), _("Minutes")])
        heure = lambda d: timezone.localtime(d).strftime("%d/%m/%Y %H:%M") if d else ""
        for ligne in suivi.presence(salle):
            i = ligne["invitation"]
            # Une cellule qui commence par = + - @ (ou une tabulation) serait lue comme une formule.
            ecrire.writerow([cellule(i.nom), cellule(i.email), i.get_role_display(), _("oui") if ligne["venue"] else _("non"),
                             heure(ligne["arrivee"]), heure(ligne["sortie"]), ligne["minutes"]])
        return reponse


class EcrireAuxInvites(_Acces):
    permission_required = MODIFIER

    def post(self, request, pk):
        salle = get_object_or_404(Salle, pk=pk)
        form = MessageForm(request.POST)
        if not form.is_valid():
            messages.error(request, _("Objet et message sont obligatoires."))
            return redirect(salle)
        nombre = suivi.ecrire_aux_invites(salle, objet=form.cleaned_data["objet"], message=form.cleaned_data["message"],
                                          destinataires=form.cleaned_data["destinataires"],
                                          documents=[int(d) for d in request.POST.getlist("documents") if d.isdigit()],
                                          par=request.user)
        messages.success(request, _("%(n)s message(s) envoyé(s).") % {"n": nombre})
        return redirect(reverse("jeiko_visio_admin:fiche", args=[salle.pk]) + "#suivi")


class DeposerUnDocument(_Acces):
    """Onglet Suivi : un document déposé depuis la fiche, partagé aux invités."""
    permission_required = MODIFIER

    def post(self, request, pk):
        salle = get_object_or_404(Salle, pk=pk)
        televerse = request.FILES.get("fichier")
        if televerse is None:
            messages.error(request, _("Choisissez un fichier."))
        else:
            try:
                suivi_fichiers.deposer_pour_le_suivi(salle, televerse)
            except suivi_fichiers.FichierRefuse as refus:
                messages.error(request, str(refus))
            else:
                messages.success(request, _("Document déposé : les invités le téléchargeront par leur lien."))
        return redirect(reverse("jeiko_visio_admin:fiche", args=[salle.pk]) + "#suivi")


class PartagerUnFichier(_Acces):
    """Onglet Suivi : partager (ou ne plus partager) un fichier de la salle principale."""
    permission_required = MODIFIER

    def post(self, request, pk, fichier_pk):
        fichier = get_object_or_404(suivi_fichiers.partageables(get_object_or_404(Salle, pk=pk)), pk=fichier_pk)
        fichier.partage = not fichier.partage
        fichier.save(update_fields=["partage"])
        return redirect(reverse("jeiko_visio_admin:fiche", args=[pk]) + "#suivi")


class PreparerSondage(_Acces):
    permission_required = MODIFIER

    def post(self, request, pk):
        from . import sondages

        salle = get_object_or_404(Salle, pk=pk)
        choix = (request.POST.get("choix") or "").splitlines()
        try:
            sondages.preparer(salle, request.POST.get("question"), choix, request.POST.get("plusieurs") == "on")
        except acces.Refus as refus:
            messages.error(request, str(refus))
        else:
            messages.success(request, _("Sondage préparé : l'hôte le lancera depuis la salle."))
        return redirect(salle)


class FichierDeLaSeance(_Acces):
    """GET : télécharger un fichier déposé ; POST : le supprimer (modifier la séance)."""

    def get(self, request, pk, fichier_pk):
        from .fichiers import servir

        return servir(get_object_or_404(FichierDeSalle, pk=fichier_pk, salle_id=pk))

    def post(self, request, pk, fichier_pk):
        self.exiger(MODIFIER)
        fichier = get_object_or_404(FichierDeSalle, pk=fichier_pk, salle_id=pk)
        fichier.delete()
        messages.success(request, _("Fichier supprimé."))
        return redirect(reverse("jeiko_visio_admin:fiche", args=[pk]) + "#suivi")


class Annuler(_Acces):
    """VISIO-03 — l'organisateur annule : liens révoqués, places remboursées selon la grille, invités prévenus."""

    permission_required = MODIFIER

    def post(self, request, pk):
        salle = get_object_or_404(Salle, pk=pk)
        form = AnnulationForm(request.POST)
        if not form.is_valid():
            messages.error(request, _("Cochez la confirmation pour annuler la séance."))
            return redirect(salle)
        try:
            bilan = vente.annuler(salle, form.cleaned_data["motif"])
        except acces.Refus as refus:
            messages.error(request, str(refus))
            return redirect(salle)
        messages.success(request, _("Séance annulée : %(invites)s invité(s) prévenu(s) ; %(rembourses)s place(s) "
                                    "remboursée(s) pour %(montant)s %(devise)s ; %(sans)s sans remboursement "
                                    "selon la grille. Les remboursements se suivent dans Conférence › "
                                    "Remboursements.")
                         % {"invites": bilan["invites"], "rembourses": bilan["rembourses"],
                            "montant": bilan["montant"], "devise": salle.devise,
                            "sans": bilan["sans_remboursement"]})
        return redirect(salle)


class Supprimer(_Acces):
    permission_required = SUPPRIMER

    def post(self, request, pk):
        salle = get_object_or_404(Salle, pk=pk)
        payees = vente.places_payees(salle).count()
        if payees:
            # Supprimer effaçait les inscriptions et laissait les commandes
            # payées, sans remboursement (audit V-13).
            messages.error(request, _("%(n)s place(s) payée(s) : remboursez-les depuis leurs commandes (onglet "
                                      "Inscriptions) avant de supprimer la séance.") % {"n": payees})
            return redirect(salle)
        try:
            livekit.fermer(salle.identifiant_livekit)
        except livekit.LiveKitIndisponible as erreur:
            # Le serveur n'a peut-être jamais vu cette salle : la supprimer ici suffit.
            logger.info("Visio : fermeture de la salle %s non transmise — %s", salle.pk, erreur)
        salle.delete()
        messages.success(request, _("Séance supprimée."))
        return redirect("jeiko_visio_admin:seances")


class Serveur(_Acces):
    onglet_actif = "serveur"

    def get(self, request):
        etat, detail = "non_configure", ""
        if livekit.est_configure():
            try:
                detail = livekit.tester()
                etat = "ok"
            except livekit.LiveKitIndisponible as erreur:
                etat, detail = "injoignable", str(erreur)
        dernier = EvenementLiveKit.objects.order_by("-recu_le").first()
        return self.rendre("visio/admin/serveur.html", etat=etat, detail=detail,
                           adresse=livekit.adresse_publique(request), max_participants=livekit.MAX_PARTICIPANTS,
                           dernier_evenement=dernier.recu_le if dernier else None)


class Remboursements(_Acces):
    """
    Les places payées qui n'ont pu être livrées (audit V-07) : la file, ses
    essais, et les deux gestes quand l'automatique n'a pas suffi.
    """
    onglet_actif = "remboursements"

    def get(self, request):
        a_regler = Q(etat__in=[RemboursementDePlace.Etat.A_FAIRE, RemboursementDePlace.Etat.EN_ECHEC])
        lignes = RemboursementDePlace.objects.select_related("salle").order_by("-cree_le")
        objets, pagination = paginer(request, lignes)
        return self.rendre("visio/admin/remboursements.html", page=objets, **pagination,
                           nb_a_regler=RemboursementDePlace.objects.filter(a_regler).count())

    def post(self, request, pk, action):
        self.exiger(MODIFIER)
        a_faire = get_object_or_404(RemboursementDePlace, pk=pk)
        try:
            if action == "reessayer":
                a_faire = vente.reessayer(a_faire)
                if a_faire.etat == RemboursementDePlace.Etat.FAIT:
                    messages.success(request, _("Remboursement effectué."))
                else:
                    messages.error(request, _("Le remboursement a encore échoué : %(e)s") % {"e": a_faire.derniere_erreur})
            elif action == "a_la_main":
                vente.regler_a_la_main(a_faire)
                messages.success(request, _("Noté comme réglé à la main."))
            else:
                raise PermissionDenied
        except acces.Refus as refus:
            messages.error(request, str(refus))
        return redirect("jeiko_visio_admin:remboursements")
