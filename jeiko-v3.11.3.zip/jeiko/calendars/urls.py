from jeiko.calendars.views import (
    GoogleCalendarConfigView, GoogleCalendarConfigListAllView, GoogleCalendarAdminListView,
    AvailabilityListView, AvailabilityCreateView, AvailabilityDeleteView, AvailabilityUpdateView,
    AppointmentAdminCancelView, AppointmentAttendanceView,
    AppointmentUpcomingListView, AppointmentPastListView, SeancesView, BloquerDesPlacesView, OffrirDesCreditsView,
    AppointmentDetailView, AppointmentUpdateView, AppointmentClientCreateView,
    AppointmentRefundView,
    AppointmentTypeListView, AppointmentTypeCreateView, AppointmentTypeUpdateView, AppointmentTypeDeleteView
                                   )
from django.urls import path


app_name = "jeiko_administration_calendars"

urlpatterns = [
    path("google-config/", GoogleCalendarConfigView.as_view(), name="google_config"),
    # Supervision : configuration d'un autre gestionnaire (super-admin uniquement)
    path("google-config/<int:user_id>/", GoogleCalendarConfigView.as_view(), name="google_config_user"),
    path("google-configs/all/", GoogleCalendarConfigListAllView.as_view(), name="google_configs_all"),
    path("calendar/", GoogleCalendarAdminListView.as_view(), name="calendar_list"),
    path("calendar/<int:user_id>/", GoogleCalendarAdminListView.as_view(), name="calendar_list_user"),

    path("appointment-types/", AppointmentTypeListView.as_view(), name="appointmenttype_list"),
    path("appointment-types/create/", AppointmentTypeCreateView.as_view(), name="appointmenttype_create"),
    path("appointment-types/<int:pk>/update/", AppointmentTypeUpdateView.as_view(), name="appointmenttype_update"),
    path("appointment-types/<int:pk>/delete/", AppointmentTypeDeleteView.as_view(), name="appointmenttype_delete"),


    path("availabilities/", AvailabilityListView.as_view(), name="availability_list"),
    path("availabilities/add/", AvailabilityCreateView.as_view(), name="availability_add"),
    path("availabilities/<int:pk>/edit/", AvailabilityUpdateView.as_view(), name="availability_edit"),
    path("availabilities/<int:pk>/delete/", AvailabilityDeleteView.as_view(), name="availability_delete"),

    path("appointments/", AppointmentUpcomingListView.as_view(), name="appointment_list_upcoming"),
    path("appointments/past", AppointmentPastListView.as_view(), name="appointment_list_past"),
    # CAL-01 : créneau par créneau, qui est inscrit (cours collectifs surtout).
    path("appointments/seances/", SeancesView.as_view(), name="seances"),
    path("creneaux/<int:pk>/bloquer/", BloquerDesPlacesView.as_view(), name="slot_bloquer"),
    path("membres/<int:user_id>/credits/offrir/", OffrirDesCreditsView.as_view(), name="credits_offrir"),
    path("appointments/<int:pk>/", AppointmentDetailView.as_view(), name="appointment_detail"),
    path("appointments/<int:pk>/edit/", AppointmentUpdateView.as_view(), name="appointment_update"),
    # Création d'un RDV par un gestionnaire pour un client inscrit (user_id = client)
    path("appointments/create/for/<int:user_id>/", AppointmentClientCreateView.as_view(), name="appointment_create_for_user"),
    # Annulation par le gestionnaire (authentifiée + restreinte à son calendrier).
    # L'annulation par le client passe par jeiko.calendars.urls_public (jeton UUID).
    path('appointment/cancel/<int:pk>/', AppointmentAdminCancelView.as_view(), name="appointment_cancel"),
    path("appointments/<int:pk>/presence/", AppointmentAttendanceView.as_view(), name="appointment_attendance"),
    path("appointments/<int:pk>/refund/", AppointmentRefundView.as_view(), name="appointment_refund"),

]
