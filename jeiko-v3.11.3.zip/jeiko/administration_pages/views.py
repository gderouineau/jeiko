from django.contrib.auth.decorators import permission_required
from django.contrib.auth.mixins import PermissionRequiredMixin, LoginRequiredMixin
from django.core.cache import cache
from django.core.exceptions import PermissionDenied


import copy
import json
import datetime
from django.conf import settings
from django.http import Http404, JsonResponse, HttpResponse, HttpResponseBadRequest
from django.views.decorators.http import require_GET
from django.shortcuts import render, redirect, get_object_or_404, reverse
from django.template.loader import render_to_string
from django.views import View
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages
from jeiko.administration_pages import apparence, fabrique
from jeiko.administration_pages.content_types import groups_for
from django.db import transaction
from django.db.models import OuterRef, Subquery, F, FloatField, ExpressionWrapper
from django.db.models.functions import Coalesce
from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache
from django.views.decorators.clickjacking import xframe_options_exempt
from copy import deepcopy

import logging
from django.utils.translation import gettext_lazy as _

logger = logging.getLogger(__name__)

from jeiko.administration_pages.forms import (
    PageForm, MetadataForm, SectionForm, LineForm, MarginForm, PaddingForm,
    ImageForm, MediaLibraryImageForm, TextForm, CSSParametersForm, ContentImageForm, MainCategoryForm, SubCategoryForm, MainCategoryFormPage,
    SubCategoryFormPage, StyleBoxForm, SizeForm, BlocSizeForm, ButtonContentForm, ContentCalendarForm,
    BackgroundImageForm, BackgroundImageParametersForm, ContentVideoForm,

    # dyn générique
    DynamicContentForm,
    # dyn typés + options
    FAQItemFormSet, FAQOptionsForm,
    TabItemFormSet, TabsOptionsForm,
    CarouselSlideFormSet, CarouselBulkUploadForm, CarouselOptionsForm,
    ProgressStepFormSet, ProgressOptionsForm,
    TestimonialItemFormSet, TestimonialsSliderOptionsForm, TestimonialsGridOptionsForm,
    LiveFilterItemFormSet, LiveFilterOptionsForm,
    AccordionSectionFormSet, AccordionChildFormSetFactory,
    PricingPlanFormSet, PricingFeatureFormSetFactory, PricingOptionsForm,
    GalleryItemFormSet, GalleryOptionsForm,
    StepperStepFormSet, StepperOptionsForm,
    RatingOptionsForm, NewsletterBlocForm, CountdownOptionsForm, CountdownCTAOptionsForm,
    DynResourceConfigForm,
    )
from jeiko.administration_pages.models import (
    Page, Metadata, Strategy, PageInsights, InsightAuditOutcome, InsightAuditCategory,
    Section, Line, Margin, Padding, Size, ImageContent, Bloc, CustomCSS, Animation,
    Content, ContentImage, ContentText, CSSParameters, Category, ContentButton, ContentCalendar, ContentFormulaire,
    ContentChartQuestionnaire, BackgroundImageParameters, ContentVideo,
    # DYN models
    DynFAQItem, DynTabItem, DynCarouselSlide, DynProgressStep,
    DynTestimonialItem, DynLiveFilterItem,
    DynAccordionSection, DynAccordionChild,
    DynPricingPlan, DynPricingFeature,
    DynGalleryItem, DynStepperStep,
    DynResourceConfig,
)
from jeiko.administration_pages.responses import (
    render_section, section_response, line_response, modal_response, ok_response, error_response,
)
from jeiko.administration_pages.utils import (
    make_unique_url_tag, duplicate_instance, champs_du_contenu_a_ne_pas_recopier,
    get_section_forms_context, get_line_forms_context, get_bloc_forms_context,
    build_bound_inline_formset, resequence_queryset, _snapshot_for_content, _save_style_and_sizes,
    build_image_urls_4, _errors_dict, ensure_sequential_orders, resequence, editing_menu,
    section_duplicate, line_duplicate, bloc_duplicate,
    save_border_for_section, save_border_for_line,
    get_latest_insight, get_google_api_key
    )

from jeiko.administration.models import GoogleApi
from django.db.models import Count
from jeiko.redirections import destination_sure
from jeiko.administration_pages.forms import PageForm, VersionForm
from jeiko.langues_du_site import nom_de_la_langue

from jeiko.administration_pages.models import StyleBox
from jeiko.calendars.models import GoogleCalendarConfig
decorators = [never_cache]

from .mixins import AsyncRequestMixin
from .media_library import (
    delete_image_safely, image_preview_url, image_usage_count_map, image_usages,
    versions_qui_l_utilisent,
)


class Main(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/main.html'
    permission_required = 'administration_pages.view_page'
    raise_exception = True



    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        # Les ateliers des modèles ne sont pas des pages du site.
        pages = Page.objects.exclude(is_model_workshop=True)
        main_categories = Category.objects.filter(main_category__isnull=True)
        context = {
            'pages': pages,
            'main_categories': main_categories,
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        # même rendu (si tu ajoutes des filtres POST plus tard, tu pourras les appliquer ici)
        # Les ateliers des modèles ne sont pas des pages du site.
        pages = Page.objects.exclude(is_model_workshop=True)
        main_categories = Category.objects.filter(main_category__isnull=True)
        context = {
            'pages': pages,
            'main_categories': main_categories,
        }
        return render(request, self.template_name, context)


class MediaLibraryList(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration_pages/media/list.html"
    permission_required = "administration_pages.view_imagecontent"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request):
        from django.db.models import Q

        images = ImageContent.objects.order_by("-created_at", "-pk")
        # A-09 : ni décrites ni déclarées décoratives — des oublis à corriger.
        a_completer = Q(decorative=False) & (Q(alt__isnull=True) | Q(alt=""))
        nombre_a_completer = images.filter(a_completer).count()
        filtre = request.GET.get("filtre") == "a-completer"
        if filtre:
            images = images.filter(a_completer)

        paginator = Paginator(images, 48)
        page_obj = paginator.get_page(request.GET.get("page"))
        images = list(page_obj.object_list)
        comptes = image_usage_count_map(images, avec_l_historique=False)
        for image in images:
            image.usage_count = comptes.get(image.pk, 0)
            image.preview_url = image_preview_url(image)
        page_obj.object_list = images
        return render(request, self.template_name, {
            "page_obj": page_obj,
            "nombre_a_completer": nombre_a_completer,
            "filtre_a_completer": filtre,
        })


class MediaImageCreate(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration_pages/media/form.html"
    permission_required = "administration_pages.add_imagecontent"
    raise_exception = True

    def get(self, request):
        return render(request, self.template_name, {
            "form": MediaLibraryImageForm(), "creating": True,
        })

    def post(self, request):
        form = MediaLibraryImageForm(request.POST, request.FILES)
        if form.is_valid():
            image = form.save()
            messages.success(request, _("Image n°%(pk)s ajoutée à la médiathèque.") % {"pk": image.pk})
            return redirect("jeiko_administration_pages:media_list")
        return render(request, self.template_name, {"form": form, "creating": True}, status=400)


class MediaEnvoiFichier(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    MED-01 — une image de l'envoi multiple (glisser-déposer ou plusieurs
    fichiers choisis d'un coup). Le navigateur envoie les fichiers un par un
    et affiche l'état de chacun : une image refusée (format, taille) ne fait
    pas échouer les autres.

    Le texte alternatif n'est pas demandé ici : il se saisit juste après,
    image par image, sur la même page (`MediaTextesAlternatifs`). D'ici là,
    l'image est « à compléter », comme toute image non décrite.
    Format et taille : les validateurs du champ (`valider_l_image`).
    """

    permission_required = "administration_pages.add_imagecontent"
    raise_exception = True
    http_method_names = ["post"]

    def post(self, request):
        import pathlib

        from django.http import JsonResponse

        from .forms import EnvoiDImageForm

        fichier = request.FILES.get("fichier")
        if fichier is None:
            return JsonResponse({"erreur": str(_("Aucun fichier reçu."))}, status=400)
        titre = pathlib.Path(fichier.name).stem.replace("_", " ").replace("-", " ").strip()[:120]
        form = EnvoiDImageForm({"title": titre}, {"original_image": fichier})
        if not form.is_valid():
            erreurs = [str(e) for liste in form.errors.values() for e in liste]
            return JsonResponse({"erreur": " ".join(erreurs) or str(_("Image refusée."))}, status=400)
        image = form.save()
        return JsonResponse({"id": image.pk, "titre": image.title or "", "apercu": image_preview_url(image) or "",
                             "nom": fichier.name}, status=201)


class MediaTextesAlternatifs(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    MED-01 — décrire d'un coup les images qui viennent d'arriver : un texte
    alternatif par image, ou « décorative ». Une image laissée vide reste
    « à compléter » (le filtre de la médiathèque la retrouve) — on ne
    l'invente pas, et on ne bloque pas les autres.
    """

    permission_required = "administration_pages.change_imagecontent"
    raise_exception = True
    http_method_names = ["post"]

    def post(self, request):
        ids = [int(i) for i in request.POST.getlist("ids") if str(i).isdigit()]
        decrites = restantes = 0
        for image in ImageContent.objects.filter(pk__in=ids):
            alt = (request.POST.get(f"alt_{image.pk}") or "").strip()[:255]
            decorative = request.POST.get(f"deco_{image.pk}") == "on"
            if decorative:
                image.alt, image.decorative = "", True
            elif alt:
                image.alt, image.decorative = alt, False
            else:
                restantes += 1
                continue
            image.save(update_fields=["alt", "decorative"])
            decrites += 1
        if decrites:
            messages.success(request, _("%(n)s image(s) décrite(s).") % {"n": decrites})
        if restantes:
            messages.warning(request, _("%(n)s image(s) restent à compléter : le filtre « à compléter » les retrouve.")
                             % {"n": restantes})
        return redirect("jeiko_administration_pages:media_list")


class MediaImageUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration_pages/media/form.html"
    permission_required = "administration_pages.change_imagecontent"
    raise_exception = True

    def get_object(self, pk):
        return get_object_or_404(ImageContent, pk=pk)

    def get(self, request, pk):
        image = self.get_object(pk)
        return render(request, self.template_name, {
            "form": MediaLibraryImageForm(instance=image),
            "image": image,
            "preview_url": image_preview_url(image),
            "creating": False,
        })

    def post(self, request, pk):
        image = self.get_object(pk)
        form = MediaLibraryImageForm(request.POST, request.FILES, instance=image)
        if form.is_valid():
            with transaction.atomic():
                form.save()
            messages.success(request, _("Image n°%(pk)s mise à jour.") % {"pk": image.pk})
            return redirect("jeiko_administration_pages:media_list")
        return render(request, self.template_name, {
            "form": form,
            "image": image,
            "preview_url": image_preview_url(image),
            "creating": False,
        }, status=400)


class MediaImageDelete(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration_pages/media/delete.html"
    permission_required = "administration_pages.delete_imagecontent"
    raise_exception = True

    def get_object(self, pk):
        return get_object_or_404(ImageContent, pk=pk)

    def context(self, image, usages=None):
        usages = image_usages(image) if usages is None else usages
        return {
            "image": image,
            "preview_url": image_preview_url(image),
            "usage_groups": usages,
            "usage_total": sum(groupe.count for groupe in usages),
            "versions_historique": versions_qui_l_utilisent(image).count(),
        }

    def get(self, request, pk):
        return render(request, self.template_name, self.context(self.get_object(pk)))

    def post(self, request, pk):
        image = self.get_object(pk)
        resultat = delete_image_safely(image)
        if resultat.deleted:
            messages.success(request, resultat.message)
            return redirect("jeiko_administration_pages:media_list")
        messages.error(request, resultat.message)
        return render(
            request,
            self.template_name,
            self.context(image, resultat.usages),
            status=409,
        )


class SeePage(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/view.html'

    permission_required = 'administration_pages.view_page'
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_id = kwargs['page_id']

        page = get_object_or_404(
            Page,
            id=page_id,

        )

        context = {
            'page': page,
        }

        return render(request, self.template_name, context)


class PageAdd(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/add_or_update.html'

    permission_required = 'administration_pages.add_page'
    raise_exception = True

    page_form = PageForm
    metadata_form = MetadataForm
    main_category_form = MainCategoryFormPage
    sub_category_form = SubCategoryFormPage

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_form = self.page_form(prefix='page_')
        metadata_form = self.metadata_form(prefix='metadata_')
        main_category_form = self.main_category_form(prefix='main_category_')
        sub_category_form = self.sub_category_form(prefix='sub_category_')
        main_category_id = main_category_form.initial.get('name') if main_category_form.initial else ''
        sub_category_id = sub_category_form.initial.get('name') if sub_category_form.initial else ''
        context = {
            'update': False,
            'submit_text': _("Créer"),
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id,
            'sub_category_id': sub_category_id,
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page_form = self.page_form(request.POST, prefix='page_')
        metadata_form = self.metadata_form(request.POST, prefix='metadata_')
        main_category_form = self.main_category_form(prefix='main_category_')
        sub_category_form = self.sub_category_form(prefix='sub_category_')

        # Récupère l’id des catégories via le POST
        main_category_id = request.POST.get("main_category") or None
        sub_category_id = request.POST.get("sub_category") or None

        main_category = Category.objects.filter(id=main_category_id).first() if main_category_id else None
        sub_category = Category.objects.filter(id=sub_category_id).first() if sub_category_id else None

        if page_form.is_valid() and metadata_form.is_valid():
            page = page_form.save(commit=False)
            page.category = main_category
            page.sub_category = sub_category
            page.save()

            metadata = metadata_form.save(commit=False)
            metadata.page = page
            metadata.save()

            # On enchaîne sur l'ÉDITEUR, pas sur la liste. Une page qui vient
            # d'être créée est vide : la seule chose à faire ensuite est d'y
            # mettre du contenu. Renvoyer vers la liste laissait
            # l'administrateur devant un tableau, sans confirmation, et avec
            # une page inactive par défaut dont rien ne signalait l'état.
            messages.success(
                request,
                _("Page « %(title)s » créée. Ajoutez maintenant votre premier contenu, puis publiez-la quand elle sera prête.") % {"title": page.title}
            )
            return redirect('jeiko_administration_pages:page_editor', page.id)

        # Les id sont renvoyés à Alpine pour conserver l’état du select si erreur
        context = {
            'update': False,
            'submit_text': _("Créer"),
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id or '',
            'sub_category_id': sub_category_id or '',
        }
        return render(request, self.template_name, context)


#: Clé de session : l'ancienne adresse d'une page qu'on vient de renommer. En
#: session et non dans l'adresse de l'écran : elle n'a pas à pouvoir être forgée.
SESSION_ADRESSE_CHANGEE = "jeiko_adresse_changee"


class PageUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/add_or_update.html'

    permission_required = 'administration_pages.change_page'
    raise_exception = True


    page_form = PageForm
    metadata_form = MetadataForm
    main_category_form = MainCategoryFormPage
    sub_category_form = SubCategoryFormPage

    @staticmethod
    def _formulaire_de(page):
        # Une traduction tient sa catégorie, ses menus et son rang d'accueil
        # de l'originale : elle ne règle que ce qui lui est propre.
        return VersionForm if page.traduction_de_id else PageForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_id = kwargs['page_id']
        page = get_object_or_404(Page, id=page_id)
        page_form = self._formulaire_de(page)(instance=page, prefix='page_')
        metadata, __ = Metadata.objects.get_or_create(page=page)
        metadata_form = self.metadata_form(instance=metadata, prefix='metadata_')
        main_category_form = self.main_category_form(
            initial={'name': page.category_id} if page.category_id else None,
            prefix='main_category_'
        )
        sub_category_form = self.sub_category_form(
            initial={'name': page.sub_category_id} if page.sub_category_id else None,
            prefix='sub_category_'
        )
        main_category_id = str(page.category_id) if page.category_id else ''
        sub_category_id = str(page.sub_category_id) if page.sub_category_id else ''
        context = {
            'update': True,
            'submit_text': _("Modifier"),
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id,
            'sub_category_id': sub_category_id,
            'page': page,
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page_id = kwargs['page_id']
        page = get_object_or_404(Page, id=page_id)
        # Lue AVANT le formulaire, qui écrit dans l'instance en la validant.
        ancienne_adresse = page.get_absolute_url() if page.active else ""
        etait_en_ligne = page.active
        page_form = self._formulaire_de(page)(request.POST, instance=page, prefix='page_')
        metadata, __ = Metadata.objects.get_or_create(page=page)
        metadata_form = self.metadata_form(request.POST, instance=metadata, prefix='metadata_')
        main_category_form = self.main_category_form(prefix='main_category_')
        sub_category_form = self.sub_category_form(prefix='sub_category_')

        # Récupère l’id des catégories via le POST
        main_category_id = request.POST.get("main_category") or None
        sub_category_id = request.POST.get("sub_category") or None

        main_category = Category.objects.filter(id=main_category_id).first() if main_category_id else None
        sub_category = Category.objects.filter(id=sub_category_id).first() if sub_category_id else None

        if page_form.is_valid() and metadata_form.is_valid():
            page = page_form.save(commit=False)
            if not page.traduction_de_id:
                page.category = main_category
                page.sub_category = sub_category
            page.save()

            metadata = metadata_form.save(commit=False)
            metadata.page = page
            metadata.save()

            messages.success(request, _("Réglages de la page « %(title)s » enregistrés.") % {"title": page.title})
            if etait_en_ligne and not page.active:
                from .publication import unpublish_warning

                avertissement = unpublish_warning(page)
                if avertissement:
                    messages.warning(request, avertissement)
            # Q-20 : l'adresse d'une page en ligne a changé — on demande s'il
            # faut garder l'ancienne, qui mènera ici. Le cache, lui, est déjà
            # invalidé (compteur d'adresses, signals.py).
            if ancienne_adresse and page.get_absolute_url() != ancienne_adresse:
                request.session[SESSION_ADRESSE_CHANGEE] = {"page": page.id, "ancienne": ancienne_adresse}
                return redirect('jeiko_administration_pages:adresse_changee', page.id)
            if page.traduction_de_id:
                # On reste sur la version : la suite naturelle est son contenu.
                return redirect('jeiko_administration_pages:page_update', page.id)
            return redirect('jeiko_administration_pages:main')

        context = {
            'update': True,
            'submit_text': _("Modifier"),
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id or '',
            'sub_category_id': sub_category_id or '',
            'page': page,
        }
        return render(request, self.template_name, context)


class VersionCreate(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Crée la version d'une page dans une langue du site, par duplication.

    POST uniquement : l'action écrit une page entière. On arrive ensuite sur
    les réglages de la nouvelle version — son titre et son adresse sont encore
    ceux de l'originale, c'est la première chose à traduire.
    """

    permission_required = 'administration_pages.add_page'
    raise_exception = True

    def post(self, request, page_id, langue):
        from .versions import VersionImpossible, creer_version

        page = get_object_or_404(Page, pk=page_id)
        try:
            version = creer_version(page, langue)
        except VersionImpossible as refus:
            messages.error(request, str(refus))
            return redirect('jeiko_administration_pages:page_update', page.id)

        messages.success(
            request,
            _("La version %(langue)s de « %(title)s » est créée, en brouillon. "
              "Traduisez son titre et son adresse ici, puis son contenu dans l'éditeur.")
            % {"langue": nom_de_la_langue(langue), "title": page.title}
        )
        return redirect('jeiko_administration_pages:page_update', version.id)


class DuplicatePageView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Dupliquer une page : la copie entière naît en brouillon, « (copie) » au
    titre, sous une adresse libre.

    POST seulement (09/10/2026). Un GET dupliquait : un simple lien, ouvert
    dans un e-mail ou une autre page, faisait créer des pages à
    l'administrateur à son insu. La copie passe par `dupliquer_la_page`, la
    même que l'API des agents (P-05) — elle remplace ici quelque trois cents
    lignes qui dupliquaient l'arbre à leur façon.
    """

    permission_required = 'administration_pages.add_page'
    raise_exception = True

    def post(self, request, page_id):
        from .versions import dupliquer_la_page

        page = get_object_or_404(Page, id=page_id)
        with transaction.atomic():
            copie = dupliquer_la_page(page, titre=f"{page.title} {_('(copie)')}"[:200],
                                      url_tag=make_unique_url_tag(page.url_tag))
        messages.success(request, _("« %(title)s » est dupliquée, en brouillon.") % {"title": page.title})
        return redirect('jeiko_administration_pages:page_update', copie.id)


class Categories(LoginRequiredMixin, PermissionRequiredMixin, View):

    template_name = 'administration_pages/category/list.html'

    permission_required = "administration_pages.view_category"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        categories = Category.objects.filter(
            main_category=None,
        )

        return render(
            request,
            self.template_name,
            context={
                'categories': categories,
            }
        )

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        categories = Category.objects.all()

        return render(
            request,
            self.template_name,
            context={
                'categories': categories,
            }
        )


class CategoryAdd(LoginRequiredMixin, PermissionRequiredMixin, View):

    template_name = 'administration_pages/category/add_or_update.html'

    permission_required = "administration_pages.add_category"
    raise_exception = True

    main_category_form = MainCategoryForm
    sub_category_form = SubCategoryForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        if 'main_category_id' in kwargs:
            main_category = get_object_or_404(
                Category,
                id=kwargs['main_category_id']
            )
            category_form = self.sub_category_form(
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'category_form': category_form,
                    'submit_text': _("Créer"),
                }
            )
        else:
            category_form = self.main_category_form(
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'category_form': category_form,
                    'submit_text': _("Créer"),
                }
            )


    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        if 'main_category_id' in kwargs:
            main_category = get_object_or_404(
                Category,
                id=kwargs['main_category_id']
            )
            category_form = self.sub_category_form(
                request.POST,
                prefix='category_',
            )
            if category_form.is_valid():

                category = category_form.save(commit=False)
                category.main_category = main_category
                category.save()

                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'category_form': category_form,
                }
            )
        else:
            category_form = self.main_category_form(
                request.POST,
                prefix='category_',
            )
            if category_form.is_valid():
                category_form.save()
                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={

                    'category_form': category_form,
                    'submit_text': _("Créer"),
                }
            )


class CategoryDelete(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Suppression d'une catégorie ou d'une sous-catégorie, après bilan.

    GET montre ce qui va se passer — pages reclassées, adresses avant/après,
    sous-catégories emportées, menus et blocs dynamiques touchés — et ce qui
    l'empêche. POST recalcule le bilan (celui de l'écran a pu vieillir) et
    exige une case cochée dès qu'il y a un effet à accepter. Le détail est
    dans `suppression_categorie`.
    """

    template_name = 'administration_pages/category/delete.html'
    permission_required = "administration_pages.delete_category"
    raise_exception = True

    def _cible(self, kwargs):
        principale = get_object_or_404(
            Category, id=kwargs['main_category_id'], main_category__isnull=True
        )
        if 'sub_category_id' in kwargs:
            # La sous-catégorie doit appartenir à la catégorie de l'adresse :
            # sinon l'écran afficherait un parent qui n'est pas le sien.
            return principale, get_object_or_404(
                Category, id=kwargs['sub_category_id'], main_category=principale
            )
        return principale, None

    def _rendre(self, request, principale, sous, bilan, erreur=None):
        return render(request, self.template_name, {
            'main_category': principale,
            'sub_category': sous,
            'cible': sous or principale,
            'bilan': bilan,
            'erreur': erreur,
        })

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        from jeiko.administration_pages.suppression_categorie import evaluer

        principale, sous = self._cible(kwargs)
        return self._rendre(request, principale, sous, evaluer(sous or principale))

    def post(self, request, *args, **kwargs):
        from jeiko.administration_pages.suppression_categorie import (
            SuppressionImpossible, evaluer, supprimer,
        )

        principale, sous = self._cible(kwargs)
        cible = sous or principale
        bilan = evaluer(cible)
        if bilan.possible and bilan.confirmation_requise and not request.POST.get('confirmer'):
            return self._rendre(
                request, principale, sous, bilan,
                erreur=_("Cochez la case pour confirmer que vous avez lu les conséquences."),
            )
        try:
            bilan = supprimer(cible)
        except SuppressionImpossible as refus:
            return self._rendre(request, principale, sous, refus.bilan)

        changees = len(bilan.adresses_changees)
        message = f"« {cible.name} » a été supprimée."
        if changees:
            message += (
                f" {changees} page(s) ont changé d'adresse ; les anciennes "
                f"redirigent vers les nouvelles."
            )
        messages.success(request, message)
        return redirect('jeiko_administration_pages:categories')


class CategoryUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/category/add_or_update.html'

    permission_required = "administration_pages.change_category"
    raise_exception = True

    main_category_form = MainCategoryForm
    sub_category_form = SubCategoryForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        main_category = get_object_or_404(
            Category,
            id=kwargs['main_category_id']
        )

        if 'sub_category_id' in kwargs:

            sub_category = get_object_or_404(
                Category,
                id=kwargs['sub_category_id']
            )
            category_form = self.sub_category_form(
                instance=sub_category,
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'sub_category': sub_category,
                    'category_form': category_form,
                    'update': True,
                    'submit_text': _("Modifier"),
                }
            )
        else:
            category_form = self.main_category_form(
                instance=main_category,
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'category_form': category_form,
                    'update': True,
                    'submit_text': _("Modifier"),
                }
            )

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        main_category = get_object_or_404(
            Category,
            id=kwargs['main_category_id']
        )

        if 'sub_category_id' in kwargs:

            sub_category = get_object_or_404(
                Category,
                id=kwargs['sub_category_id'],
            )
            category_form = self.sub_category_form(
                request.POST,
                instance=sub_category,
                prefix='category_',
            )
            if category_form.is_valid():
                category = category_form.save(commit=False)
                category.main_category = main_category
                category.save()

                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'sub_category': sub_category,
                    'category_form': category_form,
                    'update': True,
                }
            )
        else:
            main_category_form = self.main_category_form(
                request.POST,
                instance=main_category,
                prefix='category_',
            )
            if main_category_form.is_valid():
                main_category_form.save()
                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={
                    'category_form': main_category_form,
                    'main_category': main_category,
                    'update': True,
                }
            )


class PageEditor(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/editor.html'

    permission_required = 'administration_pages.change_page'
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_id = kwargs['page_id']

        page = get_object_or_404(
            Page.editables,
            id=page_id
        )

        context = {
            'page': page,
        }
        # L'atelier d'un modèle : le bandeau dit quel modèle on modifie, et
        # combien de pages se mettront à jour (administration_pages/modeles.py).
        if page.is_model_workshop:
            from .modeles import copies, genre_de, modele_de_l_atelier
            modele = modele_de_l_atelier(page)
            if modele is not None:
                context.update(
                    modele=modele, genre_modele=genre_de(modele),
                    nb_copies_sync=copies(modele, synchronisees=True).count(),
                    nb_copies=copies(modele).count(),
                )
        # Brouillon et historique (historique.py) : le bandeau dit si ce
        # qu'on modifie est en ligne tout de suite ou dans un brouillon.
        from . import historique
        if page.role == Page.Role.BROUILLON:
            context["brouillon_ouvert"] = page
        elif historique.a_un_historique(page):
            context["avec_historique"] = True
            context["brouillon_en_cours"] = historique.brouillon_de(page)
        # NEWS-01 : le corps d'une newsletter — le bandeau ramène à sa fiche.
        if page.is_mail_template:
            from jeiko.emailing.models import Newsletter
            context["newsletter"] = Newsletter.objects.filter(page=page).first()

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page = get_object_or_404(
            Page.editables,
            id=kwargs['page_id']
        )

        context = {
            'page': page,
        }
        return render(request, self.template_name, context)


class PageInsight(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Vue HTML d'inspection des résultats PSI pour une page (Mobile / Desktop).
    """
    permission_required = "administration_pages.view_page"
    raise_exception = True  # renvoie 403 si non autorisé

    template_name = "administration_pages/insight.html"

    def get(self, request, page_id: int):
        page = get_object_or_404(Page, pk=page_id)

        # Derniers résultats (le signal garantit latest-only)
        insight_mobile = get_latest_insight(page, Strategy.MOBILE)
        insight_desktop = get_latest_insight(page, Strategy.DESKTOP)

        # Clé API dispo ?
        api_key_configured = bool(get_google_api_key())

        context = {
            "page": page,
            "insight_mobile": insight_mobile,
            "insight_desktop": insight_desktop,
            "api_key_configured": api_key_configured,
        }
        return render(request, self.template_name, context)


class PageDelete(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/delete.html'

    permission_required = 'administration_pages.delete_page'
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page = get_object_or_404(
            Page,
            id=kwargs['page_id']
        )


        context = {
            'page': page,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page = get_object_or_404(
            Page,
            id=kwargs['page_id']
        )


        # Une version traduite : on revient aux réglages de sa page d'origine,
        # d'où elle peut être recréée. Supprimer l'originale emporte ses
        # versions (CASCADE) — l'écran de confirmation les a nommées.
        origine_id = page.traduction_de_id
        document_pdf = page.is_pdf
        if page.delete():
            if origine_id:
                return redirect('jeiko_administration_pages:page_update', origine_id)
            if document_pdf:
                return redirect('jeiko_pdf_admin:documents')
            return redirect('jeiko_administration_pages:main')

        context = {
            'page': page,
            'message': _('Un problème est survenu')
        }

        return render(request, self.template_name, context)


class ModelLibrary(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration_pages/models/main.html"
    permission_required = 'administration_pages.change_page'
    raise_exception = True

    def get(self, request):
        from django.db.models import Count, Q

        # E5 : chaque modèle dit combien de pages l'utilisent, dont combien
        # se mettent à jour avec lui. E6 : une recherche sur le nom, et au
        # plus cent par genre affichés.
        q = (request.GET.get("q") or "").strip()

        def modeles(Model):
            qs = Model.objects.filter(is_model=True)
            if q:
                qs = qs.filter(model_name__icontains=q)
            return qs.annotate(
                nb_copies=Count("model_copies", filter=Q(model_copies__is_model=False)),
                nb_sync=Count("model_copies", filter=Q(model_copies__is_model=False,
                                                       model_copies__model_sync=True)),
            ).order_by("model_name", "id")[:100]

        sections, lines, blocs = modeles(Section), modeles(Line), modeles(Bloc)
        context = {
            "q": q,
            "sections": sections, "lines": lines, "blocs": blocs,
            # Regroupement pour un rendu homogène en tableaux.
            "groups": [
                {"label": _("Sections"), "kind": "section", "items": sections,
                 "empty_label": _("Aucune section modèle enregistrée.")},
                {"label": _("Lignes"), "kind": "line", "items": lines,
                 "empty_label": _("Aucune ligne modèle enregistrée.")},
                {"label": _("Blocs"), "kind": "bloc", "items": blocs,
                 "empty_label": _("Aucun bloc modèle enregistré.")},
            ],
        }
        return render(request, self.template_name, context)


class ModelDelete(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/models/delete.html'
    raise_exception = True

    MODEL_MAP = {
        "section": (Section, "administration_pages.delete_section"),
        "line":    (Line,    "administration_pages.delete_line"),
        "bloc":    (Bloc,    "administration_pages.delete_bloc"),
    }

    def get_permission_required(self):
        model_type = (getattr(self, "kwargs", {}) or {}).get("model_type")
        perm = self.MODEL_MAP.get(model_type, (None, None))[1]
        return (perm or "administration_pages.delete_section",)

    @method_decorator(never_cache)
    def get(self, request, model_type, pk):
        Model, __ = self.MODEL_MAP.get(model_type, (None, None))
        if not Model:
            return redirect('jeiko_administration_pages:model_library')
        obj = get_object_or_404(Model, pk=pk, is_model=True)
        from .modeles import copies
        return render(request, self.template_name, {
            "object": obj, "model_type": model_type, "nb_copies": copies(obj).count(),
        })

    @method_decorator(never_cache)
    def post(self, request, model_type, pk):
        Model, __ = self.MODEL_MAP.get(model_type, (None, None))
        if not Model:
            return redirect('jeiko_administration_pages:model_library')
        obj = get_object_or_404(Model, pk=pk, is_model=True)
        try:
            # Ses copies restent sur leurs pages, détachées ; son atelier part.
            from .modeles import supprimer_modele
            supprimer_modele(obj)
            return redirect('jeiko_administration_pages:model_library')
        except Exception:
            ctx = {"object": obj, "model_type": model_type, "message": _("Un problème est survenu")}
            return render(request, self.template_name, ctx)


class _ModeleMixin(LoginRequiredMixin, PermissionRequiredMixin):
    permission_required = "administration_pages.change_page"
    raise_exception = True

    def modele(self, model_type, pk):
        from .modeles import GENRES
        Model = GENRES.get(model_type)
        if Model is None:
            raise Http404
        return get_object_or_404(Model, pk=pk, is_model=True)

    def retour(self, request):
        suite = request.POST.get("next") or ""
        if suite.startswith("/") and not suite.startswith("//"):
            return redirect(suite)
        return redirect("jeiko_administration_pages:model_library")


class ModelEdit(_ModeleMixin, View):
    """Ouvre le modèle dans l'éditeur, sur sa page atelier (E2)."""

    def get(self, request, model_type, pk):
        from .modeles import atelier
        page = atelier(self.modele(model_type, pk))
        return redirect("jeiko_administration_pages:page_editor", page_id=page.pk)


class ModelSync(_ModeleMixin, View):
    """« Mettre à jour les pages » : remplace les copies synchronisées par le modèle."""

    def post(self, request, model_type, pk):
        from .modeles import synchroniser
        n = synchroniser(self.modele(model_type, pk))
        messages.success(request, _("%(n)s page(s) mise(s) à jour.") % {"n": n})
        return self.retour(request)


class ModelRename(_ModeleMixin, View):
    """Renommer un modèle ; deux modèles d'un genre ne portent pas le même nom (E3)."""

    def post(self, request, model_type, pk):
        from .modeles import nom_pris
        modele = self.modele(model_type, pk)
        nom = (request.POST.get("model_name") or "").strip()[:255]
        if not nom:
            messages.error(request, _("Un modèle a un nom."))
        elif nom_pris(model_type, nom, sauf=modele):
            messages.error(request, _("Un autre modèle porte déjà ce nom."))
        else:
            modele.model_name = nom
            modele.save(update_fields=["model_name"])
            messages.success(request, _("Modèle renommé."))
        return self.retour(request)


class ModelDetach(LoginRequiredMixin, PermissionRequiredMixin, View):
    """Une copie synchronisée redevient libre : le modèle ne la touchera plus."""

    permission_required = "administration_pages.change_page"
    raise_exception = True

    def post(self, request, model_type, pk):
        from .modeles import GENRES, detacher, page_du_modele
        Model = GENRES.get(model_type)
        if Model is None:
            raise Http404
        copie = get_object_or_404(Model, pk=pk, is_model=False)
        detacher(copie)
        messages.success(request, _("Détachée du modèle : vos retouches sont conservées."))
        page = page_du_modele(copie)
        if page is None:
            return redirect("jeiko_administration_pages:model_library")
        return redirect("jeiko_administration_pages:page_editor", page_id=page.pk)


class FormSubmissionList(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    CRM › Messages reçus : les envois des formulaires de contact. Les
    indésirables (antispam.py) y attendent d'être délivrés ou purgés.
    """

    permission_required = "administration_pages.view_contentformsubmission"
    raise_exception = True
    template_name = "administration_pages/messages/list.html"

    @method_decorator(never_cache)
    def get(self, request):
        from django.core.paginator import Paginator

        from .models import ContentFormSubmission

        indesirables = request.GET.get("filtre") == "indesirables"
        qs = ContentFormSubmission.objects.select_related("formulaire").filter(is_spam=indesirables)
        page = Paginator(qs, 50).get_page(request.GET.get("page"))
        return render(request, self.template_name, {
            "page_obj": page, "envois": page.object_list, "indesirables": indesirables,
            "nb_indesirables": ContentFormSubmission.objects.filter(is_spam=True).count(),
        })


class FormSubmissionAction(LoginRequiredMixin, PermissionRequiredMixin, View):
    """Délivrer un indésirable, signaler un spam passé, ou supprimer (POST)."""

    permission_required = "administration_pages.change_contentformsubmission"
    raise_exception = True

    def post(self, request, pk):
        from .antispam import delivrer
        from .models import ContentFormSubmission

        envoi = get_object_or_404(ContentFormSubmission, pk=pk)
        action = request.POST.get("action")
        if action == "delivrer" and envoi.is_spam:
            delivrer(envoi, request=request)
            messages.success(request, _("Message délivré : l'équipe et le visiteur ont reçu leurs e-mails."))
        elif action == "spam" and not envoi.is_spam:
            envoi.is_spam, envoi.spam_reason = True, _("signalé à la main")
            envoi.save(update_fields=["is_spam", "spam_reason"])
            messages.success(request, _("Message classé indésirable."))
        elif action == "supprimer" and request.user.has_perm("administration_pages.delete_contentformsubmission"):
            envoi.delete()
            messages.success(request, _("Message supprimé."))
        suite = request.POST.get("next") or ""
        if suite.startswith("/") and not suite.startswith("//"):
            return redirect(suite)
        return redirect("jeiko_administration_pages:form_submissions")


def build_errors_summary_section(
    section_form,
    styles,
    size_forms,
    bg_form,
    bg_params_form,
    custom_css_form=None,
    animation_form=None,
    border_form=None,
):
    summary = {}

    if section_form.errors or section_form.non_field_errors():
        summary['section'] = section_form.errors.as_ul() or section_form.non_field_errors().as_ul()

    style_errs = []
    for idx, f in enumerate(styles):
        if f.errors or f.non_field_errors():
            style_errs.append(f"<li>Style #{idx+1}: {f.errors.as_text() or f.non_field_errors().as_text()}</li>")
    if style_errs:
        summary['styles'] = "<ul>" + "".join(style_errs) + "</ul>"

    size_errs = []
    for idx, f in enumerate(size_forms):
        if f.errors or f.non_field_errors():
            size_errs.append(f"<li>Taille #{idx+1}: {f.errors.as_text() or f.non_field_errors().as_text()}</li>")
    if size_errs:
        summary['sizes'] = "<ul>" + "".join(size_errs) + "</ul>"

    if bg_form.errors or bg_form.non_field_errors():
        summary['background_image'] = bg_form.errors.as_ul() or bg_form.non_field_errors().as_ul()

    if bg_params_form.errors or bg_params_form.non_field_errors():
        summary['background_params'] = bg_params_form.errors.as_ul() or bg_params_form.non_field_errors().as_ul()

    if custom_css_form and (custom_css_form.errors or custom_css_form.non_field_errors()):
        summary['custom_css'] = custom_css_form.errors.as_ul() or custom_css_form.non_field_errors().as_ul()

    if animation_form and (animation_form.errors or animation_form.non_field_errors()):
        summary['animation'] = animation_form.errors.as_ul() or animation_form.non_field_errors().as_ul()

    if border_form and (border_form.errors or border_form.non_field_errors()):
        summary['border'] = border_form.errors.as_ul() or border_form.non_field_errors().as_ul()

    return summary


class EditorMutationMixin(LoginRequiredMixin, PermissionRequiredMixin):
    """
    Toutes les vues qui créent, modifient, suppriment ou déplacent un élément de page.

    Elles étaient déclarées en `View` nu : n'importe quel visiteur anonyme pouvait
    créer, éditer, supprimer et réordonner sections, lignes et blocs de toutes les pages.
    Détecté par les tests de fumée (ApiAccessTests), pas par l'audit initial, qui n'avait
    cherché le motif que dans views_api.py.

    raise_exception=True => 403 plutôt qu'une redirection HTML, ces vues répondant en JSON.
    """
    permission_required = "administration_pages.change_page"
    raise_exception = True


@method_decorator(never_cache, name='dispatch')
class SectionCreate(EditorMutationMixin, View):
    choose_template = 'administration_pages/section/choose_type.html'
    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    def get(self, request, page_id):
        page = get_object_or_404(Page.editables, id=page_id)
        section_models = Section.objects.filter(is_model=True).order_by('model_name', 'id')
        html = render_to_string(self.choose_template, {"page": page, "section_models": section_models}, request=request)
        if self._is_ajax(request):
            return JsonResponse({"status": "choose_type", "html": html}, status=200)
        return HttpResponse(html)

    @transaction.atomic
    def post(self, request, page_id):
        page = get_object_or_404(Page.editables, id=page_id)
        choice = (request.POST.get('section_choice') or request.POST.get('preset') or '').strip()
        if not choice:
            return HttpResponseBadRequest("Choix de section manquant")

        # Les gabarits et les douze objets liés qu'ils supposent vivent dans
        # `fabrique.py` : l'API des agents crée des sections par le même
        # chemin. Recopier la logique ici garantirait qu'elles divergent.
        if choice in fabrique.GABARITS_SECTION:
            created_section = fabrique.creer_section(page, gabarit=choice)


        elif choice.startswith("MODEL:"):
            try:
                model_id = int(choice.split(":", 1)[1])
            except Exception:
                return HttpResponseBadRequest("Identifiant de modèle invalide")

            model_section = get_object_or_404(Section, id=model_id, is_model=True)
            position = fabrique.position_suivante(Section.objects.filter(page=page))
            created_section = section_duplicate(model_section, target_page=page, position=position, as_model=False, link_model=True)

            created_section.is_model = False
            created_section.model_name = None
            created_section.model_source = model_section
            # Copie libre (défaut) ou synchronisée : choisi à l'insertion (modeles.py).
            created_section.model_sync = request.POST.get("model_sync") == "1"
            created_section.save(update_fields=["is_model", "model_name", "model_source", "model_sync"])

        else:
            return HttpResponseBadRequest("Choix non reconnu")

        html = render_to_string(self.section_partial, {"section": created_section}, request=request)
        if self._is_ajax(request):
            return JsonResponse({"status": "success", "html": html, "section_id": created_section.id}, status=200)
        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)


@method_decorator(never_cache, name='dispatch')
class SectionUpdate(EditorMutationMixin, View, AsyncRequestMixin):
    template_name = 'administration_pages/section/form.html'

    @method_decorator(never_cache)
    def get(self, request, page_id, section_id):
        page = get_object_or_404(Page.editables, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        ctx = get_section_forms_context(page, instance=section)
        ctx.update({
            'form_action': reverse('jeiko_administration_pages:section_update', args=[page_id, section_id]),
            'submit_text': _('Mettre à jour la section'),
            'section': section,
            'page': page,
        })
        return render(request, self.template_name, ctx)

    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        page = get_object_or_404(Page.editables, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        ctx = get_section_forms_context(page, request.POST, request.FILES, instance=section)

        form = ctx['section_form']
        styles = ctx['style_forms']
        size_forms = ctx['size_forms']
        background_image_form = ctx['background_image_form']
        background_image_parameters_form = ctx['background_image_parameters_form']
        custom_css_form = ctx.get('custom_css_form')
        animation_form = ctx.get('animation_form')
        border_form = ctx.get('border_form')

        ctx.update({
            'form_action': reverse('jeiko_administration_pages:section_update', args=[page_id, section_id]),
            'submit_text': _('Mettre à jour la section'),
        })

        if custom_css_form is not None:
            custom_css_form.instance.section = section
            custom_css_form.instance.line = None
            custom_css_form.instance.bloc = None

        if animation_form is not None:
            animation_form.instance.section = section
            animation_form.instance.line = None
            animation_form.instance.bloc = None

        if border_form is not None:
            border_form.instance.section = section
            border_form.instance.line = None
            border_form.instance.bloc = None

        if (
            form.is_valid()
            and all(f.is_valid() for f in styles)
            and all(f.is_valid() for f in size_forms)
            and background_image_form.is_valid()
            and background_image_parameters_form.is_valid()
            and (custom_css_form is None or custom_css_form.is_valid())
            and (animation_form is None or animation_form.is_valid())
            and (border_form is None or border_form.is_valid())
        ):
            margins  = [f.save() for f in styles[:4]]
            paddings = [f.save() for f in styles[4:8]]
            sizes    = [f.save() for f in size_forms]
            bgimg    = background_image_form.save()
            bgparams = background_image_parameters_form.save()

            section = form.save(commit=False)
            (section.margin_phone, section.margin_tablet, section.margin_laptop, section.margin_computer) = margins
            (section.padding_phone, section.padding_tablet, section.padding_laptop, section.padding_computer) = paddings
            (section.size_phone,   section.size_tablet,   section.size_laptop,   section.size_computer)   = sizes
            section.background_image = bgimg

            section.background_image_parameters = bgparams
            section.save()

            if custom_css_form:
                cc = custom_css_form.save(commit=False)
                if cc.pk is None:
                    cc.section, cc.line, cc.bloc = section, None, None
                cc.save()

            if animation_form:
                anim = animation_form.save(commit=False)
                anim.section, anim.line, anim.bloc = section, None, None
                anim.save()

            if border_form:
                 save_border_for_section(section, border_form)

            if self.is_fetch(request):
                html = render_to_string('administration_pages/partials/section.html', {'section': section}, request=request)
                return self.render_json(content_html=html, status=200, section_id=section.id)

            return redirect('jeiko_administration_pages:page_editor', page_id)

        if self.is_fetch(request):
            ctx['errors_summary'] = build_errors_summary_section(
                form, styles, size_forms, background_image_form, background_image_parameters_form,
                custom_css_form=custom_css_form, animation_form=animation_form, border_form=border_form
            )
            html = render_to_string(self.template_name, ctx, request=request)
            return HttpResponse(html, status=200)
        return render(request, self.template_name, ctx)


@method_decorator(never_cache, name='dispatch')
class SectionDelete(EditorMutationMixin, View, AsyncRequestMixin):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        style_ids = [
            section.margin_phone_id,
            section.margin_tablet_id,
            section.margin_laptop_id,
            section.margin_computer_id,
            section.padding_phone_id,
            section.padding_tablet_id,
            section.padding_laptop_id,
            section.padding_computer_id,
        ]
        section.delete()
        StyleBox.objects.filter(id__in=[sid for sid in style_ids if sid]).delete()

        if self.is_fetch(request):
            return self.render_json(status=200, section_id=section_id)
        return redirect('jeiko_administration_pages:page_editor', page_id)


@method_decorator(never_cache, name='dispatch')
class SectionMoveUp(EditorMutationMixin, View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        prev_sec = (
            Section.objects
            .filter(page=section.page, position__lt=section.position)
            .order_by('-position')
            .first()
        )
        if prev_sec:
            # swap
            section.position, prev_sec.position = prev_sec.position, section.position
            section.save()
            prev_sec.save()
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"status": "success"})
        return redirect('jeiko_administration_pages:page_editor', page_id)


@method_decorator(never_cache, name='dispatch')
class SectionMoveDown(EditorMutationMixin, View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        next_sec = (
            Section.objects
            .filter(page=section.page, position__gt=section.position)
            .order_by('position')
            .first()
        )
        if next_sec:
            section.position, next_sec.position = next_sec.position, section.position
            section.save()
            next_sec.save()
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"status": "success"})
        return redirect('jeiko_administration_pages:page_editor', page_id)


def build_errors_summary_line(
    line_form,
    style_forms,
    size_forms,
    bg_form,
    bg_params_form,
    custom_css_form=None,
    animation_form=None,
    border_form=None,
):
    summary = {}

    if line_form.errors or line_form.non_field_errors():
        summary['line'] = line_form.errors.as_ul() or line_form.non_field_errors().as_ul()

    style_errs = []
    for idx, f in enumerate(style_forms):
        if f.errors or f.non_field_errors():
            style_errs.append(f"<li>Style #{idx+1}: {f.errors.as_text() or f.non_field_errors().as_text()}</li>")
    if style_errs:
        summary['styles'] = "<ul>" + "".join(style_errs) + "</ul>"

    size_errs = []
    for idx, f in enumerate(size_forms):
        if f.errors or f.non_field_errors():
            size_errs.append(f"<li>Taille #{idx+1}: {f.errors.as_text() or f.non_field_errors().as_text()}</li>")
    if size_errs:
        summary['sizes'] = "<ul>" + "".join(size_errs) + "</ul>"

    if bg_form.errors or bg_form.non_field_errors():
        summary['background_image'] = bg_form.errors.as_ul() or bg_form.non_field_errors().as_ul()
    if bg_params_form.errors or bg_params_form.non_field_errors():
        summary['background_params'] = bg_params_form.errors.as_ul() or bg_params_form.non_field_errors().as_ul()

    if custom_css_form and (custom_css_form.errors or custom_css_form.non_field_errors()):
        summary['custom_css'] = custom_css_form.errors.as_ul() or custom_css_form.non_field_errors().as_ul()

    if animation_form and (animation_form.errors or animation_form.non_field_errors()):
        summary['animation'] = animation_form.errors.as_ul() or animation_form.non_field_errors().as_ul()

    if border_form and (border_form.errors or border_form.non_field_errors()):
        summary['border'] = border_form.errors.as_ul() or border_form.non_field_errors().as_ul()

    return summary


@method_decorator(never_cache, name='dispatch')
class LineCreate(EditorMutationMixin, View):
    choose_template = 'administration_pages/line/choose_type.html'
    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    def get(self, request, page_id, section_id):
        page = get_object_or_404(Page.editables, id=page_id)
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        line_models     = Line.objects.filter(is_model=True).order_by('model_name', 'id')
        desktop_choices = Line.COLUMNS_TYPE_CHOICES
        html = render_to_string(
            self.choose_template,
            {'page': page, 'section': section, 'line_models': line_models, 'desktop_choices': desktop_choices},
            request=request
        )
        if self._is_ajax(request):
            return JsonResponse({"status": "choose_type", "html": html}, status=200)
        return HttpResponse(html)

    @transaction.atomic
    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        choice = (request.POST.get('line_choice') or '').strip()
        if not choice:
            return HttpResponseBadRequest("Choix de ligne manquant")

        last = section.lines.order_by('-position').first()
        position = (last.position + 1) if last and last.position is not None else 0

        if choice == 'LINE':
            columns_type = (request.POST.get('columns_type') or '12').strip()
            columns_type_tablet = (request.POST.get('columns_type_tablet') or columns_type).strip()
            columns_type_phone = (request.POST.get('columns_type_phone') or columns_type).strip()

            def _sb():
                return StyleBox.objects.create(top=0, right=0, bottom=0, left=0)
            def _size():
                return Size.objects.create(width="100%", height="")

            line = Line.objects.create(
                section=section, position=position,
                columns_type=columns_type,
                columns_type_tablet=columns_type_tablet,
                columns_type_phone=columns_type_phone,
                columns_number=len(columns_type.split('-')) if columns_type else 1,
                margin_phone=_sb(), margin_tablet=_sb(), margin_laptop=_sb(), margin_computer=_sb(),
                padding_phone=_sb(), padding_tablet=_sb(), padding_laptop=_sb(), padding_computer=_sb(),
                size_phone=_size(), size_tablet=_size(), size_laptop=_size(), size_computer=_size(),
            )

            for pos in range(1, line.columns_number + 1):
                Bloc.objects.create(
                    line=line, position=pos,
                    margin_phone=StyleBox.objects.create(),
                    margin_tablet=StyleBox.objects.create(),
                    margin_laptop=StyleBox.objects.create(),
                    margin_computer=StyleBox.objects.create(),
                    padding_phone=StyleBox.objects.create(),
                    padding_tablet=StyleBox.objects.create(),
                    padding_laptop=StyleBox.objects.create(),
                    padding_computer=StyleBox.objects.create(),
                )

            if self._is_ajax(request):
                return section_response(section, request)
            return redirect('jeiko_administration_pages:page_editor', page_id=page_id)

        elif choice.startswith('MODEL:'):
            try:
                model_id = int(choice.split(':', 1)[1])
            except Exception:
                return HttpResponseBadRequest("Identifiant de modèle invalide")

            model_line = get_object_or_404(Line, id=model_id, is_model=True)
            line = line_duplicate(model_line, target_section=section, position=position, as_model=False, link_model=True)

            line.is_model = False
            line.model_name = None
            line.model_source = model_line
            line.model_sync = request.POST.get("model_sync") == "1"
            line.save(update_fields=["is_model", "model_name", "model_source", "model_sync"])

            if self._is_ajax(request):
                return section_response(section, request)
            return redirect('jeiko_administration_pages:page_editor', page_id=page_id)

        else:
            return HttpResponseBadRequest("Choix non reconnu")


@method_decorator(never_cache, name='dispatch')
class LineUpdate(EditorMutationMixin, View):
    def get(self, request, page_id, section_id, line_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        line = get_object_or_404(Line, id=line_id, section=section)
        context = get_line_forms_context(section, instance=line)
        context.update({
            "form_action": reverse("jeiko_administration_pages:line_update", args=[page_id, section_id, line_id]),
            "submit_text": _("Modifier la ligne"),
            "update": True,
            "line": line,
        })
        return render(request, "administration_pages/line/form.html", context)

    def post(self, request, page_id, section_id, line_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        line = get_object_or_404(Line, id=line_id, section=section)
        context = get_line_forms_context(section, data=request.POST, instance=line, files=request.FILES)

        line_form = context["line_form"]
        style_forms = context["style_forms"]
        size_forms = context["size_forms"]
        background_image_form = context["background_image_form"]
        background_image_parameters_form = context["background_image_parameters_form"]
        custom_css_form = context.get("custom_css_form")
        animation_form = context.get("animation_form")
        border_form = context.get("border_form")

        if custom_css_form is not None:
            custom_css_form.instance.section = None
            custom_css_form.instance.line = line
            custom_css_form.instance.bloc = None

        if animation_form is not None:
            animation_form.instance.section = None
            animation_form.instance.line = line
            animation_form.instance.bloc = None

        if border_form is not None:
            border_form.instance.section = None
            border_form.instance.line = line
            border_form.instance.bloc = None

        if (
            line_form.is_valid()
            and all(f.is_valid() for f in style_forms)
            and all(f.is_valid() for f in size_forms)
            and background_image_form.is_valid()
            and background_image_parameters_form.is_valid()
            and (custom_css_form is None or custom_css_form.is_valid())
            and (animation_form is None or animation_form.is_valid())
            and (border_form is None or border_form.is_valid())
        ):
            line = line_form.save(commit=False)
            line.columns_number = len(line.columns_type.split('-')) if line.columns_type else 1

            style_instances = [f.save() for f in style_forms]
            (
                line.margin_phone, line.margin_tablet, line.margin_laptop, line.margin_computer,
                line.padding_phone, line.padding_tablet, line.padding_laptop, line.padding_computer
            ) = style_instances

            size_instances = [f.save() for f in size_forms]
            (line.size_phone, line.size_tablet, line.size_laptop, line.size_computer) = size_instances

            bgimg = background_image_form.save()
            bgimg_params = background_image_parameters_form.save()
            line.background_image = bgimg
            line.background_image_parameters = bgimg_params

            line.save()

            desired = line.columns_number
            root_blocks = list(line.blocs.filter(position_in_column=0).values_list('position', flat=True))
            missing_positions = [pos for pos in range(1, desired + 1) if pos not in root_blocks]
            for pos in missing_positions:
                Bloc.objects.create(
                    line=line, position=pos, position_in_column=0,
                    margin_phone=StyleBox.objects.create(),
                    margin_tablet=StyleBox.objects.create(),
                    margin_laptop=StyleBox.objects.create(),
                    margin_computer=StyleBox.objects.create(),
                    padding_phone=StyleBox.objects.create(),
                    padding_tablet=StyleBox.objects.create(),
                    padding_laptop=StyleBox.objects.create(),
                    padding_computer=StyleBox.objects.create(),
                )

            if custom_css_form:
                cc = custom_css_form.save(commit=False)
                if cc.pk is None:
                    cc.section, cc.line, cc.bloc = None, line, None
                cc.save()

            if animation_form:
                anim = animation_form.save(commit=False)
                anim.section, anim.line, anim.bloc = None, line, None
                anim.save()

            if border_form:
                save_border_for_line(line, border_form)

            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return section_response(section, request)

            return redirect("jeiko_administration_pages:page_editor", page_id)

        context.update({
            "form_action": reverse("jeiko_administration_pages:line_update", args=[page_id, section_id, line_id]),
            "submit_text": _("Modifier la ligne"),
            "update": True,
            "line": line,
        })
        context["errors_summary"] = build_errors_summary_line(
            line_form, style_forms, size_forms, background_image_form, background_image_parameters_form,
            custom_css_form=custom_css_form, animation_form=animation_form, border_form=border_form
        )

        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string("administration_pages/line/form.html", context, request=request)
            return HttpResponse(html, status=200)
        return render(request, "administration_pages/line/form.html", context)


@method_decorator(never_cache, name='dispatch')
class LineDelete(EditorMutationMixin, View):
    """
    Suppression d'une ligne :
    - sur fetch AJAX : renvoie {"status":"success"}
    - sinon : redirect vers page_editor
    """
    def post(self, request, page_id, section_id, line_id):
        line = get_object_or_404(Line, id=line_id, section_id=section_id, section__page_id=page_id)
        line.delete()

        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            section = line.section
            return section_response(section, request)
        return redirect("jeiko_administration_pages:page_editor", page_id)


class LineMoveUp(EditorMutationMixin, View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id):

        # Récupère la ligne courante, vérifie qu'elle appartient bien à la section/page
        line = get_object_or_404(
            Line,
            id=line_id,
            section_id=section_id,
            section__page_id=page_id
        )
        # Cherche la ligne précédente dans la même section
        prev_line = (
            Line.objects
            .filter(section=line.section, position__lt=line.position)
            .order_by('-position')
            .first()
        )
        if prev_line:
            # Échange des positions
            line.position, prev_line.position = prev_line.position, line.position
            line.save()
            prev_line.save()
        # Si AJAX, renvoie JSON succès, sinon redirect
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            from jeiko.administration_pages.responses import swap_response

            # C6 : deux lignes échangent leur place ; rien d'autre ne change.
            if prev_line:
                return swap_response(f"line-{line.id}", f"line-{prev_line.id}")
            return ok_response()
        return redirect('jeiko_administration_pages:page_editor', page_id)


@method_decorator(never_cache, name='dispatch')
class LineMoveTo(EditorMutationMixin, View):
    """
    Envoie une ligne dans une autre section de la page.

    Jusqu'ici une ligne ne montait ou ne descendait que DANS sa section :
    la changer de section voulait dire la refaire. GET rend le choix, POST
    déplace (fabrique.deplacer_ligne, le même chemin que l'API des agents).
    """

    template_name = 'administration_pages/line/move_to.html'

    def _ligne(self, page_id, section_id, line_id):
        return get_object_or_404(
            Line.objects.select_related('section__page'),
            id=line_id, section_id=section_id, section__page_id=page_id,
        )

    def get(self, request, page_id, section_id, line_id):
        ligne = self._ligne(page_id, section_id, line_id)
        sections = ligne.section.page.sections.order_by('position', 'id')
        return render(request, self.template_name, {
            'ligne': ligne,
            'sections': [(numero, s) for numero, s in enumerate(sections, 1)],
        })

    def post(self, request, page_id, section_id, line_id):
        from jeiko.administration_pages import fabrique
        from jeiko.administration_pages.responses import sections_response

        ligne = self._ligne(page_id, section_id, line_id)
        source = ligne.section
        cible = get_object_or_404(Section, id=request.POST.get('section'), page_id=page_id)
        position = (request.POST.get('position') or 'fin').strip()
        rang = 0 if position == 'debut' else None
        try:
            fabrique.deplacer_ligne(ligne, cible, rang=rang)
        except fabrique.DeplacementImpossible as souci:
            return JsonResponse({'ok': False, 'message': str(souci)}, status=400)
        return sections_response([source, cible], request, message=_('Ligne déplacée'))


@method_decorator(never_cache, name='dispatch')
class BlocMoveTo(EditorMutationMixin, View):
    """
    Envoie un bloc dans une autre ligne (ou une autre colonne) de la page.

    Même raison que LineMoveTo. La colonne quittée n'est jamais laissée vide ;
    une case vide qui attendait dans la colonne d'arrivée s'efface.
    """

    template_name = 'administration_pages/line/bloc_move_to.html'

    def _bloc(self, page_id, section_id, line_id, bloc_id):
        return get_object_or_404(
            Bloc.objects.select_related('line__section__page'),
            id=bloc_id, line_id=line_id, line__section_id=section_id,
            line__section__page_id=page_id,
        )

    def get(self, request, page_id, section_id, line_id, bloc_id):
        bloc = self._bloc(page_id, section_id, line_id, bloc_id)
        destinations = []
        for numero_section, section in enumerate(
            bloc.line.section.page.sections.order_by('position', 'id'), 1
        ):
            for numero_ligne, ligne in enumerate(section.lines.order_by('position', 'id'), 1):
                for colonne in range(1, max(1, ligne.columns_number or 1) + 1):
                    if ligne.pk == bloc.line_id and colonne == bloc.position:
                        continue
                    destinations.append({
                        'valeur': f'{ligne.pk}:{colonne}',
                        'libelle': (
                            f'Section {numero_section} · ligne {numero_ligne}'
                            + (f' · colonne {colonne}' if (ligne.columns_number or 1) > 1 else '')
                            + (' (ligne actuelle)' if ligne.pk == bloc.line_id else '')
                        ),
                    })
        return render(request, self.template_name, {'bloc': bloc, 'destinations': destinations})

    def post(self, request, page_id, section_id, line_id, bloc_id):
        from jeiko.administration_pages import fabrique
        from jeiko.administration_pages.responses import sections_response

        bloc = self._bloc(page_id, section_id, line_id, bloc_id)
        source = bloc.line.section
        try:
            ligne_id, colonne = (request.POST.get('destination') or '').split(':')
            colonne = int(colonne)
        except ValueError:
            return JsonResponse({'ok': False, 'message': _('Destination illisible.')}, status=400)
        cible = get_object_or_404(Line, id=ligne_id, section__page_id=page_id)
        rang = 0 if (request.POST.get('position') or 'fin') == 'debut' else None
        try:
            fabrique.deplacer_bloc(bloc, cible, colonne=colonne, rang=rang)
        except fabrique.DeplacementImpossible as souci:
            return JsonResponse({'ok': False, 'message': str(souci)}, status=400)
        return sections_response([source, cible.section], request, message=_('Bloc déplacé'))


class LineMoveDown(EditorMutationMixin, View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id):

        line = get_object_or_404(
            Line,
            id=line_id,
            section_id=section_id,
            section__page_id=page_id
        )
        # Cherche la ligne suivante dans la même section
        next_line = (
            Line.objects
            .filter(section=line.section, position__gt=line.position)
            .order_by('position')
            .first()
        )
        if next_line:
            line.position, next_line.position = next_line.position, line.position
            line.save()
            next_line.save()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            from jeiko.administration_pages.responses import swap_response

            # C6 : deux lignes échangent leur place ; rien d'autre ne change.
            if next_line:
                return swap_response(f"line-{line.id}", f"line-{next_line.id}")
            return ok_response()
        return redirect('jeiko_administration_pages:page_editor', page_id)


# Defaults dynamiques (si disponible)
try:
    from .models import DYNAMIC_DEFAULTS
except Exception:
    DYNAMIC_DEFAULTS = {}


# Ces deux vues rendent des fragments de l'éditeur. Elles étaient ouvertes à
# tout visiteur : sans donner accès à une donnée, elles exposaient la structure
# de l'outil d'administration à qui devinait l'URL. Elles portent la même garde
# que les vues de mutation voisines (EditorMutationMixin), sous forme de
# décorateurs puisque ce sont des fonctions.
@permission_required("administration_pages.change_page", raise_exception=True)
@require_GET
@never_cache
def editing_menu(request):
    """
    Retourne le fragment HTML du menu d'édition.
    """
    # Si besoin, vous pouvez passer un contexte ici.
    html = render_to_string('administration_pages/content/editing_menu.html', request=request)
    return HttpResponse(html)


@permission_required("administration_pages.change_page", raise_exception=True)
@require_GET
@never_cache
def editing_menu_section_line(request):
    """
    Retourne le fragment HTML du menu d'édition.
    """
    # Si besoin, vous pouvez passer un contexte ici.
    html = render_to_string('administration_pages/includes/sections_lines_editing_menu.html', request=request)
    return HttpResponse(html)


@method_decorator(never_cache, name='dispatch')
class ContentTypeChoice(EditorMutationMixin, View):
    """
    GET  : si content_type == NOT_SET => status="choose_type", html=choose_type.html
           sinon                       => status="ok", html=edit_{type}.html
    POST : crée/initialise le Content (TEXT/IMAGE/BUTTON/CALENDAR/FORM/CHART/VIDEO/DYN_*) et renvoie l’éditeur.
    """

    def _get_objects(self, kwargs):
        page = get_object_or_404(Page.editables, id=kwargs['page_id'])
        section = get_object_or_404(Section, id=kwargs['section_id'], page=page)
        line = get_object_or_404(Line, id=kwargs['line_id'], section=section)
        bloc = get_object_or_404(Bloc, id=kwargs['bloc_id'], line=line)
        return page, section, line, bloc

    @method_decorator(never_cache)
    def get(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content, __ = Content.objects.get_or_create(bloc=bloc)
        bloc_models = Bloc.objects.filter(is_model=True).order_by('model_name', 'id')

        if content.content_type == Content.CONTENT_TYPE_CHOICES[0][0]:  # NOT_SET
            html = render_to_string(
                "administration_pages/content/choose_type.html",
                {
                    "page": page, "section": section, "line": line, "bloc": bloc,
                    "bloc_models": bloc_models,
                    # Types groupés par intention, avec description et croquis :
                    # voir `administration_pages/content_types.py`.
                    "groups": groups_for(page),
                },
                request=request
            )
            return JsonResponse({"status": "choose_type", "html": html})

        return self._render_editor(request, page, section, line, bloc, content)

    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content, __ = Content.objects.get_or_create(bloc=bloc)
        ct = request.POST.get('content_type')

        if ct == "TEXT":
            content.content_text = ContentText.objects.create(text="")
            content.content_type = "TEXT"

        elif ct == "IMAGE":
            img = ImageContent.objects.create()
            ci = ContentImage.objects.create(image_content=img)
            content.content_image = ci
            content.content_type = "IMAGE"

        elif ct == "BUTTON":
            btn = ContentButton.objects.create(label="Cliquez ici")
            content.content_button = btn
            content.content_type = "BUTTON"
            apparence.poser(content, nouveau=True)  # BLOCS-01

        elif ct == "CALENDAR":
            cc = ContentCalendar.objects.create(title="Réserver un rendez-vous")
            content.content_calendar = cc
            content.content_type = "CALENDAR"

        elif ct == "FORM":
            formulaire = ContentFormulaire.objects.create(
                name="Nouveau formulaire",
                mail_subject="Nouveau message reçu",
                success_message="Merci, votre message a bien été envoyé.",
            )
            content.content_formulaire = formulaire
            content.content_type = "FORM"
            apparence.poser(content, nouveau=True)  # BLOCS-01

        elif ct == "CHART":
            chart = ContentChartQuestionnaire.objects.create(chart_type="bar", options_json={})
            content.content_chart = chart
            content.content_type = "CHART"

        elif ct == "VIDEO":
            cv = ContentVideo.objects.create(source=ContentVideo.Source.EXTERNAL)
            content.content_video = cv
            content.content_type = "VIDEO"

        elif ct in ("DYN_RESOURCE_CAROUSEL", "DYN_RESOURCE_GRID"):
            content.content_type = ct
            # Création de la config
            rc = DynResourceConfig.objects.create()
            content.content_resource_config = rc
            apparence.poser(content, nouveau=True)  # BLOCS-01
            content.save()
            return self._render_editor(request, page, section, line, bloc, content)

        elif ct and ct.startswith("DYN_"):
            content.content_type = ct
            content.data = copy.deepcopy(DYNAMIC_DEFAULTS.get(ct, {}))
            apparence.poser(content, nouveau=True)  # BLOCS-01
            content.save()
            return self._render_editor(request, page, section, line, bloc, content)

        else:
            return JsonResponse({"status": "error", "message": _("Type non reconnu")}, status=400)

        content.save()
        return self._render_editor(request, page, section, line, bloc, content)

    def _render_editor(self, request, page, section, line, bloc, content):
        ctx = {"page": page, "section": section, "line": line, "bloc": bloc}

        # --- classiques ---
        if content.content_type == "TEXT":
            ctx["text_form"] = TextForm(prefix="text_", instance=content.content_text)
            tpl = "administration_pages/content/edit_text.html"

        elif content.content_type == "IMAGE":
            ctx["image_form"] = ImageForm(prefix="image_", instance=content.content_image.image_content)
            ctx["content_image_form"] = ContentImageForm(prefix="content_", instance=content.content_image)
            tpl = "administration_pages/content/edit_image.html"

        elif content.content_type == "BUTTON":
            ctx["button_form"] = ButtonContentForm(prefix="button_", instance=content.content_button)
            tpl = "administration_pages/content/edit_button.html"

        elif content.content_type == "CALENDAR":
            form = ContentCalendarForm(prefix="calendar_", instance=content.content_calendar)
            if not request.user.is_superuser:
                form.fields['calendar_config'].queryset = GoogleCalendarConfig.objects.filter(user=request.user)
            ctx["calendar_form"] = form
            tpl = "administration_pages/content/edit_calendar.html"

        elif content.content_type == "FORM":
            ctx["formulaire"] = content.content_formulaire
            ctx["fields"] = content.content_formulaire.fields.all().order_by("order", "id")
            tpl = "administration_pages/content/edit_formulaire.html"

        elif content.content_type == "CHART":
            ctx["chart"] = content.content_chart
            tpl = "administration_pages/content/edit_chart.html"

        elif content.content_type == "VIDEO":
            ctx["video_form"] = ContentVideoForm(prefix="video_", instance=content.content_video)
            tpl = "administration_pages/content/edit_video.html"

        elif content.content_type in ("DYN_RESOURCE_CAROUSEL", "DYN_RESOURCE_GRID"):
            ctx["rc_form"] = DynResourceConfigForm(prefix="rc_", instance=content.content_resource_config)
            ctx["content"] = content
            if content.content_type == "DYN_RESOURCE_CAROUSEL":
                tpl = "administration_pages/content/edit_dyn/edit_dyn_resource_carousel.html"
            else:
                tpl = "administration_pages/content/edit_dyn/edit_dyn_resource_grid.html"

        # --- dyn typés ---
        elif content.content_type == "DYN_FAQ":
            ctx["faq_formset"] = FAQItemFormSet(instance=content, prefix="faq")
            ctx["faq_opts"] = FAQOptionsForm(
                initial={
                    "multiple": content.data.get("multiple", False),
                    "title_tag": content.data.get("title_tag", "H4"),
                    "main_title": content.data.get("main_title", ""),
                    "main_title_tag": content.data.get("main_title_tag", "H4"),
                },
                prefix="faqopt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_faq.html"

        elif content.content_type == "DYN_TABS":
            ctx["tab_formset"] = TabItemFormSet(instance=content, prefix="tabs")
            ctx["tabs_opts"] = TabsOptionsForm(initial={"active": content.data.get("active", 0)}, prefix="tabsopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_tabs.html"

        elif content.content_type == "DYN_CAROUSEL":
            ctx["car_formset"] = CarouselSlideFormSet(instance=content, prefix="car")
            ctx["car_opts"] = CarouselOptionsForm(
                initial={
                    "autoplay": content.data.get("autoplay", True),
                    "interval": content.data.get("interval", 5000),
                    "hide_label": content.data.get("hide_label", True),
                    "fit": content.data.get("fit", "cover"),
                },
                prefix="caropt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_carousel.html"

        elif content.content_type == "DYN_PROGRESS":
            ctx["prog_formset"] = ProgressStepFormSet(instance=content, prefix="prog")
            ctx["prog_opts"] = ProgressOptionsForm(initial={"progress": content.data.get("progress", None)}, prefix="progopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_progress.html"

        elif content.content_type == "DYN_TESTIMONIALS":
            ctx["tst_formset"] = TestimonialItemFormSet(instance=content, prefix="tst")
            ctx["tst_opts"] = TestimonialsSliderOptionsForm(
                initial={"autoplay": content.data.get("autoplay", True), "interval": content.data.get("interval", 7000)},
                prefix="tstopt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_testimonials.html"

        elif content.content_type == "DYN_TESTIMONIALS_GRID":
            ctx["tst_formset"] = TestimonialItemFormSet(instance=content, prefix="tst")
            ctx["tst_opts"] = TestimonialsGridOptionsForm(
                initial={"perRow": content.data.get("perRow", 3), "rotate": content.data.get("rotate", True), "interval": content.data.get("interval", 6000)},
                prefix="tstopt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_testimonials_grid.html"

        elif content.content_type == "DYN_FILTER":
            ctx["lf_formset"] = LiveFilterItemFormSet(instance=content, prefix="lf")
            ctx["lf_opts"] = LiveFilterOptionsForm(initial={"keys": ",".join(content.data.get("keys", ["title", "category"]))}, prefix="lfopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_live_filter.html"

        elif content.content_type == "DYN_COUNTDOWN":
            ctx["cd_opts"] = CountdownOptionsForm(initial={"deadline": content.data.get("deadline", "")}, prefix="cdopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_countdown.html"

        elif content.content_type == "DYN_COUNTDOWN_CTA":
            ctx["cd_opts"] = CountdownCTAOptionsForm(
                initial={
                    "deadline": content.data.get("deadline", ""),
                    "ctaText": content.data.get("ctaText", "Réserver"),
                    "ctaHref": content.data.get("ctaHref", "#"),
                },
                prefix="cdopt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_countdown_cta.html"

        elif content.content_type == "DYN_ACCORDION_ADV":
            sections = content.accordion_sections.all()
            ctx["acc_sec_formset"] = AccordionSectionFormSet(instance=content, prefix="acc")
            ctx["acc_child_sets"] = {sec.pk: AccordionChildFormSetFactory(sec) for sec in sections}
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_accordion_adv.html"

        elif content.content_type == "DYN_PRICING_TABLE":
            ctx["pl_formset"] = PricingPlanFormSet(instance=content, prefix="pl")
            ctx["pl_feat_sets"] = {pl.pk: PricingFeatureFormSetFactory(pl) for pl in content.pricing_plans.all()}
            ctx["pl_opts"] = PricingOptionsForm(initial={"yearly": content.data.get("yearly", False)}, prefix="plopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_pricing.html"

        elif content.content_type == "DYN_GALLERY_FILTER":
            gal_formset = GalleryItemFormSet(instance=content, prefix="gal")
            gal_opts = GalleryOptionsForm(initial={"categories": ",".join(content.data.get("categories", ["all"]))}, prefix="galopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_gallery.html"
            ctx = {
                "page": page, "section": section, "line": line, "bloc": bloc,
                "gal_formset": gal_formset, "gal_opts": gal_opts, "content": content,
            }

        elif content.content_type == "DYN_STEPPER":
            ctx["stp_formset"] = StepperStepFormSet(instance=content, prefix="stp")
            ctx["stp_opts"] = StepperOptionsForm(initial={"start": content.data.get("start", 0)}, prefix="stpopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_stepper.html"

        elif content.content_type == "DYN_RATING":
            ctx["rt_opts"] = RatingOptionsForm(
                initial={
                    "rating": content.data.get("rating", 4.0),
                    "count": content.data.get("count", 0),
                    "max": content.data.get("max", 5),
                    "editable": content.data.get("editable", False),
                },
                prefix="rtopt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_rating.html"

        elif content.content_type == "DYN_NEWSLETTER":
            ctx["nl_opts"] = NewsletterBlocForm(initial=content.data or {}, prefix="nlopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_newsletter.html"

        else:
            ctx["dyn_form"] = DynamicContentForm(initial_data=content.data, prefix="dyn_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dynamic.html"

        # Forms style/size/css du bloc (GET => non bindés)
        bloc_ctx_forms = get_bloc_forms_context(bloc, data=None)
        ctx.update(bloc_ctx_forms)

        html = render_to_string(tpl, ctx, request=request)
        return JsonResponse({"status": "success", "html": html})


@method_decorator(never_cache, name='dispatch')
class ContentTypeChoiceFromModel(EditorMutationMixin, View):
    """
    POST : remplace le bloc courant par un bloc basé sur un modèle existant.
           Renvoie le fragment HTML du nouveau bloc.
    """
    bloc_partial = 'administration_pages/partials/bloc.html'
    section_partial = 'administration_pages/partials/section.html'

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page.editables, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        old_bloc = get_object_or_404(Bloc, id=bloc_id, line=line)

        choice = (request.POST.get("bloc_model_choice") or "").strip()
        if not choice.startswith("MODEL:"):
            return HttpResponseBadRequest("Choix de modèle de bloc invalide")

        try:
            model_id = int(choice.split(":", 1)[1])
        except Exception:
            return HttpResponseBadRequest("Identifiant de modèle de bloc invalide")

        model_bloc = get_object_or_404(Bloc, id=model_id, is_model=True)

        position = old_bloc.position or 0

        # supprimer bloc + contenu
        try:
            old_content = getattr(old_bloc, "content", None)
            if old_content:
                old_content.delete()
            old_bloc.delete()
        except Exception:
            # L'ancien bloc resterait en base, invisible dans l'éditeur.
            logger.exception("Ancien bloc %s non supprimé", getattr(old_bloc, "pk", None))

        new_bloc = bloc_duplicate(model_bloc, target_line=line, position=position, as_model=False, link_model=True)

        new_bloc.is_model = False
        new_bloc.model_name = None
        new_bloc.model_source = model_bloc
        new_bloc.model_sync = request.POST.get("model_sync") == "1"
        new_bloc.save(update_fields=["is_model", "model_name", "model_source", "model_sync"])

        return line_response(line, request, bloc_id=new_bloc.id)


@method_decorator(never_cache, name='dispatch')
class EditContent(EditorMutationMixin, View):
    """
    GET : rend le formulaire d’édition du contenu (texte/image/etc.) {status:"ok", html:…}
    POST: sauvegarde et renvoie {status:"success", html:…}
    """

    def _get_objects(self, kwargs):
        page    = get_object_or_404(Page.editables, id=kwargs['page_id'])
        section = get_object_or_404(Section, id=kwargs['section_id'], page=page)
        line    = get_object_or_404(Line, id=kwargs['line_id'], section=section)
        bloc    = get_object_or_404(Bloc, id=kwargs['bloc_id'], line=line)
        return page, section, line, bloc

    @method_decorator(never_cache)
    def get(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content = getattr(bloc, "content", None)
        if not content or content.content_type == Content.CONTENT_TYPE_CHOICES[0][0]:
            return JsonResponse({"status": "choose_type", "html": ""})
        return ContentTypeChoice()._render_editor(request, page, section, line, bloc, content)

    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content = getattr(bloc, "content", None)
        if not content or content.content_type == Content.CONTENT_TYPE_CHOICES[0][0]:
            return JsonResponse({"status": "error", "message": _("Contenu non initialisé")}, status=400)

        data = request.POST
        files = request.FILES

        # --- spécifiques par type ---
        if content.content_type == "IMAGE":
            image_form = ImageForm(data, files, prefix="image_", instance=content.content_image.image_content)
            content_image_form = ContentImageForm(data, prefix="content_", instance=content.content_image)
            tpl = "administration_pages/content/edit_image.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "image_form": image_form, "content_image_form": content_image_form}
            main_valid = image_form.is_valid() and content_image_form.is_valid()

        elif content.content_type == "TEXT":
            form = TextForm(data, prefix="text_", instance=content.content_text)
            tpl = "administration_pages/content/edit_text.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "text_form": form}
            main_valid = form.is_valid()

        elif content.content_type == "BUTTON":
            form = ButtonContentForm(data, prefix="button_", instance=content.content_button)
            tpl = "administration_pages/content/edit_button.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "button_form": form}
            main_valid = form.is_valid()

        elif content.content_type == "CALENDAR":
            form = ContentCalendarForm(data, prefix="calendar_", instance=content.content_calendar)
            if not request.user.is_superuser:
                form.fields['calendar_config'].queryset = GoogleCalendarConfig.objects.filter(user=request.user)
            tpl = "administration_pages/content/edit_calendar.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "calendar_form": form}
            main_valid = form.is_valid()

        elif content.content_type == "FORM":
            formulaire = content.content_formulaire
            formulaire.name = data.get("name", formulaire.name)
            formulaire.description = data.get("description", formulaire.description)
            formulaire.mail_subject = data.get("mail_subject", formulaire.mail_subject)
            formulaire.success_message = data.get("success_message", formulaire.success_message)
            formulaire.to_email = data.get("to_email", formulaire.to_email)
            formulaire.from_email = data.get("from_email", formulaire.from_email)
            formulaire.save()
            fields = formulaire.fields.all().order_by("order", "id")
            tpl = "administration_pages/content/edit_formulaire.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "formulaire": formulaire, "fields": fields}
            main_valid = True

        elif content.content_type == "CHART":
            chart = content.content_chart
            chart.chart_type = data.get("chart_type", chart.chart_type)
            chart.title = data.get("title", chart.title)
            chart.description = data.get("description", chart.description)
            try:
                options = data.get("options_json", "{}")
                chart.options_json = json.loads(options) if options else {}
            except (TypeError, ValueError):
                # JSON mal formé : on garde les options en place plutôt que de
                # les vider, et on le trace.
                logger.warning("Options de graphique illisibles, conservées : %r", data.get("options_json"))
            chart.save()
            tpl = "administration_pages/content/edit_chart.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "chart": chart}
            main_valid = True

        elif content.content_type == "VIDEO":
            form = ContentVideoForm(data, files, prefix="video_", instance=content.content_video)
            tpl = "administration_pages/content/edit_video.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "video_form": form}
            main_valid = form.is_valid()

        elif content.content_type in ("DYN_RESOURCE_CAROUSEL", "DYN_RESOURCE_GRID"):
            rc_form = DynResourceConfigForm(data, prefix="rc_", instance=content.content_resource_config)
            if content.content_type == "DYN_RESOURCE_CAROUSEL":
                tpl = "administration_pages/content/edit_dyn/edit_dyn_resource_carousel.html"
            else:
                tpl = "administration_pages/content/edit_dyn/edit_dyn_resource_grid.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "rc_form": rc_form, "content": content}
            main_valid = rc_form.is_valid()

        # --- dyn typés ---
        elif content.content_type == "DYN_FAQ":
            faq_fs = build_bound_inline_formset(data, files, FAQItemFormSet, prefix="faq", instance=content,
                                                start_order=1)
            faq_opts = FAQOptionsForm(data, prefix="faqopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_faq.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "faq_formset": faq_fs, "faq_opts": faq_opts, "content": content}
            main_valid = faq_fs.is_valid() and faq_opts.is_valid()

        elif content.content_type == "DYN_TABS":
            tab_fs = build_bound_inline_formset(data, files, TabItemFormSet, prefix="tabs", instance=content,
                                                start_order=1)
            tabs_opts = TabsOptionsForm(data, prefix="tabsopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_tabs.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "tab_formset": tab_fs, "tabs_opts": tabs_opts, "content": content}
            main_valid = tab_fs.is_valid() and tabs_opts.is_valid()

        elif content.content_type == "DYN_CAROUSEL":
            car_fs = build_bound_inline_formset(data, files, CarouselSlideFormSet, prefix="car", instance=content,
                                                start_order=1)
            car_opts = CarouselOptionsForm(data, prefix="caropt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_carousel.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "car_formset": car_fs, "car_opts": car_opts, "content": content}
            main_valid = car_fs.is_valid() and car_opts.is_valid()

        elif content.content_type == "DYN_PROGRESS":
            prog_fs = build_bound_inline_formset(data, files, ProgressStepFormSet, prefix="prog", instance=content,
                                                 start_order=1)
            prog_opts = ProgressOptionsForm(data, prefix="progopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_progress.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "prog_formset": prog_fs, "prog_opts": prog_opts, "content": content}
            main_valid = prog_fs.is_valid() and prog_opts.is_valid()

        elif content.content_type == "DYN_TESTIMONIALS":
            tst_fs = build_bound_inline_formset(data, files, TestimonialItemFormSet, prefix="tst", instance=content,
                                                start_order=1)
            tst_opts = TestimonialsSliderOptionsForm(data, prefix="tstopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_testimonials.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "tst_formset": tst_fs, "tst_opts": tst_opts, "content": content}
            main_valid = tst_fs.is_valid() and tst_opts.is_valid()

        elif content.content_type == "DYN_TESTIMONIALS_GRID":
            tst_fs = build_bound_inline_formset(data, files, TestimonialItemFormSet, prefix="tst", instance=content,
                                                start_order=1)
            tst_opts = TestimonialsGridOptionsForm(data, prefix="tstopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_testimonials_grid.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "tst_formset": tst_fs, "tst_opts": tst_opts, "content": content}
            main_valid = tst_fs.is_valid() and tst_opts.is_valid()

        elif content.content_type == "DYN_FILTER":
            lf_fs = build_bound_inline_formset(data, files, LiveFilterItemFormSet, prefix="lf", instance=content,
                                               start_order=1)
            lf_opts = LiveFilterOptionsForm(data, prefix="lfopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_live_filter.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "lf_formset": lf_fs, "lf_opts": lf_opts, "content": content}
            main_valid = lf_fs.is_valid() and lf_opts.is_valid()

        elif content.content_type == "DYN_COUNTDOWN":
            cd_opts = CountdownOptionsForm(data, prefix="cdopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_countdown.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "cd_opts": cd_opts, "content": content}
            main_valid = cd_opts.is_valid()

        elif content.content_type == "DYN_COUNTDOWN_CTA":
            cd_opts = CountdownCTAOptionsForm(data, prefix="cdopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_countdown_cta.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "cd_opts": cd_opts, "content": content}
            main_valid = cd_opts.is_valid()

        elif content.content_type == "DYN_ACCORDION_ADV":
            acc_sec_fs = AccordionSectionFormSet(data, instance=content, prefix="acc")
            child_sets = {}
            for sec in content.accordion_sections.all():
                fs = AccordionChildFormSetFactory(sec)
                fs.data = data
                fs.is_bound = True
                child_sets[sec.pk] = fs
            tpl = "administration_pages/content/edit_dyn/edit_dyn_accordion_adv.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "acc_sec_formset": acc_sec_fs, "acc_child_sets": child_sets, "content": content}
            main_valid = acc_sec_fs.is_valid() and all(fs.is_valid() for fs in child_sets.values())

        elif content.content_type == "DYN_PRICING_TABLE":
            pl_fs = build_bound_inline_formset(data, files, PricingPlanFormSet, prefix="pl", instance=content,
                                               start_order=1)
            feat_sets = {}
            for pl in content.pricing_plans.all():
                fs = PricingFeatureFormSetFactory(pl)
                fs.data = data
                fs.is_bound = True
                feat_sets[pl.pk] = fs
            pl_opts = PricingOptionsForm(data, prefix="plopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_pricing.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "pl_formset": pl_fs, "pl_feat_sets": feat_sets, "pl_opts": pl_opts, "content": content}
            main_valid = pl_fs.is_valid() and pl_opts.is_valid() and all(fs.is_valid() for fs in feat_sets.values())

        elif content.content_type == "DYN_GALLERY_FILTER":
            gal_fs = build_bound_inline_formset(data, files, GalleryItemFormSet, prefix="gal", instance=content,
                                                start_order=1)
            gal_opts = GalleryOptionsForm(data, prefix="galopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_gallery.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "gal_formset": gal_fs, "gal_opts": gal_opts, "content": content}
            main_valid = gal_fs.is_valid() and gal_opts.is_valid()

        elif content.content_type == "DYN_STEPPER":
            stp_fs = build_bound_inline_formset(data, files, StepperStepFormSet, prefix="stp", instance=content,
                                                start_order=1)
            stp_opts = StepperOptionsForm(data, prefix="stpopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_stepper.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "stp_formset": stp_fs, "stp_opts": stp_opts, "content": content}
            main_valid = stp_fs.is_valid() and stp_opts.is_valid()

        elif content.content_type == "DYN_RATING":
            rt_opts = RatingOptionsForm(data, prefix="rtopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_rating.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "rt_opts": rt_opts, "content": content}
            main_valid = rt_opts.is_valid()

        elif content.content_type == "DYN_NEWSLETTER":
            nl_opts = NewsletterBlocForm(data, prefix="nlopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_newsletter.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "nl_opts": nl_opts, "content": content}
            main_valid = nl_opts.is_valid()

        else:
            form = DynamicContentForm(data, prefix="dyn_")
            tpl = "administration_pages/content/edit_dynamic.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "dyn_form": form, "content": content}
            main_valid = form.is_valid()

        # --- forms style/size/css/animation du bloc (bindés)
        bloc_ctx_forms = get_bloc_forms_context(bloc, data=data)
        custom_css_form = bloc_ctx_forms.get("custom_css_form")
        animation_form = bloc_ctx_forms.get("animation_form")
        border_form = bloc_ctx_forms.get("border_form")

        if custom_css_form is not None:
            custom_css_form.instance.section = None
            custom_css_form.instance.line = None
            custom_css_form.instance.bloc = bloc

        if animation_form is not None:
            animation_form.instance.section = None
            animation_form.instance.line = None
            animation_form.instance.bloc = bloc

        if border_form is not None:
            border_form.instance.section = None
            border_form.instance.line = None
            border_form.instance.bloc = bloc

        # Regroupe pour validation globale (ajout animation_form)
        if content.content_type == "IMAGE":
            all_forms = [image_form, content_image_form] \
                        + bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] \
                        + ([custom_css_form] if custom_css_form else []) \
                        + ([animation_form] if animation_form else []) \
                        + ([border_form] if border_form else [])
        elif content.content_type in ("FORM", "CHART", "VIDEO"):
            base_forms = []
            if content.content_type == "VIDEO":
                base_forms = [form]
            all_forms = base_forms \
                        + bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] \
                        + ([custom_css_form] if custom_css_form else []) \
                        + ([animation_form] if animation_form else []) \
                        + ([border_form] if border_form else [])

        elif content.content_type in ("DYN_RESOURCE_CAROUSEL", "DYN_RESOURCE_GRID"):
            base_forms = [rc_form]
            all_forms = base_forms \
                        + bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] \
                        + ([custom_css_form] if custom_css_form else []) \
                        + ([animation_form] if animation_form else []) \
                        + ([border_form] if border_form else [])
        else:
            base_forms = []
            if 'form' in locals():
                base_forms = [form]
            elif 'faq_fs' in locals():
                base_forms = [faq_fs, faq_opts]
            elif 'tab_fs' in locals():
                base_forms = [tab_fs, tabs_opts]
            elif 'car_fs' in locals():
                base_forms = [car_fs, car_opts]
            elif 'prog_fs' in locals():
                base_forms = [prog_fs, prog_opts]
            elif 'tst_fs' in locals() and 'tst_opts' in locals():
                base_forms = [tst_fs, tst_opts]
            elif 'lf_fs' in locals():
                base_forms = [lf_fs, lf_opts]
            elif 'cd_opts' in locals():
                base_forms = [cd_opts]
            elif 'acc_sec_fs' in locals():
                base_forms = [acc_sec_fs] + list(child_sets.values())
            elif 'pl_fs' in locals():
                base_forms = [pl_fs, pl_opts] + list(feat_sets.values())
            elif 'gal_fs' in locals():
                base_forms = [gal_fs, gal_opts]
            elif 'stp_fs' in locals():
                base_forms = [stp_fs, stp_opts]
            elif 'rt_opts' in locals():
                base_forms = [rt_opts]
            all_forms = base_forms \
                        + bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] \
                        + ([custom_css_form] if custom_css_form else []) \
                        + ([animation_form] if animation_form else [])

        valid = main_valid and all((f is None) or f.is_valid() for f in all_forms)

        if not valid:
            html = render_to_string(tpl, {**ctx, **bloc_ctx_forms}, request=request)

            # Collecte d’erreurs (inclut animation_form)
            base_forms = []
            if 'form' in locals():
                base_forms = [form]
            elif 'rc_form' in locals():
                base_forms = [rc_form]
            elif 'faq_fs' in locals():
                base_forms = [faq_fs, faq_opts]
            elif 'tab_fs' in locals():
                base_forms = [tab_fs, tabs_opts]
            elif 'car_fs' in locals():
                base_forms = [car_fs, car_opts]
            elif 'prog_fs' in locals():
                base_forms = [prog_fs, prog_opts]
            elif 'tst_fs' in locals() and 'tst_opts' in locals():
                base_forms = [tst_fs, tst_opts]
            elif 'lf_fs' in locals():
                base_forms = [lf_fs, lf_opts]
            elif 'cd_opts' in locals():
                base_forms = [cd_opts]
            elif 'acc_sec_fs' in locals():
                base_forms = [acc_sec_fs] + list(child_sets.values())
            elif 'pl_fs' in locals():
                base_forms = [pl_fs, pl_opts] + list(feat_sets.values())
            elif 'gal_fs' in locals():
                base_forms = [gal_fs, gal_opts]
            elif 'stp_fs' in locals():
                base_forms = [stp_fs, stp_opts]
            elif 'rt_opts' in locals():
                base_forms = [rt_opts]

            all_for_err = []
            if content.content_type == "IMAGE":
                all_for_err = [image_form, content_image_form]
            elif content.content_type in ("FORM", "CHART", "VIDEO"):
                all_for_err = base_forms
            else:
                all_for_err = base_forms
            all_for_err += bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] \
                           + ([custom_css_form] if custom_css_form else []) \
                           + ([animation_form] if animation_form else [])

            errs = _errors_dict(*all_for_err)

            import logging
            logger = logging.getLogger(__name__)
            logger.warning("EditContent invalid (%s) - errors: %s", content.content_type, errs)

            return JsonResponse({"status": "error", "errors": errs, "html": html}, status=400)

        # --- SAUVEGARDE principale selon le type ---
        message_au_redacteur = ""
        if content.content_type == "TEXT":
            form.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)
            if form.avertissements:
                # A-49 : dire ce que le site ne servira pas, plutôt que de
                # laisser le rédacteur le découvrir sur la page publiée.
                message_au_redacteur = (
                    "Enregistré, mais une partie de la mise en forme ne sera pas "
                    "servie : " + " ; ".join(form.avertissements) + "."
                )

        elif content.content_type == "IMAGE":
            image_instance = image_form.save()
            content_image = content_image_form.save(commit=False)
            content_image.image_content = image_instance
            content_image.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type in ("FORM", "CHART"):
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "VIDEO":
            form.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type in ("DYN_RESOURCE_CAROUSEL", "DYN_RESOURCE_GRID"):
            rc_form.save()
            # La configuration vit dans `rc_form` ; `data` ne garde que la marque
            # des nouveaux défauts (BLOCS-01), qu'un enregistrement n'efface pas.
            content.data = {k: v for k, v in (content.data or {}).items() if k == "apparence"}
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_FAQ":
            faq_fs.save()
            resequence_queryset(content.faq_items.all(), field="order", start=1)
            content.data["multiple"] = faq_opts.cleaned_data.get("multiple", False)
            content.data["title_tag"] = (faq_opts.cleaned_data.get("title_tag") or "h4").lower()
            content.data["main_title"] = (faq_opts.cleaned_data.get("main_title") or "")
            content.data["main_title_tag"] = (faq_opts.cleaned_data.get("main_title_tag") or "h3").lower()
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_TABS":
            tab_fs.save()
            resequence_queryset(content.tab_items.all(), field="order", start=1)
            content.data["active"] = tabs_opts.cleaned_data.get("active", 0) or 0
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_CAROUSEL":
            __ = car_fs.save(commit=False)
            for f in car_fs.forms:
                if f in car_fs.deleted_forms:
                    continue
                f.save(commit=True)
            for obj in car_fs.deleted_objects:
                obj.delete()
            resequence_queryset(content.carousel_slides.all(), field="order", start=1)
            content.data["autoplay"] = car_opts.cleaned_data.get("autoplay", True)
            content.data["interval"] = car_opts.cleaned_data.get("interval", 5000) or 5000
            content.data["hide_label"] = car_opts.cleaned_data.get("hide_label", True)
            content.data["fit"] = car_opts.cleaned_data.get("fit") or "cover"
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_PROGRESS":
            prog_fs.save()
            resequence_queryset(content.progress_steps.all(), field="order", start=1)
            pval = prog_opts.cleaned_data.get("progress")
            if pval is not None:
                content.data["progress"] = float(pval)
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_TESTIMONIALS":
            tst_fs.save()
            resequence_queryset(content.testimonial_items.all(), field="order", start=1)
            content.data["autoplay"] = tst_opts.cleaned_data.get("autoplay", True)
            content.data["interval"] = tst_opts.cleaned_data.get("interval", 7000) or 7000
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_TESTIMONIALS_GRID":
            tst_fs.save()
            resequence_queryset(content.testimonial_items.all(), field="order", start=1)
            content.data["perRow"] = tst_opts.cleaned_data.get("perRow", 3) or 3
            content.data["rotate"] = tst_opts.cleaned_data.get("rotate", True)
            content.data["interval"] = tst_opts.cleaned_data.get("interval", 6000) or 6000
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_FILTER":
            lf_fs.save()
            resequence_queryset(content.livefilter_items.all(), field="order", start=1)
            keys_raw = lf_opts.cleaned_data.get("keys")
            if isinstance(keys_raw, str):
                keys = [k.strip() for k in keys_raw.split(",") if k.strip()]
            else:
                keys = keys_raw or ["title", "category"]
            content.data["keys"] = keys
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type in ("DYN_COUNTDOWN", "DYN_COUNTDOWN_CTA"):
            deadline = cd_opts.cleaned_data.get("deadline")
            if isinstance(deadline, (datetime.datetime, datetime.date)):
                if isinstance(deadline, datetime.date) and not isinstance(deadline, datetime.datetime):
                    deadline = datetime.datetime.combine(deadline, datetime.time(0, 0, 0))
                deadline_str = deadline.strftime("%Y-%m-%d %H:%M:%S")
            else:
                deadline_str = (str(deadline).strip()) if deadline else ""
            content.data["deadline"] = deadline_str
            if content.content_type == "DYN_COUNTDOWN_CTA":
                content.data["ctaText"] = cd_opts.cleaned_data.get("ctaText") or "Réserver"
                content.data["ctaHref"] = cd_opts.cleaned_data.get("ctaHref") or "#"
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_ACCORDION_ADV":
            acc_sec_fs.save()
            for sec in content.accordion_sections.all():
                fs = AccordionChildFormSetFactory(sec)
                fs.data = data
                fs.is_bound = True
                if fs.is_valid():
                    fs.save()
                resequence_queryset(sec.children.all(), field="order", start=1)
            resequence_queryset(content.accordion_sections.all(), field="order", start=1)
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_PRICING_TABLE":
            pl_fs.save()
            resequence_queryset(content.pricing_plans.all(), field="order", start=1)
            for pl in content.pricing_plans.all():
                fs = PricingFeatureFormSetFactory(pl)
                fs.data = data
                fs.is_bound = True
                if fs.is_valid():
                    fs.save()
                resequence_queryset(pl.features.all(), field="order", start=1)
            content.data["yearly"] = bool(pl_opts.cleaned_data.get("yearly", False))
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_GALLERY_FILTER":
            gal_fs.save()
            resequence_queryset(content.gallery_items.all(), field="order", start=1)
            cats = gal_opts.cleaned_data.get("categories") or []
            if not cats:
                deduced = sorted({
                    (gi.category or "").strip()
                    for gi in content.gallery_items.all()
                    if (gi.category or "").strip()
                })
                if "all" not in [c.lower() for c in deduced]:
                    cats = ["all"] + deduced
                else:
                    cats = deduced
            else:
                if "all" not in [c.lower() for c in cats]:
                    cats = ["all"] + cats

            snap = _snapshot_for_content(content)
            snap["categories"] = cats
            content.data = snap
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_STEPPER":
            stp_fs.save()
            resequence_queryset(content.stepper_steps.all(), field="order", start=1)
            content.data["start"] = stp_opts.cleaned_data.get("start", 0) or 0
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_RATING":
            content.data["rating"] = float(rt_opts.cleaned_data.get("rating", 4.0) or 4.0)
            content.data["count"] = int(rt_opts.cleaned_data.get("count", 0) or 0)
            content.data["max"] = int(rt_opts.cleaned_data.get("max", 5) or 5)
            content.data["editable"] = bool(rt_opts.cleaned_data.get("editable", False))
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_NEWSLETTER":
            content.data = nl_opts.donnees()
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        else:
            payload = (form.cleaned_data.get("data_json") or form.cleaned_data.get("data") or None)
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except Exception:
                    payload = {"_raw": payload}
            content.data = payload or {}
            content.save()
            form.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        # --- CustomCSS : sauvegarde “propre” (avec purge si vide)
        if custom_css_form:
            cd = custom_css_form.cleaned_data
            has_css = any(
                (cd.get(k) or "").strip() for k in custom_css_form.fields)
            cc = custom_css_form.save(commit=False)
            if cc.pk is None:
                cc.section, cc.line, cc.bloc = None, None, bloc
            if has_css:
                cc.save()
            else:
                try:
                    if cc.pk:
                        cc.delete()
                except Exception:
                    logger.exception("CSS du bloc non supprimé (%s)", cc.pk)

        # --- Animations : même logique que CustomCSS (sauver si enabled, sinon purge)
        if animation_form:
            anim = animation_form.save(commit=False)
            # forcer la cible XOR
            anim.section, anim.line, anim.bloc = None, None, bloc
            try:
                if getattr(anim, "enabled", False):
                    anim.save()
                else:
                    # si une animation existe et que l’on la désactive → delete
                    # Aucune animation : rien à retirer (ObjectDoesNotExist).
                    from django.core.exceptions import ObjectDoesNotExist
                    try:
                        bloc.animation.delete()
                    except ObjectDoesNotExist:
                        pass
            except Exception:
                # fallback: ne bloque pas tout l’enregistrement si l’animation pose souci
                pass

        # C6 : le contenu d'un bloc ne touche que sa ligne.
        return line_response(line, request, message=message_au_redacteur)


@method_decorator(never_cache, name='dispatch')
class ResetContent(EditorMutationMixin, View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id, bloc_id):
        bloc = get_object_or_404(
            Bloc,
            id=bloc_id,
            line_id=line_id,
            line__section_id=section_id,
            line__section__page_id=page_id
        )

        if not hasattr(bloc, 'content') or not bloc.content:
            return JsonResponse({'status': 'no_content'}, status=400)

        content = bloc.content
        # Le modèle détache le satellite avant de le supprimer. Pour une image,
        # seul le réglage du bloc disparaît : le média reste disponible dans la
        # bibliothèque et peut continuer à servir ailleurs.
        content.reset()

        return line_response(bloc.line, request, status="reset")


@method_decorator(never_cache, name='dispatch')
class BlocCreate(EditorMutationMixin, View):
    """
    Ajout d’un bloc sous un bloc existant, dans la même colonne.
    - Params: page_id, section_id, line_id, bloc_id
    - Renvoie {"status": "success", "section_id":.., "section_html":..}
    """

    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page.editables, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        ref_bloc = get_object_or_404(Bloc, id=bloc_id, line=line)

        # même colonne
        position = ref_bloc.position

        # dernier bloc de cette colonne
        last = line.blocs.filter(position=position).order_by('-position_in_column').first()
        pos_in_col = (last.position_in_column + 1) if last else 0

        # helpers
        def _sb():
            return StyleBox.objects.create(top=0, right=0, bottom=0, left=0)

        def _size():
            return Size.objects.create(width="100%", height="")

        new_bloc = Bloc.objects.create(
            line=line,
            position=position,
            position_in_column=pos_in_col,
            margin_phone=_sb(), margin_tablet=_sb(), margin_laptop=_sb(), margin_computer=_sb(),
            padding_phone=_sb(), padding_tablet=_sb(), padding_laptop=_sb(), padding_computer=_sb(),
            size_phone=_size(), size_tablet=_size(), size_laptop=_size(), size_computer=_size(),
        )

        if self._is_ajax(request):
            return line_response(line, request, new_bloc_id=new_bloc.id)

        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)

@method_decorator(never_cache, name='dispatch')
class BlocDelete(EditorMutationMixin, View):
    """
    Suppression d'un bloc :
    - sur fetch AJAX : renvoie {"status":"success", "section_id":..., "section_html":...}
    - sinon : redirect vers page_editor
    """

    def post(self, request, page_id, section_id, line_id, bloc_id):
        line = get_object_or_404(Line, id=line_id, section_id=section_id, section__page_id=page_id)
        bloc = get_object_or_404(Bloc, id=bloc_id, line=line)

        # Vérif sécurité : ne jamais supprimer le dernier bloc
        same_column_count = Bloc.objects.filter(line_id=line_id, position=bloc.position).count()
        if same_column_count <= 1:
            return JsonResponse({
                "status": "error",
                "message": _("Impossible de supprimer le dernier bloc de cette colonne.")
            }, status=400)

        bloc.delete()

        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return line_response(line, request)

        return redirect("jeiko_administration_pages:page_editor", page_id)


@method_decorator(never_cache, name='dispatch')
class BlocMoveUp(EditorMutationMixin, View):
    """Déplacement d’un bloc vers le haut (swap avec le précédent dans la colonne)."""

    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page.editables, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        bloc    = get_object_or_404(Bloc, id=bloc_id, line=line)

        if bloc.position_in_column > 0:
            above = line.blocs.filter(position=bloc.position, position_in_column=bloc.position_in_column - 1).first()
            if above:
                # swap
                above.position_in_column, bloc.position_in_column = bloc.position_in_column, above.position_in_column
                above.save(update_fields=['position_in_column'])
                bloc.save(update_fields=['position_in_column'])

        if self._is_ajax(request):
            # C6 : un déplacement de bloc ne touche que sa ligne.
            return line_response(line, request)
        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)


@method_decorator(never_cache, name='dispatch')
class BlocMoveDown(EditorMutationMixin, View):
    """Déplacement d’un bloc vers le bas (swap avec le suivant dans la colonne)."""

    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page.editables, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        bloc    = get_object_or_404(Bloc, id=bloc_id, line=line)

        below = line.blocs.filter(position=bloc.position, position_in_column=bloc.position_in_column + 1).first()
        if below:
            # swap
            below.position_in_column, bloc.position_in_column = bloc.position_in_column, below.position_in_column
            below.save(update_fields=['position_in_column'])
            bloc.save(update_fields=['position_in_column'])

        if self._is_ajax(request):
            # C6 : un déplacement de bloc ne touche que sa ligne.
            return line_response(line, request)
        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)


@method_decorator(never_cache, name='dispatch')
class BlocMoveLeft(EditorMutationMixin, View):
    """Déplacement d’un bloc vers la colonne de gauche."""

    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    def _create_empty_bloc(self, line, position):
        """Créer un bloc vide par sécurité (comme dans BlocCreate)."""
        def _sb():
            return StyleBox.objects.create(top=0, right=0, bottom=0, left=0)

        def _size():
            return Size.objects.create(width="100%", height="")

        return Bloc.objects.create(
            line=line,
            position=position,
            position_in_column=0,
            margin_phone=_sb(), margin_tablet=_sb(), margin_laptop=_sb(), margin_computer=_sb(),
            padding_phone=_sb(), padding_tablet=_sb(), padding_laptop=_sb(), padding_computer=_sb(),
            size_phone=_size(), size_tablet=_size(), size_laptop=_size(), size_computer=_size(),
        )

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page.editables, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        bloc    = get_object_or_404(Bloc, id=bloc_id, line=line)

        if bloc.position > 1:
            old_position = bloc.position
            new_position = bloc.position - 1

            # nouvelle colonne -> bloc à la fin
            last = line.blocs.filter(position=new_position).order_by('-position_in_column').first()
            bloc.position = new_position
            bloc.position_in_column = (last.position_in_column + 1) if last else 0
            bloc.save()

            # colonne d'origine -> réordonner
            remaining = line.blocs.filter(position=old_position).order_by('position_in_column')
            if not remaining.exists():
                self._create_empty_bloc(line, old_position)
            else:
                for idx, b in enumerate(remaining):
                    if b.position_in_column != idx:
                        b.position_in_column = idx
                        b.save(update_fields=['position_in_column'])

        if self._is_ajax(request):
            # C6 : un déplacement de bloc ne touche que sa ligne.
            return line_response(line, request)
        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)


@method_decorator(never_cache, name='dispatch')
class BlocMoveRight(EditorMutationMixin, View):
    """Déplacement d’un bloc vers la colonne de droite."""

    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    def _create_empty_bloc(self, line, position):
        """Créer un bloc vide par sécurité (comme dans BlocCreate)."""
        def _sb():
            return StyleBox.objects.create(top=0, right=0, bottom=0, left=0)

        def _size():
            return Size.objects.create(width="100%", height="")

        return Bloc.objects.create(
            line=line,
            position=position,
            position_in_column=0,
            margin_phone=_sb(), margin_tablet=_sb(), margin_laptop=_sb(), margin_computer=_sb(),
            padding_phone=_sb(), padding_tablet=_sb(), padding_laptop=_sb(), padding_computer=_sb(),
            size_phone=_size(), size_tablet=_size(), size_laptop=_size(), size_computer=_size(),
        )

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page.editables, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        bloc    = get_object_or_404(Bloc, id=bloc_id, line=line)

        if bloc.position < line.columns_number :
            old_position = bloc.position
            new_position = bloc.position + 1

            # nouvelle colonne -> bloc à la fin
            last = line.blocs.filter(position=new_position).order_by('-position_in_column').first()
            bloc.position = new_position
            bloc.position_in_column = (last.position_in_column + 1) if last else 0
            bloc.save()

            # colonne d'origine -> réordonner
            remaining = line.blocs.filter(position=old_position).order_by('position_in_column')
            if not remaining.exists():
                self._create_empty_bloc(line, old_position)
            else:
                for idx, b in enumerate(remaining):
                    if b.position_in_column != idx:
                        b.position_in_column = idx
                        b.save(update_fields=['position_in_column'])

        if self._is_ajax(request):
            # C6 : un déplacement de bloc ne touche que sa ligne.
            return line_response(line, request)
        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)


class PageTogglePublish(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Publie ou dépublie une page, en un geste.

    Pourquoi cette vue existe
    -------------------------
    Publier n'était pas une action : c'était la case « Actif » d'un formulaire
    de réglages, à un autre endroit que celui où l'on venait de travailler.
    Une page fraîchement créée est inactive par défaut, et rien ne le disait —
    l'administrateur repartait en croyant sa page en ligne.

    POST uniquement : c'est un changement d'état visible du public, il n'a rien
    à faire derrière un lien qu'un préchargement peut déclencher.
    """

    permission_required = 'administration_pages.change_page'
    raise_exception = True

    def post(self, request, page_id):
        page = get_object_or_404(Page, pk=page_id)
        if not page.active and not page.langue_servie:
            # « En ligne » serait un mensonge : le site ne sert aucune page
            # d'une langue qui n'est pas activée.
            messages.error(request, _(
                "La langue de cette version n'est plus activée pour le site : "
                "elle ne serait servie à aucune adresse. Réactivez la langue "
                "dans Réglages › Langues du site, puis publiez."
            ))
            return redirect(destination_sure(
                request, request.POST.get('next'),
                'jeiko_administration_pages:main',
            ))
        page.active = not page.active
        page.save(update_fields=['active'])

        if page.active:
            messages.success(
                request,
                _("« %(title)s » est en ligne : les visiteurs y ont accès.") % {"title": page.title}
            )
        else:
            messages.success(
                request,
                _("« %(title)s » est repassée en brouillon : elle n'est plus visible du public.") % {"title": page.title}
            )
            # Une page dépubliée disparaît aussi des menus qui la référencent.
            # Sans ce signalement, l'administrateur casse une entrée de sa
            # propre navigation sans le savoir : rien, sur cet écran, ne dit
            # que la page était utilisée ailleurs.
            from .publication import unpublish_warning

            avertissement = unpublish_warning(page)
            if avertissement:
                messages.warning(request, avertissement)

        # On revient d'où l'on vient (liste, éditeur, fiche), sans jamais suivre
        # une destination fournie par l'extérieur.
        # Le test maison qui vivait ici — `startswith('/')` et pas `'//'` —
        # laissait passer `/\\site-piege.example` : le navigateur traite la
        # barre inverse comme une barre à cet endroit. Voir jeiko/redirections.py.
        return redirect(destination_sure(
            request, request.POST.get('next'),
            'jeiko_administration_pages:main',
        ))


# --------------------------------------------------------------------------- #
#  Redirections (Q-20) — voir models.Redirection
# --------------------------------------------------------------------------- #
class AdresseChangee(LoginRequiredMixin, PermissionRequiredMixin, View):
    """Après un renommage : garder l'ancienne adresse comme redirection, ou non."""
    template_name = 'administration_pages/adresse_changee.html'
    permission_required = 'administration_pages.change_page'
    raise_exception = True

    def _donnees(self, request, page_id):
        donnees = request.session.get(SESSION_ADRESSE_CHANGEE) or {}
        if donnees.get("page") != page_id:
            return None
        return donnees

    @method_decorator(never_cache)
    def get(self, request, page_id):
        page = get_object_or_404(Page, pk=page_id)
        donnees = self._donnees(request, page_id)
        if donnees is None:
            return redirect('jeiko_administration_pages:main')
        return render(request, self.template_name, {
            "page": page, "ancienne": donnees["ancienne"], "nouvelle": page.get_absolute_url()})

    @method_decorator(never_cache)
    def post(self, request, page_id):
        from .models import Redirection

        page = get_object_or_404(Page, pk=page_id)
        donnees = self._donnees(request, page_id)
        request.session.pop(SESSION_ADRESSE_CHANGEE, None)
        if donnees and request.POST.get("garder") == "oui" and donnees["ancienne"] != page.get_absolute_url():
            Redirection.objects.update_or_create(adresse=donnees["ancienne"], defaults={"page": page})
            messages.success(request, _("L'ancienne adresse %(adresse)s mène désormais à cette page.")
                             % {"adresse": donnees["ancienne"]})
        return redirect('jeiko_administration_pages:main')


class ListeDesRedirections(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/redirections.html'
    permission_required = 'administration_pages.view_page'
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request):
        from .models import Redirection

        from jeiko.listes import paginer

        # D-03 : chaque changement d'adresse en ajoute une ; un site qui vit
        # en accumule des centaines.
        redirections, pagination = paginer(
            request, Redirection.objects.select_related("page").order_by("page__title", "-creee_le"))
        return render(request, self.template_name, {**pagination, "redirections": redirections})


class SupprimerUneRedirection(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = 'administration_pages.change_page'
    raise_exception = True

    def post(self, request, pk):
        from .models import Redirection

        get_object_or_404(Redirection, pk=pk).delete()
        messages.success(request, _("Redirection supprimée."))
        return redirect('jeiko_administration_pages:redirections')



class PagesDErreur(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Pages › Pages d'erreur : la page à montrer pour une adresse introuvable
    (404) et pour un accès refusé (403) — voir pages_erreur.py (A-10).
    """
    template_name = 'administration_pages/pages_erreur.html'
    permission_required = 'administration_pages.view_page'
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request):
        from jeiko.administration.models import WebSite

        from .pages_erreur import CODES, pages_possibles

        site = WebSite.objects.first()
        titres = {
            404: _("Adresse introuvable (404)"),
            403: _("Accès refusé (403) — un visiteur non connecté y trouve de quoi se connecter"),
            500: _("Erreur du serveur (500) — servie depuis une copie, mise à jour dans les 5 minutes"),
            400: _("Requête invalide (400)"),
        }
        return render(request, self.template_name, {
            "pages": pages_possibles(),
            "choix": [{"code": c, "titre": titres[c], "page_id": getattr(site, f"page_{c}_id", None)}
                      for c in CODES],
        })

    def post(self, request):
        from jeiko.administration.models import WebSite

        from .pages_erreur import CODES, ecrire_la_page_500_sans_lever, pages_possibles

        if not request.user.has_perm('administration_pages.change_page'):
            raise PermissionDenied
        site = WebSite.objects.first()
        possibles = pages_possibles()
        for code in CODES:
            valeur = request.POST.get(f"page_{code}") or None
            page = possibles.filter(pk=valeur).first() if valeur and valeur.isdigit() else None
            setattr(site, f"page_{code}", page)
        site.save(update_fields=[f"page_{code}" for code in CODES])
        transaction.on_commit(ecrire_la_page_500_sans_lever)
        messages.success(request, _("Pages d'erreur enregistrées."))
        return redirect('jeiko_administration_pages:pages_erreur')
