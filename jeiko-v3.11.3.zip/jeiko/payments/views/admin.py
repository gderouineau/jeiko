from django.views.generic import ListView, UpdateView, CreateView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from ..models import PaymentGateway
from ..forms import PaymentGatewayForm


# Ces écrans exposent les clés Stripe du site. Ils ne portaient que
# LoginRequiredMixin : tout compte connecté — un simple client inscrit — y
# accédait. On revient à la convention du reste de l'administration
# (PermissionRequiredMixin + raise_exception), qui passe par les rôles.

class PaymentGatewayListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = PaymentGateway
    template_name = 'payments/admin/gateway_list.html'
    context_object_name = 'gateways'

    permission_required = 'payments.view_paymentgateway'
    raise_exception = True


class PaymentGatewayUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = PaymentGateway
    form_class = PaymentGatewayForm
    template_name = 'payments/admin/gateway_form.html'
    success_url = reverse_lazy('jeiko_payments_admin:gateway_list')

    permission_required = 'payments.change_paymentgateway'
    raise_exception = True

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['update'] = True
        if self.object.code == 'stripe':
            from .. import branchement
            context['branchement'] = {
                'verifications': branchement.verifications(self.object),
                'adresse': branchement.adresse_du_webhook(self.request),
                'evenements': branchement.EVENEMENTS,
                'version': branchement.VERSION_DE_L_API,
                'documentation': branchement.DOCUMENTATION,
            }
        return context


class PaymentGatewayCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = PaymentGateway
    form_class = PaymentGatewayForm
    template_name = 'payments/admin/gateway_form.html'
    success_url = reverse_lazy('jeiko_payments_admin:gateway_list')

    permission_required = 'payments.add_paymentgateway'
    raise_exception = True
