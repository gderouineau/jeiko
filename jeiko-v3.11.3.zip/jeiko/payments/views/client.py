from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import transaction
from django.views.generic import TemplateView, View
from django.http import JsonResponse, HttpResponse, HttpResponseRedirect
from django.contrib import messages
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from ..services.stripe import StripeService
from ..verification import ecart_de_paiement, signaler_paiement_non_conforme
from jeiko.shop.livraison import panier_a_expedier
from jeiko.shop.models import Order, ShopSettings
from jeiko.shop.services import (
    CHAMPS_ADRESSE, CommandeImpossible, compute_order_totals, mark_order_paid,
    preparer_commande,
)
from ..forms import CoordonneesForm
from jeiko.shop.views.client import get_or_create_cart
from jeiko.shop.views.client import BoutiqueEnLigneRequiredMixin
import json
import logging
import stripe
from secrets import compare_digest
from django.utils.translation import gettext_lazy as _

logger = logging.getLogger(__name__)


class CheckoutView(BoutiqueEnLigneRequiredMixin, View):
    """
    Entrée du tunnel de paiement : les coordonnées, puis le paiement.

    Une commande exige un compte. Sans lui, `shop.services._grant_access` n'a
    personne à qui ouvrir une formation ou un questionnaire : le paiement était
    encaissé, la commande passait en payée, le stock était décrémenté, et rien
    n'était délivré — sans erreur ni message.

    Le panier, lui, reste accessible en anonyme : c'est seulement au moment de
    commander qu'on demande un compte. Un visiteur sans compte le crée ICI, en
    donnant un e-mail et un mot de passe à côté de ses coordonnées
    (`users/compte_acheteur.py`) ; un client existant se connecte, et revient.
    Le panier constitué avant la connexion est repris par `shop.signals`.

    Cet écran demande les adresses : la facturation toujours, la livraison
    pour un panier qui contient un article à expédier — c'est elle qui fixe
    les frais de port. Il pré-remplit avec la commande en cours, sinon la
    dernière commande du compte.
    """

    template_name = 'payments/client/checkout.html'

    def _contexte(self, request, cart, items, form):
        total_ht, total_tva, total_ttc = compute_order_totals(items)
        return {
            'cart': cart, 'items': items, 'form': form,
            'total_ttc': total_ttc,
            'expedition': form.expedition,
            'shop_currency': ShopSettings.get_solo().currency,
        }

    def _initial(self, request, cart):
        if not request.user.is_authenticated:
            return {"billing_country": "FR"}
        source = (
            Order.objects.filter(cart=cart).exclude(billing_name="").first()
            or Order.objects.filter(user=request.user).exclude(billing_name="")
            .order_by("-created_at").first()
        )
        if source is None:
            nom = (request.user.get_full_name() or "").strip()
            return {"billing_name": nom, "billing_country": "FR"}
        initial = {champ: getattr(source, champ) for champ in CHAMPS_ADRESSE}
        if source.cart_id != cart.pk:
            initial["customer_note"] = ""
        initial["ship_elsewhere"] = bool(source.shipping_name) and (
            source.shipping_block != source.billing_block
        )
        return initial

    def get(self, request):
        cart = get_or_create_cart(request)
        items = list(cart.items.select_related("product", "product__type"))
        if not items:
            return redirect('jeiko_client_shop:cart_detail')
        form = CoordonneesForm(initial=self._initial(request, cart),
                               expedition=panier_a_expedier(items),
                               avec_compte=not request.user.is_authenticated)
        return render(request, self.template_name, self._contexte(request, cart, items, form))

    def post(self, request):
        cart = get_or_create_cart(request)
        items = list(cart.items.select_related("product", "product__type"))
        if not items:
            return redirect('jeiko_client_shop:cart_detail')
        anonyme = not request.user.is_authenticated
        form = CoordonneesForm(request.POST, expedition=panier_a_expedier(items),
                               avec_compte=anonyme)
        if form.is_valid() and anonyme:
            from jeiko.users.compte_acheteur import creer_et_connecter
            from jeiko.users.throttling import check_signup

            refus = check_signup(request, request.POST)
            if refus:
                form.add_error(None, refus)
            else:
                creer_et_connecter(request, form.cleaned_data["email"],
                                   form.cleaned_data["password"],
                                   form.cleaned_data["billing_name"])
                # Le panier anonyme est devenu celui du compte.
                cart = get_or_create_cart(request)
        if form.is_valid() and not form.non_field_errors():
            try:
                preparer_commande(request.user, cart, form.cleaned_data)
            except CommandeImpossible as exc:
                form.add_error(None, str(exc))
            else:
                return redirect('jeiko_payments_client:payment')
        return render(request, self.template_name, self._contexte(request, cart, items, form))


class PaymentStepView(BoutiqueEnLigneRequiredMixin, LoginRequiredMixin, View):
    """
    Le récapitulatif — articles, port, total — et le formulaire Stripe.

    La commande est préparée de nouveau ici : un prix ou un stock a pu bouger
    depuis l'écran des coordonnées, et ce qui s'affiche doit être ce que
    l'intention de paiement demandera.
    """

    template_name = 'payments/client/payment.html'

    def get(self, request):
        cart = get_or_create_cart(request)
        order = Order.objects.filter(cart=cart, user=request.user).first()
        if order is None or not order.billing_name:
            return redirect('jeiko_payments_client:checkout')
        try:
            order = preparer_commande(request.user, cart)
        except CommandeImpossible as exc:
            messages.error(request, str(exc))
            return redirect('jeiko_client_shop:cart_detail')

        lines = list(order.lines.select_related('product', 'variant'))
        # Un abonnement se paie sur la page de Stripe (shop/abonnements.py) :
        # pas de formulaire de carte ici, un bouton qui y mène.
        ligne = next((l for l in lines if l.product and l.product.intervalle(l.variant)), None)
        if ligne is not None:
            from jeiko.shop.abonnements import essai_offert

            return render(request, self.template_name, {
                'order': order, 'lines': lines,
                'abonnement': ligne.product.intervalle(ligne.variant),
                'essai': essai_offert(request.user, ligne.product),
            })
        # Rien à payer : pas de formulaire de carte (Stripe refuse un montant
        # nul), un bouton qui valide la commande (CommandeGratuiteView).
        if order.total_ttc == 0:
            return render(request, self.template_name, {'order': order, 'lines': lines, 'gratuit': True})
        stripe_service = StripeService()
        return render(request, self.template_name, {
            'order': order,
            'lines': lines,
            'stripe_public_key': stripe_service.gateway.api_key if stripe_service.gateway else "",
        })


class CommandeGratuiteView(BoutiqueEnLigneRequiredMixin, LoginRequiredMixin, View):
    """
    Valide une commande à 0 € — l'essai gratuit d'une licence de jeiko.fr, un
    produit offert — sans passer par Stripe, qui refuse un montant nul.

    Rien n'est cru du navigateur : la commande est recalculée par
    `preparer_commande`, et seule une commande dont le total VAUT zéro, sans
    abonnement, est réglée. Une licence gratuite ne s'obtient qu'une fois par
    compte (`licences.boutique.essai_refuse`). Le règlement passe par
    `mark_order_paid`, comme un paiement : accès, licences, facture et
    e-mails suivent le même chemin.
    """

    @transaction.atomic
    def post(self, request):
        cart = get_or_create_cart(request)
        if not Order.objects.filter(cart=cart, user=request.user).exclude(billing_name="").exists():
            return redirect('jeiko_payments_client:checkout')
        try:
            order = preparer_commande(request.user, cart)
        except CommandeImpossible as exc:
            messages.error(request, str(exc))
            return redirect('jeiko_client_shop:cart_detail')
        lines = list(order.lines.select_related('product', 'variant'))
        if order.total_ttc != 0 or any(l.product and l.product.intervalle(l.variant) for l in lines):
            return redirect('jeiko_payments_client:payment')

        from jeiko.licences.boutique import essai_refuse

        refus = essai_refuse(request.user, lines, order)
        if refus:
            messages.error(request, refus)
            return redirect('jeiko_client_shop:cart_detail')
        mark_order_paid(order, source="gratuit")
        return redirect('jeiko_payments_client:merci', pk=order.pk)


class AbonnementView(BoutiqueEnLigneRequiredMixin, LoginRequiredMixin, View):
    """Part sur la page de paiement Stripe d'un abonnement (Checkout)."""

    def post(self, request):
        from jeiko.shop.abonnements import ouvrir_la_session

        cart = get_or_create_cart(request)
        if not Order.objects.filter(cart=cart, user=request.user).exclude(billing_name="").exists():
            return redirect('jeiko_payments_client:checkout')
        try:
            order = preparer_commande(request.user, cart)
            if not any(l.product and l.product.intervalle(l.variant) for l in order.lines.select_related('product', 'variant')):
                return redirect('jeiko_payments_client:payment')
            return HttpResponseRedirect(ouvrir_la_session(request, order))
        except CommandeImpossible as exc:
            messages.error(request, str(exc))
            return redirect('jeiko_client_shop:cart_detail')
        except Exception:
            logger.exception("Page de paiement d'abonnement impossible")
            messages.error(request, _("Le paiement n'a pas pu être initialisé."))
            return redirect('jeiko_payments_client:payment')


class AbonnementRetourView(LoginRequiredMixin, View):
    """
    Retour de Stripe après la souscription. Le webhook fait foi ; ce retour
    synchronise tout de suite pour que le client trouve sa licence en
    arrivant — et seulement pour SA commande.
    """

    def get(self, request):
        from jeiko.shop import abonnements

        session_id = request.GET.get('session_id') or ''
        try:
            abonnements._stripe()
            session = stripe.checkout.Session.retrieve(session_id)
            commande = str(session.get('client_reference_id') or '')
            if not (commande.isdigit() and Order.objects.filter(pk=commande, user=request.user).exists()):
                logger.warning("Retour d'abonnement %s refusé (compte %s).", session_id, request.user.pk)
                return redirect('jeiko_client_shop:cart_detail')
            if session.get('status') == 'complete' and session.get('subscription'):
                abonnements.synchroniser(abonnements._id(session['subscription']))
                if session.get('invoice'):
                    abonnements.enregistrer_le_paiement(stripe.Invoice.retrieve(abonnements._id(session['invoice'])))
            # La page « Merci » : le webhook a pu ne pas encore passer, elle le dit.
            return redirect('jeiko_payments_client:merci', pk=int(commande))
        except Exception:
            # Le webhook rattrapera : le client voit son compte, sans erreur.
            logger.exception("Retour d'abonnement %s non synchronisé", session_id)
        return HttpResponseRedirect(reverse('jeiko_users_client:profile-detail') + '#licences')


class PortailAbonnementView(LoginRequiredMixin, View):
    """Le portail Stripe du client : carte, factures, résiliation."""

    def post(self, request):
        from jeiko.shop.abonnements import adresse_du_portail

        retour = request.build_absolute_uri(reverse('jeiko_users_client:profile-detail')) + '#licences'
        try:
            adresse = adresse_du_portail(request.user, retour)
        except Exception:
            logger.exception("Portail d'abonnement impossible (compte %s)", request.user.pk)
            adresse = None
        if not adresse:
            messages.error(request, _("La gestion de l'abonnement n'est pas disponible pour le moment."))
            return HttpResponseRedirect(retour)
        return HttpResponseRedirect(adresse)


class CreatePaymentIntentView(BoutiqueEnLigneRequiredMixin, LoginRequiredMixin, View):
    """
    Création de l'intention de paiement.

    Gardée comme `CheckoutView` : sans cela, l'exigence de compte se contournerait
    en appelant directement ce point d'entrée. Le montant vient de
    `preparer_commande`, seul juge de ce que coûte le panier.
    """

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        cart = get_or_create_cart(request)
        if not Order.objects.filter(cart=cart).exclude(billing_name="").exists():
            return JsonResponse({'error': _('Renseignez d’abord vos coordonnées.')}, status=400)
        try:
            order = preparer_commande(request.user, cart)
        except CommandeImpossible as exc:
            return JsonResponse({'error': str(exc)}, status=409)
        # Un abonnement réglé ici en paiement unique serait payé sans qu'aucun
        # abonnement ni aucune licence n'existe : il passe par Stripe Checkout.
        if any(l.product and l.product.intervalle(l.variant) for l in order.lines.select_related('product', 'variant')):
            return JsonResponse({'error': _("Un abonnement se règle sur la page de paiement de Stripe.")}, status=409)

        try:
            stripe_service = StripeService()
            # L'intention précédente, créée pour une autre version de la
            # commande, ne doit plus pouvoir être réglée (Fable 1, §1.4).
            if order.payment_intent_id:
                stripe_service.cancel_payment_intent(order.payment_intent_id)
            intent = stripe_service.create_payment_intent(
                amount=order.total_ttc,
                # La commande garde sa devise ; le réglage du site a pu changer.
                currency=order.currency.lower(),
                metadata={'order_id': order.pk}
            )
        except Exception:
            # str(e) renvoyait au navigateur le message brut de l'exception —
            # y compris les erreurs de configuration Stripe.
            logger.exception("Échec de création du PaymentIntent")
            return JsonResponse(
                {'error': _("Le paiement n'a pas pu être initialisé.")}, status=400
            )
        order.payment_intent_id = intent['id']
        order.save(update_fields=['payment_intent_id'])
        return JsonResponse({
            'clientSecret': intent['client_secret'],
            'amount': f"{order.total_ttc:.2f}",
            'currency': order.currency,
        })


@method_decorator(csrf_exempt, name='dispatch')
class StripeWebhookView(View):
    def post(self, request, *args, **kwargs):
        payload = request.body
        sig_header = request.META.get('HTTP_STRIPE_SIGNATURE')
        
        stripe_service = StripeService()
        
        # STRIPE-01 : l'écran de la passerelle dit si Stripe appelle le site et
        # si la signature passe. `update()` : ni `save()` ni `clean()` pour
        # une trace, et aucune course avec une modification du formulaire.
        from django.utils import timezone

        from ..models import PaymentGateway
        passerelle = PaymentGateway.objects.filter(code="stripe")
        try:
            event = stripe_service.construct_event(payload, sig_header)
        except Exception as e:
            if sig_header:
                passerelle.update(dernier_refus_le=timezone.now())
            return HttpResponse(status=400)
        passerelle.update(dernier_evenement_le=timezone.now(),
                          dernier_evenement_type=str(event.get("type") or "")[:100],
                          dernier_evenement_version=str(event.get("api_version") or "")[:40])

        # Handle the event using the Dispatcher
        from ..webhooks.stripe import StripeWebhookDispatcher
        dispatcher = StripeWebhookDispatcher()
        dispatcher.dispatch(event)
        
        return HttpResponse(status=200)


class PaymentCheckView(LoginRequiredMixin, View):
    """
    Retour du navigateur après le passage sur Stripe (S-14).

    Cette adresse ne recevait aucun contrôle : elle acceptait n'importe quel
    `payment_intent`, d'un visiteur anonyme, et réglait la commande désignée par
    les métadonnées de l'intention — celle d'un autre client comprise.

    Trois gardes, dont deux manquaient :

    * **le compte** — le tunnel entier exige déjà d'être connecté
      (`CheckoutView`, `CreatePaymentIntentView`), cette porte-là restait
      ouverte ;
    * **le `client_secret`** — Stripe le renvoie dans l'URL précisément pour
      qu'on le confronte à celui de l'intention. Sans cette vérification,
      connaître un identifiant `pi_…` suffisait ; or il n'est pas secret, il
      traverse les journaux de serveur, les référents et l'historique du
      navigateur ;
    * **le propriétaire** — la commande doit être celle du visiteur.

    Ce que cela ne corrige pas : rien ici n'est le chemin fiable. Le client peut
    fermer son onglet avant le retour, c'est le webhook qui fait foi
    (`StripeWebhookView`), et `payments.reconcile` rattrape le reste.
    `mark_order_paid` est idempotent : celui des trois qui arrive en second ne
    fait rien.
    """

    def get(self, request, *args, **kwargs):
        payment_intent_id = request.GET.get('payment_intent')
        secret_recu = request.GET.get('payment_intent_client_secret') or ''

        if not payment_intent_id:
             return redirect('jeiko_payments_client:checkout')

        stripe_service = StripeService()
        try:
            # Ensure secret key is set
            stripe.api_key = stripe_service.gateway.secret_key

            # Retrieve the PaymentIntent from Stripe
            intent = stripe.PaymentIntent.retrieve(payment_intent_id)

            # Comparaison à temps constant : on compare bien un secret.
            if not compare_digest(str(intent.get('client_secret') or ''), secret_recu):
                logger.warning(
                    "Retour de paiement %s refusé : client_secret absent ou "
                    "incorrect (compte %s).", payment_intent_id, request.user.pk,
                )
                return redirect('jeiko_payments_client:checkout')

            if intent.status == 'succeeded':
                order_id = intent.metadata.get('order_id')
                if order_id:
                    order = Order.objects.filter(
                        pk=order_id, user=request.user
                    ).first()
                    if order is None:
                        logger.warning(
                            "Retour de paiement %s : commande %s inconnue ou "
                            "étrangère au compte %s.",
                            payment_intent_id, order_id, request.user.pk,
                        )
                        return redirect('jeiko_payments_client:checkout')

                    ecart = ecart_de_paiement(order, intent)
                    if ecart and order.payment_status != Order.PAYMENT_STATUS_PAID:
                        signaler_paiement_non_conforme(order, intent, ecart, "stripe:return")
                        return redirect('jeiko_payments_client:checkout')

                    # Même traitement que le webhook, et idempotent : celui
                    # des deux qui arrive en second ne fait rien.
                    mark_order_paid(order, source="stripe:return")

                    # La page « Merci » dit ce qui suit (licence, formation…).
                    return redirect('jeiko_payments_client:merci', pk=order.pk)

            # If not succeeded or other issue
            return redirect('jeiko_payments_client:checkout')

        except Exception:
            logger.exception("Échec de la vérification du paiement %s", payment_intent_id)
            return redirect('jeiko_payments_client:checkout')

class CommandeConfirmeeView(LoginRequiredMixin, View):
    """
    « Merci, c'est fait » — la page où l'on arrive après un paiement réussi.

    Un client de jeiko.fr (12/10/2026) : sans page d'arrivée, « on ne sait
    pas » si l'achat est passé ni où trouver sa clé. Le retour de paiement
    renvoyait vers le détail de la commande, sans un mot sur la suite. Cette
    page le dit, selon ce qui a été acheté : la licence (partie par e-mail,
    à relier à son site), la formation ouverte, les crédits ajoutés, le colis
    à venir. Seulement pour le titulaire de la commande.

    Ce qu'elle ne fait pas : confirmer le paiement. Le retour de Stripe et
    le webhook le font ; si aucun n'est encore passé, elle dit « en cours ».
    """

    template_name = 'payments/client/merci.html'

    def get(self, request, pk):
        from django.shortcuts import get_object_or_404

        order = get_object_or_404(Order, pk=pk, user=request.user)
        lignes = list(order.lines.select_related("product", "product__type", "product__linked_course"))
        produits = [l.product for l in lignes if l.product]
        suite = {
            "licence": any(getattr(p, "licence_jeiko", False) for p in produits),
            "formations": [p.linked_course for p in produits if p.linked_course_id],
            "credits": sum((l.product.credits_amount or 0) * (l.quantity or 1) for l in lignes
                           if l.product and l.product.credits_amount > 0),
            "colis": any(getattr(p.type, "requires_shipping", False) for p in produits if p.type_id),
        }
        return render(request, self.template_name, {
            "order": order, "lignes": lignes, "suite": suite,
            "payee": order.payment_status == Order.PAYMENT_STATUS_PAID,
        })


class PaymentSuccessView(TemplateView):
    template_name = 'payments/client/success.html'

class PaymentCancelView(TemplateView):
    template_name = 'payments/client/cancel.html'
