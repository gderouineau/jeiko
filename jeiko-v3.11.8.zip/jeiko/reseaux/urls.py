from django.urls import path

from . import views

app_name = "jeiko_reseaux"

urlpatterns = [
    path("", views.ComptesRelies.as_view(), name="comptes"),
    path("<int:pk>/delier/", views.DelierUnCompte.as_view(), name="delier"),
    path("journal/", views.JournalDesPublications.as_view(), name="journal"),
]
