"""
Le relais côté HTTP : l'API des sites, le passage de l'exploitant chez Meta,
les rappels de Meta, et les écrans de Guillaume. Tout répond 404 tant que
`JEIKO_RELAIS_RESEAUX` n'est pas allumé dans le .env.
"""
import json
import secrets

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.http import Http404, HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import ListView

from jeiko import throttling
from jeiko.administration.models import CompteReseau, PublicationReseau
from jeiko.listes import ListeRechercheeEtPaginee

from . import meta, service


class _Allume:
    def dispatch(self, request, *args, **kwargs):
        if not service.relais_allume():
            raise Http404
        return super().dispatch(request, *args, **kwargs)


# --- API des sites -------------------------------------------------------------


@method_decorator(csrf_exempt, name="dispatch")
class _Api(View):
    """
    Authentifiée par la clé de licence du site : `Authorization: Bearer <clé>`.
    Réponses JSON, jamais de page HTML — l'appelant est un programme.
    """

    TAILLE_MAX = 64 * 1024

    def dispatch(self, request, *args, **kwargs):
        if not service.relais_allume():
            raise Http404
        if throttling.rate_limited(request, "reseaux_api", 120, 60):
            return JsonResponse({"erreur": "trop de demandes"}, status=429)
        if len(request.body) > self.TAILLE_MAX:
            return JsonResponse({"erreur": "corps trop long"}, status=413)
        entete = request.headers.get("Authorization", "")
        try:
            self.licence = service.licence_de_la_cle(entete[7:] if entete.startswith("Bearer ") else "")
            if request.method == "POST":
                self.corps = json.loads(request.body or b"{}")
                if not isinstance(self.corps, dict):
                    raise ValueError
        except service.Refus as refus:
            return JsonResponse({"erreur": str(refus)}, status=403)
        except (ValueError, UnicodeDecodeError):
            return JsonResponse({"erreur": "objet JSON attendu"}, status=400)
        try:
            return super().dispatch(request, *args, **kwargs)
        except service.Refus as refus:
            return JsonResponse({"erreur": str(refus)}, status=400)


class ApiConnexion(_Api):
    """POST {retour} → {adresse} : où envoyer l'exploitant pour relier ses comptes."""

    def post(self, request):
        jeton = service.lien_de_connexion(self.licence, self.corps.get("retour"))
        adresse = request.build_absolute_uri(reverse("reseaux_connecter")) + "?j=" + jeton
        return JsonResponse({"adresse": adresse})


class ApiComptes(_Api):
    def get(self, request):
        return JsonResponse({"comptes": [service.compte_en_json(c) for c in self.licence.comptes_reseaux.all()]})


class ApiDelier(_Api):
    def post(self, request, pk):
        service.delier(get_object_or_404(CompteReseau, pk=pk, licence=self.licence))
        return JsonResponse({"ok": True})


class ApiPublier(_Api):
    """POST {comptes: [id…], texte, images: [adresse…], lien, quand} → {publications}."""

    def post(self, request):
        c = self.corps
        publications = service.programmer(self.licence, comptes=c.get("comptes"), texte=c.get("texte", ""),
                                          images=c.get("images"), lien=c.get("lien", ""), quand=c.get("quand"))
        for p in publications:
            p.refresh_from_db()
        return JsonResponse({"publications": [service.publication_en_json(p) for p in publications]})


class ApiJournal(_Api):
    """GET ?etat=…&limite=… → les publications, les plus récentes d'abord (200 au plus)."""

    def get(self, request):
        qs = self.licence.publications_reseaux.all()
        if request.GET.get("etat") in dict(PublicationReseau.ETATS):
            qs = qs.filter(etat=request.GET["etat"])
        try:
            limite = min(max(int(request.GET.get("limite", 50)), 1), 200)
        except ValueError:
            limite = 50
        return JsonResponse({"publications": [service.publication_en_json(p) for p in qs[:limite]]})


class ApiAnnuler(_Api):
    def post(self, request, pk):
        if not service.annuler(get_object_or_404(PublicationReseau, pk=pk, licence=self.licence)):
            return JsonResponse({"erreur": _("Seule une publication programmée s'annule.")}, status=409)
        return JsonResponse({"ok": True})


# --- Le passage de l'exploitant : site → jeiko.fr → Meta → jeiko.fr → site ---


def _adresse_de_retour_meta(request):
    """À déclarer telle quelle dans l'application Meta (« URI de redirection OAuth valides »)."""
    return request.build_absolute_uri(reverse("reseaux_retour"))


@method_decorator(never_cache, name="dispatch")
class Connecter(_Allume, View):
    def get(self, request):
        try:
            licence, retour = service.lire_le_lien(request.GET.get("j"))
        except service.Refus as refus:
            return HttpResponse(str(refus), status=400, content_type="text/plain; charset=utf-8")
        etat = service.etat_pour_meta(request.session, licence, retour)
        return HttpResponseRedirect(meta.adresse_du_dialogue(_adresse_de_retour_meta(request), etat))


@method_decorator(never_cache, name="dispatch")
class Retour(_Allume, View):
    def get(self, request):
        try:
            licence, retour = service.connexion_en_cours(request.session, request.GET.get("state"))
        except service.Refus as refus:
            return HttpResponse(str(refus), status=400, content_type="text/plain; charset=utf-8")
        code = request.GET.get("code")
        if not code:
            # Refusé ou abandonné chez Meta (`error=access_denied`).
            return HttpResponseRedirect(service.avec_parametres(retour, reseaux="annule"))
        try:
            nombre = service.relier(licence, code, _adresse_de_retour_meta(request))
        except meta.ErreurMeta:
            return HttpResponseRedirect(service.avec_parametres(retour, reseaux="erreur"))
        return HttpResponseRedirect(service.avec_parametres(retour, reseaux="ok", comptes=nombre))


# --- Ce que Meta nous envoie ---------------------------------------------------


@method_decorator(csrf_exempt, name="dispatch")
class RetraitMeta(_Allume, View):
    """
    Les deux rappels que Meta demande de déclarer : « Deauthorize » (la
    personne retire l'application) et « Data deletion » (elle demande
    l'effacement). Dans les deux cas, ses jetons sont oubliés aussitôt ;
    l'effacement répond en plus ce que Meta attend.
    """

    def post(self, request):
        donnees = meta.lire_signed_request(request.POST.get("signed_request"))
        if donnees is None:
            return JsonResponse({"erreur": "signature invalide"}, status=400)
        service.oublier_l_utilisateur(donnees.get("user_id"))
        code = secrets.token_hex(8)
        return JsonResponse({"url": request.build_absolute_uri(reverse("reseaux_effacement")) + "?code=" + code,
                             "confirmation_code": code})


class Effacement(_Allume, View):
    """Ce que Meta montre à la personne : l'effacement est immédiat, il n'y a rien à suivre."""

    def get(self, request):
        return HttpResponse(_("Les jetons de connexion liés à cette demande ont été supprimés de jeiko.fr."),
                            content_type="text/plain; charset=utf-8")


# --- Écrans de Guillaume -------------------------------------------------------


class _Acces(_Allume, LoginRequiredMixin, UserPassesTestMixin):
    """Super-administrateurs seulement, comme les licences."""

    raise_exception = True

    def test_func(self):
        return self.request.user.is_superuser


@method_decorator(never_cache, name="dispatch")
class ComptesRelies(_Acces, ListeRechercheeEtPaginee, ListView):
    template_name = "reseaux/admin/comptes.html"
    context_object_name = "comptes"
    champs_de_recherche = ("nom", "licence__titulaire", "licence__domaine")

    def get_queryset(self):
        return self.rechercher(CompteReseau.objects.select_related("licence").order_by("licence__titulaire", "nom"))

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        contexte.update(
            meta_configure=service.meta_configure(),
            adresse_de_retour=_adresse_de_retour_meta(self.request),
            adresse_de_retrait=self.request.build_absolute_uri(reverse("reseaux_retrait_meta")),
        )
        return contexte


@method_decorator(never_cache, name="dispatch")
class DelierUnCompte(_Acces, View):
    def post(self, request, pk):
        service.delier(get_object_or_404(CompteReseau, pk=pk))
        messages.success(request, _("Compte délié : ses jetons sont oubliés."))
        return redirect("jeiko_reseaux:comptes")


@method_decorator(never_cache, name="dispatch")
class JournalDesPublications(_Acces, ListeRechercheeEtPaginee, ListView):
    template_name = "reseaux/admin/journal.html"
    context_object_name = "publications"
    champs_de_recherche = ("nom_du_compte", "texte", "erreur", "licence__domaine")

    def get_queryset(self):
        qs = PublicationReseau.objects.select_related("licence")
        if self.request.GET.get("etat") in dict(PublicationReseau.ETATS):
            qs = qs.filter(etat=self.request.GET["etat"])
        return self.rechercher(qs)

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        contexte["etats"] = PublicationReseau.ETATS
        contexte["etat"] = self.request.GET.get("etat", "")
        return contexte
