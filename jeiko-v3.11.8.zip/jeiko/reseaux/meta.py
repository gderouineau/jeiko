"""
Les appels à Meta (Graph API), et rien d'autre : pas de base, pas de décision.

Relevé dans la documentation de Meta le 27/10/2026 (Graph API v26.0) — à
revérifier quand Meta annonce la fin d'une version :
* connexion : dialogue `facebook.com/<version>/dialog/oauth`, code échangé
  côté serveur, puis jeton long (60 jours) par `fb_exchange_token` ;
* `/me/accounts` avec ce jeton long rend les jetons de PAGE, sans expiration ;
  le compte Instagram professionnel se lit sur sa page
  (`instagram_business_account`) et se publie avec le jeton de cette page ;
* Facebook : `/{page}/feed` (texte, lien), `/{page}/photos` (une image), ou
  des photos non publiées jointes au fil (`attached_media`) ;
* Instagram : un conteneur (`/{ig}/media`), son `status_code`, puis
  `/{ig}/media_publish`. JPEG seulement ; 100 publications par 24 h glissantes
  et PAR COMPTE Instagram (pas par application : mille sites, mille comptes,
  chacun ses 100) ; carrousel de 2 à 10 images ici (Meta en accepte 20) ;
* les jetons de page tombent sous les plafonds « Business Use Case » de
  Meta, comptés par page ou compte et proportionnels à son audience — pas
  sous un quota fixe de l'application. Seul YouTube (RES-06) a un quota
  partagé par tous les sites.

Changer de version, c'est changer `VERSION` : un seul endroit, sur jeiko.fr
seulement, sans attendre la mise à jour des sites.
"""
import base64
import hashlib
import hmac
import json

import requests
from django.conf import settings

VERSION = "v26.0"
GRAPH = f"https://graph.facebook.com/{VERSION}"
DIALOGUE = f"https://www.facebook.com/{VERSION}/dialog/oauth"
DELAI = 20

#: Demandées au dialogue quand aucune configuration « Facebook Login for
#: Business » n'est donnée (JEIKO_META_CONFIG_ID) : la configuration porte
#: alors elle-même la liste, à l'identique.
PERMISSIONS = (
    "pages_show_list", "pages_read_engagement", "pages_manage_posts",
    "instagram_basic", "instagram_content_publish", "business_management",
)

#: Codes d'erreur Meta qui veulent dire « jeton mort » : la personne a changé
#: son mot de passe, retiré l'application, perdu son rôle sur la page.
JETON_INVALIDE = {190, 102, 10, 200}


class ErreurMeta(Exception):
    def __init__(self, message, code=None):
        super().__init__(message)
        self.code = code

    @property
    def jeton_invalide(self):
        return self.code in JETON_INVALIDE


def identifiants():
    return (getattr(settings, "JEIKO_META_APP_ID", "") or "", getattr(settings, "JEIKO_META_APP_SECRET", "") or "")


def _appel(methode, chemin, **parametres):
    try:
        reponse = requests.request(methode, f"{GRAPH}/{chemin.lstrip('/')}",
                                   **{"params" if methode == "GET" else "data": parametres}, timeout=DELAI)
        corps = reponse.json()
    except (requests.RequestException, ValueError) as souci:
        raise ErreurMeta(f"Meta injoignable : {souci.__class__.__name__}") from souci
    if not isinstance(corps, dict):
        raise ErreurMeta("Réponse de Meta illisible.")
    if "error" in corps:
        erreur = corps["error"] if isinstance(corps["error"], dict) else {}
        raise ErreurMeta(str(erreur.get("message") or "Erreur Meta.")[:300], erreur.get("code"))
    return corps


def get(chemin, **p):
    return _appel("GET", chemin, **p)


def post(chemin, **p):
    return _appel("POST", chemin, **p)


def delete(chemin, **p):
    return _appel("DELETE", chemin, **p)


def adresse_du_dialogue(retour, etat):
    from urllib.parse import urlencode

    app_id, __ = identifiants()
    parametres = {"client_id": app_id, "redirect_uri": retour, "state": etat, "response_type": "code"}
    config = getattr(settings, "JEIKO_META_CONFIG_ID", "") or ""
    if config:
        parametres.update(config_id=config, override_default_response_type="true")
    else:
        parametres["scope"] = ",".join(PERMISSIONS)
    return f"{DIALOGUE}?{urlencode(parametres)}"


def jeton_long(code, retour):
    """Code du dialogue → jeton utilisateur long (60 jours)."""
    app_id, secret = identifiants()
    court = get("oauth/access_token", client_id=app_id, client_secret=secret, redirect_uri=retour, code=code)
    long = get("oauth/access_token", grant_type="fb_exchange_token", client_id=app_id, client_secret=secret,
               fb_exchange_token=court.get("access_token", ""))
    return long.get("access_token", "")


def comptes(jeton_utilisateur):
    """
    L'identifiant de la personne, et ses pages et comptes Instagram : une
    liste de dicts {reseau, id, nom, page_id, jeton}.
    """
    moi = get("me", fields="id", access_token=jeton_utilisateur)
    pages = get("me/accounts", fields="id,name,access_token,instagram_business_account{id,username}",
                limit=100, access_token=jeton_utilisateur)
    trouves = []
    for page in pages.get("data") or []:
        if not page.get("access_token"):
            continue
        trouves.append({"reseau": "facebook", "id": str(page["id"]), "nom": page.get("name", ""),
                        "page_id": str(page["id"]), "jeton": page["access_token"]})
        ig = page.get("instagram_business_account") or {}
        if ig.get("id"):
            trouves.append({"reseau": "instagram", "id": str(ig["id"]), "nom": ig.get("username", ""),
                            "page_id": str(page["id"]), "jeton": page["access_token"]})
    return str(moi.get("id", "")), trouves


def retirer_l_autorisation(utilisateur, jeton_utilisateur):
    delete(f"{utilisateur}/permissions", access_token=jeton_utilisateur)


def lire_signed_request(signed_request):
    """
    Le corps signé que Meta envoie quand une personne retire l'application
    ou demande la suppression de ses données. Rend le dict, ou None si la
    signature (HMAC-SHA256 par le secret de l'application) ne colle pas.
    """
    __, secret = identifiants()
    if not secret or not isinstance(signed_request, str) or signed_request.count(".") != 1:
        return None
    signature, charge = signed_request.split(".")

    def decoder(morceau):
        return base64.urlsafe_b64decode(morceau + "=" * (-len(morceau) % 4))

    try:
        attendue = hmac.new(secret.encode(), charge.encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(decoder(signature), attendue):
            return None
        donnees = json.loads(decoder(charge))
    except (ValueError, TypeError):
        return None
    return donnees if isinstance(donnees, dict) and donnees.get("algorithm") == "HMAC-SHA256" else None
