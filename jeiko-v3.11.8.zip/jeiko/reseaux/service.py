"""
Le relais : relier des comptes à une licence, publier, programmer, tenir le
journal. Les vues (`views.py`) ne font que traduire HTTP vers ces fonctions ;
les appels à Meta sont dans `meta.py`.
"""
import datetime
import secrets
import time
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from django.conf import settings
from django.core import signing
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from django.utils.dateparse import parse_datetime
from django.utils.translation import gettext as _

from jeiko.administration.models import CompteReseau, Licence, PublicationReseau
from jeiko.licences import cles
from jeiko.licences.service import domaine_canonique

from . import meta

SEL_DU_LIEN = "jeiko.reseaux.lien"
SEL_DE_L_ETAT = "jeiko.reseaux.etat"
#: Le lien que l'exploitant suit depuis son site vers jeiko.fr, puis le
#: passage chez Meta : assez pour se connecter, pas pour traîner.
DUREE_DU_LIEN = 15 * 60
DUREE_DE_L_ETAT = 30 * 60

IMAGES_MAX = 10
TEXTE_MAX = {CompteReseau.FACEBOOK: 63000, CompteReseau.INSTAGRAM: 2200}
PROGRAMMATION_MAX = datetime.timedelta(days=365)
#: Instagram lit l'image avant de publier : quelques secondes d'attente dans
#: la demande, puis la tâche des 5 minutes reprend ; au-delà, c'est un échec.
ATTENTES_DU_CONTENEUR = (2, 3, 5)
ABANDON_DU_CONTENEUR = datetime.timedelta(hours=1)
CONSERVATION_DU_JOURNAL = datetime.timedelta(days=365)


class Refus(Exception):
    """Une demande d'un site qui ne peut pas être servie : le message part au site."""


def relais_allume():
    return bool(getattr(settings, "JEIKO_RELAIS_RESEAUX", False))


def meta_configure():
    return all(meta.identifiants())


# --- La licence, seule pièce d'identité d'un site --------------------------


def licence_de_la_cle(cle):
    """La licence valide de cette clé, ou Refus. Même règle que les mises à jour, sans mode observation."""
    forme = cles.canonique(cle)
    licence = Licence.objects.filter(empreinte=cles.empreinte(forme)).first() if forme else None
    if licence is None:
        raise Refus(_("Clé de licence inconnue."))
    if not licence.valide:
        raise Refus(_("Licence désactivée ou expirée."))
    return licence


# --- Connexion ---------------------------------------------------------------


def _retour_valide(licence, retour):
    """L'adresse où renvoyer l'exploitant : https, sur le domaine de la licence, et nulle part ailleurs."""
    if not licence.domaine:
        raise Refus(_("Cette licence n'est encore liée à aucun site."))
    morceaux = urlsplit(retour if isinstance(retour, str) else "")
    if morceaux.scheme != "https" or len(retour) > 1000 or domaine_canonique(morceaux.hostname or "") != licence.domaine:
        raise Refus(_("L'adresse de retour doit être en https, sur le domaine de la licence."))
    return retour


def lien_de_connexion(licence, retour):
    """Le jeton signé à suivre chez jeiko.fr (`views.Connecter`). Signé, pas gardé : rien en base."""
    if not meta_configure():
        raise Refus(_("Le relais n'a pas encore d'application Meta."))
    return signing.dumps({"l": licence.pk, "r": _retour_valide(licence, retour)}, salt=SEL_DU_LIEN)


def lire_le_lien(jeton):
    """(licence, retour) d'un lien encore valide, ou Refus."""
    try:
        donnees = signing.loads(jeton or "", salt=SEL_DU_LIEN, max_age=DUREE_DU_LIEN)
        licence = Licence.objects.get(pk=donnees["l"])
    except (signing.BadSignature, Licence.DoesNotExist, KeyError, TypeError):
        raise Refus(_("Lien de connexion expiré : recommencez depuis votre site."))
    if not licence.valide:
        raise Refus(_("Licence désactivée ou expirée."))
    return licence, _retour_valide(licence, donnees.get("r"))


def etat_pour_meta(session, licence, retour):
    """
    Le `state` du dialogue Meta. La licence et l'adresse de retour restent en
    SESSION, avec un nombre tiré au sort que le `state` doit rapporter : un
    code obtenu par quelqu'un d'autre et rejoué dans ce navigateur ne relie
    rien (CSRF du retour OAuth).
    """
    nonce = secrets.token_urlsafe(24)
    session["jeiko_reseaux"] = {"n": nonce, "l": licence.pk, "r": retour}
    return signing.dumps({"n": nonce}, salt=SEL_DE_L_ETAT)


def connexion_en_cours(session, etat):
    """(licence, retour) de la connexion que ce navigateur a commencée, ou Refus. Ne sert qu'une fois."""
    attendu = session.pop("jeiko_reseaux", None) or {}
    try:
        donnees = signing.loads(etat or "", salt=SEL_DE_L_ETAT, max_age=DUREE_DE_L_ETAT)
        if not secrets.compare_digest(str(donnees.get("n", "")), str(attendu.get("n", ""))) or not attendu.get("n"):
            raise signing.BadSignature
        licence = Licence.objects.get(pk=attendu["l"])
    except (signing.BadSignature, Licence.DoesNotExist, KeyError, AttributeError):
        raise Refus(_("Connexion expirée : recommencez depuis votre site."))
    if not licence.valide:
        raise Refus(_("Licence désactivée ou expirée."))
    return licence, _retour_valide(licence, attendu.get("r"))


def avec_parametres(adresse, **parametres):
    morceaux = urlsplit(adresse)
    requete = parse_qsl(morceaux.query, keep_blank_values=True) + list(parametres.items())
    return urlunsplit(morceaux._replace(query=urlencode(requete)))


def relier(licence, code, adresse_de_retour_meta):
    """Le code rendu par Meta → les pages et comptes Instagram reliés à la licence. Rend leur nombre."""
    jeton_utilisateur = meta.jeton_long(code, adresse_de_retour_meta)
    utilisateur, trouves = meta.comptes(jeton_utilisateur)
    with transaction.atomic():
        for compte in trouves:
            CompteReseau.objects.update_or_create(
                licence=licence, reseau=compte["reseau"], id_externe=compte["id"],
                defaults={"nom": compte["nom"][:200], "page_id": compte["page_id"], "utilisateur_meta": utilisateur,
                          "jeton": compte["jeton"], "jeton_utilisateur": jeton_utilisateur,
                          "etat": CompteReseau.ACTIF, "derniere_erreur": "", "verifie_le": timezone.now()},
            )
    return len(trouves)


def delier(compte):
    """
    Oublie le compte et ses jetons. Si c'était le dernier compte relié par
    cette personne, sur toutes les licences, l'autorisation est aussi retirée
    chez Meta — au mieux : Meta injoignable n'empêche pas d'oublier.
    """
    utilisateur, jeton_utilisateur = compte.utilisateur_meta, compte.jeton_utilisateur
    compte.delete()
    if utilisateur and jeton_utilisateur and not CompteReseau.objects.filter(utilisateur_meta=utilisateur).exists():
        try:
            meta.retirer_l_autorisation(utilisateur, jeton_utilisateur)
        except meta.ErreurMeta:
            pass


def oublier_l_utilisateur(utilisateur):
    """Meta nous dit que la personne a retiré l'application, ou demande l'effacement : ses jetons partent."""
    return CompteReseau.objects.filter(utilisateur_meta=str(utilisateur)).delete()[0] if utilisateur else 0


# --- Publier -------------------------------------------------------------------


def _images_valides(licence, images):
    if images in (None, ""):
        return []
    if not isinstance(images, list) or len(images) > IMAGES_MAX:
        raise Refus(_("Au plus %(n)s images, en liste d'adresses.") % {"n": IMAGES_MAX})
    for adresse in images:
        morceaux = urlsplit(adresse if isinstance(adresse, str) else "")
        # Les images sont celles du site : Meta va les chercher chez lui. Le
        # relais ne sert pas à diffuser ce qui est hébergé ailleurs.
        if (morceaux.scheme != "https" or len(adresse) > 1000
                or domaine_canonique(morceaux.hostname or "") != licence.domaine):
            raise Refus(_("Chaque image : une adresse publique en https, sur le domaine du site."))
    return images


def _quand(valeur, maintenant):
    if valeur in (None, ""):
        return maintenant
    quand = parse_datetime(valeur) if isinstance(valeur, str) else None
    if quand is None or timezone.is_naive(quand):
        raise Refus(_("Date de programmation : ISO 8601 avec fuseau, par exemple 2026-11-02T09:30:00+01:00."))
    if quand > maintenant + PROGRAMMATION_MAX:
        raise Refus(_("Programmation à plus d'un an : refusée."))
    return max(quand, maintenant)


def programmer(licence, *, comptes, texte="", images=None, lien="", quand=None, maintenant=None):
    """
    Une publication par compte visé, publiée tout de suite (`quand` vide ou
    passé) ou à son heure par la tâche des 5 minutes. Tout est vérifié avant
    de rien créer : une demande refusée ne laisse aucune ligne.
    """
    maintenant = maintenant or timezone.now()
    texte = texte if isinstance(texte, str) else ""
    lien = lien if isinstance(lien, str) else ""
    images = _images_valides(licence, images)
    quand = _quand(quand, maintenant)
    if lien and (urlsplit(lien).scheme not in ("http", "https") or len(lien) > 1000):
        raise Refus(_("Lien invalide."))
    if not isinstance(comptes, list) or not comptes:
        raise Refus(_("Choisissez au moins un compte."))
    vises = list(CompteReseau.objects.filter(licence=licence, pk__in=[c for c in comptes if isinstance(c, int)]))
    if len(vises) != len(set(comptes)):
        raise Refus(_("Compte inconnu sur cette licence."))
    for compte in vises:
        if compte.etat != CompteReseau.ACTIF:
            raise Refus(_("%(nom)s est à reconnecter.") % {"nom": compte.nom})
        if len(texte) > TEXTE_MAX[compte.reseau]:
            raise Refus(_("Texte trop long pour %(reseau)s.") % {"reseau": compte.get_reseau_display()})
        if compte.reseau == CompteReseau.INSTAGRAM and not images:
            raise Refus(_("Instagram demande au moins une image (JPEG)."))
    if not (texte or images or lien):
        raise Refus(_("Rien à publier."))

    publications = [PublicationReseau.objects.create(
        licence=licence, compte=compte, reseau=compte.reseau, nom_du_compte=compte.nom,
        texte=texte, images=images, lien=lien, programmee_pour=quand,
    ) for compte in vises]
    for publication in publications:
        if publication.programmee_pour <= maintenant:
            executer(publication)
    return publications


def annuler(publication):
    """Seule une publication pas encore partie s'annule. Rend vrai si c'est fait."""
    return bool(PublicationReseau.objects.filter(pk=publication.pk, etat=PublicationReseau.PROGRAMMEE)
                .update(etat=PublicationReseau.ANNULEE))


def _prendre(publication):
    """
    Passe la publication en cours si personne ne l'a prise : la demande d'un
    site et la tâche des 5 minutes ne publient jamais deux fois la même.
    """
    return bool(PublicationReseau.objects.filter(pk=publication.pk, etat=PublicationReseau.PROGRAMMEE)
                .update(etat=PublicationReseau.EN_COURS))


def _finir(publication, *, erreur="", id_externe="", permalien=""):
    publication.etat = PublicationReseau.ECHOUEE if erreur else PublicationReseau.PUBLIEE
    publication.erreur = erreur[:500]
    publication.id_externe = id_externe[:128]
    publication.permalien = permalien[:1000]
    publication.conteneur = ""
    publication.publiee_le = None if erreur else timezone.now()
    publication.save(update_fields=["etat", "erreur", "id_externe", "permalien", "conteneur", "publiee_le"])


def _texte_complet(publication):
    if publication.lien and publication.images:
        return f"{publication.texte}\n\n{publication.lien}".strip()
    return publication.texte


def _lien_public(chemin, champ, jeton):
    """Le permalien : un plus, jamais une raison d'échouer."""
    try:
        return str(meta.get(chemin, fields=champ, access_token=jeton).get(champ) or "")
    except meta.ErreurMeta:
        return ""


def _facebook(publication, compte):
    jeton, page = compte.jeton, compte.id_externe
    texte = _texte_complet(publication)
    if len(publication.images) == 1:
        reponse = meta.post(f"{page}/photos", url=publication.images[0], message=texte, access_token=jeton)
        id_post = str(reponse.get("post_id") or reponse.get("id") or "")
    elif publication.images:
        photos = [meta.post(f"{page}/photos", url=image, published="false", access_token=jeton)["id"]
                  for image in publication.images]
        jointes = {f"attached_media[{i}]": f'{{"media_fbid":"{p}"}}' for i, p in enumerate(photos)}
        id_post = str(meta.post(f"{page}/feed", message=texte, access_token=jeton, **jointes).get("id", ""))
    else:
        champs = {"message": publication.texte} if publication.texte else {}
        if publication.lien:
            champs["link"] = publication.lien
        id_post = str(meta.post(f"{page}/feed", access_token=jeton, **champs).get("id", ""))
    _finir(publication, id_externe=id_post, permalien=_lien_public(id_post, "permalink_url", jeton))


def _instagram_conteneur(publication, compte):
    jeton, ig = compte.jeton, compte.id_externe
    texte = _texte_complet(publication)
    if len(publication.images) == 1:
        return str(meta.post(f"{ig}/media", image_url=publication.images[0], caption=texte, access_token=jeton)["id"])
    enfants = [str(meta.post(f"{ig}/media", image_url=image, is_carousel_item="true", access_token=jeton)["id"])
               for image in publication.images]
    return str(meta.post(f"{ig}/media", media_type="CAROUSEL", children=",".join(enfants), caption=texte,
                         access_token=jeton)["id"])


def _instagram_suite(publication, compte, conteneur, attentes=()):
    """Attend que Meta ait lu les images, puis publie ; sinon laisse le conteneur à la tâche des 5 minutes."""
    jeton = compte.jeton
    for attente in (0, *attentes):
        time.sleep(attente)
        statut = meta.get(conteneur, fields="status_code", access_token=jeton).get("status_code")
        if statut == "FINISHED":
            media = str(meta.post(f"{compte.id_externe}/media_publish", creation_id=conteneur,
                                  access_token=jeton).get("id", ""))
            return _finir(publication, id_externe=media, permalien=_lien_public(media, "permalink", jeton))
        if statut in ("ERROR", "EXPIRED"):
            return _finir(publication, erreur=_("Instagram n'a pas pu lire l'image (JPEG public attendu)."))
    if timezone.now() - publication.programmee_pour > ABANDON_DU_CONTENEUR:
        return _finir(publication, erreur=_("Instagram n'a pas fini de lire l'image en une heure."))
    # Gardé en dernier : tant que `conteneur` est vide, la tâche des 5
    # minutes ne touche pas à cette publication.
    publication.conteneur = conteneur
    publication.save(update_fields=["conteneur"])


def executer(publication, *, attentes=ATTENTES_DU_CONTENEUR):
    """Publie une publication due. Ne lève jamais : l'erreur va au journal."""
    reprise = publication.etat == PublicationReseau.EN_COURS and publication.conteneur
    if not reprise and not _prendre(publication):
        return
    compte = publication.compte
    if compte is None or compte.etat != CompteReseau.ACTIF:
        return _finir(publication, erreur=_("Compte délié ou à reconnecter."))
    try:
        if compte.reseau == CompteReseau.FACEBOOK:
            _facebook(publication, compte)
        elif reprise:
            _instagram_suite(publication, compte, publication.conteneur)
        else:
            _instagram_suite(publication, compte, _instagram_conteneur(publication, compte), attentes)
    except (meta.ErreurMeta, KeyError) as souci:
        if isinstance(souci, meta.ErreurMeta) and souci.jeton_invalide:
            _a_reconnecter(compte, str(souci))
        _finir(publication, erreur=str(souci) or _("Réponse de Meta incomplète."))


def _a_reconnecter(compte, erreur):
    compte.etat = CompteReseau.A_RECONNECTER
    compte.derniere_erreur = erreur[:300]
    compte.save(update_fields=["etat", "derniere_erreur"])


# --- Tâches planifiées (jeiko.fr) ----------------------------------------------


def publier_les_dues(maintenant=None):
    """Tâche des 5 minutes : les programmées venues à l'heure, et les conteneurs Instagram en attente."""
    if not relais_allume():
        return 0
    maintenant = maintenant or timezone.now()
    # Une publication prise puis abandonnée en route (processus tué) : on ne
    # sait pas si Meta l'a reçue. Elle échoue en le disant plutôt que de partir deux fois.
    PublicationReseau.objects.filter(
        etat=PublicationReseau.EN_COURS, conteneur="", programmee_pour__lt=maintenant - ABANDON_DU_CONTENEUR,
    ).update(etat=PublicationReseau.ECHOUEE, erreur=_("Interrompue en cours d'envoi : vérifiez sur le réseau."))
    dues = PublicationReseau.objects.select_related("compte").filter(
        Q(etat=PublicationReseau.PROGRAMMEE, programmee_pour__lte=maintenant)
        | Q(etat=PublicationReseau.EN_COURS, conteneur__gt=""),
    ).order_by("programmee_pour")[:200]
    for publication in dues:
        executer(publication, attentes=())
    return len(dues)


def verifier_les_jetons(maintenant=None):
    """
    Tâche quotidienne : chaque jeton de page est essayé. Un jeton mort
    (mot de passe changé, application retirée, rôle perdu sur la page) passe
    le compte « à reconnecter » — le site le montre avant qu'une
    publication programmée n'échoue. Le jeton de page n'expire pas de
    lui-même : le renouveler, c'est se reconnecter, et Meta ne permet rien
    d'autre (un jeton expiré ne s'échange pas).
    """
    if not relais_allume():
        return 0
    n = 0
    for compte in CompteReseau.objects.filter(etat=CompteReseau.ACTIF):
        try:
            meta.get(compte.id_externe, fields="id", access_token=compte.jeton)
        except meta.ErreurMeta as souci:
            if souci.jeton_invalide:
                _a_reconnecter(compte, str(souci))
                n += 1
            continue
        compte.verifie_le = maintenant or timezone.now()
        compte.save(update_fields=["verifie_le"])
    return n


def purger(maintenant=None):
    limite = (maintenant or timezone.now()) - CONSERVATION_DU_JOURNAL
    return PublicationReseau.objects.filter(programmee_pour__lt=limite).exclude(
        etat=PublicationReseau.PROGRAMMEE).delete()[0]


# --- Ce que l'API rend ----------------------------------------------------------


def compte_en_json(compte):
    return {"id": compte.pk, "reseau": compte.reseau, "nom": compte.nom, "etat": compte.etat,
            "relie_le": compte.relie_le.isoformat()}


def publication_en_json(p):
    return {
        "id": p.pk, "compte": p.compte_id, "reseau": p.reseau, "nom_du_compte": p.nom_du_compte,
        "texte": p.texte, "images": p.images, "lien": p.lien, "programmee_pour": p.programmee_pour.isoformat(),
        "etat": p.etat, "permalien": p.permalien, "erreur": p.erreur,
        "publiee_le": p.publiee_le.isoformat() if p.publiee_le else None,
    }
