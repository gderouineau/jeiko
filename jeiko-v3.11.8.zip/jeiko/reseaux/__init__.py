"""
Le relais des réseaux (RESEAUX-01, RES-01, 27/10/2026).

Sur jeiko.fr : les sites JEIKO publient sur Facebook (page) et Instagram
(compte professionnel) par UNE application Meta, celle de l'entreprise de
Guillaume. Allumé par `JEIKO_RELAIS_RESEAUX=True` dans le .env, avec
`JEIKO_META_APP_ID` et `JEIKO_META_APP_SECRET` ; partout ailleurs, écrans,
API et rappels de Meta répondent 404 et le menu ne le montre pas.

Comme les licences, pas de modèle à lui : `CompteReseau` et
`PublicationReseau` vivent dans `administration.models` — une application de
plus aurait dû entrer dans le gabarit de settings, et un site resté sur un
ancien settings ne démarrerait plus.

Qui gère quoi (Guillaume, 27/10)
--------------------------------
« La gestion ne se fait que dans jeiko.fr, la gestion client se fait depuis
le site de chacun. »
* Sur jeiko.fr, les écrans sont à Guillaume seul (super-administrateurs) :
  l'état de l'application Meta et les adresses à lui déclarer, les comptes
  reliés de tous les sites, le journal, délier un compte. Couper un site
  abusif : désactiver sa licence — l'API lui répond alors 403.
* Un exploitant n'a ni compte ni écran sur jeiko.fr. Pendant la connexion,
  il ne fait que le TRAVERSER (`/reseaux/connecter/`, `/reseaux/retour/` :
  des redirections), puis revient sur son site.
* Tout ce que fait le client — relier, voir et délier ses comptes, publier,
  programmer, annuler, lire son journal — passe par l'API du relais, appelée
  depuis l'administration de SON site avec sa clé de licence (`client.py`).
  Les écrans du site sont RES-02 ; l'API leur suffit.

Ce qui fait foi
---------------
* Un site s'identifie par sa CLÉ DE LICENCE (`Authorization: Bearer`) : elle
  sert déjà un seul domaine, pas de second secret à distribuer. Une licence
  désactivée ou expirée ne publie plus.
* Jamais de mot de passe de réseau : l'exploitant part de son site vers
  jeiko.fr, qui l'envoie chez Meta ; Meta rend un code à jeiko.fr, échangé
  contre des jetons de PAGE, gardés chiffrés (jeiko/encrypted.py), puis
  l'exploitant revient sur son site — et seulement sur le domaine de la
  licence, en https.
* Le retour de Meta est lié au navigateur qui est parti (nombre en session,
  rapporté par `state`) : un code rejoué ailleurs ne relie rien.
* Délier oublie les jetons, et retire l'autorisation chez Meta quand c'était
  le dernier compte de cette personne. Retirer l'application depuis Facebook
  (rappel « Deauthorize ») ou demander l'effacement fait oublier aussitôt.
* Publier : texte, ADRESSES des images (https, sur le domaine du site —
  Meta va les chercher chez lui), lien ; tout de suite ou programmé (un an au
  plus), une ligne de journal par compte visé. La tâche des 5 minutes publie
  les programmées et finit les conteneurs Instagram ; une publication n'est
  jamais prise deux fois.
* Côté site, `client.py` ne lève jamais : jeiko.fr en panne fait échouer une
  publication en le disant, jamais le site.

Ce que ça ne fait pas : la vidéo (Reels, vidéos Facebook), YouTube (RES-06),
l'écran « Réseaux » des sites (RES-02), les outils MCP (RES-03). Et la
contrepartie assumée par Guillaume le 27/10 : jeiko.fr tient les jetons de
tous les sites — une base lue sans le .env ne les livre pas, mais qui tient
le serveur les tient.
"""
