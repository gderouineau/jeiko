"""
Côté SITE : parler au relais de jeiko.fr avec la clé de licence du site.

Le principe est celui des licences : jeiko.fr en panne, lent ou injoignable
ne casse jamais un site. `appeler` ne lève pas et attend peu ; il rend la
réponse JSON du relais, ou `{"erreur": …}` que l'écran (RES-02) montre tel
quel. Une publication qui n'a pas pu partir n'est pas rejouée en douce :
l'exploitant voit l'erreur et décide.
"""
import requests
from django.conf import settings
from django.utils.translation import gettext as _

DELAI = (5, 30)


def adresse_du_relais():
    return (getattr(settings, "JEIKO_RELAIS_URL", "") or "https://jeiko.fr").rstrip("/")


def appeler(methode, chemin, corps=None, params=None):
    from jeiko.administration.models import WebSite

    site = WebSite.objects.first()
    cle = site.licence_cle if site is not None else ""
    if not cle:
        return {"erreur": _("Ce site n'a pas de clé de licence : les réseaux passent par elle.")}
    try:
        reponse = requests.request(
            methode, f"{adresse_du_relais()}/api/reseaux/{chemin.lstrip('/')}", json=corps, params=params,
            headers={"Authorization": f"Bearer {cle}"}, timeout=DELAI,
        )
        donnees = reponse.json()
    except (requests.RequestException, ValueError):
        return {"erreur": _("jeiko.fr ne répond pas : réessayez dans quelques minutes.")}
    if not isinstance(donnees, dict):
        return {"erreur": _("Réponse de jeiko.fr illisible.")}
    if reponse.status_code >= 400 and "erreur" not in donnees:
        donnees["erreur"] = _("jeiko.fr a refusé la demande (%(code)s).") % {"code": reponse.status_code}
    return donnees
