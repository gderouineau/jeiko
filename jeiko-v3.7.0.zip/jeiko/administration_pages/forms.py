# forms.py
# =====================================================================
# Imports
# =====================================================================
from django import forms
from django.forms import formset_factory, inlineformset_factory, BaseInlineFormSet
from django.core.validators import EmailValidator
from django.core.exceptions import ValidationError
from django.db.models import Q
import json
from django.forms.widgets import ClearableFileInput
# Modèles
import jeiko.administration_pages.models as M
from jeiko.administration_pages.models import (
    Page, Section, Line, Bloc, Category,
    ImageContent, ContentButton, ContentVideo, BackgroundImageParameters,
    # Contenu classiques
    Content, ContentImage, Animation, Border,
)

from jeiko.administration_menu.models import Menu, MenuPlace

# ---- DYN models (ajoutés dans models.py juste avant)
from jeiko.administration_pages.models import (
    DynFAQItem, DynTabItem, DynCarouselSlide, DynProgressStep,
    DynTestimonialItem, DynLiveFilterItem,
    DynAccordionSection, DynAccordionChild,
    DynPricingPlan, DynPricingFeature,
    DynGalleryItem, DynStepperStep,
    DynResourceConfig,
)

from jeiko.questionnaires_expert.models import ExpertTest
from django.utils.translation import gettext_lazy as _
from jeiko.formulaires_par_langue import ChampsParLangueMixin

# =====================================================================
# Helpers
# =====================================================================

class OrderedInlineFormSet(BaseInlineFormSet):
    """
    Sauvegarde l'ordre (ORDER) dans le champ `order` du modèle.
    Utiliser avec inlineformset_factory(..., can_order=True, formset=OrderedInlineFormSet).
    """
    def save(self, commit=True):
        instances = super().save(commit=False)

        # delete marqués
        for obj in self.deleted_objects:
            obj.delete()

        # recopier ORDER -> instance.order
        # si can_order=True, `ordered_forms` existe, sinon on parcourt `forms`
        forms_iter = getattr(self, 'ordered_forms', self.forms)
        for f in forms_iter:
            if not hasattr(f, 'cleaned_data') or not f.cleaned_data:
                continue
            if f.cleaned_data.get('DELETE'):
                continue
            inst = f.instance
            order_val = f.cleaned_data.get('ORDER')
            if order_val is not None:
                inst.order = order_val
            if commit:
                inst.save()

        # m2m
        if commit:
            self.save_m2m()
        return instances


# =====================================================================
# Catégories / Pages
# =====================================================================

class MainCategoryForm(ChampsParLangueMixin, forms.ModelForm):
    valeurs_traduites = (("name", _("Nom")), ("slug", _("Adresse")))

    class Meta:
        model = Category
        fields = [
            'name', 'slug', 'show_cat_in_url',
            'main_menu', 'footer_menu',
            'is_protected',
        ]
        widgets = {
            'slug': forms.TextInput(attrs={'placeholder': 'auto-si-vide'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['main_menu'].queryset = Menu.objects.filter(place=MenuPlace.MAIN)
        self.fields['main_menu'].required = False
        self.fields['footer_menu'].queryset = Menu.objects.filter(place=MenuPlace.FOOTER)
        self.fields['footer_menu'].required = False


class SubCategoryForm(ChampsParLangueMixin, forms.ModelForm):
    valeurs_traduites = (("name", _("Nom")), ("slug", _("Adresse")))

    class Meta:
        model = Category
        fields = [
            'name', 'slug', 'show_cat_in_url',
            'main_menu', 'footer_menu',
            'is_protected',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['main_menu'].queryset = Menu.objects.filter(place=MenuPlace.MAIN)
        self.fields['main_menu'].required = False
        self.fields['footer_menu'].queryset = Menu.objects.filter(place=MenuPlace.FOOTER)
        self.fields['footer_menu'].required = False


class MainCategoryFormPage(forms.Form):
    name = forms.ModelChoiceField(
        queryset=Category.objects.filter(main_category__isnull=True),
        required=False,
        label=_("Catégorie principale"),
        widget=forms.Select(attrs={'id': 'id_main_category_-name'})
    )


class SubCategoryFormPage(forms.Form):
    name = forms.ModelChoiceField(
        queryset=Category.objects.filter(main_category__isnull=False),
        required=False,
        label=_("Sous-catégorie"),
        widget=forms.Select(attrs={'id': 'id_sub_category_-name'})
    )


class PageForm(forms.ModelForm):
    # Les libellés et les aides vivent ici plutôt que dans le gabarit : ils
    # suivent alors le formulaire partout où il est rendu. Les champs portaient
    # des noms d'implémentation (« Tag URL », « Template objet », « Racine du
    # site ») sans une ligne d'explication, alors que ce sont précisément les
    # décisions qu'un administrateur non technique ne peut pas deviner.
    class Meta:
        model = M.Page
        fields = ['title', 'active', 'url_tag', 'is_root', 'google_index', 'is_custom_object_template']
        labels = {
            'title': _("Titre de la page"),
            'active': _("Page en ligne"),
            'url_tag': _("Adresse de la page"),
            'is_root': _("Utiliser comme page d'accueil"),
            'google_index': _("Autoriser l'indexation par les moteurs de recherche"),
            'is_custom_object_template': _("Utiliser comme gabarit d'objet personnalisé"),
        }
        help_texts = {
            'title': _("Sert de titre d'onglet et de repère dans l'administration."),
            'active': _("Décochée, la page existe mais reste invisible pour les visiteurs."),
            'url_tag': _("Dernier segment de l'adresse, en minuscules et sans accent. "
                       "Exemple : « nos-tarifs » donne une page à l'adresse /nos-tarifs/."),
            'is_root': _("La page s'affichera à la racine du site. Une seule page à la fois."),
            'google_index': _("Décochez pour une page de remerciement, un brouillon ou une page privée."),
            'is_custom_object_template': _("Réservé aux gabarits qui affichent un objet personnalisé "
                                         "(fiche produit, article…). Laissez décoché pour une page normale."),
        }
        widgets = {
            'url_tag': forms.TextInput(attrs={'placeholder': 'nos-tarifs'}),
        }


class VersionForm(forms.ModelForm):
    """
    Les réglages d'une version traduite : ce qui lui est propre, rien d'autre.
    La catégorie, les menus et le rang de page d'accueil se règlent sur la
    version d'origine et valent pour toutes.
    """
    class Meta:
        model = M.Page
        fields = ['title', 'active', 'url_tag', 'google_index']
        labels = {k: PageForm.Meta.labels[k] for k in fields}
        help_texts = {
            **{k: PageForm.Meta.help_texts[k] for k in ('title', 'active', 'google_index')},
            'url_tag': _("Dernier segment de l'adresse dans cette langue, en minuscules et sans accent."),
        }

    def clean_active(self):
        en_ligne = self.cleaned_data.get("active")
        if en_ligne and not self.instance.langue_servie:
            raise ValidationError(_(
                "La langue de cette version n'est plus activée pour le site : "
                "elle ne serait servie à aucune adresse. Réactivez la langue "
                "dans Réglages › Langues du site, puis publiez."
            ))
        return en_ligne


class MetadataForm(forms.ModelForm):
    # Renseignées, ces deux valeurs deviennent le titre et le résumé affichés
    # par Google et par les partages sur les réseaux sociaux.
    class Meta:
        model = M.Metadata
        fields = ['title', 'description']
        labels = {
            'title': _("Titre affiché dans les résultats de recherche"),
            'description': _("Résumé affiché sous le titre"),
        }
        help_texts = {
            'title': _("Environ 60 caractères. Laissé vide, le titre de la page est utilisé."),
            'description': _("Environ 155 caractères. C'est le texte qui donne envie de cliquer."),
        }


# =====================================================================
# Mise en page (Fond, Marges, Paddings, Tailles, Bloc)
# =====================================================================

class BackgroundImageParametersForm(forms.ModelForm):
    class Meta:
        model = BackgroundImageParameters
        fields = [
            'background_repeat', 'background_size', 'background_position',
            'background_attachment', 'background_blur', 'background_brightness', 'background_opacity'
        ]
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for f in self.fields.values():
            f.required = False


class StyleBoxForm(forms.ModelForm):
    class Meta:
        model = M.StyleBox
        fields = ['top', 'right', 'bottom', 'left']


class MarginForm(forms.ModelForm):
    class Meta:
        model = M.Margin
        fields = ['top', 'right', 'bottom', 'left']
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['top'].widget.attrs['placeholder'] = _("Haute")
        self.fields['right'].widget.attrs['placeholder'] = _("Droite")
        self.fields['bottom'].widget.attrs['placeholder'] = _("Basse")
        self.fields['left'].widget.attrs['placeholder'] = _("Gauche")


class PaddingForm(forms.ModelForm):
    class Meta:
        model = M.Padding
        fields = ['top', 'right', 'bottom', 'left']
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['top'].widget.attrs['placeholder'] = _("Haute")
        self.fields['right'].widget.attrs['placeholder'] = _("Droite")
        self.fields['bottom'].widget.attrs['placeholder'] = _("Basse")
        self.fields['left'].widget.attrs['placeholder'] = _("Gauche")


class AnimationForm(forms.ModelForm):
    dx = forms.CharField(required=False, help_text=_("Ex. 24px, -16px"))
    dy = forms.CharField(required=False, help_text=_("Ex. 24px, -16px"))
    scale_from = forms.CharField(required=False, help_text=_("Ex. 0.96"))
    deg = forms.CharField(required=False, help_text=_("Ex. 6deg"))
    px = forms.CharField(required=False, help_text=_("Ex. 8px"))

    class Meta:
        model = Animation
        exclude = ("section", "line", "bloc")  # 👈 cible pilotée par l’instance, pas par le POST

    PRESET_PARAM_FIELDS = {
        "slide-up": ["dx", "dy"],
        "slide-down": ["dx", "dy"],
        "slide-left": ["dx", "dy"],
        "slide-right": ["dx", "dy"],
        "zoom-in": ["scale_from"],
        "rotate-in": ["deg"],
        "blur-in": ["px"],
        "fade": [],
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        params = (self.instance.params or {}) if getattr(self.instance, "params", None) is not None else {}
        for key in ["dx", "dy", "scale_from", "deg", "px"]:
            if key in params:
                self.fields[key].initial = params[key]

    def clean(self):
        cleaned = super().clean()

        # 👉 Si désactivée, on ne force pas la cible (pratique si vous voulez laisser l’objet "off")
        if cleaned.get("enabled") is False:
            return cleaned

        # ⚖️ XOR exact via l'instance (pas cleaned_data)
        section = getattr(self.instance, "section", None)
        line    = getattr(self.instance, "line", None)
        bloc    = getattr(self.instance, "bloc", None)
        if (bool(section) + bool(line) + bool(bloc)) != 1:
            raise ValidationError(_("Animation: renseigner exactement une cible parmi section/line/bloc."))

        # Reconstruire params à partir des champs paramétriques
        preset = cleaned.get("preset") or "fade"
        wanted = self.PRESET_PARAM_FIELDS.get(preset, [])
        params = {}
        for key in wanted:
            val = cleaned.get(key)
            if val not in (None, ""):
                params[key] = val
        self.instance.params = params
        return cleaned



class BorderForm(forms.ModelForm):
    class Meta:
        model = Border
        exclude = ("section", "line", "bloc")
        widgets = {
             "border_width": forms.TextInput(attrs={"placeholder": "Ex: 1px"}),
             "border_color": forms.TextInput(attrs={"type": "color"}),
             "border_radius": forms.TextInput(attrs={"placeholder": "Ex: 4px"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for f in self.fields.values():
            if 'class' not in f.widget.attrs:
                f.widget.attrs['class'] = 'form-control'


class BlocSizeForm(forms.ModelForm):
    class Meta:
        model = M.Size
        fields = ['width', 'height']
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['height'].required = False


class SizeForm(forms.ModelForm):
    class Meta:
        model = M.Size
        fields = ['width']


class BlocForm(forms.ModelForm):
    """
    L'alignement du contenu dans un bloc : à gauche, centré, à droite ; en
    haut, au milieu, en bas.

    Ce formulaire existait, importé par `utils.py` et jamais instancié : les
    deux champs vivaient dans le modèle, l'API les écrivait, le rendu les
    appliquait — et l'éditeur ne les montrait nulle part. Un bouton ne pouvait
    donc se caler à gauche que par l'API (relevé le 01/10/2026).

    Il ne porte QUE l'alignement. Il listait aussi `background_color`, que
    d'autres formulaires écrivent déjà : lié à des données qui ne la
    contiennent pas, il aurait effacé la couleur de fond du bloc.
    """

    class Meta:
        model = Bloc
        fields = ['horizontal_align', 'vertical_align']
        widgets = {
            'horizontal_align': forms.Select(choices=Bloc._meta.get_field('horizontal_align').choices),
            'vertical_align': forms.Select(choices=Bloc._meta.get_field('vertical_align').choices),
        }


# =====================================================================
# Medias (Image / Vidéo)
# =====================================================================

class ImageForm(forms.ModelForm):
    class Meta:
        model = M.ImageContent
        fields = ['original_image', 'alt']
        widgets = {
            'original_image': forms.ClearableFileInput(attrs={'accept': 'image/*'}),
            'alt': forms.TextInput(attrs={'class': 'form-control'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['original_image'].required = True
        self.fields["alt"].required = False


class MediaLibraryImageForm(forms.ModelForm):
    """Formulaire dédié à la création et à l'édition d'un média."""

    class Meta:
        model = M.ImageContent
        fields = ["original_image", "title", "alt", "decorative"]
        widgets = {
            # Pas de case « effacer » : une entrée sans fichier n'est pas un
            # média. La suppression complète dispose d'un écran explicite.
            "original_image": forms.FileInput(attrs={"accept": "image/*"}),
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "alt": forms.TextInput(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["original_image"].required = not bool(self.instance.pk)
        self.fields["original_image"].label = _("Fichier image")
        self.fields["title"].required = False
        self.fields["alt"].required = False
        self.fields["alt"].help_text = (
            _("Décrivez l'information portée par l'image. Obligatoire, sauf si "
            "vous la déclarez décorative ci-dessous.")
        )

    def clean(self):
        """A-09 : décrite, ou déclarée décorative — jamais vide par oubli."""
        cleaned = super().clean()
        alt = (cleaned.get("alt") or "").strip()
        if cleaned.get("decorative"):
            # Une image décorative se tait : un texte ici serait lu quand même.
            cleaned["alt"] = ""
        elif not alt:
            self.add_error(
                "alt",
                _("Décrivez l'image, ou cochez « Image décorative » si elle "
                "n'apporte aucune information."),
            )
        else:
            cleaned["alt"] = alt
        return cleaned


class BackgroundImageForm(forms.ModelForm):
    class Meta:
        model = ImageContent
        fields = ['original_image', 'alt']
        widgets = {
            'original_image': forms.ClearableFileInput(attrs={'accept': 'image/*'}),
            'alt': forms.TextInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['original_image'].label = _("Image principale (sera redimensionnée pour chaque format)")
        self.fields["original_image"].required = False
        self.fields["alt"].required = False

    def save(self, commit=True):
        # A-09 : une image téléversée COMME FOND est décorative par nature —
        # le fond est rendu `aria-hidden`, un lecteur d'écran ne le lit pas.
        # Sans ce marquage, chaque fond apparaîtrait « à compléter » dans la
        # médiathèque. Une image existante réutilisée en fond garde son réglage.
        if self.instance._state.adding:
            self.instance.decorative = True
        return super().save(commit=commit)


# --- Vidéo ---

class ContentVideoForm(forms.ModelForm):
    class Meta:
        model = ContentVideo
        fields = (
            "source", "provider", "file", "url", "poster",
            "title", "aria_label", "width", "height", "aspect_ratio",
            "controls", "autoplay", "muted", "loop", "playsinline", "preload",
            "start_time", "end_time",
            "track_file", "track_lang", "track_label",
        )
        widgets = {
            "source": forms.Select(attrs={"class": "form-select"}),
            "provider": forms.Select(attrs={"class": "form-select"}),
            "file": forms.ClearableFileInput(attrs={"class": "form-control"}),
            "url": forms.URLInput(attrs={"class": "form-control", "placeholder": _("https://youtu.be/... ou https://...") }),
            "poster": forms.Select(attrs={"class": "form-select"}),

            "title": forms.TextInput(attrs={"class": "form-control"}),
            "aria_label": forms.TextInput(attrs={"class": "form-control", "placeholder": _("Description pour lecteurs d’écran")}),

            "width": forms.TextInput(attrs={"class": "form-control", "placeholder": _("ex: 100% ou 640px")}),
            "height": forms.TextInput(attrs={"class": "form-control", "placeholder": "ex: 360px"}),
            "aspect_ratio": forms.TextInput(attrs={"class": "form-control", "placeholder": "ex: 16/9"}),

            "controls": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "autoplay": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "muted": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "loop": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "playsinline": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "preload": forms.Select(attrs={"class": "form-select"}),

            "start_time": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
            "end_time": forms.NumberInput(attrs={"class": "form-control", "min": 0}),

            "track_file": forms.ClearableFileInput(attrs={"class": "form-control"}),
            "track_lang": forms.TextInput(attrs={"class": "form-control", "placeholder": "fr, en, ..."}),
            "track_label": forms.TextInput(attrs={"class": "form-control", "placeholder": _("Français")}),
        }

    def clean(self):
        cleaned = super().clean()
        source   = cleaned.get("source")
        provider = cleaned.get("provider")
        file     = cleaned.get("file")
        url      = cleaned.get("url")
        autoplay = cleaned.get("autoplay")
        muted    = cleaned.get("muted")
        start_t  = cleaned.get("start_time")
        end_t    = cleaned.get("end_time")

        if source == ContentVideo.Source.FILE:
            if not file:
                raise ValidationError(_("Veuillez ajouter un fichier vidéo (source=fichier)."))
            cleaned["provider"] = ContentVideo.Provider.HTML5
            if url:
                cleaned["url"] = None

        elif source == ContentVideo.Source.EXTERNAL:
            if not url:
                raise ValidationError(_("Veuillez renseigner l’URL de la vidéo (source=URL)."))
            u = (url or "").lower()
            if "youtu.be" in u or "youtube.com" in u:
                cleaned["provider"] = ContentVideo.Provider.YOUTUBE
            elif "vimeo.com" in u:
                cleaned["provider"] = ContentVideo.Provider.VIMEO
            elif "dailymotion.com" in u:
                cleaned["provider"] = ContentVideo.Provider.DAILYMOTION
            elif u.endswith((".mp4", ".webm", ".ogg", ".m3u8")):
                cleaned["provider"] = ContentVideo.Provider.HTML5
            else:
                cleaned["provider"] = ContentVideo.Provider.OTHER
            if file:
                cleaned["file"] = None
        else:
            raise ValidationError(_("Source invalide."))

        if start_t is not None and start_t < 0:
            self.add_error("start_time", _("La valeur doit être ≥ 0."))
        if end_t is not None and end_t < 0:
            self.add_error("end_time", _("La valeur doit être ≥ 0."))
        if start_t and end_t and end_t <= start_t:
            raise ValidationError(_("`end_time` doit être strictement supérieur à `start_time`."))
        if autoplay and not muted:
            self.add_error("muted", _("Conseillé d’activer 'muted' pour que l’autoplay fonctionne sur mobile/Chrome."))
        return cleaned


# =====================================================================
# Contenus classiques (Text / Image / Button / Calendar / Chart / CSS)
# =====================================================================

class ContentForm(forms.ModelForm):
    class Meta:
        model = M.Content
        fields = ['content_type']


class ContentImageForm(forms.ModelForm):
    class Meta:
        model = M.ContentImage
        fields = [
            'object_fit', 'object_position', 'filter', 'opacity',
            'transition', 'mix_blend_mode', 'alt', 'title',
            'dynamic_key',
        ]
        widgets = {
            'object_fit': forms.Select(choices=M.ContentImage._meta.get_field('object_fit').choices),
            'mix_blend_mode': forms.Select(choices=M.ContentImage._meta.get_field('mix_blend_mode').choices),
        }


class ContentTextAdvancedForm(forms.ModelForm):
    class Meta:
        model = M.ContentText
        fields = ['text']
        widgets = {
            'text': forms.Textarea(attrs={'placeholder': _('Utilisez [%prenom%], [%score%], etc.')}),
        }


class ContentChartQuestionnaireForm(forms.ModelForm):
    class Meta:
        model = M.ContentChartQuestionnaire
        fields = ["title", "description", "chart_type", "options_json", "main_axis"]
        widgets = {"options_json": forms.Textarea(attrs={"rows": 4, "cols": 60})}


class ButtonContentForm(forms.ModelForm):

    # on force un ChoiceField pour conserver une valeur str (le slug) en base
    test_slug = forms.ChoiceField(
        required=False,
        label=_("Questionnaire lié"),
        choices=[],  # rempli dynamiquement dans __init__
    )


    class Meta:
        model = ContentButton
        fields = [
            'label', 'page_target', 'custom_object_target', 'test_slug', 'open_in_new_tab', 'external_url', 'dynamic_key',
            'is_add_to_cart', 'product_target',
            'background_color', 'text_color', 'border_color',
            'hover_background_color', 'hover_text_color', 'hover_border_color',
            'border_radius', 'border_width', 'padding', 'width', 'height',
            'font_size', 'font_weight', 'font_family', 'letter_spacing', 'text_transform',
            'box_shadow', 'hover_shadow', 'transition',
            'icon_left', 'icon_right',
            'animation',
            'aria_label', 'tabindex', 'disabled',
        ]
        widgets = {
            'text_transform': forms.Select(choices=ContentButton._meta.get_field('text_transform').choices),
            'animation': forms.Select(choices=ContentButton._meta.get_field('animation').choices),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # 1) Remplir la liste (valeur = slug, libellé = title)
        tests = ExpertTest.objects.all().order_by('title')
        choices = [('', _('— Sélectionner un questionnaire —'))]
        choices += [(t.slug, t.title) for t in tests]

        # 2) Si l’instance contient un slug qui n’existe plus, on l’affiche quand même
        current = getattr(self.instance, 'test_slug', None)
        if current and current not in [c[0] for c in choices if isinstance(c, (list, tuple))]:
            choices.append((current, f"{current} (inexistant / déjà supprimé)"))

        self.fields['test_slug'].choices = choices
        self.fields['test_slug'].widget.attrs.update({'class': 'form-select'})

        # 3) Un bouton vise une fiche d'ORIGINE : le lien mène de lui-même à la
        # version que lit le visiteur. Ses versions par langue ne se proposent
        # donc pas — elles doubleraient chaque fiche dans la liste.
        cible = self.fields['custom_object_target']
        cible.queryset = cible.queryset.filter(langue="")

    def clean_test_slug(self):
        # On enregistre bien un slug (str) ou None
        value = (self.cleaned_data.get('test_slug') or '').strip()
        return value or None

    def clean(self):
        data = super().clean()
        page_target = data.get('page_target')
        custom_object_target = data.get('custom_object_target')
        test_slug = data.get('test_slug')
        external_url = (data.get('external_url') or '').strip()
        is_add_to_cart = data.get('is_add_to_cart')
        product_target = data.get('product_target')

        # empêcher de définir plusieurs types de cible en même temps
        # On compte les "types" de destinations activés
        destinations = [
            bool(page_target),
            bool(custom_object_target),
            bool(test_slug),
            bool(external_url),
            bool(is_add_to_cart)
        ]
        
        if sum(destinations) > 1:
            msg = _("Choisis une seule action : page, questionnaire, lien externe OU ajout au panier.")
            self.add_error('page_target', msg)
            self.add_error('custom_object_target', msg)
            self.add_error('test_slug', msg)
            self.add_error('external_url', msg)
            self.add_error('is_add_to_cart', msg)

        if external_url:
            data['external_url'] = external_url
            
        # Si ajout au panier manuel, on peut vérifier si product_target est rempli, 
        # mais on laisse optionnel pour le cas "produit courant"
        
        return data


class ContentCalendarForm(forms.ModelForm):
    class Meta:
        model = M.ContentCalendar
        fields = ['title', 'appointment_type', 'calendar_config']
        widgets = {
            'calendar_config': forms.Select(attrs={'class': 'form-control'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Personnaliser l'affichage du champ calendar_config pour montrer user + name
        if 'calendar_config' in self.fields:
            self.fields['calendar_config'].label_from_instance = lambda obj: f"{obj.user} → {obj.name}"


class SectionForm(forms.ModelForm):
    class Meta:
        model = M.Section
        fields = [
            'background_color',
            'background_image_dynamic_key'
        ]


class LineForm(forms.ModelForm):
    class Meta:
        model = M.Line
        fields = [
            'background_color',
            'background_image_dynamic_key',
            'columns_type',
            'columns_type_tablet',
            'columns_type_phone'
        ]
        labels = {
            'background_color': _('Couleur de fond'),
            'background_image_dynamic_key': _('Clé pour image d fond dynamique'),
            'columns_type':       _('Disposition (Ordinateur)'),
            'columns_type_tablet':_('Disposition (Tablette)'),
            'columns_type_phone': _('Disposition (Téléphone)'),
        }


class TextForm(forms.ModelForm):
    """Bloc texte de l'éditeur — assaini à l'ÉCRITURE (A-49).

    L'API des agents stockait déjà ce qui serait servi ; l'administration
    stockait le HTML tapé et ne l'assainissait qu'au rendu. L'éditeur montrait
    donc à son rédacteur ce qu'il venait de taper, pas ce que verrait le
    visiteur — c'est ainsi qu'une accroche est partie en production dans la
    mauvaise couleur (A-46). Désormais ce qui est stocké est ce qui est servi,
    et la section rafraîchie après l'enregistrement le montre.

    `avertissements` dit ce qui a été retiré ; la vue le transmet à l'éditeur.
    `clean_html` reste appliqué au rendu, pour les contenus plus anciens.
    """

    class Meta:
        model = M.ContentText
        fields = ['text']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['text'].required = False
        self.avertissements = []

    def clean_text(self):
        from jeiko.sanitize import nettoyer_en_rendant_compte

        brut = self.cleaned_data.get('text') or ""
        if not brut:
            return brut
        propre, self.avertissements = nettoyer_en_rendant_compte(brut)
        return propre


class CSSParametersForm(forms.ModelForm):
    class Meta:
        model = M.CSSParameters
        fields = ['object_id', 'object_classes', 'before', 'current', 'after', 'hover', 'custom']



class CustomCSSForm(forms.ModelForm):
    class Meta:
        model = M.CustomCSS
        fields = [
            "object_classes",
            "before", "current", "after", "hover", "custom",
            "current_phone", "current_tablet", "current_computer", "current_laptop",
            "hover_phone", "hover_tablet", "hover_computer", "hover_laptop",
        ]
        widgets = {
            "before": forms.Textarea(attrs={"rows": 3}),
            "current": forms.Textarea(attrs={"rows": 6}),
            "after": forms.Textarea(attrs={"rows": 3}),
            "hover": forms.Textarea(attrs={"rows": 3}),
            "custom": forms.Textarea(attrs={"rows": 6}),
            "current_phone": forms.Textarea(attrs={"rows": 4}),
            "current_tablet": forms.Textarea(attrs={"rows": 4}),
            "current_computer": forms.Textarea(attrs={"rows": 4}),
            "current_laptop": forms.Textarea(attrs={"rows": 4}),
            "hover_phone": forms.Textarea(attrs={"rows": 3}),
            "hover_tablet": forms.Textarea(attrs={"rows": 3}),
            "hover_computer": forms.Textarea(attrs={"rows": 3}),
            "hover_laptop": forms.Textarea(attrs={"rows": 3}),
        }

# =====================================================================
# Fallback générique pour DYN_* (textarea JSON)
# =====================================================================

class DynamicContentForm(forms.Form):
    data_json = forms.CharField(
        label=_("Données (JSON)"),
        widget=forms.Textarea(attrs={"rows": 18, "spellcheck": "false", "style": "font-family:monospace"}),
        help_text=_("Modifiez la structure JSON du bloc dynamique.")
    )
    def __init__(self, *args, **kwargs):
        initial_data = kwargs.pop("initial_data", {})
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.fields["data_json"].initial = json.dumps(initial_data, ensure_ascii=False, indent=2)
    def clean_data_json(self):
        raw = self.cleaned_data["data_json"]
        try:
            parsed = json.loads(raw) if raw else {}
            if not isinstance(parsed, dict):
                raise forms.ValidationError(_("Le JSON racine doit être un objet ({})."))
            return parsed
        except Exception as e:
            raise forms.ValidationError(_("JSON invalide : %(e)s") % {"e": e})


# =====================================================================
# DYN_* — Forms typés + Inline FormSets + Options
# =====================================================================

# ---- 1) FAQ ----------------------------------------------------------

class FAQItemForm(forms.ModelForm):
    class Meta:
        model = DynFAQItem
        fields = ['title', 'answer', 'open', 'order']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'answer': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
        }

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        if "order" in self.fields:
            self.fields["order"].required = False
            self.fields["order"].widget = forms.HiddenInput()


FAQItemFormSet = inlineformset_factory(
    parent_model=Content, model=DynFAQItem,
    form=FAQItemForm, extra=0, can_delete=True, can_order=True,
    fields=['title', 'answer', 'open', 'order'],
    formset=OrderedInlineFormSet,

)

TITLE_TAG_CHOICES = [(f"h{i}", f"H{i}") for i in range(1, 7)]

class FAQOptionsForm(forms.Form):

    multiple = forms.BooleanField(required=False, initial=False, label=_("Autoriser plusieurs panneaux ouverts"))

    title_tag = forms.ChoiceField(
        choices=TITLE_TAG_CHOICES,
        initial="h4",
        label=_("Niveau de titre (H1–H6)"),
        help_text=_("Choisit la balise de titre utilisée pour chaque question (H1 à H6).")
    )

    main_title = forms.CharField(

        max_length=300,
        required=False,
        label=_("Titre principal"),

    )
    main_title_tag = forms.ChoiceField(
        choices=TITLE_TAG_CHOICES,
        initial="h3",
        label=_("Niveau de titre principal (H1–H6)"),
        help_text=_("Choisit la balise de titre principal utilisée (H1 à H6).")
    )

    def clean_title_tag(self):
        v = (self.cleaned_data.get("title_tag") or "").lower()
        if v not in {f"h{i}" for i in range(1, 7)}:
            raise forms.ValidationError(_("Balise de titre invalide."))
        return v

    def clean_main_title_tag(self):
        v = (self.cleaned_data.get("main_title_tag") or "").lower()
        if v not in {f"h{i}" for i in range(1, 7)}:
            raise forms.ValidationError(_("Balise de titre principal invalide."))
        return v

# ---- 2) Tabs ---------------------------------------------------------

class TabItemForm(forms.ModelForm):
    class Meta:
        model = DynTabItem
        fields = ['label', 'body', 'order']
        widgets = {
            'label': forms.TextInput(attrs={'class': 'form-control'}),
            'body': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
        }

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        if "order" in self.fields:
            self.fields["order"].required = False
            self.fields["order"].widget = forms.HiddenInput()

TabItemFormSet = inlineformset_factory(
    parent_model=Content, model=DynTabItem,
    form=TabItemForm, extra=0, can_delete=True, can_order=True,
    fields=['label', 'body', 'order'],
    formset=OrderedInlineFormSet
)

class TabsOptionsForm(forms.Form):
    active = forms.IntegerField(required=False, min_value=0, initial=0, label=_("Onglet actif par défaut"))


# ---- 3) Carousel -----------------------------------------------------

class CarouselSlideForm(forms.ModelForm):
    """Form d'un slide : édite les champs texte + SOUS-FORM image (full_size)."""
    class Meta:
        model = DynCarouselSlide
        fields = ['alt', 'caption', 'href', 'open_in_new_tab', 'order', 'object_position']  # PAS 'image' ni 'external_src'
        widgets = {
            'alt': forms.TextInput(attrs={'class': 'form-control'}),
            'caption': forms.TextInput(attrs={'class': 'form-control'}),
            'href': forms.URLInput(attrs={'class': 'form-control', 'placeholder': _('Lien au clic (optionnel)')}),
            'order': forms.HiddenInput(),
            'object_position': forms.TextInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        data  = kwargs.get('data')
        files = kwargs.get('files')
        super().__init__(*args, **kwargs)

        # Sous-formulaire image, lié à l'ImageContent existant (ou nouveau si création)
        self.image_form = ImageForm(
            data=data,
            files=files,
            prefix=f"{self.prefix}-img",
            instance=(self.instance.image if getattr(self.instance, "image_id", None) else ImageContent())
        )

    def is_valid(self):
        return super().is_valid() and self.image_form.is_valid()

    def save(self, commit=True):
        # 1) Sauver/mettre à jour l'image via le sous-form (gère ClearableFileInput)
        img = self.image_form.save(commit=True)  # -> crée ou met à jour ImageContent(full_size)
        # 2) Lier l'image au slide et sauver le slide
        inst = super().save(commit=False)
        inst.image = img if img and img.pk else None
        if commit:
            inst.save()
        return inst


CarouselSlideFormSet = inlineformset_factory(
    parent_model=Content,
    model=DynCarouselSlide,
    form=CarouselSlideForm,
    extra=0,
    can_delete=True,
    can_order=True,
    formset=OrderedInlineFormSet
)

class MultiFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True

class CarouselBulkUploadForm(forms.Form):
    # 2) ImageField (valide côté serveur) + widget multiple
    images = forms.ImageField(
        required=False,
        widget=MultiFileInput(attrs={'accept': 'image/*'})
    )

    # 3) Récupérer la VRAIE liste de fichiers
    def clean_images(self):
        field_name = self.add_prefix('images')
        return self.files.getlist('images') or []


class CarouselOptionsForm(forms.Form):
    autoplay = forms.BooleanField(required=False, initial=True, label=_("Lecture automatique"))
    interval = forms.IntegerField(required=False, min_value=500, initial=5000, label=_("Intervalle (ms)"))
    hide_label = forms.BooleanField(required=False, initial=True, label=_("Cacher la légende"))


# ---- 4) Progress / Timeline -----------------------------------------

class ProgressStepForm(forms.ModelForm):
    class Meta:
        model = DynProgressStep
        fields = ['label', 'done', 'order']
        widgets = {
            'label': forms.TextInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        if "order" in self.fields:
            self.fields["order"].required = False
            self.fields["order"].widget = forms.HiddenInput()


ProgressStepFormSet = inlineformset_factory(
    parent_model=Content, model=DynProgressStep,
    form=ProgressStepForm, extra=0, can_delete=True, can_order=True,
    fields=['label', 'done', 'order'],
    formset=OrderedInlineFormSet
)

class ProgressOptionsForm(forms.Form):
    progress = forms.FloatField(required=False, min_value=0, max_value=1, initial=0.5, label=_("Progression (0 → 1)"))


# ---- 5) & 10) Testimonials (slider & grid) --------------------------

class TestimonialItemForm(forms.ModelForm):
    class Meta:
        model = DynTestimonialItem
        fields = ['quote', 'author', 'role', 'avatar', 'order']
        widgets = {
            'quote': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'author': forms.TextInput(attrs={'class': 'form-control'}),
            'role': forms.TextInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        if "order" in self.fields:
            self.fields["order"].required = False
            self.fields["order"].widget = forms.HiddenInput()


TestimonialItemFormSet = inlineformset_factory(
    parent_model=Content, model=DynTestimonialItem,
    form=TestimonialItemForm, extra=0, can_delete=True, can_order=True,
    fields=['quote', 'author', 'role', 'avatar', 'order'],
    formset=OrderedInlineFormSet
)

class TestimonialsSliderOptionsForm(forms.Form):
    autoplay = forms.BooleanField(required=False, initial=True, label=_("Lecture automatique"))
    interval = forms.IntegerField(required=False, min_value=500, initial=7000, label=_("Intervalle (ms)"))

class TestimonialsGridOptionsForm(forms.Form):
    perRow = forms.IntegerField(required=False, min_value=1, max_value=6, initial=3, label=_("Éléments par rotation"))
    rotate = forms.BooleanField(required=False, initial=True, label=_("Rotation automatique"))
    interval = forms.IntegerField(required=False, min_value=500, initial=6000, label=_("Intervalle (ms)"))


# ---- 6) Live Filter --------------------------------------------------

class LiveFilterItemForm(forms.ModelForm):
    class Meta:
        model = DynLiveFilterItem
        fields = ['title', 'category', 'description', 'order']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'category': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        if "order" in self.fields:
            self.fields["order"].required = False
            self.fields["order"].widget = forms.HiddenInput()


LiveFilterItemFormSet = inlineformset_factory(
    parent_model=Content, model=DynLiveFilterItem,
    form=LiveFilterItemForm, extra=1, can_delete=True, can_order=True,
    fields=['title', 'category', 'description', 'order'],
    formset=OrderedInlineFormSet
)

class LiveFilterOptionsForm(forms.Form):
    keys = forms.CharField(
        required=False, initial="title,category",
        help_text=_("Clés sur lesquelles filtrer (séparées par des virgules).")
    )
    def clean_keys(self):
        raw = (self.cleaned_data.get('keys') or '').strip()
        return [k.strip() for k in raw.split(',') if k.strip()]


# ---- 7) Countdown ----------------------------------------------------

class CountdownOptionsForm(forms.Form):
    deadline = forms.DateTimeField(
        input_formats=['%Y-%m-%d %H:%M', '%Y-%m-%dT%H:%M', '%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S'],
        label=_("Échéance"),
        help_text=_("Format : 2025-12-31 23:59")
    )


# ---- 8) Accordion avancé --------------------------------------------

class AccordionSectionForm(forms.ModelForm):
    class Meta:
        model = DynAccordionSection
        fields = ['title', 'open', 'order']
        widgets = {'title': forms.TextInput(attrs={'class': 'form-control'})}

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        if "order" in self.fields:
            self.fields["order"].required = False
            self.fields["order"].widget = forms.HiddenInput()


AccordionSectionFormSet = inlineformset_factory(
    parent_model=Content, model=DynAccordionSection,
    form=AccordionSectionForm, extra=0, can_delete=True, can_order=True,
    fields=['title', 'open', 'order'],
    formset=OrderedInlineFormSet
)

class AccordionChildForm(forms.ModelForm):
    class Meta:
        model = DynAccordionChild
        fields = ['title', 'body', 'open', 'order']
        widgets = {'title': forms.TextInput(attrs={'class': 'form-control'}),
                   'body': forms.Textarea(attrs={'class': 'form-control', 'rows': 3})}

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        if "order" in self.fields:
            self.fields["order"].required = False
            self.fields["order"].widget = forms.HiddenInput()


AccordionChildFormSetFactory = lambda section: inlineformset_factory(
    parent_model=DynAccordionSection, model=DynAccordionChild,
    form=AccordionChildForm, extra=0, can_delete=True, can_order=True,
    fields=['title', 'body', 'open', 'order'],
    formset=OrderedInlineFormSet
)(instance=section, prefix=f"accch_{section.pk if section.pk else 'new'}")


# ---- 9) Pricing table ------------------------------------------------

class PricingPlanForm(forms.ModelForm):
    class Meta:
        model = DynPricingPlan
        fields = ['name', 'price_monthly', 'price_yearly', 'popular', 'cta_label', 'cta_href', 'order']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'cta_label': forms.TextInput(attrs={'class': 'form-control'}),
            'cta_href': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'https://...'}),
        }

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        if "order" in self.fields:
            self.fields["order"].required = False
            self.fields["order"].widget = forms.HiddenInput()


PricingPlanFormSet = inlineformset_factory(
    parent_model=Content, model=DynPricingPlan,
    form=PricingPlanForm, extra=0, can_delete=True, can_order=True,
    fields=['name', 'price_monthly', 'price_yearly', 'popular', 'cta_label', 'cta_href', 'order'],
    formset=OrderedInlineFormSet
)

class PricingFeatureForm(forms.ModelForm):
    class Meta:
        model = DynPricingFeature
        fields = ['label', 'order']
        widgets = {'label': forms.TextInput(attrs={'class': 'form-control'})}

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        if "order" in self.fields:
            self.fields["order"].required = False
            self.fields["order"].widget = forms.HiddenInput()


# Comme pour l'accordéon : formset enfants par plan (dans les vues)
PricingFeatureFormSetFactory = lambda plan: inlineformset_factory(
    parent_model=DynPricingPlan, model=DynPricingFeature,
    form=PricingFeatureForm, extra=0, can_delete=True, can_order=True,
    fields=['label', 'order'],
    formset=OrderedInlineFormSet
)(instance=plan, prefix=f"plf_{plan.pk if plan.pk else 'new'}")

class PricingOptionsForm(forms.Form):
    yearly = forms.BooleanField(required=False, initial=False, label=_("Afficher tarifs annuels par défaut"))


# ---- 10) Testimonials grid → (partagé plus haut) --------------------


# ---- 11) Countdown + CTA --------------------------------------------

class CountdownCTAOptionsForm(CountdownOptionsForm):
    ctaText = forms.CharField(required=False, initial="Réserver", label=_("Texte du bouton"))
    ctaHref = forms.URLField(required=False, label=_("Lien du bouton"))


# ---- 12) Galerie filtrable ------------------------------------------

class GalleryItemForm(forms.ModelForm):
    class Meta:
        model = DynGalleryItem
        fields = ['category', 'title', 'order']  # pas 'image' ici
        widgets = {
            'category': forms.TextInput(attrs={'class': 'form-control'}),
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'order': forms.HiddenInput(),

        }

    def __init__(self, *args, **kwargs):
        data  = kwargs.get('data')
        files = kwargs.get('files')
        super().__init__(*args, **kwargs)
        # sous-form image aligné sur Carousel
        self.image_form = ImageForm(
            data=data,
            files=files,
            prefix=f"{self.prefix}-img",
            instance=(self.instance.image if getattr(self.instance, "image_id", None) else ImageContent())
        )
        if 'order' in self.fields:
            self.fields['order'].required = False

    def is_valid(self):
        ok_parent = super().is_valid()
        ok_img = self.image_form.is_valid()
        # Exiger une image si création (ou si aucune image n'existe encore)
        if ok_parent:
            has_existing = bool(getattr(self.instance, 'image_id', None))
            has_new = bool(self.image_form.cleaned_data.get('original_image')) if ok_img else False
            if not has_existing and not has_new:
                ok_img = False
                # lever une erreur lisible côté parent (non-field error)
                self.add_error(None, _("Veuillez sélectionner une image."))
        if not ok_img and not self.errors.get('__all__'):
            self.add_error(None, _("Image invalide."))
        return ok_parent and ok_img

    def save(self, commit=True):
        # Sauver/MAJ l'image via le sous-form
        img = self.image_form.save(commit=True)  # -> original_image + dérivés WEBP
        inst = super().save(commit=False)

        # Lier l'image (si un nouveau fichier est fourni ou si instance déjà liée)
        if img and img.pk:
            # purge éventuelle de l’ancienne si on change
            if getattr(inst, 'image_id', None) and inst.image_id != img.pk:
                try:
                    inst.image.delete()
                except Exception:
                    pass
            inst.image = img

        if commit:
            inst.save()
        return inst


GalleryItemFormSet = inlineformset_factory(
    parent_model=Content,
    model=DynGalleryItem,
    form=GalleryItemForm,
    extra=0,
    can_delete=True,
    can_order=True,
    fields=['category', 'title', 'order'],  # on laisse pour l'admin list
    formset=OrderedInlineFormSet,
)


class GalleryOptionsForm(forms.Form):
    categories = forms.CharField(
        required=False,
        initial="all,nature,portrait",
        help_text=_("Catégories séparées par des virgules (inclure 'all' si souhaité).")
    )
    def clean_categories(self):
        raw = (self.cleaned_data.get('categories') or '').strip()
        return [c.strip() for c in raw.split(',') if c.strip()]

# ---- 13) Stepper -----------------------------------------------------

class StepperStepForm(forms.ModelForm):
    class Meta:
        model = DynStepperStep
        fields = ['title', 'body', 'order']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'body': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        if "order" in self.fields:
            self.fields["order"].required = False
            self.fields["order"].widget = forms.HiddenInput()


StepperStepFormSet = inlineformset_factory(
    parent_model=Content, model=DynStepperStep,
    form=StepperStepForm, extra=0, can_delete=True, can_order=True,
    fields=['title', 'body', 'order'],
    formset=OrderedInlineFormSet
)

class StepperOptionsForm(forms.Form):
    start = forms.IntegerField(required=False, min_value=0, initial=0, label=_("Étape active par défaut"))


# ---- 14) Rating ------------------------------------------------------

class RatingOptionsForm(forms.Form):
    rating = forms.FloatField(required=False, min_value=0, initial=4.0, label=_("Note"))
    count = forms.IntegerField(required=False, min_value=0, initial=0, label=_("Nombre d’avis"))
    max = forms.IntegerField(required=False, min_value=1, initial=5, label=_("Maximum d’étoiles"))
    editable = forms.BooleanField(required=False, initial=False, label=_("Éditable par l’utilisateur"))
# ---- 14/15) Resource Config -------------------------------------------
class DynResourceConfigForm(forms.ModelForm):
    class Meta:
        model = M.DynResourceConfig
        fields = [
            'source_type', 'product_type', 'custom_object_model',
            'category', 'sub_category',
            'limit', 'interval',
            'columns_computer', 'columns_laptop', 'columns_tablet', 'columns_phone',
            'button_label', 'load_more_label'
        ]
        widgets = {
            'source_type': forms.Select(attrs={'class': 'form-select'}),
            'product_type': forms.Select(attrs={'class': 'form-select'}),
            'custom_object_model': forms.Select(attrs={'class': 'form-select'}),
            'category': forms.Select(attrs={'class': 'form-select'}),
            'sub_category': forms.Select(attrs={'class': 'form-select'}),
            'limit': forms.NumberInput(attrs={'class': 'form-control'}),
            'interval': forms.NumberInput(attrs={'class': 'form-control'}),
            'columns_computer': forms.NumberInput(attrs={'class': 'form-control'}),
            'columns_laptop': forms.NumberInput(attrs={'class': 'form-control'}),
            'columns_tablet': forms.NumberInput(attrs={'class': 'form-control'}),
            'columns_phone': forms.NumberInput(attrs={'class': 'form-control'}),
            'button_label': forms.TextInput(attrs={'class': 'form-control'}),
            'load_more_label': forms.TextInput(attrs={'class': 'form-control'}),
        }
