from django.db import models
from django.utils.translation import gettext_lazy as _

class PaymentGateway(models.Model):
    GATEWAY_CHOICES = (
        ('stripe', 'Stripe'),
    )

    name = models.CharField(_("Nom"), max_length=100)
    code = models.SlugField(_("Code"), unique=True, choices=GATEWAY_CHOICES, default='stripe', help_text=_("Identifiant unique (ex: stripe)"))
    is_active = models.BooleanField(_("Actif"), default=False)
    
    # API Keys
    api_key = models.CharField(_("Clé API publique"), max_length=255, blank=True)
    secret_key = models.CharField(_("Clé secrète"), max_length=255, blank=True)
    webhook_secret = models.CharField(_("Secret Webhook"), max_length=255, blank=True)
    
    test_mode = models.BooleanField(_("Mode Test"), default=True)

    class Meta:
        verbose_name = _("Moyen de paiement")
        verbose_name_plural = _("Moyens de paiement")

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if self.is_active:
            # Ensure only this gateway is active
            PaymentGateway.objects.filter(is_active=True).exclude(pk=self.pk).update(is_active=False)
        super().save(*args, **kwargs)
