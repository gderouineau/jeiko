"""
Abonnements Stripe : un produit payé chaque mois ou chaque année, par
prélèvement automatique (`Product.abonnement`, ou la déclinaison choisie
pour proposer les deux modes). Dans toute boutique JEIKO ; sur jeiko.fr, il
délivre aussi des licences.

Le parcours
-----------
Le client passe par le tunnel ordinaire (panier, coordonnées, compte) ; à
l'étape du paiement, au lieu d'un formulaire de carte, il part sur la page
de paiement de Stripe (Checkout, mode « subscription »). C'est elle qui gère
la carte, l'authentification forte, l'essai gratuit et, ensuite, les
prélèvements, les relances et le portail où le client change de carte ou
résilie. Ici, on ne fait qu'écouter.

Stripe fait foi
---------------
Chaque événement d'abonnement — souscription, renouvellement, échec,
résiliation — ne sert que de signal : `synchroniser` RELIT l'abonnement chez
Stripe et recopie son état. Les événements arrivent en double et dans le
désordre ; relire l'état courant rend leur ordre indifférent.

Ce que suivent les droits
-------------------------
Tant que l'abonnement est en essai ou payé, ce qu'il ouvre vaut jusqu'à la
fin de la période payée, plus `MARGE` : un prélèvement relancé par Stripe a
le temps d'aboutir sans rien couper. Résilié ou impayé, rien n'est retiré —
les droits arrivent simplement à échéance. Cela vaut pour les licences JEIKO
et l'accès à une formation ; l'accès à un questionnaire, lui, n'a pas de date
de fin dans JEIKO : il reste ouvert.

Chaque prélèvement réel (`invoice.paid`, montant non nul) devient une commande
payée, avec sa facture JEIKO : la première est la commande du tunnel, les
suivantes en sont des copies. Une facture Stripe = une commande, même si
l'événement est rejoué (contrainte d'unicité sur `stripe_invoice_id`).

Ce que ce module ne fait pas : changer d'offre en cours d'abonnement (le
portail Stripe peut le proposer ; un montant qui ne correspond plus à la
commande d'origine est signalé à l'exploitant, pas enregistré), ni
rembourser — un remboursement se fait depuis Stripe, et la licence garde sa
date.
"""
import datetime
import logging
from decimal import Decimal

import stripe
from django.db import IntegrityError, transaction
from django.urls import reverse
from django.utils import timezone

from .models import Abonnement, Order, OrderLine
from .services import mark_order_paid, to_minor_units

logger = logging.getLogger(__name__)

#: Délai laissé après la fin d'une période payée : Stripe relance un
#: prélèvement refusé pendant plusieurs jours.
MARGE = datetime.timedelta(days=7)

#: Statuts Stripe où le client a droit au service.
EN_COURS = ("trialing", "active")


def _id(valeur):
    """Un objet Stripe peut arriver développé ou en simple identifiant."""
    if valeur is None or isinstance(valeur, str):
        return valeur
    return valeur.get("id")


def _date(horodatage):
    return datetime.datetime.fromtimestamp(int(horodatage), tz=datetime.timezone.utc) if horodatage else None


def _fin_de_periode(sub):
    """
    La fin de la période en cours. Depuis l'API Stripe 2025-03-31, elle vit
    sur chaque article de l'abonnement et non plus sur l'abonnement.
    """
    fins = [sub.get("current_period_end"), sub.get("trial_end")]
    for article in (sub.get("items") or {}).get("data") or []:
        fins.append(article.get("current_period_end"))
    fins = [f for f in fins if f]
    return _date(max(fins)) if fins else None


def _abonnement_de_la_facture(invoice):
    """L'abonnement d'une facture : `subscription` jusqu'en 2025, `parent` depuis."""
    ancien = _id(invoice.get("subscription"))
    if ancien:
        return ancien
    details = ((invoice.get("parent") or {}).get("subscription_details") or {})
    return _id(details.get("subscription"))


def _stripe():
    from jeiko.payments.services.stripe import StripeService

    service = StripeService()
    if not service.gateway or not service.gateway.is_active:
        raise RuntimeError("La passerelle Stripe n'est pas active.")
    return service


def essai_offert(user, produit):
    """
    Jours d'essai accordés à ce compte : ceux du produit, une seule fois —
    jamais à un compte qui a déjà eu un abonnement ou une licence.
    """
    if not produit.abonnement_essai_jours:
        return 0
    if Abonnement.objects.filter(user=user).exists() or user.licences.exists():
        return 0
    return produit.abonnement_essai_jours


def ouvrir_la_session(request, order):
    """
    La page de paiement Stripe pour la commande d'un abonnement ; rend son
    adresse. La commande vient d'être préparée (`preparer_commande`), qui
    garantit une seule ligne, sans code ni port.
    """
    ligne = order.lines.select_related("product", "variant").get()
    produit = ligne.product
    devise = order.currency.lower()
    _stripe()

    # Une seule unité au total de la commande : le montant prélevé est
    # exactement celui de la commande — au centime, quelle que soit la
    # quantité (pack de plusieurs licences compris).
    nom = ligne.label if ligne.quantity == 1 else f"{ligne.quantity} × {ligne.label}"
    abonnement = {"metadata": {"order_id": str(order.pk)}}
    essai = essai_offert(order.user, produit)
    if essai:
        abonnement["trial_period_days"] = essai
    parametres = {
        "mode": "subscription",
        "line_items": [{
            "price_data": {
                "currency": devise,
                "unit_amount": to_minor_units(order.total_ttc, devise),
                "recurring": {"interval": produit.intervalle(ligne.variant)},
                "product_data": {"name": nom[:250]},
            },
            "quantity": 1,
        }],
        "client_reference_id": str(order.pk),
        "metadata": {"order_id": str(order.pk)},
        "subscription_data": abonnement,
        "success_url": request.build_absolute_uri(reverse("jeiko_payments_client:abonnement_retour"))
                       + "?session_id={CHECKOUT_SESSION_ID}",
        "cancel_url": request.build_absolute_uri(reverse("jeiko_payments_client:payment")),
    }
    # Un client qui a déjà un abonnement garde sa fiche Stripe : un seul
    # portail pour tous ses abonnements, sa carte déjà connue.
    client = (Abonnement.objects.filter(user=order.user).exclude(stripe_customer_id="")
              .values_list("stripe_customer_id", flat=True).first())
    if client:
        parametres["customer"] = client
    else:
        parametres["customer_email"] = order.user.email

    from jeiko.payments.services.stripe import StripeService

    session = stripe.checkout.Session.create(
        **parametres,
        idempotency_key=StripeService.cle_d_idempotence(
            f"abonnement-{essai}", order.pk, order.total_ttc, devise),
    )
    return session["url"]


def synchroniser(subscription_id):
    """
    Recopie l'état d'un abonnement Stripe et met ses licences à jour. Rend
    l'`Abonnement`, ou None s'il n'est pas né d'une commande de ce site.
    """
    _stripe()
    sub = stripe.Subscription.retrieve(subscription_id)
    order_id = str((sub.get("metadata") or {}).get("order_id") or "")
    order = Order.objects.filter(pk=order_id).first() if order_id.isdigit() else None
    if order is None:
        logger.info("Abonnement Stripe %s sans commande de ce site : ignoré.", subscription_id)
        return None
    ligne = order.lines.select_related("product").first()

    with transaction.atomic():
        try:
            abo, __ = Abonnement.objects.get_or_create(
                stripe_subscription_id=sub["id"],
                defaults={"user": order.user, "commande": order,
                          "product": ligne.product if ligne else None,
                          "quantite": ligne.quantity if ligne else 1},
            )
        except IntegrityError:
            abo = Abonnement.objects.get(stripe_subscription_id=sub["id"])
        abo = Abonnement.objects.select_for_update().get(pk=abo.pk)
        abo.statut = sub.get("status") or ""
        abo.stripe_customer_id = _id(sub.get("customer")) or abo.stripe_customer_id
        abo.fin_de_periode = _fin_de_periode(sub)
        abo.resilie_en_fin_de_periode = bool(sub.get("cancel_at_period_end") or sub.get("cancel_at"))
        abo.save()

        # La commande a quitté le panier : sans cela, le client qui revient
        # à la boutique pendant l'essai retrouverait l'abonnement à payer.
        if order.cart_id and not order.cart.is_locked:
            order.cart.is_locked = True
            order.cart.save(update_fields=["is_locked", "updated_at"])

        if abo.statut in EN_COURS and abo.product is not None and abo.fin_de_periode is not None:
            _suivre_les_acces(abo)
            _suivre_les_licences(abo)
    return abo


def _suivre_les_acces(abo):
    """Formation et questionnaire du produit : ouverts jusqu'à la fin de la période payée."""
    produit, user = abo.product, abo.user
    if user is None:
        return
    if produit.linked_expert_test_id:
        from jeiko.questionnaires_expert.models import UserTestAccess

        UserTestAccess.objects.get_or_create(user=user, test_id=produit.linked_expert_test_id,
                                             defaults={"source": "PURCHASE"})
    if produit.linked_course_id:
        from jeiko.courses.models import CourseEnrollment

        fin = abo.fin_de_periode + MARGE
        inscription, creee = CourseEnrollment.objects.select_for_update().get_or_create(
            user=user, course_id=produit.linked_course_id,
            defaults={"status": CourseEnrollment.STATUS_ACTIVE, "has_payed": True,
                      "order": abo.commande, "access_expires_at": fin},
        )
        # Un accès à vie (achat unique antérieur) le reste ; sinon, la date
        # avance avec la période — elle ne recule jamais.
        if not creee and inscription.access_expires_at is not None and inscription.access_expires_at < fin:
            inscription.access_expires_at = fin
            inscription.has_payed = True
            if inscription.status == CourseEnrollment.STATUS_SUSPENDED:
                inscription.status = CourseEnrollment.STATUS_ACTIVE
            inscription.save(update_fields=["access_expires_at", "has_payed", "status", "updated_at"])


def _suivre_les_licences(abo):
    """Crée les licences qui manquent ; repousse leur fin à la période payée."""
    from jeiko.licences.views import serveur_allume

    produit = abo.product
    if not produit.licence_jeiko or not serveur_allume():
        return
    from jeiko.administration.models import Licence
    from jeiko.licences import service
    from jeiko.licences.boutique import _envoyer

    fin = timezone.localtime(abo.fin_de_periode).date() + MARGE
    licences = list(Licence.objects.select_for_update().filter(abonnement=abo))
    for licence in licences:
        if licence.expire_le is not None and licence.expire_le < fin:
            licence.expire_le = fin
            licence.save(update_fields=["expire_le"])

    voulues = abo.quantite * produit.licence_cles
    utilisateur = abo.user
    commande = abo.commande
    titulaire = ((commande.billing_name if commande else "")
                 or (utilisateur.get_full_name() if utilisateur else "")
                 or (utilisateur.email if utilisateur else "") or "—")
    nouvelles = []
    for __ in range(voulues - len(licences)):
        licence, __cle = service.creer(
            titulaire=titulaire[:200], email=(utilisateur.email if utilisateur else ""),
            expire_le=fin, compte=utilisateur, commande=commande,
            notes=f"Abonnement {abo.stripe_subscription_id}"[:500],
        )
        licence.abonnement = abo
        licence.save(update_fields=["abonnement"])
        nouvelles.append((licence.pk, "creee"))
    if nouvelles:
        transaction.on_commit(lambda: _envoyer(nouvelles))


def enregistrer_le_paiement(invoice):
    """
    Un prélèvement réussi : l'abonnement est resynchronisé (licences
    prolongées) et le paiement devient une commande payée, avec sa facture.
    Une facture à zéro — celle qui ouvre un essai — n'est pas un paiement.
    """
    subscription_id = _abonnement_de_la_facture(invoice)
    if not subscription_id:
        return None
    abo = synchroniser(subscription_id)
    if abo is None or abo.commande_id is None or not invoice.get("amount_paid"):
        return None

    with transaction.atomic():
        # Verrou sur la commande d'origine AVANT de chercher la facture : deux
        # livraisons simultanées du même événement passent l'une après l'autre.
        origine = Order.objects.select_for_update().get(pk=abo.commande_id)
        deja = Order.objects.filter(stripe_invoice_id=invoice["id"]).first()
        if deja is not None:
            return deja

        devise = (invoice.get("currency") or origine.currency).lower()
        if int(invoice["amount_paid"]) != to_minor_units(origine.total_ttc, devise):
            transaction.on_commit(lambda: _signaler_un_montant_inattendu(origine.pk, invoice))
            return None

        premiere = (origine.payment_status == Order.PAYMENT_STATUS_PENDING
                    and not origine.stripe_invoice_id)
        commande = origine if premiere else _copie(origine)
        commande.stripe_invoice_id = invoice["id"]
        commande.save(update_fields=["stripe_invoice_id", "updated_at"])
        mark_order_paid(commande, source="stripe:abonnement")
    commande.refresh_from_db()
    return commande


def _copie(origine):
    """Une nouvelle commande pour un renouvellement : mêmes lignes, mêmes montants, mêmes coordonnées."""
    from .services import CHAMPS_ADRESSE

    copie = Order.objects.create(
        user=origine.user, currency=origine.currency,
        total_ht=origine.total_ht, total_tva=origine.total_tva, total_ttc=origine.total_ttc,
        vat_breakdown=origine.vat_breakdown,
        **{champ: getattr(origine, champ) for champ in CHAMPS_ADRESSE if champ != "customer_note"},
    )
    OrderLine.objects.bulk_create(
        OrderLine(order=copie, product=l.product, variant=l.variant, label=l.label, sku=l.sku,
                  quantity=l.quantity, unit_price_ht=l.unit_price_ht, tax_rate=l.tax_rate)
        for l in origine.lines.all()
    )
    return copie


def _signaler_un_montant_inattendu(order_pk, invoice):
    try:
        from jeiko.emailing.admin_alerts import notifier_erreur

        montant = Decimal(int(invoice.get("amount_paid") or 0)) / 100
        notifier_erreur(
            "Abonnement : prélèvement d'un montant inattendu",
            f"La facture Stripe {invoice.get('id')} ({montant} {str(invoice.get('currency', '')).upper()}) "
            f"ne correspond pas au total de la commande #{order_pk} d'origine. Les licences sont "
            f"prolongées, mais aucune commande n'est enregistrée pour ce paiement : à vérifier "
            f"dans Stripe (changement d'offre depuis le portail ?).",
        )
    except Exception:
        logger.exception("Alerte de montant d'abonnement impossible (commande #%s)", order_pk)


def adresse_du_portail(user, retour):
    """Le portail Stripe du client (carte, factures, résiliation) ; None s'il n'a pas d'abonnement."""
    client = (Abonnement.objects.filter(user=user).exclude(stripe_customer_id="")
              .values_list("stripe_customer_id", flat=True).first())
    if not client:
        return None
    _stripe()
    return stripe.billing_portal.Session.create(customer=client, return_url=retour)["url"]


#: Statuts où Stripe prélève encore, ou prélèvera.
EN_VIE = ("trialing", "active", "past_due", "unpaid", "paused")


def resilier_tout(user):
    """
    Résilie tout de suite chez Stripe les abonnements vivants d'un compte —
    avant l'effacement RGPD : un compte effacé ne doit plus être prélevé.
    Lève si Stripe refuse ; l'effacement n'a alors pas lieu.
    """
    vivants = list(Abonnement.objects.filter(user=user, statut__in=EN_VIE))
    if not vivants:
        return 0
    _stripe()
    for abo in vivants:
        try:
            stripe.Subscription.cancel(abo.stripe_subscription_id)
        except stripe.error.InvalidRequestError as souci:
            # Déjà résilié ou inconnu chez Stripe : rien ne sera prélevé.
            if getattr(souci, "code", "") != "resource_missing":
                raise
        abo.statut = "canceled"
        abo.save(update_fields=["statut", "mis_a_jour_le"])
    return len(vivants)

