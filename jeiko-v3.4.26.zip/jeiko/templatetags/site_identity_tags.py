# apps/core/templatetags/site_identity_tags.py
import json
from django import template
from django.utils.safestring import mark_safe

from jeiko.templatetags.json_extras import JSON_SCRIPT_ESCAPES

register = template.Library()

def _abs_url(request, url, site_url=None):
    if not url:
        return None
    if url.startswith("http://") or url.startswith("https://"):
        return url
    # construit une URL absolue depuis la requête ; fallback sur site_url
    if request:
        return request.build_absolute_uri(url)
    if site_url:
        return f"{site_url.rstrip('/')}/{url.lstrip('/')}"
    return url  # dernier recours


@register.simple_tag(takes_context=True)
def open_graph_image(context, image, fallback_alt=""):
    """Décrit l'image réellement émise par les balises Open Graph.

    L'URL, la largeur et la hauteur viennent du même fichier : on n'annonce
    donc jamais les dimensions de l'original pour servir une variante WebP.
    Les accès au stockage restent tolérants à un ancien fichier manquant.
    """
    if not image:
        return {}

    selected = None
    for field_name in (
        "full_size", "computer_size", "laptop_size", "tablet_size",
        "mobile_size", "original_image",
    ):
        candidate = getattr(image, field_name, None)
        if candidate:
            selected = candidate
            break
    if selected is None:
        return {}

    try:
        path = selected.url
    except (ValueError, OSError, NotImplementedError):
        return {}

    request = context.get("request")
    website = context.get("website_data")
    identity = getattr(website, "identity", None) if website else None
    site_url = getattr(identity, "url", None) if identity else None
    result = {
        "url": _abs_url(request, path, site_url),
        "alt": (getattr(image, "alt", "") or getattr(image, "title", "") or fallback_alt or "").strip(),
    }
    try:
        result["width"] = selected.width
        result["height"] = selected.height
    except (ValueError, OSError, TypeError, AttributeError):
        # Une ancienne entrée dont le fichier a disparu ne doit pas casser le
        # <head>. L'URL/alt restent utiles et la médiathèque permettra de la
        # remplacer ; les nouveaux uploads ont toujours leurs dimensions.
        pass
    return result

@register.simple_tag(takes_context=True)
def site_identity_jsonld(context, website):
    """
    Rend le JSON-LD Organization/LocalBusiness à partir de website.identity.
    - Logo pris depuis website.logo (computer_size -> >=112px).
    """
    request = context.get("request")
    identity = getattr(website, "identity", None)
    if not identity:
        return ""

    # Détermine l'URL de base (home)
    site_url = getattr(identity, "url", None) or getattr(website, "base_url", None)
    if not site_url and request is not None:
        site_url = f"{request.scheme}://{request.get_host()}/"

    if not site_url:
        return ""

    typ = "LocalBusiness" if identity.type == "localbusiness" else "Organization"
    data = {
        "@context": "https://schema.org",
        "@type": typ,
        "@id": f"{site_url.rstrip('/')}/#org",
        "name": identity.name,
        "url": site_url,
    }

    if identity.telephone:
        data["telephone"] = identity.telephone
    if identity.price_range:
        data["priceRange"] = identity.price_range

    # --- LOGO depuis WebSite.logo ---
    logo_obj = getattr(website, "logo", None)
    logo_url = None
    if logo_obj:
        # priorité: computer_size (150x150), fallback full_size
        if getattr(logo_obj, "computer_size", None) and getattr(logo_obj.computer_size, "url", None):
            logo_url = logo_obj.computer_size.url
        elif getattr(logo_obj, "full_size", None) and getattr(logo_obj.full_size, "url", None):
            logo_url = logo_obj.full_size.url

    logo_abs = _abs_url(request, logo_url, site_url) if logo_url else None
    if logo_abs:
        data["logo"] = logo_abs

    # --- sameAs : profils sociaux actifs (renforce le knowledge panel Google) ---
    social_mgr = getattr(website, "social_links", None)
    if social_mgr is not None:
        same_as = [
            link.profile_url.strip()
            for link in social_mgr.filter(is_active=True).order_by("position", "id")
            if (getattr(link, "profile_url", "") or "").strip()
        ]
        if same_as:
            data["sameAs"] = same_as

    # LocalBusiness: adresse & géo
    if typ == "LocalBusiness":
        data["address"] = {
            "@type": "PostalAddress",
            "streetAddress": identity.street_address or "",
            "addressLocality": identity.address_locality or "",
            "addressRegion": identity.address_region or "",
            "postalCode": identity.postal_code or "",
            "addressCountry": (identity.address_country or "").upper(),
        }
        if identity.geo_lat is not None and identity.geo_lng is not None:
            data["geo"] = {
                "@type": "GeoCoordinates",
                "latitude": float(identity.geo_lat),
                "longitude": float(identity.geo_lng),
            }

    # Le résultat est inséré tel quel dans un <script type="application/ld+json">
    # (includes/site_identity.html). `json.dumps` n'échappe ni `<`, ni `>`, ni
    # `&` : un nom de site ou une adresse contenant littéralement `</script>`
    # refermait le bloc et faisait interpréter la suite comme du HTML — sur
    # TOUTES les pages du site, puisque ce bloc est dans base.html.
    #
    # La table vient de json_extras, où vit déjà le filtre `tojson` : une
    # seconde copie divergerait le jour où l'une serait corrigée sans l'autre.
    json_str = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return mark_safe(json_str.translate(JSON_SCRIPT_ESCAPES))
