from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone

User = get_user_model()
CENTIME = Decimal("0.01")


def _montant(valeur):
    """Montant affichable et facturable, arrondi au centime supérieur usuel."""
    return Decimal(valeur or 0).quantize(CENTIME, rounding=ROUND_HALF_UP)



class ShopSettings(models.Model):
    """
    Les réglages de la boutique, pour le site entier.

    Pourquoi ce modèle n'existait pas, et pourquoi il manque
    ---------------------------------------------------------
    La TVA se réglait produit par produit (`Product.tax_rate`), avec un défaut
    par type (`ProductType.default_tax_rate`). Cela suffit tant qu'on a trois
    produits ; passé la dizaine, changer un taux — parce que la loi bouge, ou
    parce qu'on s'était trompé — demande de reprendre chaque fiche, et le
    premier oubli passe inaperçu jusqu'à la facture.

    Il manquait donc l'étage au-dessus : **une valeur de référence pour le
    site**, dont les types héritent quand ils ne disent rien.

    Ce que ce modèle ne fait PAS
    ----------------------------
    Il ne réécrit rien. Un produit ou un type qui porte déjà un taux garde le
    sien : changer ici ne doit pas modifier en silence le prix de commandes en
    cours de préparation. Le taux du site sert de **défaut**, consulté à la
    création d'un type qui n'en précise pas.

    Singleton, comme `MailSettings` : il y a une boutique par site.
    """

    is_online = models.BooleanField(
        default=True,
        verbose_name="Boutique en ligne active",
        help_text=(
            "Désactivée, les fiches, le panier et le paiement ne sont plus "
            "accessibles au public. Les produits et commandes restent conservés."
        ),
    )

    homepage = models.ForeignKey(
        "administration_pages.Page",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="shop_homepage_for",
        verbose_name="Page d’accueil de la boutique",
        help_text=(
            "Une page classique publiée, utilisée à l’adresse /shop/. "
            "Elle n’est pas transformée en page spéciale."
        ),
    )

    prices_include_tax = models.BooleanField(
        default=False,
        verbose_name="Les prix saisis incluent la TVA",
        help_text=(
            "Le formulaire produit convertit alors le montant TTC saisi en "
            "montant HT conservé en base."
        ),
    )

    display_prices_including_tax = models.BooleanField(
        default=True,
        verbose_name="Afficher les prix TTC dans la boutique",
        help_text="Détermine l'affichage public des prix et du panier.",
    )

    default_tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("20.00"),
        verbose_name="TVA par défaut (%)",
        help_text=(
            "Taux appliqué aux nouveaux types de produit qui n'en précisent "
            "pas. Ne modifie aucun produit ni aucune commande existante."
        ),
    )

    currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name="Devise",
        help_text="Code ISO à trois lettres : EUR, CHF, CAD…",
    )

    #: Réservé aux réglages de livraison, à venir. Le champ est posé maintenant
    #: pour que la page existe et se remplisse au fil des besoins plutôt que
    #: d'attendre d'être complète.
    free_shipping_from = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        verbose_name="Livraison offerte à partir de (TTC)",
        help_text="Laisser vide pour ne jamais offrir la livraison.",
    )

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Réglages de la boutique"
        verbose_name_plural = "Réglages de la boutique"

    def __str__(self):
        return "Réglages de la boutique"

    @classmethod
    def get_solo(cls):
        """
        Les réglages du site, créés au premier accès.

        `get_or_create` sur `pk=1` plutôt que `first()` : deux requêtes
        concurrentes sur une page d'administration fraîchement ouverte
        créeraient sinon deux lignes, et la seconde deviendrait invisible.
        """
        objet, _ = cls.objects.get_or_create(pk=1)
        return objet


class DeliveryZone(models.Model):
    """Zone de livraison déclarée dans les réglages de la boutique."""

    settings = models.ForeignKey(
        ShopSettings,
        on_delete=models.CASCADE,
        related_name="delivery_zones",
        verbose_name="Réglages de la boutique",
    )
    code = models.SlugField(
        max_length=50,
        verbose_name="Code",
        help_text="Identifiant interne de la zone (ex : france-metropolitaine).",
    )
    name = models.CharField(max_length=120, verbose_name="Nom de la zone")
    country_codes = models.CharField(
        max_length=500,
        verbose_name="Pays (codes ISO)",
        help_text="Ex : FR, BE, LU. Utiliser * pour tous les pays.",
    )
    postal_code_prefixes = models.CharField(
        max_length=500,
        blank=True,
        verbose_name="Préfixes postaux",
        help_text="Optionnel. Ex : 75, 77, 78. Vide = tout le pays.",
    )
    price_ttc = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name="Frais de livraison (TTC)",
    )
    free_from = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        verbose_name="Gratuite à partir de (TTC)",
        help_text="Laisser vide pour ne jamais offrir cette zone gratuitement.",
    )
    is_active = models.BooleanField(default=True, verbose_name="Zone active")
    position = models.PositiveIntegerField(default=0, verbose_name="Ordre")

    class Meta:
        ordering = ["position", "name", "id"]
        constraints = [
            models.UniqueConstraint(
                fields=("settings", "code"),
                name="shop_delivery_zone_code_unique",
            ),
        ]
        verbose_name = "Zone de livraison"
        verbose_name_plural = "Zones de livraison"

    def __str__(self):
        return self.name

    def matches(self, country_code, postal_code=""):
        """Indique si une adresse appartient à la zone."""
        if not self.is_active:
            return False
        pays = (country_code or "").strip().upper()
        autorises = {
            code.strip().upper()
            for code in (self.country_codes or "").replace(";", ",").split(",")
            if code.strip()
        }
        if "*" not in autorises and pays not in autorises:
            return False
        prefixes = {
            prefix.strip().upper()
            for prefix in (self.postal_code_prefixes or "").replace(";", ",").split(",")
            if prefix.strip()
        }
        if not prefixes:
            return True
        postal = (postal_code or "").strip().upper()
        return any(postal.startswith(prefix) for prefix in prefixes)


class ProductType(models.Model):
    """
    Type métier du produit (couche "conceptuelle") :
    - produit_physique
    - formation_en_ligne
    - seance_1to1
    - abonnement
    etc.

    Chaque ProductType pointe vers un CustomObjectModel qui gère la fiche
    (contenu + template) côté "administration_pages".
    """

    name = models.CharField(
        max_length=150,
        verbose_name="Nom du type de produit",
    )
    code = models.SlugField(
        max_length=100,
        unique=True,
        verbose_name="Code interne",
        help_text="Identifiant technique (ex : produit_physique, formation, seance…).",
    )

    content_model = models.ForeignKey(
        "custom_objects.CustomObjectModel",
        on_delete=models.PROTECT,
        related_name="product_types",
        verbose_name="Modèle de contenu",
        null=True,
        blank=True,
        help_text=(
            "Modèle de contenu (CustomObjectModel) utilisé pour les fiches "
            "de ce type de produit."
        ),
    )

    # Flags fonctionnels
    KIND_PHYSICAL = "physical"
    KIND_COURSE = "course"
    KIND_QUESTIONNAIRE = "questionnaire"
    KIND_APPOINTMENT = "appointment"
    KIND_SERVICE = "service"

    KIND_CHOICES = (
        (KIND_PHYSICAL, "Produit physique"),
        (KIND_COURSE, "Formation en ligne"),
        (KIND_QUESTIONNAIRE, "Questionnaire expert"),
        (KIND_APPOINTMENT, "Rendez-vous / Crédits"),
        (KIND_SERVICE, "Service"),
    )

    kind = models.CharField(
        max_length=20,
        choices=KIND_CHOICES,
        default=KIND_PHYSICAL,
        verbose_name="Nature du produit",
    )

    is_physical = models.BooleanField(
        default=True,
        verbose_name="Produit physique (legacy)",
        help_text="Si coché, le produit nécessite une gestion de stock et de livraison.",
    )
    requires_shipping = models.BooleanField(
        default=True,
        verbose_name="Nécessite une expédition",
        help_text="Ex : colis, lettre. Décoche pour les produits 100 % digitaux.",
    )
    is_subscription = models.BooleanField(
        default=False,
        verbose_name="Abonnement",
        help_text="Produit facturé de manière récurrente.",
    )

    # TVA par défaut (en %)
    default_tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("20.00"),
        verbose_name="TVA par défaut (%)",
    )

    default_currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name="Devise par défaut",
        help_text="Code ISO (ex : EUR, USD).",
    )

    date_created = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Date de création",
    )

    class Meta:
        verbose_name = "Type de produit"
        verbose_name_plural = "Types de produit"
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name


class Product(models.Model):
    """
    Produit vendable (couche e-commerce).
    Il est relié :
      - à un ProductType (logique métier),
      - à un CustomObject (contenu + template).
    """

    type = models.ForeignKey(
        ProductType,
        on_delete=models.PROTECT,
        related_name="products",
        verbose_name="Type de produit",
    )

    content = models.OneToOneField(
        "custom_objects.CustomObject",
        on_delete=models.PROTECT,
        related_name="product",
        verbose_name="Fiche contenu",
        help_text="Objet custom (CustomObject) qui porte la fiche produit et le template.",
    )

    sku = models.CharField(
        max_length=64,
        unique=True,
        verbose_name="Référence (SKU)",
        help_text="Identifiant unique du produit (SKU).",
    )

    is_active = models.BooleanField(
        default=True,
        verbose_name="Actif (vendable)",
    )

    # Prix
    price_ht = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Prix HT",
    )
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("20.00"),
        verbose_name="TVA (%)",
        help_text="Laisse vide pour utiliser la TVA du type (si tu gères ce comportement plus tard).",
    )
    currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name="Devise",
        help_text="Code ISO (ex : EUR, USD).",
    )

    # Stock (simple)
    stock_quantity = models.IntegerField(
        default=0,
        verbose_name="Quantité en stock",
    )
    allow_negative_stock = models.BooleanField(
        default=False,
        verbose_name="Autoriser le stock négatif",
    )

    # Logistique
    weight_kg = models.DecimalField(
        max_digits=7,
        decimal_places=3,
        default=Decimal("0.000"),
        verbose_name="Poids (kg)",
    )

    # Liens spécifiques (selon le kind)
    linked_expert_test = models.ForeignKey(
        "questionnaires_expert.ExpertTest",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Questionnaire lié",
        help_text="Si ce produit vend l'accès à un questionnaire.",
    )
    linked_appointment_type = models.ForeignKey(
        "calendars.AppointmentType",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Type de RDV lié",
        help_text="Si ce produit vend des crédits pour un type de RDV.",
    )
    # Seuil d'alerte de stock, par produit.
    #
    # NULL plutôt qu'une valeur sentinelle (-1) pour dire « pas d'alerte » :
    # rien, dans un entier, ne distingue un drapeau d'un seuil, et quelqu'un
    # finirait par saisir -1 en pensant « une commande en attente ». NULL se lit
    # sans convention à connaître.
    #
    #   NULL -> aucune alerte pour ce produit
    #   0    -> alerte à la rupture
    #   n    -> alerte dès qu'il reste n unités ou moins
    stock_alert_threshold = models.PositiveIntegerField(
        null=True,
        blank=True,
        verbose_name="Seuil d'alerte de stock",
        help_text="Laisser vide pour ne recevoir aucune alerte. 0 = alerte à la rupture.",
    )
    credits_amount = models.IntegerField(
        default=0,
        verbose_name="Crédits offerts",
        help_text="Nombre de crédits/RDV crédités à l'achat.",
    )
    linked_course = models.ForeignKey(
        "courses.Course",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="products",
        verbose_name="Formation liée",
        help_text="Si ce produit donne accès à une formation en ligne.",
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Créé le",
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Mis à jour le",
    )

    class Meta:
        verbose_name = "Produit"
        verbose_name_plural = "Produits"
        ordering = ["sku"]

    def __str__(self) -> str:
        # content.title vient du CustomObject
        return f"{self.sku} – {self.content.title}"

    @property
    def suit_le_stock(self):
        """
        Ce produit s'épuise-t-il ?

        Un pot de cornichons, oui. Une séance de coaching, un abonnement, une
        formation en ligne : non. Ces produits n'ont pas de stock, personne
        n'en saisit, et `stock_quantity` y reste à zéro pour toujours.

        Or zéro était traité comme « épuisé » partout : l'ajout au panier était
        REFUSÉ, la mise à jour du panier ramenait la quantité à zéro et
        supprimait la ligne, et le JSON-LD annonçait `OutOfStock` à Google.
        Autrement dit, **aucun service n'était vendable** tant que personne
        n'avait pensé à cocher « stock négatif autorisé » — un réglage dont le
        nom ne suggère rien de tel.

        Trois notions coexistaient, et c'est ce qui a produit le défaut :

        * `ProductType.requires_shipping` — « nécessite une expédition » ;
        * `ProductType.is_physical` — le même champ en plus ancien, marqué
          « legacy » jusque dans son intitulé ;
        * `Product.allow_negative_stock` — un réglage de dépassement, pas une
          nature.

        Le décrément de stock (`services.py`, à la commande) tranchait déjà sur
        `requires_shipping` — et c'est lui l'autorité, puisque c'est lui qui
        bouge réellement le stock. Le panier, lui, tranchait sur
        `allow_negative_stock` : deux critères pour une même question, d'où un
        panier qui refuse ce que la commande aurait servi sans y toucher.

        On s'aligne donc sur `requires_shipping`, ici et une seule fois.
        """
        return bool(getattr(self.type, "requires_shipping", True))

    @property
    def est_disponible(self):
        """
        Y a-t-il de quoi servir une commande ?

        Toujours vrai pour ce qui ne s'épuise pas. Sinon, le stock tranche —
        ou le dépassement autorisé.
        """
        if not self.suit_le_stock:
            return True
        return (self.stock_quantity or 0) > 0 or self.allow_negative_stock

    def peut_servir(self, quantite):
        """Le même contrôle, pour une quantité donnée."""
        if not self.suit_le_stock or self.allow_negative_stock:
            return True
        return (self.stock_quantity or 0) >= quantite

    @property
    def main_image(self):
        return self.content.main_image

    @property
    def title(self):
        return self.content.title

    @property
    def name(self):
        return self.title

    @property
    def description(self):
        return self.content.description

    @property
    def excerpt(self):
        return self.description

    def get_absolute_url(self):
        return self.content.get_absolute_url()

    def clean(self):
        """
        Sécurité : on impose que le CustomObject utilise bien le CustomObjectModel
        attendu par le ProductType.
        """
        if self.content_id and self.type_id:
            if self.content.model_id != self.type.content_model_id:
                raise ValidationError(
                    {
                        "content": (
                            "Cet objet n'utilise pas le modèle de contenu attendu "
                            "pour ce type de produit."
                        )
                    }
                )

    @property
    def price_ttc(self) -> Decimal:
        return _montant(
            self.price_ht * (Decimal("1.0") + self.tax_rate / Decimal("100.0"))
        )


class ProductImage(models.Model):
    """
    Images liées à un produit.
    On réutilise ton ImageContent de l'app administration_pages.
    """

    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name="images",
        verbose_name="Produit",
    )
    image = models.ForeignKey(
        "administration_pages.ImageContent",
        on_delete=models.PROTECT,
        related_name="product_images",
        verbose_name="Image",
    )
    is_main = models.BooleanField(
        default=False,
        verbose_name="Image principale",
    )
    position = models.PositiveIntegerField(
        default=0,
        verbose_name="Ordre d'affichage",
    )

    class Meta:
        verbose_name = "Image de produit"
        verbose_name_plural = "Images de produit"
        ordering = ["product", "position", "id"]

    def __str__(self) -> str:
        return f"Image {self.product.sku} (pos={self.position})"


class ProductStockMovement(models.Model):
    """
    Historique des mouvements de stock (optionnel mais pratique).
    Ex :
      - commande -1
      - correction inventaire +10
      - retour client +1
    """

    IN = "IN"
    OUT = "OUT"
    MOVEMENT_TYPES = [
        (IN, "Entrée"),
        (OUT, "Sortie"),
    ]

    product = models.ForeignKey(
        Product,
        # Un mouvement est une pièce d'historique, pas un détail jetable du
        # produit. Même une suppression ORM directe doit obliger l'appelant à
        # désactiver le produit ou à traiter explicitement cet historique.
        on_delete=models.PROTECT,
        related_name="stock_movements",
        verbose_name="Produit",
    )
    movement_type = models.CharField(
        max_length=3,
        choices=MOVEMENT_TYPES,
        verbose_name="Type de mouvement",
    )
    quantity = models.IntegerField(
        verbose_name="Quantité",
        help_text="Positive ou négative selon ton usage, mais le type IN/OUT est là pour clarifier.",
    )
    reason = models.CharField(
        max_length=255,
        blank=True,
        verbose_name="Raison",
        help_text="Ex : commande #123, ajustement, retour, etc.",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Date du mouvement",
    )
    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="stock_movements",
        verbose_name="Utilisateur",
    )

    class Meta:
        verbose_name = "Mouvement de stock"
        verbose_name_plural = "Mouvements de stock"
        ordering = ["-created_at", "-id"]

    def __str__(self) -> str:
        return f"{self.product.sku} – {self.movement_type} {self.quantity}"


# ----------------------------------------------------------------------
#  Panier (Cart) + Commandes (Order)
#  La partie paiement ira dans l'app "payments" (FK depuis Order).
# ----------------------------------------------------------------------


class Cart(models.Model):
    """
    Panier simple :
    - lié éventuellement à un user,
    - ou à une session (anonyme).
    """

    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="carts",
        verbose_name="Utilisateur",
    )
    session_key = models.CharField(
        max_length=40,
        blank=True,
        db_index=True,
        verbose_name="Session",
        help_text="Clé de session pour les paniers anonymes.",
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Créé le",
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Mis à jour le",
    )

    is_locked = models.BooleanField(
        default=False,
        verbose_name="Verrouillé",
        help_text="Un panier verrouillé ne peut plus être modifié (ex : transformé en commande).",
    )

    class Meta:
        verbose_name = "Panier"
        verbose_name_plural = "Paniers"
        ordering = ["-updated_at", "-id"]

    def __str__(self) -> str:
        if self.user:
            return f"Panier #{self.pk} – {self.user}"
        return f"Panier #{self.pk} (session={self.session_key})"


class CartItem(models.Model):
    """
    Ligne de panier.
    On snapshot le prix au moment où on ajoute l'article.
    """

    cart = models.ForeignKey(
        Cart,
        on_delete=models.CASCADE,
        related_name="items",
        verbose_name="Panier",
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name="cart_items",
        verbose_name="Produit",
    )
    quantity = models.PositiveIntegerField(
        default=1,
        verbose_name="Quantité",
    )

    unit_price_ht = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Prix unitaire HT (snapshot)",
    )
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        verbose_name="TVA (%)",
    )
    currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name="Devise",
    )

    class Meta:
        verbose_name = "Ligne de panier"
        verbose_name_plural = "Lignes de panier"

    def __str__(self) -> str:
        return f"{self.product.sku} x {self.quantity} (panier #{self.cart_id})"

    @property
    def total_ht(self) -> Decimal:
        return _montant(self.unit_price_ht * self.quantity)

    @property
    def unit_price_ttc(self) -> Decimal:
        return _montant(
            self.unit_price_ht * (Decimal("1.0") + self.tax_rate / Decimal("100.0"))
        )

    @property
    def total_ttc(self) -> Decimal:
        return _montant(
            self.total_ht * (Decimal("1.0") + self.tax_rate / Decimal("100.0"))
        )


class Order(models.Model):
    """
    Commande client.
    La relation avec les paiements (Stripe, etc.) se fera dans l'app payments.
    """

    ORDER_STATUS_DRAFT = "draft"
    ORDER_STATUS_CONFIRMED = "confirmed"
    ORDER_STATUS_PROCESSING = "processing"
    ORDER_STATUS_SHIPPED = "shipped"
    ORDER_STATUS_COMPLETED = "completed"
    ORDER_STATUS_CANCELLED = "cancelled"

    ORDER_STATUS_CHOICES = [
        (ORDER_STATUS_DRAFT, "Brouillon"),
        (ORDER_STATUS_CONFIRMED, "Confirmée"),
        (ORDER_STATUS_PROCESSING, "En cours de traitement"),
        (ORDER_STATUS_SHIPPED, "Expédiée"),
        (ORDER_STATUS_COMPLETED, "Terminée"),
        (ORDER_STATUS_CANCELLED, "Annulée"),
    ]

    PAYMENT_STATUS_PENDING = "pending"
    PAYMENT_STATUS_PAID = "paid"
    PAYMENT_STATUS_FAILED = "failed"
    PAYMENT_STATUS_REFUNDED = "refunded"

    PAYMENT_STATUS_CHOICES = [
        (PAYMENT_STATUS_PENDING, "En attente"),
        (PAYMENT_STATUS_PAID, "Payée"),
        (PAYMENT_STATUS_FAILED, "Échouée"),
        (PAYMENT_STATUS_REFUNDED, "Remboursée"),
    ]

    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="orders",
        verbose_name="Utilisateur",
    )

    cart = models.OneToOneField(
        Cart,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="order",
        verbose_name="Panier source",
        help_text="Panier dont est issue cette commande (pour debug / tracking).",
    )

    order_status = models.CharField(
        max_length=20,
        choices=ORDER_STATUS_CHOICES,
        default=ORDER_STATUS_DRAFT,
        verbose_name="Statut Commande",
    )
    
    payment_status = models.CharField(
        max_length=20,
        choices=PAYMENT_STATUS_CHOICES,
        default=PAYMENT_STATUS_PENDING,
        verbose_name="Statut Paiement",
    )

    # Totaux snapshot
    currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name="Devise",
    )
    total_ht = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name="Total HT",
    )
    total_tva = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name="Total TVA",
    )
    total_ttc = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name="Total TTC",
    )

    # Coordonnées (V1 : inline, on factorisera plus tard si besoin)
    billing_name = models.CharField(max_length=200, blank=True)
    billing_address = models.TextField(blank=True)
    shipping_name = models.CharField(max_length=200, blank=True)
    shipping_address = models.TextField(blank=True)

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Créée le",
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Mise à jour le",
    )

    class Meta:
        verbose_name = "Commande"
        verbose_name_plural = "Commandes"
        ordering = ["-created_at", "-id"]

    def __str__(self) -> str:
        return f"Commande #{self.pk} – {self.order_status} / {self.payment_status}"


class OrderLine(models.Model):
    """
    Ligne de commande (snapshot du produit et du prix au moment de la commande).
    """

    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE,
        related_name="lines",
    )

    product = models.ForeignKey(
        Product,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="order_lines",
        help_text="Produit d'origine (peut être supprimé plus tard).",
    )

    label = models.CharField(
        max_length=255,
        verbose_name="Description",
        help_text="Texte affiché pour cette ligne (titre produit, options, etc.).",
    )
    sku = models.CharField(
        max_length=64,
        blank=True,
        verbose_name="SKU (snapshot)",
    )

    quantity = models.PositiveIntegerField(
        default=1,
        verbose_name="Quantité",
    )

    unit_price_ht = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Prix unitaire HT",
    )
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        verbose_name="TVA (%)",
    )

    class Meta:
        verbose_name = "Ligne de commande"
        verbose_name_plural = "Lignes de commande"

    def __str__(self) -> str:
        return f"Commande #{self.order_id} – {self.label} x {self.quantity}"

    @property
    def total_ht(self) -> Decimal:
        return _montant(self.unit_price_ht * self.quantity)

    @property
    def total_ttc(self) -> Decimal:
        return _montant(
            self.total_ht * (Decimal("1.0") + self.tax_rate / Decimal("100.0"))
        )
