"""
Signaux de la boutique.

Un seul pour l'instant : la reprise du panier anonyme à la connexion. Elle est
branchée sur `user_logged_in` plutôt que dans la vue de connexion, parce que
les entrées sont multiples — formulaire allauth, connexion sociale, connexion
programmée après inscription — et qu'un panier perdu selon le chemin emprunté
serait impossible à diagnostiquer.
"""

from django.contrib.auth.signals import user_logged_in
from django.db.models.signals import post_save
from django.dispatch import receiver

from .cart import merge_session_cart_safe
from .models import ShopSettings


@receiver(user_logged_in, dispatch_uid="jeiko_shop_merge_session_cart")
def reprendre_le_panier_anonyme(sender, request, user, **kwargs):
    if request is None:
        return
    merge_session_cart_safe(request, user)


@receiver(post_save, sender=ShopSettings, dispatch_uid="jeiko_shop_invalidate_cart_menu")
def invalider_les_menus_apres_reglages(sender, instance, **kwargs):
    """Le cache HTML du menu doit suivre l'activation de la boutique."""
    # Le menu est rendu et mémorisé trente jours. Sans invalidation ciblée,
    # cocher/décocher la boutique dans l'admin ne changerait l'icône qu'à
    # l'expiration du cache. L'import local évite le cycle shop -> menu -> shop.
    from jeiko.administration_menu.models import Menu, _invalidate_menu_cache_by_ids

    for menu in Menu.objects.filter(show_cart=True).only("id", "place"):
        _invalidate_menu_cache_by_ids(menu_id=menu.id, place=menu.place)
