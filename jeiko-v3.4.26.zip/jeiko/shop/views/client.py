from django.contrib import messages
from django.shortcuts import render, get_object_or_404, redirect
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import ensure_csrf_cookie

from jeiko.custom_objects.services import (
    OBJECT_VALUE_PREFETCH,
    build_object_context,
)
from jeiko.shop.models import Product, Cart, CartItem, ShopSettings
from jeiko.shop.services import compute_order_totals
from jeiko.shop.state import require_shop_online
from jeiko.administration_pages.querysets import public_pages


class BoutiqueEnLigneRequiredMixin:
    """Garde commune aux fiches, au panier et à ses actions."""

    def dispatch(self, request, *args, **kwargs):
        require_shop_online()
        return super().dispatch(request, *args, **kwargs)


@method_decorator(ensure_csrf_cookie, name="get")
class ProductView(BoutiqueEnLigneRequiredMixin, View):
    """
    Vue client pour afficher un produit.
    URL canonique : /shop/<product_type_code>/<product_sku>/

    C'est la page de référence de la fiche : elle rend le même gabarit que
    CustomObjectView, augmenté du prix, du stock et du panier.
    """

    template_name = "pages/main.html"  # même template que PageView

    def get(self, request, *args, **kwargs):
        product_sku = kwargs["product_sku"]
        product_type_code = kwargs["product_type_code"]

        qs = (
            Product.objects
            .select_related(
                "type",
                "content",
                "content__model",
                "content__model__page_template",
                "content__metadata",
            )
            .prefetch_related(
                *(f"content__{lookup}" for lookup in OBJECT_VALUE_PREFETCH)
            )
        )

        # Un produit retiré de la vente, ou dont la fiche est encore en
        # brouillon, ne doit pas être servi au public : sans ce filtre, il
        # suffisait de connaître le SKU. Le staff garde l'accès pour la
        # prévisualisation, comme sur CustomObjectView.
        if not request.user.is_staff:
            qs = qs.filter(is_active=True, content__is_published=True)

        # Le code du type était extrait de l'URL puis ignoré : n'importe quelle
        # valeur menait à la fiche. On l'exige.
        product = get_object_or_404(
            qs,
            sku=product_sku,
            type__code=product_type_code,
        )

        obj = product.content  # Le CustomObject associé
        page = obj.model.page_template
        shop_settings = ShopSettings.get_solo()

        # Contexte de base
        context = {
            "page": page,
            "custom_object": obj,
            "object": obj,
            "product": product,
            "product_price": (
                product.price_ttc
                if shop_settings.display_prices_including_tax
                else product.price_ht
            ),
            "product_price_ttc": product.price_ttc,
            "product_price_ht": product.price_ht,
            "product_price_includes_tax": shop_settings.display_prices_including_tax,
            "product_sku": product.sku,
            "product_stock": product.stock_quantity,
            # `est_disponible` et non le stock brut : un service n'est pas
            # épuisé parce que personne n'a saisi de quantité.
            "product_is_in_stock": product.est_disponible,
        }

        # Metadata éventuelle
        metadata = getattr(obj, "metadata", None)
        if metadata is not None:
            context["metadata"] = metadata

        # Valeurs des champs, aplaties sous leur code pour les jetons [%code%]
        context.update(build_object_context(obj))

        return render(request, self.template_name, context)


class ShopHomeView(BoutiqueEnLigneRequiredMixin, View):
    """Point d'entrée `/shop/`, redirigé vers une page classique choisie."""

    def get(self, request):
        settings = ShopSettings.get_solo()
        page = settings.homepage
        if page is None:
            # Sans choix explicite, on évite d'inventer une page de boutique :
            # le site garde sa page d'accueil normale et l'admin peut revenir
            # ici pour choisir la page dédiée.
            return redirect("jeiko_pages:root_page")
        if not public_pages().filter(pk=page.pk).exists():
            from django.http import Http404
            raise Http404("La page d’accueil de la boutique n’est pas publiée.")
        return redirect(page.get_absolute_url())


# ----------------------------------------------------------------------
#  Cart Views
# ----------------------------------------------------------------------

# Le panier a déménagé dans `jeiko.shop.cart` : sa reprise à la connexion est
# branchée sur un signal, et le module n'a donc pas à importer les vues. Le nom
# reste exposé ici, plusieurs appelants l'important depuis ce module.
from ..cart import get_or_create_cart  # noqa: E402,F401


class CartDetailView(BoutiqueEnLigneRequiredMixin, View):
    template_name = "shop/cart_detail.html"

    def get(self, request):
        cart = get_or_create_cart(request)
        items = cart.items.select_related("product", "product__content").all()
        shop_settings = ShopSettings.get_solo()
        
        total_ht, total_tva, total_ttc = compute_order_totals(items)

        context = {
            "cart": cart,
            "items": items,
            "total_ht": total_ht,
            "total_tva": total_tva,
            "total_ttc": total_ttc,
            "display_prices_including_tax": shop_settings.display_prices_including_tax,
            "shop_currency": shop_settings.currency,
        }
        return render(request, self.template_name, context)


class AddToCartView(BoutiqueEnLigneRequiredMixin, View):
    def post(self, request, product_id):
        cart = get_or_create_cart(request)
        # Même filtre que ProductView : un produit retiré de la vente ou dont
        # la fiche est en brouillon ne doit pas pouvoir entrer dans un panier,
        # même en connaissant son identifiant.
        product = get_object_or_404(
            Product,
            pk=product_id,
            is_active=True,
            content__is_published=True,
        )

        try:
            quantity = int(request.POST.get("quantity", 1))
        except (TypeError, ValueError):
            quantity = 1
        if quantity < 1:
            quantity = 1

        # Un produit qui ne s'épuise pas — service, abonnement, formation —
        # est toujours servable : voir `Product.suit_le_stock`.
        if not product.peut_servir(quantity):
            messages.error(
                request,
                f"« {product.title} » n'est plus disponible en quantité suffisante.",
            )
            return redirect("jeiko_client_shop:cart_detail")

        # On cherche si l'item existe déjà
        item, created = CartItem.objects.get_or_create(
            cart=cart,
            product=product,
            defaults={
                "quantity": 0, # On ajoutera la quantité juste après
                "unit_price_ht": product.price_ht,
                "tax_rate": product.tax_rate,
                "currency": product.currency,
            }
        )
        # Mise à jour prix/taxe si ça a changé entre temps ?
        # Pour l'instant on garde le snapshot à la création ou on met à jour ?
        # Généralement dans un panier on veut le prix actuel.
        item.unit_price_ht = product.price_ht
        item.tax_rate = product.tax_rate
        
        item.quantity += quantity
        item.save()
        
        return redirect("jeiko_client_shop:cart_detail")


#: Quantité maximale par ligne de panier. Une commande légitime reste très en
#: dessous ; au-delà, c'est une saisie erronée ou une tentative de faire
#: déborder les calculs de total.
MAX_CART_QUANTITY = 999


class UpdateCartItemView(BoutiqueEnLigneRequiredMixin, View):
    def post(self, request, item_id):
        cart = get_or_create_cart(request)
        item = get_object_or_404(CartItem, pk=item_id, cart=cart)

        action = request.POST.get("action")

        if action == "update":
            # `int()` était appelé sans garde : une valeur non numérique
            # renvoyait une 500. `AddToCartView`, deux fonctions plus haut,
            # protégeait déjà le même appel.
            try:
                quantity = int(request.POST.get("quantity", item.quantity))
            except (TypeError, ValueError):
                messages.error(request, "Quantité invalide.")
                return redirect("jeiko_client_shop:cart_detail")

            if quantity <= 0:
                item.delete()
                return redirect("jeiko_client_shop:cart_detail")

            quantity = min(quantity, MAX_CART_QUANTITY)

            # Le stock n'était vérifié qu'à l'ajout : on pouvait porter une
            # ligne au-delà du disponible en passant par la mise à jour.
            produit = item.product
            if produit and not produit.peut_servir(quantity):
                quantity = max(produit.stock_quantity or 0, 0)
                if quantity == 0:
                    item.delete()
                    messages.error(
                        request,
                        f"« {produit.title} » n'est plus disponible.",
                    )
                    return redirect("jeiko_client_shop:cart_detail")
                messages.warning(
                    request,
                    f"Quantité ramenée à {quantity} : c'est tout ce qu'il reste "
                    f"de « {produit.title} ».",
                )

            item.quantity = quantity
            item.save()

        return redirect("jeiko_client_shop:cart_detail")


class RemoveCartItemView(BoutiqueEnLigneRequiredMixin, View):
    def post(self, request, item_id):
        cart = get_or_create_cart(request)
        item = get_object_or_404(CartItem, pk=item_id, cart=cart)
        item.delete()
        return redirect("jeiko_client_shop:cart_detail")
