from django import template

from ..state import shop_is_online

register = template.Library()


@register.simple_tag
def boutique_en_ligne():
    """Expose l'état de la boutique aux fragments de menu mis en cache."""
    return shop_is_online()

