import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("shop", "0008_shopsettings_display_prices_including_tax_and_more"),
    ]

    operations = [
        migrations.AlterField(
            model_name="productstockmovement",
            name="product",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.PROTECT,
                related_name="stock_movements",
                to="shop.product",
                verbose_name="Produit",
            ),
        ),
    ]
