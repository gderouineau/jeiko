"""État public partagé de la boutique."""

from django.http import Http404

from .models import ShopSettings


def shop_is_online():
    """Retourne l'état d'ouverture sans dupliquer la lecture du singleton."""
    return bool(ShopSettings.get_solo().is_online)


def require_shop_online():
    """Bloque une URL publique de la boutique lorsqu'elle est désactivée."""
    if not shop_is_online():
        raise Http404("La boutique en ligne est actuellement désactivée.")

