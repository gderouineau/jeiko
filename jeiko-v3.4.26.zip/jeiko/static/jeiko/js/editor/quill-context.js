/** E-07 : reprendre les vrais sélecteurs dans un document distinct.
 * Aucun CSS du site n'entre dans l'habillage de la modale. Le document ne
 * reçoit une copie du contexte public, les feuilles
 * de contenu et Quill, jamais les scripts ou contrôles de la page.
 */
export function appliquerCssGlobalAuContenu() {
    const data = document.getElementById('jk-editor-global-css');
    const content = document.querySelector('.content');
    if (!data || !content || content.querySelector('[data-jk-editor-global-style]')) return;
    const style = document.createElement('style');
    style.dataset.jkEditorGlobalStyle = '';
    style.textContent = JSON.parse(data.textContent);
    content.prepend(style);
}

export function selecteursPublics(sheet) {
    // base_style contient aussi d'anciennes branches :is(.ql-editor, ...)
    // à spécificité plus élevée. Elles n'existent pas au rendu public : ne
    // garder que les branches publiques, sans modifier le gabarit partagé.
    for (const rule of [...sheet.cssRules]) {
        if (rule.cssRules) { selecteursPublics(rule); continue; }
        if (!rule.selectorText?.includes('.ql-editor')) continue;
        const parts = [];
        let depth = 0, start = 0, quote = null;
        for (let i = 0; i < rule.selectorText.length; i++) {
            const c = rule.selectorText[i];
            if (c === '\\') { i++; continue; }
            if (quote) { if (c === quote) quote = null; continue; }
            if (c === '"' || c === "'") { quote = c; continue; }
            if (c === '(' || c === '[') depth++;
            if (c === ')' || c === ']') depth--;
            if (c === ',' && depth === 0) { parts.push(rule.selectorText.slice(start,i)); start=i+1; }
        }
        parts.push(rule.selectorText.slice(start));
        rule.selectorText = parts.filter(p => !p.includes('.ql-editor')).join(',') || ':not(*)';
    }
}

export function htmlPourSauvegarde(quill) {
    const copie = quill.root.cloneNode(true);
    // Parchment peut porter des éléments UI hors du document : puces de
    // liste et fond du bloc. Ils ne doivent pas devenir du contenu enregistré.
    for (const el of copie.querySelectorAll('.ql-ui')) el.remove();
    return copie.innerHTML;
}

export function retirerStylesContenuSnow(sheet) {
    for (let i = sheet.cssRules.length - 1; i >= 0; i--) {
        const selector = sheet.cssRules[i].selectorText;
        // Snow colore aussi les liens par .ql-snow a, sans .ql-editor.
        // Garder l'habillage des contrôles, pas celui du texte public.
        if (selector?.includes('.ql-editor') || selector === '.ql-snow a') sheet.deleteRule(i);
    }
}

export function quillAvecRacinePublique(Quill, emplacement) {
    // addContainer est le point de création natif de Quill 2.0.3. Placer sa
    // vraie racine à l'emplacement public évite un parent artificiel et
    // conserve les sélecteurs >, nth-child et :has, sans réécrire le CSS.
    return class extends Quill {
        addContainer(container, refNode = null) {
            if (container === 'ql-editor') {
                const root = emplacement.ownerDocument.createElement('div');
                root.classList.add('ql-editor');
                emplacement.replaceWith(root);
                return root;
            }
            return super.addContainer(container, refNode);
        }
    };
}

export async function preparerContexteQuill(editorEl, blocId) {
    const source = document.getElementById(`bloc-${blocId}`);
    const content = source?.closest('.content');
    if (!source || !content) throw new Error('Contexte public du bloc introuvable.');
    const script = [...document.scripts].find(s => /\/quill(?:\.min)?\.js(?:\?|$)/.test(s.src));
    if (!script) throw new Error('Chargement Quill introuvable.');

    const frame = document.createElement('iframe');
    frame.title = 'Texte éditable dans le contexte du site';
    // Le viewport de la page, pas la largeur du dialogue : les mêmes
    // @media s'appliquent. Le dialogue permet le défilement horizontal.
    const viewportSource = source.closest('.editor-body');
    const largeur = viewportSource ? parseFloat(getComputedStyle(viewportSource).width) : window.innerWidth;
    frame.style.cssText = `width:${largeur || window.innerWidth}px;height:420px;border:0;display:block;`;
    editorEl.after(frame);
    const doc = frame.contentDocument;
    const base = doc.createElement('base');
    base.href = document.baseURI;
    doc.head.append(base);

    // Snow ne doit pas redéfinir la typographie du contenu. On conserve ses
    // règles de toolbar, puis les styles publics prennent la priorité.
    const feuilles = [];
    for (const link of document.querySelectorAll('head link[rel="stylesheet"]')) {
        if (/quill|\/css\/main\/|fonts\.googleapis\.com|\/fonts\//.test(link.href)) {
            const copy = doc.importNode(link, true);
            if (/quill/.test(link.href)) copy.crossOrigin = 'anonymous';
            feuilles.push(new Promise((resolve, reject) => {
                copy.onload = () => {
                    // Snow définit .ql-snow .ql-editor h3 avec une priorité
                    // supérieure à .content h3. Garder seulement son habillage
                    // évite cette divergence, même si la police est copiée.
                    if (/quill/.test(copy.href)) {
                        try {
                            retirerStylesContenuSnow(copy.sheet);
                        } catch (error) { reject(new Error('La feuille Quill ne peut pas être isolée.')); return; }
                    }
                    resolve();
                };
                copy.onerror = () => reject(new Error('Une feuille de contenu ne peut pas être chargée.'));
            }));
            doc.head.append(copy);
        }
    }
    const reset = doc.createElement('style');
    reset.textContent = 'body{margin:0}.ql-container{font:inherit;border:0!important;display:contents}.ql-editor{padding:0;overflow:visible;white-space:normal;line-height:inherit;font:inherit;height:auto;min-height:100px}.ql-toolbar{position:sticky;top:0;z-index:10;background:white}';
    doc.head.append(reset);
    for (const style of document.querySelectorAll('[data-jk-content-style]')) {
        const copy = doc.importNode(style, true);
        doc.head.append(copy);
        selecteursPublics(copy.sheet);
    }
    const globalData = document.getElementById('jk-editor-global-css');
    if (globalData) {
        const style = doc.createElement('style');
        style.textContent = JSON.parse(globalData.textContent);
        doc.head.append(style);
    }
    // Conserver les frères : retirer une colonne change la grille et les
    // sélecteurs nth-child/:has. Aucun comportement de la page n'est exécuté.
    const viewport = doc.createElement('div');
    viewport.className = 'editor-body';
    viewport.style.cssText = 'container-type:inline-size;container-name:editor-body;';
    doc.body.append(viewport);
    const page = doc.importNode(content, true);
    for (const el of page.querySelectorAll('script,iframe,object,embed,.overlay-section-bg,.overlay-section-controls,.overlay-line-bg,.overlay-line-controls,.overlay-block-bg,.overlay-block-controls,[data-empty-state]')) el.remove();
    for (const el of [page, ...page.querySelectorAll('*')]) {
        for (const attr of [...el.attributes]) {
            if (/^on|^x-|^hx-/i.test(attr.name) || attr.name === 'contenteditable') el.removeAttribute(attr.name);
        }
    }
    viewport.append(page);
    // Toute feuille locale reste dans l'ordre du DOM public, y compris une
    // feuille sur un autre bloc qui porte un style partagé entre sections.
    for (const style of [...page.querySelectorAll('style')]) doc.head.append(style);
    doc.addEventListener('click', event => {
        if (event.target.closest('a') && !event.target.closest('.ql-toolbar,.ql-tooltip')) event.preventDefault();
    });
    doc.addEventListener('submit', event => event.preventDefault());
    const original = doc.getElementById(source.id);
    const background = original.querySelector(':scope > .bg-img');
    const emplacement = doc.createComment('racine Quill publique');
    original.replaceWith(emplacement);
    const mount = doc.createElement('div');
    // Le conteneur natif reste connecté pour l'émetteur/les tooltips, mais
    // hors de .content : aucun parent supplémentaire autour du texte.
    mount.style.cssText = 'position:fixed!important;inset:0!important;width:100%!important;height:100%!important;display:block!important;pointer-events:none;z-index:50';
    const controles = doc.createElement('style');
    controles.textContent = '.ql-container > .ql-tooltip{pointer-events:auto}';
    doc.head.append(controles);
    doc.body.append(mount);
    let timer;
    try {
        await Promise.race([Promise.all(feuilles).then(() => new Promise((resolve, reject) => {
            const load = doc.createElement('script');
            load.src = script.src;
            load.onload = resolve;
            load.onerror = () => reject(new Error('Quill ne peut pas être chargé dans le contexte isolé.'));
            doc.head.append(load);
        })), new Promise((resolve, reject) => {
            timer = setTimeout(() => reject(new Error('Délai de chargement du contexte dépassé.')), 20000);
        })]);
    } catch (error) {
        frame.remove();
        throw error;
    } finally {
        clearTimeout(timer);
    }
    return {
        mount, Quill: quillAvecRacinePublique(frame.contentWindow.Quill, emplacement),
        actualiserCss(css, classes, anciennesClasses) {
            if (!frame.isConnected) return;
            let style = doc.querySelector(`style[data-jk-bloc-style="${blocId}"]`);
            if (!style) {
                style = doc.createElement('style');
                style.dataset.jkBlocStyle = String(blocId);
                doc.head.append(style);
            }
            // textContent ne peut pas faire sortir une réponse du <style>.
            style.textContent = css;
            const root = doc.getElementById(source.id);
            const reserves = new Set(['ql-editor', 'ql-blank', 'bloc', `bloc-${blocId}`, ...[...source.classList].filter(c => c.startsWith('bloc-'))]);
            for (const name of anciennesClasses) if (!reserves.has(name)) root.classList.remove(name);
            for (const name of String(classes).split(/\s+/).filter(Boolean)) root.classList.add(name);
        },
        finaliser(quill) {
            // Le bloc devient la racine éditable : #bloc-ID > p reste vrai,
            // sans wrapper supplémentaire entre le bloc et ses paragraphes.
            quill.root.id = source.id;
            for (const name of source.classList) quill.root.classList.add(name);
            // ParentBlot.attachUI exclut ce noeud du document et de ses
            // mutations, tout en gardant l'image à sa place dans le bloc.
            if (background) quill.scroll.attachUI(background);
            quill.root.setAttribute('aria-label', 'Contenu du texte');
            // La toolbar reste dans la modale, hors du document qui reçoit
            // le CSS du site : même un CSS local général ne la repeint pas.
            editorEl.before(quill.getModule('toolbar').container);
            editorEl.hidden = true;
            // Le document garde son contexte, mais le viewport montre le
            // bloc édité, pas le début de la page complète.
            requestAnimationFrame(() => quill.root.scrollIntoView({block:'start',inline:'nearest'}));
        },
    };
}

export function enregistrerAttributsQuill(Quill) {
    const Parchment = Quill.import('parchment');
    // Les classes utilisateur restent des attributs de document lors d'une
    // scission de paragraphe ; les classes ql-* restent gérées par Quill.
    class Classes extends Parchment.Attributor {
        value(node) { return [...node.classList].filter(c => !c.startsWith('ql-')).join(' '); }
        add(node, value) {
            this.remove(node);
            for (const name of String(value).split(/\s+/).filter(Boolean)) node.classList.add(name);
            return true;
        }
        remove(node) { for (const c of [...node.classList]) if (!c.startsWith('ql-')) node.classList.remove(c); }
    }
    for (const [name, scope] of [['Block', Parchment.Scope.BLOCK_ATTRIBUTE], ['Inline', Parchment.Scope.INLINE_ATTRIBUTE]]) {
        Quill.register(new Classes(`jkClasses${name}`, 'class', {scope}), true);
        Quill.register(new Parchment.Attributor(`jkId${name}`, 'id', {scope}), true);
    }
}
