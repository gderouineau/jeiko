"""
Garde-fous de la fin de questionnaire (rapport Fable 2, §4.3.1).

Pourquoi
--------
La dernière étape d'un questionnaire est un formulaire PUBLIC qui écrit un
passage, une fiche prospect, jusqu'à trois consentements, et **envoie deux
e-mails** — le résultat à l'adresse saisie, la notification à l'exploitant.
Sans plafond, une boucle de POST avec des adresses arbitraires faisait du
site un relais d'envoi « vos résultats » vers n'importe quelle boîte, noyait
la boîte de l'exploitant, et gonflait trois tables sans limite.

Même politique que le formulaire de contact (`administration_pages/
throttling.py`), avec un plafond de plus : **par adresse e-mail**. C'est lui
qui coupe le relais, puisqu'un robot change d'IP plus facilement que de
cible.

Ce que ça ne résout pas
-----------------------
Un robot patient, sous le plafond, sur beaucoup d'IP. Les valeurs par défaut
laissent large à l'usage humain — une personne passe quelques questionnaires
par jour, pas par minute — et restent réglables par
`JEIKO_QUESTIONNAIRE_LIMITS`.
"""

import logging

from jeiko.throttling import get_client_ip, get_limits, hit, honeypot_filled, peek

logger = logging.getLogger(__name__)

# (nombre maximum, fenêtre en secondes)
DEFAULT_LIMITS = {
    "ip_attempts": (30, 3600),
    "ip_submissions": (10, 3600),
    "ip_submissions_day": (30, 86400),
    "email_submissions_day": (5, 86400),
}

SCOPE = "questionnaire"

REFUS = (
    "Trop de questionnaires envoyés depuis cet appareil ou vers cette adresse. "
    "Vos réponses sont conservées : merci de réessayer un peu plus tard."
)


def limites():
    return get_limits("JEIKO_QUESTIONNAIRE_LIMITS", DEFAULT_LIMITS)


def _adresse(email):
    return (email or "").strip().lower()


def verifier_envoi(request, email=None):
    """`None` si l'envoi peut poursuivre, sinon le message à afficher."""
    plafonds = limites()
    ip = get_client_ip(request)

    if honeypot_filled(request.POST):
        logger.warning("Questionnaire rejeté (leurre rempli) ip=%s", ip)
        return REFUS
    if hit(f"{SCOPE}:attempts", ip, *plafonds["ip_attempts"]):
        logger.warning("Questionnaire rejeté (trop de tentatives) ip=%s", ip)
        return REFUS
    if peek(f"{SCOPE}:sent_h", ip, plafonds["ip_submissions"][0]) or \
       peek(f"{SCOPE}:sent_d", ip, plafonds["ip_submissions_day"][0]):
        logger.warning("Questionnaire rejeté (plafond d'envois par IP) ip=%s", ip)
        return REFUS
    adresse = _adresse(email)
    if adresse and peek(f"{SCOPE}:email_d", adresse, plafonds["email_submissions_day"][0]):
        logger.warning("Questionnaire rejeté (plafond par adresse) ip=%s", ip)
        return REFUS
    return None


def compter_envoi(request, email=None):
    """Comptabilise un envoi accepté, après enregistrement du passage."""
    plafonds = limites()
    ip = get_client_ip(request)
    hit(f"{SCOPE}:sent_h", ip, *plafonds["ip_submissions"])
    hit(f"{SCOPE}:sent_d", ip, *plafonds["ip_submissions_day"])
    adresse = _adresse(email)
    if adresse:
        hit(f"{SCOPE}:email_d", adresse, *plafonds["email_submissions_day"])
