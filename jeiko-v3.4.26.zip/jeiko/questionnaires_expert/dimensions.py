"""
Résultat « par dimensions » : chaque profil simple est une dimension, et le
visiteur reçoit, pour CHACUNE, le contenu de la tranche où tombe son score.

Pourquoi un module à part
-------------------------
Le mode historique (`views/client.resolve_profiles`) désigne un profil
gagnant. Ce mode-ci n'en désigne aucun : il ordonne. Mélanger les deux dans
une même fonction aurait rendu chacun plus difficile à lire, et le mode
historique — utilisé par des sites en service — plus risqué à toucher. Rien
ici n'est appelé quand `ExpertTest.result_mode` vaut « profil ».

La règle de composition
-----------------------
1. Le milieu de l'échelle est `(min + max) / 2` — 9 pour une échelle 0-18.
2. L'écart d'une dimension est `|score − milieu|`, vers le haut ou vers le
   bas indifféremment.
3. En tête : la ou les dimensions au plus grand écart. Plusieurs à égalité
   passent toutes en tête, au pluriel, dans l'ordre fixe.
4. Ensuite : les autres, dans l'ordre fixe (rang, puis identifiant).
5. Cas « profil nuancé » : si TOUTES les dimensions tombent dans leur tranche
   du milieu, aucune n'est mise en tête et le texte « profil nuancé » ouvre
   la page.

Ce que ce module ne fait pas
----------------------------
Il ne calcule pas les scores : il les reçoit, tels qu'enregistrés dans
`ExpertTestData.data["scores"]`. Il n'affiche aucun pourcentage et ne compare
le visiteur à personne — c'est une exigence du contenu, pas un oubli.
"""

import re
from dataclasses import dataclass, field

# En dessous de cet écart, deux flottants sont tenus pour égaux. Les scores
# sont des sommes de poids (souvent entiers), mais un poids 0.1 répété peut
# produire 0.30000000000000004 : sans tolérance, une égalité voulue par le
# rédacteur serait départagée par l'arrondi de la machine.
EPSILON = 1e-9

HEX_COLOR = re.compile(r"#(?:[0-9a-fA-F]{3}){1,2}")
COULEUR_PAR_DEFAUT = "#cccccc"


@dataclass
class Dimension:
    profile: object
    score: float
    band: object = None
    gap: float = 0.0
    percent: float = 0.0

    @property
    def color(self):
        """
        La couleur du profil, seulement si c'est bien un hexadécimal.

        Elle est posée dans un attribut `style` : le modèle la valide dans le
        formulaire, mais une écriture hors formulaire n'y passe pas, et un
        attribut n'est pas un endroit où laisser entrer n'importe quoi.
        """
        couleur = self.profile.color or ""
        # « #cccccc » est la valeur par défaut du modèle, pas un choix : la
        # barre prend alors l'accent du thème plutôt qu'un gris sans intention.
        if couleur.lower() in ("", COULEUR_PAR_DEFAUT):
            return ""
        return couleur if HEX_COLOR.fullmatch(couleur) else ""

    @property
    def low_label(self):
        return self.profile.low_pole_label

    @property
    def high_label(self):
        return self.profile.high_pole_label


@dataclass
class DimensionsResult:
    head: list = field(default_factory=list)
    rest: list = field(default_factory=list)
    nuanced: bool = False

    @property
    def head_is_plural(self):
        return len(self.head) > 1

    @property
    def all(self):
        return self.head + self.rest


def dimension_profiles(test):
    """Les dimensions d'un test, dans l'ordre fixe d'affichage."""
    return list(
        test.profiles
        .filter(is_complex=False, is_score_profile=False)
        .prefetch_related("bands")
        .order_by("order", "id")
    )


def arrange(test, scores_by_profile_id, profiles=None):
    """
    Compose le résultat à partir de `{profile_id: score}`.

    `profiles` évite une requête quand l'appelant les a déjà ; ils doivent
    alors être dans l'ordre fixe et porter leurs tranches préchargées.
    """
    profiles = dimension_profiles(test) if profiles is None else profiles
    low = float(test.dimension_scale_min)
    high = float(test.dimension_scale_max)
    middle = (low + high) / 2
    width = high - low

    dimensions = []
    for profile in profiles:
        score = float(scores_by_profile_id.get(profile.id, 0) or 0)
        band = next((b for b in profile.bands.all() if b.contains(score)), None)
        percent = 0.0 if width <= 0 else (score - low) / width * 100
        dimensions.append(Dimension(
            profile=profile,
            score=score,
            band=band,
            gap=abs(score - middle),
            percent=max(0.0, min(100.0, percent)),
        ))

    if not dimensions:
        return DimensionsResult()

    nuanced = all(
        d.band is not None and d.band.position == d.band.MIDDLE for d in dimensions
    )
    largest = max(d.gap for d in dimensions)
    # Toutes exactement au milieu : personne ne se distingue, il n'y a rien à
    # mettre en tête — même sans tranche « milieu » renseignée.
    if nuanced or largest < EPSILON:
        return DimensionsResult(head=[], rest=dimensions, nuanced=nuanced)

    head = [d for d in dimensions if largest - d.gap < EPSILON]
    rest = [d for d in dimensions if largest - d.gap >= EPSILON]
    return DimensionsResult(head=head, rest=rest, nuanced=False)


def scores_from_test_data(test_data):
    """`{profile_id: score}` depuis le document JSON d'un passage."""
    scores = (test_data.data or {}).get("scores") or []
    return {s["profile_id"]: s.get("score", 0) for s in scores if s.get("profile_id")}
