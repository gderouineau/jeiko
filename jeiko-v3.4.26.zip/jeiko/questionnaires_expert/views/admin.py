from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.db import models, transaction
from django.db.models import Prefetch
from django.db.models import Max
import re

from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.views.generic import (
    ListView, DetailView, CreateView, UpdateView, DeleteView
)
from django.views import View
from django.contrib.auth.decorators import permission_required
from django.contrib.auth import get_user_model
User = get_user_model()

from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy, reverse

from django.contrib import messages


from jeiko.questionnaires_expert.models import (
    ExpertTest, ExpertQuestion, ExpertAnswer,
    ExpertProfileType, ExpertProfileCombination,
    ExpertProfileCriterion, ExpertTestData,
    Prospect, ExpertAnswerProfileWeight,

    ExpertTestStyle
)
from jeiko.questionnaires_expert.forms import (
    ExpertAnswerForm, AnswerProfileWeightFormSet, ExpertProfileCombinationForm, ExpertProfileTypeForm,
    ExpertTestStyleForm, DimensionsSettingsForm, DimensionProfileForm, DimensionBandForm,
)
from jeiko.users.models import (
    Comments
)
from jeiko.users.forms_admin import CommentsForm





@method_decorator(never_cache, name='dispatch')
class ExpertTestListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = ExpertTest
    template_name = "questionnaires_expert/test_list.html"
    context_object_name = "tests"

    permission_required = 'questionnaires_expert.view_questionnaire'
    raise_exception = True


@method_decorator(never_cache, name='dispatch')
class ExpertTestDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = ExpertTest
    template_name = "questionnaires_expert/test_detail.html"
    context_object_name = "test"
    pk_url_kwarg = "test_id"

    permission_required = 'questionnaires_expert.view_questionnaire'
    raise_exception = True

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profiles = self.object.profiles.all()
        context['questions'] = self.object.questions.prefetch_related(
            Prefetch('answers', queryset=ExpertAnswer.objects.prefetch_related('profile_weights__profile_type'))
        ).all()
        context['simple_profiles'] = profiles.filter(is_complex=False, is_score_profile=False)
        context['complex_profiles'] = profiles.filter(is_complex=True, is_score_profile=False)
        context['score_profiles'] = profiles.filter(is_score_profile=True)
        context['profiles'] = profiles
        context['combinations'] = self.object.combinations.prefetch_related(
            'parent_profile', 'preferred_profile', 'alternative_profile'
        ).all()
        return context


@method_decorator(never_cache, name='dispatch')
class ExpertTestCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = ExpertTest
    fields = [
        "title", "slug", "description", "intro_warning", "is_active", "is_restricted",
        "main_image", "presentation_page",
    ]
    template_name = "questionnaires_expert/test_form.html"

    permission_required = 'questionnaires_expert.add_questionnaire'
    raise_exception = True

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.id])


@method_decorator(never_cache, name='dispatch')
class ExpertTestUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = ExpertTest
    # `slug` est volontairement absent : il est figé après création, sinon les
    # liens déjà diffusés (emails, pages, produits) cessent de fonctionner.
    fields = [
        "title", "description", "intro_warning", "is_active", "is_restricted",
        "main_image", "presentation_page",
    ]
    template_name = "questionnaires_expert/test_form.html"
    pk_url_kwarg = "test_id"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True


    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.id])


@method_decorator(never_cache, name='dispatch')
class ExpertTestDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = ExpertTest
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "test_id"
    success_url = reverse_lazy("jeiko_administration_questionnaires_expert:test_list")

    permission_required = 'questionnaires_expert.delete_questionnaire'
    raise_exception = True


@method_decorator(never_cache, name='dispatch')
class ExpertTestStyleUpdateView(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "questionnaires_expert/style_form.html"
    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_object(self, test_id):
        test = get_object_or_404(ExpertTest, pk=test_id)
        style, _ = ExpertTestStyle.objects.get_or_create(test=test)
        return test, style

    def get(self, request, test_id):
        test, style = self.get_object(test_id)
        form = ExpertTestStyleForm(instance=style)
        # vars pour la preview
        css_vars = style.get_css_vars()
        return render(
            request,
            self.template_name,
            {
                "test": test,
                "form": form,
                "css_vars": css_vars,
                "devices": ["mobile", "tablet", "desktop"],
            }
        )

    def post(self, request, test_id):
        test, style = self.get_object(test_id)
        form = ExpertTestStyleForm(request.POST, instance=style)
        if form.is_valid():
            form.save()
            messages.success(request, "Style du questionnaire enregistré.")
            return redirect(reverse("jeiko_administration_questionnaires_expert:test_style", args=[test.id]))
        css_vars = style.get_css_vars()
        return render(
            request,
            self.template_name,
            {
                "test": test,
                "form": form,
                "css_vars": css_vars,
                "devices": ["mobile", "tablet", "desktop"],
            }
        )


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = ExpertQuestion
    fields = ["text", "question_type", "extra_config"]  # on ne met plus "order" ici
    template_name = "questionnaires_expert/question_form.html"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def form_valid(self, form):
        test = get_object_or_404(ExpertTest, id=self.kwargs['test_id'])
        form.instance.test = test
        # Calcul du prochain order
        last_order = (
            ExpertQuestion.objects.filter(test=test)
            .aggregate(Max('order'))['order__max']
        )
        form.instance.order = (last_order + 1) if last_order is not None else 0
        return super().form_valid(form)

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = ExpertQuestion
    fields = ["text"]
    template_name = "questionnaires_expert/question_form.html"
    pk_url_kwarg = "question_id"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = ExpertQuestion
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "question_id"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionMoveUp(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get(self, request, question_id):
        question = get_object_or_404(ExpertQuestion, id=question_id)
        prev_q = (
            ExpertQuestion.objects
            .filter(test=question.test, order__lt=question.order)
            .order_by('-order')
            .first()
        )
        if prev_q:
            with transaction.atomic():
                question.order, prev_q.order = prev_q.order, question.order
                question.save(update_fields=["order"])
                prev_q.save(update_fields=["order"])
        return redirect(
            reverse("jeiko_administration_questionnaires_expert:test_detail", args=[question.test.id])
        )


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionMoveDown(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True


    def get(self, request, question_id):
        question = get_object_or_404(ExpertQuestion, id=question_id)
        next_q = (
            ExpertQuestion.objects
            .filter(test=question.test, order__gt=question.order)
            .order_by('order')
            .first()
        )
        if next_q:
            with transaction.atomic():
                question.order, next_q.order = next_q.order, question.order
                question.save(update_fields=["order"])
                next_q.save(update_fields=["order"])
        return redirect(
            reverse("jeiko_administration_questionnaires_expert:test_detail", args=[question.test.id])
        )


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionToggleActive(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Active / désactive une question. Une question inactive reste éditable mais
    n'est plus posée aux visiteurs ni prise en compte dans le scoring.
    """
    http_method_names = ["post"]

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def post(self, request, question_id):
        question = get_object_or_404(ExpertQuestion, id=question_id)
        question.is_active = not question.is_active
        question.save(update_fields=["is_active"])
        messages.success(
            request,
            f"Question {'activée' if question.is_active else 'désactivée'}."
        )
        return redirect(
            reverse("jeiko_administration_questionnaires_expert:test_detail", args=[question.test_id])
        )


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionDuplicate(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True


    def get(self, request, question_id):
        with transaction.atomic():
            # 0) Question d'origine
            original = get_object_or_404(ExpertQuestion, id=question_id)
            test = original.test
            old_order = original.order

            # 1) Décale les suivantes
            ExpertQuestion.objects.filter(
                test=test,
                order__gt=old_order
            ).update(order=models.F('order') + 1)

            # 2) Clone question (copie simple : pk=None)
            #    Astuce: on recharge l'objet pour éviter de modifier 'original' en mémoire
            q_src = ExpertQuestion.objects.get(pk=question_id)
            q_src.pk = None
            q_src.order = old_order + 1
            q_src.save()  # => q_clone

            # 3) Duplique réponses + poids
            #    On préfetch les poids pour éviter N+1
            answers = (ExpertAnswer.objects
                       .filter(question=original.pk)
                       .prefetch_related('profile_weights'))

            weights_to_create = []
            for ans in answers:
                # --- Cloner la réponse sans lister les champs à la main ---
                # Récupère tous les champs "concrets" (pas O2M/M2M)
                fields = [
                    f for f in ans._meta.get_fields()
                    if getattr(f, 'concrete', False)
                    and not getattr(f, 'many_to_many', False)
                    and not getattr(f, 'one_to_many', False)
                ]
                # Construit un dict {field_name: value} sauf pk/id/question
                payload = {}
                for f in fields:
                    if f.name in ('id', 'pk', 'question'):
                        continue
                    payload[f.name] = getattr(ans, f.name)

                # Force la nouvelle FK question
                payload['question'] = q_src
                ans_clone = ExpertAnswer.objects.create(**payload)

                # --- Cloner les poids par profil ---
                for w in ans.profile_weights.all():
                    weights_to_create.append(
                        ExpertAnswerProfileWeight(
                            answer=ans_clone,
                            profile_type=w.profile_type,
                            weight=w.weight
                        )
                    )

            if weights_to_create:
                # unique_together (answer, profile_type) -> aucun conflit attendu
                ExpertAnswerProfileWeight.objects.bulk_create(weights_to_create)

        return redirect(
            reverse("jeiko_administration_questionnaires_expert:test_detail", args=[test.id])
        )


def _normalize_question_text(s: str) -> str:
    """
    Normalise le texte pour la détection de doublons :
    - trim, lowercase
    - remplace les suites d'espaces (et \n, \t) par un seul espace
    - supprime espaces avant ponctuation courante
    """
    if not s:
        return ""
    s = s.strip().lower()
    s = re.sub(r"\s+", " ", s)  # collapse whitespace
    s = re.sub(r"\s+([?!;:,.])", r"\1", s)  # remove space before punctuation
    return s


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionDedupeView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    POST /jeiko/administration/questionnaires/expert/<test_id>/dedupe/
    - Détecte les doublons de questions (par texte normalisé)
    - Conserve la 1ère occurrence (ordre croissant), supprime les suivantes.
    - Redirige vers test_detail.

    POST uniquement : l'action supprime des questions et leurs réponses. En GET,
    un préchargement de lien par le navigateur suffisait à la déclencher.
    """
    http_method_names = ["post"]

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def post(self, request, test_id):
        test = get_object_or_404(ExpertTest, id=test_id)

        # On ordonne par 'order' puis 'id' pour conserver la première occurrence "la plus ancienne"
        questions = list(
            test.questions.order_by("order", "id").only("id", "text")
        )

        seen = {}
        ids_to_delete = []

        for q in questions:
            key = _normalize_question_text(q.text)
            if key in seen:
                ids_to_delete.append(q.id)
            else:
                seen[key] = q.id

        with transaction.atomic():
            if ids_to_delete:
                ExpertQuestion.objects.filter(id__in=ids_to_delete).delete()

        if ids_to_delete:
            messages.success(request, f"{len(ids_to_delete)} doublon(s) supprimé(s).")
        else:
            messages.info(request, "Aucun doublon détecté.")

        return redirect(reverse(
            "jeiko_administration_questionnaires_expert:test_detail",
            args=[test.id]
        ))


@method_decorator(never_cache, name='dispatch')
class ExpertAnswerCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = ExpertAnswer
    form_class = ExpertAnswerForm
    template_name = "questionnaires_expert/answer_form.html"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True


    def dispatch(self, request, *args, **kwargs):
        self.question = get_object_or_404(ExpertQuestion, id=self.kwargs['question_id'])
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        answer = ExpertAnswer(question=self.question)
        if self.request.POST:
            context['formset'] = AnswerProfileWeightFormSet(
                self.request.POST,
                instance=answer,
                form_kwargs={'answer': answer}
            )
        else:
            context['formset'] = AnswerProfileWeightFormSet(
                instance=answer,
                form_kwargs={'answer': answer}
            )
        return context

    def form_valid(self, form):
        form.instance.question = self.question
        # Ajout : calcul du prochain order pour la réponse
        last_order = (
            ExpertAnswer.objects.filter(question=self.question)
            .aggregate(Max('order'))['order__max']
        )
        form.instance.order = (last_order + 1) if last_order is not None else 0

        self.object = form.save()
        formset = AnswerProfileWeightFormSet(
            self.request.POST,
            instance=self.object,
            form_kwargs={'answer': self.object}
        )
        if formset.is_valid():
            formset.save()
            return redirect(self.get_success_url())
        else:
            return self.render_to_response(self.get_context_data(form=form, formset=formset))

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.question.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertAnswerUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = ExpertAnswer
    form_class = ExpertAnswerForm
    template_name = "questionnaires_expert/answer_form.html"
    pk_url_kwarg = "answer_id"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.POST:
            context['formset'] = AnswerProfileWeightFormSet(
                self.request.POST,
                instance=self.object,
                form_kwargs={'answer': self.object}
            )
        else:
            context['formset'] = AnswerProfileWeightFormSet(
                instance=self.object,
                form_kwargs={'answer': self.object}
            )
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        formset = context['formset']
        if formset.is_valid():
            self.object = form.save()
            formset.instance = self.object
            formset.save()
            return redirect(self.get_success_url())
        return self.render_to_response(self.get_context_data(form=form))

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.question.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertAnswerDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = ExpertAnswer
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "answer_id"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.question.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertAnswerMoveUp(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get(self, request, answer_id):
        answer = get_object_or_404(ExpertAnswer, id=answer_id)
        prev_a = (
            ExpertAnswer.objects
            .filter(question=answer.question, order__lt=answer.order)
            .order_by('-order')
            .first()
        )
        if prev_a:
            with transaction.atomic():
                answer.order, prev_a.order = prev_a.order, answer.order
                answer.save(update_fields=["order"])
                prev_a.save(update_fields=["order"])
        return redirect(
            reverse("jeiko_administration_questionnaires_expert:test_detail", args=[answer.question.test.id])
        )


@method_decorator(never_cache, name='dispatch')
class ExpertAnswerMoveDown(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get(self, request, answer_id):
        answer = get_object_or_404(ExpertAnswer, id=answer_id)
        next_a = (
            ExpertAnswer.objects
            .filter(question=answer.question, order__gt=answer.order)
            .order_by('order')
            .first()
        )
        if next_a:
            with transaction.atomic():
                answer.order, next_a.order = next_a.order, answer.order
                answer.save(update_fields=["order"])
                next_a.save(update_fields=["order"])
        return redirect(
            reverse("jeiko_administration_questionnaires_expert:test_detail", args=[answer.question.test.id])
        )


@method_decorator(never_cache, name='dispatch')
class ExpertProfileTypeCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = ExpertProfileType
    form_class = ExpertProfileTypeForm
    template_name = "questionnaires_expert/profil_form.html"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def dispatch(self, request, *args, **kwargs):
        self.test = get_object_or_404(ExpertTest, id=self.kwargs['test_id'])
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        form.instance.test = self.test
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.test.id])

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        test_id = self.kwargs.get('test_id') or self.object.test_id
        kwargs['test'] = get_object_or_404(ExpertTest, pk=test_id)
        return kwargs


@method_decorator(never_cache, name='dispatch')
class ExpertProfileTreeView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    """
    L'arborescence des profils d'un test.

    L'écran de détail du test liste les profils à plat : rien n'y montre qu'un
    profil en précise un autre, alors que c'est cette hiérarchie qui décide du
    résultat rendu au répondant. Cette vue la rend visible.

    La construction de l'arbre est faite par `profile_tree.construire_foret`,
    en Python : la relation est un ManyToMany, donc un graphe — avec des
    profils à plusieurs parents et des cycles possibles — et ce n'est pas
    quelque chose qu'un gabarit sait démêler. Une tentative précédente s'y
    était essayée avec des filtres inventés, et ne compilait pas.
    """

    model = ExpertTest
    pk_url_kwarg = "test_id"
    context_object_name = "test"
    template_name = "questionnaires_expert/profile_tree.html"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_context_data(self, **kwargs):
        from jeiko.questionnaires_expert.profile_tree import construire_foret

        context = super().get_context_data(**kwargs)
        # `parent_profiles` est lu pour chaque profil par le constructeur, et
        # `result_page` par le gabarit : sans ce préchargement, l'écran fait
        # deux requêtes par profil.
        profils = (
            self.object.profiles
            .select_related("result_page")
            .prefetch_related("parent_profiles")
            .order_by("name")
        )
        context["racines"] = construire_foret(profils)
        context["nombre_profils"] = len(profils)
        return context


@method_decorator(never_cache, name='dispatch')
class ExpertProfileTypeUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = ExpertProfileType
    form_class = ExpertProfileTypeForm
    template_name = "questionnaires_expert/profil_form.html"
    pk_url_kwarg = "pk"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.test.id])

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        test_id = self.kwargs.get('test_id') or self.object.test_id
        kwargs['test'] = get_object_or_404(ExpertTest, pk=test_id)
        return kwargs

@method_decorator(never_cache, name='dispatch')
class ExpertProfileTypeDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = ExpertProfileType
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "profile_id"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCombinationCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = ExpertProfileCombination
    form_class = ExpertProfileCombinationForm
    template_name = "questionnaires_expert/profile_combination_form.html"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def dispatch(self, request, *args, **kwargs):
        self.test = get_object_or_404(ExpertTest, id=self.kwargs['test_id'])
        return super().dispatch(request, *args, **kwargs)

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        queryset = ExpertProfileType.objects.filter(test=self.test)
        form.fields['parent_profile'].queryset = queryset
        form.fields['preferred_profile'].queryset = queryset
        form.fields['alternative_profile'].queryset = queryset
        return form

    def form_valid(self, form):
        form.instance.test = self.test
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCombinationUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = ExpertProfileCombination
    form_class = ExpertProfileCombinationForm
    template_name = "questionnaires_expert/profile_combination_form.html"
    pk_url_kwarg = "pk"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        test_profiles = self.object.test.profiles.all()
        form.fields['parent_profile'].queryset = test_profiles
        form.fields['preferred_profile'].queryset = test_profiles
        form.fields['alternative_profile'].queryset = test_profiles
        return form


    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCombinationDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = ExpertProfileCombination
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "pk"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCriterionCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = ExpertProfileCriterion
    fields = ['profile_a', 'comparison', 'profile_b', 'tolerance', 'priority']
    template_name = "questionnaires_expert/profile_criterion_form.html"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def dispatch(self, request, *args, **kwargs):
        self.combination = get_object_or_404(ExpertProfileCombination, id=self.kwargs['combination_id'])
        return super().dispatch(request, *args, **kwargs)

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        test = self.combination.test
        queryset = ExpertProfileType.objects.filter(test=test)
        form.fields['profile_a'].queryset = queryset
        form.fields['profile_b'].queryset = queryset
        return form

    def form_valid(self, form):
        form.instance.combination = self.combination
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.combination.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCriterionUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = ExpertProfileCriterion
    fields = ['profile_a', 'comparison', 'profile_b', 'tolerance', 'priority']
    template_name = "questionnaires_expert/profile_criterion_form.html"
    pk_url_kwarg = "criterion_id"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        profiles = self.object.combination.test.profiles.all()
        form.fields['profile_a'].queryset = profiles
        form.fields['profile_b'].queryset = profiles
        return form

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.combination.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCriterionDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = ExpertProfileCriterion
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "criterion_id"

    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.combination.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertTestDataDetailView(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'questionnaires_expert.view_prospect'
    raise_exception = True

    def get(self, request, pk):
        test_data = get_object_or_404(ExpertTestData, pk=pk)
        # NB: la clé de contexte ne doit pas s'appeler "user" : elle masquerait
        # l'utilisateur connecté fourni par le context processor auth.
        test_user = test_data.user
        prospect = test_data.prospect
        comments = Comments.objects.filter(test_data=test_data).order_by('-date_created')
        comment_form = CommentsForm()

        # Préparer pour l’affichage (data dans le JSONField)
        result_data = test_data.data or {}

        return render(request, "questionnaires_expert/test_data_detail.html", {
            "test_data": test_data,
            "test_user": test_user,
            "prospect": prospect,
            "result_data": result_data,
            "comments": comments,
            "comment_form": comment_form,
        })

    def post(self, request, pk):
        test_data = get_object_or_404(ExpertTestData, pk=pk)
        # NB: la clé de contexte ne doit pas s'appeler "user" : elle masquerait
        # l'utilisateur connecté fourni par le context processor auth.
        test_user = test_data.user
        prospect = test_data.prospect
        comment_form = CommentsForm(request.POST)

        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.test_data = test_data
            if test_user:
                comment.user = test_user
            if prospect:
                comment.prospect = prospect
            comment.save()
            return redirect(reverse("jeiko_administration_questionnaires_expert:test_data_detail", args=[pk]))

        # En cas d’erreur, on réaffiche la page avec le form rempli
        comments = Comments.objects.filter(test_data=test_data).order_by('-date_created')
        result_data = test_data.data or {}
        return render(request, "questionnaires_expert/test_data_detail.html", {
            "test_data": test_data,
            "test_user": test_user,
            "prospect": prospect,
            "result_data": result_data,
            "comments": comments,
            "comment_form": comment_form,
        })

@method_decorator(never_cache, name='dispatch')
class ExpertTestResultsListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    """
    Tous les passages d'un test, quelle que soit la façon dont ils ont été faits.

    La liste des prospects ne montre que les visiteurs non connectés : les
    résultats des utilisateurs authentifiés n'étaient visibles que depuis la
    fiche de l'utilisateur, dans le module Users.
    """
    model = ExpertTestData
    template_name = "questionnaires_expert/test_results_list.html"
    context_object_name = "results"
    paginate_by = 50

    permission_required = 'questionnaires_expert.view_prospect'
    raise_exception = True

    def dispatch(self, request, *args, **kwargs):
        self.test = get_object_or_404(ExpertTest, id=self.kwargs['test_id'])
        return super().dispatch(request, *args, **kwargs)

    def get_queryset(self):
        return (
            ExpertTestData.objects
            .filter(test=self.test)
            .select_related('user', 'prospect', 'result_profile')
            .order_by('-created_at')
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        queryset = self.get_queryset()
        context['test'] = self.test
        context['total_count'] = queryset.count()
        context['user_count'] = queryset.filter(user__isnull=False).count()
        context['prospect_count'] = queryset.filter(prospect__isnull=False).count()
        return context


@method_decorator(never_cache, name='dispatch')
class ProspectListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Prospect
    template_name = "questionnaires_expert/prospect_list.html"
    context_object_name = "prospects"
    paginate_by = 50  # optionnel

    permission_required = 'questionnaires_expert.view_prospect'
    raise_exception = True

    def get_queryset(self):
        qs = Prospect.objects.all().order_by('-last_test_date')
        # Tu peux ajouter des filtres ici si besoin
        return qs

@permission_required('questionnaires_expert.view_prospect', raise_exception=True)
def prospects_for_test(request, test_id):
    test = get_object_or_404(ExpertTest, id=test_id)
    # Récupérer tous les prospects ayant passé ce test
    prospect_ids = ExpertTestData.objects.filter(test=test, prospect__isnull=False).values_list('prospect_id', flat=True)
    prospects = Prospect.objects.filter(id__in=prospect_ids).distinct()
    return render(request, "questionnaires_expert/prospect_list.html", {
        "prospects": prospects,
        "test": test,
    })

@permission_required('questionnaires_expert.view_prospect', raise_exception=True)
def prospect_detail(request, pk):
    prospect = get_object_or_404(Prospect, pk=pk)
    test_data_list = (
        ExpertTestData.objects
        .filter(prospect=prospect)
        .select_related('test')
        .order_by('-created_at')
    )
    return render(request, "questionnaires_expert/prospect_detail.html", {
        "prospect": prospect,
        "test_data_list": test_data_list,
    })


@method_decorator(never_cache, name='dispatch')
class ExpertTestDimensionsView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Tout le résultat « par dimensions » sur un seul écran.

    Un questionnaire de cinq dimensions, c'est quinze contenus : les répartir
    sur quinze écrans obligerait à naviguer sans voir l'ensemble. Ici, chaque
    dimension montre ses pôles et ses trois tranches côte à côte, et un seul
    bouton enregistre tout — ou rien, si une tranche est invalide.
    """

    template_name = "questionnaires_expert/dimensions_form.html"
    permission_required = 'questionnaires_expert.change_questionnaire'
    raise_exception = True

    def construire(self, test, data=None):
        from jeiko.questionnaires_expert.dimensions import dimension_profiles
        from jeiko.questionnaires_expert.models import ExpertDimensionBand

        reglages = DimensionsSettingsForm(data, instance=test, prefix="reglages")
        dimensions = []
        for profil in dimension_profiles(test):
            existantes = {b.position: b for b in profil.bands.all()}
            tranches = []
            for position, libelle in ExpertDimensionBand.POSITION_CHOICES:
                instance = existantes.get(position) or ExpertDimensionBand(
                    profile=profil, position=position,
                )
                tranches.append({
                    "position": position,
                    "libelle": libelle,
                    "form": DimensionBandForm(
                        data, instance=instance, prefix=f"t{profil.id}-{position}",
                    ),
                })
            dimensions.append({
                "profil": profil,
                "form": DimensionProfileForm(data, instance=profil, prefix=f"p{profil.id}"),
                "tranches": tranches,
            })
        return reglages, dimensions

    def rendre(self, request, test, reglages, dimensions, status=200):
        return render(request, self.template_name, {
            "test": test, "reglages": reglages, "dimensions": dimensions,
        }, status=status)

    def get(self, request, test_id):
        test = get_object_or_404(ExpertTest, pk=test_id)
        reglages, dimensions = self.construire(test)
        return self.rendre(request, test, reglages, dimensions)

    def post(self, request, test_id):
        test = get_object_or_404(ExpertTest, pk=test_id)
        reglages, dimensions = self.construire(test, request.POST)

        valides = reglages.is_valid()
        for dimension in dimensions:
            valides &= dimension["form"].is_valid()
            for tranche in dimension["tranches"]:
                valides &= tranche["form"].is_valid()

        if valides:
            mini = reglages.cleaned_data["dimension_scale_min"]
            maxi = reglages.cleaned_data["dimension_scale_max"]
            for dimension in dimensions:
                pleines = [t for t in dimension["tranches"] if not t["form"].est_vide()]
                for tranche in pleines:
                    form = tranche["form"]
                    de, a = form.cleaned_data["min_score"], form.cleaned_data["max_score"]
                    if de < mini or a > maxi:
                        form.add_error(None, f"Cette tranche sort de l'échelle ({mini:g} à {maxi:g}).")
                        valides = False
                # Trié par clé : deux tranches aux mêmes bornes ne doivent pas
                # obliger Python à comparer les dictionnaires eux-mêmes.
                bornes = sorted(
                    (t for t in pleines if not t["form"].errors),
                    key=lambda t: (t["form"].cleaned_data["min_score"],
                                   t["form"].cleaned_data["max_score"]),
                )
                for t1, t2 in zip(bornes, bornes[1:]):
                    fin1 = t1["form"].cleaned_data["max_score"]
                    debut2 = t2["form"].cleaned_data["min_score"]
                    if debut2 <= fin1:
                        t2["form"].add_error(
                            None,
                            f"Chevauche la tranche « {t1['libelle']} » : un score doit "
                            f"tomber dans une seule tranche (bornes incluses).",
                        )
                        valides = False

        if not valides:
            messages.error(request, "Rien n'a été enregistré : corrigez les champs signalés.")
            return self.rendre(request, test, reglages, dimensions, status=400)

        with transaction.atomic():
            reglages.save()
            for dimension in dimensions:
                dimension["form"].save()
                for tranche in dimension["tranches"]:
                    form = tranche["form"]
                    if form.est_vide():
                        if form.instance.pk:
                            form.instance.delete()
                    else:
                        form.save()

        messages.success(request, "Résultat par dimensions enregistré.")
        return redirect("jeiko_administration_questionnaires_expert:test_dimensions", test_id=test.id)
