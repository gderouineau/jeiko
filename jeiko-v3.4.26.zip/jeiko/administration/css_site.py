"""E-08 : feuille globale bornée au contenu, jamais à l'interface d'édition.

Les règles sont analysées, pas nettoyées par suppressions silencieuses.
Les imports, polices externes et règles globales sont refusés. Ce compilateur
ne valide pas toutes les propriétés CSS : une valeur inconnue reste inopérante.
"""
import re

import tinycss2
from django.core.exceptions import ValidationError

SCOPE = '.content:not(:where(#editor-modal *))'


def _refuser(message):
    raise ValidationError(message)


def _structure(source):
    # tinycss2 répare les accolades manquantes : ne pas enregistrer cette
    # réparation silencieusement. Chaînes, commentaires et échappements ne
    # comptent pas comme délimiteurs.
    pile, quote, commentaire, i = [], None, False, 0
    while i < len(source):
        c = source[i]
        if commentaire:
            if source[i:i+2] == '*/':
                commentaire, i = False, i + 2
            else:
                i += 1
            continue
        if c == '\\':
            i += 2
            continue
        if quote:
            if c == quote:
                quote = None
        elif source[i:i+2] == '/*':
            commentaire, i = True, i + 2
            continue
        elif c in ('"', "'"):
            quote = c
        elif c in '({[':
            pile.append(c)
        elif c in ')}]':
            if not pile or pile.pop() != {')': '(', '}': '{', ']': '['}[c]:
                _refuser('Délimiteurs CSS incohérents.')
        i += 1
    if pile or quote or commentaire:
        _refuser('CSS incomplet : délimiteur, chaîne ou commentaire non fermé.')


def _valeurs(tokens):
    for token in tokens:
        if token.type in ('error', '{} block'):
            _refuser('Valeur CSS invalide ou règle imbriquée non prise en charge.')
        if token.type == 'url':
            _url(token.value)
        if token.type == 'function':
            nom = token.lower_name
            if nom in ('expression', 'image-set', '-webkit-image-set'):
                _refuser(f'Fonction CSS non autorisée : {nom}.')
            if nom == 'url':
                args = [t for t in token.arguments if t.type not in ('whitespace', 'comment')]
                if len(args) != 1 or args[0].type != 'string':
                    _refuser('URL CSS invalide.')
                _url(args[0].value)
            _valeurs(token.arguments)
        if hasattr(token, 'content'):
            _valeurs(token.content)


def _url(value):
    if not value.startswith('/') or value.startswith('//') or '\\' in value or any(c.isspace() for c in value):
        _refuser('Seules les URL locales commençant par / sont autorisées.')


def _selecteurs(tokens):
    _valeurs(tokens)
    groupes, actuel = [], []
    for token in tokens:
        if token.type == 'literal' and token.value == ',':
            groupes.append(actuel)
            actuel = []
        else:
            actuel.append(token)
    groupes.append(actuel)
    resultat = []
    for groupe in groupes:
        texte = tinycss2.serialize(groupe).strip()
        if not texte:
            _refuser('Sélecteur CSS vide.')
        if texte == '.content':
            resultat.append(SCOPE)
            continue
        # Le pseudo-élément appartient au sujet, à l'extérieur de :is().
        pseudo = re.search(r'::(before|after|marker|first-letter|first-line|selection)$', texte, re.I)
        suffixe = pseudo.group(0) if pseudo else ''
        sujet = texte[:pseudo.start()] if pseudo else texte
        if '::' in sujet:
            _refuser('Pseudo-élément non pris en charge dans ce sélecteur.')
        resultat.append(f'{SCOPE} :is({sujet}){suffixe}')
    return ', '.join(resultat)


def _regles(regles, profondeur=0):
    if profondeur > 10:
        _refuser('Trop de niveaux de règles CSS.')
    resultat = []
    for regle in regles:
        if regle.type in ('comment', 'whitespace'):
            continue
        if regle.type == 'at-rule':
            if regle.lower_at_keyword not in ('media', 'supports', 'container') or regle.content is None:
                _refuser(f'Règle @{regle.at_keyword} non autorisée.')
            _valeurs(regle.prelude)
            enfants = tinycss2.parse_rule_list(regle.content, skip_comments=True, skip_whitespace=True)
            resultat.append(f'@{regle.at_keyword} {tinycss2.serialize(regle.prelude).strip()}{{{_regles(enfants, profondeur+1)}}}')
        elif regle.type == 'qualified-rule':
            selecteur = _selecteurs(regle.prelude)
            declarations = tinycss2.parse_declaration_list(regle.content, skip_comments=True, skip_whitespace=True)
            for declaration in declarations:
                if declaration.type != 'declaration':
                    _refuser('Déclaration CSS invalide ; imbrication non prise en charge.')
                if declaration.lower_name in ('behavior', '-moz-binding'):
                    _refuser('Propriété CSS non autorisée.')
                _valeurs(declaration.value)
            resultat.append(f'{selecteur}{{{tinycss2.serialize(declarations)}}}')
        else:
            _refuser('Règle CSS invalide.')
    return '\n'.join(resultat)


def compiler_css_site(source):
    if not isinstance(source, str) or len(source) > 50000:
        _refuser('Le CSS doit être un texte de 50 000 caractères au maximum.')
    if '<' in source or '\x00' in source:
        _refuser('Le CSS ne doit pas contenir de HTML ni de caractère nul.')
    _structure(source)
    resultat = _regles(tinycss2.parse_stylesheet(source, skip_comments=True, skip_whitespace=True))
    # Une chaîne CSS échappée (\\3c /style...) peut devenir du HTML à la
    # sérialisation. Vérifier aussi la sortie, avant tout |safe de gabarit.
    if '<' in resultat:
        _refuser('Les échappements CSS ne doivent pas produire de HTML.')
    return resultat
