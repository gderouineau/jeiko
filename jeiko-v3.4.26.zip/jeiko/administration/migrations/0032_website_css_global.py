from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('administration', '0031_siteidentity_default_share_image')]
    operations = [migrations.AddField(
        model_name='website', name='css_global',
        field=models.TextField(blank=True, default='', verbose_name='CSS global du contenu'),
    )]
