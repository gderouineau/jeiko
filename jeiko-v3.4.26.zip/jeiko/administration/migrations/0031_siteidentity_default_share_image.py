import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("administration", "0030_theme_du_site"),
        ("administration_pages", "0061_imagecontent_title"),
    ]

    operations = [
        migrations.AddField(
            model_name="siteidentity",
            name="default_share_image",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="default_share_for_identities",
                to="administration_pages.imagecontent",
                verbose_name="Image de partage par défaut",
            ),
        ),
    ]
