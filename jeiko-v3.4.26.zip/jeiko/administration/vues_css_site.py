"""E-08 : réglage global sans application du CSS à son propre écran."""
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import F
from django.shortcuts import render, redirect
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.cache import never_cache

from .forms_css_site import CssSiteForm
from .models import WebSite
from .website_cache import invalidate_website_data


@method_decorator(never_cache, name='dispatch')
class CssSiteView(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = 'users.config_edit_site'
    raise_exception = True
    template_name = 'administration/css_site/update.html'

    def get(self, request):
        site = WebSite.objects.first()
        if site is None:
            messages.error(request, "Aucun site n'est encore configuré.")
            return redirect('jeiko_administration:main')
        return render(request, self.template_name, {'form': CssSiteForm(instance=site)})

    def post(self, request):
        site = WebSite.objects.first()
        if site is None:
            return redirect('jeiko_administration:main')
        form = CssSiteForm(request.POST, instance=site)
        if form.is_valid():
            # Incrément SQL atomique ; update ne déclenche pas post_save,
            # donc l'invalidation explicite du cache est indispensable.
            WebSite.objects.filter(pk=site.pk).update(
                css_global=form.cleaned_data['css_global'], assets_version=F('assets_version') + 1,
            )
            invalidate_website_data()
            messages.success(request, 'CSS global enregistré pour le contenu du site.')
            return redirect('jeiko_administration:css_site')
        return render(request, self.template_name, {'form': form}, status=400)
