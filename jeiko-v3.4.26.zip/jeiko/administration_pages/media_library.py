"""Inventaire et suppression sûre des images de la médiathèque.

Ce module est volontairement indépendant des vues : l'administration et les
autres points d'entrée peuvent appliquer exactement la même règle métier.
Une image utilisée n'est jamais supprimée implicitement ; l'appelant reçoit la
liste des dépendances à retirer ou à remplacer avant de réessayer.
"""

from dataclasses import dataclass

from django.db import IntegrityError, transaction
from django.db.models import Count
from django.db.models.deletion import ProtectedError, RestrictedError

from .models import ImageContent


LIBELLES_USAGES = {
    "administration.siteidentity.default_share_image": "Images de partage par défaut",
    "administration_pages.page.main_image": "Images principales de pages",
    "administration_pages.section.background_image": "Fonds de sections",
    "administration_pages.line.background_image": "Fonds de lignes",
    "administration_pages.bloc.background_image": "Fonds de blocs",
    "administration_pages.contentimage.image_content": "Blocs image",
    "administration_pages.contentvideo.poster": "Vignettes de vidéos",
    "administration_pages.dyncarouselslide.image": "Diapositives de carrousel",
    "administration_pages.dyntestimonialitem.avatar": "Avatars de témoignages",
    "administration_pages.dyngalleryitem.image": "Éléments de galerie",
    "custom_objects.customobject.main_image": "Images principales de fiches",
    "custom_objects.customobjectvalue.image": "Champs image de fiches",
    "questionnaires_expert.experttest.main_image": "Images de questionnaires",
    "shop.productimage.image": "Images de produits",
}


@dataclass(frozen=True)
class ImageUsage:
    label: str
    model_label: str
    field_name: str
    count: int
    items: tuple


@dataclass(frozen=True)
class ImageDeletionResult:
    deleted: bool
    message: str
    usages: tuple = ()


def _relations_images():
    """Toutes les relations inverses concrètes qui ciblent ImageContent."""
    return tuple(
        relation
        for relation in ImageContent._meta.related_objects
        if getattr(relation, "field", None) is not None
        and not relation.field.many_to_many
    )


def _relation_label(relation):
    model = relation.related_model
    cle = f"{model._meta.label_lower}.{relation.field.name}"
    return LIBELLES_USAGES.get(cle, str(model._meta.verbose_name_plural).capitalize())


def _item_label(item):
    texte = str(item).strip()
    valeur_par_defaut = f"{item.__class__.__name__} object ({item.pk})"
    if not texte or texte == valeur_par_defaut:
        return f"{item._meta.verbose_name} n°{item.pk}"
    return texte


def image_usage_count_map(images):
    """Compte tous les usages d'un lot d'images sans requête par image."""
    image_ids = [image.pk for image in images if image.pk]
    comptes = {image_id: 0 for image_id in image_ids}
    if not image_ids:
        return comptes

    for relation in _relations_images():
        champ = relation.field.name
        cle = f"{champ}_id"
        lignes = (
            relation.related_model._base_manager
            .filter(**{f"{cle}__in": image_ids})
            .values(cle)
            .annotate(total=Count("pk"))
        )
        for ligne in lignes:
            comptes[ligne[cle]] += ligne["total"]
    return comptes


def image_usages(image, item_limit=20):
    """Retourne les usages regroupés, assez détaillés pour agir avant suppression."""
    groupes = []
    for relation in _relations_images():
        champ = relation.field.name
        queryset = relation.related_model._base_manager.filter(
            **{f"{champ}_id": image.pk}
        ).order_by("pk")
        total = queryset.count()
        if not total:
            continue
        items = tuple(
            {"id": item.pk, "label": _item_label(item)}
            for item in queryset[:item_limit]
        )
        groupes.append(ImageUsage(
            label=_relation_label(relation),
            model_label=relation.related_model._meta.label_lower,
            field_name=champ,
            count=total,
            items=items,
        ))
    return tuple(groupes)


def image_preview_url(image):
    """URL de la variante la plus utile disponible, sans laisser `.url` lever."""
    for champ in (
        "mobile_size", "tablet_size", "laptop_size", "computer_size",
        "full_size", "original_image",
    ):
        fichier = getattr(image, champ, None)
        if not fichier:
            continue
        try:
            return fichier.url
        except (ValueError, OSError, NotImplementedError):
            continue
    return ""


def delete_image_safely(image):
    """Supprime une image libre, ou renvoie un refus métier détaillé.

    Le verrou et la seconde lecture des usages réduisent la fenêtre de course
    entre l'écran de confirmation et le POST. Les protections de schéma restent
    la dernière barrière si une référence apparaît malgré tout.
    """
    try:
        with transaction.atomic():
            courante = ImageContent.objects.select_for_update().get(pk=image.pk)
            usages = image_usages(courante)
            if usages:
                total = sum(groupe.count for groupe in usages)
                return ImageDeletionResult(
                    False,
                    f"Suppression refusée : cette image possède {total} usage(s).",
                    usages,
                )
            courante.delete()
    except ImageContent.DoesNotExist:
        return ImageDeletionResult(False, "Cette image n'existe plus.")
    except (ProtectedError, RestrictedError, IntegrityError):
        # Une référence concurrente peut apparaître après l'inventaire. On ne
        # diffuse pas l'exception SQL et on restitue l'état actuel si possible.
        courante = ImageContent.objects.filter(pk=image.pk).first()
        usages = image_usages(courante) if courante else ()
        return ImageDeletionResult(
            False,
            "Suppression refusée : l'image est encore utilisée.",
            usages,
        )
    return ImageDeletionResult(True, "Image supprimée de la médiathèque.")
