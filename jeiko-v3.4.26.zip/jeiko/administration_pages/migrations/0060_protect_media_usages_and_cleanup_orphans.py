import django.db.models.deletion
from django.db import migrations, models


def remove_orphan_content_images(apps, schema_editor):
    """Retire les satellites laissés par d'anciens blocs supprimés.

    L'ImageContent associé est volontairement conservé : c'est l'actif de la
    médiathèque, potentiellement partagé ; seul le réglage de bloc orphelin est
    devenu inutile.
    """
    ContentImage = apps.get_model("administration_pages", "ContentImage")
    ContentImage.objects.filter(content__isnull=True).delete()


class Migration(migrations.Migration):
    dependencies = [
        ("administration_pages", "0059_alter_bloc_background_image_and_more"),
    ]

    operations = [
        migrations.RunPython(remove_orphan_content_images, migrations.RunPython.noop),
        migrations.AlterField(
            model_name="contentimage",
            name="image_content",
            field=models.OneToOneField(
                on_delete=django.db.models.deletion.PROTECT,
                related_name="content_image",
                to="administration_pages.imagecontent",
            ),
        ),
        migrations.AlterField(
            model_name="dyncarouselslide",
            name="image",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.PROTECT,
                related_name="carousel_slides",
                to="administration_pages.imagecontent",
            ),
        ),
        migrations.AlterField(
            model_name="dyngalleryitem",
            name="image",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.PROTECT,
                related_name="gallery_items",
                to="administration_pages.imagecontent",
            ),
        ),
        migrations.AlterField(
            model_name="dyntestimonialitem",
            name="avatar",
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="testimonial_avatars",
                to="administration_pages.imagecontent",
            ),
        ),
    ]
