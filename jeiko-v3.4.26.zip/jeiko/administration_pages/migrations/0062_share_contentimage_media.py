"""M-02 : retire l'unicité du média sans perdre les usages ni PROTECT."""

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("administration_pages", "0061_imagecontent_title"),
    ]

    operations = [
        migrations.AlterField(
            model_name="contentimage",
            name="image_content",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.PROTECT,
                related_name="content_image",
                to="administration_pages.imagecontent",
            ),
        ),
    ]
