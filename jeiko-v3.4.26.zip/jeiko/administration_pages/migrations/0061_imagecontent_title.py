from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("administration_pages", "0060_protect_media_usages_and_cleanup_orphans"),
    ]

    operations = [
        migrations.AddField(
            model_name="imagecontent",
            name="title",
            field=models.CharField(
                blank=True,
                default="",
                help_text="Nom permettant de retrouver l'image dans la médiathèque.",
                max_length=200,
                verbose_name="Titre interne",
            ),
        ),
    ]
