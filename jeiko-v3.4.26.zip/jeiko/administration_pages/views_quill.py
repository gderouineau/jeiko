"""E-07 : aperçu du CSS du bloc sans sauvegarde ni logique CSS parallèle.

Le formulaire et le gabarit publics restent la source de vérité. Cette vue
réservée aux éditeurs ne crée aucun satellite et ne sauvegarde aucun modèle.
"""
import re

from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404
from django.template.loader import render_to_string
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.cache import never_cache

from .forms import CustomCSSForm
from .models import Bloc, CustomCSS, Line, Page, Section
from .views import EditorMutationMixin


@method_decorator(never_cache, name='dispatch')
class ApercuCssQuill(EditorMutationMixin, View):
    def handle_no_permission(self):
        return JsonResponse({'status': 'error', 'message': 'Droit de modification des pages requis.'}, status=403)

    def post(self, request, page_id, section_id, line_id, bloc_id):
        try:
            page = get_object_or_404(Page, pk=page_id)
            section = get_object_or_404(Section, pk=section_id, page=page)
            line = get_object_or_404(Line, pk=line_id, section=section)
            bloc = get_object_or_404(Bloc, pk=bloc_id, line=line)
        except Http404:
            return JsonResponse({'status': 'error', 'message': 'Bloc introuvable dans cette page.'}, status=404)
        prefix = 'customcss_bloc_'
        if sum(len(v) for k, values in request.POST.lists() if k.startswith(prefix + '-') for v in values) > 50000:
            return JsonResponse({'status': 'error', 'message': 'CSS trop volumineux pour cet aperçu.'}, status=400)
        css = CustomCSS.objects.filter(bloc=bloc).first() or CustomCSS(bloc=bloc)
        form = CustomCSSForm(request.POST, prefix=prefix, instance=css)
        if not form.is_valid():
            return JsonResponse({'status': 'error', 'message': 'Paramètres CSS invalides.', 'errors': form.errors.get_json_data()}, status=400)
        # _post_clean met à jour cette instance en mémoire uniquement.
        bloc._state.fields_cache['custom_css'] = form.instance
        html = render_to_string('administration_pages/styles/bloc.html', {'bloc': bloc, 'request': None})
        match = re.fullmatch(r'\s*<style\b[^>]*>(.*?)</style>\s*', html, flags=re.S)
        if not match:
            return JsonResponse({'status': 'error', 'message': 'Gabarit CSS du bloc indisponible.'}, status=500)
        return JsonResponse({'status': 'ok', 'css': match.group(1), 'classes': form.cleaned_data['object_classes']})
