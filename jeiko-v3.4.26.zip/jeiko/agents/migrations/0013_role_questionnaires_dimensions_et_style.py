"""
Le rôle « agent-questionnaires » couvre les tranches et le style.

Le résultat « par dimensions » ajoute deux modèles au questionnaire —
`ExpertDimensionBand` (les tranches) et, exposé à l'API en même temps,
`ExpertTestStyle` (Gestion du style). Le rôle listait ses permissions modèle
par modèle : sans cette migration, il aurait décrit un périmètre plus étroit
que ce que ses routes permettent réellement, et un exploitant qui lit le rôle
se serait trompé sur ce qu'il accorde.

Le rôle « Administrateur » reçoit aussi ces permissions : il a reçu toutes
celles qui existaient à son seed, et chaque modèle ajouté depuis doit lui être
donné explicitement (voir questionnaires_expert/0011).

Même mécanique que 0011 : on force la création des permissions — Django ne
les crée qu'après toutes les migrations — puis on attribue, de façon
idempotente.
"""

from django.db import migrations

MODELES = ("expertdimensionband", "expertteststyle")
ROLES = {
    "agent-questionnaires": ("view", "add", "change"),
    "administrateur": ("view", "add", "change", "delete"),
}


def peupler(apps, schema_editor):
    from django.apps import apps as registre_reel
    from django.contrib.auth.management import create_permissions

    create_permissions(registre_reel.get_app_config("questionnaires_expert"), verbosity=0)

    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    for slug, actions in ROLES.items():
        role = Role.objects.filter(slug=slug).first()
        if role is None:
            continue
        for modele in MODELES:
            for action in actions:
                permission = Permission.objects.filter(
                    codename=f"{action}_{modele}",
                    content_type__app_label="questionnaires_expert",
                ).first()
                if permission is not None:
                    RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer(apps, schema_editor):
    """Volontairement vide : on ne retire pas des droits déjà attribués."""


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0012_agent_plafond_horaire"),
        ("questionnaires_expert", "0014_resultat_par_dimensions"),
    ]

    operations = [migrations.RunPython(peupler, retirer)]
