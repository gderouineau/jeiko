# jeiko/agents/vues_questionnaires.py
"""
Les questionnaires experts — définir le test, ses profils, ses questions, ses poids.

Ce que c'est
------------
Un `ExpertTest` pose des questions ; chaque réponse porte des **poids** vers un
ou plusieurs **profils** ; à la fin, le profil le plus lourd gagne, et sa
**page de résultat** est affichée au visiteur. Un profil peut aussi être
attribué par un **score global** (`min_score` / `max_score`), et des
**combinaisons** arbitrent les cas où deux profils se disputent la première
place.

Autrement dit c'est le même mécanisme que les fiches de la boutique — une page
dessinée une fois, rendue avec les valeurs du moment — mais où le choix de la
page dépend d'un calcul au lieu d'une clé.

Pourquoi cette API existe
-------------------------
Construire un questionnaire à la main est long et ingrat : vingt questions,
quatre réponses chacune, cinq profils, et **quatre cents poids** à saisir un
par un dans un formulaire. C'est précisément le genre de travail qu'un agent
fait sans se tromper et sans se lasser — à condition qu'on lui donne la porte.

Ce qui est délibérément absent
------------------------------
**La suppression d'un test, d'une question ou d'un profil.** Un test supprimé
emporte ses questions, ses réponses, ses poids et **les passages déjà
enregistrés** — c'est-à-dire des données de visiteurs, parfois nominatives.
Même règle que les pages : un agent crée et corrige, il n'efface pas.

**Les passages et les prospects.** `ExpertTestData` et `Prospect` contiennent
des réponses de personnes identifiables. L'API de construction n'a aucune
raison de les lire, et une clé qui traîne ne doit pas pouvoir les exfiltrer.
Aucune route ne les expose.

**`is_restricted`** se règle, mais c'est un contrôle d'accès : voir le
commentaire à sa déclaration.

Le résultat « par dimensions »
------------------------------
Avec `mode_resultat: "dimensions"`, il n'y a plus de profil gagnant : chaque
profil simple est une dimension, et le visiteur reçoit pour CHACUNE le contenu
de la tranche (« bas », « milieu », « haut ») où tombe son score. La page est
composée par `questionnaires_expert/dimensions.py` ; `POST …/simuler/` la
compose pour des scores donnés, sans passage enregistré.

La règle d'écriture des listes
------------------------------
Envoyer « reponses » sur une question REMPLACE la liste entière, poids
compris. Comme partout ailleurs dans cette API : une liste ordonnée n'a pas de
clé stable sur laquelle fusionner, et rapprocher par position mettrait un poids
sur la mauvaise réponse — une erreur qui ne se voit qu'en passant le test.
"""

import re

from django.core.exceptions import ValidationError
from django.db import transaction
from django.shortcuts import get_object_or_404
from django.utils.text import slugify

from jeiko.administration_pages.models import ImageContent, Page
from jeiko.questionnaires_expert.models import (
    DEFAULT_TEST_STYLE, ExpertAnswer, ExpertAnswerProfileWeight, ExpertDimensionBand,
    ExpertProfileCombination, ExpertProfileCriterion, ExpertProfileType,
    ExpertQuestion, ExpertTest, ExpertTestStyle, validate_test_style,
)

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR = "questionnaires_expert.view_experttest"
AJOUTER = "questionnaires_expert.add_experttest"
MODIFIER = "questionnaires_expert.change_experttest"

#: Types de question, lus sur le modèle pour qu'ils ne puissent pas dériver.
TYPES_DE_QUESTION = [
    code for code, _ in ExpertQuestion._meta.get_field("question_type").choices
]

#: Comparaisons acceptées par un critère de combinaison.
COMPARAISONS = [c for c, _ in ExpertProfileCriterion.COMPARISON_CHOICES]


# --------------------------------------------------------------------------- #
#  Sérialisation
# --------------------------------------------------------------------------- #
POSITIONS_DE_TRANCHE = [code for code, _ in ExpertDimensionBand.POSITION_CHOICES]


def _tranche_en_dict(tranche):
    return {
        "de": tranche.min_score,
        "a": tranche.max_score,
        "titre": tranche.title,
        "texte": tranche.text,
        "forces": tranche.strengths_list(),
        "vigilance": tranche.watch_point,
        "piste": tranche.reflection,
    }


def _profil_en_dict(profil):
    tranches = {t.position: t for t in profil.bands.all()}
    return {
        "id": profil.id,
        "nom": profil.name,
        "slug": profil.slug,
        "description": profil.description or "",
        "page_de_resultat": profil.result_page_id,
        "complexe": profil.is_complex,
        "attribue_par_score": profil.is_score_profile,
        "score_min": profil.min_score,
        "score_max": profil.max_score,
        # Mode « dimensions » — sans effet dans le mode historique.
        "rang": profil.order,
        "couleur": profil.color,
        "pole_bas": profil.low_pole_label,
        "pole_haut": profil.high_pole_label,
        "tranches": {
            position: (_tranche_en_dict(tranches[position]) if position in tranches else None)
            for position in POSITIONS_DE_TRANCHE
        },
    }


def _reponse_en_dict(reponse):
    """
    Une réponse et ses poids.

    ⚠️ `ExpertAnswerProfileWeight.profile_type` est **nullable** : un poids
    enregistré depuis l'administration sans choisir de profil existe en base,
    et il ne compte pour rien dans le calcul. Lire `p.profile_type.slug` sur
    lui levait une `AttributeError` — donc un **500 sur tout le
    questionnaire**, dont on ne pouvait alors plus rien corriger par l'API.
    C'est ce qui bloquait le questionnaire nº 6 d'accompagnementhumain.com.

    On ne l'expose donc plus dans `poids` — il n'y a pas de clé à lui donner —
    mais on le COMPTE. Le taire complètement laisserait un agent chercher
    pourquoi un questionnaire ne se comporte pas comme sa description : une
    donnée cassée qu'on masque est pire qu'une donnée cassée qu'on nomme.
    """
    poids = {}
    orphelins = 0
    for p in reponse.profile_weights.select_related("profile_type"):
        if p.profile_type_id is None:
            orphelins += 1
            continue
        poids[p.profile_type.slug or str(p.profile_type_id)] = p.weight

    document = {
        "id": reponse.id,
        "texte": reponse.text,
        "rang": reponse.order,
        "active": reponse.is_active,
        # Les poids sont la matière du calcul : les taire obligerait à un
        # second appel pour relire ce qu'on vient d'écrire.
        "poids": poids,
    }
    if orphelins:
        document["poids_sans_profil"] = orphelins
    return document


def _question_en_dict(question):
    return {
        "id": question.id,
        "texte": question.text,
        "rang": question.order,
        "type": question.question_type,
        "active": question.is_active,
        "reponses": [
            _reponse_en_dict(r)
            for r in question.answers.all().order_by("order", "id")
        ],
    }


def _combinaison_en_dict(combinaison):
    return {
        "id": combinaison.id,
        "slug": combinaison.slug,
        "titre": combinaison.title or "",
        "profil_parent": combinaison.parent_profile_id,
        "profil_prefere": combinaison.preferred_profile_id,
        "profil_alternatif": combinaison.alternative_profile_id,
        "criteres": [
            {
                "profil_a": c.profile_a_id,
                "profil_b": c.profile_b_id,
                "comparaison": c.comparison,
                "tolerance": c.tolerance,
            }
            for c in combinaison.criteria.all()
        ],
    }


def _test_en_resume(test):
    return {
        "id": test.id,
        "titre": test.title,
        "slug": test.slug,
        "description": test.description or "",
        "actif": test.is_active,
        "acces_restreint": test.is_restricted,
        "image_principale_id": test.main_image_id,
        "page_de_presentation": test.presentation_page_id,
        "mention_precaution": test.intro_warning,
        "mode_resultat": test.result_mode,
        "echelle_min": test.dimension_scale_min,
        "echelle_max": test.dimension_scale_max,
        "texte_nuance": test.nuanced_text,
        "texte_final": test.closing_text,
        "bouton_libelle": test.cta_label,
        "bouton_page": test.cta_page_id,
        "style": _style_en_dict(test),
    }


def _test_en_dict(test):
    document = _test_en_resume(test)
    document["profils"] = [
        _profil_en_dict(p)
        for p in test.profiles.prefetch_related("bands").order_by("id")
    ]
    document["questions"] = [
        _question_en_dict(q)
        for q in test.questions.prefetch_related(
            "answers__profile_weights__profile_type"
        ).order_by("order", "id")
    ]
    document["combinaisons"] = [
        _combinaison_en_dict(c)
        for c in test.combinations.prefetch_related("criteria")
    ]
    return document


# --------------------------------------------------------------------------- #
#  Aides
# --------------------------------------------------------------------------- #
def _page(identifiant, quoi):
    """Une page par son identifiant, ou None. Lève si elle n'existe pas."""
    if identifiant in (None, "", 0):
        return None
    page = Page.objects.filter(pk=identifiant).first()
    if page is None:
        raise CorpsInvalide(f"Aucune page nº {identifiant} pour « {quoi} ».")
    return page


def _refuser_si_deja_passe(test, quoi):
    """
    On ne supprime pas ce dont des résultats dépendent.

    Les passages sont enregistrés dans `ExpertTestData.data`, un document JSON
    qui cite les questions et les réponses par identifiant — sans clé
    étrangère, donc sans que la base s'y oppose. Supprimer une question déjà
    répondue ne casse rien visiblement : cela rend illisibles des résultats
    déjà rendus à des personnes, en silence, et sans retour possible.

    `active: false` fait le travail dans ce cas : la question disparaît des
    passages à venir et les anciens restent interprétables. C'est d'ailleurs le
    contournement qu'un agent avait trouvé seul sur le terrain, faute de
    pouvoir supprimer — il avait raison.
    """
    if test.datas.exists():
        raise CorpsInvalide(
            f"Ce questionnaire a déjà été passé : supprimer {quoi} rendrait "
            f"illisibles des résultats déjà rendus. Passer « active » à false "
            f"la retire des passages à venir sans toucher aux anciens."
        )


def _profil_du_test(test, designation, quoi):
    """
    Un profil du test, désigné par slug ou par identifiant.

    Borné au test : sans ce filtre, un poids pourrait viser le profil d'un
    AUTRE questionnaire. La base l'accepterait — les deux sont des
    `ExpertProfileType` — et le calcul deviendrait faux sans rien signaler.
    """
    if designation in (None, ""):
        return None

    texte = str(designation).strip()
    profil = test.profiles.filter(slug=texte).first()
    if profil is None and texte.isdigit():
        profil = test.profiles.filter(pk=int(texte)).first()
    if profil is None:
        connus = list(test.profiles.values_list("slug", flat=True))
        raise CorpsInvalide(
            f"Aucun profil « {designation} » dans ce questionnaire "
            f"(« {quoi} »). Profils : {', '.join(c for c in connus if c) or 'aucun'}."
        )
    return profil


def _refuser_les_cles(corps, connues, quoi):
    inconnues = sorted(set(corps) - set(connues))
    if inconnues:
        raise CorpsInvalide(
            f"Clé(s) inconnue(s) pour {quoi} : {', '.join(inconnues)}. "
            f"Acceptées : {', '.join(sorted(connues))}."
        )


#: Le style d'un questionnaire (écran « Gestion du style »), en clés françaises.
#: Il habille les pages de questions ET la page de résultat par dimensions.
STYLE_API = {
    "police": "font_family",
    "couleur_titres": "title_color",
    "couleur_theme": "theme_color",
    "couleur_fond": "body_bg",
    "taille_titre_mobile": "title_size_mobile_px",
    "taille_titre_tablette": "title_size_tablet_px",
    "taille_titre_ordinateur": "title_size_desktop_px",
    "taille_reponses_mobile": "input_font_size_mobile_px",
    "taille_reponses_tablette": "input_font_size_tablet_px",
    "taille_reponses_ordinateur": "input_font_size_desktop_px",
    "taille_bouton": "submit_font_size_px",
    "arrondi_reponses": "answer_radius_px",
    "arrondi_bouton": "submit_radius_px",
}

#: Une pile de polices : lettres, chiffres, espaces, virgules, guillemets,
#: tirets. Rien qui puisse terminer une déclaration CSS.
POLICE_VALIDE = re.compile(r"[\w \-,'\"]{1,200}")


def _style_en_dict(test):
    try:
        brut = test.style_config.style or {}
    except ExpertTestStyle.DoesNotExist:
        brut = {}
    effectif = {**DEFAULT_TEST_STYLE, **brut}
    return {cle: effectif[interne] for cle, interne in STYLE_API.items()}


def _ecrire_le_style(test, style):
    """
    Fusionne `style` dans le style du questionnaire, après validation complète.

    Mêmes règles que l'écran humain (`validate_test_style`) ; la police, que
    celui-ci ne contrôlait pas, est bornée ici à une pile de noms.
    """
    if not isinstance(style, dict):
        raise CorpsInvalide("« style » est un objet, ex. {\"couleur_theme\": \"#2F6F8F\"}.")
    _refuser_les_cles(style, set(STYLE_API), "« style »")

    config, _ = ExpertTestStyle.objects.get_or_create(test=test)
    nouveau = {**DEFAULT_TEST_STYLE, **(config.style or {})}
    for cle, valeur in style.items():
        interne = STYLE_API[cle]
        if isinstance(DEFAULT_TEST_STYLE[interne], int):
            if isinstance(valeur, bool) or not isinstance(valeur, int):
                raise CorpsInvalide(f"« style.{cle} » attend un entier (pixels) — reçu {valeur!r}.")
        elif not isinstance(valeur, str):
            raise CorpsInvalide(f"« style.{cle} » attend un texte — reçu {valeur!r}.")
        nouveau[interne] = valeur.strip() if isinstance(valeur, str) else valeur

    if not POLICE_VALIDE.fullmatch(nouveau["font_family"] or ""):
        raise CorpsInvalide(
            "« style.police » attend une liste de polices, ex. "
            "« Inter, Arial, sans-serif » — sans ; { } ni autre ponctuation."
        )
    try:
        validate_test_style(nouveau)
    except ValidationError as souci:
        message = " ".join(souci.messages)
        for cle, interne in STYLE_API.items():
            message = message.replace(interne, f"style.{cle}")
        raise CorpsInvalide(message)

    config.style = nouveau
    config.save()


MODES_DE_RESULTAT = [code for code, _ in ExpertTest.RESULT_MODE_CHOICES]

#: Réglages du résultat, acceptés à la création comme en modification.
CLES_REGLAGES_RESULTAT = {
    "mention_precaution", "mode_resultat", "echelle_min", "echelle_max",
    "texte_nuance", "texte_final", "bouton_libelle", "bouton_page", "style",
}


def _nombre(valeur, cle):
    if isinstance(valeur, bool):
        raise CorpsInvalide(f"« {cle} » attend un nombre, pas un booléen.")
    try:
        return float(valeur)
    except (TypeError, ValueError):
        raise CorpsInvalide(f"« {cle} » attend un nombre — reçu {valeur!r}.")


def _ecrire_les_reglages_du_resultat(test, corps):
    """Applique les réglages présents dans `corps` ; rend les champs modifiés."""
    modifies = []
    textes = {
        "mention_precaution": "intro_warning",
        "texte_nuance": "nuanced_text",
        "texte_final": "closing_text",
    }
    for cle, champ in textes.items():
        if cle in corps:
            setattr(test, champ, str(corps[cle] or ""))
            modifies.append(champ)
    if "bouton_libelle" in corps:
        test.cta_label = str(corps["bouton_libelle"] or "").strip()[:120]
        modifies.append("cta_label")
    if "bouton_page" in corps:
        test.cta_page = _page(corps["bouton_page"], "bouton_page")
        modifies.append("cta_page")
    if "mode_resultat" in corps:
        mode = corps["mode_resultat"]
        if mode not in MODES_DE_RESULTAT:
            raise CorpsInvalide(
                f"« mode_resultat » vaut {', '.join(MODES_DE_RESULTAT)} — reçu {mode!r}."
            )
        test.result_mode = mode
        modifies.append("result_mode")
    for cle, champ in (("echelle_min", "dimension_scale_min"),
                       ("echelle_max", "dimension_scale_max")):
        if cle in corps:
            setattr(test, champ, _nombre(corps[cle], cle))
            modifies.append(champ)
    if test.dimension_scale_min >= test.dimension_scale_max:
        raise CorpsInvalide(
            f"echelle_min ({test.dimension_scale_min:g}) doit être inférieur à "
            f"echelle_max ({test.dimension_scale_max:g})."
        )
    return modifies


# --------------------------------------------------------------------------- #
#  Questionnaires
# --------------------------------------------------------------------------- #
class ListeDesQuestionnaires(VueAgent):
    permission_requise = VOIR

    def get(self, request):
        tests = ExpertTest.objects.order_by("title")
        return ok({"questionnaires": [_test_en_resume(t) for t in tests]})


class CreationQuestionnaire(VueAgent):
    permission_requise = AJOUTER

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)
        _refuser_les_cles(
            corps,
            {"titre", "slug", "description", "actif", "acces_restreint",
             "image_principale_id", "page_de_presentation"} | CLES_REGLAGES_RESULTAT,
            "un questionnaire",
        )

        titre = str(corps.get("titre") or "").strip()
        if not titre:
            raise CorpsInvalide("« titre » est obligatoire.")

        slug = slugify(str(corps.get("slug") or titre).strip())
        if not slug:
            raise CorpsInvalide("« slug » ne donne rien d'utilisable.")
        if ExpertTest.objects.filter(slug=slug).exists():
            raise CorpsInvalide(
                f"Le slug « {slug} » est déjà pris : il entre dans l'URL du test."
            )

        image = None
        if corps.get("image_principale_id"):
            image = ImageContent.objects.filter(
                pk=corps["image_principale_id"]
            ).first()
            if image is None:
                raise CorpsInvalide(
                    f"Aucune image nº {corps['image_principale_id']}. Voir /images/."
                )

        test = ExpertTest(
            title=titre[:200],
            slug=slug,
            description=str(corps.get("description") or ""),
            # Comme une page ou une fiche : inactif à la création. Un
            # questionnaire à moitié construit, avec ses questions et sans ses
            # poids, donnerait des résultats faux à qui le passerait.
            is_active=False,
            is_restricted=bool(corps.get("acces_restreint", False)),
            main_image=image,
            presentation_page=_page(
                corps.get("page_de_presentation"), "page_de_presentation"
            ),
        )
        _ecrire_les_reglages_du_resultat(test, corps)
        test.save()
        if "style" in corps:
            _ecrire_le_style(test, corps["style"])
        return ok({"questionnaire": _test_en_resume(test)}, statut=201)


class DetailQuestionnaire(VueAgent):
    """L'arbre complet d'un questionnaire, ou la modification de son entête."""

    permission_requise = VOIR

    def get(self, request, test_id):
        test = get_object_or_404(
            ExpertTest.objects.prefetch_related("profiles", "questions"), pk=test_id
        )
        return ok({"questionnaire": _test_en_dict(test)})

    @transaction.atomic
    def patch(self, request, test_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification de questionnaire non autorisée.", statut=403)

        test = get_object_or_404(ExpertTest, pk=test_id)
        corps = self.corps(request)
        _refuser_les_cles(
            corps,
            {"titre", "description", "actif", "acces_restreint",
             "image_principale_id", "page_de_presentation"} | CLES_REGLAGES_RESULTAT,
            "un questionnaire",
        )

        modifies = _ecrire_les_reglages_du_resultat(test, corps)
        style_modifie = "style" in corps
        if style_modifie:
            _ecrire_le_style(test, corps["style"])
        if "titre" in corps:
            test.title = str(corps["titre"]).strip()[:200]
            modifies.append("title")
        if "description" in corps:
            test.description = str(corps["description"])
            modifies.append("description")
        if "actif" in corps:
            test.is_active = bool(corps["actif"])
            modifies.append("is_active")
        if "acces_restreint" in corps:
            test.is_restricted = bool(corps["acces_restreint"])
            modifies.append("is_restricted")
        if "page_de_presentation" in corps:
            test.presentation_page = _page(
                corps["page_de_presentation"], "page_de_presentation"
            )
            modifies.append("presentation_page")
        if "image_principale_id" in corps:
            identifiant = corps["image_principale_id"]
            test.main_image = (
                ImageContent.objects.filter(pk=identifiant).first()
                if identifiant else None
            )
            modifies.append("main_image")

        if modifies:
            test.save(update_fields=modifies)
        # `style` vit dans son propre modèle : il ne passe pas par update_fields.
        return ok({"questionnaire": _test_en_resume(test),
                   "modifie": modifies + (["style"] if style_modifie else [])})


# --------------------------------------------------------------------------- #
#  Profils — les résultats possibles
# --------------------------------------------------------------------------- #
CLES_PROFIL = {
    "nom", "slug", "description", "page_de_resultat", "complexe",
    "attribue_par_score", "score_min", "score_max",
    "rang", "pole_bas", "pole_haut", "tranches", "couleur",
}
CLES_TRANCHE = {"de", "a", "titre", "texte", "forces", "vigilance", "piste"}


def _preparer_les_tranches(profil, tranches):
    """
    Valide « tranches » ENTIÈREMENT avant toute écriture.

    Rend `{position: dict | None}` : un objet remplace la tranche de cette
    position, `null` la retire, une position absente n'est pas touchée. Les
    bornes sont contrôlées sur l'état FINAL — une tranche qu'on ne renvoie pas
    compte aussi dans les chevauchements.
    """
    if not isinstance(tranches, dict):
        raise CorpsInvalide(
            "« tranches » est un objet {\"bas\": {…}, \"milieu\": {…}, \"haut\": {…}}."
        )
    _refuser_les_cles(tranches, set(POSITIONS_DE_TRANCHE), "« tranches »")

    test = profil.test
    prepares = {}
    for position, brut in tranches.items():
        if brut is None:
            prepares[position] = None
            continue
        if not isinstance(brut, dict):
            raise CorpsInvalide(f"Tranche « {position} » : un objet ou null est attendu.")
        _refuser_les_cles(brut, CLES_TRANCHE, f"la tranche « {position} »")
        for cle in ("de", "a"):
            if brut.get(cle) in (None, ""):
                raise CorpsInvalide(f"Tranche « {position} » : « {cle} » est obligatoire.")
        de = _nombre(brut["de"], f"tranches.{position}.de")
        a = _nombre(brut["a"], f"tranches.{position}.a")
        if de > a:
            raise CorpsInvalide(f"Tranche « {position} » : « de » ({de:g}) dépasse « a » ({a:g}).")
        if de < test.dimension_scale_min or a > test.dimension_scale_max:
            raise CorpsInvalide(
                f"Tranche « {position} » : {de:g}–{a:g} sort de l'échelle du questionnaire "
                f"({test.dimension_scale_min:g}–{test.dimension_scale_max:g})."
            )
        forces = brut.get("forces") or []
        if isinstance(forces, str):
            forces = forces.splitlines()
        if not isinstance(forces, list) or not all(isinstance(f, str) for f in forces):
            raise CorpsInvalide(f"Tranche « {position} » : « forces » est une liste de textes.")
        prepares[position] = {
            "min_score": de,
            "max_score": a,
            "title": str(brut.get("titre") or "").strip()[:200],
            "text": str(brut.get("texte") or ""),
            "strengths": "\n".join(f.strip() for f in forces if f.strip()),
            "watch_point": str(brut.get("vigilance") or ""),
            "reflection": str(brut.get("piste") or ""),
        }

    # Chevauchements, sur l'état final.
    finales = {}
    if profil.pk:
        finales = {t.position: (t.min_score, t.max_score) for t in profil.bands.all()}
    for position, valeurs in prepares.items():
        if valeurs is None:
            finales.pop(position, None)
        else:
            finales[position] = (valeurs["min_score"], valeurs["max_score"])
    bornes = sorted((mini, maxi, pos) for pos, (mini, maxi) in finales.items())
    for (min1, max1, pos1), (min2, max2, pos2) in zip(bornes, bornes[1:]):
        if min2 <= max1:
            raise CorpsInvalide(
                f"Les tranches « {pos1} » ({min1:g}–{max1:g}) et « {pos2} » "
                f"({min2:g}–{max2:g}) se chevauchent : un score doit tomber dans "
                f"une seule tranche. Les bornes sont incluses des deux côtés."
            )
    return prepares


def _enregistrer_les_tranches(profil, prepares):
    for position, valeurs in prepares.items():
        if valeurs is None:
            profil.bands.filter(position=position).delete()
        else:
            ExpertDimensionBand.objects.update_or_create(
                profile=profil, position=position, defaults=valeurs,
            )


def _ecrire_le_profil(profil, corps, creation):
    if creation:
        nom = str(corps.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide("« nom » est obligatoire pour un profil.")
        profil.name = nom[:200]
        profil.slug = slugify(str(corps.get("slug") or nom).strip())
    else:
        if "nom" in corps:
            profil.name = str(corps["nom"]).strip()[:200]
        # Le slug ne se modifie PAS : il est dans l'URL de la page de résultat
        # (`/…/resultat/<slug>/`), donc dans des liens déjà partagés et dans
        # les e-mails déjà envoyés. Le changer les casserait sans un mot.

    if "description" in corps:
        profil.description = str(corps["description"])
    if "page_de_resultat" in corps:
        profil.result_page = _page(corps["page_de_resultat"], "page_de_resultat")
    if "complexe" in corps:
        profil.is_complex = bool(corps["complexe"])
    if "attribue_par_score" in corps:
        profil.is_score_profile = bool(corps["attribue_par_score"])
    if "rang" in corps:
        rang = corps["rang"]
        if isinstance(rang, bool) or not isinstance(rang, int) or rang < 0:
            raise CorpsInvalide(f"« rang » attend un entier positif ou nul — reçu {rang!r}.")
        profil.order = rang
    if "couleur" in corps:
        couleur = str(corps["couleur"] or "").strip()
        if not re.fullmatch(r"#(?:[0-9a-fA-F]{3}){1,2}", couleur):
            raise CorpsInvalide(
                f"« couleur » attend un hexadécimal comme « #3A4BC7 » — reçu {corps['couleur']!r}."
            )
        profil.color = couleur
    if "pole_bas" in corps:
        profil.low_pole_label = str(corps["pole_bas"] or "").strip()[:120]
    if "pole_haut" in corps:
        profil.high_pole_label = str(corps["pole_haut"] or "").strip()[:120]

    for cle, champ in (("score_min", "min_score"), ("score_max", "max_score")):
        if cle in corps:
            valeur = corps[cle]
            if valeur in (None, ""):
                setattr(profil, champ, None)
                continue
            # `float("bas")` lève une ValueError, qui remontait jusqu'au 500 :
            # une faute de saisie devenait une panne serveur, et l'agent n'avait
            # pas le nom du champ fautif. Tout le reste de cette API refuse en
            # 400 en nommant ce qu'elle attend ; ce coin-là ne le faisait pas.
            try:
                setattr(profil, champ, float(valeur))
            except (TypeError, ValueError):
                raise CorpsInvalide(
                    f"« {cle} » attend un nombre — reçu {valeur!r}. "
                    f"Les bornes de score sont numériques : 0, 20, 12.5."
                )

    # Un intervalle inversé n'attribue jamais rien : le profil existerait sans
    # pouvoir sortir, et le test renverrait tout le monde ailleurs sans erreur.
    if (
        profil.is_score_profile
        and profil.min_score is not None
        and profil.max_score is not None
        and profil.min_score > profil.max_score
    ):
        raise CorpsInvalide(
            f"score_min ({profil.min_score}) dépasse score_max "
            f"({profil.max_score}) : aucun score ne pourrait attribuer ce profil."
        )


class ProfilsDuQuestionnaire(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def post(self, request, test_id):
        test = get_object_or_404(ExpertTest, pk=test_id)
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_PROFIL, "un profil")

        profil = ExpertProfileType(test=test)
        _ecrire_le_profil(profil, corps, creation=True)
        tranches = (
            _preparer_les_tranches(profil, corps["tranches"]) if "tranches" in corps else {}
        )

        if test.profiles.filter(slug=profil.slug).exists():
            raise CorpsInvalide(
                f"Un profil « {profil.slug} » existe déjà dans ce questionnaire."
            )
        profil.save()
        _enregistrer_les_tranches(profil, tranches)
        return ok({"profil": _profil_en_dict(profil)}, statut=201)


class DetailProfil(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def patch(self, request, profil_id):
        profil = get_object_or_404(ExpertProfileType, pk=profil_id)
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_PROFIL - {"slug"}, "un profil")

        _ecrire_le_profil(profil, corps, creation=False)
        tranches = (
            _preparer_les_tranches(profil, corps["tranches"]) if "tranches" in corps else {}
        )
        profil.save()
        _enregistrer_les_tranches(profil, tranches)
        return ok({"profil": _profil_en_dict(profil)})


# --------------------------------------------------------------------------- #
#  Questions, réponses et poids
# --------------------------------------------------------------------------- #
CLES_QUESTION = {"texte", "rang", "type", "active", "reponses"}
CLES_REPONSE = {"texte", "rang", "active", "poids"}


def _ecrire_les_reponses(question, reponses):
    """
    Remplace les réponses d'une question, poids compris.

    Tout est validé AVANT le premier effacement : une question à moitié
    réécrite, dont la troisième réponse a été refusée, laisserait le
    questionnaire dans un état qui fausse le calcul sans être visible.
    """
    if not isinstance(reponses, list):
        raise CorpsInvalide("« reponses » doit être une liste.")

    prepares = []
    for rang, brut in enumerate(reponses, 1):
        if not isinstance(brut, dict):
            raise CorpsInvalide(f"Réponse nº {rang} : un objet est attendu.")
        _refuser_les_cles(brut, CLES_REPONSE, f"la réponse nº {rang}")

        texte = str(brut.get("texte") or "").strip()
        if not texte:
            raise CorpsInvalide(f"Réponse nº {rang} : « texte » est obligatoire.")

        poids = brut.get("poids") or {}
        if not isinstance(poids, dict):
            raise CorpsInvalide(
                f"Réponse nº {rang} : « poids » est un objet "
                f"{{profil: valeur}}, pas une liste."
            )

        resolus = {}
        for designation, valeur in poids.items():
            profil = _profil_du_test(
                question.test, designation, f"le poids de la réponse nº {rang}"
            )
            try:
                resolus[profil] = float(valeur)
            except (TypeError, ValueError):
                raise CorpsInvalide(
                    f"Réponse nº {rang} : le poids vers « {designation} » "
                    f"doit être un nombre, pas « {valeur} »."
                )

        prepares.append({
            "text": texte[:300],
            "order": int(brut.get("rang", rang)),
            "is_active": bool(brut.get("active", True)),
            "poids": resolus,
        })

    question.answers.all().delete()
    for valeurs in prepares:
        poids = valeurs.pop("poids")
        reponse = ExpertAnswer.objects.create(question=question, **valeurs)
        for profil, valeur in poids.items():
            ExpertAnswerProfileWeight.objects.create(
                answer=reponse, profile_type=profil, weight=valeur
            )


class QuestionsDuQuestionnaire(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def post(self, request, test_id):
        test = get_object_or_404(ExpertTest, pk=test_id)
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_QUESTION, "une question")

        texte = str(corps.get("texte") or "").strip()
        if not texte:
            raise CorpsInvalide("« texte » est obligatoire pour une question.")

        type_question = str(corps.get("type") or "single").strip()
        if type_question not in TYPES_DE_QUESTION:
            raise CorpsInvalide(
                f"Type « {type_question} » inconnu. "
                f"Acceptés : {', '.join(TYPES_DE_QUESTION)}."
            )

        rang = corps.get("rang")
        if rang is None:
            dernier = test.questions.order_by("-order").first()
            rang = (dernier.order + 1) if dernier else 1

        question = ExpertQuestion.objects.create(
            test=test, text=texte, order=int(rang),
            question_type=type_question,
            is_active=bool(corps.get("active", True)),
        )
        if "reponses" in corps:
            _ecrire_les_reponses(question, corps["reponses"])

        question.refresh_from_db()
        return ok({"question": _question_en_dict(question)}, statut=201)


class DetailQuestion(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def patch(self, request, question_id):
        question = get_object_or_404(
            ExpertQuestion.objects.select_related("test"), pk=question_id
        )
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_QUESTION, "une question")

        modifies = []
        if "texte" in corps:
            question.text = str(corps["texte"])
            modifies.append("text")
        if "rang" in corps:
            question.order = int(corps["rang"])
            modifies.append("order")
        if "active" in corps:
            question.is_active = bool(corps["active"])
            modifies.append("is_active")
        if "type" in corps:
            if corps["type"] not in TYPES_DE_QUESTION:
                raise CorpsInvalide(
                    f"Type « {corps['type']} » inconnu. "
                    f"Acceptés : {', '.join(TYPES_DE_QUESTION)}."
                )
            question.question_type = corps["type"]
            modifies.append("question_type")

        if modifies:
            question.save(update_fields=modifies)
        if "reponses" in corps:
            _ecrire_les_reponses(question, corps["reponses"])
            modifies.append("reponses")

        question.refresh_from_db()
        return ok({"question": _question_en_dict(question), "modifie": modifies})

    @transaction.atomic
    def delete(self, request, question_id):
        question = get_object_or_404(
            ExpertQuestion.objects.select_related("test"), pk=question_id
        )
        _refuser_si_deja_passe(question.test, "cette question")
        question.delete()
        return ok({"supprime": question_id})


class DetailReponse(VueAgent):
    """
    Une réponse, et sa suppression.

    Elle était déjà supprimable en creux — `PATCH /questions/<id>/` avec
    « reponses » REMPLACE la liste, donc omettre une réponse l'efface. Mais
    supprimer une réponse sur trois obligeait alors à réécrire les deux autres
    et tous leurs poids, ce qui est exactement l'occasion de se tromper.
    """

    permission_requise = MODIFIER

    @transaction.atomic
    def delete(self, request, reponse_id):
        reponse = get_object_or_404(
            ExpertAnswer.objects.select_related("question__test"), pk=reponse_id
        )
        _refuser_si_deja_passe(reponse.question.test, "cette réponse")
        reponse.delete()
        return ok({"supprime": reponse_id})


# --------------------------------------------------------------------------- #
#  Combinaisons — l'arbitrage entre profils
# --------------------------------------------------------------------------- #
#
# Quand deux profils arrivent au coude à coude, le plus lourd ne dit pas
# toujours la bonne chose. Une combinaison décrit ce cas : « si A et B sont
# proches, alors montrer le profil préféré plutôt que le gagnant brut ».
#
# C'est la partie la plus délicate à saisir à la main — des triplets de profils
# et des comparaisons — et donc celle où une API rend le plus service.

CLES_COMBINAISON = {
    "slug", "titre", "profil_parent", "profil_prefere", "profil_alternatif",
    "criteres",
}
CLES_CRITERE = {"profil_a", "profil_b", "comparaison", "tolerance"}


class CombinaisonsDuQuestionnaire(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def post(self, request, test_id):
        test = get_object_or_404(ExpertTest, pk=test_id)
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_COMBINAISON, "une combinaison")

        titre = str(corps.get("titre") or "").strip()
        slug = slugify(str(corps.get("slug") or titre).strip())
        if not slug:
            raise CorpsInvalide(
                "« slug » (ou « titre », qui en tient lieu) est obligatoire."
            )
        if ExpertProfileCombination.objects.filter(slug=slug).exists():
            raise CorpsInvalide(f"La combinaison « {slug} » existe déjà.")

        # `parent_profile` est NOT NULL en base : l'omettre levait une
        # `NotNullViolation`, c'est-à-dire une 500. Une combinaison sans profil
        # parent n'aurait de toute façon aucun sens — c'est LUI qu'on arbitre.
        parent = _profil_du_test(test, corps.get("profil_parent"), "profil_parent")
        if parent is None:
            raise CorpsInvalide(
                "« profil_parent » est obligatoire : c'est le profil dont on "
                "arbitre le résultat. Les profils préféré et alternatif, eux, "
                "sont facultatifs."
            )

        combinaison = ExpertProfileCombination.objects.create(
            test=test,
            slug=slug,
            title=titre[:150],
            parent_profile=parent,
            preferred_profile=_profil_du_test(
                test, corps.get("profil_prefere"), "profil_prefere"
            ),
            alternative_profile=_profil_du_test(
                test, corps.get("profil_alternatif"), "profil_alternatif"
            ),
        )
        _ecrire_les_criteres(combinaison, corps.get("criteres") or [])

        return ok({"combinaison": _combinaison_en_dict(combinaison)}, statut=201)


def _ecrire_les_criteres(combinaison, criteres):
    """
    Remplace les critères d'une combinaison. Tout validé avant d'effacer.
    """
    if not isinstance(criteres, list):
        raise CorpsInvalide("« criteres » doit être une liste.")

    test = combinaison.test
    prepares = []
    for rang, brut in enumerate(criteres, 1):
        if not isinstance(brut, dict):
            raise CorpsInvalide(f"Critère nº {rang} : un objet est attendu.")
        _refuser_les_cles(brut, CLES_CRITERE, f"le critère nº {rang}")

        comparaison = str(brut.get("comparaison") or "").strip()
        if comparaison not in COMPARAISONS:
            raise CorpsInvalide(
                f"Critère nº {rang} : comparaison « {comparaison} » inconnue. "
                f"Acceptées : {', '.join(COMPARAISONS)}."
            )

        # « ~= » est la seule comparaison qui consomme la tolérance. L'exiger
        # ailleurs n'a pas de sens, mais l'oublier ici rend le critère
        # inopérant : proche à zéro près, c'est-à-dire égal.
        tolerance = brut.get("tolerance")
        if comparaison == "~=" and tolerance in (None, ""):
            raise CorpsInvalide(
                f"Critère nº {rang} : « ~= » (proche de) demande une "
                f"« tolerance ». Sans elle, le critère revient à « == »."
            )

        prepares.append({
            "profile_a": _profil_du_test(
                test, brut.get("profil_a"), f"le critère nº {rang}"
            ),
            "profile_b": _profil_du_test(
                test, brut.get("profil_b"), f"le critère nº {rang}"
            ),
            "comparison": comparaison,
            "tolerance": int(tolerance) if tolerance not in (None, "") else 0,
        })

    combinaison.criteria.all().delete()
    for valeurs in prepares:
        ExpertProfileCriterion.objects.create(combination=combinaison, **valeurs)


class DetailCombinaison(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def patch(self, request, combinaison_id):
        combinaison = get_object_or_404(
            ExpertProfileCombination.objects.select_related("test"),
            pk=combinaison_id,
        )
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_COMBINAISON - {"slug"}, "une combinaison")

        test = combinaison.test
        modifies = []
        if "titre" in corps:
            combinaison.title = str(corps["titre"]).strip()[:150]
            modifies.append("title")
        for cle, champ in (
            ("profil_parent", "parent_profile"),
            ("profil_prefere", "preferred_profile"),
            ("profil_alternatif", "alternative_profile"),
        ):
            if cle in corps:
                profil = _profil_du_test(test, corps[cle], cle)
                if profil is None and champ == "parent_profile":
                    raise CorpsInvalide(
                        "« profil_parent » ne peut pas être retiré : c'est le "
                        "profil dont on arbitre le résultat."
                    )
                setattr(combinaison, champ, profil)
                modifies.append(champ)

        if modifies:
            combinaison.save(update_fields=modifies)
        if "criteres" in corps:
            _ecrire_les_criteres(combinaison, corps["criteres"])
            modifies.append("criteres")

        return ok({
            "combinaison": _combinaison_en_dict(combinaison), "modifie": modifies
        })


# --------------------------------------------------------------------------- #
#  Simulation du résultat « par dimensions »
# --------------------------------------------------------------------------- #
class SimulationDuResultat(VueAgent):
    """
    Compose la page de résultat pour des scores donnés, sans rien enregistrer.

    Un agent qui rédige les tranches doit pouvoir vérifier ce que verra un
    visiteur — qui passe en tête, quelle tranche s'affiche, le cas « profil
    nuancé » — sans passer trente questions ni créer de passage : un passage
    est une donnée de personne, pas un outil de test.
    """

    permission_requise = VOIR

    def post(self, request, test_id):
        from jeiko.questionnaires_expert.dimensions import arrange, dimension_profiles

        test = get_object_or_404(ExpertTest, pk=test_id)
        corps = self.corps(request)
        _refuser_les_cles(corps, {"scores"}, "une simulation")
        scores = corps.get("scores")
        if not isinstance(scores, dict):
            raise CorpsInvalide(
                "« scores » est un objet {profil: score}, profil désigné par slug ou id."
            )

        par_id = {}
        for designation, valeur in scores.items():
            profil = _profil_du_test(test, designation, "scores")
            par_id[profil.id] = _nombre(valeur, f"scores.{designation}")

        resultat = arrange(test, par_id, profiles=dimension_profiles(test))

        def decrire(dimension):
            tranche = dimension.band
            return {
                "profil": dimension.profile.slug,
                "nom": dimension.profile.name,
                "score": dimension.score,
                "ecart_au_milieu": dimension.gap,
                "tranche": tranche.position if tranche else None,
                "titre_de_tranche": tranche.title if tranche else None,
            }

        avertissements = []
        if not test.uses_dimensions:
            avertissements.append(
                "Ce questionnaire est en mode « profil » : les visiteurs ne voient "
                "pas cette page. Passer « mode_resultat » à « dimensions » pour l'activer."
            )
        for dimension in resultat.all:
            if dimension.band is None:
                avertissements.append(
                    f"« {dimension.profile.slug} » : le score {dimension.score:g} ne tombe "
                    f"dans aucune tranche — sa barre s'affiche sans texte."
                )

        return ok({
            "mode_resultat": test.result_mode,
            "profil_nuance": resultat.nuanced,
            "titre_de_tete": (
                None if not resultat.head else
                "Vos tendances les plus marquées" if resultat.head_is_plural
                else "Votre tendance la plus marquée"
            ),
            "en_tete": [decrire(d) for d in resultat.head],
            "ensuite": [decrire(d) for d in resultat.rest],
            "avertissements": avertissements,
        })
