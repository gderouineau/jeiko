/*
 * jk-init — le JavaScript d'un gabarit, sorti du gabarit (S-03, phase 2).
 *
 * Le problème
 * -----------
 * Un `<script>` écrit dans un gabarit oblige la politique de sécurité du
 * contenu à autoriser tout script en ligne — donc tout script injecté. Le code
 * part dans un fichier ; ce qui venait du serveur (identifiants, adresses,
 * textes traduits) passe par des DONNÉES, qu'un navigateur n'exécute jamais :
 *
 *   <div data-jk-init="calendrier">
 *     {{ donnees|json_script:… }}  ou  <script type="application/json" data-jk-donnees>…</script>
 *   </div>
 *   <script src="{% static 'jeiko/js/gabarits/…/calendrier.js' %}"></script>
 *
 * et le fichier :
 *
 *   JeikoInit.enregistrer("calendrier", function (racine, donnees) { … });
 *
 * Chaque élément `data-jk-init` est initialisé UNE fois, dès qu'il existe :
 * au chargement de la page, et quand l'éditeur injecte une fenêtre plus tard
 * (le fichier peut alors arriver après le HTML : il initialise ce qu'il
 * trouve en s'enregistrant). Un bloc présent deux fois sur une page est
 * initialisé deux fois, chacun avec SES données.
 *
 * Ce qu'il ne fait pas : exécuter du texte. Les données sont lues par
 * JSON.parse, jamais évaluées.
 */
(function () {
  "use strict";
  if (window.JeikoInit) return;

  var fonctions = {};

  function donnees_de(el) {
    var source = el.querySelector(":scope > script[type='application/json'][data-jk-donnees]");
    var brut = source ? source.textContent : el.getAttribute("data-jk-donnees");
    if (!brut) return {};
    try { return JSON.parse(brut); }
    catch (e) { console.error("[jk-init] données illisibles pour", el.getAttribute("data-jk-init"), e); return null; }
  }

  function initialiser(el) {
    if (el.__jkInit) return;
    var fn = fonctions[el.getAttribute("data-jk-init")];
    if (!fn) return;  // son fichier n'est pas encore chargé : il le fera
    var donnees = donnees_de(el);
    if (donnees === null) return;
    el.__jkInit = true;
    try { fn(el, donnees); }
    catch (e) { console.error("[jk-init] échec de", el.getAttribute("data-jk-init"), e); }
  }

  function parcourir(racine, nom) {
    var selecteur = nom ? "[data-jk-init='" + nom + "']" : "[data-jk-init]";
    if (racine.matches && racine.matches(selecteur)) initialiser(racine);
    if (racine.querySelectorAll) racine.querySelectorAll(selecteur).forEach(initialiser);
  }

  window.JeikoInit = {
    enregistrer: function (nom, fn) {
      fonctions[nom] = fn;
      if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", function () { parcourir(document, nom); });
      } else {
        parcourir(document, nom);
      }
    },
    parcourir: parcourir
  };

  // Le HTML injecté plus tard (fenêtres de l'éditeur, formulaires dynamiques).
  new MutationObserver(function (mutations) {
    mutations.forEach(function (m) {
      m.addedNodes.forEach(function (n) { if (n.nodeType === 1) parcourir(n); });
    });
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
