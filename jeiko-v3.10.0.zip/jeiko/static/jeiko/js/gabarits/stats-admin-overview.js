/* Sorti de templates/stats/admin/overview.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
    (function () {
        const data = D.v1;
        const labels = data.map(d => d.day);
        const pageviews = data.map(d => d.pageviews);
        const visits = data.map(d => d.visits);
        const ctx = document.getElementById('line').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    { label: '' + D.v2 + '', data: pageviews, borderColor: '#D97757', backgroundColor: 'rgba(217, 119, 87, 0.12)', fill: true },
                    { label: '' + D.v3 + '', data: visits, borderColor: '#388e3c', backgroundColor: 'transparent' }
                ]
            }
        });
    })();
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
