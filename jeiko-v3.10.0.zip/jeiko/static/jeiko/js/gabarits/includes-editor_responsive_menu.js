/* Sorti de templates/includes/editor_responsive_menu.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
function editorSizer() {
    return {
        current: null,
        widths: {
            desktop: 1250,
            laptop: 1150,
            tablet: 900,
            mobile: 600
        },
        init() {
            document.body.setAttribute('data-editor', '1');
            const vw = window.innerWidth;

            if (vw >= 1200) {
                this.current = 'desktop';
                this.apply(true);
            } else if (vw >= 992) {
                this.current = 'laptop';
                this.apply(true);
            } else if (vw >= 768) {
                this.current = 'tablet';
                this.apply();
            } else {
                this.current = 'mobile';
                this.apply();
            }
        },
        set(mode) {
            this.current = mode;
            this.apply();
        },
        apply(auto = false) {
            const container = document.querySelector('.editor-body');
            if (!container) return;

            if ((this.current === 'desktop' && auto) || (this.current === 'laptop' && auto)) {
                container.style.width = '100%';
            } else {
                container.style.width = this.widths[this.current] + 'px';
            }

            // force reflow pour que la transition démarre bien
            void container.offsetWidth;

            // on émet jeiko:editor-refresh une fois la transition "width" terminée
            let fired = false;
            const dispatch = () => window.dispatchEvent(new Event('jeiko:editor-refresh'));

            const onEnd = (e) => {
                // selon les navigateurs, e.propertyName peut être 'width' ou vide → on ne filtre pas trop
                fired = true;
                container.removeEventListener('transitionend', onEnd);
                dispatch();
            };

            container.addEventListener('transitionend', onEnd, { once: true });

            // fallback si pas de transition (ou propriété non transitable)
            setTimeout(() => {
                if (!fired) dispatch();
            }, 400);
        },

        exit() {
            // Action pour quitter l’éditeur
            window.location.href = "" + D.v1 + "";
        }
    }
}
window.editorSizer = editorSizer;
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
