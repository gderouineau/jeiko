/* Sorti de templates/shop/admin/product_form.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
                                            (function() {
                                                const initQuill = () => {
                                                    if (!window.Quill) {
                                                        setTimeout(initQuill, 100);
                                                        return;
                                                    }
                                                    const container = document.getElementById('quill-' + D.v1 + '');
                                                    const hiddenInput = document.getElementById('' + D.v2 + '');
                                                    if (!container || !hiddenInput || container.classList.contains('ql-container')) return;
                                                    
                                                    const quill = new Quill(container, {
                                                        theme: 'snow',
                                                        modules: {
                                                            toolbar: [
                                                                [{ header: [1, 2, 3, 4, 5, 6, false] }],
                                                                ['bold', 'italic', 'underline', 'strike'],
                                                                ['link', 'blockquote', 'code-block'],
                                                                [{ list: 'ordered' }, { list: 'bullet' }, { list: 'check' }],
                                                                [{ script: 'sub' }, { script: 'super' }],
                                                                [{ align: [] }],
                                                                [{ size: ['small', false, 'large', 'huge'] }]
                                                            ]
                                                        }
                                                    });
                                                    
                                                    if (hiddenInput.value) {
                                                        quill.root.innerHTML = hiddenInput.value;
                                                    }
                                                    
                                                    quill.on('text-change', () => {
                                                        hiddenInput.value = quill.root.innerHTML;
                                                    });
                                                };
                                                
                                                if (document.readyState === 'loading') {
                                                    document.addEventListener('DOMContentLoaded', initQuill);
                                                } else {
                                                    initQuill();
                                                }
                                            })();
                                            
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
