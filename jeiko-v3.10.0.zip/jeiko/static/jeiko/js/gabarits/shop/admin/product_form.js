/* Sorti de templates/shop/admin/product_form.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
    function productImageFormsetManager(totalName) {
        return {
            totalInput: null,
            total: 0,

            init() {
                this.totalInput = document.querySelector('[name="' + totalName + '"]');
                this.total = this.totalInput ? parseInt(this.totalInput.value || '0') : 0;
            },

            addForm() {
                if (!this.totalInput) return;

                const container = document.getElementById('product-images-forms');
                if (!container) return;

                const tpl = this.$refs.emptyFormTemplate;
                if (!tpl) return;

                let html = tpl.innerHTML;
                const index = this.total;
                html = html.replace(/__prefix__/g, index);

                const wrapper = document.createElement('div');
                wrapper.innerHTML = html.trim();
                const newForm = wrapper.firstElementChild;
                container.appendChild(newForm);

                this.total += 1;
                this.totalInput.value = this.total;
            }
        }
    }

    function collapsibleBlock(initialOpen) {
        return {
            open: initialOpen ?? true,
            toggle() {
                this.open = !this.open;
            }
        }
    }
