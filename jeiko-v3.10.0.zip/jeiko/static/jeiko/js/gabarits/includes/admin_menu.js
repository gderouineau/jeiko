/* Sorti de templates/includes/admin_menu.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
document.addEventListener("DOMContentLoaded", () => {
    // Menu rétractable (sous 992 px).
    const burger = document.querySelector('.jk-menu-toggle');
    const voile = document.querySelector('.jk-menu-backdrop');
    const croix = document.querySelector('.jk-menu-close');
    if (burger) {
        const setOpen = (open) => {
            document.body.classList.toggle('admin-menu-open', open);
            burger.setAttribute('aria-expanded', String(open));
            // `hidden` plutôt que le seul CSS : sans lui le voile reste dans
            // l'arbre d'accessibilité et sur le trajet de tabulation, alors
            // qu'il n'est qu'un décor cliquable.
            if (voile) { voile.hidden = !open; }
        };
        burger.addEventListener('click', () => {
            setOpen(!document.body.classList.contains('admin-menu-open'));
        });
        if (voile) { voile.addEventListener('click', () => setOpen(false)); }
        if (croix) { croix.addEventListener('click', () => setOpen(false)); }
        // Suivre un lien referme le menu, sinon il masque la page d'arrivée.
        document.querySelectorAll('nav.admin-menu a').forEach(a => {
            a.addEventListener('click', () => setOpen(false));
        });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') setOpen(false);
        });
        // Une page RESTAURÉE par le navigateur (retour arrière, Safari sur
        // iPhone) revient telle qu'on l'a quittée, menu ouvert compris : on
        // arrive sur une page ouverte sous un menu (08/10/2026).
        window.addEventListener('pageshow', () => setOpen(false));
    }

    const captions = document.querySelectorAll('nav.admin-menu figure figcaption');

    // L'ouverture anime la VRAIE hauteur de la section. Animée de 0 à la
    // hauteur maximale du CSS (1500 px) pour 300 px de contenu, elle était
    // finie en un cinquième du temps : la section paraissait sauter.
    const deplier = (list, open) => {
        list.style.maxHeight = list.scrollHeight + 'px';
        if (!open) {
            list.offsetHeight;  // part de la hauteur réelle, pas de 1500 px
            list.style.maxHeight = '0px';
        }
        list.classList.toggle('expanded', open);
        list.previousElementSibling.setAttribute('aria-expanded', String(open));
    };

    const toggle = (caption) => {
        const list = caption.nextElementSibling;
        const wasOpen = list.classList.contains('expanded');
        // Accordéon : une seule section ouverte à la fois.
        document.querySelectorAll('nav.admin-menu ul.sub-menu.expanded').forEach(other => {
            if (other !== list) deplier(other, false);
        });
        deplier(list, !wasOpen);
    };

    captions.forEach(caption => {
        caption.addEventListener('click', () => toggle(caption));
        // Les en-têtes sont des <figcaption> : sans ceci, ils ne répondent
        // qu'à la souris et le menu devient inutilisable au clavier.
        caption.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                toggle(caption);
            }
        });
    });
});
