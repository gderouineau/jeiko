/* Sorti de templates/emailing/admin/template_form.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
(function () {
    var subject = document.getElementById('id_subject');
    if (!subject) return;

    document.querySelectorAll('.js-insert-key').forEach(function (button) {
        button.addEventListener('click', function () {
            var key = button.dataset.key;
            var start = subject.selectionStart;
            var end = subject.selectionEnd;

            // selectionStart vaut null si le champ n'a jamais eu le focus : on ajoute à la fin.
            if (start === null || start === undefined) {
                subject.value += key;
            } else {
                subject.value = subject.value.slice(0, start) + key + subject.value.slice(end);
                subject.selectionStart = subject.selectionEnd = start + key.length;
            }

            subject.focus();
        });
    });
})();
