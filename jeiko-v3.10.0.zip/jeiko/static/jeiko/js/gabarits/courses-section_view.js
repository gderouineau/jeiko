/* Sorti de templates/courses/section_view.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
// API call to mark section as complete
async function callMarkCompleteApi() {
    console.log('[DEBUG] Calling mark complete API...');
    const formData = new FormData();
    formData.append('csrfmiddlewaretoken', document.querySelector('[name=csrfmiddlewaretoken]').value);
    
    try {
        const response = await fetch(`${D.v1}`, {
            method: 'POST',
            body: formData
        });
        const data = await response.json();
        console.log('[DEBUG] Mark complete response:', data);
        return true;
    } catch (error) {
        console.error('[ERROR] Error marking complete:', error);
        return false;
    }
}

// Handle "Next" button click
async function handleNavigation(event, url) {
    console.log('[DEBUG] handleNavigation called, url:', url);
    event.preventDefault();
    
    const video = document.getElementById('course-video');
    const quizState = window.quizState;
    
    let warning = null;
    
    // Check constraints
    if (video && !video.ended && video.currentTime < video.duration * 0.9) {
        warning = "Vous n'avez pas terminé de regarder la vidéo.";
    }
    
    if (quizState && !quizState.passed && !quizState.skipped) {
        warning = "Vous n'avez pas réussi le quiz.";
    }
    
    // If warning, ask for confirmation
    if (warning) {
        console.log('[DEBUG] Warning:', warning);
        if (!confirm(warning + "\n\nVoulez-vous vraiment passer à la suite ? (La section sera marquée comme terminée)")) {
            console.log('[DEBUG] User cancelled navigation');
            return false;
        }
    }
    
    // Auto-validate
    console.log('[DEBUG] Auto-validating section before navigation...');
    try {
        await callMarkCompleteApi();
        console.log('[DEBUG] Section marked complete, navigating to:', url);
    } catch (error) {
        console.error('[ERROR] Error marking section complete:', error);
    }
    
    // Navigate
    window.location.href = url;
}

// Manual "Mark as read" button
async function markAsComplete(sectionId) {
    const success = await callMarkCompleteApi();
    if (success) {
        window.location.reload();
    } else {
        alert('Erreur lors de la mise à jour de la progression');
    }
}

// Video player with progress tracking
function videoPlayer(sectionId, duration) {
    return {
        sectionId: sectionId,
        duration: duration,
        updateInterval: null,
        
        init() {
            this.loadProgress();
            this.updateInterval = setInterval(() => {
                this.updateProgress();
            }, 10000);
        },
        
        onTimeUpdate(e) {},
        
        onLoaded() {},
        
        onEnded() {
            this.updateProgress();
            clearInterval(this.updateInterval);
            this.markComplete();
        },
        
        async loadProgress() {
            try {
                const response = await fetch(`/api/courses/video-progress/${this.sectionId}/`);
                if (response.ok) {
                    const data = await response.json();
                    if (data.position && this.$refs.video) {
                        this.$refs.video.currentTime = data.position;
                    }
                }
            } catch (error) {
                console.error('Error loading progress:', error);
            }
        },
        
        async updateProgress() {
            if (!this.$refs.video) return;
            const formData = new FormData();
            formData.append('section_id', this.sectionId);
            formData.append('position', Math.floor(this.$refs.video.currentTime));
            formData.append('duration', this.duration || Math.floor(this.$refs.video.duration));
            formData.append('csrfmiddlewaretoken', document.querySelector('[name=csrfmiddlewaretoken]').value);
            
            try {
                await fetch('/api/courses/video-progress/update/', {
                    method: 'POST',
                    body: formData
                });
            } catch (error) {
                console.error('Error updating progress:', error);
            }
        },
        
        async markComplete() {
             await callMarkCompleteApi();
             // Reload to update sidebar checkmark
             window.location.reload();
        }
    }
}

// Quiz manager
function quizManager(config) {
    return {
        quizId: config.quizId,
        passingScore: config.passingScore,
        allowSkip: config.allowSkip,
        submitUrl: config.submitUrl,
        skipUrl: config.skipUrl,
        answers: {},
        multiAnswers: {},
        submitted: false,
        score: 0,
        passed: false,
        skipped: false,
        
        init() {
            if (config.initialAttempt) {
                this.score = config.initialAttempt.score;
                this.passed = config.initialAttempt.passed;
                this.skipped = config.initialAttempt.skipped;
                this.submitted = true;
            }
            window.quizState = this;
        },
        
        toggleAnswer(questionId, answerId) {
            const key = `question_${questionId}`;
            if (!this.multiAnswers[key]) this.multiAnswers[key] = [];
            const index = this.multiAnswers[key].indexOf(answerId);
            if (index > -1) this.multiAnswers[key].splice(index, 1);
            else this.multiAnswers[key].push(answerId);
        },
        
        async submitQuiz() {
            const formData = new FormData();
            formData.append('csrfmiddlewaretoken', document.querySelector('[name=csrfmiddlewaretoken]').value);
            
            for (const [key, value] of Object.entries(this.answers)) {
                if (value) formData.append(key, value);
            }
            for (const [key, values] of Object.entries(this.multiAnswers)) {
                if (values && values.length) values.forEach(v => formData.append(key, v));
            }
            
            try {
                const response = await fetch(this.submitUrl, {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                this.score = data.score.toFixed(1);
                this.passed = data.passed;
                this.submitted = true;
                window.quizState = this;
                
                this.$el.scrollIntoView({ behavior: 'smooth' });
                
                if (this.passed) {
                    setTimeout(() => window.location.reload(), 2000);
                }
                
            } catch (error) {
                console.error('Error submitting quiz:', error);
                alert('Erreur lors de la soumission du quiz');
            }
        },
        
        async skipQuiz() {
            if (!confirm('Êtes-vous sûr de vouloir passer ce quiz ?')) return;
            
            const formData = new FormData();
            formData.append('csrfmiddlewaretoken', document.querySelector('[name=csrfmiddlewaretoken]').value);
            
            try {
                const response = await fetch(this.skipUrl, {
                    method: 'POST',
                    body: formData
                });
                await response.json();
                
                this.skipped = true;
                this.submitted = true;
                window.quizState = this;
                
                setTimeout(() => window.location.reload(), 1000);
                
            } catch (error) {
                console.error('Error skipping quiz:', error);
            }
        },
        
        resetQuiz() {
            this.answers = {};
            this.multiAnswers = {};
            this.submitted = false;
            this.score = 0;
            this.passed = false;
            this.skipped = false;
            window.quizState = this;
        }
    }
}
window.callMarkCompleteApi = callMarkCompleteApi;
window.handleNavigation = handleNavigation;
window.markAsComplete = markAsComplete;
window.quizManager = quizManager;
window.videoPlayer = videoPlayer;
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
