/* Sorti de templates/calendars/availability_form.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
(function(){
    // Affiche/masque les lignes de récurrence selon la sélection
    const form = document.getElementById('availability-form');
    if (!form) return;
    const freq = form.querySelector('[name="recurrence_freq"]');
    const rows = form.querySelectorAll('.recur-row[data-recur="has-recur"]');
    function refresh() {
        const val = (freq && freq.value) || 'NONE';
        const show = val !== 'NONE';
        rows.forEach(r => { r.style.display = show ? '' : 'none'; });
    }
    if (freq) {
        freq.addEventListener('change', refresh);
        refresh();
    }
})();
