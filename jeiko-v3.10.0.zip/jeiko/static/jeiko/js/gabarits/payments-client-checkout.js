/* Sorti de templates/payments/client/checkout.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
document.getElementById("" + D.v1 + "").addEventListener("change", function () {
    document.getElementById("livraison").hidden = !this.checked;
});
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
