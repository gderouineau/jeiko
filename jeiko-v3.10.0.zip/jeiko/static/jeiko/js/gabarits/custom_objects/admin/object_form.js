/* Sorti de templates/custom_objects/admin/object_form.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
    function collapsibleBlock(initialOpen) {
        return {
            open: initialOpen ?? true,
            toggle() {
                this.open = !this.open;
            }
        }
    }
