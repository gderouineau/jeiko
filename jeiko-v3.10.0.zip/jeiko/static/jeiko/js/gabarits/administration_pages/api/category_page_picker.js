/* Sorti de templates/administration_pages/api/category_page_picker.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
function categoryPagePicker(initialPage, pageInput) {
  return {
    // Données
    categories: [],
    subcategories: [],
    pages: [],
    selectedCategory: '',
    selectedSubcategory: '',
    selectedPage: initialPage || '',
    pageInput: pageInput || '',

    // --- Utilitaire fetch JSON avec anti-cache ---
    async fetchJson(url) {
      const res = await fetch(
        url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(),
        {
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Cache-Control': 'no-store'
          },
          cache: 'no-store',
        }
      );
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return await res.json();
    },

    // Fetch catégories principales
    async fetchCategories() {
      try {
        const data = await this.fetchJson('/api/pages/categories/');
        this.categories = data.categories || [];
      } catch (e) {
        this.categories = [];
        console.warn('fetchCategories:', e);
      }
    },

    // Fetch sous-catégories de la catégorie sélectionnée
    async fetchSubcategories() {
      this.subcategories = [];
      if (!this.selectedCategory) return;
      try {
        const dataSub = await this.fetchJson(`/api/pages/categories/${this.selectedCategory}/subcategories/`);
        this.subcategories = dataSub.subcategories || [];
      } catch (e) {
        this.subcategories = [];
        console.warn('fetchSubcategories:', e);
      }
    },

    // Fetch pages selon le filtre sélectionné
    async fetchPages() {
      try {
        let url = '/api/pages/pages/';
        if (this.selectedSubcategory) {
          url += `?sub_category_id=${this.selectedSubcategory}`;
        } else if (this.selectedCategory) {
          url += `?category_id=${this.selectedCategory}`;
        }
        const dataPages = await this.fetchJson(url);
        this.pages = dataPages.pages || [];
      } catch (e) {
        this.pages = [];
        console.warn('fetchPages:', e);
      }
    },

    // Synchroniser l’input hidden
    syncPageInput() {
      if (this.pageInput) {
        const input = document.querySelector(this.pageInput);
        if (input) input.value = this.selectedPage;
      }
    },

    // Handlers
    async onCategoryChange() {
      this.selectedSubcategory = '';
      await this.fetchSubcategories();
      await this.fetchPages();
      this.selectedPage = '';
      this.syncPageInput();
    },

    async onSubcategoryChange() {
      await this.fetchPages();
      this.selectedPage = '';
      this.syncPageInput();
    },

    // Initialisation
    async setInitialValues() {
      await this.fetchCategories();

      if (this.selectedPage) {
        try {
          let data;
      try {
        data = await this.fetchJson(`/api/pages/page/${this.selectedPage}`);
          } catch (e) {
            data = await this.fetchJson(`/api/pages/page/${this.selectedPage}/`);
          }
          const page = data.page;
          if (page) {
            this.selectedCategory = page.category_id ? String(page.category_id) : '';
            await this.fetchSubcategories();
            this.selectedSubcategory = page.sub_category_id ? String(page.sub_category_id) : '';
            await this.fetchPages();
            this.selectedPage = String(page.id);
          } else {
            this.selectedCategory = '';
            this.selectedSubcategory = '';
            await this.fetchPages();
            this.selectedPage = '';
          }
        } catch (e) {
          // 404/410/etc → reset propre
          this.selectedCategory = '';
          this.selectedSubcategory = '';
          await this.fetchPages();
          this.selectedPage = '';
        }
      } else {
        await this.fetchPages();
      }
      this.syncPageInput();
    },

    async init() {
      await this.setInitialValues();
    }
  }
}
document.addEventListener('alpine:init', () => {
  Alpine.data('categoryPagePicker', categoryPagePicker)
});
