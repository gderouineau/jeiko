/* Sorti de templates/administration_pages/main.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
function pageFilterAlpine() {
    return {
        categories: [],
        subcategories: [],
        pages: [],
        selectedCategory: '',
        selectedSubcategory: '',
        search: '',
        pagination: null,

        // Map des scores par pageId: { mobile: Number|null, desktop: Number|null }
        insightsMap: {},

        // ✅ Adapte ces bases si ton prefix change
        // Base API data (déjà utilisé)
        apiPagesBase: '/api/pages/pages/',
        // Base API insights latest (TU AS DONNÉ: "pages/<id>/insights/latest/")
        // Ici je l'accroche sous le même prefix admin que tes autres routes:
        adminBase: '/jeiko/administration/pages/',

        // Helper fetch JSON anti-cache
        async fetchJSON(url) {
            const sep = url.includes('?') ? '&' : '?';
            const full = `${url}${sep}_ts=${Date.now()}`;
            const res = await fetch(full, {
                cache: 'no-store',
                headers: { 'Cache-Control': 'no-cache' },
                credentials: 'same-origin',
            });
            if (!res.ok) {
                const text = await res.text();
                throw new Error(`HTTP ${res.status} ${res.statusText}\n${text.slice(0,400)}`);
            }
            return res.json();
        },

        // ---------- Chargement catalogue ----------
        async fetchCategories() {
            const data = await this.fetchJSON('/api/pages/categories/');
            this.categories = data.categories;
        },

        async fetchSubcategoriesAndPages() {
            this.selectedSubcategory = '';
            this.subcategories = [];
            await this.fetchSubcategories();
            await this.fetchPages();
        },

        async fetchSubcategories() {
            if (!this.selectedCategory) {
                this.subcategories = [];
                return;
            }
            const data = await this.fetchJSON(`/api/pages/categories/${this.selectedCategory}/subcategories/`);
            this.subcategories = data.subcategories;
        },

        async fetchPages(numero = 1) {
            let url = this.apiPagesBase + `?page=${numero}&`;
            if (this.selectedSubcategory) {
                url += `sub_category_id=${this.selectedSubcategory}&`;
            } else if (this.selectedCategory) {
                url += `category_id=${this.selectedCategory}&`;
            }
            if (this.search) {
                url += `search=${encodeURIComponent(this.search)}&`;
            }
            const data = await this.fetchJSON(url);
            this.pages = data.pages;
            this.pagination = data.pagination || null;
            // Les scores de la page affichée arrivent avec elle (une requête
            // au lieu d'une par page).
            this.insightsMap = data.scores || {};
        },

        // ---------- URLs existantes ----------
        // L'adresse vient du serveur (`get_absolute_url`) : elle seule sait si la
        // catégorie figure dans l'URL. Repli sur l'ancienne forme par sécurité.
        getViewUrl(page) { return page.url || `/${page.url_tag}/`; },
        getUpdateUrl(id) { return `${this.adminBase}${id}/update/`; },
        getDuplicateUrl(id) { return `${this.adminBase}${id}/duplicate/`; },
        getDeleteUrl(id) { return `${this.adminBase}${id}/delete/`; },
        getEditorUrl(id) { return `${this.adminBase}${id}/editor/`; },

        // Nouveau: lien vers la vue détail Insights
        getInsightsUrl(id) { return `${this.adminBase}${id}/insights/`; },
        getPublishUrl(id) { return `${this.adminBase}${id}/publish/`; },

        // lecture score depuis map
        scoreFor(pageId, strategy) {
            return this.insightsMap?.[pageId]?.[strategy] ?? null;
        },

        // display helpers
        displayScore(v) {
            if (v === null || v === undefined) return '—';
            return Number(v);
        },
        chipStyle(score) {
            const v = Number(score);
            let bg = '#eee', color = '#333', border = '#ddd';
            if (!isNaN(v)) {
                if (v >= 90) { bg = '#e6f4ea'; color = '#137333'; border = '#c8e6d0'; }      // vert
                else if (v >= 50) { bg = '#fff8e1'; color = '#a15c00'; border = '#ffe2a8'; } // orange
                else { bg = '#fdecea'; color = '#a12622'; border = '#f7c6c5'; }              // rouge
            }
            return `background:${bg}; color:${color}; border:1px solid ${border};`;
        },

        async init() {
            await this.fetchCategories();
            await this.fetchPages();
        }
    }
}
document.addEventListener('alpine:init', () => {
    Alpine.data('pageFilterAlpine', pageFilterAlpine)
});
