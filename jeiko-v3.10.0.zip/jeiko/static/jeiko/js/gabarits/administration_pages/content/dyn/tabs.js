/* Sorti de templates/administration_pages/content/dyn/tabs.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
/* Mesure la plus grande hauteur de .tabpanel et fixe la min-height du bloc */
function tabsMeasureMixin() {
    return {
        _ro: null,
        _onWinResize: null,
        initMeasure() {
            this.$watch('active', () => this.$nextTick(() => this.computeHeights()));
            this.$watch('tabs',   () => this.$nextTick(() => this.computeHeights()));

            const ro = new ResizeObserver(() => this.computeHeights());
            this._ro = ro;
            if (this.$refs.tablist)   ro.observe(this.$refs.tablist);
            if (this.$refs.tabpanels) ro.observe(this.$refs.tabpanels);

            this.$nextTick(() => this.computeHeights());
            this._onWinResize = () => this.computeHeights();
            window.addEventListener('resize', this._onWinResize);
        },
        computeHeights() {
            const root    = this.$refs.root;
            const tablist = this.$refs.tablist;
            const panels  = this.$refs.tabpanels;
            if (!root || !tablist || !panels) return;

            let maxH = 0;
            panels.querySelectorAll('.tabpanel').forEach(node => {
                const prev = node.getAttribute('style') || '';
                node.style.position   = 'absolute';
                node.style.visibility = 'hidden';
                node.style.display    = 'block';
                node.style.inset      = '0 auto auto 0';
                const h = node.offsetHeight;
                if (h > maxH) maxH = h;
                node.setAttribute('style', prev);
            });

            const total = tablist.offsetHeight + maxH;
            root.style.minHeight = total + 'px';
        },
        destroy() {
            if (this._ro) this._ro.disconnect();
            if (this._onWinResize) window.removeEventListener('resize', this._onWinResize);
        }
    };
}
