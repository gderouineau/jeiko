/* Sorti de templates/administration_pages/content/edit_dyn/edit_dyn_faq.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
// addInline, moveUp, moveDown et renumberOrders : ceux de formsets.js (Q-05).
