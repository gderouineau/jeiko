/* Sorti de templates/administration_pages/content/partials/content_video.html (S-03, phase 2).
 * Bornes de lecture d'une vidéo locale : début et fin, en secondes. */
JeikoInit.enregistrer("video-bornes", function (v, D) {
  var START = D.debut || 0;
  var END = (D.fin === null || D.fin === undefined) ? null : D.fin;
  function onLoaded() {
    try { if (START && v.currentTime < START) v.currentTime = START; } catch (e) {}
  }
  function onTime() {
    if (END !== null && v.currentTime >= END) {
      if (v.loop) { v.currentTime = START || 0; }
      else { v.pause(); }
    }
  }
  v.addEventListener("loadedmetadata", onLoaded, { once: true });
  v.addEventListener("timeupdate", onTime);
});
