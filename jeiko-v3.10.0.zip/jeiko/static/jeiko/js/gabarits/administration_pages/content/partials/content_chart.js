/* Sorti de templates/administration_pages/content/partials/content_chart.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
// Appelle `fn` une fois Chart.js disponible — tout de suite s'il l'est déjà,
// sinon au chargement de son script (ou de la page, en dernier recours).
function quandChartEstPret(fn) {
    if (window.Chart) { fn(); return; }
    let fait = false;
    const une = () => { if (!fait && window.Chart) { fait = true; fn(); } };
    document.querySelectorAll('script[data-jk-chartjs]').forEach(
        (s) => s.addEventListener('load', une, { once: true })
    );
    window.addEventListener('load', une, { once: true });
}

function chartBloc(chartId, chartType) {
    return {
        chart: null,

        // Lit un bloc <script type="application/json"> et le rend, ou null.
        // Un bloc absent ou illisible ne doit pas empêcher le graphique de
        // s'afficher : les options sont facultatives.
        readJson(id) {
            const holder = document.getElementById(id);
            if (!holder) return null;
            const brut = (holder.textContent || '').trim();
            if (!brut) return null;
            try {
                return JSON.parse(brut);
            } catch (e) {
                console.error(`[chartBloc] JSON illisible dans #${id}`, e);
                return null;
            }
        },

        initChart() {
            const input = this.readJson(`chart-data-${chartId}`);
            const chartOptions = this.readJson(`chart-options-${chartId}`);

            if (!input) {
                console.error(`[chartBloc ${chartId}] Données absentes`);
                return;
            }

            // Si jamais c’est encore au format "scores", on convertit
            let chartData = input;
            if (Array.isArray(input.scores)) {
                chartData = {
                    labels: input.scores.map(s => s.name),
                    datasets: [{
                        label: 'Scores',
                        data: input.scores.map(s => Number(s.score) || 0),
                        backgroundColor: input.scores.map(s => s.color || '#ccc')
                    }]
                };
            }

            // Des réglages PAR TYPE : les axes x/y ne valent que pour les barres
            // et les lignes. Posés sur un radar, ils dessinaient deux axes de
            // 0 à 1 autour de l'étoile ; sur un camembert, un cadre vide.
            const type = chartType || 'bar';
            const axes = {
                y: { beginAtZero: true },
                x: { ticks: { color: '#333', font: { size: 14, family: 'Arial', weight: 'bold' } } }
            };
            const parType = {
                bar: { scales: axes },
                line: { scales: axes },
                radar: { scales: { r: { beginAtZero: true, ticks: { display: false } } } },
                pie: {},
                doughnut: {}
            };
            if (type === 'radar') {
                // Un radar n'a qu'une surface : une couleur par point, et
                // l'aire en translucide de la première.
                chartData.datasets.forEach((ds) => {
                    const couleurs = [].concat(ds.backgroundColor || '#888888');
                    ds.pointBackgroundColor = couleurs;
                    ds.borderColor = couleurs[0];
                    ds.backgroundColor = /^#[0-9a-f]{6}$/i.test(couleurs[0])
                        ? couleurs[0] + '33' : 'rgba(128, 128, 128, 0.2)';
                    ds.fill = true;
                });
            }
            const finalOptions = Object.assign(
                { responsive: true, maintainAspectRatio: false },
                parType[type] || parType.bar,
                chartOptions || {}
            );

            this.$nextTick(() => quandChartEstPret(() => {
                const canvas = document.getElementById(`chart-canvas-${chartId}`);
                if (!canvas) return;
                const ctx = canvas.getContext('2d');

                if (this.chart) this.chart.destroy();
                this.chart = new Chart(ctx, {
                    type: type,
                    data: chartData,
                    options: finalOptions
                });
            }));
        }
    };
}
