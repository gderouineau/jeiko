/* Sorti de templates/administration_pages/content/partials/content_formulaire.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
(function() {
  // Empêcher double soumission
  document.querySelectorAll('form.bloc-formulaire').forEach(form => {
    const submitBtn = form.querySelector('.cf-submit-btn');

    form.addEventListener('submit', async function(e) {
      e.preventDefault();
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.setAttribute('aria-disabled', 'true');
        submitBtn.dataset.originalText = submitBtn.textContent;
        submitBtn.textContent = submitBtn.textContent || '…';
      }

      // reset erreurs visibles
      form.querySelectorAll('.form-error').forEach(el => el.remove());

      // La preuve de JavaScript : un robot qui poste l'adresse directement
      // n'envoie pas ce champ (administration_pages/antispam.py).
      const corps = new FormData(form);
      corps.append('jk_js', (corps.get('jk_t') || '').split('').reverse().join(''));
      const res = await fetch(form.action, {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: corps
      });

      let data;
      try { data = await res.json(); } catch { data = {}; }

      if (data.success) {
        form.reset();
        const ok = form.querySelector('.form-success-message');
        if (ok) {
          ok.hidden = false;
          ok.textContent = data.message || ok.textContent || '';
        }
        // On laisse le bouton désactivé (cliquable une seule fois)
        if (submitBtn) submitBtn.textContent = (submitBtn.dataset.originalText && submitBtn.dataset.originalText.trim()) || '✔';
      } else {
        // Afficher erreurs et réactiver si échec
        if (data.errors) {
          Object.entries(data.errors).forEach(([name, msg]) => {
            const field = form.querySelector(`[name="${name}"]`);
            if (field) {
              const error = document.createElement('div');
              error.className = 'form-error';
              error.style.color = 'var(--cf-danger, #d00)';
              error.textContent = msg;
              field.insertAdjacentElement('afterend', error);
            }
          });
        }
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.removeAttribute('aria-disabled');
          if (submitBtn.dataset.originalText) submitBtn.textContent = submitBtn.dataset.originalText;
        }
      }
    });
  });
})();
