/* Sorti de templates/administration/update/form.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
(function () {
    "use strict";

    var statusUrl = "" + D.v1 + "";
    var box       = document.getElementById("jeiko-update-status");
    var label     = document.getElementById("jeiko-status-label");
    var stepEl    = document.getElementById("jeiko-status-step");
    var messageEl = document.getElementById("jeiko-status-message");
    var logEl     = document.getElementById("jeiko-update-log");
    var button    = document.getElementById("jeiko-update-button");
    var versionEl = document.getElementById("jeiko-installed-version");
    var logBox    = document.getElementById("jeiko-log-wrapper");

    if (!box || !logEl) { return; }

    var LABELS = {
        idle:    "" + D.v2 + "",
        running: "" + D.v3 + "",
        success: "" + D.v4 + "",
        failed:  "" + D.v5 + "",
        stalled: "" + D.v6 + "",
        unknown: "" + D.v7 + ""
    };

    var timer = null;
    var settledPolls = 0;

    function render(data) {
        var status = data.status || "idle";

        box.hidden = (status === "idle");
        box.setAttribute("data-status", status);
        label.textContent = LABELS[status] || status;
        stepEl.textContent = data.step ? " — " + data.step : "";
        messageEl.textContent = data.message || "";

        if (versionEl && data.installed_version) {
            versionEl.textContent = data.installed_version;
        }

        if (typeof data.log === "string" && data.log !== logEl.textContent) {
            // Ne recoller au bas du journal que si l'utilisateur y était déjà :
            // sinon on lui arracherait la vue pendant qu'il lit plus haut.
            var atBottom = logEl.scrollTop + logEl.clientHeight >= logEl.scrollHeight - 40;
            logEl.textContent = data.log;
            if (atBottom) { logEl.scrollTop = logEl.scrollHeight; }
        }

        if (status === "running") {
            if (button) {
                button.disabled = true;
                button.textContent = "" + D.v8 + "";
            }
            if (logBox) { logBox.open = true; }
        } else if (button) {
            button.disabled = false;
            button.textContent = "" + D.v9 + "";
        }

        return status;
    }

    function poll() {
        fetch(statusUrl, {
            headers: { "X-Requested-With": "XMLHttpRequest" },
            credentials: "same-origin",
            cache: "no-store"
        })
            .then(function (response) {
                if (!response.ok) { throw new Error("HTTP " + response.status); }
                return response.json();
            })
            .then(function (data) {
                var status = render(data);
                if (status === "running") {
                    settledPolls = 0;
                    return;
                }
                // On ne s'arrête pas au premier état non « running » : après le
                // POST, systemd n'a pas forcément encore écrit le fichier d'état,
                // et l'état lu serait celui de la mise à jour PRÉCÉDENTE. On
                // laisse une dizaine de secondes au démarrage réel.
                settledPolls += 1;
                if (settledPolls >= 5) {
                    window.clearInterval(timer);
                    timer = null;
                }
            })
            .catch(function () {
                // Silencieux : gunicorn est probablement en train de redémarrer,
                // ce qui fait précisément partie de la mise à jour.
            });
    }

    function startPolling() {
        if (timer !== null) { return; }
        settledPolls = 0;
        timer = window.setInterval(poll, 2000);
        poll();
    }

    render({
        status: "" + D.v10 + "",
        step: "" + D.v11 + "",
        message: "" + D.v12 + ""
    });

    // Toujours interroger au chargement : la page est atteinte soit en suivant
    // une mise à jour en cours, soit juste après l'avoir déclenchée.
    startPolling();

    var form = document.getElementById("jeiko-update-form");
    if (form) {
        form.addEventListener("submit", function () {
            if (button) {
                button.disabled = true;
                button.textContent = "" + D.v13 + "";
            }
        });
    }
})();
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
