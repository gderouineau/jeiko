/* Sorti de templates/calendars/appointment_payment.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
        (function () {
          const stripe = Stripe("" + D.v1 + "");
          const elements = stripe.elements({ clientSecret: "" + D.v2 + "" });
          elements.create("payment").mount("#payment-element");

          const form    = document.getElementById("payment-form");
          const button  = document.getElementById("submit-payment");
          const label   = document.getElementById("payment-button-text");
          const spinner = document.getElementById("payment-spinner");
          const message = document.getElementById("payment-message");

          function busy(state) {
            button.disabled = state;
            label.style.display   = state ? "none" : "inline";
            spinner.style.display = state ? "inline" : "none";
          }

          function showError(text) {
            message.textContent = text;
            message.style.display = "block";
          }

          form.addEventListener("submit", async (event) => {
            event.preventDefault();
            busy(true);
            message.style.display = "none";

            const { error } = await stripe.confirmPayment({
              elements,
              confirmParams: { return_url: "" + D.v3 + "" },
            });

            // On n'arrive ici que si le paiement a échoué : en cas de succès,
            // Stripe redirige vers return_url, où le statut est revérifié
            // côté serveur.
            if (error) {
              showError(error.message || "Le paiement n'a pas abouti.");
              busy(false);
            }
          });
        })();
        
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
