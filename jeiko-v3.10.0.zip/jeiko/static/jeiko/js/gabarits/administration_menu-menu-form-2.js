/* Sorti de templates/administration_menu/menu/form.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
    function menuDesigner() {
        return {
            // base
            place: '' + D.v1 + '',
            layout: '' + D.v2 + '',

            // logo preview
            logoSelected: '' + D.v3 + '',
            logoPreview: {},
            _objectUrl: null,   // pour révoquer l’URL locale

            // état style (hydraté depuis les inputs existants)
            style: {
                backgroundColor: '#fafafa',
                textColor: '#111111',
                hoverTextColor: '#111111',
                activeTextColor: '#111111',
                submenuBackgroundColor: '#ffffff',
                submenuBorderColor: '#e5e7eb',
                submenuHoverBackgroundColor: '#f7f7f7',
                fontFamily: '',
                fontWeight: 'normal',
                fontSizeMobile: 16,
                fontSizeDesktop: 16,
                letterSpacing: 0,
                uppercase: false,
                menuMinHeight: 64,
                paddingYMobile: 10,
                paddingYDesktop: 12,
                gapDesktop: 32,
                gapMobile: 0,
                logoWidthMobile: 80,
                logoWidthDesktop: 100,
                logoHeightDesktop: 100,
                borderBottomWidth: 0,
                borderBottomColor: '#e5e7eb',
                sticky: false,
                stickyShadow: true,
                transitionsMs: 180,
                roundedSubmenu: 8,
            },

            // mapping noms de champs -> propriétés
            field2prop: {
                background_color: 'backgroundColor',
                text_color: 'textColor',
                hover_text_color: 'hoverTextColor',
                active_text_color: 'activeTextColor',
                submenu_background_color: 'submenuBackgroundColor',
                submenu_border_color: 'submenuBorderColor',
                submenu_hover_background_color: 'submenuHoverBackgroundColor',
                font_family: 'fontFamily',
                font_weight: 'fontWeight',
                font_size_mobile: 'fontSizeMobile',
                font_size_desktop: 'fontSizeDesktop',
                letter_spacing: 'letterSpacing',
                uppercase: 'uppercase',
                menu_min_height: 'menuMinHeight',
                padding_y_mobile: 'paddingYMobile',
                padding_y_desktop: 'paddingYDesktop',
                gap_desktop: 'gapDesktop',
                gap_mobile: 'gapMobile',
                logo_width_mobile: 'logoWidthMobile',
                logo_width_desktop: 'logoWidthDesktop',
                logo_height_desktop: 'logoHeightDesktop',
                border_bottom_width: 'borderBottomWidth',
                border_bottom_color: 'borderBottomColor',
                sticky: 'sticky',
                sticky_shadow: 'stickyShadow',
                transitions_ms: 'transitionsMs',
                rounded_submenu: 'roundedSubmenu',
            },

            // hydrate les valeurs initiales depuis les inputs du form
            init() {
                // reset layout quand l’emplacement change
                const placeEl = document.getElementById('' + D.v4 + '') ||
                                document.querySelector('[name="' + D.v5 + '"]');
                if (placeEl) {
                    placeEl.addEventListener('change', () => {
                        this.place = placeEl.value || 'NULL';
                        this.layout = '';
                        document.querySelectorAll('input[name="' + D.v6 + '"]').forEach(el => el.checked = false);
                        this.applyLogoPreview();
                    });
                }

                // choix logo (existants) -> preview auto
                const logoEl = document.getElementById('' + D.v7 + '') ||
                               document.querySelector('[name="' + D.v8 + '"]');
                const updateLogoFromSelect = () => {
                    // Ne met à jour depuis la liste que si aucun fichier upload n’est présent
                    const fileEl = document.getElementById('' + D.v9 + '') ||
                                   document.querySelector('[name="' + D.v10 + '"]');
                    if (fileEl && fileEl.files && fileEl.files.length) return;

                    this.logoSelected = (logoEl && logoEl.value) ? logoEl.value : '';
                    this.logoPreview = (window.__LOGO_MAP__ && (window.__LOGO_MAP__[this.logoSelected] || window.__LOGO_MAP__['default'])) || {};
                    this.applyLogoPreview();
                };
                if (logoEl) logoEl.addEventListener('change', updateLogoFromSelect);

                // upload d’un nouveau logo -> preview locale
                const fileEl = document.getElementById('' + D.v11 + '') ||
                               document.querySelector('[name="' + D.v12 + '"]');
                if (fileEl) {
                    fileEl.addEventListener('change', () => {
                        // révoquer l’ancien objectURL si besoin
                        if (this._objectUrl) {
                            URL.revokeObjectURL(this._objectUrl);
                            this._objectUrl = null;
                        }

                        if (fileEl.files && fileEl.files[0]) {
                            const f = fileEl.files[0];
                            const url = URL.createObjectURL(f);
                            this._objectUrl = url;

                            // mini vignette à gauche
                            const thumbWrap = document.getElementById('new-logo-thumb');
                            const thumbImg = document.getElementById('new-logo-thumb-img');
                            if (thumbWrap && thumbImg) {
                                thumbImg.src = url;
                                thumbWrap.style.display = 'block';
                            }

                            // preview dans l’aperçu menu
                            this.logoPreview = { full: url, computer: url, tablet: url, mobile: url };
                            this.applyLogoPreview();
                        } else {
                            // champ vidé => revenir à la sélection existante ou défaut
                            const thumbWrap = document.getElementById('new-logo-thumb');
                            const thumbImg = document.getElementById('new-logo-thumb-img');
                            if (thumbWrap && thumbImg) {
                                thumbImg.removeAttribute('src');
                                thumbWrap.style.display = 'none';
                            }
                            updateLogoFromSelect();
                        }
                    });
                }

                // init preview (depuis select / défaut)
                this.logoSelected = (logoEl && logoEl.value) ? logoEl.value : '';
                this.logoPreview = (window.__LOGO_MAP__ && (window.__LOGO_MAP__[this.logoSelected] || window.__LOGO_MAP__['default'])) || {};
                this.applyLogoPreview();

                // Hydrate style depuis les champs existants
                for (const [name, prop] of Object.entries(this.field2prop)) {
                    const el = document.querySelector(`[name="${name}"]`);
                    if (!el) continue;
                    if (el.type === 'checkbox') {
                        this.style[prop] = !!el.checked;
                    } else if (el.type === 'number' || el.type === 'range') {
                        const v = el.value !== '' ? Number(el.value) : null;
                        if (v !== null && !Number.isNaN(v)) this.style[prop] = v;
                    } else {
                        this.style[prop] = el.value || this.style[prop];
                    }
                }
            },

            // remplace les src/srcset dans l’aperçu
            applyLogoPreview() {
                const previews = document.querySelectorAll('.menu-preview .logo picture');
                previews.forEach(p => {
                    const img = p.querySelector('img');
                    const sMobile = p.querySelector('source[media*="max-width: 575px"]');
                    const sTablet = p.querySelector('source[media*="min-width: 576px"][media*="max-width: 991px"]');
                    const sDesktop = p.querySelector('source[media*="min-width: 992px"]');

                    if (sMobile) sMobile.srcset = this.logoPreview?.mobile || this.logoPreview?.full || '';
                    if (sTablet) sTablet.srcset = this.logoPreview?.tablet || this.logoPreview?.full || '';
                    if (sDesktop) sDesktop.srcset = this.logoPreview?.computer || this.logoPreview?.full || '';
                    if (img && this.logoPreview?.full) img.src = this.logoPreview.full;
                });
            },

            // écoute globale des inputs du style
            styleChanged(e) {
                const t = e.target;
                if (!t || !t.name) return;
                const prop = this.field2prop[t.name];
                if (!prop) return;
                if (t.type === 'checkbox') this.style[prop] = !!t.checked;
                else if (t.type === 'number' || t.type === 'range') {
                    const v = t.value !== '' ? Number(t.value) : null;
                    if (v !== null && !Number.isNaN(v)) this.style[prop] = v;
                } else {
                    this.style[prop] = t.value;
                }
            },

            // génère les variables CSS pour la preview
            cssVars() {
                return {
                    '--menu-bg': this.style.backgroundColor || '#fafafa',
                    '--menu-text': this.style.textColor || '#111111',
                    '--menu-hover-text': this.style.hoverTextColor || this.style.textColor || '#111111',
                    '--menu-active-text': this.style.activeTextColor || this.style.textColor || '#111111',
                    '--submenu-bg': this.style.submenuBackgroundColor || '#ffffff',
                    '--submenu-border': this.style.submenuBorderColor || '#e5e7eb',
                    '--submenu-hover-bg': this.style.submenuHoverBackgroundColor || '#f7f7f7',

                    '--font-family': this.style.fontFamily || 'inherit',
                    '--font-weight': this.style.fontWeight || 'normal',
                    '--font-size-desktop': (this.style.fontSizeDesktop ?? 16) + 'px',
                    '--font-size-mobile': (this.style.fontSizeMobile ?? 16) + 'px',
                    '--letter-spacing': (this.style.letterSpacing ?? 0) + 'em',
                    '--text-transform': this.style.uppercase ? 'uppercase' : 'none',

                    '--menu-min-h': (this.style.menuMinHeight ?? 64) + 'px',
                    '--py-desktop': (this.style.paddingYDesktop ?? 12) + 'px',
                    '--py-mobile': (this.style.paddingYMobile ?? 10) + 'px',
                    '--gap-desktop': (this.style.gapDesktop ?? 32) + 'px',
                    '--gap-mobile': (this.style.gapMobile ?? 0) + 'px',

                    '--logo-w-desktop': (this.style.logoWidthDesktop ?? 100) + 'px',
                    '--logo-h-desktop': (this.style.logoHeightDesktop ?? 100) + 'px',
                    '--logo-w-mobile': (this.style.logoWidthMobile ?? 80) + 'px',

                    '--border-bottom-w': (this.style.borderBottomWidth ?? 0) + 'px',
                    '--border-bottom-c': this.style.borderBottomColor || '#e5e7eb',

                    '--rounded-submenu': (this.style.roundedSubmenu ?? 8) + 'px',
                    '--transition-ms': (this.style.transitionsMs ?? 180) + 'ms',
                    '--shadow-sticky': this.style.stickyShadow ? '0 4px 16px rgba(0,0,0,.08)' : 'none',
                };
            },
        }
    }
window.menuDesigner = menuDesigner;
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
