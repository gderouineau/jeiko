/* Sorti de templates/base_editor.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
window.JK_TEXTES = JSON.parse(document.getElementById("jk-textes").textContent);
