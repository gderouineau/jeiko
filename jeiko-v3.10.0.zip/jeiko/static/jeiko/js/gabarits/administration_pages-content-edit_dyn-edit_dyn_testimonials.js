/* Sorti de templates/administration_pages/content/edit_dyn/edit_dyn_testimonials.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
// addInline, moveUp, moveDown et renumberOrders viennent de formsets.js : les
// redéfinir ici les remplaçait pour tout l'éditeur (Q-05). L'écran écoute
// l'annonce de chaque ajout ou déplacement pour rafraîchir son aperçu.
document.addEventListener('jeiko:formset', function ecoute(e){
  if (!document.getElementById('tst-list')) { document.removeEventListener('jeiko:formset', ecoute); return; }
  if (e.detail.prefix !== 'tst' || typeof window.renderTestimonials !== 'function') return;
  if (e.detail.element && typeof window.wirePreviewHandlers === 'function') window.wirePreviewHandlers(e.detail.element);
  window.renderTestimonials();
});

/* ----------- Prévisualisation + autoplay ----------- */
(function(){
  const idAutoplay = '' + D.v1 + '';
  const idInterval = '' + D.v2 + '';
  const elAutoplay = document.getElementById(idAutoplay);
  const elInterval = document.getElementById(idInterval);

  const slideQ   = document.getElementById('tst-quote');
  const slideA   = document.getElementById('tst-author');
  const slideR   = document.getElementById('tst-role');
  const imgWrap  = document.getElementById('tst-avatar-wrap');
  const img      = document.getElementById('tst-avatar');
  const dotsWrap = document.getElementById('tst-dots');
  const btnPrev  = document.getElementById('tst-prev');
  const btnNext  = document.getElementById('tst-next');

  let timer = null;
  let idx   = 0;
  let data  = [];

  function toMs(v){
    const n = parseFloat(String(v||'').replace(',', '.'));
    if (isNaN(n)) return 5000;
    return n < 50 ? n * 1000 : n; // si petit, on considère secondes
  }

  function collect(){
    const items = Array.from(document.querySelectorAll('#tst-list .tst-item'));
    const active = items.filter(it=>{
      const del = it.querySelector('input[type="checkbox"][name$="-DELETE"]');
      return !(del && del.checked);
    });
    data = active.map(it=>{
      const quote  = it.querySelector('[name$="-quote"]')?.value || '';
      const author = it.querySelector('[name$="-author"]')?.value || '';
      const role   = it.querySelector('[name$="-role"]')?.value || '';
      // avatar: si input file a un fichier, on preview. Sinon on laisse vide.
      let avatarUrl = '';
      const fileInput = it.querySelector('input[type="file"][name$="-avatar"]');
      if (fileInput && fileInput.files && fileInput.files[0]) {
        avatarUrl = URL.createObjectURL(fileInput.files[0]);
      }
      return { quote, author, role, avatarUrl };
    });
    if (idx >= data.length) idx = Math.max(0, data.length - 1);
  }

  function renderDots(){
    dotsWrap.innerHTML = '';
    data.forEach((_, i)=>{
      const d = document.createElement('button');
      d.type='button';
      d.style.width='8px'; d.style.height='8px';
      d.style.borderRadius='50%'; d.style.border='none';
      d.style.background = (i===idx)? '#D97757':'#ccc';
      d.style.cursor='pointer';
      d.onclick = ()=>{ idx = i; renderSlide(); restartAutoplay(); };
      dotsWrap.appendChild(d);
    });
  }

  function renderSlide(){
    if (!data.length){
      slideQ.textContent = '—';
      slideA.textContent = 'Auteur';
      slideR.textContent = '' + D.v3 + '';
      img.style.display = 'none';
      renderDots();
      return;
    }
    const cur = data[idx];
    slideQ.textContent = cur.quote || '—';
    slideA.textContent = cur.author || '';
    slideR.textContent = cur.role || '';
    if (cur.avatarUrl){
      img.src = cur.avatarUrl;
      img.style.display = '';
    } else {
      img.removeAttribute('src');
      img.style.display = 'none';
    }
    renderDots();
  }

  function next(){ if(!data.length) return; idx = (idx + 1) % data.length; renderSlide(); }
  function prev(){ if(!data.length) return; idx = (idx - 1 + data.length) % data.length; renderSlide(); }

  function restartAutoplay(){
    if (timer){ clearInterval(timer); timer = null; }
    if (elAutoplay && elAutoplay.checked && data.length > 1){
      timer = setInterval(next, toMs(elInterval?.value));
    }
  }

  window.renderTestimonials = function(){
    collect();
    renderSlide();
    restartAutoplay();
  };

  window.wirePreviewHandlers = function(scope){
    const fields = [
      scope.querySelector('[name$="-quote"]'),
      scope.querySelector('[name$="-author"]'),
      scope.querySelector('[name$="-role"]'),
      scope.querySelector('input[type="file"][name$="-avatar"]'),
      scope.querySelector('input[type="checkbox"][name$="-DELETE"]'),
    ];
    fields.forEach(el => el && el.addEventListener('input', renderTestimonials));
    fields.forEach(el => el && el.addEventListener('change', renderTestimonials));
  };

  // bind existants
  document.querySelectorAll('#tst-list .tst-item').forEach(wirePreviewHandlers);
  if (elAutoplay) elAutoplay.addEventListener('change', restartAutoplay);
  if (elInterval) elInterval.addEventListener('input', restartAutoplay);
  btnNext.addEventListener('click', ()=>{ next(); restartAutoplay(); });
  btnPrev.addEventListener('click', ()=>{ prev(); restartAutoplay(); });

  renderTestimonials();
})();
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
