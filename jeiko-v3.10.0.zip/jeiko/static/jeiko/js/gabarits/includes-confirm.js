/* Sorti de templates/includes/confirm.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
function jkConfirm() {
    return {
        open: false,
        message: '',
        detail: '',
        label: '' + D.v1 + '',
        pending: null,

        init() {
            // Délégation : les lignes de tableau sont souvent rendues par
            // Alpine après coup, un écouteur posé élément par élément les
            // manquerait.
            document.addEventListener('click', (event) => {
                const trigger = event.target.closest('[data-confirm]');
                if (!trigger) return;
                event.preventDefault();
                event.stopPropagation();
                this.ask(trigger);
            }, true);

            document.addEventListener('submit', (event) => {
                const form = event.target.closest('form[data-confirm]');
                if (!form || form.dataset.confirmed === '1') return;
                event.preventDefault();
                this.ask(form);
            }, true);
        },

        ask(el) {
            this.message = el.dataset.confirm || '' + D.v2 + '';
            this.detail = el.dataset.confirmDetail || '';
            this.label = el.dataset.confirmLabel || '' + D.v3 + '';
            this.pending = el;
            this.open = true;
            // Le focus part sur « Annuler » : l'issue par défaut d'une
            // demande de confirmation doit être celle qui ne détruit rien.
            this.$nextTick(() => this.$refs.cancelBtn && this.$refs.cancelBtn.focus());
        },

        cancel() {
            this.open = false;
            this.pending = null;
        },

        accept() {
            const el = this.pending;
            this.open = false;
            this.pending = null;
            if (!el) return;

            if (el.tagName === 'FORM') {
                el.dataset.confirmed = '1';
                el.submit();
                return;
            }
            const form = el.closest('form');
            if (el.tagName === 'BUTTON' && form) {
                form.dataset.confirmed = '1';

                // `form.submit()` ignore DEUX choses portées par le bouton :
                // son `formaction`, et son propre couple nom/valeur.
                //
                // Conséquence constatée en production : le bouton « Supprimer
                // la sélection » portait un `formaction` vers la suppression
                // en masse, mais le formulaire postait sur sa propre `action`
                // — vide, donc sur la page courante, qui n'accepte pas le
                // POST. L'utilisateur tombait sur une page blanche.
                //
                // `requestSubmit(bouton)` déclenche l'envoi COMME si l'on
                // avait cliqué le bouton : `formaction`, `formmethod` et le
                // submitter sont respectés.
                if (typeof form.requestSubmit === 'function') {
                    form.requestSubmit(el);
                    return;
                }

                // Repli pour les navigateurs sans `requestSubmit` : on reporte
                // à la main ce que le bouton surcharge, faute de mieux.
                if (el.formAction) form.action = el.formAction;
                if (el.formMethod) form.method = el.formMethod;
                form.submit();
                return;
            }
            if (el.href) {
                window.location.href = el.href;
            }
        },
    };
}
window.jkConfirm = jkConfirm;
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
