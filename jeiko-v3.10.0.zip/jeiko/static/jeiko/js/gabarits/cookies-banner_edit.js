/* Sorti de templates/cookies/banner_edit.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
function cookieDesigner() {
    // mapping form fields -> CSS variables
    const cssMap = {
        font_family: '--jk-font-family',
        font_size_px: '--jk-font-size',
        line_height: '--jk-line-height',
        banner_bg: '--jk-banner-bg',
        banner_fg: '--jk-banner-fg',
        link_color: '--jk-link-color',
        btn_radius_px: '--jk-btn-radius',
        btn_primary_bg: '--jk-btn-primary-bg',
        btn_primary_fg: '--jk-btn-primary-fg',
        btn_outline_fg: '--jk-btn-outline-fg',
        btn_outline_border: '--jk-btn-outline-border',
        btn_ghost_fg: '--jk-btn-ghost-fg',
        modal_bg: '--jk-modal-bg',
        modal_fg: '--jk-modal-fg',
        modal_shadow: '--jk-modal-shadow',
    };

    const shadowMap = {
        none: 'none',
        sm: '0 4px 12px rgba(0,0,0,.12)',
        md: '0 12px 30px rgba(0,0,0,.20)',
        lg: '0 20px 60px rgba(0,0,0,.30)',
    };

    function setVar(root, varName, value, key) {
        if (key && key.endsWith('_px') && value !== '') value = parseInt(value, 10) + 'px';
        if (key === 'modal_shadow') value = shadowMap[value] || shadowMap.lg;
        root.style.setProperty(varName, value);
    }

    function byId(id){ return document.getElementById(id); }

    function syncLabels(root) {
        const f_message = byId('id_message_text');
        const f_accept  = byId('id_accept_all_label');
        const f_refuse  = byId('id_refuse_all_label');
        const f_customize = byId('id_customize_label');
        const f_save = byId('id_save_choices_label');
        const f_more_label = byId('id_more_info_label');
        const f_more_url   = byId('id_more_info_url');
        const f_show_refuse = byId('id_show_refuse_all');

        const elMsg   = root.querySelector('#jk-cookie-banner-message');
        const elAcc   = root.querySelector('#jk-accept-all');
        const elRef   = root.querySelector('#jk-refuse-all');
        const elCust  = root.querySelector('#jk-customize');
        const elSave  = root.querySelector('#jk-save-choices');
        const elMore  = root.querySelector('#jk-more-info');

        if (elMsg && f_message) elMsg.textContent = f_message.value || "" + D.v1 + "";
        if (elAcc && f_accept) elAcc.textContent = f_accept.value || "" + D.v2 + "";
        if (elRef && f_refuse) elRef.textContent = f_refuse.value || "" + D.v3 + "";
        if (elCust && f_customize) elCust.textContent = f_customize.value || "" + D.v4 + "";
        if (elSave && f_save) elSave.textContent = f_save.value || "" + D.v5 + "";

        if (elMore) {
            const label = (f_more_label?.value || "En savoir plus");
            const url   = (f_more_url?.value || "#");
            elMore.textContent = label;
            elMore.setAttribute('href', url || '#');
            // si pas d'URL, on masque
            elMore.style.display = url && url !== '#' ? '' : 'none';
        }

        if (f_show_refuse && elRef) {
            elRef.style.display = f_show_refuse.checked ? '' : 'none';
        }
    }

    return {
        init(){ this.syncAll(); },
        rootCssVars(){
            // variables initiales depuis l'instance (rendu serveur) — rien à faire ici,
            // Alpine mettra à jour au fil des inputs via syncAll()
            return {};
        },
        syncAll(){
            const mount = document.querySelector('#cookie-preview-mount #jk-cookie-root');
            if (!mount) return;

            // 1) Styles (variables CSS)
            for (const [key, cssVar] of Object.entries(cssMap)) {
                const input = byId('id_' + key);
                if (!input) continue;
                setVar(mount, cssVar, input.value, key);
            }

            // 2) Libellés & visibilité
            syncLabels(mount);
        }
    }
}
window.cookieDesigner = cookieDesigner;
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
