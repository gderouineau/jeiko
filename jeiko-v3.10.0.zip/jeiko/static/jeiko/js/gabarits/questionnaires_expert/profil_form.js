/* Sorti de templates/questionnaires_expert/profil_form.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
    // Si tu veux masquer/afficher dynamiquement les champs scoring
    document.addEventListener('DOMContentLoaded', function() {
        const scoringCheckbox = document.querySelector('[name="is_score_profile"]');
        const scoreFields = document.getElementById('score-fields');
        if(scoringCheckbox && scoreFields){
            scoringCheckbox.addEventListener('change', function(){
                if(this.checked){
                    scoreFields.style.display = "";
                }else{
                    scoreFields.style.display = "none";
                }
            });
        }
    });
