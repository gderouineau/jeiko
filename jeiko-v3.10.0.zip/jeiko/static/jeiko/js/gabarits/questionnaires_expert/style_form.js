/* Sorti de templates/questionnaires_expert/style_form.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
(function(){
  const root = document.getElementById('q-style-preview-root');
  const form = document.getElementById('q-style-form');
  if (!root || !form) return;

  function setVar(name, val){ root.style.setProperty(name, val); }

  // map inputs -> CSS vars keys (bouton = réponses, pas de submit_* ici)
  const map = {
    "font_family": "--q-font-family",
    "title_color": "--q-title-color",
    "title_size_mobile_px": "--q-title-size-mobile",
    "title_size_tablet_px": "--q-title-size-tablet",
    "title_size_desktop_px": "--q-title-size-desktop",
    "input_font_size_mobile_px": "--q-input-size-mobile",
    "input_font_size_tablet_px": "--q-input-size-tablet",
    "input_font_size_desktop_px": "--q-input-size-desktop",
    "theme_color": "--q-theme",
    "body_bg": "--q-body-bg",
    "answer_radius_px": "--q-answer-radius",
    "submit_font_size_px": "--q-submit-size",
    "submit_radius_px": "--q-submit-radius",
  };

  // derive hover color (simple lighten)
  function lighten(hex, f){
    const c = (hex || '').replace('#','');
    if (!/^[0-9a-f]{3}([0-9a-f]{3})?$/i.test(c)) return hex || '#000000';
    const full = c.length === 3 ? c.split('').map(ch => ch+ch).join('') : c;
    const r = parseInt(full.slice(0,2),16), g = parseInt(full.slice(2,4),16), b = parseInt(full.slice(4,6),16);
    const L = (x)=> Math.min(255, Math.round(x + (255 - x)*f));
    return '#' + [L(r),L(g),L(b)].map(x => x.toString(16).padStart(2,'0')).join('').toUpperCase();
  }

  function refreshDeviceFonts(){
    root.querySelectorAll('.preview-card').forEach(card=>{
      const device = card.getAttribute('data-device');
      const title = card.querySelector('.q-title');
      const answers = card.querySelectorAll('.q-answer');
      const btn = card.querySelector('.q-submit');

      let titleSizeVar = "--q-title-size-desktop";
      let inputSizeVar = "--q-input-size-desktop";
      if (device === 'mobile'){ titleSizeVar="--q-title-size-mobile"; inputSizeVar="--q-input-size-mobile"; }
      if (device === 'tablet'){ titleSizeVar="--q-title-size-tablet"; inputSizeVar="--q-input-size-tablet"; }

      const ts = getComputedStyle(root).getPropertyValue(titleSizeVar).trim();
      const isz = getComputedStyle(root).getPropertyValue(inputSizeVar).trim();

      if (title) title.style.fontSize = ts || title.style.fontSize;
      answers.forEach(a => a.style.fontSize = isz || a.style.fontSize);
      // Le bouton a sa propre taille, indépendante du device.
      const bsz = getComputedStyle(root).getPropertyValue('--q-submit-size').trim();
      if (btn) btn.style.fontSize = bsz || btn.style.fontSize;
    });
  }

  function refreshAll(){
    // css vars
    Object.keys(map).forEach(name=>{
      const el = form.querySelector(`[name="${name}"]`);
      if (!el) return;
      let val = el.value;
      if (name.endsWith('_px')) val = `${parseInt(val||0)}px`;
      if (name === 'font_family' && !val) val = 'inherit';
      if (map[name]) setVar(map[name], val);
      if (name === 'theme_color'){
        setVar('--q-theme-hover', lighten(val, 0.18));
        // overlay rgba pas utile ici pour le preview — on garde uniquement hover clair
      }
    });
    refreshDeviceFonts();
  }

  form.addEventListener('input', refreshAll);
  refreshAll();
})();
