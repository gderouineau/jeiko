/* Sorti de templates/administration_pages/insight.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
function pageInsights({ latestUrl, refreshUrl, csrfToken, apiKeyConfigured }) {
    return {
        latestUrl,
        refreshUrl,
        csrfToken,
        apiKeyConfigured,
        tab: 'mobile',
        loading: false,
        globalError: '',
        globalInfo: '',
        data: { mobile: null, desktop: null },

        scoreKeys: ['performance', 'accessibility', 'best_practices', 'seo', 'pwa'],
        scoreLabels: {
            performance: '' + D.v1 + '',
            accessibility: '' + D.v2 + '',
            best_practices: '' + D.v3 + '',
            seo: 'SEO',
            pwa: 'PWA'
        },

        // Flags à afficher (ordre et libellés)
        a11yFlags: [
            { key: 'alt_text_ok',        label: '' + D.v4 + '' },
            { key: 'form_labels_ok',     label: '' + D.v5 + '' },
            { key: 'link_names_ok',      label: '' + D.v6 + '' },
            { key: 'color_contrast_ok',  label: '' + D.v7 + '' },
            { key: 'headings_ok',        label: '' + D.v8 + '' },
            { key: 'lang_ok',            label: '' + D.v9 + '' },
            { key: 'keyboard_ok',        label: '' + D.v10 + '' },
        ],
        seoFlags: [
            { key: 'title_ok',              label: '' + D.v11 + '' },
            { key: 'meta_description_ok',   label: '' + D.v12 + '' },
            { key: 'viewport_ok',           label: '' + D.v13 + '' },
            { key: 'font_size_ok',          label: '' + D.v14 + '' },
            { key: 'tap_targets_ok',        label: '' + D.v15 + '' },
            { key: 'canonical_ok',          label: '' + D.v16 + '' },
            { key: 'hreflang_ok',           label: 'Hreflang' },
            { key: 'is_crawlable',          label: '' + D.v17 + '' },
            { key: 'structured_data_ok',    label: '' + D.v18 + '' },
            { key: 'robots_txt_ok',         label: 'robots.txt' },
        ],
        get categories() {
            return [
                { key: 'a11y', label: '' + D.v19 + '', flags: this.a11yFlags },
                { key: 'seo',  label: 'SEO',           flags: this.seoFlags },
            ];
        },

        init() { this.fetchLatest(); },

        async fetchLatest() {
            this.globalError = '';
            try {
                const res = await fetch(this.latestUrl, { credentials: 'same-origin' });
                if (!res.ok) throw new Error("" + D.v20 + " (" + res.status + ")");
                const json = await res.json();
                this.data.mobile = json.mobile || null;
                this.data.desktop = json.desktop || null;
            } catch (e) {
                this.globalError = e.message || '' + D.v21 + '';
            }
        },

        async refresh(strategy) {
            if (!this.apiKeyConfigured) {
                this.globalError = "" + D.v22 + "";
                return;
            }
            if (this.loading) return;
            this.loading = true;
            this.globalError = '';
            this.globalInfo = '';

            const form = new FormData();
            form.append('strategy', strategy);

            try {
                const res = await fetch(this.refreshUrl + '?strategy=' + encodeURIComponent(strategy), {
                    method: 'POST',
                    headers: { 'X-CSRFToken': this.csrfToken },
                    body: form,
                    credentials: 'same-origin'
                });
                const json = await res.json();

                if (res.status === 429) {
                    this.globalInfo = json.message || '' + D.v23 + '';
                } else if (!res.ok || json.ok === false) {
                    const err = (json.errors && json.errors.length) ? json.errors.map(e => e.error).join(' | ') : '' + D.v24 + '';
                    this.globalError = err;
                } else {
                    this.globalInfo = '' + D.v25 + '';
                }
            } catch (e) {
                this.globalError = e.message || '' + D.v26 + '';
            } finally {
                this.loading = false;
                this.fetchLatest();
            }
        },

        // utils display
        get(obj, pathArr) {
            try { return pathArr.reduce((acc, k) => (acc && acc[k] !== undefined) ? acc[k] : null, obj); }
            catch { return null; }
        },
        displayScore(v) {
            if (v === null || v === undefined) return '—';
            return Number(v);
        },
        // Tons du socle (--state-*) : les couleurs ne sont plus écrites ici.
        circleClass(score) {
            if (score === null || score === undefined || isNaN(Number(score))) return 'jk-ton-neutre';
            const v = Number(score);
            if (v >= 90) return 'jk-ton-ok';
            if (v >= 50) return 'jk-ton-attention';
            return 'jk-ton-erreur';
        },
        statusClass(status) {
            switch (status) {
                case 'ok': return 'jk-txt-ok';
                case 'pending': return 'jk-txt-attention';
                case 'error': return 'jk-txt-erreur';
                default: return 'jk-txt-neutre';
            }
        },
        fmt(v) { return (v === null || v === undefined) ? '—' : v; },
        formatDate(iso) {
            if (!iso) return '—';
            try { return new Date(iso).toLocaleString(); }
            catch { return iso; }
        },

        // icônes/états pour booléens (true/false/null)
        boolIcon(v) {
            if (v === true)  return '✓';
            if (v === false) return '✗';
            return '·';
        },
        boolClass(v) {
            if (v === true)  return 'jk-txt-ok';
            if (v === false) return 'jk-txt-erreur';
            return 'jk-txt-neutre';
        },
        boolLabel(v) {
            if (v === true)  return '' + D.v27 + '';
            if (v === false) return '' + D.v28 + '';
            return '' + D.v29 + '';
        },
    }
}
window.pageInsights = pageInsights;
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
