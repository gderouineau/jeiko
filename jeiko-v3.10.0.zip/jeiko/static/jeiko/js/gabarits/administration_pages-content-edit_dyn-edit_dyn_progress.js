/* Sorti de templates/administration_pages/content/edit_dyn/edit_dyn_progress.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
// addInline, moveUp, moveDown et renumberOrders viennent de formsets.js : les
// redéfinir ici les remplaçait pour tout l'éditeur (Q-05). L'écran écoute
// l'annonce de chaque ajout ou déplacement pour rafraîchir son aperçu.
document.addEventListener('jeiko:formset', function ecoute(e){
  if (!document.getElementById('prog-list')) { document.removeEventListener('jeiko:formset', ecoute); return; }
  if (e.detail.prefix !== 'prog' || typeof window.renderProgress !== 'function') return;
  if (e.detail.element && typeof window.wirePreviewHandlers === 'function') window.wirePreviewHandlers(e.detail.element);
  window.renderProgress();
});

/* ----------- Prévisualisation ----------- */
(function(){
  const progressInputId = '' + D.v1 + '';
  const progressInput   = document.getElementById(progressInputId);
  const bar  = document.getElementById('prog-bar');
  const text = document.getElementById('prog-text');

  function parseProgressField(v){
    if(v == null) return null;
    const n = parseFloat(String(v).replace(',', '.'));
    if (isNaN(n)) return null;
    // supporte 0–1 et 0–100
    if (n <= 1) return Math.max(0, Math.min(100, n * 100));
    return Math.max(0, Math.min(100, n));
  }

  function computeAutoPercent(){
    const items = Array.from(document.querySelectorAll('#prog-list .prog-item'));
    if (!items.length) return 0;
    // exclut ceux marqués DELETE
    const active = items.filter(it => {
      const del = it.querySelector('input[type="checkbox"][name$="-DELETE"]');
      return !(del && del.checked);
    });
    if (!active.length) return 0;
    const doneCount = active.reduce((acc, it)=>{
      const ck = it.querySelector('input[type="checkbox"][name$="-done"]');
      return acc + (ck && ck.checked ? 1 : 0);
    }, 0);
    return Math.round((doneCount / active.length) * 100);
  }

  window.renderProgress = function(){
    let percent = null;
    if (progressInput && progressInput.value.trim() !== '') {
      percent = parseProgressField(progressInput.value.trim());
    }
    if (percent === null) {
      percent = computeAutoPercent();
    }
    bar.style.width = (percent||0) + '%';
    text.textContent = (percent||0) + '%';
  };

  window.wirePreviewHandlers = function(scope){
    const del = scope.querySelector('input[type="checkbox"][name$="-DELETE"]');
    const dn  = scope.querySelector('input[type="checkbox"][name$="-done"]');
    if (del) del.addEventListener('change', renderProgress);
    if (dn)  dn.addEventListener('change', renderProgress);
  };

  // bind existants
  document.querySelectorAll('#prog-list .prog-item').forEach(wirePreviewHandlers);
  if (progressInput) progressInput.addEventListener('input', renderProgress);
  renderProgress();
})();
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
