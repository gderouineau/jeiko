/* Sorti de templates/administration/global/main.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
(function () {
    const data = D.v1;
    const labels = data.map(d => d.day);
    const pageviews = data.map(d => d.pageviews);
    const visits = data.map(d => d.visits);

    // Graphique principal
    const ctx = document.getElementById('global_stats_chart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [
                { label: '' + D.v2 + '', data: pageviews },
                { label: '' + D.v3 + '', data: visits }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });

    // Sparklines (sans axes ni tooltips)
    function spark(canvasId, arr) {
        const el = document.getElementById(canvasId);
        if (!el) return;
        const c = el.getContext('2d');
        new Chart(c, {
            type: 'line',
            data: {
                labels: arr.map((_, i) => i),
                datasets: [{
                    data: arr,
                    pointRadius: 0,
                    borderWidth: 1,
                    tension: 0.35,
                    fill: true
                }]
            },
            options: {
                plugins: { legend: { display: false }, tooltip: { enabled: false } },
                scales: { x: { display: false }, y: { display: false } },
                layout: { padding: 0 },
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }
    spark('spark_pv', pageviews);
    spark('spark_visits', visits);
})();
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
