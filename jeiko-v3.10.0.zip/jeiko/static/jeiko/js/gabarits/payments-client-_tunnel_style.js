/* Sorti de templates/payments/client/_tunnel_style.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
document.addEventListener("DOMContentLoaded", function () {
    if (!window.Intl || !Intl.DisplayNames) return;
    var noms = new Intl.DisplayNames([document.documentElement.lang || "fr"], { type: "region" });
    document.querySelectorAll("select[data-pays] option, [data-nom-pays]").forEach(function (el) {
        var code = el.value || el.getAttribute("data-nom-pays");
        if (code && code.length === 2) { try { el.textContent = noms.of(code); } catch (e) {} }
    });
    document.querySelectorAll("select[data-pays]").forEach(function (select) {
        var options = Array.from(select.options).filter(function (o) { return o.value; });
        options.sort(function (a, b) { return a.textContent.localeCompare(b.textContent); });
        options.forEach(function (o) { select.appendChild(o); });
    });
});
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
