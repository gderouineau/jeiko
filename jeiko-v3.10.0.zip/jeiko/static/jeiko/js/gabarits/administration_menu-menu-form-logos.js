/* Sorti de templates/administration_menu/menu/form.html (S-03, phase 2) :
 * les adresses des logos, lues dans le bloc de données qui précède. */
window.__LOGO_MAP__ = JSON.parse(document.currentScript.previousElementSibling.textContent);
