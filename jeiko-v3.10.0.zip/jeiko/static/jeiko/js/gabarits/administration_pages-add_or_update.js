/* Sorti de templates/administration_pages/add_or_update.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
function categorySubcategoryAlpine(initialCategory = '', initialSubcategory = '') {
    return {
        selectedCategory: initialCategory || '',
        selectedSubcategory: initialSubcategory || '',
        subcategories: [],
        loading: false,
        error: null,

        // interne
        _abortCtrl: null,

        // --- API call
        async fetchSubcategories({ force = false, preserve = false } = {}) {
            this.error = null;

            // reset seulement si on ne veut pas préserver la valeur (ex: changement manuel de catégorie)
            if (!preserve) {
                this.selectedSubcategory = '';
            }

            if (!this.selectedCategory) {
                this.subcategories = [];
                return;
            }

            // annule la requête précédente si elle existe
            if (this._abortCtrl) this._abortCtrl.abort();
            this._abortCtrl = new AbortController();

            // cache-bust si force=true
            const bust = force ? `?_=${Date.now()}` : '';
            const url = `/api/pages/categories/${this.selectedCategory}/subcategories/${bust}`;

            this.loading = true;
            try {
                const res = await fetch(url, {
                    signal: this._abortCtrl.signal,
                    cache: 'no-store',
                    headers: { 'Accept': 'application/json' }
                });
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                const data = await res.json();

                // normalise en tableau et stringifie les ids
                const items = Array.isArray(data) ? data : (data.subcategories || []);
                this.subcategories = items.map(s => ({
                    ...s,
                    id: String(s.id)
                }));
            } catch (e) {
                if (e.name !== 'AbortError') {
                    this.error = "" + D.v1 + "";
                    this.subcategories = [];
                }
            } finally {
                this.loading = false;
                this._abortCtrl = null;
            }
        },

        // --- API helpers
        refresh() {
            return this.fetchSubcategories({ force: true });
        },

        onCategoryChange() {
            return this.fetchSubcategories({ force: true, preserve: false });
        },

        // --- init
        async init() {
            if (this.selectedCategory) {
                const initialSubcat = this.selectedSubcategory ? String(this.selectedSubcategory) : '';
                // ne pas reset pendant l'init
                await this.fetchSubcategories({ force: true, preserve: true });

                if (initialSubcat) {
                    // ne l'applique que si elle existe dans la liste
                    const exists = this.subcategories.some(s => s.id === initialSubcat);
                    if (exists) {
                        // attendre que le DOM ait rendu les <option>
                        await this.$nextTick();
                        this.selectedSubcategory = initialSubcat;
                    } else {
                        // sécurité : si l'id n'existe plus, on vide
                        this.selectedSubcategory = '';
                    }
                }
            }
        }
    }
}

document.addEventListener('alpine:init', () => {
    Alpine.data('categorySubcategoryAlpine', categorySubcategoryAlpine);
});
window.categorySubcategoryAlpine = categorySubcategoryAlpine;
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
