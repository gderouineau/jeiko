/* Sorti de templates/administration_pages/content/edit_dyn/edit_dyn_stepper.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
// addInline, moveUp, moveDown et renumberOrders viennent de formsets.js : les
// redéfinir ici les remplaçait pour tout l'éditeur (Q-05). L'écran écoute
// l'annonce de chaque ajout ou déplacement pour rafraîchir son aperçu.
document.addEventListener('jeiko:formset', function ecoute(e){
  if (!document.getElementById('stp-list')) { document.removeEventListener('jeiko:formset', ecoute); return; }
  if (e.detail.prefix !== 'stp' || typeof window.renderStepperPreview !== 'function') return;
  if (e.detail.element && typeof window.wirePreviewHandlers === 'function') window.wirePreviewHandlers(e.detail.element);
  window.renderStepperPreview();
});

/* ----------- Prévisualisation ----------- */
(function(){
  const idStart = '' + D.v1 + '';
  const elStart = document.getElementById(idStart);
  const preview = document.getElementById('stp-preview');
  const previewBody = document.getElementById('stp-preview-body');

  function clamp(n,min,max){ return Math.min(Math.max(n,min),max); }
  function toInt(v, def=1){
    const n = parseInt(String(v||'').trim(), 10);
    return isNaN(n) ? def : n;
  }

  function getActiveSteps(){
    const items = Array.from(document.querySelectorAll('#stp-list .stp-item'));
    const active = items.filter(it=>{
      const del = it.querySelector('input[type="checkbox"][name$="-DELETE"]');
      return !(del && del.checked);
    });
    return active.map(it=>{
      const title = it.querySelector('[name$="-title"]')?.value || '' + D.v2 + '';
      const body  = it.querySelector('[name$="-body"]')?.value || '';
      return { title, body };
    });
  }

  window.renderStepperPreview = function(){
    const steps = getActiveSteps();
    preview.innerHTML = '';
    previewBody.innerHTML = '';

    if(!steps.length){
      preview.innerHTML = '<em>' + '' + D.v3 + '' + '</em>';
      return;
    }

    const startIndex = clamp(toInt(elStart?.value, 1), 1, steps.length) - 1;

    steps.forEach((s, i)=>{
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = (i+1) + '. ' + s.title;
      btn.style.borderRadius = '999px';
      btn.style.padding = '6px 10px';
      btn.style.border = '1px solid #ddd';
      btn.style.background = (i===startIndex) ? '#D97757' : '#fff';
      btn.style.color = (i===startIndex) ? '#fff' : '#333';
      btn.style.cursor = 'pointer';
      btn.onclick = ()=> {
        if (elStart){ elStart.value = i+1; }
        renderStepperPreview();
      };
      preview.appendChild(btn);
    });

    // body de l'étape active
    previewBody.innerHTML = steps[startIndex].body || '<em>(Sans contenu)</em>';
  };

  window.wirePreviewHandlers = function(scope){
    const del  = scope.querySelector('input[type="checkbox"][name$="-DELETE"]');
    const ttl  = scope.querySelector('[name$="-title"]');
    const body = scope.querySelector('[name$="-body"]');
    [del, ttl, body].forEach(el => el && el.addEventListener('input', renderStepperPreview));
  };

  // Bind init
  document.querySelectorAll('#stp-list .stp-item').forEach(wirePreviewHandlers);
  if (elStart) elStart.addEventListener('input', renderStepperPreview);
  renderStepperPreview();
})();
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
