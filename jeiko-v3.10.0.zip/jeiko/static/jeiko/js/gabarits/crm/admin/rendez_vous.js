/* Sorti de templates/crm/admin/rendez_vous.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
(function () {
  var form = document.getElementById('rdv-contact');
  function montrer() {
    var choisi = (form.querySelector('input[name="mode"]:checked') || {}).value || 'creneau';
    form.querySelectorAll('[data-mode]').forEach(function (bloc) { bloc.hidden = bloc.dataset.mode !== choisi; });
  }
  form.querySelectorAll('input[name="mode"]').forEach(function (r) { r.addEventListener('change', montrer); });
  montrer();
})();
