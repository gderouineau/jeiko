/* Sorti de templates/crm/admin/_selection_script.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
(function () {
  var form = document.getElementById('crm-selection');
  if (!form) return;
  var cases = function () { return Array.from(document.querySelectorAll('.crm-coche')); };
  var choisis = function () { return cases().filter(function (c) { return c.checked; }).map(function (c) { return c.value; }); };
  function maj() {
    var n = choisis().length;
    document.getElementById('crm-compte').textContent = n;
    document.getElementById('crm-supprimer').disabled = n === 0;
  }
  document.getElementById('crm-tout').addEventListener('change', function () {
    var coche = this.checked;
    cases().forEach(function (c) { c.checked = coche; });
    maj();
  });
  cases().forEach(function (c) { c.addEventListener('change', maj); });
  form.addEventListener('submit', function (e) {
    var ids = choisis();
    if (!ids.length || !window.confirm(form.dataset.confirmation)) { e.preventDefault(); return; }
    document.getElementById('crm-ids').value = ids.join(',');
  });
})();
