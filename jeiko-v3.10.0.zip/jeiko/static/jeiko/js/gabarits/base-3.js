/* Sorti de templates/base.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
        (function(){
      // A-06 : le lien de la page affichée porte aria-current="page", ce qui
      // permet aux lecteurs d'écran d'annoncer où l'on est. Posé ici et non
      // dans le gabarit : le HTML des menus est mis en cache, le même pour
      // toutes les pages. Menu principal ET pied de page.
      function marquerLaPageCourante(){
        const ici = window.location.pathname.replace(/\/+$/, '') || '/';
        document.querySelectorAll('nav a.nav-item[href]').forEach(a=>{
          const href = a.getAttribute('href');
          if (!href || href.startsWith('#')) return;  // entrée qui n'ouvre qu'un sous-menu
          const cible = new URL(href, window.location.href);
          if (cible.origin !== window.location.origin) return;
          if ((cible.pathname.replace(/\/+$/, '') || '/') === ici) a.setAttribute('aria-current', 'page');
        });
      }
      marquerLaPageCourante();
        })();
        
