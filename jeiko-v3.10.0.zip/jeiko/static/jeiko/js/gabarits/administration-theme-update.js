/* Sorti de templates/administration/theme/update.html (S-03, phase 2).
 * S'exécute là où était le script ; les valeurs du serveur arrivent par D. */
(function (D) {
(function () {
    // L'aperçu suit la saisie : on réécrit les variables sur <html>, ce qui
    // fait bouger les pastilles ET l'aperçu d'un seul geste, sans dupliquer
    // la logique de rendu.
    // {champ: variable CSS}, venu du serveur (Theme.VARIABLES).
    const VARIABLES = Object.fromEntries(D.variables);

    function enHexa(valeur) {
        // Le sélecteur natif n'accepte que #rrggbb. On convertit ce qu'on
        // peut, et on le laisse tel quel sinon — il affichera du noir, mais
        // la valeur en toutes lettres, elle, reste juste.
        const m = String(valeur).match(/rgba?\(\s*(\d+)\D+(\d+)\D+(\d+)/i);
        if (!m) return /^#[0-9a-f]{6}$/i.test(valeur) ? valeur : null;
        return "#" + [1, 2, 3].map(i => (+m[i]).toString(16).padStart(2, "0")).join("");
    }

    function appliquer(champ, valeur) {
        const variable = VARIABLES[champ];
        if (variable) document.documentElement.style.setProperty(variable, valeur);

        const pastille = document.querySelector('.jk-theme-pastille[data-pour="id_' + champ + '"]');
        if (pastille) pastille.style.background = valeur;

        const pipette = document.querySelector('.jk-theme-pipette[data-pour="id_' + champ + '"]');
        const hexa = enHexa(valeur);
        if (pipette && hexa) pipette.value = hexa;
    }

    document.querySelectorAll(".jk-theme-valeur").forEach(entree => {
        const champ = entree.dataset.couleur;
        appliquer(champ, entree.value);
        entree.addEventListener("input", () => appliquer(champ, entree.value));
    });

    document.querySelectorAll(".jk-theme-pipette").forEach(pipette => {
        pipette.addEventListener("input", () => {
            const entree = document.getElementById(pipette.dataset.pour);
            if (!entree) return;
            entree.value = pipette.value;
            appliquer(entree.dataset.couleur, pipette.value);
        });
    });
})();
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
