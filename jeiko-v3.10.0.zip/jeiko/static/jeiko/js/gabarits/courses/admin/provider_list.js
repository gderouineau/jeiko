/* Sorti de templates/courses/admin/provider_list.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
async function testProvider(providerId) {
    try {
        const response = await fetch(`/administration/courses/providers/${providerId}/test/`);
        const data = await response.json();
        if (data.success) {
            alert('✓ ' + data.message);
        } else {
            alert('✗ ' + data.message);
        }
    } catch (error) {
        alert('Erreur lors du test de connexion');
    }
}
