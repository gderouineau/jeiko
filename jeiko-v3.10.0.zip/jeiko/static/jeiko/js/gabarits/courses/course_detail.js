/* Sorti de templates/courses/course_detail.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
// Marquer les sections complétées au chargement
document.addEventListener('DOMContentLoaded', function() {
    // Already handled in template with progress data
});
