/* Sorti de templates/courses/base_courses.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
        (function () {
            const root = document.getElementById("jk-cookie-root");
            if (!root) return;
            const statusUrl = root.dataset.statusUrl;
            
            // R-01 — Il n'y a RIEN à démarrer ni à arrêter, et c'est voulu.
            // Ces fonctions appelaient `window.jeikoStartAnalytics`, définie nulle
            // part : le code avait l'air de piloter une mesure d'audience alors
            // qu'il ne pilotait rien, et le `if` empêchait de s'en apercevoir.
            // La mesure de JEIKO ne dépose rien sur l'appareil et n'enregistre
            // aucune donnée personnelle — voir stats/middleware.py. Une vraie
            // mesure, un jour, se brancherait ici et exigerait un consentement.
            function startAnalytics() {}
            function stopAnalytics() {}
            
            function initFromStatus() {
                fetch(statusUrl, { credentials: "same-origin", headers: { "X-Requested-With": "XMLHttpRequest" }})
                    .then(r => r.ok ? r.json() : null)
                    .then(data => {
                        if (!data) return;
                        if (data.tracking_allowed && data.choices && data.choices.analytics) {
                            startAnalytics();
                        }
                    })
                    .catch(() => {});
            }
            
            document.addEventListener("jeiko:cookies:consent-updated", (e) => {
                const ch = (e.detail && e.detail.choices) || {};
                if (ch.analytics) startAnalytics(); else stopAnalytics();
            });
            
            if (document.readyState === "loading") {
                document.addEventListener("DOMContentLoaded", initFromStatus);
            } else {
                initFromStatus();
            }
        })();
        
