/* Sorti de templates/base.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
        (function(){
          function cssPath(el){
            if (!el || el.nodeType !== 1) return '';
            var sel = el.tagName.toLowerCase();
            if (el.id) sel += '#'+el.id;
            else if (el.className) sel += '.'+Array.from(el.classList).join('.');
            var parent = el.parentElement;
            if (!parent) return sel;
            var i=1, sib=el;
            while ((sib = sib.previousElementSibling) && i++, sib);
            return cssPath(parent) + ' > ' + sel + ':nth-child(' + i + ')';
          }
          new PerformanceObserver(list => {
            list.getEntries().forEach(entry => {
              if (entry.hadRecentInput) return;
              (entry.sources || []).forEach(src => {
                console.log('[CLS]', entry.value.toFixed(4), {
                  node: src.node,
                  selector: cssPath(src.node),
                  prev: src.previousRect,
                  curr: src.currentRect
                });
              });
            });
          }).observe({type:'layout-shift', buffered:true});
        })();
        
