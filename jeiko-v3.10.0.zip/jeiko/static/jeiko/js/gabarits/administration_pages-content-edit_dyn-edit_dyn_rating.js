/* Sorti de templates/administration_pages/content/edit_dyn/edit_dyn_rating.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
(function(){
  const idRating   = '' + D.v1 + '';
  const idCount    = '' + D.v2 + '';
  const idMax      = '' + D.v3 + '';
  const idEditable = '' + D.v4 + '';

  const elRating   = document.getElementById(idRating);
  const elCount    = document.getElementById(idCount);
  const elMax      = document.getElementById(idMax);
  const elEditable = document.getElementById(idEditable);

  const starsBase  = document.getElementById('rt-stars-base');
  const starsFill  = document.getElementById('rt-stars-fill');
  const starsWrap  = document.getElementById('rt-stars');
  const txtVal     = document.getElementById('rt-value');
  const txtMax     = document.getElementById('rt-max');
  const txtCount   = document.getElementById('rt-count');

  function clamp(n, min, max){ return Math.min(Math.max(n, min), max); }
  function toNum(v, def=0){
    if (v === null || v === undefined) return def;
    const n = parseFloat(String(v).replace(',', '.'));
    return isNaN(n) ? def : n;
  }

  function repeatStar(n){
    let s = '';
    for (let i=0; i<n; i++) s += '★';
    return s || '★';
  }

  function render(){
    const max  = Math.max(1, Math.floor(toNum(elMax?.value, 5)));
    let   rate = toNum(elRating?.value, 0);
    rate = clamp(rate, 0, max);

    const count = Math.max(0, Math.floor(toNum(elCount?.value, 0)));
    const pct   = max > 0 ? (rate / max) * 100 : 0;

    // MAJ étoiles
    const stars = repeatStar(max);
    starsBase.textContent = stars;
    starsFill.textContent = stars;
    starsFill.style.width = pct + '%';

    // MAJ meta
    txtVal.textContent   = (Math.round(rate * 10) / 10).toFixed(1);
    txtMax.textContent   = String(max);
    txtCount.textContent = String(count);

    // curseur si editable
    starsWrap.style.cursor = (elEditable && elEditable.checked) ? 'pointer' : 'default';
  }

  // Click sur les étoiles pour ajuster la note (si editable)
  function handleClick(e){
    if (!(elEditable && elEditable.checked)) return;

    const max = Math.max(1, Math.floor(toNum(elMax?.value, 5)));
    const rect = starsBase.getBoundingClientRect();
    const x = clamp(e.clientX - rect.left, 0, rect.width);
    const ratio = rect.width > 0 ? (x / rect.width) : 0;
    // sélection au demi-point près :
    const value = Math.round((ratio * max) * 2) / 2;
    if (elRating){
      elRating.value = (Math.round(value * 10) / 10).toFixed(1);
      render();
    }
  }

  // Survol : pré-visualisation temporaire (si editable)
  function handleMove(e){
    if (!(elEditable && elEditable.checked)) return;
    const max = Math.max(1, Math.floor(toNum(elMax?.value, 5)));
    const rect = starsBase.getBoundingClientRect();
    const x = clamp(e.clientX - rect.left, 0, rect.width);
    const ratio = rect.width > 0 ? (x / rect.width) : 0;
    const tempValue = Math.round((ratio * max) * 2) / 2;
    const pct = clamp((tempValue / max) * 100, 0, 100);
    starsFill.style.width = pct + '%';
    txtVal.textContent = (Math.round(tempValue * 10) / 10).toFixed(1);
  }
  function handleLeave(){
    render();
  }

  [elRating, elCount, elMax, elEditable].forEach(el => el && el.addEventListener('input', render));
  starsWrap.addEventListener('click', handleClick);
  starsWrap.addEventListener('mousemove', handleMove);
  starsWrap.addEventListener('mouseleave', handleLeave);

  render();
})();
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
