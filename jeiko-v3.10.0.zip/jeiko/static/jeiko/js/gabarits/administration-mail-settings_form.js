/* Sorti de templates/administration/mail/settings_form.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
function testMailConfig() {
    const resultDiv = document.getElementById('test-result');
    const button = event.target;
    
    // Désactiver le bouton pendant le test
    button.disabled = true;
    button.textContent = '' + D.v1 + '';
    
    // Afficher un message de chargement
    resultDiv.innerHTML = '<div class="alert alert-info">' + D.v2 + '</div>';
    
    // Récupérer le CSRF token
    const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]').value;
    
    // Faire la requête AJAX
    fetch('' + D.v3 + '', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken
        },
    })
    .then(response => response.json())
    .then(data => {
        button.disabled = false;
        button.textContent = '' + D.v4 + '';
        
        if (data.success) {
            resultDiv.innerHTML = `
                <div class="alert alert-success">
                    <strong>✓ ${D.v5}</strong><br>
                    ${data.message}
                </div>
            `;
        } else {
            let errorHtml = `
                <div class="alert alert-danger">
                    <strong>✗ ${D.v6}</strong><br>
                    ${data.error}
            `;
            if (data.trace) {
                errorHtml += `<br><br><details><summary>${D.v7}</summary><pre style="font-size: 0.85em; max-height: 200px; overflow: auto;">${data.trace}</pre></details>`;
            }
            errorHtml += '</div>';
            resultDiv.innerHTML = errorHtml;
        }
    })
    .catch(error => {
        button.disabled = false;
        button.textContent = '' + D.v8 + '';
        resultDiv.innerHTML = `
            <div class="alert alert-danger">
                <strong>✗ ${D.v9}</strong><br>
                ${D.v10} ${error}
            </div>
        `;
    });
}
window.testMailConfig = testMailConfig;
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
