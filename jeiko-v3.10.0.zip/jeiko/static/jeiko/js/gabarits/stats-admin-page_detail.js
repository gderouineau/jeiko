/* Sorti de templates/stats/admin/page_detail.html (S-03, phase 2).
 * S'exécute là où était le script, au même moment ; les valeurs du serveur
 * arrivent par D, lues dans le bloc de données qui précède cette balise. */
(function (D) {
    (function () {
        const data = D.v1;
        const labels = data.map(d => d.day);
        const pageviews = data.map(d => d.pageviews);
        const visits = data.map(d => d.visits);
        const ctx = document.getElementById('line').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    { label: '' + D.v2 + '', data: pageviews },
                    { label: '' + D.v3 + '', data: visits }
                ]
            }
        });
    })();
})(JSON.parse(document.currentScript.previousElementSibling.textContent));
