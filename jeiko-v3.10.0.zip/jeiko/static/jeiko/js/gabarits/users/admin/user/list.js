/* Sorti de templates/users/admin/user/list.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
  (function(){
    var checkAll = document.getElementById('check-all');
    var bulkForm = document.getElementById('bulk-form');
    if(!bulkForm){ return; }  // pas la permission : rien à câbler

    function rowChecks(){ return Array.prototype.slice.call(document.querySelectorAll('.row-check')); }
    function selectedIds(){ return rowChecks().filter(function(c){ return c.checked; }).map(function(c){ return c.value; }); }
    function updateCount(){
      document.getElementById('bulk-count').textContent = selectedIds().length;
    }

    if(checkAll){
      checkAll.addEventListener('change', function(){
        rowChecks().forEach(function(c){ c.checked = checkAll.checked; });
        updateCount();
      });
    }
    rowChecks().forEach(function(c){ c.addEventListener('change', updateCount); });

    // Le formulaire porte plusieurs actions, distinguées par le `formaction`
    // du bouton cliqué. La validation doit donc dépendre du bouton, et non
    // s'appliquer à tout envoi :
    //
    //  - une sélection non vide est exigée par TOUTES les actions ;
    //  - un rôle n'est exigé QUE par les actions de rôle.
    //
    // Le contrôle du rôle était inconditionnel : la suppression en masse était
    // donc refusée en silence, faute d'un rôle qui ne la concerne pas. Et
    // `getElementById('bulk-role')` levait pour un compte autorisé à supprimer
    // mais pas à assigner, puisque le select n'est alors pas rendu.
    bulkForm.addEventListener('submit', function(e){
      var ids = selectedIds();
      if(ids.length === 0){
        e.preventDefault();
        alert('Sélectionnez au moins un utilisateur.');
        return;
      }

      // `e.submitter` désigne le bouton réellement actionné. Absent sur les
      // navigateurs anciens : on retombe alors sur l'ancien comportement, le
      // plus strict.
      var bouton = e.submitter;
      var action = (bouton && bouton.getAttribute('formaction')) || bulkForm.action || '';
      var estUneSuppression = action.indexOf('delete-selection') !== -1;

      if(!estUneSuppression){
        var champRole = document.getElementById('bulk-role');
        if(champRole && !champRole.value){
          e.preventDefault();
          alert('Choisissez un rôle.');
          return;
        }
      }

      document.getElementById('bulk-user-ids').value = ids.join(',');
    });
  })();
