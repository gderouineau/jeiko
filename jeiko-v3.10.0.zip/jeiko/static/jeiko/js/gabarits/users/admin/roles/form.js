/* Sorti de templates/users/admin/roles/form.html (S-03, phase 2) : plus de script écrit dans le gabarit. */
  document.querySelectorAll('.group-toggle').forEach(function(btn){
    btn.addEventListener('click', function(){
      var body = document.querySelector('[data-group-body="' + btn.dataset.group + '"]');
      var boxes = body.querySelectorAll('input[type=checkbox]');
      var allChecked = Array.prototype.every.call(boxes, function(b){ return b.checked; });
      boxes.forEach(function(b){ b.checked = !allChecked; });
    });
  });
