# JEIKO — état des lieux et plan d'action

*Constat du 17/08/2026, tenu à jour au fil des correctifs.*

Ce document est la mémoire du chantier : il porte les constats, ce qui est
livré, ce qui reste, et les décisions prises. Les identifiants (`S-01`, `A-12`,
`Q-11`…) sont ceux cités dans les commentaires du code.

Légende : `[x]` fait · `[~]` partiel · `[ ]` à faire

Pour les conventions de travail (où éditer, comment vérifier, les pièges) :
voir `CLAUDE.md` à la racine de `Documents/Projects`.

---

## Où en est-on

Publié en **3.3.0** le 21/08/2026 : phase 1 terminée, régression d'affichage
corrigée, administration mobile réparée.

| | |
|---|---|
| Tests | **692 passent** (637 à la 3.2.3, 558 avant le chantier) |
| Gabarits | 283, **0 erreur de compilation** |
| `check` / migrations | aucun problème, aucune migration manquante |

### Ce que 3.3.0 corrige, et pourquoi elle est mineure et non corrective

**3.2.3 éteignait tout le contenu de toutes les pages sous 992 px** — mobiles
et tablettes, site public comme éditeur (A-17). Constaté en ligne sur
accompagnementhumain.com. C'est le motif de la publication.

Une version mineure plutôt qu'un correctif se justifie : la livraison ne fait
pas que réparer, elle **change ce que le produit accepte**. Les validateurs de
S-10/S-11 refusent des fichiers qu'un site prenait jusqu'ici — une image de
plus de 10 Mo, un PDF qui n'en est pas un. Un exploitant qui voit un import
échouer après mise à jour doit pouvoir rattacher ce changement à un numéro de
version.

**Six migrations, dont deux touchent des données** : `calendars/0017` chiffre
les clés Google existantes, `courses/0005` rattrape ce que `courses/0004`
n'avait pas repris. Les quatre autres n'ajoutent que des validateurs.

Reste à passer `jeiko-client-update` sur chaque site : c'est ce qui rallume
les mobiles.

---

## 1. Livré

### Défauts visibles par les visiteurs

- `[x]` **A-12 — le menu mobile ne s'ouvrait sur aucun layout.** Le binding
  Alpine était décomposé : `mobile ? 'is-open' : ''` se trouvait *à l'intérieur*
  de l'attribut `class`, avec un `:` orphelin à la place de `:class`. La classe
  `is-open` n'était jamais posée, et `toggle_menu.html` laissait donc le panneau
  en `display:none`. **Le site public était sans navigation sur mobile.**
  Verrouillé par `administration_menu/tests_layouts.py`.

- `[x]` **Q-11 — le CSS de production avait neuf à onze mois de retard.**
  L'éditeur chargeait `main.css`, le site public `main.min.css`, maintenu à la
  main : 175 sélecteurs sur 370 manquaient en ligne. C'est l'origine des écarts
  observés entre l'éditeur et le rendu réel. La minification se fait désormais à
  `collectstatic` (`jeiko/staticfiles.py`), les `.min.css` ont disparu du paquet.

- `[x]` **Q-11 bis — deux défauts de mon propre correctif, corrigés après la
  première mise en production.** Le balayage portait sur tout `STATIC_ROOT`, donc
  sur des fichiers périmés que `collectstatic` n'efface jamais ; et le filtre
  « déjà minifié » testait le suffixe `.min.css`, que l'empreinte
  (`main.min.<hash>.css`) fait échouer. D'où dix traces `csscompressor` par
  déploiement, sans conséquence mais bruyantes.

- `[x]` **S-05 — le bloc graphique était mort dès qu'on le configurait.**
  `options_json` est un `JSONField` rendu en repr Python dans `x-data` :
  `{'beginAtZero': True}` sortait avec `True`, inexistant en JavaScript, d'où une
  `ReferenceError` et aucun graphique. Toute option contenant un booléen ou un
  `null` cassait l'affichage. Les options passent par un bloc
  `<script type="application/json">`.

- `[x]` **Le bandeau cookies était partiellement non stylé en ligne.** La branche
  non-DEBUG de `base.html` ne chargeait ni `menu.css`, ni `consent.css` — seule
  la branche DEBUG était complète, ce qui rendait l'écart invisible en
  développement.

- `[x]` **Les leurres anti-robots étaient visibles.** `.cf-hp` n'était stylé
  nulle part : le champ « Société » du formulaire de contact s'affichait, les
  visiteurs le remplissaient de bonne foi, et leur message était rejeté.

- `[x]` **A-17 — le contenu de toutes les pages était éteint sous 992 px.**
  *Régression introduite par le correctif A-12, sortie en 3.2.3.* En réparant
  le sélecteur cassé `[x-cloak="menu"]` de `menu.css` — Alpine écrit
  `x-cloak=""`, la règle ne correspondait donc à rien — on l'a élargi à
  `[x-cloak]` tout court. Or `partials/bloc.html` posait cet attribut sur
  **chaque bloc de chaque page**, et Alpine ne l'en retire jamais : le bloc ne
  porte aucun `x-data`, ce n'est pas un composant, Alpine ne le visite pas.
  Sous 992 px, tout passait en `display:none !important` — public et éditeur.

  Deux erreurs ont été nécessaires, deux verrous les ferment :
  `nav.top-menu [x-cloak]` borne la règle au menu, et le bloc ne porte plus
  d'attribut inutile. `administration_pages/tests_bloc_cloak.py` refuse toute
  règle `[x-cloak]` non bornée, dans n'importe quelle feuille du paquet.

  **Ce que cet épisode dit du reste du plan** : rien ne le voyait. Les 637
  tests passaient, les 283 gabarits compilaient, le HTML rendu était complet et
  correct — c'est le CSS qui l'effaçait, et seulement en dessous d'une largeur
  qu'on n'a pas sur un écran d'ordinateur. C'est l'argument le plus concret
  pour la phase 4, et pour un contrôle de rendu à deux ou trois largeurs.

### Inscription et comptes

- `[x]` **S-15 — confirmation d'adresse obligatoire.**
  `ACCOUNT_EMAIL_VERIFICATION = "mandatory"`. Le compte ne sert qu'une fois le
  lien suivi.
- `[x]` **Bienvenue et alerte à l'exploitant déplacées** de `user_signed_up` vers
  `email_confirmed` : plus de « Bienvenue » avant confirmation, et l'exploitant
  n'est prévenu que des comptes qui existent vraiment.
- `[x]` **Antispam à l'inscription** — leurre + trois plafonds par IP
  (`users/throttling.py`). Le formulaire reçoit la requête par
  `CustomSignupView.get_form_kwargs` : `SignupForm` d'allauth ne la prend pas, et
  sans elle le plafond serait global.
- `[x]` **Purge des comptes non confirmés à 30 jours** (`users/purge.py`, inscrite
  dans `cron_24h`). Protège le personnel et tout compte porteur d'une commande,
  d'une formation ou d'un rendez-vous.
- `[x]` **Migration `users/0010`** — marque vérifiés les comptes antérieurs.
  **Indispensable et non réversible** : sans elle, le passage en `mandatory`
  enfermait dehors la totalité des comptes existants.
- `[x]` **S-19 — l'administration confondait « actif » et « peut se connecter ».**
  Depuis le passage en `mandatory`, un compte a deux états sans rapport :
  `User.is_active` — non désactivé — et l'adresse confirmée, qui vit dans
  `EmailAddress` (allauth). La liste n'affichait que le premier, en vert : un
  compte fraîchement inscrit s'y lisait « Actif : Oui » alors qu'il était
  inutilisable, et l'exploitant cherchait la panne ailleurs.

  La liste affiche désormais l'état **effectif** (`Non — e-mail non confirmé`),
  la fiche sépare les deux, et deux gestes sont offerts : renvoyer le lien, ou
  **confirmer à la place du titulaire** — porte de service pour les adresses
  qui ne reçoivent rien, réservée à `auth.change_user` et tracée au journal de
  sécurité, puisqu'elle ouvre un compte. Côté visiteur, l'écran d'attente
  d'allauth — anglais, hors charte, sans issue — est remplacé et porte un
  bouton **Renvoyer l'e-mail**, plafonné (3 par quart d'heure et par compte,
  10 par heure et par IP). Le compte vient de la session, jamais d'un champ :
  sinon l'écran devient un service d'envoi ouvert doublé d'un révélateur de
  comptes existants. `jeiko/users/verification.py`, 13 tests.

  **Décision prise le 23/08/2026, à ne pas rouvrir sans raison :
  `is_active` n'est PAS mis à `False` pour un compte non confirmé.** La
  tentation est forte — « ils doivent être inactifs » — mais ce drapeau a son
  propre sens, celui d'une suspension décidée par l'exploitant. Le confondre
  avec la confirmation coûterait trois choses : Django refusant d'authentifier
  un compte inactif, il faudrait un récepteur sur `email_confirmed` pour le
  repasser à `True`, sans quoi le lien reçu par e-mail ne servirait plus à
  rien ; `users/purge.py` s'appuie sur la distinction ; et le filtre « Actif »
  de la liste changerait de sens sans prévenir. C'est l'affichage qui mentait,
  pas la donnée.

- `[x]` **Suppression de comptes** — unitaire et en masse, avec refus motivé.
  À distinguer de l'effacement RGPD : `Supprimer` retire la ligne (faux comptes),
  `Effacer les données` anonymise et conserve les commandes (demande d'un client).

### E-mails

- `[x]` **Logo dédié aux e-mails** (`Logo.mail_logo`, facultatif). Sa présence
  vaut activation ; vide, on retombe sur le logo du site.
- `[x]` **Correction du logo servi.** `_logo_url` prenait `computer_size`, une
  variante **WebP** — format qu'Outlook pour Windows n'affiche pas. Tous les
  e-mails partaient avec un logo cassé chez une partie des destinataires.
  L'ordre est maintenant : logo dédié → original (PNG/JPEG) → variantes WebP.
- `[x]` **Absence d'URL de site journalisée.** Sans elle, toutes les images de
  tous les e-mails sont relatives donc cassées — et invisible depuis
  l'administration, puisque le site les affiche parfaitement.

### Sécurité et conformité

- `[x]` **S-04** — les trois générateurs JSON échappent `<`, `>`, `&`
  (identité du site, boutique, questionnaires).
- `[x]` **S-13** — les deux fragments d'éditeur exigent `change_page`.
- `[x]` **S-17** — `X_FRAME_OPTIONS = "DENY"`, avec
  `@xframe_options_sameorigin` sur la seule vue d'aperçu d'e-mail.
- `[x]` **S-18** — `css_vars` nettoie avant d'interpoler dans un attribut `style`.
- `[x]` **R-03** — l'avatar est effacé du disque à l'effacement RGPD.
- `[x]` **R-04** — `stats_purge` et `jeiko_calendars_purge` inscrites dans
  `cron_24h` : elles existaient et n'étaient appelées nulle part.
- `[x]` **Q-03** — file d'écriture des statistiques plafonnée (1000).
- `[x]` **Q-01** — écran d'arborescence des profils de questionnaire, et
  suppression des deux gabarits qui ne compilaient pas.
- `[x]` **E-04, A-10a, D-04, Q-10** — cache du `<title>`, `<h1>` sur les pages
  d'erreur, page 500 autonome, fichiers morts.

### Corrections d'audits antérieurs

`AUDIT_EDITOR.md` est à réviser sur trois points :

- **C3** y est marqué « volontairement non fait » : il **a été fait** depuis, via
  `administration_pages/page_cache.py`.
- **F5** affirme que `menu_design_1.css` « est bien utilisé » : **non**.
- **B11** décrit une redéfinition d'`addInline` dans un gabarit : il y en a
  **sept**.

`AUDIT_COURSES.md` — ses quatre points sont bien corrigés.

**E-01 était un faux positif** : produits et formations sont déjà correctement
traités (`CustomObject.get_absolute_url()` renvoie l'URL boutique ; l'espace
formation est volontairement en `noindex`).

---

## 2. Reste à faire, par ordre proposé

### Phase 1 — sécurité, correctifs ponctuels · ~1 j · **terminée le 21/08**

- `[x]` **S-01 — `credentials_json` est chiffré** (`calendars/models.py`).
  Le JSON de compte de service Google, clé privée RSA comprise, était en clair
  en base : une sauvegarde égarée suffisait, et une clé qui a fuité ne se
  rattrape pas — il faut la révoquer chez Google et reconfigurer chaque site.
  Migration `calendars/0017`, réversible dans les deux sens (la marche arrière
  passe par du SQL brut, sans quoi l'ORM rechiffrerait ce qu'on déchiffre).
  Vérifié sur les données réelles : aller, retour, aller.

  Deux choses apprises sur `EncryptedJSONField`, notées dans `encrypted.py` :
  il chiffre **les valeurs, pas les clés** (la structure du document reste
  lisible en base), et il rend **les scalaires en chaînes** (`21` ressort
  `"21"`). N'y ranger que des chaînes.

- `[x]` **Rattrapage de `courses/0004`** *(trouvé en faisant S-01)*. Cette
  migration passait `VideoStorageProvider.config` en champ chiffré par un
  simple `AlterField`, sans reprise de données. Comme la colonne ne change pas
  (`jsonb` de part et d'autre), rien ne signalait le problème — mais les lignes
  déjà présentes restaient en clair, et une ligne en clair n'est pas
  déchiffrable : la lecture rendait une `str` là où `courses/utils.py` fait
  `config.get('access_token')`. `courses/0005` reprend les données, et
  `encrypted.py` rétablit le `dict` en journalisant, pour les lignes qu'une
  migration n'aurait pas vues.

- `[x]` **S-14 — `PaymentCheckView`.** Pire que prévu : le
  `payment_intent_client_secret` était **lu puis jamais utilisé**. L'adresse
  acceptait n'importe quel `pi_…`, d'un visiteur anonyme, et réglait la
  commande désignée par les métadonnées — celle d'un autre client comprise.
  Trois gardes : `LoginRequiredMixin`, comparaison du `client_secret` à temps
  constant, et commande restreinte au visiteur. Six tests dans
  `payments/tests.py`.

- `[x]` **S-10 / S-11 — gardes sur les fichiers téléversés** (`jeiko/uploads.py`).

  *Images.* `Image.MAX_IMAGE_PIXELS` descend à 25 Mpx, posé dans
  `apps.ready()` — c'est une variable globale de Pillow, la laisser dépendre
  de l'ordre des imports revient à ne pas savoir si elle est en vigueur. Le
  garde-fou d'origine de Pillow existait, mais à 89 Mpx : de quoi mettre une
  machine à genoux avant qu'il ne serve, d'autant que `ImageContent.save()`
  déplie l'image **cinq fois** pour produire ses variantes. Plafond de 10 Mo
  en complément : 25 Mpx ne dit rien du poids du fichier.

  Le validateur est posé sur les sept champs réellement téléversés — image de
  page, avatar, deux miniatures de formation, logo, logo d'e-mail, favicon,
  icône de réseau social — et **pas** sur les variantes, que nous fabriquons.

  *PDF de formation.* Le champ n'avait **aucun** validateur : ni extension, ni
  poids, ni contenu. Extension, 25 Mo, et vérification de la signature
  `%PDF-` : `serve_pdf` renvoie ce fichier depuis le domaine du site sous un
  `Content-Type` que nous affirmons. `SECURE_CONTENT_TYPE_NOSNIFF` couvre
  déjà le cas, mais c'est un réglage, dans un autre fichier, qu'un site peut
  perdre — la signature, elle, ne dépend d'aucun réglage.

  Dix tests (`jeiko/tests_uploads.py`), dont une vraie bombe de
  décompression : un PNG valide de quelques dizaines d'octets dont l'en-tête
  annonce dix mille mégapixels.

  *Ce que cela ne couvre pas* : ces validateurs s'exécutent après réception du
  fichier. La limite de réception reste celle du serveur web
  (`client_max_body_size`). Et une signature `%PDF-` ne dit pas qu'un PDF est
  inoffensif, seulement que ce n'est pas autre chose déguisé.
- `[x]` **S-12 — les six redirections sont validées** (`jeiko/redirections.py`).
  Elles passaient `next` tel quel à `redirect()` : le lien part de votre
  domaine, porte votre certificat, et dépose l'utilisateur sur la copie de
  votre page de connexion. Rien ne casse, rien ne lève — une redirection
  ouverte n'existe que dans le lien envoyé par courriel.

  **Le modèle proposé par ce plan était lui-même faillible.** Le contrôle de
  `administration_pages/views.py` — `startswith('/')` et pas `'//'` — laisse
  passer `/\site-piege.example` : le navigateur traite la barre inverse comme
  une barre à cet endroit. On passe donc par
  `django.utils.http.url_has_allowed_host_and_scheme`, et cet écran-là est
  corrigé avec les six autres.

  Un test relit le paquet et refuse qu'un `next` reparte brut vers
  `redirect()` : c'est ce qui empêche le septième cas d'apparaître.

- `[x]` **S-06 — `clean_svg` couvre les formes qui lui échappaient.**
  Deux trous, vérifiés l'un et l'autre sur l'ancienne version avant
  correction — les cinq charges d'épreuve passaient toutes.

  *La forme auto-fermante.* La branche appariée listait `handler`, `set` et
  `animate`, la branche auto-fermante ne les avait pas : `<set …>…</set>`
  était retiré, `<set …/>` passait. Or c'est leur forme naturelle, ces
  éléments n'ayant pas de contenu — et ils sont retors : ils n'exécutent rien
  eux-mêmes, ils **écrivent un attribut pendant l'animation**.
  `<set attributeName="onload" to="alert(1)"/>` repose donc un gestionnaire
  d'événement *après* le passage du nettoyage. Les deux branches lisent
  maintenant la même liste, augmentée d'`animateTransform` et `animateMotion`.

  *Les références de caractères.* `href="&#106;avascript:alert(1)"` ne
  contient pas le mot `javascript` : rien ne le retirait, alors que le
  navigateur décode la valeur avant de lire le schéma. Le motif accepte
  désormais les mêmes écritures que lui — décimale, hexadécimale, zéros de
  tête, point-virgule facultatif — ainsi que les blancs de contrôle
  intercalés (`java\tscript:`).

  19 tests, dont un jeu d'icônes légitimes qui doivent traverser intactes :
  un nettoyage qui casse les vraies icônes ne serait pas gardé longtemps.

### Phase 2 — RGPD · ~1 j

- `[ ]` **R-01 — le bandeau promet un réglage qui n'existe pas.**
  `window.jeikoStartAnalytics` n'est défini nulle part, et `stats/middleware.py`
  mesure sans consulter le consentement. Votre décision « aucun cookie non
  obligatoire » simplifie sans supprimer : l'écart entre ce que le bandeau
  annonce et ce que le site fait reste à refermer.
- `[ ]` **R-02** — les six `except Exception: pass` de l'effacement RGPD
  (`users/rgpd.py`) : journaliser et remonter l'échec partiel.
- `[ ]` **R-05** — rétention sur `SecurityEvent` et `UserSession`.
- `[ ]` **R-06** — auto-héberger FontAwesome (page publique !) et Inter (admin).

### Phase 3 — référencement · ~1 j

- `[ ]` **E-05 / D-06 — un seul chantier.** `SocialLink` n'a ni formulaire ni
  écran, *donc* le `sameAs` du JSON-LD reste vide. **Priorité 1 SEO.**
- `[ ]` **E-06** — image de partage par défaut + `og:image:width/height/alt`.
- `[ ]` **E-03** — `robots.txt` ne doit plus lister les pages dépubliées.
- `[ ]` **S-09** — `ACCOUNT_RATE_LIMITS` sur un cache dédié : aujourd'hui
  publier une page remet à zéro le compteur anti-force-brute d'allauth.
- `[ ]` **S-07 / S-08** — jeton CSRF sur la réservation publique ; plafond et
  leurre sur le questionnaire.
- `[~]` **E-02** — multilingue, reporté (dépend de Q-07).

### Phase 4 — responsive de l'administration · ~2,5 j · **urgent**

Chantier commencé puis laissé. `.jk-filters` (admin_ui.css) vient d'être adopté
par la liste des utilisateurs : cinq filtres passent de dix lignes à deux.

**Priorité relevée (21/08) : l'administration est utilisée quotidiennement
depuis un mobile.** Ce n'est donc pas un confort, c'est le poste de travail.

- `[x]` **A-18 — le menu latéral ne se refermait pas sur téléphone**, et
  s'ouvrait parfois tout seul au chargement. Deux causes, indépendantes.

  *Il s'ouvrait seul.* `admin_menu.css` pose le menu `position:fixed; left:0`
  à toutes les largeurs — déployé par défaut. Ce qui le repliait sous 992 px
  ne vivait que dans `admin_ui.css`, chargée après. Il suffit que cette
  feuille manque — cache de navigateur périmé sur un téléphone, requête qui
  n'aboutit pas — pour que le menu s'affiche en travers de l'écran, et
  qu'aucun bouton ne sache le refermer : leur style vient de la même feuille
  absente. C'est très probablement ce qui s'est produit sur iPhone alors que
  la même largeur se comportait bien sur un ordinateur — en production, le
  nom des fichiers porte une empreinte, ce qui protège de ce cas ; en
  développement, non. L'état replié est désormais déclaré **aussi** dans
  `admin_menu.css` : la redite fait pencher la panne du bon côté.

  *Il ne se refermait pas.* Il n'existait qu'une sortie — le bouton flottant
  — plus la touche Échap, qu'un téléphone n'a pas. Tout reposait donc sur un
  unique élément `position:fixed`. Plutôt que de chercher ce qui le
  recouvrait, on a retiré le point unique de défaillance : un voile qui ferme
  au toucher (le geste que tout le monde essaie d'abord) et une croix à
  l'intérieur du panneau s'ajoutent au bouton. Les quatre sorties vérifiées
  au navigateur, verrouillées par `administration/tests_menu_mobile.py`.

- `[x]` **A-19 — la barre rapide débordait de la largeur sur téléphone.**
  Six entrées sur une ligne `flex` sans retour à la ligne. Elles passent
  désormais à la ligne, ce qui rend la hauteur variable — et condamnait le
  `body { margin-top: 30px }` qui lui réservait sa place, écrit pour UNE
  ligne. La barre passe de `fixed` à `sticky` : elle occupe exactement sa
  propre hauteur, sans marge à tenir à jour ni JavaScript à redéclencher à
  chaque rotation d'écran, et reste épinglée en haut au défilement comme
  avant. Le `width: 100vw` est retiré au passage : il compte la barre de
  défilement et provoquait à lui seul un débordement horizontal.
- `[ ]` **A-14** — généraliser `.jk-filters` aux autres écrans à filtres.

- `[ ]` **A-20 — les tableaux débordent de la page, y compris sur ordinateur.**
  Constaté sur « Rendez-vous passés » : douze colonnes posées directement dans
  `.admin-content-container`, sans rien pour les contenir. La page entière se
  décale, et les premières colonnes sortent de l'écran.

  `admin_ui.css:272` déclare pourtant `.admin-table-scroll { overflow-x:
  auto; }` — un conteneur qui fait défiler le tableau sans emporter la page.
  **Aucun des 14 gabarits qui utilisent `.admin-table` ne l'emploie.** La
  classe a été écrite et jamais posée : c'est exactement le défaut invisible
  que décrit A-17, un outil correct que rien ne relie à son usage.

  Le travail est mécanique — envelopper 14 tableaux — et devrait s'accompagner
  d'un test qui refuse un `.admin-table` sans conteneur, sans quoi le
  quinzième écran rouvrira le défaut. **À faire avant A-15** : c'est la moitié
  peu coûteuse du problème, et elle règle déjà le cas de l'ordinateur.

  Les plus larges : rendez-vous (12 colonnes), types de rendez-vous (11),
  disponibilités (8), accès aux formations (8).

- `[ ]` **A-15** — tableaux en cartes sous 768 px. *À trancher* : défilement
  latéral (peu coûteux, se lit de travers) ou bascule en cartes (recommandé,
  commencer par utilisateurs / commandes / rendez-vous). A-20 livre déjà le
  défilement latéral ; ce point ne porte donc plus que sur la bascule en
  cartes.

- `[ ]` **A-21 — l'écran Performance / Insights ignore la charte de
  l'administration.** Ses boutons sont clair sur clair, à peine visibles :
  `background:#fff` avec une bordure `#888` et aucune couleur de texte posée,
  et les onglets Mobile / Desktop sont `background:transparent; border:none`
  — rien ne dit que ce sont des boutons.

  La cause n'est pas un mauvais réglage de couleur, c'est que l'écran est
  écrit **entièrement en styles en ligne** : 91 attributs `style=` dans
  `administration_pages/insight.html`, trois fois plus que le deuxième gabarit
  le plus chargé. Il n'utilise aucune des classes `.btn`, `.btn-secondary`,
  `.btn-outline-primary` d'`admin_ui.css`, qui portent pourtant les contrastes
  validés et les variables de thème.

  Reprendre l'écran sur les classes existantes le règle, et le rend au passage
  compatible avec A-13 (palette d'accent) et A-11 (mode sombre) — dont il
  serait autrement le seul écran à sortir, ses couleurs étant figées dans le
  balisage. À rapprocher de **A-07** (contrastes) et **D-02** (généraliser les
  composants aux écrans les plus vus).
- `[ ]` **A-16** — cibles tactiles d'au moins 44 px.

### Phase 5 — accessibilité, le socle · ~2 j

- `[ ]` **A-01** — `<main>` et lien d'évitement. Aucun écran d'administration
  n'a de repère principal.
- `[ ]` **A-02** — `aria-describedby` vers l'aide, `aria-invalid` sur les
  erreurs. `includes/field.html` pose déjà l'`id`, aucun champ ne le référence.
- `[ ]` **A-03** — 135 `<label>` sans `for`, dont
  `product_form.html:447` où le `=` manque.
- `[ ]` **A-04** — retirer `role="menu"`/`menuitem`, ajouter `aria-haspopup`.
- `[ ]` **A-05** — sous-menus ouvrables au clic et au clavier (desktop
  uniquement : sur mobile ils sont déjà `display:block`).
- `[ ]` **A-06** — `aria-current="page"`.
- `[ ]` **D-07** — reprendre les designs de menu abandonnés (mêmes fichiers).

### Phase 6 — accessibilité, finition · ~1,5 j

- `[ ]` **A-07** — contrastes : onglet actif à 1,05:1, bordures de champ à
  1,3:1, anneau de focus à 20 % d'opacité.
- `[ ]` **A-08** — `@media (forced-colors: active)`.
- `[ ]` **A-09** — alt obligatoire avec case « image décorative ».
  *Attention* : un alt par défaut automatique est **contre-productif** — le
  lecteur d'écran annonce « image, image ». Il faut un alt écrit, ou vide.
- `[ ]` **A-10** — 404 et 403 éditables. *La 500 ne peut pas l'être* (elle
  s'affiche quand la base est tombée) : la rendre éditable en administration,
  puis en écrire une copie statique sur disque.
- `[ ]` **D-03** — paginer les 14 listes d'administration.

### Phase 7 — thème de l'administration · ~1,5 j

- `[ ]` **A-13** — palette d'accent au choix (6-7 teintes validées en
  contraste), stockée sur `WebSite`.
- `[ ]` **A-11** — mode sombre (`prefers-color-scheme`). *Distinct de A-13* :
  l'un suit le système, l'autre est un choix de couleur.
- `[ ]` **D-09** — unifier les cinq `:root` concurrents (préalable aux deux).

### Phase 8 — robustesse et nettoyage · ~1,5 j

- `[ ]` **Q-05** — sept redéfinitions d'`addInline` en collision avec
  `formsets.js`.
- `[ ]` **Q-02** — journaliser les 28 `except Exception: pass` restants.
- `[ ]` **Q-08** — classifier `Django :: 5.1` faux dans
  `packages/jeiko/pyproject.toml` (hors du périmètre habituel).
- `[ ]` **D-08** — Cookies, Pages légales et Identité sous le système de rôles.
- `[ ]` **D-02** — généraliser `includes/field.html` aux 30 écrans les plus vus.

### Phase 9 — génération de PDF · ~4 j

`Page.is_pdf` **existe déjà** (`models.py:202`) et ne sert qu'à exclure ces pages
du sitemap : le concept était prévu, jamais construit. `emailing/render.py`
(620 lignes, une `Page` → du HTML d'e-mail) est le patron exact à décliner.

- `[ ]` **D-10** — moteur de rendu PDF (WeasyPrint).
- `[ ]` **D-11** — écran des gabarits PDF.
- `[ ]` **D-05** — certificat de formation (aujourd'hui `# TODO`).
- `[ ]` **D-12** — restitution de questionnaire en PDF.

### Phase 10 — rapports périodiques · ~3 j

`envoyer_le_recapitulatif_quotidien()` existe (`emailing/admin_alerts.py`) mais
est figé : une cadence, des indicateurs en dur, aucun réglage.

- `[ ]` **D-13** — préférences par destinataire, cadences cumulables.
- `[ ]` **D-14** — rapport d'inscriptions (quotidien / hebdo / mensuel).
- `[ ]` **D-15** — rapport d'activité en **compteurs** : questionnaires,
  commandes, rendez-vous, prospects, visites. Jusqu'à l'annuel.
- `[ ]` **D-16** — écran de réglage et gabarits au catalogue.

*Deux points à trancher avant d'écrire* : les cadences longues ne peuvent pas
passer par `cron_24h` seul — mémoriser la dernière période envoyée, sur le
modèle de `GoogleCalendarConfig.last_digest_sent_on`. Et il faut des compteurs
avec comparaison à la période précédente, pas des listes : sur un mois, une
liste ne dit rien.

### Phase 11 — tests · ~2 j

- `[ ]` **Q-04a** — `templatetags` : 1 459 lignes, **aucun test**, et c'est là
  que vivent `sanitize`, `css_value`, `tojson`. Le code le plus sensible du
  paquet est le moins couvert.
- `[ ]` **Q-04b** — `administration` (2 %) et `administration_menu`.

### Phase 12 — accompagnement · ~4 j · reporté

- `[ ]` **D-01** — assistant de mise en route, relançable, plus tableau de bord
  d'installation. `walkthrough.md` fait 0 octet ; c'est le manque fonctionnel le
  plus lourd pour un produit vendu à des non-techniciens.

### Phase 13 — CSP · ~3,5 j · à terme

- `[ ]` **S-03** — la CSP est en `Report-Only`, donc n'empêche rien. Son
  passage en application est bloqué par **129 `onclick=` inline dans 35
  gabarits** et 40 exports `window.*`. Sortir les `onclick` d'abord.
- `[ ]` **S-02** — Quill servi en local avec SRI (indépendant, peut être avancé).

### Phase 14 — bibliothèque de modèles · ~3 j · à terme

- `[ ]` **Q-06** — `model_source` est écrit et jamais lu. Aperçu, renommage,
  compteur d'usages, suppression avertie : E1 à E6 de `AUDIT_EDITOR.md`.

---

### Chantier d'outillage — mettre le code sous git · ~0,5 j

- `[ ]` **O-01 — dépôt git, sur GitHub** *(décidé le 21/08)*. Aujourd'hui
  `Art` et `packages` ne sont sous aucun contrôle de version : la seule
  mémoire est `packages/.sauvegardes/`, des copies datées à la main. C'est ce
  qui a permis de dater la régression A-17 — en comparant à la sauvegarde du
  17/08 — mais au prix d'un `diff -rq` sur tout l'arbre, sans savoir *pourquoi*
  une ligne avait changé.

  Trois précautions au moment de le faire :
  * `.gitignore` d'abord — `ENV/` en entier sauf `site-packages/jeiko/`, qui
    est le code ; `mediadir/`, `staticdir/`, `*.pyc`, `.DS_Store`, `.env` ;
  * **aucun secret dans l'historique** : vérifier `main/settings.py` et les
    éventuels JSON de compte de service avant le premier commit — un secret
    poussé sur GitHub est à considérer comme divulgué, même après suppression ;
  * sortir d'abord `site-packages` d'iCloud (Q-09), sans quoi les doublons
    « fichier 2.py » entreront dans le dépôt.

---

## 3. Hors plan, à connaître

- **S-16 — l'intégrité de la chaîne de mise à jour repose sur un sha256 publié
  par le même canal que le wheel.** Cela protège d'un téléchargement corrompu,
  pas d'un dépôt compromis. Une signature détachée serait la vraie réponse.
- **Q-07 — l'internationalisation est structurellement absente** : 11 marquages
  `gettext`, aucun `.po`. Ce n'est pas une dette, c'est un plafond à connaître
  avant de promettre du multilingue. Compter 5 à 8 jours.
- **Q-09 — `site-packages` est dans un dossier synchronisé iCloud**, d'où les
  doublons « fichier 2.py ». À sortir de la synchronisation.
