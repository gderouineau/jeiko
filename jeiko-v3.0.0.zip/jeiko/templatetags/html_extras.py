"""
Filtres de rendu HTML des contenus.

`html_unescape` faisait auparavant :

    mark_safe(html.unescape(value or ""))

soit exactement l'inverse d'une protection : il ré-activait du HTML qui avait
déjà été neutralisé. `&lt;script&gt;alert(1)&lt;/script&gt;` ressortait en
`<script>alert(1)</script>`, exécuté chez tous les visiteurs — administrateurs
compris, donc avec vol de session à la clé.

Le dé-échappement reste nécessaire (les contenus sont stockés échappés par
l'éditeur), mais il est désormais suivi d'un assainissement par liste blanche.
Voir jeiko/sanitize.py pour la liste des balises et attributs autorisés, et le
réglage JEIKO_SANITIZE_HTML.
"""

import html

from django import template
from django.utils.safestring import mark_safe

from jeiko.sanitize import clean_html

register = template.Library()


@register.filter
def html_unescape(value):
    """
    Restitue le HTML stocké échappé, après assainissement.

    La mise en forme est conservée ; `<script>`, les attributs `on*` et les URL
    `javascript:` sont retirés.
    """
    return mark_safe(clean_html(html.unescape(value or "")))
