// utils.js
let lastScrollTop = 0;

// Échappe une valeur destinée à être injectée en HTML (innerHTML / insertAdjacentHTML).
// À utiliser pour TOUTE donnée venant de la base ou d'une saisie utilisateur.
export function escapeHtml(value) {
    if (value === null || value === undefined) return '';
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

// getCSRF() faisait exactement la même chose que getCookie('csrftoken') : supprimée.
export function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== "") {
        const cookies = document.cookie.split(";");
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Effectue un appel fetch classique et renvoie le HTML
export async function fetchHtml(url) {
    const response = await fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    });
    if (!response.ok) throw new Error(`Erreur de chargement : ${url}`);
    return await response.text();
}

// Effectue un POST d'un formulaire (FormData ou form HTML)
export async function postForm(formElement, callback) {
    const formData = new FormData(formElement);
    const url = formElement.action;
    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: formData
    });
    const contentType = response.headers.get("content-type");
    if (response.ok) {
        if (contentType && contentType.includes("application/json")) {
            const json = await response.json();
            if (json.status === 'success') {
                callback(json);
            }
        } else {
            const html = await response.text();
            callback(html);
        }
    } else {
        console.error("Erreur dans postForm", response);
    }
}

const FOCUSABLE = [
  'a[href]', 'button:not([disabled])', 'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])', 'textarea:not([disabled])', '[tabindex]:not([tabindex="-1"])',
].join(',');

// Élément qui avait le focus avant l'ouverture, pour le lui rendre à la fermeture.
let lastFocused = null;

/**
 * Confine le clavier dans le modal : Échap ferme, Tab boucle sur les éléments focusables.
 * Sans ça, la tabulation sortait du modal et parcourait la page en arrière-plan.
 */
function onModalKeydown(e) {
  const modal = document.getElementById('editor-modal');
  if (!modal) return;

  if (e.key === 'Escape') {
    e.preventDefault();
    closeModal();
    return;
  }
  if (e.key !== 'Tab') return;

  const items = [...modal.querySelectorAll(FOCUSABLE)].filter(el => el.offsetParent !== null);
  if (!items.length) return;

  const first = items[0];
  const last = items[items.length - 1];
  if (e.shiftKey && document.activeElement === first) {
    e.preventDefault();
    last.focus();
  } else if (!e.shiftKey && document.activeElement === last) {
    e.preventDefault();
    first.focus();
  }
}

export function showModal(html, header = "") {
  lastScrollTop = window.scrollY || document.documentElement.scrollTop;
  let modal = document.getElementById("editor-modal");
  const headerMarkup =
    (typeof header === 'string' && header.trim().startsWith('<'))
      ? header // HTML brut (menu)
      : (header ? `<h3>${header}</h3>` : ''); // texte simple → <h3>

  if (!modal) {
    lastFocused = document.activeElement;

    modal = document.createElement("div");
    modal.id = "editor-modal";
    // Le fond passait par onclick="this.parentElement.remove()", ce qui court-circuitait
    // closeModal() : la position de défilement n'était jamais restaurée.
    modal.innerHTML = `
      <div class="modal-background"></div>
      <div class="modal-content" role="dialog" aria-modal="true" tabindex="-1">
        <div class="modal-header">
          ${headerMarkup}
        </div>
        <div class="modal-body">${html}</div>
      </div>
    `;
    document.body.appendChild(modal);

    modal.querySelector('.modal-background')?.addEventListener('click', closeModal);
    document.addEventListener('keydown', onModalKeydown);

    const content = modal.querySelector('.modal-content');
    (content?.querySelector(FOCUSABLE) || content)?.focus();

  } else {
    modal.querySelector('.modal-header')?.replaceChildren();
    modal.querySelector('.modal-header')?.insertAdjacentHTML('afterbegin', headerMarkup);
    modal.querySelector('.modal-body')?.replaceChildren();
    modal.querySelector('.modal-body')?.insertAdjacentHTML('afterbegin', html);
  }
}

// Petit toast temporaire en bas de l'écran
export function showToast(message) {
    const toast = document.createElement("div");
    toast.className = "toast-message";
    toast.innerText = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

export function showConfirmModal(message, onConfirm) {
    const modal = document.createElement("div");
    modal.id = "confirm-modal";
    modal.innerHTML = `
        <div class="confirm-overlay"></div>
        <div class="confirm-box">
            <div class="confirm-header">
                <h3>Confirmation</h3>
                <button class="confirm-close">&times;</button>
            </div>
            <div class="confirm-body">
                <p>${escapeHtml(message)}</p>
                <div class="confirm-actions">
                    <button class="btn-cancel">Annuler</button>
                    <button class="btn-confirm">Confirmer</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);

    const previous = document.activeElement;
    const close = () => {
        modal.remove();
        document.removeEventListener("keydown", onKey);
        if (previous && document.contains(previous)) previous.focus();
    };
    const onKey = (e) => {
        if (e.key === "Escape") { e.preventDefault(); close(); }
    };

    modal.querySelector(".confirm-close").addEventListener("click", close);
    modal.querySelector(".btn-cancel").addEventListener("click", close);
    modal.querySelector(".confirm-overlay").addEventListener("click", close);
    modal.querySelector(".btn-confirm").addEventListener("click", () => {
        close();
        onConfirm();
    });
    document.addEventListener("keydown", onKey);

    // Le bouton de confirmation prend le focus : Entrée valide, Échap annule.
    modal.querySelector(".btn-confirm").focus();
}

export function closeModal() {
  const modal = document.getElementById('editor-modal');
  if (modal) modal.remove();

  document.removeEventListener('keydown', onModalKeydown);
  window.scrollTo(0, lastScrollTop);

  // Rendre le focus à l'élément qui l'avait avant l'ouverture.
  if (lastFocused && document.contains(lastFocused)) lastFocused.focus();
  lastFocused = null;
}

