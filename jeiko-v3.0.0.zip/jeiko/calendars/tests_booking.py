# jeiko/calendars/tests_booking.py
"""
Sonde du moteur de réservation : capacité multi-participants et libération
des places à l'annulation.
"""
import json
from datetime import timedelta

from django.test import TestCase, override_settings
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.urls import reverse
from django.utils import timezone

from .models import Appointment, AppointmentType, Availability, Slot

User = get_user_model()


class BookingFixture(TestCase):
    CAPACITY = 3

    def setUp(self):
        # Les compteurs anti-abus vivent dans le cache, qui survit d'un test à
        # l'autre dans le même process : sans ça, les tests se limitent entre eux.
        cache.clear()
        self.user = User.objects.create_user(username="prov", password="pwd12345")
        self.conf = AppointmentType.objects.create(
            name="Conférence", user=self.user,
            duration=timedelta(hours=1), capacity=self.CAPACITY,
        )
        self.start = (timezone.now() + timedelta(days=3)).replace(
            minute=0, second=0, microsecond=0
        )
        self.availability = Availability.objects.create(
            user=self.user, start=self.start, end=self.start + timedelta(hours=2)
        )
        self.availability.appointment_types.add(self.conf)
        self.slot = Slot.objects.filter(
            availability=self.availability, type=self.conf
        ).order_by("start").first()

    def book(self, email, slot=None):
        return self.client.post(
            reverse("api_calendars:api_book_appointment"),
            data=json.dumps({"slot_id": (slot or self.slot).id, "email": email}),
            content_type="application/json",
        )


class MultiParticipantTests(BookingFixture):
    """Un créneau à N places doit accepter N clients, puis se fermer."""

    def test_slot_is_generated_with_type_capacity(self):
        self.assertEqual(self.slot.capacity, self.CAPACITY)
        self.assertEqual(self.slot.remaining_places, self.CAPACITY)
        self.assertTrue(self.slot.is_available)

    def test_three_clients_can_book_the_same_slot(self):
        for i in range(self.CAPACITY):
            resp = self.book(f"c{i}@example.com")
            self.assertEqual(resp.status_code, 200, resp.content)
            self.assertTrue(resp.json()["success"])

        self.slot.refresh_from_db()
        self.assertEqual(self.slot.appointments.count(), self.CAPACITY)
        self.assertEqual(self.slot.remaining_places, 0)
        self.assertFalse(self.slot.is_available)

    def test_slot_refuses_booking_when_full(self):
        for i in range(self.CAPACITY):
            self.book(f"c{i}@example.com")
        resp = self.book("late@example.com")
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(self.slot.appointments.count(), self.CAPACITY)

    def test_full_slot_disappears_from_public_api(self):
        for i in range(self.CAPACITY):
            self.book(f"c{i}@example.com")
        resp = self.client.get(reverse("api_calendars:api_availabilities"))
        ids = [row["id"] for row in resp.json()]
        self.assertNotIn(self.slot.id, ids)

    def test_partially_booked_slot_stays_visible_with_right_count(self):
        self.book("c0@example.com")
        resp = self.client.get(reverse("api_calendars:api_availabilities"))
        row = next(r for r in resp.json() if r["id"] == self.slot.id)
        self.assertEqual(row["remaining_places"], self.CAPACITY - 1)


class CancellationFreesPlaceTests(BookingFixture):
    """Une annulation doit rendre la place au créneau."""

    def test_cancel_frees_one_place_on_full_slot(self):
        for i in range(self.CAPACITY):
            self.book(f"c{i}@example.com")
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 0)

        Appointment.objects.filter(email="c0@example.com").first().cancel()

        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 1)
        self.assertTrue(self.slot.is_available)
        # `count()` compterait aussi l'annulé : la ligne est conservée.
        self.assertEqual(self.slot.appointments.active().count(), self.CAPACITY - 1)

    def test_freed_place_can_be_rebooked(self):
        for i in range(self.CAPACITY):
            self.book(f"c{i}@example.com")
        Appointment.objects.filter(email="c0@example.com").first().cancel()

        resp = self.book("newcomer@example.com")
        self.assertEqual(resp.status_code, 200, resp.content)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 0)

    def test_client_cancel_via_public_link_frees_place(self):
        self.book("c0@example.com")
        appt = Appointment.objects.get(email="c0@example.com")
        self.client.post(appt.get_public_cancel_url())

        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY)

    def test_double_cancel_cannot_inflate_places(self):
        self.book("c0@example.com")
        appt = Appointment.objects.get(email="c0@example.com")
        appt.cancel()
        appt.cancel()  # rejoue l'annulation sur un objet déjà supprimé
        self.slot.refresh_from_db()
        self.assertLessEqual(self.slot.remaining_places, self.slot.capacity)

    def test_deleting_appointment_directly_also_frees_place(self):
        """Suppression hors `cancel()` : admin Django, suppression en masse..."""
        self.book("c0@example.com")
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY - 1)

        Appointment.objects.get(email="c0@example.com").delete()

        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY)


class OverlapTests(BookingFixture):
    """Deux créneaux qui se chevauchent ne doivent pas être réservables tous les deux."""

    def setUp(self):
        super().setUp()
        # Un second type, plus court, sur la MÊME plage de disponibilité.
        self.short = AppointmentType.objects.create(
            name="Entretien court", user=self.user,
            duration=timedelta(minutes=30), capacity=1,
        )
        self.availability.appointment_types.add(self.short)
        self.short_slot = Slot.objects.filter(
            availability=self.availability, type=self.short, start=self.slot.start
        ).first()

    def test_overlapping_slot_is_closed_when_conference_is_full(self):
        for i in range(self.CAPACITY):
            self.book(f"c{i}@example.com")
        self.short_slot.refresh_from_db()
        self.assertFalse(self.short_slot.is_available)

    def test_overlapping_slot_is_closed_as_soon_as_one_place_is_taken(self):
        """Le praticien est occupé dès le 1er inscrit, même s'il reste des places."""
        self.book("c0@example.com")
        self.short_slot.refresh_from_db()
        self.assertFalse(self.short_slot.is_available)

    def test_cannot_book_overlapping_slot_after_partial_booking(self):
        self.book("c0@example.com")
        resp = self.book("intrus@example.com", slot=self.short_slot)
        self.assertEqual(resp.status_code, 400, resp.content)


class AntiSpamTests(BookingFixture):
    """Garde-fous du point d'entrée public de réservation."""

    CAPACITY = 20  # assez de places pour tester les plafonds, pas la capacité

    def test_honeypot_blocks_booking(self):
        resp = self.client.post(
            reverse("api_calendars:api_book_appointment"),
            data=json.dumps({
                "slot_id": self.slot.id,
                "email": "bot@example.com",
                "company": "Acme Corp",   # champ leurre rempli => robot
            }),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 429)
        self.assertEqual(Appointment.objects.count(), 0)

    def test_invalid_email_is_refused(self):
        for bad in ["", "   ", "pas-un-email", "a@", "@b.fr"]:
            resp = self.book(bad)
            self.assertEqual(resp.status_code, 400, bad)
        self.assertEqual(Appointment.objects.count(), 0)

    def test_email_is_normalised(self):
        self.book("  Client@Example.COM ")
        self.assertTrue(Appointment.objects.filter(email="client@example.com").exists())

    def test_ip_hourly_cap_stops_flood(self):
        booked = 0
        for i in range(12):
            if self.book(f"flood{i}@example.com").status_code == 200:
                booked += 1
        self.assertEqual(booked, 5)   # cf. DEFAULT_LIMITS["ip_bookings"]
        self.assertEqual(Appointment.objects.count(), 5)

    @override_settings(JEIKO_CALENDARS_BOOKING_LIMITS={"email_bookings_day": (2, 86400)})
    def test_same_email_cannot_book_indefinitely(self):
        self.assertEqual(self.book("recidiviste@example.com").status_code, 200)
        self.assertEqual(self.book("recidiviste@example.com").status_code, 200)
        resp = self.book("recidiviste@example.com")
        self.assertEqual(resp.status_code, 429)
        self.assertEqual(Appointment.objects.filter(email="recidiviste@example.com").count(), 2)

    def test_malformed_payload_returns_400_not_500(self):
        resp = self.client.post(
            reverse("api_calendars:api_book_appointment"),
            data="ceci n'est pas du json",
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 400)

    def test_server_error_does_not_leak_details(self):
        """Un pépin interne ne doit pas renvoyer de trace au navigateur."""
        with self.settings(USE_TZ=True):
            resp = self.client.post(
                reverse("api_calendars:api_book_appointment"),
                data=json.dumps({"slot_id": "pas-un-entier", "email": "x@example.com"}),
                content_type="application/json",
            )
        self.assertIn(resp.status_code, (400, 500))
        body = resp.json()["message"]
        self.assertNotIn("Traceback", body)
        self.assertNotIn("SELECT", body)
        self.assertNotIn("calendars_slot", body)

    def test_failed_booking_is_rolled_back(self):
        """Aucun rendez-vous fantôme ne doit subsister après un échec."""
        before = Appointment.objects.count()
        self.client.post(
            reverse("api_calendars:api_book_appointment"),
            data=json.dumps({"slot_id": 999999, "email": "x@example.com"}),
            content_type="application/json",
        )
        self.assertEqual(Appointment.objects.count(), before)


class CapacityChangeTests(BookingFixture):
    """Modifier la capacité d'un type doit se répercuter proprement."""

    def test_increasing_capacity_adds_places_to_existing_slots(self):
        self.book("c0@example.com")          # 1 réservé, 2 restantes
        self.conf.capacity = 5
        self.conf.save()
        self.availability.save()             # régénère les créneaux

        self.slot.refresh_from_db()
        self.assertEqual(self.slot.capacity, 5)
        self.assertEqual(self.slot.remaining_places, 4)  # 5 - 1 réservé
