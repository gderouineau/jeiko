# jeiko/calendars/throttling.py
"""
Garde-fous anti-abus du point d'entrée public de réservation.

⚠️ Ces compteurs vivent dans le cache Django. Avec le backend par défaut
(`LocMemCache`), ils sont **par processus** : sous gunicorn à N workers, les
limites sont de fait multipliées par N. Pour un vrai plafond, configurer un
cache partagé (Redis / Memcached / base) dans `CACHES`, ou un alias dédié
`jeiko_throttle`.
"""
import logging
import re

from django.conf import settings
from django.core.cache import caches, InvalidCacheBackendError
from django.core.exceptions import ValidationError
from django.core.validators import validate_email

logger = logging.getLogger(__name__)

# (nombre maximum, fenêtre en secondes)
DEFAULT_LIMITS = {
    "ip_attempts": (30, 3600),        # toute requête, même refusée
    "ip_bookings": (5, 3600),         # réservations effectives
    "ip_bookings_day": (10, 86400),
    "email_bookings_day": (3, 86400),
}

# Champ leurre : invisible pour l'humain, rempli par la plupart des robots.
HONEYPOT_FIELD = "company"

GENERIC_REFUSAL = (
    "Trop de réservations depuis cet appareil. Merci de réessayer plus tard "
    "ou de nous contacter directement."
)


def _cache():
    try:
        return caches["jeiko_throttle"]
    except InvalidCacheBackendError:
        return caches["default"]


def get_limits():
    limits = dict(DEFAULT_LIMITS)
    limits.update(getattr(settings, "JEIKO_CALENDARS_BOOKING_LIMITS", {}) or {})
    return limits


def get_client_ip(request):
    """
    IP de l'appelant.

    `X-Forwarded-For` n'est lu que si `JEIKO_TRUST_X_FORWARDED_FOR` est activé :
    sans reverse-proxy qui le réécrit, cet en-tête est falsifiable et rendrait
    toute limitation inopérante.
    """
    if getattr(settings, "JEIKO_TRUST_X_FORWARDED_FOR", False):
        forwarded = request.META.get("HTTP_X_FORWARDED_FOR", "")
        if forwarded:
            return forwarded.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR") or "unknown"


def _bucket_key(name, value):
    # Le cache n'accepte pas n'importe quel caractère dans une clé.
    safe = re.sub(r"[^a-zA-Z0-9_.@:-]", "_", str(value))[:120]
    return f"jeiko:cal:{name}:{safe}"


def _hit(name, value, limit, window):
    """Incrémente un compteur à fenêtre fixe. Retourne True si la limite est dépassée."""
    key = _bucket_key(name, value)
    cache = _cache()
    if cache.add(key, 1, window):
        return 1 > limit
    try:
        count = cache.incr(key)
    except ValueError:
        # La clé a expiré entre le add et le incr : on repart à 1.
        cache.set(key, 1, window)
        count = 1
    return count > limit


def _peek(name, value, limit):
    """Lit un compteur sans l'incrémenter."""
    return (_cache().get(_bucket_key(name, value)) or 0) >= limit


def clean_booking_email(raw):
    """Retourne l'e-mail normalisé, ou None s'il est invalide."""
    email = (raw or "").strip()
    if not email or len(email) > 254:
        return None
    try:
        validate_email(email)
    except ValidationError:
        return None
    return email.lower()


def check_booking_request(request, payload, email):
    """
    Contrôles anti-abus AVANT réservation.

    Retourne `None` si la requête peut poursuivre, sinon un message destiné au
    client (volontairement vague : ne pas renseigner un robot sur la règle
    qui l'a arrêté).
    """
    limits = get_limits()
    ip = get_client_ip(request)

    # 1. Leurre : un humain ne remplit jamais ce champ (masqué en CSS).
    if (payload.get(HONEYPOT_FIELD) or "").strip():
        logger.warning("Réservation rejetée (honeypot rempli) ip=%s", ip)
        return GENERIC_REFUSAL

    # 2. Volumétrie brute, pour couper le martèlement même en échec.
    if _hit("attempts", ip, *limits["ip_attempts"]):
        logger.warning("Réservation rejetée (trop de tentatives) ip=%s", ip)
        return GENERIC_REFUSAL

    # 3. Réservations effectives par IP, à l'heure et au jour.
    if _peek("book_h", ip, limits["ip_bookings"][0]) or \
       _peek("book_d", ip, limits["ip_bookings_day"][0]):
        logger.warning("Réservation rejetée (plafond IP atteint) ip=%s", ip)
        return GENERIC_REFUSAL

    # 4. Réservations par adresse e-mail.
    if email and _peek("book_mail", email, limits["email_bookings_day"][0]):
        logger.warning("Réservation rejetée (plafond e-mail atteint) email=%s", email)
        return (
            "Plusieurs rendez-vous ont déjà été réservés avec cette adresse "
            "aujourd'hui. Contactez-nous si vous en avez besoin d'un autre."
        )

    return None


def record_booking(request, email):
    """Comptabilise une réservation réussie (appelé après création du RDV)."""
    limits = get_limits()
    ip = get_client_ip(request)
    _hit("book_h", ip, *limits["ip_bookings"])
    _hit("book_d", ip, *limits["ip_bookings_day"])
    if email:
        _hit("book_mail", email, *limits["email_bookings_day"])
