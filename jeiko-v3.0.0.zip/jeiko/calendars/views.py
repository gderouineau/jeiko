from django.views import View
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
import datetime
from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied
from django.shortcuts import render, redirect, get_object_or_404
from .forms import GoogleCalendarConfigForm, AvailabilityForm, AppointmentTypeForm, AppointmentFormAdmin
from .models import GoogleCalendarConfig, Availability, AppointmentType, Appointment, Slot
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin, PermissionRequiredMixin
from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache
from django.utils import timezone
from django.http import JsonResponse
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from datetime import timedelta
from django.views.decorators.csrf import csrf_exempt
import json
from django.db import transaction
from django.db.models import Count, Q
import logging
from .google_api import upsert_event
from .emailing import send_booking_emails
from .mixins import CalendarOwnerQuerysetMixin, get_target_user, is_calendar_supervisor
from .throttling import check_booking_request, clean_booking_email, record_booking

logger = logging.getLogger(__name__)


class SlotUnavailable(Exception):
    """Le créneau demandé n'est plus réservable (message destiné au client)."""


@method_decorator(never_cache, name='dispatch')
class GoogleCalendarConfigListAllView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    """
    Supervision de TOUS les calendriers du site (super-administrateur uniquement).

    Sert de point d'entrée pour ouvrir la configuration d'un gestionnaire donné.
    """
    model = GoogleCalendarConfig
    template_name = "calendars/config_list_all.html"
    context_object_name = "configs"
    raise_exception = True

    def test_func(self):
        return is_calendar_supervisor(self.request.user)

    def get_queryset(self):
        now = timezone.now()
        return (
            GoogleCalendarConfig.objects
            .select_related('user')
            .annotate(
                nb_types=Count('user__appointment_types', distinct=True),
                nb_availabilities=Count('user__availabilities', distinct=True),
                nb_upcoming=Count(
                    'user__appointment_types__appointment',
                    filter=Q(user__appointment_types__appointment__start__gte=now)
                    & ~Q(user__appointment_types__appointment__status=Appointment.Status.CANCELLED),
                    distinct=True,
                ),
            )
            .order_by('user__username', 'name')
        )

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        User = get_user_model()
        # Gestionnaires qui ont des types de RDV mais aucune config Google :
        # ils travaillent sans synchronisation, autant le voir d'un coup d'œil.
        ctx["users_without_config"] = (
            User.objects
            .filter(appointment_types__isnull=False, google_calendar_config__isnull=True)
            .distinct()
            .order_by("username")
        )
        # Objets antérieurs à la migration 0007 (champ `user` ajouté après coup) :
        # sans propriétaire, ils n'appartiennent à aucun calendrier et ne sont donc
        # visibles que d'ici. Il faut les rattacher ou les supprimer.
        ctx["orphan_types"] = AppointmentType.objects.filter(user__isnull=True)
        ctx["orphan_availabilities"] = Availability.objects.filter(user__isnull=True)
        ctx["orphan_configs"] = GoogleCalendarConfig.objects.filter(user__isnull=True)
        ctx["has_orphans"] = any([
            ctx["orphan_types"].exists(),
            ctx["orphan_availabilities"].exists(),
            ctx["orphan_configs"].exists(),
        ])
        return ctx


@method_decorator(never_cache, name='dispatch')
class GoogleCalendarConfigView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Configuration Google d'UN calendrier.

    Sans `user_id` : le calendrier de l'utilisateur connecté.
    Avec `user_id`  : celui d'un autre gestionnaire — réservé au superviseur
    (cf. `get_target_user`, qui lève PermissionDenied sinon).
    """

    permission_required = 'calendars.view_googlecalendarconfig'
    raise_exception = True

    def _get_config(self, request, user_id=None):
        target = get_target_user(request, user_id)
        config, _ = GoogleCalendarConfig.objects.get_or_create(
            user=target, defaults={"name": "Primary"}
        )
        return target, config

    def _context(self, request, form, config, target):
        return {
            "form": form,
            "config": config,
            "target_user": target,
            "is_own_calendar": target == request.user,
            "is_calendar_supervisor": is_calendar_supervisor(request.user),
        }

    def get(self, request, user_id=None):
        target, config = self._get_config(request, user_id)
        form = GoogleCalendarConfigForm(instance=config)
        return render(request, "calendars/admin_config.html",
                      self._context(request, form, config, target))

    def post(self, request, user_id=None):
        target, config = self._get_config(request, user_id)
        if not request.user.has_perm('calendars.change_googlecalendarconfig'):
            raise PermissionDenied("Vous n'avez pas le droit de modifier cette configuration.")
        form = GoogleCalendarConfigForm(request.POST, instance=config)
        if form.is_valid():
            form.save()
            messages.success(request, "Configuration Google Calendar enregistrée avec succès !")
            if target != request.user:
                return redirect("jeiko_administration_calendars:google_config_user", user_id=target.pk)
            return redirect("jeiko_administration_calendars:google_config")
        return render(request, "calendars/admin_config.html",
                      self._context(request, form, config, target))


@method_decorator(never_cache, name='dispatch')
class GoogleCalendarAdminListView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """Aperçu des événements Google d'un calendrier (le sien, ou celui d'un
    gestionnaire pour le superviseur)."""

    permission_required = 'calendars.view_googlecalendarconfig'
    raise_exception = True

    def get(self, request, user_id=None):
        target = get_target_user(request, user_id)
        config = GoogleCalendarConfig.objects.filter(user=target).first()
        events = []
        error = None

        if config and config.credentials_json:
            try:
                creds = Credentials.from_service_account_info(config.credentials_json)
                service = build('calendar', 'v3', credentials=creds)
                now = datetime.datetime.utcnow().isoformat() + 'Z'
                result = service.events().list(
                    calendarId=config.calendar_id,
                    timeMin=(datetime.datetime.utcnow() - datetime.timedelta(days=90)).isoformat() + 'Z',
                    maxResults=20,
                    singleEvents=True,
                    orderBy='startTime'
                ).execute()
                events = result.get('items', [])
            except Exception as e:
                error = f"Erreur lors de la récupération des événements : {e}"

        context = {
            "events": events,
            "error": error,
            "target_user": target,
            "is_own_calendar": target == request.user,
            "is_calendar_supervisor": is_calendar_supervisor(request.user),
        }
        return render(request, "calendars/calendar_list.html", context)


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeListView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                              PermissionRequiredMixin, ListView):
    model = AppointmentType
    template_name = "calendars/appointmenttype_list.html"
    context_object_name = "types"
    owner_lookup = "user"

    permission_required = 'calendars.view_appointmenttype'
    raise_exception = True

    def get_queryset(self):
        return super().get_queryset().select_related("user")


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = AppointmentType
    form_class = AppointmentTypeForm
    template_name = "calendars/appointmenttype_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointmenttype_list")

    permission_required = 'calendars.add_appointmenttype'
    raise_exception = True

    def form_valid(self, form):
        form.instance.user = self.request.user
        resp = super().form_valid(form)
        messages.success(self.request, "Type de rendez-vous créé avec succès.")
        return resp


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeUpdateView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                                PermissionRequiredMixin, UpdateView):
    model = AppointmentType
    form_class = AppointmentTypeForm
    template_name = "calendars/appointmenttype_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointmenttype_list")
    owner_lookup = "user"

    permission_required = 'calendars.change_appointmenttype'
    raise_exception = True

    def form_valid(self, form):
        resp = super().form_valid(form)
        messages.success(self.request, "Type de rendez-vous mis à jour avec succès.")
        return resp


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeDeleteView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                                PermissionRequiredMixin, DeleteView):
    model = AppointmentType
    template_name = "calendars/appointmenttype_confirm_delete.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointmenttype_list")
    owner_lookup = "user"

    permission_required = 'calendars.delete_appointmenttype'
    raise_exception = True

    # NB : depuis Django 4.1, DeleteView.post() passe par form_valid() —
    # surcharger delete() n'a plus aucun effet.
    def form_valid(self, form):
        messages.success(self.request, "Type de rendez-vous supprimé avec succès.")
        return super().form_valid(form)


@method_decorator(never_cache, name='dispatch')
class AvailabilityListView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                           PermissionRequiredMixin, ListView):
    model = Availability
    template_name = "calendars/availability_list.html"
    context_object_name = "availabilities"
    owner_lookup = "user"

    permission_required = 'calendars.view_availability'
    raise_exception = True

    def get_queryset(self):
        return super().get_queryset().select_related("user").prefetch_related("appointment_types")


@method_decorator(never_cache, name='dispatch')
class AvailabilityCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Availability
    form_class = AvailabilityForm
    template_name = "calendars/availability_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")

    permission_required = 'calendars.add_availability'
    raise_exception = True

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def form_valid(self, form):
        form.instance.user = self.request.user
        # super() enregistre l'objet PUIS les M2M (save_m2m) : les types sont
        # donc déjà rattachés quand on régénère les créneaux ci-dessous.
        resp = super().form_valid(form)
        self.object.generate_slots()
        messages.success(self.request, "Disponibilité créée et créneaux générés.")
        return resp

@method_decorator(never_cache, name='dispatch')
class AvailabilityUpdateView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                             PermissionRequiredMixin, UpdateView):
    model = Availability
    form_class = AvailabilityForm
    template_name = "calendars/availability_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")
    owner_lookup = "user"

    permission_required = 'calendars.change_availability'
    raise_exception = True

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        # Les types proposés restent ceux du PROPRIÉTAIRE de la disponibilité,
        # même quand c'est le superviseur qui édite.
        kwargs['user'] = self.object.user
        return kwargs

    def form_valid(self, form):
        resp = super().form_valid(form)
        self.object.generate_slots()
        messages.success(self.request, "Disponibilité mise à jour et créneaux régénérés.")
        return resp


@method_decorator(never_cache, name='dispatch')
class AvailabilityDeleteView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                             PermissionRequiredMixin, DeleteView):
    model = Availability
    template_name = "calendars/availability_confirm_delete.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")
    owner_lookup = "user"

    permission_required = 'calendars.delete_availability'
    raise_exception = True

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        # Avertissement : supprimer une dispo casse en cascade ses créneaux,
        # et donc les rendez-vous déjà réservés dessus.
        ctx["booked_appointments"] = (
            Appointment.objects.active()
            .filter(slot__availability=self.object, start__gte=timezone.now())
            .select_related("type")
            .order_by("start")
        )
        return ctx


@method_decorator(never_cache, name='dispatch')
class AppointmentAdminCancelView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Annulation d'un rendez-vous par le gestionnaire du calendrier.

    L'accès public par `pk` a été supprimé : il permettait à n'importe qui
    d'annuler n'importe quel rendez-vous (cf. AppointmentPublicCancelView).
    """
    template_name = "calendars/appointment_cancel_confirm.html"

    permission_required = 'calendars.delete_appointment'
    raise_exception = True

    def get_queryset(self):
        qs = Appointment.objects.select_related("type", "slot")
        if is_calendar_supervisor(self.request.user):
            return qs
        return qs.filter(type__user=self.request.user)

    def get(self, request, pk):
        appt = get_object_or_404(self.get_queryset(), pk=pk)
        return render(request, self.template_name, {"appointment": appt, "is_admin": True})

    def post(self, request, pk):
        appt = get_object_or_404(self.get_queryset(), pk=pk)
        appt.cancel(
            by=Appointment.CancelledBy.MANAGER,
            reason=(request.POST.get("reason") or "").strip(),
        )
        messages.success(request, "Le rendez-vous a bien été annulé.")
        return redirect("jeiko_administration_calendars:appointment_list_upcoming")


@method_decorator(never_cache, name='dispatch')
class AppointmentAttendanceView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Marque un rendez-vous passé comme honoré ou comme absence (no-show).
    """
    permission_required = 'calendars.change_appointment'
    raise_exception = True

    def post(self, request, pk):
        qs = Appointment.objects.select_related("type", "slot")
        if not is_calendar_supervisor(request.user):
            qs = qs.filter(type__user=request.user)
        appt = get_object_or_404(qs, pk=pk)

        attendance = request.POST.get("attendance")
        if attendance not in ("honoured", "no_show"):
            messages.error(request, "Statut de présence inconnu.")
        elif not appt.mark_attendance(honoured=attendance == "honoured"):
            messages.error(request, "Ce rendez-vous est annulé : sa présence ne se marque pas.")
        else:
            messages.success(request, f"Rendez-vous marqué « {appt.get_status_display()} ».")

        return redirect(
            request.POST.get("next")
            or "jeiko_administration_calendars:appointment_list_past"
        )


@method_decorator(never_cache, name='dispatch')
class AppointmentPublicCancelView(View):
    """
    Annulation par le CLIENT, via le jeton non devinable reçu par e-mail.

    Le rendez-vous n'est jamais adressé par son `pk` : `public_token` est un
    UUID4, non énumérable. Un jeton inconnu renvoie 404, sans distinguer
    « n'existe pas » de « déjà annulé ».
    """
    template_name = "calendars/appointment_cancel_confirm.html"

    def get_appointment(self, token):
        return get_object_or_404(
            Appointment.objects.select_related("type", "slot"), public_token=token
        )

    def get(self, request, token):
        appt = self.get_appointment(token)
        return render(request, self.template_name, {
            "appointment": appt,
            "is_admin": False,
            "cancellable": appt.is_cancellable_by_client(),
        })

    def post(self, request, token):
        appt = self.get_appointment(token)
        if not appt.is_cancellable_by_client():
            return render(request, self.template_name, {
                "appointment": appt,
                "is_admin": False,
                "cancellable": False,
                "error": (
                    "Ce rendez-vous a déjà été annulé."
                    if appt.is_cancelled
                    else "Ce rendez-vous est passé : il ne peut plus être annulé en ligne."
                ),
            })
        appt.cancel(by=Appointment.CancelledBy.CLIENT)
        return render(request, "calendars/appointment_cancel_done.html")


@method_decorator(never_cache, name='dispatch')
class AppointmentUpcomingListView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                                  PermissionRequiredMixin, ListView):
    model = Appointment
    template_name = "calendars/appointment/list.html"
    context_object_name = "appointments"
    paginate_by = 50
    owner_lookup = "type__user"

    permission_required = 'calendars.view_appointment'
    raise_exception = True

    def get_queryset(self):
        qs = super().get_queryset().select_related("type", "type__user", "slot")
        today = timezone.localdate()
        # Inclut tous les RDV dont la date de début est >= aujourd’hui (0h00).
        # Les annulés sortent de l'agenda : ils restent consultables dans l'historique.
        return qs.active().filter(start__date__gte=today).order_by("start")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["now"] = timezone.now()
        ctx["today"] = timezone.localdate()
        ctx["scope"] = "upcoming"
        return ctx


@method_decorator(never_cache, name='dispatch')
class AppointmentPastListView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                              PermissionRequiredMixin, ListView):
    model = Appointment
    template_name = "calendars/appointment/list.html"
    context_object_name = "appointments"
    paginate_by = 50
    owner_lookup = "type__user"

    permission_required = 'calendars.view_appointment'
    raise_exception = True

    def get_queryset(self):
        qs = super().get_queryset().select_related("type", "type__user", "slot")
        today = timezone.localdate()
        # Tous les RDV avant aujourd’hui
        return qs.filter(start__date__lt=today).order_by("-start")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["now"] = timezone.now()
        ctx["today"] = timezone.localdate()
        ctx["scope"] = "past"
        return ctx


@method_decorator(never_cache, name='dispatch')
class AppointmentDetailView(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "calendars/appointment/detail.html"

    permission_required = 'calendars.view_appointment'
    raise_exception = True

    def get(self, request, pk):
        qs = Appointment.objects.select_related("type", "type__user", "slot")
        if not is_calendar_supervisor(request.user):
            qs = qs.filter(type__user=request.user)
        appt = get_object_or_404(qs, pk=pk)
        return render(request, self.template_name, {
            "appointment": appt,
            "is_calendar_supervisor": is_calendar_supervisor(request.user),
        })


@method_decorator(never_cache, name='dispatch')
class AppointmentUpdateView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                            PermissionRequiredMixin, UpdateView):
    model = Appointment
    form_class = AppointmentFormAdmin
    template_name = "calendars/appointment/form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointment_list_upcoming")
    owner_lookup = "type__user"

    permission_required = 'calendars.change_appointment'
    raise_exception = True

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        # Restreint types & créneaux sélectionnables au calendrier du
        # propriétaire du RDV : sans ça, un POST forgé rattache le rendez-vous
        # au créneau d'un autre gestionnaire.
        kwargs['owner'] = self.object.owner
        return kwargs

    @transaction.atomic
    def form_valid(self, form):
        old = self.get_object()
        old_slot = old.slot

        resp = super().form_valid(form)  # self.object est mis à jour

        # Gestion de la capacité si on change de slot
        new_slot = self.object.slot
        if old_slot and new_slot and old_slot.id != new_slot.id:
            # On libère l'ancien slot
            old_slot.remaining_places += 1
            if old_slot.remaining_places > 0:
                old_slot.is_available = True
            old_slot.save(update_fields=["remaining_places", "is_available"])
            old_slot.availability.update_slots_availability()

            # On occupe le nouveau slot (si dispo)
            # (Dans un vrai flux, tu peux vérifier la dispo ici aussi)
            new_slot.remaining_places = max(0, new_slot.remaining_places - 1)
            if new_slot.remaining_places <= 0:
                new_slot.is_available = False
            new_slot.save(update_fields=["remaining_places", "is_available"])
            new_slot.availability.update_slots_availability()

        messages.success(self.request, "Rendez-vous mis à jour.")
        return resp




@method_decorator(csrf_exempt, name='dispatch')
class APIBookAppointmentView(View):
    """
    Réservation publique (sans compte).

    Point d'entrée ouvert : il est protégé par des garde-fous anti-abus
    (leurre, plafonds par IP et par e-mail) et ne renvoie jamais de détail
    technique au client.
    """

    def post(self, request):
        try:
            payload = json.loads(request.body or b"{}")
            if not isinstance(payload, dict):
                raise ValueError("payload")
        except Exception:
            return JsonResponse(
                {'success': False, 'message': "Requête invalide."}, status=400
            )

        email = clean_booking_email(payload.get('email'))
        if not email:
            return JsonResponse(
                {'success': False, 'message': "Merci de saisir une adresse e-mail valide."},
                status=400,
            )

        refusal = check_booking_request(request, payload, email)
        if refusal:
            return JsonResponse({'success': False, 'message': refusal}, status=429)

        try:
            appt = self._book(
                payload.get('slot_id'),
                email,
                client_name=(payload.get('name') or "").strip()[:150],
                places=payload.get('places', 1),
            )
        except SlotUnavailable as exc:
            return JsonResponse({'success': False, 'message': str(exc)}, status=400)
        except Exception:
            # Aucun détail technique vers le client : il finirait dans une
            # console de navigateur, voire indexé.
            logger.exception("Échec de réservation (slot_id=%r)", payload.get('slot_id'))
            return JsonResponse(
                {'success': False, 'message': "Une erreur est survenue, merci de réessayer."},
                status=500,
            )

        record_booking(request, email)
        return JsonResponse({'success': True, 'message': "Rendez-vous réservé avec succès !"})

    @staticmethod
    def _clean_places(raw, slot):
        """
        Valide le nombre de places demandé.

        Deux plafonds : celui fixé par le gestionnaire sur le type de rendez-vous
        (`max_places_per_booking`), et ce qu'il reste réellement sur le créneau.
        """
        try:
            places = int(raw)
        except (TypeError, ValueError):
            raise SlotUnavailable("Nombre de places invalide.")

        if places < 1:
            raise SlotUnavailable("Nombre de places invalide.")

        maximum = max(1, slot.type.max_places_per_booking)
        if places > maximum:
            raise SlotUnavailable(
                f"Vous ne pouvez réserver que {maximum} place"
                f"{'s' if maximum > 1 else ''} au maximum pour ce rendez-vous."
            )
        if places > slot.remaining_places:
            raise SlotUnavailable(
                f"Il ne reste que {slot.remaining_places} place"
                f"{'s' if slot.remaining_places > 1 else ''} sur ce créneau."
            )
        return places

    @transaction.atomic
    def _book(self, slot_id, email, client_name="", places=1):
        """
        Réserve une ou plusieurs places. La transaction couvre uniquement cette
        méthode : toute exception remonte et provoque bien un rollback —
        auparavant le `except` interne validait un état partiel.
        """
        slot = Slot.objects.select_related("type").select_for_update().filter(
            id=slot_id,
            is_available=True,
            remaining_places__gt=0,
            start__gte=timezone.now()
        ).first()
        if not slot:
            raise SlotUnavailable("Créneau non disponible ou déjà réservé.")

        places = self._clean_places(places, slot)

        appt = Appointment.objects.create(
            type=slot.type,
            slot=slot,
            start=slot.start,
            end=slot.end,
            email=email,
            client_name=client_name,
            places=places,
        )

        # Recompte depuis les rendez-vous réels (idempotent), puis referme les
        # créneaux qui chevauchent : le gestionnaire est désormais occupé.
        slot.sync_remaining_places()
        slot.availability.update_slots_availability()

        # La synchronisation Google est portée par le signal post_save de
        # Appointment. L'envoi des e-mails est déclenché après commit.
        def send_emails(appt_id):
            try:
                a = Appointment.objects.select_related("type").get(pk=appt_id)
                send_booking_emails(a)
            except Exception as e:
                logger.exception("send_emails failed for appt=%s: %s", appt_id, e)

        transaction.on_commit(lambda appt_id=appt.id: send_emails(appt_id))
        return appt


@method_decorator(never_cache, name="dispatch")
class APIAvailabilitiesView(View):
    def get(self, request):
        appointment_type_id = request.GET.get("type")
        provider_id = request.GET.get("provider")

        slots = Slot.objects.filter(
            is_available=True,
            start__gte=timezone.now(),
            remaining_places__gt=0,
        )
        if appointment_type_id:
            slots = slots.filter(type_id=appointment_type_id)
        
        if provider_id:
            slots = slots.filter(availability__user_id=provider_id)

        data = []
        for slot in slots.select_related("type").order_by('start'):
            display = f"{slot.start.strftime('%A %d %B à %Hh%M')} ({int((slot.end-slot.start).total_seconds()//60)} min)"
            data.append({
                "id": slot.id,
                "availability_id": slot.availability_id,
                "start": slot.start.isoformat(),
                "end": slot.end.isoformat(),
                "display": display,
                "type": slot.type.name,
                "slot_minutes": int((slot.end-slot.start).total_seconds()//60),
                "remaining_places": slot.remaining_places,
                "type_color": slot.type.color,
                # Plafond de places par réservation, borné par ce qu'il reste :
                # le front n'a plus qu'à proposer 1..max_places.
                "max_places": min(
                    max(1, slot.type.max_places_per_booking), slot.remaining_places
                ),
            })
        return JsonResponse(data, safe=False)
