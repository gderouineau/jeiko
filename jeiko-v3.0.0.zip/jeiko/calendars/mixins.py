# jeiko/calendars/mixins.py
"""
Contrôle d'accès du module calendars.

Règle générale : chaque gestionnaire ne voit et ne modifie QUE son propre
calendrier (ses types de rendez-vous, ses disponibilités, ses rendez-vous).
Seul le super-administrateur supervise l'ensemble des calendriers du site.
"""

from django.core.exceptions import PermissionDenied


def is_calendar_supervisor(user) -> bool:
    """
    Vrai si l'utilisateur supervise TOUS les calendriers.

    Volontairement limité à `is_superuser` : `is_staff` signifie seulement
    « peut ouvrir l'admin Django » et est souvent accordé largement, ce qui
    donnerait accès aux configurations Google et aux clients des autres
    gestionnaires.
    """
    return bool(user and user.is_authenticated and user.is_superuser)


def get_target_user(request, user_id=None):
    """
    Détermine le gestionnaire dont on manipule le calendrier.

    - sans `user_id` : l'utilisateur connecté ;
    - avec `user_id`  : cet utilisateur, réservé au superviseur.
    """
    if user_id is None or str(user_id) == str(request.user.pk):
        return request.user
    if not is_calendar_supervisor(request.user):
        raise PermissionDenied("Vous ne pouvez gérer que votre propre calendrier.")
    from django.contrib.auth import get_user_model
    from django.shortcuts import get_object_or_404
    return get_object_or_404(get_user_model(), pk=user_id)


class CalendarOwnerQuerysetMixin:
    """
    Restreint le queryset d'une vue aux objets appartenant à `request.user`.

    `owner_lookup` est le chemin ORM menant au propriétaire depuis le modèle
    de la vue ('user', 'type__user', ...). Le superviseur n'est pas filtré.

    À placer AVANT la vue générique dans les bases pour que `get_queryset`
    s'applique aussi bien aux listes qu'aux vues de détail/édition/suppression
    (`SingleObjectMixin.get_object` passe par `get_queryset`).
    """

    owner_lookup = "user"

    def is_calendar_supervisor(self):
        return is_calendar_supervisor(self.request.user)

    def get_queryset(self):
        qs = super().get_queryset()
        if self.is_calendar_supervisor():
            return qs
        return qs.filter(**{self.owner_lookup: self.request.user})

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["is_calendar_supervisor"] = self.is_calendar_supervisor()
        return ctx
