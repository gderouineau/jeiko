# jeiko/calendars/models.py

import uuid

from django.db import models, transaction
from django.contrib.auth import get_user_model
from django.urls import reverse
from django.utils import timezone
from datetime import timedelta, datetime, time
from dateutil.rrule import rrulestr

import logging
logger = logging.getLogger(__name__)

WEEKDAY_TOKENS = ["MO","TU","WE","TH","FR","SA","SU"]


class GoogleCalendarConfig(models.Model):
    name = models.CharField(
        max_length=100,
        default="Primary"
    )
    user = models.OneToOneField(
        get_user_model(),
        on_delete=models.CASCADE,
        related_name='google_calendar_config',
        null=True,  # Temporary for migration
        blank=True
    )
    credentials_json = models.JSONField(
        help_text="Copier-coller ici le JSON de credentials Google",
        default=dict,
    )
    updated_at = models.DateTimeField(
        auto_now=True
    )

    calendar_id = models.CharField(

        max_length=300,
        default="",
        null=True,
        blank=True,
    )

    def __str__(self):
        return f"{self.user} -> {self.name}"


class AppointmentType(models.Model):
    name = models.CharField(
        "Nom du type",
        max_length=50
    )
    user = models.ForeignKey(
        get_user_model(),
        on_delete=models.CASCADE,
        related_name='appointment_types',
        null=True,  # Temporary for migration
        blank=True
    )
    duration = models.DurationField(
        "Durée",
    )
    is_paid = models.BooleanField(
        "Payant",
        default=False
    )
    is_registration_required = models.BooleanField(
        "Réservation uniquement pour inscrits",
        default=False,
    )
    color = models.CharField(
        "Couleur",
        max_length=7,
        default="#2ecc40",
    )
    font = models.CharField(
        "Police",
        max_length=50,
        default="Inter"
    )
    description = models.TextField(
        "Description",
        blank=True
    )
    capacity = models.PositiveIntegerField(
        default=1,
        verbose_name="Nombre de places par créneau"
    )
    max_places_per_booking = models.PositiveIntegerField(
        default=1,
        verbose_name="Places maximum par réservation",
        help_text=(
            "Nombre de places qu'un même client peut réserver d'un coup "
            "(1 = une place par réservation). Ne peut pas dépasser le nombre "
            "de places du créneau."
        ),
    )

    def clean(self):
        super().clean()
        from django.core.exceptions import ValidationError
        if self.max_places_per_booking and self.capacity and \
                self.max_places_per_booking > self.capacity:
            raise ValidationError({
                "max_places_per_booking": (
                    "Un client ne peut pas réserver plus de places que n'en "
                    f"compte le créneau ({self.capacity})."
                )
            })

    @property
    def allows_multiple_places(self):
        return self.max_places_per_booking > 1

    def __str__(self):
        return self.name


class Availability(models.Model):
    appointment_types = models.ManyToManyField(
        AppointmentType,
        related_name='availabilities',
        verbose_name="Types de rendez-vous possibles"
    )
    user = models.ForeignKey(
        get_user_model(),
        on_delete=models.CASCADE,
        related_name='availabilities',
        null=True,  # Temporary for migration
        blank=True
    )
    start = models.DateTimeField(
        "Début de disponibilité",
    )
    end = models.DateTimeField(
        "Fin de disponibilité",
    )
    recurring_rule = models.TextField(
        "Règle de récurrence iCal (optionnel)",
        blank=True,
        help_text="Inclut éventuellement DTSTART, RRULE, EXDATE (une par ligne)."
    )
    is_available = models.BooleanField(
        "Disponible",
        default=True,
    )
    recurrence_exdates = models.JSONField(
        default=list, blank=True,
        help_text="Liste de dates à exclure, au format YYYY-MM-DD."
    )

    google_event_id = models.CharField(
        max_length=128,
        null=True,
        blank=True,
        db_index=True
    )

    def __str__(self):
        types = ", ".join([str(t) for t in self.appointment_types.all()])
        return f"{types}: {self.start} - {self.end}"


    def update_slots_availability(self):
        """
        Recalcule la disponibilité des créneaux du gestionnaire sur cette fenêtre.

        Règle : dès qu'UNE place est prise sur un créneau, le gestionnaire est
        occupé sur cette tranche horaire — tous les créneaux qui la chevauchent
        se ferment. Le créneau entamé, lui, reste ouvert tant qu'il lui reste
        des places (cas des rendez-vous collectifs / conférences).

        Le calcul porte sur TOUS les créneaux du même gestionnaire sur la
        fenêtre, pas seulement ceux de cette disponibilité : deux plages qui se
        chevauchent ne doivent pas se réserver l'une l'autre.
        """
        own_slots = list(self.slots.all())
        if not own_slots:
            return

        window_start = min(s.start for s in own_slots)
        window_end = max(s.end for s in own_slots)

        if self.user_id:
            slots = list(
                Slot.objects.filter(
                    availability__user_id=self.user_id,
                    start__lt=window_end,
                    end__gt=window_start,
                )
            )
        else:
            # Disponibilité orpheline (antérieure à l'attribution des
            # calendriers) : on ne la compare qu'à elle-même.
            slots = own_slots

        booked = [s for s in slots if s.remaining_places < s.capacity]

        to_update = []
        for slot in slots:
            busy_elsewhere = any(
                b.pk != slot.pk and b.start < slot.end and b.end > slot.start
                for b in booked
            )
            available = (not busy_elsewhere) and slot.remaining_places > 0
            if slot.is_available != available:
                slot.is_available = available
                to_update.append(slot)

        if to_update:
            # bulk_update : ne repasse pas par Slot.save(), donc pas de récursion.
            Slot.objects.bulk_update(to_update, ["is_available"])

    def _duration(self):
        return self.end - self.start

    def _as_rruleset(self):
        """
        Construit un rruleset (ou rrule) à partir de recurring_rule + DTSTART.
        Supporte RRULE/EXDATE multiples (forceset=True).
        """
        rule_str = (self.recurring_rule or "").strip()
        if not rule_str:
            return None
        # IMPORTANT: on fournit dtstart=self.start pour aligner la 1re occurrence
        return rrulestr(rule_str, forceset=True, dtstart=self.start)

    def iter_occurrences(self, start_from=None, until=None):
        """
        Génère les fenêtres (start,end) d’Availability pour chaque occurrence.
        - Si pas de récurrence: une seule fenêtre self.start/self.end.
        - Sinon: on expanse via rruleset().between().
        """
        dur = self._duration()
        if not (self.recurring_rule or "").strip():
            yield (self.start, self.end)
            return

        rs = self._as_rruleset()
        if not rs:
            yield (self.start, self.end)
            return

        if start_from is None:
            start_from = self.start

        if until is None:
            # horizon par défaut : 90 jours
            until = timezone.now() + timedelta(days=90)

        for occ_start in rs.between(start_from, until, inc=True):
            occ_end = occ_start + dur
            # Si tu as JSONField recurrence_exdates ET que tu préfères un double filet de sécurité:
            exdates = getattr(self, 'recurrence_exdates', []) or []
            if exdates:
                # compare la date uniquement
                if occ_start.date().isoformat() in exdates:
                    continue
            yield (occ_start, occ_end)


    def generate_slots(self, horizon_days=90):
        """
        Génère tous les slots pour CHAQUE occurrence (quotidienne/hebdomadaire),
        pour TOUS les types associés (durées différentes OK),
        puis met à jour les conflits et nettoie les slots hors plage.
        """
        types = list(self.appointment_types.all())
        if not types:
            return

        type_ids = {t.id for t in types}
        horizon_end = timezone.now() + timedelta(days=horizon_days)
        windows = list(self.iter_occurrences(until=horizon_end))

        # Si aucune occurrence dans l'horizon -> on nettoie simplement
        if not windows:
            to_delete = []
            to_update = []
            for slot in self.slots.all():
                if slot.remaining_places == slot.capacity:
                    to_delete.append(slot.id)
                elif slot.is_available:
                    slot.is_available = False
                    to_update.append(slot)
            if to_delete:
                self.slots.filter(id__in=to_delete).delete()
            if to_update:
                Slot.objects.bulk_update(to_update, ["is_available"])
            return

        # Index des slots existants, avec le nombre de places réellement prises
        from django.db.models import Q as _Q, Sum
        existing_qs = self.slots.select_related("type").annotate(
            _booked=Sum(
                "appointments__places",
                filter=~_Q(appointments__status=Appointment.Status.CANCELLED),
            )
        )
        existing = {(s.start, s.end, s.type_id): s for s in existing_qs}

        to_create = []
        to_update = []

        def in_any_window(s, e):
            for ws, we in windows:
                if ws <= s and e <= we and e > s:
                    return True
            return False

        # Tessellation des fenêtres en pas = duration de chaque type
        for appt_type in types:
            step = appt_type.duration
            capacity = appt_type.capacity
            for ws, we in windows:
                cur = ws
                while cur + step <= we:
                    se = cur + step
                    key = (cur, se, appt_type.id)
                    slot = existing.get(key)
                    if slot is None:
                        to_create.append(Slot(
                            availability=self,
                            type=appt_type,
                            start=cur,
                            end=se,
                            capacity=capacity,
                            remaining_places=capacity,
                            is_available=True,
                        ))
                    else:
                        changed = False
                        # Capacité modifiée sur le type : on réaligne les places
                        # restantes sur les réservations réelles, sinon augmenter
                        # la capacité n'ouvrirait aucune place supplémentaire.
                        if slot.capacity != capacity:
                            booked = getattr(slot, "_booked", 0) or 0
                            slot.capacity = capacity
                            slot.remaining_places = max(0, capacity - booked)
                            changed = True
                        # Si non complet et désactivé → réactive
                        # (update_slots_availability refermera si conflit)
                        if slot.remaining_places > 0 and not slot.is_available:
                            slot.is_available = True
                            changed = True
                        if changed:
                            to_update.append(slot)
                    cur = se

        if to_create:
            Slot.objects.bulk_create(to_create)
        if to_update:
            Slot.objects.bulk_update(to_update, ["capacity", "remaining_places", "is_available"])

        # 1) Mise à jour de la dispo vs RDV pris (chevauchements avec slots complets)
        self.update_slots_availability()

        # 2) Nettoyage: tout slot qui ne tombe plus dans une fenêtre active ou dont le type a été retiré
        type_ids_set = type_ids  # alias lisible
        to_delete = []
        to_deactivate = []
        for slot in self.slots.all():
            if not in_any_window(slot.start, slot.end) or (slot.type_id not in type_ids_set):
                if slot.remaining_places == slot.capacity:
                    to_delete.append(slot.id)
                else:
                    if slot.is_available:
                        slot.is_available = False
                        to_deactivate.append(slot)

        if to_delete:
            self.slots.filter(id__in=to_delete).delete()
        if to_deactivate:
            Slot.objects.bulk_update(to_deactivate, ["is_available"])


    def save(self, *args, **kwargs):
        with transaction.atomic():

            super().save(*args, **kwargs)

            self.generate_slots()

        def _push(av_id):
            try:
                from .google_api import upsert_availability_event
                a = Availability.objects.get(pk=av_id)
                eid = upsert_availability_event(a)
                if eid and eid != a.google_event_id:
                    Availability.objects.filter(pk=av_id).update(google_event_id=eid)
            except Exception:
                logger.exception("Failed pushing availability to Google (id=%s)", av_id)

        transaction.on_commit(lambda av_id=self.id: _push(av_id))



class Slot(models.Model):
    availability = models.ForeignKey(
        'Availability',
        on_delete=models.CASCADE,
        related_name='slots',
        verbose_name="Plage de disponibilité"
    )
    type = models.ForeignKey(
        AppointmentType,
        on_delete=models.CASCADE,
        related_name="slots"
    )

    start = models.DateTimeField(
        verbose_name="Début du créneau"
    )
    end = models.DateTimeField(
        verbose_name="Fin du créneau"
    )
    is_available = models.BooleanField(
        default=False,
        verbose_name="Est disponible"
    )
    capacity = models.PositiveIntegerField(
        default=1
    )
    remaining_places = models.PositiveIntegerField(
        default=1
    )


    class Meta:
        ordering = ["start"]
        unique_together = (('availability', 'start', 'end', 'type'),)
        indexes = [
            models.Index(fields=["availability", "start"]),
            models.Index(fields=["start"]),
            models.Index(fields=["type", "start"]),
        ]

    def sync_remaining_places(self):
        """
        Réaligne les places restantes sur les rendez-vous réellement rattachés.

        Recalculer plutôt qu'incrémenter/décrémenter rend l'opération idempotente :
        une annulation rejouée, ou une suppression passée hors de `cancel()`, ne
        peut plus faire dériver le compteur.
        Retourne True si la valeur a changé.
        """
        from django.db.models import Sum
        taken = self.appointments.active().aggregate(n=Sum("places"))["n"] or 0
        remaining = max(0, self.capacity - taken)
        if remaining == self.remaining_places:
            return False
        self.remaining_places = remaining
        Slot.objects.filter(pk=self.pk).update(remaining_places=remaining)
        return True

    def __str__(self):
        return f"{self.type.name}: {self.start} - {self.end} ({self.remaining_places}/{self.capacity})"


class AppointmentQuerySet(models.QuerySet):
    """Un rendez-vous annulé occupe une ligne, jamais une place."""

    def active(self):
        """Rendez-vous qui comptent : tout sauf les annulés."""
        return self.exclude(status=Appointment.Status.CANCELLED)

    def cancelled(self):
        return self.filter(status=Appointment.Status.CANCELLED)

    def upcoming(self):
        return self.active().filter(start__gte=timezone.now())

    def to_review(self):
        """Rendez-vous passés dont la présence n'a pas encore été tranchée."""
        return self.filter(
            status=Appointment.Status.CONFIRMED, end__lt=timezone.now()
        )


class Appointment(models.Model):

    class Status(models.TextChoices):
        CONFIRMED = "confirmed", "Confirmé"
        HONOURED = "honoured", "Honoré"
        NO_SHOW = "no_show", "Absent"
        CANCELLED = "cancelled", "Annulé"

    class CancelledBy(models.TextChoices):
        CLIENT = "client", "Le client"
        MANAGER = "manager", "Le gestionnaire"
        SYSTEM = "system", "Le système"

    objects = AppointmentQuerySet.as_manager()

    type = models.ForeignKey(
        AppointmentType,
        on_delete=models.PROTECT,
    )
    slot = models.ForeignKey(
        Slot,
        on_delete=models.CASCADE,
        related_name="appointments",
        null=True,
        blank=True
    )
    user = models.ForeignKey(
        get_user_model(),
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )
    start = models.DateTimeField(
        "Début"
    )
    end = models.DateTimeField(
        "Fin",
    )
    created = models.DateTimeField(
        auto_now_add=True
    )
    is_paid = models.BooleanField(
        default=False,
    )  # utile si tu veux vérifier le paiement
    client_name = models.CharField(
        "Nom du client",
        max_length=150,
        blank=True,
    )
    email = models.EmailField(
        "Email du client",
        blank=True,
    )
    places = models.PositiveIntegerField(
        "Nombre de places",
        default=1,
        help_text="Places occupées par cette réservation (accompagnants inclus).",
    )

    google_event_id = models.CharField(
        max_length=128, blank=True, null=True, db_index=True
    )

    public_token = models.UUIDField(
        "Jeton public",
        default=uuid.uuid4,
        editable=False,
        unique=True,
        help_text="Identifiant non devinable utilisé dans les liens envoyés au client.",
    )

    status = models.CharField(
        "Statut",
        max_length=16,
        choices=Status.choices,
        default=Status.CONFIRMED,
        db_index=True,
    )
    cancelled_at = models.DateTimeField(
        "Annulé le", null=True, blank=True
    )
    cancelled_by = models.CharField(
        "Annulé par", max_length=16, choices=CancelledBy.choices, blank=True
    )
    cancel_reason = models.TextField(
        "Motif d'annulation", blank=True
    )

    def __str__(self):
        return f"{self.type.name} - {self.start:%Y-%m-%d %H:%M}"

    # ------------------------------------------------------------------
    # Accès client (liens envoyés par e-mail)
    # ------------------------------------------------------------------
    def get_public_cancel_url(self):
        """URL relative d'annulation, à insérer dans les e-mails au client."""
        return reverse(
            "jeiko_calendars_public:appointment_cancel",
            kwargs={"token": str(self.public_token)},
        )

    @property
    def is_past(self):
        return self.start <= timezone.now()

    @property
    def is_cancelled(self):
        return self.status == self.Status.CANCELLED

    def is_cancellable_by_client(self):
        """
        Un client ne peut annuler qu'un rendez-vous à venir et non déjà annulé.
        (Un délai de prévenance pourra être ajouté ici plus tard.)
        """
        return not self.is_past and not self.is_cancelled

    @property
    def owner(self):
        """Gestionnaire du calendrier auquel appartient ce rendez-vous."""
        return self.type.user if self.type_id else None

    def cancel(self, by=CancelledBy.CLIENT, reason=""):
        """
        Annule ce rendez-vous :
        - Passe le statut à « annulé ». La ligne est CONSERVÉE : historique,
          suivi des no-shows, déclenchement de la liste d'attente.
        - Libère la place et rouvre les créneaux qui étaient bloqués.
        - L'évènement Google est retiré par le signal post_save.

        Idempotent : retourne False si le rendez-vous était déjà annulé.
        """
        if self.pk is None or self.is_cancelled:
            # Déjà annulé (double clic, rejeu) : rien à faire.
            return False

        with transaction.atomic():
            self.status = self.Status.CANCELLED
            self.cancelled_at = timezone.now()
            self.cancelled_by = by
            self.cancel_reason = reason or ""
            self.save(update_fields=[
                "status", "cancelled_at", "cancelled_by", "cancel_reason"
            ])
            self.release_slot()
        return True

    def release_slot(self):
        """Rend la place au créneau et recalcule les chevauchements."""
        slot = Slot.objects.filter(pk=self.slot_id).select_related("availability").first()
        if slot is None:
            return
        slot.sync_remaining_places()
        slot.availability.update_slots_availability()

    def mark_attendance(self, honoured: bool):
        """Tranche la présence après coup (suivi des no-shows)."""
        if self.is_cancelled:
            return False
        self.status = self.Status.HONOURED if honoured else self.Status.NO_SHOW
        self.save(update_fields=["status"])
        return True