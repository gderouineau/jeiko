# jeiko/calendars/urls_public.py
"""
Routes accessibles au CLIENT, sans compte, via un jeton non devinable
transmis par e-mail. Aucun identifiant séquentiel n'est exposé ici.
"""
from django.urls import path

from jeiko.calendars.views import AppointmentPublicCancelView

app_name = "jeiko_calendars_public"

urlpatterns = [
    path(
        "annulation/<uuid:token>/",
        AppointmentPublicCancelView.as_view(),
        name="appointment_cancel",
    ),
]
