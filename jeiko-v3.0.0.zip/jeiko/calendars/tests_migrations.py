# jeiko/calendars/tests_migrations.py
"""
Test de la migration de données 0008.

Les tests applicatifs ordinaires ne l'exercent pas : la base de test est créée
vide, donc le peuplement ne rencontre aucune ligne. Or c'est précisément sur
des données existantes que la migration peut casser — un `AddField` avec défaut
écrit la MÊME valeur partout, et l'index unique échoue ensuite.
On rejoue donc la migration pour de vrai, sur des lignes préexistantes.
"""
from datetime import timedelta

from django.db.migrations.executor import MigrationExecutor
from django.db import connection
from django.test import TransactionTestCase
from django.utils import timezone

BEFORE = ("calendars", "0007_appointmenttype_user_availability_user_and_more")
AFTER = ("calendars", "0008_appointment_public_token")


class PublicTokenBackfillTests(TransactionTestCase):
    # La migration touche le schéma : il faut une vraie transaction par test.
    available_apps = None

    def _migrate(self, target):
        executor = MigrationExecutor(connection)
        executor.loader.build_graph()
        executor.migrate([target])
        executor.loader.build_graph()
        return executor

    def tearDown(self):
        # Remet la base à jour pour les tests suivants. On ne redescend pas
        # jusqu'à zéro : d'autres apps portent des migrations irréversibles.
        executor = MigrationExecutor(connection)
        executor.loader.build_graph()
        executor.migrate(executor.loader.graph.leaf_nodes())

    def test_existing_appointments_get_distinct_tokens(self):
        executor = self._migrate(BEFORE)
        old_apps = executor.loader.project_state(BEFORE).apps

        AppointmentType = old_apps.get_model("calendars", "AppointmentType")
        Appointment = old_apps.get_model("calendars", "Appointment")

        appt_type = AppointmentType.objects.create(
            name="Historique", duration=timedelta(hours=1), capacity=1
        )
        start = timezone.now() + timedelta(days=1)
        for i in range(5):
            Appointment.objects.create(
                type=appt_type,
                start=start + timedelta(hours=i),
                end=start + timedelta(hours=i + 1),
                email=f"ancien{i}@example.com",
            )

        # Application réelle de 0008 sur ces 5 lignes préexistantes.
        executor = self._migrate(AFTER)
        new_apps = executor.loader.project_state(AFTER).apps
        Appointment = new_apps.get_model("calendars", "Appointment")

        tokens = list(Appointment.objects.values_list("public_token", flat=True))
        self.assertEqual(len(tokens), 5)
        self.assertTrue(all(t is not None for t in tokens))
        self.assertEqual(len(set(tokens)), 5, "les jetons doivent être tous distincts")
