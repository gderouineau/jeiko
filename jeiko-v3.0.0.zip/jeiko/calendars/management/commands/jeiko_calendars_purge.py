# jeiko/calendars/management/commands/jeiko_calendars_purge.py
"""
Purge RGPD des données de rendez-vous.

Deux niveaux, du plus doux au plus radical :

1. **Anonymisation** — au-delà du délai de conservation, l'adresse e-mail du
   client (seule donnée personnelle stockée ici) est effacée. Le rendez-vous
   reste comptabilisé : statistiques d'activité, historique des no-shows,
   comptabilité.
2. **Suppression** — les rendez-vous annulés, beaucoup plus anciens, n'ont plus
   d'intérêt statistique : la ligne part.

Réglages (settings) :
    JEIKO_CALENDARS_ANONYMIZE_AFTER_MONTHS  (défaut 24)
    JEIKO_CALENDARS_DELETE_CANCELLED_AFTER_MONTHS  (défaut 12)

À faire tourner une fois par jour :
    manage.py jeiko_calendars_purge
Toujours vérifier d'abord avec --dry-run.
"""
from django.conf import settings
from django.core.management.base import BaseCommand
from django.utils import timezone

from jeiko.calendars.models import Appointment

DEFAULT_ANONYMIZE_MONTHS = 24
DEFAULT_DELETE_CANCELLED_MONTHS = 12


def _months_ago(months):
    # Approximation volontaire (30,44 j/mois) : un seuil de rétention n'a pas
    # besoin d'être exact à la journée près, et ça évite une dépendance.
    return timezone.now() - timezone.timedelta(days=int(months * 30.44))


class Command(BaseCommand):
    help = "Anonymise et purge les rendez-vous au-delà des délais de conservation."

    def add_arguments(self, parser):
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Affiche ce qui serait fait, sans rien modifier.",
        )
        parser.add_argument(
            "--anonymize-after", type=int, default=None,
            help="Délai en mois avant anonymisation de l'e-mail client.",
        )
        parser.add_argument(
            "--delete-cancelled-after", type=int, default=None,
            help="Délai en mois avant suppression des rendez-vous annulés.",
        )

    def handle(self, *args, **options):
        dry = options["dry_run"]

        anonymize_months = options["anonymize_after"] or getattr(
            settings, "JEIKO_CALENDARS_ANONYMIZE_AFTER_MONTHS", DEFAULT_ANONYMIZE_MONTHS
        )
        delete_months = options["delete_cancelled_after"] or getattr(
            settings, "JEIKO_CALENDARS_DELETE_CANCELLED_AFTER_MONTHS",
            DEFAULT_DELETE_CANCELLED_MONTHS,
        )

        if dry:
            self.stdout.write(self.style.WARNING("Mode simulation : aucune écriture."))

        # --- 1. Suppression des annulés anciens (avant l'anonymisation :
        #        inutile d'anonymiser une ligne qui va disparaître).
        delete_before = _months_ago(delete_months)
        to_delete = Appointment.objects.cancelled().filter(start__lt=delete_before)
        nb_delete = to_delete.count()
        if nb_delete and not dry:
            # Boucle plutôt que .delete() en masse : le post_delete qui libère
            # les places doit s'exécuter proprement pour chaque ligne.
            for appt in to_delete.iterator():
                appt.delete()
        self.stdout.write(
            f"Rendez-vous annulés avant le {delete_before:%d/%m/%Y} supprimés : {nb_delete}"
        )

        # --- 2. Anonymisation des rendez-vous anciens encore identifiants
        anonymize_before = _months_ago(anonymize_months)
        to_anonymize = Appointment.objects.filter(
            start__lt=anonymize_before
        ).exclude(email="")
        nb_anonymize = to_anonymize.count()
        if nb_anonymize and not dry:
            # update() en masse : pas de signal, donc aucune synchronisation
            # Google déclenchée sur des rendez-vous vieux de deux ans.
            to_anonymize.update(email="")
        self.stdout.write(
            f"Rendez-vous antérieurs au {anonymize_before:%d/%m/%Y} anonymisés : {nb_anonymize}"
        )

        if dry:
            self.stdout.write(self.style.WARNING(
                "Simulation terminée — relancer sans --dry-run pour appliquer."
            ))
        else:
            self.stdout.write(self.style.SUCCESS("Purge terminée."))
