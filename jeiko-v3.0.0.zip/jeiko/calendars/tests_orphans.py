# jeiko/calendars/tests_orphans.py
"""
Rendu des pages de supervision en présence d'objets SANS propriétaire.

Ces objets datent d'avant l'attribution des calendriers à un gestionnaire
(migration 0007). Le superviseur est le seul à les voir — donc le seul à
déclencher les colonnes « Gestionnaire », d'où des pages qui cassaient sur lui
et sur lui seul.

Piège Django : `{{ a.user.get_full_name|default:a.user.username }}` lève
VariableDoesNotExist quand `user` vaut None. L'échec est silencieux pour la
variable principale d'une expression, mais PAS pour un argument de filtre.
"""
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Appointment, AppointmentType, Availability, GoogleCalendarConfig, Slot
from .tests import grant_calendar_perms

User = get_user_model()


class OrphanRenderingTests(TestCase):
    """Aucune page ne doit casser à cause d'un objet sans propriétaire."""

    def setUp(self):
        self.root = User.objects.create_superuser(username="root", password="pwd12345")

        # --- objets orphelins (user=None), comme en base de production
        self.orphan_type = AppointmentType.objects.create(
            name="Ancien type", user=None, duration=timedelta(hours=1), capacity=1
        )
        start = (timezone.now() + timedelta(days=2)).replace(
            minute=0, second=0, microsecond=0
        )
        self.orphan_availability = Availability.objects.create(
            user=None, start=start, end=start + timedelta(hours=1)
        )
        self.orphan_availability.appointment_types.add(self.orphan_type)
        GoogleCalendarConfig.objects.create(user=None, name="Ancienne config")

        slot = Slot.objects.filter(availability=self.orphan_availability).first()
        self.orphan_appointment = Appointment.objects.create(
            type=self.orphan_type, slot=slot,
            start=slot.start, end=slot.end, email="ancien@example.com",
        )
        # Un rendez-vous passé, pour la page « historique »
        past = timezone.now() - timedelta(days=3)
        Appointment.objects.create(
            type=self.orphan_type, start=past, end=past + timedelta(hours=1),
            email="passe@example.com",
        )

        self.client.force_login(self.root)

    def assert_renders(self, url_name, **kwargs):
        resp = self.client.get(reverse(url_name, kwargs=kwargs or None))
        self.assertEqual(resp.status_code, 200, f"{url_name} → {resp.status_code}")
        return resp

    def test_appointment_type_list_renders(self):
        resp = self.assert_renders("jeiko_administration_calendars:appointmenttype_list")
        self.assertContains(resp, "Ancien type")
        self.assertContains(resp, "sans propriétaire")

    def test_past_appointment_list_renders(self):
        resp = self.assert_renders("jeiko_administration_calendars:appointment_list_past")
        self.assertContains(resp, "passe@example.com")

    def test_upcoming_appointment_list_renders(self):
        resp = self.assert_renders("jeiko_administration_calendars:appointment_list_upcoming")
        self.assertContains(resp, "ancien@example.com")

    def test_availability_list_renders(self):
        self.assert_renders("jeiko_administration_calendars:availability_list")

    def test_availability_delete_confirmation_renders(self):
        self.assert_renders(
            "jeiko_administration_calendars:availability_delete",
            pk=self.orphan_availability.pk,
        )

    def test_supervision_page_lists_orphans(self):
        resp = self.assert_renders("jeiko_administration_calendars:google_configs_all")
        self.assertTrue(resp.context["has_orphans"])
        self.assertContains(resp, "Ancien type")

    def test_appointment_detail_renders(self):
        self.assert_renders(
            "jeiko_administration_calendars:appointment_detail",
            pk=self.orphan_appointment.pk,
        )


class OrphansAreHiddenFromManagersTests(TestCase):
    """Un gestionnaire ordinaire ne doit pas voir les objets sans propriétaire."""

    def setUp(self):
        self.manager = grant_calendar_perms(
            User.objects.create_user(username="gestionnaire", password="pwd12345")
        )
        AppointmentType.objects.create(
            name="Ancien type", user=None, duration=timedelta(hours=1), capacity=1
        )
        self.client.force_login(self.manager)

    def test_orphan_type_absent_from_list(self):
        resp = self.client.get(
            reverse("jeiko_administration_calendars:appointmenttype_list")
        )
        self.assertEqual(resp.status_code, 200)
        self.assertNotContains(resp, "Ancien type")
