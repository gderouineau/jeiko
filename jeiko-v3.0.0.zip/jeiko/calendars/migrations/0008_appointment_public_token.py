# jeiko/calendars/migrations/0008_appointment_public_token.py
"""
Ajoute Appointment.public_token (UUID non devinable) utilisé dans les liens
envoyés au client (annulation, et plus tard modification).

Déroulé en 3 temps, et SANS défaut au moment de l'ajout : un `AddField` porteur
d'un `default=uuid.uuid4` n'évalue ce défaut qu'une seule fois, au niveau du
`ALTER TABLE` — toutes les lignes existantes recevraient donc le MÊME UUID, et
l'index unique de la 3e étape échouerait. La colonne est donc créée vide, puis
peuplée ligne à ligne, puis seulement rendue unique.
"""
import uuid

from django.db import migrations, models


def fill_public_tokens(apps, schema_editor):
    """Attribue un UUID distinct à chaque rendez-vous existant."""
    Appointment = apps.get_model("calendars", "Appointment")

    # 1. Lignes sans jeton (cas normal : la colonne vient d'être créée vide).
    pks = list(
        Appointment.objects.filter(public_token__isnull=True)
        .values_list("pk", flat=True)
    )

    # 2. Filet de sécurité : si une base porte déjà des jetons dupliqués
    #    (colonne créée avec un défaut unique par un ancien état de cette
    #    migration), on ne garde qu'une ligne par jeton et on régénère les
    #    autres. Sans ça, l'index unique ci-dessous échouerait.
    seen = set()
    for pk, token in (
        Appointment.objects.filter(public_token__isnull=False)
        .order_by("pk")
        .values_list("pk", "public_token")
    ):
        if token in seen:
            pks.append(pk)
        else:
            seen.add(token)

    for pk in pks:
        Appointment.objects.filter(pk=pk).update(public_token=uuid.uuid4())


class Migration(migrations.Migration):

    dependencies = [
        ("calendars", "0007_appointmenttype_user_availability_user_and_more"),
    ]

    operations = [
        migrations.AddField(
            model_name="appointment",
            name="public_token",
            field=models.UUIDField(
                null=True,
                editable=False,
                help_text="Identifiant non devinable utilisé dans les liens envoyés au client.",
                verbose_name="Jeton public",
            ),
        ),
        migrations.RunPython(fill_public_tokens, migrations.RunPython.noop),
        migrations.AlterField(
            model_name="appointment",
            name="public_token",
            field=models.UUIDField(
                default=uuid.uuid4,
                editable=False,
                unique=True,
                help_text="Identifiant non devinable utilisé dans les liens envoyés au client.",
                verbose_name="Jeton public",
            ),
        ),
    ]
