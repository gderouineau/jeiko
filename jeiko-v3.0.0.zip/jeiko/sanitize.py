"""
Assainissement du HTML saisi dans l'administration.

Le contenu des pages est du HTML : les rédacteurs doivent pouvoir mettre en
forme, insérer des liens, des images. On ne peut donc pas simplement tout
échapper. Mais on ne peut pas non plus le rendre tel quel — un `<script>`, un
attribut `onerror=` ou une URL `javascript:` s'exécuteraient chez tous les
visiteurs, y compris les administrateurs, ce qui permet le vol de session vers
un compte plus privilégié.

Stratégie, par ordre de préférence :

1. `nh3` — liaison Python d'`ammonia` (Rust), l'analyseur de référence. C'est la
   dépendance déclarée dans requirements.txt.
2. `bleach` — repli si le projet l'a déjà.
3. Aucun des deux — on **échappe intégralement**. Le rendu perd sa mise en
   forme, ce qui se voit immédiatement, plutôt que de laisser passer du script
   silencieusement. Un défaut visible vaut mieux qu'une faille invisible.

Le comportement est pilotable par `JEIKO_SANITIZE_HTML` (défaut : True). Le
passer à False rend le HTML brut : à ne faire que si les seuls rédacteurs sont
de confiance et qu'aucun rôle n'est délégué à un tiers.
"""

import logging

from django.conf import settings
from django.utils.html import escape
from django.utils.safestring import mark_safe

logger = logging.getLogger("jeiko")

# Balises de mise en forme, de structure et de média. Volontairement sans
# <script>, <style>, <iframe>, <object>, <embed>, <form> ni <input>.
ALLOWED_TAGS = {
    "a", "abbr", "b", "blockquote", "br", "caption", "cite", "code", "col",
    "colgroup", "dd", "del", "div", "dl", "dt", "em", "figcaption", "figure",
    "h1", "h2", "h3", "h4", "h5", "h6", "hr", "i", "img", "ins", "li", "mark",
    "ol", "p", "picture", "pre", "q", "s", "small", "source", "span", "strong",
    "sub", "sup", "table", "tbody", "td", "tfoot", "th", "thead", "time", "tr",
    "u", "ul", "video", "audio",
}

# Aucun attribut `on*` : c'est la voie d'exécution la plus courante.
ALLOWED_ATTRIBUTES = {
    "*": {"class", "id", "title", "dir", "lang", "role", "aria-label", "aria-hidden"},
    # « rel » est absent volontairement : nh3 le pose lui-même via link_rel et
    # refuse qu'on le déclare en plus. Le repli bleach l'ajoute de son côté.
    "a": {"href", "target"},
    "img": {"src", "alt", "width", "height", "loading", "srcset", "sizes"},
    "source": {"src", "srcset", "type", "media"},
    "video": {"src", "controls", "poster", "width", "height", "preload"},
    "audio": {"src", "controls", "preload"},
    "td": {"colspan", "rowspan"},
    "th": {"colspan", "rowspan", "scope"},
    "time": {"datetime"},
    "col": {"span"},
    "colgroup": {"span"},
}

# `javascript:` et `data:` exclus — `data:text/html` est un vecteur d'exécution.
ALLOWED_SCHEMES = {"http", "https", "mailto", "tel"}

_BACKEND = None


def _resolve_backend():
    """Choisit l'implémentation une fois pour toutes, et le dit dans le journal."""
    global _BACKEND
    if _BACKEND is not None:
        return _BACKEND

    try:
        import nh3  # noqa: F401
        _BACKEND = "nh3"
    except ImportError:
        try:
            import bleach  # noqa: F401
            _BACKEND = "bleach"
        except ImportError:
            _BACKEND = "escape"
            logger.warning(
                "Ni nh3 ni bleach ne sont installés : le HTML des contenus sera "
                "intégralement échappé et perdra sa mise en forme. "
                "Installer nh3 (déjà présent dans requirements.txt) pour "
                "rétablir le rendu."
            )
    return _BACKEND


def clean_html(value):
    """
    Retourne une chaîne sûre à insérer telle quelle dans un gabarit.

    La valeur de retour n'est PAS marquée sûre : c'est à l'appelant de le faire
    explicitement, pour que chaque `mark_safe` du code reste visible.
    """
    if not value:
        return ""

    text = str(value)

    if not getattr(settings, "JEIKO_SANITIZE_HTML", True):
        return text

    backend = _resolve_backend()

    if backend == "nh3":
        import nh3
        return nh3.clean(
            text,
            tags=ALLOWED_TAGS,
            attributes={k: set(v) for k, v in ALLOWED_ATTRIBUTES.items()},
            url_schemes=ALLOWED_SCHEMES,
            link_rel="noopener noreferrer",
        )

    if backend == "bleach":
        import bleach
        attributes = {k: list(v) for k, v in ALLOWED_ATTRIBUTES.items()}
        # bleach ne pose pas rel="noopener" tout seul : on autorise l'attribut
        # pour que celui déjà présent dans le contenu survive.
        attributes["a"] = attributes.get("a", []) + ["rel"]
        return bleach.clean(
            text,
            tags=ALLOWED_TAGS,
            attributes=attributes,
            protocols=list(ALLOWED_SCHEMES),
            strip=True,
        )

    return escape(text)


def clean_html_safe(value):
    """`clean_html` suivi de `mark_safe` — pour un usage direct en gabarit."""
    return mark_safe(clean_html(value))
