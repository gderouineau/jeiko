from django.http import HttpResponsePermanentRedirect
from django.shortcuts import render, get_object_or_404, redirect
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import ensure_csrf_cookie
from django.urls import reverse

from jeiko.custom_objects.models import CustomObject, CustomObjectField
from jeiko.shop.models import Product, Cart, CartItem

@method_decorator(ensure_csrf_cookie, name="get")
class ProductView(View):
    """
    Vue client pour afficher un produit (basé sur CustomObjectView) :
    URL canonique : /shop/product/<slug>/ (ou autre structure d'URL définie dans shop/urls.py)
    """

    template_name = "pages/main.html"  # même template que PageView

    def get(self, request, *args, **kwargs):
        product_sku = kwargs["product_sku"]
        product_type_code = kwargs['product_type_code']
        # Récupération du produit via son CustomObject slug ou directement via SKU/ID si l'URL change
        # Ici on suppose que l'URL utilise le slug du CustomObject lié au produit
        # Ou alors on récupère le produit via son propre slug s'il en a un, ou via le slug du content.
        
        # Option 1: On cherche le CustomObject, puis on vérifie s'il a un produit
        # Option 2: On cherche le Product qui a un content__slug = product_slug


        product = get_object_or_404(
            Product,
            sku=product_sku,

        )
        
        obj = product.content # Le CustomObject associé

        # Canonical check (optionnel, selon votre config URL)
        # canonical_path = product.get_absolute_url()
        # if request.path != canonical_path:
        #     return HttpResponsePermanentRedirect(canonical_path)

        page = obj.model.page_template

        # Contexte de base
        context = {"page": page, "custom_object": obj, "object": obj, "product": product,
                   "product_price": product.price_ttc, "product_price_ht": product.price_ht, "product_sku": product.sku,
                   "product_stock": product.stock_quantity,
                   "product_is_in_stock": product.stock_quantity > 0 or product.allow_negative_stock}

        # Injection des champs "magiques" du produit

        # Metadata éventuelle
        metadata = getattr(obj, "metadata", None)
        if metadata is not None:
            context["metadata"] = metadata

        # Injection des valeurs des champs CustomObject dans le contexte
        for value in obj.values.all():
            code = value.field.code
            if not code:
                continue

            field_type = value.field.field_type

            if field_type in (CustomObjectField.TEXT, CustomObjectField.RICH_TEXT):
                context[code] = value.value_text

            elif field_type == CustomObjectField.IMAGE:
                context[code] = value.image

            elif field_type == CustomObjectField.VIDEO:
                context[code] = value.video_url

            elif field_type == CustomObjectField.BUTTON:
                # Construire l’URL comme pour ContentButton
                url = "#"

                if getattr(value, "button_page", None):
                    try:
                        url = value.button_page.get_absolute_url()
                    except Exception:
                        url = "#"

                elif getattr(value, "button_test_slug", None):
                    slug = (value.button_test_slug or "").strip()
                    if slug:
                        try:
                            url = reverse(
                                "jeiko_client_questionnaires_expert:test_question",
                                kwargs={"slug": slug, "position": 0},
                            )
                        except Exception:
                            url = f"/pass-test/{slug}/question/0/"

                elif getattr(value, "button_external_url", None):
                    url = (value.button_external_url or "").strip() or "#"

                label = (value.button_label or "").strip()

                context[code] = {
                    "url": url,
                    "label": label,
                }

        return render(request, self.template_name, context)


# ----------------------------------------------------------------------
#  Cart Views
# ----------------------------------------------------------------------

def get_or_create_cart(request):
    """
    Helper pour récupérer ou créer le panier courant.
    Gère le merge si l'utilisateur se connecte (TODO).
    """
    cart = None
    user = request.user

    # 1. Si user connecté, on cherche son panier
    if user.is_authenticated:
        cart = Cart.objects.filter(user=user, is_locked=False).first()
        if not cart:
            cart = Cart.objects.create(user=user)
    else:
        # 2. Sinon on utilise la session
        if not request.session.session_key:
            request.session.create()
        
        session_key = request.session.session_key
        cart = Cart.objects.filter(session_key=session_key, is_locked=False).first()
        if not cart:
            cart = Cart.objects.create(session_key=session_key)
            
    return cart


class CartDetailView(View):
    template_name = "shop/cart_detail.html"

    def get(self, request):
        cart = get_or_create_cart(request)
        items = cart.items.select_related("product", "product__content").all()
        
        # Calcul des totaux (simple pour l'instant)
        total_ht = sum(item.total_ht for item in items)
        total_ttc = sum(item.total_ttc for item in items)

        context = {
            "cart": cart,
            "items": items,
            "total_ht": total_ht,
            "total_ttc": total_ttc,
        }
        return render(request, self.template_name, context)


class AddToCartView(View):
    def post(self, request, product_id):
        cart = get_or_create_cart(request)
        product = get_object_or_404(Product, pk=product_id)
        quantity = int(request.POST.get("quantity", 1))
        if quantity < 1:
            quantity = 1

        # Vérif stock (basique)
        if not product.allow_negative_stock and product.stock_quantity < quantity:
            # TODO: Message d'erreur
            return redirect("jeiko_client_shop:cart_detail")

        # On cherche si l'item existe déjà
        item, created = CartItem.objects.get_or_create(
            cart=cart,
            product=product,
            defaults={
                "quantity": 0, # On ajoutera la quantité juste après
                "unit_price_ht": product.price_ht,
                "tax_rate": product.tax_rate,
                "currency": product.currency,
            }
        )
        print(cart)
        print('test')
        # Mise à jour prix/taxe si ça a changé entre temps ? 
        # Pour l'instant on garde le snapshot à la création ou on met à jour ?
        # Généralement dans un panier on veut le prix actuel.
        item.unit_price_ht = product.price_ht
        item.tax_rate = product.tax_rate
        
        item.quantity += quantity
        item.save()
        
        return redirect("jeiko_client_shop:cart_detail")


class UpdateCartItemView(View):
    def post(self, request, item_id):
        cart = get_or_create_cart(request)
        item = get_object_or_404(CartItem, pk=item_id, cart=cart)
        
        action = request.POST.get("action")
        
        if action == "update":
            quantity = int(request.POST.get("quantity", item.quantity))
            if quantity > 0:
                item.quantity = quantity
                item.save()
            else:
                item.delete()
                
        return redirect("jeiko_client_shop:cart_detail")


class RemoveCartItemView(View):
    def post(self, request, item_id):
        cart = get_or_create_cart(request)
        item = get_object_or_404(CartItem, pk=item_id, cart=cart)
        item.delete()
        return redirect("jeiko_client_shop:cart_detail")
