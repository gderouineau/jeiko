Gabarits du projet Django, embarqués dans le package.

GÉNÉRÉS — ne pas éditer ici. La source est INSTALLER/templates/ dans Art ;
publier-jeiko.sh les recopie à chaque publication.

Ils voyagent avec le package pour que la mise à jour côté client puisse
réaligner settings.py quand une nouvelle version ajoute une application à
INSTALLED_APPS. Sans ça, le client n'aurait aucun moyen d'apprendre qu'une
app est apparue.

L'extension .txt n'est pas cosmétique : MANIFEST.in embarque
« recursive-include jeiko *.txt », donc ces fichiers entrent dans le wheel
sans modifier la configuration de construction.
