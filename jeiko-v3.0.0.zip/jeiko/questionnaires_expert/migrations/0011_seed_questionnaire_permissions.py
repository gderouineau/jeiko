from django.db import migrations

# Les vues d'administration exigent ces permissions depuis toujours, mais rien
# ne les créait : elles étaient donc impossibles à accorder et le back-office
# questionnaires restait réservé aux superusers.
QUESTIONNAIRE_PERMISSIONS = [
    ('view_questionnaire', 'Voir les questionnaires'),
    ('add_questionnaire', 'Créer un questionnaire'),
    ('change_questionnaire', 'Éditer un questionnaire'),
    ('delete_questionnaire', 'Supprimer un questionnaire'),
]


def create_questionnaire_permissions(apps, schema_editor):
    Permission = apps.get_model('auth', 'Permission')
    ContentType = apps.get_model('contenttypes', 'ContentType')
    Role = apps.get_model('users', 'Role')

    content_type, _ = ContentType.objects.get_or_create(
        app_label='questionnaires_expert', model='experttest'
    )

    created = []
    for codename, name in QUESTIONNAIRE_PERMISSIONS:
        # Certaines bases ont pu recevoir ces permissions à la main, éventuellement
        # sur un autre content type : on ne veut pas créer de doublon.
        if Permission.objects.filter(codename=codename).exists():
            continue
        created.append(Permission.objects.create(
            codename=codename, name=name, content_type=content_type
        ))

    # Le rôle « Administrateur » a reçu toutes les permissions existantes lors de
    # son seed initial ; les nouvelles doivent lui être ajoutées explicitement.
    if created:
        role = Role.objects.filter(slug='administrateur').first()
        if role:
            role.permissions.add(*created)


def noop_reverse(apps, schema_editor):
    # On ne supprime pas de permissions : ce serait perdre les attributions de rôles.
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('questionnaires_expert', '0010_experttestdata_public_token'),
        ('users', '0002_role_alter_comments_options_marketingpreference_and_more'),
        ('auth', '0012_alter_user_first_name_max_length'),
        ('contenttypes', '0002_remove_content_type_name'),
    ]

    operations = [
        migrations.RunPython(create_questionnaire_permissions, noop_reverse),
    ]
