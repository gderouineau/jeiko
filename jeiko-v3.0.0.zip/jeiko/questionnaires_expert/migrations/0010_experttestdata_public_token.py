import uuid

from django.db import migrations, models


def fill_public_tokens(apps, schema_editor):
    """
    Attribue un UUID distinct à chaque résultat existant.

    On ne peut pas s'appuyer sur `default=uuid.uuid4` dans l'AddField : le
    default est évalué une seule fois côté SQL, toutes les lignes existantes
    recevraient donc le même jeton et la contrainte unique échouerait.
    """
    ExpertTestData = apps.get_model('questionnaires_expert', 'ExpertTestData')
    for pk in ExpertTestData.objects.filter(public_token__isnull=True).values_list('pk', flat=True).iterator():
        ExpertTestData.objects.filter(pk=pk).update(public_token=uuid.uuid4())


def noop(apps, schema_editor):
    pass


def preserve_legacy_comparison(apps, schema_editor):
    """
    Jusqu'ici le moteur de scoring appliquait `score_a >= score_b` en dur, en
    ignorant le champ `comparison` (resté au défaut '>' pour tous les critères).
    Maintenant que `comparison` est réellement évalué, on convertit l'existant
    en '>=' pour que les questionnaires en production continuent de produire
    exactement les mêmes profils qu'avant.
    """
    ExpertProfileCriterion = apps.get_model('questionnaires_expert', 'ExpertProfileCriterion')
    ExpertProfileCriterion.objects.filter(comparison='>').update(comparison='>=')


def revert_legacy_comparison(apps, schema_editor):
    ExpertProfileCriterion = apps.get_model('questionnaires_expert', 'ExpertProfileCriterion')
    ExpertProfileCriterion.objects.filter(comparison='>=').update(comparison='>')


class Migration(migrations.Migration):

    dependencies = [
        ('questionnaires_expert', '0009_remove_experttest_customization_page_and_more'),
    ]

    operations = [
        # --- Jeton public sur les résultats (3 temps : ajout / remplissage / unicité) ---
        migrations.AddField(
            model_name='experttestdata',
            name='public_token',
            field=models.UUIDField(
                null=True,
                editable=False,
                verbose_name='Jeton public',
                help_text="Identifiant non devinable servant à consulter ce résultat sans être connecté.",
            ),
        ),
        migrations.RunPython(fill_public_tokens, noop),
        migrations.AlterField(
            model_name='experttestdata',
            name='public_token',
            field=models.UUIDField(
                default=uuid.uuid4,
                editable=False,
                unique=True,
                verbose_name='Jeton public',
                help_text="Identifiant non devinable servant à consulter ce résultat sans être connecté.",
            ),
        ),

        # --- Ordre déterministe d'évaluation des combinaisons ---
        migrations.AlterModelOptions(
            name='expertprofilecombination',
            options={'ordering': ['id']},
        ),

        # --- Le champ `comparison` devient réellement appliqué ---
        migrations.RunPython(preserve_legacy_comparison, revert_legacy_comparison),
        migrations.AlterField(
            model_name='expertprofilecriterion',
            name='output_type',
            field=models.CharField(
                choices=[('parent', 'Parent (dominant)'), ('preferred', 'Préféré'), ('alternative', 'Alternatif')],
                default='parent',
                help_text='Non utilisé : les profils résultants sont ceux de la combinaison.',
                max_length=20,
            ),
        ),
    ]
