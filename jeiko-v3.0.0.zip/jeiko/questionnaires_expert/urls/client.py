# urls_client.py
from django.urls import path
from jeiko.questionnaires_expert.views import client as views

app_name = "jeiko_client_questionnaires_expert"

urlpatterns = [
    # Résultat personnel, porté par le jeton du ExpertTestData.
    # Déclaré avant les routes en <slug:slug> pour éviter toute ambiguïté.
    path(
        "result/<uuid:token>/",
        views.ExpertTestResultTokenView.as_view(),
        name="test_result_token"
    ),

    # Page d'introduction du test (description, bouton commencer)
    path(
        "<slug:slug>/",
        views.ExpertTestIntroView.as_view(),
        name="test_intro"
    ),

    # Affichage d'une question selon sa position dans le test
    path(
        "<slug:slug>/question/<int:position>/",
        views.ExpertTestQuestionView.as_view(),
        name="test_question"
    ),

    # Formulaire d'enregistrement des coordonnées du prospect après les réponses
    path(
        "<slug:slug>/result/input/",
        views.ExpertTestResultInputView.as_view(),
        name="test_result_input"
    ),

    # Résultat final du test (page de profil)
    path(
        "<slug:slug>/result/<slug:result_slug>/",
        views.ExpertTestResultView.as_view(),
        name="test_result"
    ),
]
