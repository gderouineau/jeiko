from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.test import TestCase
from django.urls import reverse

from jeiko.questionnaires_expert.models import (
    ExpertTest, ExpertQuestion, ExpertAnswer, ExpertAnswerProfileWeight,
    ExpertProfileType, ExpertProfileCombination, ExpertProfileCriterion,
    ExpertTestData, ExpertTestStyle, Prospect, UserTestAccess,
    DEFAULT_TEST_STYLE,
)
from jeiko.questionnaires_expert.forms import ExpertTestStyleForm
from jeiko.questionnaires_expert.views.client import (
    compute_total_score, get_score_profile, resolve_profiles,
)

User = get_user_model()


class CriterionEvaluateTests(TestCase):
    """Le champ `comparison` doit réellement piloter l'évaluation."""

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="T", slug="t")
        cls.a = ExpertProfileType.objects.create(test=cls.test, name="A")
        cls.b = ExpertProfileType.objects.create(test=cls.test, name="B")
        cls.combination = ExpertProfileCombination.objects.create(
            test=cls.test, parent_profile=cls.a, title="C"
        )

    def _criterion(self, comparison, tolerance=None):
        return ExpertProfileCriterion(
            combination=self.combination,
            profile_a=self.a, profile_b=self.b,
            comparison=comparison, tolerance=tolerance,
        )

    def test_operators(self):
        scores = {self.a.id: 10, self.b.id: 5}
        equal = {self.a.id: 5, self.b.id: 5}

        self.assertTrue(self._criterion('>').evaluate(scores))
        self.assertFalse(self._criterion('>').evaluate(equal))

        self.assertTrue(self._criterion('>=').evaluate(equal))
        self.assertFalse(self._criterion('<').evaluate(scores))
        self.assertTrue(self._criterion('<=').evaluate(equal))
        self.assertTrue(self._criterion('==').evaluate(equal))
        self.assertFalse(self._criterion('==').evaluate(scores))

    def test_tolerance(self):
        scores = {self.a.id: 10, self.b.id: 8}
        self.assertTrue(self._criterion('~=', tolerance=3).evaluate(scores))
        self.assertFalse(self._criterion('~=', tolerance=1).evaluate(scores))
        # tolérance vide == égalité stricte
        self.assertFalse(self._criterion('~=').evaluate(scores))
        self.assertTrue(self._criterion('~=').evaluate({self.a.id: 4, self.b.id: 4}))

    def test_missing_profile_scores_default_to_zero(self):
        self.assertTrue(self._criterion('==').evaluate({}))
        self.assertTrue(self._criterion('>').evaluate({self.a.id: 1}))


class ResolveProfilesTests(TestCase):

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="T", slug="t")
        cls.a = ExpertProfileType.objects.create(test=cls.test, name="A")
        cls.b = ExpertProfileType.objects.create(test=cls.test, name="B")

    def test_combination_requires_all_criteria(self):
        combination = ExpertProfileCombination.objects.create(
            test=self.test, parent_profile=self.a, preferred_profile=self.b, title="C"
        )
        ExpertProfileCriterion.objects.create(
            combination=combination, profile_a=self.a, profile_b=self.b, comparison='>'
        )
        ExpertProfileCriterion.objects.create(
            combination=combination, profile_a=self.b, profile_b=self.a, comparison='>'
        )

        # Les deux critères sont contradictoires : aucune combinaison ne matche.
        result, preferred, alternative = resolve_profiles(self.test, {self.a.id: 10, self.b.id: 1})
        self.assertIsNone(result)
        self.assertIsNone(preferred)
        self.assertIsNone(alternative)

    def test_matching_combination_returns_its_three_profiles(self):
        combination = ExpertProfileCombination.objects.create(
            test=self.test, parent_profile=self.a, preferred_profile=self.b, title="C"
        )
        ExpertProfileCriterion.objects.create(
            combination=combination, profile_a=self.a, profile_b=self.b, comparison='>'
        )

        result, preferred, alternative = resolve_profiles(self.test, {self.a.id: 10, self.b.id: 1})
        self.assertEqual(result, self.a)
        self.assertEqual(preferred, self.b)
        self.assertIsNone(alternative)

    def test_first_matching_combination_wins_in_id_order(self):
        for parent in (self.a, self.b):
            combination = ExpertProfileCombination.objects.create(
                test=self.test, parent_profile=parent, title=f"C-{parent.name}"
            )
            ExpertProfileCriterion.objects.create(
                combination=combination, profile_a=self.a, profile_b=self.b, comparison='>'
            )

        result, _, _ = resolve_profiles(self.test, {self.a.id: 10, self.b.id: 1})
        self.assertEqual(result, self.a)

    def test_combination_without_criteria_is_skipped(self):
        ExpertProfileCombination.objects.create(test=self.test, parent_profile=self.a, title="vide")
        result, _, _ = resolve_profiles(self.test, {self.a.id: 10})
        self.assertIsNone(result)

    def test_score_profile_fallback_does_not_crash(self):
        """Régression : get_score_profile levait une TypeError (never_cache mal appliqué)."""
        score_profile = ExpertProfileType.objects.create(
            test=self.test, name="Score", is_score_profile=True, min_score=0, max_score=100
        )
        result, preferred, alternative = resolve_profiles(self.test, {self.a.id: 10})
        self.assertEqual(result, score_profile)
        self.assertIsNone(preferred)
        self.assertIsNone(alternative)


class ScoreProfileBoundsTests(TestCase):

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="T", slug="t")

    def test_open_bounds_are_not_constraining(self):
        low = ExpertProfileType.objects.create(
            test=self.test, name="Bas", is_score_profile=True, min_score=None, max_score=10
        )
        high = ExpertProfileType.objects.create(
            test=self.test, name="Haut", is_score_profile=True, min_score=10, max_score=None
        )
        self.assertEqual(get_score_profile(self.test, -50), low)
        self.assertEqual(get_score_profile(self.test, 9999), high)
        self.assertEqual(get_score_profile(self.test, 10), high)

    def test_no_matching_range(self):
        ExpertProfileType.objects.create(
            test=self.test, name="P", is_score_profile=True, min_score=0, max_score=10
        )
        self.assertIsNone(get_score_profile(self.test, 50))


class CombinationSlugTests(TestCase):
    """Régression : deux combinaisons sans titre violaient la contrainte unique."""

    def test_untitled_combinations_get_distinct_slugs(self):
        test = ExpertTest.objects.create(title="T", slug="t")
        profile = ExpertProfileType.objects.create(test=test, name="A")
        first = ExpertProfileCombination.objects.create(test=test, parent_profile=profile)
        second = ExpertProfileCombination.objects.create(test=test, parent_profile=profile)
        self.assertTrue(first.slug)
        self.assertNotEqual(first.slug, second.slug)


class RestrictedAccessTests(TestCase):
    """Un test restreint ne doit être passable qu'avec une autorisation."""

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="Privé", slug="prive", is_restricted=True)
        cls.public = ExpertTest.objects.create(title="Public", slug="public")
        cls.user = User.objects.create_user("bob", "bob@example.com", "pwd")
        cls.staff = User.objects.create_user("staff", "staff@example.com", "pwd", is_staff=True)
        cls.granted = User.objects.create_user("ok", "ok@example.com", "pwd")
        UserTestAccess.objects.create(user=cls.granted, test=cls.test, source='ADMIN')

    def _intro(self, test):
        return reverse("jeiko_client_questionnaires_expert:test_intro", kwargs={"slug": test.slug})

    def test_public_test_is_open(self):
        self.assertEqual(self.client.get(self._intro(self.public)).status_code, 200)

    def test_anonymous_is_redirected_to_login(self):
        response = self.client.get(self._intro(self.test))
        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("jeiko_allauth:login"), response.url)

    def test_authenticated_without_access_is_refused(self):
        self.client.force_login(self.user)
        response = self.client.get(self._intro(self.test))
        self.assertEqual(response.status_code, 302)
        self.assertNotIn("prive", response.url)

    def test_user_with_access_can_enter(self):
        self.client.force_login(self.granted)
        self.assertEqual(self.client.get(self._intro(self.test)).status_code, 200)

    def test_staff_can_preview(self):
        self.client.force_login(self.staff)
        self.assertEqual(self.client.get(self._intro(self.test)).status_code, 200)

    def test_inactive_test_is_hidden_from_the_public(self):
        inactive = ExpertTest.objects.create(title="Off", slug="off", is_active=False)
        self.assertEqual(self.client.get(self._intro(inactive)).status_code, 404)

        # Le staff conserve l'accès pour relire le questionnaire
        self.client.force_login(self.staff)
        self.assertEqual(self.client.get(self._intro(inactive)).status_code, 200)

    def test_questions_are_gated_too(self):
        url = reverse(
            "jeiko_client_questionnaires_expert:test_question",
            kwargs={"slug": self.test.slug, "position": 0},
        )
        self.assertEqual(self.client.get(url).status_code, 302)


class ResultTokenTests(TestCase):

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="T", slug="t")
        cls.profile = ExpertProfileType.objects.create(test=cls.test, name="A")
        cls.data = ExpertTestData.objects.create(
            test=cls.test, result_profile=cls.profile,
            data={"scores": [{"name": "A", "score": 3, "color": "#fff"}]},
        )
        cls.other = ExpertTestData.objects.create(
            test=cls.test, result_profile=cls.profile,
            data={"scores": [{"name": "A", "score": 99, "color": "#000"}]},
        )

    def test_tokens_are_unique(self):
        self.assertNotEqual(self.data.public_token, self.other.public_token)

    def test_result_url_uses_the_token(self):
        self.assertIn(str(self.data.public_token), self.data.get_result_url())

    def test_unknown_token_is_404(self):
        url = reverse(
            "jeiko_client_questionnaires_expert:test_result_token",
            kwargs={"token": "00000000-0000-0000-0000-000000000000"},
        )
        self.assertEqual(self.client.get(url).status_code, 404)

    def test_token_page_shows_its_own_scores_not_the_latest(self):
        """Régression : la page servait le dernier résultat du test, tous visiteurs confondus."""
        response = self.client.get(self.data.get_result_url())
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["test_data"], self.data)
        self.assertIn("3.0", response.context["chart_data_json"])
        self.assertNotIn("99", response.context["chart_data_json"])


class FullRunTests(TestCase):
    """Parcours complet : questions → coordonnées → page de résultat."""

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="Parcours", slug="parcours")
        cls.winner = ExpertProfileType.objects.create(test=cls.test, name="Gagnant")
        cls.loser = ExpertProfileType.objects.create(test=cls.test, name="Perdant")

        cls.question = ExpertQuestion.objects.create(test=cls.test, text="Q1", order=0)
        cls.answer = ExpertAnswer.objects.create(question=cls.question, text="A1", order=0)
        ExpertAnswerProfileWeight.objects.create(
            answer=cls.answer, profile_type=cls.winner, weight=5
        )

        combination = ExpertProfileCombination.objects.create(
            test=cls.test, parent_profile=cls.winner, title="Gagne"
        )
        ExpertProfileCriterion.objects.create(
            combination=combination, profile_a=cls.winner, profile_b=cls.loser, comparison='>'
        )

    def _answer_all(self, client=None):
        client = client or self.client
        client.post(
            reverse("jeiko_client_questionnaires_expert:test_question",
                    kwargs={"slug": self.test.slug, "position": 0}),
            {"answer": str(self.answer.id)},
        )

    def _submit(self, client=None, **overrides):
        client = client or self.client
        payload = {
            "firstname": "Ada", "lastname": "Lovelace",
            "email": "ada@example.com", "phone": "0600000000",
            "consent": "on",
        }
        payload.update(overrides)
        return client.post(
            reverse("jeiko_client_questionnaires_expert:test_result_input",
                    kwargs={"slug": self.test.slug}),
            payload,
        )

    def test_run_creates_result_and_redirects_to_its_token(self):
        self._answer_all()
        response = self._submit()

        test_data = ExpertTestData.objects.get(test=self.test)
        self.assertEqual(test_data.result_profile, self.winner)
        self.assertEqual(test_data.data["scores"][0]["score"], 5)

        # La redirection porte le jeton du résultat qui vient d'être créé
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, test_data.get_result_url())

        # Le prospect est rattaché et sa date de dernier test renseignée
        prospect = Prospect.objects.get(email="ada@example.com")
        self.assertEqual(test_data.prospect, prospect)
        self.assertIsNotNone(prospect.last_test_date)

        # Et la page de résultat est consultable sans être connecté
        self.assertEqual(self.client.get(response.url).status_code, 200)

    def test_authenticated_user_result_is_saved(self):
        user = User.objects.create_user("ada", "ada@example.com", "pwd")
        self.client.force_login(user)

        self._answer_all()
        response = self.client.post(
            reverse("jeiko_client_questionnaires_expert:test_result_input",
                    kwargs={"slug": self.test.slug}),
            {},  # connecté : le template ne poste qu'un bouton
        )

        self.assertEqual(ExpertTestData.objects.count(), 1)
        test_data = ExpertTestData.objects.get()
        self.assertEqual(test_data.user, user)
        self.assertIsNone(test_data.prospect)
        self.assertEqual(test_data.result_profile, self.winner)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, test_data.get_result_url())

    def test_consent_is_required(self):
        self._answer_all()
        response = self._submit(consent="")
        self.assertEqual(response.status_code, 200)  # formulaire réaffiché
        self.assertFalse(ExpertTestData.objects.exists())
        self.assertFalse(Prospect.objects.exists())

    def test_invalid_payload_does_not_crash_nor_persist(self):
        """Régression : un POST sans firstname levait une IntegrityError."""
        self._answer_all()
        response = self._submit(firstname="", email="pas-un-email")
        self.assertEqual(response.status_code, 200)
        self.assertFalse(ExpertTestData.objects.exists())

    def test_direct_post_without_answers_is_sent_back_to_the_questions(self):
        response = self._submit()
        self.assertEqual(response.status_code, 302)
        self.assertIn("/question/0/", response.url)
        self.assertFalse(ExpertTestData.objects.exists())

    def test_forged_answer_id_is_ignored(self):
        """Régression : une valeur non numérique remontait au scoring et levait ValueError."""
        url = reverse("jeiko_client_questionnaires_expert:test_question",
                      kwargs={"slug": self.test.slug, "position": 0})
        response = self.client.post(url, {"answer": "'; DROP TABLE--"})
        # Rejeté : on reste sur la question au lieu d'avancer
        self.assertEqual(response.status_code, 302)
        self.assertIn("/question/0/", response.url)

    def test_answer_from_another_question_is_rejected(self):
        other = ExpertQuestion.objects.create(test=self.test, text="Q2", order=1)
        foreign = ExpertAnswer.objects.create(question=other, text="A2", order=0)

        url = reverse("jeiko_client_questionnaires_expert:test_question",
                      kwargs={"slug": self.test.slug, "position": 0})
        response = self.client.post(url, {"answer": str(foreign.id)})
        self.assertIn("/question/0/", response.url)

    def test_answers_are_scoped_per_test(self):
        """Régression : les réponses d'un test validaient le suivant."""
        other_test = ExpertTest.objects.create(title="Autre", slug="autre")
        ExpertQuestion.objects.create(test=other_test, text="Autre Q", order=0)

        self._answer_all()  # on répond intégralement au premier test

        # Le second test doit rester incomplet et renvoyer à sa propre question
        response = self.client.post(
            reverse("jeiko_client_questionnaires_expert:test_result_input",
                    kwargs={"slug": other_test.slug}),
            {"firstname": "A", "lastname": "B", "email": "a@b.c", "consent": "on"},
        )
        self.assertEqual(response.status_code, 302)
        self.assertIn("/autre/question/0/", response.url)
        self.assertFalse(ExpertTestData.objects.filter(test=other_test).exists())

    def test_inactive_questions_are_skipped(self):
        ExpertQuestion.objects.create(test=self.test, text="Désactivée", order=1, is_active=False)

        response = self.client.get(
            reverse("jeiko_client_questionnaires_expert:test_question",
                    kwargs={"slug": self.test.slug, "position": 0})
        )
        self.assertEqual(response.context["total"], 1)

        # Répondre à l'unique question active suffit à terminer le test
        self._answer_all()
        self.assertEqual(self._submit().status_code, 302)

    def test_inactive_answers_are_not_offered_nor_scored(self):
        dead = ExpertAnswer.objects.create(
            question=self.question, text="Obsolète", order=1, is_active=False
        )
        ExpertAnswerProfileWeight.objects.create(
            answer=dead, profile_type=self.loser, weight=99
        )

        response = self.client.get(
            reverse("jeiko_client_questionnaires_expert:test_question",
                    kwargs={"slug": self.test.slug, "position": 0})
        )
        self.assertNotIn(dead, response.context["answers"])

        # Et son poids ne peut pas être injecté via un POST forgé
        url = reverse("jeiko_client_questionnaires_expert:test_question",
                      kwargs={"slug": self.test.slug, "position": 0})
        self.client.post(url, {"answer": str(dead.id)})
        self.assertIn("/question/0/", self.client.post(url, {"answer": str(dead.id)}).url)


class QuestionnairePermissionTests(TestCase):
    """
    Les vues d'admin exigent des permissions `*_questionnaire` que rien ne
    créait : le back-office était de fait réservé aux superusers.
    """

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="T", slug="t")
        cls.staff = User.objects.create_user("s", "s@example.com", "pwd", is_staff=True)

    def test_permissions_exist(self):
        for codename in ("view_questionnaire", "add_questionnaire",
                         "change_questionnaire", "delete_questionnaire"):
            self.assertTrue(
                Permission.objects.filter(codename=codename).exists(),
                f"permission {codename} absente",
            )

    def test_staff_without_permission_is_refused(self):
        self.client.force_login(self.staff)
        response = self.client.get(
            reverse("jeiko_administration_questionnaires_expert:test_list")
        )
        self.assertEqual(response.status_code, 403)

    def test_granted_staff_can_access_without_being_superuser(self):
        self.staff.user_permissions.add(
            Permission.objects.get(codename="view_questionnaire")
        )
        self.client.force_login(self.staff)
        response = self.client.get(
            reverse("jeiko_administration_questionnaires_expert:test_list")
        )
        self.assertEqual(response.status_code, 200)


class TestDetailPageTests(TestCase):
    """La page qui liste les questions doit se rendre avec toutes ses actions."""

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="T", slug="t")
        cls.active = ExpertQuestion.objects.create(test=cls.test, text="Active ?", order=0)
        cls.inactive = ExpertQuestion.objects.create(
            test=cls.test, text="Inactive ?", order=1, is_active=False
        )
        ExpertAnswer.objects.create(question=cls.active, text="Oui", order=0)
        cls.admin = User.objects.create_superuser("root", "root@example.com", "pwd")

    def test_page_renders_with_state_and_actions(self):
        self.client.force_login(self.admin)
        response = self.client.get(
            reverse("jeiko_administration_questionnaires_expert:test_detail",
                    args=[self.test.id])
        )
        self.assertEqual(response.status_code, 200)
        html = response.content.decode()

        self.assertIn("question-row", html)
        self.assertIn("question-actions", html)
        self.assertIn("badge-active", html)
        self.assertIn("badge-inactive", html)
        self.assertIn(
            reverse("jeiko_administration_questionnaires_expert:question_toggle_active",
                    args=[self.active.id]),
            html,
        )


class TestResultsListTests(TestCase):
    """
    Les passages d'utilisateurs connectés doivent être visibles depuis le
    module questionnaires, pas seulement depuis la fiche utilisateur.
    """

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="T", slug="t")
        cls.profile = ExpertProfileType.objects.create(test=cls.test, name="P")
        cls.member = User.objects.create_user("ada", "ada@example.com", "pwd")
        cls.prospect = Prospect.objects.create(
            firstname="Bob", lastname="M", email="bob@example.com", phone=""
        )
        ExpertTestData.objects.create(test=cls.test, user=cls.member, result_profile=cls.profile)
        ExpertTestData.objects.create(test=cls.test, prospect=cls.prospect, result_profile=cls.profile)
        ExpertTestData.objects.create(test=cls.test, result_profile=cls.profile)  # anonyme
        cls.admin = User.objects.create_superuser("root", "root@example.com", "pwd")

    def test_lists_every_kind_of_run(self):
        self.client.force_login(self.admin)
        response = self.client.get(
            reverse("jeiko_administration_questionnaires_expert:test_results",
                    args=[self.test.id])
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["total_count"], 3)
        self.assertEqual(response.context["user_count"], 1)
        self.assertEqual(response.context["prospect_count"], 1)

        html = response.content.decode()
        self.assertIn("ada@example.com", html)   # utilisateur connecté
        self.assertIn("bob@example.com", html)   # prospect

    def test_only_shows_the_current_test(self):
        other = ExpertTest.objects.create(title="Autre", slug="autre")
        ExpertTestData.objects.create(test=other, user=self.member)

        self.client.force_login(self.admin)
        response = self.client.get(
            reverse("jeiko_administration_questionnaires_expert:test_results",
                    args=[self.test.id])
        )
        self.assertEqual(response.context["total_count"], 3)


class DedupeTests(TestCase):
    """La déduplication reste disponible, mais plus en GET."""

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="T", slug="t")
        cls.admin = User.objects.create_superuser("root", "root@example.com", "pwd")
        for text in ("Quelle est votre couleur ?", "quelle  est votre couleur?", "Autre"):
            ExpertQuestion.objects.create(test=cls.test, text=text, order=0)

    def test_get_is_not_allowed(self):
        self.client.force_login(self.admin)
        url = reverse("jeiko_administration_questionnaires_expert:question_dedupe",
                      args=[self.test.id])
        self.assertEqual(self.client.get(url).status_code, 405)
        self.assertEqual(self.test.questions.count(), 3)

    def test_post_removes_normalized_duplicates(self):
        self.client.force_login(self.admin)
        url = reverse("jeiko_administration_questionnaires_expert:question_dedupe",
                      args=[self.test.id])
        self.client.post(url)
        self.assertEqual(self.test.questions.count(), 2)


class QuestionToggleTests(TestCase):

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="T", slug="t")
        cls.question = ExpertQuestion.objects.create(test=cls.test, text="Q", order=0)
        cls.admin = User.objects.create_superuser("root", "root@example.com", "pwd")

    def test_questions_are_active_by_default(self):
        self.assertTrue(self.question.is_active)

    def test_toggle_switches_state(self):
        self.client.force_login(self.admin)
        url = reverse("jeiko_administration_questionnaires_expert:question_toggle_active",
                      args=[self.question.id])

        self.client.post(url)
        self.question.refresh_from_db()
        self.assertFalse(self.question.is_active)

        self.client.post(url)
        self.question.refresh_from_db()
        self.assertTrue(self.question.is_active)

    def test_toggle_rejects_get(self):
        self.client.force_login(self.admin)
        url = reverse("jeiko_administration_questionnaires_expert:question_toggle_active",
                      args=[self.question.id])
        self.assertEqual(self.client.get(url).status_code, 405)


class TestStyleFormTests(TestCase):
    """Régression : le formulaire effaçait les clés qu'il n'exposait pas."""

    def test_save_preserves_every_schema_key(self):
        test = ExpertTest.objects.create(title="T", slug="t")
        style = ExpertTestStyle.objects.create(test=test)

        payload = {k: v for k, v in DEFAULT_TEST_STYLE.items()}
        payload["submit_font_size_px"] = 26
        payload["submit_radius_px"] = 8

        form = ExpertTestStyleForm(payload, instance=style)
        self.assertTrue(form.is_valid(), form.errors)
        form.save()

        style.refresh_from_db()
        for key in DEFAULT_TEST_STYLE:
            self.assertIn(key, style.style, f"clé {key} perdue à l'enregistrement")
        self.assertEqual(style.style["submit_font_size_px"], 26)
        self.assertEqual(style.style["submit_radius_px"], 8)
        self.assertEqual(style.get_css_vars()["--q-submit-size"], "26px")


class TotalScoreTests(TestCase):
    """Le total doit correspondre aux scores restitués au visiteur."""

    def test_complex_profiles_are_excluded(self):
        test = ExpertTest.objects.create(title="T", slug="t")
        simple = ExpertProfileType.objects.create(test=test, name="Simple")
        complexe = ExpertProfileType.objects.create(test=test, name="Complexe", is_complex=True)

        total = compute_total_score(test, {simple.id: 4, complexe.id: 100})
        self.assertEqual(total, 4)


class LastTestDateTests(TestCase):
    """
    Régression : last_test_date restait figée quand les résultats étaient
    supprimés autrement que par instance.delete().
    """

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="T", slug="t")

    def _prospect_with_result(self):
        prospect = Prospect.objects.create(
            firstname="A", lastname="B", email="a@b.c", phone=""
        )
        ExpertTestData.objects.create(test=self.test, prospect=prospect)
        prospect.refresh_from_db()
        return prospect

    def test_date_is_set_on_creation(self):
        prospect = self._prospect_with_result()
        self.assertIsNotNone(prospect.last_test_date)

    def test_date_is_cleared_on_queryset_delete(self):
        prospect = self._prospect_with_result()
        ExpertTestData.objects.filter(prospect=prospect).delete()
        prospect.refresh_from_db()
        self.assertIsNone(prospect.last_test_date)

    def test_date_is_cleared_when_the_test_is_deleted_in_cascade(self):
        prospect = self._prospect_with_result()
        self.test.delete()
        prospect.refresh_from_db()
        self.assertIsNone(prospect.last_test_date)


class ProspectMergeTests(TestCase):
    """Une fiche vérifiée ne doit pas pouvoir être détournée par un tiers."""

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="T", slug="t")
        cls.question = ExpertQuestion.objects.create(test=cls.test, text="Q", order=0)
        cls.answer = ExpertAnswer.objects.create(question=cls.question, text="A", order=0)

    def _run(self, email):
        self.client.post(
            reverse("jeiko_client_questionnaires_expert:test_question",
                    kwargs={"slug": self.test.slug, "position": 0}),
            {"answer": str(self.answer.id)},
        )
        return self.client.post(
            reverse("jeiko_client_questionnaires_expert:test_result_input",
                    kwargs={"slug": self.test.slug}),
            {"firstname": "X", "lastname": "Y", "email": email, "consent": "on"},
        )

    def test_unverified_prospect_is_reused(self):
        existing = Prospect.objects.create(
            firstname="Ada", lastname="L", email="ada@example.com", phone=""
        )
        self._run("ada@example.com")
        self.assertEqual(Prospect.objects.filter(email="ada@example.com").count(), 1)
        self.assertEqual(ExpertTestData.objects.get().prospect, existing)

    def test_verified_prospect_is_never_hijacked(self):
        verified = Prospect.objects.create(
            firstname="Ada", lastname="L", email="ada@example.com",
            phone="", email_verified=True,
        )
        self._run("ADA@example.com")  # même adresse, casse différente

        self.assertEqual(Prospect.objects.filter(email__iexact="ada@example.com").count(), 2)
        attached = ExpertTestData.objects.get().prospect
        self.assertNotEqual(attached, verified)
        self.assertFalse(attached.email_verified)

    def test_email_is_verified_by_opening_the_emailed_link(self):
        self._run("ada@example.com")
        test_data = ExpertTestData.objects.get()
        prospect = test_data.prospect
        self.assertFalse(prospect.email_verified)

        # La redirection post-soumission ne porte pas la signature : pas de vérification
        self.client.get(test_data.get_result_url())
        prospect.refresh_from_db()
        self.assertFalse(prospect.email_verified)

        # Le lien reçu par email, lui, la porte
        self.client.get(test_data.get_result_url(confirm=True))
        prospect.refresh_from_db()
        self.assertTrue(prospect.email_verified)

    def test_forged_confirmation_signature_is_rejected(self):
        self._run("ada@example.com")
        test_data = ExpertTestData.objects.get()
        self.client.get(f"{test_data.get_result_url()}?c=nimportequoi")
        test_data.prospect.refresh_from_db()
        self.assertFalse(test_data.prospect.email_verified)
