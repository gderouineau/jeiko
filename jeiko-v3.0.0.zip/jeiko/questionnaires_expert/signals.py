# jeiko/questionnaires_expert/signals.py
from django.db.models.signals import post_delete, post_save
from django.dispatch import receiver

from .models import ExpertTestData, refresh_prospect_last_test_date


@receiver(post_save, sender=ExpertTestData, dispatch_uid="questionnaires_expert.last_test_date_save")
def update_last_test_date_on_save(sender, instance, **kwargs):
    refresh_prospect_last_test_date(instance.prospect_id)


@receiver(post_delete, sender=ExpertTestData, dispatch_uid="questionnaires_expert.last_test_date_delete")
def update_last_test_date_on_delete(sender, instance, **kwargs):
    # post_delete est aussi émis pour les suppressions en cascade et pour
    # queryset.delete(), contrairement à un override de Model.delete().
    refresh_prospect_last_test_date(instance.prospect_id)
