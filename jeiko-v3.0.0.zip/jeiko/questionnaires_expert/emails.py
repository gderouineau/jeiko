"""
Emails du module questionnaires_expert.

PROVISOIRE — le contenu et la mise en forme des messages ont vocation à être
repris par la future bibliothèque de modèles d'emails éditables en back-office.
Tout est volontairement regroupé ici, en texte brut, pour que le remplacement
se limite à ce fichier : les vues n'appellent que `send_test_result_email()` et
`send_admin_test_notification()`.
"""

import logging

from django.utils import timezone

from jeiko.administration.models import MailSettings

logger = logging.getLogger(__name__)


def _active_mail_settings():
    return (
        MailSettings.objects
        .filter(active=True)
        .select_related('website')
        .first()
    )


def _site_name(mail_settings):
    website = getattr(mail_settings, 'website', None)
    return getattr(getattr(website, 'identity', None), 'name', None) or "Votre site"


def send_test_result_email(test_data, request=None):
    """
    Envoie à la personne ayant passé le test le lien vers sa page de résultat.

    Retourne (success: bool, error: str|None). N'élève jamais d'exception :
    un échec d'envoi ne doit pas faire perdre le résultat au visiteur.
    """
    from jeiko.administration.emailing import send_simple_email

    recipient = test_data.recipient_email
    if not recipient:
        return False, "Aucune adresse email pour ce résultat"

    mail_settings = _active_mail_settings()
    if not mail_settings:
        return False, "Aucune configuration email active"

    site_name = _site_name(mail_settings)
    # confirm=True : ce lien-ci porte la signature qui vaut vérification de
    # l'adresse. Il ne doit apparaître que dans le message envoyé au titulaire.
    result_url = test_data.get_result_absolute_url(request, confirm=True)
    profile = test_data.result_profile

    greeting = f"Bonjour {test_data.recipient_name}," if test_data.recipient_name else "Bonjour,"
    body_lines = [
        greeting,
        "",
        f"Merci d'avoir passé le questionnaire « {test_data.test.title} » sur {site_name}.",
        "",
    ]
    if profile:
        body_lines += [f"Votre profil : {profile.name}", ""]
    body_lines += [
        "Vous pouvez consulter votre résultat détaillé à tout moment via ce lien :",
        result_url,
        "",
        "Conservez ce lien : il vous est personnel.",
    ]

    try:
        return send_simple_email(
            subject=f"Votre résultat · {test_data.test.title}",
            body="\n".join(body_lines),
            to_recipients=[recipient],
        )
    except Exception as exc:
        logger.exception("Échec de l'envoi du résultat #%s à %s", test_data.pk, recipient)
        return False, str(exc)


def send_admin_test_notification(test_data, request=None):
    """
    Notifie l'équipe qu'un test vient d'être passé, avec le lien vers le résultat.
    Retourne (success: bool, error: str|None).
    """
    from jeiko.administration.emailing import send_simple_email

    mail_settings = _active_mail_settings()
    if not mail_settings or not mail_settings.default_from_email:
        return False, "Aucune configuration email active"

    # reply_to_email est optionnel : on ne veut pas d'un destinataire vide
    recipients = [
        email for email in (mail_settings.reply_to_email, mail_settings.default_from_email)
        if email
    ]
    if not recipients:
        return False, "Aucun destinataire administrateur configuré"

    site_name = _site_name(mail_settings)

    if test_data.user:
        who = f"Utilisateur connecté : {test_data.recipient_name} ({test_data.user.email})"
    elif test_data.prospect:
        who = f"Prospect : {test_data.recipient_name} ({test_data.prospect.email})"
    else:
        who = "Prospect anonyme (non connecté, pas de prospect associé)"

    profile = test_data.result_profile
    body_lines = [
        f"Un test vient d'être passé sur {site_name}.",
        "",
        f"Test : {test_data.test.title}",
        f"Date : {timezone.localtime(test_data.created_at).strftime('%d/%m/%Y %H:%M')}",
        who,
        "",
        f"Profil dominant : {profile.name if profile else 'N/A'}",
        "",
        f"Résultat : {test_data.get_result_absolute_url(request)}",
    ]

    try:
        return send_simple_email(
            subject=f"Nouveau test passé : {test_data.test.title} [{site_name}]",
            body="\n".join(body_lines),
            to_recipients=recipients,
        )
    except Exception as exc:
        logger.exception("Échec de la notification admin pour le résultat #%s", test_data.pk)
        return False, str(exc)
