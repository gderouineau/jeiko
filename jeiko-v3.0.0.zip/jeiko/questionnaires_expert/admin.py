from django.contrib import admin

from jeiko.questionnaires_expert.models import (
    ExpertProfileType, ExpertTest, ExpertQuestion, ExpertAnswer,
    ExpertProfileCombination, ExpertProfileCriterion,
    ExpertAnswerProfileWeight, ExpertTestStyle, UserTestAccess,
    Prospect, ExpertTestData,
)


@admin.register(ExpertTest)
class ExpertTestAdmin(admin.ModelAdmin):
    list_display = ('title', 'slug', 'is_active', 'is_restricted')
    list_filter = ('is_active', 'is_restricted')
    search_fields = ('title', 'slug')
    prepopulated_fields = {'slug': ('title',)}


@admin.register(ExpertQuestion)
class ExpertQuestionAdmin(admin.ModelAdmin):
    list_display = ('text', 'test', 'order', 'question_type', 'is_active')
    list_filter = ('test', 'is_active', 'question_type')
    search_fields = ('text',)


@admin.register(ExpertAnswer)
class ExpertAnswerAdmin(admin.ModelAdmin):
    list_display = ('text', 'question', 'order', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('text',)


@admin.register(ExpertProfileType)
class ExpertProfileTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'test', 'is_complex', 'is_score_profile', 'min_score', 'max_score')
    list_filter = ('test', 'is_complex', 'is_score_profile')
    search_fields = ('name', 'slug')


@admin.register(ExpertProfileCombination)
class ExpertProfileCombinationAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'test', 'parent_profile', 'preferred_profile', 'alternative_profile')
    list_filter = ('test',)


@admin.register(ExpertProfileCriterion)
class ExpertProfileCriterionAdmin(admin.ModelAdmin):
    list_display = ('combination', 'profile_a', 'comparison', 'profile_b', 'tolerance', 'priority')
    list_filter = ('comparison',)


@admin.register(UserTestAccess)
class UserTestAccessAdmin(admin.ModelAdmin):
    list_display = ('user', 'test', 'source', 'granted_at', 'granted_by')
    list_filter = ('source', 'test')
    search_fields = ('user__username', 'user__email')
    autocomplete_fields = ('user', 'test', 'granted_by')


@admin.register(Prospect)
class ProspectAdmin(admin.ModelAdmin):
    list_display = ('lastname', 'firstname', 'email', 'email_verified', 'last_test_date')
    list_filter = ('email_verified',)
    search_fields = ('firstname', 'lastname', 'email')
    readonly_fields = ('date_created', 'last_test_date')


@admin.register(ExpertTestData)
class ExpertTestDataAdmin(admin.ModelAdmin):
    list_display = ('test', 'prospect', 'user', 'result_profile', 'created_at')
    list_filter = ('test', 'created_at')
    search_fields = ('prospect__email', 'user__email')
    readonly_fields = ('public_token', 'created_at')


admin.site.register(ExpertAnswerProfileWeight)
admin.site.register(ExpertTestStyle)
