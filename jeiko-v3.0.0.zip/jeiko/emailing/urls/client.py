from django.urls import path
from jeiko.emailing.views import client as client_views

app_name = "jeiko_client_emailing"

urlpatterns = []