# jeiko/emailing/render.py
"""
Rendu e-mail d'une Page d'administration_pages.

Le rendu web (administration_pages/partials_client + styles) produit du CSS Grid,
des sélecteurs `#section-42` dans des balises <style>, des media queries et des
fonds en <img> absolus : rien de tout cela ne survit à Outlook ni au client Gmail.

Ce module parcourt le MÊME arbre d'objets et émet la forme que les clients mail
savent lire — des <table> imbriquées, des largeurs en pourcentage et des styles
inline. Il ne modifie rien du rendu web, qui reste seul responsable du site.

Différences assumées avec le rendu web :
  - seules les valeurs `_computer` sont lues (un e-mail ne fait pas de responsive
    par device, il fait 600 px et s'empile) ;
  - animations, bordures dynamiques, CSS custom et images de fond sont ignorés ;
  - seuls quatre types de contenu sont rendus (voir SUPPORTED_CONTENT_TYPES).
"""

import re
from html import unescape

from django.conf import settings
from django.template.loader import render_to_string
from django.utils.safestring import mark_safe

from jeiko.emailing.models import render_tags

# Largeur canonique d'un e-mail. Au-delà, Outlook et les webmails coupent.
EMAIL_WIDTH = 600

# Types de contenu rendus. Le reste (vidéo, calendrier, formulaire, carrousel,
# accordéon, countdown…) repose sur du JavaScript ou du CSS moderne : sans objet
# dans une boîte de réception.
SUPPORTED_CONTENT_TYPES = {"TEXT", "TEXT_QUESTIONNAIRE", "IMAGE", "BUTTON"}

CONTENT_TYPE_LABELS = {
    "TEXT": "Texte",
    "TEXT_QUESTIONNAIRE": "Texte avec balises",
    "IMAGE": "Image",
    "BUTTON": "Bouton",
}


# =========================
#  Contexte du site
# =========================

def _website():
    from jeiko.administration.models import WebSite
    return (
        WebSite.objects
        .select_related("identity", "logo", "fonts_computer", "fonts_computer__text")
        .first()
    )


def site_base_url():
    """Racine absolue du site, indispensable : un /media/... relatif ne s'affiche pas en mail."""
    site = _website()
    identity = getattr(site, "identity", None)

    url = (getattr(identity, "url", "") or "").strip()
    if not url:
        url = (getattr(settings, "SITE_URL", "") or "").strip()

    return url.rstrip("/")


def absolute_url(url):
    """Rend une URL absolue si elle ne l'est pas déjà."""
    if not url:
        return ""

    url = str(url)
    if url.startswith(("http://", "https://", "mailto:", "tel:", "data:")):
        return url

    base = site_base_url()
    if not base:
        return url

    return f"{base}/{url.lstrip('/')}"


def _logo_url(site):
    logo = getattr(site, "logo", None)
    if not logo:
        return ""

    for field in ("computer_size", "full_size", "tablet_size", "mobile_size"):
        image = getattr(logo, field, None)
        if image and getattr(image, "name", ""):
            return absolute_url(image.url)

    return ""


def base_font_css():
    """
    Police du site, en piochant dans Fonts.text.

    Les webfonts ne se chargent ni sous Gmail ni sous Outlook : c'est le
    `fallback` du modèle Font qui sera vu par la majorité des destinataires.
    """
    site = _website()
    fonts = getattr(site, "fonts_computer", None)
    font = getattr(fonts, "text", None)

    if not font:
        return "font-family:Georgia,serif;font-size:16px;line-height:1.5;color:#333333;"

    family = (font.family or "Georgia").strip()
    fallback = (font.fallback or "serif").strip()
    quoted = f"'{family}'" if " " in family else family

    return (
        f"font-family:{quoted},{fallback};"
        f"font-size:{font.size or '16px'};"
        f"line-height:{font.line_height or '1.5'};"
        f"color:{font.color or '#333333'};"
    )


def site_context():
    """Éléments d'identité injectés dans la mise en page de l'e-mail."""
    site = _website()
    identity = getattr(site, "identity", None)

    return {
        "site_name": getattr(identity, "name", None) or getattr(site, "name", None) or "",
        "site_url": site_base_url(),
        "logo_url": _logo_url(site),
        "contact_email": "",
        "contact_tel": getattr(identity, "telephone", "") or "",
        "base_font": base_font_css(),
    }


# =========================
#  Styles inline
# =========================

def _box(stylebox):
    """StyleBox -> 'haut droite bas gauche', normalisé (les valeurs nues sont en px)."""
    if not stylebox:
        return None

    values = []
    for side in ("top", "right", "bottom", "left"):
        value = str(getattr(stylebox, side, "") or "0").strip()
        if value.isdigit():
            value = f"{value}px"
        values.append(value or "0")

    if all(value in ("0", "0px") for value in values):
        return None

    return " ".join(values)


def _color(value):
    """Ignore les couleurs totalement transparentes, qu'Outlook rend en noir."""
    value = (value or "").strip()
    if not value:
        return ""
    if value.replace(" ", "").endswith(",0)"):
        return ""
    return value


def element_style(element, include_margin=True):
    """
    Padding, marge et couleur de fond d'un Section/Line/Bloc, en version desktop.

    Les marges d'un e-mail sont peu fiables sur <td> : elles sont converties en
    padding par les appelants quand c'est nécessaire.
    """
    if not element:
        return ""

    parts = []

    padding = _box(getattr(element, "padding_computer", None))
    if padding:
        parts.append(f"padding:{padding};")

    if include_margin:
        margin = _box(getattr(element, "margin_computer", None))
        if margin:
            parts.append(f"margin:{margin};")

    background = _color(getattr(element, "background_color", ""))
    if background:
        parts.append(f"background-color:{background};")

    return "".join(parts)


RGB_PATTERN = re.compile(
    r"rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)", re.I
)


def _hex_color(value):
    """
    Convertit une couleur en forme acceptée par l'attribut `bgcolor`.

    L'éditeur stocke des `rgba(...)`, que l'attribut HTML ne sait pas lire — et
    c'est précisément cet attribut qu'Outlook utilise pour peindre un <td>, la
    déclaration CSS `background-color` étant appliquée de façon inégale.
    """
    value = _color(value)
    if not value:
        return ""

    if value.startswith("#"):
        return value

    match = RGB_PATTERN.match(value)
    if not match:
        # Couleur nommée (white, transparent…) : bgcolor les accepte telles quelles.
        return value

    red, green, blue, alpha = match.groups()
    if alpha is not None and float(alpha) == 0:
        return ""

    return "#{:02x}{:02x}{:02x}".format(int(red), int(green), int(blue))


def element_background(element):
    """Couleur de fond seule, pour l'attribut bgcolor (compatibilité Outlook)."""
    return _hex_color(getattr(element, "background_color", "")) if element else ""


def column_widths(line):
    """
    Traduit `columns_type` ('6-6', '4-4-4', '12'…) en pourcentages.

    Le rendu web fait ça en CSS Grid sur 12 colonnes ; en mail on convertit en
    largeurs de <td>, seule mise en colonnes que tous les clients comprennent.

    Les largeurs sont renvoyées en CHAÎNES. Le projet tourne en `fr-fr` : laissé
    en flottant, le gabarit écrirait width="50,0%" — une virgule décimale qu'aucun
    client mail ne sait lire, et toutes les colonnes s'effondreraient.
    """
    raw = (getattr(line, "columns_type", "") or "").strip()
    columns = getattr(line, "columns_number", 1) or 1

    parts = []
    if raw:
        for chunk in raw.split("-"):
            chunk = chunk.strip()
            if chunk.isdigit() and int(chunk) > 0:
                parts.append(int(chunk))

    if not parts:
        parts = [12 // columns] * columns if columns else [12]

    total = sum(parts) or 12
    return [f"{part * 100 / total:.4f}".rstrip("0").rstrip(".") for part in parts]


# =========================
#  Contenus
# =========================

# Quill pose l'alignement en classe (ql-align-center). Sans <style>, un client
# mail l'ignore : on le repasse en inline.
QL_ALIGN_PATTERN = re.compile(
    r'<(?P<tag>\w+)(?P<before>[^>]*?)class="(?P<classes>[^"]*?)ql-align-(?P<align>\w+)([^"]*?)"(?P<after>[^>]*?)>'
)


def _inline_quill_alignment(html):
    def replace(match):
        align = match.group("align")
        tag = match.group("tag")
        before = match.group("before")
        after = match.group("after")
        return f'<{tag}{before}{after} style="text-align:{align};">'

    return QL_ALIGN_PATTERN.sub(replace, html or "")


def _render_text(raw, context):
    return mark_safe(_inline_quill_alignment(render_tags(raw, context)))


def _image_src(content_image):
    image = getattr(content_image, "image_content", None)
    if not image:
        return ""

    # Les variantes larges sont inutiles : l'e-mail fait 600 px.
    for field in ("computer_size", "full_size", "original_image", "tablet_size", "mobile_size"):
        candidate = getattr(image, field, None)
        if candidate and getattr(candidate, "name", ""):
            return absolute_url(candidate.url)

    return ""


def button_style(button):
    """
    Style du <a> d'un bouton, repris des champs de ContentButton.

    Les états de survol, ombres, transitions et animations sont volontairement
    abandonnés : aucun client mail ne les rend de façon fiable.
    """
    background = _color(getattr(button, "background_color", "")) or "#333333"
    color = _color(getattr(button, "text_color", "")) or "#ffffff"
    padding = (getattr(button, "padding", "") or "12px 24px").strip()
    radius = (getattr(button, "border_radius", "") or "4px").strip()

    parts = [
        "display:inline-block;",
        "text-decoration:none;",
        f"background-color:{background};",
        f"color:{color};",
        f"padding:{padding};",
        f"border-radius:{radius};",
    ]

    width = (getattr(button, "border_width", "") or "").strip()
    border_color = _color(getattr(button, "border_color", ""))
    if width and border_color:
        parts.append(f"border:{width} solid {border_color};")

    for attribute, css in (
        ("font_size", "font-size"),
        ("font_weight", "font-weight"),
        ("letter_spacing", "letter-spacing"),
    ):
        value = (getattr(button, attribute, "") or "").strip()
        if value:
            parts.append(f"{css}:{value};")

    family = (getattr(button, "font_family", "") or "").strip()
    if family:
        quoted = f"'{family}'" if " " in family else family
        parts.append(f"font-family:{quoted},Arial,sans-serif;")

    transform = (getattr(button, "text_transform", "") or "").strip()
    if transform and transform != "none":
        parts.append(f"text-transform:{transform};")

    return "".join(parts)


def _bloc_payload(bloc, context, warnings):
    """Données prêtes à rendre pour un bloc, ou None si son type n'est pas supporté."""
    content = getattr(bloc, "content", None)
    if not content:
        return None

    content_type = content.content_type

    if content_type not in SUPPORTED_CONTENT_TYPES:
        if content_type != "NOT_SET":
            warnings.append(
                f"Bloc #{bloc.id} : le type « {content.get_content_type_display()} » "
                f"n'est pas rendu dans un e-mail, il a été ignoré."
            )
        return None

    if content_type == "TEXT":
        text = getattr(content, "content_text", None)
        if not text:
            return None
        return {"type": "TEXT", "html": _render_text(text.text, context)}

    if content_type == "TEXT_QUESTIONNAIRE":
        text = getattr(content, "content_text_questionnaire", None)
        if not text:
            return None
        return {"type": "TEXT", "html": _render_text(text.raw_text, context)}

    if content_type == "IMAGE":
        image = getattr(content, "content_image", None)
        if not image:
            return None
        src = _image_src(image)
        if not src:
            warnings.append(f"Bloc #{bloc.id} : image sans fichier, ignorée.")
            return None
        return {
            "type": "IMAGE",
            "src": src,
            "alt": getattr(image, "alt", "") or "",
            "title": getattr(image, "title", "") or "",
        }

    if content_type == "BUTTON":
        button = getattr(content, "content_button", None)
        if not button:
            return None
        return {
            "type": "BUTTON",
            "label": render_tags(button.label, context),
            "url": absolute_url(render_tags(button.get_url(), context)),
            "style": button_style(button),
            "target": "_blank" if button.open_in_new_tab else "",
        }

    return None


# =========================
#  Rendu
# =========================

def _build_lines(section, context, warnings):
    lines = []

    for line in section.lines.all():
        widths = column_widths(line)
        blocs = list(line.blocs.all())
        columns = []

        for index, width in enumerate(widths):
            bloc = blocs[index] if index < len(blocs) else None
            payload = _bloc_payload(bloc, context, warnings) if bloc else None

            columns.append({
                "width": width,
                "bloc": bloc,
                "payload": payload,
                "style": element_style(bloc, include_margin=False) if bloc else "",
                "bgcolor": element_background(bloc) if bloc else "",
                "align": (getattr(bloc, "horizontal_align", "") or "left") if bloc else "left",
                "valign": (getattr(bloc, "vertical_align", "") or "top") if bloc else "top",
            })

        # Une ligne dont aucune colonne n'a de contenu rendu laisserait une
        # rangée vide dans l'e-mail : on la supprime.
        if not any(column["payload"] for column in columns):
            continue

        lines.append({
            "line": line,
            "columns": columns,
            "style": element_style(line, include_margin=False),
            "bgcolor": element_background(line),
        })

    return lines


def render_page(page, context=None):
    """
    Rend une Page en HTML d'e-mail.

    Retourne (html, warnings) — les avertissements listent ce qui a été ignoré,
    pour être affichés dans l'aperçu de l'administration.
    """
    context = context or {}
    warnings = []

    if page is None:
        return "", ["Aucune page de contenu n'est rattachée à cet e-mail."]

    sections = [
        {
            "section": section,
            "lines": _build_lines(section, context, warnings),
            "style": element_style(section, include_margin=False),
            "bgcolor": element_background(section),
        }
        for section in page.sections.all()
    ]

    if not sections:
        warnings.append("La page de contenu est vide.")

    site = site_context()
    html = render_to_string("emailing/email/layout.html", {
        "sections": sections,
        "site": site,
        "email_width": EMAIL_WIDTH,
        "context_values": context,
        "unsubscribe_url": context.get("lien_desabonnement", ""),
    })

    return html, warnings


# =========================
#  Version texte
# =========================

_BLOCK_END = re.compile(r"</(p|div|tr|h[1-6]|li|table)>", re.I)
_BREAK = re.compile(r"<br\s*/?>", re.I)
_LINK = re.compile(r'<a\b[^>]*href="([^"]*)"[^>]*>(.*?)</a>', re.I | re.S)
_TAG = re.compile(r"<[^>]+>")
_BLANK_LINES = re.compile(r"\n{3,}")


def html_to_text(html):
    """
    Version texte brut d'un e-mail HTML.

    Beaucoup de clients et la plupart des filtres antispam attendent une
    alternative text/plain ; l'absence de partie texte dégrade la délivrabilité.
    """
    if not html:
        return ""

    # Ne garder que le corps : l'en-tête technique n'a rien à faire en texte.
    body = re.search(r"<body[^>]*>(.*)</body>", html, re.I | re.S)
    text = body.group(1) if body else html

    text = re.sub(r"<(script|style)\b.*?</\1>", "", text, flags=re.I | re.S)
    text = _LINK.sub(lambda m: f"{_TAG.sub('', m.group(2)).strip()} ({m.group(1)})", text)
    text = _BREAK.sub("\n", text)
    text = _BLOCK_END.sub("\n", text)
    text = _TAG.sub("", text)
    text = unescape(text)

    lines = [line.strip() for line in text.splitlines()]
    text = "\n".join(lines)

    return _BLANK_LINES.sub("\n\n", text).strip()


# =========================
#  Point d'entrée
# =========================

def render_email(email_template, context=None):
    """
    Rend un EmailTemplate complet.

    Retourne (subject, html, text, warnings).
    """
    context = context or {}

    subject = email_template.render_subject(context)
    html, warnings = render_page(email_template.page, context)
    text = html_to_text(html)

    return subject, html, text, warnings


# =========================
#  Contexte d'aperçu
# =========================

# Valeurs de démonstration pour l'aperçu et l'envoi de test. Une clé absente de
# ce tableau retombe sur un marqueur explicite, jamais sur du vide : un aperçu
# qui masque une variable non alimentée ne sert à rien.
SAMPLE_VALUES = {
    "prenom": "Camille",
    "nom": "Dupont",
    "email": "camille.dupont@exemple.fr",
    "date": "12/08/2026",
    "annee": "2026",
    "date_heure": "12/08/2026 à 14h30",
    "expiration": "24 heures",
    "code": "482913",
    "ip": "82.64.12.7",
    "appareil": "Chrome sur macOS",
    "localisation": "Paris, France",
    "motif": "Indisponibilité exceptionnelle",
    "montant": "75,00 €",
    "score": "42",
    "progression": "60 %",

    "rdv_date": "jeudi 13 août 2026",
    "rdv_heure": "14h30",
    "rdv_duree": "1h00",
    "rdv_type": "Consultation individuelle",
    "pro_nom": "Alexandra Hannat",
    "lieu": "12 rue des Lilas, 75011 Paris",
    "client_nom": "Camille Dupont",
    "client_email": "camille.dupont@exemple.fr",
    "client_tel": "06 12 34 56 78",

    "test_nom": "Bilan de personnalité",
    "profil": "Analytique",
    "formation_nom": "Les fondamentaux",
    "commande_num": "CMD-2026-0184",
    "commande_total": "129,00 €",
    "produit_nom": "Coffret découverte",
}


def sample_context(code):
    """Contexte de démonstration couvrant toutes les variables d'un événement."""
    from jeiko.emailing import registry

    site = site_context()
    base = site["site_url"] or "https://exemple.fr"

    # Valeurs réelles du site : elles priment sur les valeurs de démonstration,
    # sinon l'aperçu afficherait ‹site_nom› alors que la donnée est connue.
    known = {
        "site_nom": site["site_name"],
        "site_url": site["site_url"],
        "logo_url": site["logo_url"],
        "contact_tel": site["contact_tel"],
    }

    context = {}
    for variable in registry.available_variables(code):
        key = variable["key"]

        if known.get(key):
            context[key] = known[key]
        elif key in SAMPLE_VALUES:
            context[key] = SAMPLE_VALUES[key]
        elif key.startswith("lien_") or key.endswith("_url"):
            context[key] = f"{base}/#{key}"
        elif key.startswith("bloc_"):
            context[key] = f"[ {key} — contenu généré à l'envoi ]"
        else:
            context[key] = f"‹{key}›"

    return context
