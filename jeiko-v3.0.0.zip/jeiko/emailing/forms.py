# jeiko/emailing/forms.py
from django import forms

from jeiko.emailing.models import EmailTemplate, extract_tags


class EmailTemplateForm(forms.ModelForm):
    """
    Édition d'un modèle d'e-mail. Le sujet accepte les variables [%cle%] ;
    celles qui ne sont pas déclarées par l'événement sont refusées, pour éviter
    qu'un [%prenon%] parte tel quel dans une boîte de réception.
    """

    class Meta:
        model = EmailTemplate
        fields = ["subject", "active", "from_email", "reply_to_email"]
        widgets = {
            "subject": forms.TextInput(attrs={
                "class": "form-control",
                "id": "id_subject",
                "placeholder": "[%site_nom%] — Votre rendez-vous du [%rdv_date%]",
                "autocomplete": "off",
            }),
            "from_email": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Par défaut : expéditeur de la configuration mail",
            }),
            "reply_to_email": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "Par défaut : adresse de réponse de la configuration mail",
            }),
        }

    def clean_subject(self):
        subject = (self.cleaned_data.get("subject") or "").strip()

        if not subject:
            raise forms.ValidationError("Le sujet ne peut pas être vide.")

        allowed = self.instance.variable_keys()
        unknown = sorted(extract_tags(subject) - allowed)
        if unknown:
            raise forms.ValidationError(
                "Variable(s) inconnue(s) pour cet e-mail : %(keys)s. "
                "Consulte la liste des clés disponibles ci-dessous.",
                params={"keys": ", ".join(f"[%{key}%]" for key in unknown)},
            )

        return subject
