# jeiko/emailing/views/admin.py
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views import View

from jeiko.emailing import registry, render as email_render
from jeiko.emailing.forms import EmailTemplateForm
from jeiko.emailing.models import EmailTemplate

# Réutilise la permission des réglages email tant que l'app n'a pas les siennes.
EMAILING_PERMISSION = "users.admincfg_change_mailsettings"


class EmailTemplateListView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """Catalogue des e-mails, groupé par catégorie."""

    template_name = "emailing/admin/template_list.html"
    permission_required = EMAILING_PERMISSION

    def get(self, request):
        templates_by_code = {t.code: t for t in EmailTemplate.objects.select_related("page")}

        categories = []
        for key, label, events in registry.events_by_category():
            rows = [
                {
                    "code": code,
                    "event": event,
                    "audience_label": registry.AUDIENCE_LABELS.get(event["audience"], ""),
                    "template": templates_by_code.get(code),
                }
                for code, event in events
            ]
            categories.append({
                "key": key,
                "label": label,
                "rows": rows,
                "configured": sum(1 for row in rows if row["template"]),
                "total": len(rows),
            })

        # Templates dont le code a disparu du catalogue.
        orphans = [t for t in templates_by_code.values() if t.is_orphan]

        return render(request, self.template_name, {
            "categories": categories,
            "orphans": orphans,
            "total_events": len(registry.EMAIL_EVENTS),
            "total_configured": sum(1 for t in templates_by_code.values() if not t.is_orphan),
        })


class EmailTemplateUpdateView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Édition du sujet et des réglages d'envoi d'un e-mail.

    Le template est créé à la volée au premier accès : le catalogue fait foi,
    la base ne stocke que ce qui a été personnalisé.
    """

    template_name = "emailing/admin/template_form.html"
    permission_required = EMAILING_PERMISSION

    def get_object(self, code):
        event = registry.get_event(code)
        if event is None:
            # Code hors catalogue : on n'édite que ce qui existe déjà en base.
            return get_object_or_404(EmailTemplate, code=code)

        template, _ = EmailTemplate.objects.get_or_create(
            code=code,
            defaults={"subject": f"[%site_nom%] — {event['label']}"},
        )
        return template

    def get_context(self, template, form):
        context = email_render.sample_context(template.code)
        _, warnings = email_render.render_page(template.page, context)

        return {
            "template": template,
            "form": form,
            "variables": template.available_variables(),
            "is_transactional": registry.is_transactional(template.code),
            "preview_subject": template.render_subject(context),
            "preview_warnings": warnings,
            "preview_url": reverse(
                "jeiko_administration_emailing:template_preview",
                args=[template.code],
            ),
        }

    def get(self, request, code):
        template = self.get_object(code)
        form = EmailTemplateForm(instance=template)
        return render(request, self.template_name, self.get_context(template, form))

    def post(self, request, code):
        template = self.get_object(code)
        form = EmailTemplateForm(request.POST, instance=template)

        if form.is_valid():
            form.save()
            messages.success(request, "Modèle d'e-mail enregistré.")
            return redirect(reverse("jeiko_administration_emailing:template_edit", args=[code]))

        return render(request, self.template_name, self.get_context(template, form))


class EmailTemplatePreviewView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Rendu e-mail brut, destiné à être affiché dans une iframe.

    Indispensable : l'éditeur visuel montre le rendu web (grille CSS, media
    queries), pas ce qui sera réellement envoyé.
    """

    permission_required = EMAILING_PERMISSION

    def get(self, request, code):
        template = get_object_or_404(EmailTemplate, code=code)
        context = email_render.sample_context(code)
        html, _ = email_render.render_page(template.page, context)

        if not html:
            html = (
                "<!DOCTYPE html><html><body "
                "style=\"font-family:Arial,sans-serif;padding:24px;color:#888;\">"
                "Aucun contenu à afficher.</body></html>"
            )

        return HttpResponse(html)
