# jeiko/emailing/apps.py
from django.apps import AppConfig

class EmailingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "jeiko.emailing"

    def ready(self):

        from . import signals

