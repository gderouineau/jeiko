from django.core.management.base import BaseCommand

from jeiko.emailing.services import flush_queue


class Command(BaseCommand):
    help = (
        "Envoie les e-mails en file d'attente. "
        "Destiné à une tâche planifiée (cron), toutes les 5 à 15 minutes."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--limit",
            type=int,
            default=100,
            help="Nombre maximum d'e-mails traités par passage (défaut : 100).",
        )

    def handle(self, *args, **options):
        sent, failed = flush_queue(limit=options["limit"])

        if not sent and not failed:
            self.stdout.write("Aucun e-mail en attente.")
            return

        self.stdout.write(self.style.SUCCESS(f"{sent} e-mail(s) envoyé(s)."))
        if failed:
            self.stdout.write(self.style.WARNING(f"{failed} échec(s)."))
