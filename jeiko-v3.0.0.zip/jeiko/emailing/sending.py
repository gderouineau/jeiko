# jeiko/emailing/sending.py
"""
Couche basse d'envoi : connexion SMTP et fabrication du message.

La configuration reste `administration.MailSettings` — c'est un réglage de site,
en OneToOne sur WebSite, déjà éditable dans l'écran des réglages. Ce module se
contente de la lire.
"""

import logging

from django.conf import settings
from django.core.mail import EmailMultiAlternatives, get_connection

logger = logging.getLogger(__name__)


def get_mail_settings():
    from jeiko.administration.models import WebSite

    site = WebSite.objects.select_related("mail_settings").first()
    return getattr(site, "mail_settings", None)


def get_mail_connection():
    """
    Connexion SMTP d'après MailSettings.

    Retourne (connection | None, from_email | None, reply_to | None).
    """
    mail_settings = get_mail_settings()

    if not mail_settings or not mail_settings.active:
        logger.info("Email non configuré ou inactif : aucun envoi.")
        return None, None, None

    try:
        connection = get_connection(
            backend="django.core.mail.backends.smtp.EmailBackend",
            host=mail_settings.host,
            port=mail_settings.port,
            username=(mail_settings.host_user or None),
            password=(mail_settings.host_password or None),
            use_tls=bool(mail_settings.use_tls),
            use_ssl=bool(mail_settings.use_ssl),
            timeout=10,
        )
    except Exception as error:
        logger.exception("Impossible d'initialiser la connexion SMTP : %s", error)
        return None, None, None

    from_email = (
        mail_settings.default_from_email
        or mail_settings.host_user
        or getattr(settings, "DEFAULT_FROM_EMAIL", None)
    )
    reply_to = [mail_settings.reply_to_email] if mail_settings.reply_to_email else None

    return connection, from_email, reply_to


def admin_recipients():
    """Destinataires internes : expéditeur par défaut et adresse de test."""
    mail_settings = get_mail_settings()
    if not mail_settings:
        return []

    recipients = [mail_settings.default_from_email, mail_settings.test_receiver]
    return list(dict.fromkeys([r for r in recipients if r]))


def send_message(subject, text_body, to, html_body=None, from_email=None,
                 reply_to=None, attachments=None, connection=None):
    """
    Envoie un message. Retourne (success: bool, error: str | None).

    Ne lève jamais : un échec d'envoi ne doit pas faire échouer l'action métier
    qui l'a déclenché (une réservation reste valide même si son mail ne part pas).
    """
    if isinstance(to, str):
        to = [to]
    to = [address for address in (to or []) if address]

    if not to:
        return False, "Aucun destinataire"

    own_connection = connection is None
    default_from, default_reply_to = None, None

    if own_connection:
        connection, default_from, default_reply_to = get_mail_connection()
        if not connection:
            return False, "Configuration email manquante ou inactive"

    from_email = from_email or default_from
    if not from_email:
        _, from_email, _ = get_mail_connection()
    if not from_email:
        return False, "Aucune adresse d'expéditeur configurée"

    if reply_to is None:
        reply_to = default_reply_to
    if isinstance(reply_to, str):
        reply_to = [reply_to]

    try:
        message = EmailMultiAlternatives(
            subject=subject,
            body=text_body or "",
            from_email=from_email,
            to=to,
            reply_to=reply_to,
            connection=connection,
        )

        if html_body:
            message.attach_alternative(html_body, "text/html")

        for attachment in attachments or []:
            # (nom, contenu, type_mime)
            message.attach(*attachment)

        message.send()
        logger.info("E-mail envoyé à %s — %s", ", ".join(to), subject)
        return True, None

    except Exception as error:
        logger.exception("Échec d'envoi à %s : %s", ", ".join(to), error)
        return False, str(error)
