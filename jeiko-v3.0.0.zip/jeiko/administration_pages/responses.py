"""
Contrat de réponse unique entre les vues de l'éditeur et `editor.js`.

Avant, chaque vue inventait sa propre forme : la clé du HTML pouvait être `html`,
`section_html` ou `content_html`, et le statut `"success"`, `"ok"` ou `"reset"`. Le client
compensait avec `data.section_html || data.line_html || data.html` répété douze fois, et une
poignée de tests de statut incohérents.

Forme canonique :

    {
      "ok":      true | false,
      "action":  "replace" | "insert" | "modal" | "none",
      "target":  "section-12",     # id DOM sur lequel agir (si action != "none")
      "html":    "<div …>",        # fragment (si action != "none")
      "message": "",               # texte destiné à l'utilisateur
      ...                          # extras spécifiques (bloc_id, errors…)
    }

Les clés historiques (`status`, `section_id`, `section_html`) restent émises pour ne rien
casser côté consommateurs tiers ; elles pourront disparaître au lot 8, une fois que plus rien
ne les lit. Côté client, seul `applyEditorResponse()` connaît cette forme.
"""

from django.http import JsonResponse
from django.template.loader import render_to_string

SECTION_PARTIAL = "administration_pages/partials/section.html"


def render_section(section, request):
    """Rend le partial d'une section. Point d'entrée unique pour ce rendu."""
    return render_to_string(SECTION_PARTIAL, {"section": section}, request=request)


def section_payload(section, request, *, status="success", **extra):
    """Construit le dictionnaire canonique pour un remplacement de section."""
    html = render_section(section, request)
    payload = {
        "ok": True,
        "action": "replace",
        "target": f"section-{section.id}",
        "html": html,
        "message": "",
        # --- compatibilité (à retirer au lot 8) ---
        "status": status,
        "section_id": section.id,
        "section_html": html,
    }
    payload.update(extra)
    return payload


def section_response(section, request, *, status="success", http_status=200, **extra):
    """Réponse « remplace cette section par ce HTML »."""
    return JsonResponse(
        section_payload(section, request, status=status, **extra), status=http_status
    )


def modal_response(html, *, status="choose_type", message="", **extra):
    """Réponse « ouvre ce fragment dans le modal »."""
    payload = {
        "ok": True,
        "action": "modal",
        "target": None,
        "html": html,
        "message": message,
        "status": status,
        **extra,
    }
    return JsonResponse(payload)


def ok_response(*, message="", status="success", **extra):
    """Réponse « c'est fait, rien à réinjecter »."""
    payload = {
        "ok": True,
        "action": "none",
        "target": None,
        "html": "",
        "message": message,
        "status": status,
        **extra,
    }
    return JsonResponse(payload)


def error_response(message, *, http_status=400, status="error", **extra):
    """Réponse d'erreur."""
    payload = {
        "ok": False,
        "action": "none",
        "target": None,
        "html": extra.pop("html", ""),
        "message": message,
        "status": status,
        **extra,
    }
    return JsonResponse(payload, status=http_status)
