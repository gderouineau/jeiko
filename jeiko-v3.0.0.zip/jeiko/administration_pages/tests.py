"""
Tests de fumée de l'éditeur de pages.

Objectif : couvrir en quelques secondes ce qu'il faudrait une trentaine de manipulations
manuelles pour vérifier — le rendu, la duplication, les endpoints de déplacement et la
fermeture des APIs. Ils servent de filet pour les lots 3 et 4, qui réécrivent en une fois
les onze opérations CRUD.

Lancer depuis le projet Art :
    python manage.py test jeiko.administration_pages
"""

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.db import connection
from django.test import TestCase
from django.test.utils import CaptureQueriesContext
from django.urls import reverse

from jeiko.administration_pages.models import (
    Page, Section, Line, Bloc, Content, ContentText,
)
from jeiko.administration_pages.utils import section_duplicate

User = get_user_model()

AJAX = {"HTTP_X_REQUESTED_WITH": "XMLHttpRequest"}

# Plafond de requêtes pour le rendu d'une page publique (voir PageQueryCountTests).
MAX_QUERIES_PAGE = 40


def make_tree(page, *, n_lines=2, n_blocs=2, text="Bonjour"):
    """Construit page > section > lignes > blocs > contenus texte."""
    section = Section.objects.create(page=page, position=0)
    for li in range(n_lines):
        line = Line.objects.create(
            section=section, position=li,
            columns_type="6-6", columns_number=n_blocs,
        )
        for bi in range(n_blocs):
            bloc = Bloc.objects.create(
                line=line, position=bi + 1, position_in_column=0,
            )
            content = Content.objects.create(bloc=bloc, content_type="TEXT")
            content.content_text = ContentText.objects.create(text=f"{text} {li}-{bi}")
            content.save()
    return section


def grant(user, *codenames):
    user.user_permissions.add(
        *Permission.objects.filter(
            content_type__app_label="administration_pages",
            codename__in=codenames,
        )
    )


class PageRenderTests(TestCase):
    """Le rendu public ne doit pas casser, et doit contenir les contenus."""

    def setUp(self):
        # url_tag préfixé : la migration 0002 sème un site de démo qui occupe déjà
        # les tags évidents (accueil, contact...) et la contrainte d'unicité s'applique.
        self.page = Page.objects.create(title="Accueil", url_tag="t-accueil")
        make_tree(self.page)

    def test_page_publique_rend_200_et_affiche_les_contenus(self):
        response = self.client.get(self.page.get_absolute_url())
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Bonjour 0-0")
        self.assertContains(response, "Bonjour 1-1")

    def test_le_fil_dariane_est_bien_construit(self):
        # Régression B4 : build_breadcrumb_for_page ne retournait rien.
        response = self.client.get(self.page.get_absolute_url())
        breadcrumb = response.context["breadcrumb"]
        self.assertIsNotNone(breadcrumb)
        self.assertEqual(breadcrumb[-1]["name"], "Accueil")


class PageQueryCountTests(TestCase):
    """
    Verrou anti-N+1 sur le rendu public.

    StylableElement porte 14 relations (margin/padding/size x4 devices, background_image,
    background_image_parameters), auxquelles s'ajoutent animation, border et custom_css.
    Sans prefetch, chaque section, ligne et bloc les charge une par une.
    """

    def _build(self, tag, n_sections):
        page = Page.objects.create(title=tag, url_tag=tag)
        for s in range(n_sections):
            section = Section.objects.create(page=page, position=s)
            for li in range(3):
                line = Line.objects.create(
                    section=section, position=li,
                    columns_type="6-6", columns_number=2,
                )
                for bi in range(2):
                    bloc = Bloc.objects.create(
                        line=line, position=bi + 1, position_in_column=0
                    )
                    content = Content.objects.create(bloc=bloc, content_type="TEXT")
                    content.content_text = ContentText.objects.create(text=f"T{s}{li}{bi}")
                    content.save()
        return page

    def _count_queries(self, page):
        # Première requête : chauffe les fragments {% cache %} de base.html, qui ne sont
        # payés qu'une fois en production. On mesure le coût marginal réel d'une page.
        self.client.get(page.get_absolute_url())
        with CaptureQueriesContext(connection) as ctx:
            response = self.client.get(page.get_absolute_url())
        self.assertEqual(response.status_code, 200)
        return len(ctx.captured_queries)

    def test_le_rendu_ne_depend_pas_de_la_taille_de_la_page(self):
        """
        L'invariant qui compte : le nombre de requêtes ne doit pas croître avec le nombre
        de sections. Avant le prefetch, 18 blocs coûtaient 191 requêtes.
        """
        petite = self._count_queries(self._build("t-petite", 3))   # 18 blocs
        grande = self._count_queries(self._build("t-grande", 9))   # 54 blocs

        self.assertEqual(
            petite, grande,
            f"le rendu n'est plus constant : {petite} requêtes pour 18 blocs, "
            f"{grande} pour 54 — un N+1 est réapparu",
        )
        self.assertLess(petite, MAX_QUERIES_PAGE)


class SectionDuplicationTests(TestCase):
    """La duplication profonde est la brique la plus utilisée : elle doit rester exacte."""

    def setUp(self):
        self.page = Page.objects.create(title="Source", url_tag="t-source")
        self.section = make_tree(self.page, n_lines=2, n_blocs=2)

    def test_duplication_conserve_toute_larborescence(self):
        copy = section_duplicate(self.section, target_page=self.page)

        self.assertNotEqual(copy.pk, self.section.pk)
        self.assertEqual(copy.lines.count(), self.section.lines.count())

        blocs_source = Bloc.objects.filter(line__section=self.section).count()
        blocs_copie = Bloc.objects.filter(line__section=copy).count()
        self.assertEqual(blocs_copie, blocs_source)

        contents_copie = Content.objects.filter(bloc__line__section=copy).count()
        self.assertEqual(contents_copie, blocs_source)

    def test_les_contenus_sont_copies_et_independants(self):
        copy = section_duplicate(self.section, target_page=self.page)

        source_texts = sorted(
            ContentText.objects
            .filter(content__bloc__line__section=self.section)
            .values_list("text", flat=True)
        )
        copy_texts = sorted(
            ContentText.objects
            .filter(content__bloc__line__section=copy)
            .values_list("text", flat=True)
        )
        self.assertEqual(source_texts, copy_texts)

        # Objets distincts : modifier la copie ne doit pas toucher la source.
        source_ids = set(
            ContentText.objects
            .filter(content__bloc__line__section=self.section)
            .values_list("id", flat=True)
        )
        copy_ids = set(
            ContentText.objects
            .filter(content__bloc__line__section=copy)
            .values_list("id", flat=True)
        )
        self.assertFalse(source_ids & copy_ids)

    def test_la_copie_nest_pas_marquee_comme_modele(self):
        copy = section_duplicate(self.section, target_page=self.page)
        self.assertFalse(copy.is_model)
        self.assertFalse(Line.objects.filter(section=copy, is_model=True).exists())


class HeroResolverTests(TestCase):
    """
    Régression : `_page_id_of_bloc` et `_page_id_of_content` interrogeaient `Line.page_id`,
    un champ qui n'existe pas — Line ne porte que `section_id`. Le FieldError était avalé
    par un `except Exception: pass`, donc le héros n'était jamais recalculé lors d'une
    modification de bloc ou de contenu.
    """

    def setUp(self):
        self.page = Page.objects.create(title="Heros", url_tag="t-heros")
        self.section = make_tree(self.page, n_lines=1, n_blocs=1)
        self.line = self.section.lines.first()
        self.bloc = self.line.blocs.first()
        self.content = self.bloc.content

    def test_chaque_niveau_remonte_jusqua_la_page(self):
        from jeiko.administration_pages.signals import (
            _page_id_of_section, _page_id_of_line,
            _page_id_of_bloc, _page_id_of_content,
        )

        self.assertEqual(_page_id_of_section(self.section), self.page.id)
        self.assertEqual(_page_id_of_line(self.line), self.page.id)
        self.assertEqual(_page_id_of_bloc(self.bloc), self.page.id)
        self.assertEqual(_page_id_of_content(self.content), self.page.id)

    def test_un_element_orphelin_ne_leve_pas(self):
        orphelin = Bloc(line=None)
        from jeiko.administration_pages.signals import _page_id_of_bloc
        self.assertIsNone(_page_id_of_bloc(orphelin))


class EditorMoveTests(TestCase):
    """Endpoints de déplacement : statut, fragment renvoyé, et effet réel en base."""

    def setUp(self):
        self.user = User.objects.create_user("editeur", password="x", is_staff=True)
        grant(self.user, "view_page", "change_page", "add_page", "delete_page")
        self.client.force_login(self.user)

        self.page = Page.objects.create(title="Edition", url_tag="t-edition")
        self.s1 = make_tree(self.page, n_lines=2, n_blocs=2)
        self.s2 = Section.objects.create(page=self.page, position=1)

        self.l1, self.l2 = list(self.s1.lines.order_by("position"))

    def _post(self, name, **kwargs):
        return self.client.post(
            reverse(f"jeiko_administration_pages:{name}", kwargs=kwargs), **AJAX
        )

    def test_descendre_une_ligne_echange_les_positions(self):
        # Régression B13 : le serveur était correct, c'est le JS qui n'appliquait rien.
        p1, p2 = self.l1.position, self.l2.position

        response = self._post(
            "line_move_down",
            page_id=self.page.id, section_id=self.s1.id, line_id=self.l1.id,
        )
        self.assertEqual(response.status_code, 200)
        payload = response.json()
        self.assertEqual(payload["status"], "success")
        self.assertIn("section_html", payload)
        self.assertIn(f'id="section-{self.s1.id}"', payload["section_html"])

        self.l1.refresh_from_db()
        self.l2.refresh_from_db()
        self.assertEqual(self.l1.position, p2)
        self.assertEqual(self.l2.position, p1)

    def test_descendre_puis_remonter_revient_a_letat_initial(self):
        self._post("line_move_down", page_id=self.page.id,
                   section_id=self.s1.id, line_id=self.l1.id)
        self._post("line_move_up", page_id=self.page.id,
                   section_id=self.s1.id, line_id=self.l1.id)

        self.l1.refresh_from_db()
        self.assertEqual(self.l1.position, 0)

    def test_deplacer_un_bloc_dans_sa_colonne(self):
        bloc_du_bas = Bloc.objects.create(
            line=self.l1, position=1, position_in_column=1
        )

        response = self._post(
            "bloc_move_up",
            page_id=self.page.id, section_id=self.s1.id,
            line_id=self.l1.id, bloc_id=bloc_du_bas.id,
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["status"], "success")

        bloc_du_bas.refresh_from_db()
        self.assertEqual(bloc_du_bas.position_in_column, 0)

    def test_deplacer_un_bloc_vers_la_colonne_de_gauche(self):
        bloc = Bloc.objects.filter(line=self.l1, position=2).first()
        self.assertIsNotNone(bloc)

        response = self._post(
            "bloc_move_left",
            page_id=self.page.id, section_id=self.s1.id,
            line_id=self.l1.id, bloc_id=bloc.id,
        )
        self.assertEqual(response.status_code, 200)

        bloc.refresh_from_db()
        self.assertEqual(bloc.position, 1)

    def test_descendre_une_section(self):
        response = self._post(
            "section_move_down", page_id=self.page.id, section_id=self.s1.id
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["status"], "success")

        self.s1.refresh_from_db()
        self.s2.refresh_from_db()
        self.assertGreater(self.s1.position, self.s2.position)


class ApiAccessTests(TestCase):
    """Verrouille le lot 1 : les APIs d'administration ne doivent plus être ouvertes."""

    ADMIN_ENDPOINTS = [
        "api_pages:api_category_main_list",
        "api_pages:api_page_list",
    ]

    def setUp(self):
        self.page = Page.objects.create(title="Privee", url_tag="t-privee")

    def test_anonyme_refuse_sur_les_apis_dadministration(self):
        for name in self.ADMIN_ENDPOINTS:
            with self.subTest(endpoint=name):
                response = self.client.get(reverse(name))
                self.assertEqual(
                    response.status_code, 403,
                    f"{name} répond {response.status_code} au lieu de 403",
                )

    def test_utilisateur_sans_permission_refuse(self):
        User.objects.create_user("simple", password="x")
        self.client.login(username="simple", password="x")
        response = self.client.get(reverse("api_pages:api_page_list"))
        self.assertEqual(response.status_code, 403)

    def test_utilisateur_avec_permission_accepte(self):
        user = User.objects.create_user("lecteur", password="x", is_staff=True)
        grant(user, "view_page")
        self.client.force_login(user)

        response = self.client.get(reverse("api_pages:api_page_list"))
        self.assertEqual(response.status_code, 200)
        self.assertIn("pages", response.json())

    def test_toutes_les_mutations_de_lediteur_refusent_lanonyme(self):
        """
        Régression A8. Les 20 vues de views.py étaient déclarées en `View` nu : un visiteur
        anonyme pouvait créer, modifier, supprimer et déplacer sections, lignes et blocs.
        """
        section = make_tree(self.page, n_lines=1, n_blocs=2)
        line = section.lines.first()
        bloc = line.blocs.first()

        p = {"page_id": self.page.id}
        s = {**p, "section_id": section.id}
        li = {**s, "line_id": line.id}
        b = {**li, "bloc_id": bloc.id}

        endpoints = [
            ("section_add", p), ("section_update", s), ("section_delete", s),
            ("section_move_up", s), ("section_move_down", s),
            ("line_add", s), ("line_update", li), ("line_delete", li),
            ("line_move_up", li), ("line_move_down", li),
            ("bloc_add", b), ("bloc_delete", b),
            ("bloc_move_up", b), ("bloc_move_down", b),
            ("bloc_move_left", b), ("bloc_move_right", b),
            ("content_add", b), ("content_edit", b), ("content_reset", b),
        ]

        for name, kwargs in endpoints:
            with self.subTest(endpoint=name):
                url = reverse(f"jeiko_administration_pages:{name}", kwargs=kwargs)
                for method in (self.client.get, self.client.post):
                    response = method(url, **AJAX)
                    self.assertIn(
                        response.status_code, (302, 403),
                        f"{name} ({method.__name__.upper()}) répond "
                        f"{response.status_code} à un anonyme",
                    )

    def test_un_editeur_authentifie_passe(self):
        user = User.objects.create_user("editeur2", password="x", is_staff=True)
        grant(user, "view_page", "change_page")
        self.client.force_login(user)

        section = make_tree(self.page, n_lines=1, n_blocs=1)
        response = self.client.post(
            reverse(
                "jeiko_administration_pages:section_move_down",
                kwargs={"page_id": self.page.id, "section_id": section.id},
            ),
            **AJAX,
        )
        self.assertEqual(response.status_code, 200)
