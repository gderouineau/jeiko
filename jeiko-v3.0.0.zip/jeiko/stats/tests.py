import json
from datetime import date, timedelta
from django.test import TestCase, RequestFactory
from django.contrib.auth import get_user_model
from django.http import HttpResponse
from django.core.management import call_command
from io import StringIO

from jeiko.stats.models import PageView
from jeiko.stats.middleware import PageViewCounterMiddleware, _is_probably_bot, _path_is_ignored, _is_mobile_device
from jeiko.stats import services

User = get_user_model()

class StatsBotDetectionTestCase(TestCase):
    def test_empty_user_agent_is_bot(self):
        self.assertTrue(_is_probably_bot(""))
        self.assertTrue(_is_probably_bot("   "))
        self.assertTrue(_is_probably_bot(None))

    def test_known_bots_and_scrapers(self):
        bot_uas = [
            "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
            "Mozilla/5.0 (compatible; GPTBot/1.0; +https://openai.com/gptbot)",
            "Mozilla/5.0 (compatible; ClaudeBot/1.0; +https://anthropic.com)",
            "Mozilla/5.0 (compatible; SemrushBot/7~bl; +http://www.semrush.com/bot.html)",
            "python-requests/2.31.0",
            "curl/7.88.1",
            "Wget/1.21.3",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/120.0.0.0 Safari/537.36",
        ]
        for ua in bot_uas:
            self.assertTrue(_is_probably_bot(ua), f"Failed to identify bot UA: {ua}")

    def test_legitimate_human_user_agents(self):
        human_uas = [
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
        ]
        for ua in human_uas:
            self.assertFalse(_is_probably_bot(ua), f"Misidentified human UA as bot: {ua}")

    def test_is_mobile_device(self):
        self.assertTrue(_is_mobile_device("Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X)"))
        self.assertTrue(_is_mobile_device("Mozilla/5.0 (Linux; Android 14; SM-S918B)"))
        self.assertFalse(_is_mobile_device("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"))

    def test_path_is_ignored(self):
        self.assertTrue(_path_is_ignored("/favicon.ico"))
        self.assertTrue(_path_is_ignored("/robots.txt"))
        self.assertTrue(_path_is_ignored("/static/css/style.css"))
        self.assertTrue(_path_is_ignored("/.well-known/acme-challenge/123"))
        self.assertFalse(_path_is_ignored("/contact/"))
        self.assertFalse(_path_is_ignored("/courses/math/"))


class StatsMiddlewareTestCase(TestCase):
    def setUp(self):
        self.factory = RequestFactory()

    def test_middleware_human_request_and_referrer_domain(self):
        def dummy_get_response(request):
            return HttpResponse("<html><body><h1>Hello World</h1></body></html>", content_type="text/html")

        middleware = PageViewCounterMiddleware(dummy_get_response)
        req = self.factory.get(
            "/",
            HTTP_USER_AGENT="Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15",
            HTTP_REFERER="https://www.google.fr/search?q=jeiko"
        )

        res = middleware(req)
        self.assertEqual(res.status_code, 200)

        pv = PageView.objects.first()
        self.assertIsNotNone(pv)
        self.assertFalse(pv.is_bot)
        self.assertTrue(pv.is_mobile)
        self.assertEqual(pv.referrer_domain, "google.fr")
        self.assertFalse(pv.is_internal_referrer)
        self.assertTrue(pv.is_entry)


class StatsServicesTestCase(TestCase):
    def setUp(self):
        today = date.today()
        # Vues aujourd'hui (période N)
        PageView.objects.create(path="/", day=today, is_bot=False, is_mobile=True, referrer_domain="google.fr", is_entry=True, dwell_ms=5000)
        PageView.objects.create(path="/about", day=today, is_bot=False, is_mobile=False, referrer_domain="direct", is_entry=False, dwell_ms=10000)
        # Vues période précédente N-1 (il y a 8 jours pour 1w preset)
        prev_day = today - timedelta(days=8)
        PageView.objects.create(path="/", day=prev_day, is_bot=False, is_mobile=False, referrer_domain="direct", is_entry=True, dwell_ms=3000)

    def test_summary_and_trends(self):
        res = services.summary(preset="1w", traffic_type="human")
        self.assertIsNotNone(res["pageviews_change_pct"])
        self.assertIsNotNone(res["visits_change_pct"])
        self.assertEqual(res["pageviews"], 2)
        self.assertEqual(res["pageviews_change_pct"], 100.0)  # (2 - 1) / 1 * 100

    def test_external_referrers(self):
        refs = services.external_referrers(date.today() - timedelta(days=10), date.today())
        self.assertTrue(any(r["referrer_domain"] == "google.fr" for r in refs))

    def test_device_breakdown(self):
        devices = services.device_breakdown(date.today() - timedelta(days=10), date.today())
        self.assertGreater(devices["total"], 0)
        self.assertEqual(devices["mobile"], 1)
        self.assertEqual(devices["desktop"], 2)


class StatsPurgeCommandTestCase(TestCase):
    def setUp(self):
        old_day = date.today() - timedelta(days=200)
        recent_day = date.today() - timedelta(days=10)
        PageView.objects.create(path="/old", day=old_day)
        PageView.objects.create(path="/recent", day=recent_day)

    def test_stats_purge_command(self):
        out = StringIO()
        call_command("stats_purge", "--days", "180", stdout=out)
        self.assertIn("Purge effectuée", out.getvalue())
        self.assertEqual(PageView.objects.count(), 1)
        self.assertEqual(PageView.objects.first().path, "/recent")
