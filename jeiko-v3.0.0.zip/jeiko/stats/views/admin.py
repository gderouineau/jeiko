# jeiko/stats/views/admin.py
from __future__ import annotations

import csv
import json
from datetime import datetime, date
from typing import Optional, Tuple, List, Dict, Any

from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Count, Avg, Sum, Case, When, IntegerField, QuerySet
from django.http import HttpRequest, HttpResponse, HttpResponseBadRequest
from django.shortcuts import render

from jeiko.stats.models import PageView
from jeiko.stats import services


# -----------------------
# Helpers
# -----------------------

def _parse_date(s: Optional[str]) -> Optional[date]:
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        return None


def _range_from_request(request: HttpRequest) -> Tuple[date, date, str | None, str]:
    """
    Lit preset/start/end/traffic_type de la querystring.
    traffic_type = "human" | "bot" | "all" (défaut: "human")
    """
    preset = request.GET.get("preset") or None
    start = _parse_date(request.GET.get("start"))
    end = _parse_date(request.GET.get("end"))
    traffic_type = request.GET.get("traffic_type") or "human"
    if traffic_type not in {"human", "bot", "all"}:
        traffic_type = "human"

    k = services.summary(preset, start, end, traffic_type=traffic_type)
    return k["start"], k["end"], preset, traffic_type


def _series_json(items: List[Dict[str, Any]]) -> str:
    serializable = []
    for row in items:
        serializable.append({
            "day": row["day"].isoformat() if hasattr(row["day"], "isoformat") else row["day"],
            "pageviews": row.get("pageviews", 0),
            "visits": row.get("visits", 0),
            "avg_dwell_ms": float(row["avg_dwell_ms"]) if row.get("avg_dwell_ms") is not None else None,
        })
    return json.dumps(serializable)


# -----------------------
# Views (admin)
# -----------------------

@staff_member_required
def overview(request: HttpRequest) -> HttpResponse:
    """
    Dashboard principal : KPIs, variation N-1, série quotidienne, top pages, referrers externes, appareils.
    """
    start, end, preset, traffic_type = _range_from_request(request)

    kpis = services.summary(preset=None, start=start, end=end, traffic_type=traffic_type)
    series = services.daily_series(start, end, traffic_type=traffic_type)
    pages = services.top_pages(start, end, limit=20, traffic_type=traffic_type)
    external_refs = services.external_referrers(start, end, limit=10, traffic_type=traffic_type)
    devices = services.device_breakdown(start, end, traffic_type=traffic_type)

    ctx = {
        "preset": request.GET.get("preset") or "",
        "traffic_type": traffic_type,
        "kpis": kpis,
        "series": _series_json(series),
        "pages": pages,
        "external_refs": external_refs,
        "devices": devices,
    }
    return render(request, "stats/admin/overview.html", ctx)


@staff_member_required
def pages(request: HttpRequest) -> HttpResponse:
    """
    Liste agrégée des pages (filtrable par période, type de trafic + recherche 'q').
    """
    start, end, preset, traffic_type = _range_from_request(request)
    q = (request.GET.get("q") or "").strip()

    qs: QuerySet[PageView] = services.qs_between(start, end, traffic_type=traffic_type)
    if q:
        qs = qs.filter(path__icontains=q)

    agg = (
        qs.values("path")
          .annotate(
              pageviews=Count("id"),
              visits=Sum(Case(When(is_entry=True, then=1), default=0, output_field=IntegerField())),
              avg_dwell_ms=Avg("dwell_ms"),
          )
          .order_by("-pageviews")
    )

    ctx = {
        "preset": preset or "",
        "traffic_type": traffic_type,
        "start": start,
        "end": end,
        "q": q,
        "pages": list(agg),
    }
    return render(request, "stats/admin/pages.html", ctx)


@staff_member_required
def page_detail(request: HttpRequest) -> HttpResponse:
    """
    Détail d’une page : KPIs, série quotidienne, referrers internes.
    """
    path = request.GET.get("path")
    if not path:
        return HttpResponseBadRequest("Paramètre 'path' requis.")

    start, end, preset, traffic_type = _range_from_request(request)
    base_qs = services.qs_between(start, end, traffic_type=traffic_type).filter(path=path)

    pageviews = base_qs.count()
    visits = base_qs.filter(is_entry=True).count()
    avg_dwell_ms = base_qs.aggregate(Avg("dwell_ms"))["dwell_ms__avg"]
    pages_per_visit = (pageviews / visits) if visits else None

    kpis = {
        "start": start,
        "end": end,
        "traffic_type": traffic_type,
        "pageviews": pageviews,
        "visits": visits,
        "avg_dwell_ms": avg_dwell_ms,
        "pages_per_visit": pages_per_visit,
    }

    series = (
        base_qs.values("day")
               .annotate(
                   pageviews=Count("id"),
                   visits=Sum(Case(When(is_entry=True, then=1), default=0, output_field=IntegerField())),
                   avg_dwell_ms=Avg("dwell_ms"),
               )
               .order_by("day")
    )

    referrers = services.referrers_for(path, start, end, limit=50, traffic_type=traffic_type)

    ctx = {
        "preset": preset or "",
        "traffic_type": traffic_type,
        "path": path,
        "start": start,
        "end": end,
        "kpis": kpis,
        "series": _series_json(list(series)),
        "referrers": referrers,
    }
    return render(request, "stats/admin/page_detail.html", ctx)


@staff_member_required
def export_csv(request: HttpRequest) -> HttpResponse:
    """
    Export CSV des pages vues selon la période et le type de trafic.
    """
    start, end, preset, traffic_type = _range_from_request(request)

    pages_data = services.top_pages(start, end, limit=5000, traffic_type=traffic_type)

    response = HttpResponse(content_type="text/csv; charset=utf-8")
    filename = f"jeiko_stats_{traffic_type}_{start}_{end}.csv"
    response["Content-Disposition"] = f'attachment; filename="{filename}"'

    writer = csv.writer(response)
    writer.writerow(["Chemin (Path)", "Pages Vues", "Visites", "Temps Moyen Dwell (ms)"])

    for item in pages_data:
        writer.writerow([
            item.get("path", ""),
            item.get("pageviews", 0),
            item.get("visits", 0),
            round(item.get("avg_dwell_ms") or 0, 1),
        ])

    return response
