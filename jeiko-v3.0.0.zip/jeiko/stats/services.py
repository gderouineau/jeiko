# stats/services.py
from datetime import date, timedelta
from django.db.models import Count, Avg, Sum, Case, When, IntegerField
from .models import PageView

def _range(preset: str | None, start: date | None, end: date | None):
    if preset in {"1w", "1m", "3m"} and not (start and end):
        today = date.today()
        if preset == "1w":  start, end = today - timedelta(days=6), today
        if preset == "1m":  start, end = today - timedelta(days=29), today
        if preset == "3m":  start, end = today - timedelta(days=89), today
    if not (start and end):
        today = date.today()
        start, end = today - timedelta(days=29), today
    return start, end

def qs_between(start: date, end: date, traffic_type: str = "human"):
    qs = PageView.objects.filter(day__gte=start, day__lte=end)
    if traffic_type == "human":
        qs = qs.filter(is_bot=False)
    elif traffic_type == "bot":
        qs = qs.filter(is_bot=True)
    return qs

def _calc_change_pct(current: float | int | None, previous: float | int | None) -> float | None:
    if current is None or previous is None or previous == 0:
        return None
    return round(((current - previous) / previous) * 100.0, 1)

def summary(preset: str | None = None, start: date | None = None, end: date | None = None, traffic_type: str = "human"):
    start, end = _range(preset, start, end)
    qs = qs_between(start, end, traffic_type=traffic_type)
    totals = qs.aggregate(
        pageviews=Count("id"),
        visits=Sum(Case(When(is_entry=True, then=1), default=0, output_field=IntegerField())),
        engaged_views=Sum(Case(When(dwell_ms__gt=0, then=1), default=0, output_field=IntegerField())),
        avg_dwell_ms=Avg("dwell_ms"),
    )
    visits = totals["visits"] or 0
    pageviews = totals["pageviews"] or 0
    engaged_views = totals["engaged_views"] or 0

    pages_per_visit = (pageviews / visits) if visits else None
    engagement_rate = (engaged_views / pageviews * 100) if pageviews else 0.0

    avg_dwell_per_visit_ms = None
    if totals["avg_dwell_ms"] is not None and pages_per_visit:
        avg_dwell_per_visit_ms = float(totals["avg_dwell_ms"]) * pages_per_visit

    # --- Comparatif Période Précédente N-1 ---
    delta_days = (end - start).days + 1
    prev_end = start - timedelta(days=1)
    prev_start = prev_end - timedelta(days=delta_days - 1)
    prev_qs = qs_between(prev_start, prev_end, traffic_type=traffic_type)
    prev_totals = prev_qs.aggregate(
        pageviews=Count("id"),
        visits=Sum(Case(When(is_entry=True, then=1), default=0, output_field=IntegerField())),
        avg_dwell_ms=Avg("dwell_ms"),
    )
    prev_pageviews = prev_totals["pageviews"] or 0
    prev_visits = prev_totals["visits"] or 0
    prev_dwell = prev_totals["avg_dwell_ms"]

    pageviews_change_pct = _calc_change_pct(pageviews, prev_pageviews)
    visits_change_pct = _calc_change_pct(visits, prev_visits)
    avg_dwell_change_pct = _calc_change_pct(totals["avg_dwell_ms"], prev_dwell)

    # Métriques globales pour le comparatif Humains / Bots
    all_qs = PageView.objects.filter(day__gte=start, day__lte=end)
    bot_count = all_qs.filter(is_bot=True).count()
    human_count = all_qs.filter(is_bot=False).count()

    return {
        "start": start,
        "end": end,
        "traffic_type": traffic_type,
        "pageviews": pageviews,
        "visits": visits,
        "pages_per_visit": pages_per_visit,
        "avg_dwell_ms": totals["avg_dwell_ms"],
        "avg_dwell_per_visit_ms": avg_dwell_per_visit_ms,
        "engaged_views": engaged_views,
        "engagement_rate": engagement_rate,
        "bot_count": bot_count,
        "human_count": human_count,
        # Tendances N vs N-1
        "prev_start": prev_start,
        "prev_end": prev_end,
        "pageviews_change_pct": pageviews_change_pct,
        "visits_change_pct": visits_change_pct,
        "avg_dwell_change_pct": avg_dwell_change_pct,
    }

def daily_series(start: date, end: date, traffic_type: str = "human"):
    qs = qs_between(start, end, traffic_type=traffic_type).values("day").annotate(
        pageviews=Count("id"),
        visits=Sum(Case(When(is_entry=True, then=1), default=0, output_field=IntegerField())),
        avg_dwell_ms=Avg("dwell_ms"),
    ).order_by("day")
    return list(qs)

def top_pages(start: date, end: date, limit: int = 20, traffic_type: str = "human"):
    qs = qs_between(start, end, traffic_type=traffic_type).values("path").annotate(
        pageviews=Count("id"),
        visits=Sum(Case(When(is_entry=True, then=1), default=0, output_field=IntegerField())),
        avg_dwell_ms=Avg("dwell_ms"),
    ).order_by("-pageviews")[:limit]
    return list(qs)

def external_referrers(start: date, end: date, limit: int = 10, traffic_type: str = "human"):
    """
    Agrège les domaines d'origine des visiteurs (ex: google.fr, t.co, direct).
    """
    qs = qs_between(start, end, traffic_type=traffic_type).filter(is_internal_referrer=False)
    agg = (
        qs.values("referrer_domain")
          .annotate(arrivals=Count("id"))
          .order_by("-arrivals")[:limit]
    )
    return list(agg)

def device_breakdown(start: date, end: date, traffic_type: str = "human"):
    """
    Calcule la répartition Mobile vs Desktop.
    """
    qs = qs_between(start, end, traffic_type=traffic_type)
    totals = qs.aggregate(
        mobile=Sum(Case(When(is_mobile=True, then=1), default=0, output_field=IntegerField())),
        desktop=Sum(Case(When(is_mobile=False, then=1), default=0, output_field=IntegerField())),
        total=Count("id")
    )
    mobile = totals["mobile"] or 0
    desktop = totals["desktop"] or 0
    total = totals["total"] or 0

    mobile_pct = round((mobile / total * 100.0), 1) if total else 0.0
    desktop_pct = round((desktop / total * 100.0), 1) if total else 0.0

    return {
        "mobile": mobile,
        "desktop": desktop,
        "total": total,
        "mobile_pct": mobile_pct,
        "desktop_pct": desktop_pct,
    }

def referrers_for(path: str, start: date, end: date, limit: int = 20, traffic_type: str = "human"):
    qs = qs_between(start, end, traffic_type=traffic_type).filter(path=path).values("referrer_path").annotate(
        arrivals=Count("id"),
        avg_dwell_ms=Avg("dwell_ms"),
    ).order_by("-arrivals")[:limit]
    return list(qs)
