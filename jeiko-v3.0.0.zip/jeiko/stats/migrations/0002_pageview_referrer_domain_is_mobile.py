# Generated for stats app

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('stats', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='pageview',
            name='referrer_domain',
            field=models.CharField(blank=True, db_index=True, max_length=255, null=True),
        ),
        migrations.AddField(
            model_name='pageview',
            name='is_mobile',
            field=models.BooleanField(db_index=True, default=False),
        ),
        migrations.AddIndex(
            model_name='pageview',
            index=models.Index(fields=['day', 'referrer_domain'], name='stats_pagev_day_ref_dom_idx'),
        ),
    ]
