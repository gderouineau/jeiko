# jeiko/stats/urls/admin.py
from django.urls import path
from jeiko.stats.views.admin import overview, pages as stats_pages, page_detail, export_csv

app_name = "jeiko_administration_stats"

urlpatterns = [
    path("overview/", overview, name="stats_overview"),
    path("pages/", stats_pages, name="stats_pages"),
    path("page/", page_detail, name="stats_page_detail"),
    path("export/", export_csv, name="stats_export_csv"),
]
