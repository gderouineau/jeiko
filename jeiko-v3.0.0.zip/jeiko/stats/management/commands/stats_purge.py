# jeiko/stats/management/commands/stats_purge.py
from datetime import date, timedelta
from django.core.management.base import BaseCommand
from jeiko.stats.models import PageView

class Command(BaseCommand):
    help = "Purge les anciennes données de statistiques (PageView) plus anciennes qu'un nombre de jours donné."

    def add_arguments(self, parser):
        parser.add_argument(
            "--days",
            type=int,
            default=180,
            help="Nombre de jours de conservation des données (défaut: 180 jours / 6 mois).",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Affiche le nombre d'enregistrements qui seraient supprimés sans les effacer de la BDD.",
        )

    def handle(self, *args, **options):
        keep_days = options["days"]
        dry_run = options["dry_run"]

        cutoff_date = date.today() - timedelta(days=keep_days)
        qs = PageView.objects.filter(day__lt=cutoff_date)
        count = qs.count()

        if dry_run:
            self.stdout.write(
                self.style.WARNING(
                    f"[DRY-RUN] {count} enregistrements PageView antérieurs au {cutoff_date} seraient supprimés (conservation: {keep_days} jours)."
                )
            )
        else:
            deleted_count, _ = qs.delete()
            self.stdout.write(
                self.style.SUCCESS(
                    f"Purge effectuée : {deleted_count} enregistrements PageView antérieurs au {cutoff_date} ont été supprimés avec succès (conservation: {keep_days} jours)."
                )
            )
