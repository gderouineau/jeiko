# Audit — système d'édition de pages (`administration_pages`)

Périmètre : `static/jeiko/js/editor/*`, `templates/administration_pages/**`,
`administration_pages/{views,views_api,views_client,utils,signals,models}.py`, `templates/base_editor.html`.

Légende statut : `[ ]` à traiter · `[~]` en cours · `[x]` corrigé

---

## A. Sécurité — à traiter en premier

### [x] A1 — Toutes les APIs `/api/pages/…` sont ouvertes (critique)
`views_api.py:58-102, 152-154, 215-217, 396-398, 465-467, 505-507, 549-551`

Chaque vue API est décorée `@csrf_exempt` **et n'a aucun contrôle d'authentification ni de
permission**. Seules `insights_latest` / `insights_refresh` (`views_api.py:612, 690`) sont
protégées par `@login_required` + `@permission_required`.

Sont donc accessibles sans compte :
- `PageListAPI` / `PageGetAPI` — énumération de toutes les pages, y compris `is_protected`
- `ContentFormulaireAPI` (GET + POST) — lecture et modification de la config des formulaires,
  dont `to_email` / `from_email` (détournement de destinataire possible)
- `ContentFormFieldAPI` (GET/POST/PUT/PATCH/DELETE) — CRUD complet sur les champs
- `SectionModelCreateAPI` / `LineModelCreateAPI` / `BlocModelCreateAPI` — création d'objets en base
- `CategoryMainListAPI`, `SubCategoryListAPI`, `ProductTypeListAPI`, `CustomObjectModelListAPI`

Correctif : mixin `LoginRequiredMixin` + `PermissionRequiredMixin`, suppression de
`csrf_exempt` (le JS envoie déjà `X-CSRFToken` partout sauf A5).

### [x] A2 — XSS stocké dans la liste des champs de formulaire
`editor.js:1718-1731` — `field.label`, `field.type`, `field.name` injectés via
`insertAdjacentHTML` sans échappement. Un label `<img src=x onerror=…>` s'exécute chez tout
administrateur ouvrant le formulaire. Payload injectable via A1 sans authentification.

### [x] A3 — Échappement incomplet dans l'éditeur de champ
`editor.js:1555, 1558, 1561, 1574` — `.replace(/"/g,'&quot;')` seulement. `<`, `>`, `&` passent.

### [x] A4 — `showConfirmModal` injecte son message en HTML
`utils.js:112-127` — `message` interpolé dans un `innerHTML`.

### [x] A5 — POST sans jeton CSRF
`editor.js:1811-1815` — `InitFormulaireStyle` poste vers `ContentFormulaireAPI` sans
`X-CSRFToken`. Ne fonctionne aujourd'hui que grâce au `csrf_exempt` de A1 : corriger A1 sans
corriger A5 casse la sauvegarde de style.

### [x] A6 — Permissions déclarées avec le mauvais `app_label`
Découvert en traitant A1. Le label de l'application est `administration_pages`
(`apps.py:5`), or trois emplacements demandent la permission `pages.*` :
`views_api.py:614` (`insights_latest`), `views_api.py:692` (`insights_refresh`),
`views.py:948` (`PageInsight`). Ces permissions n'existent pas : `has_perm()` renvoie
toujours `False`. Invisible pour un superutilisateur (qui contourne le contrôle), mais
**tout compte non-superutilisateur reçoit un 403** sur les écrans PageSpeed.
Supprimé au passage : `_check_perm_or_403` (`views_api.py:601`), jamais appelé.

### [x] A8 — Les 20 vues d'édition étaient ouvertes à tous (critique, plus grave que A1)
Découvert par les tests de fumée (lot 2 bis), pas par l'audit initial : je n'avais cherché le
motif que dans `views_api.py`.

Toutes les vues de mutation de `views.py` étaient déclarées `class X(View)` nu, sans
`LoginRequiredMixin` ni `PermissionRequiredMixin` : `SectionCreate`, `SectionUpdate`,
`SectionDelete`, `SectionMoveUp/Down`, `LineCreate/Update/Delete/MoveUp/MoveDown`,
`ContentTypeChoice`, `ContentTypeChoiceFromModel`, `EditContent`, `ResetContent`,
`BlocCreate/Delete/MoveUp/Down/Left/Right`.

N'importe quel visiteur anonyme pouvait donc **créer, modifier, supprimer et réordonner**
sections, lignes, blocs et contenus de toutes les pages du site. La protection CSRF ne
constituait pas une barrière : les vues publiques posent le cookie via `@ensure_csrf_cookie`.

Correctif : `EditorMutationMixin` (`LoginRequiredMixin` + `PermissionRequiredMixin`,
`change_page`, `raise_exception=True`) appliqué aux 20 vues. Verrouillé par
`ApiAccessTests.test_toutes_les_mutations_de_lediteur_refusent_lanonyme`, qui vérifie
19 endpoints en GET et en POST.

### [ ] A7 — `csrf_exempt` sur la réservation de créneau (hors périmètre)
`calendars/views.py:355` — `APIBookAppointmentView` est légitimement publique, mais
`csrf_exempt`, et `content_calendar.html:374` poste sans jeton. Même famille que A1, dans un
autre module. À traiter séparément.

---

## B. Bugs fonctionnels

### [x] B1 — `formsets.js` chargé deux fois
`base_editor.html:40-41` — une fois en `type="module"`, une fois en `defer`. Le fichier
s'exécute intégralement 2×. Conséquence directe : `Countdown.boot()` pose deux `setInterval`
concurrents sur le même input, et les wrappers `window.addInline`, `window.moveUp`… sont
redéfinis.

### [x] B2 — `executeInlineScripts` n'est appelé qu'à un seul endroit
`editor.js:1145` (dans `editContent`). Les 10 autres emplacements qui font
`old.outerHTML = frag` ne l'appellent pas : `editSection:632`, `editLine:849`,
`resetContent:1181`, `addBloc:1214`, `removeBloc:1253`, `moveBlocUp:1285`,
`moveBlocDown:1312`, `moveBlocLeft:1339`, `moveBlocRight:1366`,
`attachBlocModelHandler:1514`.

`outerHTML` n'exécute jamais les `<script>` (spec HTML). Or les partials rendus contiennent des
scripts inline : `content/dyn/tabs.html:103`, `carousel.html`, `stepper.html`,
`countdown.html`, `progress.html`, `rating.html`, `live_filter.html`, `accordion_adv.html`,
`gallery_filter.html`, `pricing_table.html`, `countdown_cta.html`,
`content/partials/content_video.html`.

Symptôme masqué : ça marche si le type de contenu était déjà présent au chargement initial
(la fonction globale existe déjà). Ça casse pour un type ajouté en cours de session.

### [x] B3 — Sélecteur CSS inexistant
`editor.js:881` — `sectionEl.querySelector('.overlay-section')`. Les classes réelles sont
`.overlay-section-bg` et `.overlay-section-controls` (`partials/section.html:8-9`).
Résultat : après suppression de la dernière ligne d'une section, le message
« Aucune ligne créée pour l'instant » n'est jamais réaffiché.

### [x] B4 — `build_breadcrumb_for_page` ne retourne rien
`views_client.py:15-25` — construit `items` puis termine sans `return`. `breadcrumb` vaut
donc toujours `None` dans le contexte de `RootPage` et `PageView`.

### [x] B5 — `attachBlocModelHandler` sans garde de ré-attachement
`editor.js:1483-1487` — contrairement à `attachAjaxFormHandler` (`editor.js:43`), pas de flag
`_handlerAttached`. Rouvrir le modal empile les handlers : 2 POST, puis 3, puis 4.

### [x] B6 — `attachAjaxFormHandler` : pas de `try/catch`, pas de garde anti double-soumission
`editor.js:47-94` — `await fetch(...)` nu. Coupure réseau ⇒ promesse rejetée non gérée, aucun
retour utilisateur. Le bouton submit n'est jamais désactivé pendant l'envoi ⇒ double-clic =
création en double.

### [x] B7 — `.then()` sans `.catch()`
`editor.js:1200, 1272, 1299, 1326, 1353` — `addBloc`, `moveBlocUp/Down/Left/Right`. Fonctions
déclarées `async` mais écrites en chaînes de promesses, sans branche d'erreur. Toute erreur
réseau ou 500 est silencieuse.

### [x] B8 — Le fond du modal court-circuite `closeModal()`
`utils.js:82` — `onclick="this.parentElement.remove()"`. `closeModal` (`utils.js:139`) est le
seul endroit qui restaure `lastScrollTop`. Cliquer à côté du modal fait donc perdre la
position de défilement. Par ailleurs : pas de fermeture à la touche Échap, pas de piège de
focus, pas de `role="dialog"` / `aria-modal`.

### [x] B9 — `#text-editor` utilisé comme sélecteur multiple
`editor.js:425` — `body.querySelectorAll('#text-editor')`. Un `id` est unique par définition ;
dès que deux zones de texte cohabiteront dans le modal, comportement indéfini.

### [x] B10 — Détection d'état vide par le texte d'un `<h4>`
`editor.js:554-556` — `noMsg.textContent.includes("Aucune section")`. Casse au premier
changement de libellé ou de balise.

### [x] B16 — Le héros n'était jamais recalculé pour un bloc ou un contenu
Révélé par F13 : dès que les `except Exception: pass` ont été remplacés par
`logger.exception`, chaque création de `Bloc` ou de `Content` a fait remonter un
`FieldError: Cannot resolve keyword 'page_id' into field`.

`_page_id_of_bloc` et `_page_id_of_content` (`signals.py`) interrogeaient `Line.page_id`.
Or `Line` n'a **pas** de clé étrangère vers `Page` — seulement `section_id`. Un commentaire
« si Line a un FK direct vers Page » entérinait une hypothèse fausse. La requête levait donc
systématiquement, l'exception était avalée, et `recompute_page_hero` n'était jamais appelé
lors d'une modification de bloc ou de contenu : **seules les sections et les lignes
déclenchaient réellement le recalcul**. Ajouter une image censée devenir le héros de la page
ne produisait aucun effet.

Correctif : un unique `_page_id_from_line_id` qui remonte `Line.section_id → Section.page_id`,
utilisé par les trois résolveurs. Verrouillé par `HeroResolverTests`.

### [x] B14 — L'éditeur de champ est monté dans le formulaire principal (signalé par l'utilisateur)
`edit_formulaire.html:155` — `#field-inline-editor` se trouve **à l'intérieur** de
`<form id="content-edit-form">` (ouvert l. 3, fermé l. 178). `mountEditor` y injecte des
contrôles nommés `label`, `name`, `placeholder`, `type`, `required`, `options`.

Or le formulaire porte déjà `<input name="name">` — le **Titre du formulaire** (l. 24). Deux
contrôles homonymes dans un même `<form>` : à la soumission, `request.POST.get("name")`
renvoie le dernier, donc le « Nom technique » du champ **écrasait le titre du formulaire**.

Second effet : ces contrôles étaient marqués `required`. Un éditeur de champ ouvert avec des
saisies vides **empêchait purement et simplement l'enregistrement du bloc**, via la validation
native HTML, sans message visible si la zone était hors écran.

Correctif : les contrôles sont rattachés à un `<form>` inexistant via l'attribut
`form="jeiko-detached-field-editor"`. Ils restent éditables mais n'appartiennent à aucun
formulaire, ne sont jamais soumis, et leur validation ne bloque plus rien. La validation
(label et nom techniques obligatoires) est faite en JS, avec un message dans l'éditeur.
`placeholder` redevient facultatif, conformément au modèle (`models.py:2363`, `blank=True`).

### [x] B15 — `id` dupliqué
`edit_formulaire.html:154-158` — deux `<div id="field-inline-editor">` dans les deux branches
d'un `{% if %}`... mais l'une comme l'autre étaient rendues dans le même document selon la
branche. Fusionnées en un seul élément.

### [x] B13 — Les lignes ne peuvent pas être déplacées (signalé par l'utilisateur)
`editor.js:891-948` — `moveLineUp` / `moveLineDown` ignoraient le `section_html` renvoyé par
le serveur et réordonnaient le DOM à la main :
`sectionEl.insertBefore(lines[idx], lines[idx - 1])`.

Or `insertBefore` exige que le nœud de référence soit un **enfant direct** du nœud appelant.
Les lignes sont enfants de `.section-content-wrapper` (`partials/section.html:20`), pas de
`#section-N` : l'appel levait donc `NotFoundError` et rien ne bougeait.

Les sections fonctionnaient parce qu'elles *sont* enfants directs de `#content`
(`editor.js:690`), et les blocs parce qu'ils passent par le remplacement de `section_html`.

Le serveur (`views.py:1660-1718`) était correct : il échange bien les `position` et renvoie la
section rendue. Corrigé en utilisant ce fragment, via un nouvel helper `replaceSection()`
(`editor.js`) qui remplace + exécute les scripts inline + réinitialise Alpine et les overlays.
Cet helper est la préfiguration de `applyEditorResponse()` du lot 3.

### [x] B17 — Balise `{% with %}` multi-lignes : les blocs vidéo étaient cassés
Trouvé par la compilation systématique des 307 templates (vérification de fin de lot 5).

Même racine que B12, mais sur une balise et non un commentaire : le lexer de Django est
`tag_re = r"({%.*?%}|{{.*?}}|{#.*?#})"`, **sans `re.DOTALL`**. Une balise contenant un saut de
ligne n'est donc pas reconnue et ressort en texte brut.

`content_video.html:59-63` ouvrait un `{% with %}` sur cinq lignes. Résultat : le `{% endwith %}`
de la ligne 65 se retrouvait orphelin à l'intérieur d'un `{% if %}`, et le template entier
levait `TemplateSyntaxError`. Or il est inclus par `partials/bloc.html:78` :
**toute page contenant un bloc vidéo YouTube renvoyait une erreur 500.**

Le bloc était en outre entièrement mort : ses variables `start`, `end` et `qs` n'étaient
utilisées nulle part — l'`<iframe>` reconstruit son URL depuis `video.*` — et son unique sortie
aurait été d'imprimer une chaîne de paramètres en clair dans la page. Supprimé.

Contrôle : le scan de toutes les balises multi-lignes ne renvoie plus rien, et le rendu du
partial avec un contexte vidéo produit bien l'`<iframe>` sans fuite de balise.

### [x] B12 — Commentaires Django `{# #}` sur plusieurs lignes (signalé par l'utilisateur)
La syntaxe `{# … #}` ne fonctionne **que sur une seule ligne** : dès qu'un retour à la ligne
sépare `{#` de `#}`, le moteur ne reconnaît plus un commentaire et rend le contenu comme du
texte brut — en évaluant au passage les `{{ variables }}` qu'il contient.

Trois occurrences, toutes converties en `{% comment %}` :

- `base.html:79-81` et `base.html:92-94` — rendues dans `<head>`. Du texte dans `<head>`
  force le navigateur à ouvrir `<body>` immédiatement : **`<meta name="robots">` (l. 84, 88)
  et `<link rel="canonical">` (l. 96, 98) se retrouvaient dans le corps de page, donc ignorés
  par les moteurs de recherche.** Les pages non publiées n'étaient plus en `noindex`.
- `base.html:13-15` — dans un `{% if custom_object %}`, donc jamais vu sur une page normale.
  Sur une page d'objet custom, la coupure survenait **avant** le `<title>` et la meta
  description, qui basculaient eux aussi dans `<body>`.
- `custom_objects/admin/object_list.html:93-95` — un lien « voir en ligne » mis en commentaire
  s'affichait réellement dans la liste d'administration, encadré de `{#` et `#}`, avec son
  `href` évalué.

Contrôle : `grep -rn "{#" templates/ | grep -v "#}"` doit ne rien renvoyer.

### [ ] B11 — `window.addInline` défini deux fois avec des signatures incompatibles
`formsets.js:212` → `(prefix) => Formsets.addInline(prefix, '.${prefix}-item')`
`content/edit_dyn/edit_dyn_faq.html:114` → `function addInline(prefix){…}` (implémentation
complète, autre comportement). Le gagnant dépend de l'ordre d'exécution, lui-même dépendant de
B2. Vérifier aussi les autres `<script>` de `content/edit_dyn/*`.

---

## C. Performance

### [x] C1 — N+1 massif sur le rendu des pages publiques
`views_client.py:79` — `render()` sans aucun `prefetch_related` sur l'arbre.
`templates/pages/main.html:6` itère `page.sections.all` → `section.lines.all`
(`partials/section.html:69`) → `line.blocs.all` (`partials/line.html:70`) →
`bloc.content.*` (`partials/bloc.html`).

`StylableElement` (`models.py:1089-1210`) porte **14 relations** :
`margin_{phone,tablet,laptop,computer}`, `padding_×4`, `size_×4`, `background_image`,
`background_image_parameters` — toutes lues par `styles/{section,line,bloc}.html`.

Ordre de grandeur pour 10 sections × 3 lignes × 3 blocs = 120 éléments stylables :
> 1 700 requêtes par affichage de page.

Le prefetch existe déjà et fonctionne dans `signals.py:235-238` — il n'a jamais été porté sur
le chemin de rendu.

### [x] C2 — `cache.clear()` global, 30+ appels
`views.py:192, 278, 936, 997, 1052, 1343, 1364, 1586, 1651, 1683, 1713, 2077, 2765, 2848`
plus `administration/views.py` et `administration_menu/views.py`.

Déplacer un bloc d'un cran purge **tout** le cache du site : métadonnées, blocs `{% cache %}`
de `base.html` (`site_assets_block`, `site_identity_block`, `head_meta_block`), menus, et le
cache de toutes les autres pages. Un seul contre-exemple correct dans la base :
`administration_menu/views.py:143` (« Invalide les clés ciblées (évite cache.clear()) »).

### [x] C9 — `cache.clear()` purgeait le cache des polices à chaque édition
Conséquence mesurée de C2. Le bloc `{% cache 2592000 "site_assets_block" %}` de `base.html`
englobe `google_fonts.html` et `base_style.html`, dont la construction coûte **36 requêtes**
(33 sur `administration_font`, 3 sur `administration_fonts`).

Or `PageEditor.post` et neuf vues de mutation appelaient `cache.clear()`. Autrement dit :
**ouvrir l'éditeur, ou déplacer une ligne, purgeait ce cache**, et le visiteur suivant payait
les 36 requêtes. Rien de ce qui est mis en cache ne dépend pourtant de l'arborescence des
pages — l'appel était superstitieux, ce que confirme son absence sur des vues équivalentes
(`SectionUpdate`, `BlocMoveUp`… ne l'avaient jamais eu).

Retiré de 10 vues. Conservé sur les 4 opérations rares et globales (`PageAdd`, `PageUpdate`,
`PageDelete`, `ModelDelete`).

À noter, hors périmètre : 36 requêtes pour construire les polices reste beaucoup. Le N+1 est
dans le module `administration`, pas ici.

### [~] C3 — Aucun cache sur les pages publiques *(volontairement non fait)*
Le prefetch de C1 rend un cache de page inutile pour le problème initial : le rendu est
descendu à **27 requêtes constantes**, quelle que soit la taille de la page.

Et l'ajouter serait dangereux en l'état : `content/partials/content_formulaire.html` et
`content/partials/content_button.html` contiennent `{% csrf_token %}` et sont rendus **à
l'intérieur des sections**. Un fragment de section mis en cache figerait le jeton, et tous les
visiteurs suivants recevraient un 403 en soumettant le formulaire. `cache_page` est exclu pour
la même raison, `PageView` étant décorée `@ensure_csrf_cookie`.

Rouvrir le sujet supposerait soit de n'appliquer le cache qu'aux sections sans formulaire,
soit d'injecter le jeton CSRF par JS après coup. À arbitrer si le besoin se présente.
`views_client.py` — `RootPage` et `PageView` ne posent ni `cache_page`, ni cache de fragment,
ni `ETag`/`Last-Modified`. Combiné à C1, chaque visite anonyme paie le coût complet.

### [x] C4 — Fuite mémoire : listeners `resize` jamais retirés
`editor.js:255-259` — `window.addEventListener('resize', …)` est enregistré **une fois par
ligne**, à l'intérieur de la boucle `.line`. Aucun `removeEventListener`. Après chaque
remplacement de section par `outerHTML`, les anciens handlers survivent et référencent des
éléments détachés du DOM (fuite de closure + travail inutile à chaque redimensionnement).

### [x] C5 — Double réinitialisation systématique de l'UI
Motif présent 12 fois : `reinitUI(nouvelleSection)` puis `reinitUI(document)`.
Ex. `editor.js:1214+1219`, `1253+1258`, `1285+1289`, `1312+1316`, `1339+1344`, `1366+1370`,
`1515+1519`. Le second appel relance `Alpine.initTree(document)` et `initOverlayHandlers` sur
la page entière, et peut réinitialiser l'état Alpine de blocs qui n'ont pas bougé (onglet
actif, slide courant d'un carousel).

### [x] C8 — `initOverlayHandlers` ignore l'élément racine
`editor.js` — `scope.querySelectorAll('.section')` ne cherche que dans les **descendants**.
Quand la racine passée *est* la section (remplacement ciblé), aucune section n'est trouvée et
plus rien n'est branché : les overlays disparaissaient jusqu'au rechargement de la page.

Le bug était masqué par le `reinitUI(document)` redondant de C5, qui rebranchait tout à chaque
fois. Il est apparu dès que ce second appel a été retiré. Corrigé en incluant la racine
lorsqu'elle correspond elle-même au sélecteur — ce qui rend `reinitUI(document)` réellement
inutile et débloque C5.

### [x] C7 — Recalcul complet du héros à *chaque* enregistrement (important)
`signals.py:431-508` — huit récepteurs `post_save` / `post_delete` sur `Section`, `Line`,
`Bloc`, `Content`. Chacun appelle :

1. `_mark_page_non_default` → 1 `UPDATE` (`signals.py:415`)
2. `_recompute_for_page_id` → 1 `SELECT` sur `Page` (`signals.py:407`)
3. `recompute_page_hero` → parcours **complet** de la page avec prefetch imbriqué
   (`signals.py:235-259`) + 3 `UPDATE` en masse (`signals.py:276-278`)

Il n'y a ni `transaction.on_commit`, ni déduplication : le coût est payé **par objet
enregistré**, pas par requête.

Conséquence sur la duplication de section — la fonctionnalité la plus utilisée :
une section de 3 lignes × 3 blocs (avec contenus) déclenche ~22 `save()`, donc **22 parcours
complets de la page** à l'intérieur d'un même `@transaction.atomic`. Le coût croît avec la
taille de la page *et* avec la taille de l'élément dupliqué.

Correctif : différer via `transaction.on_commit` et dédupliquer par `page_id` sur la durée de
la transaction. ~15 lignes, aucune migration.

### [~] C6 — Rendu serveur de la section entière pour chaque micro-action
Un `moveBlocUp` re-sérialise toute la section, ses lignes, ses blocs, ses contenus et son
`<style>` (`views.py:2887, 2916, 2975, 3034`). Coûteux côté serveur, et côté client cela
détruit tout l'état DOM non persisté de la section.

---

## D. Ergonomie des overlays d'édition

### [x] D1 — Le survol ne réagit pas immédiatement après une action (cause racine)
`initOverlayHandlers` (`editor.js:98-262`) repose exclusivement sur `mouseenter` /
`mouseleave`. Après `old.outerHTML = frag`, la nouvelle section apparaît **sous le curseur**
sans qu'aucun franchissement de frontière ne se produise : le navigateur n'émet donc aucun
`mouseenter`. Il faut sortir de l'élément et y revenir pour que les contrôles apparaissent.

C'est exactement le symptôme « ça ne marche pas tout de suite ».

### [x] D2 — `pointer-events: none` rend les handlers de la barre de bloc inopérants
`editor.css:627` — `.overlay-block-controls { pointer-events: none; }`.
Un élément non ciblable par le pointeur ne reçoit ni `:hover` ni `mouseenter`. Or
`editor.js:228` teste `isHover(blockCtrls)` et `editor.js:250-251` attache
`mouseenter`/`mouseleave` sur `blockCtrls` : ces trois lignes ne s'exécutent jamais.

La barre ne reste visible que parce qu'elle est centrée *à l'intérieur* du bloc
(`editor.css:601-602`) et que survoler la barre survole donc le bloc. Sur les bords du bloc,
ou si la barre déborde, elle disparaît sous le curseur. Source principale du scintillement.

### [x] D3 — Le décalage anti-collision est calculé en JS
`editor.js:120-132` (`placeLineControls`) + `editor.css:589-598` (`--line-x`). Les barres
Section, Ligne et Bloc sont toutes ancrées `left:0; top:0` avec la même transformation, donc
elles se superposent quand une section, une ligne et un bloc partagent le même bord haut. D'où
la mesure de `sectionCtrls.offsetWidth` et la tolérance `FIRST_LINE_TOL = 10`.

Un ancrage à des coins distincts supprime le besoin de tout ce calcul (voir plan §G).

### [ ] D4 — Poids DOM des overlays
`partials/section.html:8-9`, `partials/line.html:10-11`, `partials/line.html:115-116` :
**2 nœuds `<div>` supplémentaires par section, par ligne et par bloc**, plus un `<button>` par
action (jusqu'à 8 par bloc). Sur une page de 120 éléments : ~240 divs et plusieurs centaines de
boutons rendus systématiquement, y compris pour des éléments jamais survolés.

### [x] D5 — `initOverlayHandlers` : 165 lignes de machine à états implicite
Chaque `mouseleave` re-teste `:hover` sur les frères, le parent et les barres
(`editor.js:153-156, 195-199, 232-245`). Toute nouvelle configuration d'imbrication demande un
nouveau test croisé. Non testable, non extensible.

---

## E. Système de modèles (« models »)

### État actuel

Trois champs sur `Section`, `Line`, `Bloc` (`models.py:1281-1302, 1330-1351, 1515-1536`) :
`is_model` (booléen), `model_name` (chaîne), `model_source` (FK réflexive,
`related_name="model_copies"`).

Création (`views_api.py:468, 508, 552`) : duplication profonde de l'objet, la copie est
détachée de son parent (`page=None` / `section=None` / `line=None`) et marquée `is_model=True`.
Puis la **source** reçoit `model_source = copie`.

Utilisation (`views.py:1179-1186, 1493-1502, 2052-2073`) : à l'insertion depuis un modèle,
duplication profonde du modèle, `is_model=False` sur la copie, `model_source = modèle`.

Bibliothèque (`views.py:1008`, `templates/administration_pages/models/main.html`) : liste
`model_name` + lien de suppression.

### [ ] E1 — `model_source` est écrit mais jamais lu
Vérifié sur l'ensemble du paquet : aucune occurrence de `model_source` en lecture ni de
`model_copies` en dehors des définitions de champ et des migrations. La relation qui
permettrait la synchronisation existe déjà en base et n'alimente rien.

### [ ] E2 — Un modèle n'est pas éditable
Aucune vue d'édition. `ModelLibrary` (`views.py:1008`) n'expose que nom + suppression ;
`ModelDelete` (`views.py:1021`) est la seule action. Les vues d'édition de section / ligne /
bloc passent par `page_id` / `section_id` / `line_id` dans l'URL (`urls.py:129` et voisines) —
un modèle ayant `page=None` / `section=None` / `line=None` n'est adressable par aucune d'elles.

### [ ] E3 — `model_name` n'est ni obligatoire, ni unique, ni renommable
`models.py:1295` — `default=""`, `null=True`, `blank=True`, aucune contrainte d'unicité. Deux
modèles peuvent porter le même nom ; la bibliothèque n'offre pas de renommage.

### [ ] E4 — La sémantique de `model_source` sur la *source* est contre-intuitive
`views_api.py:495-496, 539-540, 582-583` : après « faire un modèle depuis cette section », la
section d'origine pointe vers le modèle. Elle devient donc indistinguable d'une instance créée
*depuis* le modèle. Si une synchronisation descendante est ajoutée plus tard, la section
d'origine sera écrasée par sa propre copie.

### [ ] E5 — Pas d'aperçu, pas de compteur d'utilisation, pas de suppression sûre
`models/main.html` — aucune vignette, aucun décompte d'instances. `on_delete=SET_NULL` fait
que supprimer un modèle rompt silencieusement le lien de toutes ses copies.

### [ ] E6 — La bibliothèque n'est pas paginée ni filtrable
`views.py:1013-1016` — trois `QuerySet` complets chargés à chaque affichage.

---

## F. Dette technique

### [x] F1 — Le contrat JSON serveur → client n'est pas fixé
Clé HTML selon les vues : `html` (`views.py:1119, 1193, 1435, 2024`),
`section_html` (`1484, 1620, 2082, 2702, 2768…`), `content_html` (`1290`).
Clé de statut : `"success"`, `"ok"` (`editor.js:1109`), `"reset"` (`2768`),
`"choose_type"`, `"no_content"` (`2718`), plus `success: true` booléen dans `views_api.py`.

Côté client, le contournement `data.section_html || data.line_html || data.html || ''`
apparaît **12 fois**.

### [x] F2 — 11 fonctions CRUD dupliquées
`moveBlocUp/Down/Left/Right` (`editor.js:1270-1375`) sont identiques à l'URL près : 105 lignes
pour 4 comportements. Idem `moveSectionUp/Down` (`674-731`), `moveLineUp/Down` (`891-948`), et
`makeSectionModel` / `makeLineModel` / `makeBlocModel` / `makeContentModel`
(`734, 951, 1431, 1379`) — quatre copies d'une cinquantaine de lignes.

### [ ] F3 — ~30 exports globaux + `onclick` inline
`editor.js:1874-1908`. Alimentent les `onclick="editSection(3, 12)"` des partials
(`section.html:11-15`, `line.html:13-17, 118-137`). Annule le bénéfice des modules ES,
provoque B11, et rend impossible une CSP sans `unsafe-inline`.

### [x] F4 — `getCSRF()` et `getCookie()` font la même chose
`utils.js:5-15` et `utils.js:17-30`. Les deux sont utilisées.

### [x] F5 — Fichiers morts dans `static/`
`editor/editor_old.js` (1 282 lignes, 43 Ko) — non référencé.
`editor/quill_text_edit.js` — vide, non référencé.
`js/menu_design_1.js` — doublon exact de `js/menu/menu_design_1.js` (la copie hors du dossier
`menu/` a été supprimée, celle de `menu/` est conservée : aucune des deux n'est référencée
aujourd'hui, mais le CSS `menu_design_1.css` correspondant est bien utilisé).
`templates/administration_pages/line/add_or_update_old.html` — non référencé.
45 fichiers `.DS_Store` (F18).

⚠️ Correction de l'audit : `alpine-blocks.min.js` **est** utilisé — `base.html:67` le charge
dans la branche non-DEBUG. Il est conservé. Seul `base_editor.html` charge la version non
minifiée, d'où l'erreur initiale.

Restent en place, morts mais non supprimés faute de certitude : `templates/base/base.html` et
`templates/base/base_admin.html` (aucun `{% extends %}` ne les cible).

### [x] F6 — `</head>` en double
`base_editor.html:59` et `base_editor.html:61`.

### [x] F7 — Variable déclarée et non utilisée
`editor.js:515` — `const form = body.querySelector('#content-edit-form');`

### [x] F8 — ~15 `setTimeout(…, 0)` inutiles
`editor.js:598, 627, 812, 821, 844, 1025, 1137` etc. `showModal` (`utils.js:70`) est
synchrone : le DOM est prêt au retour. Ces temporisations masquent des ordres d'exécution mal
maîtrisés plutôt qu'elles ne résolvent un problème.

### [x] F9 — `print()` en production
`views_api.py:65, 78`.

### [x] F10 — Imports dupliqués
`views_api.py:26-30` — `ContentFormulaire`, `ContentFormField`, `ContentFormSubmission`,
`PageInsights`, `InsightAuditOutcome`, `InsightAuditCategory` importés deux fois dans le même
bloc.

### [x] F11 — `logger` défini deux fois
`views_api.py:17` (`getLogger("administration_pages")`) puis `views_api.py:607`
(`getLogger(__name__)`). Le second écrase le premier.

### [x] F13 — `except Exception: pass` sur tous les signaux
`signals.py:437, 447, 457, 467, 477, 487, 497, 507, 424` — dix blocs qui avalent
silencieusement toute erreur. Si le calcul du héros casse, rien ne le signale. À remplacer par
un `logger.exception(...)` : le comportement « ne jamais casser la requête » est conservé, mais
l'erreur devient visible.

### [x] F14 — `print()` en production (suite de F9)
`signals.py:138` — `print(f"[signal] post_save pk={instance.pk} async={async_mode}")`, exécuté
à chaque enregistrement d'`ImageContent`.

### [x] F15 — Clés `{% cache %}` construites sur des variables inexistantes
`base_editor.html:12` — `{% cache 2000000 title meta meta.id %}` : `title` n'est pas dans le
contexte (le contexte fournit `page`), donc la variable vaut la chaîne vide. Sauvé de justesse
par `meta.id`.
`base_editor.html:18` — `{% cache 2000000 title nometa %}` : **les deux** variables sont
inexistantes. La clé est donc identique pour toutes les pages : **toutes les pages sans
metadata partagent le même `<title>` en cache**. Même motif dans
`base_questionnaire.html:19, 25` et `base/base.html:11, 17`.

### [x] F16 — Tri instable *(reporté au lot 6 : génère une migration)*
`models.py:1309-1310` (et équivalents `Line` / `Bloc`) — `ordering = ('position',)` alors que
`position` est `null=True`. Le placement des `NULL` dépend du moteur de base, et deux éléments
peuvent partager la même `position` (aucune contrainte d'unicité) : l'ordre d'affichage n'est
pas déterministe. Ajouter `'id'` en critère secondaire.

### [x] F17 — Double préfixe d'URL
`urls_api.py:52` — `"api/pages/<int:page_id>/insights/refresh/"` déclaré dans un fichier déjà
monté sur `api/pages/` (`urls.py:24`). L'URL réelle est
`/api/pages/api/pages/<id>/insights/refresh/`. Fonctionne car le template passe par
`{% url %}` (`insight.html:9`).

### [x] F18 — `.DS_Store` livrés dans le paquet
`administration_pages/.DS_Store`, `administration_pages/migrations/.DS_Store`,
`templates/administration_pages/.DS_Store`.

### [x] F12 — `moveField` : commentaire trompeur
`editor.js:1690` — « swap visuel » sur un tableau JavaScript qui ne touche pas le DOM. Le
tableau ne sert qu'à calculer `newOrder` ; le rendu vient de `reloadFieldsList`.

---

## G. Ce qui fonctionne bien — à préserver

- **Duplication profonde** (`utils.py:814-1199`). Le cache local
  `{'stylebox','size','image','bgparams'}` évite de re-dupliquer un objet de style partagé ; la
  non-propagation de `as_model` / `link_model` aux enfants est explicite et documentée
  (`utils.py:1085-1086, 1148-1149`) ; `@transaction.atomic` sur les trois niveaux. C'est la
  brique la plus solide du module et la fondation naturelle du système de modèles.
- **Le choix « fragments HTML » plutôt que JSON + rendu client.** C'est ce qui permet à
  `styles/section.html` de générer un CSS scopé par élément côté Django, avec `mq_to_cq`. Un
  rendu client obligerait à réimplémenter tout le moteur de style en JS.
- **`formsets.js`** — IIFE propre, une seule responsabilité, pas de fuite dans le global au-delà
  des wrappers explicites.
- **`initQuillInModal`** (`editor.js:424-519`) — la résolution de la valeur initiale (DOM vs
  input caché vs vide) est réfléchie et correctement commentée.
- **`recompute_page_hero`** (`signals.py:262`) — idempotent, atomique, avec prefetch.

---

## H. Ordre de traitement proposé

| Lot | Contenu | Risque | Effet |
|-----|---------|--------|-------|
| 1 | A1 → A5 | faible | ferme les APIs et les XSS |
| 2 | B1, B3, B4, B5, F6, F7, F9, F10, F11, F5 | nul | bugs isolés + nettoyage |
| 3 | F1 (contrat JSON unique) puis B2, C5 | moyen | supprime les 12 `\|\|` et la double réinit |
| 4 | F2 (table d'actions) | moyen | `editor.js` ~1 900 → ~800 lignes |
| 5 | D1, D2, D3, D4, C4 (overlays en CSS + délégation) | moyen | corrige la latence et les collisions |
| 6 | C1, C2, C3 (prefetch + invalidation ciblée + cache page) | moyen | performance publique |
| 7 | E1 → E6 (modèles éditables + synchronisation) | élevé | nouvelle fonctionnalité |
| 8 | F3 (suppression des globaux et des `onclick`) | élevé | touche tous les partials |
