# jeiko/administration_pages/tests_bloc_cloak.py
"""
`x-cloak` ne doit éteindre que le menu — jamais le contenu des pages.

Ce qui s'est passé
------------------
`menu.css` portait, sous 992 px, une règle d'anti-flash pour le panneau du
menu mobile. Son sélecteur, `[x-cloak="menu"]`, était cassé : Alpine écrit
`x-cloak=""`, donc la règle ne correspondait à rien. En la corrigeant on l'a
élargie à `[x-cloak]` tout court.

Or `partials/bloc.html` posait un `x-cloak` sur **chaque bloc de chaque page**,
et Alpine ne le retire jamais : le bloc ne porte aucun `x-data`, ce n'est pas
un composant, Alpine ne le visite pas. La règle a donc trouvé six blocs par
page au lieu d'un panneau de menu, et les a passés en
`display:none !important`.

Résultat : **plus aucun contenu sous 992 px**, ni sur le site public, ni dans
l'éditeur. Au-dessus de 992 px, rien. D'où un défaut invisible en
développement, sur un écran d'ordinateur, et invisible aux tests : le HTML
était rendu, complet et correct — c'est le CSS qui l'effaçait.

Deux verrous, parce qu'il a fallu deux erreurs pour éteindre le site :

* le sélecteur reste borné au menu (`nav.top-menu [x-cloak]`) ;
* le bloc ne porte plus d'attribut `x-cloak` inutile.

L'un des deux suffit à empêcher le retour du défaut. Les deux ensemble font
qu'aucune règle `[x-cloak]` écrite plus tard, où que ce soit, ne pourra
éteindre une page.
"""

import pathlib
import re

from django.template.loader import render_to_string
from django.test import RequestFactory, SimpleTestCase

#: Racine des feuilles de style livrées avec le paquet.
CSS = pathlib.Path(__file__).resolve().parent.parent / "static" / "jeiko" / "css"

#: Un sélecteur `[x-cloak]` et ce qui le précède immédiatement sur la ligne.
_SELECTEUR = re.compile(r"([^\n{};,]*)\[x-cloak[^\]]*\]")

#: Les commentaires CSS — retirés avant l'analyse, sans quoi le commentaire qui
#: *raconte* le défaut se ferait prendre pour le défaut. Les lignes sont
#: remplacées par du vide plutôt que supprimées, pour garder la numérotation.
_COMMENTAIRE = re.compile(r"/\*.*?\*/", re.DOTALL)


def _sans_commentaires(texte):
    return _COMMENTAIRE.sub(
        lambda trouve: "\n" * trouve.group().count("\n"), texte
    )


class _ContenuFactice:
    """Un contenu d'aucun type connu : aucune branche d'inclusion ne s'ouvre."""

    content_type = ""
    CSS_parameters = None


class _BlocFactice:
    """Le strict minimum que consulte l'enveloppe du bloc."""

    id = 42
    content = _ContenuFactice()
    background_image = None
    background_image_parameters = None


def _rendre_un_bloc():
    """
    Rend l'enveloppe du bloc telle que la reçoit le navigateur.

    `request` est nécessaire : `styles/bloc.html` passe par
    `{% filter mq_to_cq:request %}`, qui lève sans lui.
    """
    return render_to_string(
        "administration_pages/partials/bloc.html",
        {"bloc": _BlocFactice(), "request": RequestFactory().get("/")},
    )


class EnveloppeDuBlocTests(SimpleTestCase):
    def test_le_bloc_ne_porte_pas_de_x_cloak(self):
        """
        Un `x-cloak` que personne ne retire est une page éteinte en attente.

        L'attribut ne protège d'aucun flash ici — le bloc est du HTML rendu par
        Django, pas un composant Alpine. Les blocs dynamiques qui ont vraiment
        besoin d'attendre le posent sur leur propre racine `x-data`
        (`content/dyn/*.html`), qu'Alpine initialise et découvre.
        """
        html = _rendre_un_bloc()
        self.assertIn('class="bloc bloc-42', html)  # on a bien rendu l'enveloppe
        self.assertNotIn(
            "x-cloak", html,
            "Le bloc porte à nouveau un x-cloak qu'Alpine ne retirera pas : "
            "il suffit d'une règle [x-cloak] pour éteindre toutes les pages.",
        )


class PorteeDesReglesXCloakTests(SimpleTestCase):
    def test_aucune_feuille_ne_cache_x_cloak_globalement(self):
        """
        Toute règle `[x-cloak]` doit être bornée à `nav.top-menu`.

        On lit les feuilles livrées, pas le rendu : c'est le fichier qui part
        chez le client, et une règle non bornée y est dangereuse quel que soit
        le gabarit qui la déclenchera un jour.
        """
        coupables = []
        for feuille in sorted(CSS.rglob("*.css")):
            contenu = _sans_commentaires(feuille.read_text())
            for numero, ligne in enumerate(contenu.splitlines(), 1):
                for prefixe in _SELECTEUR.findall(ligne):
                    if "nav.top-menu" not in prefixe:
                        coupables.append(
                            f"{feuille.relative_to(CSS)}:{numero} — {ligne.strip()}"
                        )

        self.assertEqual(
            coupables, [],
            "Règle [x-cloak] non bornée au menu :\n  "
            + "\n  ".join(coupables)
            + "\nElle s'appliquera à tout élément portant l'attribut, y compris "
              "hors du menu. Préfixer par « nav.top-menu ».",
        )
