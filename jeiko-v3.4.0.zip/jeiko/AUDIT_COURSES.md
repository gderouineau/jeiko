# Audit — module de formation (`courses`)

Périmètre : `courses/{models,storage,utils}.py`, `courses/views/{client,admin_ordering}.py`,
`courses/forms/admin.py`, `courses/admin.py`, `courses/migrations/`,
`templates/courses/section_view.html`, et côté serveur
`INSTALLER/scripts/11_configure_nginx.sh` + `INSTALLER/templates/settings.template.py`.

Légende statut : `[ ]` à traiter · `[~]` en cours · `[x]` corrigé

Les quatre correctifs ci-dessous sont **appliqués** dans le package
(`ENV/lib/python3.10/site-packages/jeiko`) et l'installeur. Ils atteignent les
sites en production par la chaîne habituelle — voir « G. Déploiement ».

---

## Synthèse

| # | Constat | Gravité | État |
|---|---|---|---|
| A1 | L'`access_token` du compte Vimeo était injecté dans l'URL du lecteur | Élevée | corrigé |
| A2 | Vidéos et PDF de cours servis sans authentification sur `/media/` | Élevée | corrigé |
| B1 | Quiz à choix multiples toujours comptés faux | Fonctionnel | corrigé |
| B2 | Réordonnancement partie/chapitre/section en `IntegrityError` | Fonctionnel | corrigé |

---

## A. Sécurité

### [x] A1 — Fuite de l'`access_token` Vimeo dans l'URL du lecteur (élevée)
`storage.py:44-55` (`_get_vimeo_signed_url`), `utils.py:251-275` (`get_provider_video_url`).

L'ancien code injectait l'`access_token` du compte (jeton d'API donnant accès à
**tout** le compte Vimeo) dans l'URL rendue dans la page du lecteur, exposée à
tout visiteur. En prime, la lecture était souvent cassée car un access_token
n'est pas le bon paramètre pour une vidéo non listée.

Correctif : nouveau champ par vidéo `remote_video_hash` (`models.py:424`, après
`remote_video_id`). La branche Vimeo construit désormais
`https://player.vimeo.com/video/<id>?h=<hash>` (`utils.py:270-275`) et l'URL
signée s'appuie sur ce hash (`storage.py:55`). L'`access_token` n'apparaît plus
jamais dans une URL rendue. Le champ est exposé à l'admin
(`forms/admin.py:120,129`, `admin.py:241`) avec un `help_text` qui interdit
explicitement d'y placer un token d'API. Migration `0002_videocontent_remote_video_hash`.

Le hash est le suffixe de l'URL de partage : `vimeo.com/76979871/<abcdef1234>`
→ `remote_video_hash = abcdef1234`. Vidéos publiques/listées : laisser vide.

### [x] A2 — Médias de cours servis sans authentification (élevée)
`views/client.py:641-712` (`_serve_protected_file`, `serve_video`, `serve_pdf`),
`templates/courses/section_view.html:64-73`,
`INSTALLER/scripts/11_configure_nginx.sh`, `INSTALLER/templates/settings.template.py`.

Les uploads vont dans `mediadir/courses/videos/` et `.../pdfs/`, et nginx les
servait publiquement sur `/media/…`. Une URL devinée contournait donc toute
authentification et tout contrôle d'accès à la formation payante. Le template
exposait de plus `content.file.url` (`/media/...`) directement dans l'`<embed>` PDF.

Correctif, en trois points :
- **Application** : `serve_video` / `serve_pdf` (`@login_required` + contrôle des
  droits) passent par `_serve_protected_file`. Si `COURSES_XACCEL_MEDIA_PREFIX`
  est défini, la lecture est déléguée à nginx via `X-Accel-Redirect`
  (`client.py:659-666`) ; sinon (dev) Django streame en `FileResponse`, qui gère
  nativement le HTTP Range (seek). Le template pointe l'`<embed>` PDF sur
  `serve_pdf` (`section_view.html:66,73`), plus jamais sur `content.file.url`.
- **Settings** : `COURSES_XACCEL_MEDIA_PREFIX = "/protected-media"` dans le
  gabarit de l'installeur (`INSTALLER/templates/settings.template.py`), donc
  réaligné sur tous les sites par `jeiko-client-update`.
- **nginx** (`11_configure_nginx.sh`) : `location ^~ /media/courses/videos/` et
  `^~ /media/courses/pdfs/` renvoient `404` (le `^~` prime sur `/media/`) ; une
  `location /protected-media/ { internal; alias $MEDIA_ROOT/; }` n'est atteignable
  que via le `X-Accel-Redirect` émis par Django. **Les miniatures
  (`courses/thumbnails/`, `courses/video_thumbnails/`) restent publiques** et ne
  sont pas bloquées.

Droits de lecture nginx sur les fichiers protégés : garantis par le modèle de
permissions existant (`lib/jeiko-common.sh`) — dossiers `2750` setgid + fichiers
`0640` + `chown …:www-data` sur `mediadir` — donc nginx (www-data) lit les
fichiers en direct pour le X-Accel, sans intervention. Réappliqué à chaque
`jeiko-server-update` [5/8].

Résiduel connu (hors périmètre de ce correctif) : un fichier servi via
`/protected-media/` ne reçoit pas l'en-tête CSP `sandbox` du bloc « médias
exécutables » (ancré sur `^/media/`). Risque faible : uploads limités aux champs
vidéo/PDF, accès authentifié et contrôlé.

---

## B. Bugs fonctionnels

### [x] B1 — Quiz à choix multiples toujours comptés faux
`views/client.py:398-438` (`quiz_submit`).

Pour une question à réponses multiples, plusieurs `<input>` partagent le même
`name`. L'ancien code lisait `request.POST.get(name)`, qui ne renvoie que la
**dernière** valeur : dès qu'au moins deux bonnes réponses étaient attendues, le
score était systématiquement faux. Correctif : lecture par
`request.POST.getlist(key)` (`client.py:438`), qui récupère toutes les valeurs cochées.

### [x] B2 — Réordonnancement partie/chapitre/section en `IntegrityError`
`views/admin_ordering.py:15-49` (`_move_item`).

`Part` / `Chapter` / `Section` portent une contrainte `unique_together
(parent, position)`. Écrire directement la position de destination pendant que
l'élément voisin l'occupe encore violait la contrainte → `IntegrityError`.
Correctif : passage par une **position temporaire libre** (`max + 1`) avant
d'échanger les deux positions définitives (`admin_ordering.py:22-23, 30-49`).

---

## G. Déploiement

Le code voyage dans le package (rsync depuis `ENV/lib/.../jeiko` à la
publication) ; le gabarit `settings.py.txt` est régénéré depuis
`INSTALLER/templates/settings.template.py` ; la conf nginx est appliquée par
`jeiko-server-update`, qui ré-exécute `scripts/11_configure_nginx.sh`. Aucun des
scripts `jeiko-server-update` / `jeiko-client-update` n'a eu besoin d'édition :
ils orchestrent déjà nginx, le réalignement de `settings.py`, la migration et
`collectstatic`.

1. **Publier** (poste de dev) :
   - `./publier-jeiko.sh <version>` — wheel + `version.json` + sha256.
   - `./publier-installer.sh` — zip installeur (bump `INSTALLER/VERSION`).
2. **Serveur Debian**, pour chaque site en production :
   ```
   sudo ./migrate_site.sh --tools-only    # rafraîchit les assets (nouveau 11_configure_nginx.sh)
   sudo jeiko-server-update <site>         # blocage nginx + location /protected-media
   sudo jeiko-client-update <site>         # package + settings réaligné + migrate 0002 + collectstatic
   ```
3. **Hash Vimeo (A1)** — lister les vidéos non listées sans hash puis renseigner
   le champ « Hash / clé privée de la vidéo » dans l'admin :
   ```
   python manage.py shell -c "
   from jeiko.courses.models import VideoContent
   qs = VideoContent.objects.filter(storage_type='remote', remote_provider__provider_type='vimeo', remote_video_hash='')
   for v in qs:
       print(v.pk, v.section_id, v.remote_video_id, v.title or v.section.title)
   "
   ```

### Vérification (prod)
1. `python manage.py check` → aucun problème ; `showmigrations courses` → `[X] 0002`.
2. Déconnecté : `https://<site>/media/courses/videos/<f>.mp4` → **404** ; idem un PDF sous `courses/pdfs/`.
3. Inscrit avec accès : vidéo locale + PDF se chargent via `/courses/serve/...`, le seek fonctionne.
4. Miniatures : « Mes formations » affiche toujours les images (pas de 404).
5. Quiz à 2 bonnes réponses, cocher exactement les bonnes → 100 % / réussi.
6. Monter/descendre partie, chapitre, section → plus d'`IntegrityError`.
7. Lecteur Vimeo : le `src` contient `?h=<hash>`, jamais l'`access_token` du compte.
