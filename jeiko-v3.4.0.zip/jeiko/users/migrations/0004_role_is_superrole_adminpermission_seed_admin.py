from django.db import migrations, models


def create_admin_role(apps, schema_editor):
    """
    Crée (si absent) un rôle protégé « Administrateur » de type super-rôle.
    Le super-rôle accorde toutes les permissions via le backend, il n'est donc
    pas nécessaire d'y attacher explicitement des Permission (qui, de toute
    façon, ne sont créées qu'en post_migrate).
    """
    Role = apps.get_model("users", "Role")
    Role.objects.update_or_create(
        slug="administrateur",
        defaults={
            "name": "Administrateur",
            "description": "Accès complet à l'administration du site.",
            "is_active": True,
            "is_protected": True,
            "is_superrole": True,
        },
    )


def remove_admin_role(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    Role.objects.filter(slug="administrateur", is_superrole=True).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("users", "0003_address"),
    ]

    operations = [
        migrations.AddField(
            model_name="role",
            name="is_superrole",
            field=models.BooleanField(
                default=False,
                help_text="Accorde TOUTES les permissions du site (super-administrateur "
                "applicatif), sans nécessiter le statut superuser Django.",
            ),
        ),
        migrations.CreateModel(
            name="AdminPermission",
            fields=[
                (
                    "id",
                    models.AutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
            ],
            options={
                "verbose_name": "Permission d'administration",
                "verbose_name_plural": "Permissions d'administration",
                "permissions": [
                    ("access_admin", "Accéder à l'espace d'administration"),
                    ("config_edit_site", "Modifier la configuration du site"),
                    ("config_edit_mail", "Modifier les réglages e-mail"),
                    ("config_edit_fonts", "Modifier les polices"),
                    ("config_clear_cache", "Vider le cache"),
                    ("assign_role", "Assigner / retirer des rôles aux utilisateurs"),
                ],
                "managed": False,
                "default_permissions": (),
            },
        ),
        migrations.RunPython(create_admin_role, remove_admin_role),
    ]
