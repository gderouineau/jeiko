# jeiko/users/migrations/0010_grandfather_verified_emails.py
"""
Marque les comptes EXISTANTS comme vérifiés, avant que la vérification devienne
obligatoire.

Pourquoi cette migration est indispensable
------------------------------------------
`ACCOUNT_EMAIL_VERIFICATION` passe de "none" à "mandatory". allauth refuse
alors la connexion à tout compte dont l'adresse n'est pas marquée vérifiée dans
`account_emailaddress`.

Or sur un site qui tournait en "none", cette table est vide ou non vérifiée :
personne n'a jamais eu à confirmer quoi que ce soit. **Sans cette migration, la
mise à jour enfermerait dehors la totalité des comptes existants** — clients
ayant acheté une formation compris — et le seul recours serait une
réinitialisation manuelle, compte par compte.

Ce que fait la migration
------------------------
1. `EmailAddress.verified = True` sur les lignes existantes ;
2. une ligne `EmailAddress` vérifiée pour les comptes qui n'en ont aucune,
   à partir de `User.email`.

Un compte sans adresse renseignée est laissé tel quel : il n'y a rien à
vérifier, et lui inventer une adresse serait pire que le laisser en l'état.

Portée, et ce que cela n'est pas
--------------------------------
C'est une reprise d'historique, pas un blanc-seing : elle ne vaut que pour les
comptes déjà en base au moment de la mise à jour. Toute inscription ultérieure
passe par la confirmation.

Elle marque aussi comme vérifiés d'éventuels faux comptes déjà créés — c'est
inévitable, on ne peut pas distinguer après coup. Le tri se fait depuis l'écran
d'administration des utilisateurs ; c'est précisément ce que la vérification
obligatoire empêchera de se reproduire.
"""

from django.db import migrations


def marquer_verifies(apps, schema_editor):
    EmailAddress = apps.get_model("account", "EmailAddress")
    User = apps.get_model("users", "Profile")._meta.get_field("user").related_model

    # 1) Les lignes déjà présentes.
    EmailAddress.objects.filter(verified=False).update(verified=True)

    # 2) Les comptes qui n'en ont aucune.
    deja = set(EmailAddress.objects.values_list("user_id", flat=True))
    manquants = User.objects.exclude(pk__in=deja).exclude(email="").exclude(email=None)

    EmailAddress.objects.bulk_create(
        [
            EmailAddress(
                user_id=compte.pk,
                email=compte.email,
                verified=True,
                primary=True,
            )
            for compte in manquants.iterator()
        ],
        # Une adresse partagée par deux comptes ferait échouer la contrainte
        # d'unicité. Le cas est possible sur un site qui tournait sans
        # vérification : on ignore le doublon plutôt que d'interrompre une
        # migration qui doit passer sur tous les sites.
        ignore_conflicts=True,
    )


def revenir(apps, schema_editor):
    """
    Sans effet, à dessein.

    On ne sait pas distinguer les adresses vérifiées par cette migration de
    celles confirmées par leur propriétaire. Les remettre toutes à `False`
    enfermerait dehors les comptes légitimes — exactement ce que la migration
    aller a évité.
    """
    pass


class Migration(migrations.Migration):

    dependencies = [
        ("users", "0009_alter_providerconfig_client_secret_and_more"),
        ("account", "0001_initial"),
    ]

    operations = [
        migrations.RunPython(marquer_verifies, revenir),
    ]
