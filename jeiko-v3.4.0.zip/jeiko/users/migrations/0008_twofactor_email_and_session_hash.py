"""
Second facteur par e-mail, et empreinte de session.

Écrite à la main plutôt que générée : l'autodétecteur voyait un retrait suivi
d'un ajout là où `session_key` devient `session_key_hash`, ce qui aurait perdu
les lignes existantes. `RenameField` conserve la colonne.

En pratique la table est vide — rien ne créait jamais de `UserSession` — mais
la migration doit rester juste indépendamment de cet état de fait.
"""

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("users", "0007_alter_securityevent_event_type"),
    ]

    operations = [
        # --- TwoFactorDevice : type e-mail + défi en cours ---
        migrations.AlterField(
            model_name="twofactordevice",
            name="device_type",
            field=models.CharField(
                choices=[
                    ("email", "Code par e-mail"),
                    ("totp", "TOTP (App d'authent.)"),
                    ("webauthn", "WebAuthn (Clé/FIDO2)"),
                ],
                db_index=True,
                default="email",
                max_length=16,
            ),
        ),
        migrations.AlterField(
            model_name="twofactordevice",
            name="secret_or_credential",
            field=models.TextField(
                blank=True,
                default="",
                help_text=(
                    "Secret TOTP ou credential WebAuthn (id, publicKey). "
                    "Inutilisé pour le type e-mail."
                ),
            ),
        ),
        migrations.AddField(
            model_name="twofactordevice",
            name="challenge_hash",
            field=models.CharField(
                blank=True, default="", editable=False, max_length=256,
                verbose_name="Empreinte du code en cours",
            ),
        ),
        migrations.AddField(
            model_name="twofactordevice",
            name="challenge_expires_at",
            field=models.DateTimeField(blank=True, editable=False, null=True),
        ),
        migrations.AddField(
            model_name="twofactordevice",
            name="challenge_sent_at",
            field=models.DateTimeField(blank=True, editable=False, null=True),
        ),
        migrations.AddField(
            model_name="twofactordevice",
            name="challenge_attempts",
            field=models.PositiveSmallIntegerField(
                default=0, editable=False,
                verbose_name="Essais sur le code en cours",
            ),
        ),

        # --- UserSession : on ne conserve plus la clé, mais son empreinte ---
        # La contrainte d'unicité porte sur l'ancien nom : la lever d'abord,
        # sinon le renommage échoue sur certains moteurs.
        migrations.AlterUniqueTogether(
            name="usersession",
            unique_together=set(),
        ),
        migrations.RenameField(
            model_name="usersession",
            old_name="session_key",
            new_name="session_key_hash",
        ),
        migrations.AlterField(
            model_name="usersession",
            name="session_key_hash",
            field=models.CharField(
                db_index=True, max_length=64,
                verbose_name="Empreinte de session",
            ),
        ),
        migrations.AlterUniqueTogether(
            name="usersession",
            unique_together={("user", "session_key_hash")},
        ),
    ]
