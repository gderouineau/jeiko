from django.db import migrations

# Permissions « custom » d'une tentative précédente, créées à tort sur le
# content type du modèle Role (au lieu d'un modèle dédié). Elles font doublon
# avec les permissions canoniques (users.config_*, users.access_admin,
# users.assign_role) et n'étaient attachées qu'au rôle Administrateur, devenu
# super-rôle (qui accorde de toute façon toutes les permissions). On les retire
# pour ne pas polluer l'interface de gestion des rôles.
STALE_CODENAMES = [
    "admincfg_change_fonts",
    "admincfg_change_mailsettings",
    "admincfg_change_website",
    "admincfg_clear_cache",
    "admincfg_view_admin_menu",
    "admincfg_view_health",
    "users_assign_role",
    "users_manage_role_permissions",
    "users_view_users_menu",
]


def remove_stale_permissions(apps, schema_editor):
    Permission = apps.get_model("auth", "Permission")
    ContentType = apps.get_model("contenttypes", "ContentType")
    try:
        ct = ContentType.objects.get(app_label="users", model="role")
    except ContentType.DoesNotExist:
        return
    # La suppression des Permission cascade sur les RolePermission (FK CASCADE).
    Permission.objects.filter(content_type=ct, codename__in=STALE_CODENAMES).delete()


def noop(apps, schema_editor):
    # Irréversible : on ne recrée pas ces permissions obsolètes.
    pass


class Migration(migrations.Migration):

    dependencies = [
        ("users", "0004_role_is_superrole_adminpermission_seed_admin"),
    ]

    operations = [
        migrations.RunPython(remove_stale_permissions, noop),
    ]
