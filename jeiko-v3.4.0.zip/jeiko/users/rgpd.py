# -*- coding: utf-8 -*-
"""
Export des données personnelles d'un utilisateur (RGPD art. 15 « droit d'accès »
et art. 20 « portabilité »).

`build_user_export(user)` renvoie un dict JSON-sérialisable rassemblant l'empreinte
de données rattachée au compte, à travers toutes les apps (compte, profil, adresses,
consentements, commandes, formations, rendez-vous, questionnaires, journal sécurité).

Principes :
- On n'exporte QUE les données de la personne concernée, jamais celles de tiers.
- Le mot de passe (même haché) n'est jamais inclus.
- Tolérant : une app absente ou un modèle vide n'interrompt pas l'export.
"""
from __future__ import annotations

import logging
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

logger = logging.getLogger(__name__)


def _dt(value):
    return value.isoformat() if value else None


def _num(value):
    # Decimal → str (JSON n'a pas de décimal exact) ; None reste None.
    if value is None:
        return None
    if isinstance(value, Decimal):
        return str(value)
    return value


def _account_section(user):
    return {
        "id": user.pk,
        "username": user.get_username(),
        "email": getattr(user, "email", "") or "",
        "first_name": getattr(user, "first_name", "") or "",
        "last_name": getattr(user, "last_name", "") or "",
        "is_active": bool(getattr(user, "is_active", True)),
        "date_joined": _dt(getattr(user, "date_joined", None)),
        "last_login": _dt(getattr(user, "last_login", None)),
    }


def _profile_section(user):
    profile = getattr(user, "profile", None)
    if profile is None:
        return None
    return {
        "bio": profile.bio or "",
        "phone_number": profile.phone_number or "",
        "date_of_birth": _dt(profile.date_of_birth),
        "location": profile.location or "",
        "website": profile.website or "",
        "avatar": profile.avatar.url if profile.avatar else None,
    }


def _addresses_section(user):
    out = []
    for a in user.addresses.all():
        out.append({
            "type": a.get_address_type_display(),
            "is_default": a.is_default,
            "name": a.name,
            "street_address": a.street_address,
            "street_address_2": a.street_address_2,
            "city": a.city,
            "postal_code": a.postal_code,
            "country": a.country,
            "phone": a.phone,
            "created_at": _dt(getattr(a, "created_at", None)),
        })
    return out


def _consents_section(user):
    out = []
    for c in user.consents.all().order_by("granted_at"):
        out.append({
            "type": c.get_consent_type_display(),
            "granted": c.granted,
            "granted_at": _dt(c.granted_at),
            "version_text": c.version_text,
            "source": c.source,
            "ip_address": c.ip_address,
        })
    return out


def _marketing_section(user):
    prefs = getattr(user, "marketing_prefs", None)
    if prefs is None:
        return None
    return {
        "email_optin": prefs.email_optin,
        "sms_optin": prefs.sms_optin,
        "whatsapp_optin": prefs.whatsapp_optin,
        "frequency": prefs.get_frequency_display(),
        "topics": prefs.topics,
    }


def _cookie_consents_section(user):
    try:
        from jeiko.cookies.models import CookieConsent
    except Exception:
        return []
    out = []
    for c in CookieConsent.objects.filter(user=user).order_by("-created_at"):
        out.append({
            "created_at": _dt(c.created_at),
            "choices": c.choices,
            "policy_version": c.policy_version,
            "source": c.get_source_display(),
            "is_latest": c.is_latest,
        })
    return out


def _orders_section(user):
    try:
        from jeiko.shop.models import Order
    except Exception:
        return []
    out = []
    for o in Order.objects.filter(user=user).prefetch_related("lines").order_by("-created_at"):
        out.append({
            "id": o.pk,
            "created_at": _dt(o.created_at),
            "order_status": o.order_status,
            "payment_status": o.payment_status,
            "currency": o.currency,
            "total_ht": _num(o.total_ht),
            "total_tva": _num(o.total_tva),
            "total_ttc": _num(o.total_ttc),
            "billing_name": o.billing_name,
            "billing_address": o.billing_address,
            "shipping_name": o.shipping_name,
            "shipping_address": o.shipping_address,
            "lines": [
                {
                    "label": l.label,
                    "sku": l.sku,
                    "quantity": l.quantity,
                    "unit_price_ht": _num(l.unit_price_ht),
                    "tax_rate": _num(l.tax_rate),
                }
                for l in o.lines.all()
            ],
        })
    return out


def _enrollments_section(user):
    try:
        from jeiko.courses.models import CourseEnrollment
    except Exception:
        return []
    out = []
    qs = CourseEnrollment.objects.filter(user=user).select_related("course").order_by("-enrolled_at")
    for e in qs:
        out.append({
            "course": getattr(e.course, "title", None) or str(e.course_id),
            "status": e.get_status_display(),
            "progress_percentage": _num(e.progress_percentage),
            "enrolled_at": _dt(e.enrolled_at),
            "completed_at": _dt(e.completed_at),
            "access_expires_at": _dt(e.access_expires_at),
        })
    return out


def _appointments_section(user):
    try:
        from jeiko.calendars.models import Appointment
    except Exception:
        return []
    out = []
    qs = Appointment.objects.filter(user=user).select_related("type").order_by("-start")
    for a in qs:
        out.append({
            "type": getattr(a.type, "name", None),
            "start": _dt(a.start),
            "end": _dt(a.end),
            "status": a.get_status_display(),
            "places": a.places,
            "email": a.email,
            "client_name": a.client_name,
            "contact_consent": getattr(a, "contact_consent", None),
        })
    return out


def _questionnaires_section(user):
    try:
        from jeiko.questionnaires_expert.models import ExpertTestData
    except Exception:
        return []
    out = []
    qs = ExpertTestData.objects.filter(user=user).select_related("test", "result_profile").order_by("-created_at")
    for d in qs:
        out.append({
            "test": getattr(d.test, "title", None),
            "created_at": _dt(d.created_at),
            "result_profile": getattr(d.result_profile, "name", None),
            "data": d.data,  # réponses, scores, profils (déjà les données de la personne)
        })
    return out


def _security_section(user):
    events = [
        {
            "event_type": e.get_event_type_display(),
            "ip_address": e.ip_address,
            "occured_at": _dt(e.occured_at),
        }
        for e in user.security_events.all().order_by("-occured_at")[:200]
    ]
    sessions = [
        {
            "first_seen": _dt(s.first_seen),
            "last_seen": _dt(s.last_seen),
            "ip_last": s.ip_last,
            "is_active": s.is_active,
        }
        for s in user.sessions.all().order_by("-last_seen")
    ]
    return {"events": events, "sessions": sessions}


def build_user_export(user) -> dict:
    """Rassemble toutes les données personnelles rattachées à `user`."""
    return {
        "export_metadata": {
            "generated_at": timezone.now().isoformat(),
            "subject": {
                "id": user.pk,
                "username": user.get_username(),
                "email": getattr(user, "email", "") or "",
            },
            "notice": (
                "Export des données personnelles au titre du droit d'accès "
                "(RGPD art. 15) et à la portabilité (art. 20). Le mot de passe "
                "(même haché) et les données concernant des tiers ne sont pas inclus."
            ),
        },
        "account": _account_section(user),
        "profile": _profile_section(user),
        "addresses": _addresses_section(user),
        "consents": _consents_section(user),
        "marketing_preferences": _marketing_section(user),
        "cookie_consents": _cookie_consents_section(user),
        "orders": _orders_section(user),
        "course_enrollments": _enrollments_section(user),
        "appointments": _appointments_section(user),
        "questionnaires": _questionnaires_section(user),
        "security": _security_section(user),
    }


def export_filename(user) -> str:
    stamp = timezone.now().strftime("%Y%m%d")
    return f"export-donnees-{user.get_username()}-{stamp}.json"


# ---------------------------------------------------------------------------
# Effacement / droit à l'oubli (RGPD art. 17)
# ---------------------------------------------------------------------------
#
# Principe : on N'EFFACE PAS en dur les enregistrements sous obligation légale
# de conservation (commandes/factures : 10 ans). On les ANONYMISE (on retire le
# nom et l'adresse, on garde les montants et dates pour la comptabilité). Tout
# le reste des données personnelles est supprimé, et le compte est désactivé et
# vidé de ses identifiants — la ligne User est conservée (coquille anonymisée)
# pour ne pas casser les liens des enregistrements retenus.

def _delete_avatars(user) -> int:
    """
    Efface les fichiers d'avatar du compte. Retourne le nombre supprimé.

    `FileField.delete()` retire le fichier du stockage ET vide le champ. On
    passe `save=False` : la ligne `Profile` est supprimée juste après, et un
    enregistrement intermédiaire ne servirait qu'à écrire pour rien.

    Un fichier déjà absent — effacé à la main, stockage remplacé — ne doit pas
    faire échouer l'effacement : c'est le résultat recherché, pas une erreur.
    """
    from .models import Profile

    supprimes = 0
    for profil in Profile.objects.filter(user=user):
        if not profil.avatar:
            continue
        try:
            profil.avatar.delete(save=False)
            supprimes += 1
        except Exception:
            # Journalisé et non avalé : un effacement partiel doit se voir.
            # Voir R-02 — c'est la même exigence, appliquée ici dès l'écriture.
            logger.exception(
                "Suppression de l'avatar impossible pour le profil %s "
                "(compte %s) : le fichier subsiste sur le disque.",
                profil.pk, user.pk,
            )
    return supprimes


def _anonymize_orders(user):
    try:
        from jeiko.shop.models import Order
    except Exception:
        return 0
    count = 0
    for o in Order.objects.filter(user=user):
        o.billing_name = ""
        o.billing_address = ""
        o.shipping_name = ""
        o.shipping_address = ""
        o.save(update_fields=[
            "billing_name", "billing_address", "shipping_name", "shipping_address",
        ])
        count += 1
    return count


def _anonymize_appointments(user):
    try:
        from jeiko.calendars.models import Appointment
    except Exception:
        return 0
    return Appointment.objects.filter(user=user).update(
        email="", client_name="", contact_consent=False, contact_consent_at=None,
    )


@transaction.atomic
def erase_user_data(user, *, actor=None, reason="") -> tuple[str, dict]:
    """
    Efface les données personnelles de `user`. Renvoie (ancien_email, résumé).

    - Anonymise les enregistrements sous rétention légale (commandes, rendez-vous).
    - Supprime le reste (profil, adresses, consentements, préférences, sessions,
      notifications, formations, questionnaires, cookies, liens prospects).
    - Désactive et vide le compte (identifiants), en conservant la ligne.
    """
    from .models import (
        Profile, Address, MarketingPreference, Consent, UserSession,
        Notification, ProspectLink, Comments, SecurityEvent, SecurityEventType,
    )

    old_email = getattr(user, "email", "") or ""
    summary = {}

    # 1) Anonymisation (rétention légale)
    summary["orders_anonymized"] = _anonymize_orders(user)
    summary["appointments_anonymized"] = _anonymize_appointments(user)

    # 2) Suppression des données personnelles restantes
    #
    # L'avatar D'ABORD, et sur disque : supprimer la ligne `Profile` laisse le
    # fichier dans `mediadir/avatars/`, où il reste servi par /media/. C'est une
    # photographie de personne identifiée qui survivait à un effacement déclaré
    # complet — le manquement le plus visible qu'on puisse opposer à une
    # demande d'effacement.
    summary["avatars_deleted"] = _delete_avatars(user)
    Profile.objects.filter(user=user).delete()
    summary["addresses_deleted"] = Address.objects.filter(user=user).delete()[0]
    MarketingPreference.objects.filter(user=user).delete()
    summary["consents_deleted"] = Consent.objects.filter(user=user).delete()[0]
    UserSession.objects.filter(user=user).delete()
    Notification.objects.filter(user=user).delete()
    # Commentaires rédigés par l'utilisateur (au sujet de tiers) : on détache
    # l'auteur plutôt que de casser le fil des autres.
    Comments.objects.filter(user=user).update(user=None)

    try:
        from jeiko.questionnaires_expert.models import ExpertTestData
        summary["questionnaires_deleted"] = ExpertTestData.objects.filter(user=user).delete()[0]
    except Exception:
        pass

    # Prospects rattachés : on anonymise leurs coordonnées puis on retire le lien.
    try:
        for link in ProspectLink.objects.filter(user=user).select_related("prospect"):
            p = link.prospect
            if p:
                p.firstname, p.lastname, p.email, p.phone = "—", "—", "", ""
                p.save(update_fields=["firstname", "lastname", "email", "phone"])
        ProspectLink.objects.filter(user=user).delete()
    except Exception:
        pass

    try:
        from jeiko.courses.models import CourseEnrollment
        summary["enrollments_deleted"] = CourseEnrollment.objects.filter(user=user).delete()[0]
    except Exception:
        pass

    try:
        from jeiko.cookies.models import CookieConsent
        CookieConsent.objects.filter(user=user).delete()
    except Exception:
        pass

    # 3) Vidage + désactivation du compte (ligne conservée)
    user.username = f"deleted-{user.pk}"
    user.email = ""
    user.first_name = ""
    user.last_name = ""
    user.is_active = False
    user.set_unusable_password()
    user.save()

    # 4) Trace d'audit (preuve que l'effacement a eu lieu, sans donnée personnelle)
    try:
        SecurityEvent.objects.create(
            user=user,
            event_type=SecurityEventType.ACCOUNT_ERASED,
            extra={"reason": reason, "actor_id": getattr(actor, "pk", None)},
        )
    except Exception:
        pass

    return old_email, summary


def notify_account_deactivated(old_email):
    """Envoie l'e-mail `account_deactivated` (best-effort, ne bloque jamais)."""
    if not old_email:
        return
    try:
        from jeiko.emailing.services import send_email
        send_email(
            "account_deactivated",
            to=old_email,
            context={"date_heure": timezone.now().strftime("%d/%m/%Y %H:%M")},
        )
    except Exception:
        pass
