from django import forms
from django.contrib.auth import get_user_model
from allauth.account.forms import SignupForm, LoginForm
from django.utils import timezone
import re

from jeiko.users.models import Profile, Address


class AddressForm(forms.ModelForm):
    class Meta:
        model = Address
        fields = [
            'address_type', 'is_default', 'name', 
            'street_address', 'street_address_2', 
            'city', 'postal_code', 'country', 'phone'
        ]
        widgets = {
            'address_type': forms.Select(attrs={'class': 'form-select'}),
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: Maison, Bureau...'}),
            'street_address': forms.TextInput(attrs={'class': 'form-control'}),
            'street_address_2': forms.TextInput(attrs={'class': 'form-control'}),
            'city': forms.TextInput(attrs={'class': 'form-control'}),
            'postal_code': forms.TextInput(attrs={'class': 'form-control'}),
            'country': forms.TextInput(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'is_default': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

User = get_user_model()


class ProfileForm(forms.ModelForm):
    """
    Formulaire pour que l’utilisateur modifie son profil.
    - Validation avatar: type & taille
    - Date de naissance: pas dans le futur
    - Téléphone: nettoyage simple
    """
    MAX_AVATAR_MB = 5
    ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/png", "image/webp"}

    class Meta:
        model = Profile
        fields = [
            'avatar',
            'bio',
            'phone_number',
            'date_of_birth',
            'location',
            'website',
        ]
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
        }

    def clean_avatar(self):
        f = self.cleaned_data.get('avatar')
        if not f:
            return f
        # Taille
        if f.size > self.MAX_AVATAR_MB * 1024 * 1024:
            raise forms.ValidationError(
                f"L’image est trop lourde (>{self.MAX_AVATAR_MB} Mo)."
            )
        # Type MIME (si disponible via uploaded file)
        content_type = getattr(f, "content_type", None)
        if content_type and content_type.lower() not in self.ALLOWED_CONTENT_TYPES:
            raise forms.ValidationError("Format d’image non supporté (jpeg, png, webp).")
        return f

    def clean_date_of_birth(self):
        dob = self.cleaned_data.get('date_of_birth')
        if not dob:
            return dob
        if dob > timezone.now().date():
            raise forms.ValidationError("La date de naissance ne peut pas être dans le futur.")
        # Optionnel : interdire des dates irréalistes (avant 1900)
        if dob.year < 1900:
            raise forms.ValidationError("Merci de saisir une date réaliste (≥ 1900).")
        return dob

    def clean_phone_number(self):
        phone = (self.cleaned_data.get('phone_number') or '').strip()
        if not phone:
            return phone
        # Nettoyage simple : on retire espaces, points, tirets
        normalized = re.sub(r"[.\s\-()]", "", phone)
        # Vérif très souple (commence par + ou chiffre, au moins 6-7 chiffres)
        if not re.match(r"^\+?\d{6,}$", normalized):
            raise forms.ValidationError("Numéro de téléphone invalide.")
        return normalized


class CustomSignupForm(SignupForm):
    """
    Formulaire d’inscription Allauth enrichi pour demander le prénom et le nom.

    Porte aussi les garde-fous anti-abus (voir users/throttling.py) : créer un
    compte écrit deux lignes en base et déclenche un e-mail, ce qui en fait le
    point d'entrée public le plus coûteux du site.
    """
    first_name = forms.CharField(
        max_length=30,
        label="Prénom",
        widget=forms.TextInput(attrs={'placeholder': 'Prénom'}),
    )
    last_name = forms.CharField(
        max_length=30,
        label="Nom",
        widget=forms.TextInput(attrs={'placeholder': 'Nom'}),
    )

    #: Champ leurre. Invisible pour l'humain (masqué par le gabarit, sans
    #: étiquette et hors du parcours de tabulation), rempli par la plupart des
    #: robots, qui remplissent tout ce qu'ils trouvent. Le nom est neutre à
    #: dessein : « company » ressemble à un champ légitime, là qu'un
    #: « honeypot » se contournerait d'une ligne.
    company = forms.CharField(
        required=False,
        label="",
        widget=forms.TextInput(attrs={
            "autocomplete": "off",
            "tabindex": "-1",
            "aria-hidden": "true",
            "class": "jk-leurre",
        }),
    )

    def __init__(self, *args, **kwargs):
        """
        Récupère la requête, que les garde-fous exigent.

        `SignupForm` d'allauth ne l'accepte PAS — seul `LoginForm` le fait
        (account/forms.py:72). Sans ce `pop`, `self.request` vaudrait None, et
        `get_client_ip(None)` renverrait « unknown » : tous les visiteurs
        partageraient alors un unique compteur, et le site se fermerait à tout
        le monde après cinq inscriptions. C'est `CustomSignupView` qui fournit
        la clé, via `get_form_kwargs`.
        """
        self.request = kwargs.pop("request", None)
        super().__init__(*args, **kwargs)

    def clean_first_name(self):
        return (self.cleaned_data.get('first_name') or '').strip()

    def clean_last_name(self):
        return (self.cleaned_data.get('last_name') or '').strip()

    def clean(self):
        """
        Refuse l'inscription abusive avant toute écriture.

        Le contrôle est ici plutôt que dans la vue : `SignupView` d'allauth
        appelle `form.save()` dès que le formulaire est valide, et rien ne
        s'interpose entre les deux. Un refus posé au niveau du formulaire est
        aussi celui qui s'affiche correctement, sans page d'erreur.
        """
        cleaned = super().clean()

        from jeiko.users.throttling import check_signup

        refus = check_signup(self.request, self.data)
        if refus:
            raise forms.ValidationError(refus)

        return cleaned

    def save(self, request):
        # Crée l'utilisateur via Allauth (gère email/password/username selon ta config)
        user = super().save(request)
        # Complète prénom/nom ; le profile sera créé par signal
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.save(update_fields=["first_name", "last_name"])
        return user


class CustomLoginForm(LoginForm):
    login = forms.CharField(
        label="Identifiant",
        widget=forms.TextInput(attrs={
            'placeholder': "Email ou nom d'utilisateur",
            'class': 'form-control',
            'autocomplete': 'username',
        }),
        help_text="Saisissez votre e-mail ou votre nom d’utilisateur"
    )
    password = forms.CharField(
        label="Mot de passe",
        widget=forms.PasswordInput(attrs={
            'placeholder': '••••••••',
            'class': 'form-control',
            'autocomplete': 'current-password',
        })
    )
