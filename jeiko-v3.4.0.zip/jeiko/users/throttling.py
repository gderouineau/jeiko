# jeiko/users/throttling.py
"""
Garde-fous du formulaire d'inscription.

Le problème
-----------
Créer un compte est le point d'entrée public le plus coûteux du site : il écrit
une ligne `User`, une ligne `Profile`, et déclenche l'envoi d'un e-mail de
confirmation. Une boucle sur ce formulaire remplit donc la base **et** fait
partir autant de messages — vers des adresses que le robot choisit, ce qui
transforme le site en relais d'envoi non sollicité et fait blacklister le
domaine d'expédition.

`jeiko.throttling` portait déjà ces garde-fous pour la soumission de
formulaire, le consentement cookies et la mesure d'audience. L'inscription n'en
avait aucun.

La politique retenue
--------------------
Deux plafonds, parce que les deux coûts diffèrent :

- `ip_attempts` compte **toutes** les soumissions, y compris refusées : c'est
  ce qui arrête le martèlement, avant même qu'une ligne soit écrite ;
- `ip_signups` borne les inscriptions **abouties**, celles qui envoient un
  e-mail : c'est ce qui protège la réputation du domaine.

Les valeurs sont larges à dessein. Plusieurs personnes derrière une même sortie
réseau — entreprise, université, réseau mobile — doivent pouvoir s'inscrire le
même jour sans se gêner. Un robot, lui, dépasse ces seuils en quelques secondes.
Réglables par `JEIKO_SIGNUP_LIMITS`.

Le leurre
---------
Un champ invisible que les robots remplissent parce qu'ils remplissent tout.
Il ne remplace pas les plafonds — il attrape le tout-venant sans coûter une
seule requête, et sans opposer d'épreuve au visiteur légitime, contrairement à
un captcha.
"""

import logging

from jeiko.throttling import HONEYPOT_FIELD, get_client_ip, get_limits, hit, honeypot_filled

logger = logging.getLogger(__name__)

#: (nombre maximum, fenêtre en secondes)
DEFAULT_LIMITS = {
    "ip_attempts": (20, 3600),
    "ip_signups": (5, 3600),
    "ip_signups_day": (15, 86400),
}

SCOPE = "signup"

#: Message unique, volontairement vague : préciser la règle atteinte
#: renseignerait un robot sur la manière de la contourner. Un visiteur
#: légitime qui le voit a de toute façon une seule chose à faire — attendre.
GENERIC_REFUSAL = (
    "Trop de tentatives d'inscription depuis cet appareil. "
    "Merci de réessayer plus tard, ou de nous contacter directement."
)


def get_signup_limits():
    return get_limits("JEIKO_SIGNUP_LIMITS", DEFAULT_LIMITS)


def check_signup(request, data):
    """
    Contrôles AVANT création du compte.

    Retourne `None` si l'inscription peut poursuivre, sinon le message à
    afficher.
    """
    limits = get_signup_limits()
    ip = get_client_ip(request) if request else "unknown"

    if honeypot_filled(data):
        logger.warning("Inscription rejetée (leurre rempli) ip=%s", ip)
        return GENERIC_REFUSAL

    if hit(f"{SCOPE}:attempts", ip, *limits["ip_attempts"]):
        logger.warning("Inscription rejetée (trop de tentatives) ip=%s", ip)
        return GENERIC_REFUSAL

    if hit(f"{SCOPE}:created", ip, *limits["ip_signups"]):
        logger.warning("Inscription rejetée (plafond horaire) ip=%s", ip)
        return GENERIC_REFUSAL

    if hit(f"{SCOPE}:created_day", ip, *limits["ip_signups_day"]):
        logger.warning("Inscription rejetée (plafond quotidien) ip=%s", ip)
        return GENERIC_REFUSAL

    return None


__all__ = ["HONEYPOT_FIELD", "check_signup", "get_signup_limits", "GENERIC_REFUSAL"]
