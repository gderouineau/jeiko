# jeiko/users/purge.py
"""
Suppression des comptes restés non confirmés.

Pourquoi
--------
Depuis que la confirmation d'adresse est obligatoire, une inscription non
suivie laisse en base un compte inutilisable : il ne peut pas se connecter, ne
recevra rien, et n'a aucune chance de servir un jour. La plupart proviennent
d'inscriptions automatisées ou abandonnées en cours de route.

Sans purge, cette table n'accumule que du bruit — bruit qui fausse les
décomptes, encombre l'écran des utilisateurs, et retient des adresses
personnelles dont plus rien ne justifie la conservation (RGPD : la donnée n'est
gardée que le temps de sa finalité, et cette finalité a expiré).

Le délai
--------
Trente jours par défaut, réglable par `JEIKO_UNVERIFIED_ACCOUNT_TTL_DAYS`.
Assez long pour qu'un lien retrouvé au fond d'une boîte fonctionne encore,
assez court pour que le ménage soit réel.

Ce qui n'est JAMAIS supprimé
----------------------------
Un compte qui a servi, même sans adresse confirmée. C'est le point délicat :
sur un site qui a tourné sans vérification, ou après une création manuelle
depuis l'administration, il peut exister des comptes légitimes non confirmés.
Sont donc protégés :

- le personnel (`is_staff`, `is_superuser`) ;
- tout compte confirmé, évidemment ;
- tout compte rattaché à une commande, une inscription à une formation ou un
  rendez-vous — il a une histoire, et souvent une obligation de conservation
  comptable.

La migration 0010 ayant marqué vérifiés tous les comptes antérieurs, cette
purge ne devrait rencontrer que des inscriptions postérieures au changement.
Ces garde-fous sont là pour les cas qu'on n'a pas prévus.
"""

import logging

from django.conf import settings
from django.contrib.auth import get_user_model
from django.utils import timezone

logger = logging.getLogger(__name__)

DEFAULT_TTL_DAYS = 30


def ttl_days() -> int:
    try:
        return max(1, int(getattr(settings, "JEIKO_UNVERIFIED_ACCOUNT_TTL_DAYS",
                                  DEFAULT_TTL_DAYS)))
    except (TypeError, ValueError):
        return DEFAULT_TTL_DAYS


def comptes_a_purger(maintenant=None):
    """
    Les comptes supprimables : jamais confirmés, anciens, et sans histoire.

    Retourne un QuerySet, pour que l'appelant puisse compter ou inspecter avant
    de supprimer.
    """
    from allauth.account.models import EmailAddress

    User = get_user_model()
    limite = (maintenant or timezone.now()) - timezone.timedelta(days=ttl_days())

    confirmes = EmailAddress.objects.filter(verified=True).values("user_id")

    qs = (
        User.objects
        .filter(date_joined__lt=limite)
        .exclude(pk__in=confirmes)
        .exclude(is_staff=True)
        .exclude(is_superuser=True)
    )

    return _exclure_les_comptes_avec_historique(qs)


#: Ce qui donne une histoire à un compte, et interdit donc de l'effacer.
#:
#: Chacun de ces liens engage soit une obligation de conservation comptable,
#: soit un accès acheté. Un compte qui en porte un ne se supprime pas : il
#: s'anonymise, par l'effacement RGPD (users/rgpd.py), qui conserve la pièce et
#: retire la personne.
LIENS_D_HISTORIQUE = (
    ("jeiko.shop.models", "Order", "user_id", "commande"),
    ("jeiko.courses.models", "CourseEnrollment", "user_id", "inscription à une formation"),
    ("jeiko.calendars.models", "Appointment", "user_id", "rendez-vous"),
)


def historique_du_compte(user):
    """
    Ce qui rattache le compte à une activité. Liste vide = compte sans histoire.

    Sert aussi bien à la purge automatique qu'à l'écran de suppression, pour
    dire à l'exploitant POURQUOI un compte ne peut pas être effacé.
    """
    trouve = []
    for chemin, nom_modele, champ, libelle in LIENS_D_HISTORIQUE:
        try:
            module = __import__(chemin, fromlist=[nom_modele])
            modele = getattr(module, nom_modele)
            nombre = modele.objects.filter(**{champ: user.pk}).count()
        except Exception:
            logger.exception(
                "Contrôle d'historique : %s.%s illisible. Le compte est traité "
                "comme ayant une histoire, par prudence.", chemin, nom_modele,
            )
            trouve.append((libelle, None))
            continue
        if nombre:
            trouve.append((libelle, nombre))
    return trouve


def compte_supprimable(user, par=None):
    """
    Dit si un compte peut être effacé, et sinon pourquoi.

    Retourne `(True, None)` ou `(False, motif)` — le motif étant destiné à
    l'écran, donc écrit pour être lu.
    """
    if par is not None and user.pk == par.pk:
        return False, "Vous ne pouvez pas supprimer votre propre compte."

    if user.is_superuser:
        return False, (
            "Ce compte est superutilisateur. Retirez-lui d'abord ce statut si "
            "la suppression est bien voulue."
        )

    histoire = historique_du_compte(user)
    if histoire:
        details = ", ".join(
            f"{nombre} {libelle}{'s' if nombre and nombre > 1 else ''}"
            if nombre else libelle
            for libelle, nombre in histoire
        )
        return False, (
            f"Ce compte a une activité ({details}). Le supprimer effacerait des "
            f"pièces à conserver. Utilisez « Effacer les données personnelles », "
            f"qui anonymise le compte et garde les écritures."
        )

    return True, None


def _exclure_les_comptes_avec_historique(qs):
    """
    Retire les comptes rattachés à une commande, une formation ou un rendez-vous.

    Chaque exclusion est isolée : le paquet s'installe entier, mais un modèle
    peut manquer pendant une migration ou un test partiel, et cette purge ne
    doit jamais devenir la raison pour laquelle une tâche planifiée échoue.
    """
    for chemin, nom_modele, champ, _libelle in LIENS_D_HISTORIQUE:
        try:
            module = __import__(chemin, fromlist=[nom_modele])
            modele = getattr(module, nom_modele)
            qs = qs.exclude(pk__in=modele.objects.values(champ))
        except Exception:
            logger.exception(
                "Purge des comptes : impossible d'exclure %s.%s — par prudence, "
                "la purge est interrompue plutôt que d'effacer un compte qui "
                "aurait une histoire.", chemin, nom_modele,
            )
            return qs.none()

    return qs


def purger_les_comptes_non_confirmes(dry_run=False):
    """
    Supprime les comptes éligibles. Retourne le nombre traité.

    `dry_run` compte sans rien effacer — de quoi vérifier l'assiette avant de
    laisser la tâche planifiée s'en occurrer seule.
    """
    qs = comptes_a_purger()
    nombre = qs.count()

    if not nombre or dry_run:
        return nombre

    # Suppression par lots d'identifiants : `delete()` sur un QuerySet portant
    # des exclusions par sous-requête produit un SQL que certains moteurs
    # refusent. Passer par une liste de clés est plus verbeux et sûr partout.
    identifiants = list(qs.values_list("pk", flat=True))
    get_user_model().objects.filter(pk__in=identifiants).delete()

    logger.info(
        "Purge des comptes non confirmés : %s compte(s) supprimé(s) "
        "(inactifs depuis plus de %s jours).", nombre, ttl_days(),
    )
    return nombre
