# jeiko/users/tests_purge.py
"""
Purge des comptes non confirmés — et surtout, ce qu'elle ne doit PAS toucher.

Une purge automatique qui se trompe efface des clients. Ces tests portent donc
davantage sur les protections que sur la suppression elle-même : le cas nominal
tient en une ligne, les garde-fous sont ce qui mérite d'être verrouillé.
"""

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone

from jeiko.users.purge import comptes_a_purger, purger_les_comptes_non_confirmes
from jeiko.users.testing import creer_compte_verifie, creer_compte_non_verifie

User = get_user_model()


class PurgeDesComptesTests(TestCase):

    def _vieillir(self, compte, jours):
        """Recule la date d'inscription — `date_joined` est auto_now_add."""
        User.objects.filter(pk=compte.pk).update(
            date_joined=timezone.now() - timezone.timedelta(days=jours)
        )
        compte.refresh_from_db()
        return compte

    # -- le cas nominal ----------------------------------------------------

    def test_un_compte_non_confirme_et_ancien_est_supprime(self):
        self._vieillir(creer_compte_non_verifie("fantome", "f@exemple.test", "mdp"), 45)
        self.assertEqual(purger_les_comptes_non_confirmes(), 1)
        self.assertFalse(User.objects.filter(username="fantome").exists())

    # -- les protections ---------------------------------------------------

    def test_un_compte_recent_est_epargne(self):
        """Le lien de confirmation doit rester utilisable un moment."""
        self._vieillir(creer_compte_non_verifie("recent", "r@exemple.test", "mdp"), 3)
        self.assertEqual(purger_les_comptes_non_confirmes(), 0)
        self.assertTrue(User.objects.filter(username="recent").exists())

    def test_un_compte_confirme_est_epargne_meme_tres_ancien(self):
        self._vieillir(creer_compte_verifie("fidele", "fi@exemple.test", "mdp"), 900)
        self.assertEqual(purger_les_comptes_non_confirmes(), 0)
        self.assertTrue(User.objects.filter(username="fidele").exists())

    def test_le_personnel_est_epargne(self):
        """
        Un compte d'administration créé à la main n'a souvent jamais confirmé
        d'adresse. Le supprimer fermerait l'accès au site à son exploitant.
        """
        for nom, champs in (("staff", {"is_staff": True}),
                            ("root", {"is_superuser": True})):
            compte = User.objects.create_user(nom, f"{nom}@exemple.test", "mdp", **champs)
            self._vieillir(compte, 400)

        self.assertEqual(purger_les_comptes_non_confirmes(), 0)
        self.assertEqual(User.objects.filter(username__in=["staff", "root"]).count(), 2)

    def test_un_compte_avec_une_commande_est_epargne(self):
        """
        Le garde-fou qui compte le plus : une commande vaut obligation de
        conservation comptable, et le compte qui la porte ne s'efface pas.
        """
        from jeiko.shop.models import Order

        compte = self._vieillir(
            creer_compte_non_verifie("acheteur", "a@exemple.test", "mdp"), 400
        )
        Order.objects.create(user=compte)

        self.assertEqual(purger_les_comptes_non_confirmes(), 0)
        self.assertTrue(User.objects.filter(username="acheteur").exists())

    def test_le_dry_run_compte_sans_supprimer(self):
        self._vieillir(creer_compte_non_verifie("fantome", "f@exemple.test", "mdp"), 45)
        self.assertEqual(purger_les_comptes_non_confirmes(dry_run=True), 1)
        self.assertTrue(
            User.objects.filter(username="fantome").exists(),
            "Le dry-run a supprimé.",
        )

    def test_lassiette_est_inspectable_avant_suppression(self):
        """`comptes_a_purger` rend un QuerySet : on doit pouvoir regarder."""
        self._vieillir(creer_compte_non_verifie("fantome", "f@exemple.test", "mdp"), 45)
        self.assertEqual(
            list(comptes_a_purger().values_list("username", flat=True)), ["fantome"]
        )

    def test_le_delai_est_reglable(self):
        self._vieillir(creer_compte_non_verifie("fantome", "f@exemple.test", "mdp"), 10)
        self.assertEqual(purger_les_comptes_non_confirmes(), 0)
        with self.settings(JEIKO_UNVERIFIED_ACCOUNT_TTL_DAYS=7):
            self.assertEqual(purger_les_comptes_non_confirmes(), 1)
