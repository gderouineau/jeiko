# jeiko/users/twofactor.py
"""
Double authentification par code envoyé à l'adresse du compte.

Ce qui existait avant : un modèle `TwoFactorDevice`, des écrans pour le
remplir, une entrée dans le menu Sécurité — et aucune ligne de code qui
vérifiait quoi que ce soit à la connexion. Un administrateur qui activait la
double authentification se croyait protégé sans l'être, ce qui est pire que de
ne rien proposer.

Ce que ce module apporte : le second facteur réel. Après le mot de passe, un
code à six chiffres est envoyé par e-mail ; la connexion n'aboutit qu'une fois
ce code saisi.

Le choix de l'e-mail plutôt que d'une application d'authentification est celui
du projet. Il est plus faible — quelqu'un qui contrôle la boîte de réception
franchit les deux facteurs — mais il protège contre le cas de loin le plus
fréquent : un mot de passe fuité, réutilisé ou hameçonné. Le type `TOTP` reste
déclaré au modèle pour être ajouté sans refonte.

Précautions prises
------------------
- Le code n'est **jamais stocké en clair** : seule son empreinte l'est, avec le
  même hacheur que les mots de passe. Une fuite de la base ne livre pas les
  codes en circulation.
- Tiré avec `secrets`, pas `random` : ce dernier est prédictible.
- Durée de vie courte, nombre d'essais borné, et renvoi limité — sinon le
  point d'entrée devient un moyen d'inonder une boîte de réception.
- La comparaison passe par `check_password`, à temps constant.
"""

import hashlib
import logging
import secrets

from django.conf import settings
from django.contrib.auth.hashers import check_password, make_password
from django.utils import timezone

from jeiko.throttling import hit

logger = logging.getLogger(__name__)

#: Nombre de chiffres du code. Six est l'usage ; la sécurité vient de la durée
#: de vie et du nombre d'essais, pas de la longueur.
CODE_LENGTH = 6

#: Durée de validité. Assez pour aller chercher un mail, trop court pour être
#: réutilisé plus tard.
CODE_TTL_SECONDS = 10 * 60

#: Essais autorisés sur un même code. Au-delà, le code est brûlé et il faut en
#: redemander un : six chiffres se devineraient en un million d'essais, il faut
#: donc borner strictement.
MAX_ATTEMPTS = 5

#: Renvois autorisés par heure et par compte.
RESEND_LIMIT = (5, 3600)

#: Clés du dossier d'attente, en session.
SESSION_USER_KEY = "jeiko_2fa_user_id"
SESSION_BACKEND_KEY = "jeiko_2fa_backend"
SESSION_PASSED_KEY = "jeiko_2fa_passed"


def get_active_device(user):
    """
    Dispositif de second facteur à honorer, ou None.

    Seul le type e-mail est implémenté : un dispositif TOTP ou WebAuthn n'est
    pas retenu, pour ne pas faire croire à une protection inexistante.
    """
    from .models import TwoFactorDevice, TwoFactorType

    if not user or not user.is_authenticated:
        return None
    return (
        TwoFactorDevice.objects
        .filter(user=user, is_active=True, device_type=TwoFactorType.EMAIL)
        .order_by("-confirmed_at", "-id")
        .first()
    )


def user_requires_2fa(user):
    return get_active_device(user) is not None


def _new_code():
    """Code à N chiffres, tiré d'une source cryptographique."""
    borne = 10 ** CODE_LENGTH
    return f"{secrets.randbelow(borne):0{CODE_LENGTH}d}"


def issue_code(device):
    """
    Tire un code, en enregistre l'empreinte et le retourne en clair.

    Le clair n'est retourné que pour être envoyé immédiatement ; il n'est ni
    journalisé, ni conservé.
    """
    code = _new_code()
    device.challenge_hash = make_password(code)
    device.challenge_expires_at = timezone.now() + timezone.timedelta(
        seconds=CODE_TTL_SECONDS
    )
    device.challenge_sent_at = timezone.now()
    device.challenge_attempts = 0
    device.save(update_fields=[
        "challenge_hash", "challenge_expires_at",
        "challenge_sent_at", "challenge_attempts", "updated_at",
    ])
    return code


def clear_challenge(device):
    device.challenge_hash = ""
    device.challenge_expires_at = None
    device.challenge_attempts = 0
    device.save(update_fields=[
        "challenge_hash", "challenge_expires_at", "challenge_attempts", "updated_at",
    ])


def send_code(device, request=None):
    """
    Envoie un code au compte. Retourne True si un code est parti.

    Le plafond de renvoi protège la boîte de réception : sans lui, réafficher
    la page suffirait à la remplir.
    """
    limite, fenetre = RESEND_LIMIT
    if hit("2fa:send", device.user_id, limite, fenetre):
        logger.warning("Envoi de code 2FA refusé (plafond) user=%s", device.user_id)
        return False

    code = issue_code(device)
    minutes = CODE_TTL_SECONDS // 60

    from jeiko.emailing.services import send_email

    destinataire = (device.user.email or "").strip()
    if not destinataire:
        logger.error("2FA : le compte %s n'a pas d'adresse.", device.user_id)
        return False

    send_email(
        "twofa_code",
        destinataire,
        {"code": code, "expiration": f"{minutes} minutes"},
        user=device.user,
    )
    return True


def verify_code(device, saisie):
    """
    Vérifie un code saisi. Retourne (ok: bool, motif: str | None).

    Un code juste est consommé immédiatement : il ne peut pas resservir.
    """
    saisie = (saisie or "").strip().replace(" ", "")
    if not saisie:
        return False, "Merci de saisir le code reçu."

    if not device.challenge_hash or not device.challenge_expires_at:
        return False, "Aucun code en attente. Demandez-en un nouveau."

    if timezone.now() > device.challenge_expires_at:
        clear_challenge(device)
        return False, "Ce code a expiré. Demandez-en un nouveau."

    if device.challenge_attempts >= MAX_ATTEMPTS:
        clear_challenge(device)
        return False, "Trop d'essais. Demandez un nouveau code."

    # Un code de secours reste accepté : c'est le filet quand la boîte de
    # réception est inaccessible.
    if _consume_backup_code(device, saisie):
        clear_challenge(device)
        device.last_used_at = timezone.now()
        device.save(update_fields=["last_used_at", "updated_at"])
        return True, None

    if check_password(saisie, device.challenge_hash):
        clear_challenge(device)
        device.last_used_at = timezone.now()
        device.save(update_fields=["last_used_at", "updated_at"])
        return True, None

    device.challenge_attempts += 1
    device.save(update_fields=["challenge_attempts", "updated_at"])
    restants = MAX_ATTEMPTS - device.challenge_attempts
    if restants <= 0:
        clear_challenge(device)
        return False, "Trop d'essais. Demandez un nouveau code."
    return False, "Code incorrect."


def generate_backup_codes(device, nombre=8):
    """
    (Re)génère les codes de secours. Retourne les codes EN CLAIR, à afficher
    une seule fois — seules les empreintes sont conservées.
    """
    codes = [secrets.token_hex(4) for _ in range(nombre)]
    device.backup_codes_hashes = [make_password(c) for c in codes]
    device.save(update_fields=["backup_codes_hashes", "updated_at"])
    return codes


def _consume_backup_code(device, saisie):
    """Retire le code de secours utilisé, pour qu'il ne serve qu'une fois."""
    restants = list(device.backup_codes_hashes or [])
    for empreinte in restants:
        if check_password(saisie, empreinte):
            restants.remove(empreinte)
            device.backup_codes_hashes = restants
            device.save(update_fields=["backup_codes_hashes", "updated_at"])
            return True
    return False


# ---------------------------------------------------------------------------
#  Empreinte de session (SEC-11)
# ---------------------------------------------------------------------------

def hash_session_key(session_key):
    """
    Empreinte d'une clé de session.

    SHA-256 sans salage, à dessein : il faut pouvoir retrouver la ligne à
    partir de la clé courante. Ce n'est pas un secret à protéger contre une
    attaque par dictionnaire — une clé de session Django fait 32 caractères
    aléatoires — mais une valeur qu'on ne veut pas laisser recopiable telle
    quelle depuis un écran d'administration.
    """
    if not session_key:
        return ""
    sel = getattr(settings, "SECRET_KEY", "")
    return hashlib.sha256(f"{sel}:{session_key}".encode("utf-8")).hexdigest()
