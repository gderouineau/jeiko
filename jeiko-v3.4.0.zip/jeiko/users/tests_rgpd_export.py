# -*- coding: utf-8 -*-
"""
Export RGPD (droit d'accès / portabilité) : self-service + admin.
"""
import json

from django.test import TestCase
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.urls import reverse

from .models import Address, Consent, ConsentType
from .rgpd import build_user_export

User = get_user_model()


class ExportServiceTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username="alice", email="alice@example.com", password="pwd12345",
            first_name="Alice", last_name="Martin",
        )
        Address.objects.create(
            user=self.user, name="Maison", street_address="1 rue du Test",
            city="Paris", postal_code="75001",
        )
        Consent.objects.create(
            user=self.user, consent_type=ConsentType.PRIVACY, granted=True,
            source="test",
        )

    def test_export_contains_personal_data(self):
        data = build_user_export(self.user)
        self.assertEqual(data["account"]["email"], "alice@example.com")
        self.assertEqual(data["account"]["last_name"], "Martin")
        self.assertEqual(len(data["addresses"]), 1)
        self.assertEqual(data["addresses"][0]["postal_code"], "75001")
        types = {c["type"] for c in data["consents"]}
        self.assertIn("Politique de confidentialité", types)
        # Sections attendues présentes (même vides)
        for key in ["orders", "appointments", "questionnaires", "course_enrollments", "security"]:
            self.assertIn(key, data)

    def test_export_never_contains_password(self):
        blob = json.dumps(build_user_export(self.user))
        self.assertNotIn(self.user.password, blob)
        self.assertNotIn("password", blob.lower())


class SelfServiceExportViewTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="bob", email="bob@example.com", password="pwd12345")

    def test_requires_login(self):
        resp = self.client.get(reverse("jeiko_users_client:profile-data-export"))
        self.assertIn(resp.status_code, (301, 302))  # redirection login

    def test_downloads_own_data_as_json(self):
        self.client.force_login(self.user)
        resp = self.client.get(reverse("jeiko_users_client:profile-data-export"))
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp["Content-Type"], "application/json")
        self.assertIn("attachment", resp["Content-Disposition"])
        payload = json.loads(resp.content)
        self.assertEqual(payload["account"]["email"], "bob@example.com")


class AdminExportViewTests(TestCase):
    def setUp(self):
        self.target = User.objects.create_user(username="carol", email="carol@example.com", password="pwd12345")
        self.staff = User.objects.create_user(username="staff", password="pwd12345", is_staff=True)
        self.url = reverse("jeiko_administration_users:user_data_export", args=[self.target.pk])

    def test_denied_without_permission(self):
        self.client.force_login(self.staff)
        resp = self.client.get(self.url)
        self.assertEqual(resp.status_code, 403)

    def test_allowed_with_view_user_permission(self):
        self.staff.user_permissions.add(Permission.objects.get(codename="view_user"))
        self.client.force_login(self.staff)
        resp = self.client.get(self.url)
        self.assertEqual(resp.status_code, 200)
        payload = json.loads(resp.content)
        self.assertEqual(payload["account"]["email"], "carol@example.com")
