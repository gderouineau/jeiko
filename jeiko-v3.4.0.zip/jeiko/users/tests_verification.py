# jeiko/users/tests_verification.py
"""
Confirmation d'adresse : ce que l'administration voit, et ce qu'elle peut faire.

Le défaut d'origine
-------------------
Depuis `ACCOUNT_EMAIL_VERIFICATION = "mandatory"`, un compte a deux états sans
rapport : `is_active` — le compte n'est pas désactivé — et l'adresse confirmée
— la personne peut réellement entrer. La liste des utilisateurs n'affichait que
le premier, en vert. Un compte fraîchement inscrit s'y lisait « Actif : Oui »
alors qu'il était inutilisable, et l'exploitant cherchait la panne ailleurs.

Deux gestes manquaient : confirmer à la place de quelqu'un dont l'e-mail
n'arrive pas, et — côté visiteur — redemander le lien. L'écran d'attente
d'allauth ne propose rien d'autre qu'attendre.

Ce que ces tests attrapent
--------------------------
Le rendu de la liste (une chaîne dans du HTML), les droits sur une action qui
**ouvre un compte**, et les plafonds du renvoi — un bouton qui fait partir un
e-mail est une cible, et l'oublier ne se voit qu'une fois le domaine
blacklisté.
"""

from allauth.account.models import EmailAddress
from django.contrib.auth import get_user_model
from django.core import mail
from django.test import TestCase
from django.urls import reverse

from jeiko.users.testing import (
    configurer_lenvoi_demails,
    creer_compte_non_verifie,
    creer_compte_verifie,
    reinitialiser_les_plafonds,
)
from jeiko.users.verification import confirmer_pour, est_verifie

User = get_user_model()


class ListeDesComptesTests(TestCase):
    """La liste doit dire l'état EFFECTIF, pas le seul drapeau `is_active`."""

    @classmethod
    def setUpTestData(cls):
        # Le chef est confirmé, sinon il apparaîtrait lui-même dans sa liste
        # comme non confirmé — ce qui est d'ailleurs le cas d'un compte créé
        # par `createsuperuser`, et parfaitement exact : il se heurterait au
        # même mur à la connexion.
        cls.chef = creer_compte_verifie(
            "chef", "chef@example.test", "pw", is_staff=True, is_superuser=True
        )
        cls.confirme = creer_compte_verifie("alice", "alice@example.test", "pw")
        cls.en_attente = creer_compte_non_verifie("bob", "bob@example.test", "pw")

    def setUp(self):
        self.client.force_login(self.chef)
        self.url = reverse("jeiko_administration_users:user_list")

    def test_un_compte_non_confirme_n_est_pas_annonce_actif(self):
        corps = self.client.get(self.url).content.decode()
        self.assertIn("Non — e-mail non confirmé", corps)

    def test_un_compte_confirme_reste_annonce_actif(self):
        self.en_attente.delete()  # ne reste que le compte confirmé et le chef
        corps = self.client.get(self.url).content.decode()
        self.assertNotIn("e-mail non confirmé", corps)

    def test_l_etat_est_annote_pas_interroge_par_ligne(self):
        """
        Un `Exists` annoté, pas une requête par compte.

        On compte les requêtes sur trois comptes, puis sur quinze : le nombre
        doit être le MÊME. Interroger l'état ligne par ligne dans le gabarit
        coûterait une requête de plus par compte — un défaut qui ne se voit pas
        sur un site de démonstration et qui grossit avec la clientèle.
        """
        avec_trois = self._compter()
        for i in range(12):
            creer_compte_non_verifie(f"u{i}", f"u{i}@example.test", "pw")
        avec_quinze = self._compter()

        self.assertEqual(
            avec_trois, avec_quinze,
            f"{avec_quinze - avec_trois} requête(s) de plus pour 12 comptes "
            f"supplémentaires : l'état de confirmation est interrogé par ligne.",
        )

    def _compter(self):
        from django.db import connection
        from django.test.utils import CaptureQueriesContext

        with CaptureQueriesContext(connection) as capture:
            self.client.get(self.url)
        return len(capture)


class ConfirmerPourAutruiTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.chef = User.objects.create_superuser("chef", "chef@example.test", "pw")
        cls.simple = creer_compte_verifie("temoin", "temoin@example.test", "pw")

    def setUp(self):
        configurer_lenvoi_demails()
        reinitialiser_les_plafonds()
        self.cible = creer_compte_non_verifie("bob", "bob@example.test", "pw")
        self.url = reverse(
            "jeiko_administration_users:user_verify_email", kwargs={"pk": self.cible.pk}
        )

    def test_la_confirmation_rend_le_compte_utilisable(self):
        self.client.force_login(self.chef)
        self.assertFalse(est_verifie(self.cible))

        reponse = self.client.post(self.url, {"action": "confirmer"})
        self.assertEqual(reponse.status_code, 302)
        self.assertTrue(est_verifie(self.cible))

    def test_la_confirmation_est_tracee(self):
        """
        Elle affirme une vérification qui n'a pas eu lieu : sans trace, rien ne
        distingue plus un compte vérifié par son titulaire d'un compte ouvert
        par un administrateur.
        """
        from jeiko.users.models import SecurityEvent, SecurityEventType

        self.client.force_login(self.chef)
        self.client.post(self.url, {"action": "confirmer"})

        evenement = SecurityEvent.objects.filter(
            user=self.cible,
            event_type=SecurityEventType.EMAIL_VERIFIED_BY_ADMIN,
        ).first()
        self.assertIsNotNone(evenement, "aucune trace de la confirmation")
        self.assertEqual(evenement.extra.get("by"), self.chef.pk)

    def test_un_compte_sans_droit_est_refuse(self):
        self.client.force_login(self.simple)
        reponse = self.client.post(self.url, {"action": "confirmer"})
        self.assertEqual(reponse.status_code, 403)
        self.assertFalse(est_verifie(self.cible))

    def test_le_renvoi_depuis_l_administration_envoie_un_message(self):
        self.client.force_login(self.chef)
        mail.outbox.clear()
        self.client.post(self.url, {"action": "renvoyer"})
        self.assertEqual(len(mail.outbox), 1)
        self.assertFalse(est_verifie(self.cible))  # renvoyer ne confirme pas

    def test_confirmer_un_compte_sans_ligne_email_la_cree(self):
        """
        Cas réel : un compte créé hors du parcours d'inscription n'a aucune
        ligne `EmailAddress`. Sans elle, il n'y a rien à confirmer — et rien à
        renvoyer non plus.
        """
        orphelin = User.objects.create_user("orphelin", "orphelin@example.test", "pw")
        self.assertFalse(EmailAddress.objects.filter(user=orphelin).exists())

        fait, _ = confirmer_pour(orphelin)
        self.assertTrue(fait)
        self.assertTrue(est_verifie(orphelin))

    def test_confirmer_deux_fois_ne_fait_rien_la_seconde(self):
        confirmer_pour(self.cible)
        fait, message = confirmer_pour(self.cible)
        self.assertFalse(fait)
        self.assertIn("déjà", message)


class RenvoiDepuisLEcranDAttenteTests(TestCase):
    """Le bouton « Renvoyer l'e-mail » de l'écran public."""

    def setUp(self):
        configurer_lenvoi_demails()
        reinitialiser_les_plafonds()
        self.cible = creer_compte_non_verifie("bob", "bob@example.test", "pw")
        self.url = reverse("jeiko_allauth:renvoyer_confirmation")

    def _armer_la_session(self):
        from jeiko.users.adapters import SESSION_A_CONFIRMER

        session = self.client.session
        session[SESSION_A_CONFIRMER] = self.cible.pk
        session.save()

    def test_sans_session_on_repart_a_la_connexion(self):
        """
        Le compte vient de la session, jamais d'un champ : sans quoi l'adresse
        saisie ferait partir un e-mail vers n'importe qui, et dirait au passage
        si un compte existe.
        """
        mail.outbox.clear()
        reponse = self.client.post(self.url)
        self.assertEqual(reponse.status_code, 302)
        self.assertEqual(len(mail.outbox), 0)

    def test_avec_session_l_email_repart(self):
        self._armer_la_session()
        mail.outbox.clear()
        reponse = self.client.post(self.url)
        self.assertEqual(reponse.status_code, 302)
        self.assertEqual(len(mail.outbox), 1)

    def test_le_plafond_arrete_le_martelage(self):
        """Trois envois par compte et par quart d'heure, pas davantage."""
        self._armer_la_session()
        mail.outbox.clear()
        for _ in range(6):
            self.client.post(self.url)
        self.assertLessEqual(
            len(mail.outbox), 3,
            "le bouton de renvoi fait partir autant d'e-mails qu'on le clique.",
        )

    def test_l_ecran_d_attente_porte_le_bouton(self):
        corps = self.client.get(reverse("account_email_verification_sent")).content.decode()
        self.assertIn("Renvoyer l'e-mail", corps)
        self.assertIn(self.url, corps)
