# jeiko/users/verification.py
"""
État de confirmation d'adresse, et les deux gestes qui l'accompagnent.

Pourquoi ce module
------------------
Depuis `ACCOUNT_EMAIL_VERIFICATION = "mandatory"`, un compte a **deux** états
qui n'ont rien à voir et que l'administration confondait :

* `User.is_active` — le compte n'est pas désactivé. C'est ce que la liste
  affichait sous « Actif », en vert ;
* l'adresse est **confirmée** — le compte peut réellement se connecter.

Un compte fraîchement inscrit est donc `is_active=True` et parfaitement
inutilisable. L'écran disait « Actif : Oui » à un exploitant qui se demandait
pourquoi la personne n'arrivait pas à entrer.

L'état vit dans `allauth.account.models.EmailAddress`, pas sur `User` : c'est
une table à part, et un compte peut n'y avoir aucune ligne — les comptes créés
directement en base, ou par `User.objects.create_user()`.

Ce que ce module ne fait pas
----------------------------
Il ne remplace pas le parcours normal : la personne reçoit un lien et le suit.
`confirmer_pour` est une porte de service pour l'exploitant, quand l'e-mail
n'arrive pas — boîte pleine, filtre anti-spam, adresse saisie de travers puis
corrigée. Elle affirme une vérification qui n'a pas eu lieu : c'est pour cela
qu'elle est tracée au journal de sécurité, avec le nom de qui l'a faite.
"""

import logging

from django.db.models import Exists, OuterRef

logger = logging.getLogger(__name__)


def _modele_adresse():
    from allauth.account.models import EmailAddress

    return EmailAddress


def adresse_de(user):
    """
    L'adresse principale d'un compte, ou la première trouvée, ou `None`.

    `None` est un cas réel, pas une anomalie : un compte créé hors du parcours
    d'inscription n'a aucune ligne `EmailAddress`.
    """
    EmailAddress = _modele_adresse()
    lignes = EmailAddress.objects.filter(user=user)
    return lignes.filter(primary=True).first() or lignes.first()


def adresse_ou_creer(user):
    """
    L'adresse du compte, matérialisée si elle manque. `None` si le compte n'a
    pas d'e-mail du tout.

    Deux chemins mènent à un compte sans ligne `EmailAddress` : la création
    directe (`User.objects.create_user`, `createsuperuser`, un import), et les
    comptes antérieurs à la vérification obligatoire. Dans les deux cas il n'y
    a **rien à confirmer et rien à renvoyer** tant que la ligne n'existe pas —
    et l'absence de ligne n'est pas un refus, c'est un décor incomplet.
    """
    adresse = adresse_de(user)
    if adresse is not None:
        return adresse
    if not user.email:
        return None
    return _modele_adresse().objects.create(
        user=user, email=user.email, primary=True, verified=False
    )


def est_verifie(user):
    return _modele_adresse().objects.filter(user=user, verified=True).exists()


def annoter_verification(queryset):
    """
    Ajoute `email_verifie` à un queryset de comptes, en une seule requête.

    Sans cela, afficher l'état sur une liste de 25 comptes coûte 25 requêtes —
    et le défaut ne se voit qu'en production, quand la liste s'allonge.
    """
    EmailAddress = _modele_adresse()
    return queryset.annotate(
        email_verifie=Exists(
            EmailAddress.objects.filter(user_id=OuterRef("pk"), verified=True)
        )
    )


def confirmer_pour(user, *, request=None):
    """
    Marque l'adresse confirmée à la place de la personne.

    Retourne `(fait, message)` : `fait` est faux si rien n'a changé — pas
    d'adresse connue, ou déjà confirmée.

    Le signal `email_confirmed` est émis volontairement : c'est lui qui
    déclenche le message de bienvenue et l'alerte à l'exploitant
    (`users/signals.py`). Un compte confirmé par l'administration doit se
    comporter exactement comme un compte confirmé par son titulaire ; s'en
    dispenser créerait une seconde catégorie de comptes, silencieusement
    différente.
    """
    adresse = adresse_ou_creer(user)
    if adresse is None:
        return False, "Ce compte n'a pas d'adresse e-mail à confirmer."

    if adresse.verified:
        return False, "Cette adresse était déjà confirmée."

    adresse.verified = True
    adresse.set_as_primary(conditional=True)
    adresse.save(update_fields=["verified", "primary"])

    from allauth.account.signals import email_confirmed

    email_confirmed.send(
        sender=_modele_adresse(), request=request, email_address=adresse
    )
    logger.info(
        "Adresse %s confirmée par l'administration (compte %s).", adresse.email, user.pk
    )
    return True, f"L'adresse {adresse.email} est confirmée."


def renvoyer_confirmation(user, request):
    """
    Renvoie le lien de confirmation. Retourne `(envoye, message)`.

    Passe par `EmailAddress.send_confirmation()`, méthode publique du modèle
    d'allauth — et non par les fonctions de `allauth.account.internal`, dont le
    nom dit assez qu'elles peuvent bouger d'une version à l'autre.
    """
    adresse = adresse_ou_creer(user)
    if adresse is None:
        return False, "Ce compte n'a pas d'adresse e-mail connue."
    if adresse.verified:
        return False, "Cette adresse est déjà confirmée."

    try:
        adresse.send_confirmation(request)
    except Exception:
        logger.exception("Renvoi de la confirmation impossible (compte %s).", user.pk)
        return False, "L'e-mail n'a pas pu être envoyé. Réessayez dans un instant."

    return True, f"Un nouveau lien de confirmation a été envoyé à {adresse.email}."
