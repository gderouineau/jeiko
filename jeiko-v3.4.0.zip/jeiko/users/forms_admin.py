# users/forms_admin.py

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.utils import timezone

from jeiko.users.models import (
    Role, RolePermission, RoleAssignment,
    ProviderConfig,
    TwoFactorDevice, TwoFactorType, SecurityEvent, UserSession,
    Consent, ConsentType, MarketingPreference,
    NotificationChannel, Notification, NotificationStatus,
    ProspectLink,
    Comments,
)
from jeiko.questionnaires_expert.models import Prospect, ExpertTestData

User = get_user_model()


# =========================================================
#  Tes formulaires existants (légèrement retouchés)
# =========================================================

class AdminUserFilterForm(forms.Form):
    """
    Filtres de la liste des utilisateurs.

    Tous les widgets portent `form-control` : c'est la classe que cible
    `.jk-filter .form-control` (admin_ui.css) pour poser une hauteur de 36 px
    et supprimer la marge basse. Sans elle, chaque champ retombe sur le style
    global des formulaires d'administration — pleine largeur et marge — et les
    cinq filtres occupaient dix lignes avant le tableau.
    """

    #: Attributs communs, pour que l'ajout d'un filtre ne réintroduise pas le
    #: défaut par simple oubli.
    CLASSE = {'class': 'form-control'}

    search = forms.CharField(
        required=False,
        label="Recherche",
        widget=forms.TextInput(attrs={**CLASSE, 'placeholder': 'Nom ou email'})
    )
    is_active = forms.ChoiceField(
        required=False,
        choices=[('', 'Tous'), ('1', 'Actifs'), ('0', 'Inactifs')],
        label="Statut",
        widget=forms.Select(attrs=CLASSE),
    )
    # Conserve Group pour compat, mais tu auras désormais Role (voir plus bas)
    group = forms.ModelChoiceField(
        queryset=Group.objects.all(),
        required=False,
        label="Groupe",
        widget=forms.Select(attrs=CLASSE),
    )
    role = forms.ModelChoiceField(
        queryset=Role.objects.all(),
        required=False,
        label="Rôle",
        widget=forms.Select(attrs=CLASSE),
    )
    date_joined_from = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={**CLASSE, 'type': 'date'}),
        label="Inscrits depuis"
    )
    date_joined_to = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={**CLASSE, 'type': 'date'}),
        label="Inscrits jusqu’à"
    )


class AdminUserEditForm(forms.ModelForm):
    groups = forms.ModelMultipleChoiceField(
        queryset=Group.objects.all(),
        required=False,
        widget=forms.CheckboxSelectMultiple,
        label="Groupes"
    )

    class Meta:
        model = User
        fields = [
            'username',
            'email',
            'is_active',
            'is_staff',
            'is_superuser',
            'groups',
        ]

    def __init__(self, *args, **kwargs):
        # Le champ `request` permet de savoir qui édite (anti-escalade).
        self.request = kwargs.pop("request", None)
        super().__init__(*args, **kwargs)
        editor = getattr(self.request, "user", None)
        # Seul un superuser Django peut accorder / retirer les statuts sensibles
        # is_superuser et is_staff : on évite qu'un gestionnaire s'auto-promeuve
        # ou promeuve un tiers en super-administrateur.
        if editor is None or not editor.is_superuser:
            for fname in ("is_superuser", "is_staff"):
                if fname in self.fields:
                    self.fields[fname].disabled = True  # ignoré côté POST, conserve la valeur en base


class AdminUserCreateForm(forms.ModelForm):
    """
    Création d'un utilisateur par l'administration.

    Aucun mot de passe n'est saisi ici : le compte est créé sans mot de passe
    utilisable, et l'utilisateur définit le sien via le lien reçu par e-mail
    (account_created_by_admin). Volontairement dépouillé de is_staff/is_superuser
    pour écarter toute escalade — les droits s'attribuent ensuite par rôle depuis
    la fiche utilisateur.
    """

    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name']
        labels = {
            'username': "Nom d'utilisateur",
            'email': "Adresse e-mail",
            'first_name': "Prénom",
            'last_name': "Nom",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # L'e-mail porte le lien de définition du mot de passe : il est requis.
        self.fields['email'].required = True

    def clean_email(self):
        email = (self.cleaned_data.get('email') or '').strip()
        if email and User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("Un compte utilise déjà cette adresse e-mail.")
        return email


class CommentsForm(forms.ModelForm):
    class Meta:
        model = Comments
        fields = ['text']

    def __init__(self, *args, **kwargs):
        super(CommentsForm, self).__init__(*args, **kwargs)
        self.fields['text'].widget = forms.Textarea(
            attrs={'placeholder': 'Commentaire'}
        )


# =========================================================
#  Rôles & Permissions (site)
# =========================================================

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.db import models

from jeiko.users.models import Role, RolePermission



# ---------------------------------------------------------------------------
#  Construction dynamique du catalogue de permissions
# ---------------------------------------------------------------------------
#
#  Plutôt que de coder en dur des noms de permissions (fragile : une faute de
#  frappe = case vide), on lit les permissions réellement présentes en base et
#  on ne garde que les domaines pertinents pour l'administration du site.
#
#  Catalogue CURÉ : pour chaque domaine (titre FR), on liste explicitement les
#  couples (app_label, model) dont on veut exposer les permissions. On évite
#  ainsi de noyer l'admin sous les centaines de permissions techniques (blocs,
#  sections, images, adresses, etc.).
CURATED_PERM_GROUPS = [
    ("Pages", [
        ("administration_pages", "page"),
        ("administration_pages", "category"),
    ]),
    ("Boutique", [
        ("shop", "product"),
        ("shop", "producttype"),
        ("shop", "order"),
    ]),
    ("Paiements", [
        ("payments", "paymentgateway"),
    ]),
    ("Calendrier & rendez-vous", [
        ("calendars", "appointment"),
        ("calendars", "appointmenttype"),
        ("calendars", "availability"),
        ("calendars", "googlecalendarconfig"),
    ]),
    ("Questionnaires & prospects", [
        ("questionnaires_expert", "experttest"),
        ("questionnaires_expert", "prospect"),
        ("questionnaires_expert", "usertestaccess"),
    ]),
    ("Formations", [
        ("courses", "course"),
        ("courses", "courseenrollment"),
    ]),
    ("Objets personnalisés", [
        ("custom_objects", "customobjectmodel"),
        ("custom_objects", "customobject"),
    ]),
    ("E-mails", [
        ("emailing", "emailtemplate"),
    ]),
    ("Comptes utilisateurs", [
        ("auth", "user"),
    ]),
    ("Rôles & administration", [
        ("users", "role"),
        ("users", "adminpermission"),  # permissions métier : access_admin, config_*, assign_role
    ]),
    ("Sécurité & connexions", [
        ("users", "providerconfig"),
        ("users", "twofactordevice"),
        ("users", "usersession"),
        ("users", "securityevent"),
    ]),
    ("Consentements & notifications", [
        ("users", "consent"),
        ("users", "marketingpreference"),
        ("users", "notification"),
        ("users", "notificationchannel"),
    ]),
]

#  Traduction des verbes standard Django pour un affichage propre.
_VERB_FR = {
    "view": "Voir",
    "add": "Ajouter",
    "change": "Modifier",
    "delete": "Supprimer",
}
#  Priorité d'affichage des permissions d'un même modèle (view, add, change, delete).
_VERB_ORDER = {"view": 0, "add": 1, "change": 2, "delete": 3}

#  Codes à ne PAS exposer : doublons des permissions par défaut quand le code
#  applicatif utilise un alias plus parlant. Ex. le modèle ExpertTest déclare
#  aussi view/add/change/delete_questionnaire (utilisés par les vues) → on cache
#  les view/add/change/delete_experttest redondants pour éviter la confusion.
_EXCLUDED_CODENAMES = {
    "view_experttest", "add_experttest", "change_experttest", "delete_experttest",
}


def humanize_permission(perm: Permission) -> str:
    """Libellé lisible : « Voir : rendez-vous » plutôt que « Can view appointment »."""
    verb = perm.codename.split("_", 1)[0]
    if verb in _VERB_FR:
        return f"{_VERB_FR[verb]} : {perm.content_type.name}"
    # Permission custom (access_admin, config_edit_site, assign_role, …)
    return perm.name


def build_permission_catalog():
    """
    Renvoie une liste ordonnée de groupes :
        [(titre_fr, [(perm, label_fr), ...]), ...]
    en ne conservant que les permissions curées et réellement présentes.
    """
    # Toutes les permissions des content types cités, en une requête.
    wanted = {(a, m) for _, pairs in CURATED_PERM_GROUPS for a, m in pairs}
    perms = (
        Permission.objects
        .select_related("content_type")
        .filter(content_type__app_label__in={a for a, _ in wanted})
    )
    by_ct = {}
    for p in perms:
        if p.codename in _EXCLUDED_CODENAMES:
            continue
        key = (p.content_type.app_label, p.content_type.model)
        if key in wanted:
            by_ct.setdefault(key, []).append(p)

    def sort_key(p):
        verb = p.codename.split("_", 1)[0]
        return (_VERB_ORDER.get(verb, 9), p.codename)

    catalog = []
    for title, pairs in CURATED_PERM_GROUPS:
        items = []
        for key in pairs:
            for p in sorted(by_ct.get(key, []), key=sort_key):
                items.append((p, humanize_permission(p)))
        if items:
            catalog.append((title, items))
    return catalog


class RoleForm(forms.ModelForm):
    """
    Formulaire de rôle. Les permissions sont construites dynamiquement à partir
    de celles réellement présentes en base (cf. build_permission_catalog) et
    sont enregistrées via le modèle intermédiaire RolePermission (traçabilité
    granted_by). Le champ ``permissions`` est rendu à la main dans le template,
    groupé par domaine, mais reste validé par ce ModelMultipleChoiceField.
    """
    permissions = forms.ModelMultipleChoiceField(
        queryset=Permission.objects.none(),
        required=False,
    )

    class Meta:
        model = Role
        fields = ['name', 'slug', 'description', 'is_active', 'is_protected']

    def __init__(self, *args, **kwargs):
        # pour enregistrer granted_by + connaître le user courant
        self.request = kwargs.pop("request", None)
        super().__init__(*args, **kwargs)

        # Catalogue groupé (pour le template) + queryset plat (pour la validation).
        self.permission_catalog = build_permission_catalog()
        allowed_ids = [p.id for _, perms in self.permission_catalog for p, _ in perms]
        self.fields['permissions'].queryset = Permission.objects.filter(id__in=allowed_ids)

        # Seul un superuser Django peut créer/modifier un super-rôle.
        current_user = getattr(self.request, "user", None)
        if current_user is not None and current_user.is_superuser:
            self.fields['is_superrole'] = forms.BooleanField(
                required=False,
                label="Super-rôle (accès total au site)",
                initial=getattr(self.instance, "is_superrole", False),
            )

        # Pré-cocher les permissions déjà attachées au rôle.
        if self.instance and self.instance.pk:
            self.initial['permissions'] = list(
                RolePermission.objects
                .filter(role=self.instance)
                .values_list('permission_id', flat=True)
            )

    @property
    def selected_permission_ids(self):
        """IDs cochés (pour le rendu manuel des cases dans le template)."""
        if self.is_bound and hasattr(self.data, 'getlist'):
            return {int(x) for x in self.data.getlist('permissions') if str(x).isdigit()}
        return set(self.initial.get('permissions') or [])

    def clean(self):
        data = super().clean()
        # Un rôle protégé ne peut pas être déprotégé depuis ce formulaire.
        if (self.instance and self.instance.pk and self.instance.is_protected
                and not data.get('is_protected', True)):
            raise forms.ValidationError(
                "Ce rôle est protégé : vous ne pouvez pas le déprotéger ici."
            )
        return data

    def save(self, commit=True):
        # is_superrole n'est présent que pour un superuser (cf. __init__).
        if 'is_superrole' in self.fields:
            self.instance.is_superrole = self.cleaned_data.get('is_superrole', False)
        role = super().save(commit=commit)

        selected_ids = {p.id for p in self.cleaned_data.get('permissions') or []}
        current_ids = set(
            RolePermission.objects.filter(role=role).values_list('permission_id', flat=True)
        )

        to_add = selected_ids - current_ids
        to_del = current_ids - selected_ids

        if to_add:
            granted_by = getattr(self.request, 'user', None)
            perms_map = {p.id: p for p in Permission.objects.filter(id__in=to_add)}
            for pid in to_add:
                RolePermission.objects.get_or_create(
                    role=role,
                    permission=perms_map[pid],
                    defaults={'granted_by': granted_by},
                )
        if to_del:
            RolePermission.objects.filter(role=role, permission_id__in=to_del).delete()

        return role



class RolePermissionForm(forms.ModelForm):
    permission = forms.ModelChoiceField(
        queryset=Permission.objects.select_related('content_type').all(),
        widget=forms.Select
    )

    class Meta:
        model = RolePermission
        fields = ['role', 'permission']

    def clean(self):
        data = super().clean()
        role = data.get('role')
        perm = data.get('permission')
        if role and perm and RolePermission.objects.filter(role=role, permission=perm).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError("Cette permission est déjà attachée à ce rôle.")
        return data


class RoleAssignmentForm(forms.ModelForm):
    class Meta:
        model = RoleAssignment
        fields = ['user', 'role', 'expires_at', 'notes']
        widgets = {
            'expires_at': forms.DateTimeInput(attrs={'type': 'datetime-local'})
        }

    def clean_expires_at(self):
        expires_at = self.cleaned_data.get('expires_at')
        if expires_at and expires_at < timezone.now():
            raise forms.ValidationError("La date d’expiration doit être dans le futur.")
        return expires_at


class BulkAssignRoleForm(forms.Form):
    """
    Assigner un rôle à une sélection d'utilisateurs (IDs).
    """
    user_ids = forms.CharField(widget=forms.HiddenInput)
    role = forms.ModelChoiceField(queryset=Role.objects.filter(is_active=True), label="Rôle à assigner")

    def clean_user_ids(self):
        raw = self.cleaned_data['user_ids']
        try:
            ids = [int(x) for x in raw.split(',') if x.strip()]
        except ValueError:
            raise forms.ValidationError("Liste d'IDs invalide.")
        if not ids:
            raise forms.ValidationError("Aucun utilisateur sélectionné.")
        return ids


class BulkRevokeRoleForm(forms.Form):
    user_ids = forms.CharField(widget=forms.HiddenInput)
    role = forms.ModelChoiceField(queryset=Role.objects.all(), label="Rôle à révoquer")

    def clean_user_ids(self):
        raw = self.cleaned_data['user_ids']
        try:
            ids = [int(x) for x in raw.split(',') if x.strip()]
        except ValueError:
            raise forms.ValidationError("Liste d'IDs invalide.")
        if not ids:
            raise forms.ValidationError("Aucun utilisateur sélectionné.")
        return ids


# =========================================================
#  Providers (allauth) – config côté site
# =========================================================

class ProviderConfigForm(forms.ModelForm):
    client_secret = forms.CharField(
        widget=forms.PasswordInput(render_value=True),
        label="Client secret"
    )

    class Meta:
        model = ProviderConfig
        fields = [
            'provider', 'label',
            'client_id', 'client_secret',
            'enabled', 'callback_url', 'extra_config'
        ]
        widgets = {
            'extra_config': forms.Textarea(attrs={'rows': 3, 'placeholder': '{"scope": "..."}'})
        }


# =========================================================
#  Sécurité & Sessions
# =========================================================

class TwoFactorDeviceForm(forms.ModelForm):
    """
    Activation du second facteur pour un compte.

    Le champ `secret_or_credential` était obligatoire — hérité d'une intention
    TOTP — ce qui rendait impossible la création du seul type réellement
    implémenté. Il est retiré du formulaire : le type e-mail n'a pas de secret,
    l'adresse du compte tient lieu de destination.

    Les types TOTP et WebAuthn ne sont pas proposés tant qu'aucun code ne les
    honore : les offrir laisserait créer un dispositif qui ne protège rien, ce
    qui est exactement le défaut qu'on vient de corriger.
    """

    class Meta:
        model = TwoFactorDevice
        fields = ['user', 'device_type', 'name', 'is_active']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['device_type'].choices = [
            (TwoFactorType.EMAIL, TwoFactorType.EMAIL.label)
        ]
        self.fields['device_type'].initial = TwoFactorType.EMAIL
        self.fields['device_type'].help_text = (
            "Un code à usage unique est envoyé à l'adresse du compte à chaque "
            "connexion."
        )

    def clean(self):
        donnees = super().clean()
        utilisateur = donnees.get("user")
        if utilisateur and not (utilisateur.email or "").strip():
            raise forms.ValidationError(
                "Ce compte n'a pas d'adresse e-mail : il ne pourrait jamais "
                "recevoir son code, et se retrouverait enfermé dehors."
            )
        return donnees


class TwoFactorToggleForm(forms.Form):
    """
    Activer/Désactiver 2FA (niveau compte).
    """
    enable = forms.BooleanField(required=False, initial=True, label="Activer la double authentification")


class UserSessionRevokeForm(forms.Form):
    """
    Révoquer une ou plusieurs sessions (side admin).
    """
    session_ids = forms.CharField(widget=forms.HiddenInput)

    def clean_session_ids(self):
        raw = self.cleaned_data['session_ids']
        try:
            ids = [int(x) for x in raw.split(',') if x.strip()]
        except ValueError:
            raise forms.ValidationError("Liste d'IDs invalide.")
        if not ids:
            raise forms.ValidationError("Aucune session sélectionnée.")
        return ids


class SecurityEventFilterForm(forms.Form):
    """
    Filtrer l'audit sécurité (lecture seule).
    """
    user = forms.ModelChoiceField(queryset=User.objects.all(), required=False, label="Utilisateur")
    event_type = forms.ChoiceField(
        required=False,
        choices=[('', 'Tous')] + list(SecurityEvent._meta.get_field('event_type').choices),
        label="Type d’événement"
    )
    date_from = forms.DateTimeField(required=False, widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}))
    date_to = forms.DateTimeField(required=False, widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}))


# =========================================================
#  Consentements & Préférences
# =========================================================

class ConsentForm(forms.ModelForm):
    class Meta:
        model = Consent
        fields = [
            'user', 'anonymous_key',
            'consent_type', 'version_text',
            'granted', 'granted_at',
            'ip_address', 'evidence', 'source'
        ]
        widgets = {
            'granted_at': forms.DateTimeInput(attrs={'type': 'datetime-local'})
        }

    def clean(self):
        data = super().clean()
        user = data.get('user')
        anon = data.get('anonymous_key')
        if not user and not anon:
            raise forms.ValidationError("Renseigner un utilisateur ou un identifiant anonyme.")
        return data


class MarketingPreferenceForm(forms.ModelForm):
    class Meta:
        model = MarketingPreference
        fields = ['user', 'email_optin', 'sms_optin', 'whatsapp_optin', 'frequency', 'topics']
        widgets = {
            'topics': forms.Textarea(attrs={'rows': 2, 'placeholder': '["coaching","tests"]'})
        }


# =========================================================
#  Notifications
# =========================================================

class NotificationChannelForm(forms.ModelForm):
    class Meta:
        model = NotificationChannel
        fields = ['user', 'channel', 'enabled', 'quiet_hours']
        widgets = {
            'quiet_hours': forms.Textarea(attrs={'rows': 2, 'placeholder': '{"start":"22:00","end":"07:00"}'})
        }


class NotificationComposeForm(forms.ModelForm):
    """
    Composer/forcer l’envoi d’une notif (back-office côté site).
    """
    class Meta:
        model = Notification
        fields = ['user', 'notif_type', 'payload', 'status']
        widgets = {
            'payload': forms.Textarea(attrs={'rows': 3, 'placeholder': '{"subject":"...","message":"..."}'})
        }

    def clean_status(self):
        status = self.cleaned_data.get('status')
        if status not in [NotificationStatus.QUEUED, NotificationStatus.SENT]:
            # On interdit de créer directement en FAILED/OPENED ici
            raise forms.ValidationError("Statut non autorisé à la création.")
        return status


# =========================================================
#  Bridge User ↔ Prospect
# =========================================================

class ProspectLinkForm(forms.ModelForm):
    class Meta:
        model = ProspectLink
        fields = ['user', 'prospect']
        widgets = {
            'user': forms.Select(attrs={'class': 'form-control'}),
            'prospect': forms.Select(attrs={'class': 'form-control'}),
        }

    def clean(self):
        data = super().clean()
        user = data.get('user')
        prospect = data.get('prospect')
        if user and prospect and ProspectLink.objects.filter(user=user, prospect=prospect).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError("Ce User est déjà lié à ce Prospect.")
        return data


# --- Questionnaires Access ---
from jeiko.questionnaires_expert.models import UserTestAccess

class UserTestAccessForm(forms.ModelForm):
    class Meta:
        model = UserTestAccess
        fields = ['user', 'test', 'source']
        widgets = {
            'user': forms.HiddenInput(),
            'test': forms.Select(attrs={'class': 'form-control'}),
            'source': forms.Select(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Accorder un accès n'a de sens que sur un test à accès restreint :
        # sur un test public, l'objet serait créé sans rien changer.
        from jeiko.questionnaires_expert.models import ExpertTest
        self.fields['test'].queryset = ExpertTest.objects.filter(
            is_restricted=True
        ).order_by('title')


# =========================================================
#  Utilitaires “site” (actions rapides)
# =========================================================

class SyncProviderToAllauthForm(forms.Form):
    """
    Déclenchera la synchronisation ProviderConfig -> allauth.SocialApp.
    """
    provider_config_id = forms.IntegerField(widget=forms.HiddenInput)


class BulkNotificationForm(forms.Form):
    """
    Envoi d’une notification à une sélection d’utilisateurs.
    """
    user_ids = forms.CharField(widget=forms.HiddenInput)
    notif_type = forms.CharField(max_length=64, label="Type interne")
    payload = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), required=False)

    def clean_user_ids(self):
        raw = self.cleaned_data['user_ids']
        try:
            ids = [int(x) for x in raw.split(',') if x.strip()]
        except ValueError:
            raise forms.ValidationError("Liste d'IDs invalide.")
        if not ids:
            raise forms.ValidationError("Aucun utilisateur sélectionné.")
        return ids
