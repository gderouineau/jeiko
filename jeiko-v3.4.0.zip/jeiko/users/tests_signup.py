"""
Inscription : le parcours doit aboutir, et échouer visiblement s'il échoue.

Signalé en production : l'inscription renvoyait le formulaire vide, sans aucun
message. Cause — `CustomSignupForm` déclare `first_name` et `last_name`
OBLIGATOIRES, mais le gabarit ne les rendait pas (sa boucle ne parcourait que
`hidden_fields`, or ce sont des champs visibles). Ils étaient donc absents du
POST, la validation échouait, et les erreurs portaient sur des champs
invisibles : rien ne s'affichait.

D'où les deux garanties testées ici : l'inscription aboutit, et **tout champ
obligatoire du formulaire est effectivement rendu** — c'est cette seconde
garantie qui empêche le défaut de revenir sous une autre forme.
"""

from django.contrib.auth import get_user_model
from django.core import mail
from django.test import TestCase
from django.urls import reverse

from jeiko.users.forms import CustomSignupForm
from jeiko.users.testing import (
    configurer_lenvoi_demails,
    creer_compte_verifie,
    reinitialiser_les_plafonds,
)

User = get_user_model()


class FormulaireRenduTests(TestCase):
    def test_tous_les_champs_obligatoires_sont_rendus(self):
        """
        La garantie qui compte : un champ obligatoire absent du gabarit rend
        l'inscription impossible ET muette.
        """
        page = self.client.get(reverse("jeiko_allauth:signup"))
        html = page.content.decode()

        manquants = [
            nom for nom, champ in CustomSignupForm().fields.items()
            if champ.required and f'name="{nom}"' not in html
        ]
        self.assertEqual(
            manquants, [],
            f"Champs obligatoires jamais affichés : {manquants}. "
            "L'inscription échouera sans message.",
        )


class InscriptionTests(TestCase):
    URL = None

    def setUp(self):
        # Les compteurs anti-abus vivent dans le cache, donc SURVIVENT d'un
        # test à l'autre : sans remise à zéro, le sixième test d'une classe se
        # ferait refuser par le plafond posé par les cinq précédents, et
        # l'échec serait incompréhensible.
        reinitialiser_les_plafonds()
        self.URL = reverse("jeiko_allauth:signup")

    def donnees(self, **surcharge):
        base = {
            "email": "nouveau@exemple.test",
            "username": "nouveau",
            "first_name": "Camille",
            "last_name": "Durand",
            "password1": "MotDePasse-Solide-42",
            "password2": "MotDePasse-Solide-42",
        }
        base.update(surcharge)
        return base

    def test_une_inscription_complete_cree_le_compte(self):
        self.client.post(self.URL, self.donnees())
        self.assertTrue(
            User.objects.filter(username="nouveau").exists(),
            "Le compte n'a pas été créé alors que le formulaire était complet.",
        )

    def test_le_prenom_et_le_nom_sont_enregistres(self):
        self.client.post(self.URL, self.donnees())
        compte = User.objects.get(username="nouveau")
        self.assertEqual(compte.first_name, "Camille")
        self.assertEqual(compte.last_name, "Durand")

    def test_l_inscription_ne_connecte_PAS_le_nouveau_compte(self):
        """
        Le contraire de ce que ce test affirmait avant.

        Tant que l'adresse n'est pas confirmée, le compte ne doit pas ouvrir de
        session : c'est tout l'objet de `ACCOUNT_EMAIL_VERIFICATION =
        "mandatory"`. Connecter d'emblée reviendrait à ne rien vérifier du tout.
        """
        self.client.post(self.URL, self.donnees())
        self.assertIsNone(
            self.client.session.get("_auth_user_id"),
            "Le compte est connecté sans avoir confirmé son adresse.",
        )

    def test_un_echec_affiche_un_message(self):
        """Un refus doit se voir : c'est tout le problème d'origine."""
        reponse = self.client.post(
            self.URL, self.donnees(password2="pas-le-meme"), follow=True
        )
        self.assertContains(reponse, "error", status_code=200)

    def test_une_adresse_deja_prise_ne_cree_pas_de_second_compte(self):
        """
        Et le formulaire ne DOIT PAS dire que l'adresse est déjà connue.

        Ce test attendait auparavant une erreur affichée. C'est le contraire de
        ce qu'il faut : répondre « cette adresse est déjà prise » transforme le
        formulaire d'inscription en oracle, où l'on découvre qui a un compte sur
        le site en essayant des adresses. allauth prévient cette énumération
        (`ACCOUNT_PREVENT_ENUMERATION`, actif par défaut) en répondant
        exactement comme pour une inscription réussie, et en prévenant par
        e-mail le titulaire de l'adresse.

        Ce qui compte est donc double : aucun second compte, et aucune
        divulgation.
        """
        creer_compte_verifie("deja", "nouveau@exemple.test", "mdp")
        avant = User.objects.count()

        reponse = self.client.post(self.URL, self.donnees(username="autre"))

        self.assertEqual(User.objects.count(), avant,
                         "Un second compte a été créé sur une adresse déjà prise.")
        self.assertEqual(reponse.status_code, 302,
                         "Le formulaire distingue le cas « adresse déjà prise » : "
                         "il révèle qui a un compte.")


class ConfirmationDAdresseTests(TestCase):
    """
    Le compte n'existe vraiment qu'une fois l'adresse confirmée.

    Avant, `ACCOUNT_EMAIL_VERIFICATION` valait "none" : n'importe qui pouvait
    créer un compte avec l'adresse d'un tiers, sur un site qui vend et qui ouvre
    des accès à des formations.
    """

    def setUp(self):
        reinitialiser_les_plafonds()
        configurer_lenvoi_demails()
        self.URL = reverse("jeiko_allauth:signup")
        mail.outbox = []

    def _inscrire(self, **surcharge):
        base = {
            "email": "nouveau@exemple.test",
            "username": "nouveau",
            "first_name": "Camille",
            "last_name": "Durand",
            "password1": "MotDePasse-Solide-42",
            "password2": "MotDePasse-Solide-42",
        }
        base.update(surcharge)
        return self.client.post(self.URL, base)

    def test_un_lien_de_confirmation_est_envoye(self):
        self._inscrire()
        self.assertTrue(mail.outbox, "Aucun e-mail n'est parti à l'inscription.")

    def test_la_connexion_est_refusee_avant_confirmation(self):
        """La garantie centrale : une adresse non confirmée n'ouvre rien."""
        self._inscrire()
        self.client.logout()
        self.client.post(reverse("jeiko_allauth:login"), {
            "login": "nouveau", "password": "MotDePasse-Solide-42",
        })
        self.assertIsNone(self.client.session.get("_auth_user_id"))

    def test_la_confirmation_declenche_bienvenue_et_alerte_interne(self):
        """
        Les deux envois étaient branchés sur l'inscription. Résultat : le
        visiteur recevait « Bienvenue » en même temps que « Confirmez votre
        adresse », et l'exploitant était prévenu de comptes qui n'existeraient
        jamais. Ils partent désormais à la confirmation.
        """
        from allauth.account.models import EmailAddress
        from allauth.account.signals import email_confirmed

        self._inscrire()
        compte = User.objects.get(username="nouveau")
        adresse = EmailAddress.objects.get(user=compte)
        mail.outbox = []

        adresse.verified = True
        adresse.save(update_fields=["verified"])
        email_confirmed.send(sender=EmailAddress, request=None, email_address=adresse)

        self.assertTrue(
            mail.outbox,
            "Ni bienvenue ni alerte interne à la confirmation : les envois "
            "sont restés branchés sur l'inscription.",
        )


class AntispamInscriptionTests(TestCase):
    """
    Créer un compte écrit deux lignes et déclenche un e-mail : c'est le point
    d'entrée public le plus coûteux du site, et il n'avait aucun garde-fou.
    """

    def setUp(self):
        reinitialiser_les_plafonds()
        self.URL = reverse("jeiko_allauth:signup")

    def _donnees(self, **surcharge):
        base = {
            "email": "robot@exemple.test",
            "username": "robot",
            "first_name": "Robot",
            "last_name": "Test",
            "password1": "MotDePasse-Solide-42",
            "password2": "MotDePasse-Solide-42",
        }
        base.update(surcharge)
        return base

    def test_le_leurre_rempli_bloque_la_creation(self):
        self.client.post(self.URL, self._donnees(company="Acme SARL"))
        self.assertFalse(
            User.objects.filter(username="robot").exists(),
            "Un formulaire dont le leurre est rempli a créé un compte.",
        )

    def test_le_leurre_est_hors_de_vue_et_hors_tabulation(self):
        """
        Un leurre VISIBLE est pire que pas de leurre : le visiteur le remplit
        de bonne foi et son inscription est refusée sans qu'il comprenne.
        """
        html = self.client.get(self.URL).content.decode()
        self.assertIn('name="company"', html, "Le leurre doit être dans la page.")
        self.assertIn("cf-hp", html, "Le leurre doit porter la classe qui le masque.")
        self.assertIn('tabindex="-1"', html, "Le leurre doit être hors tabulation.")

    def test_le_plafond_finit_par_refuser(self):
        """Le martèlement est arrêté avant d'avoir rempli la base."""
        for i in range(25):
            self.client.post(self.URL, self._donnees(
                username=f"robot{i}", email=f"robot{i}@exemple.test",
            ))
        self.assertLess(
            User.objects.count(), 25,
            "Aucun plafond : 25 inscriptions d'affilée ont toutes abouti.",
        )

    def test_le_plafond_compte_par_adresse_ip(self):
        """
        Sans requête, `get_client_ip` renvoie « unknown » et TOUS les visiteurs
        partagent un même compteur : le site se fermerait à tout le monde après
        cinq inscriptions. `SignupForm` d'allauth n'accepte pas `request` — la
        vue doit le fournir explicitement.
        """
        from jeiko.users.forms import CustomSignupForm

        page = self.client.get(self.URL)
        formulaire = page.context["form"]
        self.assertIsInstance(formulaire, CustomSignupForm)
        self.assertIsNotNone(
            getattr(formulaire, "request", None),
            "Le formulaire n'a pas reçu la requête : le plafond serait global.",
        )


class DepuisLaConnexionTests(TestCase):
    def test_la_page_de_connexion_propose_de_creer_un_compte(self):
        """
        Le tunnel de commande exige désormais un compte : sans ce lien, un
        acheteur envoyé vers la connexion n'a aucun moyen d'en créer un.
        """
        page = self.client.get(reverse("jeiko_allauth:login"))
        self.assertContains(page, reverse("jeiko_allauth:signup"))
