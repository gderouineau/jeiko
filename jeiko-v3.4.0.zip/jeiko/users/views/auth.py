# users/views.py

from django.contrib.auth import get_user_model
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import DetailView, UpdateView

from allauth.account.utils import perform_login
from allauth.account.views import SignupView, LoginView, LogoutView

from jeiko.users import twofactor
from jeiko.users.forms import CustomSignupForm, ProfileForm, CustomLoginForm
from jeiko.users.models import SecurityEventType

class CustomSignupView(SignupView):
    form_class = CustomSignupForm
    template_name = 'users/client/signup.html'

    def get_form_kwargs(self):
        """
        Fournit la requête au formulaire.

        `SignupForm` d'allauth ne la reçoit pas de lui-même. Le formulaire en a
        besoin pour ses garde-fous anti-abus, qui comptent par adresse IP :
        sans elle, le compteur serait commun à tous les visiteurs.
        """
        kwargs = super().get_form_kwargs()
        kwargs["request"] = self.request
        return kwargs
    # Le namespace réel est `jeiko_users_client` (cf. users/urls/client.py) :
    # « jeiko_users » n'existe pas. La redirection de fin d'inscription levait
    # donc une NoReverseMatch — une 500 juste après la création du compte. Le
    # défaut restait invisible parce que le formulaire, lui, n'était jamais
    # valide (champs obligatoires non rendus) : on n'atteignait jamais ce point.
    success_url = reverse_lazy('jeiko_users_client:profile-detail')


class CustomLoginView(LoginView):
    form_class = CustomLoginForm
    template_name = 'users/client/login.html'


class CustomLogoutView(LogoutView):
    template_name = 'users/client/logout.html'


class RenvoyerConfirmationView(View):
    """
    Bouton « Renvoyer l'e-mail » de l'écran d'attente de confirmation.

    Le compte concerné vient de la SESSION, jamais du formulaire. C'est ce qui
    évite d'en faire un service d'envoi ouvert : sans cela, une adresse dans un
    champ suffirait à faire partir un message depuis le domaine du site, vers
    n'importe qui, autant de fois qu'on veut — et à répondre au passage si un
    compte existe pour cette adresse.

    Deux plafonds, sur le modèle de `users/throttling.py` : un par compte, qui
    protège la boîte du destinataire du harcèlement, et un par adresse IP, qui
    protège la réputation d'expéditeur du domaine.
    """

    #: (nombre maximum, fenêtre en secondes)
    LIMITES = {
        "compte": (3, 900),
        "ip": (10, 3600),
    }

    MESSAGE_PLAFOND = (
        "Un e-mail vient d'être envoyé. Patientez quelques minutes avant d'en "
        "redemander un, et pensez à regarder dans les indésirables."
    )

    def post(self, request):
        from django.contrib import messages

        from jeiko.throttling import get_client_ip, get_limits, hit
        from jeiko.users.adapters import SESSION_A_CONFIRMER
        from jeiko.users.verification import renvoyer_confirmation

        user_id = request.session.get(SESSION_A_CONFIRMER)
        if not user_id:
            # Arrivée directe sur l'URL, ou session expirée : on ne dit pas
            # « compte inconnu », qui renseignerait. On renvoie à la connexion.
            return redirect("account_login")

        user = get_user_model().objects.filter(pk=user_id).first()
        if user is None:
            return redirect("account_login")

        limites = get_limits("JEIKO_RESEND_CONFIRMATION_LIMITS", self.LIMITES)
        trop = hit("confirm:resend:user", str(user.pk), *limites["compte"]) or hit(
            "confirm:resend:ip", get_client_ip(request), *limites["ip"]
        )
        if trop:
            messages.warning(request, self.MESSAGE_PLAFOND)
            return redirect("account_email_verification_sent")

        envoye, message = renvoyer_confirmation(user, request)
        (messages.success if envoye else messages.warning)(request, message)
        return redirect("account_email_verification_sent")


class TwoFactorVerifyView(View):
    """
    Saisie du code reçu par e-mail, entre le mot de passe et la session.

    L'utilisateur n'est PAS connecté à ce stade : il n'est identifié que par ce
    que porte sa session côté serveur, déposé par l'adaptateur. Rien dans l'URL
    ni dans le formulaire ne désigne le compte — sinon il suffirait de changer
    un identifiant pour se faire passer pour un autre.
    """

    template_name = "users/client/twofa_verify.html"

    def _pending_user(self, request):
        user_id = request.session.get(twofactor.SESSION_USER_KEY)
        if not user_id:
            return None
        return get_user_model().objects.filter(pk=user_id, is_active=True).first()

    def get(self, request):
        user = self._pending_user(request)
        if user is None:
            return redirect("account_login")
        return render(request, self.template_name, {"email": _masque(user.email)})

    def post(self, request):
        user = self._pending_user(request)
        if user is None:
            return redirect("account_login")

        device = twofactor.get_active_device(user)
        if device is None:
            # La 2FA a été retirée entre-temps : plus rien à vérifier.
            return self._finaliser(request, user)

        if request.POST.get("action") == "resend":
            envoye = twofactor.send_code(device, request)
            message = ("Un nouveau code vient d'être envoyé."
                       if envoye else
                       "Trop de demandes de code. Réessayez plus tard.")
            return render(request, self.template_name,
                          {"email": _masque(user.email), "info": message})

        ok, motif = twofactor.verify_code(device, request.POST.get("code"))
        if not ok:
            _journaliser(request, user, SecurityEventType.LOGIN_FAILURE,
                         {"etape": "2fa"})
            return render(request, self.template_name,
                          {"email": _masque(user.email), "error": motif},
                          status=400)

        return self._finaliser(request, user)

    def _finaliser(self, request, user):
        """Ouvre enfin la session, en repassant par allauth."""
        backend = request.session.get(twofactor.SESSION_BACKEND_KEY)
        suite = request.session.get("jeiko_2fa_next")

        for cle in (twofactor.SESSION_USER_KEY, twofactor.SESSION_BACKEND_KEY,
                    "jeiko_2fa_next"):
            request.session.pop(cle, None)

        # Laissez-passer à usage unique, lu puis retiré par l'adaptateur : sans
        # lui, `pre_login` redemanderait un code en boucle.
        request.session[twofactor.SESSION_PASSED_KEY] = True

        if backend:
            user.backend = backend
        perform_login(request, user, email_verification=None)
        return redirect(suite or "/")


def _masque(email):
    """« camille@exemple.fr » -> « c•••e@exemple.fr » : assez pour se repérer."""
    email = (email or "").strip()
    if "@" not in email:
        return ""
    nom, domaine = email.split("@", 1)
    if len(nom) <= 2:
        return f"{nom[:1]}•••@{domaine}"
    return f"{nom[0]}•••{nom[-1]}@{domaine}"


def _journaliser(request, user, event_type, extra=None):
    from jeiko.users.security_log import log_event

    log_event(request, user, event_type, extra)
