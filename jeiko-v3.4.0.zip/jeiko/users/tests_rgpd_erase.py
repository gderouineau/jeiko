# -*- coding: utf-8 -*-
"""
Effacement RGPD (droit à l'oubli) : anonymisation des données sous rétention
légale, suppression du reste, désactivation du compte. Self-service + admin.
"""
from datetime import timedelta

from django.test import TestCase
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.urls import reverse
from django.utils import timezone

from .models import (
    Address, Consent, ConsentType, Profile, SecurityEvent, SecurityEventType,
)
from .rgpd import erase_user_data
from jeiko.shop.models import Order
from jeiko.calendars.models import Appointment, AppointmentType

User = get_user_model()


class EraseServiceTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username="dan", email="dan@example.com", password="pwd12345",
            first_name="Dan", last_name="Durand",
        )
        Profile.objects.update_or_create(user=self.user, defaults={"phone_number": "0600000000"})
        Address.objects.create(user=self.user, name="Maison",
                               street_address="1 rue X", city="Paris", postal_code="75001")
        Consent.objects.create(user=self.user, consent_type=ConsentType.PRIVACY, granted=True)
        self.order = Order.objects.create(
            user=self.user, billing_name="Dan Durand",
            billing_address="1 rue X, 75001 Paris", shipping_name="Dan Durand",
            shipping_address="1 rue X",
        )
        self.appt_type = AppointmentType.objects.create(
            name="Consult", user=self.user, duration=timedelta(hours=1), capacity=1,
        )
        start = timezone.now() + timedelta(days=2)
        self.appt = Appointment.objects.create(
            type=self.appt_type, start=start, end=start + timedelta(hours=1),
            user=self.user, email="dan@example.com", client_name="Dan Durand",
        )

    def test_erase_anonymizes_and_deletes(self):
        erase_user_data(self.user, actor=self.user, reason="test")

        # Compte : vidé + désactivé, ligne conservée
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_active)
        self.assertEqual(self.user.email, "")
        self.assertEqual(self.user.first_name, "")
        self.assertTrue(self.user.username.startswith("deleted-"))
        self.assertFalse(self.user.has_usable_password())

        # Rétention légale : commande conservée mais anonymisée
        self.order.refresh_from_db()
        self.assertEqual(self.order.billing_name, "")
        self.assertEqual(self.order.billing_address, "")
        self.assertEqual(self.order.user_id, self.user.pk)  # coquille anonymisée

        # RDV : identité effacée
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.email, "")
        self.assertEqual(self.appt.client_name, "")

        # Données personnelles supprimées
        self.assertFalse(Profile.objects.filter(user=self.user).exists())
        self.assertFalse(Address.objects.filter(user=self.user).exists())
        self.assertFalse(Consent.objects.filter(user=self.user).exists())

        # Trace d'audit
        self.assertTrue(SecurityEvent.objects.filter(
            user=self.user, event_type=SecurityEventType.ACCOUNT_ERASED).exists())


class SelfServiceDeleteViewTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="erin", email="erin@example.com", password="pwd12345")
        self.url = reverse("jeiko_users_client:profile-data-delete")

    def test_wrong_confirmation_does_not_delete(self):
        self.client.force_login(self.user)
        resp = self.client.post(self.url, {"confirm": "oui"})
        self.assertEqual(resp.status_code, 200)  # ré-affiche la page
        self.user.refresh_from_db()
        self.assertTrue(self.user.is_active)

    def test_correct_confirmation_erases_and_logs_out(self):
        self.client.force_login(self.user)
        resp = self.client.post(self.url, {"confirm": "SUPPRIMER"})
        self.assertEqual(resp.status_code, 302)
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_active)
        self.assertEqual(self.user.email, "")


class AdminDeleteViewTests(TestCase):
    def setUp(self):
        self.target = User.objects.create_user(username="frank", email="frank@example.com", password="pwd12345")
        self.staff = User.objects.create_user(username="staff", password="pwd12345", is_staff=True)
        self.staff.user_permissions.add(Permission.objects.get(codename="delete_user"))
        self.url = reverse("jeiko_administration_users:user_data_delete", args=[self.target.pk])

    def test_denied_without_permission(self):
        nobody = User.objects.create_user(username="nobody", password="pwd12345", is_staff=True)
        self.client.force_login(nobody)
        self.assertEqual(self.client.post(self.url, {"confirm": "SUPPRIMER"}).status_code, 403)

    def test_superuser_target_is_protected(self):
        su = User.objects.create_superuser(username="root", email="r@example.com", password="pwd12345")
        self.client.force_login(self.staff)
        resp = self.client.post(
            reverse("jeiko_administration_users:user_data_delete", args=[su.pk]),
            {"confirm": "SUPPRIMER"},
        )
        su.refresh_from_db()
        self.assertTrue(su.is_active)  # non effacé

    def test_erases_target_with_confirmation(self):
        self.client.force_login(self.staff)
        resp = self.client.post(self.url, {"confirm": "SUPPRIMER"})
        self.assertEqual(resp.status_code, 302)
        self.target.refresh_from_db()
        self.assertFalse(self.target.is_active)
        self.assertEqual(self.target.email, "")
