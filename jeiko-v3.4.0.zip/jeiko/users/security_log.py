# jeiko/users/security_log.py
"""
Journal de sécurité et suivi des sessions.

Deux dispositifs existaient sur le papier et ne fonctionnaient pas :

- `SecurityEvent` n'était écrit que pour les changements de rôle et
  l'effacement RGPD. Aucune connexion, aucun échec, aucune déconnexion n'y
  figurait — après un incident, il n'y avait rien à lire pour savoir quand et
  depuis où un compte avait été pris.
- `UserSession` n'était **jamais créé** : ni signal, ni middleware. L'écran
  « sessions actives » était structurellement vide, et « déconnecter partout »
  se contentait de passer un drapeau à False sans toucher à la session Django.

Ce module branche les deux sur les signaux d'authentification, qui voient
passer toutes les entrées quel que soit le chemin emprunté.
"""

import logging

from django.contrib.auth import get_user_model
from django.contrib.auth.signals import (
    user_logged_in,
    user_logged_out,
    user_login_failed,
)
from django.dispatch import receiver
from django.utils import timezone

from jeiko.throttling import get_client_ip

logger = logging.getLogger(__name__)


def log_event(request, user, event_type, extra=None):
    """
    Écrit un événement. Ne lève jamais : journaliser ne doit pas empêcher de
    se connecter.
    """
    from .models import SecurityEvent

    try:
        SecurityEvent.objects.create(
            user=user if getattr(user, "pk", None) else None,
            event_type=event_type,
            ip_address=_ip_ou_none(request),
            user_agent=(request.META.get("HTTP_USER_AGENT", "")[:1000]
                        if request else ""),
            extra=extra or {},
        )
    except Exception:
        logger.exception("Écriture du journal de sécurité impossible (%s)",
                         event_type)


def _ip_ou_none(request):
    if request is None:
        return None
    ip = get_client_ip(request)
    # Le champ est un GenericIPAddressField : « unknown » le ferait échouer.
    return ip if ip and ip != "unknown" else None


def track_session(request, user):
    """
    Enregistre — ou rafraîchit — la session courante de l'utilisateur.

    La clé n'est jamais stockée telle quelle : seule son empreinte l'est, pour
    que l'écran d'administration ne devienne pas un moyen d'usurper les
    sessions qu'il liste.
    """
    from .models import UserSession
    from .twofactor import hash_session_key

    if request is None or not getattr(request, "session", None):
        return None

    if not request.session.session_key:
        request.session.save()
    empreinte = hash_session_key(request.session.session_key)
    if not empreinte:
        return None

    try:
        session, _ = UserSession.objects.update_or_create(
            user=user,
            session_key_hash=empreinte,
            defaults={
                "last_seen": timezone.now(),
                "ip_last": _ip_ou_none(request),
                "user_agent_last": request.META.get("HTTP_USER_AGENT", "")[:1000],
                "is_active": True,
            },
        )
        return session
    except Exception:
        logger.exception("Suivi de session impossible (user=%s)",
                         getattr(user, "pk", None))
        return None


def revoke_sessions(session_ids):
    """
    Ferme réellement les sessions désignées.

    L'ancienne version passait `is_active=False` sur la ligne de journal et
    s'arrêtait là : le cookie du navigateur restait parfaitement valide. Il faut
    supprimer la session du magasin de sessions, seul endroit qui compte.
    """
    from django.contrib.sessions.models import Session

    from .models import UserSession
    from .twofactor import hash_session_key

    lignes = list(UserSession.objects.filter(id__in=session_ids))
    if not lignes:
        return 0

    cibles = {ligne.session_key_hash for ligne in lignes}
    # Le magasin ne connaît que les clés en clair : on les rehache pour
    # retrouver celles qui correspondent.
    for session in Session.objects.iterator():
        if hash_session_key(session.session_key) in cibles:
            session.delete()

    UserSession.objects.filter(id__in=[l.id for l in lignes]).update(is_active=False)
    return len(lignes)


# =========================
#  Signaux
# =========================

@receiver(user_logged_in, dispatch_uid="jeiko_users_login_event")
def _on_login(sender, request, user, **kwargs):
    from .models import SecurityEventType

    log_event(request, user, SecurityEventType.LOGIN_SUCCESS)
    track_session(request, user)


@receiver(user_logged_out, dispatch_uid="jeiko_users_logout_event")
def _on_logout(sender, request, user, **kwargs):
    from .models import SecurityEventType, UserSession
    from .twofactor import hash_session_key

    if user is None:
        return
    log_event(request, user, SecurityEventType.LOGOUT)

    if request is not None and getattr(request, "session", None):
        empreinte = hash_session_key(request.session.session_key)
        if empreinte:
            UserSession.objects.filter(
                user=user, session_key_hash=empreinte
            ).update(is_active=False)


@receiver(user_login_failed, dispatch_uid="jeiko_users_login_failed_event")
def _on_login_failed(sender, credentials, request=None, **kwargs):
    from .models import SecurityEventType

    # `credentials` est déjà expurgé par Django (le mot de passe est masqué),
    # mais on ne garde que l'identifiant : rien d'autre n'a d'intérêt ici.
    identifiant = (credentials or {}).get("username") or ""
    utilisateur = None
    if identifiant:
        utilisateur = get_user_model().objects.filter(
            username=identifiant
        ).first() or get_user_model().objects.filter(email=identifiant).first()

    log_event(request, utilisateur, SecurityEventType.LOGIN_FAILURE,
              {"identifiant": identifiant[:150]})
