# jeiko/users/testing.py
"""
Fabrique de comptes pour les tests.

Pourquoi ce module existe
-------------------------
Depuis que `ACCOUNT_EMAIL_VERIFICATION` vaut "mandatory", allauth refuse la
connexion à tout compte dont l'adresse n'est pas marquée vérifiée dans
`account_emailaddress`. Or `User.objects.create_user()` ne crée pas cette
ligne : un compte fabriqué ainsi ne peut pas se connecter, et une douzaine de
tests portant sur la 2FA, le journal de sécurité ou les sessions échouaient
d'un coup — non parce que ce qu'ils vérifient s'est cassé, mais parce que leur
décor était devenu irréaliste.

`creer_compte_verifie` produit l'état dans lequel se trouvent réellement les
comptes en service : ceux repris par la migration 0010, et ceux qui ont suivi
leur lien de confirmation. Un test qui part de là teste le site tel qu'il est.

Pour éprouver le cas inverse — un compte en attente de confirmation — utiliser
`creer_compte_non_verifie`, qui rend explicite ce qu'on met à l'épreuve.
"""

from django.contrib.auth import get_user_model


def reinitialiser_les_plafonds():
    """
    Remet à zéro TOUS les compteurs anti-abus, les nôtres et ceux d'allauth.

    `jeiko.throttling.reset_counters()` ne vide que l'alias `jeiko_throttle`,
    isolé à dessein pour qu'un `cache.clear()` applicatif ne désarme pas nos
    garde-fous. Mais allauth compte dans le cache `default` : un test qui
    martèle l'inscription y laisse un plafond atteint, et les tests suivants
    reçoivent un 429 sans rapport avec ce qu'ils vérifient.

    C'est le constat S-09 vu depuis les tests : les deux dispositifs ne
    partagent pas le même cache, et il faut vider les deux pour repartir
    proprement.
    """
    from django.core.cache import cache

    from jeiko.throttling import reset_counters

    reset_counters()
    cache.clear()


def configurer_lenvoi_demails():
    """
    Donne au site de quoi expédier, pour que les e-mails atteignent `outbox`.

    Les envois du paquet passent tous par le catalogue éditable
    (`jeiko.emailing.services.send_email`), qui lit les réglages SMTP portés
    par `WebSite.mail_settings`. Sans eux, `send_email` renonce en silence —
    comportement voulu en production, où un site à moitié configuré ne doit pas
    lever à chaque envoi, mais qui rend muet tout test cherchant à vérifier
    qu'un message est parti.
    """
    from jeiko.administration.models import MailSettings, WebSite

    site = WebSite.objects.first()
    if site is None:
        return None
    site.mail_settings = MailSettings.objects.create(
        host="localhost", port=587, active=True,
        default_from_email="site@exemple.test",
    )
    site.save(update_fields=["mail_settings"])
    return site


def creer_compte_verifie(username, email, password, **champs):
    """
    Compte utilisable, adresse confirmée. L'état normal d'un compte en service.
    """
    from allauth.account.models import EmailAddress

    User = get_user_model()
    compte = User.objects.create_user(username, email, password, **champs)
    if email:
        EmailAddress.objects.update_or_create(
            user=compte, email=email,
            defaults={"verified": True, "primary": True},
        )
    return compte


def creer_compte_non_verifie(username, email, password, **champs):
    """
    Compte créé mais pas encore confirmé : il ne doit PAS pouvoir se connecter.

    C'est l'état d'une inscription abandonnée — de loin le plus fréquent — et
    celui qu'il faut choisir pour vérifier que la porte est bien fermée.
    """
    User = get_user_model()
    return User.objects.create_user(username, email, password, **champs)
