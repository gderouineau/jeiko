"""
Consentement cookies — preuve, catégories essentielles, garde-fous.

Ce module n'avait aucun test, alors qu'il porte une obligation : la preuve du
consentement. Les points vérifiés ici sont ceux dont l'absence coûterait cher en
cas de contrôle, ou ouvrirait un point d'écriture public non borné.
"""

import json

from django.contrib.sites.models import Site
from django.test import TestCase
from django.urls import reverse

from jeiko.cookies.models import CookieCategory, CookieConsent
from jeiko.throttling import reset_counters


class ConsentementFixture(TestCase):
    def setUp(self):
        reset_counters()
        self.site = Site.objects.get_current()
        # `_categories()` filtre sur la locale : reprendre celle du modèle
        # évite un décor invisible depuis la vue.
        from jeiko.cookies.models import default_locale

        commun = {"site": self.site, "locale": default_locale(), "is_active": True}
        self.essentiel = CookieCategory.objects.create(
            key="essential", label="Strictement nécessaires",
            is_essential=True, display_order=1, **commun,
        )
        self.mesure = CookieCategory.objects.create(
            key="analytics", label="Mesure d'audience",
            is_essential=False, display_order=2, **commun,
        )
        self.url = reverse("jeiko_cookies:consent_persist")

    def enregistrer(self, choix, **extra):
        charge = {"choices": choix}
        charge.update(extra)
        return self.client.post(
            self.url, data=json.dumps(charge), content_type="application/json"
        )


class PreuveDeConsentementTests(ConsentementFixture):
    def test_un_choix_est_enregistre(self):
        reponse = self.enregistrer({"analytics": True})
        self.assertEqual(reponse.status_code, 200)
        self.assertEqual(CookieConsent.objects.count(), 1)

    def test_le_refus_est_enregistre_aussi(self):
        """Refuser est un consentement à prouver autant qu'accepter."""
        self.enregistrer({"analytics": False})
        preuve = CookieConsent.objects.get()
        self.assertFalse(preuve.choices.get("analytics"))

    def test_une_categorie_essentielle_reste_vraie_meme_si_refusee(self):
        self.enregistrer({"essential": False, "analytics": False})
        preuve = CookieConsent.objects.get()
        self.assertTrue(
            preuve.choices.get("essential"),
            "Une catégorie strictement nécessaire ne se refuse pas.",
        )

    def test_la_version_de_politique_est_conservee(self):
        self.enregistrer({"analytics": True})
        self.assertTrue(CookieConsent.objects.get().policy_version)

    def test_l_ip_est_tronquee(self):
        """Conserver l'IP entière serait disproportionné pour une preuve."""
        self.enregistrer({"analytics": True})
        preuve = CookieConsent.objects.get()
        if preuve.ip_truncated:
            self.assertNotEqual(preuve.ip_truncated, "127.0.0.1")

    def test_un_jeton_public_est_remis(self):
        reponse = self.enregistrer({"analytics": True})
        self.assertTrue(json.loads(reponse.content)["consent_token"])

    def test_un_cookie_est_depose(self):
        reponse = self.enregistrer({"analytics": True})
        self.assertTrue(reponse.cookies, "Aucun cookie : le choix sera reperdu.")

    def test_un_seul_consentement_courant_par_visiteur(self):
        """`is_latest` doit désigner exactement un enregistrement."""
        self.enregistrer({"analytics": True})
        self.enregistrer({"analytics": False})
        self.assertEqual(CookieConsent.objects.filter(is_latest=True).count(), 1)
        self.assertEqual(CookieConsent.objects.count(), 2)

    def test_le_dernier_choix_fait_foi(self):
        self.enregistrer({"analytics": True})
        self.enregistrer({"analytics": False})
        courant = CookieConsent.objects.get(is_latest=True)
        self.assertFalse(courant.choices.get("analytics"))


class EntreeInvalideTests(ConsentementFixture):
    def test_un_corps_illisible_est_refuse_proprement(self):
        reponse = self.client.post(
            self.url, data="ceci n'est pas du json",
            content_type="application/json",
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertEqual(CookieConsent.objects.count(), 0)

    def test_une_categorie_inconnue_est_ignoree(self):
        self.enregistrer({"categorie_qui_nexiste_pas": True})
        preuve = CookieConsent.objects.get()
        self.assertNotIn("categorie_qui_nexiste_pas", preuve.choices)


class GardeFouTests(ConsentementFixture):
    def test_l_ecriture_publique_est_plafonnee(self):
        """
        Sans plafond, ce point d'entrée fait grossir deux tables depuis
        l'extérieur : les preuves, et les sessions anonymes qu'il force.
        """
        codes = {self.enregistrer({"analytics": True}).status_code
                 for _ in range(80)}
        self.assertIn(429, codes)

    def test_un_usage_normal_n_est_pas_gene(self):
        """Un visiteur qui hésite fait quelques appels, pas des centaines."""
        for _ in range(5):
            self.assertEqual(self.enregistrer({"analytics": True}).status_code, 200)


class StatutEtBanniereTests(ConsentementFixture):
    def test_le_statut_est_consultable(self):
        reponse = self.client.get(reverse("jeiko_cookies:consent_status"))
        self.assertEqual(reponse.status_code, 200)

    def test_le_statut_reflete_le_choix(self):
        self.enregistrer({"analytics": True})
        donnees = json.loads(
            self.client.get(reverse("jeiko_cookies:consent_status")).content
        )
        self.assertIn("choices", donnees)

    def test_la_configuration_de_banniere_est_servie(self):
        reponse = self.client.get(reverse("jeiko_cookies:banner_config"))
        self.assertEqual(reponse.status_code, 200)
