from django.core.validators import MinValueValidator, MaxValueValidator

import logging
from io import BytesIO
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
import os
from PIL import Image
from django.db import models
from jeiko.encrypted import EncryptedCharField
from jeiko.uploads import valider_l_image
from django.core.exceptions import ValidationError
from django.core.validators import URLValidator

from jeiko.administration_pages.models import Page


from django.utils import timezone

logger = logging.getLogger(__name__)


class Font(models.Model):
    size = models.CharField(
        default="20px",
        max_length=20,
        verbose_name="Taille de la police",
        help_text="Ex: 18px, 1.2em, etc."
    )
    family = models.CharField(
        default="Georgia",
        max_length=100,
        verbose_name="Famille de police",
        help_text="Ex: Roboto, Playfair Display, Arial, etc."
    )
    fallback = models.CharField(
        default="serif",
        max_length=100,
        verbose_name="Police de secours",
        help_text="Ex: serif, sans-serif, monospace, Arial… (sera utilisée si la police principale n’est pas chargée)"
    )
    stretch = models.CharField(
        default="100%",
        max_length=100,
        verbose_name="Étirement",
        help_text="Ex: 100%, condensed, expanded (optionnel)"
    )
    color = models.CharField(
        default="rgba(0,0,0,1)",
        max_length=30,
        verbose_name="Couleur de la police",
        help_text="Ex: #333, rgba(0,0,0,1)"
    )
    POLICE_STYLE_CHOICES = [
        ("normal", "normal"),
        ("italic", "italic"),
        ("oblique", "oblique"),
    ]
    style = models.CharField(
        default="normal",
        max_length=10,
        choices=POLICE_STYLE_CHOICES,
        verbose_name="Style"
    )
    variant = models.CharField(
        default="normal",
        max_length=20,
        verbose_name="Variante",
        help_text="Ex: small-caps, normal"
    )
    weight = models.CharField(
        default="normal",
        max_length=50,
        verbose_name="Épaisseur de la police",
        help_text="Ex: normal, bold, 700"
    )
    line_height = models.CharField(
        default="normal",
        max_length=50,
        verbose_name="Hauteur de ligne",
        help_text="Ex: 1.2, normal, 32px"
    )
    google_fonts_url = models.URLField(
        blank=True,
        null=True,
        verbose_name="URL Google Fonts",
        help_text="Optionnel : colle ici l’URL Google Fonts si besoin (sinon sera générée automatiquement)."
    )

    def __str__(self):
        return f"{self.family} ({self.size})"

    class Meta:
        verbose_name = "Police"
        verbose_name_plural = "Polices"


class Fonts(models.Model):

    links = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="links"
    )

    links_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="links_hover"
    )
    menu = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="menu"
    )

    menu_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="menu_hover"
    )

    sub_menu = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="sub_menu"
    )

    sub_menu_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="sub_menu_hover"
    )

    text = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="text"
    )

    h1 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h1"
    )

    h2 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h2"
    )

    h3 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h3"
    )

    h4 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h4"
    )

    h5 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h5"
    )

    h6 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h6"
    )


class Logo(models.Model):
    # S-10 — seul `full_size` est téléversé ; les trois variantes ci-dessous
    # sont fabriquées par `save()` en redimensionnant celle-ci.
    full_size = models.ImageField(upload_to="images/logo", null=True, blank=True,
                                  validators=[valider_l_image], verbose_name="Logo")
    computer_size = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name="Logo")
    tablet_size   = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name="Logo")
    mobile_size   = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name="Logo")

    #: Logo réservé aux e-mails. Facultatif : sa PRÉSENCE vaut activation.
    #:
    #: Deux raisons de le vouloir distinct du logo du site.
    #:
    #: *Technique.* Les variantes générées pour le site sont en WebP, format
    #: que plusieurs clients de messagerie — Outlook pour Windows au premier
    #: rang — ne savent pas afficher. Un logo destiné aux e-mails doit être en
    #: PNG ou JPEG pour arriver chez tout le monde.
    #:
    #: *Éditoriale.* Un logo lisible sur un site à fond clair peut disparaître
    #: dans un e-mail, dont le fond varie avec le client et le thème sombre.
    #:
    #: Pas de case « activer » associée : un booléen coché sans image, ou une
    #: image sans le booléen, sont deux états incohérents qu'il faudrait
    #: expliquer. Ici, déposer une image l'active, la retirer revient au logo
    #: du site.
    mail_logo = models.ImageField(
        upload_to="images/logo/mail", null=True, blank=True,
        validators=[valider_l_image],
        verbose_name="Logo pour les e-mails",
        help_text=(
            "Facultatif. S'il est renseigné, il remplace le logo du site dans "
            "tous les e-mails. À fournir en PNG ou JPEG : le format WebP n'est "
            "pas affiché par plusieurs messageries, dont Outlook. Largeur "
            "conseillée : 300 à 600 pixels."
        ),
    )

    updated_at = models.DateTimeField(auto_now=True)

    def email_image(self):
        """
        L'image à utiliser dans un e-mail, ou None.

        Ordre délibéré : le logo dédié d'abord, puis l'original téléversé, et
        seulement en dernier recours les variantes générées — celles-ci sont en
        WebP, que toutes les messageries ne rendent pas.

        `_logo_url` prenait auparavant `computer_size` en premier : tous les
        e-mails partaient donc avec un logo WebP, invisible chez une partie des
        destinataires.
        """
        for champ in ("mail_logo", "full_size", "computer_size",
                      "tablet_size", "mobile_size"):
            image = getattr(self, champ, None)
            if image and getattr(image, "name", ""):
                return image
        return None

    # ---------- helpers ----------
    def _variant_name(self, base_name: str, suffix: str) -> str:
        # base_name = self.full_size.name (chemin relatif au storage)
        name_no_ext, _ = os.path.splitext(base_name)  # ex: images/logo/monfichier
        return f"{name_no_ext}-{suffix}.webp"          # ex: images/logo/monfichier-computer.webp

    def _save_webp(self, img: Image.Image, size: tuple[int, int], target_name: str) -> str:
        # préserver l’alpha
        if img.mode not in ("RGBA", "LA"):
            img = img.convert("RGBA")
        # copier l’original avant thumbnail (pour éviter cascade de thumbnails)
        variant = img.copy()
        variant.thumbnail(size, Image.LANCZOS)

        buf = BytesIO()
        # WebP supporte la transparence ; ajuste quality/method si besoin
        variant.save(buf, format="WEBP", quality=85, method=6)
        buf.seek(0)

        # Écrire via le storage (portable: local, S3…)
        if default_storage.exists(target_name):
            default_storage.delete(target_name)
        default_storage.save(target_name, ContentFile(buf.read()))
        return target_name  # chemin relatif (à assigner à .name)

    # ---------- save ----------
    def save(self, *args, **kwargs):
        # 1) sauvegarder d’abord pour garantir full_size.path/.name
        super().save(*args, **kwargs)

        # 2) régénérer les variantes si on a un original
        if self.full_size and self.full_size.name:
            base_name = self.full_size.name   # chemin relatif, ex: images/logo/monfichier.png
            base_img  = Image.open(self.full_size.path)

            computer_name = self._variant_name(base_name, "computer")
            tablet_name   = self._variant_name(base_name, "tablet")
            mobile_name   = self._variant_name(base_name, "mobile")

            comp_rel = self._save_webp(base_img, (150, 150), computer_name)
            tab_rel  = self._save_webp(base_img, (100, 100), tablet_name)
            mob_rel  = self._save_webp(base_img, (75, 75),  mobile_name)

            # 3) assigner .name (PAS .url)
            self.computer_size.name = comp_rel
            self.tablet_size.name   = tab_rel
            self.mobile_size.name   = mob_rel

            # 4) sauver uniquement les champs modifiés (updated_at bouge aussi)
            super().save(update_fields=["computer_size", "tablet_size", "mobile_size", "updated_at"])


class Favicon(models.Model):
    """Favicon du site : une image carrée uploadée, déclinée en PNG 32×32
    (onglet) et 180×180 (apple-touch-icon). PNG et non WebP : compat maximale
    des onglets/navigateurs et d'iOS. Même logique de génération que Logo."""
    source = models.ImageField(
        upload_to="images/favicon", null=True, blank=True,
        validators=[valider_l_image],
        verbose_name="Favicon (image carrée, PNG conseillé)",
        help_text="Idéalement une image carrée d'au moins 180×180 px.",
    )
    png_32 = models.ImageField(upload_to="images/favicon", null=True, blank=True, editable=False)
    png_180 = models.ImageField(upload_to="images/favicon", null=True, blank=True, editable=False)

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Favicon"
        verbose_name_plural = "Favicons"

    def _variant_name(self, base_name: str, suffix: str) -> str:
        name_no_ext, _ = os.path.splitext(base_name)
        return f"{name_no_ext}-{suffix}.png"

    def _save_png(self, img: Image.Image, size: int, target_name: str) -> str:
        if img.mode not in ("RGBA", "LA"):
            img = img.convert("RGBA")
        variant = img.copy()
        variant.thumbnail((size, size), Image.LANCZOS)
        buf = BytesIO()
        variant.save(buf, format="PNG")
        buf.seek(0)
        if default_storage.exists(target_name):
            default_storage.delete(target_name)
        default_storage.save(target_name, ContentFile(buf.read()))
        return target_name

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if self.source and self.source.name:
            base_name = self.source.name
            base_img = Image.open(self.source.path)
            self.png_32.name = self._save_png(base_img, 32, self._variant_name(base_name, "32"))
            self.png_180.name = self._save_png(base_img, 180, self._variant_name(base_name, "180"))
            super().save(update_fields=["png_32", "png_180", "updated_at"])


class MailSettings(models.Model):
    # Utilisation d’un singleton, une seule config par site
    host = models.CharField(max_length=200, verbose_name="Serveur SMTP")
    port = models.PositiveIntegerField(
        default=587, validators=[MinValueValidator(1), MaxValueValidator(65535)],
        verbose_name="Port SMTP"
    )
    use_tls = models.BooleanField(default=True, verbose_name="Utiliser TLS")
    use_ssl = models.BooleanField(default=False, verbose_name="Utiliser SSL")
    host_user = models.CharField(max_length=200, blank=True, verbose_name="Nom d’utilisateur SMTP")
    # Chiffré au repos : ce mot de passe permet d'envoyer du courrier signé
    # du domaine du site.
    host_password = EncryptedCharField(max_length=200, blank=True, verbose_name="Mot de passe SMTP")
    default_from_email = models.CharField(max_length=200, blank=True, verbose_name="Adresse expéditeur par défaut")
    reply_to_email = models.CharField(max_length=200, blank=True, verbose_name="Adresse reply-to (optionnelle)")
    active = models.BooleanField(default=True, verbose_name="Actif")
    test_receiver = models.CharField(max_length=200, blank=True, verbose_name="Email de test (pour bouton 'Tester')")

    class Meta:
        verbose_name = "Configuration Email"
        verbose_name_plural = "Configuration Email"

    def __str__(self):
        return f"Mail SMTP ({self.host}:{self.port}) pour {self.website.name}"


class WebSite(models.Model):

    name = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        default="Jeiko",
    )
    fonts_phone = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_phone',
        null=True
    )

    fonts_tablet = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_tablet',
        null=True
    )

    fonts_computer = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_computer',
        null=True
    )

    logo = models.OneToOneField(
        Logo,
        on_delete=models.CASCADE,
        related_name='site',
        null=True,
    )

    favicon = models.OneToOneField(
        Favicon,
        on_delete=models.SET_NULL,
        related_name='site_favicon',
        null=True,
        blank=True,
    )

    mail_settings = models.OneToOneField(
        "MailSettings",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name="website",
        verbose_name="Configuration Email"
    )

    assets_version = models.IntegerField(
        default=1
    )

    # ------------------------------------------------------------------ #
    # Disponibilité d'une mise à jour de JEIKO.
    #
    # Renseigné une fois par jour par le job `cron_24h` (cf.
    # `administration/update_check.py`), qui lit le `version.json` du canal de
    # publication et le compare à la version installée.
    #
    # Ces trois champs vivent sur `WebSite` — et non dans le cache — pour deux
    # raisons : le résultat doit survivre à un redémarrage (un badge qui
    # disparaît au hasard est pire que pas de badge), et `WebSite` est déjà
    # chargé et mis en cache à chaque rendu (`website_cache.get_website_data`),
    # donc afficher le badge ne coûte aucune requête supplémentaire.
    # ------------------------------------------------------------------ #
    update_available_version = models.CharField(
        max_length=32,
        blank=True,
        default="",
        help_text="Version publiée sur le canal, si elle est plus récente que celle installée.",
    )
    update_last_checked_at = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Dernière interrogation réussie ou non du canal de publication.",
    )
    update_check_error = models.CharField(
        max_length=255,
        blank=True,
        default="",
        help_text="Raison du dernier échec de vérification. Vide si la dernière a abouti.",
    )


class SiteIdentity(models.Model):
    TYPE_ORG = "organization"
    TYPE_LOCAL = "localbusiness"
    TYPE_CHOICES = [
        (TYPE_ORG, "Organization"),
        (TYPE_LOCAL, "LocalBusiness"),
    ]

    website = models.OneToOneField("administration.WebSite", on_delete=models.CASCADE, related_name="identity")
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, default=TYPE_ORG)

    # Commun (recommandé / utile)
    name = models.CharField(max_length=200)                 # Required si LocalBusiness, recommandé si Organization
    url = models.URLField(blank=True)                       # Recommandé
    telephone = models.CharField(max_length=50, blank=True) # Recommandé

    # Adresse (obligatoire si LocalBusiness)
    street_address = models.CharField(max_length=255, blank=True)
    address_locality = models.CharField(max_length=120, blank=True)
    address_region = models.CharField(max_length=120, blank=True)
    postal_code = models.CharField(max_length=20, blank=True)
    address_country = models.CharField(max_length=2, blank=True)  # ISO-3166-1 alpha-2 (FR, CH, etc.)

    # Extras utiles (facultatifs)
    geo_lat = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    geo_lng = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    price_range = models.CharField(max_length=10, blank=True)     # ex: €, €€, €€€

    created_at = models.DateTimeField(default=timezone.now, editable=False)
    updated_at = models.DateTimeField(auto_now=True)


    class Meta:
        verbose_name = "Identité du site"
        verbose_name_plural = "Identités du site"

    def clean(self):
        if self.type == self.TYPE_LOCAL:
            missing = [f for f in ["name","street_address","address_locality","postal_code","address_country"] if not getattr(self, f)]
            if missing:
                raise ValidationError(
                    "LocalBusiness nécessite name + adresse complète (street/locality/postal_code/country)."
                )

    def __str__(self):
        return f"{self.get_type_display()} — {self.name or 'sans nom'}"


class GoogleApi(models.Model):
    """
    Réglages globaux pour les APIs Google (clé PSI, Search Console...).
    On ne garde qu'une seule configuration.
    """
    name = models.CharField(
        max_length=100,
        default="Default"
    )
    psi_api_key = models.CharField(
        "PageSpeed Insights API key",
        max_length=300,
        blank=True,
        default="",
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Configuration Google API"
        verbose_name_plural = "Configuration Google API"

    def __str__(self):
        return self.name

    @classmethod
    def get_solo(cls):
        obj, _ = cls.objects.get_or_create(pk=1, defaults={"name": "Default"})
        return obj



class Legals(models.Model):
    """
    Un jeu de pages légales par site.
    Les FK sont PROTECT pour empêcher la suppression d'une Page liée.
    """
    site = models.OneToOneField(
        WebSite,
        on_delete=models.CASCADE,
        related_name="legals",
        verbose_name="Site",
    )

    privacy_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_privacy_page_for",
        verbose_name="Page RGPD/Privacy",

    )
    cgv_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_cgv_page_for",
        verbose_name="Page CGV",
    )
    cgu_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_cgu_page_for",
        verbose_name="Page CGU",
    )
    mentions_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_mentions_page_for",
        verbose_name="Page Mentions légales",
    )

    class Meta:
        verbose_name = "Pages légales"
        verbose_name_plural = "Pages légales"
        ordering = ["site__name"]

    def __str__(self):
        return f"Pages légales — {self.site.name}"


    @property
    def all_links(self):
        return {
            "privacy": getattr(self.privacy_page, "get_absolute_url", lambda: None)(),
            "cgv": getattr(self.cgv_page, "get_absolute_url", lambda: None)(),
            "cgu": getattr(self.cgu_page, "get_absolute_url", lambda: None)(),
            "mentions": getattr(self.mentions_page, "get_absolute_url", lambda: None)(),
        }


PLATFORM_CHOICES = [
    # Social “généraux”
    ("facebook", "Facebook"),
    ("instagram", "Instagram"),
    ("x", "X (Twitter)"),
    ("threads", "Threads"),
    ("bluesky", "Bluesky"),
    ("tiktok", "TikTok"),
    ("snapchat", "Snapchat"),
    ("pinterest", "Pinterest"),
    ("linkedin", "LinkedIn"),
    ("youtube", "YouTube"),
    ("vimeo", "Vimeo"),
    ("reddit", "Reddit"),
    ("tumblr", "Tumblr"),
    ("mastodon", "Mastodon"),
    # Messageries / communautés
    ("whatsapp", "WhatsApp"),
    ("telegram", "Telegram"),
    ("signal", "Signal"),
    ("messenger", "Facebook Messenger"),
    ("discord", "Discord"),
    ("slack", "Slack"),
    # Créateurs / portfolio
    ("dribbble", "Dribbble"),
    ("behance", "Behance"),
    ("medium", "Medium"),
    ("substack", "Substack"),
    # Dev / produit
    ("github", "GitHub"),
    ("gitlab", "GitLab"),
    ("bitbucket", "Bitbucket"),
    ("producthunt", "Product Hunt"),
    ("wellfound", "Wellfound (AngelList)"),
    # Musique / audio
    ("spotify", "Spotify"),
    ("applemusic", "Apple Music"),
    ("deezer", "Deezer"),
    ("soundcloud", "SoundCloud"),
    ("twitch", "Twitch"),
    # Avis / annuaires
    ("googlebusiness", "Google Business Profile"),
    ("tripadvisor", "Tripadvisor"),
    ("yelp", "Yelp"),
    ("trustpilot", "Trustpilot"),
    ("glassdoor", "Glassdoor"),
    ("indeed", "Indeed"),
    ("houzz", "Houzz"),
    # E-commerce / marketplaces
    ("etsy", "Etsy"),
    ("amazon", "Amazon Store"),
    # Réseaux FR / divers
    ("viadeo", "Viadeo"),
    ("vk", "VK"),
    # Liens utilitaires
    ("email", "E-mail"),
    ("phone", "Téléphone"),
    ("website", "Site (autre)"),
    # Personnalisé
    ("custom", "Personnalisé"),
]


class SocialLink(models.Model):
    """
    Un lien social associé à un site (WebSite).
    Icônes 100% locales :
      - par défaut : SVG livré en static (jeiko/icons/social/<platform>.svg)
      - override possible : upload raster -> génération WebP 48/32/24
      - override possible : upload SVG custom (utilisé tel quel)
    """
    website = models.ForeignKey("administration.WebSite", on_delete=models.CASCADE, related_name="social_links")
    platform = models.CharField(max_length=32, choices=PLATFORM_CHOICES, default="instagram")
    profile_url = models.URLField(validators=[URLValidator()], blank=True, default="")
    handle = models.CharField(max_length=120, blank=True, default="")  # @pseudo, si utile à l'affichage
    display_name = models.CharField(max_length=120, blank=True, default="")  # texte alternatif à montrer
    position = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    aria_label = models.CharField(max_length=140, blank=True, default="")  # pour accessibilité

    # --- Overrides d’icône (OPTIONNELS) ---
    # 1) SVG custom (recommandé pour teinter via CSS currentColor)
    icon_svg = models.FileField(upload_to="images/social/svg", null=True, blank=True)

    # 2) Raster custom → on génère 3 variantes WebP 48/32/24 (fond transparent conservé)
    icon_raster_source = models.ImageField(upload_to="images/social/src", null=True, blank=True,
                                           validators=[valider_l_image])
    icon_48 = models.ImageField(upload_to="images/social/variants", null=True, blank=True, editable=False)
    icon_32 = models.ImageField(upload_to="images/social/variants", null=True, blank=True, editable=False)
    icon_24 = models.ImageField(upload_to="images/social/variants", null=True, blank=True, editable=False)

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["position", "id"]
        verbose_name = "Lien social"
        verbose_name_plural = "Liens sociaux"
        constraints = [
            models.UniqueConstraint(fields=["website", "platform", "profile_url"], name="uniq_social_per_site_and_url"),
        ]

    def __str__(self):
        base = self.get_platform_display()
        return f"{base} — {self.display_name or self.handle or self.profile_url or 'sans URL'}"

    # ---------- helpers generation ----------
    def _variant_name(self, base_name: str, suffix: str) -> str:
        name_no_ext, _ = os.path.splitext(base_name)   # ex: images/social/src/monfichier
        return f"{name_no_ext}-{suffix}.webp"          # ex: images/social/src/monfichier-48.webp

    def _save_webp(self, img: Image.Image, size: int, target_name: str) -> str:
        if img.mode not in ("RGBA", "LA"):
            img = img.convert("RGBA")
        variant = img.copy()
        variant.thumbnail((size, size), Image.LANCZOS)

        buf = BytesIO()
        variant.save(buf, format="WEBP", quality=85, method=6)
        buf.seek(0)

        if default_storage.exists(target_name):
            default_storage.delete(target_name)
        default_storage.save(target_name, ContentFile(buf.read()))
        return target_name

    def save(self, *args, **kwargs):
        # 1) sauvegarder d’abord pour garantir .path/.name
        super().save(*args, **kwargs)

        # 1 bis) assainir le SVG déposé.
        #
        # Un SVG est un document XML : il peut porter un script, un attribut
        # `on*` ou un lien `javascript:`, et il est servi depuis /media/ — donc
        # sur l'origine du site. Aucun écran n'alimente ce champ aujourd'hui
        # (SocialLink n'a ni formulaire ni entrée d'administration), mais le
        # jour où l'un existera, le nettoyage sera déjà en place.
        self._sanitize_svg()

        # 2) si on a une source raster, (re)générer les variantes
        if self.icon_raster_source and self.icon_raster_source.name:
            base_name = self.icon_raster_source.name
            try:
                base_img = Image.open(self.icon_raster_source.path)
            except Exception:
                return  # si format non supporté par PIL

            name_48 = self._variant_name(base_name, "48")
            name_32 = self._variant_name(base_name, "32")
            name_24 = self._variant_name(base_name, "24")

            rel_48 = self._save_webp(base_img, 48, name_48)
            rel_32 = self._save_webp(base_img, 32, name_32)
            rel_24 = self._save_webp(base_img, 24, name_24)

            # assigner .name (PAS .url)
            self.icon_48.name = rel_48
            self.icon_32.name = rel_32
            self.icon_24.name = rel_24

            super().save(update_fields=["icon_48", "icon_32", "icon_24", "updated_at"])

    # ---------- accès icône ----------
    def _sanitize_svg(self):
        """
        Réécrit le SVG déposé, débarrassé de ce qui peut s'exécuter.

        Best-effort : un fichier illisible est laissé tel quel plutôt que de
        faire échouer l'enregistrement du lien.
        """
        if not (self.icon_svg and self.icon_svg.name):
            return

        from jeiko.sanitize import clean_svg

        try:
            self.icon_svg.open("rb")
            brut = self.icon_svg.read()
        except Exception:
            return
        finally:
            try:
                self.icon_svg.close()
            except Exception:
                pass

        propre = clean_svg(brut).encode("utf-8")
        if propre == brut:
            return

        try:
            self.icon_svg.storage.delete(self.icon_svg.name)
            self.icon_svg.storage.save(self.icon_svg.name, ContentFile(propre))
        except Exception:
            logger.exception(
                "Assainissement du SVG impossible pour le lien social #%s", self.pk
            )

    def get_icon_static_path(self) -> str:
        """
        Fallback local → chemin static attendu pour l’icône SVG par défaut.
        À placer dans: static/jeiko/icons/social/<platform>.svg
        """
        return f"jeiko/icons/social/{self.platform}.svg"

    def has_svg(self) -> bool:
        return bool(self.icon_svg)

    def has_raster_variants(self) -> bool:
        return bool(self.icon_24 and self.icon_24.name and self.icon_32 and self.icon_48)

    def get_best_icon(self, size: int = 24):
        """
        Retourne un tuple (type, url) où type ∈ {'svg','img'}
          - 'svg' => chemin static (ou override SVG)
          - 'img' => URL d’une variante raster (webp)
        size ∈ {24, 32, 48}
        """
        # 1) SVG custom prioritaire
        if self.icon_svg and hasattr(self.icon_svg, "url"):
            return ("svg", self.icon_svg.url)

        # 2) Variantes raster custom
        if self.has_raster_variants():
            if size <= 24 and self.icon_24 and self.icon_24.url:
                return ("img", self.icon_24.url)
            if size <= 32 and self.icon_32 and self.icon_32.url:
                return ("img", self.icon_32.url)
            return ("img", self.icon_48.url)

        # 3) SVG par défaut en static
        # (la template utilisera {% static path %})
        return ("svg", self.get_icon_static_path())


class SocialProvider(models.Model):
    """
    Configuration back-office d'un fournisseur de connexion sociale (allauth).

    Source de vérité unique : les clés sont saisies ici depuis `admin/`,
    puis synchronisées vers le `SocialApp` d'allauth (`sync_to_allauth`).

    Activation / désactivation = rattachement / détachement du `SocialApp`
    au `Site` courant. allauth (`SocialApp.objects.on_site`) n'affiche les
    boutons que pour les apps rattachées au site, donc un provider désactivé
    (ou sans identifiants) disparaît automatiquement de la page de connexion.

    Correspondance des champs allauth (SocialApp) :
        - Google / Facebook : client_id = Client ID, secret = Client Secret
        - Apple             : client_id = Services ID, secret = Key ID,
                              key = Team ID, settings["certificate_key"] = .p8
    """

    PROVIDER_GOOGLE = "google"
    PROVIDER_APPLE = "apple"
    PROVIDER_FACEBOOK = "facebook"
    PROVIDER_CHOICES = [
        (PROVIDER_GOOGLE, "Google"),
        (PROVIDER_APPLE, "Apple"),
        (PROVIDER_FACEBOOK, "Facebook"),
    ]

    provider = models.CharField(
        max_length=32,
        choices=PROVIDER_CHOICES,
        unique=True,
        verbose_name="Fournisseur",
    )
    enabled = models.BooleanField(
        default=False,
        verbose_name="Activé",
        help_text="Affiche (ou masque) le bouton de connexion correspondant.",
    )

    client_id = models.CharField(
        max_length=300,
        blank=True,
        default="",
        verbose_name="Client ID",
        help_text="Google/Facebook : Client ID. Apple : Services ID.",
    )
    secret = models.CharField(
        max_length=500,
        blank=True,
        default="",
        verbose_name="Client Secret",
        help_text="Google/Facebook : Client Secret. Apple : Key ID.",
    )
    key = models.CharField(
        max_length=191,
        blank=True,
        default="",
        verbose_name="Clé / Team ID",
        help_text="Inutile pour Google/Facebook. Apple : Team ID.",
    )
    certificate_key = models.TextField(
        blank=True,
        default="",
        verbose_name="Clé privée (.p8)",
        help_text="Apple uniquement : contenu du fichier .p8 (clé privée).",
    )

    position = models.PositiveIntegerField(default=0)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["position", "provider"]
        verbose_name = "Connexion sociale"
        verbose_name_plural = "Connexions sociales"

    def __str__(self):
        return f"{self.get_provider_display()} ({'activé' if self.enabled else 'désactivé'})"

    # ------------------------------------------------------------------ #
    # Validité des identifiants
    # ------------------------------------------------------------------ #
    @property
    def has_credentials(self) -> bool:
        """Identifiants minimum requis selon le fournisseur."""
        if not self.client_id:
            return False
        if self.provider == self.PROVIDER_APPLE:
            return bool(self.secret and self.key and self.certificate_key)
        return bool(self.secret)

    @property
    def is_live(self) -> bool:
        """Réellement exposé sur la page de connexion."""
        return self.enabled and self.has_credentials

    # ------------------------------------------------------------------ #
    # Synchronisation vers allauth
    # ------------------------------------------------------------------ #
    def sync_to_allauth(self):
        """
        Crée / met à jour le SocialApp allauth et gère le rattachement au
        Site courant (= activation/désactivation effective).
        """
        from django.conf import settings as dj_settings
        from django.contrib.sites.models import Site
        from allauth.socialaccount.models import SocialApp

        app = (
            SocialApp.objects.filter(provider=self.provider).first()
            or SocialApp(provider=self.provider)
        )
        app.name = self.get_provider_display()
        app.client_id = self.client_id
        app.secret = self.secret
        app.key = self.key

        app_settings = dict(app.settings or {})
        if self.provider == self.PROVIDER_APPLE:
            app_settings["certificate_key"] = self.certificate_key
        else:
            app_settings.pop("certificate_key", None)
        app.settings = app_settings
        app.save()

        site = Site.objects.filter(pk=dj_settings.SITE_ID).first()
        if site is not None:
            if self.is_live:
                app.sites.add(site)
            else:
                app.sites.remove(site)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        self.sync_to_allauth()

    @classmethod
    def all_providers(cls):
        """Retourne les 3 configs (créées si besoin), dans l'ordre d'affichage."""
        order = {p: i for i, (p, _) in enumerate(cls.PROVIDER_CHOICES)}
        for i, (code, _) in enumerate(cls.PROVIDER_CHOICES):
            cls.objects.get_or_create(provider=code, defaults={"position": i})
        return sorted(cls.objects.all(), key=lambda o: order.get(o.provider, 99))