# jeiko/agents/tests.py
"""
L'API des agents ouvre le site à des programmes. Ces tests gardent la porte.

Ce qu'ils verrouillent, par ordre d'importance
----------------------------------------------
**Une seule façon d'entrer.** Le test le plus important du fichier est
`test_une_session_de_navigateur_n_authentifie_pas` : si l'API acceptait un jour
la session en plus du jeton, elle deviendrait manipulable depuis le navigateur
d'un administrateur connecté — une page piégée lui ferait modifier son propre
site. C'est aussi ce qui rend l'exemption CSRF de ces vues légitime ; le jour
où ce test tombe, l'exemption devient un trou.

**Les refus ne renseignent pas.** Jeton inconnu, agent expiré, IP refusée :
même message, même code. Distinguer les cas apprendrait à un appelant hostile
où il en est.

**Les droits passent par les rôles.** Un agent authentifié n'est pas un agent
autorisé. Un agent sans rôle ne doit rien pouvoir faire.

**La page ne se supprime pas.** Deux barrières, testées séparément : aucune
route, et aucune permission dans le rôle.
"""

import json

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.test import TestCase, override_settings
from django.utils import timezone

from jeiko.administration_pages.models import Page
from jeiko.agents import jetons
from jeiko.agents.models import Agent, AgentToken, AppelAgent
from jeiko.agents.services import creer_agent, reinitialiser_le_jeton
from jeiko.users.models import Role, RoleAssignment, RolePermission
from jeiko.users.testing import creer_compte_verifie

User = get_user_model()

QUI_SUIS_JE = "/api/agent/v1/qui-suis-je/"
PAGES = "/api/agent/v1/pages/"

#: Le message unique de refus. Le figer ici, c'est refuser qu'on le rende
#: « plus utile » un jour en y mettant la raison.
REFUS = "Authentification requise ou refusée."


def donner_le_role(user, *codenames, app="administration_pages", nom="Rôle de test"):
    role = Role.objects.create(name=nom, slug=nom.lower().replace(" ", "-"))
    for code in codenames:
        RolePermission.objects.create(
            role=role,
            permission=Permission.objects.get(
                codename=code, content_type__app_label=app
            ),
        )
    RoleAssignment.objects.create(user=user, role=role)
    return role


class SocleMixin:
    def creer(self, **kwargs):
        agent, jeton = creer_agent(nom=kwargs.pop("nom", "Agent"), **kwargs)
        return agent, jeton

    def entetes(self, jeton):
        return {"HTTP_AUTHORIZATION": f"Bearer {jeton}"}

    def json_post(self, url, corps, jeton):
        return self.client.post(
            url,
            data=json.dumps(corps),
            content_type="application/json",
            **self.entetes(jeton),
        )


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class AuthentificationTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()

    # ---------------------------------------------------------------- #
    #  La seule façon d'entrer
    # ---------------------------------------------------------------- #
    def test_sans_jeton(self):
        reponse = self.client.get(QUI_SUIS_JE)
        self.assertEqual(reponse.status_code, 401)
        self.assertEqual(reponse.json()["erreur"], REFUS)

    def test_avec_un_jeton_valide(self):
        reponse = self.client.get(QUI_SUIS_JE, **self.entetes(self.jeton))
        self.assertEqual(reponse.status_code, 200)
        self.assertEqual(reponse.json()["agent"]["nom"], "Agent")

    def test_une_session_de_navigateur_n_authentifie_pas(self):
        """
        LE test à ne jamais laisser tomber.

        Un administrateur connecté, sans jeton, doit être refusé exactement
        comme un inconnu. Si ce n'était pas le cas, une page piégée ouverte
        dans son navigateur pourrait piloter l'API en son nom — et l'exemption
        CSRF de ces vues, qui est aujourd'hui sûre, deviendrait une faille.
        """
        chef = creer_compte_verifie("chef", "chef@example.test", "pw",
                                    is_staff=True, is_superuser=True)
        self.client.force_login(chef)

        reponse = self.client.get(QUI_SUIS_JE)
        self.assertEqual(reponse.status_code, 401)

        # ... et le passage d'un jeton valide ne doit pas non plus faire
        # travailler l'API au nom du superutilisateur connecté.
        reponse = self.client.get(QUI_SUIS_JE, **self.entetes(self.jeton))
        self.assertEqual(reponse.json()["agent"]["nom"], "Agent")
        self.assertEqual(reponse.json()["permissions"], [])

    def test_le_jeton_dans_l_adresse_ne_marche_pas(self):
        """Une URL part dans les journaux, les référents et l'historique."""
        reponse = self.client.get(f"{QUI_SUIS_JE}?token={self.jeton}")
        self.assertEqual(reponse.status_code, 401)

    def test_entete_mal_formee(self):
        for entete in ("", "Bearer", "Basic abc", f"Token {self.jeton}", "Bearer  "):
            with self.subTest(entete=entete):
                reponse = self.client.get(QUI_SUIS_JE, HTTP_AUTHORIZATION=entete)
                self.assertEqual(reponse.status_code, 401)

    # ---------------------------------------------------------------- #
    #  Les états qui ferment la porte
    # ---------------------------------------------------------------- #
    def test_jeton_inconnu(self):
        _, _, faux = jetons.fabriquer()
        self.assertEqual(self.client.get(QUI_SUIS_JE, **self.entetes(faux)).status_code, 401)

    def test_jeton_revoque(self):
        self.agent.jetons.first().revoquer()
        self.assertEqual(
            self.client.get(QUI_SUIS_JE, **self.entetes(self.jeton)).status_code, 401
        )

    def test_agent_desactive(self):
        self.agent.actif = False
        self.agent.save(update_fields=["actif"])
        self.assertEqual(
            self.client.get(QUI_SUIS_JE, **self.entetes(self.jeton)).status_code, 401
        )

    def test_agent_expire(self):
        self.agent.expire_le = timezone.now() - timezone.timedelta(minutes=1)
        self.agent.save(update_fields=["expire_le"])
        self.assertEqual(
            self.client.get(QUI_SUIS_JE, **self.entetes(self.jeton)).status_code, 401
        )

    def test_compte_porteur_desactive(self):
        """Désactiver le compte doit suffire, sans passer par l'écran des agents."""
        self.agent.user.is_active = False
        self.agent.user.save(update_fields=["is_active"])
        self.assertEqual(
            self.client.get(QUI_SUIS_JE, **self.entetes(self.jeton)).status_code, 401
        )

    def test_ip_hors_liste(self):
        self.agent.ips_autorisees = "10.0.0.1"
        self.agent.save(update_fields=["ips_autorisees"])
        self.assertEqual(
            self.client.get(QUI_SUIS_JE, **self.entetes(self.jeton)).status_code, 401
        )

    def test_ip_dans_la_liste(self):
        self.agent.ips_autorisees = "127.0.0.1\n10.0.0.1"
        self.agent.save(update_fields=["ips_autorisees"])
        self.assertEqual(
            self.client.get(QUI_SUIS_JE, **self.entetes(self.jeton)).status_code, 200
        )

    def test_tous_les_refus_se_ressemblent(self):
        """
        Le corps de la réponse ne doit pas dire POURQUOI.

        Le motif précis existe, mais dans le journal — il est pour
        l'exploitant, pas pour l'appelant.
        """
        self.agent.expire_le = timezone.now() - timezone.timedelta(minutes=1)
        self.agent.save(update_fields=["expire_le"])
        _, _, inconnu = jetons.fabriquer()

        corps = {
            self.client.get(QUI_SUIS_JE).json()["erreur"],
            self.client.get(QUI_SUIS_JE, **self.entetes(inconnu)).json()["erreur"],
            self.client.get(QUI_SUIS_JE, **self.entetes(self.jeton)).json()["erreur"],
        }
        self.assertEqual(corps, {REFUS})

    @override_settings(JEIKO_AGENTS_AUTORISER_HTTP=False)
    def test_http_en_clair_est_refuse(self):
        """Un jeton qui voyage en clair est un jeton divulgué."""
        self.assertEqual(
            self.client.get(QUI_SUIS_JE, **self.entetes(self.jeton)).status_code, 401
        )

    @override_settings(JEIKO_AGENTS_AUTORISER_HTTP=False)
    def test_https_passe(self):
        self.assertEqual(
            self.client.get(QUI_SUIS_JE, secure=True, **self.entetes(self.jeton)).status_code,
            200,
        )


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class JetonTests(SocleMixin, TestCase):
    def test_le_secret_n_est_jamais_enregistre(self):
        """
        La base ne doit contenir aucune trace exploitable du jeton.

        C'est ce qui fait qu'une sauvegarde égarée ne donne pas d'accès.
        """
        agent, jeton = self.creer()
        _, secret = jetons.decouper(jeton)

        ligne = AgentToken.objects.get(agent=agent)
        self.assertNotIn(secret, ligne.empreinte)
        self.assertNotEqual(ligne.empreinte, secret)
        self.assertEqual(ligne.empreinte, jetons.empreinte(secret))
        self.assertEqual(len(ligne.empreinte), 64)

        # Et nulle part ailleurs dans la ligne.
        for champ in (ligne.prefixe, ligne.libelle):
            self.assertNotIn(secret, champ)

    def test_reinitialiser_revoque_l_ancien(self):
        agent, ancien = self.creer()
        nouveau = reinitialiser_le_jeton(agent)

        self.assertNotEqual(ancien, nouveau)
        self.assertEqual(
            self.client.get(QUI_SUIS_JE, **self.entetes(ancien)).status_code, 401
        )
        self.assertEqual(
            self.client.get(QUI_SUIS_JE, **self.entetes(nouveau)).status_code, 200
        )

    def test_le_compte_porteur_ne_peut_pas_se_connecter(self):
        agent, _ = self.creer()
        self.assertFalse(agent.user.has_usable_password())
        self.assertFalse(agent.user.is_staff)
        self.assertFalse(agent.user.is_superuser)


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class JournalTests(SocleMixin, TestCase):
    def test_les_appels_acceptes_et_refuses_sont_traces(self):
        agent, jeton = self.creer()
        self.client.get(QUI_SUIS_JE, **self.entetes(jeton))
        self.client.get(QUI_SUIS_JE)

        self.assertEqual(AppelAgent.objects.count(), 2)
        accepte = AppelAgent.objects.get(statut=200)
        self.assertEqual(accepte.agent, agent)

        refuse = AppelAgent.objects.get(statut=401)
        self.assertIsNone(refuse.agent)
        # Le motif existe pour l'exploitant, il n'est jamais sorti à l'appelant.
        self.assertEqual(refuse.motif_refus, "absent")


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class PermissionsTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()

    def test_un_agent_sans_role_ne_peut_rien(self):
        """Authentifié n'est pas autorisé."""
        reponse = self.client.get(PAGES, **self.entetes(self.jeton))
        self.assertEqual(reponse.status_code, 403)

    def test_un_agent_peut_toujours_se_presenter(self):
        """
        Sans quoi un jeton valide répondrait 403 avant tout rôle, et l'on
        chercherait la panne du mauvais côté.
        """
        self.assertEqual(
            self.client.get(QUI_SUIS_JE, **self.entetes(self.jeton)).status_code, 200
        )

    def test_lecture_seule_ne_permet_pas_d_ecrire(self):
        donner_le_role(self.agent.user, "view_page")

        self.assertEqual(self.client.get(PAGES, **self.entetes(self.jeton)).status_code, 200)
        reponse = self.json_post(
            "/api/agent/v1/pages/creer/", {"titre": "Interdit"}, self.jeton
        )
        self.assertEqual(reponse.status_code, 403)
        self.assertFalse(Page.objects.filter(title="Interdit").exists())

    def test_aucune_route_ne_supprime_une_page(self):
        """
        Première des deux barrières : la route n'existe pas, quelle que soit
        la permission. La seconde est le rôle, qui ne porte pas `delete_page`.
        """
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page", "delete_page"
        )
        page = Page.objects.create(title="Intouchable", url_tag="intouchable")

        reponse = self.client.delete(
            f"/api/agent/v1/pages/{page.id}/", **self.entetes(self.jeton)
        )
        self.assertEqual(reponse.status_code, 405)
        self.assertTrue(Page.objects.filter(id=page.id).exists())


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class ConstructionDePageTests(SocleMixin, TestCase):
    """Le parcours réel : bâtir une page entière par l'API."""

    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(self.agent.user, "view_page", "add_page", "change_page")

    def _json(self, reponse):
        return json.loads(reponse.content)

    def test_parcours_complet(self):
        page = self._json(
            self.json_post("/api/agent/v1/pages/creer/", {"titre": "Nos tarifs"}, self.jeton)
        )["page"]
        self.assertEqual(page["url_tag"], "nos-tarifs")

        section = self._json(self.json_post(
            f"/api/agent/v1/pages/{page['id']}/sections/", {"gabarit": "CLASSIC"}, self.jeton
        ))["section"]
        ligne = self._json(self.json_post(
            f"/api/agent/v1/sections/{section['id']}/lignes/", {"colonnes": 2}, self.jeton
        ))["ligne"]
        bloc = self._json(self.json_post(
            f"/api/agent/v1/lignes/{ligne['id']}/blocs/", {"colonne": 1}, self.jeton
        ))["bloc"]

        self.assertEqual(bloc["colonne"], 1)

        self.client.put(
            f"/api/agent/v1/blocs/{bloc['id']}/contenu/",
            data=json.dumps({"type": "TEXT", "texte": "<p>Bonjour</p>"}),
            content_type="application/json",
            **self.entetes(self.jeton),
        )

        arbre = self._json(self.client.get(
            f"/api/agent/v1/pages/{page['id']}/", **self.entetes(self.jeton)
        ))
        contenu = arbre["sections"][0]["lignes"][0]["blocs"][0]["contenu"]
        self.assertEqual(contenu["type"], "TEXT")
        self.assertEqual(contenu["texte"], "<p>Bonjour</p>")

    def test_une_page_creee_par_un_agent_naît_en_brouillon(self):
        """
        Mettre en ligne est une décision éditoriale. Un agent qui se trompe ne
        doit pas se tromper devant les visiteurs.
        """
        page = self._json(
            self.json_post("/api/agent/v1/pages/creer/", {"titre": "Essai"}, self.jeton)
        )["page"]
        self.assertFalse(page["publiee"])
        self.assertFalse(Page.objects.get(id=page["id"]).active)

    def test_une_adresse_deja_prise_est_refusee(self):
        Page.objects.create(title="Déjà là", url_tag="deja-la")
        reponse = self.json_post(
            "/api/agent/v1/pages/creer/",
            {"titre": "Autre", "url_tag": "deja-la"},
            self.jeton,
        )
        self.assertEqual(reponse.status_code, 409)

    def test_une_modification_partielle_ne_touche_pas_le_reste(self):
        """
        Le point le plus utile de l'API des paramètres : un agent qui règle le
        padding du téléphone ne doit pas remettre à zéro celui de l'ordinateur.
        """
        page = Page.objects.create(title="P", url_tag="p")
        section = self._json(self.json_post(
            f"/api/agent/v1/pages/{page.id}/sections/", {}, self.jeton
        ))["section"]

        self.client.patch(
            f"/api/agent/v1/sections/{section['id']}/",
            data=json.dumps({"paddings": {"computer": {"haut": "60px"}}}),
            content_type="application/json",
            **self.entetes(self.jeton),
        )
        reponse = self.client.patch(
            f"/api/agent/v1/sections/{section['id']}/",
            data=json.dumps({"paddings": {"phone": {"haut": "20px"}}}),
            content_type="application/json",
            **self.entetes(self.jeton),
        )

        paddings = self._json(reponse)["section"]["parametres"]["paddings"]
        self.assertEqual(paddings["computer"]["haut"], "60px")
        self.assertEqual(paddings["phone"]["haut"], "20px")

    def test_un_appareil_inconnu_est_signale(self):
        page = Page.objects.create(title="P2", url_tag="p2")
        section = self._json(self.json_post(
            f"/api/agent/v1/pages/{page.id}/sections/", {}, self.jeton
        ))["section"]

        reponse = self.client.patch(
            f"/api/agent/v1/sections/{section['id']}/",
            data=json.dumps({"marges": {"montre": {"haut": "1px"}}}),
            content_type="application/json",
            **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("montre", self._json(reponse)["erreur"])

    def test_le_corps_doit_etre_du_json(self):
        reponse = self.client.post(
            "/api/agent/v1/pages/creer/",
            data="pas du json",
            content_type="application/json",
            **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 400)


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class TousLesParametresTests(SocleMixin, TestCase):
    """
    « Tous les paramètres » veut dire tous : au-delà des marges et des tailles,
    l'image de fond et ses réglages, l'animation, la bordure et le CSS.

    Les trois derniers vivent dans des modèles à part, reliés par un
    `OneToOneField` nullable qui n'existe pas tant qu'on ne l'a pas créé.
    L'API les fabrique à la demande : un agent n'a pas à savoir lequel manque.
    """

    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(self.agent.user, "view_page", "add_page", "change_page")
        self.page = Page.objects.create(title="Params", url_tag="params")
        self.section = json.loads(self.json_post(
            f"/api/agent/v1/pages/{self.page.id}/sections/", {}, self.jeton
        ).content)["section"]

    def patch(self, corps):
        return self.client.patch(
            f"/api/agent/v1/sections/{self.section['id']}/",
            data=json.dumps(corps),
            content_type="application/json",
            **self.entetes(self.jeton),
        )

    def test_animation(self):
        reponse = self.patch({"animation": {
            "enabled": True, "preset": "slide-up", "duration_ms": 900,
            "enable_phone": False,
        }})
        self.assertEqual(reponse.status_code, 200)
        anim = json.loads(reponse.content)["section"]["parametres"]["animation"]
        self.assertTrue(anim["enabled"])
        self.assertEqual(anim["preset"], "slide-up")
        self.assertEqual(anim["duration_ms"], 900)
        self.assertFalse(anim["enable_phone"])

    def test_bordure(self):
        reponse = self.patch({"bordure": {
            "border_width": "2px", "border_style": "solid",
            "border_color": "rgba(0,0,0,1)", "border_radius": "12px",
        }})
        bordure = json.loads(reponse.content)["section"]["parametres"]["bordure"]
        self.assertEqual(bordure["border_radius"], "12px")

    def test_css_par_appareil(self):
        reponse = self.patch({"css": {
            "current": "display:flex;", "current_phone": "display:block;",
            "object_classes": "ma-classe",
        }})
        css = json.loads(reponse.content)["section"]["parametres"]["css"]
        self.assertEqual(css["current_phone"], "display:block;")
        self.assertEqual(css["object_classes"], "ma-classe")

    def test_image_de_fond_et_ses_reglages(self):
        from jeiko.administration_pages.models import ImageContent

        image = ImageContent.objects.create(alt="Fond")
        reponse = self.patch({"fond": {
            "image_id": image.id,
            "reglages_image": {"background_size": "cover",
                               "background_position": "center center",
                               "background_opacity": "0.8"},
        }})
        self.assertEqual(reponse.status_code, 200)
        fond = json.loads(reponse.content)["section"]["parametres"]["fond"]
        self.assertEqual(fond["image"]["id"], image.id)
        self.assertEqual(fond["image"]["reglages"]["background_size"], "cover")
        self.assertEqual(fond["image"]["reglages"]["background_opacity"], "0.8")

    def test_detacher_l_image_de_fond(self):
        from jeiko.administration_pages.models import ImageContent

        image = ImageContent.objects.create()
        self.patch({"fond": {"image_id": image.id}})
        reponse = self.patch({"fond": {"image_id": None}})
        fond = json.loads(reponse.content)["section"]["parametres"]["fond"]
        self.assertIsNone(fond["image"]["id"])

    def test_une_image_inexistante_est_signalee(self):
        reponse = self.patch({"fond": {"image_id": 999999}})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("999999", json.loads(reponse.content)["erreur"])

    def test_un_champ_inconnu_est_signale_avec_la_liste(self):
        """
        Un agent qui se trompe de nom doit apprendre les noms valides du
        premier coup, sans avoir à deviner ni à lire le code.
        """
        reponse = self.patch({"bordure": {"epaisseur": "2px"}})
        self.assertEqual(reponse.status_code, 400)
        message = json.loads(reponse.content)["erreur"]
        self.assertIn("epaisseur", message)
        self.assertIn("border_width", message)

    def test_les_satellites_valent_None_tant_qu_on_n_y_a_pas_touche(self):
        arbre = json.loads(self.client.get(
            f"/api/agent/v1/pages/{self.page.id}/", **self.entetes(self.jeton)
        ).content)
        params = arbre["sections"][0]["parametres"]
        self.assertIsNone(params["animation"])
        self.assertIsNone(params["bordure"])
        self.assertIsNone(params["css"])


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class GuideTests(SocleMixin, TestCase):
    """
    Le mode d'emploi que l'API se donne à elle-même.

    Ces tests ne vérifient pas qu'il est bien écrit — ils vérifient qu'il **ne
    ment pas**. Une documentation recopiée à la main devient fausse au premier
    changement, et une documentation fausse fait perdre plus de temps que pas
    de documentation du tout : elle se trompe avec autorité.

    Tout ce qui peut être déduit du code l'est ; ces tests le prouvent en
    confrontant le guide aux constantes.
    """

    def setUp(self):
        self.agent, self.jeton = self.creer()

    def guide(self):
        return json.loads(
            self.client.get("/api/agent/v1/", **self.entetes(self.jeton)).content
        )

    def test_lisible_sans_le_moindre_role(self):
        """
        Un agent doit pouvoir lire le mode d'emploi avant qu'on lui accorde
        quoi que ce soit — sinon on lui demande de deviner ce qu'il a le droit
        de demander.
        """
        reponse = self.client.get("/api/agent/v1/", **self.entetes(self.jeton))
        self.assertEqual(reponse.status_code, 200)
        self.assertFalse(self.agent.user.role_assignments.exists())

    def test_mais_pas_sans_jeton(self):
        self.assertEqual(self.client.get("/api/agent/v1/").status_code, 401)

    def test_il_liste_toutes_les_routes_reellement_montees(self):
        from jeiko.agents.urls_api import urlpatterns

        annonces = {e["nom"] for e in self.guide()["points_d_entree"]}
        self.assertEqual(annonces, {m.name for m in urlpatterns})

    def test_chaque_route_annoncee_est_decrite(self):
        """Une ligne « ? » dans le guide est une ligne qui n'aide personne."""
        for entree in self.guide()["points_d_entree"]:
            with self.subTest(route=entree["nom"]):
                self.assertNotEqual(entree["methodes"], "?")
                self.assertTrue(entree["role"])

    def test_les_champs_annonces_sont_ceux_du_code(self):
        from jeiko.agents import parametres

        params = self.guide()["parametres"]
        self.assertEqual(params["appareils"], list(parametres.APPAREILS))
        self.assertEqual(
            params["animation"], list(parametres.SATELLITES["animation"][1])
        )
        self.assertEqual(params["bordure"], list(parametres.SATELLITES["bordure"][1]))
        self.assertEqual(params["css"], list(parametres.SATELLITES["css"][1]))
        self.assertEqual(
            params["fond"]["reglages_image"], list(parametres.CHAMPS_IMAGE_DE_FOND)
        )

    def test_les_gabarits_annonces_existent(self):
        from jeiko.administration_pages import fabrique

        self.assertEqual(
            set(self.guide()["gabarits_de_section"]), set(fabrique.GABARITS_SECTION)
        )

    def test_les_types_de_contenu_annonces_sont_ceux_qu_on_accepte(self):
        from jeiko.agents.vues_pages import TYPES_OUVERTS

        self.assertEqual(
            self.guide()["contenus"]["modifiables_par_l_api"], list(TYPES_OUVERTS)
        )

    def test_il_dit_le_piege_de_vocabulaire(self):
        """
        `colonne` n'est pas un rang vertical. C'est le contresens le plus
        probable, et le seul qui produise une page bancale sans lever d'erreur.
        """
        guide = self.guide()
        self.assertIn("colonne", guide["vocabulaire"])
        self.assertIn("PAS un rang vertical", guide["vocabulaire"]["colonne"])
        self.assertIn("piège de vocabulaire", guide["guide"])

    def test_il_annonce_ce_qui_est_interdit(self):
        guide = self.guide()
        self.assertTrue(any("Supprimer une page" in i for i in guide["interdits"]))
        self.assertIn("brouillon", guide["guide"])


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class FichesEtProduitsTests(SocleMixin, TestCase):
    """
    Le cas d'usage central : une page dessinée une fois, autant de pages
    publiées qu'il y a de fiches.

    Un modèle de fiche déclare des champs et désigne une page-gabarit ; chaque
    fiche remplit ces champs, et le gabarit se rend avec ses valeurs. Un agent
    ne construit pas trente pages produit à la main : il crée trente fiches.
    """

    def setUp(self):
        from jeiko.administration_pages.models import Page
        from jeiko.custom_objects.models import CustomObjectField, CustomObjectModel

        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_customobject", "add_customobject",
            "change_customobject", app="custom_objects", nom="Agent fiches",
        )

        gabarit = Page.objects.create(
            title="Gabarit produit", url_tag="gabarit-produit",
            is_custom_object_template=True,
        )
        self.modele = CustomObjectModel.objects.create(
            name="Produit", slug="produit", page_template=gabarit, is_product=True,
        )
        CustomObjectField.objects.create(
            model=self.modele, code="description", label="Description",
            field_type="rich_text", position=1,
        )
        CustomObjectField.objects.create(
            model=self.modele, code="visuel", label="Visuel",
            field_type="image", position=2,
        )

    def _json(self, reponse):
        return json.loads(reponse.content)

    def test_le_contrat_est_lisible_avant_toute_creation(self):
        """
        Sans `/modeles/`, un agent devrait deviner que le champ s'appelle
        « description » et qu'il attend du texte riche.
        """
        donnees = self._json(
            self.client.get("/api/agent/v1/modeles/", **self.entetes(self.jeton))
        )
        modele = donnees["modeles"][0]
        self.assertEqual(modele["slug"], "produit")
        self.assertEqual(modele["gabarit_de_page"]["titre"], "Gabarit produit")

        codes = {c["code"]: c["type"] for c in modele["champs"]}
        self.assertEqual(codes, {"description": "rich_text", "visuel": "image"})

    def test_creer_une_fiche_avec_ses_valeurs(self):
        reponse = self.json_post("/api/agent/v1/objets/creer/", {
            "modele": "produit",
            "titre": "Chaise Ada",
            "valeurs": {"description": "<p>Une belle chaise.</p>"},
        }, self.jeton)
        self.assertEqual(reponse.status_code, 201)

        objet = self._json(reponse)["objet"]
        self.assertEqual(objet["slug"], "chaise-ada")
        valeurs = {v["code"]: v for v in objet["valeurs"]}
        self.assertEqual(valeurs["description"]["valeur"], "<p>Une belle chaise.</p>")

    def test_une_fiche_naît_non_publiee(self):
        objet = self._json(self.json_post("/api/agent/v1/objets/creer/", {
            "modele": "produit", "titre": "Brouillon",
        }, self.jeton))["objet"]
        self.assertFalse(objet["publie"])

    def test_un_code_de_champ_inconnu_liste_les_codes_valides(self):
        """Se tromper de nom doit s'apprendre du premier coup, pas se deviner."""
        reponse = self.json_post("/api/agent/v1/objets/creer/", {
            "modele": "produit", "titre": "X", "valeurs": {"prix_barre": "10"},
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)
        message = self._json(reponse)["erreur"]
        self.assertIn("prix_barre", message)
        self.assertIn("description", message)

    def test_un_modele_inconnu_liste_les_modeles(self):
        reponse = self.json_post("/api/agent/v1/objets/creer/", {
            "modele": "nimporte", "titre": "X",
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("produit", self._json(reponse)["erreur"])

    def test_une_modification_partielle_ne_touche_pas_les_autres_champs(self):
        objet = self._json(self.json_post("/api/agent/v1/objets/creer/", {
            "modele": "produit", "titre": "Chaise",
            "valeurs": {"description": "<p>Texte d'origine.</p>"},
        }, self.jeton))["objet"]

        reponse = self.client.patch(
            f"/api/agent/v1/objets/{objet['id']}/",
            data=json.dumps({"publie": True}),
            content_type="application/json",
            **self.entetes(self.jeton),
        )
        rendu = self._json(reponse)["objet"]
        self.assertTrue(rendu["publie"])
        valeurs = {v["code"]: v for v in rendu["valeurs"]}
        self.assertEqual(valeurs["description"]["valeur"], "<p>Texte d'origine.</p>")

    def test_une_image_inexistante_est_refusee_avec_la_raison(self):
        reponse = self.json_post("/api/agent/v1/objets/creer/", {
            "modele": "produit", "titre": "X", "valeurs": {"visuel": 999999},
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)
        message = self._json(reponse)["erreur"]
        self.assertIn("999999", message)
        self.assertIn("administration", message)

    def test_aucune_route_ne_supprime_une_fiche(self):
        objet = self._json(self.json_post("/api/agent/v1/objets/creer/", {
            "modele": "produit", "titre": "Intouchable",
        }, self.jeton))["objet"]

        reponse = self.client.delete(
            f"/api/agent/v1/objets/{objet['id']}/", **self.entetes(self.jeton)
        )
        self.assertEqual(reponse.status_code, 405)

    def test_sans_role_produit_on_ne_cree_pas_de_produit(self):
        """
        Les fiches et les produits sont deux permissions distinctes : gérer le
        contenu n'autorise pas à fixer un prix.
        """
        reponse = self.json_post("/api/agent/v1/produits/creer/", {
            "type": "objet", "fiche_id": 1, "sku": "x",
        }, self.jeton)
        self.assertEqual(reponse.status_code, 403)
