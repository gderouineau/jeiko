# jeiko/agents/vues_pages.py
"""
L'API des pages : lire un arbre complet, le construire, le modifier.

La forme retenue
----------------
**Une lecture d'un seul tenant, des écritures granulaires.**

`GET /pages/<id>/` rend la page entière — sections, lignes, blocs, contenus et
tous les paramètres — en un seul document. Un agent qui doit modifier une page
a besoin de la voir en entier pour décider ; le faire en quarante appels
coûterait cher et lui donnerait une vue par morceaux.

Les écritures, elles, restent unitaires. Un `PUT` de l'arbre complet aurait été
séduisant, mais il suppose un moteur de comparaison : c'est lui qui déciderait
seul de supprimer ce qui manque dans le document reçu. Un agent qui oublie une
branche effacerait alors du contenu sans l'avoir demandé, et personne ne
saurait dire si c'était voulu. Les écritures unitaires disent ce qu'elles font,
se journalisent une par une, et une erreur n'emporte que son propre appel.

Ce qui est délibérément absent
------------------------------
**La suppression de page.** Aucun point d'entrée, à aucune permission. Un agent
peut tout construire et tout défaire à l'intérieur d'une page, mais la page
elle-même ne disparaît que par la main d'un humain, dans l'écran qui dit les
conséquences. C'est la règle posée avec l'exploitant, et elle est appliquée
deux fois : ici par l'absence de route, et par un rôle qui ne porte pas
`delete_page`.

Le vocabulaire du modèle, à connaître
-------------------------------------
`Bloc.position` n'est **pas** un rang vertical : c'est un numéro de COLONNE.
Le rang dans la colonne est `position_in_column`. L'API expose donc `colonne`
et `rang`, qui disent ce qu'ils sont.
"""

from django.db import transaction
from django.shortcuts import get_object_or_404
from django.utils.text import slugify

from jeiko.administration_pages import fabrique
from jeiko.administration_pages.models import (
    Bloc, Content, ContentButton, ContentImage, ContentText, ImageContent,
    Line, Page, Section,
)

from . import parametres
from .parametres import ParametreInvalide
from .vues_api import CorpsInvalide, VueAgent, erreur, ok

LIRE = "administration_pages.view_page"
MODIFIER = "administration_pages.change_page"
CREER = "administration_pages.add_page"


# --------------------------------------------------------------------------- #
#  Sérialisation
# --------------------------------------------------------------------------- #
def _contenu_en_dict(content):
    """
    Le contenu d'un bloc, réduit à ce qu'un agent peut lire et écrire.

    Les types non encore couverts sont rendus avec leur seul `type` : mieux
    vaut dire « ce bloc est un carrousel, je ne sais pas te le détailler » que
    de laisser croire qu'il est vide.
    """
    if content is None:
        return {"type": "NOT_SET"}

    donnees = {"type": content.content_type}

    if content.content_type == "TEXT" and content.content_text:
        donnees["texte"] = content.content_text.text
    elif content.content_type == "BUTTON" and content.content_button:
        bouton = content.content_button
        donnees["bouton"] = {
            "libelle": bouton.label,
            "url": getattr(bouton, "url", "") or "",
        }
    elif content.content_type == "IMAGE" and content.content_image:
        image = content.content_image.image_content
        donnees["image"] = {
            "id": image.id if image else None,
            "alt": getattr(image, "alt", "") if image else "",
        }
    elif content.content_type != "NOT_SET":
        donnees["modifiable_par_l_api"] = False

    return donnees


def _bloc_en_dict(bloc):
    return {
        "id": bloc.id,
        "colonne": bloc.position,
        "rang": bloc.position_in_column,
        "contenu": _contenu_en_dict(getattr(bloc, "content", None)),
        "parametres": parametres.lire(bloc),
    }


def _ligne_en_dict(ligne):
    return {
        "id": ligne.id,
        "position": ligne.position,
        "blocs": [
            _bloc_en_dict(b)
            for b in ligne.blocs.all().order_by("position", "position_in_column", "id")
        ],
        "parametres": parametres.lire(ligne),
    }


def _section_en_dict(section):
    return {
        "id": section.id,
        "position": section.position,
        "lignes": [
            _ligne_en_dict(l) for l in section.lines.all().order_by("position", "id")
        ],
        "parametres": parametres.lire(section),
    }


def _page_en_resume(page):
    return {
        "id": page.id,
        "titre": page.title,
        "url_tag": page.url_tag,
        "publiee": page.active,
        "racine": page.is_root,
        "protegee": page.is_protected,
        "url": page.get_absolute_url() if hasattr(page, "get_absolute_url") else "",
    }


#: Champs de page qu'un agent peut écrire.
#:
#: `is_root`, `is_protected`, `is_pdf`, `is_mail_template` et les autres
#: drapeaux de nature en sont exclus : ils changent ce QU'EST une page, pas ce
#: qu'elle raconte. Les basculer par erreur transformerait la page d'accueil en
#: gabarit d'e-mail, ce qu'aucun message d'erreur ne rattraperait.
CHAMPS_PAGE_MODIFIABLES = {
    "titre": "title",
    "url_tag": "url_tag",
    "publiee": "active",
    "afficher_le_menu": "show_default_main_menu",
    "afficher_le_pied_de_page": "show_default_footer",
    "indexable_par_google": "google_index",
}


# --------------------------------------------------------------------------- #
#  Pages
# --------------------------------------------------------------------------- #
class ListeDesPages(VueAgent):
    permission_requise = LIRE

    def get(self, request):
        pages = Page.objects.all().order_by("title")
        return ok({"pages": [_page_en_resume(p) for p in pages]})


class CreationDePage(VueAgent):
    permission_requise = CREER

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)

        titre = str(corps.get("titre") or "").strip()
        if not titre:
            raise CorpsInvalide("Un « titre » est obligatoire.")

        url_tag = str(corps.get("url_tag") or "").strip() or slugify(titre)
        if Page.objects.filter(url_tag=url_tag).exists():
            return erreur(
                f"Une page utilise déjà l'adresse « {url_tag} ».",
                statut=409,
                url_tag=url_tag,
            )

        page = Page.objects.create(
            title=titre[:200],
            url_tag=url_tag[:200],
            # Une page créée par un agent naît en BROUILLON, toujours.
            # La mise en ligne est une décision éditoriale : elle reste un geste
            # humain, ou un appel explicite et séparé.
            active=False,
        )
        return ok({"page": _page_en_resume(page)}, statut=201)


class DetailPage(VueAgent):
    permission_requise = LIRE

    def get(self, request, page_id):
        page = get_object_or_404(
            Page.objects.prefetch_related("sections__lines__blocs"), id=page_id
        )
        return ok({
            "page": _page_en_resume(page),
            "sections": [
                _section_en_dict(s)
                for s in page.sections.all().order_by("position", "id")
            ],
        })

    def patch(self, request, page_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification de page non autorisée.", statut=403)

        page = get_object_or_404(Page, id=page_id)
        corps = self.corps(request)

        modifies = []
        for cle_api, champ in CHAMPS_PAGE_MODIFIABLES.items():
            if cle_api not in corps:
                continue
            valeur = corps[cle_api]
            if champ in ("title", "url_tag"):
                valeur = str(valeur).strip()[:200]
                if not valeur:
                    raise CorpsInvalide(f"« {cle_api} » ne peut pas être vide.")
            if champ == "url_tag" and Page.objects.filter(
                url_tag=valeur
            ).exclude(id=page.id).exists():
                return erreur(
                    f"Une autre page utilise déjà l'adresse « {valeur} ».", statut=409
                )
            setattr(page, champ, valeur)
            modifies.append(champ)

        if modifies:
            page.save(update_fields=modifies)

        return ok({"page": _page_en_resume(page), "modifies": modifies})


# --------------------------------------------------------------------------- #
#  Sections, lignes, blocs
# --------------------------------------------------------------------------- #
class SectionsDeLaPage(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        corps = self.corps(request, obligatoire=False)
        gabarit = str(corps.get("gabarit") or "CLASSIC").upper()

        try:
            section = fabrique.creer_section(page, gabarit=gabarit)
        except ValueError as souci:
            raise CorpsInvalide(str(souci))

        return ok({"section": _section_en_dict(section)}, statut=201)


class DetailSection(VueAgent):
    permission_requise = MODIFIER

    def _section(self, section_id):
        return get_object_or_404(Section, id=section_id)

    def get(self, request, section_id):
        return ok({"section": _section_en_dict(self._section(section_id))})

    def patch(self, request, section_id):
        section = self._section(section_id)
        try:
            touches = parametres.appliquer(section, self.corps(request))
        except ParametreInvalide as souci:
            raise CorpsInvalide(str(souci))
        return ok({"section": _section_en_dict(section), "modifies": touches})

    def delete(self, request, section_id):
        section = self._section(section_id)
        section.delete()
        return ok({"supprime": True, "section_id": int(section_id)})


class LignesDeLaSection(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, section_id):
        section = get_object_or_404(Section, id=section_id)
        corps = self.corps(request, obligatoire=False)
        colonnes = corps.get("colonnes", 1)

        try:
            colonnes = int(colonnes)
        except (TypeError, ValueError):
            raise CorpsInvalide("« colonnes » doit être un nombre entier.")

        ligne = fabrique.creer_ligne(section, colonnes=colonnes)
        return ok({"ligne": _ligne_en_dict(ligne)}, statut=201)


class DetailLigne(VueAgent):
    permission_requise = MODIFIER

    def _ligne(self, ligne_id):
        return get_object_or_404(Line, id=ligne_id)

    def get(self, request, ligne_id):
        return ok({"ligne": _ligne_en_dict(self._ligne(ligne_id))})

    def patch(self, request, ligne_id):
        ligne = self._ligne(ligne_id)
        try:
            touches = parametres.appliquer(ligne, self.corps(request))
        except ParametreInvalide as souci:
            raise CorpsInvalide(str(souci))
        return ok({"ligne": _ligne_en_dict(ligne), "modifies": touches})

    def delete(self, request, ligne_id):
        self._ligne(ligne_id).delete()
        return ok({"supprime": True, "ligne_id": int(ligne_id)})


class BlocsDeLaLigne(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, ligne_id):
        ligne = get_object_or_404(Line, id=ligne_id)
        corps = self.corps(request, obligatoire=False)

        try:
            colonne = int(corps.get("colonne", 0))
        except (TypeError, ValueError):
            raise CorpsInvalide("« colonne » doit être un nombre entier.")

        if colonne < 0 or colonne >= max(1, ligne.columns_number or 1):
            raise CorpsInvalide(
                f"Cette ligne a {ligne.columns_number} colonne(s) : "
                f"« colonne » doit être entre 0 et {max(0, (ligne.columns_number or 1) - 1)}."
            )

        bloc = fabrique.creer_bloc(ligne, colonne=colonne)
        return ok({"bloc": _bloc_en_dict(bloc)}, statut=201)


class DetailBloc(VueAgent):
    permission_requise = MODIFIER

    def _bloc(self, bloc_id):
        return get_object_or_404(Bloc, id=bloc_id)

    def get(self, request, bloc_id):
        return ok({"bloc": _bloc_en_dict(self._bloc(bloc_id))})

    def patch(self, request, bloc_id):
        bloc = self._bloc(bloc_id)
        try:
            touches = parametres.appliquer(bloc, self.corps(request))
        except ParametreInvalide as souci:
            raise CorpsInvalide(str(souci))
        return ok({"bloc": _bloc_en_dict(bloc), "modifies": touches})

    def delete(self, request, bloc_id):
        self._bloc(bloc_id).delete()
        return ok({"supprime": True, "bloc_id": int(bloc_id)})


# --------------------------------------------------------------------------- #
#  Contenu d'un bloc
# --------------------------------------------------------------------------- #
#: Types qu'un agent peut poser et remplir par l'API.
#:
#: Les vingt autres existent et se voient en lecture, mais chacun a sa propre
#: forme et ses propres objets liés : les ouvrir tous d'un coup, sans les
#: éprouver un par un, produirait une API qui prétend savoir faire ce qu'elle
#: ne sait pas. On ouvre au fil des besoins réels.
TYPES_OUVERTS = ("TEXT", "BUTTON", "IMAGE")


class ContenuDuBloc(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def put(self, request, bloc_id):
        bloc = get_object_or_404(Bloc, id=bloc_id)
        corps = self.corps(request)

        type_demande = str(corps.get("type") or "").upper()
        if type_demande not in TYPES_OUVERTS:
            raise CorpsInvalide(
                f"Type « {type_demande or 'absent'} » non modifiable par l'API. "
                f"Ouverts : {', '.join(TYPES_OUVERTS)}."
            )

        content, _ = Content.objects.get_or_create(bloc=bloc)

        if type_demande == "TEXT":
            if content.content_text is None:
                content.content_text = ContentText.objects.create(text="")
            if "texte" in corps:
                content.content_text.text = str(corps["texte"])
                content.content_text.save(update_fields=["text"])

        elif type_demande == "BUTTON":
            if content.content_button is None:
                content.content_button = ContentButton.objects.create(
                    label="Cliquez ici"
                )
            bouton = content.content_button
            donnees = corps.get("bouton") or {}
            if not isinstance(donnees, dict):
                raise CorpsInvalide("« bouton » doit être un objet.")
            modifies = []
            if "libelle" in donnees:
                bouton.label = str(donnees["libelle"])[:200]
                modifies.append("label")
            if "url" in donnees and hasattr(bouton, "url"):
                bouton.url = str(donnees["url"])[:500]
                modifies.append("url")
            if modifies:
                bouton.save(update_fields=modifies)

        elif type_demande == "IMAGE":
            # On ne crée que le réceptacle : le téléversement du fichier passe
            # par l'écran d'administration, où les validateurs de S-10
            # s'appliquent. Un agent qui pousserait des octets contournerait
            # le plafond de taille et le garde anti-bombe de décompression.
            if content.content_image is None:
                content.content_image = ContentImage.objects.create(
                    image_content=ImageContent.objects.create()
                )

        content.content_type = type_demande
        content.save()

        return ok({"bloc": _bloc_en_dict(bloc)})
