"""
Aplatissement d'un CustomObject vers le contexte de gabarit.

Le gabarit d'un objet custom est une Page ordinaire truffée de jetons
`[%code%]`, résolus par `jeiko.templatetags.custom_tags`. Il faut donc exposer
chaque valeur sous la clé de son champ.

Cette logique était dupliquée à l'identique entre la vue objet et la vue
produit ; toute évolution du typage des champs devait être faite en double.
Elle vit désormais ici, et les deux vues l'appellent.
"""

from django.urls import NoReverseMatch, reverse
from django.utils.safestring import mark_safe

from jeiko.sanitize import clean_html

from .models import CustomObjectField


def build_button_url(value):
    """
    Résout la destination d'un champ BOUTON, dans l'ordre de priorité du
    modèle : page interne, questionnaire, lien externe.
    """
    if value.button_page_id:
        try:
            return value.button_page.get_absolute_url()
        except Exception:
            return "#"

    slug = (value.button_test_slug or "").strip()
    if slug:
        try:
            return reverse(
                "jeiko_client_questionnaires_expert:test_question",
                kwargs={"slug": slug, "position": 0},
            )
        except NoReverseMatch:
            return f"/pass-test/{slug}/question/0/"

    return (value.button_external_url or "").strip() or "#"


def build_object_context(obj):
    """
    Retourne {code_du_champ: valeur} pour un CustomObject.

    Les valeurs sont consommées telles quelles par le gabarit :
      - texte / vidéo  -> str, échappé au rendu
      - texte riche    -> HTML assaini et marqué sûr
      - image          -> ImageContent
      - bouton         -> {"url": ..., "label": ...}
    """
    context = {}

    for value in obj.values.all():
        code = value.field.code
        if not code:
            continue

        field_type = value.field.field_type

        if field_type == CustomObjectField.TEXT:
            context[code] = value.value_text

        elif field_type == CustomObjectField.RICH_TEXT:
            # Le contenu vient de Quill : c'est du HTML, et le rédacteur
            # attend sa mise en forme. L'échapper comme le reste afficherait
            # le balisage en clair au lecteur. On l'assainit donc (cf.
            # jeiko/sanitize.py) avant de le marquer sûr — c'est le seul type
            # de champ à sortir non échappé.
            context[code] = mark_safe(clean_html(value.value_text))

        elif field_type == CustomObjectField.IMAGE:
            context[code] = value.image

        elif field_type == CustomObjectField.VIDEO:
            context[code] = value.video_url

        elif field_type == CustomObjectField.BUTTON:
            context[code] = {
                "url": build_button_url(value),
                "label": (value.button_label or "").strip(),
            }

    return context


#: Chargements à appliquer avant `build_object_context` pour éviter les N+1.
OBJECT_VALUE_PREFETCH = (
    "values__field",
    "values__image",
    "values__button_page",
)


def discard_image_if_orphan(image):
    """
    Supprime une ImageContent devenue inutilisée. Retourne True si supprimée.

    Les formulaires d'objet custom créent une *nouvelle* ImageContent à chaque
    envoi de fichier, plutôt que d'écraser celle en place : la même image peut
    être partagée par plusieurs contenus, et la modifier les changerait tous.
    La contrepartie est que l'ancienne restait en base et sur disque à chaque
    remplacement. On la supprime ici — mais seulement si plus rien ne la
    référence.

    Le balayage passe par les relations inverses déclarées sur le modèle, donc
    il suit automatiquement les usages ajoutés plus tard. `ProtectedError` est
    rattrapé en dernier recours : les relations en PROTECT refuseront d'elles-
    mêmes la suppression si le balayage avait laissé passer quelque chose.
    """
    from django.db.models import ProtectedError, RestrictedError

    if image is None:
        return False

    for rel in image._meta.related_objects:
        related_manager = rel.related_model._base_manager
        if related_manager.filter(**{rel.field.name: image}).exists():
            return False

    try:
        image.delete()  # ImageContent.delete() nettoie aussi les fichiers
    except (ProtectedError, RestrictedError):
        return False
    return True
