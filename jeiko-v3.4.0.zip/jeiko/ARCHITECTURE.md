# JEIKO — une application, pas une suite de modules

*Décision prise le 17/08/2026, avant publication du package.*

## La décision

JEIKO se présente comme quatorze applications Django. **Ce n'en est pas.** C'est
**une application indivisible**, dont le code est réparti en quatorze dossiers
pour la lisibilité — pas pour la composition.

On ne peut pas installer « JEIKO sans la boutique » ou « JEIKO sans les
formations ». Les quatorze entrées d'`INSTALLED_APPS` forment un bloc.

## Pourquoi

Le graphe d'imports comporte **douze paires mutuelles** :

```
administration      ↔ emailing, administration_pages, calendars
administration_menu ↔ administration_pages
administration_pages↔ questionnaires_expert, shop, emailing, custom_objects
calendars           ↔ payments, users
custom_objects      ↔ shop
questionnaires_expert ↔ users
```

Rien ne casse aujourd'hui parce que ces imports croisés sont **différés à
l'intérieur des fonctions**. Mais cela signifie que le découplage n'existe pas :
il est simulé par une convention d'écriture, que rien ne fait respecter.

Deux réponses étaient possibles :

1. **Découpler pour de bon** — extraire un `jeiko.core` (WebSite, Page, envoi
   d'e-mail, signaux) dont tout dépendrait et qui ne dépendrait de rien, puis
   faire passer les couplages restants par des signaux ou un registre.
2. **Assumer l'indivisibilité** et cesser d'en payer le coût en faux-semblant.

La seconde a été retenue. Pour un parc de deux à trois sites, la première serait
une refonte coûteuse au service d'une modularité que personne ne demande.

**Ce choix devait être fait avant publication** : une fois le package publié,
les noms d'import deviennent une interface publique qu'on ne déplace plus sans
casser les installations existantes.

## Ce qui en découle

### Le contrôle au démarrage

`jeiko/checks.py` vérifie que les quatorze applications sont présentes dans
`INSTALLED_APPS` et refuse un démarrage partiel (`jeiko.E001`). Sans lui, une
installation incomplète produit un `ImportError` tardif, loin de sa cause.

C'est la forme vérifiable de la décision : une intention écrite se perd, un
contrôle qui échoue au démarrage non.

### Les imports différés restent

Les `from jeiko.autre_app import ...` placés à l'intérieur des fonctions ne sont
plus une dette à rembourser : ils sont la conséquence assumée du choix. **Ne pas
les remonter en tête de fichier** — ils déclencheraient des imports circulaires
au démarrage.

### Ajouter une application

Trois gestes, toujours ensemble :

1. créer le dossier et son `apps.py` ;
2. l'ajouter à `JEIKO_APPS` dans `jeiko/checks.py` ;
3. l'ajouter au gabarit `INSTALLED_APPS` de l'installeur
   (`INSTALLER/templates/settings.template.py`).

Oublier le troisième est le piège classique : les sites existants ne verront
jamais la nouvelle application, puisque leur `settings.py` est réécrit depuis ce
gabarit à chaque mise à jour.

## Si la décision devait changer

Le point de départ serait `jeiko.core`, et le signal qu'il est temps d'y venir
serait un vrai besoin de vendre JEIKO par modules — pas un souci d'élégance du
graphe de dépendances.
