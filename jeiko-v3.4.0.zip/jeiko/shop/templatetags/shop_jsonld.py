# shop/templatetags/shop_jsonld.py
import json
from decimal import Decimal, ROUND_HALF_UP

from django import template
from django.utils.safestring import mark_safe

from jeiko.templatetags.json_extras import JSON_SCRIPT_ESCAPES

register = template.Library()


def _abs_url(request, url, site_url=None):
    """URL absolue à partir d'une URL relative (même logique que site_identity_tags)."""
    if not url:
        return None
    if url.startswith("http://") or url.startswith("https://"):
        return url
    if request:
        return request.build_absolute_uri(url)
    if site_url:
        return f"{site_url.rstrip('/')}/{url.lstrip('/')}"
    return url


def _image_url(image_content):
    """
    Renvoie l'URL (relative) la plus adaptée pour un ImageContent.
    Priorité : full_size (1920w) -> computer_size (1500w) -> original_image.
    """
    if not image_content:
        return None
    for field in ("full_size", "computer_size", "original_image"):
        f = getattr(image_content, field, None)
        if f and getattr(f, "url", None):
            return f.url
    return None


def _price_str(value):
    """Prix normalisé à 2 décimales, sans symbole (format attendu par schema.org)."""
    if value is None:
        return None
    try:
        return str(Decimal(value).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
    except (ArithmeticError, TypeError, ValueError):
        return None


@register.simple_tag(takes_context=True)
def product_jsonld(context, product):
    """
    Rend le JSON-LD schema.org/Product (+ Offer) pour une fiche produit boutique.
    Retourne "" si le produit est absent ou n'a pas de prix exploitable.
    """
    if not product:
        return ""

    price = _price_str(getattr(product, "price_ttc", None))
    if price is None:
        return ""

    request = context.get("request")

    # URL canonique absolue de la fiche
    try:
        path = product.get_absolute_url()
    except Exception:
        path = None
    url_abs = _abs_url(request, path) if path else None

    data = {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": getattr(product, "name", "") or "",
    }
    if url_abs:
        data["@id"] = f"{url_abs}#product"
        data["url"] = url_abs

    sku = getattr(product, "sku", None)
    if sku:
        data["sku"] = sku
        data["mpn"] = sku

    description = getattr(product, "description", None)
    if description:
        data["description"] = str(description)

    # Image principale (absolue), en tableau comme recommandé par Google
    img_abs = _abs_url(request, _image_url(getattr(product, "main_image", None)))
    if img_abs:
        data["image"] = [img_abs]

    # Marque = identité du site si disponible
    website = context.get("website_data")
    identity = getattr(website, "identity", None) if website else None
    brand_name = getattr(identity, "name", None) or getattr(website, "name", None)
    if brand_name:
        data["brand"] = {"@type": "Brand", "name": brand_name}

    # Disponibilité : en stock si quantité > 0 ou stock négatif autorisé
    stock = getattr(product, "stock_quantity", 0) or 0
    in_stock = stock > 0 or bool(getattr(product, "allow_negative_stock", False))
    availability = (
        "https://schema.org/InStock" if in_stock else "https://schema.org/OutOfStock"
    )

    offer = {
        "@type": "Offer",
        "price": price,
        "priceCurrency": getattr(product, "currency", None) or "EUR",
        "availability": availability,
        "itemCondition": "https://schema.org/NewCondition",
    }
    if url_abs:
        offer["url"] = url_abs
    if brand_name:
        offer["seller"] = {"@type": "Organization", "name": brand_name}

    data["offers"] = offer

    # Inséré tel quel dans un <script type="application/ld+json">
    # (includes/product_jsonld.html). `json.dumps` n'échappe ni `<`, ni `>`,
    # ni `&` : un titre de produit ou un nom de marque contenant `</script>`
    # refermait le bloc et faisait exécuter la suite. Même table que `tojson`,
    # importée plutôt que recopiée.
    json_str = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return mark_safe(json_str.translate(JSON_SCRIPT_ESCAPES))
