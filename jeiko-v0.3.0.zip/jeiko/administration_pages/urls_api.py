from jeiko.administration_pages.views_api import (
    CategoryMainListAPI, SubCategoryListAPI,
    PageListAPI, PageGetAPI,
    ContentFormFieldAPI, ContentFormulaireAPI, FormulaireSubmitView,
    SectionModelCreateAPI, LineModelCreateAPI, BlocModelCreateAPI
)
from django.urls import path

app_name = "api_pages"

urlpatterns = [
    path("categories/", CategoryMainListAPI.as_view(), name="api_category_main_list"),
    path("categories/<int:category_id>/subcategories/", SubCategoryListAPI.as_view(), name="api_subcategory_list"),

    path("pages/", PageListAPI.as_view(), name="api_page_list"),
    path("page/<int:page_id>", PageGetAPI.as_view(), name="api_page_get"),

    path("formulaires/<int:formulaire_id>/", ContentFormulaireAPI.as_view(), name="api_formulaire_get_update"),
    path("formulaires/<int:formulaire_id>/fields/", ContentFormFieldAPI.as_view(),
         name="api_formfield_add_edit_reorder"),
    path("formulaires/<int:formulaire_id>/fields/<int:field_id>/", ContentFormFieldAPI.as_view(),
         name="api_formfield_delete"),
    path(
        "formulaires/<int:formulaire_id>/submit/",
        FormulaireSubmitView.as_view(),
        name="formulaire_submit"
    ),
    path(
        "sections/<int:section_id>/make_model/",
        SectionModelCreateAPI.as_view(),
        name="api_section_make_model"
    ),
    path(
        "lines/<int:line_id>/make_model/",
        LineModelCreateAPI.as_view(),
        name="api_line_make_model"
    ),
    path(
        'blocs/<int:bloc_id>/make_model/',
        BlocModelCreateAPI.as_view(),
        name='api_bloc_make_model'
    ),

]
