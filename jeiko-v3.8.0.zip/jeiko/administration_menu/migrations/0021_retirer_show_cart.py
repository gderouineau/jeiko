"""
`Menu.show_cart` est retiré : l'icône du panier se règle dans les réglages de
la boutique (`ShopSettings.show_cart`), une fois pour tous les menus.

Dépend de `shop.0011`, qui relit ce champ avant qu'il ne disparaisse : un site
qui affichait le panier le garde.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_menu", "0020_site_multilingue"),
        ("shop", "0011_afficher_le_panier"),
    ]

    operations = [
        migrations.RemoveField(model_name="menu", name="show_cart"),
    ]
