"""
Les champs « par langue » d'un formulaire d'administration.

Une catégorie et une entrée de menu ne se dupliquent pas par langue : elles
gardent leur nom d'origine et rangent ses traductions dans un champ JSON
(`Category.traductions`, `MenuItem.titres`). Ce mixin ajoute au formulaire un
champ par langue ACTIVE du site et par valeur traduisible, et les range dans ce
JSON à l'enregistrement.

Rien ne s'ajoute sur un site monolingue. Une traduction saisie pour une langue
éteinte depuis n'est pas effacée : elle revient si la langue est réactivée.
"""

from django import forms
from django.utils.text import slugify

from jeiko import langues_du_site


class ChampsParLangueMixin:
    #: Le champ JSON du modèle.
    champ_json = "traductions"
    #: (clé dans le JSON, libellé) ; clé vide : la valeur EST la traduction
    #: ({"en": "Pricing"}), sinon elle est rangée sous cette clé
    #: ({"en": {"name": …, "slug": …}}).
    valeurs_traduites = ()
    #: Les clés dont la valeur est une adresse, ramenée en slug.
    cles_d_adresse = ("slug",)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        existant = getattr(self.instance, self.champ_json, None) or {}
        self._champs_de_langue = []
        for code in langues_du_site.langues_actives():
            for cle, libelle in self.valeurs_traduites:
                nom = self._nom_du_champ(code, cle)
                valeur = existant.get(code)
                if cle:
                    valeur = (valeur or {}).get(cle)
                self.fields[nom] = forms.CharField(
                    required=False, max_length=120, initial=valeur or "",
                    label=f"{libelle} — {langues_du_site.nom_de_la_langue(code)}",
                )
                self._champs_de_langue.append(nom)

    def _nom_du_champ(self, code, cle):
        return f"{self.champ_json}_{code}_{cle}".rstrip("_")

    @property
    def champs_de_langue(self):
        """Les champs ajoutés, liés, pour le gabarit."""
        return [self[nom] for nom in self._champs_de_langue]

    def valeurs_par_langue(self):
        """Le JSON à enregistrer : l'existant, les langues actives remplacées."""
        resultat = dict(getattr(self.instance, self.champ_json, None) or {})
        for code in langues_du_site.langues_actives():
            saisie = {}
            for cle, _libelle in self.valeurs_traduites:
                valeur = (self.cleaned_data.get(self._nom_du_champ(code, cle)) or "").strip()
                if cle in self.cles_d_adresse:
                    valeur = slugify(valeur)
                if valeur:
                    saisie[cle] = valeur
            if not saisie:
                resultat.pop(code, None)
            elif "" in saisie:
                resultat[code] = saisie[""]
            else:
                resultat[code] = saisie
        return resultat

    def _post_clean(self):
        # AVANT la validation du modèle : c'est `Model.clean()` qui refuse une
        # adresse traduite déjà prise, il doit la voir.
        setattr(self.instance, self.champ_json, self.valeurs_par_langue())
        super()._post_clean()
