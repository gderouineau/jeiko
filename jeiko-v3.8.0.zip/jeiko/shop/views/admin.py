from jeiko.listes import ListeRechercheeEtPaginee
from django.contrib import messages
from django.db import transaction
from django.db.models import ProtectedError, RestrictedError
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.forms import inlineformset_factory
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse, reverse_lazy
from django.utils.text import slugify
from django.views import View
from django.views.generic import (
    ListView,
    CreateView,
    UpdateView,
    DeleteView,
)

from ..models import (
    ProductType,
    Product,
    ProductImage,
    ShopSettings,
    DeliveryZone,
)
from ..forms import (
    ProductTypeForm,
    ProductForm,
    ProductImageForm,
    ProductCustomObjectForm,
    ShopSettingsForm,
    DeliveryZoneForm,
)

from jeiko.custom_objects.models import (
    CustomObjectModel, 
    CustomObjectField, 
    CustomObject,
    CustomObjectValue,
    CustomObjectMetadata,
)
from jeiko.custom_objects.forms import (
    CustomObjectFieldForm,
    CustomObjectValueForm,
    CustomObjectMetadataForm,
)
from django.utils.translation import gettext_lazy as _

class ShopAdminMixin(LoginRequiredMixin, PermissionRequiredMixin):
    """
    Contrôle d'accès de l'administration de la boutique.

    Remplace un test qui ne regardait que `is_staff or is_superuser`. Ce test
    contredisait le système de rôles dans les deux sens : tout compte marqué
    « équipe » — rédacteur, formateur — obtenait l'écriture complète sur les
    produits et les types de produit par l'URL directe alors que le menu lui
    masquait l'entrée ; et à l'inverse un porteur du super-rôle sans le drapeau
    `is_staff` voyait l'entrée et se prenait un 403.

    Les vues sont désormais gardées par les permissions réelles des modèles,
    celles-là mêmes que `templates/includes/admin_menu.html` interroge : le
    menu et la vue disent enfin la même chose.

    Pas de `raise_exception` ici : `AccessMixin.handle_no_permission` distingue
    déjà les deux cas — 403 pour un compte connecté sans droit, redirection vers
    la connexion pour un visiteur anonyme. Le forcer donnait un 403 sec à
    l'anonyme, qui n'a pas de moyen de comprendre qu'il lui suffit de se
    connecter. (Les vues de l'éditeur, elles, le forcent à dessein : elles
    répondent en JSON, où une redirection HTML n'a aucun sens.)
    """


# -------------------------------------------------------------------
#  Inline formsets
# -------------------------------------------------------------------

ProductImageFormSet = inlineformset_factory(
    Product,
    ProductImage,
    form=ProductImageForm,
    extra=0,
    can_delete=True,
)

CustomObjectFieldFormSet = inlineformset_factory(
    CustomObjectModel,
    CustomObjectField,
    form=CustomObjectFieldForm,
    extra=1,
    can_delete=True,
)

CustomObjectValueFormSet = inlineformset_factory(
    CustomObject,
    CustomObjectValue,
    form=CustomObjectValueForm,
    extra=0,
    can_delete=False,
)

DeliveryZoneFormSet = inlineformset_factory(
    ShopSettings,
    DeliveryZone,
    form=DeliveryZoneForm,
    extra=1,
    can_delete=True,
)
# -------------------------------------------------------------------
#  ProductType
# -------------------------------------------------------------------

class ProductTypeListView(ShopAdminMixin, ListView):
    permission_required = "shop.view_producttype"

    model = ProductType
    template_name = "shop/admin/product_type_list.html"
    context_object_name = "types"


class ProductTypeCreateView(ShopAdminMixin, CreateView):
    permission_required = "shop.add_producttype"

    model = ProductType
    form_class = ProductTypeForm
    template_name = "shop/admin/product_type_form.html"

    def form_valid(self, form):
        # 1) On sauvegarde le ProductType SANS content_model
        self.object = form.save(commit=False)
        self.object.save()

        # 2) On crée automatiquement le CustomObjectModel lié
        com_name = f"Produit – {self.object.name}"
        com_slug = slugify(f"product-{self.object.code}")

        content_model = CustomObjectModel.objects.create(
            name=com_name,
            slug=com_slug,
            page_template=form.cleaned_data["page_template"],
            is_product=True,
        )

        # 3) On relie le ProductType à ce modèle de contenu
        self.object.content_model = content_model
        self.object.save(update_fields=["content_model"])

        messages.success(
            self.request,
            _("Type de produit créé (modèle de contenu associé automatiquement).")
        )
        return redirect(self.get_success_url())

    def get_success_url(self):
        return reverse(
            "jeiko_administration_shop:product_type_update",
            args=[self.object.pk],
        )


class ProductTypeUpdateView(ShopAdminMixin, UpdateView):
    permission_required = "shop.change_producttype"

    model = ProductType
    form_class = ProductTypeForm
    template_name = "shop/admin/product_type_form.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        product_type = self.object

        # Formset des champs de contenu (si un content_model existe)
        if product_type.content_model:
            if self.request.method == "POST":
                context["fields_formset"] = CustomObjectFieldFormSet(
                    self.request.POST,
                    instance=product_type.content_model,
                )
            else:
                context["fields_formset"] = CustomObjectFieldFormSet(
                    instance=product_type.content_model,
                )
        else:
            context["fields_formset"] = None

        return context

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        form = self.get_form()

        fields_formset = None
        if self.object.content_model:
            fields_formset = CustomObjectFieldFormSet(
                self.request.POST,
                instance=self.object.content_model,
            )

        if form.is_valid() and (fields_formset is None or fields_formset.is_valid()):
            return self.forms_valid(form, fields_formset)
        else:
            return self.forms_invalid(form, fields_formset)

    def forms_valid(self, form, fields_formset):
        # Sauvegarde du ProductType
        response = super().form_valid(form)
        tpl = form.cleaned_data["page_template"]

        # S'assurer qu'un content_model existe
        if not self.object.content_model:
            com_name = f"Produit – {self.object.name}"
            com_slug = slugify(f"product-{self.object.code}")

            content_model = CustomObjectModel.objects.create(
                name=com_name,
                slug=com_slug,
                page_template=tpl,
                is_product=True,
            )
            self.object.content_model = content_model
            self.object.save(update_fields=["content_model"])
        else:
            cm = self.object.content_model
            if cm.page_template_id != tpl.id:
                cm.page_template = tpl
                cm.save(update_fields=["page_template"])

        # Sauvegarde des champs de contenu
        if fields_formset is not None:
            fields_formset.save()

        messages.success(self.request, _("Type de produit mis à jour."))
        return response

    def forms_invalid(self, form, fields_formset):
        return self.render_to_response(
            self.get_context_data(form=form, fields_formset=fields_formset)
        )

    def get_success_url(self):
        return reverse(
            "jeiko_administration_shop:product_type_update",
            args=[self.object.pk],
        )


class ProductTypeDeleteView(ShopAdminMixin, DeleteView):
    permission_required = "shop.delete_producttype"

    model = ProductType
    template_name = "shop/admin/product_type_confirm_delete.html"
    success_url = reverse_lazy("jeiko_administration_shop:product_type_list")

    # Depuis Django 4.0, DeleteView passe par form_valid() : la surcharge de
    # delete() n'était plus appelée et le message ne s'affichait jamais.
    def form_valid(self, form):
        messages.success(self.request, _("Type de produit supprimé."))
        return super().form_valid(form)


# -------------------------------------------------------------------
#  Product (lié à ProductType + CustomObject)
# -------------------------------------------------------------------
class AllProductListView(ShopAdminMixin, ListeRechercheeEtPaginee, ListView):
    permission_required = "shop.view_product"
    champs_de_recherche = ("sku", "content__title")

    """
    Liste tous les produits, tous types confondus.
    URL : /administration/shop/products/
    """

    model = Product
    template_name = "shop/admin/product_list.html"
    context_object_name = "products"

    def get_queryset(self):
        return self.rechercher(
            Product.objects
            .select_related("type", "content", "content__model")
            .order_by("-created_at")
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Pas de product_type spécifique dans cette vue
        context["product_type"] = None
        return context


class ProductListView(ShopAdminMixin, ListeRechercheeEtPaginee, ListView):
    permission_required = "shop.view_product"
    champs_de_recherche = ("sku", "content__title")

    """
    Liste des produits pour un type donné.
    URL prévue : /administration/shop/types/<type_pk>/products/
    """

    model = Product
    template_name = "shop/admin/product_list.html"
    context_object_name = "products"

    def dispatch(self, request, *args, **kwargs):
        self.product_type = get_object_or_404(ProductType, pk=self.kwargs["type_pk"])
        return super().dispatch(request, *args, **kwargs)

    def get_queryset(self):
        return self.rechercher(
            Product.objects
            .filter(type=self.product_type)
            .select_related("type", "content", "content__model")
            .order_by("-created_at")
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["product_type"] = self.product_type
        return context


class ProductCreateView(ShopAdminMixin, CreateView):
    permission_required = "shop.add_product"

    """
    Création d'un produit pour un ProductType donné.
    On gère :
      - ProductForm (SKU, prix, stock…)
      - ProductCustomObjectForm (titre, slug, publication)
    On ne gère pas encore les images ici : on redirige vers l'update.
    """

    model = Product
    form_class = ProductForm
    template_name = "shop/admin/product_form.html"

    def dispatch(self, request, *args, **kwargs):
        self.product_type = get_object_or_404(ProductType, pk=self.kwargs["type_pk"])
        return super().dispatch(request, *args, **kwargs)

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["product_type"] = self.product_type
        return kwargs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        if self.request.method == "POST":
            context["content_form"] = ProductCustomObjectForm(
                self.request.POST,
                self.request.FILES,
                content_model=self.product_type.content_model,
            )
        else:
            context["content_form"] = ProductCustomObjectForm(
                content_model=self.product_type.content_model,
            )

        context["product_type"] = self.product_type
        context["images_formset"] = None  # images gérées après création
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        content_form = context["content_form"]

        if not content_form.is_valid():
            # On renvoie les deux formulaires avec leurs erreurs
            return self.render_to_response(self.get_context_data(form=form))

        # 1) Créer le CustomObject (fiche contenu)
        custom_obj = content_form.save()

        # 2) Créer le Product en le reliant au CustomObject
        form.instance.type = self.product_type
        form.instance.content = custom_obj
        self.object = form.save()

        messages.success(self.request, _("Produit créé avec sa fiche contenu."))
        return redirect(self.get_success_url())

    def get_success_url(self):
        return reverse(
            "jeiko_administration_shop:product_update",
            kwargs={"type_pk": self.product_type.pk, "pk": self.object.pk},
        )



class ProductUpdateView(ShopAdminMixin, UpdateView):
    permission_required = "shop.change_product"

    model = Product
    form_class = ProductForm
    template_name = "shop/admin/product_form.html"

    def dispatch(self, request, *args, **kwargs):
        self.product_type = get_object_or_404(ProductType, pk=self.kwargs["type_pk"])
        return super().dispatch(request, *args, **kwargs)

    def get_queryset(self):
        """
        Sécurise : on ne peut éditer que les produits
        appartenant au type donné dans l'URL.
        """
        return (
            Product.objects
            .filter(type=self.product_type)
            .select_related("type", "content", "content__model")
        )

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["product_type"] = self.product_type
        return kwargs

    def _ensure_all_values_exist(self, obj: CustomObject):
        """
        S'assure qu'il existe une CustomObjectValue pour
        chaque CustomObjectField du modèle.
        """
        existing = {v.field_id for v in obj.values.all()}
        # obj.model est une instance de CustomObjectModel
        for field in obj.model.fields.all():
            if field.id not in existing:
                CustomObjectValue.objects.create(obj=obj, field=field)

    def _fiche(self):
        """
        La fiche que cet écran modifie : celle du produit — ou sa version dans
        une langue du site, quand le bouton de langue l'a demandée
        (`?langue=en`). Le produit, lui, est le même : son prix, son stock et
        ses images valent pour toutes les langues, et se règlent depuis l'une
        comme depuis l'autre.
        """
        langue = self.request.GET.get("langue", "")
        contenu = self.object.content
        if not langue:
            return contenu
        return get_object_or_404(contenu.traductions, langue=langue)

    def _get_metadata_instance(self):
        metadata, _created = CustomObjectMetadata.objects.get_or_create(obj=self._fiche())
        return metadata

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        product = self.object
        fiche = self._fiche()

        # Site en plusieurs langues : le bouton de langue de la fiche.
        from jeiko.custom_objects.versions import etat_des_versions
        context["fiche"] = fiche
        context["versions"] = etat_des_versions(fiche)

        # S'assurer que toutes les valeurs existent pour le CustomObject du produit
        self._ensure_all_values_exist(fiche)

        # ----- Formulaire contenu (CustomObject) -----
        if self.request.method == "POST":
            context["content_form"] = ProductCustomObjectForm(
                self.request.POST,
                self.request.FILES,
                instance=fiche,
                content_model=self.product_type.content_model,
            )
            # ----- Formset valeurs (CustomObjectValue) -----
            context["values_formset"] = CustomObjectValueFormSet(
                self.request.POST,
                self.request.FILES,
                instance=fiche,
            )
            # ----- Metadata (SEO) -----
            context["metadata_form"] = CustomObjectMetadataForm(
                self.request.POST,
                instance=self._get_metadata_instance(),
                prefix="meta",
            )
        else:
            context["content_form"] = ProductCustomObjectForm(
                instance=fiche,
                content_model=self.product_type.content_model,
            )
            context["values_formset"] = CustomObjectValueFormSet(instance=fiche)
            context["metadata_form"] = CustomObjectMetadataForm(
                instance=self._get_metadata_instance(),
                prefix="meta",
            )

        # ----- Formset images -----
        if self.request.method == "POST":
            context["images_formset"] = ProductImageFormSet(
                self.request.POST,
                self.request.FILES,
                instance=product,
            )
        else:
            context["images_formset"] = ProductImageFormSet(instance=product)

        context["product_type"] = self.product_type
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        content_form = context["content_form"]
        images_formset = context["images_formset"]
        values_formset = context["values_formset"]
        metadata_form = context["metadata_form"]

        # Valider tous les formulaires
        if (not content_form.is_valid() or 
            not images_formset.is_valid() or 
            not values_formset.is_valid() or 
            not metadata_form.is_valid()):
            return self.render_to_response(self.get_context_data(form=form))

        # Sauver la fiche contenu
        content_form.save()

        # Sauver le produit
        self.object = form.save()

        # Sauver les images
        images_formset.instance = self.object
        images_formset.save()

        # Sauver les valeurs custom — de la fiche ouverte, originale ou version.
        fiche = self._fiche()
        values_formset.instance = fiche
        values_formset.save()

        # Sauver les metadata
        metadata = metadata_form.save(commit=False)
        metadata.obj = fiche
        metadata.save()

        messages.success(self.request, _("Produit, contenu et images mis à jour."))
        return redirect(self.get_success_url())

    def get_success_url(self):
        # On reste sur la langue qu'on modifiait.
        from jeiko.custom_objects.versions import ecran_d_edition
        return ecran_d_edition(self._fiche())


class ProductVersionCreateView(ShopAdminMixin, View):
    """
    Crée la version de la fiche d'un produit dans une langue du site, par
    duplication — le pendant, côté boutique, de l'écran des fiches. Le produit
    reste unique : seule sa fiche a une version par langue.

    POST uniquement. Gardée par le droit de modifier un PRODUIT : traduire sa
    fiche, c'est modifier ce qu'il montre, et qui tient la boutique n'a pas
    forcément la main sur les autres fiches du site.
    """

    permission_required = "shop.change_product"
    action = "creer"

    def post(self, request, type_pk, pk, langue):
        from jeiko.custom_objects.versions import repondre

        produit = get_object_or_404(Product.objects.select_related("content"), pk=pk, type_id=type_pk)
        return repondre(request, produit.content, langue, self.action)


class ProductVersionDeleteView(ProductVersionCreateView):
    """Supprime UNE version de la fiche ; le produit et sa fiche d'origine restent."""

    action = "supprimer"


class ProductDeleteView(ShopAdminMixin, DeleteView):
    permission_required = "shop.delete_product"

    model = Product
    template_name = "shop/admin/product_confirm_delete.html"

    def dispatch(self, request, *args, **kwargs):
        self.product_type = get_object_or_404(ProductType, pk=self.kwargs["type_pk"])
        return super().dispatch(request, *args, **kwargs)

    def get_queryset(self):
        return Product.objects.filter(type=self.product_type)

    def get_success_url(self):
        return reverse(
            "jeiko_administration_shop:product_list",
            kwargs={"type_pk": self.product_type.pk},
        )

    # Depuis Django 4.0, DeleteView passe par form_valid() : la surcharge de
    # delete() n'était plus appelée et le message ne s'affichait jamais.
    def form_valid(self, form):
        paniers = self.object.cart_items.count()
        mouvements = self.object.stock_movements.count()
        if paniers or mouvements:
            dependances = []
            if paniers:
                dependances.append(_("%(nombre)s panier(s)") % {"nombre": paniers})
            if mouvements:
                dependances.append(
                    _("%(nombre)s mouvement(s) de stock — l'historique doit être conservé")
                    % {"nombre": mouvements}
                )
            messages.error(
                self.request,
                _("Produit non supprimé : %(raisons)s. "
                  "Désactivez-le plutôt que de supprimer son historique.")
                % {"raisons": ", ".join(str(d) for d in dependances)},
            )
            return redirect(self.get_success_url())
        try:
            response = super().form_valid(form)
        except (ProtectedError, RestrictedError):
            messages.error(
                self.request,
                _("Produit non supprimé : il est encore utilisé par un panier, "
                "une commande ou une autre donnée protégée."),
            )
            return redirect(self.get_success_url())
        messages.success(self.request, _("Produit supprimé."))
        return response


class ShopSettingsUpdateView(ShopAdminMixin, UpdateView):
    """
    Les réglages de la boutique — TVA, devise, livraison.

    `change_producttype` plutôt qu'une permission dédiée : ces réglages
    décident du défaut des types de produit, et qui a le droit de créer un type
    a déjà le droit d'en fixer la TVA. Inventer une permission de plus pour la
    même décision compliquerait les rôles sans rien protéger.
    """

    permission_required = "shop.change_producttype"

    model = ShopSettings
    form_class = ShopSettingsForm
    template_name = "shop/admin/settings_form.html"

    def get_object(self, queryset=None):
        return ShopSettings.get_solo()

    def form_valid(self, form):
        zones_postees = "zones-TOTAL_FORMS" in self.request.POST
        formset = None
        if zones_postees:
            formset = DeliveryZoneFormSet(
                self.request.POST,
                instance=self.object,
                prefix="zones",
            )
            if not formset.is_valid():
                return self.render_to_response(
                    self.get_context_data(form=form, delivery_formset=formset)
                )
        with transaction.atomic():
            response = super().form_valid(form)
            if formset is not None:
                formset.instance = self.object
                formset.save()
        messages.success(self.request, _("Réglages de la boutique enregistrés."))
        return response

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if "delivery_formset" not in context:
            context["delivery_formset"] = DeliveryZoneFormSet(
                instance=self.object,
                prefix="zones",
            )
        context["active_tab"] = self.request.POST.get("active_tab", "general")
        return context

    def form_invalid(self, form):
        zones_postees = "zones-TOTAL_FORMS" in self.request.POST
        formset = DeliveryZoneFormSet(
            self.request.POST if zones_postees else None,
            instance=self.object,
            prefix="zones",
        )
        return self.render_to_response(
            self.get_context_data(form=form, delivery_formset=formset)
        )

    def get_success_url(self):
        return reverse("jeiko_administration_shop:settings")
