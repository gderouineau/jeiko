from decimal import Decimal, ROUND_HALF_UP
import re

from django import forms

from .models import (
    ProductType,
    Product,
    ProductImage,
    ShopSettings,
    DeliveryZone,
)
from jeiko.custom_objects.models import CustomObject
from jeiko.administration_pages.models import Page

from jeiko.custom_objects.forms import CustomObjectForm as BaseCustomObjectForm
from jeiko.formulaires_par_langue import ChampsParLangueMixin
from django.utils.translation import gettext_lazy as _

CENTIME = Decimal("0.01")
CURRENCY_CHOICES = (
    ("EUR", _("EUR — euro")),
    ("USD", _("USD — dollar américain")),
    ("GBP", _("GBP — livre sterling")),
    ("CHF", _("CHF — franc suisse")),
    ("CAD", _("CAD — dollar canadien")),
    ("AUD", _("AUD — dollar australien")),
    ("JPY", _("JPY — yen japonais")),
)


class ProductTypeForm(ChampsParLangueMixin, forms.ModelForm):
    # Sur un site en plusieurs langues : le nom du type et le segment de
    # l'adresse de ses produits (/en/shop/workshops/…), langue par langue —
    # voir jeiko/modeles_par_langue.py.
    valeurs_traduites = (("name", _("Nom")), ("slug", _("Adresse")))

    # Champ "virtuel" : sert à créer / mettre à jour le CustomObjectModel
    page_template = forms.ModelChoiceField(
        # Les pages d'ORIGINE : la version anglaise d'un gabarit est prise
        # d'elle-même pour une fiche anglaise.
        queryset=Page.objects.filter(is_custom_object_template=True, langue=""),
        required=True,
        label=_("Template de page produit"),
        help_text=_("Page gabarit utilisée pour afficher les produits de ce type.")
    )

    class Meta:
        model = ProductType
        fields = [
            "name",
            "code",
            "kind",
            "default_tax_rate",
            "default_currency",
            "is_physical",
            "requires_shipping",
            "is_subscription",
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Si on est en édition et qu'un CustomObjectModel existe déjà,
        # on pré-remplit page_template avec celui de ce modèle.
        instance = getattr(self, "instance", None)
        if instance and instance.pk and instance.content_model:
            self.fields["page_template"].initial = instance.content_model.page_template
        elif not instance or not instance.pk:
            # Le réglage global sert réellement de défaut à la création d'un
            # type ; il ne réécrit jamais les types déjà enregistrés.
            reglages = ShopSettings.get_solo()
            self.initial.setdefault("default_tax_rate", reglages.default_tax_rate)
            self.initial.setdefault("default_currency", reglages.currency)



class ProductForm(forms.ModelForm):
    """
    Formulaire produit relié à ProductType.
    Le CustomObject (contenu) est géré par ProductCustomObjectForm.
    """

    class Meta:
        model = Product
        fields = [
            "type",              # sera figé depuis l'URL (product_type)
            # "content",         # ⚠️ plus exposé ici, géré en coulisse
            "sku",
            "is_active",
            "price_ht",
            "tax_rate",
            "currency",
            "stock_quantity",
            "stock_alert_threshold",
            "allow_negative_stock",
            "weight_kg",
            "linked_expert_test",
            "linked_appointment_type",
            # « credits_amount » retiré : le champ est enregistré mais AUCUN code
            # ne crédite quoi que ce soit à l'achat. Le proposer laissait
            # configurer un produit qui ne délivre rien, en silence. À remettre
            # le jour où les crédits de rendez-vous seront implémentés.
        ]

    def __init__(self, *args, **kwargs):
        # On accepte un kwarg supplémentaire product_type pour simplifier
        self.product_type = kwargs.pop("product_type", None)
        super().__init__(*args, **kwargs)

        # --------- Type ---------
        if self.product_type is not None:
            self.fields["type"].initial = self.product_type
            self.fields["type"].widget = forms.HiddenInput()
            self.fields["type"].disabled = True

        # --------- Defaults basés sur le ProductType ---------
        instance = getattr(self, "instance", None)
        effective_type = self.product_type or getattr(instance, "type", None)

        if effective_type and not self.initial.get("tax_rate"):
            self.initial.setdefault("tax_rate", effective_type.default_tax_rate)
        if effective_type and not self.initial.get("currency"):
            self.initial.setdefault("currency", effective_type.default_currency)

        # Le seuil d'alerte n'a de sens que si une rupture est possible.
        if getattr(instance, "allow_negative_stock", False):
            self.fields.pop("stock_alert_threshold", None)

        # --------- Masquage conditionnel des champs selon le kind ---------
        if effective_type:
            kind = effective_type.kind
            
            # Questionnaire
            if kind != ProductType.KIND_QUESTIONNAIRE:
                self.fields.pop("linked_expert_test", None)
            
            # Appointment / Credits
            if kind != ProductType.KIND_APPOINTMENT:
                self.fields.pop("linked_appointment_type", None)
            
            # Physical (weight)
            if kind != ProductType.KIND_PHYSICAL:
                # On peut garder weight_kg pour tous ou le masquer. 
                # Le user a dit "produit physique ok", mais pour un service ça sert à rien.
                # On le laisse pour l'instant ou on le masque si tu veux être strict.
                pass

        reglages = ShopSettings.get_solo()
        if reglages.prices_include_tax:
            self.fields["price_ht"].label = _("Prix TTC")
            self.fields["price_ht"].help_text = (
                _("Montant saisi TTC ; il sera converti en HT pour la comptabilité.")
            )
            if instance and instance.pk:
                self.initial["price_ht"] = instance.price_ttc
        else:
            self.fields["price_ht"].label = _("Prix HT")
            self.fields["price_ht"].help_text = (
                _("Montant saisi HT ; la TVA est ajoutée pour l'affichage TTC.")
            )

    def clean(self):
        cleaned_data = super().clean()

        # Forcer le type depuis product_type si présent
        if self.product_type is not None:
            cleaned_data["type"] = self.product_type

        ptype = cleaned_data.get("type")
        if ptype:
            # Si tax_rate est vide, on reprend celui du type
            tax_rate = cleaned_data.get("tax_rate")
            if tax_rate in (None, ""):
                cleaned_data["tax_rate"] = ptype.default_tax_rate

            # Si currency est vide, on reprend la devise du type
            currency = cleaned_data.get("currency")
            if not currency:
                cleaned_data["currency"] = ptype.default_currency

        if ShopSettings.get_solo().prices_include_tax:
            prix_saisi = cleaned_data.get("price_ht")
            taux = cleaned_data.get("tax_rate")
            if prix_saisi is not None and taux is not None:
                coefficient = Decimal("1.0") + taux / Decimal("100.0")
                cleaned_data["price_ht"] = (
                    prix_saisi / coefficient
                ).quantize(CENTIME, rounding=ROUND_HALF_UP)

        return cleaned_data

    def clean_tax_rate(self):
        value = self.cleaned_data.get("tax_rate")
        if value is None:
            # On laisse clean() gérer l’héritage depuis ProductType
            return value
        if value < 0 or value > 100:
            raise forms.ValidationError(_("La TVA doit être comprise entre 0 et 100%."))
        return value

    def clean_price_ht(self):
        value = self.cleaned_data.get("price_ht")
        if value is None:
            raise forms.ValidationError(_("Le prix HT est requis."))
        if value < 0:
            raise forms.ValidationError(_("Le prix HT ne peut pas être négatif."))
        return value

    def clean_stock_quantity(self):
        value = self.cleaned_data.get("stock_quantity")
        if value is None:
            return 0
        return value



class ProductCustomObjectForm(BaseCustomObjectForm):
    """
    Version simplifiée de CustomObjectForm pour l'écran Produit :
    - on ne montre pas le champ `model`, il sera imposé selon le ProductType
    """

    class Meta(BaseCustomObjectForm.Meta):
        model = BaseCustomObjectForm.Meta.model
        # On garde le trio de base ; on rajoutera d’autres champs plus tard si tu veux
        fields = ["title", "slug", "is_published", "main_image"]
        widgets = {
            "title": BaseCustomObjectForm.Meta.widgets["title"],
            "slug": BaseCustomObjectForm.Meta.widgets["slug"],
            "is_published": BaseCustomObjectForm.Meta.widgets["is_published"],
            "main_image": BaseCustomObjectForm.Meta.widgets["main_image"],
        }

    def __init__(self, *args, **kwargs):
        self.content_model = kwargs.pop("content_model", None)
        super().__init__(*args, **kwargs)
        # On s’assure que le champ `model` ne soit pas manipulable dans ce form
        if "model" in self.fields:
            self.fields.pop("model")
        # Le modèle est connu AVANT la validation : c'est lui qui permet à
        # `CustomObject.clean()` de refuser une adresse déjà prise. Posé
        # seulement à l'enregistrement, un doublon passait la validation et
        # finissait en erreur 500 sur la contrainte de base.
        if self.content_model and not self.instance.pk:
            self.instance.model = self.content_model
        # La version traduite de la fiche d'un produit n'a pas d'adresse à
        # elle : un produit vit à sa référence, dans toutes les langues
        # (/en/shop/<type>/<référence>/). Son slug ne sert à aucune adresse —
        # on ne le montre pas. Il garde celui de l'originale, reçu à sa
        # naissance.
        if self.instance.pk and self.instance.traduction_de_id:
            self.fields.pop("slug", None)

    def clean_slug(self):
        from django.utils.text import slugify
        slug = self.cleaned_data.get("slug") or self.cleaned_data.get("title")
        return slugify(slug or "")

    def save(self, commit=True):
        obj = super().save(commit=False)
        # À la création, on impose le bon CustomObjectModel
        if self.content_model and not obj.pk:
            obj.model = self.content_model
        if commit:
            obj.save()
        return obj


class ProductImageForm(forms.ModelForm):
    """
    Formulaire simple pour les images de produit.
    Utile pour un inline formset dans l’admin (quand on fera les views).
    """

    class Meta:
        model = ProductImage
        fields = [
            "image",
            "is_main",
            "position",
        ]


class ShopSettingsForm(forms.ModelForm):
    """
    Les réglages de la boutique.

    `default_tax_rate` sert de valeur de référence pour les nouveaux types de
    produit ; il ne réécrit rien. C'est dit dans le `help_text` du modèle, et
    répété ici parce que c'est la question que se pose quiconque change un taux
    de TVA : « est-ce que ça va modifier mes commandes ? » Non.
    """

    currency = forms.CharField(
        max_length=3,
        widget=forms.Select(choices=CURRENCY_CHOICES),
        error_messages={
            "max_length": (
                _("La devise est un code ISO à trois lettres parmi les devises proposées.")
            ),
        },
    )

    class Meta:
        model = ShopSettings
        fields = (
            "is_online",
            "show_cart",
            "homepage",
            "prices_include_tax",
            "display_prices_including_tax",
            "default_tax_rate",
            "currency",
            "free_shipping_from",
        )
        widgets = {
            "default_tax_rate": forms.NumberInput(
                attrs={"step": "0.01", "min": "0", "max": "100"}
            ),
            "currency": forms.Select(choices=CURRENCY_CHOICES),
            "free_shipping_from": forms.NumberInput(attrs={"step": "0.01", "min": "0"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Une page d'accueil de boutique est une page publique ordinaire, pas
        # un gabarit d'objet, un e-mail ou un PDF.
        self.fields["homepage"].queryset = Page.objects.filter(
            active=True,
            is_mail_template=False,
            is_pdf=False,
            is_custom_object_template=False,
        ).order_by("title", "id")

    def clean_default_tax_rate(self):
        taux = self.cleaned_data["default_tax_rate"]
        # Un taux hors [0, 100] n'est pas un taux. La base l'accepterait
        # (`DecimalField` ne borne rien) et le prix TTC deviendrait absurde
        # sans qu'aucune page n'ait l'air fautive.
        if taux < 0 or taux > 100:
            raise forms.ValidationError(
                _("Un taux de TVA se situe entre 0 et 100 %.")
            )
        return taux

    def clean_currency(self):
        devise = (self.cleaned_data["currency"] or "").strip().upper()
        devises_proposees = {code for code, _libelle in CURRENCY_CHOICES}
        if devise not in devises_proposees:
            raise forms.ValidationError(
                _("La devise est un code ISO à trois lettres parmi : %(devises)s.")
                % {"devises": ", ".join(sorted(devises_proposees))}
            )
        return devise

    def clean_free_shipping_from(self):
        valeur = self.cleaned_data.get("free_shipping_from")
        if valeur is not None and valeur < 0:
            raise forms.ValidationError(_("Le seuil de livraison offerte ne peut pas être négatif."))
        return valeur


class DeliveryZoneForm(forms.ModelForm):
    class Meta:
        model = DeliveryZone
        fields = (
            "code",
            "name",
            "country_codes",
            "postal_code_prefixes",
            "price_ttc",
            "free_from",
            "is_active",
            "position",
        )
        widgets = {
            "price_ttc": forms.NumberInput(attrs={"step": "0.01", "min": "0"}),
            "free_from": forms.NumberInput(attrs={"step": "0.01", "min": "0"}),
            "position": forms.NumberInput(attrs={"min": "0"}),
        }

    def clean_code(self):
        from django.utils.text import slugify
        return slugify(self.cleaned_data.get("code") or "")

    @staticmethod
    def _liste_normalisee(valeur, *, postal=False):
        elements = [
            element.strip().upper()
            for element in (valeur or "").replace(";", ",").split(",")
            if element.strip()
        ]
        if postal:
            pattern = re.compile(r"^[A-Z0-9 -]+$")
            invalides = [element for element in elements if not pattern.match(element)]
        else:
            invalides = [
                element for element in elements
                if element != "*" and (len(element) != 2 or not element.isalpha())
            ]
        if invalides:
            raise forms.ValidationError(
                _("Utilisez des valeurs séparées par des virgules ; les codes pays "
                "doivent être ISO à deux lettres.")
            )
        return ", ".join(dict.fromkeys(elements))

    def clean_country_codes(self):
        valeur = self._liste_normalisee(self.cleaned_data.get("country_codes"))
        if not valeur:
            raise forms.ValidationError(_("Indiquez au moins un pays ou * pour tous les pays."))
        return valeur

    def clean_postal_code_prefixes(self):
        return self._liste_normalisee(
            self.cleaned_data.get("postal_code_prefixes"), postal=True
        )

    def clean_price_ttc(self):
        valeur = self.cleaned_data.get("price_ttc")
        if valeur is not None and valeur < 0:
            raise forms.ValidationError(_("Les frais de livraison ne peuvent pas être négatifs."))
        return valeur

    def clean_free_from(self):
        valeur = self.cleaned_data.get("free_from")
        if valeur is not None and valeur < 0:
            raise forms.ValidationError(_("Le seuil de gratuité ne peut pas être négatif."))
        return valeur
