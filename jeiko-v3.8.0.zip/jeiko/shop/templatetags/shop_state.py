from django import template

from .. import state

register = template.Library()


@register.simple_tag
def boutique_en_ligne():
    """Expose l'état de la boutique aux gabarits publics (bouton « panier »)."""
    return state.shop_is_online()


@register.simple_tag
def panier_au_menu():
    """Vrai si le menu du site montre l'icône du panier — voir `state.panier_au_menu`."""
    return state.panier_au_menu()
