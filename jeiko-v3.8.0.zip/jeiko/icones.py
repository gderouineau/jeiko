# jeiko/icones.py
"""
Les icônes des boutons, dessinées en SVG dans la page (28/09/2026).

Les champs « icône à gauche / à droite » d'un bouton attendaient une classe
FontAwesome. Le kit n'étant plus chargé nulle part (R-06), ces icônes ne
s'affichaient plus. Elles sont maintenant choisies dans ce catalogue et
dessinées dans le bouton lui-même : visibles partout, sans rien importer.

Un code, un libellé, un tracé (grille 24×24, trait `currentColor`).
"""

from django.utils.html import format_html
from django.utils.safestring import mark_safe

ICONES = {
    "fleche-droite": ("Flèche vers la droite", '<path d="M5 12h14M13 6l6 6-6 6"/>'),
    "fleche-gauche": ("Flèche vers la gauche", '<path d="M19 12H5M11 6l-6 6 6 6"/>'),
    "chevron-droite": ("Chevron", '<path d="m9 6 6 6-6 6"/>'),
    "coche": ("Coche", '<path d="M5 12.5 9.5 17 19 7"/>'),
    "telechargement": ("Téléchargement", '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>'),
    "lien-externe": ("Lien externe",
                     '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>'),
    "telephone": ("Téléphone",
                  '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 '
                  '19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 '
                  '2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2Z"/>'),
    "email": ("E-mail", '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>'),
    "calendrier": ("Calendrier", '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>'),
    "panier": ("Panier",
               '<path d="M3 4h2l2.4 11.2a1.5 1.5 0 0 0 1.5 1.2h8.7a1.5 1.5 0 0 0 1.4-1.1L21 8H6.2"/>'
               '<circle cx="9" cy="20" r="1.3"/><circle cx="17" cy="20" r="1.3"/>'),
    "lecture": ("Lecture (vidéo)", '<path d="M7 4v16l13-8Z"/>'),
    "plus": ("Plus", '<path d="M12 5v14M5 12h14"/>'),
    "utilisateur": ("Utilisateur", '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'),
    "localisation": ("Localisation",
                     '<path d="M12 22s7-6.2 7-12a7 7 0 0 0-14 0c0 5.8 7 12 7 12Z"/><circle cx="12" cy="10" r="2.5"/>'),
    "etoile": ("Étoile",
               '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3l-5.6 2.9 1.1-6.2L3 9.6l6.2-.9Z"/>'),
    "coeur": ("Cœur", '<path d="M12 20s-7-4.4-9.3-9A5 5 0 0 1 12 6a5 5 0 0 1 9.3 5c-2.3 4.6-9.3 9-9.3 9Z"/>'),
    "info": ("Information", '<circle cx="12" cy="12" r="10"/><path d="M12 11v6M12 7.5h.01"/>'),
}

#: Pour le formulaire et le modèle.
CHOIX = [(code, libelle) for code, (libelle, _) in ICONES.items()]

#: Les noms FontAwesome les plus courants, vers notre catalogue.
DEPUIS_FONTAWESOME = {
    "arrow-right": "fleche-droite", "arrow-left": "fleche-gauche",
    "chevron-right": "chevron-droite", "angle-right": "chevron-droite",
    "check": "coche", "circle-check": "coche", "check-circle": "coche",
    "download": "telechargement",
    "arrow-up-right-from-square": "lien-externe", "external-link": "lien-externe",
    "external-link-alt": "lien-externe", "up-right-from-square": "lien-externe",
    "phone": "telephone", "phone-alt": "telephone", "phone-flip": "telephone",
    "envelope": "email", "envelope-open": "email",
    "calendar": "calendrier", "calendar-alt": "calendrier", "calendar-days": "calendrier",
    "calendar-check": "calendrier",
    "cart-shopping": "panier", "shopping-cart": "panier", "basket-shopping": "panier",
    "play": "lecture", "circle-play": "lecture", "play-circle": "lecture",
    "plus": "plus", "user": "utilisateur",
    "location-dot": "localisation", "map-marker-alt": "localisation", "map-marker": "localisation",
    "star": "etoile", "heart": "coeur",
    "info": "info", "circle-info": "info", "info-circle": "info",
}


def depuis_fontawesome(valeur):
    """« fa-solid fa-arrow-right » → « fleche-droite » ; None si rien ne correspond."""
    for morceau in str(valeur or "").split():
        if morceau.startswith("fa-") and morceau[3:] in DEPUIS_FONTAWESOME:
            return DEPUIS_FONTAWESOME[morceau[3:]]
    if valeur in ICONES:
        return valeur
    return None


def svg(code, classe="jk-ic-bouton"):
    """Le SVG de l'icône, prêt à insérer ; chaîne vide si le code est inconnu."""
    if code not in ICONES:
        return ""
    return format_html(
        '<svg class="{}" viewBox="0 0 24 24" width="1em" height="1em" fill="none" '
        'stroke="currentColor" stroke-width="2" stroke-linecap="round" '
        'stroke-linejoin="round" aria-hidden="true" focusable="false">{}</svg>',
        classe, mark_safe(ICONES[code][1]),
    )
