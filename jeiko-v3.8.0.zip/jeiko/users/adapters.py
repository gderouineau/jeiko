# jeiko/users/adapters.py
"""
Adaptateur de compte allauth.

allauth compose ses e-mails transactionnels à partir de gabarits `.txt`/`.html`
livrés dans le package. On surcharge ici les points d'extension documentés qui
donnent un accès typé à l'utilisateur et au lien, pour rediriger ces envois vers
le catalogue emailing éditable en back-office.

  - `send_password_reset_mail`  → password_reset_request
  - `send_confirmation_mail`    → account_email_verify (inscription)
                                  / email_change_confirm (changement d'adresse)

Les notifications de sécurité (mot de passe modifié, alerte de changement
d'adresse) passent, elles, par les signaux allauth (voir `signals.py`) : elles
ne dépendent pas de ces méthodes.

En cas d'imprévu, on retombe sur le comportement natif d'allauth pour ne jamais
priver l'utilisateur d'un mail critique (réinitialisation, confirmation).
"""

import logging

from allauth.account import app_settings as allauth_settings
from allauth.account.adapter import DefaultAccountAdapter
from allauth.socialaccount.adapter import DefaultSocialAccountAdapter

from jeiko.users import emailing

logger = logging.getLogger(__name__)


#: Clé de session portant le compte à qui l'on vient d'envoyer un lien de
#: confirmation. Sert au bouton « Renvoyer l'e-mail » de l'écran d'attente.
SESSION_A_CONFIRMER = "jeiko_email_a_confirmer"

#: Attribut posé sur la requête : le lien de confirmation est-il parti ?
#: `send_confirmation_mail` ne peut rien renvoyer à allauth, qui ignore sa
#: valeur de retour ; c'est par la requête que l'écran de renvoi l'apprend.
REQUETE_CONFIRMATION_PARTIE = "_jeiko_confirmation_partie"


def _mfa_allauth_active(user):
    """Vrai si le compte a une méthode d'allauth.mfa en service.

    Faux si l'application n'est pas installée (settings d'un site non
    encore mis à jour) : le code par e-mail reste alors la seule protection,
    et ne doit surtout pas sauter.
    """
    from django.apps import apps

    if not apps.is_installed("allauth.mfa"):
        return False
    from allauth.mfa.utils import is_mfa_enabled

    return bool(user and getattr(user, "pk", None) and is_mfa_enabled(user))


class JeikoAccountAdapter(DefaultAccountAdapter):

    def respond_email_verification_sent(self, request, user):
        """
        Retient QUI attend une confirmation, le temps de la session.

        L'écran « vérifiez votre adresse » d'allauth ne reçoit aucun contexte :
        il ne sait pas de quelle adresse il parle, et ne peut donc rien
        proposer d'autre que d'attendre. Une personne dont l'e-mail n'arrive
        pas — boîte pleine, filtre anti-spam, message effacé par mégarde — n'a
        aucun moyen d'en redemander un, sinon retenter une connexion en
        espérant que ça renvoie quelque chose.

        On dépose l'identifiant du compte en session pour que l'écran puisse
        offrir un bouton de renvoi. L'identifiant, pas l'adresse : la session
        est signée mais lisible côté client, et il n'y a aucune raison d'y
        écrire une adresse e-mail.

        Rien ici ne divulgue quoi que ce soit : on ne retient que ce que le
        visiteur vient lui-même de saisir.
        """
        if user is not None and getattr(user, "pk", None):
            request.session[SESSION_A_CONFIRMER] = user.pk
        return super().respond_email_verification_sent(request, user)

    def pre_login(self, request, user, **kwargs):
        """
        Interpose le second facteur entre le mot de passe et la session.

        `pre_login` est le seul endroit qui voit passer TOUTES les connexions —
        formulaire, connexion sociale, connexion programmée après inscription.
        Le placer ici évite qu'un chemin d'entrée oublié contourne la
        vérification, ce qui est précisément le genre de trou qu'on ne découvre
        qu'après.

        Renvoyer une réponse interrompt la connexion : allauth n'ouvre pas la
        session. L'utilisateur est mis en attente, identifié seulement par ce
        que porte sa session côté serveur.
        """
        reponse = super().pre_login(request, user, **kwargs)
        if reponse is not None:
            return reponse

        from django.shortcuts import redirect
        from django.urls import NoReverseMatch, reverse

        from jeiko.users import twofactor

        # Second passage, après saisie du bon code : on laisse faire.
        if request.session.pop(twofactor.SESSION_PASSED_KEY, False):
            return None

        # Jamais deux seconds facteurs (28/09/2026). Un compte qui a activé
        # une méthode d'allauth.mfa — application, clé, passkey — passe par
        # l'étape d'allauth, plus forte que le code par e-mail : ajouter
        # celui-ci demanderait deux codes à chaque connexion, pour rien.
        if _mfa_allauth_active(user):
            return None

        device = twofactor.get_active_device(user)
        if device is None:
            return None

        try:
            url = reverse("jeiko_allauth:twofa_verify")
        except NoReverseMatch:
            # Sans écran de saisie, exiger un code enfermerait tout le monde
            # dehors. On préfère journaliser bruyamment et laisser entrer.
            logger.error(
                "2FA active pour %s mais l'écran de saisie est introuvable : "
                "connexion autorisée sans second facteur.", user.pk,
            )
            return None

        request.session[twofactor.SESSION_USER_KEY] = user.pk
        request.session[twofactor.SESSION_BACKEND_KEY] = getattr(
            user, "backend", "django.contrib.auth.backends.ModelBackend"
        )
        # `redirect_url` porte la destination demandée avant la connexion.
        suite = kwargs.get("redirect_url")
        if suite:
            request.session["jeiko_2fa_next"] = suite

        twofactor.send_code(device, request)
        return redirect(url)

    # --- Après connexion, inscription, déconnexion : l'accueil DU LECTEUR ---
    #
    # `LOGIN_REDIRECT_URL` et `LOGOUT_REDIRECT_URL` valent « / ». Sur un site
    # en plusieurs langues, « / » est l'accueil de la langue d'origine : un
    # visiteur anglais qui se connecte y perdait sa langue — la page lue
    # ensuite la lui fait oublier. On ne touche qu'à ce repli-là : une
    # destination demandée (`?next=`) ou réglée autrement est rendue telle
    # quelle.
    @staticmethod
    def _accueil_du_lecteur(url):
        from jeiko.langues_du_site import accueil
        return accueil() if url == "/" else url

    def get_login_redirect_url(self, request):
        return self._accueil_du_lecteur(super().get_login_redirect_url(request))

    def get_signup_redirect_url(self, request):
        return self._accueil_du_lecteur(super().get_signup_redirect_url(request))

    def get_logout_redirect_url(self, request):
        return self._accueil_du_lecteur(super().get_logout_redirect_url(request))

    def send_password_reset_mail(self, user, email, context):
        url = context.get("password_reset_url")
        if url:
            try:
                emailing.send_password_reset(user, email, url, self.request)
                return
            except Exception:
                logger.exception("Repli allauth pour password_reset_request")
        return super().send_password_reset_mail(user, email, context)

    def send_confirmation_mail(self, request, emailconfirmation, signup):
        # En vérification par code (pas de lien), on laisse allauth gérer.
        if allauth_settings.EMAIL_VERIFICATION_BY_CODE_ENABLED:
            return super().send_confirmation_mail(request, emailconfirmation, signup)

        email_address = emailconfirmation.email_address
        url = self.get_email_confirmation_url(request, emailconfirmation)
        if url:
            try:
                user = email_address.user
                if signup:
                    envoye, _erreur = emailing.send_email_verification(
                        user, email_address.email, url
                    )
                else:
                    envoye, _erreur = emailing.send_email_change_confirm(
                        user, email_address.email, url
                    )
                # Un échec est déjà journalisé en erreur par le catalogue
                # (e-mail obligatoire) et tracé dans EmailLog. On ne retombe
                # PAS sur l'envoi d'allauth : il passerait par la connexion
                # globale de Django, sans hôte configuré sur un site installé
                # — c'est précisément le défaut S-22. On le signale seulement.
                if request is not None:
                    setattr(request, REQUETE_CONFIRMATION_PARTIE, bool(envoye))
                return
            except Exception:
                logger.exception("Repli allauth pour la confirmation d'adresse")
        return super().send_confirmation_mail(request, emailconfirmation, signup)


class JeikoSocialAccountAdapter(DefaultSocialAccountAdapter):
    """
    Fournit à allauth les secrets des connexions sociales, déchiffrés en mémoire.

    Fable 1 §1.5. Les secrets OAuth (Client Secret, clé privée Apple .p8) sont
    saisis dans Réglages ▸ Connexions sociales et rangés chiffrés dans
    `administration.SocialProvider`. `sync_to_allauth` les recopiait en clair
    dans `socialaccount_socialapp` : un dump de la base suffisait pour se faire
    passer pour le site auprès de Google, Apple ou Facebook.

    Le `SocialApp` garde tout ce qui n'est pas secret — fournisseur, Client ID,
    Team ID, rattachement au site (c'est lui qui affiche ou masque le bouton).
    Les secrets sont posés ici sur l'instance, jamais enregistrés.

    Ce que ça ne couvre pas : un `SocialApp` saisi directement dans le Django
    admin, hors de l'écran de JEIKO, garde ce qu'on y a mis ; il est rendu tel
    quel.
    """

    def list_apps(self, request, provider=None, client_id=None):
        apps = super().list_apps(request, provider=provider, client_id=client_id)
        if not apps:
            return apps

        from jeiko.administration.models import SocialProvider

        configs = {
            c.provider: c
            for c in SocialProvider.objects.filter(provider__in={a.provider for a in apps})
        }
        for app in apps:
            config = configs.get(app.provider)
            if config is None or app.pk is None:
                continue
            app.secret = config.secret
            if config.provider == SocialProvider.PROVIDER_APPLE:
                app.settings = {**(app.settings or {}), "certificate_key": config.certificate_key}
        return apps
