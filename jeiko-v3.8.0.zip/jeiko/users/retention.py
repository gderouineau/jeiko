"""
Durées de conservation du journal de sécurité et des sessions (R-05, 28/09/2026).

Pourquoi
--------
`SecurityEvent` et `UserSession` portent une adresse IP et un navigateur par
ligne : ce sont des données personnelles. Rien ne les retirait jamais — une
connexion de 2023 restait lisible, IP comprise, aussi longtemps que le site.
Le RGPD veut une durée proportionnée à la finalité (art. 5-1-e) ; pour une
journalisation de sécurité, la CNIL recommande de six mois à un an.

Les durées
----------
- **Journal de sécurité : 365 jours** (`JEIKO_SECURITY_EVENTS_RETENTION_DAYS`).
  Un an couvre le temps de s'apercevoir d'une intrusion et de la remonter.
  Exception : les preuves d'effacement (`ACCOUNT_ERASED`) sont gardées. Elles
  ne contiennent aucune donnée personnelle — le compte est une coquille vide,
  l'IP est retirée — et elles démontrent qu'une demande a été honorée.
- **Sessions fermées : 30 jours** (`JEIKO_USER_SESSIONS_RETENTION_DAYS`).
  Une session révoquée ou expirée ne sert plus qu'à répondre « d'où me
  suis-je connecté récemment ? ».
- **Sessions ouvertes** : retirées quand elles ne peuvent plus servir, c'est-à-
  dire après la durée de vie du cookie de session (`SESSION_COOKIE_AGE`) plus
  la même marge. Jamais avant : l'écran « se déconnecter partout » doit voir
  toute session encore utilisable.
- **Sessions Django expirées** (`django_session`) : `clearsessions` n'était
  appelé nulle part. Chaque visite connectée laissait une ligne pour toujours.
"""

from datetime import timedelta

from django.conf import settings
from django.utils import timezone

JOURNAL_PAR_DEFAUT = 365
SESSIONS_PAR_DEFAUT = 30


def _jours(nom, defaut):
    try:
        return max(1, int(getattr(settings, nom, defaut)))
    except (TypeError, ValueError):
        return defaut


def purger_le_journal_de_securite(maintenant=None):
    """Supprime les événements au-delà du délai, sauf les preuves d'effacement."""
    from .models import SecurityEvent, SecurityEventType

    maintenant = maintenant or timezone.now()
    limite = maintenant - timedelta(days=_jours("JEIKO_SECURITY_EVENTS_RETENTION_DAYS", JOURNAL_PAR_DEFAUT))
    return (
        SecurityEvent.objects.filter(occured_at__lt=limite)
        .exclude(event_type=SecurityEventType.ACCOUNT_ERASED)
        .delete()[0]
    )


def purger_les_sessions(maintenant=None):
    """Supprime les sessions fermées au-delà du délai, et celles qui ne peuvent plus servir."""
    from django.db.models import Q

    from .models import UserSession

    maintenant = maintenant or timezone.now()
    marge = timedelta(days=_jours("JEIKO_USER_SESSIONS_RETENTION_DAYS", SESSIONS_PAR_DEFAUT))
    vie_du_cookie = timedelta(seconds=int(getattr(settings, "SESSION_COOKIE_AGE", 1209600)))
    return UserSession.objects.filter(
        Q(is_active=False, last_seen__lt=maintenant - marge)
        | Q(last_seen__lt=maintenant - vie_du_cookie - marge)
    ).delete()[0]


def purger_les_sessions_django():
    """`clearsessions` : retire les sessions expirées du moteur de sessions."""
    from django.core.management import call_command

    call_command("clearsessions", verbosity=0)
