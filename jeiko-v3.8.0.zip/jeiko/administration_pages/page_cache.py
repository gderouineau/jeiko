"""
Cache du corps des pages publiques (le fragment ``#content``).

Le rendu de l'arbre section > ligne > bloc, avec un bloc ``<style>`` inline par
élément, est identique d'une requête à l'autre tant que la page (et, pour une
fiche d'objet custom, l'objet) ne change pas. C'est la partie coûteuse du rendu.
On met donc en cache ce fragment.

Deux propriétés du rendu public rendent la clé simple et sûre :

- **Indépendant du device** : ``mq_to_cq`` (templatetags/editor_responsive.py)
  ne duplique les media-queries en container-queries que dans le namespace
  éditeur. Sur le site public le CSS sort tel quel → même HTML mobile/desktop.
- **Indépendant de l'utilisateur** : les tokens ``[% code %]`` se résolvent
  depuis ``build_object_context(obj)`` (custom_objects/services.py), c.-à-d.
  depuis l'OBJET affiché, jamais depuis ``request.user``.

La clé n'a donc besoin que de l'identité (page, et objet le cas échéant) et d'une
**version** incrémentée à chaque modification de l'arbre. L'incrément est branché
sur ``signals._flush_pending_pages`` : la même infrastructure qui recalcule déjà
le héros une fois par page et par commit (dédupliquée) invalide ici le cache.

Ce qui reste HORS cache (déterminé par ``page_is_cacheable``) :
- un bloc ``FORM`` : il rend ``{% csrf_token %}``, un jeton lié au secret CSRF
  du visiteur ; le figer casserait l'envoi pour tous les autres ;
- un bloc ``CALENDAR`` : les créneaux dépendent des réservations (temps réel).

Les vues de résultats de questionnaire (chart_data_json par session) n'activent
tout simplement pas le cache : elles ne passent pas ``page_cache_enabled``.

Ce que le corps montre d'AUTRES objets que la page (Q-18)
---------------------------------------------------------
« Une version par page suffit » suppose que le corps ne montre que la page.
Une grille ou un carrousel de ressources (``DYN_RESOURCE_GRID``,
``DYN_RESOURCE_CAROUSEL``) fait exception : il ne porte aucun contenu, il LISTE
des fiches, des produits, des pages ou des questionnaires. En publier un ne
touche pas la page : la grille restait figée jusqu'à sept jours, sans erreur
ni rien pour le dire — alors que le guide des agents promet qu'une nouvelle
fiche y apparaît d'elle-même.

La clé d'une page à grille porte donc en plus une **version des ressources**
(``resources_version``), incrémentée dès qu'un des modèles de
``RESOURCE_MODELS`` est enregistré ou supprimé. Les pages SANS grille ne sont
pas concernées : leur clé ne change pas, elles ne lisent pas le compteur.

Ce que ça ne résout pas :
- ``QuerySet.update()`` et ``bulk_create()`` n'émettent aucun signal : qui
  écrit une ressource ainsi appelle ``bump_resources_version()`` lui-même ;
- hors des grilles, le corps montre encore d'autres objets que la page, et
  rien ne l'invalide quand ils changent : l'image d'un bloc dont on remplace
  le fichier (PLAN_ACTION, Q-19) et, sur un site monolingue, l'adresse d'une
  page renommée vers laquelle mène un bouton (Q-20).
"""

import time

from django.core.cache import cache
from django.db import transaction

# Compteur de version par page. Sans expiration : c'est un entier, pas une donnée
# lourde. Le fragment, lui, porte un TTL de garde ci-dessous.
_VERSION_KEY = "jeiko:page_body:ver:{page_id}"

# Idem pour une fiche d'objet custom. Nécessaire car CustomObjectValue n'a AUCUN
# timestamp et CustomObject.date_updated ne bouge qu'au save() du parent : on ne
# peut pas se fier à une date. Le compteur est bumpé par signal sur CustomObject
# et CustomObjectValue (custom_objects/signals.py).
_OBJ_VERSION_KEY = "jeiko:co_body:ver:{obj_id}"

# TTL de garde du fragment. La version invalide bien avant en cas d'édition ; ce
# TTL ne sert que de filet (éviction, cohérence après un éventuel reset du
# compteur sous pression mémoire).
PAGE_BODY_TTL = 60 * 60 * 24 * 7  # 7 jours

# Types de contenu qui interdisent la mise en cache du corps de page.
UNCACHEABLE_CONTENT_TYPES = frozenset({"FORM", "CALENDAR"})

# Types de contenu qui ne portent rien : ils LISTENT des ressources du site
# (templatetags/dynamic_resources.py). Une page qui en contient un porte la
# version des ressources dans sa clé — voir ``public_page_vary``.
RESOURCE_CONTENT_TYPES = frozenset({"DYN_RESOURCE_GRID", "DYN_RESOURCE_CAROUSEL"})

# Tout ce qu'une CARTE de grille montre — pas seulement ce que la grille
# liste. Enregistrer ou supprimer l'un de ces modèles invalide les pages à
# grille (branché dans signals.py). Par NOM : la boutique et les
# questionnaires importent ce module, pas l'inverse — et un site qui n'installe
# pas l'un d'eux n'a rien à brancher.
#
# Ajouter une source à ``get_resources``, ou un champ à une carte, c'est
# compléter cette liste : sinon la grille reste figée, et rien ne le dit.
RESOURCE_MODELS = (
    # Ce que les grilles listent.
    "custom_objects.CustomObject",        # une fiche — et le titre, l'image, la publication d'un produit
    "shop.Product",                       # mise en vente, référence (dans l'adresse)
    "administration_pages.Page",
    "questionnaires_expert.ExpertTest",
    # La description d'une carte : un modèle à part, que l'API des agents
    # enregistre sans réenregistrer ni la fiche ni la page.
    "custom_objects.CustomObjectMetadata",
    "administration_pages.Metadata",
    # L'adresse d'une carte : /co/<modèle>/…, /shop/<type>/…, /<catégorie>/…
    "custom_objects.CustomObjectModel",
    "shop.ProductType",
    "administration_pages.Category",
    # L'image d'une carte : ses variantes arrivent APRÈS l'enregistrement
    # (JEIKO_IMAGES_ASYNC), et remplacer son fichier efface les anciennes.
    "administration_pages.ImageContent",
)


def page_body_version(page_id) -> int:
    """Version courante du corps de la page (crée le compteur à 1 au besoin)."""
    if not page_id:
        return 0
    key = _VERSION_KEY.format(page_id=page_id)
    ver = cache.get(key)
    if ver is None:
        ver = 1
        cache.set(key, ver, None)
    return ver


def bump_page_body_version(page_id) -> None:
    """Invalide le corps de la page (appelé à chaque changement de l'arbre)."""
    if not page_id:
        return
    key = _VERSION_KEY.format(page_id=page_id)
    try:
        cache.incr(key)
    except ValueError:
        # Clé absente (jamais lue ou évincée) : un lecteur repartirait de 1, donc
        # on force >= 2 pour ne pas réutiliser une version déjà servie.
        cache.set(key, 2, None)


def object_body_version(obj_id) -> int:
    """Version courante d'une fiche d'objet custom (crée le compteur à 1)."""
    if not obj_id:
        return 0
    key = _OBJ_VERSION_KEY.format(obj_id=obj_id)
    ver = cache.get(key)
    if ver is None:
        ver = 1
        cache.set(key, ver, None)
    return ver


def bump_object_body_version(obj_id) -> None:
    """Invalide la fiche d'un objet custom (édition de l'objet ou d'une valeur)."""
    if not obj_id:
        return
    key = _OBJ_VERSION_KEY.format(obj_id=obj_id)
    try:
        cache.incr(key)
    except ValueError:
        cache.set(key, 2, None)


_LINKS_VERSION_KEY = "jeiko:page_body:liens"


def links_version() -> int:
    """Version des adresses du site : change quand une page ou une catégorie change."""
    ver = cache.get(_LINKS_VERSION_KEY)
    if ver is None:
        ver = 1
        cache.set(_LINKS_VERSION_KEY, ver, None)
    return ver


def bump_links_version(*args, **kwargs) -> None:
    """
    Invalide les liens gardés dans les corps de page (signature de récepteur
    de signal). Grossier — toutes les pages d'un coup — mais une page ou une
    catégorie s'enregistre rarement, et savoir qui pointe vers qui demanderait
    de relire tous les boutons du site.
    """
    try:
        cache.incr(_LINKS_VERSION_KEY)
    except ValueError:
        cache.set(_LINKS_VERSION_KEY, 2, None)


_RESOURCES_VERSION_KEY = "jeiko:page_body:ressources"


def resources_version() -> int:
    """Version des ressources listées par les grilles et les carrousels."""
    ver = cache.get(_RESOURCES_VERSION_KEY)
    if ver is None:
        # L'heure et non 1 : si memcached évince ce compteur, il repart
        # au-dessus de toutes les valeurs déjà servies. Reparti de 1, il
        # retrouverait la clé d'un ancien corps — et le resservirait.
        ver = int(time.time())
        cache.set(_RESOURCES_VERSION_KEY, ver, None)
    return ver


def _incrementer_les_ressources() -> None:
    try:
        cache.incr(_RESOURCES_VERSION_KEY)
    except ValueError:
        cache.set(_RESOURCES_VERSION_KEY, int(time.time()), None)


def bump_resources_version(*args, using=None, **kwargs) -> None:
    """
    Invalide les pages à grille (signature de récepteur de signal). Grossier —
    toutes les pages à grille d'un coup, quoi qu'elles listent — mais savoir
    quelle grille montre quoi demanderait de rejouer ses filtres à chaque
    écriture.

    Un produit est enregistré à CHAQUE commande (décrément du stock,
    ``shop/services.py``) : c'est pour cela que seules les pages à grille
    portent cette version, et pas tout le site.

    Au COMMIT, et non à l'enregistrement : incrémenter pendant la transaction
    laisserait une autre requête lire la nouvelle version, rendre la grille
    avec les anciennes données — l'écriture n'est pas encore visible — et
    ranger ce rendu périmé sous la nouvelle clé, pour sept jours.

    ``robust`` : ce récepteur est sur le chemin d'une commande payée. Un cache
    en panne ne doit jamais la faire échouer ; l'erreur est journalisée.
    """
    # ponytail: chaque commande fait rendre une fois les pages à grille. Si
    # une boutique le paie, ignorer ici les `update_fields` qui ne portent que
    # le stock — tant qu'aucune carte n'affiche la disponibilité.
    transaction.on_commit(_incrementer_les_ressources, using=using, robust=True)


def _content_types(page) -> set:
    """
    Les types de contenu présents dans l'arbre. Parcourt l'arbre déjà
    préchargé par ``with_page_tree`` : aucune requête supplémentaire.
    """
    return {
        getattr(getattr(bloc, "content", None), "content_type", None)
        for section in page.sections.all()
        for line in section.lines.all()
        for bloc in line.blocs.all()
    }


def page_is_cacheable(page) -> bool:
    """
    True si aucun bloc de l'arbre n'est per-requête (FORM) ou temps réel
    (CALENDAR).
    """
    return not (_content_types(page) & UNCACHEABLE_CONTENT_TYPES)


def public_page_vary(page, obj=None) -> str:
    """
    Construit la chaîne ``vary_on`` unique du ``{% cache %}`` : identité + version.

    Pour une fiche d'objet custom, ``obj`` ajoute son id et sa version propre :
    - une édition de l'objet (ou d'une de ses valeurs) bumpe la version objet
      → nouvelle clé, contenu à jour ;
    - une édition du gabarit bumpe la version de la page → nouvelle clé pour
      TOUTES ses fiches, sans avoir à les énumérer.
    """
    parts = [str(page.id), str(page_body_version(page.id))]
    if obj is not None:
        parts += ["co", str(obj.pk), str(object_body_version(obj.pk))]
    # Grille ou carrousel de ressources : le corps liste des objets que la
    # version de la page ignore. Les SEULES pages à porter cette version —
    # une page sans grille ne lit même pas le compteur.
    if _content_types(page) & RESOURCE_CONTENT_TYPES:
        parts += ["r", str(resources_version())]
    # Site en plusieurs langues : le corps contient des liens, et un lien suit
    # la langue du lecteur. Une page d'origine lue sous /en/ n'a donc pas le
    # même HTML que sous / — et il change encore le jour où sa cible est
    # traduite, d'où la version des liens. Un site monolingue garde sa clé.
    from jeiko.langues_du_site import langue_du_site, langues_actives
    langue = langue_du_site()
    if langue is not None and langues_actives():
        parts += ["l", langue or "-", str(links_version())]
    return ":".join(parts)


def build_page_cache_context(page, obj=None) -> dict:
    """
    Renvoie les variables de contexte attendues par ``pages/main.html`` :
    ``page_cache_enabled`` (bool), ``page_cache_vary`` (str) et
    ``page_cache_ttl`` (int).

    Une vue qui ne veut jamais cacher (résultats de questionnaire) n'appelle
    simplement pas ce helper.
    """
    if not page_is_cacheable(page):
        return {"page_cache_enabled": False}
    return {
        "page_cache_enabled": True,
        "page_cache_vary": public_page_vary(page, obj=obj),
        "page_cache_ttl": PAGE_BODY_TTL,
    }
