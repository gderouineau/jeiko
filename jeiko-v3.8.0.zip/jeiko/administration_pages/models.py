from django.db import models

from jeiko.horodatage import HorodatageFiable
from jeiko.icones import CHOIX as ICONES_BOUTON
from django.core.validators import RegexValidator
import os
from django.utils import timezone
from django.db.models import UniqueConstraint, Q
from PIL import Image, ImageOps
from io import BytesIO
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator

from jeiko.uploads import valider_l_image
from django.conf import settings
import time
from uuid import uuid4

from decimal import Decimal
import re
from copy import deepcopy

from jeiko.calendars.models import AppointmentType, Appointment, Availability



from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils.text import slugify
from django.utils.translation import gettext_lazy as _

alphanumeric = RegexValidator(
    r'^[A-Za-z0-9_-]+$',
    _('Seules les lettres (A–Z/a–z), chiffres (0–9), tirets (-) et underscores (_) sont autorisés.')
)

class Category(models.Model):
    name = models.CharField(
        max_length=100,

    )

    main_category = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name="sub_categories"
    )

    hidden_slug = models.CharField(
        default="",
        null=True,
        blank=True,

    )

    slug = models.SlugField(
        max_length=120,
        blank=True,
        null=True,  # ⇐ important
        default=None,  # ⇐ important
        db_index=True,
        help_text=_("Laisser vide pour auto-générer depuis le nom.")
    )

    show_cat_in_url = models.BooleanField(
        default=False,
        help_text=_("Si activé pour une sous-catégorie, le parent doit aussi l’être.")
    )

    is_protected = models.BooleanField(
        default=False,
    )

    main_menu = models.ForeignKey(
        'administration_menu.Menu',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='categories_main_menu'
    )
    footer_menu = models.ForeignKey(
        'administration_menu.Menu',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='categories_footer_menu'
    )

    # Le nom et le slug dans les autres langues du site :
    # {"en": {"name": "Services", "slug": "our-services"}}. UNE catégorie pour
    # toutes les langues, et non une par langue : c'est ce qui laisse la
    # version anglaise d'une page hériter du menu de sa catégorie. Une langue
    # absente retombe sur le nom et le slug d'origine — voir jeiko/langues_du_site.py.
    traductions = models.JSONField(default=dict, blank=True)

    class Meta:
        constraints = [
            # Le NOM est unique là où deux catégories seraient confondues : au
            # même niveau. Pas dans tout le site.
            #
            # Une contrainte globale interdisait « Actualités » sous
            # « Formations » ET sous « Coaching » — deux rubriques légitimes,
            # qui donnent /formations/actualites/ et /coaching/actualites/.
            # Elle obligeait à écrire « Actualités formations », que le
            # visiteur lit ensuite dans le fil d'Ariane. Les deux contraintes
            # de slug ci-dessous portaient déjà la bonne règle ; celle du nom
            # était plus stricte qu'elles sans raison.
            UniqueConstraint(
                fields=('name',),
                condition=Q(main_category__isnull=True),
                name='uniq_root_category_name',
            ),
            UniqueConstraint(
                fields=('main_category', 'name'),
                condition=Q(main_category__isnull=False),
                name='uniq_subcategory_name_per_parent',
            ),

            # Unicité des slugs de catégories racines, uniquement si slug non NULL
            UniqueConstraint(
                fields=('slug',),
                condition=Q(main_category__isnull=True) & Q(slug__isnull=False),
                name='uniq_root_category_slug',
            ),

            # Unicité (parent, slug) pour sous-catégories, uniquement si slug non NULL
            UniqueConstraint(
                fields=('main_category', 'slug'),
                condition=Q(main_category__isnull=False) & Q(slug__isnull=False),
                name='uniq_subcategory_slug_per_parent',
            ),
        ]

    def __str__(self):
        return self.name

    def slug_pour(self, langue):
        """Le slug dans cette langue ; celui d'origine si elle n'est pas traduite."""
        return ((self.traductions or {}).get(langue) or {}).get("slug") or self.slug

    def nom_pour(self, langue):
        return ((self.traductions or {}).get(langue) or {}).get("name") or self.name

    @property
    def nom_du_site(self):
        """Le nom dans la langue que lit le visiteur — pour les gabarits publics."""
        from jeiko.langues_du_site import langue_du_site
        return self.nom_pour(langue_du_site())

    @staticmethod
    def _is_reserved_root_slug(slug: str) -> bool:
        """Un slug qu'une route du site occupe déjà — codes de langue compris."""
        from jeiko.langues_du_site import est_un_slug_reserve
        return est_un_slug_reserve(slug)

    def clean(self):
        # Normaliser le slug ('' -> None ; slugify si fourni)
        if self.slug:
            self.slug = slugify(self.slug)
            if self.slug == "":
                self.slug = None
        else:
            # Auto-générer depuis le name si non fourni
            auto = slugify(self.name or "")
            self.slug = auto or None

        # Règle: si sous-cat avec show_cat_in_url=True, le parent doit aussi l’avoir
        if self.main_category and self.show_cat_in_url and not getattr(self.main_category, 'show_cat_in_url', False):
            raise ValidationError({
                'show_cat_in_url': _("Le parent doit aussi être « Afficher dans l’URL ».")
            })

        # Vérifs d’unicité amont (messages clairs)
        qs = Category.objects.exclude(pk=self.pk)
        if self.slug:
            if self.main_category is None:
                if qs.filter(main_category__isnull=True, slug=self.slug).exists():
                    raise ValidationError({'slug': _("Slug déjà utilisé par une autre catégorie racine.")})
            else:
                if qs.filter(main_category=self.main_category, slug=self.slug).exists():
                    raise ValidationError({'slug': _("Slug déjà utilisé par une sous-catégorie du même parent.")})

        if self.slug and self.main_category is None and self._is_reserved_root_slug(self.slug):
            raise ValidationError({'slug': _("Ce slug est réservé par le système.")})

        self.verifier_les_traductions()

    def verifier_les_traductions(self):
        """
        Les adresses traduites obéissent aux mêmes règles que les autres,
        langue par langue : pas de slug réservé à la racine, pas deux
        catégories sœurs au même endroit. Lève une `ValidationError` générale
        — et non par champ : `traductions` n'est pas un champ de formulaire.

        « Dans les deux sens » : le slug traduit de celle-ci contre celui
        (traduit ou non) de ses sœurs, ET son slug d'origine contre le slug
        traduit d'une sœur. « Offres » nommée « offers » en anglais et une
        catégorie « offers » se retrouveraient toutes deux en /en/offers/.

        À part de `clean()` : l'API des agents l'appelle seule, sans la
        normalisation du slug que `clean()` fait au passage.
        """
        def traduit(categorie, code):
            return ((categorie.traductions or {}).get(code) or {}).get("slug")

        soeurs = list(
            Category.objects.exclude(pk=self.pk).filter(main_category=self.main_category)
        )
        codes = set(self.traductions or {})
        for soeur in soeurs:
            codes |= set(soeur.traductions or {})
        for code in sorted(codes):
            slug = self.slug_pour(code)
            if not slug:
                continue
            if (traduit(self, code) and self.main_category is None
                    and self._is_reserved_root_slug(slug)):
                raise ValidationError(
                    _("L'adresse « %(slug)s » est réservée par le système.") % {"slug": slug})
            for soeur in soeurs:
                # Deux slugs d'origine identiques : c'est `clean()` qui le refuse.
                if soeur.slug_pour(code) == slug and (traduit(self, code) or traduit(soeur, code)):
                    raise ValidationError(
                        _("L'adresse « %(slug)s » est déjà celle d'une autre catégorie dans cette langue.")
                        % {"slug": slug})

    def save(self, *args, **kwargs):
        # Garantir la même normalisation qu’en clean()
        if not self.slug:
            auto = slugify(self.name or "")
            self.slug = auto or None
        elif self.slug == "":
            self.slug = None
        else:
            self.slug = slugify(self.slug) or None
        super().save(*args, **kwargs)


class Page(models.Model):

    title = models.CharField(
        max_length=100,
        verbose_name=_("Titre"),
    )

    active = models.BooleanField(
        default=False,
    )

    url_tag = models.CharField(
        max_length=100,
        verbose_name=_('Nom de l\'url'),
        validators=[alphanumeric],
        db_index=True,
        help_text=_("Doit éviter les slugs réservés et ceux des catégories."),
    )

    date_created = models.DateTimeField(
        auto_now_add=True,
        blank=True,
    )

    is_root = models.BooleanField(
        default=False,
        db_index=True,
    )

    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='pages_main_category'
    )

    sub_category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='pages_sub_category',
    )

    is_pdf = models.BooleanField(
        default=False,
    )

    is_mail_template = models.BooleanField(
        default=False
    )

    is_custom_object_template = models.BooleanField(
        default=False,
    )

    is_default_legal_template = models.BooleanField(
        default=False,
    )

    show_default_main_menu = models.BooleanField(
        default=True,
    )

    is_protected = models.BooleanField(
        default=False,
    )

    show_default_footer = models.BooleanField(
        default=True,
    )

    google_index = models.BooleanField(
        default=True,
    )

    main_menu = models.ForeignKey(
        'administration_menu.Menu',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='pages_main_menu'
    )
    footer_menu = models.ForeignKey(
        'administration_menu.Menu',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='pages_footer_menu'
    )
    
    main_image = models.ForeignKey(
        'ImageContent',
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='pages_main_image',
        verbose_name=_('Image Principale')
    )

    # --- Site en plusieurs langues (jeiko/langues_du_site.py) ---
    # Vide : la langue d'origine du site. Vide plutôt que « fr » : un site
    # monolingue n'a rien à migrer, et changer `LANGUAGE_CODE` ne laisse pas
    # ses pages étiquetées dans une langue qui n'est plus la sienne.
    langue = models.CharField(max_length=10, blank=True, default="", db_index=True)

    # La page d'origine dont celle-ci est la traduction. CASCADE : supprimer
    # l'originale supprime toutes ses versions — c'est elle qui porte la
    # catégorie et les menus, une traduction orpheline n'aurait plus ni l'un
    # ni l'autre.
    traduction_de = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        null=True, blank=True,
        related_name='traductions',
    )

    #: Ce qu'une traduction tient de son originale. Recopié à chaque
    #: enregistrement de celle-ci : les requêtes qui filtrent par catégorie
    #: (grilles de pages, choix du menu) continuent de marcher sans jointure.
    CHAMPS_COMMUNS_AUX_VERSIONS = (
        'category', 'sub_category', 'main_menu', 'footer_menu',
        'show_default_main_menu', 'show_default_footer',
    )

    class Meta:
        constraints = [
            # Une traduction ne porte jamais `is_root` : elle est l'accueil de
            # sa langue quand son originale l'est (`est_l_accueil`).
            UniqueConstraint(fields=('is_root',), condition=Q(is_root=True), name='only_one_is_root_page'),

            # Les trois unicités d'adresse valent PAR LANGUE : /contact/ et
            # /en/contact/ sont deux adresses, pas une collision.

            # Unicité du url_tag quand pas de catégorie (pages « racine » P0)
            UniqueConstraint(
                fields=('langue', 'url_tag'),
                condition=Q(category__isnull=True),
                name='uniq_url_tag_when_no_category',
            ),

            # Unicité par catégorie pour les pages « cat only » (pas de sous-cat)
            UniqueConstraint(
                fields=('langue', 'category', 'url_tag'),
                condition=Q(category__isnull=False) & Q(sub_category__isnull=True),
                name='uniq_url_tag_per_category_cat_only',
            ),

            # Unicité par (cat, sous-cat) pour les pages « cat + sub »
            UniqueConstraint(
                fields=('langue', 'category', 'sub_category', 'url_tag'),
                condition=Q(category__isnull=False) & Q(sub_category__isnull=False),
                name='uniq_url_tag_per_category_sub',
            ),

            # Une seule version par langue.
            UniqueConstraint(
                fields=('traduction_de', 'langue'),
                condition=Q(traduction_de__isnull=False),
                name='uniq_traduction_par_langue',
            ),
            # Une traduction dit sa langue ; une originale n'en dit pas.
            models.CheckConstraint(
                name='page_traduction_et_langue_vont_ensemble',
                condition=(
                    (Q(traduction_de__isnull=True) & Q(langue=''))
                    | (Q(traduction_de__isnull=False) & ~Q(langue=''))
                ),
            ),
        ]

    def __str__(self):
        return self.title

    @staticmethod
    def _is_reserved_root_slug(slug: str) -> bool:
        """
        Vrai uniquement si le tag entrerait en collision avec une route racine
        réservée — ou avec le préfixe d'une langue (/en/).
        """
        from jeiko.langues_du_site import est_un_slug_reserve
        return est_un_slug_reserve(slug)

    @property
    def est_l_accueil(self):
        """La page d'accueil de sa langue."""
        if self.traduction_de_id:
            return self.traduction_de.is_root
        return self.is_root

    @property
    def origine(self):
        """La page d'origine : elle-même, sauf pour une traduction."""
        return self.traduction_de if self.traduction_de_id else self

    # Ce que `jeiko/langues_du_site.py` demande à tout ce qui a une version par
    # langue — une page ici, une fiche dans `custom_objects` : dire si l'on est
    # en ligne, et rendre les versions en ligne d'une langue.
    @property
    def est_publiee(self):
        return self.active

    @classmethod
    def versions_publiees(cls, langue):
        """Les versions publiées dans `langue`, avec de quoi écrire leur adresse."""
        return cls.objects.filter(langue=langue, active=True).select_related(
            "traduction_de", "category", "sub_category"
        )

    @property
    def langue_servie(self):
        """
        Vrai si le site sert cette version : toujours pour la langue
        d'origine ; pour une traduction, tant que sa langue est activée.
        Publiée ou non, une version d'une langue éteinte ne répond à aucune
        adresse (`querysets.public_pages`).
        """
        if not self.langue:
            return True
        from jeiko.langues_du_site import langues_actives
        return self.langue in langues_actives()

    def versions(self):
        """
        Toutes les versions de la page, l'originale en tête.

        Tri en Python, pas par `order_by` : celui-ci relancerait une requête
        et ignorerait un `prefetch_related("traductions")` — une requête par
        page dans une liste.
        """
        origine = self.origine
        return [origine, *sorted(origine.traductions.all(), key=lambda v: v.langue)]

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if self.traduction_de_id is None and self.pk:
            # Ce qui vient d'être écrit, et rien d'autre : avec `update_fields`,
            # un champ modifié en mémoire mais non enregistré sur l'originale
            # ne doit pas partir sur ses versions.
            ecrits = kwargs.get("update_fields")
            communs = [
                c for c in self.CHAMPS_COMMUNS_AUX_VERSIONS
                if ecrits is None or c in ecrits
            ]
            if communs:
                # `.update()` et non une boucle de `save()` : rien à valider,
                # et un site monolingue n'y perd qu'une requête sans effet.
                Page.objects.filter(traduction_de=self).update(
                    **{c: getattr(self, c) for c in communs}
                )

    def _effective_url_mode(self):
        """
        'global'   : pas de catégorie OU catégorie masquée (show_cat_in_url=False)
        'cat_only' : catégorie visible, pas de sous-catégorie visible
        'cat_sub'  : catégorie + sous-catégorie visibles (et sub est bien enfant de cat)
        """
        cat = self.category
        sub = self.sub_category

        if not cat or not getattr(cat, "show_cat_in_url", False):
            return "global"

        if sub and sub.main_category_id == getattr(cat, "id", None) and getattr(sub, "show_cat_in_url", False):
            return "cat_sub"

        return "cat_only"

    def clean(self):
        from django.core.exceptions import ValidationError
        from django.utils.text import slugify
        from django.db.models import Q

        errors = {}

        # --- Normalisation du tag ---
        self.url_tag = slugify(self.url_tag or "") or None

        # --- Page racine ---


        # --- Présence du tag requise hors root ---
        if not self.url_tag:
            errors['url_tag'] = _("Le tag d’URL est requis pour une page non racine.")

        # --- Cohérence Cat/Sub ---
        cat = self.category
        sub = self.sub_category
        if sub and not cat:
            errors['sub_category'] = _("Sélectionne d’abord une catégorie pour pouvoir choisir une sous-catégorie.")
        if cat and sub and sub.main_category_id != cat.id:
            errors['sub_category'] = _("Cette sous-catégorie n’appartient pas à la catégorie sélectionnée.")

        # --- Conflit avec les slugs de catégories ---
        if self.url_tag and any(
            c.slug_pour(self.langue) == self.url_tag
            for c in Category.objects.only('slug', 'traductions')
        ):
            errors['url_tag'] = _("Ce tag d’URL est déjà utilisé par une catégorie/sous-catégorie.")

        # Stop si erreurs de base
        if errors:
            raise ValidationError(errors)

        # --- Mode effectif d'URL ---
        mode = self._effective_url_mode()

        # --- Slugs réservés (seulement si exposé à la racine) ---
        if mode == "global" and self._is_reserved_root_slug(self.url_tag):
            errors['url_tag'] = _("Ce tag d’URL est réservé par le système (conflit avec une route existante).")

        # --- Unicités logiques (complètent les contraintes DB) ---
        if not errors:
            # Deux langues, deux adresses : on ne compare qu'au sein de la sienne.
            qs = Page.objects.exclude(pk=self.pk).filter(langue=self.langue)
            if mode == "global":
                conflict = qs.filter(url_tag=self.url_tag).filter(
                    Q(category__isnull=True) | Q(category__show_cat_in_url=False)
                ).exists()
                if conflict:
                    errors[
                        'url_tag'] = _("Ce tag d’URL est déjà utilisé par une page exposée à la racine (ou catégorie masquée).")

            elif mode == "cat_only":
                conflict = qs.filter(
                    category=cat, sub_category__isnull=True, url_tag=self.url_tag
                ).exists()
                if conflict:
                    errors['url_tag'] = f"Déjà utilisé par une autre page de la catégorie « {cat.name} »."

            else:  # cat_sub
                conflict = qs.filter(
                    category=cat, sub_category=sub, url_tag=self.url_tag
                ).exists()
                if conflict:
                    errors['url_tag'] = f"Déjà utilisé pour « {cat.name} / {sub.name} »."

        if errors:
            raise ValidationError(errors)

    def adresse_propre(self):
        """
        L'adresse de CETTE version, sans égard pour qui la demande :

          - accueil :                    "/"            ou "/en/"
          - catégorie et sous-catégorie visibles : "/<cat>/<sous-cat>/<url_tag>/"
          - catégorie seule visible :    "/<cat>/<url_tag>/"
          - sinon :                      "/<url_tag>/"

        précédée de "/<langue>" pour une traduction, les slugs de catégorie
        pris dans sa langue.
        """
        return self._adresse(self.langue)

    def _adresse(self, langue):
        prefixe = f"/{langue}" if langue else ""
        if self.est_l_accueil:
            return f"{prefixe}/"

        cat = self.category
        sub = self.sub_category

        # Visibilités (seulement si slug présent)
        cat_visible = bool(
            cat and getattr(cat, "show_cat_in_url", False) and getattr(cat, "slug", None)
        )
        sub_visible = bool(
            sub
            and sub.main_category_id == getattr(cat, "id", None)
            and getattr(sub, "show_cat_in_url", False)
            and getattr(sub, "slug", None)
        )

        if cat_visible and sub_visible:
            return f"{prefixe}/{cat.slug_pour(langue)}/{sub.slug_pour(langue)}/{self.url_tag}/"
        if cat_visible:
            return f"{prefixe}/{cat.slug_pour(langue)}/{self.url_tag}/"
        # Catégorie masquée (ou absente) -> racine
        return f"{prefixe}/{self.url_tag}/"

    def get_absolute_url(self):
        """
        L'adresse à écrire dans un lien vers cette page.

        Hors du site public (administration, API, plan du site) : son adresse
        propre. Pour un visiteur qui lit le site dans une autre langue que
        celle de cette version : l'adresse de la version qu'IL lira — c'est
        ici, et nulle part ailleurs, que menus, pieds de page et boutons
        suivent la langue. Voir jeiko/langues_du_site.py.
        """
        from jeiko.langues_du_site import adresse_pour_le_visiteur
        return adresse_pour_le_visiteur(self)

    @property
    def excerpt(self):
        """Return metadata description or empty string for compatibility with resource templates."""
        if hasattr(self, 'metadata') and self.metadata:
            return self.metadata.description or ""
        return ""


class Metadata(HorodatageFiable):
    # `updated_at` sert de clé au cache du <head> (base.html) : une
    # sauvegarde partielle doit le faire bouger, sinon le titre et la
    # description restent gelés trente jours. Voir jeiko/horodatage.py.
    page = models.OneToOneField(
        Page,
        on_delete=models.CASCADE,
        related_name='metadata',
        null=True,
        blank=True,

    )

    title = models.CharField(

        max_length=100,
        verbose_name=_('Titre'),
        default="",
        null=True,
        blank=True,
    )

    description = models.TextField(
        default="",
        verbose_name=_("Description"),
        null=True,
        blank=True,
    )

    updated_at = models.DateTimeField(
        auto_now=True
    )


class Strategy(models.TextChoices):
    MOBILE = "mobile", _("Mobile")
    DESKTOP = "desktop", _("Desktop")


class InsightStatus(models.TextChoices):
    PENDING = "pending", _("Pending")
    OK = "ok", "OK"
    ERROR = "error", _("Error")


class PageInsights(models.Model):
    """
    Historique des mesures PageSpeed pour une Page donnée et une stratégie (mobile/desktop).
    Un enregistrement par run. On historise pour les graphes et comparaisons.
    """
    # ⚠️ FK: si on supprime la Page -> on supprime les insights (CASCADE).
    # Supprimer un insight ne supprime pas la Page (comportement normal, aucun reverse CASCADE).
    page = models.ForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name="insights",
        null=True,
        blank=True,
    )

    strategy = models.CharField(
        max_length=16,
        choices=Strategy.choices,
        db_index=True,
    )

    # Statut du run
    status = models.CharField(
        max_length=16,
        choices=InsightStatus.choices,
        default=InsightStatus.PENDING,
        db_index=True,
    )

    # URL réellement testée (canonique normalisée au moment du run)
    url_tested = models.URLField(max_length=500, blank=True)

    # Scores Lighthouse (0–100)
    score_performance = models.PositiveSmallIntegerField(
        null=True, blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )
    score_accessibility = models.PositiveSmallIntegerField(
        null=True, blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )
    score_best_practices = models.PositiveSmallIntegerField(
        null=True, blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )
    score_seo = models.PositiveSmallIntegerField(
        null=True, blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )
    score_pwa = models.PositiveSmallIntegerField(
        null=True, blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )

    # Field data (CrUX) — valeurs typiques (ms, ratio)
    crux_lcp_ms = models.FloatField(null=True, blank=True, validators=[MinValueValidator(0)])
    crux_inp_ms = models.FloatField(null=True, blank=True, validators=[MinValueValidator(0)])
    crux_cls = models.FloatField(null=True, blank=True, validators=[MinValueValidator(0)])

    # Lab (Lighthouse) — principales métriques (ms ou valeur)
    lab_fcp_ms = models.FloatField(null=True, blank=True, validators=[MinValueValidator(0)])
    lab_lcp_ms = models.FloatField(null=True, blank=True, validators=[MinValueValidator(0)])
    lab_cls = models.FloatField(null=True, blank=True, validators=[MinValueValidator(0)])
    lab_ttfb_ms = models.FloatField(null=True, blank=True, validators=[MinValueValidator(0)])
    lab_speed_index_ms = models.FloatField(null=True, blank=True, validators=[MinValueValidator(0)])
    lab_tbt_ms = models.FloatField(null=True, blank=True, validators=[MinValueValidator(0)])  # Total Blocking Time

    # Métadonnées
    fetched_at = models.DateTimeField(default=timezone.now, db_index=True)
    error_message = models.TextField(blank=True)
    api_cost = models.PositiveIntegerField(null=True, blank=True)  # si utile
    raw_json = models.JSONField(null=True, blank=True)

    # --- KPI par catégorie (totaux / pass / fail / NA) ---
    a11y_total = models.PositiveSmallIntegerField(null=True, blank=True)
    a11y_pass = models.PositiveSmallIntegerField(null=True, blank=True)
    a11y_fail = models.PositiveSmallIntegerField(null=True, blank=True)
    a11y_na = models.PositiveSmallIntegerField(null=True, blank=True)

    seo_total = models.PositiveSmallIntegerField(null=True, blank=True)
    seo_pass = models.PositiveSmallIntegerField(null=True, blank=True)
    seo_fail = models.PositiveSmallIntegerField(null=True, blank=True)
    seo_na = models.PositiveSmallIntegerField(null=True, blank=True)

    # --- Accessibilité : récap WCAG (utile pour prioriser) ---
    a11y_wcag2a_fail = models.PositiveSmallIntegerField(null=True, blank=True)
    a11y_wcag2aa_fail = models.PositiveSmallIntegerField(null=True, blank=True)
    a11y_wcag21a_fail = models.PositiveSmallIntegerField(null=True, blank=True)
    a11y_wcag21aa_fail = models.PositiveSmallIntegerField(null=True, blank=True)

    # --- Accessibilité : flags “corrigibles côté contenu” ---
    a11y_alt_text_ok = models.BooleanField(null=True, blank=True)          # image-alt
    a11y_form_labels_ok = models.BooleanField(null=True, blank=True)       # label
    a11y_link_names_ok = models.BooleanField(null=True, blank=True)        # link-name
    a11y_color_contrast_ok = models.BooleanField(null=True, blank=True)    # color-contrast
    a11y_headings_ok = models.BooleanField(null=True, blank=True)          # headings-order / h1
    a11y_lang_ok = models.BooleanField(null=True, blank=True)              # html-has-lang
    a11y_keyboard_ok = models.BooleanField(null=True, blank=True)          # keyboard traps/focus

    # --- SEO : flags “corrigibles côté contenu” ---
    seo_title_ok = models.BooleanField(null=True, blank=True)              # document-title
    seo_meta_description_ok = models.BooleanField(null=True, blank=True)   # meta-description
    seo_viewport_ok = models.BooleanField(null=True, blank=True)           # viewport
    seo_font_size_ok = models.BooleanField(null=True, blank=True)          # font-size
    seo_tap_targets_ok = models.BooleanField(null=True, blank=True)        # tap-targets
    seo_canonical_ok = models.BooleanField(null=True, blank=True)          # canonical
    seo_hreflang_ok = models.BooleanField(null=True, blank=True)           # hreflang
    seo_is_crawlable = models.BooleanField(null=True, blank=True)          # is-crawlable
    seo_structured_data_ok = models.BooleanField(null=True, blank=True)    # structured-data
    seo_robots_txt_ok = models.BooleanField(null=True, blank=True)         # robots-txt

    # --- Statut technique rapide ---
    http_status_code = models.PositiveSmallIntegerField(null=True, blank=True)

    # --- Shortlists rapides pour l’UI (ids d’audits en échec) ---
    a11y_failed_ids = models.JSONField(null=True, blank=True)  # ex: ["image-alt","label","color-contrast",...]
    seo_failed_ids = models.JSONField(null=True, blank=True)   # ex: ["meta-description","canonical",...]

    # (Optionnel) Top issues “prioritaires” (titre + id + quick fix hint)
    top_issues = models.JSONField(null=True, blank=True)       # liste de dicts {category, id, title, outcome}

    class Meta:
        verbose_name = _("Page Insights")
        verbose_name_plural = _("Page Insights")
        indexes = [
            models.Index(fields=["page", "strategy", "-fetched_at"]),
            models.Index(fields=["status"]),
        ]
        ordering = ["-fetched_at"]

    def __str__(self) -> str:
        p = getattr(self.page, "title", None) or f"page_id={self.page_id}"
        return f"Insights[{self.strategy}] {p} @ {self.fetched_at:%Y-%m-%d %H:%M}"


class InsightAuditCategory(models.TextChoices):
    ACCESSIBILITY = "accessibility", _("Accessibility")
    SEO = "seo", "SEO"
    PERFORMANCE = "performance", _("Performance")
    BEST_PRACTICES = "best-practices", _("Best Practices")
    PWA = "pwa", "PWA"
    OTHER = "other", _("Other")


class InsightAuditOutcome(models.TextChoices):
    PASS = "pass", _("Pass")
    FAIL = "fail", _("Fail")
    NA = "notApplicable", _("Not Applicable")
    NOT_AVAILABLE = "notAvailable", _("Not Available")   # renommé


class PageInsightAudit(models.Model):
    insight = models.ForeignKey(
        PageInsights,
        on_delete=models.CASCADE,
        related_name="audits",
        db_index=True,
    )
    category = models.CharField(max_length=32, choices=InsightAuditCategory.choices, db_index=True)
    audit_id = models.CharField(max_length=128, db_index=True)   # ex: "meta-description", "image-alt"
    title = models.CharField(max_length=512, blank=True)
    description = models.TextField(blank=True)
    outcome = models.CharField(max_length=32, choices=InsightAuditOutcome.choices, db_index=True)
    score = models.FloatField(null=True, blank=True)             # 0..1 quand disponible
    score_display_mode = models.CharField(max_length=64, blank=True)
    numeric_value = models.FloatField(null=True, blank=True)
    numeric_unit = models.CharField(max_length=64, blank=True)
    tags = models.JSONField(null=True, blank=True)               # ex: ["wcag2a","wcag21aa"]
    details = models.JSONField(null=True, blank=True)            # raw “details” de Lighthouse

    class Meta:
        unique_together = [("insight", "audit_id")]  # un audit par run
        indexes = [
            models.Index(fields=["insight", "category"]),
            models.Index(fields=["category", "audit_id"]),
            models.Index(fields=["outcome"]),
        ]
        ordering = ["category", "audit_id"]

    def __str__(self) -> str:
        return f"{self.category}:{self.audit_id} ({self.outcome})"



class StyleBox(models.Model):
    top = models.CharField(
        max_length=10,
        default=0,
    )

    right = models.CharField(
        max_length=10,
        default=0,
    )

    bottom = models.CharField(
        max_length=10,
        default=0,
    )

    left = models.CharField(
        max_length=10,
        default=0,
    )

    def as_inline_css(self):
        return f"{self.top} {self.right} {self.bottom} {self.left};"


class Margin(models.Model):
    top = models.CharField(
        max_length=10,
        verbose_name=_("Marge haute"),
        default=0,
    )

    right = models.CharField(
        max_length=10,
        verbose_name=_("Marge droite"),
        default="auto",
    )

    bottom = models.CharField(
        max_length=10,
        verbose_name=_("Marge basse"),
        default=0,
    )

    left = models.CharField(
        max_length=10,
        verbose_name=_("Marge gauche"),
        default="auto",
    )


class Padding(models.Model):
    top = models.CharField(
        max_length=10,
        verbose_name=_("Padding haut"),
        default=0,
    )

    right = models.CharField(
        max_length=10,
        verbose_name=_("Padding droit"),
        default=0,
    )

    bottom = models.CharField(
        max_length=10,
        verbose_name=_("Padding bas"),
        default=0,
    )

    left = models.CharField(
        max_length=10,
        verbose_name=_("Padding gauche"),
        default=0,
    )


class Size(models.Model):
    width = models.CharField(
        max_length=50,
        default="100%",
        verbose_name=_("Largeur")
    )

    height = models.CharField(
        max_length=50,
        default="",
        verbose_name=_("Hauteur")
    )


class ImageContent(models.Model):
    # === Original (remplace "full_size") ===
    # S-10 — c'est LE point d'entrée des images du site, et celui qui coûte le
    # plus cher : `save()` produit cinq variantes en redimensionnant, donc
    # déplie l'image cinq fois en mémoire. Une bombe de décompression déposée
    # ici tue le processus. Voir jeiko/uploads.py.
    # Les variantes ci-dessous ne portent pas de validateur : elles ne sont pas
    # téléversées, c'est nous qui les fabriquons.
    original_image = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        validators=[valider_l_image],
        verbose_name=_("Image originale"),
        max_length=255,
    )

    # === Variantes dérivées (WEBP) ===
    # 1920px (full / hero)
    full_size = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        verbose_name=_("Image 1920w (WEBP)"),
        max_length=255,
    )
    # 1500px (desktop large)
    computer_size = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        verbose_name=_("Image 1500w (WEBP)"),
        max_length=255,
    )
    # 1200px (992–1199)
    laptop_size = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        verbose_name=_("Image 1200w (WEBP)"),
        max_length=255,
    )
    # 991px (768–991)
    tablet_size = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        verbose_name=_("Image 991w (WEBP)"),
        max_length=255,
    )
    # 767px (≤767)
    mobile_size = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        verbose_name=_("Image 767w (WEBP)"),
        max_length=255,
    )

    title = models.CharField(
        max_length=200,
        default="",
        blank=True,
        verbose_name=_("Titre interne"),
        help_text=_("Nom permettant de retrouver l'image dans la médiathèque."),
    )
    alt = models.CharField(max_length=200, default="", null=True, blank=True)
    # A-09 (28/09/2026) — un `alt` vide disait deux choses opposées : « cette
    # image ne porte rien, un lecteur d'écran doit la taire » et « personne
    # n'a pensé à la décrire ». Le relevé d'un agent trouvait des `alt` vides
    # presque partout, sans pouvoir dire lesquels étaient des oublis. Le choix
    # est désormais explicite : décrite, ou déclarée décorative.
    decorative = models.BooleanField(
        default=False,
        verbose_name=_("Image décorative"),
        help_text=(
            _("À cocher si l'image n'apporte aucune information (ornement, "
            "fond) : un lecteur d'écran la taira. Sinon, décrivez-la.")
        ),
    )
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)

    def __str__(self):
        return self.title or self.alt or f"Image n°{self.pk or 'nouvelle'}"

    @property
    def alt_manquant(self):
        """Ni décrite ni déclarée décorative : un oubli à corriger."""
        return not self.decorative and not (self.alt or "").strip()

    # cibles : (field_name, width, suffix)
    TARGETS = (
        ("full_size", 1920, "full"),
        ("computer_size", 1500, "computer"),
        ("laptop_size", 1200, "laptop"),
        ("tablet_size", 991, "tablet"),
        ("mobile_size", 767, "mobile"),
    )

    # ---------- utils ----------
    def _delete_storage_file(self, f):
        """Supprime un fichier du storage s’il existe (sans casser si absent)."""
        try:
            if f and getattr(f, "name", None) and default_storage.exists(f.name):
                default_storage.delete(f.name)
        except Exception:
            pass  # on ne bloque pas une suppression pour un souci disque

    def _clear_derivative_fields_db(self, target_pk=None):
        """
        Met à NULL les champs dérivés en base (sans passer par update_fields du caller).
        On n’écrit pas self.<field>=None ici pour éviter un conflit avec update_fields éventuel.
        """
        pk = target_pk or self.pk
        if not pk:
            return
        type(self).objects.filter(pk=pk).update(
            full_size=None,
            computer_size=None,
            laptop_size=None,
            tablet_size=None,
            mobile_size=None,
        )

    def _derivatives_field_names(self):
        return ("full_size", "computer_size", "laptop_size", "tablet_size", "mobile_size")

    def _cleanup_derivatives(self, old_instance=None):
        """Supprime tous les dérivés existants (utile avant régénération)."""
        target = old_instance or self
        for field_name in ("full_size", "computer_size", "laptop_size", "tablet_size", "mobile_size"):
            self._delete_storage_file(getattr(target, field_name))

    def _open_original(self):
        """Ouvre l’original depuis le storage, compatible storages distants."""
        if not self.original_image:
            return None
        try:
            img = Image.open(self.original_image.path)
        except Exception:
            with default_storage.open(self.original_image.name, "rb") as f:
                img = Image.open(f)
        return ImageOps.exif_transpose(img)

    def _make_derivative_webp(self, max_width, suffix):
        """
        Crée une dérivée WEBP redimensionnée par largeur (pas de contrainte hauteur).
        - Si l’original est plus petit que max_width → pas d’upscale : on encode tel quel en WEBP.
        - Retourne le nom du fichier sauvé dans le storage.
        """
        src = self._open_original()
        if src is None:
            return None

        if src.mode not in ("RGB", "L"):
            src = src.convert("RGB")

        ow, oh = src.size
        if ow > max_width:
            ratio = max_width / float(ow)
            new_size = (max_width, int(oh * ratio))
            resample = getattr(Image, "Resampling", Image).LANCZOS
            img = src.resize(new_size, resample)
        else:
            img = src

        buffer = BytesIO()
        img.save(buffer, format="WEBP", quality=85, method=6)  # qualité haute, poids contenu
        buffer.seek(0)

        base, __ = os.path.splitext(self.original_image.name)
        ts = int(time.time())
        rand = uuid4().hex[:6]
        new_name = f"{base}-{suffix}-{ts}-{rand}.webp"
        return default_storage.save(new_name, ContentFile(buffer.read()))

    # ---------- cycles de vie ----------
    def save_old(self, *args, **kwargs):
        """
        - Si l’original change : purge des dérivés anciens.
        - Génère systématiquement toutes les variantes (1920/1500/1200/991/767) en WEBP.
        """
        old = None
        if self.pk:
            try:
                old = type(self).objects.get(pk=self.pk)
            except type(self).DoesNotExist:
                old = None

        # Si on a explicitement vidé l’original → nettoyer dérivés + ancien original
        if old and not self.original_image and old.original_image:
            self._cleanup_derivatives(old)
            self._delete_storage_file(old.original_image)

        # 1er save pour disposer d’un PK + placer l’original dans le storage
        super().save(*args, **kwargs)

        if self.original_image:
            # Si l’original a changé → purge des dérivés précédents
            if old and old.original_image and old.original_image.name != self.original_image.name:
                self._cleanup_derivatives(old)

            # (Re)génère toutes les cibles
            to_update = []
            for field_name, width, suffix in self.TARGETS:
                saved_name = self._make_derivative_webp(width, suffix)
                if saved_name:
                    # On affecte le nom renvoyé par le storage (ImageField accepte un str)
                    setattr(self, field_name, saved_name)
                    to_update.append(field_name)

            if to_update:
                to_update.append("updated_at")
                super().save(update_fields=to_update)

    def save(self, *args, **kwargs):
        old = None
        if self.pk:
            try:
                old = type(self).objects.only(
                    "original_image",
                    "full_size", "computer_size", "laptop_size", "tablet_size", "mobile_size"
                ).get(pk=self.pk)
            except type(self).DoesNotExist:
                old = None

        old_had_original = bool(getattr(old, "original_image", None))
        new_has_original = bool(self.original_image)

        original_removed = old and old_had_original and not new_has_original
        original_changed = (
                old and old_had_original and new_has_original
                and old.original_image.name != self.original_image.name
        )

        # --- si suppression ou remplacement de l’original ---
        if original_removed or original_changed:
            # 1) supprimer les anciens dérivés (fichiers)
            self._cleanup_derivatives(old)

            # 2) très important : mettre les champs dérivés à None sur L’INSTANCE
            #    (sinon le template verra encore les vieilles valeurs)
            for fn in self._derivatives_field_names():
                setattr(self, fn, None)

            # 3) enregistrer tout de suite : on pose le nouvel original + dérivés NULL en DB
            super().save(*args, **kwargs)
        else:
            # cas nominal (pas de changement d’original)
            super().save(*args, **kwargs)

        # --- si l’original a été supprimé : enlever aussi l’ancien fichier et sortir ---
        if original_removed:
            if old and old.original_image:
                self._delete_storage_file(old.original_image)
            return

        # --- mode ASYNC : arrêt ici, le signal va régénérer plus tard ---
        if getattr(settings, "JEIKO_IMAGES_ASYNC", False):
            if original_changed and old and old.original_image:
                self._delete_storage_file(old.original_image)
            return

        # --- mode SYNC : régénération immédiate ---
        if self.original_image:
            # (les champs sont déjà None en mémoire si original_changed)
            to_update = []
            for field_name, width, suffix in self.TARGETS:
                saved_name = self._make_derivative_webp(width, suffix)
                if saved_name:
                    setattr(self, field_name, saved_name)
                    to_update.append(field_name)

            if to_update:
                to_update.append("updated_at")
                super().save(update_fields=to_update)

        # --- nettoyer l’ancien original si remplacé ---
        if original_changed and old and old.original_image:
            self._delete_storage_file(old.original_image)

    def delete(self, using=None, keep_parents=False):
        """Supprime la ligne ; le signal ``post_delete`` nettoie les fichiers.

        Les fichiers ne doivent surtout pas disparaître avant que la base ait
        accepté la suppression : une relation ``PROTECT`` laisserait sinon un
        ``ImageContent`` vivant mais privé de ses fichiers.
        """
        return super().delete(using=using, keep_parents=keep_parents)


class BackgroundImageParameters(models.Model):
    # Background repeat
    REPEAT_CHOICES = [
        ('no-repeat', _('Pas de répétition (no-repeat)')),
        ('repeat', _('Répéter (repeat)')),
        ('repeat-x', _('Répéter horizontalement (repeat-x)')),
        ('repeat-y', _('Répéter verticalement (repeat-y)')),
        ('space', _('Espacement (space)')),
        ('round', _('Adapter (round)')),
    ]
    background_repeat = models.CharField(
        max_length=20, choices=REPEAT_CHOICES, default='no-repeat', verbose_name=_("Répétition")
    )

    # Background size
    SIZE_CHOICES = [
        ('auto', _('Auto')),
        ('cover', _('Couvrir (cover)')),
        ('contain', _('Adapter (contain)')),
        # tu peux ajouter d'autres tailles CSS si besoin (100% 100%, etc.)
    ]
    background_size = models.CharField(
        max_length=20, choices=SIZE_CHOICES, default='cover', verbose_name=_("Taille")
    )

    # Background position (tous les classiques + custom possible)
    POSITION_CHOICES = [
        ('left top', _('Gauche Haut')),
        ('left center', _('Gauche Centre')),
        ('left bottom', _('Gauche Bas')),
        ('center top', _('Centre Haut')),
        ('center center', _('Centre')),
        ('center bottom', _('Centre Bas')),
        ('right top', _('Droite Haut')),
        ('right center', _('Droite Centre')),
        ('right bottom', _('Droite Bas')),
        # Pour plus d’options, prévoir une saisie custom (ex: '70% 20px')
    ]
    background_position = models.CharField(
        max_length=30, choices=POSITION_CHOICES, default='center center', verbose_name=_("Position")
    )

    # Background attachment (scroll/fixed/local)
    ATTACHMENT_CHOICES = [
        ('scroll', _('Défilement (scroll)')),
        ('fixed', _('Fixé (fixed)')),
        ('local', _('Local (local)')),
    ]
    background_attachment = models.CharField(
        max_length=10, choices=ATTACHMENT_CHOICES, default='scroll', verbose_name=_("Attachement")
    )

    # Blur (via filter: blur(xpx))
    background_blur = models.CharField(
        max_length=10, blank=True, default='', verbose_name=_("Flou (px)"),
        help_text=_("Ex : 5px ou laisser vide pour aucun flou")
    )

    # Brightness (via filter: brightness(x))
    background_brightness = models.CharField(
        max_length=10, blank=True, default='', verbose_name=_("Luminosité"),
        help_text=_("Ex : 0.7 (plus sombre), 1.2 (plus clair), laisser vide pour valeur par défaut (1)")
    )

    background_opacity = models.CharField(
        max_length=10, blank=True, default='',
        verbose_name=_("Opacité"),
        help_text=_("0–1 ou % (ex. 0.5 ou 50%)")
    )

    class Meta:
        verbose_name = _("Paramètres d’image de fond")
        verbose_name_plural = _("Paramètres d’images de fond")

    def get_filter_css(self):
        """Génère la chaîne filter CSS à partir du flou et de la luminosité"""
        filters = []
        if self.background_blur:
            filters.append(f'blur({self.background_blur})')
        if self.background_brightness:
            filters.append(f'brightness({self.background_brightness})')
        if self.background_opacity:
            filters.append(f'opacity({self.background_opacity})')
        return ' '.join(filters) if filters else None

    def __str__(self):
        return f"BG params ({self.background_repeat}, {self.background_size}, {self.background_position})"


class StylableElement(models.Model):
    """
    Modèle abstrait pour éléments stylables (Section, Line, Bloc).
    Gère les marges, paddings, background et tailles par device.
    """

    # Margins
    margin_phone = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_margin_phone",
        null=True,
        blank=True,
    )
    margin_tablet = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_margin_tablet",
        null=True,
        blank=True,
    )
    margin_laptop = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_margin_laptop",
        null=True,
        blank=True,
    )

    margin_computer = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_margin_computer",
        null=True,
        blank=True,
    )

    # Paddings
    padding_phone = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_padding_phone",
        null=True,
        blank=True,
    )
    padding_tablet = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_padding_tablet",
        null=True,
        blank=True,
    )
    padding_laptop = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_padding_laptop",
        null=True,
        blank=True,
    )
    padding_computer = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_padding_computer",
        null=True,
        blank=True,
    )

    # Sizes
    size_phone = models.ForeignKey(
        Size,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_size_phone"
    )
    size_tablet = models.ForeignKey(
        Size,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_size_tablet"
    )
    size_laptop = models.ForeignKey(
        Size,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_size_laptop"
    )
    size_computer = models.ForeignKey(
        Size,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_size_computer"
    )

    # Background
    background_image = models.ForeignKey(
        ImageContent,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="%(class)s_background_image"
    )
    background_image_dynamic_key = models.SlugField(
        max_length=100,
        blank=True,
        default='',
        verbose_name=_('Tag d’image de fond dynamique'),
        help_text=(
            _("Optionnel. Code d’un champ IMAGE de l’objet custom (ex : cover_image). "
            "Si renseigné et présent dans le contexte, l’image de l’objet sera utilisée "
            "à la place de l’image fixe choisie ci-dessus.")
        ),
    )
    background_image_parameters = models.OneToOneField(
        BackgroundImageParameters,
        on_delete=models.CASCADE,
        null=True,
        blank=True,

    )
    background_color = models.CharField(
        max_length=30,
        default="rgba(255,255,255,0)",
        null=True,
        blank=True,
    )

    class Meta:
        abstract = True

    # --- Méthodes utiles (optionnel)
    def css_margin_inline(self, device='computer'):
        field = getattr(self, f"margin_{device}")
        return f"margin: {field.as_inline_css()};"

    def css_padding_inline(self, device='computer'):
        field = getattr(self, f"padding_{device}")
        return f"padding: {field.as_inline_css()};"

    def css_size_inline(self, device='computer'):
        size = getattr(self, f"size_{device}")
        if not size:
            return ""
        return f"width: {size.width}; height: {size.height};"

    def css_background(self):
        return f"background-color: {self.background_color};"

    def has_background_image(self):
        return bool(self.background_image and self.background_image.full_size)

    def get_background_image_url(self, device='computer'):
        """
        Retourne l’URL de l’image background selon le device.
        device = 'computer' | 'tablet' | 'phone'
        """
        if not self.background_image:
            return ""
        # On suppose que ImageContent a bien des champs : computer_size, tablet_size, mobile_size
        img = self.background_image
        if device == "computer" and hasattr(img, 'computer_size') and img.computer_size:
            return img.computer_size.url
        elif device == "tablet" and hasattr(img, 'tablet_size') and img.tablet_size:
            return img.tablet_size.url
        elif device == "phone" and hasattr(img, 'mobile_size') and img.mobile_size:
            return img.mobile_size.url
        # fallback : full_size si présent
        elif hasattr(img, 'full_size') and img.full_size:
            return img.full_size.url
        return ""


class Section(StylableElement):

    page = models.ForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name='sections',
        null=True,
        blank=True
    )

    position = models.IntegerField(
        default=0,
        db_index=True,
        null=True,
        blank=True
    )

    is_model = models.BooleanField(
        default=False,
        db_index=True
    )

    model_source = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        db_index=True,
        related_name="model_copies"
    )

    model_name = models.CharField(
        max_length=200,
        default="",
        null=True,
        blank=True,
        verbose_name=_("Nom du modèle")

    )

    is_hero = models.BooleanField(
        default=False,
        db_index=True,
    )

    class Meta:
        ordering = ('position', 'id')


class Line(StylableElement):

    section = models.ForeignKey(
        Section,
        on_delete=models.CASCADE,
        related_name='lines',
        null=True,
        blank=True,
    )

    position = models.IntegerField(
        default=0,
        db_index=True,
        blank=True,
        null=True,
    )

    is_model = models.BooleanField(
        default=False,
        db_index=True
    )

    model_source = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        db_index=True,
        related_name="model_copies"
    )

    model_name = models.CharField(
        max_length=200,
        default="",
        null=True,
        blank=True,
        verbose_name=_("Nom du modèle")

    )

    COLUMNS_TYPE_CHOICES = [
        ("12", "12"),
        ("6-6", "6-6"),
        ("4-8", "4-8"),
        ("8-4", "8-4"),
        ("9-3", "9-3"),
        ("3-9", "3-9"),
        ("2-10", "2-10"),
        ("10-2", "10-2"),
        ("4-4-4", "4-4-4"),
        ("3-6-3", "3-6-3"),
        ("3-3-6", "3-3-6"),
        ("6-3-3", "6-3-3"),
        ("2-8-2", "2-8-2"),
        ("2-2-8", "2-2-8"),
        ("8-2-2", "8-2-2"),
        ("3-3-3-3", "3-3-3-3"),
        ("2-2-2-6", "2-2-2-6"),
        ("6-2-2-2", "6-2-2-2"),
        ("2-2-2-2-2-2", "2-2-2-2-2-2"),
    ]

    COLUMNS_ROWS_TYPE_CHOICES = [
        ("12", "12"),
        ("6-6", "6-6"),
        ("4-8", "4-8"),
        ("8-4", "8-4"),
        ("9-3", "9-3"),
        ("3-9", "3-9"),
        ("2-10", "2-10"),
        ("10-2", "10-2"),
        ("12-12", "12-12"),
        ("4-4-4", "4-4-4"),
        ("3-6-3", "3-6-3"),
        ("3-3-6", "3-3-6"),
        ("6-3-3", "6-3-3"),
        ("2-8-2", "2-8-2"),
        ("2-2-8", "2-2-8"),
        ("8-2-2", "8-2-2"),
        ("12-12-12", "12-12-12"),
        ("6-6-12", "6-6-12"),
        ("12-6-6", "12-6-6"),
        ("3-3-3-3", "3-3-3-3"),
        ("2-2-2-6", "2-2-2-6"),
        ("6-2-2-2", "6-2-2-2"),
        ("6-6-6-6", "6-6-6-6"),
        ("12-12-12-12", "12-12-12-12"),
        ("6-6-12-12", "6-6-12-12"),
        ("12-12-6-6", "12-12-6-6"),
        ("12-4-4-4", "12-4-4-4"),
        ("4-4-4-12", "4-4-4-12"),
        ("2-2-2-2-2-2", "2-2-2-2-2-2"),
        ("12-12-12-12-12-12", "12-12-12-12-12-12"),
        ("6-6-6-6-6-6", "6-6-6-6-6-6"),
        ("4-4-4-4-4-4", "4-4-4-4-4-4"),
        ("3-3-3-3-3-3", "3-3-3-3-3-3"),
    ]

    columns_type = models.CharField(
        max_length=20,
        choices=COLUMNS_TYPE_CHOICES,
        default="12",
        verbose_name=_("Desktop/Laptop layout"),
    )

    columns_type_tablet = models.CharField(
        max_length=20,
        choices=COLUMNS_ROWS_TYPE_CHOICES,
        default="12",
        verbose_name=_("Tablet layout"),
    )

    columns_type_phone = models.CharField(
        max_length=20,
        choices=COLUMNS_ROWS_TYPE_CHOICES,
        default="12",
        verbose_name=_("Mobile layout"),
    )

    columns_number = models.IntegerField(
        default=1,
        verbose_name=_("Nombre de colonnes"),
    )

    is_hero = models.BooleanField(
        default=False,
        db_index=True,
    )

    class Meta:
        ordering = ('position', 'id')

    def get_grid_positions(self, device="computer"):
        """
        Renvoie une liste de dicts {start, end} pour chaque bloc,
        en fonction de columns_type (desktop/tablet/phone).
        """
        field = {
            "computer": "columns_type",
            "tablet": "columns_type_tablet",
            "phone": "columns_type_phone"
        }[device]
        ratios = [int(r) for r in getattr(self, field).split("-")]
        positions = []
        current = 1
        for span in ratios:
            positions.append({"start": current, "end": current + span})
            current += span
        return positions

    @property
    def desktop_layout(self):
        return [int(x) for x in self.columns_type.split('-')]

    @property
    def tablet_layout(self):
        return [int(x) for x in self.columns_type_tablet.split('-')]

    @property
    def mobile_layout(self):
        return [int(x) for x in self.columns_type_phone.split('-')]

    def save(self, *args, **kwargs):
        is_new = self.pk is None
        super().save(*args, **kwargs)

        if is_new:
            # Par défaut, tablet = même as desktop
            if self.columns_type_tablet == "12":
                self.columns_type_tablet = self.columns_type
            # Par défaut, mobile = autant de "12" que de blocs desktop
            if self.columns_type_phone == "12":
                self.columns_type_phone = "-".join(
                    ["12"] * len(self.columns_type.split("-"))
                )
            super().save(update_fields=["columns_type_tablet", "columns_type_phone"])


class Bloc(StylableElement):

    line = models.ForeignKey(
        Line,
        on_delete=models.CASCADE,
        related_name='blocs',
        blank=True,
        null=True,
    )

    position = models.IntegerField(
        default=0,
        db_index=True,
        blank=True,
        null=True,
    )

    position_in_column = models.IntegerField(
        default=0,
        db_index=True,
        blank=True,
        null=True,
    )

    is_model = models.BooleanField(
        default=False,
        db_index=True
    )

    model_source = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        db_index=True,
        related_name="model_copies"
    )

    model_name = models.CharField(
        max_length=200,
        default="",
        null=True,
        blank=True,
        verbose_name=_("Nom du modèle")

    )

    # Ajout alignement
    horizontal_align = models.CharField(
        max_length=16,
        choices=[
            ('', _('Automatique')),
            ('left', _('Gauche')),
            ('center', _('Centré')),
            ('right', _('Droite')),
            ('justify', _('Justifié')),
        ],
        default='', blank=True,
        verbose_name=_("Alignement horizontal")
    )
    vertical_align = models.CharField(
        max_length=16,
        choices=[
            ('', _('Automatique')),
            ('top', _('Haut')),
            ('middle', _('Milieu')),
            ('bottom', _('Bas')),
        ],
        default='', blank=True,
        verbose_name=_("Alignement vertical")
    )

    class Meta:
        ordering = ('position', 'position_in_column', 'id')


class CustomCSS(models.Model):
    """
    CSS custom par élément stylable (Section/Line/Bloc).
    Remplace progressivement CSSParameters (lié à Content).
    Un seul des trois FK doit être renseigné.
    """
    # Cible (exactement un des 3)
    section = models.OneToOneField(
        'administration_pages.Section',
        on_delete=models.CASCADE,
        related_name='custom_css',
        null=True, blank=True,
    )
    line = models.OneToOneField(
        'administration_pages.Line',
        on_delete=models.CASCADE,
        related_name='custom_css',
        null=True, blank=True,
    )
    bloc = models.OneToOneField(
        'administration_pages.Bloc',
        on_delete=models.CASCADE,
        related_name='custom_css',
        null=True, blank=True,
    )

    # Classes utilitaires à ajouter à l'élément
    object_classes = models.CharField(
        max_length=200, default="", blank=True, verbose_name=_("Classes de l'objet")
    )

    # CSS global
    before = models.TextField(default="", blank=True, verbose_name=_("CSS before (global)"))
    current = models.TextField(default="", blank=True, verbose_name=_("CSS (global)"))
    after = models.TextField(default="", blank=True, verbose_name=_("CSS after (global)"))
    hover = models.TextField(default="", blank=True, verbose_name=_("CSS :hover (global)"))
    custom = models.TextField(default="", blank=True, verbose_name=_("CSS personnalisé (global)"))

    # Overrides par device (aligné avec tes paliers: phone/tablet/computer/laptop)
    current_phone    = models.TextField(default="", blank=True, verbose_name=_("CSS phone"))
    current_tablet   = models.TextField(default="", blank=True, verbose_name=_("CSS tablet"))
    current_computer = models.TextField(default="", blank=True, verbose_name=_("CSS computer (992–1199)"))
    current_laptop   = models.TextField(default="", blank=True, verbose_name=_("CSS laptop (≥1200)"))

    hover_phone    = models.TextField(default="", blank=True, verbose_name=_("CSS :hover phone"))
    hover_tablet   = models.TextField(default="", blank=True, verbose_name=_("CSS :hover tablet"))
    hover_computer = models.TextField(default="", blank=True, verbose_name=_("CSS :hover computer"))
    hover_laptop   = models.TextField(default="", blank=True, verbose_name=_("CSS :hover laptop"))

    class Meta:
        constraints = [
            # exactement un target non nul
            models.CheckConstraint(
                name="customcss_exactly_one_target",
                condition=(
                    (Q(section__isnull=False) & Q(line__isnull=True) & Q(bloc__isnull=True)) |
                    (Q(section__isnull=True)  & Q(line__isnull=False) & Q(bloc__isnull=True)) |
                    (Q(section__isnull=True)  & Q(line__isnull=True)  & Q(bloc__isnull=False))
                ),
            ),
        ]
        indexes = [
            models.Index(fields=["section"]),
            models.Index(fields=["line"]),
            models.Index(fields=["bloc"]),
        ]

    def __str__(self):
        if self.section_id:
            return f"CustomCSS(section={self.section_id})"
        if self.line_id:
            return f"CustomCSS(line={self.line_id})"
        if self.bloc_id:
            return f"CustomCSS(bloc={self.bloc_id})"
        return "CustomCSS(?)"

    # (Optionnel) Helper si tu veux générer du CSS avec media queries
    def as_css(self, dom_id: str | None = None) -> str:
        """
        Concatène le CSS global + device (avec media queries).
        dom_id peut être passé si tu veux scoper avec #id ou .class, etc.
        """
        sel = f"#{dom_id}" if dom_id else ""
        parts = []

        if self.before.strip():
            parts.append(self.before.strip())

        if self.current.strip():
            parts.append(f"{sel}{{{self.current.strip()}}}")

        # devices
        if self.current_phone.strip():
            parts.append(f"@media (max-width: 767.98px){{{sel}{{{self.current_phone.strip()}}}}}")
        if self.current_tablet.strip():
            parts.append(f"@media (min-width:768px) and (max-width:991.98px){{{sel}{{{self.current_tablet.strip()}}}}}")
        if self.current_computer.strip():
            parts.append(f"@media (min-width:992px) and (max-width:1199.98px){{{sel}{{{self.current_computer.strip()}}}}}")
        if self.current_laptop.strip():
            parts.append(f"@media (min-width:1200px){{{sel}{{{self.current_laptop.strip()}}}}}")

        if self.hover.strip():
            parts.append(f"{sel}:hover{{{self.hover.strip()}}}")

        # :hover devices
        if self.hover_phone.strip():
            parts.append(f"@media (max-width: 767.98px){{{sel}:hover{{{self.hover_phone.strip()}}}}}")
        if self.hover_tablet.strip():
            parts.append(f"@media (min-width:768px) and (max-width:991.98px){{{sel}:hover{{{self.hover_tablet.strip()}}}}}")
        if self.hover_computer.strip():
            parts.append(f"@media (min-width:992px) and (max-width:1199.98px){{{sel}:hover{{{self.hover_computer.strip()}}}}}")
        if self.hover_laptop.strip():
            parts.append(f"@media (min-width:1200px){{{sel}:hover{{{self.hover_laptop.strip()}}}}}")

        if self.after.strip():
            parts.append(self.after.strip())
        if self.custom.strip():
            parts.append(self.custom.strip())

        return "\n".join(p for p in parts if p)


class Animation(models.Model):
    """
    Configuration d'une animation 100% CSS appliquée à un élément.
    OneToOne depuis Section/Line/Bloc.
    """
    # Activation
    enabled = models.BooleanField(default=False, db_index=True)

    # Quel preset visuel (liste simple, extensible)
    PRESET_CHOICES = [
        ('fade', _('Fade')),
        ('slide-up', _('Slide Up')),
        ('slide-down', _('Slide Down')),
        ('slide-left', _('Slide Left')),
        ('slide-right', _('Slide Right')),
        ('zoom-in', _('Zoom In')),
        ('rotate-in', _('Rotate In')),
        ('blur-in', _('Blur In')),
        # tu pourras en ajouter : clip-reveal, wipe, scale-y, etc.
    ]
    preset = models.CharField(max_length=32, choices=PRESET_CHOICES, default='fade')

    # Déclencheur (uniquement CSS)
    TRIGGER_CHOICES = [
        ('scroll', _('Quand visible (scroll-driven)')),
        ('load', _('Au chargement')),
        ('hover', _('Au survol')),
        ('focus', _('Au focus-within')),
        # NB : on reste pur CSS, pas de click JS. Un toggle/click pur CSS est possible,
        # mais requiert un input:checked + :has(). On le garde pour plus tard.
    ]
    trigger = models.CharField(max_length=16, choices=TRIGGER_CHOICES, default='scroll')

    # Timing génériques
    duration_ms = models.PositiveIntegerField(default=600, validators=[MinValueValidator(1)])
    delay_ms = models.PositiveIntegerField(default=0)
    easing = models.CharField(max_length=64, default='ease-out')  # ex: 'ease', 'linear', 'cubic-bezier(...)'
    iterations = models.CharField(max_length=16, default='1')     # '1', '2', 'infinite', etc.
    direction = models.CharField(max_length=16, default='normal') # 'normal', 'reverse', 'alternate'
    fill_mode = models.CharField(max_length=16, default='both')   # 'none', 'forwards', 'backwards', 'both'

    # Options scroll-driven (utilisées si trigger=scroll et navigateur compatible)
    # Exemple: "entry 10% cover 30%" (sinon valeur par défaut)
    animation_range = models.CharField(max_length=64, blank=True, default='')

    # Ciblage devices (simple et aligné avec tes modèles)
    enable_phone = models.BooleanField(default=True)
    enable_tablet = models.BooleanField(default=True)
    enable_laptop = models.BooleanField(default=True)
    enable_computer = models.BooleanField(default=True)

    # Paramètres spécifiques au preset (distance, blur, scale, angles, etc.)
    # Par ex. slide: {"dx":"0px","dy":"24px"} ; zoom: {"scale_from":0.96}; rotate: {"deg":"6deg"} ; blur: {"px":"8px"}
    params = models.JSONField(default=dict, blank=True)

    # Accessibilité
    reduce_motion_strategy = models.CharField(
        max_length=16,
        choices=[('disable',_('Désactiver')), ('simplify',_('Simplifier'))],
        default='disable'
    )

    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    section = models.OneToOneField(
        'administration_pages.Section',
        on_delete=models.CASCADE,
        related_name='animation',
        null=True, blank=True,
    )
    line = models.OneToOneField(
        'administration_pages.Line',
        on_delete=models.CASCADE,
        related_name='animation',
        null=True, blank=True,
    )
    bloc = models.OneToOneField(
        'administration_pages.Bloc',
        on_delete=models.CASCADE,
        related_name='animation',
        null=True, blank=True,
    )
    # Helpers -----------------------------------------------------------------
    def css_custom_props(self):
        """Retourne un dict de variables CSS pour style=""."""
        p = self.params or {}
        # valeurs par défaut par preset
        defaults = {
            'slide-up':   {'dx': '0px',  'dy': '24px'},
            'slide-down': {'dx': '0px',  'dy': '-24px'},
            'slide-left': {'dx': '24px', 'dy': '0px'},
            'slide-right':{'dx': '-24px','dy': '0px'},
            'zoom-in':    {'scale_from': '0.96'},
            'rotate-in':  {'deg': '6deg'},
            'blur-in':    {'px': '8px'},
            'fade':       {},
        }
        base = defaults.get(self.preset, {}).copy()
        base.update(p)  # override par l’admin

        props = {
            '--anim-duration': f"{self.duration_ms}ms",
            '--anim-delay': f"{self.delay_ms}ms",
            '--anim-ease': self.easing,
            '--anim-iterations': self.iterations,
            '--anim-direction': self.direction,
            '--anim-fill': self.fill_mode,
        }
        if self.animation_range:
            props['--anim-range'] = self.animation_range

        # props spécifiques
        if 'dx' in base: props['--slide-dx'] = base['dx']
        if 'dy' in base: props['--slide-dy'] = base['dy']
        if 'scale_from' in base: props['--scale-from'] = base['scale_from']
        if 'deg' in base: props['--rotate-from'] = base['deg']
        if 'px' in base: props['--blur-from'] = base['px']

        return props

    class Meta:
        constraints = [
            models.CheckConstraint(
                name="anim_exactly_one_target",
                condition=(
                        (models.Q(section__isnull=False) & models.Q(line__isnull=True) & models.Q(bloc__isnull=True)) |
                        (models.Q(section__isnull=True) & models.Q(line__isnull=False) & models.Q(bloc__isnull=True)) |
                        (models.Q(section__isnull=True) & models.Q(line__isnull=True) & models.Q(bloc__isnull=False))
                ),
            ),
        ]


    def clean(self):
        targets = [bool(self.section_id), bool(self.line_id), bool(self.bloc_id)]
        if sum(targets) != 1:
            raise ValidationError(_("Animation: renseigner exactement une cible parmi section/line/bloc."))


class Border(models.Model):
    """
    Configuration des bordures (CSS) appliquée à un élément (Section/Line/Bloc).
    OneToOne depuis Section/Line/Bloc.
    """
    # Attributs CSS
    border_width = models.CharField(
        max_length=32, blank=True, default="",
        verbose_name=_("Largeur (width)"), help_text=_("Ex: 1px, 2px, 0.5rem")
    )
    border_style = models.CharField(
        max_length=32, blank=True, default="",
        verbose_name=_("Style"),
        choices=[
            ("", _("Aucun")),
            ("solid", _("Continu (solid)")),
            ("dashed", _("Tirets (dashed)")),
            ("dotted", _("Pointillés (dotted)")),
            ("double", _("Double")),
            ("groove", _("Rainure (groove)")),
            ("ridge", _("Arête (ridge)")),
            ("inset", _("Inset")),
            ("outset", _("Outset")),
            ("hidden", _("Caché (hidden)")),
        ]
    )
    border_color = models.CharField(
        max_length=32, blank=True, default="",
        verbose_name=_("Couleur"), help_text=_("Ex: #000, rgba(0,0,0,0.5)")
    )
    border_radius = models.CharField(
        max_length=32, blank=True, default="",
        verbose_name=_("Rayon (radius)"), help_text=_("Ex: 4px, 50%, 0.5rem")
    )

    # Cibles (mutually exclusive)
    section = models.OneToOneField(
        'administration_pages.Section',
        on_delete=models.CASCADE,
        related_name='border',
        null=True, blank=True,
    )
    line = models.OneToOneField(
        'administration_pages.Line',
        on_delete=models.CASCADE,
        related_name='border',
        null=True, blank=True,
    )
    bloc = models.OneToOneField(
        'administration_pages.Bloc',
        on_delete=models.CASCADE,
        related_name='border',
        null=True, blank=True,
    )

    class Meta:
        verbose_name = _("Bordure")
        verbose_name_plural = _("Bordures")
        constraints = [
            models.CheckConstraint(
                name="border_exactly_one_target",
                condition=(
                    (models.Q(section__isnull=False) & models.Q(line__isnull=True) & models.Q(bloc__isnull=True)) |
                    (models.Q(section__isnull=True)  & models.Q(line__isnull=False) & models.Q(bloc__isnull=True)) |
                    (models.Q(section__isnull=True)  & models.Q(line__isnull=True)  & models.Q(bloc__isnull=False))
                ),
            ),
        ]
        indexes = [
            models.Index(fields=["section"]),
            models.Index(fields=["line"]),
            models.Index(fields=["bloc"]),
        ]

    def __str__(self):
        return f"Border({self.border_style} {self.border_width})"


class ContentText(models.Model):
    text = models.TextField(
        default='',
        verbose_name=_("Contenu")
    )


class ContentTextQuestionnaire(models.Model):
    raw_text = models.TextField(
        verbose_name=_("Texte avec balises dynamiques"),
        help_text=_("Utilisez [%prenom%], [%score%], [%profil%], etc.")
    )

    def render(self, context: dict):
        # Optionnel si tu veux un rendu simple dans l'admin ou autre
        rendered = self.raw_text
        for key, value in context.items():
            rendered = rendered.replace(f"[%{key}%]", str(value))
        return rendered


class ContentChartQuestionnaire(models.Model):
    CHART_TYPE_CHOICES = [
        ("bar", _("Barres")),
        ("radar", _("Radar")),
        ("doughnut", _("Doughnut")),
        ("pie", _("Camembert")),
        ("line", _("Lignes")),
    ]

    title = models.CharField(
        max_length=200,
        blank=True,
        default="",
        verbose_name=_("Titre du graphique")
    )
    description = models.TextField(
        blank=True,
        default="",
        verbose_name=_("Description (optionnelle)")
    )

    chart_type = models.CharField(
        max_length=20,
        choices=CHART_TYPE_CHOICES,
        default="bar",
        verbose_name=_("Type de graphique")
    )

    # Options Chart.js globales (axes, legendes, couleurs par défaut, etc.)
    options_json = models.JSONField(
        verbose_name=_("Options JSON (Chart.js)"),
        help_text=_("Personnalisation du graphique (axes, titres, etc.)"),
        default=dict,
        blank=True
    )

    # Facultatif : pour lier à une structure de scores particulière
    main_axis = models.CharField(
        max_length=100,
        blank=True,
        default="",
        help_text=_("Nom du champ dans les scores à utiliser (laisser vide pour auto)")
    )

    def __str__(self):
        return self.title or f"Graphique {self.pk}"


class ContentImage(models.Model):
    # M-02 : un média se partage, pas le cadrage propre à chaque bloc. PROTECT
    # conserve le refus de suppression directe tant qu'un satellite le cite.
    image_content = models.ForeignKey(
        ImageContent,
        on_delete=models.PROTECT,
        related_name='content_image',
    )

    # Options d'affichage spécifiques à l'image
    object_fit = models.CharField(
        max_length=20,
        choices=[
            ('fill', 'fill'),
            ('contain', 'contain'),
            ('cover', 'cover'),
            ('none', 'none'),
            ('scale-down', 'scale-down'),
        ],
        default='cover',
        verbose_name=_('object-fit'),
        help_text=_('Détermine comment l’image s’adapte à son conteneur.')
    )
    object_position = models.CharField(
        max_length=30,
        default='center center',
        verbose_name=_('object-position'),
        help_text=_('Exemple : center center, top left, 50% 50%…')
    )
    filter = models.CharField(
        max_length=100,
        default='none',
        blank=True,
        verbose_name=_('CSS filter'),
        help_text=_('Effet CSS : blur(2px), grayscale(100%), etc.')
    )
    opacity = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=1.0,
        verbose_name=_('Opacité'),
        help_text=_('Entre 0.0 (transparent) et 1.0 (opaque).')
    )
    transition = models.CharField(
        max_length=100,
        default='',
        blank=True,
        verbose_name=_('Transition CSS'),
        help_text=_('Exemple : all 0.3s ease-in-out')
    )
    mix_blend_mode = models.CharField(
        max_length=30,
        default='normal',
        choices=[
            ('normal', 'normal'),
            ('multiply', 'multiply'),
            ('screen', 'screen'),
            ('overlay', 'overlay'),
            ('darken', 'darken'),
            ('lighten', 'lighten'),
            ('color-dodge', 'color-dodge'),
            ('color-burn', 'color-burn'),
            ('hard-light', 'hard-light'),
            ('soft-light', 'soft-light'),
            ('difference', 'difference'),
            ('exclusion', 'exclusion'),
            ('hue', 'hue'),
            ('saturation', 'saturation'),
            ('color', 'color'),
            ('luminosity', 'luminosity'),
        ],
        verbose_name=_('Mix blend mode')
    )
    alt = models.CharField(
        max_length=150,
        default='Image',
        verbose_name=_('Texte alternatif (alt)'),
        help_text=_('Description de l’image pour l’accessibilité et le SEO.')
    )
    title = models.CharField(
        max_length=150,
        default='',
        blank=True,
        verbose_name=_('Title (tooltip)'),
        help_text=_('Texte affiché au survol.')
    )
    dynamic_key = models.SlugField(
        max_length=100,
        blank=True,
        default='',
        verbose_name=_('Tag d’image dynamique'),
        help_text=(
            _("Optionnel. Code d’un champ IMAGE de l’objet custom (ex : cover_image). "
            "Si renseigné et présent dans le contexte, l’image de l’objet sera utilisée "
            "à la place de l’image fixe choisie ci-dessus.")
        ),
    )

    def clean(self):
        # éventuel nettoyage supplémentaire
        if self.dynamic_key:
            self.dynamic_key = slugify(self.dynamic_key)

    def __str__(self):
        return self.alt or "Image"


class ContentButton(models.Model):
    # ------- CONTENU -------
    label = models.CharField(max_length=100, verbose_name=_("Texte du bouton"))
    open_in_new_tab = models.BooleanField(default=False, verbose_name=_("Ouvrir dans un nouvel onglet"))
    page_target = models.ForeignKey(
        'Page', null=True, blank=True, on_delete=models.SET_NULL, verbose_name=_("Page cible"),
        related_name="buttons_targeted"
    )
    test_slug = models.CharField(max_length=100, null=True, blank=True, verbose_name=_("Slug du test"))

    custom_object_target = models.ForeignKey(
        'custom_objects.CustomObject',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        verbose_name=_("Page automatique"),
        related_name="buttons_targeted",
    )
    external_url = models.URLField(
        max_length=500,
        null=True,
        blank=True,
        verbose_name=_("Lien externe (URL complète)"),
        help_text=_("Ex : https://exemple.com/…")
    )

    dynamic_key = models.SlugField(
        max_length=100,
        blank=True,
        default='',
        verbose_name=_("Tag bouton dynamique"),
        help_text=(
            _("Optionnel. Code d’un champ BOUTON de l’objet custom (ex : cta_principal). "
            "Si renseigné, l’URL (et éventuellement le texte) seront pris depuis l’objet custom.")
        ),
    )

    # ------- E-COMMERCE -------
    is_add_to_cart = models.BooleanField(
        default=False,
        verbose_name=_("Action : Ajouter au panier"),
        help_text=_("Si coché, ce bouton ajoutera le produit ciblé au panier (au lieu d'être un lien simple).")
    )
    product_target = models.ForeignKey(
        'shop.Product',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="buttons_targeted",
        verbose_name=_("Produit cible (si manuel)"),
        help_text=_("Sélectionner un produit spécifique. Si vide et que la page est un produit, utilise le produit courant.")
    )

    # ------- DESIGN : COULEURS -------
    background_color = models.CharField(max_length=32, null=True, blank=True, verbose_name=_("Couleur de fond (CSS)"))
    text_color = models.CharField(max_length=32, null=True, blank=True, verbose_name=_("Couleur du texte (CSS)"))
    border_color = models.CharField(max_length=32, null=True, blank=True, verbose_name=_("Couleur de bordure (CSS)"))
    hover_background_color = models.CharField(max_length=32, null=True, blank=True, verbose_name=_("Couleur de fond au survol (CSS)"))
    hover_text_color = models.CharField(max_length=32, null=True, blank=True, verbose_name=_("Texte au survol (CSS)"))
    hover_border_color = models.CharField(max_length=32, null=True, blank=True, verbose_name=_("Bordure au survol (CSS)"))

    # ------- DESIGN : DIMENSIONS/FORME -------
    border_radius = models.CharField(max_length=16, null=True, blank=True,
                                     verbose_name=_("Rayon des coins (ex: 6px, 50%)"))
    border_width = models.CharField(max_length=16, null=True, blank=True, verbose_name=_("Largeur bordure (ex: 2px)"))
    # Défaut posé le 28/09/2026 : un bouton neuf — de l'éditeur comme de l'API —
    # naissait sans marge intérieure, son libellé collé aux bords. « 14px 28px »
    # est la valeur d'usage (exemple du guide, constructeur d'e-mails). Les
    # boutons existants gardent la leur.
    padding = models.CharField(max_length=32, null=True, blank=True, default="14px 28px",
                               verbose_name=_("Padding (ex: 12px 24px)"))
    width = models.CharField(max_length=16, null=True, blank=True, verbose_name=_("Largeur (ex: 100%)"))
    height = models.CharField(max_length=16, null=True, blank=True, verbose_name=_("Hauteur (ex: 100px)"))
    font_size = models.CharField(max_length=16, null=True, blank=True, verbose_name=_("Taille de police (ex: 1.2rem)"))
    font_weight = models.CharField(max_length=16, null=True, blank=True, verbose_name=_("Graisse police (400, 700...)"))
    font_family = models.CharField(max_length=64, null=True, blank=True, verbose_name=_("Famille de police (ex: Roboto)"))
    letter_spacing = models.CharField(max_length=16, null=True, blank=True, verbose_name=_("Espacement lettres"))
    text_transform = models.CharField(
        max_length=16,
        choices=[('none', _('Normal')), ('uppercase', _('Majuscules')), ('lowercase', _('Minuscules')),
                 ('capitalize', _('Capitalize'))],
        default='none', blank=True, verbose_name=_("Casse")
    )

    # ------- OMBRES/TRANSITIONS -------
    box_shadow = models.CharField(max_length=128, null=True, blank=True, verbose_name=_("Box-shadow (CSS)"))
    hover_shadow = models.CharField(max_length=128, null=True, blank=True, verbose_name=_("Ombre au hover (CSS)"))
    transition = models.CharField(max_length=64, null=True, blank=True, verbose_name=_("Transition (ex: all 0.2s)"))

    # ------- ICONES -------
    # Choisies dans jeiko/icones.py et dessinées en SVG dans le bouton : ces
    # champs attendaient une classe FontAwesome, que plus rien ne chargeait.
    icon_left = models.CharField(max_length=64, null=True, blank=True, choices=ICONES_BOUTON,
                                 verbose_name=_("Icône à gauche"))
    icon_right = models.CharField(max_length=64, null=True, blank=True, choices=ICONES_BOUTON,
                                  verbose_name=_("Icône à droite"))

    # ------- ANIMATIONS prédéfinies CSS -------
    animation = models.CharField(
        max_length=32, null=True, blank=True,
        choices=[
            ('', _('Aucune')),
            ('bounce', _('Bounce')),
            ('pulse', _('Pulse')),
            ('shake', _('Shake')),
            ('wiggle', _('Wiggle')),
        ],
        verbose_name=_("Animation CSS")
    )

    # ------- ACCESSIBILITE -------
    aria_label = models.CharField(max_length=200, null=True, blank=True, verbose_name=_("Aria label"))
    tabindex = models.IntegerField(null=True, blank=True, verbose_name=_("Tabindex"))
    disabled = models.BooleanField(default=False, verbose_name=_("Désactivé"))

    def get_url(self):
        # 1) Lien vers une page du site → toujours la canonique
        if getattr(self, "page_target", None):
            try:
                return self.page_target.get_absolute_url()
            except Exception:
                pass

        # 2) Lien vers un test
        if getattr(self, "test_slug", None):
            try:
                from django.urls import reverse
                return reverse(
                    "jeiko_client_questionnaires_expert:test_question",
                    kwargs={"slug": self.test_slug, "position": 0},
                )
            except Exception:
                return f"/pass-test/{self.test_slug}/question/0/"

        # 3) Lien externe
        if getattr(self, "external_url", None):
            # Neutralisée au rendu (jeiko/liens.py) : une valeur écrite avant
            # le contrôle d'écriture ne doit pas s'exécuter non plus.
            from jeiko.liens import url_neutralisee
            return url_neutralisee(self.external_url, "lien") or "#"

        # 4) Lien vers une page du site → toujours la canonique
        if getattr(self, "custom_object_target", None):
            try:
                return self.custom_object_target.get_absolute_url()
            except Exception:
                pass

        # 5) Rien à lier
        return "#"

    def clean(self):
        # on peut en profiter pour normaliser dynamic_key
        if self.dynamic_key:
            self.dynamic_key = slugify(self.dynamic_key)

    def __str__(self):
        return self.label or "Bouton"


class ContentCalendar(models.Model):
    # Optionnel : on peut y lier un ou plusieurs types de rendez-vous, couleur, titre...
    title = models.CharField(max_length=150, default="Réserver un rendez-vous")
    appointment_type = models.ForeignKey(
        AppointmentType,  # modèle de type de RDV
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name=_("Type de rendez-vous par défaut")
    )
    calendar_config = models.ForeignKey(
        'calendars.GoogleCalendarConfig',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name=_("Calendrier (Prestataire)")
    )

    # Tu peux ajouter d'autres options ici (couleur, affichage...)

    def __str__(self):
        return self.title

HEX_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")

FORM_STYLE_SCHEMA = {
    "title_size_px": int,            # 12..48
    "title_color": str,              # "#RRGGBB"
    "button_text_color": str,        # "#RRGGBB"
    "button_bg_color": str,          # "#RRGGBB"
    "button_hover_bg_color": str,    # "#RRGGBB"
    "button_radius_px": int,         # 0..32
}

DEFAULT_FORM_STYLE = {
    "title_size_px": 22,
    "title_color": "#111827",
    "button_text_color": "#ffffff",
    "button_bg_color": "#2563eb",
    "button_hover_bg_color": "#1e40af",
    "button_radius_px": 12,
}

def default_form_style():
    return deepcopy(DEFAULT_FORM_STYLE)

def _coerce_int(v, field):
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, int):
        return v
    if isinstance(v, (float, Decimal)) and float(v).is_integer():
        return int(v)
    try:
        return int(str(v).strip())
    except Exception:
        raise ValidationError(_("%(field)s doit être un entier.") % {"field": field})

def _coerce_hex(v, field):
    s = str(v).strip()
    if not HEX_RE.match(s):
        raise ValidationError(_("%(field)s doit être une couleur hexadécimale (#rrggbb).") % {"field": field})
    return s.lower()

def validate_form_style(value: dict):
    if not isinstance(value, dict):
        raise ValidationError(_("Le style doit être un objet JSON."))
    out = {**DEFAULT_FORM_STYLE, **value}

    # Coercions + bornes
    out["title_size_px"]   = _coerce_int(out["title_size_px"], "title_size_px")
    out["button_radius_px"] = _coerce_int(out["button_radius_px"], "button_radius_px")

    if not (12 <= out["title_size_px"] <= 48):
        raise ValidationError(_("title_size_px doit être entre 12 et 48."))
    if not (0 <= out["button_radius_px"] <= 32):
        raise ValidationError(_("button_radius_px doit être entre 0 et 32."))

    out["title_color"]            = _coerce_hex(out["title_color"], "title_color")
    out["button_text_color"]      = _coerce_hex(out["button_text_color"], "button_text_color")
    out["button_bg_color"]        = _coerce_hex(out["button_bg_color"], "button_bg_color")
    out["button_hover_bg_color"]  = _coerce_hex(out["button_hover_bg_color"], "button_hover_bg_color")
    # si tout va bien, on ne retourne rien (Django ne s’en sert pas), mais on peut aussi
    # renvoyer `out` si tu utilises cette fonction à la main
    return


class ContentFormulaire(models.Model):
    name = models.CharField(max_length=200, verbose_name=_("Nom du formulaire"))
    description = models.TextField(blank=True, null=True)
    to_email = models.CharField(max_length=200, blank=True, null=True)
    from_email = models.CharField(max_length=200, blank=True, null=True)
    mail_subject = models.CharField(max_length=200, blank=True, null=True)
    success_message = models.TextField(blank=True, null=True)

    style = models.JSONField(default=default_form_style, validators=[validate_form_style])

    # Ajoute d’autres champs génériques si besoin (style, etc.)

    def __str__(self):
        return self.name or f"Formulaire #{self.pk}"

    def css_vars(self) -> dict:
        s = {**DEFAULT_FORM_STYLE, **(self.style or {})}
        return {
            "--cf-title-size": f"{int(s['title_size_px'])}px",
            "--cf-title-color": s["title_color"],
            "--cf-btn-fg": s["button_text_color"],
            "--cf-btn-bg": s["button_bg_color"],
            "--cf-btn-bg-hover": s["button_hover_bg_color"],
            "--cf-btn-radius": f"{int(s['button_radius_px'])}px",
        }

class ContentFormField(models.Model):
    TYPE_CHOICES = [
        ('text', _('Texte')),
        ('email', _('Email')),
        ('phone', _('Téléphone')),
        ('textarea', _('Zone de texte')),
        ('select', _('Liste déroulante')),
        ('checkbox', _('Case à cocher')),
        ('date', _('Date')),
        ('number', _('Numérique')),
        # Ajoute d’autres types si besoin
    ]
    formulaire = models.ForeignKey(
        ContentFormulaire,
        related_name='fields',
        on_delete=models.CASCADE
    )
    label = models.CharField(max_length=200)
    name = models.CharField(
        max_length=100,
        help_text=_("Nom technique (utilisé en HTML). Doit être unique dans le formulaire.")
    )
    placeholder = models.CharField(max_length=200, default="", blank=True)
    type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    required = models.BooleanField(default=False)
    options = models.JSONField(
        blank=True,
        null=True,
        help_text=(
            _("Pour les selects/checkbox : liste de dicts ex : "
            "[{'value': 'opt1', 'label': 'Option 1'}, {'value': 'opt2', 'label': 'Option 2'}]")
        )
    )
    order = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = ('formulaire', 'name')
        ordering = ['order', 'id']

    def __str__(self):
        return f"{self.label} ({self.formulaire})"


class ContentFormSubmission(models.Model):
    formulaire = models.ForeignKey(
        ContentFormulaire,
        related_name='submissions',
        on_delete=models.CASCADE
    )
    submitted_at = models.DateTimeField(auto_now_add=True)
    data = models.JSONField()  # { field_name: value }
    ip_address = models.GenericIPAddressField(blank=True, null=True)
    user_agent = models.CharField(max_length=300, blank=True, null=True)

    # Optionnel : user = models.ForeignKey(settings.AUTH_USER_MODEL, ...)

    def __str__(self):
        return f"Soumission {self.pk} ({self.formulaire})"


class ContentVideo(models.Model):
    class Source(models.TextChoices):
        FILE = "file", _("Fichier")
        EXTERNAL = "external", _("URL (YouTube/Vimeo/MP4)")

    class Provider(models.TextChoices):
        HTML5 = "html5", _("HTML5 (mp4/webm/ogg)")
        YOUTUBE = "youtube", _("YouTube")
        VIMEO = "vimeo", _("Vimeo")
        DAILYMOTION = "dailymotion", _("Dailymotion")
        OTHER = "other", _("Autre")

    # ----- Source / Provider -----
    source = models.CharField(
        max_length=16, choices=Source.choices, default=Source.FILE, db_index=True
    )
    provider = models.CharField(
        max_length=16, choices=Provider.choices, default=Provider.HTML5
    )

    # Fichier vidéo (local) OU URL externe
    file = models.FileField(
        upload_to="videos/%Y/%m/",
        blank=True, null=True,
        validators=[FileExtensionValidator(allowed_extensions=["mp4", "webm", "ogg", "mov"])],
        verbose_name=_("Fichier vidéo")
    )
    url = models.URLField(blank=True, null=True, verbose_name=_("URL vidéo (YouTube/Vimeo/MP4)"))

    # Poster (vignette) — on réutilise ton ImageContent (déjà géré ailleurs)
    poster = models.OneToOneField(
        "ImageContent",
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="poster_for_video",
        verbose_name=_("Poster (image d’aperçu)")
    )

    # ----- Accessibilité / Dimensions -----
    title = models.CharField(max_length=150, blank=True, default="", verbose_name=_("Titre (accessible)"))
    aria_label = models.CharField(max_length=200, blank=True, null=True, verbose_name=_("Aria label"))
    width = models.CharField(max_length=16, blank=True, null=True, help_text=_("ex: 100% ou 640px"))
    height = models.CharField(max_length=16, blank=True, null=True, help_text=_("ex: 360px"))
    aspect_ratio = models.CharField(
        max_length=16, blank=True, null=True,
        help_text=_("ex: 16/9, 4/3 (utilisé en CSS si width/height non définis)")
    )

    # ----- Comportement -----
    controls = models.BooleanField(default=True)
    autoplay = models.BooleanField(default=False)
    muted = models.BooleanField(default=False)
    loop = models.BooleanField(default=False)
    playsinline = models.BooleanField(default=True)
    preload = models.CharField(
        max_length=10,
        choices=[("auto", "auto"), ("metadata", "metadata"), ("none", "none")],
        default="metadata"
    )

    # ----- Plage de lecture -----
    start_time = models.PositiveIntegerField(blank=True, null=True, help_text=_("en secondes"))
    end_time = models.PositiveIntegerField(blank=True, null=True, help_text=_("en secondes"))

    # ----- Sous-titres (WebVTT) -----
    track_file = models.FileField(
        upload_to="videos/captions/%Y/%m/",
        blank=True, null=True,
        validators=[FileExtensionValidator(allowed_extensions=["vtt"])],
        help_text=_("Fichier de sous-titres .vtt")
    )
    track_lang = models.CharField(max_length=8, blank=True, default="fr")
    track_label = models.CharField(max_length=64, blank=True, default="Français")

    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    # ----- Validation & utilitaires -----
    def clean(self):
        # Cohérence source/fichier/url
        if self.source == self.Source.FILE and not self.file:
            raise ValidationError(_("Veuillez ajouter un fichier vidéo."))
        if self.source == self.Source.EXTERNAL and not self.url:
            raise ValidationError(_("Veuillez renseigner l’URL de la vidéo."))

        # Externes ≠ fichier local (provider externe seulement si EXTERNAL)
        if self.source == self.Source.FILE and self.provider != self.Provider.HTML5:
            raise ValidationError(_("Les providers externes s’utilisent avec une URL (source=external)."))

        # Plage de lecture
        if self.start_time and self.end_time and self.end_time <= self.start_time:
            raise ValidationError(_("`end_time` doit être > `start_time`."))

    def save(self, *args, **kwargs):
        # Déduction du provider depuis l’URL si EXTERNAL (pratique)
        if self.source == self.Source.EXTERNAL and self.url:
            u = self.url.lower()
            if "youtu.be" in u or "youtube.com" in u:
                self.provider = self.Provider.YOUTUBE
            elif "vimeo.com" in u:
                self.provider = self.Provider.VIMEO
            elif "dailymotion.com" in u:
                self.provider = self.Provider.DAILYMOTION
            elif any(u.endswith(ext) for ext in (".mp4", ".webm", ".ogg", ".m3u8")):
                self.provider = self.Provider.HTML5
            else:
                self.provider = self.Provider.OTHER
        super().save(*args, **kwargs)

    def get_src(self) -> str:
        """Retourne l’URL vidéo à utiliser (fichier local ou URL)."""
        if self.source == self.Source.FILE and self.file:
            try:
                return self.file.url
            except Exception:
                return ""
        from jeiko.liens import url_neutralisee
        return url_neutralisee(self.url, "media")

    def delete(self, *args, **kwargs):
        """
        Supprime proprement les fichiers vidéo / sous-titres du stockage.
        (Le poster dépend d'ImageContent et sera géré ailleurs si tu le supprimes.)
        """
        file_storage = self.file.storage if self.file else None
        file_name = self.file.name if self.file else None
        track_storage = self.track_file.storage if self.track_file else None
        track_name = self.track_file.name if self.track_file else None

        super().delete(*args, **kwargs)

        try:
            if file_storage and file_name:
                file_storage.delete(file_name)
        except Exception:
            pass
        try:
            if track_storage and track_name:
                track_storage.delete(track_name)
        except Exception:
            pass

    def __str__(self):
        return self.title or (self.url or (self.file.name if self.file else f"Vidéo {self.pk}"))


# content_defaults.py (recommandé) ou en bas de models.py
DYNAMIC_DEFAULTS = {
    "DYN_FAQ": {"items": [], "multiple": False},
    "DYN_TABS": {"items": [], "active": 0},
    "DYN_CAROUSEL": {"items": [], "autoplay": True, "interval": 5000},
    "DYN_PROGRESS": {"items": [], "progress": None},
    "DYN_TESTIMONIALS": {"items": [], "autoplay": True, "interval": 7000},
    "DYN_TESTIMONIALS_GRID": {"items": [], "perRow": 3, "rotate": True, "interval": 6000},
    "DYN_FILTER": {"items": [], "keys": ["title", "category"]},
    "DYN_COUNTDOWN": {"deadline": ""},
    "DYN_COUNTDOWN_CTA": {"deadline": "", "ctaText": "Réserver", "ctaHref": "#"},
    "DYN_ACCORDION_ADV": {"sections": []},
    "DYN_PRICING_TABLE": {"plans": [], "yearly": False},
    "DYN_GALLERY_FILTER": {"items": [], "categories": ["all"]},
    "DYN_STEPPER": {"items": [], "start": 0},
    "DYN_RATING": {"rating": 4.0, "count": 0, "max": 5, "editable": False},
}

# ---------- DYN 1) FAQ ----------
class DynFAQItem(models.Model):
    content = models.ForeignKey('Content', related_name='faq_items', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    answer = models.TextField(blank=True, default="")
    open = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"FAQ #{self.pk}"


# ---------- DYN 2) Tabs ----------
class DynTabItem(models.Model):
    content = models.ForeignKey('Content', related_name='tab_items', on_delete=models.CASCADE)
    label = models.CharField(max_length=120)
    body = models.TextField(blank=True, default="")  # texte riche autorisé (HTML)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.label or f"Tab #{self.pk}"


# ---------- DYN 3) Carousel ----------
class DynCarouselSlide(models.Model):
    content = models.ForeignKey('Content', related_name='carousel_slides', on_delete=models.CASCADE)
    image = models.ForeignKey('ImageContent', on_delete=models.PROTECT, null=True, blank=True, related_name='carousel_slides')
    external_src = models.URLField(blank=True, null=True, help_text=_("Optionnel si image externe/CDN"))
    alt = models.CharField(max_length=150, blank=True, default="")
    caption = models.CharField(max_length=200, blank=True, default="")
    href = models.URLField(blank=True, null=True, help_text=_("Lien au clic (optionnel)"))
    open_in_new_tab = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0, db_index=True)
    object_position = models.CharField(
        max_length=100,
        null=True,
        blank=True,
        default="center center",
        help_text=_("center center ou 50% 50% ou left top ou 0% 100%"),
    )
    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.caption or self.alt or f"Slide #{self.pk}"

    def get_src(self):
        if self.image:
            # privilégie les versions optimisées si disponibles
            if getattr(self.image, 'computer_size', None):
                return self.image.computer_size.url
            if getattr(self.image, 'full_size', None):
                return self.image.full_size.url
        from jeiko.liens import url_neutralisee
        return url_neutralisee(self.external_src, "media")


# ---------- DYN 4) Progress / Timeline ----------
class DynProgressStep(models.Model):
    content = models.ForeignKey('Content', related_name='progress_steps', on_delete=models.CASCADE)
    label = models.CharField(max_length=200)
    done = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.label or f"Step #{self.pk}"


# ---------- DYN 5 & 10) Testimonials (slider & grid) ----------
class DynTestimonialItem(models.Model):
    content = models.ForeignKey('Content', related_name='testimonial_items', on_delete=models.CASCADE)
    quote = models.TextField()
    author = models.CharField(max_length=120, blank=True, default="")
    role = models.CharField(max_length=120, blank=True, default="")
    avatar = models.ForeignKey('ImageContent', on_delete=models.SET_NULL, null=True, blank=True, related_name='testimonial_avatars')
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return (self.author or "Témoignage") + f" #{self.pk}"


# ---------- DYN 6) Live Filter items ----------
class DynLiveFilterItem(models.Model):
    content = models.ForeignKey('Content', related_name='livefilter_items', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    category = models.CharField(max_length=120, blank=True, default="")
    description = models.TextField(blank=True, default="")
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"Item #{self.pk}"


# ---------- DYN 8) Accordion avancé (sections + enfants) ----------
class DynAccordionSection(models.Model):
    content = models.ForeignKey('Content', related_name='accordion_sections', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    open = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"Section #{self.pk}"


class DynAccordionChild(models.Model):
    section = models.ForeignKey('DynAccordionSection', related_name='children', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    body = models.TextField(blank=True, default="")
    open = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"Child #{self.pk}"


# ---------- DYN 9) Pricing table ----------
class DynPricingPlan(models.Model):
    content = models.ForeignKey('Content', related_name='pricing_plans', on_delete=models.CASCADE)
    name = models.CharField(max_length=120)
    price_monthly = models.DecimalField(max_digits=9, decimal_places=2, default=0)
    price_yearly = models.DecimalField(max_digits=9, decimal_places=2, null=True, blank=True, help_text=_("Si vide, calcule 10× mensuel côté rendu"))
    popular = models.BooleanField(default=False)
    cta_label = models.CharField(max_length=80, blank=True, default="Choisir")
    cta_href = models.URLField(blank=True, null=True)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.name or f"Plan #{self.pk}"

class DynPricingFeature(models.Model):
    plan = models.ForeignKey('DynPricingPlan', related_name='features', on_delete=models.CASCADE)
    label = models.CharField(max_length=200)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.label or f"Feature #{self.pk}"


# ---------- DYN 12) Galerie filtrable ----------
class DynGalleryItem(models.Model):
    content = models.ForeignKey('Content', related_name='gallery_items', on_delete=models.CASCADE)
    image = models.ForeignKey('ImageContent', on_delete=models.PROTECT, related_name='gallery_items')
    category = models.CharField(max_length=120, blank=True, default="")
    title = models.CharField(max_length=200, blank=True, default="")
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"Image #{self.pk}"


# ---------- DYN 13) Stepper ----------
class DynStepperStep(models.Model):
    content = models.ForeignKey('Content', related_name='stepper_steps', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    body = models.TextField(blank=True, default="")
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"Étape #{self.pk}"



# ---------- DYN 14/15) Resource Config (Carousel or Grid) ----------
class DynResourceConfig(models.Model):
    """
    Configuration for dynamic resource listing (Carousel or Grid).
    Linked to Content (OneToOne).
    """
    SOURCE_PRODUCT = "PRODUCT"
    SOURCE_CUSTOM_OBJECT = "CUSTOM_OBJECT"
    SOURCE_EXPERT_TEST = "EXPERT_TEST"
    SOURCE_PAGE = "PAGE"

    SOURCE_CHOICES = [
        (SOURCE_PRODUCT, _("Produits")),
        (SOURCE_CUSTOM_OBJECT, _("Objets Personnalisés")),
        (SOURCE_EXPERT_TEST, _("Questionnaires Expert")),
        (SOURCE_PAGE, _("Pages")),
    ]

    source_type = models.CharField(
        max_length=50,
        choices=SOURCE_CHOICES,
        default=SOURCE_PRODUCT,
        verbose_name=_("Source de contenu")
    )

    # Filtering options
    product_type = models.ForeignKey(
        'shop.ProductType',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name=_("Type de produit (si source Produit)")
    )
    custom_object_model = models.ForeignKey(
        'custom_objects.CustomObjectModel',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        verbose_name=_("Modèle d'objet (si source Objet Personnalisé)")
    )
    # Generic category filtering (for Pages / Products / CustomObjects if applicable)
    category = models.ForeignKey(
        'administration_pages.Category',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="resource_configs",
        verbose_name=_("Catégorie")
    )
    sub_category = models.ForeignKey(
        'administration_pages.Category',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="resource_configs_sub",
        verbose_name=_("Sous-catégorie")
    )

    # Display options
    limit = models.PositiveIntegerField(
        default=0,
        verbose_name=_("Limite d'éléments (0 = tous)"),
        help_text=_("Combien d'éléments charger au maximum.")
    )
    
    # Grid layout options (nb columns per device)
    columns_computer = models.PositiveIntegerField(default=3, verbose_name=_("Colonnes (Desktop)"), null=True, blank=True)
    columns_laptop = models.PositiveIntegerField(default=3, verbose_name=_("Colonnes (Laptop)"), null=True, blank=True)
    columns_tablet = models.PositiveIntegerField(default=2, verbose_name=_("Colonnes (Tablet)"), null=True, blank=True)
    columns_phone = models.PositiveIntegerField(default=1, verbose_name=_("Colonnes (Mobile)"), null=True, blank=True)

    # Carousel specific
    interval = models.PositiveIntegerField(
        default=5000,
        verbose_name=_("Intervalle (ms)"),
        help_text=_("Durée d'affichage par slide (si carrousel).")
    )

    # UI Texts
    button_label = models.CharField(
        max_length=100,
        blank=True, default="Voir",
        verbose_name=_("Libellé du bouton (item)"),
        help_text=_("Ex: 'Lire la suite', 'Commencer le test'...")
    )
    load_more_label = models.CharField(
        max_length=100,
        blank=True, default="Afficher plus",
        verbose_name=_("Libellé bouton 'Charger plus'")
    )

    def __str__(self):
        return f"ResourceConfig ({self.source_type})"

class Content(models.Model):
    bloc = models.OneToOneField(
        'Bloc',
        on_delete=models.CASCADE,
        related_name='content',
    )

    CONTENT_TYPE_CHOICES = [
        ("NOT_SET", _("Non défini")),
        ("TEXT", _("Texte")),
        ("IMAGE", _("Image")),
        ("TEXT_QUESTIONNAIRE", _("Texte avec balises")),
        ("CHART", _("Graphique")),
        ("BUTTON", _("Bouton")),
        ("CALENDAR", _("Calendrier")),
        ("FORM", _("Formulaire")),
        ("VIDEO", _("Vidéo")),

        # Dynamiques
        ("DYN_FAQ", _("FAQ (accordéon)")),
        ("DYN_TABS", _("Onglets (tabs)")),
        ("DYN_CAROUSEL", _("Carrousel / Slider")),
        ("DYN_PROGRESS", _("Progression / Timeline")),
        ("DYN_TESTIMONIALS", _("Témoignages (slider)")),
        ("DYN_FILTER", _("Filtre / Recherche live")),
        ("DYN_COUNTDOWN", _("Compteur régressif (countdown)")),
        ("DYN_ACCORDION_ADV", _("Accordéon avancé (multi-niveaux)")),
        ("DYN_PRICING_TABLE", _("Table de prix (comparatif)")),
        ("DYN_TESTIMONIALS_GRID", _("Témoignages (grille + rotation)")),
        ("DYN_COUNTDOWN_CTA", _("Countdown + CTA")),
        ("DYN_GALLERY_FILTER", _("Galerie filtrable (portfolio)")),
        ("DYN_STEPPER", _("Stepper (parcours / wizard)")),
        ("DYN_RATING", _("Avis / Étoiles (rating)")),
        
        # New resource types
        ("DYN_RESOURCE_CAROUSEL", _("Ressources (Carrousel)")),
        ("DYN_RESOURCE_GRID", _("Ressources (Grille)")),
    ]

    content_type = models.CharField(
        max_length=32,
        default="NOT_SET",
        choices=CONTENT_TYPE_CHOICES,
        db_index=True,
    )

    # Données génériques pour TOUS les blocs dynamiques (DYN_*)
    # Exemple pour DYN_FAQ: {"items":[{"title":"Q1","content":"R1","open":false}, ...]}
    data = models.JSONField(default=dict, blank=True)

    # Liens vers sous-modèles (types "classiques")
    content_text = models.OneToOneField(
        'ContentText',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_image = models.OneToOneField(
        'ContentImage',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_text_questionnaire = models.OneToOneField(
        'ContentTextQuestionnaire',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_chart = models.OneToOneField(
        'ContentChartQuestionnaire',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_button = models.OneToOneField(
        'ContentButton',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_calendar = models.OneToOneField(
        'ContentCalendar',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_formulaire = models.OneToOneField(
        'ContentFormulaire',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )

    content_video = models.OneToOneField(
        "ContentVideo",
        on_delete=models.CASCADE,
        null=True, blank=True,
        related_name="parent_content",
    )

    content_resource_config = models.OneToOneField(
        'DynResourceConfig',
        on_delete=models.CASCADE,
        null=True, blank=True,
    )

    is_hero = models.BooleanField(
        default=False,
        db_index=True
    )

    # Mapping pratique pour factoriser
    CHILD_BY_TYPE = {
        "TEXT": "content_text",
        "IMAGE": "content_image",
        "TEXT_QUESTIONNAIRE": "content_text_questionnaire",
        "CHART": "content_chart",
        "BUTTON": "content_button",
        "CALENDAR": "content_calendar",
        "FORM": "content_formulaire",
        "VIDEO": "content_video",
        "DYN_RESOURCE_CAROUSEL": "content_resource_config",
        "DYN_RESOURCE_GRID": "content_resource_config",
        # DYN_* => stockés dans `data`
    }

    @property
    def is_dynamic(self) -> bool:
        return self.content_type.startswith("DYN_")

    def reset(self):
        """
        Supprime proprement la sous-instance liée et/ou les fichiers,
        vide `data` pour les dynamiques, et repasse en NOT_SET.
        """
        # 1) Supprime la sous-instance si type "classique"
        attr = self.CHILD_BY_TYPE.get(self.content_type)
        if attr:
            child = getattr(self, attr, None)
            if child:
                # La relation part de Content vers son satellite. Supprimer le
                # satellite alors que Content le référence encore peut faire
                # remonter la cascade jusqu'au Content lui-même. On détache
                # donc d'abord, puis seulement on détruit le satellite.
                setattr(self, attr, None)
                self.save(update_fields=[attr])
                # Si le child contient des FileField/ImageField, supprime-les proprement
                for field in child._meta.get_fields():
                    if hasattr(field, 'upload_to'):  # heuristique FileField/ImageField
                        f = getattr(child, field.name, None)
                        if f:
                            try:
                                f.delete(save=False)
                            except Exception:
                                pass
                child.delete()

        # 2) Vide les données dynamiques si DYN_*
        if self.is_dynamic:
            self.data = {}

        # 3) Reset le type
        self.content_type = "NOT_SET"
        self.save()

    def clear_dynamic_related(self):
        """
        Supprime tous les items relationnels associés au contenu dynamique courant.
        À appeler avant de repasser en NOT_SET, ou quand on change de type DYN_*.
        """
        # FAQ
        self.faq_items.all().delete()
        # Tabs
        self.tab_items.all().delete()
        # Carousel
        self.carousel_slides.all().delete()
        # Progress steps
        self.progress_steps.all().delete()
        # Testimonials (slider + grid)
        self.testimonial_items.all().delete()
        # Live filter
        self.livefilter_items.all().delete()
        # Accordion avancé (+ enfants via cascade)
        self.accordion_sections.all().delete()
        # Pricing (features via cascade)
        self.pricing_plans.all().delete()
        # Gallery
        self.gallery_items.all().delete()
        # Stepper
        self.stepper_steps.all().delete()
        # Resource Config (OneToOne)
        if self.content_resource_config:
            self.content_resource_config.delete()
            self.content_resource_config = None
        # Snapshot JSON
        self.data = {}
        self.save()

    def __str__(self):
        return f"Content #{self.pk} — {self.content_type}"


class CSSParameters(models.Model):
    object_id = models.CharField(
        default="",
        null=True,
        blank=True,
        verbose_name=_("ID de l'objet"),
        max_length=100,
    )

    object_classes = models.CharField(
        default="",
        null=True,
        blank=True,
        verbose_name=_("Classes de l'objet"),
        max_length=200,
    )

    before = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name=_('CSS before'),
    )

    current = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name='CSS',
    )

    after = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name=_('CSS after'),
    )

    hover = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name=_('CSS hover'),
    )
    custom = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name=_("CSS personnalisé")
    )

    content = models.ForeignKey(
        Content,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="CSS_parameters",

    )
