"""
Recalcule le visuel « héros » de chaque page (28/09/2026).

Le choix du héros ignorait les fonds de bloc, et le carrousel ne tenait pas
compte du drapeau : la première image d'une page pouvait partir en
`loading="lazy"`, sans `fetchpriority="high"` (relevé par PageSpeed). Le code
est corrigé, mais le drapeau n'est recalculé qu'à la prochaine modification
d'une page — sur un site en service, des mois plus tard. Cette migration le
recalcule une fois pour toutes les pages, à la mise à jour.

Elle appelle la vraie fonction plutôt qu'une copie figée : le calcul est une
lecture de l'état courant, pas une transformation de schéma, et une seconde
version de la règle finirait par diverger. Le prix de ce choix : elle doit
passer APRÈS toute migration qui ajoute une colonne lue par ce calcul. Elle
était en 0063, avant `0064` (`ImageContent.decorative`), et échouait pour
chaque page de chaque site — d'où sa place en fin de chaîne. Elle a été en
0068 ; `0069` (les langues du site) ajoute des colonnes à `Page`. Le calcul
d'aujourd'hui ne les lit pas, mais la règle ne se discute pas au cas par cas :
le recalcul passe APRÈS toute migration de schéma de ce module
(`tests/test_migration_des_heros.py`). La voici donc en 0070, et 0068 est
vide. Une base qui avait joué 0068 recalcule une seconde fois — c'est sans
effet, le calcul est idempotent.

Si une migration FUTURE ajoute à nouveau une colonne lue par ce calcul, une
base qui rejoue toute la chaîne (installation neuve) retombera dans ce cas :
le premier échec de schéma arrête alors le recalcul avec UNE ligne au journal,
au lieu d'une trace par page. Rien n'est perdu : une base neuve n'a que ses
pages légales, qui se recalculent à leur première modification.
"""

import logging

from django.db import migrations
from django.db.utils import OperationalError, ProgrammingError

logger = logging.getLogger(__name__)


def recalculer(apps, schema_editor):
    from django.db import transaction

    from jeiko.administration_pages.models import Page
    from jeiko.administration_pages.signals import recompute_page_hero

    try:
        with transaction.atomic():
            pages = list(Page.objects.all().only("pk"))
    except (OperationalError, ProgrammingError):
        logger.warning("Recalcul des héros sauté : schéma en avance sur cette étape.")
        return

    for page in pages:
        try:
            with transaction.atomic():
                recompute_page_hero(page)
        except (OperationalError, ProgrammingError):
            logger.warning(
                "Recalcul des héros arrêté : le schéma n'est pas celui qu'attend le "
                "code (page %s). Les héros se recalculent à la modification des pages.",
                page.pk,
            )
            return
        except Exception:
            # Une page abîmée ne doit pas bloquer la mise à jour du site.
            logger.exception("Héros non recalculé pour la page %s", page.pk)


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0069_site_multilingue"),
    ]

    operations = [
        migrations.RunPython(recalculer, migrations.RunPython.noop),
    ]
