"""
Réglage de la langue de l'administration, pour tout le site.

Le problème : l'administration n'existait qu'en français, et le seul moyen
d'en changer était la préférence de chaque compte. Un exploitant hispanophone
devait donc régler son profil, puis celui de chaque collaborateur. Ce réglage
pose la langue une fois ; la préférence d'un compte ne sert plus qu'à y déroger.

Ce qu'il ne fait pas : il ne change rien pour les visiteurs. Le site public
reste dans la langue où son contenu est écrit (voir `jeiko/i18n.py`).
"""
from django import forms
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import redirect, render
from django.utils import translation
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views import View
from django.views.decorators.cache import never_cache

from jeiko.i18n import langues_disponibles

from .models import WebSite


class LangueAdminForm(forms.Form):
    langue_admin = forms.ChoiceField(label=_("Langue de l'administration"))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # La liste vient des RÉGLAGES (`LANGUAGES`), comme pour la préférence
        # d'un compte : on ne propose que ce que le site sait afficher.
        self.fields["langue_admin"].choices = langues_disponibles()


@method_decorator(never_cache, name="dispatch")
class LangueAdminView(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = "users.config_edit_site"
    raise_exception = True
    template_name = "administration/langue/update.html"

    def get(self, request):
        site = WebSite.objects.first()
        if site is None:
            messages.error(request, _("Aucun site n'est encore configuré."))
            return redirect("jeiko_administration:main")
        form = LangueAdminForm(initial={"langue_admin": site.langue_admin})
        return render(request, self.template_name, {"form": form})

    def post(self, request):
        site = WebSite.objects.first()
        if site is None:
            return redirect("jeiko_administration:main")
        form = LangueAdminForm(request.POST)
        if form.is_valid():
            site.langue_admin = form.cleaned_data["langue_admin"]
            # `save()` et non `update()` : le signal post_save vide le cache de
            # `WebSite`, que le middleware de langue lit à chaque requête.
            site.save(update_fields=["langue_admin"])
            # La confirmation s'affiche à la requête suivante, mais elle est
            # rédigée ici : sans cela elle sortirait dans l'ancienne langue.
            from jeiko.i18n import langue_de_l_utilisateur
            with translation.override(
                langue_de_l_utilisateur(request.user) or site.langue_admin
            ):
                messages.success(request, str(_("Langue de l'administration enregistrée.")))
            return redirect("jeiko_administration:langue_admin")
        return render(request, self.template_name, {"form": form}, status=400)


class LanguesDuSiteForm(forms.Form):
    """Le site PUBLIC en plusieurs langues — voir `jeiko/langues_du_site.py`."""

    multilingue = forms.BooleanField(
        required=False,
        label=_("Site en plusieurs langues"),
        help_text=_("Décoché, le site reste dans une seule langue : rien ne change pour les visiteurs."),
    )
    langues = forms.MultipleChoiceField(
        required=False,
        widget=forms.CheckboxSelectMultiple,
        label=_("Langues ajoutées"),
        help_text=_("Chaque langue cochée reçoit ses adresses sous son préfixe (/en/, /es/…). "
                    "La langue d'origine garde les siennes, sans préfixe."),
    )

    def __init__(self, *args, **kwargs):
        from jeiko.langues_du_site import codes_proposes, nom_de_la_langue

        super().__init__(*args, **kwargs)
        self.fields["langues"].choices = [(c, nom_de_la_langue(c)) for c in codes_proposes()]

    def clean(self):
        donnees = super().clean()
        if donnees.get("multilingue") and not donnees.get("langues"):
            self.add_error("langues", _("Cochez au moins une langue, ou désactivez l'option."))
        return donnees


@method_decorator(never_cache, name="dispatch")
class LanguesDuSiteView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Active le site en plusieurs langues et choisit lesquelles.

    Retirer une langue dépublie ses pages sans les supprimer : l'écran le dit
    avant, et le message d'après en donne le nombre.
    """

    permission_required = "users.config_edit_site"
    raise_exception = True
    template_name = "administration/langue/site.html"

    def _contexte(self, form):
        from jeiko.administration_pages.models import Page
        from jeiko.langues_du_site import langue_d_origine, nom_de_la_langue

        return {
            "form": form,
            # En minuscules : le nom s'insère dans une phrase (« écrit en français »).
            "langue_d_origine": nom_de_la_langue(langue_d_origine()).lower(),
            "pages_traduites": Page.objects.exclude(langue="").count(),
        }

    def get(self, request):
        site = WebSite.objects.first()
        if site is None:
            messages.error(request, _("Aucun site n'est encore configuré."))
            return redirect("jeiko_administration:main")
        form = LanguesDuSiteForm(initial={
            "multilingue": site.multilingue, "langues": site.langues_du_site,
        })
        return render(request, self.template_name, self._contexte(form))

    def post(self, request):
        from jeiko.administration_pages.versions import VersionImpossible, regler_les_langues

        site = WebSite.objects.first()
        if site is None:
            return redirect("jeiko_administration:main")
        form = LanguesDuSiteForm(request.POST)
        if form.is_valid():
            try:
                eteintes = regler_les_langues(
                    site,
                    multilingue=form.cleaned_data["multilingue"],
                    langues=form.cleaned_data["langues"],
                )
            except VersionImpossible as refus:
                form.add_error("langues", str(refus))
            else:
                messages.success(request, _("Langues du site enregistrées."))
                if eteintes.pages or eteintes.fiches:
                    messages.warning(request, _(
                        "%(pages)s page(s) et %(fiches)s fiche(s) traduite(s) ont été dépubliées : "
                        "leur langue n'est plus active."
                    ) % {"pages": eteintes.pages, "fiches": eteintes.fiches})
                return redirect("jeiko_administration:langues_du_site")
        return render(request, self.template_name, self._contexte(form), status=400)
