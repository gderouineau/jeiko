"""Le CSS reste un dernier recours, après thème et polices natifs."""
from django import forms
from .models import WebSite
from .css_site import compiler_css_site
from django.utils.translation import gettext_lazy as _


class CssSiteForm(forms.ModelForm):
    class Meta:
        model = WebSite
        fields = ['css_global']
        widgets = {'css_global': forms.Textarea(attrs={'rows': 22, 'spellcheck': 'false'})}
        help_texts = {'css_global': _('Règles CSS complètes : p.intro { color: var(--jk-accent); }. Maximum 50 000 caractères. Imports et ressources externes interdits.')}

    def clean_css_global(self):
        css = self.cleaned_data['css_global']
        compiler_css_site(css)
        return css
