from django.contrib import admin

from jeiko.administration.models import WebSite, Fonts, Font, Logo, Favicon, Legals

# Absents du Django admin, volontairement (Fable 1 §1.5) : `SocialProvider`,
# `MailSettings`, `GoogleApi`. Ils portent le secret OAuth et la clé privée
# Apple, le mot de passe SMTP, la clé PageSpeed — que le Django admin affiche
# déchiffrés dans ses formulaires. Leurs écrans de JEIKO (Réglages) les
# couvrent, ne renvoient jamais un secret enregistré, et sont gardés par les
# permissions de configuration. Même raison dans `calendars/admin.py`,
# `courses/admin.py` et `users/admin.py`.

admin.site.register(WebSite)
admin.site.register(Fonts)
admin.site.register(Font)
admin.site.register(Logo)
admin.site.register(Favicon)
admin.site.register(Legals)
