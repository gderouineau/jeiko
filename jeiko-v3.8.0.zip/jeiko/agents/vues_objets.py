# jeiko/agents/vues_objets.py
"""
Objets personnalisés et produits — l'API qui remplit les gabarits.

À quoi cela sert vraiment
-------------------------
Un `CustomObjectModel` est un **type de fiche** : « Produit », « Réalisation »,
« Membre de l'équipe ». Il déclare des champs (`CustomObjectField`) et désigne
une `Page` qui lui sert de gabarit. Cette page contient des jetons `[%code%]`
qui seront remplacés par les valeurs de chaque fiche.

Autrement dit : **une page dessinée une fois, autant de pages publiées qu'il y
a de fiches.** C'est le cas d'usage central de cette API — un agent ne construit
pas trente pages produit à la main, il crée trente fiches.

Un `Product` ajoute à une fiche ce qui relève de la vente : référence, prix,
TVA, stock. La fiche porte le contenu, le produit porte le commerce ; les deux
sont liés par `Product.content`.

Le point d'entrée qui compte
----------------------------
`GET /modeles/` liste les types de fiches **avec leurs champs, leurs codes et
leurs types**. Sans lui, un agent devrait deviner que le champ s'appelle
`prix_barre` et qu'il attend du texte court. Avec lui, il lit le contrat puis
le remplit. C'est le pendant du guide pour les pages.

Ce qui est délibérément absent
------------------------------
**La suppression**, comme pour les pages : un agent crée et corrige, il
n'efface pas. Une fiche supprimée emporte ses valeurs, et souvent le produit
qui la référence.

**Le téléversement d'images.** Les champs image acceptent l'identifiant d'une
image déjà présente dans la médiathèque. Le fichier passe par l'administration,
où s'appliquent les validateurs de S-10 — plafond de poids et garde
anti-bombe de décompression.

Un site en plusieurs langues
----------------------------
Une fiche a une version par langue, comme une page : `POST
/objets/<id>/versions/` duplique la fiche d'origine dans une langue, en
brouillon — c'est ensuite une fiche comme une autre, que `PATCH /objets/<id>/`
traduit puis publie. Le produit reste unique et se rattache à la fiche
d'origine. Les règles sont dans `jeiko/langues_du_site.py`.
"""

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
import re

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Prefetch

from jeiko import langues_du_site
from jeiko.liens import url_sure
from django.shortcuts import get_object_or_404
from django.utils.text import slugify

from jeiko.administration_pages.models import ImageContent, Page
from jeiko.custom_objects.models import (
    CustomObject, CustomObjectField, CustomObjectModel, CustomObjectValue,
)
from jeiko.shop.models import Product, ProductType

from .vues_api import (
    CorpsInvalide, VueAgent, appliquer_les_traductions, borne, erreur, ok,
    slug_d_adresse, traductions_en_dict,
)

VOIR_OBJET = "custom_objects.view_customobject"
AJOUTER_OBJET = "custom_objects.add_customobject"
MODIFIER_OBJET = "custom_objects.change_customobject"
VOIR_PRODUIT = "shop.view_product"
AJOUTER_PRODUIT = "shop.add_product"
MODIFIER_PRODUIT = "shop.change_product"
AJOUTER_MODELE = "custom_objects.add_customobjectmodel"
MODIFIER_MODELE = "custom_objects.change_customobjectmodel"
VOIR_TYPE_PRODUIT = "shop.view_producttype"
AJOUTER_TYPE_PRODUIT = "shop.add_producttype"
MODIFIER_TYPE_PRODUIT = "shop.change_producttype"


def _modele_par_id_ou_slug(valeur):
    """Refuse de choisir entre un id et le slug numérique d'un autre modèle.

    Les anciennes intégrations gardent leurs ids/slugs non ambigus. En cas de
    collision, id:… et slug:… permettent de préciser la cible, y compris dans
    un filtre GET où toutes les valeurs sont des chaînes. Un entier JSON ne
    suffit pas à lever l'ambiguïté : les anciennes vues le convertissaient
    aussi en texte et l'intention ne pouvait pas être déduite.
    """
    if valeur is not None and (isinstance(valeur, bool) or not isinstance(valeur, (str, int))):
        raise CorpsInvalide("« modele » attend un id ou un slug, pas une structure ni un booléen.")
    texte = str(valeur or "").strip()
    explicite = None
    if texte.startswith(("id:", "slug:")):
        explicite, texte = texte.split(":", 1)
        texte = texte.strip()
        if not texte:
            raise CorpsInvalide(f"« modele » : la référence {explicite}: est vide.")

    # isdigit() accepte « ² », mais int() le refuse : la conversion levait un
    # 500. Les ids explicites sont des chiffres ASCII et bornés avant l'ORM.
    numerique = texte.isascii() and texte.isdecimal()
    identifiant = int(texte) if numerique and len(texte) <= 19 else None
    if identifiant is not None and not 0 < identifiant <= 9223372036854775807:
        identifiant = None
    if explicite == "id" and identifiant is None:
        raise CorpsInvalide("« modele » : id: attend un identifiant entier positif valide.")

    par_slug = (CustomObjectModel.objects.filter(slug=texte).first()
                if explicite != "id" else None)
    par_id = (CustomObjectModel.objects.filter(pk=identifiant).first()
              if identifiant is not None and explicite != "slug" else None)
    if par_slug is not None and par_id is not None and par_slug.pk != par_id.pk:
        raise CorpsInvalide(
            f"Modèle ambigu « {texte} » : {par_id.name} (id {par_id.pk}, slug {par_id.slug}) "
            f"ou {par_slug.name} (id {par_slug.pk}, slug {par_slug.slug}). "
            f"Utilisez « id:{par_id.pk} » ou « slug:{par_slug.slug} » pour choisir explicitement."
        )
    return par_id or par_slug


def _type_produit_par_id_ou_code(valeur):
    """Résout un type commercial par son id ou son code stable."""
    texte = str(valeur or "").strip()
    type_produit = ProductType.objects.filter(code=texte).first()
    if texte.isdigit():
        type_produit = ProductType.objects.filter(pk=int(texte)).first() or type_produit
    return type_produit


# --------------------------------------------------------------------------- #
#  Sérialisation
# --------------------------------------------------------------------------- #
def _champ_en_dict(champ):
    return {
        "code": champ.code,
        "libelle": champ.label,
        "type": champ.field_type,
        "obligatoire": champ.required,
        "aide": champ.help_text or "",
    }


def _type_de_produit_en_dict(type_produit):
    return {
        "id": type_produit.id,
        "nom": type_produit.name,
        "code": type_produit.code,
        "nature": type_produit.kind,
        # `expedition` décide si le produit CONSOMME DU STOCK — c'est la seule
        # question qui compte pour le panier, le JSON-LD et le décrément à la
        # commande. La taire l'a rendue invisible : un type créé « service »
        # gardait `requires_shipping=True` par défaut, et l'abonnement
        # redevenait un produit qui s'épuise, donc invendable.
        "expedition": type_produit.requires_shipping,
        "modele_de_fiche": (
            type_produit.content_model.slug
            if type_produit.content_model_id else None
        ),
        # Le nom et le code dans les autres langues du site :
        # {"en": {"nom": "Workshops", "slug": "workshops"}} — le « slug » est
        # le segment de l'adresse des produits (/en/shop/workshops/…).
        "traductions": traductions_en_dict(type_produit),
    }


def _modele_en_dict(modele):
    return {
        "id": modele.id,
        "nom": modele.name,
        "slug": modele.slug,
        "est_un_produit": modele.is_product,
        "gabarit_de_page": (
            {"id": modele.page_template_id, "titre": modele.page_template.title}
            if modele.page_template_id else None
        ),
        "champs": [
            _champ_en_dict(c)
            for c in modele.fields.all().order_by("position", "id")
        ],
        # Le nom et le slug dans les autres langues du site :
        # {"en": {"nom": "Articles", "slug": "articles"}} → /en/co/articles/…
        "traductions": traductions_en_dict(modele),
    }


def _valeur_en_dict(valeur):
    """La valeur d'un champ, réduite à ce qui a du sens pour son type."""
    champ = valeur.field
    rendu = {"code": champ.code, "type": champ.field_type}

    if champ.field_type in ("text", "rich_text"):
        rendu["valeur"] = valeur.value_text or ""
    elif champ.field_type == "image":
        rendu["image_id"] = valeur.image_id
    elif champ.field_type == "video":
        rendu["url"] = valeur.video_url or ""
    elif champ.field_type == "button":
        rendu["bouton"] = {
            "libelle": valeur.button_label or "",
            "page_id": valeur.button_page_id,
            "url_externe": valeur.button_external_url or "",
            "questionnaire": valeur.button_test_slug or "",
        }
    return rendu


def _metadonnees_de_l_objet(objet):
    """Le titre et la description de recherche d'une fiche, jamais None."""
    meta = getattr(objet, "metadata", None)
    return {
        "titre": getattr(meta, "title", "") or "",
        "description": getattr(meta, "description", "") or "",
    }


def _appliquer_metadonnees_objet(objet, donnees):
    """
    Écrit le SEO propre à cette fiche.

    Le modèle n'existe pas tant qu'on ne l'a pas créé — d'où le
    `get_or_create`. C'est le même dispositif que pour les pages ordinaires,
    sur un modèle distinct (`CustomObjectMetadata`), parce que la page qui
    rend la fiche est un gabarit partagé : ses propres métadonnées vaudraient
    pour toutes les fiches du modèle à la fois.
    """
    from jeiko.custom_objects.models import CustomObjectMetadata

    if not isinstance(donnees, dict):
        raise CorpsInvalide("« metadonnees » doit être un objet.")
    inconnues = sorted(set(donnees) - {"titre", "description"})
    if inconnues:
        raise CorpsInvalide(
            f"Clé(s) inconnue(s) sous « metadonnees » : {', '.join(inconnues)}. "
            f"Acceptées : titre, description."
        )

    meta, _ = CustomObjectMetadata.objects.get_or_create(obj=objet)
    modifies = []
    if "titre" in donnees:
        meta.title = str(donnees["titre"])[:100]
        modifies.append("title")
    if "description" in donnees:
        meta.description = str(donnees["description"])
        modifies.append("description")
    if modifies:
        meta.save(update_fields=modifies)
    return [f"metadonnees.{c}" for c in modifies]


def _version_en_dict(version):
    return {
        "id": version.id,
        "langue": version.langue or langues_du_site.langue_d_origine(),
        "publie": version.is_published,
        "url": version.adresse_propre(),
    }


def _objet_en_dict(objet):
    return {
        "id": objet.id,
        "titre": objet.title,
        "slug": objet.slug,
        "publie": objet.is_published,
        "modele": {"id": objet.model_id, "nom": objet.model.name},
        "image_principale_id": objet.main_image_id,
        "valeurs": [
            _valeur_en_dict(v)
            for v in objet.values.select_related("field").order_by("field__position")
        ],
        "url": objet.get_absolute_url() if hasattr(objet, "get_absolute_url") else "",
        # Site en plusieurs langues : la langue de CETTE version, la fiche
        # d'origine dont elle est la traduction (null pour une originale), et
        # ses autres versions. Voir /langues/ et /objets/<id>/versions/.
        "langue": objet.langue or langues_du_site.langue_d_origine(),
        "version_d_origine": objet.traduction_de_id,
        "versions": [_version_en_dict(v) for v in objet.versions() if v.pk != objet.pk],
        # Le titre et la description des résultats de recherche.
        #
        # Ils vivent sur la FICHE, pas sur le produit ni sur le gabarit : le
        # gabarit est unique et sert toutes les fiches d'un modèle, donc y
        # mettre un titre le donnerait à toutes. Un produit, lui, n'en a pas —
        # il emprunte ceux de sa fiche.
        #
        # Sans ce point d'entrée, une boutique montée par un agent sortait
        # avec, pour chaque produit, le titre brut de la fiche et AUCUNE
        # description. Google reprend alors un morceau du corps, souvent le
        # menu ou un prix isolé.
        "metadonnees": _metadonnees_de_l_objet(objet),
    }


def _produit_en_dict(produit):
    return {
        "id": produit.id,
        "sku": produit.sku,
        "actif": produit.is_active,
        "prix_ht": str(produit.price_ht),
        # Ce que le client paie : l'API écrit TOUJOURS un prix HT, même sur
        # un site où l'écran saisit des prix TTC (Fable 2 §1.4).
        "prix_ttc": str(
            (Decimal(produit.price_ht or 0) * (1 + Decimal(produit.tax_rate or 0) / 100))
            .quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        ),
        "taux_tva": str(produit.tax_rate),
        "devise": produit.currency,
        "stock": produit.stock_quantity,
        "type": {"id": produit.type_id, "nom": produit.type.name if produit.type else ""},
        # La fiche d'ORIGINE : c'est elle que porte le produit. Ses versions
        # par langue sont des fiches à part entière (lire_objet, modifier_objet).
        "fiche": (
            {"id": produit.content_id, "titre": produit.content.title,
             "versions": [_version_en_dict(v) for v in produit.content.versions()[1:]]}
            if produit.content_id else None
        ),
    }


# --------------------------------------------------------------------------- #
#  Écriture d'une valeur
# --------------------------------------------------------------------------- #
def _ecrire_valeur(objet, champ, donnee):
    """
    Pose la valeur d'un champ, selon son type.

    Chaque type a sa colonne : mettre une URL de vidéo dans `value_text` la
    rendrait invisible au gabarit, sans qu'aucune erreur ne le signale. On
    refuse donc explicitement ce qui ne correspond pas au type déclaré.
    """
    valeur, _ = CustomObjectValue.objects.get_or_create(obj=objet, field=champ)
    modifies = []

    if champ.field_type in ("text", "rich_text"):
        valeur.value_text = str(donnee if donnee is not None else "")
        modifies.append("value_text")

    elif champ.field_type == "image":
        if donnee in (None, "", 0):
            valeur.image = None
        else:
            image = ImageContent.objects.filter(pk=donnee).first()
            if image is None:
                raise CorpsInvalide(
                    f"« {champ.code} » : aucune image nº {donnee} dans la "
                    f"médiathèque (lister_images), ou envoyez-la d'abord avec "
                    f"creer_image."
                )
            valeur.image = image
        modifies.append("image")

    elif champ.field_type == "video":
        try:
            valeur.video_url = url_sure(donnee, "media", champ.code)
        except ValueError as souci:
            raise CorpsInvalide(str(souci))
        modifies.append("video_url")

    elif champ.field_type == "button":
        if not isinstance(donnee, dict):
            raise CorpsInvalide(
                f"« {champ.code} » est un bouton : un objet est attendu, avec "
                f"« libelle » et l'une des destinations « page_id », "
                f"« url_externe » ou « questionnaire »."
            )
        valeur.button_label = str(donnee.get("libelle", ""))[:200]
        try:
            valeur.button_external_url = url_sure(
                donnee.get("url_externe", ""), "lien", f"{champ.code}.url_externe"
            )
        except ValueError as souci:
            raise CorpsInvalide(str(souci))
        valeur.button_test_slug = borne(type(valeur), "button_test_slug", donnee.get("questionnaire", ""))
        page_id = donnee.get("page_id")
        if page_id:
            page = Page.objects.filter(pk=page_id).first()
            if page is None:
                raise CorpsInvalide(f"« {champ.code} » : page nº {page_id} inconnue.")
            valeur.button_page = page
        elif "page_id" in donnee:
            valeur.button_page = None
        modifies.extend([
            "button_label", "button_external_url", "button_test_slug", "button_page",
        ])

    valeur.save(update_fields=modifies)
    return champ.code


def _appliquer_valeurs(objet, valeurs):
    """
    Écrit les champs présents. Ceux qu'on ne mentionne pas ne bougent pas.

    Un code inconnu est refusé AVEC la liste des codes valides : un agent qui
    se trompe de nom doit l'apprendre du premier coup, pas deviner.
    """
    if isinstance(valeurs, list):
        normalisees = {}
        for ligne in valeurs:
            if not isinstance(ligne, dict) or not ligne.get("code"):
                raise CorpsInvalide(
                    "Chaque valeur doit être un objet contenant « code » et "
                    "la donnée correspondant à son type."
                )
            code = ligne["code"]
            donnees = {k: v for k, v in ligne.items() if k not in {"code", "type"}}
            if len(donnees) != 1:
                raise CorpsInvalide(
                    f"La valeur « {code} » doit contenir une seule donnée "
                    "(valeur, image_id, url ou bouton)."
                )
            normalisees[code] = next(iter(donnees.values()))
        valeurs = normalisees
    if not isinstance(valeurs, dict):
        raise CorpsInvalide("« valeurs » doit être un objet ou la liste renvoyée par GET.")

    champs = {c.code: c for c in objet.model.fields.all()}
    inconnus = sorted(set(valeurs) - set(champs))
    if inconnus:
        raise CorpsInvalide(
            f"Champ(s) inconnu(s) pour le modèle « {objet.model.name} » : "
            f"{', '.join(inconnus)}. Codes acceptés : "
            f"{', '.join(sorted(champs)) or '(aucun)'}."
        )

    return [_ecrire_valeur(objet, champs[code], valeurs[code]) for code in valeurs]


# --------------------------------------------------------------------------- #
#  Modèles de fiche
# --------------------------------------------------------------------------- #
class ListeDesModeles(VueAgent):
    """
    Le contrat : quels types de fiches existent, et quels champs les composent.

    À lire AVANT toute création : c'est là qu'un agent apprend qu'un champ
    s'appelle `prix_barre` et qu'il attend du texte court.
    """

    permission_requise = VOIR_OBJET

    def get(self, request):
        modeles = CustomObjectModel.objects.prefetch_related("fields").select_related(
            "page_template"
        )
        return ok({"modeles": [_modele_en_dict(m) for m in modeles]})


# --------------------------------------------------------------------------- #
#  Fiches
# --------------------------------------------------------------------------- #
class ListeDesObjets(VueAgent):
    permission_requise = VOIR_OBJET

    def get(self, request):
        # Chaque fiche liste ses autres versions avec leur adresse : on charge
        # d'avance ce que cette adresse consulte (le modèle, le produit de
        # l'originale), plutôt qu'une requête par version.
        versions = CustomObject.objects.select_related("model")
        objets = CustomObject.objects.select_related(
            "model", "metadata", "product__type", "traduction_de__product__type",
        ).prefetch_related(
            "values__field",
            Prefetch("traductions", queryset=versions),
            Prefetch("traduction_de__traductions", queryset=versions),
        )
        modele = request.GET.get("modele")
        if modele:
            modele_obj = _modele_par_id_ou_slug(modele)
            if modele_obj is None:
                raise CorpsInvalide(f"Modèle « {modele} » inconnu. Utilisez son id ou son slug.")
            objets = objets.filter(model=modele_obj)
        # `?langue=en` : les seules versions de cette langue ; le code de la
        # langue d'origine donne les fiches d'origine.
        langue = request.GET.get("langue")
        if langue:
            objets = objets.filter(
                langue="" if langue == langues_du_site.langue_d_origine() else langue
            )
        return ok({"objets": [_objet_en_dict(o) for o in objets.order_by("-id")[:200]]})


class CreationObjet(VueAgent):
    permission_requise = AJOUTER_OBJET

    @transaction.atomic
    def post(self, request):
        corps = self.corps(
            request, connues={"modele", "titre", "slug", "valeurs"}
        )

        slug_modele = str(corps.get("modele") or "").strip()
        if not slug_modele:
            raise CorpsInvalide(
                "« modele » est obligatoire : l'id ou le slug du type de fiche. "
                "Voir /modeles/ pour la liste."
            )
        modele = _modele_par_id_ou_slug(corps.get("modele"))
        if modele is None:
            connus = ", ".join(
                CustomObjectModel.objects.values_list("slug", flat=True)
            )
            raise CorpsInvalide(
                f"Modèle « {slug_modele} » inconnu. Connus : {connus or '(aucun)'}."
            )

        titre = str(corps.get("titre") or "").strip()
        if not titre:
            raise CorpsInvalide("Un « titre » est obligatoire.")

        # Une fiche vit à /co/<modele>/<slug>/ : un slug avec espace ou « / »
        # créait une fiche introuvable, pourtant listée (Fable 2 §2).
        slug = slug_d_adresse(
            str(corps.get("slug") or "").strip() or slugify(titre), "slug",
            CustomObject._meta.get_field("slug").max_length or 200, a_la_racine=False,
        )
        if CustomObject.objects.filter(model=modele, slug=slug).exists():
            return erreur(
                f"Une fiche « {slug} » existe déjà pour ce modèle.",
                statut=409, slug=slug,
            )

        objet = CustomObject.objects.create(
            model=modele,
            title=borne(CustomObject, "title", titre),
            slug=slug,
            # Comme une page créée par un agent : non publiée. La mise en ligne
            # est une décision éditoriale, pas un effet de bord de la création.
            is_published=False,
        )

        if "valeurs" in corps:
            _appliquer_valeurs(objet, corps["valeurs"])

        return ok({"objet": _objet_en_dict(objet)}, statut=201)


class DetailObjet(VueAgent):
    permission_requise = VOIR_OBJET

    def get(self, request, objet_id):
        objet = get_object_or_404(
            CustomObject.objects.select_related("model"), id=objet_id
        )
        return ok({"objet": _objet_en_dict(objet)})

    @transaction.atomic
    def patch(self, request, objet_id):
        if not request.user.has_perm(MODIFIER_OBJET):
            return erreur("Modification de fiche non autorisée.", statut=403)

        objet = get_object_or_404(
            CustomObject.objects.select_related("model"), id=objet_id
        )
        corps = self.corps(request)
        # L'adresse d'une fiche d'origine est attribuée à la création. Celle
        # d'une VERSION se traduit : elle est née avec le slug de l'originale.
        modifiables = {"titre", "publie", "image_principale_id", "metadonnees", "valeurs"}
        if objet.traduction_de_id:
            modifiables.add("slug")
        inconnues = sorted(set(corps) - modifiables)
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) ou non modifiable(s) : {', '.join(inconnues)}. "
                "« slug » est attribué à la création et ne se modifie pas — sauf "
                "sur la version traduite d'une fiche, dont l'adresse se traduit."
            )
        if (objet.traduction_de_id and corps.get("publie")
                and objet.langue not in langues_du_site.langues_actives()):
            # Publier ici répondrait 200 pour une fiche que le site ne sert pas.
            raise CorpsInvalide(
                f"La langue « {objet.langue} » n'est pas activée pour le site : "
                f"cette version ne serait servie à aucune adresse. Activez "
                f"d'abord la langue (PATCH /langues/), puis publiez."
            )
        modifies = []

        if "slug" in corps:
            objet.slug = slug_d_adresse(
                str(corps["slug"] or "").strip(), "slug",
                CustomObject._meta.get_field("slug").max_length or 200, a_la_racine=False,
            )
            try:
                # Une adresse appartient à une seule fiche, toutes langues
                # confondues : c'est `clean()` qui le dit.
                objet.clean()
            except ValidationError as refus:
                return erreur(" ".join(refus.messages), statut=409, slug=objet.slug)
            modifies.append("slug")
        if "titre" in corps:
            objet.title = str(corps["titre"]).strip()[:200]
            modifies.append("title")
        if "publie" in corps:
            objet.is_published = bool(corps["publie"])
            modifies.append("is_published")
        if "image_principale_id" in corps:
            identifiant = corps["image_principale_id"]
            if identifiant in (None, "", 0):
                objet.main_image = None
            else:
                image = ImageContent.objects.filter(pk=identifiant).first()
                if image is None:
                    raise CorpsInvalide(f"Aucune image nº {identifiant}.")
                objet.main_image = image
            modifies.append("main_image")

        if modifies:
            objet.save(update_fields=modifies)

        meta = _appliquer_metadonnees_objet(objet, corps["metadonnees"]) \
            if "metadonnees" in corps else []

        champs = _appliquer_valeurs(objet, corps["valeurs"]) if "valeurs" in corps else []

        return ok({
            "objet": _objet_en_dict(objet),
            "modifies": modifies + meta + [f"valeurs.{c}" for c in champs],
        })


class VersionsDeLObjet(VueAgent):
    """
    Crée la version d'une fiche dans une langue du site, par duplication.

    `{"langue": "en"}` — la réponse est la nouvelle fiche : mêmes valeurs,
    mêmes images, même adresse que l'originale, et **non publiée**. Reste à
    traduire son titre, ses valeurs, ses métadonnées — et son `slug`, pour une
    fiche servie sous `/co/…` —, puis à la publier (PATCH /objets/<id>/).
    Désigner une version revient à désigner sa fiche d'origine.
    """

    permission_requise = AJOUTER_OBJET

    @transaction.atomic
    def post(self, request, objet_id):
        from jeiko.administration_pages.versions import VersionImpossible
        from jeiko.custom_objects.versions import creer_version

        objet = get_object_or_404(CustomObject.objects.select_related("model"), id=objet_id)
        corps = self.corps(request, connues={"langue"})
        try:
            version = creer_version(objet, str(corps.get("langue") or ""))
        except VersionImpossible as refus:
            return erreur(str(refus), statut=409)
        return ok({"objet": _objet_en_dict(version)}, statut=201)


# --------------------------------------------------------------------------- #
#  Produits
# --------------------------------------------------------------------------- #
class ListeDesProduits(VueAgent):
    permission_requise = VOIR_PRODUIT

    def get(self, request):
        produits = (
            Product.objects.select_related("type", "content__model")
            .prefetch_related(Prefetch(
                "content__traductions", queryset=CustomObject.objects.select_related("model")))
            .order_by("-id")
        )
        return ok({"produits": [_produit_en_dict(p) for p in produits[:200]]})


def _valeur_produit(cle, valeur):
    """
    Valide une valeur de produit comme le formulaire humain (Fable 2 §1.4).

    L'API écrivait les valeurs telles quelles : prix négatif et TVA à 250 %
    acceptés, `prix_ht: "abc"` ou `stock: "x"` en 500, devise ou référence
    trop longues en 500 PostgreSQL. Chaque refus nomme le champ.
    """
    if cle in ("prix_ht", "taux_tva"):
        if isinstance(valeur, bool):
            raise CorpsInvalide(f"« {cle} » attend un nombre.")
        try:
            nombre = Decimal(str(valeur).replace(",", ".")).quantize(Decimal("0.01"))
        except (InvalidOperation, ValueError):
            raise CorpsInvalide(f"« {cle} » attend un nombre — reçu {valeur!r}.")
        if not nombre.is_finite() or nombre < 0:
            raise CorpsInvalide(f"« {cle} » ne peut pas être négatif.")
        if cle == "taux_tva" and nombre > 100:
            raise CorpsInvalide("« taux_tva » est un pourcentage entre 0 et 100.")
        if cle == "prix_ht" and nombre >= Decimal("100000000"):
            raise CorpsInvalide("« prix_ht » dépasse le maximum (99 999 999,99).")
        return nombre
    if cle == "stock":
        if isinstance(valeur, bool) or not isinstance(valeur, int) and not (
            isinstance(valeur, str) and valeur.strip().lstrip("-").isdigit()
        ):
            raise CorpsInvalide(f"« stock » attend un nombre entier — reçu {valeur!r}.")
        return int(valeur)
    if cle == "devise":
        devise = str(valeur or "").strip().upper()
        if not re.fullmatch(r"[A-Z]{3}", devise):
            raise CorpsInvalide(f"« devise » est un code à trois lettres (EUR, USD…) — reçu {valeur!r}.")
        return devise
    if cle == "sku":
        sku = str(valeur or "").strip()
        longueur = Product._meta.get_field("sku").max_length
        if not sku:
            raise CorpsInvalide("Une référence « sku » est obligatoire.")
        if len(sku) > longueur:
            raise CorpsInvalide(f"« sku » fait au plus {longueur} caractères.")
        return sku
    return valeur


class CreationProduit(VueAgent):
    permission_requise = AJOUTER_PRODUIT

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request, connues={
            "type", "fiche_id", "sku", "prix_ht", "taux_tva", "devise", "stock",
        })

        code_type = str(corps.get("type") or "").strip()
        type_produit = _type_produit_par_id_ou_code(code_type)
        if type_produit is None:
            connus = ", ".join(
                f"{identifiant} ({code})"
                for identifiant, code in ProductType.objects.values_list("id", "code")
            )
            raise CorpsInvalide(
                f"Type de produit « {code_type or 'absent'} » inconnu. "
                f"Utilisez un id ou un code. Connus : {connus or '(aucun)'}."
            )

        fiche_id = corps.get("fiche_id")
        fiche = CustomObject.objects.filter(pk=fiche_id).first() if fiche_id else None
        if fiche is None:
            raise CorpsInvalide(
                "« fiche_id » est obligatoire : un produit porte le commerce, "
                "la fiche porte le contenu. Créer la fiche d'abord."
            )
        if fiche.traduction_de_id:
            # Le prix, le stock et la référence valent pour toutes les langues.
            raise CorpsInvalide(
                f"La fiche nº {fiche.id} est la version « {fiche.langue} » de la fiche "
                f"nº {fiche.traduction_de_id} : un produit se rattache à la fiche "
                f"d'origine, et sert toutes ses versions."
            )

        sku = _valeur_produit("sku", corps.get("sku"))
        if Product.objects.filter(sku=sku).exists():
            return erreur(f"La référence « {sku} » est déjà prise.", statut=409)

        produit = Product.objects.create(
            type=type_produit,
            content=fiche,
            sku=sku,
            price_ht=_valeur_produit("prix_ht", corps.get("prix_ht", 0) or 0),
            tax_rate=_valeur_produit(
                "taux_tva", corps.get("taux_tva", type_produit.default_tax_rate or 0) or 0
            ),
            currency=_valeur_produit(
                "devise", corps.get("devise") or type_produit.default_currency or "EUR"
            ),
            stock_quantity=_valeur_produit("stock", corps.get("stock", 0) or 0),
            # Comme les pages et les fiches : inactif à la création.
            is_active=False,
        )
        return ok({"produit": _produit_en_dict(produit)}, statut=201)


class DetailProduit(VueAgent):
    permission_requise = VOIR_PRODUIT

    def get(self, request, produit_id):
        produit = get_object_or_404(
            Product.objects.select_related("type", "content"), id=produit_id
        )
        return ok({"produit": _produit_en_dict(produit)})

    def patch(self, request, produit_id):
        if not request.user.has_perm(MODIFIER_PRODUIT):
            return erreur("Modification de produit non autorisée.", statut=403)

        produit = get_object_or_404(
            Product.objects.select_related("type", "content"), id=produit_id
        )
        correspondances = {
            "sku": "sku", "actif": "is_active", "prix_ht": "price_ht",
            "taux_tva": "tax_rate", "devise": "currency", "stock": "stock_quantity",
        }
        corps = self.corps(request, connues=set(correspondances))
        modifies = []
        for cle, champ in correspondances.items():
            if cle not in corps:
                continue
            valeur = corps[cle]
            if champ == "is_active":
                valeur = bool(valeur)
            else:
                valeur = _valeur_produit(cle, valeur)
            if champ == "sku" and Product.objects.filter(sku=valeur).exclude(id=produit.id).exists():
                return erreur(f"La référence « {valeur} » est déjà prise.", statut=409)
            setattr(produit, champ, valeur)
            modifies.append(champ)

        if modifies:
            produit.save(update_fields=modifies)

        return ok({"produit": _produit_en_dict(produit), "modifies": modifies})


# --------------------------------------------------------------------------- #
#  Types de fiches — la définition, pas le remplissage
# --------------------------------------------------------------------------- #
#
# Jusqu'ici l'API savait REMPLIR des fiches, pas créer leur type : il fallait
# passer par l'administration pour déclarer « Formule » et ses six champs, puis
# revenir à l'API pour les remplir. Un agent à qui on demande « fais-moi trois
# formules » ne pouvait donc pas aller au bout tout seul.
#
# Créer un type engage plus qu'une fiche : le `slug` entre dans les URL
# (`/co/<slug>/…`), les `code` de champs entrent dans les gabarits sous la
# forme `[%code%]`. Les renommer plus tard casse des pages publiées. D'où deux
# précautions : les codes sont normalisés à la création, et **jamais modifiés
# ensuite** — un PATCH peut ajouter un champ, pas rebaptiser un existant.

#: Types de champ acceptés, lus sur le modèle : la liste ne peut pas dériver.
TYPES_DE_CHAMP = [code for code, _ in CustomObjectField.FIELD_TYPES]


def _lire_les_champs(corps, obligatoire):
    """
    Valide la liste de champs d'un type de fiche et la rend prête à créer.

    On valide tout avant d'écrire quoi que ce soit : un type à moitié déclaré,
    dont le quatrième champ a été refusé, serait plus pénible à réparer qu'un
    refus franc.
    """
    champs = corps.get("champs")
    if champs is None:
        if obligatoire:
            raise CorpsInvalide(
                "« champs » est obligatoire : un type de fiche sans champ ne "
                "peut rien porter. Chaque champ attend « code », « libelle » "
                f"et « type » parmi {', '.join(TYPES_DE_CHAMP)}."
            )
        return []

    if not isinstance(champs, list):
        raise CorpsInvalide("« champs » doit être une liste.")

    prepares, vus = [], set()
    for rang, brut in enumerate(champs, 1):
        if not isinstance(brut, dict):
            raise CorpsInvalide(f"Champ nº {rang} : un objet est attendu.")

        code = slugify(str(brut.get("code") or "").strip()).replace("-", "_")
        if not code:
            raise CorpsInvalide(
                f"Champ nº {rang} : « code » est obligatoire. C'est lui qui "
                f"s'écrit [%code%] dans le gabarit."
            )
        if code in vus:
            raise CorpsInvalide(
                f"Champ nº {rang} : le code « {code} » apparaît deux fois. "
                f"Un jeton [%{code}%] ne saurait pas lequel rendre."
            )
        vus.add(code)

        type_de_champ = str(brut.get("type") or "").strip()
        if type_de_champ not in TYPES_DE_CHAMP:
            raise CorpsInvalide(
                f"Champ nº {rang} : type « {type_de_champ} » inconnu. "
                f"Acceptés : {', '.join(TYPES_DE_CHAMP)}."
            )

        prepares.append({
            "code": code,
            "label": str(brut.get("libelle") or code).strip(),
            "field_type": type_de_champ,
            "required": bool(brut.get("obligatoire", False)),
            "help_text": str(brut.get("aide") or "").strip()[:255],
            "position": rang,
        })
    return prepares


class CreationModele(VueAgent):
    """
    Crée un type de fiche, ses champs, et marque sa page gabarit.

    Le marquage de la page (`is_custom_object_template`) est fait ici plutôt
    que laissé à l'appelant : `CustomObjectModel.page_template` n'accepte que
    des pages ainsi marquées, et une page qui ne l'est pas produirait une
    erreur de validation opaque. Le faire au moment où l'on sait pourquoi
    évite un aller-retour que rien ne justifie.
    """

    permission_requise = AJOUTER_MODELE

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request, connues={
            "nom", "slug", "gabarit_de_page", "champs", "est_un_produit", "traductions",
        })

        nom = str(corps.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide("« nom » est obligatoire.")

        slug = slugify(str(corps.get("slug") or nom).strip())
        if not slug:
            raise CorpsInvalide("« slug » ne donne rien d'utilisable.")
        if CustomObjectModel.objects.filter(slug=slug).exists():
            raise CorpsInvalide(
                f"Le slug « {slug} » est déjà pris. Il entre dans les URL "
                f"(/co/{slug}/…), il ne peut pas être partagé."
            )

        gabarit_id = corps.get("gabarit_de_page")
        if not gabarit_id:
            raise CorpsInvalide(
                "« gabarit_de_page » est obligatoire : l'identifiant de la page "
                "qui sert de modèle, celle où figurent les jetons [%code%]."
            )
        gabarit = Page.objects.filter(pk=gabarit_id).first()
        if gabarit is None:
            raise CorpsInvalide(f"Aucune page nº {gabarit_id}.")
        if gabarit.traduction_de_id:
            # La version anglaise d'un gabarit est prise d'elle-même pour une
            # fiche anglaise : le modèle désigne toujours la page d'origine.
            raise CorpsInvalide(
                f"La page nº {gabarit.id} est la version « {gabarit.langue} » de la page "
                f"nº {gabarit.traduction_de_id} : désignez la page d'origine."
            )

        prepares = _lire_les_champs(corps, obligatoire=True)

        # La page devient un gabarit. C'est une modification de page, mais qui
        # découle directement de la création demandée : la refuser ici
        # obligerait à un second appel dont le seul effet serait de rendre
        # celui-ci possible.
        if not gabarit.is_custom_object_template:
            gabarit.is_custom_object_template = True
            gabarit.save(update_fields=["is_custom_object_template"])

        modele = CustomObjectModel(
            name=nom,
            slug=slug,
            page_template=gabarit,
            is_product=bool(corps.get("est_un_produit", False)),
        )
        if "traductions" in corps:
            appliquer_les_traductions(modele, corps["traductions"])
        modele.save()
        for valeurs in prepares:
            CustomObjectField.objects.create(model=modele, **valeurs)

        return ok({"modele": _modele_en_dict(modele)}, statut=201)


class DetailModele(VueAgent):
    """
    Lit un type de fiche, ou lui AJOUTE des champs.

    Ajouter seulement : un code de champ est écrit dans les gabarits sous la
    forme `[%code%]`, et dans les fiches déjà remplies. Le renommer casserait
    les deux, silencieusement — le jeton ne serait plus reconnu et resterait
    affiché en clair sur la page publique. Un champ devenu inutile se laisse
    vide ; le retirer se fait depuis l'administration, en connaissance de cause.
    """

    permission_requise = VOIR_OBJET

    def get(self, request, modele_id):
        modele = get_object_or_404(
            CustomObjectModel.objects.prefetch_related("fields"), pk=modele_id
        )
        return ok({"modele": _modele_en_dict(modele)})

    @transaction.atomic
    def patch(self, request, modele_id):
        if not request.user.has_perm(MODIFIER_MODELE):
            return erreur("Modification de type de fiche non autorisée.", statut=403)

        modele = get_object_or_404(CustomObjectModel, pk=modele_id)
        corps = self.corps(request)
        touches = []

        if "nom" in corps:
            modele.name = str(corps["nom"]).strip() or modele.name
            modele.save(update_fields=["name"])
            touches.append("nom")

        if "traductions" in corps:
            appliquer_les_traductions(modele, corps["traductions"])
            modele.save(update_fields=["traductions"])
            touches.append("traductions")

        existants = set(modele.fields.values_list("code", flat=True))
        for valeurs in _lire_les_champs(corps, obligatoire=False):
            if valeurs["code"] in existants:
                raise CorpsInvalide(
                    f"Le champ « {valeurs['code']} » existe déjà. Un code de "
                    f"champ ne se renomme pas : il est écrit dans le gabarit "
                    f"et dans les fiches remplies."
                )
            CustomObjectField.objects.create(model=modele, **valeurs)
            touches.append(f"champ:{valeurs['code']}")

        modele.refresh_from_db()
        return ok({"modele": _modele_en_dict(modele), "modifie": touches})


# --------------------------------------------------------------------------- #
#  Types de produit
# --------------------------------------------------------------------------- #
class ListeDesTypesDeProduit(VueAgent):
    permission_requise = VOIR_TYPE_PRODUIT

    def get(self, request):
        types = ProductType.objects.select_related("content_model")
        return ok({"types": [_type_de_produit_en_dict(t) for t in types]})


class CreationTypeDeProduit(VueAgent):
    """
    Crée le type métier d'un produit, et le relie à son type de fiche.

    Deux couches, et c'est voulu : `CustomObjectModel` porte le CONTENU (les
    champs, le gabarit), `ProductType` porte le COMMERCE (la nature du produit,
    physique ou service). Un même modèle de fiche peut servir plusieurs types
    de produit.
    """

    permission_requise = AJOUTER_TYPE_PRODUIT

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request, connues={
            "nom", "code", "nature", "expedition", "modele", "traductions",
        })

        nom = str(corps.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide("« nom » est obligatoire.")

        code = slugify(str(corps.get("code") or nom).strip()).replace("-", "_")
        if not code:
            raise CorpsInvalide("« code » ne donne rien d'utilisable.")
        if ProductType.objects.filter(code=code).exists():
            raise CorpsInvalide(f"Le code « {code} » est déjà pris.")

        natures = [c for c, _ in ProductType.KIND_CHOICES]
        nature = str(corps.get("nature") or ProductType.KIND_PHYSICAL).strip()
        if nature not in natures:
            raise CorpsInvalide(
                f"« nature » inconnue. Acceptées : {', '.join(natures)}."
            )

        modele = None
        if corps.get("modele"):
            modele = _modele_par_id_ou_slug(corps["modele"])
            if modele is None:
                raise CorpsInvalide(
                    f"Aucun type de fiche « {corps['modele']} ». Voir /modeles/."
                )

        # `requires_shipping` DÉCOULE de la nature, sauf mention contraire.
        #
        # Ne pas le poser était un défaut de cette vue : le champ vaut `True`
        # par défaut, si bien qu'un type créé « service » se retrouvait à
        # exiger une expédition. Or c'est LUI que consultent le panier, le
        # JSON-LD et le décrément de stock : l'abonnement redevenait un produit
        # qui s'épuise, donc invendable — le défaut même qu'on venait de
        # corriger, réintroduit par la porte d'à côté.
        #
        # Un bien numérique livré par colis n'existe pas ; l'inverse, si — un
        # « service » qui expédie un support imprimé. D'où la possibilité de
        # forcer, sans en faire le défaut.
        expedition = corps.get("expedition")
        if expedition is None:
            expedition = nature == ProductType.KIND_PHYSICAL

        type_produit = ProductType(
            name=nom, code=code, kind=nature, content_model=modele,
            is_physical=(nature == ProductType.KIND_PHYSICAL),
            requires_shipping=bool(expedition),
        )
        if "traductions" in corps:
            appliquer_les_traductions(type_produit, corps["traductions"])
        type_produit.save()
        return ok({"type": _type_de_produit_en_dict(type_produit)}, statut=201)


class DetailTypeDeProduit(VueAgent):
    """
    Corrige un type de produit — sa nature, son expédition, son modèle.

    Sans cette route, un type mal créé restait faux : la création ne se rejoue
    pas (le code est unique), et rien d'autre ne le rattrapait. C'est ce qui
    est arrivé au type « abonnement » d'ateliersderouineau, créé « service »
    mais expédiable, donc invendable.

    Le CODE ne se modifie pas : il est dans l'URL de chaque page produit du
    type (`/shop/<code>/<sku>/`), donc dans des liens publiés et indexés.
    """

    permission_requise = VOIR_TYPE_PRODUIT

    def get(self, request, type_id):
        type_produit = get_object_or_404(ProductType, pk=type_id)
        return ok({"type": _type_de_produit_en_dict(type_produit)})

    @transaction.atomic
    def patch(self, request, type_id):
        if not request.user.has_perm(MODIFIER_TYPE_PRODUIT):
            return erreur("Modification de type de produit non autorisée.", statut=403)

        type_produit = get_object_or_404(ProductType, pk=type_id)
        corps = self.corps(request)

        connues = {"nom", "nature", "expedition", "modele", "traductions"}
        inconnues = sorted(set(corps) - connues)
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Acceptées : {', '.join(sorted(connues))}. "
                f"Le « code » ne se modifie pas : il est dans l'URL de chaque "
                f"page produit du type."
            )

        modifies = []
        if "nom" in corps:
            type_produit.name = str(corps["nom"]).strip()[:150]
            modifies.append("name")

        if "nature" in corps:
            natures = [c for c, _ in ProductType.KIND_CHOICES]
            if corps["nature"] not in natures:
                raise CorpsInvalide(
                    f"« nature » inconnue. Acceptées : {', '.join(natures)}."
                )
            type_produit.kind = corps["nature"]
            type_produit.is_physical = (
                corps["nature"] == ProductType.KIND_PHYSICAL
            )
            modifies += ["kind", "is_physical"]
            # La nature entraîne l'expédition, sauf mention explicite dans le
            # MÊME appel : sans cela, corriger la nature laisserait le produit
            # invendable pour la raison qu'on croyait avoir réglée.
            if "expedition" not in corps:
                type_produit.requires_shipping = type_produit.is_physical
                modifies.append("requires_shipping")

        if "expedition" in corps:
            type_produit.requires_shipping = bool(corps["expedition"])
            modifies.append("requires_shipping")

        if "modele" in corps:
            if corps["modele"]:
                modele = _modele_par_id_ou_slug(corps["modele"])
                if modele is None:
                    raise CorpsInvalide(
                        f"Aucun type de fiche « {corps['modele']} »."
                    )
                type_produit.content_model = modele
            else:
                type_produit.content_model = None
            modifies.append("content_model")

        if "traductions" in corps:
            appliquer_les_traductions(type_produit, corps["traductions"])
            modifies.append("traductions")

        if modifies:
            type_produit.save(update_fields=modifies)
        return ok({
            "type": _type_de_produit_en_dict(type_produit), "modifie": modifies
        })
