# jeiko/agents/vues_pages.py
"""
L'API des pages : lire un arbre complet, le construire, le modifier.

La forme retenue
----------------
**Une lecture d'un seul tenant, des écritures granulaires.**

`GET /pages/<id>/` rend la page entière — sections, lignes, blocs, contenus et
tous les paramètres — en un seul document. Un agent qui doit modifier une page
a besoin de la voir en entier pour décider ; le faire en quarante appels
coûterait cher et lui donnerait une vue par morceaux.

Les écritures, elles, restent unitaires. Un `PUT` de l'arbre complet aurait été
séduisant, mais il suppose un moteur de comparaison : c'est lui qui déciderait
seul de supprimer ce qui manque dans le document reçu. Un agent qui oublie une
branche effacerait alors du contenu sans l'avoir demandé, et personne ne
saurait dire si c'était voulu. Les écritures unitaires disent ce qu'elles font,
se journalisent une par une, et une erreur n'emporte que son propre appel.

Ce qui est délibérément absent
------------------------------
**La suppression de page.** Aucun point d'entrée, à aucune permission. Un agent
peut tout construire et tout défaire à l'intérieur d'une page, mais la page
elle-même ne disparaît que par la main d'un humain, dans l'écran qui dit les
conséquences. C'est la règle posée avec l'exploitant, et elle est appliquée
deux fois : ici par l'absence de route, et par un rôle qui ne porte pas
`delete_page`.

Le vocabulaire du modèle, à connaître
-------------------------------------
`Bloc.position` n'est **pas** un rang vertical : c'est un numéro de COLONNE.
Le rang dans la colonne est `position_in_column`. L'API expose donc `colonne`
et `rang`, qui disent ce qu'ils sont.

L'API compte les colonnes à partir de 0 ; la base, l'éditeur et le rendu, à
partir de 1. La traduction se fait ici et nulle part ailleurs :
`colonne_en_base()` à l'écriture, `colonne_de_l_api()` à la lecture.
"""

import re

from django.db import transaction
from jeiko.liens import url_sure
from django.db.models import F, Prefetch, Q
from django.shortcuts import get_object_or_404
from django.utils.text import slugify

from jeiko import langues_du_site
from jeiko.administration_pages import adresses

from jeiko.administration_pages import fabrique
from jeiko.administration_pages.forms import MediaLibraryImageForm
from jeiko.administration_pages.models import (
    Bloc, Content, ContentButton, ContentFormField, ContentFormulaire,
    ContentImage, ContentText, ContentVideo, ImageContent, Line, Page,
    Section,
)

from jeiko.sanitize import nettoyer_en_rendant_compte

from . import compatibilite_editeur, contenus_dynamiques, parametres
from .contenus_dynamiques import ElementInvalide
from .parametres import ParametreInvalide
from .vues_api import borne, refuser_une_adresse_reservee, slug_d_adresse, CorpsInvalide, VueAgent, erreur, ok

LIRE = "administration_pages.view_page"
MODIFIER = "administration_pages.change_page"
CREER = "administration_pages.add_page"


# --------------------------------------------------------------------------- #
#  Sérialisation
# --------------------------------------------------------------------------- #
def _contenu_en_dict(content):
    """
    Le contenu d'un bloc, réduit à ce qu'un agent peut lire et écrire.

    Les types non encore couverts sont rendus avec leur seul `type` : mieux
    vaut dire « ce bloc est un carrousel, je ne sais pas te le détailler » que
    de laisser croire qu'il est vide.
    """
    if content is None:
        return {"type": "NOT_SET"}

    donnees = {"type": content.content_type}

    if content.content_type == "TEXT" and content.content_text:
        donnees["texte"] = content.content_text.text
    elif content.content_type == "BUTTON" and content.content_button:
        bouton = content.content_button
        donnees["bouton"] = {
            cle: getattr(bouton, champ) for cle, champ in CHAMPS_BOUTON.items()
        }
        donnees["bouton"]["page_id"] = bouton.page_target_id
        # Par référence et par slug, pour que la relecture soit renvoyable
        # telle quelle — un identifiant obligerait l'appelant à traduire.
        donnees["bouton"]["produit_cible"] = (
            bouton.product_target.sku if bouton.product_target_id else None
        )
        donnees["bouton"]["fiche_cible"] = (
            bouton.custom_object_target.slug
            if bouton.custom_object_target_id else None
        )
        donnees["bouton"]["style"] = {
            cle: getattr(bouton, champ) for cle, champ in STYLE_BOUTON.items()
        }
        if bouton.is_add_to_cart and not bouton.product_target_id:
            donnees["bouton"]["_avertissement"] = AVERTISSEMENT_PANIER
    elif content.content_type == "IMAGE" and content.content_image:
        image = content.content_image.image_content
        donnees["image"] = {
            "id": image.id if image else None,
            "alt": getattr(image, "alt", "") if image else "",
        }
    elif content.content_type == "FORM" and content.content_formulaire:
        donnees["formulaire"] = _formulaire_en_dict(content.content_formulaire)
    elif content.content_type == "VIDEO" and content.content_video:
        donnees["video"] = {
            cle: getattr(content.content_video, champ)
            for cle, champ in CHAMPS_VIDEO.items()
        }
    elif content.content_type in CONTENUS_SIMPLES:
        donnees[content.content_type.lower()] = _lire_contenu_simple(content)
    elif contenus_dynamiques.est_dynamique(content.content_type):
        donnees.update(contenus_dynamiques.lire(content))
    elif content.content_type != "NOT_SET":
        donnees["modifiable_par_l_api"] = False

    return donnees


def colonne_en_base(colonne):
    """La colonne de l'API (à partir de 0) en `Bloc.position` (à partir de 1)."""
    return colonne + 1


def colonne_de_l_api(position):
    """`Bloc.position` (à partir de 1) en colonne de l'API (à partir de 0)."""
    return max(0, (position or 1) - 1)


def _bloc_en_dict(bloc):
    return {
        "id": bloc.id,
        "colonne": colonne_de_l_api(bloc.position),
        "rang": bloc.position_in_column,
        "contenu": _contenu_en_dict(getattr(bloc, "content", None)),
        "parametres": parametres.lire(bloc),
    }


def _ligne_en_dict(ligne):
    return {
        "id": ligne.id,
        "position": ligne.position,
        "blocs": [
            _bloc_en_dict(b)
            for b in ligne.blocs.all().order_by("position", "position_in_column", "id")
        ],
        "parametres": parametres.lire(ligne),
    }


def _section_en_dict(section):
    return {
        "id": section.id,
        "position": section.position,
        "lignes": [
            _ligne_en_dict(l) for l in section.lines.all().order_by("position", "id")
        ],
        "parametres": parametres.lire(section),
    }


def _metadonnees_de(page):
    """Le titre et la description qui partent dans les résultats de recherche."""
    meta = getattr(page, "metadata", None)
    return {
        "titre": meta.title if meta else "",
        "description": meta.description if meta else "",
    }


def _page_en_resume(page):
    return {
        "id": page.id,
        "titre": page.title,
        "metadonnees": _metadonnees_de(page),
        "url_tag": page.url_tag,
        "publiee": page.active,
        "racine": page.is_root,
        "protegee": page.is_protected,
        "categorie": page.category.slug if page.category_id else None,
        "sous_categorie": page.sub_category.slug if page.sub_category_id else None,
        "url": page.get_absolute_url() if hasattr(page, "get_absolute_url") else "",
        # Un gabarit de fiche n'a pas d'existence propre : il sert à rendre les
        # objets d'un modèle, avec leurs jetons [%champ%] remplacés. Ouvert
        # directement, il répond 404 — ce qui, joint à « publiee: true »,
        # formait un signal contradictoire que rien n'expliquait. On le dit.
        "gabarit_de_fiche": bool(getattr(page, "is_custom_object_template", False)),
        # Même raison pour les deux autres gabarits : le corps d'un e-mail et
        # une page PDF sont des pages, publiées, avec une adresse — que le site
        # public ne sert pas. Sans ces drapeaux rien ne les distinguait d'une
        # page ordinaire, et un bouton « Nous écrire » a pu viser le gabarit
        # d'un accusé de réception au lieu de la page de contact (01/10/2026).
        "gabarit_de_mail": bool(page.is_mail_template),
        "pdf": bool(page.is_pdf),
        # Site en plusieurs langues : la langue de CETTE version, la page
        # d'origine dont elle est la traduction (null pour une originale), et
        # ses autres versions. Voir /langues/ et /pages/<id>/versions/.
        "langue": page.langue or langues_du_site.langue_d_origine(),
        "version_d_origine": page.traduction_de_id,
        "versions": [
            {"id": v.id, "langue": v.langue or langues_du_site.langue_d_origine(),
             "publiee": v.active, "url": v.adresse_propre()}
            for v in page.versions() if v.pk != page.pk
        ],
    }


#: Ce qu'une version traduite tient de sa page d'origine : on le règle là-bas.
CLES_DE_L_ORIGINALE = (
    "categorie", "sous_categorie", "racine", "afficher_le_menu",
    "afficher_le_pied_de_page", "pdf", "gabarit_de_mail", "gabarit_de_fiche",
    "gabarit_legal_par_defaut",
)


#: Champs de page qu'un agent peut écrire.
#:
#: Les drapeaux de nature — `is_root`, `is_pdf`, `is_mail_template`,
#: `is_custom_object_template`, `is_default_legal_template` — sont ouverts
#: depuis le 03/09, à la demande de l'exploitant : un agent qui construit un
#: site entier doit pouvoir déclarer une page d'accueil et une page gabarit,
#: sans quoi il s'arrête au milieu et laisse le travail à finir à la main.
#:
#: Le risque est réel et il faut le connaître : basculer `racine` déplace la
#: page d'accueil du site, et `gabarit_de_mail` retire une page du site public.
#: Rien n'en avertit. C'est le prix de l'autonomie demandée — la contrepartie
#: est qu'aucune de ces bascules n'est destructrice : toutes se défont.
CHAMPS_PAGE_MODIFIABLES = {
    "titre": "title",
    "url_tag": "url_tag",
    "publiee": "active",
    "afficher_le_menu": "show_default_main_menu",
    "afficher_le_pied_de_page": "show_default_footer",
    "indexable_par_google": "google_index",
    "racine": "is_root",
    "pdf": "is_pdf",
    "gabarit_de_mail": "is_mail_template",
    "gabarit_de_fiche": "is_custom_object_template",
    "gabarit_legal_par_defaut": "is_default_legal_template",
}

#: Les deux liens vers une catégorie, désignés par SLUG.
#:
#: Une catégorie classe la page dans le site ; une sous-catégorie l'affine.
#: Toutes deux sont facultatives en base, et le restent ici — mais un agent
#: qui construit un site doit pouvoir les poser, sinon les pages qu'il crée
#: sont hors de tout classement, et invisibles des blocs qui filtrent par
#: catégorie.
CHAMPS_PAGE_CATEGORIES = {
    "categorie": "category",
    "sous_categorie": "sub_category",
}

#: Volontairement ABSENT de tout ce qui précède : `is_protected`.
#:
#: Ce drapeau gouverne l'accès à la page, pas son contenu. Le confier à un
#: jeton d'API reviendrait à laisser un agent retirer la protection d'une page
#: réservée — ou en protéger une par erreur, ce qui la ferait disparaître pour
#: les visiteurs sans que rien ne l'explique. C'est une décision d'exploitant,
#: elle reste dans l'administration. Même raisonnement que pour la suppression
#: de page : l'absence est la barrière.
CHAMPS_PAGE_FERMES = ("is_protected",)


def _categorie(valeur):
    """
    La catégorie désignée par son slug, son identifiant, ou son nom exact.

    Le slug d'abord, parce que c'est ce qui se relit : « electricite » a du
    sens là où « 4 » demande une traduction.

    Mais **toutes les catégories n'ont pas de slug.** Certaines ne servent qu'à
    regrouper — « les gabarits ensemble », « les pages de résultat de
    questionnaire ensemble » — et n'apparaissent dans aucune URL. Les désigner
    par slug est alors impossible, d'où les deux replis : l'identifiant, puis
    le nom exact. `/categories/` donne les trois pour chacune.

    `None` retire le classement.
    """
    from jeiko.administration_pages.models import Category

    if valeur in (None, ""):
        return None

    texte = str(valeur).strip()

    # Depuis qu'un slug peut se répéter sous deux parentes différentes, le
    # premier venu n'est plus le bon : `.first()` classait la page dans une
    # catégorie prise au hasard, et la réponse affirmait le succès. Une
    # désignation ambiguë se refuse — l'appelant a l'identifiant sous la main,
    # `/categories/` le lui donne.
    homonymes = list(
        Category.objects.filter(slug=texte).select_related("main_category")
    )
    if len(homonymes) > 1:
        candidates = ", ".join(
            f"{c.name} (id {c.id}"
            + (f", {chemin}" if (chemin := adresses.chemin_de_categorie(c)) else "")
            + ")"
            for c in homonymes
        )
        raise CorpsInvalide(
            f"Plusieurs catégories portent le slug « {texte} » : {candidates}. "
            f"Désignez celle que vous visez par son identifiant."
        )

    categorie = homonymes[0] if homonymes else None

    if categorie is None and texte.isdigit():
        categorie = Category.objects.filter(pk=int(texte)).first()
    if categorie is None:
        categorie = Category.objects.filter(name=texte).first()

    if categorie is None:
        connues = [
            f"{c.slug or c.name} (id {c.id})"
            for c in Category.objects.order_by("name")[:20]
        ]
        raise CorpsInvalide(
            f"Aucune catégorie « {valeur} ». "
            + (f"Connues : {', '.join(connues)}." if connues
               else "Aucune catégorie n'existe encore — voir /categories/.")
        )
    return categorie


def _liberer_la_racine(page):
    """
    Retire le drapeau racine à l'ancienne page d'accueil.

    Une contrainte de base — `only_one_is_root_page` — n'autorise qu'une seule
    page racine. Sans ce passage, poser `racine: true` sur une deuxième page
    levait une `UniqueViolation`, c'est-à-dire une **erreur 500** : un défaut
    de l'API rendu comme une panne du serveur, sans rien dire de la cause.

    On transfère plutôt que de refuser, parce que c'est ce que veut dire la
    demande : « cette page est l'accueil ». Refuser obligerait à deux appels
    dont le premier — dépublier l'accueil actuel — laisserait le site sans
    page d'accueil entre les deux.

    **Cela DÉPLACE la page d'accueil du site.** C'est écrit dans le guide, et
    la réponse le dit en listant « is_root » parmi les champs modifiés.
    """
    Page.objects.filter(is_root=True).exclude(pk=page.pk).update(is_root=False)


def _verifier_la_hierarchie(categorie, sous_categorie):
    """
    Une sous-catégorie doit appartenir à la catégorie annoncée.

    Sans ce contrôle, on pouvait classer une page dans « Services » et lui
    donner la sous-catégorie « Résultats de questionnaire » : la base l'accepte
    — ce sont deux clés étrangères indépendantes — et le classement devient
    incohérent. Personne ne s'en aperçoit avant qu'un listage filtré revienne
    vide ou trop plein.

    Une sous-catégorie SANS parente est acceptée : rien n'oblige une catégorie
    à en avoir une, et refuser bloquerait des classements légitimes.
    """
    if categorie is None or sous_categorie is None:
        return
    if sous_categorie.main_category_id is None:
        return
    if sous_categorie.main_category_id != categorie.id:
        parente = sous_categorie.main_category
        raise CorpsInvalide(
            f"« {sous_categorie.slug or sous_categorie.name} » est une "
            f"sous-catégorie de « {parente.slug or parente.name} », "
            f"pas de « {categorie.slug or categorie.name} ». "
            f"Voir /categories/ pour la hiérarchie."
        )


# --------------------------------------------------------------------------- #
#  Médiathèque
# --------------------------------------------------------------------------- #
#: Les variantes d'une image, du plus grand au plus petit.
#:
#: Le rendu lit `laptop_size` en priorité et ne retombe sur `original_image`
#: qu'en dernier recours (voir `partials/bloc.html`). L'API, elle, ne lisait
#: QUE `original_image` : une image dont l'original avait disparu — effacé
#: pour gagner de la place, ou jamais conservé par un import — sortait avec
#: « url: "" » alors qu'elle s'affiche parfaitement sur le site, déclinée en
#: cinq tailles.
#:
#: Sur un site en service, trente-huit entrées sur quatre-vingt-quatre étaient
#: dans ce cas : la moitié de la médiathèque était invisible à un agent, qui
#: ne pouvait ni la décrire ni la choisir. Et rien ne le disait — la réponse
#: était bien formée, l'identifiant correct, le champ simplement vide.
VARIANTES_D_IMAGE = (
    "original_image", "full_size", "computer_size",
    "laptop_size", "tablet_size", "mobile_size",
)

#: L'ordre dans lequel le rendu choisit sa source. On répond dans le même :
#: ce que l'agent lit doit être ce que le visiteur verra.
PREFERENCE_D_IMAGE = (
    "laptop_size", "computer_size", "full_size",
    "original_image", "tablet_size", "mobile_size",
)


def _url_de(fichier):
    """L'URL d'un fichier, ou None. `.url` lève si le stockage l'ignore."""
    try:
        return fichier.url if fichier else None
    except Exception:
        return None


def _fichiers_de_l_image(image):
    """
    Ce qu'il faut savoir pour choisir une image et la poser.

    On répond à la question posée — « puis-je m'en servir, et à quoi
    ressemble-t-elle » — plutôt qu'à celle du schéma de la base.
    """
    variantes = {}
    for champ in VARIANTES_D_IMAGE:
        url = _url_de(getattr(image, champ, None))
        if url:
            variantes[champ] = url

    principale = next(
        (variantes[c] for c in PREFERENCE_D_IMAGE if c in variantes), ""
    )
    return {
        "url": principale,
        "apercu": (variantes.get("mobile_size")
                   or variantes.get("tablet_size") or principale),
        "variantes": variantes,
        # Vraiment aucun fichier, dans aucune variante. Une entrée pareille
        # posée en fond produit une section vide, sans erreur.
        "fichier_absent": not variantes,
    }


def _image_en_dict(image):
    return {
        "id": image.id,
        "titre": image.title or "",
        "alt": image.alt or "",
        # A-09 : un `alt` vide est soit une image décorative, soit un oubli.
        "decorative": image.decorative,
        "alt_manquant": image.alt_manquant,
        **_fichiers_de_l_image(image),
        "ajoutee_le": image.created_at.isoformat() if image.created_at else None,
    }


class ListeDesImages(VueAgent):
    """
    Les images disponibles, avec leur identifiant.

    Sans ce point d'entrée, un agent pouvait poser un bloc image ou une image
    de fond sans jamais savoir QUELLE image choisir : les champs attendent un
    identifiant, et rien ne le lui donnait. Il devait deviner un nombre, ou
    renoncer.

    Le téléversement possède une route séparée et une permission propre. Il
    passe par le même formulaire que l'administration : plafond de poids,
    validation réelle du format et garde contre les bombes de décompression
    ne peuvent donc pas être contournés par un agent.
    """

    permission_requise = LIRE

    #: Au-delà, on pagine. Une médiathèque de plusieurs milliers d'images ne
    #: doit pas produire une réponse que personne ne peut lire.
    PAR_PAGE = 100

    def get(self, request):
        images = ImageContent.objects.order_by("-id")

        try:
            depuis = int(request.GET.get("apres") or 0)
        except (TypeError, ValueError):
            raise CorpsInvalide("« apres » doit être un identifiant.")
        if depuis:
            images = images.filter(id__lt=depuis)

        lot = list(images[:self.PAR_PAGE])
        return ok({
            "images": [_image_en_dict(i) for i in lot],
            "suite": lot[-1].id if len(lot) == self.PAR_PAGE else None,
        })


#: Les champs d'un téléversement en JSON : le fichier voyage en base64.
CLES_IMAGE_JSON = {"fichier_base64", "nom_du_fichier", "titre", "alt", "decorative"}


def _fichier_depuis_base64(corps):
    """Le fichier d'un corps JSON, ou une erreur qui dit quoi corriger."""
    import base64
    import binascii

    from django.core.files.base import ContentFile

    brut = str(corps.get("fichier_base64") or "")
    if "," in brut[:100] and brut.startswith("data:"):
        brut = brut.split(",", 1)[1]  # accepte une « data URL »
    if not brut:
        raise CorpsInvalide("« fichier_base64 » est obligatoire : le contenu du fichier, encodé en base64.")
    try:
        contenu = base64.b64decode(brut, validate=True)
    except (binascii.Error, ValueError):
        raise CorpsInvalide("« fichier_base64 » n'est pas du base64 valide.")
    nom = str(corps.get("nom_du_fichier") or "image").strip()[:100] or "image"
    return ContentFile(contenu, name=nom)


class CreationImage(VueAgent):
    """
    Téléverse un fichier validé et renvoie l'identifiant à réutiliser.

    Deux formes, mêmes validations (poids, format réel, dimensions, alt) :
    un envoi multipart (`fichier`), ou un corps JSON dont le fichier est en
    base64 (`fichier_base64`). La seconde est ce qui rend l'outil utilisable
    par le serveur MCP, qui ne transporte que du JSON : sans elle, une IA
    pouvait poser un bloc image mais jamais téléverser l'image à y mettre.
    """

    permission_requise = "administration_pages.add_imagecontent"

    def post(self, request):
        from django.conf import settings

        from jeiko.uploads import LIMITE_IMAGE_MO_PAR_DEFAUT

        # L'en-tête plutôt que `request.content_type` : la requête rejouée par
        # le serveur MCP ne porte que l'en-tête.
        if str(request.META.get("CONTENT_TYPE") or "").startswith("application/json"):
            plafond_mo = getattr(settings, "JEIKO_MAX_IMAGE_UPLOAD_MB", LIMITE_IMAGE_MO_PAR_DEFAUT)
            # base64 grossit d'un tiers : on laisse passer l'enveloppe, le
            # formulaire tranche ensuite sur le poids RÉEL du fichier.
            corps = self.corps(request, connues=CLES_IMAGE_JSON,
                               taille_max=int(plafond_mo * 1024 * 1024 * 4 / 3) + 4096)
            fichier = _fichier_depuis_base64(corps)
            donnees = corps
        else:
            cles = set(request.POST) | set(request.FILES)
            inconnues = sorted(cles - {"fichier", "titre", "alt", "decorative"})
            if inconnues:
                raise CorpsInvalide(
                    "Champ(s) inconnu(s) : " + ", ".join(inconnues)
                    + ". Champs acceptés : alt, decorative, fichier, titre."
                )
            fichier = request.FILES.get("fichier")
            donnees = request.POST

        decorative = str(donnees.get("decorative", "")).strip().lower()
        form = MediaLibraryImageForm(
            data={
                "title": donnees.get("titre", ""),
                "alt": donnees.get("alt", ""),
                # A-09 : décrite (`alt`), ou déclarée décorative.
                "decorative": decorative in ("1", "true", "oui", "on"),
            },
            files={"original_image": fichier} if fichier else {},
        )
        if not form.is_valid():
            details = {
                champ: [erreur["message"] for erreur in erreurs]
                for champ, erreurs in form.errors.get_json_data().items()
            }
            message = (
                "Texte alternatif manquant : décrivez l'image dans « alt », ou "
                "envoyez « decorative=true » si elle n'apporte aucune information."
                if list(details) == ["alt"] else "Le fichier image est invalide."
            )
            return erreur(message, statut=400, champs=details)

        image = form.save()
        return ok({"image": _image_en_dict(image)}, statut=201)


# --------------------------------------------------------------------------- #
#  Pages
# --------------------------------------------------------------------------- #
class ListeDesPages(VueAgent):
    permission_requise = LIRE

    def get(self, request):
        pages = Page.objects.all().order_by("title")
        # `?langue=en` : les seules versions de cette langue ; le code de la
        # langue d'origine donne les pages d'origine.
        langue = request.GET.get("langue")
        if langue:
            pages = pages.filter(
                langue="" if langue == langues_du_site.langue_d_origine() else langue
            )
        # Chaque page liste ses autres versions avec leur adresse : on charge
        # d'avance ce que cette adresse consulte, plutôt qu'une requête par
        # version et par catégorie.
        versions = Page.objects.select_related("category", "sub_category")
        pages = pages.select_related(
            "category", "sub_category", "traduction_de", "metadata",
            "traduction_de__category", "traduction_de__sub_category",
        ).prefetch_related(
            Prefetch("traductions", queryset=versions),
            Prefetch("traduction_de__traductions", queryset=versions),
        )
        return ok({"pages": [_page_en_resume(p) for p in pages]})


class CreationDePage(VueAgent):
    permission_requise = CREER

    #: Ce qu'accepte la création d'une page. Une clé de plus est une faute de
    #: frappe : mieux vaut la dire que produire une page à moitié voulue.
    CLES = {"titre", "url_tag", "categorie", "sous_categorie", "metadonnees", "sections"}

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request, connues=self.CLES)

        # Des sections dès la création : la page naît complète, en un appel.
        # Les poser, c'est MODIFIER la page — le droit de créer ne suffit pas,
        # comme pour `POST /pages/<id>/sections/`.
        sections = _Construction._liste(corps.get("sections"), "sections", "corps")
        if sections and not request.user.has_perm(MODIFIER):
            return erreur(
                "Poser des sections demande le droit de modifier les pages.",
                statut=403, permission_manquante=MODIFIER,
            )

        titre = str(corps.get("titre") or "").strip()
        if not titre:
            raise CorpsInvalide("Un « titre » est obligatoire.")

        url_tag = slug_d_adresse(corps.get("url_tag") or slugify(titre), "url_tag",
                                 a_la_racine=False)

        # L'unicité est portée par la CATÉGORIE, pas par le site.
        #
        # La base l'a toujours dit — `uniq_url_tag_when_no_category` ne
        # s'applique qu'aux pages sans catégorie — mais cette vue vérifiait
        # globalement. Deux pages « editeur-de-pages », l'une dans
        # « Fonctionnalités » et l'autre dans « Documentation », étaient donc
        # refusées alors qu'elles ont des adresses distinctes et parfaitement
        # légitimes. C'est précisément ce que demande une organisation en
        # catégories.
        categorie_demandee = _categorie(corps.get("categorie"))
        sous_demandee = _categorie(corps.get("sous_categorie"))
        _verifier_la_hierarchie(categorie_demandee, sous_demandee)

        # Ce qui doit être unique, c'est l'ADRESSE, pas le couple
        # (url_tag, catégorie). Deux pages classées dans deux catégories
        # différentes mais toutes deux masquées dans les URL tombent à la même
        # adresse : le triplet ci-dessus les croyait distinctes, et la seconde
        # naissait inatteignable sans qu'aucune erreur ne le dise.
        adresse = adresses.adresse_prevue(
            url_tag=url_tag,
            categorie=categorie_demandee,
            sous_categorie=sous_demandee,
        )
        refuser_une_adresse_reservee(adresse, "url_tag")
        occupante = adresses.page_a_cette_adresse(adresse)
        if occupante is not None:
            return erreur(
                f"L'adresse « {adresse} » est déjà celle de "
                f"« {occupante.title} » (page {occupante.id}).",
                statut=409,
                url_tag=url_tag,
                adresse=adresse,
            )

        page = Page.objects.create(
            title=borne(Page, "title", titre),
            url_tag=url_tag,
            # Une page créée par un agent naît en BROUILLON, toujours.
            # La mise en ligne est une décision éditoriale : elle reste un geste
            # humain, ou un appel explicite et séparé.
            active=False,
        )

        # Les métadonnées à la CRÉATION, et pas seulement en modification.
        # Une page publiée sans titre ni description de recherche part avec un
        # handicap que personne ne revient corriger : c'est le moment de les
        # écrire, pendant qu'on sait de quoi la page parle.
        if "metadonnees" in corps:
            _appliquer_metadonnees(page, corps["metadonnees"])

        if categorie_demandee is not None or sous_demandee is not None:
            page.category = categorie_demandee
            page.sub_category = sous_demandee
            page.save(update_fields=["category", "sub_category"])

        if not sections:
            return ok({"page": _page_en_resume(page)}, statut=201)
        construction = _Construction()
        arbre = [construction.section(page, s, f"sections[{n}]") for n, s in enumerate(sections)]
        return _reponse_de_construction(
            construction, "sections", arbre, page=_page_en_resume(page)
        )


class DetailPage(VueAgent):
    permission_requise = LIRE

    def get(self, request, page_id):
        page = get_object_or_404(
            Page.objects.prefetch_related("sections__lines__blocs"), id=page_id
        )
        return ok({
            "page": _page_en_resume(page),
            "sections": [
                _section_en_dict(s)
                for s in page.sections.all().order_by("position", "id")
            ],
        })

    @transaction.atomic
    def patch(self, request, page_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification de page non autorisée.", statut=403)

        page = get_object_or_404(Page, id=page_id)
        corps = self.corps(request)

        # Même règle que pour le contenu d'un bloc : envoyer « active » quand
        # le champ s'appelle « publiee » renvoyait 200 et ne publiait pas.
        inconnues = sorted(
            set(corps) - set(CHAMPS_PAGE_MODIFIABLES)
            - set(CHAMPS_PAGE_CATEGORIES) - {"metadonnees"}
        )
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Modifiables : "
                f"{', '.join(sorted(list(CHAMPS_PAGE_MODIFIABLES) + list(CHAMPS_PAGE_CATEGORIES) + ['metadonnees']))}."
            )

        if page.traduction_de_id and corps.get("publiee") and not page.langue_servie:
            # Publier ici répondrait 200 pour une page que le site ne sert pas.
            raise CorpsInvalide(
                f"La langue « {page.langue} » n'est pas activée pour le site : "
                f"cette version ne serait servie à aucune adresse. Activez "
                f"d'abord la langue (PATCH /langues/), puis publiez."
            )

        if page.traduction_de_id:
            a_l_originale = sorted(set(corps) & set(CLES_DE_L_ORIGINALE))
            if a_l_originale:
                raise CorpsInvalide(
                    f"Cette page est la version « {page.langue} » de la page "
                    f"{page.traduction_de_id} : {', '.join(a_l_originale)} se "
                    f"règle(nt) sur la page d'origine et vaut pour toutes ses versions."
                )

        modifies = []
        for cle_api, champ in CHAMPS_PAGE_MODIFIABLES.items():
            if cle_api not in corps:
                continue
            valeur = corps[cle_api]
            if champ == "title":
                valeur = borne(Page, "title", valeur)
                if not valeur:
                    raise CorpsInvalide(f"« {cle_api} » ne peut pas être vide.")
            if champ == "url_tag":
                valeur = slug_d_adresse(valeur, cle_api, a_la_racine=False)
            if champ == "url_tag":
                # On compare l'adresse COMPLÈTE, classement compris : deux
                # pages peuvent porter le même `url_tag` sans se gêner tant que
                # leurs catégories les séparent. Refuser sur le seul tag
                # interdisait des adresses parfaitement distinctes —
                # /formations/tarifs/ et /coaching/tarifs/.
                visee = adresses.adresse_prevue(
                    url_tag=valeur,
                    categorie=_categorie(corps["categorie"])
                    if "categorie" in corps else page.category,
                    sous_categorie=_categorie(corps["sous_categorie"])
                    if "sous_categorie" in corps else page.sub_category,
                    racine=page.est_l_accueil,
                    langue=page.langue,
                )
                refuser_une_adresse_reservee(visee, cle_api)
                occupante = adresses.page_a_cette_adresse(
                    visee, sauf_page_id=page.id
                )
                if occupante is not None:
                    return erreur(
                        f"L'adresse « {visee} » est déjà celle de "
                        f"« {occupante.title} » (page {occupante.id}).",
                        statut=409,
                        adresse=visee,
                    )
            setattr(page, champ, valeur)
            modifies.append(champ)

        if set(corps) & set(CHAMPS_PAGE_CATEGORIES):
            categorie = (
                _categorie(corps["categorie"]) if "categorie" in corps
                else page.category
            )
            sous_categorie = (
                _categorie(corps["sous_categorie"]) if "sous_categorie" in corps
                else page.sub_category
            )
            _verifier_la_hierarchie(categorie, sous_categorie)

            if "categorie" in corps:
                page.category = categorie
                modifies.append("category")
            if "sous_categorie" in corps:
                page.sub_category = sous_categorie
                modifies.append("sub_category")

        if corps.get("racine"):
            _liberer_la_racine(page)

        if modifies:
            page.save(update_fields=modifies)

        if "metadonnees" in corps:
            modifies += _appliquer_metadonnees(page, corps["metadonnees"])

        return ok({"page": _page_en_resume(page), "modifies": modifies})


def _appliquer_metadonnees(page, donnees):
    """
    Le titre et la description des résultats de recherche.

    Ils vivent dans un modèle à part (`Metadata`), lié en un-à-un et absent
    tant qu'on ne l'a pas créé. Sans ce point d'entrée, une page construite par
    un agent sortait sans description : Google reprend alors un morceau du
    corps, souvent mal choisi.
    """
    from jeiko.administration_pages.models import Metadata

    if not isinstance(donnees, dict):
        raise CorpsInvalide("« metadonnees » doit être un objet.")

    meta, _ = Metadata.objects.get_or_create(page=page)
    modifies = []
    if "titre" in donnees:
        meta.title = borne(Metadata, "title", donnees["titre"])
        modifies.append("title")
    if "description" in donnees:
        meta.description = str(donnees["description"])
        modifies.append("description")
    if modifies:
        meta.save(update_fields=modifies)
    return [f"metadonnees.{c}" for c in modifies]


# --------------------------------------------------------------------------- #
#  Sections, lignes, blocs
# --------------------------------------------------------------------------- #
class SectionsDeLaPage(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        corps = self.corps(request, obligatoire=False, connues={"gabarit"})
        gabarit = str(corps.get("gabarit") or "CLASSIC").upper()

        try:
            section = fabrique.creer_section(page, gabarit=gabarit)
        except ValueError as souci:
            raise CorpsInvalide(str(souci))

        return ok({"section": _section_en_dict(section)}, statut=201)


def _avec_avertissements(element, touches, reponse):
    """
    La réponse d'un `PATCH` de paramètres, avec ce que l'agent doit relire.

    La clé « avertissements » n'apparaît que s'il y a quelque chose à dire —
    comme pour l'écriture d'un contenu : vide, elle serait un bruit de fond ;
    présente, c'est un signal.
    """
    rappels = parametres.avertissements(element, touches)
    if rappels:
        reponse["avertissements"] = rappels
    return reponse


class DetailSection(VueAgent):
    permission_requise = MODIFIER

    def _section(self, section_id):
        return get_object_or_404(Section, id=section_id)

    def get(self, request, section_id):
        return ok({"section": _section_en_dict(self._section(section_id))})

    def patch(self, request, section_id):
        section = self._section(section_id)
        try:
            touches = parametres.appliquer(section, self.corps(request))
        except ParametreInvalide as souci:
            raise CorpsInvalide(str(souci))
        return ok(_avec_avertissements(section, touches, {"section": _section_en_dict(section), "modifies": touches}))

    def delete(self, request, section_id):
        section = self._section(section_id)
        section.delete()
        return ok({"supprime": True, "section_id": int(section_id)})


class LignesDeLaSection(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, section_id):
        section = get_object_or_404(Section, id=section_id)
        # La répartition (`columns_type`…) se règle par PATCH sur la ligne,
        # pas à sa création : la refuser ici évite qu'elle soit ignorée.
        corps = self.corps(request, obligatoire=False, connues={"colonnes"})
        colonnes = corps.get("colonnes", 1)

        try:
            colonnes = int(colonnes)
        except (TypeError, ValueError):
            raise CorpsInvalide("« colonnes » doit être un nombre entier.")

        ligne = fabrique.creer_ligne(section, colonnes=colonnes)
        return ok({"ligne": _ligne_en_dict(ligne)}, statut=201)


#: Les trois répartitions d'une ligne, et l'appareil qu'elles décrivent.
REPARTITIONS = {
    "columns_type": "ordinateur",
    "columns_type_tablet": "tablette",
    "columns_type_phone": "téléphone",
}


def _verifier_les_repartitions(ligne, corps):
    """
    Une répartition doit avoir AUTANT DE SEGMENTS QUE LA LIGNE A DE COLONNES.

    Le piège, rencontré en montant jeiko.fr : pour empiler trois blocs sur
    téléphone, on écrit spontanément « 12 » — une colonne pleine largeur. Or
    « 12 » décrit une ligne d'UNE colonne. Les colonnes suivantes ne reçoivent
    aucune largeur et leurs blocs se retrouvent écrasés à trente pixels,
    illisibles.

    Rien ne le signalait : la valeur est dans les choix du modèle, elle
    s'enregistre, et le défaut ne se voit qu'en réduisant la fenêtre. La bonne
    valeur est « 12-12-12 » — autant de segments que de colonnes, chacune
    pleine largeur.

    On se mesure au nombre de colonnes DÉCLARÉ, pas aux blocs présents.
    Première version de ce contrôle, il comptait les blocs — et ne servait donc
    à rien sur une ligne encore vide, c'est-à-dire au moment précis où on règle
    sa mise en page. C'est ainsi qu'un `columns_type: "12"` est passé sur une
    ligne à deux colonnes. `columns_number` est la bonne référence : c'est lui
    que la répartition décrit.

    Quand le corps change AUSSI `columns_number`, c'est la nouvelle valeur qui
    fait foi — sans quoi on refuserait un passage de 2 à 3 colonnes accompagné
    de sa répartition, qui est pourtant la manière correcte de procéder.
    """
    if not any(champ in corps for champ in REPARTITIONS):
        return

    nombre = ligne.columns_number
    if "columns_number" in corps:
        try:
            nombre = int(corps["columns_number"])
        except (TypeError, ValueError):
            return          # la validation du champ lui-même s'en chargera
    if not nombre or nombre < 1:
        return

    for champ, appareil in REPARTITIONS.items():
        if champ not in corps:
            continue
        valeur = str(corps[champ] or "")
        segments = len([m for m in valeur.split("-") if m])
        if segments and segments != nombre:
            attendu = "-".join(["12"] * nombre)
            exemple = "-".join([str(12 // nombre)] * nombre) if 12 % nombre == 0 else attendu
            raise CorpsInvalide(
                f"Cette ligne a {nombre} colonne(s) : « {champ} » doit avoir "
                f"{nombre} segment(s). Reçu « {valeur} » ({segments} segment(s)). "
                f"Les colonnes sans largeur écrasent leur bloc — sur {appareil}, "
                f"il devient illisible sans qu'aucune erreur ne le dise. "
                f"Côte à côte : « {exemple} ». Empilés pleine largeur : "
                f"« {attendu} »."
            )


class DetailLigne(VueAgent):
    permission_requise = MODIFIER

    def _ligne(self, ligne_id):
        return get_object_or_404(Line, id=ligne_id)

    def get(self, request, ligne_id):
        return ok({"ligne": _ligne_en_dict(self._ligne(ligne_id))})

    def patch(self, request, ligne_id):
        ligne = self._ligne(ligne_id)
        corps = self.corps(request)
        _verifier_les_repartitions(ligne, corps)
        try:
            touches = parametres.appliquer(ligne, corps)
        except ParametreInvalide as souci:
            raise CorpsInvalide(str(souci))
        return ok(_avec_avertissements(ligne, touches, {"ligne": _ligne_en_dict(ligne), "modifies": touches}))

    def delete(self, request, ligne_id):
        self._ligne(ligne_id).delete()
        return ok({"supprime": True, "ligne_id": int(ligne_id)})


class BlocsDeLaLigne(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, ligne_id):
        ligne = get_object_or_404(Line, id=ligne_id)
        corps = self.corps(request, obligatoire=False, connues={"colonne", "rang"})

        try:
            colonne = int(corps.get("colonne", 0))
        except (TypeError, ValueError):
            raise CorpsInvalide("« colonne » doit être un nombre entier.")

        if colonne < 0 or colonne >= max(1, ligne.columns_number or 1):
            raise CorpsInvalide(
                f"Cette ligne a {ligne.columns_number} colonne(s) : "
                f"« colonne » doit être entre 0 et {max(0, (ligne.columns_number or 1) - 1)}."
            )

        rang = corps.get("rang")
        if rang is not None:
            try:
                rang = int(rang)
            except (TypeError, ValueError):
                raise CorpsInvalide("« rang » doit être un nombre entier positif ou nul.")
            if rang < 0:
                raise CorpsInvalide("« rang » doit être un nombre entier positif ou nul.")

        bloc = fabrique.creer_bloc(ligne, colonne=colonne_en_base(colonne))
        if rang is not None and bloc.position_in_column != rang:
            # La fabrique empile pour préserver les contraintes d'unicité. On
            # décale uniquement les voisins de la même colonne, puis place le
            # nouveau bloc au rang demandé.
            Bloc.objects.filter(
                line=ligne, position=colonne_en_base(colonne),
                position_in_column__gte=rang,
            ).exclude(pk=bloc.pk).update(
                position_in_column=F("position_in_column") + 1
            )
            bloc.position_in_column = rang
            bloc.save(update_fields=["position_in_column"])
        return ok({"bloc": _bloc_en_dict(bloc)}, statut=201)


class DetailBloc(VueAgent):
    permission_requise = MODIFIER

    def _bloc(self, bloc_id):
        return get_object_or_404(Bloc, id=bloc_id)

    def get(self, request, bloc_id):
        return ok({"bloc": _bloc_en_dict(self._bloc(bloc_id))})

    def patch(self, request, bloc_id):
        bloc = self._bloc(bloc_id)
        try:
            touches = parametres.appliquer(bloc, self.corps(request))
        except ParametreInvalide as souci:
            raise CorpsInvalide(str(souci))
        return ok(_avec_avertissements(bloc, touches, {"bloc": _bloc_en_dict(bloc), "modifies": touches}))

    def delete(self, request, bloc_id):
        self._bloc(bloc_id).delete()
        return ok({"supprime": True, "bloc_id": int(bloc_id)})


# --------------------------------------------------------------------------- #
#  Déplacement
# --------------------------------------------------------------------------- #
#: Comment retrouver les voisins d'un élément, par niveau.
#:
#: Un bloc se déplace dans SA colonne : deux blocs de colonnes différentes sont
#: côte à côte, pas l'un au-dessus de l'autre. C'est pourquoi il a son propre
#: champ d'ordre — `position` désigne la colonne, `position_in_column` le rang.
FRATRIES = {
    "section": (Section, lambda e: {"page_id": e.page_id}, "position"),
    "ligne": (Line, lambda e: {"section_id": e.section_id}, "position"),
    "bloc": (Bloc, lambda e: {"line_id": e.line_id, "position": e.position},
             "position_in_column"),
}


def _deplacer(element, niveau, sens):
    """
    Échange l'élément avec son voisin. Retourne `True` si quelque chose a bougé.

    On échange plutôt qu'on ne renumérote : c'est ce que fait l'éditeur, et
    cela laisse les positions des autres intactes — donc aucune surprise pour
    quelqu'un qui regarde la page pendant qu'un agent la réorganise.
    """
    modele, fratrie, champ = FRATRIES[niveau]
    actuelle = getattr(element, champ)
    if actuelle is None:
        actuelle = 0

    comparaison = "lt" if sens == "haut" else "gt"
    ordre = f"-{champ}" if sens == "haut" else champ

    voisin = (
        modele.objects.filter(**fratrie(element), **{f"{champ}__{comparaison}": actuelle})
        .order_by(ordre)
        .first()
    )
    if voisin is None:
        return False

    setattr(element, champ, getattr(voisin, champ))
    setattr(voisin, champ, actuelle)
    element.save(update_fields=[champ])
    voisin.save(update_fields=[champ])
    return True


class Deplacement(VueAgent):
    """
    Monter ou descendre une section, une ligne ou un bloc.

    Sans ce point d'entrée, un agent ne pouvait qu'**ajouter à la fin** : pour
    insérer une section en deuxième position, il fallait tout reconstruire.
    Les vues de l'éditeur le faisaient déjà ; la logique est reprise ici sur
    les trois niveaux d'un seul tenant, plutôt que recopiée six fois.

    `position` n'est pas modifiable par `PATCH` — et c'est délibéré : l'écrire
    à la main produirait deux éléments au même rang, donc un ordre d'affichage
    arbitraire. On passe par ici, qui renumérote les deux côtés.
    """

    permission_requise = MODIFIER

    def post(self, request, niveau, element_id):
        if niveau not in FRATRIES:
            raise CorpsInvalide(
                f"Niveau « {niveau} » inconnu. Attendus : {', '.join(FRATRIES)}."
            )

        corps = self.corps(request, obligatoire=False, connues={
            "sens", "vers_section", "vers_ligne", "colonne", "rang",
        })
        modele = FRATRIES[niveau][0]
        element = get_object_or_404(modele, id=element_id)

        # Changer de CONTENEUR : une ligne vers une autre section, un bloc
        # vers une autre ligne (ou colonne). Même chemin que l'éditeur.
        if "vers_section" in corps or "vers_ligne" in corps:
            return self._changer_de_conteneur(niveau, element, corps)

        sens = str(corps.get("sens") or "").lower()
        if sens not in ("haut", "bas"):
            raise CorpsInvalide(
                "« sens » doit valoir « haut » ou « bas » — ou bien donner une "
                "destination : « vers_section » pour une ligne, « vers_ligne » "
                "(et « colonne ») pour un bloc."
            )
        bouge = _deplacer(element, niveau, sens)

        return ok({
            "deplace": bouge,
            "niveau": niveau,
            "id": element.id,
            # Faux n'est pas une erreur : c'est « il est déjà en bout de
            # course ». Le dire explicitement évite qu'un agent réessaie.
            "raison": "" if bouge else f"déjà en {'première' if sens == 'haut' else 'dernière'} position",
        })

    @staticmethod
    def _rang(corps):
        if corps.get("rang") is None:
            return None
        try:
            rang = int(corps["rang"])
        except (TypeError, ValueError):
            raise CorpsInvalide("« rang » doit être un entier positif ou nul.")
        if rang < 0:
            raise CorpsInvalide("« rang » doit être un entier positif ou nul.")
        return rang

    def _changer_de_conteneur(self, niveau, element, corps):
        if niveau == "ligne" and "vers_section" in corps:
            cible = Section.objects.filter(pk=corps["vers_section"]).first()
            if cible is None:
                raise CorpsInvalide(f"Aucune section nº {corps['vers_section']}.")
            try:
                fabrique.deplacer_ligne(element, cible, rang=self._rang(corps))
            except fabrique.DeplacementImpossible as souci:
                raise CorpsInvalide(str(souci))
            element.refresh_from_db()
            return ok({"deplace": True, "niveau": niveau, "id": element.id,
                       "section": cible.id, "position": element.position})

        if niveau == "bloc" and "vers_ligne" in corps:
            cible = Line.objects.filter(pk=corps["vers_ligne"]).first()
            if cible is None:
                raise CorpsInvalide(f"Aucune ligne nº {corps['vers_ligne']}.")
            try:
                colonne = int(corps.get("colonne", 0))
            except (TypeError, ValueError):
                raise CorpsInvalide("« colonne » doit être un entier (à partir de 0).")
            dernieres = max(1, cible.columns_number or 1) - 1
            if not 0 <= colonne <= dernieres:
                raise CorpsInvalide(
                    f"La ligne nº {cible.id} a {dernieres + 1} colonne(s) : "
                    f"« colonne » va de 0 à {dernieres}."
                )
            try:
                fabrique.deplacer_bloc(element, cible, colonne=colonne_en_base(colonne),
                                       rang=self._rang(corps))
            except fabrique.DeplacementImpossible as souci:
                raise CorpsInvalide(str(souci))
            element.refresh_from_db()
            return ok({"deplace": True, "niveau": niveau, "id": element.id,
                       "bloc": _bloc_en_dict(element), "ligne": cible.id})

        raise CorpsInvalide(
            "« vers_section » déplace une LIGNE (niveau « ligne ») ; « vers_ligne » "
            "déplace un BLOC (niveau « bloc »). Une section reste dans sa page."
        )


# --------------------------------------------------------------------------- #
#  Contenu d'un bloc
# --------------------------------------------------------------------------- #
#: Les cinq types restants, chacun une poignée de champs sur un objet lié.
#: Décrits en données comme le reste : ajouter un champ ne demande pas
#: d'écrire du code, et l'oublier dans le guide devient impossible puisque
#: celui-ci lit cette table.
CONTENUS_SIMPLES = {
    "TEXT_QUESTIONNAIRE": ("content_text_questionnaire", "ContentTextQuestionnaire", {
        "texte": "raw_text",
    }),
    "CHART": ("content_chart", "ContentChartQuestionnaire", {
        "titre": "title", "description": "description", "type_de_graphique": "chart_type",
        "axe_principal": "main_axis", "options": "options_json",
    }),
    "CALENDAR": ("content_calendar", "ContentCalendar", {
        "titre": "title",
    }),
    "DYN_RESOURCE_CAROUSEL": ("content_resource_config", "DynResourceConfig", {
        "source": "source_type", "limite": "limit", "intervalle": "interval",
        "colonnes_ordinateur": "columns_computer", "colonnes_portable": "columns_laptop",
        "colonnes_tablette": "columns_tablet", "colonnes_telephone": "columns_phone",
        "libelle_bouton": "button_label", "libelle_voir_plus": "load_more_label",
        "type_de_produit": "product_type", "modele_de_fiche": "custom_object_model",
    }),
    "DYN_RESOURCE_GRID": ("content_resource_config", "DynResourceConfig", {
        "source": "source_type", "limite": "limit",
        "colonnes_ordinateur": "columns_computer", "colonnes_portable": "columns_laptop",
        "colonnes_tablette": "columns_tablet", "colonnes_telephone": "columns_phone",
        "libelle_bouton": "button_label", "libelle_voir_plus": "load_more_label",
        "type_de_produit": "product_type", "modele_de_fiche": "custom_object_model",
    }),
}

#: Les deux clés de `DynResourceConfig` qui désignent un AUTRE objet, et par
#: quoi on le désigne.
#:
#: Sans elles, un bloc ressource ne savait dire que « liste des produits » —
#: jamais « liste des abonnements ». C'est pourtant tout l'intérêt : une page
#: de présentation qui liste les formules et renvoie vers chacune, sans qu'on
#: écrive un seul lien à la main.
#:
#: On désigne par CODE et par SLUG, pas par identifiant numérique : un agent
#: qui a lu /types-de-produit/ et /modeles/ connaît « abonnement » et
#: « formule », et ces valeurs restent lisibles dans un document JSON qu'un
#: humain relira. Un `product_type: 4` ne se relit pas.
LIENS_DES_RESSOURCES = {
    "product_type": ("shop.models", "ProductType", "code"),
    "custom_object_model": ("custom_objects.models", "CustomObjectModel", "slug"),
}


def _resoudre_un_lien(champ, valeur):
    """Rend l'objet désigné, ou lève en disant où aller le chercher."""
    from importlib import import_module

    chemin, nom_modele, cle = LIENS_DES_RESSOURCES[champ]
    if valeur in (None, ""):
        return None

    modele = getattr(import_module(f"jeiko.{chemin}"), nom_modele)
    objet = modele.objects.filter(**{cle: str(valeur).strip()}).first()
    if objet is None:
        ou = "/types-de-produit/" if champ == "product_type" else "/modeles/"
        raise CorpsInvalide(
            f"Aucun « {valeur} » : c'est un {cle} attendu, pas un identifiant. "
            f"La liste est en {ou}."
        )
    return objet


def _modele_simple(nom):
    from jeiko.administration_pages import models as M
    return getattr(M, nom)


def _lire_contenu_simple(content):
    lien, _, correspondances = CONTENUS_SIMPLES[content.content_type]
    objet = getattr(content, lien, None)
    if objet is None:
        return {}
    rendu = {}
    for cle, champ in correspondances.items():
        valeur = getattr(objet, champ)
        if champ in LIENS_DES_RESSOURCES:
            # On rend le code/slug, pas l'objet : ce que l'API relit doit
            # pouvoir être renvoyé tel quel, sans traduction par l'appelant.
            _, _, attribut = LIENS_DES_RESSOURCES[champ]
            valeur = getattr(valeur, attribut) if valeur is not None else None
        rendu[cle] = valeur
    return rendu


def _appliquer_contenu_simple(content, type_demande, donnees):
    lien, nom_modele, correspondances = CONTENUS_SIMPLES[type_demande]
    objet = getattr(content, lien, None)
    if objet is None:
        objet = _modele_simple(nom_modele).objects.create()
        setattr(content, lien, objet)

    if not isinstance(donnees, dict):
        raise CorpsInvalide(f"« {type_demande.lower()} » doit être un objet.")

    inconnus = sorted(set(donnees) - set(correspondances))
    if inconnus:
        raise CorpsInvalide(
            f"Clé(s) inconnue(s) : {', '.join(inconnus)}. "
            f"Acceptées pour {type_demande} : {', '.join(sorted(correspondances))}."
        )

    modifies = []
    for cle, valeur in donnees.items():
        champ = correspondances[cle]
        if champ in LIENS_DES_RESSOURCES:
            valeur = _resoudre_un_lien(champ, valeur)
        else:
            # La validation du MODÈLE, champ par champ (Fable 2 §2) : un
            # entier attendu recevait « x » et levait en 500, un choix hors
            # liste passait, une longueur dépassée finissait en 500
            # PostgreSQL. `field.clean` convertit, vérifie choix et longueur.
            from django.core.exceptions import ValidationError

            try:
                valeur = objet._meta.get_field(champ).clean(valeur, objet)
            except ValidationError as souci:
                raise CorpsInvalide(f"« {cle} » : {' '.join(souci.messages)}")
        setattr(objet, champ, valeur)
        modifies.append(champ)
    if modifies:
        objet.save(update_fields=modifies)
    return modifies


#: La vidéo. `source` dit d'où elle vient : un fichier hébergé, une URL
#: externe (YouTube, Vimeo…). L'API ne pose pas de fichier — elle renseigne
#: une URL ou réutilise ce qui est déjà là.
CHAMPS_VIDEO = {
    "source": "source", "fournisseur": "provider", "url": "url",
    "titre": "title", "ratio": "aspect_ratio", "controles": "controls",
    "lecture_auto": "autoplay", "muet": "muted", "boucle": "loop",
    "debut": "start_time", "fin": "end_time", "aria_label": "aria_label",
}


def _valeur_video(cle, valeur):
    """
    Valide une clé de vidéo avant `setattr` (Fable 2 §1.1 et §2).

    L'URL devient le `src` d'une iframe : `javascript:` y exécutait du code.
    `source` et `fournisseur` suivent les choix du modèle ; `debut` et `fin`
    sont des entiers (« x » faisait un 500) ; `ratio` est posé dans un
    attribut `style`, donc borné à « 16/9 » ou « 4:3 ».
    """
    from jeiko.administration_pages.models import ContentVideo

    if cle == "url":
        try:
            return url_sure(valeur, "media", "video.url")
        except ValueError as souci:
            raise CorpsInvalide(str(souci))
    if cle in ("source", "fournisseur"):
        champ = "source" if cle == "source" else "provider"
        permis = [code for code, _ in ContentVideo._meta.get_field(champ).choices]
        if valeur not in permis:
            raise CorpsInvalide(f"« video.{cle} » vaut {', '.join(permis)} — reçu {valeur!r}.")
        return valeur
    if cle in ("debut", "fin"):
        if valeur in (None, ""):
            return None
        if isinstance(valeur, bool) or not isinstance(valeur, int) or valeur < 0:
            raise CorpsInvalide(f"« video.{cle} » attend un nombre entier de secondes.")
        return valeur
    if cle == "ratio":
        texte = str(valeur or "").strip()
        if texte and not re.fullmatch(r"\d{1,3}\s*[/:]\s*\d{1,3}", texte):
            raise CorpsInvalide("« video.ratio » s'écrit comme « 16/9 » ou « 4:3 ».")
        return texte
    if cle in ("controles", "lecture_auto", "muet", "boucle"):
        return bool(valeur)
    return str(valeur or "")[:200]


#: Types de champ d'un formulaire, tels que le modèle les accepte.
TYPES_DE_CHAMP = ("text", "email", "phone", "textarea", "select",
                  "checkbox", "date", "number")

#: L'apparence du formulaire, en vocabulaire français.
#:
#: Elle n'était pas exposée : tout formulaire posé par l'API gardait le bleu
#: par défaut, qui jure sur un site aux couleurs de la maison. Un bouton
#: d'envoi qui ne ressemble à aucun autre bouton de la page ressemble à une
#: erreur, pas à un choix.
#:
#: Les couleurs sont HEXADÉCIMALES et rien d'autre — c'est le modèle qui
#: l'impose (`validate_form_style`), et on le laisse trancher plutôt que de
#: recopier sa règle ici. `var(--jk-accent)` n'y passera donc pas : il faut la
#: valeur, par exemple « #b45309 ».
STYLE_FORMULAIRE = {
    "taille_du_titre": "title_size_px",
    "couleur_du_titre": "title_color",
    "couleur_du_bouton": "button_bg_color",
    "couleur_du_bouton_survol": "button_hover_bg_color",
    "couleur_du_texte_du_bouton": "button_text_color",
    "rayon_du_bouton": "button_radius_px",
}

#: Réglages du formulaire lui-même, écrits par l'API.
#:
#: `destinataire` et `expediteur` se LISENT mais ne s'écrivent pas (Fable 2
#: §2) : un agent — légitime ou détourné — qui posait sa propre adresse en
#: destinataire recevait tous les messages des visiteurs. Un formulaire suit
#: les réglages de l'espace admin : il part de l'adresse d'envoi du site, vers
#: son adresse de réponse, avec celle du visiteur en Reply-To. Seul l'écran
#: humain peut fixer un destinataire propre à un formulaire.
CHAMPS_FORMULAIRE = {
    "nom": "name",
    "description": "description",
    "sujet": "mail_subject",
    "message_de_succes": "success_message",
}

#: Réglages visibles en lecture, réservés à l'écran d'administration.
CHAMPS_FORMULAIRE_RESERVES = {"destinataire", "expediteur"}


def _formulaire_en_dict(formulaire):
    from jeiko.administration_pages.models import DEFAULT_FORM_STYLE

    style = {**DEFAULT_FORM_STYLE, **(formulaire.style or {})}
    return {
        "style": {
            cle: style.get(champ) for cle, champ in STYLE_FORMULAIRE.items()
        },
        "nom": formulaire.name,
        "destinataire": formulaire.to_email or "",
        "sujet": formulaire.mail_subject or "",
        "message_de_succes": formulaire.success_message or "",
        "champs": [
            {
                "nom": c.name, "libelle": c.label, "type": c.type,
                "obligatoire": c.required, "indication": c.placeholder or "",
                "options": c.options or [],
            }
            for c in formulaire.fields.all().order_by("order", "id")
        ],
    }


def _appliquer_formulaire(formulaire, donnees):
    """
    Écrit un formulaire et ses champs.

    Les champs sont REMPLACÉS quand la clé « champs » est présente : un
    formulaire est un tout, et fusionner deux listes par position produirait
    des mélanges silencieux — un libellé sur le mauvais champ, un « email »
    devenu « texte ». Ne pas envoyer « champs » laisse les existants intacts.
    """
    if not isinstance(donnees, dict):
        raise CorpsInvalide("« formulaire » doit être un objet.")

    reserves = sorted(CHAMPS_FORMULAIRE_RESERVES & set(donnees))
    if reserves:
        raise CorpsInvalide(
            f"« {', '.join(reserves)} » ne se règle pas par l'API. Un formulaire "
            f"part de l'adresse d'envoi du site vers son adresse de réponse "
            f"(Réglages ▸ E-mails), avec l'adresse du visiteur en réponse. "
            f"Un destinataire particulier se fixe dans l'écran d'administration."
        )

    modifies = []
    for cle, champ in CHAMPS_FORMULAIRE.items():
        if cle in donnees:
            # Longueur tirée du modèle : `[:500]` sur un champ de 200 faisait
            # un 500 PostgreSQL (Fable 2 §2.3).
            longueur = formulaire._meta.get_field(champ).max_length
            valeur = str(donnees[cle] or "")
            setattr(formulaire, champ, valeur[:longueur] if longueur else valeur)
            modifies.append(champ)
    if modifies:
        formulaire.save(update_fields=modifies)

    style = donnees.get("style")
    if style is not None:
        if not isinstance(style, dict):
            raise CorpsInvalide("« formulaire.style » doit être un objet.")
        inconnus = sorted(set(style) - set(STYLE_FORMULAIRE))
        if inconnus:
            raise CorpsInvalide(
                f"Style de formulaire inconnu : {', '.join(inconnus)}. "
                f"Accepté : {', '.join(sorted(STYLE_FORMULAIRE))}."
            )

        from django.core.exceptions import ValidationError

        from jeiko.administration_pages.models import (
            DEFAULT_FORM_STYLE, validate_form_style,
        )

        nouveau = {**DEFAULT_FORM_STYLE, **(formulaire.style or {})}
        for cle, valeur in style.items():
            nouveau[STYLE_FORMULAIRE[cle]] = valeur

        # On laisse le MODÈLE trancher plutôt que de recopier ses bornes :
        # une seconde validation divergerait au premier réglage ajouté.
        try:
            validate_form_style(nouveau)
        except ValidationError as souci:
            raise CorpsInvalide(
                "Style de formulaire refusé : "
                + " ".join(souci.messages)
                + " Les couleurs sont hexadécimales (#rrggbb)."
            )

        formulaire.style = nouveau
        formulaire.save(update_fields=["style"])
        modifies.append("style")

    if "champs" not in donnees:
        return modifies

    champs = donnees["champs"]
    if not isinstance(champs, list):
        raise CorpsInvalide("« formulaire.champs » doit être une liste.")

    for rang, brut in enumerate(champs):
        if not isinstance(brut, dict):
            raise CorpsInvalide("Chaque champ doit être un objet.")
        type_champ = str(brut.get("type") or "text")
        if type_champ not in TYPES_DE_CHAMP:
            raise CorpsInvalide(
                f"Type de champ « {type_champ} » inconnu. "
                f"Acceptés : {', '.join(TYPES_DE_CHAMP)}."
            )
        nom = str(brut.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide(
                "Chaque champ a besoin d'un « nom » : c'est lui qui sert de "
                "clé dans le message reçu."
            )

    formulaire.fields.all().delete()
    for rang, brut in enumerate(champs):
        ContentFormField.objects.create(
            formulaire=formulaire,
            name=str(brut["nom"])[:100],
            label=str(brut.get("libelle") or brut["nom"])[:200],
            type=str(brut.get("type") or "text"),
            placeholder=str(brut.get("indication") or "")[:200],
            required=bool(brut.get("obligatoire", False)),
            options=brut.get("options") or [],
            order=rang,
        )
    return modifies + ["champs"]


#: Correspondance entre le vocabulaire de l'API et les champs de
#: `ContentButton`. Le modèle n'a **pas** de champ `url` : il a une destination
#: par nature (page interne, URL externe, questionnaire, objet, produit).
#:
#: L'API écrivait auparavant `bouton.url` derrière un `hasattr` : le champ
#: n'existant pas, l'URL était **perdue en silence** — le bouton s'affichait,
#: ne menait nulle part, et rien ne le signalait. C'est le pire cas d'erreur :
#: celui qu'on ne voit qu'en cliquant.
CHAMPS_BOUTON = {
    "libelle": "label",
    "url_externe": "external_url",
    "questionnaire": "test_slug",
    "nouvel_onglet": "open_in_new_tab",
    "ajouter_au_panier": "is_add_to_cart",
    "cle_dynamique": "dynamic_key",
    "aria_label": "aria_label",
    "icone_gauche": "icon_left",
    "icone_droite": "icon_right",
}

#: Les deux cibles d'un bouton qui désignent un AUTRE objet, et par quoi.
#:
#: `product_target` — « Produit cible (si manuel) » — est ce qui rend un bouton
#: « ajouter au panier » utilisable **hors page modèle**. Sur un gabarit de
#: fiche, le produit se déduit de la fiche affichée et le champ reste vide ;
#: sur une page ordinaire — une page de tarifs, une page d'accueil — il n'y a
#: rien à déduire, et sans cible le bouton ne peut rien ajouter.
#:
#: Ne pas les exposer rendait donc l'API incapable de poser un bouton d'achat
#: ailleurs que sur un gabarit. Par référence et par slug, comme partout
#: ailleurs : « JEIKO-EQUIPE » se relit là où « 2 » demande une traduction.
AVERTISSEMENT_PANIER = (
    "Ce bouton ajoute au panier sans « produit_cible ». Il ne fonctionne que "
    "sur une page MODÈLE, où le produit se déduit de la fiche affichée. Sur "
    "une page ordinaire, il s'affiche et ne fait rien."
)

CIBLES_DU_BOUTON = {
    "produit_cible": ("product_target", "shop.models", "Product", "sku"),
    "fiche_cible": (
        "custom_object_target", "custom_objects.models", "CustomObject", "slug"
    ),
}


def _cible_du_bouton(cle, valeur):
    """L'objet désigné, ou None pour retirer la cible."""
    from importlib import import_module

    champ, chemin, nom_modele, attribut = CIBLES_DU_BOUTON[cle]
    if valeur in (None, "", 0):
        return champ, None

    modele = getattr(import_module(f"jeiko.{chemin}"), nom_modele)
    objet = modele.objects.filter(**{attribut: str(valeur).strip()}).first()
    if objet is None:
        ou = "/produits/" if cle == "produit_cible" else "/objets/"
        raise CorpsInvalide(
            f"Aucun « {valeur} » pour « {cle} » : c'est un {attribut} qui est "
            f"attendu, pas un identifiant. La liste est en {ou}."
        )
    # Une fiche se désigne par son originale : le lien mène de lui-même à la
    # version que lit le visiteur. Le slug d'une version y ramène donc.
    return champ, getattr(objet, "origine", objet)

#: La palette du bouton. Elle existe dans le modèle et n'était pas exposée :
#: un agent ne pouvait donc pas donner à un bouton la couleur du site.
STYLE_BOUTON = {
    "fond": "background_color",
    "couleur_texte": "text_color",
    "couleur_bordure": "border_color",
    "fond_survol": "hover_background_color",
    "couleur_texte_survol": "hover_text_color",
    "couleur_bordure_survol": "hover_border_color",
    "rayon": "border_radius",
    "epaisseur_bordure": "border_width",
    "padding": "padding",
    "largeur": "width",
    "hauteur": "height",
    "taille_police": "font_size",
    "graisse": "font_weight",
    "ombre": "box_shadow",
}


def _appliquer_bouton(bouton, donnees):
    """Écrit un bouton : destination, libellé, apparence."""
    if not isinstance(donnees, dict):
        raise CorpsInvalide("« bouton » doit être un objet.")

    # Une clé inconnue est REFUSÉE, pas ignorée. C'est précisément le défaut
    # qu'on vient de corriger : l'ancienne version acceptait « url », un champ
    # qui n'existe pas, et le bouton ne menait nulle part sans un mot. Ignorer
    # en silence ce qu'on ne comprend pas, c'est reproduire la panne sous une
    # autre forme.
    # Un slug de questionnaire inexistant produit un bouton qui ne mène
    # nulle part — le même genre de panne muette que les clés avalées. On
    # vérifie qu'il existe, et on dit lesquels existent.
    if donnees.get("questionnaire"):
        from jeiko.questionnaires_expert.models import ExpertTest

        slug = str(donnees["questionnaire"]).strip()
        if not ExpertTest.objects.filter(slug=slug).exists():
            connus = list(ExpertTest.objects.values_list("slug", flat=True)[:20])
            raise CorpsInvalide(
                f"Aucun questionnaire « {slug} » : le bouton ne mènerait nulle "
                f"part. Connus : {', '.join(connus) or 'aucun'}."
            )

    connues = set(CHAMPS_BOUTON) | set(CIBLES_DU_BOUTON) | {"page_id", "style"}
    inconnues = sorted(set(donnees) - connues)
    if inconnues:
        raise CorpsInvalide(
            f"Clé(s) de bouton inconnue(s) : {', '.join(inconnues)}. "
            f"Acceptées : {', '.join(sorted(connues))}. "
            f"Un bouton n'a pas d'« url » : sa destination dépend de sa nature "
            f"— « page_id » pour une page du site, « url_externe » sinon."
        )

    modifies = []

    for cle, champ in CHAMPS_BOUTON.items():
        if cle not in donnees:
            continue
        valeur = donnees[cle]
        if champ in ("icon_left", "icon_right"):
            from jeiko.icones import ICONES
            if valeur in (None, ""):
                setattr(bouton, champ, None)
                modifies.append(champ)
                continue
            if valeur not in ICONES:
                raise CorpsInvalide(
                    f"Icône « {valeur} » inconnue pour « {cle} ». "
                    f"Disponibles : {', '.join(ICONES)}."
                )
        if champ in ("open_in_new_tab", "is_add_to_cart"):
            valeur = bool(valeur)
        elif champ == "external_url":
            # Fable 2 §1.1 : `javascript:` posé ici s'exécutait chez chaque
            # visiteur. Contrôle partagé, voir jeiko/liens.py.
            try:
                valeur = url_sure(valeur, "lien", "bouton.url_externe")
            except ValueError as souci:
                raise CorpsInvalide(str(souci))
        else:
            valeur = str(valeur or "")[:500]
        setattr(bouton, champ, valeur)
        modifies.append(champ)

    if "page_id" in donnees:
        identifiant = donnees["page_id"]
        if identifiant in (None, "", 0):
            bouton.page_target = None
        else:
            page = Page.objects.filter(pk=identifiant).first()
            if page is None:
                raise CorpsInvalide(f"Bouton : page nº {identifiant} inconnue.")
            if page.is_mail_template or page.is_pdf or page.is_custom_object_template:
                # Un lien qui mènerait à une page introuvable, sans que rien
                # ne le dise à la pose : on refuse, et on dit où regarder.
                raise CorpsInvalide(
                    f"Bouton : la page nº {identifiant} (« {page.title} ») est un "
                    f"gabarit — d'e-mail, de PDF ou de fiche. Le site public ne la "
                    f"sert pas : le bouton mènerait à une page introuvable. "
                    f"GET /pages/ signale ces pages par « gabarit_de_mail », "
                    f"« pdf » et « gabarit_de_fiche »."
                )
            bouton.page_target = page
        modifies.append("page_target")

    for cle in CIBLES_DU_BOUTON:
        if cle in donnees:
            champ, objet = _cible_du_bouton(cle, donnees[cle])
            setattr(bouton, champ, objet)
            modifies.append(champ)

    # Un bouton « ajouter au panier » sans cible ne peut agir que sur une page
    # MODÈLE, où le produit se déduit de la fiche affichée. Ailleurs, il
    # s'affiche normalement et ne fait rien — la panne muette habituelle, sauf
    # qu'ici elle coûte une vente.
    #
    # On ne peut pas savoir depuis ici sur quelle page vit le bloc au moment
    # où l'on écrit le bouton ; on ne refuse donc pas, on RENSEIGNE : la
    # réponse porte l'avertissement, et le guide dit la règle.
    style = donnees.get("style")
    if style is not None:
        if not isinstance(style, dict):
            raise CorpsInvalide("« bouton.style » doit être un objet.")
        inconnus = sorted(set(style) - set(STYLE_BOUTON))
        if inconnus:
            raise CorpsInvalide(
                f"Style de bouton inconnu : {', '.join(inconnus)}. "
                f"Acceptés : {', '.join(sorted(STYLE_BOUTON))}."
            )
        for cle, valeur in style.items():
            setattr(bouton, STYLE_BOUTON[cle], str(valeur)[:100])
            modifies.append(STYLE_BOUTON[cle])

    if modifies:
        bouton.save(update_fields=sorted(set(modifies)))
    return modifies


#: Types qu'un agent peut poser et remplir par l'API.
#:
#: Les vingt autres existent et se voient en lecture, mais chacun a sa propre
#: forme et ses propres objets liés : les ouvrir tous d'un coup, sans les
#: éprouver un par un, produirait une API qui prétend savoir faire ce qu'elle
#: ne sait pas. On ouvre au fil des besoins réels.
#: Fermé : `TEXT_QUESTIONNAIRE` n'est rendu par AUCUN gabarit.
#:
#: `partials/bloc.html` n'a pas de branche pour ce type — zéro occurrence dans
#: tout `templates/`. Un bloc de ce type s'enregistre, se relit par l'API, et
#: n'affiche rien. L'ouvrir revenait à proposer un outil qui ne fait rien, ce
#: qui est pire que de ne pas le proposer : un agent l'aurait choisi pour ce
#: que son nom promet.
#:
#: Les jetons `[%code%]` d'une page modèle vont dans un bloc **TEXT ordinaire**
#: — c'est ce que font les pages modèles en service, et la substitution a lieu
#: au rendu. Il n'y a donc rien à remplacer : le besoin est déjà couvert.
TYPES_FERMES = ("TEXT_QUESTIONNAIRE",)

TYPES_OUVERTS = tuple(sorted(
    set(
        ["TEXT", "BUTTON", "IMAGE", "FORM", "VIDEO"]
        + list(contenus_dynamiques.TYPES)
        + list(contenus_dynamiques.TYPES_SANS_ELEMENTS)
        + list(CONTENUS_SIMPLES)
    )
    - set(TYPES_FERMES)
))


#: Le document que chaque type attend, en plus de « type ». Les contenus
#: simples le nomment d'après leur type en minuscules — c'est ce que fait
#: `corps.get(type_demande.lower())`.
DOCUMENTS_ATTENDUS = {
    "TEXT": {"texte"},
    "BUTTON": {"bouton"},
    "FORM": {"formulaire"},
    "VIDEO": {"video"},
    "IMAGE": {"image_id"},
}


def _refuser_les_cles_inconnues(corps, type_demande):
    """
    Une clé que l'API ne connaît pas doit faire ÉCHOUER l'appel.

    Le défaut qu'on ferme ici a coûté une demi-journée : envoyer
    `{"type": "TEXT_QUESTIONNAIRE", "texte_questionnaire": {...}}` — au lieu de
    « text_questionnaire » — renvoyait **200 OK** et n'écrivait rien.
    `corps.get(type_demande.lower()) or {}` transformait une faute de frappe en
    succès silencieux, et la page restait vide sans que rien ne le signale.

    C'est la même famille qu'A-12, A-17, A-22 et S-17 : une écriture qui
    réussit et ne produit rien. Un appelant ne peut pas se corriger si on ne
    lui dit pas qu'il s'est trompé — surtout un agent, qui n'ira pas regarder
    la page.
    """
    attendues = DOCUMENTS_ATTENDUS.get(type_demande)
    if attendues is None:
        if type_demande in CONTENUS_SIMPLES:
            attendues = {type_demande.lower()}
        else:
            # Blocs dynamiques : « options » et « elements ».
            attendues = {"options", "elements"}

    inconnues = sorted(set(corps) - attendues - {"type"})
    if inconnues:
        raise CorpsInvalide(
            f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
            f"Pour {type_demande}, attendu : {', '.join(sorted(attendues))}. "
            f"Le catalogue du guide (GET /) donne le document de chaque type."
        )


class ContenuDuBloc(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def put(self, request, bloc_id):
        bloc = get_object_or_404(Bloc, id=bloc_id)
        avertissements = ecrire_le_contenu(bloc, self.corps(request))
        reponse = {"bloc": _bloc_en_dict(bloc)}
        if avertissements:
            reponse["avertissements"] = avertissements
        return ok(reponse)


def ecrire_le_contenu(bloc, corps):
    """
    Pose le contenu d'un bloc ; rend ce que l'assainissement a retiré.

    Partagé par `ContenuDuBloc` et `ConstructionDePage` : un contenu écrit dans
    un arbre complet passe exactement par les mêmes refus qu'écrit seul.
    """
    type_demande = str(corps.get("type") or "").upper()
    if type_demande not in TYPES_OUVERTS:
        raise CorpsInvalide(
            f"Type « {type_demande or 'absent'} » non modifiable par l'API. "
            f"Ouverts : {', '.join(TYPES_OUVERTS)}."
        )

    content, _ = Content.objects.get_or_create(bloc=bloc)
    _refuser_les_cles_inconnues(corps, type_demande)

    # Ce que l'assainissement a retiré, s'il a retiré quelque chose. La
    # liste part dans la réponse : sans elle, un agent relit son propre
    # HTML intact — l'API rend ce qu'elle a stocké — et ne découvre
    # l'amputation que sur la page publiée. Voir `sanitize.py`.
    avertissements = []

    if type_demande == "TEXT":
        if content.content_text is None:
            content.content_text = ContentText.objects.create(text="")
        if "texte" in corps:
            # Avant d'assainir : ce contenu survivra-t-il à l'ÉDITEUR ?
            # C'est une question distincte de « est-il sûr à servir », et
            # aucun test de rendu ne peut y répondre. Voir
            # `compatibilite_editeur`.
            try:
                compatibilite_editeur.verifier(corps["texte"])
            except compatibilite_editeur.ContenuNonEditable as souci:
                raise CorpsInvalide(str(souci))
            propre, avertissements = nettoyer_en_rendant_compte(corps["texte"])
            content.content_text.text = propre
            content.content_text.save(update_fields=["text"])

    elif type_demande == "BUTTON":
        if content.content_button is None:
            content.content_button = ContentButton.objects.create(
                label="Cliquez ici"
            )
        _appliquer_bouton(content.content_button, corps.get("bouton") or {})

    elif type_demande == "FORM":
        if content.content_formulaire is None:
            content.content_formulaire = ContentFormulaire.objects.create(
                name="Formulaire",
                mail_subject="Nouveau message reçu",
                success_message="Merci, votre message a bien été envoyé.",
            )
        _appliquer_formulaire(content.content_formulaire, corps.get("formulaire") or {})

    elif type_demande == "VIDEO":
        if content.content_video is None:
            content.content_video = ContentVideo.objects.create(
                source=ContentVideo.Source.EXTERNAL
            )
        video = corps.get("video") or {}
        if not isinstance(video, dict):
            raise CorpsInvalide("« video » doit être un objet.")
        inconnus = sorted(set(video) - set(CHAMPS_VIDEO))
        if inconnus:
            raise CorpsInvalide(
                f"Clé(s) de vidéo inconnue(s) : {', '.join(inconnus)}. "
                f"Acceptées : {', '.join(sorted(CHAMPS_VIDEO))}."
            )
        modifies = []
        for cle, valeur in video.items():
            valeur = _valeur_video(cle, valeur)
            setattr(content.content_video, CHAMPS_VIDEO[cle], valeur)
            modifies.append(CHAMPS_VIDEO[cle])
        if modifies:
            content.content_video.save(update_fields=modifies)

    elif type_demande in CONTENUS_SIMPLES:
        _appliquer_contenu_simple(
            content, type_demande, corps.get(type_demande.lower()) or {}
        )
        # Ces deux-là sont AUSSI des blocs dynamiques : leur configuration
        # vit dans un objet lié, mais leurs options restent dans `data`.
        if contenus_dynamiques.est_dynamique(type_demande):
            content.content_type = type_demande
            content.save(update_fields=["content_type"])
            try:
                contenus_dynamiques.appliquer(content, corps)
            except ElementInvalide as souci:
                raise CorpsInvalide(str(souci))

    elif contenus_dynamiques.est_dynamique(type_demande):
        # Le type doit être posé AVANT d'écrire : `contenus_dynamiques`
        # choisit le modèle d'élément d'après `content.content_type`.
        content.content_type = type_demande
        content.save(update_fields=["content_type"])
        try:
            contenus_dynamiques.appliquer(content, corps)
        except ElementInvalide as souci:
            raise CorpsInvalide(str(souci))

    elif type_demande == "IMAGE":
        # Le fichier vient de l'upload validé /images/creer/ ou de
        # l'administration. Chaque bloc garde son cadrage dans un
        # satellite distinct ; le média, lui, peut être partagé (M-02).
        identifiant = corps.get("image_id")
        if identifiant in (None, "", 0):
            raise CorpsInvalide(
                "« image_id » est obligatoire pour un bloc IMAGE et doit "
                "désigner une image déjà présente dans la médiathèque."
            )
        image = ImageContent.objects.filter(pk=identifiant).first()
        if image is None:
            raise CorpsInvalide(f"Aucune image nº {identifiant} dans la médiathèque.")
        if content.content_image is None:
            content.content_image = ContentImage.objects.create(image_content=image)
        elif content.content_image.image_content_id != image.pk:
            content.content_image.image_content = image
            content.content_image.save(update_fields=["image_content"])

    content.content_type = type_demande
    content.save()
    return avertissements


# --------------------------------------------------------------------------- #
#  Catégories de pages
# --------------------------------------------------------------------------- #
def _categorie_en_dict(categorie):
    return {
        "id": categorie.id,
        "nom": categorie.name,
        "slug": categorie.slug,
        "categorie_parente": (
            categorie.main_category.slug if categorie.main_category_id else None
        ),
        # Sans cette clé, on ne pouvait pas savoir pourquoi une page classée
        # gardait une adresse à plat.
        "afficher_dans_l_url": categorie.show_cat_in_url,
        # Le nom et le slug dans les autres langues du site :
        # {"en": {"nom": "Services", "slug": "our-services"}}.
        "traductions": {
            code: {"nom": (v or {}).get("name", ""), "slug": (v or {}).get("slug", "")}
            for code, v in (categorie.traductions or {}).items()
        },
    }


def _traductions_de_categorie(brut):
    """Valide `traductions` et le rend dans la forme enregistrée."""
    from jeiko.administration_pages.models import Category

    from .vues_api import traductions_nom_et_slug

    return traductions_nom_et_slug(brut, Category)


class ListeDesCategories(VueAgent):
    """
    Les catégories et sous-catégories, avec leurs slugs.

    À lire avant de classer une page : c'est ici qu'un agent apprend que la
    catégorie s'appelle « electricite » et non « Électricité ». Sans cette
    route, `categorie` serait un champ qu'on ne peut renseigner qu'en devinant.
    """

    permission_requise = LIRE

    def get(self, request):
        from jeiko.administration_pages.models import Category

        categories = Category.objects.select_related("main_category").order_by("name")
        return ok({"categories": [_categorie_en_dict(c) for c in categories]})


class CreationCategorie(VueAgent):
    """
    Crée une catégorie, éventuellement sous une autre.

    Le slug entre dans les URL de listage : il est normalisé à la création et
    ne se modifie pas ensuite par l'API — le renommer casserait les liens
    déjà publiés, silencieusement.
    """

    permission_requise = CREER

    @transaction.atomic
    def post(self, request):
        from jeiko.administration_pages.models import Category

        corps = self.corps(request)
        connues = {"nom", "slug", "categorie_parente", "afficher_dans_l_url"}
        inconnues = sorted(set(corps) - connues)
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Attendues : {', '.join(sorted(connues))}."
            )

        nom = str(corps.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide("« nom » est obligatoire.")

        slug = slugify(str(corps.get("slug") or nom).strip())
        if not slug:
            raise CorpsInvalide("« slug » ne donne rien d'utilisable.")
        # Réservé (`api`, `administration`…) : toutes les pages de la
        # catégorie seraient inatteignables (Fable 2 §2.4).
        slug_racine = slug  # la réservation ne se juge qu'à la racine, plus bas
        longueur_slug = Category._meta.get_field("slug").max_length
        if longueur_slug and len(slug) > longueur_slug:
            raise CorpsInvalide(f"« slug » fait au plus {longueur_slug} caractères.")
        parente = None
        if corps.get("categorie_parente"):
            parente = Category.objects.filter(
                slug=str(corps["categorie_parente"]).strip()
            ).first()
            if parente is None:
                raise CorpsInvalide(
                    f"Aucune catégorie « {corps['categorie_parente']} ». "
                    f"Voir /categories/."
                )

        # `show_cat_in_url` décide si la catégorie apparaît dans l'adresse des
        # pages qu'elle contient : `/documentation/api/` plutôt que `/api/`.
        #
        # Il ne l'était pas, et son défaut est `False` : une catégorie créée
        # par l'API ne servait donc qu'au classement, jamais à l'organisation
        # des URL. On ne pouvait pas s'en apercevoir autrement qu'en regardant
        # l'adresse d'une page qu'on venait de classer.
        #
        # Le défaut est ici `True` : une catégorie créée POUR ranger des pages
        # est presque toujours destinée à se voir. Celle qui ne sert qu'au
        # regroupement le dit explicitement.
        dans_l_url = bool(corps.get("afficher_dans_l_url", True))
        # Une catégorie de premier niveau visible dans les URL occupe
        # `/<slug>/` : réservé (`api`…), toutes ses pages seraient
        # inatteignables (Fable 2 §2.4).
        if dans_l_url and parente is None:
            refuser_une_adresse_reservee(f"/{slug_racine}/", "slug")
        if dans_l_url and parente is not None and not parente.show_cat_in_url:
            raise CorpsInvalide(
                f"« {parente.slug or parente.name} » n'apparaît pas dans les "
                f"URL : une sous-catégorie ne peut pas s'y montrer sans son "
                f"parent. Régler d'abord la catégorie parente."
            )

        # Le slug n'est plus unique par site, mais par CHEMIN.
        #
        # Deux sous-catégories peuvent porter le même nom et le même slug tant
        # que leur parente paraît dans l'URL : « Actualités » sous
        # « Formations » et sous « Coaching » donnent /formations/actualites/ et
        # /coaching/actualites/, qui se distinguent très bien. L'interdire
        # obligeait à inventer « actualites-2 », qui se retrouve ensuite dans
        # l'adresse publique — un défaut visible par le visiteur pour protéger
        # une contrainte qui n'avait pas lieu d'être.
        #
        # Ce qu'on refuse, c'est ce qu'on ne saurait plus DISTINGUER : deux
        # catégories au même chemin public, ou — quand elles n'apparaissent pas
        # dans les URL — deux fois le même slug, qui rendrait ambiguë toute
        # désignation par slug dans cette API.
        candidate = Category(
            name=borne(Category, "name", nom), slug=slug, main_category=parente,
            show_cat_in_url=dans_l_url,
        )
        jumelles = adresses.categories_au_meme_chemin(candidate)
        if jumelles:
            occupee = adresses.chemin_de_categorie(candidate)
            raise CorpsInvalide(
                f"« {occupee} » est déjà l'adresse de "
                f"« {jumelles[0].name} » (id {jumelles[0].id}). Deux "
                f"catégories ne peuvent pas occuper le même chemin : changez "
                f"le slug, ou rangez celle-ci sous une autre parente."
            )

        if adresses.chemin_de_categorie(candidate) is None:
            sans_chemin = [
                c for c in Category.objects.filter(slug=slug)
                if adresses.chemin_de_categorie(c) is None
            ]
            if sans_chemin:
                raise CorpsInvalide(
                    f"Une catégorie « {slug} » qui n'apparaît pas dans les URL "
                    f"existe déjà (id {sans_chemin[0].id}). Deux catégories "
                    f"invisibles au même slug ne se distingueraient plus : "
                    f"aucun chemin ne les sépare. Choisissez un autre slug, ou "
                    f"faites-les paraître dans l'URL sous des parentes "
                    f"différentes."
                )

        # Le nom reste unique AU MÊME NIVEAU : deux « Actualités » sous la même
        # parente ne se distingueraient dans aucun écran d'administration. La
        # base le dit ; sans ce contrôle, elle le disait en 500, et l'appelant
        # recevait une page HTML d'erreur pour un doublon de saisie.
        homonyme = Category.objects.filter(
            name=borne(Category, "name", nom), main_category=parente
        ).first()
        if homonyme is not None:
            ou = (
                f"sous « {parente.name} »" if parente is not None
                else "à la racine"
            )
            raise CorpsInvalide(
                f"Une catégorie « {nom} » existe déjà {ou} (id {homonyme.id}). "
                f"Deux catégories de même nom au même niveau ne se "
                f"distingueraient nulle part. Le même nom est en revanche "
                f"permis sous une autre parente."
            )

        categorie = Category.objects.create(
            name=borne(Category, "name", nom), slug=slug, main_category=parente,
            show_cat_in_url=dans_l_url,
        )
        return ok({"categorie": _categorie_en_dict(categorie)}, statut=201)


# --------------------------------------------------------------------------- #
#  Mesures PageSpeed — en lecture seule
# --------------------------------------------------------------------------- #
def _url_publique(page):
    """L'adresse à laquelle la page répond aujourd'hui, telle que mesurée."""
    try:
        from jeiko.administration_pages.utils import page_public_url

        return page_public_url(page)
    except Exception:
        return ""


class MesuresDeLaPage(VueAgent):
    """
    Ce que Google mesure sur une page : scores, Core Web Vitals, audits ratés.

    Pourquoi en lecture seule, et pourquoi quand même
    -------------------------------------------------
    Un agent qui construit des pages ne peut pas juger de ce qu'il produit :
    il voit son HTML, pas le temps de chargement chez un visiteur, ni la
    balise qui manque. Ces mesures existent déjà — elles sont relevées par
    l'administration — et les taire revenait à demander un travail sans jamais
    en montrer le résultat.

    **Rien ne se déclenche ici.** Lancer une mesure consomme du quota API et
    coûte de l'argent au propriétaire du site ; une boucle d'agent qui
    redemanderait une analyse après chaque modification viderait le quota en
    une après-midi. On lit ce qui a été relevé, on ne le provoque pas.

    `raw_json` n'est pas rendu : c'est plusieurs centaines de kilo-octets de
    Lighthouse brut, dont l'essentiel est déjà résumé dans les champs ci-après.
    """

    permission_requise = LIRE

    def get(self, request, page_id):
        from jeiko.administration_pages.models import PageInsights

        page = get_object_or_404(Page, pk=page_id)
        strategie = request.GET.get("appareil")

        mesures = PageInsights.objects.filter(page=page)
        if strategie:
            mesures = mesures.filter(strategy=strategie)

        derniere = mesures.order_by("-fetched_at").first()
        if derniere is None:
            return ok({
                "page": page.id,
                "mesure": None,
                "note": (
                    "Aucune mesure relevée pour cette page. Les analyses se "
                    "lancent depuis l'administration : elles consomment un "
                    "quota facturé, et l'API ne les déclenche pas."
                ),
            })

        return ok({"page": page.id, "mesure": _mesure_en_dict(derniere)})


def _mesure_en_dict(mesure):
    """
    Le relevé, réduit à ce sur quoi on peut agir.

    Les scores disent où on en est ; les audits ratés disent quoi corriger.
    Le reste — le JSON Lighthouse complet — n'aiderait pas à décider.
    """
    return {
        "appareil": mesure.strategy,
        "etat": mesure.status,
        "url_testee": mesure.url_tested,
        # Un relevé est un INSTANTANÉ, et l'adresse d'une page peut avoir
        # changé depuis — un rangement en catégorie suffit. Le relevé porte
        # alors sur une autre page, ou sur une adresse qui n'existe plus, tout
        # en affichant des scores parfaitement plausibles.
        #
        # Le cas s'est produit : un lecteur extérieur a conclu qu'une page
        # notée « performance 100 » allait bien, alors que l'adresse mesurée
        # répondait 404. Rien dans la réponse ne permettait de s'en douter —
        # il fallait comparer soi-même deux champs dont l'un n'était pas là.
        "url_actuelle": _url_publique(mesure.page),
        "mesure_obsolete": _url_publique(mesure.page) != (mesure.url_tested or ""),
        "releve_le": mesure.fetched_at.isoformat() if mesure.fetched_at else None,
        "scores": {
            "performance": mesure.score_performance,
            "accessibilite": mesure.score_accessibility,
            "bonnes_pratiques": mesure.score_best_practices,
            "seo": mesure.score_seo,
        },
        # Les trois signaux que Google utilise pour classer. « crux » vient des
        # visiteurs réels, « lab » d'une mesure de laboratoire : les premiers
        # comptent, les seconds expliquent.
        "web_vitals_visiteurs": {
            "lcp_ms": mesure.crux_lcp_ms,
            "inp_ms": mesure.crux_inp_ms,
            "cls": mesure.crux_cls,
        },
        "web_vitals_laboratoire": {
            "lcp_ms": mesure.lab_lcp_ms,
            "fcp_ms": mesure.lab_fcp_ms,
            "cls": mesure.lab_cls,
            "ttfb_ms": mesure.lab_ttfb_ms,
            "tbt_ms": mesure.lab_tbt_ms,
        },
        "seo": {
            "titre": mesure.seo_title_ok,
            "meta_description": mesure.seo_meta_description_ok,
            "viewport": mesure.seo_viewport_ok,
            "taille_de_police": mesure.seo_font_size_ok,
            "zones_cliquables": mesure.seo_tap_targets_ok,
            "canonique": mesure.seo_canonical_ok,
            "indexable": mesure.seo_is_crawlable,
        },
        "audits_rates": {
            "accessibilite": mesure.a11y_failed_ids or [],
            "seo": mesure.seo_failed_ids or [],
        },
        "a_corriger_en_priorite": mesure.top_issues or [],
    }


class DetailCategorie(VueAgent):
    """
    Corrige une catégorie — son nom, sa parente, sa visibilité dans les URL.

    Sans cette route, une catégorie créée sans `afficher_dans_l_url` restait
    invisible dans les adresses pour toujours : la création ne se rejoue pas,
    le slug étant unique.
    """

    permission_requise = MODIFIER

    def get(self, request, categorie_id):
        from jeiko.administration_pages.models import Category

        return ok({"categorie": _categorie_en_dict(
            get_object_or_404(Category, pk=categorie_id)
        )})

    @transaction.atomic
    def delete(self, request, categorie_id):
        """
        Supprime une catégorie VIDE, et rien d'autre.

        Le besoin est réel : une catégorie créée pour essayer ne se corrige
        pas — son slug est unique et ne se modifie plus — et restait donc en
        base pour toujours. Deux « ZZ — sonde technique » l'ont prouvé sur un
        site en service.

        Mais la supprimer pleine ne se voit pas. `Page.category` est en
        `SET_NULL` : les pages ne disparaîtraient pas, elles se
        DÉCLASSERAIENT — leur adresse changerait, les liens publiés
        tomberaient, et aucune erreur n'apparaîtrait nulle part. Les
        sous-catégories, elles, sont en `CASCADE` : elles partiraient avec.

        D'où le refus quand quelque chose s'y rattache, en disant quoi. Vider
        d'abord est un geste explicite ; supprimer en cascade ne l'est pas.
        """
        from jeiko.administration_pages.models import Category, Page

        categorie = get_object_or_404(Category, pk=categorie_id)

        pages = Page.objects.filter(
            Q(category=categorie) | Q(sub_category=categorie)
        ).count()
        filles = categorie.sub_categories.count()

        if pages or filles:
            details = []
            if pages:
                details.append(f"{pages} page(s) y sont classées")
            if filles:
                details.append(f"{filles} sous-catégorie(s) en dépendent")
            raise CorpsInvalide(
                f"Catégorie non vide : {', et '.join(details)}. La supprimer "
                f"déclasserait les pages — leur adresse changerait sans qu'aucune "
                f"erreur ne le dise — et emporterait les sous-catégories. "
                f"Reclassez-les d'abord (PATCH /pages/<id>/ « categorie »)."
            )

        categorie.delete()
        return ok({"supprime": categorie_id})

    @transaction.atomic
    def patch(self, request, categorie_id):
        from jeiko.administration_pages.models import Category

        categorie = get_object_or_404(Category, pk=categorie_id)
        corps = self.corps(request)

        connues = {"nom", "afficher_dans_l_url", "categorie_parente", "traductions"}
        inconnues = sorted(set(corps) - connues)
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Acceptées : {', '.join(sorted(connues))}. "
                f"Le « slug » ne se modifie pas : il est dans l'adresse de "
                f"chaque page de la catégorie."
            )

        modifies = []
        if "nom" in corps:
            nouveau_nom = borne(Category, "name", corps["nom"])
            homonyme = Category.objects.filter(
                name=nouveau_nom, main_category=categorie.main_category
            ).exclude(pk=categorie.pk).first()
            if homonyme is not None:
                raise CorpsInvalide(
                    f"Une catégorie « {nouveau_nom} » existe déjà à ce niveau "
                    f"(id {homonyme.id}) : les deux seraient indiscernables "
                    f"dans les écrans de l'administration."
                )
            categorie.name = nouveau_nom
            modifies.append("name")

        if "categorie_parente" in corps:
            parente = _categorie(corps["categorie_parente"])
            categorie.main_category = parente
            modifies.append("main_category")

        if "afficher_dans_l_url" in corps:
            visible = bool(corps["afficher_dans_l_url"])
            parente = categorie.main_category
            if visible and parente is not None and not parente.show_cat_in_url:
                raise CorpsInvalide(
                    f"« {parente.slug or parente.name} » n'apparaît pas dans "
                    f"les URL : une sous-catégorie ne peut pas s'y montrer "
                    f"sans son parent."
                )
            # Retirer une catégorie des URL remonte TOUTES ses pages d'un
            # cran — jusqu'à la racine si c'est la catégorie principale. Deux
            # pages qui vivaient en /formations/tarifs/ et /coaching/tarifs/
            # se retrouvent alors toutes deux en /tarifs/ : une seule répond,
            # l'autre devient inatteignable, et rien ne le signale. La
            # contrainte de base ne couvre que les pages SANS catégorie, pas
            # celles dont la catégorie est masquée.
            #
            # C'est la contrepartie de la souplesse accordée à la création :
            # deux sous-catégories peuvent partager un slug tant que le segment
            # parent les sépare. On vérifie donc, avant d'écrire, que le
            # segment qu'on retire ne portait pas seul cette distinction.
            if not visible:
                conflits = adresses.collisions_si_on_change(
                    categorie, show_cat_in_url=False
                )
                if conflits:
                    raise CorpsInvalide(adresses.message_de_conflit(conflits))

            categorie.show_cat_in_url = visible
            modifies.append("show_cat_in_url")

        if "traductions" in corps:
            from django.core.exceptions import ValidationError

            # Les langues envoyées remplacent les leurs ; les autres restent.
            # Une langue envoyée vide ({}) retire sa traduction.
            envoyees = corps["traductions"] if isinstance(corps["traductions"], dict) else None
            nouvelles = _traductions_de_categorie(corps["traductions"])
            categorie.traductions = {
                **{c: v for c, v in (categorie.traductions or {}).items() if c not in envoyees},
                **nouvelles,
            }
            try:
                categorie.verifier_les_traductions()
            except ValidationError as refus:
                raise CorpsInvalide(" ".join(refus.messages)) from refus
            modifies.append("traductions")

        if modifies:
            categorie.save(update_fields=modifies)
        return ok({"categorie": _categorie_en_dict(categorie), "modifie": modifies})


# --------------------------------------------------------------------------- #
#  Construire d'un coup : une page, une section, une ligne
# --------------------------------------------------------------------------- #
#: Ce que chaque niveau de l'arbre accepte. Une clé inconnue est refusée,
#: comme partout dans l'API : à cette échelle, une faute de frappe avalée
#: coûterait une page entière bâtie de travers.
CLES_DE_SECTION = {"gabarit", "parametres", "lignes"}
CLES_DE_LIGNE = {"colonnes", "parametres", "blocs"}
CLES_DE_BLOC = {"colonne", "contenu", "parametres"}

#: Garde-fou de volume : la plus longue page de jeiko.fr compte une
#: cinquantaine de blocs. Au-delà de ce plafond, c'est une boucle qui
#: s'emballe, pas une page.
MAX_BLOCS_PAR_CONSTRUCTION = 300


class _Construction:
    """
    Bâtit un arbre section > ligne > bloc > contenu, en tenant le compte.

    Le problème résolu : monter une page coûtait un appel par section, par
    ligne, par bloc, par contenu et par réglage — une trentaine pour une page
    sobre, chacun renvoyant l'arbre complet de l'élément. Ici, un seul appel,
    et une réponse qui ne rend que les identifiants.

    Rien n'est inventé : chaque élément passe par la fabrique, chaque réglage
    par `parametres.appliquer`, chaque contenu par `ecrire_le_contenu` — les
    mêmes chemins, donc les mêmes refus, que les routes unitaires.

    Ce que ça ne fait pas : la transaction est celle de l'appelant. C'est la
    vue qui l'ouvre, pour que la moindre erreur ne laisse RIEN en base : une
    page à moitié construite est pire qu'un refus, puisqu'il faudrait la
    retrouver et la défaire.
    """

    def __init__(self):
        self.blocs = 0
        self.avertissements = []

    @staticmethod
    def _liste(valeur, cle, chemin):
        if valeur is None:
            return []
        if not isinstance(valeur, list):
            raise CorpsInvalide(f"{chemin} : « {cle} » doit être une liste.")
        return valeur

    @staticmethod
    def _objet(valeur, cles, chemin):
        if not isinstance(valeur, dict):
            raise CorpsInvalide(f"{chemin} doit être un objet.")
        inconnues = sorted(set(valeur) - cles)
        if inconnues:
            raise CorpsInvalide(
                f"{chemin} : clé(s) inconnue(s) {', '.join(inconnues)}. "
                f"Acceptées : {', '.join(sorted(cles))}."
            )
        return valeur

    def _regler(self, element, reglages, chemin):
        if reglages in (None, {}):
            return
        if not isinstance(reglages, dict):
            raise CorpsInvalide(f"{chemin}.parametres doit être un objet.")
        try:
            touches = parametres.appliquer(element, reglages)
        except ParametreInvalide as souci:
            raise CorpsInvalide(f"{chemin}.parametres : {souci}")
        for rappel in parametres.avertissements(element, touches):
            self.avertissements.append(f"{chemin} : {rappel}")

    def section(self, page, donnees, chemin):
        donnees = self._objet(donnees, CLES_DE_SECTION, chemin)
        gabarit = str(donnees.get("gabarit") or "CLASSIC").upper()
        try:
            section = fabrique.creer_section(page, gabarit=gabarit)
        except ValueError as souci:
            raise CorpsInvalide(f"{chemin} : {souci}")
        self._regler(section, donnees.get("parametres"), chemin)
        lignes = [
            self.ligne(section, ligne, f"{chemin}.lignes[{n}]")
            for n, ligne in enumerate(self._liste(donnees.get("lignes"), "lignes", chemin))
        ]
        return {"id": section.id, "lignes": lignes}

    def ligne(self, section, donnees, chemin):
        donnees = self._objet(donnees, CLES_DE_LIGNE, chemin)
        try:
            colonnes = int(donnees.get("colonnes", 1))
        except (TypeError, ValueError):
            raise CorpsInvalide(f"{chemin} : « colonnes » doit être un nombre entier.")
        if not 1 <= colonnes <= 12:
            raise CorpsInvalide(f"{chemin} : « colonnes » doit être entre 1 et 12.")
        ligne = fabrique.creer_ligne(section, colonnes=colonnes)
        reglages = donnees.get("parametres")
        if isinstance(reglages, dict):
            try:
                _verifier_les_repartitions(ligne, reglages)
            except CorpsInvalide as souci:
                raise CorpsInvalide(f"{chemin}.parametres : {souci}")
        self._regler(ligne, reglages, chemin)
        blocs = [
            self.bloc(ligne, bloc, f"{chemin}.blocs[{n}]")
            for n, bloc in enumerate(self._liste(donnees.get("blocs"), "blocs", chemin))
        ]
        return {"id": ligne.id, "blocs": blocs}

    def bloc(self, ligne, donnees, chemin):
        donnees = self._objet(donnees, CLES_DE_BLOC, chemin)
        self.blocs += 1
        if self.blocs > MAX_BLOCS_PAR_CONSTRUCTION:
            raise CorpsInvalide(
                f"Plus de {MAX_BLOCS_PAR_CONSTRUCTION} blocs en un appel : "
                f"découpez la construction (une section à la fois, par exemple)."
            )
        try:
            colonne = int(donnees.get("colonne", 0))
        except (TypeError, ValueError):
            raise CorpsInvalide(f"{chemin} : « colonne » doit être un nombre entier.")
        nombre = max(1, ligne.columns_number or 1)
        if not 0 <= colonne < nombre:
            raise CorpsInvalide(
                f"{chemin} : la ligne a {nombre} colonne(s), « colonne » doit "
                f"être entre 0 et {nombre - 1}."
            )
        bloc = fabrique.creer_bloc(ligne, colonne=colonne_en_base(colonne))
        self._regler(bloc, donnees.get("parametres"), chemin)
        contenu = donnees.get("contenu")
        if contenu is not None:
            if not isinstance(contenu, dict):
                raise CorpsInvalide(f"{chemin}.contenu doit être un objet.")
            try:
                retires = ecrire_le_contenu(bloc, contenu)
            except CorpsInvalide as souci:
                raise CorpsInvalide(f"{chemin}.contenu : {souci}")
            for retire in retires or []:
                self.avertissements.append(f"{chemin}.contenu : {retire}")
        return bloc.id


def _reponse_de_construction(construction, cle, arbre, **autres):
    reponse = {**autres, cle: arbre}
    if construction.avertissements:
        reponse["avertissements"] = construction.avertissements
    return ok(reponse, statut=201)


class ConstructionDePage(VueAgent):
    """Ajoute à la fin d'une page des sections complètes, d'un seul appel."""

    permission_requise = MODIFIER

    def post(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        corps = self.corps(request, connues={"sections"})
        sections = _Construction._liste(corps.get("sections"), "sections", "corps")
        if not sections:
            raise CorpsInvalide("« sections » est attendu : une liste d'au moins une section.")
        construction = _Construction()
        with transaction.atomic():
            arbre = [construction.section(page, s, f"sections[{n}]") for n, s in enumerate(sections)]
        return _reponse_de_construction(construction, "sections", arbre, page_id=page.id)


class ConstructionDeSection(VueAgent):
    """Ajoute à la fin d'une section des lignes complètes, d'un seul appel."""

    permission_requise = MODIFIER

    def post(self, request, section_id):
        section = get_object_or_404(Section, id=section_id)
        corps = self.corps(request, connues={"lignes"})
        lignes = _Construction._liste(corps.get("lignes"), "lignes", "corps")
        if not lignes:
            raise CorpsInvalide("« lignes » est attendu : une liste d'au moins une ligne.")
        construction = _Construction()
        with transaction.atomic():
            arbre = [construction.ligne(section, l, f"lignes[{n}]") for n, l in enumerate(lignes)]
        return _reponse_de_construction(construction, "lignes", arbre, section_id=section.id)


class ConstructionDeLigne(VueAgent):
    """Ajoute à une ligne des blocs remplis et réglés, d'un seul appel."""

    permission_requise = MODIFIER

    def post(self, request, ligne_id):
        ligne = get_object_or_404(Line, id=ligne_id)
        corps = self.corps(request, connues={"blocs"})
        blocs = _Construction._liste(corps.get("blocs"), "blocs", "corps")
        if not blocs:
            raise CorpsInvalide("« blocs » est attendu : une liste d'au moins un bloc.")
        construction = _Construction()
        with transaction.atomic():
            arbre = [construction.bloc(ligne, b, f"blocs[{n}]") for n, b in enumerate(blocs)]
        return _reponse_de_construction(construction, "blocs", arbre, ligne_id=ligne.id)
