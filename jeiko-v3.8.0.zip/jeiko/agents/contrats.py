# jeiko/agents/contrats.py
"""
Le contrat de chaque route de l'API des agents : ce qu'elle fait, et la forme
exacte de ce qu'elle attend.

Pourquoi
--------
Le serveur MCP exposait quatre-vingts outils dont la plupart ne disaient rien
d'autre que leur route — « (POST /api/agent/v1/pages/creer/) » —, avec un
corps décrit comme « objet JSON : voir le guide ». Une IA choisit ses outils
sur leur description et remplit leurs arguments d'après leur schéma : sans
l'un ni l'autre, elle devait lire un guide de plusieurs milliers de lignes
avant chaque geste, ou deviner — donc se tromper de champ.

Ici, chaque couple (route, méthode) porte :
  * une description : ce que fait l'appel, ce qu'il faut savoir avant ;
  * le schéma JSON de son corps (POST, PUT, PATCH) ou de ses filtres (GET),
    chaque champ décrit.

Le serveur MCP en fait ses outils ; le guide de l'API les publie sous
« contrats », pour qui appelle l'API directement.

La règle qui rend ces contrats fiables
--------------------------------------
Même règle que le guide : **tout ce qui peut être lu dans le code l'est.** Les
clés acceptées viennent des constantes des vues (`CHAMPS_VIDEO`,
`CHAMPS_BOUTON`, `parametres.SATELLITES`…), les types, les choix possibles et
les libellés viennent des champs des MODÈLES. Seules les phrases qui
expliquent une intention sont écrites à la main.

`tests/test_contrats_mcp.py` refuse une route sans contrat, un corps sans
schéma, et un champ sans description.
"""

from django.db import models

#: Les quatre appareils, décrits une fois.
APPAREILS_DECRITS = {
    "phone": "téléphone",
    "tablet": "tablette",
    "laptop": "ordinateur portable",
    "computer": "grand écran",
}


# --------------------------------------------------------------------------- #
#  Schémas lus sur les modèles
# --------------------------------------------------------------------------- #
def _libelle(champ):
    texte = str(champ.verbose_name or champ.name)
    texte = texte[:1].upper() + texte[1:]
    aide = str(champ.help_text or "").strip()
    return f"{texte}. {aide}" if aide else f"{texte}."


def schema_du_champ(modele, nom, description=None):
    """Le schéma JSON d'un champ de modèle : type, choix, longueur, libellé."""
    champ = modele._meta.get_field(nom)
    schema = {}
    if isinstance(champ, models.BooleanField):
        schema["type"] = "boolean"
    elif isinstance(champ, (models.IntegerField, models.AutoField)):
        schema["type"] = "integer"
    elif isinstance(champ, (models.DecimalField, models.FloatField)):
        schema["type"] = "number"
    elif isinstance(champ, models.DateTimeField):
        schema.update(type="string", format="date-time")
    elif isinstance(champ, models.DateField):
        schema.update(type="string", format="date")
    elif isinstance(champ, models.TimeField):
        schema.update(type="string", format="time")
    elif isinstance(champ, models.JSONField):
        pass  # objet ou liste : la description dit lequel
    elif isinstance(champ, models.ForeignKey):
        schema["type"] = ["integer", "null"]
    else:
        schema["type"] = "string"
        if getattr(champ, "max_length", None):
            schema["maxLength"] = champ.max_length

    if champ.choices:
        schema["enum"] = [valeur for valeur, _ in champ.flatchoices]
        parlants = [(v, l) for v, l in champ.flatchoices if str(v) != str(l)]
        libelles = "; ".join(f"{v} = {l}" for v, l in parlants)
        schema["description"] = (description or _libelle(champ)) + (
            f" Valeurs : {libelles}." if parlants else ""
        )
    else:
        schema["description"] = description or _libelle(champ)
    if champ.null and "type" in schema and isinstance(schema["type"], str):
        schema["type"] = [schema["type"], "null"]
    return schema


def objet_depuis_modele(modele, correspondances, description, precisions=None):
    """Un objet dont chaque clé d'API correspond à un champ du modèle."""
    precisions = precisions or {}
    return {
        "type": "object",
        "description": description,
        "properties": {
            cle: precisions.get(cle) or schema_du_champ(modele, champ)
            for cle, champ in correspondances.items()
        },
        "additionalProperties": False,
    }


def _texte(description, **extra):
    return {"type": "string", "description": description, **extra}


def _entier(description, **extra):
    return {"type": "integer", "description": description, **extra}


def _booleen(description):
    return {"type": "boolean", "description": description}


# --------------------------------------------------------------------------- #
#  Pages : le document de paramètres (sections, lignes, blocs)
# --------------------------------------------------------------------------- #
def _par_appareil(description, valeur):
    return {
        "type": "object",
        "description": description + " Un objet par appareil ; les appareils absents restent inchangés.",
        "properties": {
            appareil: {**valeur, "description": f"{valeur['description']} — {nom}."}
            for appareil, nom in APPAREILS_DECRITS.items()
        },
        "additionalProperties": False,
    }


def _boite(quoi):
    from . import parametres

    return {
        "type": "object",
        "description": f"{quoi} (valeurs CSS : « 20px », « 2rem », « auto », « 0 »).",
        "properties": {
            cote: _texte(f"Côté {cote}.", maxLength=50) for cote in parametres.COTES
        },
        "additionalProperties": False,
    }


def schema_des_parametres(modele_element):
    """Le document de paramètres d'une section, d'une ligne ou d'un bloc."""
    from jeiko.administration_pages.models import BackgroundImageParameters

    from . import parametres

    proprietes = {
        "fond": {
            "type": "object",
            "description": "Le fond de l'élément : couleur, image, réglages de l'image.",
            "properties": {
                "couleur": _texte("Couleur CSS du fond, par exemple « rgba(24,28,38,1) » ou « #f5f5f4 ».", maxLength=30),
                "image_id": {
                    "type": ["integer", "null"],
                    "description": "Identifiant d'une image DÉJÀ dans la médiathèque (outil lister_images ou creer_image) ; null détache l'image.",
                },
                "image": {
                    "type": ["object", "null"],
                    "description": "Forme de LECTURE de l'image ({id, url, alt, reglages}) : seul « id » est pris en compte. Préférer « image_id ».",
                },
                "cle_image_dynamique": _texte(
                    "Sur une page modèle de fiche : code d'un champ IMAGE de la fiche, dont l'image servira de fond.",
                    maxLength=100,
                ),
                "reglages_image": {
                    **objet_depuis_modele(
                        BackgroundImageParameters,
                        {c: c for c in parametres.CHAMPS_IMAGE_DE_FOND},
                        "Cadrage et rendu de l'image de fond ; null les détache.",
                    ),
                    "type": ["object", "null"],
                },
            },
            "additionalProperties": False,
        },
        "marges": _par_appareil("Marges extérieures.", _boite("Marges")),
        "paddings": _par_appareil("Marges intérieures (padding).", _boite("Paddings")),
        "tailles": _par_appareil("Largeur et hauteur.", {
            "type": "object",
            "description": "Taille (valeurs CSS ; « » pour laisser la valeur par défaut)",
            "properties": {
                "largeur": _texte("Largeur CSS : « 1140px », « 100% », « 92% ».", maxLength=50),
                "hauteur": _texte(
                    "Hauteur CSS. Attention : « 100% » prend la hauteur de la LIGNE, "
                    "donc du plus grand bloc voisin — à réserver aux cartes de même nature.",
                    maxLength=50,
                ),
            },
            "additionalProperties": False,
        }),
    }
    for cle, (modele, champs) in parametres.SATELLITES.items():
        quoi = {"animation": "Animation d'apparition", "bordure": "Bordure",
                "css": ("CSS propre à l'élément — DERNIER RECOURS, presque jamais "
                        "nécessaire : fond, bordure, marges, paddings, tailles et "
                        "animation ont leur réglage ci-contre, la couleur et la "
                        "taille d'un texte s'écrivent dans le texte, les polices "
                        "dans l'identité du site. « object_classes » (des classes) "
                        "est sans risque ; @import et url() distantes sont refusés")}[cle]
        proprietes[cle] = objet_depuis_modele(
            modele, {c: c for c in champs}, f"{quoi}. Seuls les champs envoyés changent.",
        )
    for champ in parametres.CHAMPS_PROPRES.get(modele_element, ()):
        proprietes[champ] = schema_du_champ(modele_element, champ)

    if "horizontal_align" in proprietes:
        # Le libellé du modèle (« Alignement horizontal ») ne dit pas CE qu'on
        # aligne, ni que c'est ici qu'un bouton se cale à gauche : un agent
        # cherchait ce réglage sur le bouton, ne le trouvait pas, et écrivait
        # du CSS — ou concluait qu'il n'existait pas.
        proprietes["horizontal_align"]["description"] = (
            "Où se place le CONTENU dans le bloc, horizontalement. C'est le réglage "
            "qui cale un BOUTON à gauche (« left ») ou à droite (« right ») — sans "
            "lui, un bouton est centré — et qui aligne tout un texte d'un coup. "
            + proprietes["horizontal_align"]["description"]
        )
        proprietes["vertical_align"]["description"] = (
            "Où se place le contenu dans le bloc, verticalement. Ne se voit que si "
            "le bloc est plus haut que son contenu : pour centrer un texte à côté "
            "d'une image, donner au bloc la hauteur de sa ligne "
            "(tailles.<appareil>.hauteur = « 100% ») et « middle » ici. "
            + proprietes["vertical_align"]["description"]
        )

    if "columns_type" in proprietes:
        for cle in ("columns_type", "columns_type_tablet", "columns_type_phone"):
            proprietes[cle]["description"] += (
                " Autant de segments que la ligne a de colonnes : sur une ligne à "
                "3 colonnes, « 4-4-4 » les met côte à côte, « 12-12-12 » les empile."
            )
    return {
        "type": "object",
        "description": "Document de paramètres : seules les clés envoyées changent, une clé inconnue est refusée.",
        "properties": proprietes,
        "additionalProperties": False,
    }


# --------------------------------------------------------------------------- #
#  Pages : le contenu d'un bloc
# --------------------------------------------------------------------------- #
def schema_du_contenu():
    """PUT blocs/<id>/contenu/ : le type, et le document propre à ce type."""
    from jeiko.administration_pages.models import (
        DYNAMIC_DEFAULTS, ContentButton, ContentFormField, ContentFormulaire,
        ContentVideo,
    )

    from . import contenus_dynamiques as dyn
    from .guide import ROLE_DES_BLOCS
    from .vues_pages import (
        CHAMPS_BOUTON, CHAMPS_FORMULAIRE, CHAMPS_VIDEO, CIBLES_DU_BOUTON,
        CONTENUS_SIMPLES, STYLE_BOUTON, STYLE_FORMULAIRE, TYPES_DE_CHAMP,
        TYPES_OUVERTS, _modele_simple,
    )

    roles = "; ".join(
        f"{t} : {ROLE_DES_BLOCS.get(t, '').split('.')[0]}" for t in TYPES_OUVERTS
    )
    proprietes = {
        "type": {
            "type": "string",
            "enum": list(TYPES_OUVERTS),
            "description": f"Nature du bloc. Remplace la précédente. {roles}.",
        },
        "texte": _texte(
            "Pour TEXT : HTML du texte. Balises de mise en forme usuelles "
            "(h1-h6, p, strong, em, ul, ol, li, a, br, span) ; couleur et "
            "alignement en style en ligne (color, background-color, text-align…). "
            "Ce qui ne survivrait pas à l'éditeur est refusé ; ce qui est retiré "
            "par l'assainissement est listé dans « avertissements »."
        ),
        "image_id": _entier(
            "Pour IMAGE : identifiant d'une image de la médiathèque (lister_images, creer_image). "
            "Elle occupe la hauteur de sa LIGNE (celle des colonnes voisines) ; empilée avec "
            "d'autres blocs dans la même colonne, lui donner une hauteur (modifier_bloc, "
            "tailles.<appareil>.hauteur, par exemple « 320px »).",
            minimum=1,
        ),
        "bouton": {
            **objet_depuis_modele(
                ContentButton, CHAMPS_BOUTON,
                "Pour BUTTON : libellé et destination. Un bouton n'a pas d'« url » : "
                "« page_id » pour une page du site, « url_externe » sinon, "
                "« questionnaire » pour lancer un questionnaire.",
            ),
        },
        "formulaire": {
            "type": "object",
            "description": "Pour FORM : réglages, apparence et champs du formulaire de contact.",
            "properties": {
                **{
                    cle: schema_du_champ(ContentFormulaire, champ)
                    for cle, champ in CHAMPS_FORMULAIRE.items()
                },
                "style": {
                    "type": "object",
                    "description": "Apparence. Couleurs HEXADÉCIMALES uniquement (#rrggbb).",
                    "properties": {
                        cle: (_entier(f"{cle.replace('_', ' ').capitalize()} en pixels.")
                              if champ.endswith("_px")
                              else _texte(f"{cle.replace('_', ' ').capitalize()}, en #rrggbb.",
                                          pattern="^#[0-9a-fA-F]{6}$"))
                        for cle, champ in STYLE_FORMULAIRE.items()
                    },
                    "additionalProperties": False,
                },
                "champs": {
                    "type": "array",
                    "description": "Les champs du formulaire, dans l'ordre. Envoyer la liste la REMPLACE en entier.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "nom": _texte("Clé du champ dans le message reçu (obligatoire), par exemple « email ».", maxLength=100),
                            "libelle": _texte("Libellé affiché au visiteur.", maxLength=200),
                            "type": {"type": "string", "enum": list(TYPES_DE_CHAMP),
                                     "description": "Nature du champ."},
                            "obligatoire": _booleen("Le visiteur doit-il le remplir ?"),
                            "indication": _texte("Texte d'exemple dans le champ (placeholder).", maxLength=200),
                            "options": {"type": "array", "items": {"type": "string"},
                                        "description": "Choix proposés, pour le type « select »."},
                        },
                        "required": ["nom"],
                        "additionalProperties": False,
                    },
                },
            },
            "additionalProperties": False,
        },
        "video": objet_depuis_modele(
            ContentVideo, CHAMPS_VIDEO,
            "Pour VIDEO : une vidéo externe (YouTube, Vimeo…) par son URL, et sa lecture.",
        ),
        "options": {
            "type": "object",
            "description": "Pour les blocs dynamiques (DYN_…) : leurs options. Défauts par type : "
            + "; ".join(
                f"{t} {{" + ", ".join(
                    f"{k}: {v!r}" for k, v in DYNAMIC_DEFAULTS.get(t, {}).items()
                    if not isinstance(v, list)
                ) + "}"
                for t in sorted(DYNAMIC_DEFAULTS) if t in TYPES_OUVERTS
            ) + ".",
        },
        "elements": {
            "type": "array",
            "description": "Pour les blocs dynamiques à éléments : la liste, qui REMPLACE l'existante. "
            "Clés par type : " + "; ".join(
                f"{t} ({', '.join(sorted(c))})" for t, (_, _, c) in sorted(dyn.TYPES.items())
            ) + ". Les clés en « _id » désignent une image de la médiathèque.",
            "items": {"type": "object"},
        },
    }
    # Style du bouton, lu sur le modèle.
    proprietes["bouton"]["properties"]["page_id"] = {
        "type": ["integer", "null"],
        "description": "Page du site vers laquelle mène le bouton (identifiant, voir lister_pages) ; null la retire.",
    }
    for cle, (_, _, _, attribut) in CIBLES_DU_BOUTON.items():
        proprietes["bouton"]["properties"][cle] = {
            "type": ["string", "null"],
            "description": (
                "Produit ajouté au panier, par sa référence (sku) — indispensable hors page modèle."
                if cle == "produit_cible" else
                "Fiche vers laquelle mène le bouton, par son slug."
            ),
        }
    proprietes["bouton"]["properties"]["style"] = objet_depuis_modele(
        ContentButton, STYLE_BOUTON, "Apparence du bouton (valeurs CSS).",
    )
    # Contenus « simples » : un document nommé d'après le type.
    for type_, (_, nom_modele, correspondances) in CONTENUS_SIMPLES.items():
        if type_ not in TYPES_OUVERTS:
            continue
        proprietes[type_.lower()] = objet_depuis_modele(
            _modele_simple(nom_modele), correspondances,
            f"Pour {type_} : {ROLE_DES_BLOCS.get(type_, '').split('.')[0]}.",
        )
    return {
        "type": "object",
        "description": "Le contenu du bloc : « type », plus le document propre à ce type.",
        "properties": proprietes,
        "required": ["type"],
        "additionalProperties": False,
    }


# --------------------------------------------------------------------------- #
#  Pages : routes
# --------------------------------------------------------------------------- #
def _contrats_des_pages():
    from jeiko.administration_pages import fabrique
    from jeiko.administration_pages.models import Bloc, Line, Page, Section

    from .vues_pages import CHAMPS_PAGE_MODIFIABLES

    metadonnees = {
        "type": "object",
        "description": "Ce qu'affichent les moteurs de recherche.",
        "properties": {
            "titre": _texte("Titre dans les résultats de recherche (≈ 60 caractères).", maxLength=200),
            "description": _texte("Description dans les résultats de recherche (≈ 155 caractères)."),
        },
        "additionalProperties": False,
    }
    categorie = _texte("Catégorie de la page, par son slug (voir lister_categories) ; null pour la retirer.")
    categorie["type"] = ["string", "null"]
    sous_categorie = dict(categorie, description="Sous-catégorie, par son slug ; elle doit appartenir à la catégorie.")

    gabarits = ", ".join(
        f"{nom} ({', '.join(f'{a} {l}' for a, l in g['tailles'].items())})"
        for nom, g in fabrique.GABARITS_SECTION.items()
    )
    precisions_page = {
        "titre": _texte("Titre de la page (dans l'onglet et en haut de page).", maxLength=200),
        "url_tag": _texte("Fin de l'adresse de la page, en minuscules et tirets, par exemple « nos-tarifs ».", maxLength=200),
        "publiee": _booleen("Mettre en ligne (true) ou repasser en brouillon (false)."),
        "racine": _booleen("En faire la page d'accueil du site — la précédente cesse de l'être."),
    }
    modifiables = {
        cle: precisions_page.get(cle) or schema_du_champ(Page, champ)
        for cle, champ in CHAMPS_PAGE_MODIFIABLES.items()
    }

    # L'arbre qu'on construit d'un coup : les mêmes schémas que les routes
    # unitaires, emboîtés. Un réglage valide en PATCH l'est ici, et inversement.
    bloc_complet = {
        "type": "object",
        "description": "Un bloc : sa colonne, son contenu (même document que ecrire_bloc_contenu) et ses réglages (même document que modifier_bloc).",
        "properties": {
            "colonne": _entier("Colonne du bloc, à partir de 0 (0 par défaut). Deux blocs de la même colonne s'empilent.", minimum=0),
            "contenu": schema_du_contenu(),
            "parametres": schema_des_parametres(Bloc),
        },
        "additionalProperties": False,
    }
    ligne_complete = {
        "type": "object",
        "description": "Une ligne : son nombre de colonnes, ses réglages (même document que modifier_ligne, répartitions comprises) et ses blocs.",
        "properties": {
            "colonnes": _entier("Nombre de colonnes (1 par défaut).", minimum=1, maximum=12),
            "parametres": schema_des_parametres(Line),
            "blocs": {"type": "array", "items": bloc_complet,
                      "description": "Les blocs de la ligne, dans l'ordre ; chacun s'empile en bas de sa colonne."},
        },
        "additionalProperties": False,
    }
    section_complete = {
        "type": "object",
        "description": "Une section : son gabarit, ses réglages (même document que modifier_section) et ses lignes.",
        "properties": {
            "gabarit": {"type": "string", "enum": list(fabrique.GABARITS_SECTION),
                        "description": f"Largeurs de la section par appareil : {gabarits}. Défaut : CLASSIC."},
            "parametres": schema_des_parametres(Section),
            "lignes": {"type": "array", "items": ligne_complete,
                       "description": "Les lignes de la section, de haut en bas."},
        },
        "additionalProperties": False,
    }
    tout_ou_rien = (" TOUT OU RIEN : la moindre erreur ne laisse rien en base, et le message "
                    "désigne l'élément fautif par son chemin (sections[1].lignes[0].blocs[2].contenu). "
                    "La réponse ne rend que les identifiants ; relire avec lire_page si besoin.")

    from jeiko.administration_pages.models import PageInsights

    return {
        ("images", "GET"): {
            "description": "La MÉDIATHÈQUE du site : chaque image avec son identifiant, son titre, son texte alternatif et ses URL. C'est là qu'on choisit l'image d'un bloc IMAGE (image_id), d'un fond (fond.image_id) ou d'un carrousel. 100 par appel, de la plus récente à la plus ancienne.",
            "parametres": {
                "type": "object",
                "properties": {"apres": {"type": "integer", "description": "Pour la page suivante : la valeur « suite » de la réponse précédente."}},
                "additionalProperties": False,
            },
        },
        ("image_creer", "POST"): {
            "description": "Envoie une image dans la médiathèque et renvoie son identifiant. Le fichier voyage en base64 dans « fichier_base64 » (JPEG, PNG, WebP…, 10 Mo max) ; les variantes pour chaque écran sont fabriquées automatiquement. Chaque image est DÉCRITE (alt) ou déclarée décorative.",
            "corps": {
                "type": "object",
                "properties": {
                    "fichier_base64": _texte("Contenu du fichier encodé en base64 (une « data URL » est acceptée)."),
                    "nom_du_fichier": _texte("Nom du fichier, avec son extension : « atelier.jpg ».", maxLength=100),
                    "titre": _texte("Titre dans la médiathèque."),
                    "alt": _texte("Texte alternatif : ce que montre l'image, pour qui ne la voit pas. Obligatoire sauf image décorative."),
                    "decorative": _booleen("true si l'image n'apporte aucune information (ornement) : elle sera ignorée des lecteurs d'écran."),
                },
                "required": ["fichier_base64"],
                "additionalProperties": False,
            },
        },
        ("categories", "GET"): {"description": "Les catégories et sous-catégories des pages, avec leur slug (c'est lui qu'on donne à « categorie ») et leur place dans les adresses."},
        ("categorie_creer", "POST"): {
            "description": "Crée une catégorie de pages, éventuellement sous une autre. Le slug ne pourra plus changer : il entre dans les adresses.",
            "corps": {
                "type": "object",
                "properties": {
                    "nom": _texte("Nom affiché.", maxLength=150),
                    "slug": _texte("Identifiant dans les adresses ; déduit du nom si absent."),
                    "categorie_parente": _texte("Slug de la catégorie parente, pour une sous-catégorie."),
                    "afficher_dans_l_url": _booleen("La catégorie apparaît dans l'adresse de ses pages (/formations/tarifs/) — true par défaut."),
                },
                "required": ["nom"],
                "additionalProperties": False,
            },
        },
        ("categorie", "GET"): {"description": "Une catégorie : nom, slug, parente, présence dans les adresses."},
        ("categorie", "PATCH"): {
            "description": "Corrige une catégorie. Le slug ne change pas. Retirer une catégorie des adresses change l'adresse de toutes ses pages.",
            "corps": {
                "type": "object",
                "properties": {
                    "nom": _texte("Nouveau nom.", maxLength=150),
                    "categorie_parente": {"type": ["string", "null"], "description": "Slug de la nouvelle parente ; null pour en faire une catégorie principale."},
                    "traductions": {"type": "object", "additionalProperties": {"type": "object"},
                                    "description": "Site en plusieurs langues : le nom et le slug de la catégorie par langue — {\"en\": {\"nom\": \"Services\", \"slug\": \"our-services\"}}. Une langue envoyée remplace la sienne ; {} la retire ; une langue non traduite garde le nom et le slug d'origine."},
                    "afficher_dans_l_url": _booleen("Présence dans l'adresse des pages."),
                },
                "additionalProperties": False,
            },
        },
        ("categorie", "DELETE"): {"description": "Supprime une catégorie VIDE (sans page ni sous-catégorie) ; sinon refus, en disant quoi reclasser d'abord."},
        ("pages", "GET"): {
            "description": "Liste les pages du site : identifiant, titre, adresse, publication, catégorie — et, sur un site en plusieurs langues, la langue de chacune et ses autres versions. Une page marquée gabarit_de_mail, pdf ou gabarit_de_fiche n'est PAS servie par le site public : ne pas y mener un lien.",
            "parametres": {
                "type": "object",
                "properties": {"langue": _texte("Ne lister que les pages de cette langue (« en »). Le code de la langue d'origine donne les pages d'origine.")},
                "additionalProperties": False,
            },
        },
        ("page_versions", "POST"): {
            "description": "Site en plusieurs langues : crée la version d'une page dans une langue, en DUPLIQUANT la page d'origine (sections, images, mise en page). Elle naît en brouillon, avec le titre et l'adresse de l'originale : traduire ensuite titre, url_tag et metadonnees (modifier_page), puis le contenu de ses blocs, puis publier. 409 si la version existe ou si la langue n'est pas activée (voir lister_langues).",
            "corps": {
                "type": "object",
                "properties": {"langue": _texte("Code de la langue, parmi celles du site : « en ».")},
                "required": ["langue"],
                "additionalProperties": False,
            },
        },
        ("langues", "GET"): {"description": "Site en plusieurs langues : l'option est-elle activée, quelle est la langue d'origine (sans préfixe d'adresse), quelles langues sont ajoutées (/en/, /es/…) et lesquelles peuvent l'être."},
        ("langues", "PATCH"): {
            "description": "Active ou désactive le site en plusieurs langues et choisit les langues ajoutées. Demande le droit sur les réglages du site. RETIRER une langue DÉPUBLIE ses pages et ses fiches (sans les supprimer) : la réponse en donne le nombre, et les réactiver ne les republie pas.",
            "corps": {
                "type": "object",
                "properties": {
                    "multilingue": _booleen("Activer (true) ou désactiver (false) l'option."),
                    "langues": {"type": "array", "items": {"type": "string"},
                                "description": "Les codes des langues ajoutées, parmi langues_proposees : [\"en\"]. La langue d'origine n'y figure pas."},
                },
                "additionalProperties": False,
            },
        },
        ("page_creer", "POST"): {
            "description": "Crée une page, toujours en BROUILLON (publiee=false). Ses sections complètes peuvent être posées dans le même appel (« sections »), ou ensuite par construire_page. 409 si l'adresse est déjà prise.",
            "corps": {
                "type": "object",
                "properties": {
                    "titre": precisions_page["titre"],
                    "url_tag": dict(precisions_page["url_tag"], description=precisions_page["url_tag"]["description"] + " Déduite du titre si absente."),
                    "categorie": categorie,
                    "sous_categorie": sous_categorie,
                    "metadonnees": metadonnees,
                    "sections": {"type": "array", "items": section_complete,
                                 "description": "Facultatif : les sections complètes de la page, posées dès sa création (droit de modifier les pages requis)." + tout_ou_rien},
                },
                "required": ["titre"],
                "additionalProperties": False,
            },
        },
        ("page", "GET"): {"description": "L'arbre complet d'une page : ses sections, leurs lignes, leurs blocs et leur contenu, avec tous les identifiants."},
        ("page", "PATCH"): {
            "description": "Modifie les champs d'une page ; seuls les champs envoyés changent. Publier : {\"publiee\": true}.",
            "corps": {
                "type": "object",
                "properties": {**modifiables, "categorie": categorie,
                               "sous_categorie": sous_categorie, "metadonnees": metadonnees},
                "additionalProperties": False,
            },
        },
        ("page_sections", "POST"): {
            "description": "Ajoute une section à la FIN de la page (deplacer pour la remonter). Une section contient des lignes.",
            "corps": {
                "type": "object",
                "properties": {"gabarit": {
                    "type": "string", "enum": list(fabrique.GABARITS_SECTION),
                    "description": f"Largeurs de la section par appareil : {gabarits}. Défaut : CLASSIC.",
                }},
                "additionalProperties": False,
            },
        },
        ("page_construire", "POST"): {
            "description": "Ajoute à la FIN de la page des sections complètes — lignes, blocs, contenus et réglages — en un seul appel." + tout_ou_rien,
            "corps": {
                "type": "object",
                "properties": {"sections": {"type": "array", "items": section_complete, "minItems": 1,
                                            "description": "Les sections à ajouter, de haut en bas."}},
                "required": ["sections"],
                "additionalProperties": False,
            },
        },
        ("section_construire", "POST"): {
            "description": "Ajoute à la FIN de la section des lignes complètes — blocs, contenus et réglages — en un seul appel." + tout_ou_rien,
            "corps": {
                "type": "object",
                "properties": {"lignes": {"type": "array", "items": ligne_complete, "minItems": 1,
                                          "description": "Les lignes à ajouter, de haut en bas."}},
                "required": ["lignes"],
                "additionalProperties": False,
            },
        },
        ("ligne_construire", "POST"): {
            "description": "Ajoute à la ligne des blocs remplis et réglés, en un seul appel ; chacun s'empile en bas de sa colonne." + tout_ou_rien,
            "corps": {
                "type": "object",
                "properties": {"blocs": {"type": "array", "items": bloc_complet, "minItems": 1,
                                         "description": "Les blocs à ajouter, dans l'ordre."}},
                "required": ["blocs"],
                "additionalProperties": False,
            },
        },
        ("page_mesures", "GET"): {
            "description": "Ce que Google mesure sur la page : scores PageSpeed, Core Web Vitals, audits ratés. Lecture seule.",
            "parametres": {
                "type": "object",
                "properties": {"appareil": {**schema_du_champ(PageInsights, "strategy"),
                                            "description": "Mesure mobile ou ordinateur ; la plus récente si absent."}},
                "additionalProperties": False,
            },
        },
        ("section", "GET"): {"description": "Une section, ses paramètres et ses lignes."},
        ("section", "PATCH"): {"description": "Modifie les paramètres d'une section : fond, marges, paddings, tailles, animation, bordure. Le CSS n'y est qu'un dernier recours.",
                               "corps": schema_des_parametres(Section)},
        ("section", "DELETE"): {"description": "Supprime une section ET tout ce qu'elle contient. Irréversible."},
        ("section_lignes", "POST"): {
            "description": "Ajoute une ligne à la fin de la section, avec sa répartition en colonnes (ordinateur côte à côte, téléphone empilé).",
            "corps": {
                "type": "object",
                "properties": {"colonnes": _entier(
                    "Nombre de colonnes de la ligne (1 par défaut). Répartitions réglables ensuite par modifier_ligne.",
                    minimum=1, maximum=12)},
                "additionalProperties": False,
            },
        },
        ("ligne", "GET"): {"description": "Une ligne, ses paramètres et ses blocs par colonne."},
        ("ligne", "PATCH"): {"description": "Modifie une ligne : nombre de colonnes, répartition par appareil, fond, marges, animation… Le CSS n'y est qu'un dernier recours.",
                             "corps": schema_des_parametres(Line)},
        ("ligne", "DELETE"): {"description": "Supprime une ligne ET ses blocs. Irréversible."},
        ("ligne_blocs", "POST"): {
            "description": "Ajoute un bloc VIDE dans une colonne de la ligne ; le remplir ensuite avec ecrire_bloc_contenu.",
            "corps": {
                "type": "object",
                "properties": {
                    "colonne": _entier("Colonne visée, à partir de 0 (0 par défaut).", minimum=0),
                    "rang": _entier("Position verticale dans la colonne, à partir de 0 ; en bas par défaut.", minimum=0),
                },
                "additionalProperties": False,
            },
        },
        ("bloc", "GET"): {"description": "Un bloc : paramètres, type et contenu."},
        ("bloc", "PATCH"): {"description": "Modifie les paramètres d'un bloc : fond, marges, paddings, tailles, bordure, animation, et l'alignement de son contenu (horizontal_align : un bouton à gauche ou à droite ; vertical_align). Le CONTENU se change par ecrire_bloc_contenu. Le CSS n'y est qu'un dernier recours.",
                            "corps": schema_des_parametres(Bloc)},
        ("bloc", "DELETE"): {"description": "Supprime un bloc et son contenu. Irréversible."},
        ("bloc_contenu", "PUT"): {
            "description": "Pose ou remplace le contenu d'un bloc : « type » puis le document de ce type (texte, image_id, bouton, formulaire, video, options/elements…).",
            "corps": schema_du_contenu(),
        },
        ("deplacer", "POST"): {
            "description": "Deux gestes. 1) « sens » : monte ou descend une section (dans sa page), une ligne (dans sa section) ou un bloc (dans sa colonne), en l'échangeant avec son voisin. 2) Une destination : une LIGNE vers une autre section de la page (« vers_section »), un BLOC vers une autre ligne ou colonne de la page (« vers_ligne », « colonne ») ; le contenu suit, la colonne quittée n'est jamais laissée vide.",
            "corps": {
                "type": "object",
                "properties": {
                    "sens": {"type": "string", "enum": ["haut", "bas"], "description": "Vers le haut ou vers le bas, sans changer de conteneur."},
                    "vers_section": _entier("Niveau « ligne » : identifiant de la section d'arrivée (même page)."),
                    "vers_ligne": _entier("Niveau « bloc » : identifiant de la ligne d'arrivée (même page, ou la même ligne pour changer de colonne)."),
                    "colonne": _entier("Avec « vers_ligne » : colonne d'arrivée, à partir de 0 (0 par défaut).", minimum=0),
                    "rang": _entier("Avec une destination : place à l'arrivée, à partir de 0 ; en bas par défaut.", minimum=0),
                },
                "additionalProperties": False,
            },
            "variables": {"niveau": {"type": "string", "enum": ["section", "ligne", "bloc"],
                                     "description": "Ce qu'on déplace."}},
        },
    }


# --------------------------------------------------------------------------- #
#  Rendez-vous
# --------------------------------------------------------------------------- #
def _contrats_du_calendrier():
    from jeiko.calendars.models import AppointmentType

    instant = lambda d: _texte(d + " Date-heure ISO avec fuseau : « 2026-10-15T09:00:00+02:00 ».", format="date-time")
    type_rdv = {
        "nom": _texte("Nom du type, affiché au visiteur : « Consultation découverte ».", maxLength=200),
        "duree_minutes": _entier("Durée d'un rendez-vous en minutes ; c'est elle qui découpe les disponibilités en créneaux.", minimum=1),
        "description": _texte("Présentation affichée au visiteur."),
        "payant": _booleen("Le visiteur paie en ligne à la réservation."),
        "prix": {**schema_du_champ(AppointmentType, "price"), "type": ["number", "string"]},
        "inscription_requise": _booleen("Réservation réservée aux visiteurs connectés."),
        "capacite": {**schema_du_champ(AppointmentType, "capacity"), "minimum": 1},
        "places_max_par_reservation": {**schema_du_champ(AppointmentType, "max_places_per_booking"), "minimum": 1},
        "liste_d_attente": _booleen("Un créneau complet propose de s'inscrire en liste d'attente."),
        "couleur": _texte("Couleur du type dans l'agenda (CSS).", maxLength=50),
    }
    dispo = {
        "debut": instant("Début de la plage (de la première occurrence si elle se répète)."),
        "fin": instant("Fin de la plage — après « debut »."),
        "types": {"type": "array", "items": {"type": "integer"},
                  "description": "Identifiants des types de rendez-vous proposés sur cette plage (lister_rdv_types)."},
        "regle_de_recurrence": _texte(
            "Répétition au format iCal RRULE, vide pour une plage unique : "
            "« FREQ=WEEKLY;BYDAY=TH » (tous les jeudis), « FREQ=WEEKLY;BYDAY=MO,WE;UNTIL=20261231T235959Z »."),
        "dates_exclues": {"type": "array", "items": {"type": "string", "format": "date"},
                          "description": "Jours sans créneau malgré la répétition (congés, fériés), au format AAAA-MM-JJ."},
        "ouverte": _booleen("Plage ouverte à la réservation (true par défaut)."),
    }
    periode = {
        "type": {"type": "integer", "description": "Filtrer sur un type de rendez-vous (identifiant)."},
        "depuis": _texte("À partir de cette date-heure ISO.", format="date-time"),
        "jusqu_a": _texte("Jusqu'à cette date-heure ISO.", format="date-time"),
    }
    objet = lambda proprietes, requis=(): {"type": "object", "properties": proprietes,
                                           "required": list(requis), "additionalProperties": False}
    return {
        ("rdv_types", "GET"): {"description": "Les types de rendez-vous : nom, durée, capacité, prix, liste d'attente. Un type se propose sur des disponibilités."},
        ("rdv_type_creer", "POST"): {"description": "Crée un type de rendez-vous. Ensuite : creer_rdv_disponibilite pour ouvrir des créneaux, puis un bloc CALENDAR sur une page pour la prise de rendez-vous.",
                                     "corps": objet(type_rdv, ("nom", "duree_minutes"))},
        ("rdv_type", "GET"): {"description": "Un type de rendez-vous et tous ses réglages."},
        ("rdv_type", "PATCH"): {"description": "Modifie un type de rendez-vous ; seuls les champs envoyés changent.",
                                "corps": objet(type_rdv)},
        ("rdv_disponibilites", "GET"): {"description": "Les plages déclarées disponibles, avec leur récurrence et leur nombre de créneaux."},
        ("rdv_disponibilite_creer", "POST"): {"description": "Déclare une plage disponible — « tous les jeudis de 9 h à 12 h » — et GÉNÈRE ses créneaux, découpés à la durée de chaque type.",
                                              "corps": objet(dispo, ("debut", "fin", "types"))},
        ("rdv_disponibilite", "GET"): {"description": "Une plage disponible et ses réglages."},
        ("rdv_disponibilite", "PATCH"): {"description": "Modifie une plage ; ses créneaux sont régénérés.",
                                         "corps": objet(dispo)},
        ("rdv_disponibilite", "DELETE"): {"description": "Supprime une plage et ses créneaux ; refusé si des rendez-vous y sont pris."},
        ("rdv_creneaux", "GET"): {"description": "Les créneaux générés par les disponibilités — LECTURE SEULE : on les pilote par leur disponibilité. 500 au plus.",
                                  "parametres": objet({**periode, "ouverts": {"type": "string", "enum": ["1"], "description": "« 1 » : seulement les créneaux encore réservables."}})},
        ("rdv", "GET"): {"description": "Les rendez-vous pris (client, e-mail, places, paiement). Lecture seule ; données personnelles, permission à part.",
                         "parametres": objet(periode)},
    }


# --------------------------------------------------------------------------- #
#  Questionnaires
# --------------------------------------------------------------------------- #
def _contrats_des_questionnaires():
    from jeiko.questionnaires_expert.models import ExpertProfileCriterion, ExpertQuestion

    objet = lambda proprietes, requis=(), description=None: {
        "type": "object", "properties": proprietes, "required": list(requis),
        "additionalProperties": False, **({"description": description} if description else {}),
    }
    page = lambda d: {"type": ["integer", "null"], "description": d + " Identifiant de page (lister_pages) ; null la retire."}
    profil = lambda d: {"type": ["string", "integer", "null"], "description": d + " Profil DE CE questionnaire, par son slug (ou son identifiant)."}
    questionnaire = {
        "titre": _texte("Titre du questionnaire.", maxLength=200),
        "description": _texte("Présentation affichée avant de commencer."),
        "actif": _booleen("Ouvert aux visiteurs. Un questionnaire naît INACTIF : l'activer une fois complet."),
        "acces_restreint": _booleen("Réservé aux personnes à qui l'accès a été donné."),
        "image_principale_id": {"type": ["integer", "null"], "description": "Image d'illustration, par son identifiant dans la médiathèque (lister_images)."},
        "page_de_presentation": page("Page qui présente le questionnaire."),
        # Réglages du résultat (mode « dimensions », 25/09/2026). Voir le guide,
        # « Les questionnaires : deux façons de rendre le résultat ».
        "mode_resultat": {"type": "string", "enum": ["profil", "dimensions"],
                          "description": "« profil » (par défaut) : un profil gagnant, une page de résultat. « dimensions » : chaque profil est une dimension notée sur l'échelle, avec son propre texte selon sa tranche (bas, milieu, haut) ; les plus marquées passent en tête."},
        "echelle_min": {"type": "number", "description": "Mode dimensions : bas de l'échelle des scores (1 par défaut)."},
        "echelle_max": {"type": "number", "description": "Mode dimensions : haut de l'échelle des scores (5 par défaut)."},
        "mention_precaution": _texte("Avertissement affiché avant la première question (« ce test n'est pas un diagnostic »)."),
        "texte_nuance": _texte("Mode dimensions : texte affiché quand aucune dimension ne se détache (profil nuancé)."),
        "texte_final": _texte("Mode dimensions : texte de conclusion, sous les dimensions."),
        "bouton_libelle": _texte("Libellé du bouton d'appel à l'action en bas du résultat.", maxLength=120),
        "bouton_page": page("Page visée par ce bouton."),
        "style": objet({
            "police": _texte("Pile de polices CSS : « Inter, sans-serif ». Lettres, chiffres, espaces, virgules, guillemets et tirets seulement.", maxLength=200),
            "couleur_titres": _texte("Couleur des titres, en #rrggbb.", maxLength=7),
            "couleur_theme": _texte("Couleur d'accent (boutons, barres des dimensions), en #rrggbb.", maxLength=7),
            "couleur_fond": _texte("Couleur de fond des pages du questionnaire, en #rrggbb.", maxLength=7),
            **{f"taille_titre_{a}": _entier(f"Taille du titre sur {a}, en pixels.") for a in ("mobile", "tablette", "ordinateur")},
            **{f"taille_reponses_{a}": _entier(f"Taille du texte des réponses sur {a}, en pixels.") for a in ("mobile", "tablette", "ordinateur")},
            "taille_bouton": _entier("Taille du texte du bouton d'envoi, en pixels."),
            "arrondi_reponses": _entier("Arrondi des cases de réponse, en pixels."),
            "arrondi_bouton": _entier("Arrondi du bouton d'envoi, en pixels."),
        }, description="« Gestion du style » : habille les pages de questions ET la page de résultat par dimensions. Modification partielle : seules les clés envoyées changent."),
    }
    tranche = objet({
        "de": {"type": "number", "description": "Borne basse incluse, dans l'échelle du questionnaire."},
        "a": {"type": "number", "description": "Borne haute incluse, dans l'échelle du questionnaire."},
        "titre": _texte("Titre affiché pour cette tranche : « Très structurant ».", maxLength=200),
        "texte": _texte("Texte de la tranche."),
        "forces": {"type": "array", "items": {"type": "string"}, "description": "Forces, une par élément."},
        "vigilance": _texte("Point de vigilance."),
        "piste": _texte("Piste de réflexion."),
    }, ("de", "a"), description="Une tranche du profil ; null la retire.")
    profil_champs = {
        "nom": _texte("Nom du profil, affiché comme résultat : « Bâtisseur ».", maxLength=200),
        "slug": _texte("Identifiant du profil dans l'adresse du résultat ; déduit du nom. Ne se modifie plus ensuite."),
        "description": _texte("Texte du résultat."),
        "page_de_resultat": page("Page affichée pour ce résultat."),
        "complexe": _booleen("Profil « majeur » : attribué par une combinaison (dont il est le profil_parent), pas par les points des réponses. Les profils simples (false) reçoivent les points et s'affichent dans le graphique des scores."),
        "attribue_par_score": _booleen("Profil attribué selon le score total, entre score_min et score_max."),
        "score_min": {"type": ["number", "null"], "description": "Score total minimal (profil par score)."},
        "score_max": {"type": ["number", "null"], "description": "Score total maximal (profil par score)."},
        "rang": _entier("Mode dimensions : ordre d'affichage des dimensions à égalité."),
        "couleur": _texte("Mode dimensions : couleur de la barre de ce profil, en #rgb ou #rrggbb.", maxLength=7),
        "pole_bas": _texte("Mode dimensions : libellé du bas de l'échelle (« Improvise »).", maxLength=100),
        "pole_haut": _texte("Mode dimensions : libellé du haut de l'échelle (« Planifie »).", maxLength=100),
        "tranches": objet({pos: {**tranche, "type": ["object", "null"]} for pos in ("bas", "milieu", "haut")},
                          description="Mode dimensions : le contenu selon le score. Une position absente n'est pas touchée ; les tranches ne se chevauchent pas."),
    }
    reponse = objet({
        "texte": _texte("Texte de la réponse.", maxLength=300),
        "rang": _entier("Ordre d'affichage ; sa place dans la liste par défaut."),
        "active": _booleen("Proposée au visiteur (true par défaut)."),
        "poids": {"type": "object", "additionalProperties": {"type": "number"},
                  "description": "Points apportés à chaque profil quand cette réponse est choisie : {\"slug-du-profil\": 3, …}."},
    }, ("texte",))
    question = {
        "texte": _texte("Énoncé de la question."),
        "rang": _entier("Ordre dans le questionnaire ; à la fin par défaut."),
        "type": {**schema_du_champ(ExpertQuestion, "question_type"), "description": "Choix unique ou multiple. Valeurs : single = Choix unique ; multiple = Choix multiple."},
        "active": _booleen("Posée au visiteur (true par défaut)."),
        "reponses": {"type": "array", "items": reponse,
                     "description": "Les réponses proposées, avec leurs poids. Envoyer la liste la REMPLACE en entier."},
    }
    critere = objet({
        "profil_a": profil("Premier profil comparé."),
        "profil_b": profil("Second profil comparé."),
        "comparaison": {"type": "string", "enum": [c for c, _ in ExpertProfileCriterion.COMPARISON_CHOICES],
                        "description": "Comparaison des scores de A et B : " + "; ".join(f"{c} {l.lower()}" for c, l in ExpertProfileCriterion.COMPARISON_CHOICES) + "."},
        "tolerance": _entier("Écart admis, obligatoire pour « ~= » (proche de)."),
    }, ("profil_a", "profil_b", "comparaison"))
    combinaison = {
        "titre": _texte("Nom de la combinaison.", maxLength=150),
        "slug": _texte("Identifiant ; déduit du titre."),
        "profil_parent": profil("Profil RÉSULTAT attribué au visiteur quand tous les critères sont remplis (obligatoire)."),
        "profil_prefere": profil("Profil secondaire présenté comme « préféré » avec ce résultat."),
        "profil_alternatif": profil("Profil secondaire présenté comme « alternatif » avec ce résultat."),
        "criteres": {"type": "array", "items": critere,
                     "description": "Conditions sur les scores ; envoyer la liste la REMPLACE."},
    }
    sans = lambda d, c: {k: v for k, v in d.items() if k not in c}
    return {
        ("questionnaires", "GET"): {"description": "Les questionnaires experts du site : titre, slug, état (actif), nombre de questions et de profils."},
        ("questionnaire_creer", "POST"): {"description": "Crée un questionnaire, INACTIF. Ensuite : ses profils (résultats possibles), ses questions et leurs réponses pondérées, éventuellement des combinaisons ; puis l'activer, et poser un bouton « questionnaire » sur une page.",
                                          "corps": objet({**questionnaire, "slug": _texte("Identifiant dans l'adresse ; déduit du titre.")}, ("titre",))},
        ("questionnaire", "GET"): {"description": "L'arbre complet d'un questionnaire : profils, questions, réponses et leurs poids, combinaisons et critères."},
        ("questionnaire", "PATCH"): {"description": "Modifie l'entête d'un questionnaire (titre, description, activation, accès, image, page) et les réglages de son résultat (mode, échelle, textes, bouton, style). Le slug ne change pas.",
                                     "corps": objet(questionnaire)},
        ("questionnaire_profils", "POST"): {"description": "Ajoute un profil — un résultat possible — au questionnaire.",
                                            "corps": objet(profil_champs, ("nom",))},
        ("profil", "PATCH"): {"description": "Modifie un profil ; son slug ne change pas (il est dans l'adresse des résultats déjà envoyés).",
                              "corps": objet(sans(profil_champs, {"slug"}))},
        ("questionnaire_questions", "POST"): {"description": "Ajoute une question, avec ses réponses et leurs poids vers les profils.",
                                              "corps": objet(question, ("texte",))},
        ("question", "PATCH"): {"description": "Modifie une question ; envoyer « reponses » REMPLACE toutes ses réponses, poids compris.",
                                "corps": objet(question)},
        ("question", "DELETE"): {"description": "Supprime une question et ses réponses ; refusé si le questionnaire a déjà été passé (préférer active=false)."},
        ("reponse", "DELETE"): {"description": "Supprime une seule réponse sans réécrire les autres ; refusé si le questionnaire a déjà été passé."},
        ("questionnaire_combinaisons", "POST"): {"description": "Ajoute une combinaison : une règle de résultat. Quand TOUS ses critères sur les scores sont remplis, le visiteur obtient profil_parent (avec préféré et alternatif en complément). Les combinaisons sont évaluées dans l'ordre de création, la première remplie l'emporte ; à défaut, le profil par score.",
                                                 "corps": objet(combinaison, ("titre", "profil_parent"))},
        ("questionnaire_simuler", "POST"): {"description": "Mode « dimensions » : compose la page de résultat pour des scores donnés, SANS rien enregistrer — qui passe en tête, quelle tranche s'affiche, le cas « profil nuancé ». À utiliser pour vérifier les tranches avant d'activer le questionnaire.",
                                            "corps": objet({"scores": {"type": "object", "additionalProperties": {"type": "number"},
                                                                       "description": "Score de chaque profil : {\"slug-du-profil\": 4.2, …} (slug ou identifiant)."}},
                                                           ("scores",))},
        ("combinaison", "PATCH"): {"description": "Modifie une combinaison ; envoyer « criteres » les REMPLACE.",
                                   "corps": objet(sans(combinaison, {"slug"}))},
    }


# --------------------------------------------------------------------------- #
#  Menus et identité visuelle
# --------------------------------------------------------------------------- #
def _contrats_des_menus_et_de_l_identite():
    from jeiko.administration.models import Font, Fonts, Theme
    from jeiko.administration_menu.models import Menu

    from .vues_identite import APPAREILS, ATTRIBUTS_DE_POLICE, ROLES_DE_POLICE

    objet = lambda proprietes, requis=(), description=None: {
        "type": "object", "properties": proprietes, "required": list(requis),
        "additionalProperties": False, **({"description": description} if description else {}),
    }
    element = {
        "type": "object",
        "description": "Une entrée du menu.",
        "properties": {
            "titre": _texte("Libellé affiché (obligatoire).", maxLength=100),
            "titres": {"type": "object", "additionalProperties": {"type": "string"},
                       "description": "Site en plusieurs langues : le libellé par langue — {\"en\": \"Pricing\"}. Une langue absente affiche « titre »."},
            "page": {"type": ["integer", "null"], "description": "Page visée, par son identifiant (lister_pages) ; absente pour une entrée qui ne sert qu'à ouvrir un sous-menu. Toujours la page D'ORIGINE, jamais une version traduite : le lien mène de lui-même à la version que lit le visiteur."},
            "actif": _booleen("Affichée (true par défaut)."),
            "sous_elements": {"type": "array", "items": {"type": "object"},
                              "description": "Entrées du sous-menu, de même forme (titre, page, actif)."},
        },
        "required": ["titre"],
        "additionalProperties": False,
    }
    menu = {
        "nom": _texte("Nom du menu dans l'administration.", maxLength=150),
        "emplacement": {**schema_du_champ(Menu, "place"), "description": "Où il s'affiche. Valeurs : MAIN = menu principal (en-tête) ; FOOTER = pied de page ; NULL = non assigné."},
        "disposition": {**schema_du_champ(Menu, "layout"), "description": schema_du_champ(Menu, "layout")["description"] + " Menu principal seulement ; null pour le pied de page."},
        "par_defaut": _booleen("En faire le menu par défaut de son emplacement (le précédent cesse de l'être). Les catégories peuvent en imposer un autre."),
        "afficher_le_panier": _booleen("Afficher l'icône du panier dans le menu du site. C'est un réglage de la BOUTIQUE, commun à tous les menus (Boutique › Réglages), décoché par défaut : le changer ici le change partout. L'icône n'apparaît que si la boutique est en ligne."),
        "elements": {"type": "array", "items": element,
                     "description": "L'arborescence du menu ; l'envoyer la REMPLACE en entier."},
    }
    police = objet(
        {cle: schema_du_champ(Font, champ) for cle, champ in ATTRIBUTS_DE_POLICE.items()},
        description="Réglages d'un rôle de police ; seuls les attributs envoyés changent. Un rôle de survol (…_hover) n'accepte pas « taille ».",
    )
    roles = ", ".join(ROLES_DE_POLICE)
    return {
        ("menus", "GET"): {"description": "Les menus du site : emplacement, disposition, arborescence, et les catégories qui les utilisent."},
        ("menu_creer", "POST"): {"description": "Crée un menu, éventuellement en COPIANT un existant (copie_de) : c'est ainsi qu'on fait un sous-site. Jamais « par défaut » à la création.",
                                 "corps": objet({**{k: v for k, v in menu.items() if k != "par_defaut"},
                                                 "copie_de": _entier("Identifiant du menu à copier : disposition, style, logo et arborescence.")},
                                                ("nom",))},
        ("menu", "GET"): {"description": "Un menu et son arborescence."},
        ("menu", "PATCH"): {"description": "Modifie un menu ; « elements » REMPLACE son arborescence.",
                            "corps": objet(menu)},
        ("categorie_menus", "PATCH"): {"description": "Affecte à une catégorie un menu principal et un menu de pied de page : toutes ses pages les prennent (sous-site). null rend le menu par défaut.",
                                       "corps": objet({
                                           "menu_principal": {"type": ["integer", "null"], "description": "Identifiant d'un menu d'emplacement MAIN."},
                                           "menu_pied_de_page": {"type": ["integer", "null"], "description": "Identifiant d'un menu d'emplacement FOOTER."},
                                       })},
        ("identite", "GET"): {"description": "L'identité visuelle : nom du site, dix couleurs du thème, polices par appareil et par rôle, CSS global."},
        ("identite", "PATCH"): {
            "description": "Modifie l'identité visuelle ; seul ce qui est envoyé change. Les couleurs deviennent les variables CSS de tout le site.",
            "corps": objet({
                "nom_du_site": _texte("Nom du site.", maxLength=200),
                "couleurs": objet({c: _texte(f"{Theme._meta.get_field(c).verbose_name} (couleur CSS : « #b45309 », « rgb(…) »).")
                                   for c, _ in Theme.VARIABLES},
                                  description="Les couleurs du thème, par rôle."),
                "polices": objet({
                    appareil: {"type": "object", "additionalProperties": police,
                               "description": f"Polices sur {appareil}, par rôle ({roles}) : {{\"h1\": {{\"famille\": \"Inter\", \"taille\": \"2.5rem\"}}}}."}
                    for appareil in APPAREILS
                }, description="Les polices, par appareil puis par rôle."),
                "css_global": _texte(
                    "CSS appliqué à tout le site public ; compilé et vérifié avant d'être accepté. "
                    "DERNIER RECOURS : couleurs et polices ci-dessus, et les réglages de chaque "
                    "section, ligne et bloc, passent avant."),
            }),
        },
    }


# --------------------------------------------------------------------------- #
#  E-mails
# --------------------------------------------------------------------------- #
def _contrats_des_emails():
    from jeiko.emailing import registry

    objet = lambda proprietes, requis=(): {"type": "object", "properties": proprietes,
                                           "required": list(requis), "additionalProperties": False}
    email = {
        "sujet": _texte("Sujet de l'e-mail ; peut contenir les jetons [%cle%] de l'événement (lister_email_evenements). Un jeton inconnu est refusé.", maxLength=255),
        "page": {"type": ["integer", "null"], "description": "Page qui sert de CORPS de l'e-mail (construite comme une page, avec des jetons [%cle%] dans ses textes). Une page NON PUBLIÉE, ou déjà gabarit d'e-mail : elle est marquée gabarit et ne s'affiche pas sur le site. Une page en ligne est refusée."},
        "actif": _booleen("L'e-mail part quand l'événement survient. Les e-mails obligatoires ne peuvent pas être désactivés."),
        # Ni « expediteur » ni « adresse_de_reponse » : ils se lisent, ne
        # s'écrivent pas par l'API (vues_emails.CLES_RESERVEES, Fable 2 §2).
    }
    return {
        ("email_evenements", "GET"): {
            "description": f"Les {len(registry.EMAIL_EVENTS)} événements qui envoient un e-mail (inscription, commande, rendez-vous…), avec les CLÉS [%cle%] que chacun fournit. À lire avant d'écrire un e-mail.",
            "parametres": objet({"categorie": {"type": "string", "enum": list(registry.CATEGORY_LABELS),
                                               "description": "Filtrer par catégorie : " + "; ".join(f"{k} = {v}" for k, v in registry.CATEGORY_LABELS.items()) + "."}}),
        },
        ("emails", "GET"): {"description": "Les e-mails configurés : événement, sujet, page de corps, activation."},
        ("email_creer", "POST"): {"description": "Habille un événement d'un e-mail (un seul par événement). Il naît INACTIF : écrire la page de corps, puis l'activer.",
                                  "corps": objet({"evenement": _texte("Code de l'événement (lister_email_evenements)."), **email}, ("evenement", "sujet"))},
        ("email", "GET"): {"description": "Un e-mail configuré."},
        ("email", "PATCH"): {"description": "Modifie un e-mail : sujet, page de corps, activation. L'expéditeur et l'adresse de réponse sont ceux du site (Réglages ▸ E-mails).",
                             "corps": objet(email)},
    }


# --------------------------------------------------------------------------- #
#  Fiches, modèles de fiche, types de produit, produits
# --------------------------------------------------------------------------- #
def _contrats_des_fiches_et_produits():
    from jeiko.custom_objects.models import CustomObjectField
    from jeiko.shop.models import Product, ProductType

    objet = lambda proprietes, requis=(), description=None: {
        "type": "object", "properties": proprietes, "required": list(requis),
        "additionalProperties": False, **({"description": description} if description else {}),
    }
    champ_de_modele = objet({
        "code": _texte("Code du champ, en minuscules et « _ » : il s'écrit [%code%] dans la page gabarit. Ne se renomme plus ensuite."),
        "libelle": _texte("Libellé du champ dans l'administration."),
        "type": {"type": "string", "enum": [c for c, _ in CustomObjectField.FIELD_TYPES],
                 "description": "Nature : " + "; ".join(f"{c} = {l}" for c, l in CustomObjectField.FIELD_TYPES) + "."},
        "obligatoire": _booleen("Le champ doit être rempli."),
        "aide": _texte("Aide affichée sous le champ.", maxLength=255),
    }, ("code", "type"))
    valeurs = {
        "type": ["object", "array"],
        "description": "Les valeurs de la fiche, par code de champ (lire_modele) : "
                       "texte / texte riche → une chaîne ; image → identifiant de la médiathèque ; "
                       "vidéo → URL ; bouton → {libelle, page_id | url_externe | questionnaire}. "
                       "Seuls les champs envoyés changent.",
    }
    metadonnees = objet({
        "titre": _texte("Titre dans les moteurs de recherche.", maxLength=100),
        "description": _texte("Description dans les moteurs de recherche."),
    }, description="SEO propre à la fiche.")
    def traductions(exemple, role):
        return {"type": "object", "additionalProperties": {"type": "object"},
                "description": "Site en plusieurs langues : le nom et le segment d'adresse par langue — " + exemple + ". " + role + " Une langue envoyée remplace la sienne ; {} la retire ; une langue non traduite garde le nom et le segment d'origine. 400 si l'adresse est déjà prise dans cette langue."}

    type_produit = {
        "nom": _texte("Nom du type : « Abonnement ».", maxLength=150),
        "traductions": traductions(
            "{\"en\": {\"nom\": \"Workshops\", \"slug\": \"workshops\"}}",
            "Le « slug » remplace le code dans l'adresse des produits lus dans cette langue : /en/shop/workshops/<référence>/."),
        "nature": {"type": "string", "enum": [c for c, _ in ProductType.KIND_CHOICES],
                   "description": "Nature commerciale : " + "; ".join(f"{c} = {l}" for c, l in ProductType.KIND_CHOICES) + "."},
        "expedition": _booleen("Le produit s'expédie et consomme du stock ; par défaut, vrai pour « physical » seulement."),
        "modele": {"type": ["string", "integer", "null"], "description": "Modèle de fiche qui porte le contenu, par slug ou identifiant (lister_modeles)."},
    }
    produit = {
        "sku": _texte("Référence unique : « JEIKO-EQUIPE ».", maxLength=100),
        "prix_ht": {"type": ["number", "string"], "description": "Prix hors taxes, en unités (29.90)."},
        "taux_tva": {"type": ["number", "string"], "description": "Taux de TVA en pourcentage (20) ; celui du type par défaut."},
        "devise": _texte("Devise ISO : « EUR » par défaut.", maxLength=3),
        "stock": _entier("Quantité en stock (produits expédiés).", minimum=0),
    }
    return {
        ("modeles", "GET"): {"description": "Les modèles (types) de fiche : leurs champs et leur page gabarit. À lire avant de créer une fiche."},
        ("modele_creer", "POST"): {"description": "Crée un modèle de fiche, ses champs, et marque sa page gabarit (où les jetons [%code%] sont remplacés par les valeurs de chaque fiche).",
                                   "corps": objet({
                                       "nom": _texte("Nom du modèle : « Formule »."),
                                       "slug": _texte("Identifiant dans les adresses (/co/<slug>/…) ; déduit du nom. Ne change plus."),
                                       "gabarit_de_page": _entier("Identifiant de la page qui rend chaque fiche (créée avant avec creer_page)."),
                                       "champs": {"type": "array", "items": champ_de_modele, "description": "Les champs du modèle."},
                                       "est_un_produit": _booleen("Les fiches de ce modèle sont vendues (produits de la boutique)."),
                                       "traductions": traductions(
                                           "{\"en\": {\"nom\": \"Articles\", \"slug\": \"articles\"}}",
                                           "Le « slug » remplace celui du modèle dans l'adresse des fiches lues dans cette langue : /en/co/articles/…"),
                                   }, ("nom", "gabarit_de_page", "champs"))},
        ("modele", "GET"): {"description": "Un modèle de fiche et ses champs."},
        ("modele", "PATCH"): {"description": "Renomme un modèle, traduit son nom et son slug, ou lui AJOUTE des champs ; un champ existant ne se renomme pas.",
                              "corps": objet({"nom": _texte("Nouveau nom."),
                                              "traductions": traductions(
                                                  "{\"en\": {\"nom\": \"Articles\", \"slug\": \"articles\"}}",
                                                  "Le « slug » remplace celui du modèle dans l'adresse des fiches lues dans cette langue : /en/co/articles/…"),
                                              "champs": {"type": "array", "items": champ_de_modele, "description": "Champs à AJOUTER."}})},
        ("types_produit", "GET"): {"description": "Les types de produit — la couche commerciale d'une fiche : nature, expédition, modèle."},
        ("type_produit_creer", "POST"): {"description": "Crée un type de produit et le relie à son modèle de fiche.",
                                         "corps": objet({**type_produit, "code": _texte("Code dans les adresses ; déduit du nom. Ne change plus.")}, ("nom",))},
        ("type_produit", "GET"): {"description": "Un type de produit : nature, expédition, modèle de fiche relié."},
        ("type_produit", "PATCH"): {"description": "Corrige un type de produit ; le code d'origine ne change pas, il se traduit (traductions).",
                                    "corps": objet(type_produit)},
        ("objets", "GET"): {"description": "Les fiches existantes, avec leurs valeurs. Sur un site en plusieurs langues, chaque version d'une fiche est une fiche : « langue » dit la sienne, « version_d_origine » la fiche qu'elle traduit, « versions » ses autres versions.",
                            "parametres": objet({
                                "modele": {"type": ["string", "integer"], "description": "Filtrer par modèle (slug ou identifiant)."},
                                "langue": _texte("Ne lister que les fiches de cette langue (« en »). Le code de la langue d'origine donne les fiches d'origine."),
                            })},
        ("objet_versions", "POST"): {
            "description": "Site en plusieurs langues : crée la version d'une fiche — ou de la fiche d'un produit — dans une langue, en DUPLIQUANT la fiche d'origine (valeurs, images, métadonnées). Elle naît NON publiée, avec le titre et l'adresse de l'originale : traduire ensuite titre, valeurs et metadonnees (modifier_objet sur la version), son slug pour une fiche servie sous /co/…, puis publier. Le produit reste unique : prix, stock et référence valent pour toutes les langues. 409 si la version existe ou si la langue n'est pas activée.",
            "corps": {
                "type": "object",
                "properties": {"langue": _texte("Code de la langue, parmi celles du site : « en ».")},
                "required": ["langue"],
                "additionalProperties": False,
            },
        },
        ("objet_creer", "POST"): {"description": "Crée une fiche d'un modèle, NON publiée ; ses valeurs remplissent la page gabarit.",
                                  "corps": objet({
                                      "modele": {"type": ["string", "integer"], "description": "Modèle de la fiche (slug ou identifiant)."},
                                      "titre": _texte("Titre de la fiche.", maxLength=200),
                                      "slug": _texte("Identifiant dans l'adresse ; déduit du titre. Ne change plus."),
                                      "valeurs": valeurs,
                                  }, ("modele", "titre"))},
        ("objet", "GET"): {"description": "Une fiche et ses valeurs."},
        ("objet", "PATCH"): {"description": "Modifie une fiche : titre, publication, image principale, SEO, valeurs (seules celles envoyées changent). Vaut pour la version traduite d'une fiche comme pour une fiche d'origine.",
                             "corps": objet({
                                 "titre": _texte("Titre.", maxLength=200),
                                 "slug": _texte("Seulement sur la VERSION traduite d'une fiche : son adresse dans sa langue (/en/co/<modèle>/<slug>/). Sans effet sur l'adresse d'un produit, qui porte sa référence. 409 si une autre fiche du modèle l'occupe."),
                                 "publie": _booleen("Mettre en ligne (true) ou retirer (false)."),
                                 "image_principale_id": {"type": ["integer", "null"], "description": "Image principale, identifiant de la médiathèque."},
                                 "metadonnees": metadonnees,
                                 "valeurs": valeurs,
                             })},
        ("produits", "GET"): {"description": "Les produits de la boutique : référence, prix, TVA, stock, fiche."},
        ("produit_creer", "POST"): {"description": "Crée un produit sur une fiche existante (la fiche porte le contenu, le produit le prix).",
                                    "corps": objet({
                                        "type": {"type": ["string", "integer"], "description": "Type de produit (code ou identifiant, lister_types_produit)."},
                                        "fiche_id": _entier("Identifiant de la fiche vendue (lister_objets) — une fiche d'ORIGINE : le produit sert toutes ses versions par langue."),
                                        **produit,
                                    }, ("type", "fiche_id", "sku"))},
        ("produit", "GET"): {"description": "Un produit : référence, prix, TVA, stock, fiche vendue."},
        ("produit", "PATCH"): {"description": "Modifie un produit : référence, prix, TVA, devise, stock, activation.",
                               "corps": objet({**produit, "actif": _booleen("En vente.")})},
    }


def _contrats_du_socle():
    return {
        ("guide", "GET"): {"description": "Le mode d'emploi de l'API : modèle de page, vocabulaire, catalogue des blocs, pièges connus, exemple complet. À lire au premier usage."},
        ("whoami", "GET"): {"description": "Qui est l'agent, et ce qu'il a le droit de faire : ses rôles et ses permissions. Premier appel utile."},
    }


# --------------------------------------------------------------------------- #
#  Accès
# --------------------------------------------------------------------------- #
def tous_les_contrats():
    """{(nom de route, méthode): contrat} pour toute l'API."""
    contrats = {}
    for fabrique_de_contrats in (_contrats_des_pages, _contrats_du_calendrier,
                                  _contrats_des_questionnaires,
                                  _contrats_des_menus_et_de_l_identite,
                                  _contrats_des_emails, _contrats_des_fiches_et_produits,
                                  _contrats_du_socle):
        contrats.update(fabrique_de_contrats())
    return contrats


def contrats_publies():
    """Les contrats, par chemin et méthode, tels que la route `contrats/` les sert."""
    from . import urls_api

    chemins = {m.name: "/api/agent/v1/" + str(m.pattern) for m in urls_api.urlpatterns if m.name}
    publies = []
    for (route, methode), contrat in sorted(tous_les_contrats().items()):
        publies.append({"route": route, "methode": methode,
                        "chemin": chemins.get(route, "?"), **contrat})
    return publies
