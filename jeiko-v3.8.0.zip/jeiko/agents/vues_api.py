# jeiko/agents/vues_api.py
"""
Socle des vues de l'API : entrée, sortie, et refus uniformes.

Trois choses valent d'être expliquées.

**La permission est obligatoire, pas optionnelle.** `VueAgent` refuse de
répondre si la sous-classe n'a pas déclaré `permission_requise`. Une vue qu'on
oublie de garder est le défaut le plus banal d'une API — et il est invisible,
puisque tout fonctionne. Ici l'oubli produit une erreur immédiate, sur le
premier appel, en développement.

**Le corps est du JSON, et sa taille est bornée.** Un agent envoie du JSON ;
accepter autre chose n'apporte rien et élargit la surface. La borne évite qu'un
appel unique fasse allouer un document arbitrairement gros.

**Les erreurs se ressemblent toutes.** Un objet `{"erreur": "…"}` et un code
HTTP juste. Les vues ne renvoient jamais une trace ni un message d'exception :
ils décrivent l'intérieur du système à quelqu'un qui n'a pas à le connaître.
"""

import json
import logging

from django.http import JsonResponse, Http404
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt

from .authentification import exige_un_agent

logger = logging.getLogger(__name__)

#: 1 Mio. Un arbre de page complet tient très largement dedans ; au-delà, c'est
#: qu'il se passe autre chose.
TAILLE_MAX_CORPS = 1024 * 1024


def ok(donnees=None, statut=200):
    return JsonResponse(donnees if donnees is not None else {}, status=statut)


def erreur(message, statut=400, **extra):
    corps = {"erreur": message}
    corps.update(extra)
    return JsonResponse(corps, status=statut)


#: Sentinelle : cette vue se contente d'un agent authentifié, sans permission
#: supplémentaire. Écrite en toutes lettres pour qu'on ne la confonde pas avec
#: un oubli — c'est toute la différence entre un choix et une négligence, et la
#: seule qui se voie à la relecture.
AUTHENTIFICATION_SEULE = "authentification-seule"


class CorpsInvalide(Exception):
    """Le corps de la requête n'est pas exploitable. Porte le message à rendre."""


@method_decorator(csrf_exempt, name="dispatch")
@method_decorator(never_cache, name="dispatch")
@method_decorator(exige_un_agent, name="dispatch")
class VueAgent(View):
    """
    Base de toute vue de l'API.

    L'exemption CSRF est sûre ICI et seulement ici : ces vues n'acceptent que
    l'en-tête `Authorization`, jamais la session. Voir `authentification.py`.
    """

    #: À déclarer dans chaque sous-classe. `None` fait échouer la vue.
    permission_requise = None

    def dispatch(self, request, *args, **kwargs):
        if not self.permission_requise:
            logger.error(
                "%s ne déclare pas de `permission_requise` : appel refusé.",
                type(self).__name__,
            )
            return erreur(
                "Cette ressource est mal configurée côté serveur.", statut=500
            )

        if self.permission_requise != AUTHENTIFICATION_SEULE and not request.user.has_perm(
            self.permission_requise
        ):
            return erreur(
                "Cet agent n'a pas le droit d'effectuer cette action.",
                statut=403,
                permission_manquante=self.permission_requise,
            )

        try:
            return super().dispatch(request, *args, **kwargs)
        except CorpsInvalide as souci:
            return erreur(str(souci), statut=400)
        except Http404:
            # Cinquante-quatre vues cherchent leur objet par
            # `get_object_or_404`. Sans cette prise, un identifiant faux
            # rendait la page HTML de Django : un agent qui attend du JSON
            # recevait un document qu'il ne sait pas lire, sans savoir s'il
            # s'était trompé de route ou d'objet. La route existe ; c'est
            # l'objet qui manque, et on le dit.
            return erreur(
                "Aucun objet ne porte cet identifiant. Relisez la liste "
                "correspondante pour trouver le bon.",
                statut=404,
            )

    # ------------------------------------------------------------------ #
    #  Lecture du corps
    # ------------------------------------------------------------------ #
    def corps(self, request, *, obligatoire=True, connues=None, taille_max=None):
        """
        Le corps JSON de la requête, en dictionnaire.

        `connues` — l'ensemble des clés acceptées — fait refuser tout le reste
        en 400, en les nommant.

        Ce n'est pas du zèle. Les `PATCH` de cette API refusaient déjà les clés
        inconnues ; sept routes de CRÉATION ne le faisaient pas, et créaient
        l'objet en ignorant ce qu'elles n'avaient pas compris. Un agent qui
        écrivait `{"gabarit_de_section": "HERO"}` au lieu de `{"gabarit": …}`
        recevait un 201 et une section vide, sans un mot — puis recommençait.
        Le terrain l'a payé en sondes laissées en base : des sections vides,
        un questionnaire et deux catégories nommés « ZZ — sonde technique ».

        Une faute de frappe doit coûter un message, pas une ligne en base.
        """
        brut = request.body or b""

        if len(brut) > (taille_max or TAILLE_MAX_CORPS):
            raise CorpsInvalide("Corps de requête trop volumineux.")

        if not brut:
            if obligatoire:
                raise CorpsInvalide("Un corps JSON est attendu.")
            return {}

        try:
            donnees = json.loads(brut.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            raise CorpsInvalide("Le corps doit être du JSON valide, encodé en UTF-8.")

        if not isinstance(donnees, dict):
            raise CorpsInvalide("Le corps doit être un objet JSON.")

        if connues is not None:
            inconnues = sorted(set(donnees) - set(connues))
            if inconnues:
                raise CorpsInvalide(
                    f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                    f"Acceptées : {', '.join(sorted(connues))}."
                )
        return donnees

    def http_method_not_allowed(self, request, *args, **kwargs):
        return erreur("Méthode non autorisée sur cette ressource.", statut=405)


class Guide(VueAgent):
    """
    Le mode d'emploi de l'API, à l'adresse racine.

    Sans permission : c'est de la documentation, et un agent doit pouvoir la
    lire avant qu'on lui ait accordé quoi que ce soit. Lui refuser le mode
    d'emploi tant qu'il n'a pas de rôle reviendrait à lui demander de deviner
    ce qu'il a le droit de demander.
    """

    permission_requise = AUTHENTIFICATION_SEULE

    def get(self, request):
        from .guide import construire

        return ok(construire())


class Contrats(VueAgent):
    """
    La forme exacte de chaque appel : description, schéma du corps et des filtres.

    Ce que le serveur MCP donne à ses outils, publié pour qui appelle l'API
    directement. Voir `contrats.py`.
    """

    permission_requise = AUTHENTIFICATION_SEULE

    def get(self, request):
        from .contrats import contrats_publies

        return ok({"contrats": contrats_publies()})


class QuiSuisJe(VueAgent):
    """
    Carte d'identité de l'agent : qui il est, et ce qu'il a le droit de faire.

    Premier appel utile d'un agent : il lui évite de découvrir ses droits en
    se heurtant à des 403, et rend le diagnostic immédiat quand un rôle a été
    mal assigné.
    """

    #: Aucune permission : un agent doit pouvoir vérifier que son jeton
    #: fonctionne AVANT qu'on lui ait donné le moindre rôle. Exiger une
    #: permission ici ferait répondre 403 à un jeton parfaitement valide, et
    #: enverrait chercher la panne du mauvais côté.
    permission_requise = AUTHENTIFICATION_SEULE

    def get(self, request):
        from .authentification import quota_agent

        agent = request.agent
        permissions = sorted(request.user.get_all_permissions())

        return ok({
            "agent": {
                "nom": agent.nom,
                "description": agent.description,
                "expire_le": agent.expire_le.isoformat() if agent.expire_le else None,
            },
            "roles": [
                assignation.role.name
                for assignation in agent.user.role_assignments.select_related("role")
            ],
            "permissions": permissions,
            "peut": {
                "creer_une_page": request.user.has_perm("administration_pages.add_page"),
                "modifier_une_page": request.user.has_perm(
                    "administration_pages.change_page"
                ),
                # Toujours faux : l'API ne propose aucune suppression de page.
                # Dit explicitement pour qu'un agent ne la cherche pas.
                "supprimer_une_page": False,
            },
            "jeton": {"prefixe": request.jeton_agent.prefixe},
            "quota": quota_agent(request.jeton_agent.prefixe, agent),
        })


class RouteApiInconnue(VueAgent):
    """Évite la page HTML Django pour une URL d’API mal orthographiée."""

    permission_requise = AUTHENTIFICATION_SEULE

    def get(self, request, inconnue):
        return erreur(
            f"Route API inconnue : /{inconnue}. Consultez GET /api/agent/v1/.",
            statut=404,
        )


# --------------------------------------------------------------------------- #
#  Longueurs et adresses — rapport Fable 2, §2.3 et §2.4
# --------------------------------------------------------------------------- #
def borne(modele, champ, valeur):
    """
    Le texte tronqué à la longueur DU MODÈLE.

    L'API tronquait à des longueurs écrites en dur, parfois plus grandes que
    le champ (200 pour un titre de page de 100, 200 pour un nom de type de
    rendez-vous de 50) : PostgreSQL refusait, et l'agent recevait un 500.
    """
    texte = str(valeur or "").strip()
    longueur = modele._meta.get_field(champ).max_length
    return texte[:longueur] if longueur else texte


def slug_d_adresse(valeur, cle, longueur=100, a_la_racine=True):
    """
    Un segment d'adresse publique valide, ou un refus qui propose le bon.

    Le formulaire humain impose lettres, chiffres et tirets, et refuse les
    slugs réservés (`api`, `administration`…). L'API ne le faisait pas : une
    page naissait avec un espace ou un accent dans son adresse — introuvable,
    mais présente dans le sitemap —, ou sur `api`, inatteignable en silence.
    On refuse plutôt que de corriger : c'est l'adresse publique, elle ne doit
    pas changer sans que l'agent le sache.
    """
    from django.conf import settings
    from django.utils.text import slugify

    texte = str(valeur or "").strip()
    propre = slugify(texte)
    if not propre:
        raise CorpsInvalide(f"« {cle} » ne donne aucune adresse utilisable.")
    if texte != propre:
        raise CorpsInvalide(
            f"« {cle} » : lettres minuscules, chiffres et tirets seulement. "
            f"Proposé : « {propre} »."
        )
    if len(propre) > longueur:
        raise CorpsInvalide(f"« {cle} » fait au plus {longueur} caractères.")
    # Réservé seulement À LA RACINE : /documentation/api/ est une adresse
    # parfaitement valide, /api/ non. L'appelant dit où tombe l'adresse.
    if a_la_racine and est_reserve(propre):
        raise CorpsInvalide(
            f"« {cle} » : « {propre} » est réservé par le site (administration, "
            f"API, comptes…) — la page serait inatteignable."
        )
    return propre


def est_reserve(slug):
    """
    Vrai si `slug`, à la racine du site, masquerait une route du système — ou
    le préfixe d'une langue (`/en/`). La règle est celle des formulaires :
    `jeiko.langues_du_site.est_un_slug_reserve`.
    """
    from jeiko.langues_du_site import est_un_slug_reserve

    return est_un_slug_reserve(str(slug or ""))


def refuser_une_adresse_reservee(adresse, cle):
    """
    Refuse une adresse de premier niveau (`/api/`) réservée par le site.

    L'adresse d'une version traduite porte le préfixe de sa langue
    (`/en/accounts/`) : c'est le segment qui le SUIT qui compte. `/en/accounts/`
    est lu comme `/accounts/` une fois le préfixe retiré — la page serait
    tout aussi inatteignable.
    """
    from jeiko.langues_du_site import codes_proposes

    segments = [morceau for morceau in str(adresse or "").split("/") if morceau]
    if len(segments) == 2 and segments[0] in codes_proposes():
        segments = segments[1:]
    if len(segments) == 1 and est_reserve(segments[0]):
        raise CorpsInvalide(
            f"« {cle} » : l'adresse « {adresse} » est réservée par le site "
            f"(administration, API, comptes…) — la page serait inatteignable. "
            f"Choisir un autre nom, ou ranger la page dans une catégorie."
        )



# --------------------------------------------------------------------------- #
#  Le nom et l'adresse par langue — catégories, modèles de fiche, types de produit
# --------------------------------------------------------------------------- #
def traductions_nom_et_slug(brut, modele):
    """
    Valide « traductions » — `{"en": {"nom": "…", "slug": "…"}}` — et le rend
    dans la forme enregistrée (`{"en": {"name": …, "slug": …}}`).

    Une seule écriture pour tout ce qui se traduit en place : une catégorie,
    un modèle de fiche, un type de produit. Un agent qui a appris la forme sur
    l'un la réemploie sur les autres.
    """
    from django.utils.text import slugify

    from jeiko import langues_du_site

    if not isinstance(brut, dict):
        raise CorpsInvalide(
            "« traductions » est un objet par langue : "
            "{\"en\": {\"nom\": \"…\", \"slug\": \"…\"}}."
        )
    resultat = {}
    for code, valeurs in brut.items():
        if code not in langues_du_site.codes_proposes():
            raise CorpsInvalide(
                f"Langue inconnue : « {code} ». "
                f"Proposées : {', '.join(langues_du_site.codes_proposes())}."
            )
        if not isinstance(valeurs, dict) or set(valeurs) - {"nom", "slug"}:
            raise CorpsInvalide(f"traductions.{code} : un objet {{nom, slug}} est attendu.")
        entree = {}
        if str(valeurs.get("nom") or "").strip():
            entree["name"] = borne(modele, "name", valeurs["nom"])
        if str(valeurs.get("slug") or "").strip():
            entree["slug"] = slugify(str(valeurs["slug"]))
        if entree:
            resultat[code] = entree
    return resultat


def appliquer_les_traductions(objet, brut):
    """
    Pose les traductions envoyées sur `objet`, sans l'enregistrer : les langues
    envoyées remplacent les leurs, les autres restent, une langue envoyée vide
    (`{}`) retire la sienne. Refuse une adresse déjà prise dans une langue.
    """
    from django.core.exceptions import ValidationError

    nouvelles = traductions_nom_et_slug(brut, type(objet))
    objet.traductions = {
        **{c: v for c, v in (objet.traductions or {}).items() if c not in brut},
        **nouvelles,
    }
    try:
        objet.verifier_les_traductions()
    except ValidationError as refus:
        raise CorpsInvalide(" ".join(refus.messages)) from refus


def traductions_en_dict(objet):
    """Les traductions telles que l'API les rend : `{"en": {"nom": …, "slug": …}}`."""
    return {
        code: {"nom": (v or {}).get("name", ""), "slug": (v or {}).get("slug", "")}
        for code, v in (objet.traductions or {}).items()
    }
