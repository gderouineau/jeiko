"""
Aplatissement d'un CustomObject vers le contexte de gabarit.

Le gabarit d'un objet custom est une Page ordinaire truffée de jetons
`[%code%]`, résolus par `jeiko.templatetags.custom_tags`. Il faut donc exposer
chaque valeur sous la clé de son champ.

Cette logique était dupliquée à l'identique entre la vue objet et la vue
produit ; toute évolution du typage des champs devait être faite en double.
Elle vit désormais ici, et les deux vues l'appellent.
"""

from django.urls import NoReverseMatch, reverse
from django.utils.safestring import mark_safe

from jeiko.sanitize import clean_html

from .models import CustomObjectField


def build_button_url(value):
    """
    Résout la destination d'un champ BOUTON, dans l'ordre de priorité du
    modèle : page interne, questionnaire, lien externe.
    """
    if value.button_page_id:
        try:
            return value.button_page.get_absolute_url()
        except Exception:
            return "#"

    slug = (value.button_test_slug or "").strip()
    if slug:
        try:
            return reverse(
                "jeiko_client_questionnaires_expert:test_question",
                kwargs={"slug": slug, "position": 0},
            )
        except NoReverseMatch:
            return f"/pass-test/{slug}/question/0/"

    return (value.button_external_url or "").strip() or "#"


def build_object_context(obj):
    """
    Retourne {code_du_champ: valeur} pour un CustomObject.

    Les valeurs sont consommées telles quelles par le gabarit :
      - texte / vidéo  -> str, échappé au rendu
      - texte riche    -> HTML assaini et marqué sûr
      - image          -> ImageContent
      - bouton         -> {"url": ..., "label": ...}
    """
    # Jetons RÉSERVÉS : ce que toute fiche possède, indépendamment des champs
    # que son type déclare.
    #
    # Sans eux, écrire `[%titre%]` dans un gabarit — le premier réflexe de qui
    # découvre le système — laissait la chaîne « [%titre%] » telle quelle sur
    # la page publique. Aucune erreur, aucun avertissement : juste un gabarit
    # visiblement cassé, et rien pour dire que `titre` n'est pas un champ mais
    # une propriété de la fiche.
    #
    # Ils sont posés AVANT la boucle : un champ déclaré `titre` l'emporte donc
    # sur le jeton réservé. C'est le bon sens de priorité — ce que le modèle
    # déclare explicitement gagne sur ce que le système offre par défaut.
    context = {
        "titre": obj.title,
        "title": obj.title,
        "slug": obj.slug,
    }

    for value in obj.values.all():
        code = value.field.code
        if not code:
            continue

        field_type = value.field.field_type

        if field_type == CustomObjectField.TEXT:
            context[code] = value.value_text

        elif field_type == CustomObjectField.RICH_TEXT:
            # Le contenu vient de Quill : c'est du HTML, et le rédacteur
            # attend sa mise en forme. L'échapper comme le reste afficherait
            # le balisage en clair au lecteur. On l'assainit donc (cf.
            # jeiko/sanitize.py) avant de le marquer sûr — c'est le seul type
            # de champ à sortir non échappé.
            context[code] = mark_safe(clean_html(value.value_text))

        elif field_type == CustomObjectField.IMAGE:
            context[code] = value.image

        elif field_type == CustomObjectField.VIDEO:
            context[code] = value.video_url

        elif field_type == CustomObjectField.BUTTON:
            context[code] = {
                "url": build_button_url(value),
                "label": (value.button_label or "").strip(),
            }

    return context


#: Chargements à appliquer avant `build_object_context` pour éviter les N+1.
OBJECT_VALUE_PREFETCH = (
    "values__field",
    "values__image",
    "values__button_page",
)


def contexte_de_fiche(request, fiche):
    """
    Ce que `pages/main.html` attend pour rendre une fiche — commun à la vue
    des fiches (`/co/…`) et à celle des produits (`/shop/…`).

    * `page` : le gabarit du modèle, DANS LA LANGUE DE LA FICHE servie (sa
      version publiée, sinon l'original), avec son arbre section > ligne > bloc
      préchargé — sans quoi le rendu du corps le recharge bloc par bloc ;
    * les valeurs de la fiche, sous le code de leur champ, pour les jetons ;
    * ses métadonnées de recherche ;
    * `canonical_url` quand la fiche d'origine est lue sous le préfixe d'une
      langue où elle n'est pas traduite : elle renvoie à son adresse propre,
      Google n'y voit pas un doublon.
    """
    from jeiko.administration_pages.models import Page
    from jeiko.administration_pages.querysets import with_page_tree
    from jeiko.administration_pages.views_client import contexte_de_langue

    gabarit = fiche.model.gabarit_pour(fiche.langue)
    page = with_page_tree(Page.objects.filter(pk=gabarit.pk)).first() or gabarit
    contexte = {"page": page, "custom_object": fiche, "object": fiche}
    metadata = getattr(fiche, "metadata", None)
    if metadata is not None:
        contexte["metadata"] = metadata
    contexte.update(build_object_context(fiche))
    contexte.update(contexte_de_langue(request, fiche))
    return contexte


def discard_image_if_orphan(image):
    """
    Supprime une ImageContent devenue inutilisée. Retourne True si supprimée.

    Les formulaires d'objet custom créent une *nouvelle* ImageContent à chaque
    envoi de fichier, plutôt que d'écraser celle en place : la même image peut
    être partagée par plusieurs contenus, et la modifier les changerait tous.
    La contrepartie est que l'ancienne restait en base et sur disque à chaque
    remplacement. On la supprime ici — mais seulement si plus rien ne la
    référence.

    Le balayage passe par les relations inverses déclarées sur le modèle, donc
    il suit automatiquement les usages ajoutés plus tard. `ProtectedError` est
    rattrapé en dernier recours : les relations en PROTECT refuseront d'elles-
    mêmes la suppression si le balayage avait laissé passer quelque chose.
    """
    from django.db.models import ProtectedError, RestrictedError

    if image is None:
        return False

    for rel in image._meta.related_objects:
        related_manager = rel.related_model._base_manager
        if related_manager.filter(**{rel.field.name: image}).exists():
            return False

    try:
        image.delete()  # ImageContent.delete() nettoie aussi les fichiers
    except (ProtectedError, RestrictedError):
        return False
    return True
