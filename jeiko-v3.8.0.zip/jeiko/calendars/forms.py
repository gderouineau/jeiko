from django import forms
import json
from datetime import datetime

from django.core.exceptions import ValidationError

from .models import Appointment, AppointmentType, Availability, GoogleCalendarConfig, Slot
from .recurrence import build_rrulestr, WEEKDAY_TOKENS
from django.utils.translation import gettext_lazy as _


WEEKDAYS = [
    ("MO", _("Lundi")),
    ("TU", _("Mardi")),
    ("WE", _("Mercredi")),
    ("TH", _("Jeudi")),
    ("FR", _("Vendredi")),
    ("SA", _("Samedi")),
    ("SU", _("Dimanche")),
]


def _parse_recurrence_block(rule_text: str):
    """
    Parse un bloc multi-lignes (DTSTART / RRULE / EXDATE) et renvoie:
    {
        'freq': 'DAILY' | 'WEEKLY' | None,
        'byday': ['MO','TU',...],
        'until_date': date | None,
        'exdates': ['YYYY-MM-DD', ...],
    }
    """
    out = {'freq': None, 'byday': [], 'until_date': None, 'exdates': []}
    if not rule_text:
        return out

    lines = [ln.strip() for ln in rule_text.splitlines() if ln and ln.strip()]
    rrule_line = next((ln for ln in lines if ln.startswith('RRULE:')), None)
    exdate_lines = [ln for ln in lines if ln.startswith('EXDATE:')]

    # RRULE
    if rrule_line:
        # ex: RRULE:FREQ=WEEKLY;BYDAY=TH;UNTIL=20251231T235959Z
        parts = rrule_line[len('RRULE:'):].split(';')
        kv = {}
        for p in parts:
            if '=' in p:
                k, v = p.split('=', 1)
                kv[k.upper()] = v

        freq = kv.get('FREQ')
        if freq in ('DAILY', 'WEEKLY'):
            out['freq'] = freq

        byday = kv.get('BYDAY')
        if byday:
            out['byday'] = [s.strip() for s in byday.split(',') if s.strip()]

        until = kv.get('UNTIL')
        if until:
            # formats typiques : 20251130T235959Z ou 20251130T235959
            until = until.rstrip('Z')
            try:
                dt = datetime.strptime(until, "%Y%m%dT%H%M%S")
                out['until_date'] = dt.date()
            except Exception:
                out['until_date'] = None

    # EXDATE
    exdates = []
    for ln in exdate_lines:
        # ex: EXDATE:20251111T140000Z
        val = ln[len('EXDATE:'):].strip().rstrip('Z')
        try:
            dt = datetime.strptime(val, "%Y%m%dT%H%M%S")
            exdates.append(dt.date().isoformat())
        except Exception:
            # si jamais format différent, on ignore
            pass
    out['exdates'] = exdates

    return out


class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ['slot', 'email']  # Ajoute 'user' côté vue si connecté

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Affiche seulement les slots disponibles
        self.fields['slot'].queryset = Slot.objects.filter(is_available=True, remaining_places__gt=0)
        self.fields['slot'].label = _("Créneau souhaité")
        self.fields['slot'].empty_label = _("Choisissez un créneau")

    def clean_slot(self):
        slot = self.cleaned_data['slot']
        if not slot.is_available or slot.remaining_places <= 0:
            raise ValidationError(_("Ce créneau n'est plus disponible, veuillez en choisir un autre."))
        return slot


class AppointmentFormAdmin(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ["type", "slot", "client_name", "email", "places",
                  "is_paid", "start", "end"]

    def __init__(self, *args, **kwargs):
        # `owner` = gestionnaire propriétaire du calendrier. Les choix sont
        # restreints à SON calendrier : un ModelChoiceField valide la valeur
        # postée contre son queryset, ce qui bloque un POST forgé pointant
        # vers le type ou le créneau d'un autre gestionnaire.
        owner = kwargs.pop("owner", None)
        super().__init__(*args, **kwargs)
        if owner is not None:
            self.fields["type"].queryset = AppointmentType.objects.filter(user=owner)
            self.fields["slot"].queryset = Slot.objects.filter(
                availability__user=owner
            ).select_related("type")

    def clean(self):
        cleaned = super().clean()
        slot = cleaned.get("slot")
        apptype = cleaned.get("type")
        if slot and apptype and slot.type_id != apptype.id:
            self.add_error("slot", _("Le créneau choisi n’appartient pas à ce type de rendez-vous."))

        places = cleaned.get("places")
        if slot and places:
            # Places encore libres, en excluant ce rendez-vous s'il est déjà posé
            # sur ce créneau (sinon on lui opposerait ses propres places).
            taken = sum(
                a.places for a in slot.appointments.active().exclude(pk=self.instance.pk)
            )
            libres = max(0, slot.capacity - taken)
            if places > libres:
                self.add_error(
                    "places",
                    _("Il ne reste que %(libres)s place(s) sur ce créneau.") % {"libres": libres},
                )
        return cleaned


class AppointmentClientCreateForm(forms.Form):
    """
    Création d'un rendez-vous PAR un gestionnaire POUR un client déjà inscrit.

    Le client est fixé par la vue (page de l'utilisateur). Le gestionnaire ne
    choisit qu'un créneau de SON calendrier et le nombre de places. Le rendez-vous
    est confirmé d'emblée : le paiement, s'il y a lieu, se règle hors ligne
    (case « Déjà réglé »).
    """
    slot = forms.ModelChoiceField(
        queryset=Slot.objects.none(),
        label=_("Créneau"),
        empty_label=_("Choisissez un créneau"),
        widget=forms.Select(attrs={"class": "form-control"}),
    )
    places = forms.IntegerField(
        label=_("Nombre de places"), min_value=1, initial=1,
        widget=forms.NumberInput(attrs={"class": "form-control", "min": 1}),
    )
    is_paid = forms.BooleanField(
        label=_("Déjà réglé"), required=False,
        widget=forms.CheckboxInput(attrs={"class": "form-check-input"}),
    )

    def __init__(self, *args, manager=None, supervisor=False, **kwargs):
        from django.utils import timezone
        super().__init__(*args, **kwargs)
        slots = (
            Slot.objects
            .filter(is_available=True, remaining_places__gt=0, start__gte=timezone.now())
            .select_related("type", "availability")
        )
        # Un gestionnaire ne place un RDV que sur son propre calendrier ;
        # le superviseur peut piocher dans tous.
        if not supervisor and manager is not None:
            slots = slots.filter(availability__user=manager)
        self.fields["slot"].queryset = slots.order_by("start")
        self.fields["slot"].label_from_instance = self._label

    @staticmethod
    def _label(slot):
        from django.utils.timezone import localtime
        start = localtime(slot.start)
        libres = f"{slot.remaining_places} place" + ("s" if slot.remaining_places > 1 else "")
        return f"{start:%d/%m/%Y %H:%M} — {slot.type.name} ({libres})"

    def clean(self):
        cleaned = super().clean()
        slot = cleaned.get("slot")
        places = cleaned.get("places")
        if slot and places:
            maximum = max(1, slot.type.max_places_per_booking)
            if places > maximum:
                self.add_error(
                    "places",
                    _("Ce type de rendez-vous est limité à %(maximum)s place(s) par réservation.") % {"maximum": maximum},
                )
            elif places > slot.remaining_places:
                self.add_error(
                    "places",
                    _("Il ne reste que %(remaining_places)s place(s) sur ce créneau.") % {"remaining_places": slot.remaining_places},
                )
        return cleaned


class AppointmentTypeForm(forms.ModelForm):
    class Meta:
        model = AppointmentType
        fields = [
            "name",
            "duration",
            "is_paid",
            "price",
            "is_registration_required",
            "color",
            "font",
            "description",
            "capacity",
            "max_places_per_booking",
            "allow_waitlist",
            "cancellation_deadline_hours",
        ]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control", "placeholder": _("Ex. Séance découverte")}),
            # DurationField attend un format 'HH:MM:SS' (Django natif). Tu peux accepter HH:MM aussi.
            "duration": forms.TextInput(attrs={"class": "form-control", "placeholder": "HH:MM:SS (ex. 01:30:00)"}),
            "is_paid": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "price": forms.NumberInput(attrs={"class": "form-control", "min": 0, "step": "0.01"}),
            "is_registration_required": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "color": forms.TextInput(attrs={"type": "color", "class": "form-control form-control-color"}),
            "font": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ex. Inter"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 4}),
            "capacity": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "max_places_per_booking": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "allow_waitlist": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "cancellation_deadline_hours": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Le délai d'annulation a un défaut au niveau du modèle : inutile
        # d'obliger l'admin à le retaper. Laissé vide, on retombe dessus.
        self.fields["cancellation_deadline_hours"].required = False

    def clean(self):
        cleaned = super().clean()

        # Champ laissé vide -> défaut du modèle (24 h), jamais None.
        if cleaned.get("cancellation_deadline_hours") in (None, ""):
            cleaned["cancellation_deadline_hours"] = (
                AppointmentType._meta.get_field("cancellation_deadline_hours").default
            )

        capacity = cleaned.get("capacity")
        max_places = cleaned.get("max_places_per_booking")
        if capacity and max_places and max_places > capacity:
            self.add_error(
                "max_places_per_booking",
                _("Un client ne peut pas réserver plus de places que n'en compte le créneau (%(capacity)s).") % {"capacity": capacity},
            )

        # Champ laissé vide sur un type gratuit : c'est 0, pas une erreur.
        if cleaned.get("price") in (None, ""):
            cleaned["price"] = 0

        # Un type payant sans prix ne serait jamais encaissable : le client
        # resterait bloqué sur une page de paiement à 0 €.
        if cleaned.get("is_paid") and not (cleaned.get("price") or 0) > 0:
            self.add_error(
                "price",
                _("Indiquez un prix supérieur à 0 pour un rendez-vous payant."),
            )
        return cleaned

    def clean_color(self):
        color = self.cleaned_data.get("color", "").strip()
        # On tolère #RGB, #RRGGBB (simple)
        import re
        if not re.fullmatch(r"#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})", color):
            raise forms.ValidationError(_("Couleur invalide. Utilise un code hexadécimal (#RRGGBB)."))
        return color


class AvailabilityForm(forms.ModelForm):
    # ----- Champs UI non-modèles -----
    recurrence_freq = forms.ChoiceField(
        choices=[("NONE", _("Aucune")), ("DAILY", _("Quotidien")), ("WEEKLY", _("Hebdomadaire"))],
        required=False, initial="NONE", label=_("Récurrence")
    )
    recurrence_until = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),  # <-- ajout du format
        label=_("Jusqu’au")
    )
    # Pour WEEKLY : jours inclus ; pour DAILY : jours à garder (exclure weekend, etc.)
    recurrence_byweekday = forms.MultipleChoiceField(
        choices=WEEKDAYS, required=False, label=_("Jours (BYDAY)")
    )
    recurrence_exdates_text = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={"rows": 3, "placeholder": "YYYY-MM-DD (une par ligne)"}),
        label=_("Dates à exclure (EXDATE)")
    )

    class Meta:
        model = Availability
        # IMPORTANT: on inclut 'recurrence_exdates' pour qu'il soit sauvé !
        fields = ['appointment_types', 'start', 'end', 'recurring_rule', 'recurrence_exdates', 'is_available']
        widgets = {
            'appointment_types': forms.SelectMultiple(),
            'start': forms.DateTimeInput(
                attrs={'type': 'datetime-local'},
                format='%Y-%m-%dT%H:%M'
            ),
            'end': forms.DateTimeInput(
                attrs={'type': 'datetime-local'},
                format='%Y-%m-%dT%H:%M'
            ),
            'recurring_rule': forms.Textarea(
                attrs={'rows': 3, 'placeholder': _('(généré automatiquement)')}
            ),
            # on peut masquer la version JSON si tu ne veux pas l'afficher
            'recurrence_exdates': forms.HiddenInput(),
        }

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)

        # formats date-heure
        for f in ['start', 'end']:
            if self.instance and getattr(self.instance, f):
                self.fields[f].initial = getattr(self.instance, f).strftime('%Y-%m-%dT%H:%M')
            self.fields[f].widget.format = '%Y-%m-%dT%H:%M'
            self.fields[f].localize = False

        # Filter appointment types by user
        if not user and self.instance and self.instance.pk:
            user = self.instance.user
        
        if user:
            self.fields['appointment_types'].queryset = AppointmentType.objects.filter(user=user)


        # Aide si règle existante
        if self.instance and self.instance.recurring_rule:
            self.fields['recurring_rule'].help_text = _("Règle iCal existante. Modifier plutôt via les champs ci-dessus.")

        # Pré-remplissage des champs UI à partir de recurring_rule / recurrence_exdates
        if self.instance and (self.instance.recurring_rule or getattr(self.instance, 'recurrence_exdates', None)):
            parsed = _parse_recurrence_block(self.instance.recurring_rule or "")
            # freq
            if parsed['freq']:
                self.fields['recurrence_freq'].initial = parsed['freq']
                self.initial['recurrence_freq'] = parsed['freq']
            # BYDAY
            if parsed['byday']:
                self.fields['recurrence_byweekday'].initial = parsed['byday']
                self.initial['recurrence_byweekday'] = parsed['byday']
            # UNTIL
            if parsed['until_date']:
                self.fields['recurrence_until'].initial = parsed['until_date']
                self.initial['recurrence_until'] = parsed['until_date']
            # EXDATE (priorité au JSONField si présent, sinon parsing)
            ex_from_model = getattr(self.instance, 'recurrence_exdates', None)
            ex_list = ex_from_model if ex_from_model else parsed['exdates']
            if ex_list:
                text = "\n".join(ex_list)
                self.fields['recurrence_exdates_text'].initial = text
                self.initial['recurrence_exdates_text'] = text

        # Cases à cocher en ligne (chips)
        self.fields['recurrence_byweekday'].widget = forms.CheckboxSelectMultiple(choices=WEEKDAYS)
        self.fields['recurrence_byweekday'].widget.attrs.update({'class': 'weekday-checkboxes'})

    def clean(self):
        cleaned = super().clean()
        freq = cleaned.get("recurrence_freq") or "NONE"
        start = cleaned.get("start")
        end = cleaned.get("end")

        if not start or not end:
            return cleaned

        if freq == "NONE":
            cleaned['recurring_rule'] = ""
            cleaned['recurrence_exdates'] = []
            return cleaned

        byday = cleaned.get("recurrence_byweekday") or None
        until = cleaned.get("recurrence_until")

        # parse exdates textarea -> JSON list
        ex_text = cleaned.get("recurrence_exdates_text") or ""
        exdates = []
        for line in ex_text.splitlines():
            s = line.strip()
            if not s:
                continue
            # validation très simple YYYY-MM-DD
            try:
                y, m, d = map(int, s.split("-"))
                exdates.append(f"{y:04d}-{m:02d}-{d:02d}")
            except Exception:
                raise forms.ValidationError(_("EXDATE invalide: %(s)s (format attendu YYYY-MM-DD)") % {"s": s})

        # Si WEEKLY et aucun jour sélectionné => jour de start
        if freq == "WEEKLY" and not byday:
            # 0=lundi -> "MO"
            byday = [WEEKDAY_TOKENS[start.weekday()]]

        # Si DAILY et aucun byday, on garde tous les jours (MO..SU)
        if freq == "DAILY" and not byday:
            byday = WEEKDAY_TOKENS

        # Construit la règle iCal (DTSTART + RRULE + EXDATE...)
        rule = build_rrulestr(
            start=start, freq=freq, until_date=until, byday=byday, exdates=exdates
        )

        cleaned['recurring_rule'] = rule
        cleaned['recurrence_exdates'] = exdates  # <- sera bien sauvé car field inclus en Meta
        return cleaned


class WriteOnlyTextarea(forms.Textarea):
    """
    Textarea qui n'affiche JAMAIS la valeur enregistrée.

    Indispensable ici : `ModelForm` reconstruit `form.initial` depuis
    l'instance (`model_to_dict`), ce qui écrase `field.initial` — neutraliser
    l'initial ne suffit donc pas, il faut couper le rendu de la valeur.
    """

    def format_value(self, value):
        return ""


class GoogleCalendarConfigForm(forms.ModelForm):
    """
    Le JSON de compte de service contient une CLÉ PRIVÉE. Il n'est donc jamais
    réaffiché : le champ est en écriture seule (« write-only »). Laissé vide,
    la clé déjà enregistrée est conservée telle quelle.
    """

    REQUIRED_KEYS = ("type", "project_id", "private_key", "client_email")

    class Meta:
        model = GoogleCalendarConfig
        fields = ['name', 'credentials_json', 'calendar_id', 'daily_digest_enabled', 'daily_digest_hour']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'calendar_id': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': _('ex. contact@mondomaine.fr ou xxxxx@group.calendar.google.com'),
            }),
            'credentials_json': WriteOnlyTextarea(attrs={
                'rows': 8,
                'class': 'form-control',
                'autocomplete': 'off',
                'spellcheck': 'false',
                'placeholder': _('Collez ici le JSON du compte de service Google'),
            }),
        }
        labels = {
            'name': _("Nom du calendrier"),
            'calendar_id': _("ID du calendrier Google"),
            'credentials_json': _("Clé JSON du compte de service"),
            'daily_digest_enabled': _("Recevoir chaque jour le récapitulatif des rendez-vous du lendemain"),
            'daily_digest_hour': _("Heure d'envoi"),
        }
        help_texts = {
            'daily_digest_enabled': _("Envoyé à l'adresse e-mail du propriétaire de ce calendrier."),
            'daily_digest_hour': _("Heure locale du serveur. Le récapitulatif porte sur les rendez-vous du lendemain."),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Écriture seule : on ne renvoie JAMAIS la clé privée au navigateur.
        # (ceinture + bretelles avec WriteOnlyTextarea.format_value)
        self.fields['credentials_json'].required = False
        self.initial['credentials_json'] = ""
        if self.has_existing_credentials():
            self.fields['credentials_json'].help_text = (
                _("Une clé est déjà enregistrée. Laissez ce champ vide pour la conserver, "
                "ou collez un nouveau JSON pour la remplacer.")
            )
        else:
            self.fields['credentials_json'].help_text = (
                _("Collez le contenu du fichier .json téléchargé depuis Google Cloud.")
            )
        self.fields['calendar_id'].help_text = (
            _("Agenda Google → Paramètres du calendrier → « Intégrer l'agenda » → ID de l'agenda.")
        )

    # --- Aides pour le template (jamais la valeur elle-même) ---
    def has_existing_credentials(self):
        return bool(getattr(self.instance, 'credentials_json', None))

    def credentials_summary(self):
        """Infos NON secrètes permettant de vérifier la clé en place."""
        data = getattr(self.instance, 'credentials_json', None) or {}
        if not isinstance(data, dict):
            return None
        return {
            "client_email": data.get("client_email", ""),
            "project_id": data.get("project_id", ""),
            "updated_at": getattr(self.instance, 'updated_at', None),
        }

    def clean_credentials_json(self):
        data = self.cleaned_data.get('credentials_json')

        # Champ laissé vide -> on conserve la clé existante.
        if data in (None, "", {}, []):
            existing = getattr(self.instance, 'credentials_json', None)
            if existing:
                return existing
            return {}

        if not isinstance(data, dict):
            try:
                data = json.loads(data)
            except Exception:
                raise forms.ValidationError(_("Le champ doit contenir un JSON valide."))

        if not isinstance(data, dict):
            raise forms.ValidationError(_("Le JSON attendu est un objet, pas une liste."))

        missing = [k for k in self.REQUIRED_KEYS if not data.get(k)]
        if missing:
            raise forms.ValidationError(
                _("Ce JSON ne ressemble pas à une clé de compte de service Google (champs manquants : %(join)s). Vérifiez que vous avez bien copié le fichier téléchargé lors de la création de la clé, et non le JSON d'un identifiant OAuth.") % {"join": ', '.join(missing)}
            )
        if data.get("type") != "service_account":
            raise forms.ValidationError(
                _("Le type attendu est « service_account ». Vous avez probablement copié "
                "un identifiant OAuth client au lieu d'une clé de compte de service.")
            )
        return data
