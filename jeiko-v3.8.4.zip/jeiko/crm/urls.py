from django.urls import path

from . import views

app_name = "jeiko_crm"

urlpatterns = [
    path("contacts/", views.ListeDesContacts.as_view(), name="liste"),
    path("contacts/nouveau/", views.NouveauContact.as_view(), name="nouveau"),
    path("a-relancer/", views.ARelancer.as_view(), name="relances"),
    path("questionnaires/", views.ProspectsDesQuestionnaires.as_view(), name="prospects_questionnaires"),
    path("contacts/export.csv", views.ExportCsv.as_view(), name="export_csv"),
    path("contacts/import/", views.ImportCsv.as_view(), name="import_csv"),
    path("contacts/<int:pk>/rapprocher/<int:doublon_id>/", views.Rapprocher.as_view(), name="rapprocher"),
    path("contacts/<int:pk>/relance-faite/", views.RelanceFaite.as_view(), name="relance_faite"),
    path("contacts/<int:pk>/", views.FicheDuContact.as_view(), name="fiche"),
    path("contacts/<int:pk>/modifier/", views.ModifierLeContact.as_view(), name="modifier"),
    path("contacts/<int:pk>/export/", views.ExportDuContact.as_view(), name="export"),
    path("contacts/<int:pk>/effacer/", views.EffacerLeContact.as_view(), name="effacer"),
    path("contacts/<int:pk>/notes/", views.AjouterUneNote.as_view(), name="note_ajouter"),
    path("contacts/<int:pk>/notes/<int:note_id>/supprimer/", views.SupprimerUneNote.as_view(), name="note_supprimer"),
    path("contacts/<int:pk>/notes/<int:note_id>/transmettre/", views.TransmettreLeCompteRendu.as_view(),
         name="note_transmettre"),
]
