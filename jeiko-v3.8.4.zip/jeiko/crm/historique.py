"""
L'historique d'un contact, CALCULÉ à la lecture.

Chaque module garde ce qui le regarde ; la fiche le relit. Deux clés relient
une personne à ce qu'elle a fait :

* son **adresse e-mail**, sans tenir compte de la casse : c'est la seule chose
  que portent un rendez-vous pris sans compte, une inscription en liste
  d'attente, un envoi de formulaire ;
* les **comptes** qui lui sont liés (`ProspectLink`) : commandes et formations
  ne connaissent qu'un compte.

Ce que cela implique, et que l'écran dit : c'est l'activité d'une ADRESSE. Qui
réserve en tapant l'adresse d'un autre apparaît sur la fiche de cet autre.
Acceptable pour l'exploitant, qui lit ; jamais vers l'extérieur — rien de ce
module ne part chez le contact ni vers l'API sans passer par un geste humain.

Une ligne d'historique : `Evenement(date, genre, titre, detail, lien)`.
"""
from dataclasses import dataclass, field
from datetime import datetime

from django.apps import apps
from django.db.models import Q
from django.urls import NoReverseMatch, reverse
from django.utils import timezone
from django.utils.translation import gettext as _


@dataclass
class Evenement:
    date: datetime
    genre: str
    titre: str
    detail: list = field(default_factory=list)  # [(libellé, valeur)]
    lien: str = ""


def _modele(label):
    try:
        return apps.get_model(label)
    except LookupError:
        return None


def _lien(nom, *args):
    try:
        return reverse(nom, args=args)
    except NoReverseMatch:
        return ""


def comptes_lies(contact):
    """Les comptes rattachés à la fiche, par lien explicite ou même adresse VÉRIFIÉE."""
    from jeiko.users.models import ProspectLink

    ids = set(ProspectLink.objects.filter(prospect=contact).values_list("user_id", flat=True))
    if contact.email:
        from allauth.account.models import EmailAddress

        ids |= set(EmailAddress.objects.filter(
            email__iexact=contact.email, verified=True).values_list("user_id", flat=True))
    return ids


def rendez_vous_du_contact(contact):
    """Les rendez-vous de cette adresse et des comptes liés, du plus récent au plus ancien."""
    Appointment = _modele("calendars.Appointment")
    email = (contact.email or "").strip()
    filtre = Q(user_id__in=comptes_lies(contact))
    if email:
        filtre |= Q(email__iexact=email)
    return Appointment.objects.filter(filtre).select_related("type").order_by("-start")


def envois_de_formulaire(email):
    """
    Les envois de formulaire qui portent cette adresse dans un champ de type
    e-mail. Le type dit déjà quel champ est l'adresse : pas de reprise de
    données, les envois passés se retrouvent dès le premier jour.
    """
    ContentFormField = _modele("administration_pages.ContentFormField")
    ContentFormSubmission = _modele("administration_pages.ContentFormSubmission")
    if not email or ContentFormField is None:
        return ContentFormSubmission.objects.none() if ContentFormSubmission else []
    filtre = Q()
    for formulaire_id, nom in (ContentFormField.objects.filter(type="email")
                               .values_list("formulaire_id", "name").distinct()):
        filtre |= Q(formulaire_id=formulaire_id, **{f"data__{nom}__iexact": email})
    if not filtre:
        return ContentFormSubmission.objects.none()
    return ContentFormSubmission.objects.filter(filtre).select_related("formulaire")


def historique(contact):
    """Tout ce que le site sait de ce contact, du plus récent au plus ancien."""
    email = (contact.email or "").strip()
    comptes = comptes_lies(contact)
    par_adresse = (lambda champ: Q(**{f"{champ}__iexact": email})) if email else (lambda champ: Q(pk__in=[]))
    evenements = []

    Appointment = _modele("calendars.Appointment")
    if Appointment is not None:
        for rdv in (Appointment.objects.filter(par_adresse("email") | Q(user_id__in=comptes))
                    .select_related("type")):
            evenements.append(Evenement(
                rdv.start, "rendez_vous",
                _("Rendez-vous « %(type)s »") % {"type": rdv.type.name},
                [(libelle, valeur) for libelle, valeur in (
                    (_("Statut"), rdv.get_status_display()), (_("Nom saisi"), rdv.client_name),
                    (_("Téléphone"), rdv.phone), (_("Société"), rdv.company),
                    (_("Fonction"), rdv.job_title), (_("Message"), rdv.message),
                    (_("Recontact accepté"), _("oui") if rdv.contact_consent else _("non")),
                ) if valeur],
                _lien("jeiko_administration_calendars:appointment_detail", rdv.pk),
            ))

    WaitlistEntry = _modele("calendars.WaitlistEntry")
    if WaitlistEntry is not None:
        for entree in (WaitlistEntry.objects.filter(par_adresse("email") | Q(user_id__in=comptes))
                       .select_related("slot__type")):
            evenements.append(Evenement(
                entree.created, "liste_d_attente",
                _("Liste d'attente — %(type)s, le %(date)s") % {
                    "type": entree.slot.type.name,
                    "date": timezone.localtime(entree.slot.start).strftime("%d/%m/%Y %H:%M")},
                [(_("Statut"), entree.get_status_display())],
            ))

    for envoi in envois_de_formulaire(email):
        evenements.append(Evenement(
            envoi.submitted_at, "formulaire",
            _("Formulaire « %(nom)s »") % {"nom": envoi.formulaire.name},
            [(cle, valeur) for cle, valeur in (envoi.data or {}).items() if valeur],
        ))

    ExpertTestData = _modele("questionnaires_expert.ExpertTestData")
    if ExpertTestData is not None:
        for passage in (ExpertTestData.objects.filter(Q(prospect=contact) | Q(user_id__in=comptes))
                        .select_related("test")):
            evenements.append(Evenement(
                passage.created_at, "questionnaire",
                _("Questionnaire « %(titre)s »") % {"titre": passage.test.title},
                lien=_lien("jeiko_administration_questionnaires_expert:test_data_detail", passage.pk),
            ))

    Order = _modele("shop.Order")
    if Order is not None and comptes:
        for commande in Order.objects.filter(user_id__in=comptes):
            evenements.append(Evenement(
                commande.created_at, "commande",
                _("Commande nº %(n)s") % {"n": commande.pk},
                [(_("Montant TTC"), f"{commande.total_ttc} {commande.currency}"),
                 (_("Statut"), commande.get_order_status_display())],
                _lien("jeiko_shop_admin_orders:order_update", commande.pk),
            ))

    CourseEnrollment = _modele("courses.CourseEnrollment")
    if CourseEnrollment is not None and comptes:
        for acces in CourseEnrollment.objects.filter(user_id__in=comptes).select_related("course"):
            evenements.append(Evenement(
                acces.enrolled_at, "formation",
                _("Formation « %(titre)s »") % {"titre": acces.course.title},
            ))

    EmailLog = _modele("emailing.EmailLog")
    if EmailLog is not None:
        from jeiko.emailing import registry

        for envoi in EmailLog.objects.filter(par_adresse("to_email") | Q(user_id__in=comptes)):
            libelle = (registry.get_event(envoi.template_code) or {}).get("label", envoi.template_code)
            evenements.append(Evenement(
                envoi.sent_at or envoi.queued_at, "email",
                _("E-mail « %(libelle)s »") % {"libelle": libelle},
                [(_("Sujet"), envoi.subject), (_("Statut"), envoi.get_status_display())],
            ))

    evenements.sort(key=lambda e: e.date or timezone.now(), reverse=True)
    return evenements
