"""
Les écrans du CRM : la liste des contacts, une fiche, son historique.

Droits : ceux du modèle `Prospect` (voir, ajouter, modifier, supprimer), plus
deux permissions propres — lire les notes, exporter —, qu'aucun rôle par
défaut ne donne.
"""
import json

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.generic import CreateView, DetailView, ListView, UpdateView

from jeiko.listes import ListeRechercheeEtPaginee
from jeiko.questionnaires_expert.models import Prospect

from . import historique, rgpd
from .forms import ContactForm

VOIR = "questionnaires_expert.view_prospect"
AJOUTER = "questionnaires_expert.add_prospect"
MODIFIER = "questionnaires_expert.change_prospect"
SUPPRIMER = "questionnaires_expert.delete_prospect"
EXPORTER = "questionnaires_expert.export_contacts"
NOTES = "questionnaires_expert.view_contact_notes"


class _Acces(LoginRequiredMixin, PermissionRequiredMixin):
    raise_exception = True


@method_decorator(never_cache, name="dispatch")
class ListeDesContacts(_Acces, ListeRechercheeEtPaginee, ListView):
    permission_required = VOIR
    template_name = "crm/admin/liste.html"
    context_object_name = "contacts"
    champs_de_recherche = ("firstname", "lastname", "email", "company", "phone")

    def get_queryset(self):
        qs = Prospect.objects.select_related("owner").order_by("-updated_at", "-date_created")
        statut = self.request.GET.get("statut")
        if statut in Prospect.Statut.values:
            qs = qs.filter(status=statut)
        return self.rechercher(qs)


@method_decorator(never_cache, name="dispatch")
class ProspectsDesQuestionnaires(ListeDesContacts):
    """Les contacts qui ont passé un questionnaire — même écran, même recherche."""

    def get_queryset(self):
        return super().get_queryset().filter(test_datas__isnull=False).distinct()

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["titre"] = _("Prospects des questionnaires")
        return ctx


@method_decorator(never_cache, name="dispatch")
class ExportCsv(ListeDesContacts):
    """La liste telle qu'elle est filtrée à l'écran, en CSV (csv_contacts.py)."""
    permission_required = (VOIR, EXPORTER)
    paginate_by = None

    def get(self, request, *args, **kwargs):
        from .csv_contacts import exporter

        reponse = HttpResponse(exporter(self.get_queryset()), content_type="text/csv; charset=utf-8")
        reponse["Content-Disposition"] = 'attachment; filename="contacts.csv"'
        return reponse


@method_decorator(never_cache, name="dispatch")
class ImportCsv(_Acces, View):
    permission_required = (AJOUTER, EXPORTER)
    template_name = "crm/admin/import.html"

    def get(self, request):
        from django.shortcuts import render
        return render(request, self.template_name)

    def post(self, request):
        from django.shortcuts import render

        from .csv_contacts import ImportImpossible, importer

        fichier = request.FILES.get("fichier")
        if fichier is None:
            messages.error(request, _("Choisissez un fichier CSV."))
            return render(request, self.template_name, status=400)
        try:
            bilan = importer(fichier)
        except ImportImpossible as refus:
            messages.error(request, str(refus))
            return render(request, self.template_name, status=400)
        return render(request, self.template_name, {"bilan": bilan})

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["statuts"] = Prospect.Statut.choices
        ctx["statut"] = self.request.GET.get("statut", "")
        return ctx


@method_decorator(never_cache, name="dispatch")
class FicheDuContact(_Acces, DetailView):
    permission_required = VOIR
    model = Prospect
    template_name = "crm/admin/fiche.html"
    context_object_name = "contact"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["historique"] = historique.historique(self.object)
        if self.request.user.has_perm(NOTES):
            from jeiko.users.models import Comments

            ctx["notes"] = (Comments.objects.filter(prospect=self.object)
                            .select_related("author", "appointment__type").order_by("-date_created"))
            ctx["natures"] = Comments.Nature.choices
            ctx["rendez_vous"] = historique.rendez_vous_du_contact(self.object)
        ctx["doublons"] = (
            Prospect.objects.filter(email__iexact=self.object.email).exclude(pk=self.object.pk)
            if self.object.email else Prospect.objects.none()
        )
        return ctx


class _Edition(_Acces):
    model = Prospect
    form_class = ContactForm
    template_name = "crm/admin/formulaire.html"
    context_object_name = "contact"

    def get_success_url(self):
        return reverse("jeiko_crm:fiche", args=[self.object.pk])


@method_decorator(never_cache, name="dispatch")
class NouveauContact(_Edition, CreateView):
    permission_required = AJOUTER

    def form_valid(self, form):
        form.instance.origin = Prospect.Origine.MANUEL
        return super().form_valid(form)


@method_decorator(never_cache, name="dispatch")
class ModifierLeContact(_Edition, UpdateView):
    permission_required = MODIFIER


@method_decorator(never_cache, name="dispatch")
class ExportDuContact(_Acces, View):
    """Droit d'accès d'une personne sans compte : sa fiche et son historique, en JSON."""
    permission_required = EXPORTER

    def get(self, request, pk):
        contact = get_object_or_404(Prospect, pk=pk)
        reponse = HttpResponse(
            json.dumps(rgpd.exporter(contact), ensure_ascii=False, indent=2),
            content_type="application/json",
        )
        reponse["Content-Disposition"] = f'attachment; filename="contact-{contact.pk}.json"'
        return reponse


@method_decorator(never_cache, name="dispatch")
class EffacerLeContact(_Acces, View):
    """Droit à l'effacement : POST seulement, après la confirmation de la fiche."""
    permission_required = SUPPRIMER

    def post(self, request, pk):
        contact = get_object_or_404(Prospect, pk=pk)
        resume = rgpd.effacer(contact, acteur=request.user, motif=request.POST.get("motif", "")[:200])
        messages.success(request, _(
            "Contact effacé : %(fiches)s fiche(s), %(rdv)s rendez-vous anonymisé(s), "
            "%(envois)s envoi(s) de formulaire supprimé(s)."
        ) % {"fiches": resume.get("fiches_supprimees", 0),
             "rdv": resume.get("rendez_vous_anonymises", 0),
             "envois": resume.get("envois_de_formulaire_supprimes", 0)})
        if resume.get("comptes_lies_non_touches"):
            messages.warning(request, _(
                "Un compte utilisateur porte aussi cette personne : il s'efface depuis sa "
                "fiche utilisateur."))
        return redirect("jeiko_crm:liste")


# --------------------------------------------------------------------------- #
#  Notes et comptes rendus (CRM-04, CRM-05) — voir comptes_rendus.py
# --------------------------------------------------------------------------- #
@method_decorator(never_cache, name="dispatch")
class AjouterUneNote(_Acces, View):
    permission_required = NOTES

    def post(self, request, pk):
        from jeiko.calendars.models import Appointment
        from jeiko.users.models import Comments

        from . import comptes_rendus

        contact = get_object_or_404(Prospect, pk=pk)
        texte = (request.POST.get("texte") or "").strip()
        nature = request.POST.get("nature")
        if not texte or nature not in Comments.Nature.values:
            messages.error(request, _("Une note a besoin d'un texte."))
            return redirect("jeiko_crm:fiche", pk=pk)
        # Seulement un rendez-vous de CE contact : l'identifiant vient du navigateur.
        rdv_id = request.POST.get("rendez_vous")
        rdv = None
        if rdv_id:
            rdv = historique.rendez_vous_du_contact(contact).filter(pk=rdv_id).first()
        comptes_rendus.ajouter(contact, request.user, texte, nature, rdv)
        return redirect(reverse("jeiko_crm:fiche", args=[pk]) + "#notes")


@method_decorator(never_cache, name="dispatch")
class SupprimerUneNote(_Acces, View):
    """L'auteur supprime sa note ; un superutilisateur, toute note."""
    permission_required = NOTES

    def post(self, request, pk, note_id):
        from jeiko.users.models import Comments

        note = get_object_or_404(Comments, pk=note_id, prospect_id=pk)
        if note.author_id != request.user.pk and not request.user.is_superuser:
            messages.error(request, _("Seul son auteur peut supprimer une note."))
        else:
            note.delete()
        return redirect(reverse("jeiko_crm:fiche", args=[pk]) + "#notes")


@method_decorator(never_cache, name="dispatch")
class TransmettreLeCompteRendu(_Acces, View):
    permission_required = (NOTES, MODIFIER)

    def post(self, request, pk, note_id):
        from jeiko.users.models import Comments

        from . import comptes_rendus

        note = get_object_or_404(Comments, pk=note_id, prospect_id=pk)
        envoye, erreur = comptes_rendus.transmettre(note, request.user)
        if envoye:
            messages.success(request, _("Compte rendu envoyé à %(email)s.") % {"email": note.shared_to})
        else:
            messages.error(request, _("Le compte rendu n'est pas parti : %(erreur)s") % {"erreur": erreur})
        return redirect(reverse("jeiko_crm:fiche", args=[pk]) + "#notes")


# --------------------------------------------------------------------------- #
#  Relances (point 5 des propositions) : une prochaine action par contact
# --------------------------------------------------------------------------- #
def contacts_a_relancer(jusqu_au=None):
    """
    Les contacts dont la prochaine action est due, la plus ancienne d'abord,
    avec `recontact` : la personne a-t-elle accepté d'être recontactée (case
    de la réservation) ? Relancer est une autre finalité que réserver ; la
    liste le dit plutôt que de le taire.
    """
    from django.db.models import Exists, OuterRef
    from django.utils import timezone

    from jeiko.calendars.models import Appointment

    jusqu_au = jusqu_au or timezone.localdate()
    return (
        Prospect.objects.filter(next_action_on__lte=jusqu_au)
        .annotate(recontact=Exists(Appointment.objects.filter(
            email__iexact=OuterRef("email"), contact_consent=True)))
        .select_related("owner").order_by("next_action_on", "pk")
    )


@method_decorator(never_cache, name="dispatch")
class ARelancer(_Acces, ListView):
    permission_required = VOIR
    template_name = "crm/admin/relances.html"
    context_object_name = "contacts"
    paginate_by = 100

    def get_queryset(self):
        qs = contacts_a_relancer()
        if self.request.GET.get("moi"):
            qs = qs.filter(owner=self.request.user)
        return qs


@method_decorator(never_cache, name="dispatch")
class RelanceFaite(_Acces, View):
    """Vide la prochaine action ; la garde en note, pour l'historique de la fiche."""
    permission_required = MODIFIER

    def post(self, request, pk):
        from jeiko.users.models import Comments

        from . import comptes_rendus

        contact = get_object_or_404(Prospect, pk=pk)
        if contact.next_action_on:
            if request.user.has_perm(NOTES):
                comptes_rendus.ajouter(
                    contact, request.user,
                    _("Relance faite (prévue le %(date)s) : %(action)s") % {
                        "date": contact.next_action_on.strftime("%d/%m/%Y"),
                        "action": contact.next_action or "—"},
                    Comments.Nature.NOTE)
            contact.next_action_on, contact.next_action = None, ""
            contact.save(update_fields=["next_action_on", "next_action", "updated_at"])
        retour = request.POST.get("retour")
        if retour == "fiche":
            return redirect("jeiko_crm:fiche", pk=pk)
        return redirect("jeiko_crm:relances")


@method_decorator(never_cache, name="dispatch")
class Rapprocher(_Acces, View):
    """Rapprocher un doublon (même adresse) dans la fiche qu'on regarde."""
    permission_required = (MODIFIER, SUPPRIMER)
    template_name = "crm/admin/rapprocher.html"

    def _fiches(self, pk, doublon_id):
        gardee = get_object_or_404(Prospect, pk=pk)
        doublon = get_object_or_404(Prospect, pk=doublon_id, email__iexact=gardee.email or "\0")
        if doublon.pk == gardee.pk:
            from django.http import Http404
            raise Http404
        return gardee, doublon

    def get(self, request, pk, doublon_id):
        from django.shortcuts import render

        gardee, doublon = self._fiches(pk, doublon_id)
        return render(request, self.template_name, {"gardee": gardee, "doublon": doublon})

    def post(self, request, pk, doublon_id):
        from .rapprochement import rapprocher

        gardee, doublon = self._fiches(pk, doublon_id)
        rapprocher(gardee, doublon, request.user)
        messages.success(request, _("Fiches rapprochées."))
        return redirect("jeiko_crm:fiche", pk=gardee.pk)

