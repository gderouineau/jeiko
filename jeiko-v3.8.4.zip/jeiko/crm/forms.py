from django import forms
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _

from jeiko.questionnaires_expert.models import Prospect


class ContactForm(forms.ModelForm):
    """La fiche d'un contact, telle que l'exploitant la tient."""

    tags = forms.CharField(
        label=_("Étiquettes"), required=False,
        help_text=_("Séparées par des virgules : « devis, salon 2026 »."),
    )

    class Meta:
        model = Prospect
        fields = ["firstname", "lastname", "email", "phone", "company", "job_title",
                  "status", "owner", "tags", "next_action_on", "next_action"]
        widgets = {"next_action_on": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d")}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Un responsable est quelqu'un qui travaille sur le site, pas un client.
        self.fields["owner"].queryset = get_user_model().objects.filter(
            is_staff=True, is_active=True).order_by("first_name", "last_name", "username")
        self.initial["tags"] = ", ".join(self.instance.tags or [])

    def clean_tags(self):
        vues, propres = set(), []
        for brut in (self.cleaned_data.get("tags") or "").split(","):
            tag = brut.strip()[:50]
            if tag and tag.casefold() not in vues:
                vues.add(tag.casefold())
                propres.append(tag)
        return propres

    def clean(self):
        donnees = super().clean()
        if not any(donnees.get(c) for c in ("firstname", "lastname", "email", "company")):
            raise forms.ValidationError(_("Renseignez au moins un nom, une adresse e-mail ou une société."))
        return donnees
