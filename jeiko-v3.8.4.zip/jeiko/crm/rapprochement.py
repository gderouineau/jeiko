"""
Rapprocher deux fiches de la même personne — un geste HUMAIN.

Les doublons sont la règle, pas l'accident : une saisie publique n'est jamais
vérifiée, et deux noms différents à la même adresse font deux fiches
(`rattachement.py`). Seul l'exploitant sait qu'il s'agit de la même personne.

Rapprocher `doublon` dans `gardee` :
* ce que `gardee` n'a pas, elle le prend au doublon ; rien de ce qu'elle a
  n'est écrasé ;
* passages de questionnaire, notes et liens vers un compte la rejoignent ;
* étiquettes réunies ; la date de création la plus ancienne l'emporte ;
* adresse vérifiée si l'une des deux l'était — même adresse, même preuve ;
* le doublon disparaît, et une note dit qui a rapproché quoi, quand.
"""
from django.db import transaction

CHAMPS_COMPLETES = ("firstname", "lastname", "phone", "company", "job_title", "next_action", "owner_id")


@transaction.atomic
def rapprocher(gardee, doublon, acteur=None):
    from jeiko.users.models import Comments, ProspectLink

    if gardee.pk == doublon.pk:
        raise ValueError("Une fiche ne se rapproche pas d'elle-même.")

    for champ in CHAMPS_COMPLETES:
        if not getattr(gardee, champ) and getattr(doublon, champ):
            setattr(gardee, champ, getattr(doublon, champ))
    if not gardee.next_action_on and doublon.next_action_on:
        gardee.next_action_on = doublon.next_action_on
    gardee.tags = list(dict.fromkeys([*(gardee.tags or []), *(doublon.tags or [])]))
    gardee.email_verified = gardee.email_verified or doublon.email_verified
    if doublon.date_created and (not gardee.date_created or doublon.date_created < gardee.date_created):
        gardee.date_created = doublon.date_created

    doublon.test_datas.update(prospect=gardee)
    Comments.objects.filter(prospect=doublon).update(prospect=gardee)
    deja = set(ProspectLink.objects.filter(prospect=gardee).values_list("user_id", flat=True))
    ProspectLink.objects.filter(prospect=doublon).exclude(user_id__in=deja).update(prospect=gardee)

    nom_du_doublon = doublon.nom_complet
    doublon.delete()
    gardee.save()
    Comments.objects.create(
        prospect=gardee, author=acteur, kind=Comments.Nature.NOTE,
        text=f"Fiche « {nom_du_doublon} » rapprochée de celle-ci.",
    )
    return gardee
