"""
Export et import CSV des contacts.

Export — pour Excel, qui est ce qu'ouvre un indépendant :
* séparateur `;` et UTF-8 avec BOM : l'Excel français coupe sinon chaque ligne
  à la virgule et affiche « Ã© » à la place des accents ;
* une cellule qui commence par `=`, `+`, `-`, `@` (ou une tabulation) est
  préfixée d'une apostrophe : sans quoi Excel l'EXÉCUTE comme une formule. Un
  nom saisi dans un formulaire public (`=HYPERLINK(…)`) deviendrait un lien
  piégé dans le fichier de l'exploitant.

Import — le fichier que l'exploitant a sous la main :
* `;` ou `,`, détecté (`csv.Sniffer`) ; UTF-8 avec ou sans BOM, sinon Windows-1252 ;
* colonnes reconnues par leur nom, en français ou en anglais ;
* une adresse déjà connue complète sa fiche sans rien écraser ; une nouvelle
  fait une fiche d'origine « import », jamais « vérifiée » ;
* bornes : 2 Mo, 5 000 lignes — au-delà, c'est un autre outil.
"""
import csv
import io

from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.utils.translation import gettext as _

TAILLE_MAX = 2 * 1024 * 1024
LIGNES_MAX = 5000

COLONNES = [
    ("prenom", "firstname", "Prénom"),
    ("nom", "lastname", "Nom"),
    ("email", "email", "E-mail"),
    ("telephone", "phone", "Téléphone"),
    ("societe", "company", "Société"),
    ("fonction", "job_title", "Fonction"),
    ("statut", "status", "Statut"),
    ("etiquettes", "tags", "Étiquettes"),
    ("prochaine_action_le", "next_action_on", "Prochaine action le"),
    ("prochaine_action", "next_action", "Prochaine action"),
]

#: Noms d'en-tête acceptés à l'import → clé de COLONNES.
ALIAS = {
    "prenom": "prenom", "prénom": "prenom", "firstname": "prenom", "first name": "prenom", "first_name": "prenom",
    "nom": "nom", "lastname": "nom", "last name": "nom", "last_name": "nom", "name": "nom",
    "email": "email", "e-mail": "email", "courriel": "email", "mail": "email", "adresse e-mail": "email",
    "telephone": "telephone", "téléphone": "telephone", "phone": "telephone", "tel": "telephone", "tél": "telephone",
    "societe": "societe", "société": "societe", "entreprise": "societe", "company": "societe",
    "fonction": "fonction", "poste": "fonction", "job title": "fonction", "title": "fonction",
    "etiquettes": "etiquettes", "étiquettes": "etiquettes", "tags": "etiquettes",
}

DANGEREUX = ("=", "+", "-", "@", "\t", "\r")


def _neutraliser(valeur):
    texte = "" if valeur is None else str(valeur)
    return "'" + texte if texte.startswith(DANGEREUX) else texte


def exporter(contacts):
    """Le CSV des contacts donnés, prêt à servir (str, BOM compris)."""
    tampon = io.StringIO()
    tampon.write("﻿")
    ecrivain = csv.writer(tampon, delimiter=";", quoting=csv.QUOTE_MINIMAL)
    ecrivain.writerow([libelle for _cle, _champ, libelle in COLONNES] + ["Origine", "Créé le"])
    for c in contacts:
        ligne = []
        for _cle, champ, _libelle in COLONNES:
            valeur = getattr(c, champ)
            if champ == "tags":
                valeur = ", ".join(valeur or [])
            elif champ == "status":
                valeur = c.get_status_display()
            elif champ == "next_action_on":
                valeur = valeur.strftime("%d/%m/%Y") if valeur else ""
            ligne.append(_neutraliser(valeur))
        ligne += [_neutraliser(c.get_origin_display()),
                  c.date_created.strftime("%d/%m/%Y") if c.date_created else ""]
        ecrivain.writerow(ligne)
    return tampon.getvalue()


class _PointVirgule(csv.excel):
    """Le défaut quand la détection échoue : l'Excel français."""
    delimiter = ";"


class ImportImpossible(Exception):
    """Le fichier ne peut pas être lu (message pour l'exploitant)."""


def _decoder(brut):
    for encodage in ("utf-8-sig", "cp1252"):
        try:
            return brut.decode(encodage)
        except UnicodeDecodeError:
            continue
    raise ImportImpossible(_("Encodage illisible : enregistrez le fichier en UTF-8."))


def importer(fichier):
    """Rend {"crees": n, "completes": n, "ignores": n, "erreurs": [(ligne, raison)]}."""
    from jeiko.questionnaires_expert.models import Prospect

    if fichier.size > TAILLE_MAX:
        raise ImportImpossible(_("Fichier trop lourd (2 Mo au plus)."))
    texte = _decoder(fichier.read())
    try:
        dialecte = csv.Sniffer().sniff(texte[:4096], delimiters=";,\t")
    except csv.Error:
        dialecte = _PointVirgule
    lecteur = csv.DictReader(io.StringIO(texte), dialect=dialecte)
    entetes = {nom: ALIAS.get((nom or "").strip().lower()) for nom in (lecteur.fieldnames or [])}
    if "email" not in entetes.values():
        raise ImportImpossible(_("Aucune colonne « e-mail » : c'est elle qui relie une ligne à une personne."))

    bilan = {"crees": 0, "completes": 0, "ignores": 0, "erreurs": []}
    champ_de = {cle: champ for cle, champ, _ in COLONNES}
    for numero, ligne in enumerate(lecteur, start=2):
        if numero - 1 > LIGNES_MAX:
            bilan["erreurs"].append((numero, _("au-delà de %(n)s lignes, le reste est ignoré") % {"n": LIGNES_MAX}))
            break
        valeurs = {}
        for nom, cle in entetes.items():
            if cle:
                valeur = (ligne.get(nom) or "").strip().lstrip("'")
                if valeur:
                    valeurs[cle] = valeur
        email = valeurs.pop("email", "").lower()
        try:
            validate_email(email)
        except ValidationError:
            bilan["ignores"] += 1
            bilan["erreurs"].append((numero, _("adresse e-mail absente ou invalide")))
            continue
        tags = [t.strip()[:50] for t in valeurs.pop("etiquettes", "").split(",") if t.strip()]
        champs = {champ_de[cle]: valeur[:200] for cle, valeur in valeurs.items() if cle in champ_de}
        # Statut et prochaine action ne s'importent pas : ils se décident ici.
        champs.pop("status", None)
        champs.pop("next_action_on", None)
        if "phone" in champs:
            champs["phone"] = champs["phone"][:20]

        fiche = Prospect.objects.filter(email__iexact=email).order_by("id").first()
        if fiche is None:
            Prospect.objects.create(email=email, origin=Prospect.Origine.IMPORT, tags=tags, **champs)
            bilan["crees"] += 1
            continue
        vides = [champ for champ, valeur in champs.items() if not getattr(fiche, champ)]
        for champ in vides:
            setattr(fiche, champ, champs[champ])
        nouvelles = [t for t in tags if t not in (fiche.tags or [])]
        if nouvelles:
            fiche.tags = [*(fiche.tags or []), *nouvelles]
            vides.append("tags")
        if vides:
            fiche.save(update_fields=vides + ["updated_at"])
            bilan["completes"] += 1
        else:
            bilan["ignores"] += 1
    return bilan
