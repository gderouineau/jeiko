# -*- coding: utf-8 -*-
"""
Export des données personnelles d'un utilisateur (RGPD art. 15 « droit d'accès »
et art. 20 « portabilité »).

`build_user_export(user)` renvoie un dict JSON-sérialisable rassemblant l'empreinte
de données rattachée au compte, à travers toutes les apps (compte, profil, adresses,
consentements, commandes, formations, rendez-vous, questionnaires, journal sécurité).

Principes :
- On n'exporte QUE les données de la personne concernée, jamais celles de tiers.
- Le mot de passe (même haché) n'est jamais inclus.
- Tolérant : une app non installée n'interrompt pas l'export (`_modele`).
  Une erreur de base, elle, remonte : un export incomplet présenté comme
  complet serait pire qu'un export refusé.
"""
from __future__ import annotations

import logging
from decimal import Decimal

from django.apps import apps
from django.db import transaction
from django.utils import timezone

logger = logging.getLogger(__name__)


def _modele(label):
    """Le modèle `app.Modele`, ou None si l'app n'est pas installée sur ce site.

    Remplace les `try: import … except Exception` : seule l'ABSENCE de l'app
    est tolérée. Une erreur réelle — base indisponible, champ renommé — n'est
    plus confondue avec « rien à traiter ».
    """
    try:
        return apps.get_model(label)
    except LookupError:
        return None


def _dt(value):
    return value.isoformat() if value else None


def _num(value):
    # Decimal → str (JSON n'a pas de décimal exact) ; None reste None.
    if value is None:
        return None
    if isinstance(value, Decimal):
        return str(value)
    return value


def _account_section(user):
    return {
        "id": user.pk,
        "username": user.get_username(),
        "email": getattr(user, "email", "") or "",
        "first_name": getattr(user, "first_name", "") or "",
        "last_name": getattr(user, "last_name", "") or "",
        "is_active": bool(getattr(user, "is_active", True)),
        "date_joined": _dt(getattr(user, "date_joined", None)),
        "last_login": _dt(getattr(user, "last_login", None)),
    }


def _profile_section(user):
    profile = getattr(user, "profile", None)
    if profile is None:
        return None
    return {
        "bio": profile.bio or "",
        "phone_number": profile.phone_number or "",
        "date_of_birth": _dt(profile.date_of_birth),
        "location": profile.location or "",
        "website": profile.website or "",
        "avatar": profile.avatar.url if profile.avatar else None,
    }


def _addresses_section(user):
    out = []
    for a in user.addresses.all():
        out.append({
            "type": a.get_address_type_display(),
            "is_default": a.is_default,
            "name": a.name,
            "street_address": a.street_address,
            "street_address_2": a.street_address_2,
            "city": a.city,
            "postal_code": a.postal_code,
            "country": a.country,
            "phone": a.phone,
            "created_at": _dt(getattr(a, "created_at", None)),
        })
    return out


def _consents_section(user):
    out = []
    for c in user.consents.all().order_by("granted_at"):
        out.append({
            "type": c.get_consent_type_display(),
            "granted": c.granted,
            "granted_at": _dt(c.granted_at),
            "version_text": c.version_text,
            "source": c.source,
            "ip_address": c.ip_address,
        })
    return out


def _marketing_section(user):
    prefs = getattr(user, "marketing_prefs", None)
    if prefs is None:
        return None
    return {
        "email_optin": prefs.email_optin,
        "sms_optin": prefs.sms_optin,
        "whatsapp_optin": prefs.whatsapp_optin,
        "frequency": prefs.get_frequency_display(),
        "topics": prefs.topics,
    }


def _cookie_consents_section(user):
    CookieConsent = _modele("cookies.CookieConsent")
    if CookieConsent is None:
        return []
    out = []
    for c in CookieConsent.objects.filter(user=user).order_by("-created_at"):
        out.append({
            "created_at": _dt(c.created_at),
            "choices": c.choices,
            "policy_version": c.policy_version,
            "source": c.get_source_display(),
            "is_latest": c.is_latest,
        })
    return out


def _orders_section(user):
    Order = _modele("shop.Order")
    if Order is None:
        return []
    out = []
    for o in Order.objects.filter(user=user).prefetch_related("lines").order_by("-created_at"):
        out.append({
            "id": o.pk,
            "created_at": _dt(o.created_at),
            "order_status": o.order_status,
            "payment_status": o.payment_status,
            "currency": o.currency,
            "total_ht": _num(o.total_ht),
            "total_tva": _num(o.total_tva),
            "total_ttc": _num(o.total_ttc),
            "billing_name": o.billing_name,
            "billing_address": o.billing_address,
            "shipping_name": o.shipping_name,
            "shipping_address": o.shipping_address,
            "lines": [
                {
                    "label": l.label,
                    "sku": l.sku,
                    "quantity": l.quantity,
                    "unit_price_ht": _num(l.unit_price_ht),
                    "tax_rate": _num(l.tax_rate),
                }
                for l in o.lines.all()
            ],
        })
    return out


def _enrollments_section(user):
    CourseEnrollment = _modele("courses.CourseEnrollment")
    if CourseEnrollment is None:
        return []
    out = []
    qs = CourseEnrollment.objects.filter(user=user).select_related("course").order_by("-enrolled_at")
    for e in qs:
        out.append({
            "course": getattr(e.course, "title", None) or str(e.course_id),
            "status": e.get_status_display(),
            "progress_percentage": _num(e.progress_percentage),
            "enrolled_at": _dt(e.enrolled_at),
            "completed_at": _dt(e.completed_at),
            "access_expires_at": _dt(e.access_expires_at),
        })
    return out


def _appointments_section(user):
    Appointment = _modele("calendars.Appointment")
    if Appointment is None:
        return []
    out = []
    qs = Appointment.objects.filter(user=user).select_related("type").order_by("-start")
    for a in qs:
        out.append({
            "type": getattr(a.type, "name", None),
            "start": _dt(a.start),
            "end": _dt(a.end),
            "status": a.get_status_display(),
            "places": a.places,
            "email": a.email,
            "client_name": a.client_name,
            "contact_consent": getattr(a, "contact_consent", None),
        })
    return out


def _questionnaires_section(user):
    ExpertTestData = _modele("questionnaires_expert.ExpertTestData")
    if ExpertTestData is None:
        return []
    out = []
    qs = ExpertTestData.objects.filter(user=user).select_related("test", "result_profile").order_by("-created_at")
    for d in qs:
        out.append({
            "test": getattr(d.test, "title", None),
            "created_at": _dt(d.created_at),
            "result_profile": getattr(d.result_profile, "name", None),
            "data": d.data,  # réponses, scores, profils (déjà les données de la personne)
        })
    return out


def _security_section(user):
    events = [
        {
            "event_type": e.get_event_type_display(),
            "ip_address": e.ip_address,
            "occured_at": _dt(e.occured_at),
        }
        for e in user.security_events.all().order_by("-occured_at")[:200]
    ]
    sessions = [
        {
            "first_seen": _dt(s.first_seen),
            "last_seen": _dt(s.last_seen),
            "ip_last": s.ip_last,
            "is_active": s.is_active,
        }
        for s in user.sessions.all().order_by("-last_seen")
    ]
    return {"events": events, "sessions": sessions}


def build_user_export(user) -> dict:
    """Rassemble toutes les données personnelles rattachées à `user`."""
    return {
        "export_metadata": {
            "generated_at": timezone.now().isoformat(),
            "subject": {
                "id": user.pk,
                "username": user.get_username(),
                "email": getattr(user, "email", "") or "",
            },
            "notice": (
                "Export des données personnelles au titre du droit d'accès "
                "(RGPD art. 15) et à la portabilité (art. 20). Le mot de passe "
                "(même haché) et les données concernant des tiers ne sont pas inclus."
            ),
        },
        "account": _account_section(user),
        "profile": _profile_section(user),
        "addresses": _addresses_section(user),
        "consents": _consents_section(user),
        "marketing_preferences": _marketing_section(user),
        "cookie_consents": _cookie_consents_section(user),
        "orders": _orders_section(user),
        "course_enrollments": _enrollments_section(user),
        "appointments": _appointments_section(user),
        "questionnaires": _questionnaires_section(user),
        "security": _security_section(user),
    }


def export_filename(user) -> str:
    stamp = timezone.now().strftime("%Y%m%d")
    return f"export-donnees-{user.get_username()}-{stamp}.json"


# ---------------------------------------------------------------------------
# Effacement / droit à l'oubli (RGPD art. 17)
# ---------------------------------------------------------------------------
#
# Principe : on N'EFFACE PAS en dur les enregistrements sous obligation légale
# de conservation (commandes/factures : 10 ans). On les ANONYMISE (on retire le
# nom et l'adresse, on garde les montants et dates pour la comptabilité). Tout
# le reste des données personnelles est supprimé, et le compte est désactivé et
# vidé de ses identifiants — la ligne User est conservée (coquille anonymisée)
# pour ne pas casser les liens des enregistrements retenus.

#: Ce que devient, à l'effacement, chaque table rattachée à un compte.
#:
#: `test_rgpd_erase` refuse une table liée au compte qui manquerait ici : un
#: modèle ajouté demain doit être pensé au moment où on l'écrit, pas découvert
#: le jour où quelqu'un demande l'effacement. C'est ainsi que les adresses
#: e-mail d'allauth, les clés de connexion et le journal d'envoi ont survécu
#: des mois à un effacement qui se disait complet.
TRAITEMENT_A_L_EFFACEMENT = {
    # Supprimés
    "users.Profile": "supprimé, avatar compris (sur disque)",
    "users.Address": "supprimé",
    "users.MarketingPreference": "supprimé",
    "users.Consent": "supprimé",
    "users.UserSession": "supprimé",
    "users.Notification": "supprimé",
    "users.NotificationChannel": "supprimé",
    "users.TwoFactorDevice": "supprimé",
    "users.RoleAssignment": "supprimé (un compte effacé n'a plus de droits)",
    "account.EmailAddress": "supprimé",
    "socialaccount.SocialAccount": "supprimé (jetons compris)",
    "mfa.Authenticator": "supprimé (clés, passkeys, application, codes de secours)",
    "shop.Cart": "supprimé",
    "courses.CourseEnrollment": "supprimé",
    "courses.QuizAttempt": "supprimé",
    "questionnaires_expert.ExpertTestData": "supprimé",
    "questionnaires_expert.UserTestAccess": "supprimé",
    "cookies.CookieConsent": "supprimé",
    "calendars.GoogleCalendarConfig": "supprimé (identifiants Google)",
    "users.ProspectLink": "supprimé, fiche prospect anonymisée",
    # Anonymisés : conservés pour une obligation ou pour l'historique
    "shop.Order": "anonymisé (comptabilité : 10 ans)",
    "calendars.Appointment": "anonymisé (historique de l'agenda)",
    "calendars.WaitlistEntry": "anonymisé",
    "emailing.EmailLog": "anonymisé (destinataire, sujet, contenu)",
    "users.SecurityEvent": "anonymisé (adresse IP, navigateur) ; l'événement reste",
    "users.Comments": "supprimé : une note au sujet de la personne est une donnée de la personne",
    "users.Comments.author": "détaché : l'auteur d'une note sur un tiers ; la note reste à ce tiers",
    # Conservés : pointent vers la coquille anonymisée, sans donnée personnelle
    "users.RolePermission": "conservé (auteur d'un droit accordé)",
    "users.RoleAssignment.assigned_by": "conservé (auteur d'une attribution)",
    "calendars.AppointmentType": "conservé (agenda du praticien : le supprimer "
                                 "emporterait les rendez-vous des clients)",
    "calendars.Availability": "conservé (agenda du praticien)",
    "courses.Course": "conservé (auteur de la formation)",
    "courses.CourseEnrollment.granted_by": "conservé (auteur d'un accès)",
    "questionnaires_expert.UserTestAccess.granted_by": "conservé (auteur d'un accès)",
    "shop.ProductStockMovement": "conservé (auteur d'un mouvement de stock)",
    "admin.LogEntry": "conservé (actions d'administration)",
    "jeiko_agents.Agent": "conservé (compte technique, pas une personne)",
    "questionnaires_expert.Prospect.owner": "détaché (SET_NULL) : responsable d'une "
                                            "fiche du CRM, qui est celle d'un tiers",
    "jeiko_agents.CodeOAuth.autorise_par": "conservé (auteur d'une autorisation OAuth, P-04)",
    "jeiko_agents.Agent.cree_par": "conservé (auteur d'un agent)",
    "jeiko_agents.AgentToken": "conservé (auteur d'un jeton)",
}


def _anonymize_orders(user):
    Order = _modele("shop.Order")
    if Order is None:
        return 0
    return Order.objects.filter(user=user).update(
        billing_name="", billing_address="", shipping_name="", shipping_address="",
    )


def _anonymize_appointments(user):
    Appointment = _modele("calendars.Appointment")
    if Appointment is None:
        return 0
    return Appointment.objects.filter(user=user).update(
        email="", client_name="", contact_consent=False, contact_consent_at=None,
    )


def _supprimer(label, user):
    """Supprime les lignes de `label` rattachées au compte ; 0 si l'app manque."""
    modele = _modele(label)
    if modele is None:
        return 0
    return modele.objects.filter(user=user).delete()[0]


def _anonymiser_les_envois(user=None, email=""):
    """Retire destinataire, sujet et contenu du journal d'envoi.

    Par le compte ET par l'adresse : un e-mail envoyé avant la création du
    compte, ou sans lien vers lui, porte la même adresse.
    """
    from django.db.models import Q

    EmailLog = _modele("emailing.EmailLog")
    if EmailLog is None:
        return 0
    filtre = Q()
    if user is not None:
        filtre |= Q(user=user)
    if email:
        filtre |= Q(to_email__iexact=email)
    if not filtre:
        return 0
    return EmailLog.objects.filter(filtre).update(to_email="", subject="", context={})


@transaction.atomic
def _effacer_en_base(user, *, actor, reason):
    """Tout ce qui est en base, en une transaction : tout ou rien.

    R-02 — ce bloc avalait six erreurs (`except Exception: pass`). Sous
    PostgreSQL, une requête en échec dans une transaction l'invalide : la suite
    échouait de toute façon, ou — pire — l'erreur était silencieuse et le compte
    déclaré effacé alors que des données restaient. Désormais une erreur annule
    TOUT et remonte : l'écran dit que l'effacement n'a pas eu lieu, et on peut
    recommencer. Un effacement partiel qui se croit complet est le seul
    résultat inacceptable.
    """
    from .models import (
        Profile, Address, MarketingPreference, Consent, UserSession,
        Notification, NotificationChannel, TwoFactorDevice, RoleAssignment,
        ProspectLink, Comments, SecurityEvent, SecurityEventType,
    )

    old_email = getattr(user, "email", "") or ""
    summary = {}

    # 1) Anonymisation (rétention légale ou historique)
    summary["orders_anonymized"] = _anonymize_orders(user)
    summary["appointments_anonymized"] = _anonymize_appointments(user)
    WaitlistEntry = _modele("calendars.WaitlistEntry")
    if WaitlistEntry is not None:
        WaitlistEntry.objects.filter(user=user).update(email="", client_name="")
    summary["email_logs_anonymized"] = _anonymiser_les_envois(user, old_email)
    SecurityEvent.objects.filter(user=user).update(ip_address=None, user_agent="")

    # 2) Suppression des données personnelles restantes
    #
    # Les avatars sont relevés AVANT de supprimer les profils, et retirés du
    # disque après la transaction (voir `erase_user_data`) : un fichier effacé
    # ne revient pas si la base, elle, annule.
    avatars = [
        profil.avatar.name
        for profil in Profile.objects.filter(user=user)
        if profil.avatar
    ]
    Profile.objects.filter(user=user).delete()
    summary["addresses_deleted"] = Address.objects.filter(user=user).delete()[0]
    MarketingPreference.objects.filter(user=user).delete()
    summary["consents_deleted"] = Consent.objects.filter(user=user).delete()[0]
    UserSession.objects.filter(user=user).delete()
    Notification.objects.filter(user=user).delete()
    NotificationChannel.objects.filter(user=user).delete()
    TwoFactorDevice.objects.filter(user=user).delete()
    RoleAssignment.objects.filter(user=user).delete()
    # Commentaires rédigés par l'utilisateur (au sujet de tiers) : on détache
    # l'auteur plutôt que de casser le fil des autres.
    # `user` est la personne concernée : ses notes partent avec elle. Celles
    # qu'elle a ÉCRITES sur d'autres (`author`) restent à ces autres.
    Comments.objects.filter(user=user).delete()
    Comments.objects.filter(author=user).update(author=None)

    # Connexion : adresses allauth, comptes sociaux, clés et passkeys.
    summary["email_addresses_deleted"] = _supprimer("account.EmailAddress", user)
    _supprimer("socialaccount.SocialAccount", user)
    summary["authenticators_deleted"] = _supprimer("mfa.Authenticator", user)

    summary["questionnaires_deleted"] = _supprimer("questionnaires_expert.ExpertTestData", user)
    _supprimer("questionnaires_expert.UserTestAccess", user)
    _supprimer("courses.QuizAttempt", user)
    summary["enrollments_deleted"] = _supprimer("courses.CourseEnrollment", user)
    _supprimer("cookies.CookieConsent", user)
    _supprimer("shop.Cart", user)
    _supprimer("calendars.GoogleCalendarConfig", user)

    # Prospects rattachés : on anonymise leurs coordonnées puis on retire le lien.
    for link in ProspectLink.objects.filter(user=user).select_related("prospect"):
        p = link.prospect
        if p:
            p.firstname, p.lastname, p.email, p.phone = "—", "—", "", ""
            p.save(update_fields=["firstname", "lastname", "email", "phone"])
    ProspectLink.objects.filter(user=user).delete()

    # 3) Vidage + désactivation du compte (ligne conservée)
    user.username = f"deleted-{user.pk}"
    user.email = ""
    user.first_name = ""
    user.last_name = ""
    user.is_active = False
    user.set_unusable_password()
    user.save()

    # 4) Trace d'audit (preuve que l'effacement a eu lieu, sans donnée personnelle).
    # Obligatoire : sans elle, rien ne prouve que la demande a été honorée.
    SecurityEvent.objects.create(
        user=user,
        event_type=SecurityEventType.ACCOUNT_ERASED,
        extra={"reason": reason, "actor_id": getattr(actor, "pk", None)},
    )

    return old_email, summary, avatars


def _retirer_les_avatars(user, noms):
    """Retire les avatars du disque. Renvoie le nombre de fichiers restés.

    Une photographie de personne identifiée qui survit sous /media/ est le
    manquement le plus visible qu'on puisse opposer à un effacement. Un fichier
    déjà absent n'est pas un échec : c'est le résultat recherché.
    """
    from .models import Profile

    stockage = Profile._meta.get_field("avatar").storage
    restes = 0
    for nom in noms:
        try:
            stockage.delete(nom)
        except Exception:
            restes += 1
            logger.exception(
                "Effacement RGPD du compte %s : l'avatar %s n'a pas pu être "
                "supprimé du disque et reste servi par /media/.", user.pk, nom,
            )
    return restes


def erase_user_data(user, *, actor=None, reason="") -> tuple[str, dict]:
    """
    Efface les données personnelles de `user`. Renvoie (ancien_email, résumé).

    - Anonymise les enregistrements conservés (commandes, rendez-vous, journal
      d'envoi, journal de sécurité) — voir `TRAITEMENT_A_L_EFFACEMENT`.
    - Supprime le reste, y compris les moyens de connexion.
    - Désactive et vide le compte (identifiants), en conservant la ligne.

    Lève si l'effacement en base échoue : rien n'a alors été modifié. Un avatar
    resté sur le disque ne l'annule pas (la base est effacée), mais il est
    journalisé et compté dans `résumé["avatars_restes"]`.
    """
    old_email, summary, avatars = _effacer_en_base(user, actor=actor, reason=reason)
    restes = _retirer_les_avatars(user, avatars)
    summary["avatars_deleted"] = len(avatars) - restes
    summary["avatars_restes"] = restes
    return old_email, summary


def notify_account_deactivated(old_email) -> bool:
    """Envoie l'e-mail `account_deactivated`, puis efface sa trace.

    Ne bloque jamais l'effacement : il a déjà eu lieu. Mais un échec se
    journalise — il n'était jusqu'ici qu'un `pass`. Et l'envoi lui-même écrit
    l'adresse dans le journal d'envoi : on l'y retire aussitôt, sans quoi
    l'effacement laissait derrière lui… l'adresse effacée.
    """
    if not old_email:
        return False
    try:
        from jeiko.emailing.services import send_email
        envoye, _ = send_email(
            "account_deactivated",
            to=old_email,
            context={"date_heure": timezone.now().strftime("%d/%m/%Y %H:%M")},
        )
    except Exception:
        logger.exception("Effacement RGPD : l'e-mail de confirmation n'a pas pu partir.")
        envoye = False
    _anonymiser_les_envois(email=old_email)
    return bool(envoye)
