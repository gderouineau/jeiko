# jeiko/staticfiles.py
"""
Minification du CSS au moment de `collectstatic`.

Le problème que ce module résout
--------------------------------
Le paquet livrait deux exemplaires de chaque feuille de style : la source
(`main.css`) et une version minifiée écrite à la main (`main.min.css`). Les
gabarits chargeaient la première en `DEBUG`, la seconde en production.

Rien ne garantissait qu'elles disent la même chose. Au constat du 17/08/2026,
`main.min.css` datait de neuf mois et `menu.min.css` de onze : **175 sélecteurs
sur 370 manquaient en production**. L'éditeur affichait la mise en forme à
jour, le visiteur celle de novembre 2025 — c'est l'origine des écarts observés
entre l'éditeur et le site réel.

Le décalage était structurel : minifier était un geste manuel, donc oublié.

Ce que fait ce module
---------------------
La minification devient une étape de `collectstatic`. Les gabarits ne
référencent plus qu'un seul fichier — la source — et c'est le déploiement qui
produit la version compacte. **Il ne peut plus y avoir deux versions
divergentes, puisqu'il n'y a plus qu'un fichier écrit à la main.**

Pourquoi ici, et pas ailleurs
-----------------------------
*Pas un cron* : `ManifestStaticFilesStorage` appose une empreinte au nom de
chaque fichier, et nginx les sert en `immutable` pour un an. Réécrire un
fichier après coup produirait un cache empoisonné, sans moyen de le purger.

*Pas à la publication* : ce serait un fichier de plus à maintenir dans le
paquet, donc le même risque de divergence sous une autre forme.

`collectstatic` est le seul endroit où la minification précède le calcul de
l'empreinte : celle-ci porte alors sur le contenu réellement servi. Et
l'étape se déclenche à chaque `jeiko-client-update`, sur chaque site, sans
rien ajouter à l'installeur.

En développement (`DEBUG=True`), `collectstatic` n'intervient pas : les
sources sont servies telles quelles, lisibles et déboguables. C'est le
comportement voulu.

Précautions
-----------
- L'échec d'un fichier n'interrompt pas le déploiement : on journalise et on
  garde l'original. Une feuille non minifiée reste une feuille valide.
- Les fichiers déjà nommés `.min.css` sont laissés tels quels : ce sont des
  dépendances tierces livrées compactées.
- L'opération porte sur la copie déposée dans `STATIC_ROOT`, jamais sur les
  sources du paquet.
"""

import logging
import os

from django.conf import settings
from django.contrib.staticfiles.storage import ManifestStaticFilesStorage

logger = logging.getLogger("jeiko")


class MinifyingManifestStaticFilesStorage(ManifestStaticFilesStorage):
    """`ManifestStaticFilesStorage`, précédé d'une passe de minification CSS."""

    #: Extensions traitées. Le JavaScript du paquet est déjà livré compacté et
    #: n'a pas montré de dérive ; l'ajouter demanderait un minifieur JS, donc
    #: une dépendance de plus, pour un gain sans commune mesure.
    EXTENSIONS = (".css",)

    def post_process(self, paths, dry_run=False, **options):
        """
        Laisse Django empreindre et réécrire les URL, PUIS minifie le résultat.

        L'ordre est imposé par Django, et l'inverse ne fonctionne pas :
        `HashedFilesMixin` relit chaque fichier depuis le stockage **d'origine**
        — celui du finder, dans le paquet — et non depuis `STATIC_ROOT`.
        Minifier la copie déposée dans `STATIC_ROOT` avant lui n'a donc aucun
        effet sur le fichier réellement servi ; c'est la source intacte qui est
        empreinte et recopiée.

        On minifie donc après coup, sur les fichiers produits. L'empreinte
        continue de dériver de la source : elle change dès que la source
        change, ce qui est tout ce qu'on lui demande pour invalider les caches.
        """
        resultats = []
        for resultat in super().post_process(paths, dry_run=dry_run, **options):
            resultats.append(resultat)
            yield resultat

        # Exécuté une fois le générateur épuisé, donc après que Django a écrit
        # ses fichiers empreints et son manifeste.
        if not dry_run:
            self._minifier_sorties()

    # -- interne ------------------------------------------------------------

    def _minifier_sorties(self):
        """
        Minifie les feuilles de style présentes dans `STATIC_ROOT`.

        On balaie l'arborescence plutôt que la liste des chemins d'entrée :
        Django produit des fichiers intermédiaires au fil de ses passes de
        réécriture d'URL, et seul le résultat sur disque dit ce qui sera servi.
        """
        compress = self._charger_minifieur()
        if compress is None:
            return

        racine = getattr(settings, "STATIC_ROOT", None)
        if not racine or not os.path.isdir(racine):
            logger.warning(
                "STATIC_ROOT introuvable : minification CSS ignorée."
            )
            return

        traites = gagnes = 0
        for dossier, _sous_dossiers, fichiers in os.walk(racine):
            for fichier in fichiers:
                if not self._a_minifier(fichier):
                    continue
                gain = self._minifier_un(os.path.join(dossier, fichier), compress)
                if gain is not None:
                    traites += 1
                    gagnes += gain

        if traites:
            logger.info(
                "Minification CSS : %s fichier(s), %s octets économisés.",
                traites, gagnes,
            )

    def _charger_minifieur(self):
        """
        Retourne la fonction de compression, ou None si elle manque.

        Absente, on sert les sources : le site reste correct, simplement plus
        lourd. Un déploiement ne doit pas échouer pour une question de poids.
        """
        try:
            from csscompressor import compress
            return compress
        except ImportError:
            logger.warning(
                "csscompressor n'est pas installé : le CSS sera servi non "
                "minifié. Il figure dans requirements.txt — un `pip install "
                "-r requirements.txt` rétablit la compression."
            )
            return None

    def _a_minifier(self, chemin):
        chemin_bas = chemin.lower()
        if not chemin_bas.endswith(self.EXTENSIONS):
            return False
        # Déjà compacté à la source (dépendances tierces).
        return not chemin_bas.endswith(".min.css")

    def _minifier_un(self, absolu, compress):
        """Minifie un fichier en place. Retourne les octets gagnés, ou None."""
        chemin = os.path.relpath(absolu, getattr(settings, "STATIC_ROOT", ""))
        try:
            with open(absolu, encoding="utf-8") as f:
                avant = f.read()
            apres = compress(avant)
        except Exception:
            logger.exception(
                "Minification impossible pour %s — le fichier est servi tel "
                "quel.", chemin,
            )
            return None

        # Un minifieur qui renvoie du vide sur une source non vide s'est trompé :
        # écrire ce résultat effacerait la feuille de style du site.
        if avant.strip() and not apres.strip():
            logger.error(
                "Minification vide pour %s — original conservé.", chemin,
            )
            return None

        try:
            with open(absolu, "w", encoding="utf-8") as f:
                f.write(apres)
        except OSError:
            logger.exception("Écriture impossible pour %s.", chemin)
            return None

        return len(avant) - len(apres)
