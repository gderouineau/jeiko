"""
Champs chiffrés au repos, adaptés aux conventions du package.

Pourquoi ne pas utiliser `encrypted_fields` directement
-------------------------------------------------------
Sa classe de base transforme toute valeur vide en `NULL` :

    def get_prep_value(self, value):
        if value:
            return self.f.encrypt(...)
        return None          # <- même pour ""

Or les champs concernés ici sont déclarés `blank=True` **sans** `null=True` :
leur valeur vide est la chaîne vide, et la colonne est NOT NULL. Utiliser la
bibliothèque telle quelle fait donc échouer tout enregistrement dont le secret
n'est pas renseigné — c'est-à-dire le cas courant d'une passerelle de paiement
à moitié configurée.

Passer les champs en `null=True` « pour que ça marche » aurait introduit deux
valeurs vides distinctes (`NULL` et `""`) sur des champs que tout le code teste
par `if gateway.secret_key`. On préfère conserver la convention du package et
adapter le champ.

Ce que fait le chiffrement, et ce qu'il ne fait pas
---------------------------------------------------
La clé est dérivée de `SECRET_KEY` (PBKDF2), qui vit dans le `.env` en 0600 et
jamais en base. Cela protège contre la **lecture de la base sans le fichier** :
sauvegarde égarée, disque de VPS revendu, accès en lecture seule, injection SQL.

Cela ne protège **pas** contre quelqu'un qui a déjà la main sur le serveur — il
lit le `.env` aussi — ni contre un administrateur du back-office, à qui les
écrans déchiffrent par construction.

⚠️ Changer `SECRET_KEY` rend les secrets illisibles. En cas de rotation,
renseigner l'ancienne valeur dans `SECRET_KEY_FALLBACKS` le temps de
réenregistrer les écrans concernés : la bibliothèque essaie chaque clé.
"""

from encrypted_fields.fields import (
    EncryptedCharField as _EncryptedCharField,
    EncryptedJSONField as _EncryptedJSONField,
    EncryptedTextField as _EncryptedTextField,
)


class _VideRestVideMixin:
    """Conserve la chaîne vide au lieu de la transformer en NULL."""

    def get_prep_value(self, value):
        prepare = super().get_prep_value(value)
        if prepare is None and not self.null:
            return ""
        return prepare


class EncryptedCharField(_VideRestVideMixin, _EncryptedCharField):
    pass


class EncryptedTextField(_VideRestVideMixin, _EncryptedTextField):
    pass


class EncryptedJSONField(_EncryptedJSONField):
    """
    Le JSON vide est `{}`, pas la chaîne vide : la règle ci-dessus ne
    s'applique pas, et un dict vide n'a de toute façon aucun secret à protéger.
    """

    def get_prep_value(self, value):
        prepare = super().get_prep_value(value)
        if prepare is None and not self.null:
            return "{}"
        return prepare
