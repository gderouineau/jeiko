# jeiko/calendars/tests.py
"""
Tests de contrôle d'accès du module calendars.

Couvrent les correctifs de sécurité :
  * annulation client : jeton UUID au lieu de l'identifiant séquentiel ;
  * cloisonnement entre gestionnaires (un praticien ne voit que son calendrier) ;
  * supervision réservée au super-administrateur ;
  * clé de compte de service Google jamais renvoyée au navigateur.
"""
import uuid
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .models import Appointment, AppointmentType, Availability, GoogleCalendarConfig, Slot

User = get_user_model()

CALENDAR_PERMS = [
    "view_appointmenttype", "add_appointmenttype", "change_appointmenttype", "delete_appointmenttype",
    "view_availability", "add_availability", "change_availability", "delete_availability",
    "view_appointment", "add_appointment", "change_appointment", "delete_appointment",
    "view_googlecalendarconfig", "change_googlecalendarconfig",
]


def grant_calendar_perms(user):
    perms = Permission.objects.filter(
        content_type__app_label="calendars", codename__in=CALENDAR_PERMS
    )
    user.user_permissions.add(*perms)
    return user


class CalendarFixtureMixin:
    """Deux gestionnaires indépendants, chacun avec son calendrier complet."""

    def make_provider(self, username):
        user = User.objects.create_user(username=username, password="pwd12345")
        grant_calendar_perms(user)

        appt_type = AppointmentType.objects.create(
            name=f"Séance {username}", user=user, duration=timedelta(hours=1)
        )
        start = (timezone.now() + timedelta(days=2)).replace(minute=0, second=0, microsecond=0)
        availability = Availability.objects.create(
            user=user, start=start, end=start + timedelta(hours=2)
        )
        availability.appointment_types.add(appt_type)  # m2m_changed -> generate_slots

        slot = Slot.objects.filter(availability=availability).order_by("start").first()
        appointment = Appointment.objects.create(
            type=appt_type, slot=slot, start=slot.start, end=slot.end,
            email=f"client-{username}@example.com",
        )
        return {
            "user": user, "type": appt_type, "availability": availability,
            "slot": slot, "appointment": appointment,
        }

    def setUp(self):
        super().setUp()
        self.alice = self.make_provider("alice")
        self.bob = self.make_provider("bob")
        self.root = User.objects.create_superuser(username="root", password="pwd12345")


# Le contournement `@override_settings(DEBUG=True)` a été retiré : il évitait un
# {% url 'home' %} présent dans une ancienne page 404 du projet, route qu'aucun
# site JEIKO ne déclare. La page 404 du paquet pointe désormais sur
# `jeiko_pages:root_page`, qui se résout toujours — le test peut donc tourner
# avec DEBUG=False, c'est-à-dire dans les conditions de la production.
class PublicCancellationTests(CalendarFixtureMixin, TestCase):
    """Le lien d'annulation client ne doit plus être devinable."""

    def test_cancel_url_uses_uuid_not_pk(self):
        appt = self.alice["appointment"]
        url = appt.get_public_cancel_url()
        self.assertIn(str(appt.public_token), url)
        self.assertNotIn(f"/{appt.pk}/", url)

    def test_unknown_token_returns_404(self):
        url = reverse("jeiko_calendars_public:appointment_cancel",
                      kwargs={"token": uuid.uuid4()})
        self.assertEqual(self.client.get(url).status_code, 404)

    def test_client_can_cancel_with_valid_token(self):
        appt = self.alice["appointment"]
        slot = appt.slot
        slot.remaining_places = 0
        slot.is_available = False
        slot.save(update_fields=["remaining_places", "is_available"])

        url = appt.get_public_cancel_url()
        self.assertEqual(self.client.get(url).status_code, 200)

        resp = self.client.post(url)
        self.assertEqual(resp.status_code, 200)
        # La ligne est conservée avec le statut « annulé » (historique, no-show).
        appt.refresh_from_db()
        self.assertEqual(appt.status, Appointment.Status.CANCELLED)

        slot.refresh_from_db()
        self.assertEqual(slot.remaining_places, 1)
        self.assertTrue(slot.is_available)

    def test_past_appointment_cannot_be_cancelled_by_client(self):
        appt = self.alice["appointment"]
        past = timezone.now() - timedelta(days=1)
        Appointment.objects.filter(pk=appt.pk).update(start=past, end=past + timedelta(hours=1))
        appt.refresh_from_db()

        resp = self.client.post(appt.get_public_cancel_url())
        self.assertEqual(resp.status_code, 200)
        appt.refresh_from_db()
        self.assertEqual(appt.status, Appointment.Status.CONFIRMED)

    def test_admin_cancel_url_requires_login(self):
        appt = self.alice["appointment"]
        url = reverse("jeiko_administration_calendars:appointment_cancel", kwargs={"pk": appt.pk})
        resp = self.client.post(url)
        self.assertNotEqual(resp.status_code, 200)
        appt.refresh_from_db()
        self.assertEqual(appt.status, Appointment.Status.CONFIRMED)

    def test_provider_cannot_cancel_someone_elses_appointment(self):
        self.client.force_login(self.alice["user"])
        target = self.bob["appointment"]
        url = reverse("jeiko_administration_calendars:appointment_cancel", kwargs={"pk": target.pk})
        self.assertEqual(self.client.post(url).status_code, 404)
        target.refresh_from_db()
        self.assertEqual(target.status, Appointment.Status.CONFIRMED)

    def test_provider_can_cancel_own_appointment(self):
        self.client.force_login(self.alice["user"])
        appt = self.alice["appointment"]
        url = reverse("jeiko_administration_calendars:appointment_cancel", kwargs={"pk": appt.pk})
        self.assertEqual(self.client.post(url).status_code, 302)
        appt.refresh_from_db()
        self.assertEqual(appt.status, Appointment.Status.CANCELLED)


@override_settings(DEBUG=True)  # cf. commentaire ci-dessus sur le template 404
class OwnershipIsolationTests(CalendarFixtureMixin, TestCase):
    """Un gestionnaire ne doit atteindre que son propre calendrier."""

    def setUp(self):
        super().setUp()
        self.client.force_login(self.alice["user"])

    def test_cannot_open_other_provider_availability(self):
        url = reverse("jeiko_administration_calendars:availability_edit",
                      kwargs={"pk": self.bob["availability"].pk})
        self.assertEqual(self.client.get(url).status_code, 404)

    def test_cannot_delete_other_provider_availability(self):
        url = reverse("jeiko_administration_calendars:availability_delete",
                      kwargs={"pk": self.bob["availability"].pk})
        self.assertEqual(self.client.post(url).status_code, 404)
        self.assertTrue(Availability.objects.filter(pk=self.bob["availability"].pk).exists())

    def test_cannot_open_other_provider_appointment_type(self):
        url = reverse("jeiko_administration_calendars:appointmenttype_update",
                      kwargs={"pk": self.bob["type"].pk})
        self.assertEqual(self.client.get(url).status_code, 404)

    def test_cannot_read_other_provider_appointment_detail(self):
        url = reverse("jeiko_administration_calendars:appointment_detail",
                      kwargs={"pk": self.bob["appointment"].pk})
        self.assertEqual(self.client.get(url).status_code, 404)

    def test_cannot_edit_other_provider_appointment(self):
        url = reverse("jeiko_administration_calendars:appointment_update",
                      kwargs={"pk": self.bob["appointment"].pk})
        self.assertEqual(self.client.get(url).status_code, 404)

    def test_appointment_form_rejects_other_provider_slot(self):
        """Un POST forgé ne doit pas rattacher le RDV au créneau d'un autre."""
        appt = self.alice["appointment"]
        url = reverse("jeiko_administration_calendars:appointment_update", kwargs={"pk": appt.pk})
        resp = self.client.post(url, {
            "type": self.alice["type"].pk,
            "slot": self.bob["slot"].pk,          # <- créneau d'un autre gestionnaire
            "email": "x@example.com",
            "start": appt.start.strftime("%Y-%m-%d %H:%M:%S"),
            "end": appt.end.strftime("%Y-%m-%d %H:%M:%S"),
        })
        self.assertEqual(resp.status_code, 200)   # formulaire réaffiché avec erreur
        self.assertIn("slot", resp.context["form"].errors)
        appt.refresh_from_db()
        self.assertEqual(appt.slot_id, self.alice["slot"].pk)

    def test_lists_only_show_own_objects(self):
        resp = self.client.get(reverse("jeiko_administration_calendars:availability_list"))
        ids = set(resp.context["availabilities"].values_list("id", flat=True))
        self.assertEqual(ids, {self.alice["availability"].pk})

        resp = self.client.get(reverse("jeiko_administration_calendars:appointment_list_upcoming"))
        ids = {a.pk for a in resp.context["appointments"]}
        self.assertEqual(ids, {self.alice["appointment"].pk})

    def test_cannot_open_other_provider_google_config(self):
        url = reverse("jeiko_administration_calendars:google_config_user",
                      kwargs={"user_id": self.bob["user"].pk})
        self.assertEqual(self.client.get(url).status_code, 403)

    def test_supervision_page_is_forbidden_to_provider(self):
        url = reverse("jeiko_administration_calendars:google_configs_all")
        self.assertEqual(self.client.get(url).status_code, 403)

    def test_staff_without_superuser_is_not_a_supervisor(self):
        staff = self.alice["user"]
        staff.is_staff = True
        staff.save(update_fields=["is_staff"])
        url = reverse("jeiko_administration_calendars:google_configs_all")
        self.assertEqual(self.client.get(url).status_code, 403)


class SupervisorTests(CalendarFixtureMixin, TestCase):
    """Le super-administrateur, lui, voit et gère tous les calendriers."""

    def setUp(self):
        super().setUp()
        self.client.force_login(self.root)

    def test_supervision_page_accessible(self):
        resp = self.client.get(reverse("jeiko_administration_calendars:google_configs_all"))
        self.assertEqual(resp.status_code, 200)

    def test_sees_every_provider_availability(self):
        resp = self.client.get(reverse("jeiko_administration_calendars:availability_list"))
        ids = set(resp.context["availabilities"].values_list("id", flat=True))
        self.assertEqual(ids, {self.alice["availability"].pk, self.bob["availability"].pk})
        self.assertTrue(resp.context["is_calendar_supervisor"])

    def test_can_open_another_provider_google_config(self):
        url = reverse("jeiko_administration_calendars:google_config_user",
                      kwargs={"user_id": self.bob["user"].pk})
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.context["target_user"], self.bob["user"])
        self.assertFalse(resp.context["is_own_calendar"])


class GoogleCredentialsTests(TestCase):
    """La clé privée du compte de service ne doit jamais repartir vers le client."""

    CREDS = {
        "type": "service_account",
        "project_id": "demo-projet",
        "private_key": "-----BEGIN PRIVATE KEY-----SUPERSECRET-----END PRIVATE KEY-----",
        "client_email": "robot@demo-projet.iam.gserviceaccount.com",
    }

    def setUp(self):
        self.user = grant_calendar_perms(
            User.objects.create_user(username="carol", password="pwd12345")
        )
        self.config = GoogleCalendarConfig.objects.create(
            user=self.user, name="Primary", credentials_json=self.CREDS,
            calendar_id="carol@example.com",
        )
        self.client.force_login(self.user)
        self.url = reverse("jeiko_administration_calendars:google_config")

    def test_private_key_is_never_rendered(self):
        resp = self.client.get(self.url)
        self.assertEqual(resp.status_code, 200)
        body = resp.content.decode()
        self.assertNotIn("SUPERSECRET", body)
        self.assertNotIn("BEGIN PRIVATE KEY", body)
        # ... mais l'identité non secrète reste affichée pour vérification
        self.assertIn("robot@demo-projet.iam.gserviceaccount.com", body)

    def test_empty_field_keeps_existing_key(self):
        resp = self.client.post(self.url, {
            "name": "Agenda pro", "credentials_json": "", "calendar_id": "carol@example.com",
            # Champ ajouté par la migration 0016 (récapitulatif quotidien) :
            # obligatoire au formulaire, il doit figurer dans le POST.
            "daily_digest_hour": 20,
        })
        self.assertEqual(resp.status_code, 302)
        self.config.refresh_from_db()
        self.assertEqual(self.config.credentials_json, self.CREDS)
        self.assertEqual(self.config.name, "Agenda pro")

    def test_oauth_client_json_is_rejected(self):
        resp = self.client.post(self.url, {
            "name": "Primary",
            "credentials_json": '{"web": {"client_id": "123", "client_secret": "abc"}}',
            "calendar_id": "carol@example.com",
        })
        self.assertEqual(resp.status_code, 200)
        self.assertIn("credentials_json", resp.context["form"].errors)
        self.config.refresh_from_db()
        self.assertEqual(self.config.credentials_json, self.CREDS)
