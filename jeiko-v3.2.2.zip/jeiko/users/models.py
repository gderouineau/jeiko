from django.conf import settings
from django.db import models
from jeiko.encrypted import EncryptedTextField
from django.utils import timezone
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission

# Si tes imports actuels sont corrects, on les garde
from jeiko.questionnaires_expert.models import ExpertTestData, Prospect

User = get_user_model()


# =========================
#  Mixins & bases
# =========================

class TimestampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True, db_index=True)

    class Meta:
        abstract = True


# =========================
#  Rôles & Permissions
# =========================

class Role(TimestampedModel):
    """
    Rôle métier lisible par l'humain : Admin, Coach, Client, etc.
    On mappe ensuite le rôle vers des permissions Django (auth.Permission).
    """
    name = models.CharField(max_length=150, unique=True)
    slug = models.SlugField(max_length=150, unique=True, db_index=True)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    is_protected = models.BooleanField(
        default=False,
        help_text="Empêche la suppression/édition critique (ex. Administrateur)."
    )
    is_superrole = models.BooleanField(
        default=False,
        help_text="Accorde TOUTES les permissions du site (super-administrateur "
                  "applicatif), sans nécessiter le statut superuser Django."
    )

    permissions = models.ManyToManyField(
        Permission,
        through='RolePermission',
        related_name='roles'
    )

    class Meta:
        verbose_name = "Rôle"
        verbose_name_plural = "Rôles"
        ordering = ["name"]

    def __str__(self):
        return self.name


class RolePermission(TimestampedModel):
    """
    Jointure explicite pour tracer qui a accordé quoi, quand.
    """
    role = models.ForeignKey(Role, on_delete=models.CASCADE, related_name='role_permissions')
    permission = models.ForeignKey(Permission, on_delete=models.CASCADE, related_name='permission_roles')
    granted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='granted_role_permissions'
    )
    granted_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "Permission de rôle"
        verbose_name_plural = "Permissions de rôle"
        unique_together = (('role', 'permission'),)
        indexes = [
            models.Index(fields=['role']),
            models.Index(fields=['permission']),
        ]

    def __str__(self):
        return f"{self.role} → {self.permission.codename}"


class RoleAssignment(TimestampedModel):
    """
    Assignation d'un rôle à un utilisateur.
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='role_assignments')
    role = models.ForeignKey(Role, on_delete=models.CASCADE, related_name='assignments')
    assigned_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='assigned_roles'
    )
    assigned_at = models.DateTimeField(default=timezone.now)
    expires_at = models.DateTimeField(null=True, blank=True)
    notes = models.CharField(max_length=255, blank=True)

    class Meta:
        verbose_name = "Assignation de rôle"
        verbose_name_plural = "Assignations de rôle"
        unique_together = (('user', 'role'),)
        ordering = ['-assigned_at']
        indexes = [
            models.Index(fields=['user']),
            models.Index(fields=['role']),
        ]

    def __str__(self):
        return f"{self.user} ↔ {self.role}"

    @property
    def is_expired(self):
        return bool(self.expires_at and self.expires_at <= timezone.now())


class AdminPermission(models.Model):
    """
    Modèle « porteur » de permissions métier qui ne correspondent à aucun
    CRUD d'un modèle concret : accès à l'administration, actions de
    configuration, gestion des rôles. Aucune table n'est créée
    (``managed = False``) : seul le jeu de permissions nous intéresse.

    On y accède ensuite via ``users.<codename>`` (ex. ``users.access_admin``).
    """
    class Meta:
        managed = False
        default_permissions = ()
        verbose_name = "Permission d'administration"
        verbose_name_plural = "Permissions d'administration"
        permissions = [
            ("access_admin", "Accéder à l'espace d'administration"),
            ("config_edit_site", "Modifier la configuration du site"),
            ("config_edit_mail", "Modifier les réglages e-mail"),
            ("config_edit_fonts", "Modifier les polices"),
            ("config_clear_cache", "Vider le cache"),
            ("assign_role", "Assigner / retirer des rôles aux utilisateurs"),
        ]


# =========================
#  Social Login – Provider Config (allauth)
# =========================

class ProviderChoices(models.TextChoices):
    GOOGLE = "google", "Google"
    APPLE = "apple", "Apple"
    FACEBOOK = "facebook", "Facebook"
    TWITTER = "twitter", "X / Twitter"
    LINKEDIN = "linkedin", "LinkedIn"
    MICROSOFT = "microsoft", "Microsoft"
    GITHUB = "github", "GitHub"
    OTHER = "other", "Autre"


class ProviderConfig(TimestampedModel):
    """
    Configuration centralisée des providers OAuth/OIDC.
    Une vue/commande sync écrira/maj les SocialApp d'allauth à partir d'ici.
    """
    provider = models.CharField(max_length=32, choices=ProviderChoices.choices, db_index=True)
    label = models.CharField(max_length=128, blank=True, help_text="Nom lisible (ex. Google PROD).")
    client_id = models.TextField(help_text="ID client. Peut être chiffré via une lib dédiée.")
    # Chiffré au repos (le help_text le recommandait sans que ce soit fait).
    client_secret = EncryptedTextField(help_text="Secret client, chiffré au repos.")
    enabled = models.BooleanField(default=False)
    callback_url = models.URLField(blank=True, help_text="Optionnel si tu veux l'afficher en admin pour vérif.")
    extra_config = models.JSONField(default=dict, blank=True)

    class Meta:
        verbose_name = "Provider OAuth/OIDC"
        verbose_name_plural = "Providers OAuth/OIDC"
        unique_together = (('provider', 'label'),)
        indexes = [models.Index(fields=['provider', 'enabled'])]

    def __str__(self):
        state = "activé" if self.enabled else "désactivé"
        return f"{self.get_provider_display()} [{self.label or 'default'}] ({state})"


# =========================
#  Sécurité : 2FA, Audit, Sessions
# =========================

class TwoFactorType(models.TextChoices):
    EMAIL = "email", "Code par e-mail"
    TOTP = "totp", "TOTP (App d'authent.)"
    WEBAUTHN = "webauthn", "WebAuthn (Clé/FIDO2)"


class TwoFactorDevice(TimestampedModel):
    """
    Dispositif 2FA lié à un utilisateur.

    Seul le type `EMAIL` est implémenté : un code à usage unique envoyé à
    l'adresse du compte, vérifié après le mot de passe. Les types `TOTP` et
    `WEBAUTHN` restent déclarés pour ne pas fermer la porte, mais aucun code ne
    les honore — un dispositif de ce type est ignoré à la connexion.

    Le code en cours n'est jamais stocké en clair : seule son empreinte l'est,
    au même titre qu'un mot de passe. Une fuite de la base ne donne donc pas
    les codes en circulation.
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='twofactor_devices')
    device_type = models.CharField(max_length=16, choices=TwoFactorType.choices, db_index=True, default=TwoFactorType.EMAIL)
    name = models.CharField(max_length=150, blank=True, help_text="Nom convivial (ex. iPhone Guillaume).")
    # Vide pour le type e-mail : l'adresse du compte tient lieu de destination.
    secret_or_credential = EncryptedTextField(blank=True, default="", help_text="Secret TOTP ou credential WebAuthn (id, publicKey). Inutilisé pour le type e-mail.")
    confirmed_at = models.DateTimeField(null=True, blank=True)
    last_used_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    # Codes de secours (hashés) si tu choisis d'en fournir :
    backup_codes_hashes = models.JSONField(default=list, blank=True, help_text="Liste des hash des codes de secours.")

    # --- Défi en cours (type e-mail) ---
    challenge_hash = models.CharField(max_length=256, blank=True, default="", editable=False, verbose_name="Empreinte du code en cours")
    challenge_expires_at = models.DateTimeField(null=True, blank=True, editable=False)
    challenge_sent_at = models.DateTimeField(null=True, blank=True, editable=False)
    challenge_attempts = models.PositiveSmallIntegerField(default=0, editable=False, verbose_name="Essais sur le code en cours")

    class Meta:
        verbose_name = "Dispositif 2FA"
        verbose_name_plural = "Dispositifs 2FA"
        indexes = [models.Index(fields=['user', 'device_type', 'is_active'])]

    def __str__(self):
        return f"{self.get_device_type_display()} – {self.user}"


class SecurityEventType(models.TextChoices):
    LOGIN_SUCCESS = "login_success", "Connexion réussie"
    LOGIN_FAILURE = "login_failure", "Connexion échouée"
    LOGOUT = "logout", "Déconnexion"
    PASSWORD_RESET_REQUEST = "password_reset_request", "Demande de réinitialisation"
    PASSWORD_CHANGED = "password_changed", "Mot de passe modifié"
    EMAIL_CHANGED = "email_changed", "Email modifié"
    ROLE_CHANGED = "role_changed", "Rôle modifié"
    PERMISSION_CHANGED = "permission_changed", "Permissions modifiées"
    TWOFA_ENABLED = "twofa_enabled", "2FA activée"
    TWOFA_DISABLED = "twofa_disabled", "2FA désactivée"
    ACCOUNT_ERASED = "account_erased", "Compte effacé (RGPD)"


class SecurityEvent(TimestampedModel):
    """
    Journal d’événements sécurité/audit.
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='security_events')
    event_type = models.CharField(max_length=64, choices=SecurityEventType.choices, db_index=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    occured_at = models.DateTimeField(default=timezone.now, db_index=True)
    extra = models.JSONField(default=dict, blank=True)

    class Meta:
        verbose_name = "Événement de sécurité"
        verbose_name_plural = "Événements de sécurité"
        ordering = ['-occured_at']
        indexes = [models.Index(fields=['event_type', 'occured_at'])]

    def __str__(self):
        return f"[{self.occured_at:%Y-%m-%d %H:%M}] {self.get_event_type_display()} – {self.user or 'anonymous'}"


class UserSession(TimestampedModel):
    """
    Suivi des sessions/appareils de l'utilisateur (pour 'déconnecter partout').
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sessions')
    # EMPREINTE de la clé de session, jamais la clé elle-même. Stockée en clair,
    # elle serait recopiable dans un cookie par quiconque a le droit de lire ce
    # journal — l'écran censé permettre de fermer les sessions ouvertes aurait
    # offert le moyen de les usurper.
    session_key_hash = models.CharField(max_length=64, db_index=True, verbose_name="Empreinte de session")
    first_seen = models.DateTimeField(default=timezone.now)
    last_seen = models.DateTimeField(default=timezone.now, db_index=True)
    ip_last = models.GenericIPAddressField(null=True, blank=True)
    user_agent_last = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Session utilisateur"
        verbose_name_plural = "Sessions utilisateur"
        unique_together = (('user', 'session_key_hash'),)
        indexes = [models.Index(fields=['user', 'is_active'])]

    def __str__(self):
        return f"{self.user} – {self.session_key_hash[:8]}…"


# =========================
#  Consentements & Préférences (RGPD)
# =========================

class ConsentType(models.TextChoices):
    TERMS = "terms", "Conditions d'utilisation"
    PRIVACY = "privacy", "Politique de confidentialité"
    ANALYTICS = "analytics", "Cookies Analytics"
    MARKETING = "marketing", "Cookies Marketing"
    CONTACT = "contact", "Autorisation de recontact"
    OTHER = "other", "Autre"


class Consent(TimestampedModel):
    """
    Enregistrements de consentements (preuve + version).
    Peut être lié à un user ou à un identifiant cookie (anonyme).
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='consents')
    anonymous_key = models.CharField(
        max_length=64, blank=True, db_index=True,
        help_text="Identifiant anonyme (cookie) si non connecté."
    )
    consent_type = models.CharField(max_length=32, choices=ConsentType.choices, db_index=True)
    version_text = models.CharField(max_length=32, blank=True, help_text="Version du texte accepté.")
    granted = models.BooleanField(default=False)
    granted_at = models.DateTimeField(default=timezone.now, db_index=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    evidence = models.CharField(max_length=128, blank=True, help_text="Hash/empreinte de la preuve.")
    source = models.CharField(max_length=64, blank=True, help_text="Origine (bandeau, page, checkout, etc.)")

    class Meta:
        verbose_name = "Consentement"
        verbose_name_plural = "Consentements"
        indexes = [
            models.Index(fields=['consent_type', 'granted']),
            models.Index(fields=['anonymous_key']),
        ]

    def __str__(self):
        subject = self.user or f"anon:{self.anonymous_key[:6]}" if self.anonymous_key else "inconnu"
        return f"{subject} – {self.get_consent_type_display()} ({'OK' if self.granted else 'NON'})"


class MarketingPreference(TimestampedModel):
    """
    Préférences marketing par utilisateur.
    """
    FREQ_CHOICES = (
        ("immediate", "Immédiat"),
        ("daily", "Quotidien"),
        ("weekly", "Hebdomadaire"),
        ("monthly", "Mensuel"),
    )
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='marketing_prefs')
    email_optin = models.BooleanField(default=False)
    sms_optin = models.BooleanField(default=False)
    whatsapp_optin = models.BooleanField(default=False)
    frequency = models.CharField(max_length=16, choices=FREQ_CHOICES, default="weekly")
    topics = models.JSONField(default=list, blank=True)

    class Meta:
        verbose_name = "Préférences marketing"
        verbose_name_plural = "Préférences marketing"

    def __str__(self):
        return f"Prefs marketing – {self.user}"


# =========================
#  Notifications (socle)
# =========================

class NotificationChannel(TimestampedModel):
    """
    Préférences d'activation par canal.
    """
    CHANNEL_CHOICES = (
        ("email", "Email"),
        ("inapp", "In-App"),
        ("push", "Push"),
    )
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notification_channels')
    channel = models.CharField(max_length=16, choices=CHANNEL_CHOICES, db_index=True)
    enabled = models.BooleanField(default=True)
    quiet_hours = models.JSONField(default=dict, blank=True, help_text="Ex: {'start':'22:00','end':'07:00'}")

    class Meta:
        verbose_name = "Canal de notification"
        verbose_name_plural = "Canaux de notification"
        unique_together = (('user', 'channel'),)

    def __str__(self):
        return f"{self.user} – {self.get_channel_display()} ({'on' if self.enabled else 'off'})"


class NotificationStatus(models.TextChoices):
    QUEUED = "queued", "En file"
    SENT = "sent", "Envoyée"
    FAILED = "failed", "Échec"
    OPENED = "opened", "Ouverte"


class Notification(TimestampedModel):
    """
    Historique d'envoi de notifications.
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    notif_type = models.CharField(max_length=64, db_index=True, help_text="Type interne (ex. account_confirmed).")
    payload = models.JSONField(default=dict, blank=True)
    status = models.CharField(max_length=16, choices=NotificationStatus.choices, default=NotificationStatus.QUEUED, db_index=True)
    queued_at = models.DateTimeField(default=timezone.now, db_index=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    opened_at = models.DateTimeField(null=True, blank=True)
    error_message = models.TextField(blank=True)

    class Meta:
        verbose_name = "Notification"
        verbose_name_plural = "Notifications"
        ordering = ['-queued_at']
        indexes = [models.Index(fields=['user', 'status', 'notif_type'])]

    def __str__(self):
        return f"{self.notif_type} → {self.user} [{self.get_status_display()}]"


# =========================
#  Bridge User ↔ Prospect
# =========================

class ProspectLink(TimestampedModel):
    """
    Bridge non intrusif entre un User et un Prospect (module questionnaires_expert).
    """
    LINK_REASON_CHOICES = (
        ("email_match", "Email identique"),
        ("manual", "Association manuelle"),
        ("import", "Import"),
    )
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='prospect_links')
    prospect = models.ForeignKey(Prospect, on_delete=models.CASCADE, related_name='user_links')
    link_reason = models.CharField(max_length=32, choices=LINK_REASON_CHOICES, default="manual")
    linked_at = models.DateTimeField(default=timezone.now)
    notes = models.CharField(max_length=255, blank=True)

    class Meta:
        verbose_name = "Lien User ↔ Prospect"
        verbose_name_plural = "Liens User ↔ Prospect"
        unique_together = (('user', 'prospect'),)
        indexes = [
            models.Index(fields=['user']),
            models.Index(fields=['prospect']),
        ]

    def __str__(self):
        return f"{self.user} ↔ {self.prospect} ({self.get_link_reason_display()})"


# =========================
#  Tes modèles existants
# =========================

class Profile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='profile'
    )
    avatar = models.ImageField(
        upload_to='avatars/',
        null=True,
        blank=True
    )
    bio = models.TextField(
        blank=True
    )
    phone_number = models.CharField(
        max_length=20,
        blank=True
    )
    date_of_birth = models.DateField(
        null=True,
        blank=True
    )
    location = models.CharField(
        max_length=255,
        blank=True
    )
    website = models.URLField(
        blank=True
    )

    def __str__(self):
        return f"Profil de {self.user.get_full_name() or self.user.email}"


class Comments(models.Model):
    date_created = models.DateTimeField(
        auto_now_add=True,
        blank=True,
    )
    text = models.TextField(
        max_length=5000,
    )
    test_data = models.ForeignKey(
        ExpertTestData,
        on_delete=models.CASCADE,
        related_name='comments',
        null=True,
        blank=True,
    )
    prospect = models.ForeignKey(
        Prospect,
        on_delete=models.CASCADE,
        related_name='comments',
        null=True,
        blank=True,
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='comments',
        null=True,
        blank=True,
    )

    class Meta:
        ordering = ['-date_created']

    def __str__(self):
        return f"Commentaire #{self.pk} par {self.user or 'anonyme'}"


class Address(TimestampedModel):
    """
    Adresse utilisateur (livraison/facturation).
    """
    ADDRESS_TYPE_CHOICES = (
        ("billing", "Facturation"),
        ("shipping", "Livraison"),
    )
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='addresses')
    address_type = models.CharField(max_length=20, choices=ADDRESS_TYPE_CHOICES, default="shipping")
    is_default = models.BooleanField(default=False)
    
    name = models.CharField(max_length=255, help_text="Nom complet ou nom de l'adresse (ex. Maison)")
    street_address = models.CharField(max_length=255, verbose_name="Rue")
    street_address_2 = models.CharField(max_length=255, blank=True, verbose_name="Complément d'adresse")
    city = models.CharField(max_length=100, verbose_name="Ville")
    postal_code = models.CharField(max_length=20, verbose_name="Code postal")
    country = models.CharField(max_length=100, verbose_name="Pays", default="France")
    phone = models.CharField(max_length=20, blank=True, verbose_name="Téléphone")

    class Meta:
        verbose_name = "Adresse"
        verbose_name_plural = "Adresses"
        ordering = ['-is_default', '-created_at']

    def save(self, *args, **kwargs):
        # Si on définit cette adresse comme par défaut, on enlève le flag des autres
        if self.is_default:
            Address.objects.filter(user=self.user, address_type=self.address_type).exclude(pk=self.pk).update(is_default=False)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} ({self.get_address_type_display()})"
