# jeiko/users/adapters.py
"""
Adaptateur de compte allauth.

allauth compose ses e-mails transactionnels à partir de gabarits `.txt`/`.html`
livrés dans le package. On surcharge ici les points d'extension documentés qui
donnent un accès typé à l'utilisateur et au lien, pour rediriger ces envois vers
le catalogue emailing éditable en back-office.

  - `send_password_reset_mail`  → password_reset_request
  - `send_confirmation_mail`    → account_email_verify (inscription)
                                  / email_change_confirm (changement d'adresse)

Les notifications de sécurité (mot de passe modifié, alerte de changement
d'adresse) passent, elles, par les signaux allauth (voir `signals.py`) : elles
ne dépendent pas de ces méthodes.

En cas d'imprévu, on retombe sur le comportement natif d'allauth pour ne jamais
priver l'utilisateur d'un mail critique (réinitialisation, confirmation).
"""

import logging

from allauth.account import app_settings as allauth_settings
from allauth.account.adapter import DefaultAccountAdapter

from jeiko.users import emailing

logger = logging.getLogger(__name__)


class JeikoAccountAdapter(DefaultAccountAdapter):

    def pre_login(self, request, user, **kwargs):
        """
        Interpose le second facteur entre le mot de passe et la session.

        `pre_login` est le seul endroit qui voit passer TOUTES les connexions —
        formulaire, connexion sociale, connexion programmée après inscription.
        Le placer ici évite qu'un chemin d'entrée oublié contourne la
        vérification, ce qui est précisément le genre de trou qu'on ne découvre
        qu'après.

        Renvoyer une réponse interrompt la connexion : allauth n'ouvre pas la
        session. L'utilisateur est mis en attente, identifié seulement par ce
        que porte sa session côté serveur.
        """
        reponse = super().pre_login(request, user, **kwargs)
        if reponse is not None:
            return reponse

        from django.shortcuts import redirect
        from django.urls import NoReverseMatch, reverse

        from jeiko.users import twofactor

        # Second passage, après saisie du bon code : on laisse faire.
        if request.session.pop(twofactor.SESSION_PASSED_KEY, False):
            return None

        device = twofactor.get_active_device(user)
        if device is None:
            return None

        try:
            url = reverse("jeiko_allauth:twofa_verify")
        except NoReverseMatch:
            # Sans écran de saisie, exiger un code enfermerait tout le monde
            # dehors. On préfère journaliser bruyamment et laisser entrer.
            logger.error(
                "2FA active pour %s mais l'écran de saisie est introuvable : "
                "connexion autorisée sans second facteur.", user.pk,
            )
            return None

        request.session[twofactor.SESSION_USER_KEY] = user.pk
        request.session[twofactor.SESSION_BACKEND_KEY] = getattr(
            user, "backend", "django.contrib.auth.backends.ModelBackend"
        )
        # `redirect_url` porte la destination demandée avant la connexion.
        suite = kwargs.get("redirect_url")
        if suite:
            request.session["jeiko_2fa_next"] = suite

        twofactor.send_code(device, request)
        return redirect(url)

    def send_password_reset_mail(self, user, email, context):
        url = context.get("password_reset_url")
        if url:
            try:
                emailing.send_password_reset(user, email, url, self.request)
                return
            except Exception:
                logger.exception("Repli allauth pour password_reset_request")
        return super().send_password_reset_mail(user, email, context)

    def send_confirmation_mail(self, request, emailconfirmation, signup):
        # En vérification par code (pas de lien), on laisse allauth gérer.
        if allauth_settings.EMAIL_VERIFICATION_BY_CODE_ENABLED:
            return super().send_confirmation_mail(request, emailconfirmation, signup)

        email_address = emailconfirmation.email_address
        url = self.get_email_confirmation_url(request, emailconfirmation)
        if url:
            try:
                user = email_address.user
                if signup:
                    emailing.send_email_verification(user, email_address.email, url)
                else:
                    emailing.send_email_change_confirm(user, email_address.email, url)
                return
            except Exception:
                logger.exception("Repli allauth pour la confirmation d'adresse")
        return super().send_confirmation_mail(request, emailconfirmation, signup)
