# jeiko/users/tests_delete.py
"""
Suppression de comptes depuis l'administration — unitaire et en masse.

Ce qui se joue ici
------------------
Le paquet propose désormais DEUX gestes qu'il ne faut pas confondre :

- **Effacer les données** (RGPD) anonymise le compte et conserve les commandes.
- **Supprimer** retire la ligne, pour les faux comptes.

Confondre les deux fait disparaître des pièces comptables. Ces tests portent
donc surtout sur les refus : qu'un compte porteur d'une commande, un
superutilisateur ou son propre compte ne puissent PAS être supprimés, et que le
lot dise lesquels il a épargnés plutôt que d'échouer en bloc ou d'effacer en
silence.
"""

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from jeiko.users.purge import compte_supprimable
from jeiko.users.testing import creer_compte_verifie

User = get_user_model()


class BaseSuppression(TestCase):
    def setUp(self):
        self.admin = User.objects.create_user(
            "patron", "patron@exemple.test", "mdp",
            is_staff=True, is_superuser=True,
        )
        self.client.force_login(self.admin)
        self.cible = creer_compte_verifie("faux", "faux@exemple.test", "mdp")

    def _url(self, compte):
        return reverse("jeiko_administration_users:user_delete", args=[compte.pk])


class SuppressionUnitaireTests(BaseSuppression):

    def test_un_compte_sans_historique_est_supprime(self):
        reponse = self.client.post(self._url(self.cible))
        self.assertEqual(reponse.status_code, 302)
        self.assertFalse(User.objects.filter(pk=self.cible.pk).exists())

    def test_lecran_de_confirmation_precede_la_suppression(self):
        """Un GET ne doit jamais effacer : seul le POST agit."""
        reponse = self.client.get(self._url(self.cible))
        self.assertEqual(reponse.status_code, 200)
        self.assertTrue(User.objects.filter(pk=self.cible.pk).exists())

    def test_un_compte_avec_commande_est_refuse(self):
        """
        Le refus qui compte : supprimer effacerait une écriture comptable.
        L'écran doit renvoyer vers l'effacement RGPD, qui anonymise sans perdre
        la pièce.
        """
        from jeiko.shop.models import Order

        Order.objects.create(user=self.cible)
        self.client.post(self._url(self.cible))
        self.assertTrue(
            User.objects.filter(pk=self.cible.pk).exists(),
            "Un compte porteur d'une commande a été supprimé.",
        )

    def test_un_superutilisateur_est_refuse(self):
        autre = User.objects.create_user("root2", "r2@exemple.test", "mdp",
                                         is_superuser=True)
        self.client.post(self._url(autre))
        self.assertTrue(User.objects.filter(pk=autre.pk).exists())

    def test_on_ne_supprime_pas_son_propre_compte(self):
        self.client.post(self._url(self.admin))
        self.assertTrue(User.objects.filter(pk=self.admin.pk).exists())

    def test_un_compte_sans_permission_est_refuse(self):
        self.client.force_login(
            User.objects.create_user("simple", "s@exemple.test", "mdp", is_staff=True)
        )
        reponse = self.client.post(self._url(self.cible))
        self.assertEqual(reponse.status_code, 403)
        self.assertTrue(User.objects.filter(pk=self.cible.pk).exists())

    def test_lanonyme_est_refuse(self):
        self.client.logout()
        self.client.post(self._url(self.cible))
        self.assertTrue(User.objects.filter(pk=self.cible.pk).exists())


class SuppressionEnMasseTests(BaseSuppression):
    URL = None

    def setUp(self):
        super().setUp()
        self.URL = reverse("jeiko_administration_users:user_bulk_delete")

    def test_plusieurs_comptes_partent_en_une_fois(self):
        autres = [
            creer_compte_verifie(f"faux{i}", f"f{i}@exemple.test", "mdp")
            for i in range(3)
        ]
        ids = ",".join(str(c.pk) for c in [self.cible] + autres)

        self.client.post(self.URL, {"user_ids": ids})

        self.assertEqual(
            User.objects.filter(username__startswith="faux").count(), 0
        )

    def test_le_lot_epargne_les_comptes_proteges_sans_echouer(self):
        """
        Le point de conception : un lot n'est pas tout ou rien.

        Refuser l'ensemble parce qu'un compte porte une commande obligerait à
        refaire la sélection à l'aveugle ; supprimer sans rien dire ferait
        disparaître la pièce. On supprime ce qui peut l'être, et on nomme le
        reste.
        """
        from jeiko.shop.models import Order

        client = creer_compte_verifie("client", "c@exemple.test", "mdp")
        Order.objects.create(user=client)
        ids = f"{self.cible.pk},{client.pk}"

        reponse = self.client.post(self.URL, {"user_ids": ids}, follow=True)

        self.assertFalse(User.objects.filter(pk=self.cible.pk).exists(),
                         "Le faux compte aurait dû partir.")
        self.assertTrue(User.objects.filter(pk=client.pk).exists(),
                        "Le compte client aurait dû être conservé.")
        messages = [str(m) for m in reponse.context["messages"]]
        self.assertTrue(
            any("client" in m for m in messages),
            "Le compte conservé n'est pas nommé dans le retour.",
        )

    def test_une_selection_vide_ne_fait_rien(self):
        reponse = self.client.post(self.URL, {"user_ids": ""}, follow=True)
        self.assertTrue(User.objects.filter(pk=self.cible.pk).exists())
        self.assertEqual(reponse.status_code, 200)

    def test_des_identifiants_invalides_sont_ignores(self):
        """L'entrée vient d'un champ caché : elle n'est pas digne de confiance."""
        self.client.post(self.URL, {"user_ids": "abc,,-1, 999999 "})
        self.assertTrue(User.objects.filter(pk=self.cible.pk).exists())

    def test_sans_permission_le_lot_est_refuse(self):
        self.client.force_login(
            User.objects.create_user("simple", "s@exemple.test", "mdp", is_staff=True)
        )
        reponse = self.client.post(self.URL, {"user_ids": str(self.cible.pk)})
        self.assertEqual(reponse.status_code, 403)
        self.assertTrue(User.objects.filter(pk=self.cible.pk).exists())


class MotifsDeRefusTests(TestCase):
    """Le motif est destiné à l'écran : il doit dire quoi faire."""

    def test_le_motif_dun_compte_avec_commande_oriente_vers_leffacement(self):
        from jeiko.shop.models import Order

        compte = creer_compte_verifie("client", "c@exemple.test", "mdp")
        Order.objects.create(user=compte)

        possible, motif = compte_supprimable(compte)
        self.assertFalse(possible)
        self.assertIn("commande", motif.lower())
        self.assertIn("anonymise", motif.lower())

    def test_un_compte_ordinaire_est_supprimable(self):
        compte = creer_compte_verifie("faux", "f@exemple.test", "mdp")
        possible, motif = compte_supprimable(compte)
        self.assertTrue(possible)
        self.assertIsNone(motif)
