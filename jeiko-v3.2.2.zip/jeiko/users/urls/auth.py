from django.urls import path
from ..views.auth import (
    CustomSignupView,
    CustomLoginView,
    CustomLogoutView,
    TwoFactorVerifyView,
)

app_name = 'jeiko_allauth'

urlpatterns = [
    # Inscription / connexion / déconnexion
    path('signup/', CustomSignupView.as_view(), name='signup'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', CustomLogoutView.as_view(), name='logout'),

    # Second facteur : saisie du code reçu par e-mail.
    path('2fa/', TwoFactorVerifyView.as_view(), name='twofa_verify'),
]