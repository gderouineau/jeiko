# jeiko/checks.py
"""
Contrôles au démarrage : JEIKO s'installe entier, ou pas du tout.

Pourquoi ce fichier existe
--------------------------
Le package se présente comme quatorze applications Django séparées. Ce n'en est
pas : le graphe d'imports comporte douze paires mutuelles — `administration` et
`emailing` s'appellent l'un l'autre, `shop` et `custom_objects` aussi, et ainsi
de suite. Rien ne casse aujourd'hui parce que ces imports sont différés à
l'intérieur des fonctions, mais l'équilibre est instable.

La décision a été prise : **JEIKO est une application indivisible**. On cesse
donc d'entretenir la fiction inverse, et on la rend vérifiable — une intention
écrite dans un fichier se perd, un contrôle qui échoue au démarrage non.

Ce que ce contrôle évite
------------------------
Sans lui, installer une partie seulement des applications produit un
`ImportError` ou un `NoReverseMatch` tardif, loin de sa cause : la personne
cherche un bug dans le code alors que son `INSTALLED_APPS` est incomplet. Le
message ci-dessous nomme précisément ce qui manque.
"""

from django.core.checks import Error, register

#: Les applications qui composent JEIKO. Elles s'installent ensemble.
#:
#: Ajouter une application au package, c'est l'ajouter ici ET dans le gabarit
#: `INSTALLED_APPS` de l'installeur — sans quoi les sites existants ne la
#: verront jamais.
JEIKO_APPS = (
    "jeiko",
    "jeiko.administration",
    "jeiko.administration_menu",
    "jeiko.administration_pages",
    "jeiko.calendars",
    "jeiko.cookies",
    "jeiko.courses",
    "jeiko.custom_objects",
    "jeiko.emailing",
    "jeiko.payments",
    "jeiko.questionnaires_expert",
    "jeiko.shop",
    "jeiko.stats",
    "jeiko.users",
)


@register()
def check_jeiko_apps_installed(app_configs, **kwargs):
    """Refuse un démarrage où JEIKO n'est installé qu'à moitié."""
    from django.apps import apps

    installees = {config.name for config in apps.get_app_configs()}
    manquantes = [nom for nom in JEIKO_APPS if nom not in installees]
    if not manquantes:
        return []

    return [
        Error(
            "JEIKO est installé partiellement : %s application(s) manquent dans "
            "INSTALLED_APPS." % len(manquantes),
            hint=(
                "JEIKO ne se compose pas à la carte : ses applications "
                "s'appellent mutuellement et doivent être installées ensemble. "
                "Ajouter à INSTALLED_APPS :\n    "
                + "\n    ".join(f"'{nom}'," for nom in manquantes)
            ),
            id="jeiko.E001",
        )
    ]
