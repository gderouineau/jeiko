from django.apps import AppConfig


class AdministrationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko'
    label = "jeiko"

    def ready(self):
        # Contrôle d'installation complète : JEIKO s'installe entier ou pas du
        # tout (cf. jeiko/checks.py et ARCHITECTURE.md).
        from . import checks  # noqa: F401
