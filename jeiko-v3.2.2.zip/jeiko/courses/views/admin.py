"""
Admin views for courses management.
Views for administrators to manage courses, providers, and enrollments.
"""
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import permission_required
from django.contrib import messages
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods
from django.db import models
from django.db.models import Count, Q, Avg

from ..models import (
    Course, VideoStorageProvider, CourseEnrollment,
    Part, Chapter, Section, VideoContent,
    QuizContent, QuizQuestion, QuizAnswer
)
from ..forms.admin import (
    CourseForm, VideoStorageProviderForm, EnrollmentGrantForm,
    PartForm, ChapterForm, SectionForm, VideoContentForm
)
from ..forms.admin_quiz import (
    QuizContentForm, QuizQuestionForm, QuizAnswerFormSet
)
from ..utils import test_provider_connection, grant_course_access


@permission_required("courses.view_course", raise_exception=True)
@never_cache
def course_list(request):
    """Liste des formations (admin)."""
    courses = Course.objects.all().annotate(
        enrollments_count=Count('enrollments')
    ).order_by('-created_at')
    return render(request, 'courses/admin/course_list.html', {'courses': courses})


@permission_required("courses.add_course", raise_exception=True)
@never_cache
def course_create(request):
    """Création de formation (admin)."""
    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES)
        if form.is_valid():
            course = form.save(commit=False)
            course.created_by = request.user
            course.save()
            messages.success(request, f'Formation "{course.title}" créée avec succès.')
            return redirect('jeiko_courses:jeiko_courses_admin:course_list')
    else:
        form = CourseForm()
    
    return render(request, 'courses/admin/course_form.html', {
        'form': form,
        'course': None
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def course_edit(request, course_id):
    """Édition de formation (admin)."""
    course = get_object_or_404(Course, id=course_id)
    
    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES, instance=course)
        if form.is_valid():
            form.save()
            messages.success(request, f'Formation "{course.title}" mise à jour.')
            return redirect('jeiko_courses:jeiko_courses_admin:course_list')
    else:
        form = CourseForm(instance=course)
    
    return render(request, 'courses/admin/course_form.html', {
        'form': form,
        'course': course
    })


@permission_required("courses.delete_course", raise_exception=True)
@never_cache
def course_delete(request, course_id):
    """Suppression de formation (admin)."""
    course = get_object_or_404(Course, id=course_id)
    
    if request.method == 'POST':
        title = course.title
        course.delete()
        messages.success(request, f'Formation "{title}" supprimée.')
        return redirect('jeiko_courses:jeiko_courses_admin:course_list')
    
    return render(request, 'courses/admin/course_delete.html', {'course': course})


@permission_required("courses.view_course", raise_exception=True)
@never_cache
def course_structure(request, course_id):
    """Vue d'ensemble de la structure du cours."""
    course = get_object_or_404(Course, id=course_id)
    parts = course.parts.all().prefetch_related(
        'chapters',
        'chapters__sections',
        'chapters__sections__video_content',
        'chapters__sections__text_content',
        'chapters__sections__pdf_content',
        'chapters__sections__quiz_content'
    ).order_by('position')
    
    return render(request, 'courses/admin/course_structure.html', {
        'course': course,
        'parts': parts
    })


# =============================================================================
# STRUCTURE MANAGEMENT - PARTS
# =============================================================================

@permission_required("courses.change_course", raise_exception=True)
@never_cache
def part_create(request, course_id):
    """Création d'une partie."""
    course = get_object_or_404(Course, id=course_id)
    
    if request.method == 'POST':
        form = PartForm(request.POST)
        if form.is_valid():
            part = form.save(commit=False)
            part.course = course
            # Auto-set position
            last_position = course.parts.aggregate(models.Max('position'))['position__max'] or 0
            part.position = last_position + 1
            part.save()
            messages.success(request, f'Partie "{part.title}" ajoutée.')
            return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    else:
        # Auto-increment position
        form = PartForm(initial={'course': course})
    
    return render(request, 'courses/admin/part_form.html', {
        'form': form,
        'course': course,
        'part': None
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def part_edit(request, part_id):
    """Édition d'une partie."""
    part = get_object_or_404(Part, id=part_id)
    course = part.course
    
    if request.method == 'POST':
        form = PartForm(request.POST, instance=part)
        if form.is_valid():
            form.save()
            messages.success(request, f'Partie "{part.title}" mise à jour.')
            return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    else:
        form = PartForm(instance=part)
    
    return render(request, 'courses/admin/part_form.html', {
        'form': form,
        'course': course,
        'part': part
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def part_delete(request, part_id):
    """Suppression d'une partie."""
    part = get_object_or_404(Part, id=part_id)
    course = part.course
    
    if request.method == 'POST':
        title = part.title
        part.delete()
        messages.success(request, f'Partie "{title}" supprimée.')
        return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    
    return render(request, 'courses/admin/confirm_delete.html', {
        'object': part,
        'cancel_url': 'jeiko_courses:jeiko_courses_admin:course_structure',
        'cancel_args': [course.id]
    })


# =============================================================================
# STRUCTURE MANAGEMENT - CHAPTERS
# =============================================================================

@permission_required("courses.change_course", raise_exception=True)
@never_cache
def chapter_create(request, part_id):
    """Création d'un chapitre."""
    part = get_object_or_404(Part, id=part_id)
    course = part.course
    
    if request.method == 'POST':
        form = ChapterForm(request.POST)
        if form.is_valid():
            chapter = form.save(commit=False)
            chapter.part = part
            # Auto-set position
            last_position = part.chapters.aggregate(models.Max('position'))['position__max'] or 0
            chapter.position = last_position + 1
            chapter.save()
            messages.success(request, f'Chapitre "{chapter.title}" ajouté.')
            return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    else:
        form = ChapterForm(initial={'part': part})
    
    return render(request, 'courses/admin/chapter_form.html', {
        'form': form,
        'course': course,
        'part': part,
        'chapter': None
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def chapter_edit(request, chapter_id):
    """Édition d'un chapitre."""
    chapter = get_object_or_404(Chapter, id=chapter_id)
    part = chapter.part
    course = part.course
    
    if request.method == 'POST':
        form = ChapterForm(request.POST, instance=chapter)
        if form.is_valid():
            form.save()
            messages.success(request, f'Chapitre "{chapter.title}" mis à jour.')
            return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    else:
        form = ChapterForm(instance=chapter)
    
    return render(request, 'courses/admin/chapter_form.html', {
        'form': form,
        'course': course,
        'part': part,
        'chapter': chapter
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def chapter_delete(request, chapter_id):
    """Suppression d'un chapitre."""
    chapter = get_object_or_404(Chapter, id=chapter_id)
    course = chapter.part.course
    
    if request.method == 'POST':
        title = chapter.title
        chapter.delete()
        messages.success(request, f'Chapitre "{title}" supprimé.')
        return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    
    return render(request, 'courses/admin/confirm_delete.html', {
        'object': chapter,
        'cancel_url': 'jeiko_courses:jeiko_courses_admin:course_structure',
        'cancel_args': [course.id]
    })


# =============================================================================
# STRUCTURE MANAGEMENT - SECTIONS
# =============================================================================

@permission_required("courses.change_course", raise_exception=True)
@never_cache
def section_create(request, chapter_id):
    """Création d'une section."""
    chapter = get_object_or_404(Chapter, id=chapter_id)
    course = chapter.part.course
    
    if request.method == 'POST':
        form = SectionForm(request.POST)
        if form.is_valid():
            section = form.save(commit=False)
            section.chapter = chapter
            # Auto-set position
            last_position = chapter.sections.aggregate(models.Max('position'))['position__max'] or 0
            section.position = last_position + 1
            section.save()
            messages.success(request, f'Section "{section.title}" ajoutée.')
            return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    else:
        form = SectionForm(initial={'chapter': chapter})
    
    return render(request, 'courses/admin/section_form.html', {
        'form': form,
        'course': course,
        'chapter': chapter,
        'section': None
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def section_edit(request, section_id):
    """Édition d'une section."""
    section = get_object_or_404(Section, id=section_id)
    chapter = section.chapter
    course = chapter.part.course
    
    if request.method == 'POST':
        form = SectionForm(request.POST, instance=section)
        if form.is_valid():
            form.save()
            messages.success(request, f'Section "{section.title}" mise à jour.')
            return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    else:
        form = SectionForm(instance=section)
    
    return render(request, 'courses/admin/section_form.html', {
        'form': form,
        'course': course,
        'chapter': chapter,
        'section': section
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def section_delete(request, section_id):
    """Suppression d'une section."""
    section = get_object_or_404(Section, id=section_id)
    course = section.chapter.part.course
    
    if request.method == 'POST':
        title = section.title
        section.delete()
        messages.success(request, f'Section "{title}" supprimée.')
        return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    
    return render(request, 'courses/admin/confirm_delete.html', {
        'object': section,
        'cancel_url': 'jeiko_courses:jeiko_courses_admin:course_structure',
        'cancel_args': [course.id]
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
@require_http_methods(["POST"])
def section_notify(request, section_id):
    """Prévient les inscrits (accès non suspendu) qu'un contenu est publié.

    Action volontaire de l'admin : l'e-mail course_new_content n'est jamais
    envoyé automatiquement à la publication, pour éviter les envois en masse
    pendant la construction d'une formation.
    """
    section = get_object_or_404(Section, id=section_id)
    course = section.chapter.part.course

    from ..emailing import notify_new_content
    sent = notify_new_content(section)
    if sent:
        messages.success(request, f'{sent} inscrit(s) prévenu(s) pour « {section.title} ».')
    else:
        messages.info(request, "Aucun inscrit à prévenir pour cette formation.")
    return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)


# =============================================================================
# STRUCTURE MANAGEMENT - CONTENT
# =============================================================================

@permission_required("courses.change_course", raise_exception=True)
@never_cache
def video_content_create(request, section_id):
    """Ajout de contenu vidéo."""
    section = get_object_or_404(Section, id=section_id)
    course = section.chapter.part.course
    
    if request.method == 'POST':
        form = VideoContentForm(request.POST, request.FILES)
        if form.is_valid():
            content = form.save(commit=False)
            content.section = section
            content.save()
            messages.success(request, 'Contenu vidéo ajouté.')
            return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    else:
        form = VideoContentForm(initial={'section': section, 'title': section.title})
    
    return render(request, 'courses/admin/video_content_form.html', {
        'form': form,
        'course': course,
        'section': section,
        'content': None
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def video_content_edit(request, content_id):
    """Édition de contenu vidéo."""
    content = get_object_or_404(VideoContent, id=content_id)
    section = content.section
    course = section.chapter.part.course
    
    if request.method == 'POST':
        form = VideoContentForm(request.POST, request.FILES, instance=content)
        if form.is_valid():
            form.save()
            messages.success(request, 'Contenu vidéo mis à jour.')
            return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    else:
        form = VideoContentForm(instance=content)
    
    return render(request, 'courses/admin/video_content_form.html', {
        'form': form,
        'course': course,
        'section': section,
        'content': content
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def quiz_content_create(request, section_id):
    """Ajout de contenu quiz."""
    section = get_object_or_404(Section, id=section_id)
    course = section.chapter.part.course
    
    if request.method == 'POST':
        form = QuizContentForm(request.POST)
        if form.is_valid():
            content = form.save(commit=False)
            content.section = section
            content.save()
            messages.success(request, 'Quiz ajouté.')
            return redirect('jeiko_courses:jeiko_courses_admin:quiz_content_edit', content_id=content.id)
    else:
        form = QuizContentForm(initial={'section': section, 'title': section.title})
    
    return render(request, 'courses/admin/quiz_content_form.html', {
        'form': form,
        'course': course,
        'section': section,
        'content': None
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def quiz_content_edit(request, content_id):
    """Édition de contenu quiz et de ses questions."""
    content = get_object_or_404(QuizContent, id=content_id)
    section = content.section
    course = section.chapter.part.course
    questions = content.questions.all().order_by('position')
    
    if request.method == 'POST':
        form = QuizContentForm(request.POST, instance=content)
        if form.is_valid():
            form.save()
            messages.success(request, 'Quiz mis à jour.')
            return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=course.id)
    else:
        form = QuizContentForm(instance=content)
    
    return render(request, 'courses/admin/quiz_content_form.html', {
        'form': form,
        'course': course,
        'section': section,
        'content': content,
        'questions': questions
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def quiz_question_create(request, quiz_id):
    """Ajout d'une question au quiz."""
    quiz = get_object_or_404(QuizContent, id=quiz_id)
    course = quiz.section.chapter.part.course
    
    if request.method == 'POST':
        form = QuizQuestionForm(request.POST)
        formset = QuizAnswerFormSet(request.POST)
        
        if form.is_valid() and formset.is_valid():
            question = form.save(commit=False)
            question.quiz = quiz
            # Auto-set position
            last_position = quiz.questions.aggregate(models.Max('position'))['position__max'] or 0
            question.position = last_position + 1
            question.save()
            
            answers = formset.save(commit=False)
            for answer in answers:
                answer.question = question
                answer.save()
            formset.save_m2m()
            
            messages.success(request, 'Question ajoutée.')
            return redirect('jeiko_courses:jeiko_courses_admin:quiz_content_edit', content_id=quiz.id)
    else:
        form = QuizQuestionForm(initial={'quiz': quiz})
        formset = QuizAnswerFormSet()
    
    return render(request, 'courses/admin/quiz_question_form.html', {
        'form': form,
        'formset': formset,
        'course': course,
        'quiz': quiz,
        'question': None
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def quiz_question_edit(request, question_id):
    """Édition d'une question et de ses réponses."""
    question = get_object_or_404(QuizQuestion, id=question_id)
    quiz = question.quiz
    course = quiz.section.chapter.part.course
    
    if request.method == 'POST':
        form = QuizQuestionForm(request.POST, instance=question)
        formset = QuizAnswerFormSet(request.POST, instance=question)
        
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, 'Question mise à jour.')
            return redirect('jeiko_courses:jeiko_courses_admin:quiz_content_edit', content_id=quiz.id)
    else:
        form = QuizQuestionForm(instance=question)
        formset = QuizAnswerFormSet(instance=question)
    
    return render(request, 'courses/admin/quiz_question_form.html', {
        'form': form,
        'formset': formset,
        'course': course,
        'quiz': quiz,
        'question': question
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def quiz_question_delete(request, question_id):
    """Suppression d'une question."""
    question = get_object_or_404(QuizQuestion, id=question_id)
    quiz = question.quiz
    course = quiz.section.chapter.part.course
    
    if request.method == 'POST':
        question.delete()
        messages.success(request, 'Question supprimée.')
        return redirect('jeiko_courses:jeiko_courses_admin:quiz_content_edit', content_id=quiz.id)
    
    return render(request, 'courses/admin/confirm_delete.html', {
        'object': question,
        'cancel_url': 'jeiko_courses:jeiko_courses_admin:quiz_content_edit',
        'cancel_args': [quiz.id]
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def provider_list(request):
    """Liste des providers de stockage."""
    providers = VideoStorageProvider.objects.all().annotate(
        videos_count=Count('videos')
    ).order_by('name')
    return render(request, 'courses/admin/provider_list.html', {'providers': providers})


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def provider_create(request):
    """Création de provider."""
    if request.method == 'POST':
        form = VideoStorageProviderForm(request.POST)
        if form.is_valid():
            provider = form.save()
            messages.success(request, f'Provider "{provider.name}" créé avec succès.')
            return redirect('jeiko_courses:jeiko_courses_admin:provider_list')
    else:
        form = VideoStorageProviderForm()
    
    return render(request, 'courses/admin/provider_form.html', {
        'form': form,
        'provider': None
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def provider_edit(request, provider_id):
    """Édition de provider."""
    provider = get_object_or_404(VideoStorageProvider, id=provider_id)
    
    if request.method == 'POST':
        form = VideoStorageProviderForm(request.POST, instance=provider)
        if form.is_valid():
            form.save()
            messages.success(request, f'Provider "{provider.name}" mis à jour.')
            return redirect('jeiko_courses:jeiko_courses_admin:provider_list')
    else:
        form = VideoStorageProviderForm(instance=provider)
    
    return render(request, 'courses/admin/provider_form.html', {
        'form': form,
        'provider': provider
    })


@permission_required("courses.change_course", raise_exception=True)
@never_cache
def provider_test(request, provider_id):
    """Test de connexion à un provider."""
    provider = get_object_or_404(VideoStorageProvider, id=provider_id)
    result = test_provider_connection(provider)
    return JsonResponse(result)


@permission_required("courses.view_courseenrollment", raise_exception=True)
@never_cache
def enrollment_list(request):
    """Liste des inscriptions."""
    enrollments = CourseEnrollment.objects.all().select_related(
        'user', 'course', 'granted_by', 'order'
    ).order_by('-enrolled_at')
    
    # Filters
    course_filter = request.GET.get('course')
    status_filter = request.GET.get('status')
    
    if course_filter:
        # Le paramètre vient de l'URL : le convertir prudemment pour éviter un
        # 500 sur '?course=abc'.
        try:
            enrollments = enrollments.filter(course_id=int(course_filter))
        except (ValueError, TypeError):
            course_filter = None
    if status_filter in dict(CourseEnrollment.STATUS_CHOICES):
        enrollments = enrollments.filter(status=status_filter)
    else:
        status_filter = None
    
    courses = Course.objects.filter(is_restricted=True).order_by('title')
    
    return render(request, 'courses/admin/enrollment_list.html', {
        'enrollments': enrollments,
        'courses': courses,
        'selected_course': course_filter,
        'selected_status': status_filter,
    })


@permission_required("courses.change_courseenrollment", raise_exception=True)
@never_cache
def enrollment_grant(request):
    """Accorder un accès à une formation.

    Peut être appelée depuis la fiche d'un utilisateur : `?user=<id>` préremplit
    le champ utilisateur et `?next=<url>` ramène l'admin à la page d'origine.
    """
    # `next` transitant en GET (lien) puis en POST (champ caché du formulaire).
    next_url = request.POST.get('next') or request.GET.get('next') or ''
    if request.method == 'POST':
        form = EnrollmentGrantForm(request.POST)
        if form.is_valid():
            user = form.cleaned_data['user']
            course = form.cleaned_data['course']
            notes = form.cleaned_data.get('notes', '')
            access_expires_at = form.cleaned_data.get('access_expires_at')

            enrollment = grant_course_access(
                user=user,
                course=course,
                granted_by=request.user,
                has_payed=False,
                notes=notes
            )

            if access_expires_at:
                enrollment.access_expires_at = access_expires_at
                enrollment.save()

            messages.success(request, f'Accès accordé à {user} pour "{course.title}".')
            return redirect(next_url or 'jeiko_courses:jeiko_courses_admin:enrollment_list')
    else:
        initial = {}
        user_id = request.GET.get('user')
        if user_id:
            initial['user'] = user_id
        form = EnrollmentGrantForm(initial=initial)

    return render(request, 'courses/admin/enrollment_grant.html', {'form': form, 'next': next_url})


@permission_required("courses.change_courseenrollment", raise_exception=True)
@never_cache
def enrollment_revoke(request, enrollment_id):
    """Révoquer un accès."""
    enrollment = get_object_or_404(CourseEnrollment, id=enrollment_id)

    if request.method == 'POST':
        enrollment.status = CourseEnrollment.STATUS_SUSPENDED
        enrollment.save()
        messages.success(request, f'Accès révoqué pour {enrollment.user}.')
        return redirect(
            request.POST.get('next')
            or 'jeiko_courses:jeiko_courses_admin:enrollment_list'
        )

    return render(request, 'courses/admin/enrollment_revoke.html', {
        'enrollment': enrollment,
        'next': request.GET.get('next', ''),
    })

@permission_required("courses.change_courseenrollment", raise_exception=True)
@never_cache
@require_http_methods(["POST"])
def enrollment_cancel_revoke(request, enrollment_id):
    """Réactiver un accès suspendu (POST uniquement : mutation d'état)."""
    enrollment = get_object_or_404(CourseEnrollment, id=enrollment_id)
    enrollment.status = CourseEnrollment.STATUS_ACTIVE
    enrollment.save()
    messages.success(request, f'Accès réactivé pour {enrollment.user}.')
    return redirect(
        request.POST.get('next')
        or 'jeiko_courses:jeiko_courses_admin:enrollment_list'
    )



@permission_required("courses.view_course", raise_exception=True)
@never_cache
def course_progress(request, course_id):
    """Tableau de bord de progression par formation."""
    course = get_object_or_404(Course, id=course_id)
    enrollments = CourseEnrollment.objects.filter(
        course=course
    ).select_related('user').order_by('-progress_percentage')
    
    # Stats
    total_enrolled = enrollments.count()
    completed = enrollments.filter(status=CourseEnrollment.STATUS_COMPLETED).count()
    avg_progress = enrollments.aggregate(
        avg=Avg('progress_percentage')
    )['avg'] or 0
    
    return render(request, 'courses/admin/course_progress.html', {
        'course': course,
        'enrollments': enrollments,
        'total_enrolled': total_enrolled,
        'completed': completed,
        'avg_progress': avg_progress,
    })


@permission_required("courses.view_courseenrollment", raise_exception=True)
@never_cache
def user_progress(request, user_id):
    """Progression d'un utilisateur."""
    from django.contrib.auth import get_user_model
    from django.db import models
    
    User = get_user_model()
    user = get_object_or_404(User, id=user_id)
    enrollments = CourseEnrollment.objects.filter(
        user=user
    ).select_related('course').order_by('-enrolled_at')
    
    return render(request, 'courses/admin/user_progress.html', {
        'student': user,
        'enrollments': enrollments
    })
