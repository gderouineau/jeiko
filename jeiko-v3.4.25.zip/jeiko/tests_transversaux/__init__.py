"""Tests transversaux du paquet JEIKO."""
