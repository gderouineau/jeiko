"""Contrats de sécurité des filtres de gabarit transversaux."""

import json

from django.template import Context, Template
from django.test import SimpleTestCase

from jeiko.templatetags.css_extras import clean_css_block, clean_css_value
from jeiko.templatetags.html_extras import html_unescape, sanitize_html
from jeiko.templatetags.json_extras import tojson


class TemplateTagsSecurityTests(SimpleTestCase):
    def test_tojson_ne_peut_pas_fermer_le_script_et_conserve_la_valeur(self):
        valeur = {"titre": "Été </script><script>alert(1)</script> & suite"}
        sortie = str(tojson(valeur))
        self.assertNotIn("</script>", sortie)
        self.assertNotIn("<script>", sortie)
        self.assertIn("Été", sortie)
        self.assertEqual(json.loads(sortie), valeur)

    def test_json_script_genere_une_balise_inerte_et_echappee(self):
        sortie = Template(
            "{% load json_extras %}{{ data|json_script:'donnees' }}"
        ).render(Context({"data": {"html": "</script><b>x</b>"}}))
        self.assertIn('type="application/json"', sortie)
        self.assertIn('id="donnees"', sortie)
        self.assertNotIn("</script><b>", sortie)
        self.assertIn("\\u003C", sortie)

    def test_html_unescape_et_sanitize_html_retirent_les_scripts(self):
        echappe = str(html_unescape(
            "&lt;p onclick=\"alert(1)\"&gt;Texte&lt;/p&gt;"
            "&lt;script&gt;alert(2)&lt;/script&gt;"
        ))
        brut = str(sanitize_html(
            '<p onclick="alert(1)">Texte</p><script>alert(2)</script>'
        ))
        for sortie in (echappe, brut):
            self.assertIn("<p>Texte</p>", sortie)
            self.assertNotIn("onclick", sortie)
            self.assertNotIn("<script", sortie)

    def test_css_value_ne_peut_pas_creer_une_deuxieme_regle(self):
        sortie = clean_css_value("red; } body{display:none} @import 'x'")
        for caractere in ";{}@":
            self.assertNotIn(caractere, sortie)

    def test_css_bloc_conserve_le_css_local_et_retire_les_sorties(self):
        sortie = clean_css_block(
            ".carte{background:url(/media/fond.webp);color:red}"
            "</style><script>alert(1)</script>"
            "@import url(https://tiers.example/style.css);"
        )
        self.assertIn("url(/media/fond.webp)", sortie)
        self.assertNotIn("</style", sortie)
        # Dans un élément <style>, l'analyseur HTML est en mode texte brut :
        # seule la fermeture </style> permettrait au <script> suivant de
        # redevenir du balisage exécutable.
        self.assertNotIn("</style><script", sortie)
        self.assertNotIn("tiers.example", sortie)
