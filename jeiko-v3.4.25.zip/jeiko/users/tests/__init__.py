"""Tests du module `users`."""
