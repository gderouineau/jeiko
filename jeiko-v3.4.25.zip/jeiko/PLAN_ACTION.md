# JEIKO — état des lieux et plan d'action

> ## Revue du 17/09 — ChatGPT et OMP (MiniMax M3), relus par Claude
>
> **1442 tests passent sur PostgreSQL**, avec la commande officielle
> `ENV/bin/python manage.py test jeiko --parallel 4 --noinput`. `check` est
> propre, `makemigrations --check --dry-run` ne trouve rien, les 298 gabarits
> compilent et aucun commentaire `{# … #}` n'est sur plusieurs lignes.
>
> **Ce qui a été rejoué, pas seulement relu :** l'aller-retour `GET` → `PATCH`
> d'un fond (A-54), le partage d'un média entre deux blocs IMAGE (M-02), la
> collision id/slug d'un modèle de fiche (A-65), `mesure_obsolete` dans le
> guide (P1), le lien d'évitement et le repère unique de l'administration
> (A-01). Les journaux de ChatGPT annoncent 1334 tests ; l'écart avec 1442
> vient des cinq fichiers de tests purs du lot OMP 5, livrés après sa
> dernière mesure et non encore commités à ce moment-là.
>
> **S-21 `[x]` — le rouge et le vert purs disparaissaient des e-mails.**
> Défaut constaté par OMP, confirmé par ChatGPT, laissé ouvert : `_color`
> écartait toute couleur « finissant par `,0)` », donc aussi `rgb(255, 0, 0)`
> et `rgb(0, 128, 0)`, dont le dernier zéro est le bleu. `_hex_color` passant
> par lui, l'attribut `bgcolor` — celui qu'Outlook lit pour peindre un `<td>`
> — perdait ces fonds. La transparence se juge maintenant sur une quatrième
> composante nulle. Les trois tests de caractérisation d'OMP verrouillent le
> comportement voulu. **Non couvert :** la syntaxe `rgb(255 0 0 / 0)`, que
> l'éditeur ne produit pas.
>
> **Les dix-sept fichiers `done_*.md` sont vidés**, et laissés en place à la
> demande de Guillaume. Leur contenu reste dans l'historique git ; le compte
> rendu tient dans ce plan, qui est la seule carte.
>
> **Les fichiers de test portent tous le même nom.** Douze fichiers
> `tests_X.py` d'`administration/` et `administration_menu/` deviennent
> `test_X.py`. Django les trouvait déjà — son motif est `test*.py` —, mais
> deux conventions cohabitaient. Trente-trois en-têtes `# jeiko/…` et
> vingt-six chemins de ce plan désignaient encore l'ancien emplacement.
>
> **⚠ À faire avant d'utiliser le code récent sur la base de travail :** elle
> n'a pas appliqué `administration_pages` 0058 à 0062. Elles ont été jouées
> sur la base de tests, jamais sur celle-ci. `showmigrations` le confirme ;
> `migrate` reste à lancer après vérification. Un retour arrière de 0062
> après avoir partagé un média demande de résoudre les références multiples
> avant de rétablir l'unicité.
>
> **Deux imports restent inutilisés** dans `administration_menu/views.py`
> (`MenuLayout`, `MenuStyle`) après le lot OMP 2. Le paquet en compte 214 :
> c'est un chantier à part entière, pas un défaut de ce lot.
>
> **Pas de dépôt distant.** `Art/` n'a aucun `remote` : il n'y a rien où
> pousser tant qu'un dépôt n'est pas créé.

> ## Revue du 15/09 — le travail fait avec ChatGPT (14 et 15/09)
>
> Guillaume a avancé le plan avec ChatGPT pendant qu'on travaillait sur
> Avantion. Relu et rejoué le 15/09. Les comptes rendus de ChatGPT sont dans
> les fichiers `done_chatgpt.md` de chaque module, **conservés pour
> l'instant** à la demande de Guillaume.
>
> **Le résultat tient : 1266 tests passent sur PostgreSQL.** Mais la
> validation annoncée — « 727 tests sur SQLite » — ne l'était pas : elle était
> lancée module par module, sur une autre base, et **la commande officielle
> `manage.py test jeiko` ne tournait plus du tout**.
>
> **Q-16 — un paquet `tests/` à la racine de `jeiko/` casse la découverte.**
> `ImportError: 'tests' module incorrectly imported from …/jeiko/tests.
> Expected …/jeiko`. Le rangement des tests dans un dossier `tests/` par
> module est voulu (demandé par Guillaume) et fonctionne ; seul le dossier de
> même nom à la racine du paquet posait problème. Renommé
> `jeiko/tests_transversaux/` le 15/09 : la commande officielle retrouve ses
> 1266 tests. **Ne jamais recréer `jeiko/tests/`.**
>
> Le même jour, le rangement voulu par Guillaume est allé au bout : les 38
> fichiers de test encore posés à la racine de huit modules (`calendars`,
> `cookies`, `courses`, `emailing`, `payments`, `questionnaires_expert`,
> `stats`, `users`) et du paquet ont rejoint `<module>/tests/test_*.py` et
> `tests_transversaux/`. Les quatorze modules qui ont des tests les rangent
> désormais tous ainsi.
> Imports relatifs et chemins bâtis sur `__file__` suivis d'un niveau ;
> toujours 1266 tests.
>
> **Git est en place sur `Art/` depuis le 15/09**, en liste blanche. Des
> commits, jamais de push : le dépôt sert à tracer qui fait quoi.
>
> **Vérifié en l'exerçant, pas seulement en lisant :** route API inconnue →
> 404 JSON en `GET`, 405 JSON en `POST` ; `qui-suis-je` rend le quota
> (`utilises`, `restants`, `maximum`, fenêtre, réinitialisation) ; la
> migration `0060` ne supprime que des `ContentImage` sans `Content` — seul
> modèle à pointer vers eux —, et les mouvements de stock ne sont créés qu'à
> la vente, donc un produit jamais vendu reste supprimable.
>
> **Points signalés le 15/09, statuts actualisés le 17/09** :
>
> * **A-54 `[x]` — corrigé le 17/09 après reproduction sur PostgreSQL.**
>   Le fond lu est accepté tel quel ; les alias `image.id` / `image_id` et
>   `image.reglages` / `reglages_image` sont normalisés, leurs contradictions
>   refusées en JSON 400. Les nulls et PATCH partiels sont pris en charge.
> * **M-02 `[x]` — fonds et blocs IMAGE partagent le média.**
>   Migration nouvelle `0062_share_contentimage_media` : `ForeignKey` en
>   `PROTECT`, réglages distincts par bloc, inventaire multi-usages testé.
>   **Mise en service locale en attente :** la base de travail n'a pas
>   appliqué 0058–0062 ; aucune migration n'y a été lancée par ce lot.
>   Les migrations ont été exécutées sur la base PostgreSQL de tests.
>   **Validation du lot A-54/M-02, 17/09 :** commande officielle
>   `ENV/bin/python manage.py test jeiko --parallel 4 --noinput`, 1279 tests
>   en 152,878 s, `OK (skipped=1)` ; 13 méthodes de régression ajoutées.
>   `check`, `makemigrations --check --dry-run`, les 298 gabarits et le
>   contrôle des commentaires de templates sont propres.
> * **P1 `[x]` — contrat et guide complétés le 17/09.** `/mesures/` rend
>   `url_testee`, `url_actuelle` et `mesure_obsolete`, désormais expliqués
>   dans le guide et testés avec catégorie et sous-catégorie. L'API lit les
>   relevés existants, elle ne lance pas d'analyse. **Reste une action
>   d'exploitation :** relancer les anciens relevés dans l'administration.
>   Un drapeau false garantit la même URL, pas la fraîcheur du contenu.
> * **A-65 `[x]` — désignation ambiguë refusée le 17/09.** Une collision
>   entre l'id d'un modèle et le slug numérique d'un autre rend un JSON 400
>   avec les deux candidats. `id:12` / `slug:12` permettent de choisir,
>   en filtre des fiches et en création de fiche ou création/PATCH de type.
> * **A-60 / A-63 `[x]` — compléments livrés le 17/09.** Le guide explique
>   le quota par agent et les valeurs réellement vides des gabarits ; les
>   limites (valeur absente, HTML Quill non vide) sont explicites et testées.
>   **Validation du lot agents :** 1302 tests sur PostgreSQL en 100,391 s,
>   `OK (skipped=1)`, dont 23 méthodes nouvelles. `check`, migrations et les
>   298 gabarits sont propres. Pas de migration nouvelle ni de publication.
> * **Identifiants en double dans ce plan** : `S-19` désigne à la fois la TVA
>   du panier et un point d'administration déjà traité (« actif » et « peut
>   se connecter ») ; mon `E-01` de l'éditeur doublait l'`E-01` historique, il
>   devient **E-07**.
>
> **Priorité utilisateur actualisée le 17/09 : E-07 — fidélité du rendu Quill.**
> Guillaume signale un écart très gênant depuis la mise en place de l'IA
> via l'API et demande que le contenu dans Quill ressemble au rendu réel.
> **Prochain chantier prioritaire après la pause, avant A-02/A-03.** Le
> lien temporel est signalé par l'utilisateur ; la cause reste à diagnostiquer.
> Cette mise à jour est documentaire : aucun correctif Quill lancé maintenant.
>
> **A-01 `[x]`, 17/09 — base d'administration accessible au clavier.** Un
> main unique contient écran et messages, avec lien d'évitement avant le menu
> et focus natif sans JavaScript. Sept tests ajoutés, dont quatre vraies vues,
> et parcours Tab/Entrée/Tab vérifié dans le navigateur à 1280 et 390 px.
> Les lots OMP cookies/stats ajoutent 25 tests purs ; deux attentes de dates
> du lot stats sont corrigées au contrôle, sans changement de production.
> **Dernière validation :** 1334 tests PostgreSQL en 102,836 s,
> `OK (skipped=1)`, check/migrations et 298 gabarits propres. Les premiers
> passages interrompus sont documentés, pas assimilés à une réussite.
>
> **Non déclarés terminés par ChatGPT :** A-02 à A-10
> (suite de l'accessibilité ; l'éditeur reste distinct de base_admin),
> les frais des zones de livraison au
> paiement (pas d'adresse structurée), la décision sur le bandeau de
> consentement sans cookie optionnel, la migration vers Python 3.11
> (`google-api-core` cesse de prendre 3.10 le 04/10/2026).
>
> **Ajouté hors plan par ChatGPT, vérifié par la suite :** réglages de
> boutique (activation, page d'accueil `/shop/`, devise, TTC/HT, zones de
> livraison), devise de la commande transmise à Stripe (y compris les devises
> sans décimales), titre interne des images, entrée « Médiathèque » dans
> Réglages. Migrations : `administration_pages 0059–0061`, `shop 0008–0009`,
> `administration 0031`.
>
> `[~]` = fait en partie ; le reste est décrit ci-dessus.


> ## ⚠ O-03 — les rôles d'agents naissaient VIDES sur toute installation neuve
>
> **Constaté le 04/09**, à la première installation de jeiko.fr : la clé
> portait ses huit rôles, et `/qui-suis-je/` répondait **zéro permission**. Le
> rôle s'affiche, s'assigne, se lit — et n'autorise rien.
>
> **La cause tient à l'ordre dans lequel Django travaille.** Les migrations
> 0002 à 0010 cherchent leurs permissions avec
> `Permission.objects.filter(...).first()`. Or Django crée les
> `auth.Permission` dans un signal `post_migrate`, c'est-à-dire **après que
> toutes les migrations sont passées**. Sur un site en service elles sont déjà
> là ; sur un site neuf, le `.first()` rend `None`, le `if permission:` est
> faux, et le rôle est enregistré vide. Sans une erreur.
>
> Le défaut ne pouvait donc se voir qu'à une installation neuve — jamais en
> développement, où la base a déjà migré une fois.
>
> **Second défaut dessous :** `if not cree: return`. Les migrations d'origine
> ne peuplent que si elles viennent de créer le rôle. Un rôle existant mais
> vide n'aurait jamais été réparé, même en rejouant.
>
> **Corrigé par `0011_reparer_les_roles_agents`**, qui force la création des
> permissions (`create_permissions`, la fonction que Django appelle lui-même
> dans son signal) puis peuple **toujours**, donc reste rejouable. Une
> migration de plus plutôt qu'une correction des précédentes : Django ne
> rejoue pas ce qui est appliqué, et corriger 0002-0010 n'aurait réparé que
> les installations futures — le piège déjà rencontré avec 0004, rattrapé par
> 0005.
>
> `agents/tests/test_roles_peuples.py` — 3 tests. La base de test rejoue toutes les
> migrations depuis zéro : c'est exactement le cas qui échouait.
>
> **À retenir.** Une migration de données qui « saute ce qu'elle ne trouve
> pas » ne peut pas signaler qu'elle n'a rien fait. Partout où l'on écrit
> `if quelque_chose:` dans une migration, il faut se demander à quoi ressemble
> le cas où c'est faux — ici, à un site livré sans droits.
>
> **Voir aussi O-04 : l'installeur publié sur GitHub est en retard sur
> `Art/INSTALLER`.** Son gabarit de settings ne connaît pas `jeiko.agents`, ce
> qui a fait échouer l'étape 09 de la même installation. Republier le zip.



> ## ⚠ A-28 — l'alignement des blocs ne faisait rien · CORRIGÉ le 04/09, à publier
>
> `Bloc.horizontal_align` et `vertical_align` existent depuis longtemps,
> l'éditeur les propose, l'API les enregistrait — et **aucun gabarit ne les
> rendait** : `grep -rn "horizontal_align" templates/` ne trouvait rien. On
> réglait, ça sauvegardait, il ne se passait rien. Même famille qu'A-12 et A-22.
>
> Révélé par un bouton « Ajouter au panier » resté centré sous un texte aligné
> à gauche : le centrage venait de `.bloc-BUTTON` dans main.css, et rien ne
> permettait de le contredire.
>
> **Un second défaut dessous.** L'écriture des champs propres
> (`parametres.py`) était un `setattr` brut, sans validation : « flex-start »
> s'est retrouvé dans un champ qui n'accepte que `left`, `center`, `right`,
> `justify`. La base l'a pris, l'API l'a relu fidèlement, et le gabarit — ne
> sachant pas traduire un mot-clé flexbox — n'aurait rien aligné. Le réglage
> avait l'air posé et ne faisait rien.
>
> La validation interroge désormais les `choices` du **modèle**, pas une liste
> recopiée : elle couvre du même coup tous les champs propres, `columns_type`
> compris. `agents/tests/test_alignement.py` — 9 tests.
>
> **Correction d'une note précédente :** `columns_type`, `columns_type_tablet`
> et `columns_type_phone` étaient DÉJÀ exposés par l'API (`CHAMPS_PROPRES`).
> Le manque n'était pas là : `fabrique.creer_ligne()` ne les pose pas à la
> création, et une ligne naît donc en douze colonnes. Un `PATCH` sur la ligne
> les règle — c'est ce qu'il fallait faire, et je ne l'avais pas vu.
>
> **Contournement à retirer après publication :** les cartes de la page
> produit (section 125, bloc 609) sont dans un seul bloc avec une grille CSS,
> et l'alignement du bouton est forcé par
> `.content #bloc-607{justify-content:flex-start;}` dans le CSS de la section
> 123. Le champ porte maintenant `left` en ligne : dès que la version est
> publiée, retirer cette règle et vérifier que le bouton reste à gauche.



## Remontées d'un agent extérieur · 14/09 — EN ATTENTE, rien d'engagé

Relevé par l'agent d'ateliersderouineau.com en construisant
`/electricite/tableau-electrique/`. Chaque point lui a coûté un aller-retour
réel. Consigné tel quel le 14/09 **pour être traité plus tard** — aucune
vérification dans le code n'a encore été faite. Ses propres numéros (N7…,
P1…) sont gardés entre parenthèses pour pouvoir lui répondre.

Ce qu'il salue, et qui sert de modèle : le refus de `columns_type` (la règle,
la conséquence, la valeur à écrire) et celui des clés inconnues sous `fond`.

- `[x]` **A-51 (N7) — `columns_number` doit être posé AVANT les blocs, et le
  guide ne le dit pas.** Le piège le plus coûteux de sa session. Une ligne naît
  à une colonne ; `POST /lignes/<id>/blocs/ {colonne: 1}` est refusé à juste
  titre, mais la séquence n'est écrite nulle part. Il a cru que
  `columns_type` créait les colonnes. À ajouter au guide, là où il décrit la
  structure d'une page :

      POST  /sections/<id>/lignes/
      PATCH /lignes/<id>/  {"columns_number": 3}
      POST  /lignes/<id>/blocs/  {"colonne": 0}   … 1, 2
      PATCH /lignes/<id>/  {"columns_type": "4-4-4", …}

  À rapprocher de l'exemple complet du guide, qui passe par
  `POST /sections/<id>/lignes/ {"colonnes": 2}` : vérifier que les deux
  chemins sont cohérents et que le guide n'en enseigne qu'un.

- `[x]` **A-52 (N8) — `rang` se lit mais ne s'écrit pas à la création.**
  `POST /lignes/<id>/blocs/ {colonne: 0, rang: 0}` → 400. Le rang est attribué
  par empilement, mais le guide met « rang » sur le même plan que « colonne »
  (jusque dans un de ses pièges). Le dire.

- `[x]` **A-53 (N9) — l'écriture d'un bloc TEXT n'a pas d'exemple.** Un bloc
  neuf est `NOT_SET` ; il faut envoyer `type` à chaque écriture, et la clé est
  `texte`, pas `html` — alors que le guide parle de HTML partout. Les deux
  refus sont bons ; c'est l'amont qui manque. Une ligne au guide :
  `PUT /blocs/<id>/contenu/ {"type": "TEXT", "texte": "<p>…</p>"}`.

- `[x]` **A-54 (N10) — symétrie de lecture/écriture du fond.** Corrigé le
  17/09/2026 après reproduction du refus de `image` sur PostgreSQL. Le PATCH
  accepte le document `fond` lu sur sections, lignes et blocs, avec ou sans
  média/réglages. `image.id` et `image_id` doivent concorder, comme les deux
  formes des réglages ; les conflits répondent 400 JSON. URL et alt sont des
  métadonnées de lecture : les valeurs lues sont acceptées, une modification
  est refusée, pas ignorée. Null détache ; une clé absente laisse inchangé.
  Guide actualisé et tests dans `agents/tests/test_fond_et_images_partagees.py`.

- `[x]` **A-55 (N11) — `/fiches/?modele=1` rend une page HTML 404.** Le filtre
  attend un slug ; un identifiant produit du HTML, qu'un agent parse en JSON —
  un objet à 3 000 clés. Seul filtre de l'API qui refuse l'id, alors que l'id
  est la réponse officielle à l'ambiguïté des slugs. Accepter l'id, et
  répondre en JSON quand rien ne correspond. La route réelle est
  `objets/?modele=` — voir A-57.

- `[x]` **A-56 (N12) — les clés de colonnes manquent sur une ligne vide.**
  `GET /lignes/<id>/` sans bloc rend `parametres` sans `columns_number` ni les
  trois `columns_type*` ; elles apparaissent au premier bloc. On ne peut ni
  lire la mise en page d'une ligne vide, ni découvrir ces clés en explorant —
  c'est ce qui l'a mené à A-51.

**Toujours ouverts selon lui, signalés dès le 04/09** — à confronter à ce que
le plan donne pour corrigé, car deux d'entre eux le sont sur le papier :

- `[x]` **(P1) mesures et URL avec catégorie : contrat confirmé.** Le relevé
  historique était antérieur au correctif A-43, pas une nouvelle analyse de
  l'URL actuelle. Le 17/09, le guide explique les trois champs d'adresse,
  l'absence de relevé et la limite du drapeau de péremption ; trois tests
  couvrent l'absence, une URL devenue ancienne et l'URL canonique avec
  catégorie/sous-catégorie. **L'exploitant doit encore relancer les relevés
  anciens dans l'administration** ; ce lot ne lance aucune analyse facturée.
- `[ ]` **(P7 / N2) la médiathèque** : `url` vide sur 38 entrées, `alt` vide
  presque partout, et `image_id` ignoré sur un bloc IMAGE. Il n'a posé aucune
  image sur les pages services pour cette raison. Rapprocher d'**A-48**
  (corrigé le 04/09) et de la phase **M-01…M-05**.
- `[x]` **(N6) `--accent-color` n'existe pas** : les blocs dynamiques ignorent
  le thème (`--jk-*`).
- `[x]` **(P6) `GET /menus/` désigne les catégories par slug**, ambigu depuis
  que deux sous-catégories peuvent partager le leur.

**Deuxième relevé — 58 fiches et 7 pages locales.**

- `[x]` **A-57 (N13) — le guide dit « fiches », la route dit `/objets/`.**
  `GET /fiches/` rend une page HTML 404, parsée en JSON par l'agent : un objet
  à trois mille clés numérotées, qu'il a d'abord pris pour une réponse
  corrompue. Deux corrections distinctes : aligner le vocabulaire, et **rendre
  du JSON sur tout 404 sous `/api/agent/v1/`** — une page HTML n'a rien à y
  faire, quelle que soit la route.

- `[x]` **A-58 (N14) — `slug` est pris à la création et IGNORÉ au `PATCH` d'un
  objet.** Le plus grave de la session, parce qu'irréversible par l'API :
  `PATCH /objets/44/ {slug: …}` → 200, slug inchangé, aucun avertissement.
  Onze fiches mal nommées restent en ligne, dépubliées et renommées « ZZ à
  supprimer ». La clé est connue, donc elle passe le contrôle des clés, et elle
  est ignorée quand même — exactement ce que le guide promet d'éviter. Trancher
  entre modifiable et 400 explicite ; le silence est exclu. Si modifiable :
  l'adresse change, donc passer par `adresses.page_a_cette_adresse`.

- `[x]` **A-59 (N15) — `valeurs` se lit en liste et s'écrit en objet.** Même
  famille qu'A-54 : `GET` rend `[{code, type, valeur}]`, le `PATCH` exige
  `{code: valeur}`. Accepter les deux formes en écriture.

- `[x]` **A-60 (N16) — le plafond d'appels ne s'apprend qu'en le heurtant.**
  Le 429 est jugé parfait ; c'est qu'il arrive au milieu d'une page à moitié
  écrite, sans moyen de la finir ni de la retirer. Ordres de grandeur mesurés
  par l'agent : une fiche ≈ 3 appels, une section de deux blocs 6 à 8, une page
  de cinq sections 35 à 45 — une session de construction dépasse 600 en moins
  de deux heures. `/qui-suis-je/` expose déjà `quota` avec `utilises`,
  `restants`, `maximum`, `fenetre_secondes` et
  `reinitialisation_dans_secondes`. Le guide est complété le 17/09 : plafond
  propre `Agent.plafond_horaire`, repli sur le site, compteur par jeton,
  appel d'identité lui-même compté et attente de `Retry-After`. Deux tests
  confirment le plafond propre et le repli, avec le décompte du premier appel.

- `[x]` **A-61 (N17) — un objet ne se supprime pas.** Côté API, `DetailObjet`
  n'a que `get` et `patch`, et le guide n'en dit rien — il explique l'absence
  de suppression pour les pages seulement. Côté administration, Guillaume ne
  peut que modifier ou dupliquer (14/09). La route `object_delete` existe
  pourtant, le lien « Supprimer » est dans `object_list.html`, et la vue
  exige `custom_objects.delete_customobject`. Pistes relevées, non vérifiées :
  * la vue filtre `model__is_product=False` — un objet d'un modèle marqué
    produit tombe en 404 ;
  * `Product.content` est en `PROTECT` — supprimer un objet qui porte un
    produit lèverait `ProtectedError`, donc un 500 si rien ne l'attrape ;
  * la permission, absente d'un rôle.
  Règle à décider comme pour les catégories : suppression permise quand rien
  n'en dépend (produit, commandes), refus qui dit quoi sinon.

- `[x]` **A-64 — supprimer certains produits rend un 500.** Remonté par
  Guillaume depuis l'administration le 14/09, page d'erreur générique. Cause
  vérifiée en lisant ce qui pointe vers `Product` :

      shop.CartItem.product              PROTECT   ← la cause
      shop.OrderLine.product             SET_NULL  (les commandes survivent)
      shop.ProductImage.product          CASCADE
      shop.ProductStockMovement.product  CASCADE
      administration_pages.ContentButton SET_NULL

  Un produit présent dans **un panier, abandonné compris**, ne peut pas être
  supprimé : `ProtectedError`, que `ProductDeleteView`
  (`shop/views/admin.py`) n'attrape pas — aucune occurrence de
  `ProtectedError` dans `shop/`. D'où « certains » : ceux qui dorment dans un
  panier. `custom_objects/services.py` sait déjà attraper `ProtectedError` et
  `RestrictedError` ; la même garde manque ici.

  Deux choses à trancher avec le correctif :
  * que faire des paniers — refuser en disant combien en contiennent le
    produit, ou les vider d'abord (un panier abandonné n'engage personne) ;
  * **l'historique de stock part en `CASCADE`** : supprimer un produit efface
    ses mouvements. Pour une comptabilité de stock, c'est probablement à
    protéger — un produit retiré de la vente se désactive, il ne se supprime
    pas.

  À traiter avec A-61 : même geste — supprimer ce dont d'autres lignes
  dépendent —, même besoin d'un refus qui dit quoi au lieu d'un 500.

- **(pour Guillaume, pas un défaut)** Deux fiches « Convention » dans le 15e
  en local élec, `/co/local/convention/` et `/co/local/convention-dadef5/`,
  se font concurrence sur la même recherche. L'agent n'a touché à aucune. Le
  suffixe `-dadef5` dit aussi qu'un slug en double est complété en silence à
  la création — à rapprocher d'A-58.

**Troisième relevé — gabarits de fiche et mise en page.**

- `[x]` **A-62 (N18) — aucune répartition à cinq colonnes.** La liste fermée
  va de une à quatre colonnes puis saute à six : douze ne se divise pas par
  cinq. Pas un défaut, mais on cherche la valeur avant de comprendre. Au
  minimum une phrase au guide (« utilisez deux rangées ») ; à décider si l'on
  ajoute des approchantes — `2-2-4-2-2`, `3-2-2-2-3`, `2-3-2-3-2`.

- `[x]` **A-63 (N19) — documenter ce qui marche : le gabarit qui s'adapte.**
  Un jeton `[%champ%]` sur un champ vide rend un élément réellement vide
  (`<h3 class="…"></h3>`, sans espace), donc `:empty` s'applique :
  `.content .x:empty { display: none }` masque les emplacements non remplis, et
  un seul gabarit sert des fiches à contenu variable. Condition : la bordure et
  le padding sur l'élément HTML, pas dans les paramètres du bloc — un bloc
  garde sa bordure même vide. Les jetons traversent l'assainissement partout,
  répétés compris. Guide complété le 17/09 et six tests couvrant la chaîne
  API → contexte de fiche → vrai partiel TEXT. La promesse concerne une
  valeur explicitement vide (`""` ou null), pas une valeur jamais enregistrée
  ni un jeton inconnu (ils restent littéraux). `<p><br></p>` de Quill n'est pas
  vide pour `:empty`. La compatibilité Quill existante reste inchangée.

- `[x]` **A-65 — id de modèle et slug numérique en collision.** Résolveur
  partagé pour les filtres `/objets/` et `/fiches/`, la création de fiche et
  la création/PATCH de type de produit. Refus explicite JSON 400 avant toute
  écriture ; références `id:…` et `slug:…` pour lever l'ambiguïté. Dix tests
  couvrent collisions, absence d'écriture, choix explicite, anciens cas non
  ambigus et entrées invalides, dont `²` qui provoquait une conversion 500.
  Les autres familles de références id/code ne sont pas modifiées par ce lot.

**État du site à la date du relevé : aucune mise à jour depuis 3.4.22.** Tout
ce qui a été fait ensuite en local n'y est pas — clés inconnues refusées à la
création, unicité par adresse et migration `0058`, suppression d'une catégorie
vide, guide des trois voies. Certains points ci-dessus pourraient en être
touchés ; les relire au regard de ce travail avant de s'y mettre.


## Remontées d'un agent extérieur · 04/09

Un assistant a reçu la clé d'ateliersderouineau.com et le seul mode d'emploi
que l'API sert d'elle-même — pas nos notes, pas notre mémoire des pièges. Il a
construit, et rapporté huit points. Ce qu'il a trouvé n'est pas ce qu'on
aurait cherché : ce sont les endroits où l'API répond « oui » sans rien faire,
ou répond juste en mesurant autre chose.

C'est l'exercice à refaire à chaque version. Un lecteur qui sait où sont les
pièges ne les voit plus.


### A-48 — la moitié de la médiathèque était invisible à l'API · corrigé le 04/09

Deuxième passage du même lecteur extérieur, et **une correction de son propre
diagnostic** qui vaut d'être notée : il avait d'abord conclu « trente-huit
entrées sur quatre-vingt-quatre n'ont aucun fichier ». Vérification faite sur
le rendu, c'était l'inverse — les fichiers existent, sont servis en
production, déclinés en cinq variantes.

C'est l'API qui ne les voyait pas. Elle lisait `original_image` et rien
d'autre, quand le rendu prend `laptop_size` en priorité et ne retombe sur
l'original qu'en dernier recours. Une image dont l'original a disparu —
effacé pour gagner de la place, jamais conservé par un import — sortait donc
avec « url: "" » tout en s'affichant parfaitement.

Conséquence : un agent ne pouvait ni décrire ni choisir la moitié de la
médiathèque. Et rien ne le disait — la réponse était bien formée,
l'identifiant correct, le champ simplement vide.

`_fichiers_de_l_image()` suit désormais l'ordre de préférence du rendu et
expose `variantes`. Le drapeau `fichier_absent`, ajouté la veille sur le
premier diagnostic, était donc FAUX : il signalait des images utilisables. Il
garde son nom et son sens véritable — aucun fichier dans aucune variante.

> La leçon dépasse le cas : une réponse d'API doit répondre à la question
> posée — « puis-je m'en servir » — et non à celle du schéma de la base.


### A-49 — la relecture ne montrait pas ce que le visiteur verrait · corrigé le 04/09

Le plus coûteux du lot, parce qu'il désarmait la parade que le guide
recommande lui-même.

L'assainissement s'appliquait AU RENDU, pas à l'écriture. L'API stockait donc
le HTML brut et le rendait fidèlement à la relecture — `<svg>` intact, viewBox
et path compris — pendant que le visiteur voyait une page amputée. Un agent
écrivait, relisait, constatait que tout était en place, publiait. Le guide lui
conseille pourtant, à raison, de relire ce qu'il écrit : ici la relecture
confirmait tout, et mentait.

L'API des agents assainit maintenant à l'écriture. Ce qui est stocké est ce
qui sera servi, et la réponse du `PUT` porte un tableau `avertissements`
nommant chaque balise, attribut et propriété de style retirés. Il est vide
quand rien n'a été touché — c'est ce qui en fait un signal.

`clean_html` reste la barrière au rendu, et le restera : elle protège les
contenus déjà en base et ceux qui arrivent par d'autres voies.

**Reste ouvert.** Les contenus écrits depuis l'administration sont toujours
stockés bruts et assainis au rendu. C'est le même écart. L'éditeur montre à
son rédacteur ce qu'il vient de taper, pas ce qui sera servi — c'est ainsi que
l'accroche d'A-46 est partie en production dans la mauvaise couleur.


### A-50 — un repli écrit à la main devenait de la bouillie · corrigé le 04/09

`<details>` et `<summary>` n'étaient pas dans la liste blanche. Leur retrait
était le pire des trois cas possibles : les balises tombaient, leur texte
restait, collé. `<details><summary>plus</summary>corps</details>` sortait en
« pluscorps ».

Ni l'une ni l'autre ne peut exécuter quoi que ce soit — c'est un repli natif,
sans une ligne de script. Elles sont ouvertes.


### A-43 — PageSpeed mesurait la mauvaise adresse · corrigé le 04/09

`page_public_url()` bâtissait l'adresse sur `url_tag` seul. Une page rangée
dans « électricité » et servie à `/electricite/accueil/` était mesurée sur
`/accueil/`. Trois pages distinctes se retrouvaient mesurées à la même
adresse, deux autres sur des adresses inexistantes — en affichant
« performance 100 », puisque Lighthouse note très bien une page d'erreur,
légère et sans images.

**Le défaut ne touchait pas que l'API : toute mesure lancée depuis
l'administration sur une page en catégorie était fausse.** Le relevé était
plausible, daté, chiffré. Il mesurait autre chose.

L'adresse vient désormais de `get_absolute_url()` — la même source que les
menus et le plan du site. Et on refuse de mesurer un brouillon, qui répond 404.


### A-44 — une clé inconnue dans des paramètres était avalée · corrigé le 04/09

`PATCH /sections/126/ {"couleur_de_fond": "#ffffff"}` répondait 200 sans rien
changer. `parametres.appliquer()` lisait les clés qu'elle connaissait et
laissait tomber le reste.

Le mode d'emploi PROMETTAIT l'inverse — « une clé inconnue est refusée, jamais
ignorée ». La promesse était tenue pour les contenus de bloc, dont le message
d'erreur est un modèle du genre, et pas pour les paramètres.

Pour un humain, c'est une minute perdue. Pour un agent, c'est pire : il tient
le 200 pour une confirmation et passe à la suite.

Le refus est posé au premier niveau et sous « fond », avec la liste des clés
acceptées dans le message.


### A-45 — la voie normale de création fabriquait l'état cassé · corrigé le 04/09

Deux moitiés du même défaut.

`_verifier_les_repartitions()` existait — mais comptait les BLOCS PRÉSENTS et
exemptait les lignes vides. Or régler la répartition est précisément ce qu'on
fait sur une ligne vide : le contrôle ne s'appliquait jamais au moment où il
servait. Il se mesure désormais à `columns_number`.

Plus grave, en amont : `creer_ligne()` posait `columns_number: 3` en laissant
`columns_type` au défaut du modèle — « 12 », c'est-à-dire UNE colonne. Un agent
qui suit la documentation à la lettre — « crée une ligne à trois colonnes, pose
trois blocs » — obtenait deux blocs écrasés à trente pixels, sans qu'une seule
erreur ne soit levée. Une ligne naît maintenant décrite.


### A-46 — l'éditeur produisait des styles que le rendu détruisait · corrigé le 04/09

L'éditeur propose de colorer un mot ; il écrit `<span style="color: …">`.
`style` ne figurait dans aucune liste blanche : il était retiré au rendu. Le
texte restait bleu dans l'éditeur et sortait noir sur le site. **Des accroches
sont parties en production dans la mauvaise couleur**, sans que rien ne le
signale — ni à l'exploitant, qui voit sa couleur à la saisie, ni à un agent,
qui reçoit un 200.

Le défaut n'était pas le retrait : un `style` libre est une porte ouverte sans
avoir besoin du moindre script — `position:fixed; inset:0` recouvre la page
d'un calque qui détourne les clics, `url()` fait signer chaque affichage à un
tiers. Le défaut était qu'un bouton de l'éditeur produise quelque chose que le
rendu détruit.

`style` traverse maintenant, filtré déclaration par déclaration sur une liste
fermée de six propriétés qui ne positionnent pas, n'animent pas et ne chargent
rien : `color`, `background-color`, `text-align`, `font-weight`, `font-style`,
`text-decoration`.

`tests_style_en_ligne.py` garde les deux moitiés — ce qui doit passer, ce qui
doit tomber — et une troisième classe verrouille la LISTE elle-même : une
propriété ajoutée à la légère la percerait sans qu'aucun autre test n'échoue.


### A-47 — trois réponses qu'un agent ne pouvait pas exploiter · corrigé le 04/09

Aucune n'était un défaut de fonctionnement. Ce sont des réponses qui obligent
à deviner, et deviner est ce qu'un agent fait mal. Trois ajouts de clé, aucune
rupture :

* `categories_detail` sur les menus — deux sous-catégories peuvent
  légitimement partager un slug (« articles » sous électricité et sous
  plomberie) ; la liste de slugs ne disait pas laquelle le menu servait ;
* `fichier_absent` sur les images — trente-huit entrées de médiathèque sur
  quatre-vingt-quatre n'avaient aucun fichier, indiscernables des bonnes ;
* `gabarit_de_fiche` sur les pages — « publiee: true » sur une page qui répond
  404 est un signal contradictoire que rien n'expliquait.


### Q-15 — pas de palette par catégorie · à arbitrer

Les catégories portent déjà les menus, donc l'arborescence et la navigation.
Elles ne portent pas l'identité : un site construit en deux univers — bleu
pour l'électricité, teal pour la plomberie — doit peindre chaque bloc à la
main, et `var(--jk-accent)` y est inutilisable puisqu'il rendrait la couleur
du thème.

Le zonage est donc à moitié fait. Leur faire porter une palette optionnelle
qui surcharge les `--jk-*` sur les pages de la catégorie le finirait : une
couleur d'univers se changerait en un appel.

Chantier, pas correctif. Non urgent (arbitré le 04/09).


### A-42 — le titre et la description d'une page ne changeaient jamais · corrigé le 04/09

Écrire les métadonnées par l'API réussissait, la base était juste, et la
page continuait de servir aux moteurs de recherche **l'ancien titre et
l'ancienne description**. Pendant trente jours.

`base.html` met le `<head>` en cache sous une clé qui contient
`metadata.updated_at`. Or `save(update_fields=["title", "description"])`
n'écrit pas un champ `auto_now` absent de la liste : Django le calcule dans
`pre_save`, puis ne l'envoie pas. L'horodatage restait figé, la clé de
cache aussi.

Défaut particulièrement traître : relire la page par l'API confirmait la
nouvelle valeur. Seul le HTML servi mentait, et personne ne le compare à la
base. Même famille que A-12, A-37, A-39, A-40 — une écriture qui réussit et
ne produit rien.

Corrigé au niveau du **modèle** et non de l'appelant : `jeiko/horodatage.py`
fournit `HorodatageFiable`, qui force les champs `auto_now` dans toute
sauvegarde partielle. Posé sur `Metadata`, `SiteIdentity` et `Logo` — les
trois dont l'horodatage sert de clé de cache dans `base.html`.

`administration_pages/tests/test_horodatage.py` verrouille les deux moitiés : le
comportement modèle par modèle, et la LISTE elle-même — toute clé
`{% cache %}` du gabarit appuyée sur un `updated_at` doit correspondre à un
modèle protégé, sans quoi le test échoue en nommant le manquant.

> **À faire au déploiement.** Sur les sites déjà en service, le fragment du
> `<head>` reste en cache avec l'ancienne valeur : purger le cache une fois
> après la mise à jour. Le défaut ne reviendra pas ensuite.


### Q-13 — la pastille de mise à jour restait allumée après la mise à jour · corrigé le 04/09

`WebSite.update_available_version` est un instantané pris par le cron : « le
canal publiait 3.4.6 la dernière fois qu'on a regardé ». Ce n'est pas la
réponse à « une mise à jour existe-t-elle », parce que la seconde moitié de
la comparaison — la version installée — change précisément au moment où
l'administrateur agit. Après une mise à jour réussie, les cinq lecteurs du
champ continuaient donc d'annoncer une action déjà faite, jusqu'au prochain
passage du cron, vingt-quatre heures plus tard.

La comparaison est refaite à la lecture, par `WebSite.mise_a_jour_disponible`.
Les cinq lecteurs — badge du menu, tuile du tableau de bord, barre
d'administration, écran des réglages, page de mise à jour — y passent
désormais. L'écran de mise à jour efface en outre l'instantané périmé, une
fois, plutôt que de laisser en base une valeur qu'on sait fausse.

Le verrou qui compte n'est pas le test de comportement mais celui qui
interdit de relire le champ brut ailleurs : sans lui, le sixième lecteur
écrit demain ramènerait le défaut intact.


### A-40 — la feuille de style générée a été cassée, et publiée · corrigé le 04/09

**Le plus instructif de la journée, parce que c'est une erreur de méthode et
non de conception.**

En insérant la règle des crédits dans `base_style.html` par une expression
régulière, la coupure est tombée **au milieu d'une variable Django** :
`font-size: {{font.size}` au lieu de `{{font.size}}`. Le gabarit compilait, la
page se rendait, `manage.py check` passait, les 1042 tests passaient — et le
navigateur abandonnait le bloc `<style>` à la première accolade manquante.

Toute la typographie du site est tombée aux valeurs par défaut du navigateur.
Le défaut a été publié, et ne s'est vu qu'en mesurant les styles calculés dans
un vrai navigateur : menu en Times, crédits en Times, corps de texte en Times.

**Ce qui n'a rien vu, et pourquoi.** Rien ne regardait si le CSS produit tenait
debout. La compilation d'un gabarit vérifie la syntaxe Django, pas celle du CSS
qu'il émet. Un test qui rend la page vérifie qu'elle répond, pas que sa feuille
se parse. Le seul contrôle possible était dans le navigateur — c'est-à-dire
nulle part dans la chaîne.

`administration/tests/test_feuille_de_style_valide.py` — 4 tests, tous exécutables
sans navigateur :

* aucune variable de gabarit ne subsiste dans le CSS rendu ;
* les accolades s'équilibrent ;
* aucune propriété de police sans valeur (`margin` et `padding` exclus : un
  bloc sans marge produit légitimement `margin: ;`, et un test qui crie pour
  rien finit désarmé) ;
* les sélecteurs de chaque rôle sont présents.

**La leçon de méthode.** Une insertion par expression régulière dans un gabarit
qui contient `{{ }}` est dangereuse : `[^}]*?\}` s'arrête sur l'accolade d'une
variable, pas sur celle de la règle. Pour ce genre d'édition, découper sur des
ancres explicites — ici, le `{% endwith %}` du bloc visé — plutôt que sur des
accolades.

---

### A-41 — les rôles de survol faisaient bouger tous les boutons · corrigé le 04/09

Constat : « partout les boutons quand je passe dessus ils bougent ».

Les polices comptent onze rôles, dont trois de survol : `links_hover`,
`menu_hover`, `sub_menu_hover`. Régler `links` sans régler `links_hover` laisse
ce dernier à son ancienne valeur — 22 px là où la base passe à 17. Tout lien,
donc tout bouton, grossit de cinq pixels sous le curseur, la ligne tressaute et
le clic rate.

**C'est un piège de conception, pas une erreur de saisie.** Un rôle de survol
n'a de raison d'être que pour la COULEUR : la taille et la graisse devraient
suivre leur rôle de base par défaut. À trancher — soit les champs de métrique
disparaissent des rôles de survol, soit l'interface avertit quand ils diffèrent.
En attendant, régler un rôle impose de régler son survol.

---

### A-37 — changer une police ou une couleur ne se voyait pas · corrigé le 04/09

Une échelle typographique posée par l'API : valeurs justes en base, relues
correctement — et le visiteur continuait de recevoir l'ancienne feuille de
style. On changeait une police, rien ne bougeait, et on en concluait que le
réglage ne fonctionnait pas.

`website_cache` garde l'objet de site pour éviter une requête par rendu. Son
invalidation était branchée sur `WebSite`, `SiteIdentity`, `Logo` et
`Favicon` — **mais ni sur `Font`, ni sur `Fonts`, ni sur `Theme`**. La vue du
thème appelait `invalidate_website_data()` à la main ; celle des polices, non.

Le défaut touchait donc l'administration autant que l'API : il suffisait
d'emprunter un chemin qui n'y avait pas pensé.

Le signal est désormais branché sur le **modèle** : vrai pour l'administration,
pour l'API, et pour tout chemin d'écriture à venir. Un correctif posé sur une
vue ne protège que cette vue.

`administration/tests/test_invalidation_cache.py` — 5 tests, portant sur le
comportement (remplir le cache, écrire, vérifier qu'il est vide) plutôt que sur
le câblage des signaux.

---

### A-38 — les crédits du pied de page écrasaient le bas de page · corrigé le 04/09

Après A-34, les crédits suivaient le rôle « texte » — donc dix-sept pixels.
« Réalisé par… » pesait autant qu'un paragraphe.

Ils héritent maintenant de la **famille** du site, jamais de sa taille ni de sa
couleur : treize pixels, gris atténué. C'est une mention, pas du contenu.

---

### A-39 — l'apparence d'un formulaire n'était pas réglable · corrigé le 04/09

`ContentFormulaire.style` porte la couleur du bouton, celle du titre, le rayon
des angles — et n'était pas exposé. Tout formulaire posé par l'API gardait le
bleu par défaut (`#2563eb`), qui jure sur un site aux couleurs de la maison.

Un bouton d'envoi qui ne ressemble à aucun autre bouton de la page ressemble à
une erreur, pas à un choix — et c'est le dernier élément que voit quelqu'un
avant d'écrire.

La validation reste au modèle (`validate_form_style`) : on l'appelle plutôt que
de recopier ses bornes. Conséquence documentée dans le guide :
`var(--jk-accent)` n'est pas accepté, il faut la valeur hexadécimale.

`agents/tests/test_style_formulaire.py` — 6 tests.

---

### A-33 — le plafond d'appels empêchait de construire · corrigé le 04/09

En montant jeiko.fr, l'agent a épuisé les **six cents appels horaires** du
défaut, puis s'est vu refuser — avec le même message que pour un jeton
invalide, les refus étant volontairement indistinguables.

Le plafond n'était pas mal choisi : il est large pour un agent qui ENTRETIENT
un site. Il est trop juste pour un agent qui en CONSTRUIT un — une dizaine de
pages demande plusieurs centaines d'appels, chaque bloc en valant deux ou
trois. Un réglage unique ne peut pas servir les deux usages, et c'est l'usage
initial, le plus légitime, qui se trouvait empêché.

`Agent.plafond_horaire` : réglable **sur la fiche de l'agent**, vide = plafond
du site. Le compteur reste porté par le préfixe du jeton et non par l'agent,
pour qu'un jeton de secours ne soit pas déjà épuisé au moment où l'on en a
besoin. La fiche affiche le plafond — c'est la première question qu'on se pose
devant un agent refusé.

Le défaut du site passe par le `.env` (`JEIKO_AGENTS_APPELS_PAR_HEURE`) dans le
gabarit de settings, sinon la mise à jour suivante l'écraserait. `echecs_ip`
reste distinct et documenté comme tel : c'est lui qui arrête quelqu'un qui
essaie des jetons au hasard, et le relever affaiblirait une vraie garde.

`agents/tests/test_plafond.py` — 6 tests.

---

### A-34 — la police du site ne descendait pas jusqu'aux crédits · corrigé le 04/09

Constat après un changement de police : « le footer avec le menu est bien passé
en Inter, mais pas le bas bas ».

Le menu du pied recevait la police — il porte `.menu`, visé par les règles
générées. Les crédits n'étaient visés par **aucune** règle et restaient dans la
police par défaut du navigateur. Sur un site entièrement rhabillé, c'est le
seul bloc qui détonne, et il figure en bas de chaque page.

Rattachés au rôle « texte », sur les trois appareils. Le test lit le CSS
généré, pas un rendu : c'est cette feuille qui part chez le visiteur.

---

### A-35 — un `<a>` ne peut pas envelopper des blocs · à connaître

Pas un défaut à corriger, une **contrainte du produit** qu'il faut savoir.

Écrire `<a class="carte"><p>Titre</p><p>Texte</p></a>` dans un bloc TEXT donne
**trois liens** au rendu : l'assainissement HTML scinde le lien autour des
éléments de bloc. La carte se disloque, et rien ne le signale — le contenu
s'enregistre, la relecture par l'API rend le HTML tel qu'envoyé.

La forme qui tient : le lien sur le titre, étendu à la carte par une surface
transparente (`position:relative` sur la carte, `::after{inset:0}` sur le
lien). C'est ce qu'utilise l'index des fonctionnalités de jeiko.fr.

---

### A-36 — une répartition doit décrire TOUS les blocs · corrigé le 04/09

Pour empiler trois blocs sur téléphone, on écrit spontanément `"12"` — une
colonne pleine largeur. Or `"12"` décrit une ligne d'**un** bloc. Les deux
suivants ne reçoivent aucune largeur : ils tombent à **trente pixels**, soit
trois caractères par ligne.

Rien ne le signalait. La valeur est dans les choix du modèle, elle
s'enregistre, la page se rend — et le défaut ne se voit qu'en réduisant la
fenêtre, c'est-à-dire chez les visiteurs. La bonne valeur est `"12-12-12"` :
autant de segments que de blocs.

L'API refuse désormais une répartition dont le nombre de segments ne
correspond pas au nombre de blocs, en donnant la bonne valeur dans le message.
Le contrôle ne s'applique qu'aux lignes déjà remplies : une ligne se prépare
avant d'être garnie.

**À noter aussi :** la grille des lignes n'a **aucune gouttière** entre blocs,
sur aucun appareil. Les cartes se touchent tant qu'on ne pose pas de marges à
la main. Ce n'est pas un défaut au sens strict — les marges sont un paramètre
de bloc — mais c'est un défaut de DÉFAUT : toute ligne à plusieurs blocs paraît
ratée avant qu'on y touche. À trancher : poser une gouttière par défaut
déplacerait la mise en page de tous les sites en service.

---

### A-32 — les catégories ne pouvaient pas organiser les URL · corrigé le 04/09

Trouvé en montant jeiko.fr de zéro — l'exercice fait exactement ce qu'on en
attendait.

**Premier manque.** `Category.show_cat_in_url` décide si la catégorie apparaît
dans l'adresse des pages qu'elle contient : `/documentation/api/` plutôt que
`/api/`. Il vaut `False` par défaut et n'était **pas exposé**. Une catégorie
créée par l'API ne servait donc qu'au classement, jamais à l'organisation du
site — et rien dans la réponse ne le disait : il fallait regarder l'adresse
d'une page qu'on venait de classer.

Ouvert sous le nom `afficher_dans_l_url`, avec un défaut à **True** : une
catégorie créée pour ranger des pages est presque toujours destinée à se voir.
Celle qui ne sert qu'au regroupement le dit explicitement. Plus
`PATCH /categories/<id>/`, sans lequel une catégorie mal créée restait
invisible pour toujours — le slug étant unique, la création ne se rejoue pas.

**Second manque.** L'unicité du `url_tag` était vérifiée sur TOUT le site. La
base ne l'impose qu'aux pages sans catégorie (`uniq_url_tag_when_no_category`).
Deux pages « editeur-de-pages », l'une dans « Fonctionnalités » et l'autre dans
« Documentation », étaient donc refusées — alors que leurs adresses diffèrent
et que c'est précisément ce que demande une organisation en catégories.

L'API était plus stricte que la base, et sa sévérité rendait impossible le cas
d'usage normal.

`agents/tests/test_champs_de_page.py` — 7 tests ajoutés.

---

### Phase 19 — l'administration devient traduisible · 04/09

**Le cadrage, et pourquoi il décide de l'ordre.** 95 % des sites sont
monolingues, mais pas forcément en français. Ce n'est donc pas d'abord un
problème de traduction de CONTENU — c'est un problème de langue de l'OUTIL.
Traduire l'admin sert tout le monde ; un moteur multilingue de contenu ne
servirait que les 5 % restants et coûte bien plus cher.

**Ce qui est livré : la mécanique complète**, sans laquelle marquer 192
gabarits ne produirait rien.

* `LANGUAGES` (fr, en, es, de), `LOCALE_PATHS`, `LANGUAGE_CODE` pilotable par
  le `.env` — un exploitant hispanophone ne doit pas éditer `settings.py` ;
* `LocaleMiddleware`, placé après la session et avant `CommonMiddleware` —
  l'ordre est imposé par Django ;
* `jeiko/i18n.py` et son middleware, placé **après** l'authentification :
  `LocaleMiddleware` s'exécute avant elle et ne peut donc pas consulter une
  préférence de compte. La préférence suit ainsi la personne, pas le
  navigateur ;
* `Profile.langue_admin`, exposé au formulaire de profil, avec « Langue du
  site » comme défaut. Vide ≠ français : un site passé à l'espagnol doit
  emmener ceux qui n'ont rien choisi ;
* une langue non proposée par le site est ignorée — sinon l'interface
  retomberait sur l'anglais de Django, ce qui ressemble à une panne ;
* `locale/en/` traduit et compilé, sur les 55 libellés du menu.

**La traduction anglaise ne couvre que le menu, et c'est délibéré** : elle
existe pour éprouver la chaîne de bout en bout — réglages, middleware,
préférence, compilation, rendu. Chacun de ces maillons est invisible seul, et
un `.po` complet posé sur une chaîne rompue n'aurait rien traduit sans que rien
ne le dise. La suite se fait écran par écran ; une chaîne non traduite retombe
sur le français, ce qui est le bon comportement.

`tests_transversaux/test_i18n.py` — 11 tests.

---

### A-31 — la bannière de cookies pouvait être VIDE · corrigé le 04/09

Révélé par le montage de `LocaleMiddleware`, pas causé par lui.

Les catégories de cookies étaient filtrées par langue **exacte**. Or elles ne
sont saisies que dans la langue du site : un visiteur anglophone obtenait une
liste vide. Ce n'est pas un affichage dégradé — une bannière sans catégorie ne
permet pas de recueillir un consentement, il n'y a rien à accepter ni à
refuser.

Second piège, plus discret : les catégories sont créées avec `LANGUAGE_CODE`
(« fr-fr ») tandis que `get_language()` rend la forme normalisée (« fr »).
Sans middleware de langue les deux valaient « fr-fr » et se rencontraient **par
accident**. Le monter a rompu l'accident — et c'est ainsi que le défaut est
apparu, par un test qui vérifiait qu'une catégorie strictement nécessaire ne se
refuse pas : sans catégories, plus rien n'était forcé.

La recherche procède désormais par élargissements — langue exacte, famille
(« en-gb » accepte « en »), langue du site, puis tout. Elle n'est jamais vide
s'il existe la moindre catégorie. 4 tests ajoutés.

**Ce que cet épisode enseigne.** Une correspondance qui tient « par accident »
ne se voit pas tant que l'accident dure. Ici, activer une fonction sans rapport
l'a rompue — et le seul garde-fou a été un test écrit pour autre chose.

---

### S-20 — un e-mail obligatoire qui échoue ne prévenait personne · corrigé le 04/09

**Constat :** « je n'ai pas reçu le mail de réinitialisation ». En reproduisant,
l'envoi échoue et **la seule trace est un `logger.info`** noyé dans le journal,
plus une ligne `EmailLog` en `failed` que personne ne consulte.

Trois abandons silencieux se ressemblaient : pas de modèle configuré, modèle
inactif, échec SMTP. Tous en `info`, tous sans conséquence visible. Le
destinataire ne reçoit rien, l'exploitant ne voit rien, et le seul symptôme est
une **absence** — qui ne se remarque pas. Même mode d'échec que S-17.

**La distinction posée.** Un e-mail ordinaire qu'on n'envoie pas est souvent une
décision (modèle décoché, pas d'opt-in) : `info` convient. Un e-mail
**obligatoire** qu'on n'envoie pas est une panne fonctionnelle — sans la
réinitialisation, l'utilisateur qui oublie son mot de passe perd son compte.
Cela part désormais en `logger.error`, avec la conséquence écrite dans le
message : un exploitant qui lit un code d'erreur passe à autre chose, un
exploitant qui lit « l'utilisateur ne peut plus accéder à son compte » agit.

`registry.is_mandatory` est l'autorité — le même qui empêche de décocher ces
e-mails. `emailing/tests/test_echecs_obligatoires.py` — 4 tests, dont un inventaire
qui vérifie que les douze obligatoires ont un modèle actif avec un corps.

---

### S-21 — le rouge et le vert purs disparaissaient des e-mails · corrigé le 17/09

`_color` (`emailing/render.py`) écarte les couleurs totalement transparentes,
parce qu'Outlook les peint en noir. Le test était « la valeur finit par `,0)` ».
Dans un `rgb()`, ce dernier zéro est le **bleu** : `rgb(255, 0, 0)` et
`rgb(0, 128, 0)` tombaient dedans. Un fond rouge ou vert réglé dans l'éditeur
partait donc sans couleur, et comme `_hex_color` commence par appeler `_color`,
l'attribut `bgcolor` — celui qu'Outlook lit pour peindre un `<td>` — le perdait
aussi.

Même famille que S-17 et S-20 : le symptôme est une **absence**. Le défaut
épargnait le bleu, ce qui achevait de le rendre illisible depuis le résultat.

La transparence se juge désormais sur une quatrième composante nulle, seule
forme qui décrit un canal alpha. **Ce que cela ne couvre pas :** la syntaxe
`rgb(255 0 0 / 0)`, que l'éditeur ne produit pas, et le mot-clé `transparent`,
que `bgcolor` accepte tel quel.

Constaté par OMP, confirmé par ChatGPT et laissé ouvert : les trois tests qui
le caractérisaient dans `emailing/tests/test_helpers_rendu_purs.py` verrouillent
maintenant le comportement voulu, et échouent contre l'ancien helper.

---

### A-29 — les pages « mot de passe » sortaient de la charte · corrigé le 04/09

**Constat :** « la page de réinitialisation est super moche ». Elle l'était.

Connexion et inscription passent par les vues de JEIKO
(`users/views/auth.py`, gabarits `users/client/`). **La famille « mot de
passe », elle, traverse les vues d'allauth** — et le paquet ne surchargeait
aucun de ses gabarits. Sur ateliersderouineau, un gabarit du projet prenait le
relais, avec des classes Bootstrap absentes du site et un bouton libellé « Se
connecter » sur un formulaire de mot de passe.

Cinq gabarits ajoutés au paquet : demande, confirmation d'envoi, choix du
nouveau mot de passe (lien périmé compris), confirmation, et changement depuis
un compte connecté. Même enveloppe `content-allauth` que la connexion.

Deux points de fond :

* la page de confirmation ne dit **pas** si un compte existe pour l'adresse
  saisie — le dire en ferait un outil de vérification d'adresses ;
* un lien périmé explique ce qui s'est passé et propose d'en redemander un.
  Allauth s'arrête sur un refus ; une personne qui lit « non » referme.

**À faire côté serveur :** ateliersderouineau porte encore
`templates/account/password_reset*.html` dans son projet, qui passent devant
ceux du paquet. Les supprimer sur le serveur pour que le correctif s'applique.
Un site installé par l'INSTALLER n'a pas ce problème — il ne pose qu'un
`templates/` vide.

`users/tests/test_pages_mot_de_passe.py` — 6 tests.

---

### A-30 — la page de mise à jour ne disait pas quelle version attend · corrigé le 04/09

Le job `cron_24h` relève la version publiée et l'enregistre dans
`WebSite.update_available_version`. La donnée était là ; la page ne l'affichait
nulle part. On lisait « Version installée : 3.4.9 » et un bouton, sans savoir
ce qu'on allait installer ni s'il y avait quelque chose à installer.

**Trois états, et pas deux.** « Vérification en échec » et « à jour » se
ressemblaient — aucune annonce dans les deux cas — si bien qu'un site coupé de
son canal de publication avait l'air à jour et restait à l'écart des correctifs
sans que rien ne le dise.

L'annonce est **hors** des branches d'erreur de la page, délibérément : elle
renseigne sur le canal, pas sur l'état du serveur. La cacher derrière
« configuration correcte » la rendait invisible exactement quand elle sert le
plus. `administration/tests/test_page_mise_a_jour.py` — 4 tests.

---

### Phase 18 — réglages de la boutique · livré le 04/09

Nouvel onglet **Boutique ▸ Réglages** : TVA par défaut, devise, seuil de
livraison offerte. Le modèle `ShopSettings` est un singleton, comme
`MailSettings`.

La TVA se réglait produit par produit, avec un défaut par type. Cela suffit
jusqu'à dix produits ; ensuite, changer un taux demande de reprendre chaque
fiche et le premier oubli passe inaperçu jusqu'à la facture.

**Ce réglage ne réécrit rien**, et c'est vérifié plutôt que promis : un type ou
un produit existant garde son taux. Une commande dont le montant changerait
après coup serait un problème comptable, pas un réglage. Le taux du site sert
de défaut aux nouveaux types.

Le formulaire borne le taux à [0, 100] — `DecimalField` ne borne rien, et la
base aurait accepté 250 %. `shop/tests/test_reglages.py` — 8 tests.

---

> ## S-19 — la TVA s'affichait faux dans le panier · TRAITÉ le 14/09, vérifié le 15/09 — voir « Revue du 15/09 »
>
> **Constaté le 04/09 en production**, en simulant un achat sur
> ateliersderouineau. Panier contenant « Structure », 99,00 € HT, TVA 20 % :
>
> ```
> Sous-total HT   99,00 EUR
> TVA (estimée)   Calculé au paiement
> Total TTC       118,800 EUR        ← trois décimales
> ```
>
> Attendu : **118,80 €**. Ce n'est pas un arrondi discutable, c'est un montant
> qui n'a pas la forme d'un prix. Sur une page de panier, c'est ce que le
> client lit avant de payer.
>
> **Pistes, non vérifiées** — à confirmer avant de corriger :
>
> * `Product.price_ttc` (`shop/models.py:349`) et `CartItem.total_ttc`
>   (`shop/models.py:554`) sont des propriétés **sans arrondi** : elles
>   rendent `99 × 1.20` en Decimal brut. `to_money()` existe
>   (`shop/services.py:26`, ROUND_HALF_UP au centime) et n'est appliqué qu'au
>   total agrégé (`services.py:50`).
> * Reste à établir **quel chemin le gabarit du panier affiche réellement** :
>   si c'est la propriété non arrondie, l'affichage est faux partout où elle
>   sert ; si c'est le total agrégé, le défaut est ailleurs et l'arrondi n'est
>   pas la cause. **Ne pas conclure sans l'avoir regardé.**
> * Vérifier aussi ce qui part dans les e-mails de commande
>   (`shop/emailing.py:109`) et dans les montants envoyés au paiement
>   (`to_minor_units`) : un écart de centime côté Stripe ne se voit qu'au
>   rapprochement bancaire.
>
> **Pourquoi c'est prioritaire.** Un prix mal formé fait douter du reste, et
> un écart d'arrondi entre ce qui est affiché et ce qui est débité est un
> problème comptable, pas cosmétique.
>
> « TVA (estimée) — Calculé au paiement » mérite aussi d'être tranché : soit on
> sait calculer la TVA au panier, soit la ligne ne devrait pas annoncer un
> total TTC juste au-dessus.
>
> **À faire dans la foulée (04/09) : une entrée « Boutique ▸ Gestion » dans le
> menu d'administration**, qui manque aujourd'hui — taxes, livraison, et le
> reste des réglages commerciaux. C'est le même sujet : ces valeurs décident
> de ce que le client paie, et elles ne sont réglables nulle part.



*Constat du 17/08/2026, tenu à jour au fil des correctifs.*

Ce document est la mémoire du chantier : il porte les constats, ce qui est
livré, ce qui reste, et les décisions prises. Les identifiants (`S-01`, `A-12`,
`Q-11`…) sont ceux cités dans les commentaires du code.

Légende : `[x]` fait · `[~]` partiel · `[ ]` à faire

Pour les conventions de travail (où éditer, comment vérifier, les pièges) :
voir `CLAUDE.md` à la racine de `Documents/Projects`.

---

## Où en est-on

Publié en **3.3.0** le 21/08/2026 : phase 1 terminée, régression d'affichage
corrigée, administration mobile réparée.

| | |
|---|---|
| Tests | **692 passent** (637 à la 3.2.3, 558 avant le chantier) |
| Gabarits | 283, **0 erreur de compilation** |
| `check` / migrations | aucun problème, aucune migration manquante |

### Ce que 3.3.0 corrige, et pourquoi elle est mineure et non corrective

**3.2.3 éteignait tout le contenu de toutes les pages sous 992 px** — mobiles
et tablettes, site public comme éditeur (A-17). Constaté en ligne sur
accompagnementhumain.com. C'est le motif de la publication.

Une version mineure plutôt qu'un correctif se justifie : la livraison ne fait
pas que réparer, elle **change ce que le produit accepte**. Les validateurs de
S-10/S-11 refusent des fichiers qu'un site prenait jusqu'ici — une image de
plus de 10 Mo, un PDF qui n'en est pas un. Un exploitant qui voit un import
échouer après mise à jour doit pouvoir rattacher ce changement à un numéro de
version.

**Six migrations, dont deux touchent des données** : `calendars/0017` chiffre
les clés Google existantes, `courses/0005` rattrape ce que `courses/0004`
n'avait pas repris. Les quatre autres n'ajoutent que des validateurs.

Reste à passer `jeiko-client-update` sur chaque site : c'est ce qui rallume
les mobiles.

---

## 1. Livré

### Défauts visibles par les visiteurs

- `[x]` **A-12 — le menu mobile ne s'ouvrait sur aucun layout.** Le binding
  Alpine était décomposé : `mobile ? 'is-open' : ''` se trouvait *à l'intérieur*
  de l'attribut `class`, avec un `:` orphelin à la place de `:class`. La classe
  `is-open` n'était jamais posée, et `toggle_menu.html` laissait donc le panneau
  en `display:none`. **Le site public était sans navigation sur mobile.**
  Verrouillé par `administration_menu/tests/test_layouts.py`.

- `[x]` **Q-11 — le CSS de production avait neuf à onze mois de retard.**
  L'éditeur chargeait `main.css`, le site public `main.min.css`, maintenu à la
  main : 175 sélecteurs sur 370 manquaient en ligne. C'est l'origine des écarts
  observés entre l'éditeur et le rendu réel. La minification se fait désormais à
  `collectstatic` (`jeiko/staticfiles.py`), les `.min.css` ont disparu du paquet.

- `[x]` **Q-11 bis — deux défauts de mon propre correctif, corrigés après la
  première mise en production.** Le balayage portait sur tout `STATIC_ROOT`, donc
  sur des fichiers périmés que `collectstatic` n'efface jamais ; et le filtre
  « déjà minifié » testait le suffixe `.min.css`, que l'empreinte
  (`main.min.<hash>.css`) fait échouer. D'où dix traces `csscompressor` par
  déploiement, sans conséquence mais bruyantes.

- `[x]` **S-05 — le bloc graphique était mort dès qu'on le configurait.**
  `options_json` est un `JSONField` rendu en repr Python dans `x-data` :
  `{'beginAtZero': True}` sortait avec `True`, inexistant en JavaScript, d'où une
  `ReferenceError` et aucun graphique. Toute option contenant un booléen ou un
  `null` cassait l'affichage. Les options passent par un bloc
  `<script type="application/json">`.

- `[x]` **Le bandeau cookies était partiellement non stylé en ligne.** La branche
  non-DEBUG de `base.html` ne chargeait ni `menu.css`, ni `consent.css` — seule
  la branche DEBUG était complète, ce qui rendait l'écart invisible en
  développement.

- `[x]` **Les leurres anti-robots étaient visibles.** `.cf-hp` n'était stylé
  nulle part : le champ « Société » du formulaire de contact s'affichait, les
  visiteurs le remplissaient de bonne foi, et leur message était rejeté.

- `[x]` **A-17 — le contenu de toutes les pages était éteint sous 992 px.**
  *Régression introduite par le correctif A-12, sortie en 3.2.3.* En réparant
  le sélecteur cassé `[x-cloak="menu"]` de `menu.css` — Alpine écrit
  `x-cloak=""`, la règle ne correspondait donc à rien — on l'a élargi à
  `[x-cloak]` tout court. Or `partials/bloc.html` posait cet attribut sur
  **chaque bloc de chaque page**, et Alpine ne l'en retire jamais : le bloc ne
  porte aucun `x-data`, ce n'est pas un composant, Alpine ne le visite pas.
  Sous 992 px, tout passait en `display:none !important` — public et éditeur.

  Deux erreurs ont été nécessaires, deux verrous les ferment :
  `nav.top-menu [x-cloak]` borne la règle au menu, et le bloc ne porte plus
  d'attribut inutile. `administration_pages/tests/test_bloc_cloak.py` refuse toute
  règle `[x-cloak]` non bornée, dans n'importe quelle feuille du paquet.

  **Ce que cet épisode dit du reste du plan** : rien ne le voyait. Les 637
  tests passaient, les 283 gabarits compilaient, le HTML rendu était complet et
  correct — c'est le CSS qui l'effaçait, et seulement en dessous d'une largeur
  qu'on n'a pas sur un écran d'ordinateur. C'est l'argument le plus concret
  pour la phase 4, et pour un contrôle de rendu à deux ou trois largeurs.

### Inscription et comptes

- `[x]` **S-15 — confirmation d'adresse obligatoire.**
  `ACCOUNT_EMAIL_VERIFICATION = "mandatory"`. Le compte ne sert qu'une fois le
  lien suivi.
- `[x]` **Bienvenue et alerte à l'exploitant déplacées** de `user_signed_up` vers
  `email_confirmed` : plus de « Bienvenue » avant confirmation, et l'exploitant
  n'est prévenu que des comptes qui existent vraiment.
- `[x]` **Antispam à l'inscription** — leurre + trois plafonds par IP
  (`users/throttling.py`). Le formulaire reçoit la requête par
  `CustomSignupView.get_form_kwargs` : `SignupForm` d'allauth ne la prend pas, et
  sans elle le plafond serait global.
- `[x]` **Purge des comptes non confirmés à 30 jours** (`users/purge.py`, inscrite
  dans `cron_24h`). Protège le personnel et tout compte porteur d'une commande,
  d'une formation ou d'un rendez-vous.
- `[x]` **Migration `users/0010`** — marque vérifiés les comptes antérieurs.
  **Indispensable et non réversible** : sans elle, le passage en `mandatory`
  enfermait dehors la totalité des comptes existants.
- `[x]` **S-19 — l'administration confondait « actif » et « peut se connecter ».**
  Depuis le passage en `mandatory`, un compte a deux états sans rapport :
  `User.is_active` — non désactivé — et l'adresse confirmée, qui vit dans
  `EmailAddress` (allauth). La liste n'affichait que le premier, en vert : un
  compte fraîchement inscrit s'y lisait « Actif : Oui » alors qu'il était
  inutilisable, et l'exploitant cherchait la panne ailleurs.

  La liste affiche désormais l'état **effectif** (`Non — e-mail non confirmé`),
  la fiche sépare les deux, et deux gestes sont offerts : renvoyer le lien, ou
  **confirmer à la place du titulaire** — porte de service pour les adresses
  qui ne reçoivent rien, réservée à `auth.change_user` et tracée au journal de
  sécurité, puisqu'elle ouvre un compte. Côté visiteur, l'écran d'attente
  d'allauth — anglais, hors charte, sans issue — est remplacé et porte un
  bouton **Renvoyer l'e-mail**, plafonné (3 par quart d'heure et par compte,
  10 par heure et par IP). Le compte vient de la session, jamais d'un champ :
  sinon l'écran devient un service d'envoi ouvert doublé d'un révélateur de
  comptes existants. `jeiko/users/verification.py`, 13 tests.

  **Décision prise le 23/08/2026, à ne pas rouvrir sans raison :
  `is_active` n'est PAS mis à `False` pour un compte non confirmé.** La
  tentation est forte — « ils doivent être inactifs » — mais ce drapeau a son
  propre sens, celui d'une suspension décidée par l'exploitant. Le confondre
  avec la confirmation coûterait trois choses : Django refusant d'authentifier
  un compte inactif, il faudrait un récepteur sur `email_confirmed` pour le
  repasser à `True`, sans quoi le lien reçu par e-mail ne servirait plus à
  rien ; `users/purge.py` s'appuie sur la distinction ; et le filtre « Actif »
  de la liste changerait de sens sans prévenir. C'est l'affichage qui mentait,
  pas la donnée.

- `[x]` **Suppression de comptes** — unitaire et en masse, avec refus motivé.
  À distinguer de l'effacement RGPD : `Supprimer` retire la ligne (faux comptes),
  `Effacer les données` anonymise et conserve les commandes (demande d'un client).

### E-mails

- `[x]` **Logo dédié aux e-mails** (`Logo.mail_logo`, facultatif). Sa présence
  vaut activation ; vide, on retombe sur le logo du site.
- `[x]` **Correction du logo servi.** `_logo_url` prenait `computer_size`, une
  variante **WebP** — format qu'Outlook pour Windows n'affiche pas. Tous les
  e-mails partaient avec un logo cassé chez une partie des destinataires.
  L'ordre est maintenant : logo dédié → original (PNG/JPEG) → variantes WebP.
- `[x]` **Absence d'URL de site journalisée.** Sans elle, toutes les images de
  tous les e-mails sont relatives donc cassées — et invisible depuis
  l'administration, puisque le site les affiche parfaitement.

### Sécurité et conformité

- `[x]` **S-04** — les trois générateurs JSON échappent `<`, `>`, `&`
  (identité du site, boutique, questionnaires).
- `[x]` **S-13** — les deux fragments d'éditeur exigent `change_page`.
- `[x]` **S-17** — `X_FRAME_OPTIONS = "DENY"`, avec
  `@xframe_options_sameorigin` sur la seule vue d'aperçu d'e-mail.
- `[x]` **S-18** — `css_vars` nettoie avant d'interpoler dans un attribut `style`.
- `[x]` **R-03** — l'avatar est effacé du disque à l'effacement RGPD.
- `[x]` **R-04** — `stats_purge` et `jeiko_calendars_purge` inscrites dans
  `cron_24h` : elles existaient et n'étaient appelées nulle part.
- `[x]` **Q-03** — file d'écriture des statistiques plafonnée (1000).
- `[x]` **Q-01** — écran d'arborescence des profils de questionnaire, et
  suppression des deux gabarits qui ne compilaient pas.
- `[x]` **E-04, A-10a, D-04, Q-10** — cache du `<title>`, `<h1>` sur les pages
  d'erreur, page 500 autonome, fichiers morts.

### Corrections d'audits antérieurs

`AUDIT_EDITOR.md` est à réviser sur trois points :

- **C3** y est marqué « volontairement non fait » : il **a été fait** depuis, via
  `administration_pages/page_cache.py`.
- **F5** affirme que `menu_design_1.css` « est bien utilisé » : **non**.
- **B11** décrit une redéfinition d'`addInline` dans un gabarit : il y en a
  **sept**.

`AUDIT_COURSES.md` — ses quatre points sont bien corrigés.

**E-01 était un faux positif** : produits et formations sont déjà correctement
traités (`CustomObject.get_absolute_url()` renvoie l'URL boutique ; l'espace
formation est volontairement en `noindex`).

---

## 2. Reste à faire, par ordre proposé

### Phase 1 — sécurité, correctifs ponctuels · ~1 j · **terminée le 21/08**

- `[x]` **S-01 — `credentials_json` est chiffré** (`calendars/models.py`).
  Le JSON de compte de service Google, clé privée RSA comprise, était en clair
  en base : une sauvegarde égarée suffisait, et une clé qui a fuité ne se
  rattrape pas — il faut la révoquer chez Google et reconfigurer chaque site.
  Migration `calendars/0017`, réversible dans les deux sens (la marche arrière
  passe par du SQL brut, sans quoi l'ORM rechiffrerait ce qu'on déchiffre).
  Vérifié sur les données réelles : aller, retour, aller.

  Deux choses apprises sur `EncryptedJSONField`, notées dans `encrypted.py` :
  il chiffre **les valeurs, pas les clés** (la structure du document reste
  lisible en base), et il rend **les scalaires en chaînes** (`21` ressort
  `"21"`). N'y ranger que des chaînes.

- `[x]` **Rattrapage de `courses/0004`** *(trouvé en faisant S-01)*. Cette
  migration passait `VideoStorageProvider.config` en champ chiffré par un
  simple `AlterField`, sans reprise de données. Comme la colonne ne change pas
  (`jsonb` de part et d'autre), rien ne signalait le problème — mais les lignes
  déjà présentes restaient en clair, et une ligne en clair n'est pas
  déchiffrable : la lecture rendait une `str` là où `courses/utils.py` fait
  `config.get('access_token')`. `courses/0005` reprend les données, et
  `encrypted.py` rétablit le `dict` en journalisant, pour les lignes qu'une
  migration n'aurait pas vues.

- `[x]` **S-14 — `PaymentCheckView`.** Pire que prévu : le
  `payment_intent_client_secret` était **lu puis jamais utilisé**. L'adresse
  acceptait n'importe quel `pi_…`, d'un visiteur anonyme, et réglait la
  commande désignée par les métadonnées — celle d'un autre client comprise.
  Trois gardes : `LoginRequiredMixin`, comparaison du `client_secret` à temps
  constant, et commande restreinte au visiteur. Six tests dans
  `payments/tests.py`.

- `[x]` **S-10 / S-11 — gardes sur les fichiers téléversés** (`jeiko/uploads.py`).

  *Images.* `Image.MAX_IMAGE_PIXELS` descend à 25 Mpx, posé dans
  `apps.ready()` — c'est une variable globale de Pillow, la laisser dépendre
  de l'ordre des imports revient à ne pas savoir si elle est en vigueur. Le
  garde-fou d'origine de Pillow existait, mais à 89 Mpx : de quoi mettre une
  machine à genoux avant qu'il ne serve, d'autant que `ImageContent.save()`
  déplie l'image **cinq fois** pour produire ses variantes. Plafond de 10 Mo
  en complément : 25 Mpx ne dit rien du poids du fichier.

  Le validateur est posé sur les sept champs réellement téléversés — image de
  page, avatar, deux miniatures de formation, logo, logo d'e-mail, favicon,
  icône de réseau social — et **pas** sur les variantes, que nous fabriquons.

  *PDF de formation.* Le champ n'avait **aucun** validateur : ni extension, ni
  poids, ni contenu. Extension, 25 Mo, et vérification de la signature
  `%PDF-` : `serve_pdf` renvoie ce fichier depuis le domaine du site sous un
  `Content-Type` que nous affirmons. `SECURE_CONTENT_TYPE_NOSNIFF` couvre
  déjà le cas, mais c'est un réglage, dans un autre fichier, qu'un site peut
  perdre — la signature, elle, ne dépend d'aucun réglage.

  Dix tests (`tests_transversaux/test_uploads.py`), dont une vraie bombe de
  décompression : un PNG valide de quelques dizaines d'octets dont l'en-tête
  annonce dix mille mégapixels.

  *Ce que cela ne couvre pas* : ces validateurs s'exécutent après réception du
  fichier. La limite de réception reste celle du serveur web
  (`client_max_body_size`). Et une signature `%PDF-` ne dit pas qu'un PDF est
  inoffensif, seulement que ce n'est pas autre chose déguisé.
- `[x]` **S-12 — les six redirections sont validées** (`jeiko/redirections.py`).
  Elles passaient `next` tel quel à `redirect()` : le lien part de votre
  domaine, porte votre certificat, et dépose l'utilisateur sur la copie de
  votre page de connexion. Rien ne casse, rien ne lève — une redirection
  ouverte n'existe que dans le lien envoyé par courriel.

  **Le modèle proposé par ce plan était lui-même faillible.** Le contrôle de
  `administration_pages/views.py` — `startswith('/')` et pas `'//'` — laisse
  passer `/\site-piege.example` : le navigateur traite la barre inverse comme
  une barre à cet endroit. On passe donc par
  `django.utils.http.url_has_allowed_host_and_scheme`, et cet écran-là est
  corrigé avec les six autres.

  Un test relit le paquet et refuse qu'un `next` reparte brut vers
  `redirect()` : c'est ce qui empêche le septième cas d'apparaître.

- `[x]` **S-06 — `clean_svg` couvre les formes qui lui échappaient.**
  Deux trous, vérifiés l'un et l'autre sur l'ancienne version avant
  correction — les cinq charges d'épreuve passaient toutes.

  *La forme auto-fermante.* La branche appariée listait `handler`, `set` et
  `animate`, la branche auto-fermante ne les avait pas : `<set …>…</set>`
  était retiré, `<set …/>` passait. Or c'est leur forme naturelle, ces
  éléments n'ayant pas de contenu — et ils sont retors : ils n'exécutent rien
  eux-mêmes, ils **écrivent un attribut pendant l'animation**.
  `<set attributeName="onload" to="alert(1)"/>` repose donc un gestionnaire
  d'événement *après* le passage du nettoyage. Les deux branches lisent
  maintenant la même liste, augmentée d'`animateTransform` et `animateMotion`.

  *Les références de caractères.* `href="&#106;avascript:alert(1)"` ne
  contient pas le mot `javascript` : rien ne le retirait, alors que le
  navigateur décode la valeur avant de lire le schéma. Le motif accepte
  désormais les mêmes écritures que lui — décimale, hexadécimale, zéros de
  tête, point-virgule facultatif — ainsi que les blancs de contrôle
  intercalés (`java\tscript:`).

  19 tests, dont un jeu d'icônes légitimes qui doivent traverser intactes :
  un nettoyage qui casse les vraies icônes ne serait pas gardé longtemps.

### Phase 2 — RGPD · ~1 j

- `[~]` **R-01 — le bandeau promettait un réglage qui n'existe pas.**
  *Constat révisé le 02/09 : le défaut était l'inverse de ce que ce plan
  supposait.*

  Le plan disait « `stats/middleware.py` mesure sans consulter le
  consentement », sous-entendu qu'il devrait. Vérification faite, **il n'a
  rien à consulter** : une ligne `PageView` porte le chemin, le référent, le
  jour, quatre drapeaux et une durée. **Ni adresse IP, ni identifiant de
  session, ni identifiant de compte, ni empreinte.** Deux vues du même
  visiteur sont indiscernables de deux vues de deux personnes. Et le beacon de
  temps passé ne dépose rien sur l'appareil — pas de cookie, pas de
  `localStorage`.

  Or le consentement ePrivacy porte sur le fait de **stocker ou lire une
  information sur l'appareil**, et le RGPD sur des **données personnelles** :
  ni l'un ni l'autre n'est déclenché. Cette mesure n'a donc rien à demander.

  Le vrai écart était donc : le bandeau annonçait un choix à propos d'une
  mesure qui n'existe pas, et les trois gabarits de base appelaient
  `window.jeikoStartAnalytics` — **définie nulle part**, derrière un `if` qui
  rendait le vide invisible. Le code avait l'air de piloter un dispositif
  d'audience et ne pilotait rien.

  `[x]` **Fait** : la tuyauterie morte est retirée des trois gabarits, et la
  position juridique est écrite en tête de `stats/middleware.py` — avec ce qui
  la ferait basculer. `stats/tests/test_vie_privee.py` refuse tout champ
  d'identification ajouté à `PageView` et tout stockage introduit dans le
  beacon : le jour où quelqu'un voudra « dédoublonner les visiteurs », le test
  dira que la position juridique change, au lieu de laisser le site devenir
  non conforme en silence.

  `[ ]` **Reste une décision qui vous revient** : faut-il encore afficher un
  bandeau de consentement ? Sur ce site, il n'existe **aucune catégorie de
  cookies non essentiels** — zéro en base. Le bandeau demande donc l'accord
  pour quelque chose qui n'a pas lieu, ce qui n'est pas seulement inutile :
  cela entraîne les visiteurs à cliquer « Accepter » par réflexe. La CNIL
  n'exige pas de bandeau quand seuls des cookies exemptés sont posés — il
  reste à informer, dans la politique de confidentialité.

  Je ne l'ai pas décidé seul : masquer le bandeau se voit sur chaque page de
  chaque site client. Trois options — le laisser tel quel, le remplacer par
  une mention informative sans choix, ou ne rien afficher quand aucune
  catégorie non essentielle n'existe (dérivé des données, donc juste sur tous
  les sites).
- `[ ]` **R-02** — les six `except Exception: pass` de l'effacement RGPD
  (`users/rgpd.py`) : journaliser et remonter l'échec partiel.
- `[ ]` **R-05** — rétention sur `SecurityEvent` et `UserSession`.
- `[x]` **R-06 — plus aucune police ni icône tierce** *(02/09)*.

  **Inter est auto-hébergée.** L'administration et l'éditeur la chargeaient
  depuis `fonts.googleapis.com` : chaque ouverture d'écran envoyait l'adresse
  IP de l'exploitant chez un tiers, sans consentement possible et sans
  nécessité — cette police ne change jamais, elle fait partie du produit.
  Huit fichiers woff2 livrés dans le paquet (521 Ko), sous-ensembles **latin et
  latin-ext seulement** : embarquer le cyrillique, le grec et le vietnamien
  quadruplerait le poids pour des glyphes qu'une administration française
  n'affiche pas. `unicode-range` est conservé, donc un caractère absent
  retombe sur la police système au lieu d'un carré vide. Inter est sous SIL
  Open Font License — redistribution autorisée.

  **Le kit FontAwesome est retiré.** Il était chargé sur les deux pages
  **publiques** de questionnaire, qui n'utilisent aucune icône. Chaque visiteur
  envoyait son IP à `kit.fontawesome.com` pour rien.

  **Deux exceptions déclarées, et assumées** : l'éditeur sert les polices DU
  SITE par le CDN — l'aperçu doit refléter un changement avant enregistrement —
  et les quatre écrans de choix de police interrogent le CDN pour prévisualiser
  une famille. On ne peut pas auto-héberger ce qu'on n'a pas encore choisi.
  Une fois la police retenue, `fonts_selfhost.py` la rapatrie et le site public
  ne touche plus au CDN.

  `administration/tests/test_ressources_externes.py` refuse toute nouvelle
  ressource tierce dans un gabarit, et vérifie que les woff2 sont bien dans le
  paquet — basculer les gabarits sur une feuille locale absente ferait
  retomber l'administration sur la police système sans que rien ne le signale.

- `[ ]` **R-06b — trois gabarits utilisent encore FontAwesome, et leurs icônes
  ne s'affichent pas.** Le remplacement par du SVG avait bien été fait partout
  ailleurs ; ces trois-là ont été oubliés, et **personne ne s'en est aperçu
  parce que le kit n'était pas chargé sur leurs bases** — les icônes étaient
  invisibles dans les deux cas.

  | Gabarit | Icônes |
  |---|---|
  | `courses/section_view.html` | 8 |
  | `courses/course_detail.html` | 7 |
  | `users/client/profile_detail.html` | 3 |

  Sept des dix icônes distinctes existent déjà dans `includes/admin_icons.html`
  (chevron, file-lines, file-pdf, plus, video, list-check, question) ; manquent
  `check-circle`, `chevron-right`, `map-marker` et `phone`. Il faut un sprite
  public sur le modèle du sprite d'administration — celui-ci n'est inclus que
  par `base_admin.html`.

  Défaut d'affichage, pas de vie privée : ces pages seront *améliorées* par le
  correctif, elles ne sont pas dégradées aujourd'hui.

### Phase 3 — référencement · ~1 j

- `[x]` **E-05 / D-06 — un seul chantier.** `SocialLink` n'a ni formulaire ni
  écran, *donc* le `sameAs` du JSON-LD reste vide. **Priorité 1 SEO.**
- `[x]` **E-06** — image de partage par défaut + `og:image:width/height/alt`.
- `[x]` **E-03** — `robots.txt` ne doit plus lister les pages dépubliées.
- `[ ]` **S-09** — `ACCOUNT_RATE_LIMITS` sur un cache dédié : aujourd'hui
  publier une page remet à zéro le compteur anti-force-brute d'allauth.
- `[ ]` **S-07 / S-08** — jeton CSRF sur la réservation publique ; plafond et
  leurre sur le questionnaire.
- `[~]` **E-02** — multilingue, reporté (dépend de Q-07).

### Phase 4 — responsive de l'administration · ~2,5 j · **urgent**

Chantier commencé puis laissé. `.jk-filters` (admin_ui.css) vient d'être adopté
par la liste des utilisateurs : cinq filtres passent de dix lignes à deux.

**Priorité relevée (21/08) : l'administration est utilisée quotidiennement
depuis un mobile.** Ce n'est donc pas un confort, c'est le poste de travail.

- `[x]` **A-18 — le menu latéral ne se refermait pas sur téléphone**, et
  s'ouvrait parfois tout seul au chargement. Deux causes, indépendantes.

  *Il s'ouvrait seul.* `admin_menu.css` pose le menu `position:fixed; left:0`
  à toutes les largeurs — déployé par défaut. Ce qui le repliait sous 992 px
  ne vivait que dans `admin_ui.css`, chargée après. Il suffit que cette
  feuille manque — cache de navigateur périmé sur un téléphone, requête qui
  n'aboutit pas — pour que le menu s'affiche en travers de l'écran, et
  qu'aucun bouton ne sache le refermer : leur style vient de la même feuille
  absente. C'est très probablement ce qui s'est produit sur iPhone alors que
  la même largeur se comportait bien sur un ordinateur — en production, le
  nom des fichiers porte une empreinte, ce qui protège de ce cas ; en
  développement, non. L'état replié est désormais déclaré **aussi** dans
  `admin_menu.css` : la redite fait pencher la panne du bon côté.

  *Il ne se refermait pas.* Il n'existait qu'une sortie — le bouton flottant
  — plus la touche Échap, qu'un téléphone n'a pas. Tout reposait donc sur un
  unique élément `position:fixed`. Plutôt que de chercher ce qui le
  recouvrait, on a retiré le point unique de défaillance : un voile qui ferme
  au toucher (le geste que tout le monde essaie d'abord) et une croix à
  l'intérieur du panneau s'ajoutent au bouton. Les quatre sorties vérifiées
  au navigateur, verrouillées par `administration/tests/test_menu_mobile.py`.

- `[x]` **A-19 — la barre rapide débordait de la largeur sur téléphone.**
  Six entrées sur une ligne `flex` sans retour à la ligne. Elles passent
  désormais à la ligne, ce qui rend la hauteur variable — et condamnait le
  `body { margin-top: 30px }` qui lui réservait sa place, écrit pour UNE
  ligne. La barre passe de `fixed` à `sticky` : elle occupe exactement sa
  propre hauteur, sans marge à tenir à jour ni JavaScript à redéclencher à
  chaque rotation d'écran, et reste épinglée en haut au défilement comme
  avant. Le `width: 100vw` est retiré au passage : il compte la barre de
  défilement et provoquait à lui seul un débordement horizontal.
- `[x]` **A-14 — `.jk-filters` généralisée** *(02/09)*. Les trois écrans de
  statistiques — vue d'ensemble, pages, détail d'une page — portaient une
  classe `.filters` **définie nulle part** : leurs filtres tenaient par
  `.jk-kpi-row`, un simple `flex-wrap`. Conséquence sur un écran étroit :
  chaque étiquette et chaque champ étant des frères dans la même rangée, une
  étiquette pouvait se retrouver seule sur une ligne, loin du champ qu'elle
  nomme. `.jk-filter` regroupe les deux dans une colonne — c'est tout l'objet
  de la classe.

  Les autres écrans d'administration n'ont pas de barre de filtres à convertir :
  vérifié un par un.

- `[x]` **A-20 — les tableaux débordaient de la page, y compris sur ordinateur.**
  Constaté sur « Rendez-vous passés » : douze colonnes posées directement dans
  `.admin-content-container`, sans rien pour les contenir. La page entière se
  décale, et les premières colonnes sortent de l'écran.

  `admin_ui.css:272` déclare pourtant `.admin-table-scroll { overflow-x:
  auto; }` — un conteneur qui fait défiler le tableau sans emporter la page.
  **Aucun des 14 gabarits qui utilisent `.admin-table` ne l'emploie.** La
  classe a été écrite et jamais posée : c'est exactement le défaut invisible
  que décrit A-17, un outil correct que rien ne relie à son usage.

  Le travail est mécanique — envelopper 14 tableaux — et devrait s'accompagner
  d'un test qui refuse un `.admin-table` sans conteneur, sans quoi le
  quinzième écran rouvrira le défaut. **À faire avant A-15** : c'est la moitié
  peu coûteuse du problème, et elle règle déjà le cas de l'ordinateur.

  **Fait le 02/09.** Ils étaient **28**, pas 14 : le décompte initial ne
  comptait que ceux portant `.admin-table`, alors que la boutique, les
  statistiques, les rôles et les questionnaires en ont d'autres, écrits
  autrement. Tous enveloppés.

  Un détail découvert en le faisant, et qui décide de tout : `.admin-table`
  porte `width: 100%`. Dans un conteneur qui défile, une table à 100 % **se
  comprime au lieu de déborder** — on obtient douze colonnes illisibles plutôt
  qu'un défilement. D'où le `min-width` posé sur les tables du conteneur : il
  force le débordement, donc le défilement, donc la lisibilité. Envelopper
  sans ce plancher aurait donné l'illusion d'avoir corrigé.

  `administration/tests/test_tableaux.py` refuse le vingt-neuvième, et vérifie que
  la classe et son plancher existent toujours — envelopper des tableaux dans
  une classe supprimée ne ferait rien, et ne se verrait pas.

- `[ ]` **A-15** — tableaux en cartes sous 768 px. *À trancher* : défilement
  latéral (peu coûteux, se lit de travers) ou bascule en cartes (recommandé,
  commencer par utilisateurs / commandes / rendez-vous). A-20 livre déjà le
  défilement latéral ; ce point ne porte donc plus que sur la bascule en
  cartes.

- `[~]` **A-21 — l'écran Performance / Insights ignorait la charte.** Ses boutons sont clair sur clair, à peine visibles :
  `background:#fff` avec une bordure `#888` et aucune couleur de texte posée,
  et les onglets Mobile / Desktop sont `background:transparent; border:none`
  — rien ne dit que ce sont des boutons.

  La cause n'est pas un mauvais réglage de couleur, c'est que l'écran est
  écrit **entièrement en styles en ligne** : 91 attributs `style=` dans
  `administration_pages/insight.html`, trois fois plus que le deuxième gabarit
  le plus chargé. Il n'utilise aucune des classes `.btn`, `.btn-secondary`,
  `.btn-outline-primary` d'`admin_ui.css`, qui portent pourtant les contrastes
  validés et les variables de thème.

  Reprendre l'écran sur les classes existantes le règle, et le rend au passage
  compatible avec A-13 (palette d'accent) et A-11 (mode sombre) — dont il
  serait autrement le seul écran à sortir, ses couleurs étant figées dans le
  balisage. À rapprocher de **A-07** (contrastes) et **D-02** (généraliser les
  composants aux écrans les plus vus).

  **Première passe le 02/09** — ce que l'exploitant voyait est réglé : les
  quatre boutons passent sur `.btn` / `.btn-secondary`, les onglets sur
  `.ui-tab` (qui porte l'état actif), et les trois bandeaux d'état, dont les
  palettes étaient recopiées de Bootstrap v4, passent sur les tokens
  `--state-*` par une classe `.jk-etat` neuve — un rouge doit vouloir dire la
  même chose partout.

  `[ ]` **Reste 80 styles en ligne sur 91.** Ce sont les cartes de score, les
  jauges et les grilles : elles ne gênent pas la lecture aujourd'hui, mais
  tant qu'elles sont figées dans le balisage, cet écran restera le seul à ne
  pas suivre A-13 et A-11.
- `[x]` **A-16 — cibles tactiles à 44 px sous 992 px** *(02/09)*. Les boutons
  faisaient 30 à 36 px, et les liens d'action des tableaux
  (« Voir | Modifier | Supprimer ») étaient du texte nu de 18 px, trois cibles
  côte à côte dont une destructrice. Champs, cases à cocher et boutons radio
  suivent.

  **Rien n'est agrandi au-dessus de 992 px**, et c'est la moitié de la décision
  qu'on oublie : à la souris ces tailles sont justes, et les gonfler abîmerait
  des écrans denses qui fonctionnent. Un test le vérifie explicitement.

### Phase 5 — accessibilité, le socle · ~2 j

- `[x]` **A-01** — `<main>` unique et lien d'évitement dans base_admin,
  livrés le 17/09. Messages dans le repère, menu et confirmation en dehors,
  cible tabindex=-1 et lien visible au focus sans JavaScript. Mise en page
  conservée : les admin-content existants restent dans chaque écran. Sept
  tests (base/CSS et quatre vraies vues), parcours clavier sur desktop/mobile.
  L'éditeur de pages (base_editor) et les bases publiques restent hors lot.
- `[ ]` **A-02** — `aria-describedby` vers l'aide, `aria-invalid` sur les
  erreurs. `includes/field.html` pose déjà l'`id`, aucun champ ne le référence.
- `[ ]` **A-03** — 135 `<label>` sans `for`, dont
  `product_form.html:447` où le `=` manque.
- `[ ]` **A-04** — retirer `role="menu"`/`menuitem`, ajouter `aria-haspopup`.
- `[ ]` **A-05** — sous-menus ouvrables au clic et au clavier (desktop
  uniquement : sur mobile ils sont déjà `display:block`).
- `[ ]` **A-06** — `aria-current="page"`.
- `[ ]` **D-07** — reprendre les designs de menu abandonnés (mêmes fichiers).

### Phase 6 — accessibilité, finition · ~1,5 j

- `[ ]` **A-07** — contrastes : onglet actif à 1,05:1, bordures de champ à
  1,3:1, anneau de focus à 20 % d'opacité.
- `[ ]` **A-08** — `@media (forced-colors: active)`.
- `[ ]` **A-09** — alt obligatoire avec case « image décorative ».
  *Attention* : un alt par défaut automatique est **contre-productif** — le
  lecteur d'écran annonce « image, image ». Il faut un alt écrit, ou vide.
- `[ ]` **A-10** — 404 et 403 éditables. *La 500 ne peut pas l'être* (elle
  s'affiche quand la base est tombée) : la rendre éditable en administration,
  puis en écrire une copie statique sur disque.
- `[ ]` **D-03** — paginer les 14 listes d'administration.

### Phase 7 — thème de l'administration · ~1,5 j

- `[ ]` **A-13** — palette d'accent au choix (6-7 teintes validées en
  contraste), stockée sur `WebSite`.
- `[ ]` **A-11** — mode sombre (`prefers-color-scheme`). *Distinct de A-13* :
  l'un suit le système, l'autre est un choix de couleur.
- `[ ]` **D-09** — unifier les cinq `:root` concurrents (préalable aux deux).

### Phase 8 — robustesse et nettoyage · ~1,5 j

- `[ ]` **Q-05** — sept redéfinitions d'`addInline` en collision avec
  `formsets.js`.
- `[ ]` **Q-02** — journaliser les 28 `except Exception: pass` restants.
- `[ ]` **Q-08** — classifier `Django :: 5.1` faux dans
  `packages/jeiko/pyproject.toml` (hors du périmètre habituel).
- `[ ]` **D-08** — Cookies, Pages légales et Identité sous le système de rôles.
- `[ ]` **D-02** — généraliser `includes/field.html` aux 30 écrans les plus vus.

### Phase 9 — génération de PDF · ~4 j

`Page.is_pdf` **existe déjà** (`models.py:202`) et ne sert qu'à exclure ces pages
du sitemap : le concept était prévu, jamais construit. `emailing/render.py`
(620 lignes, une `Page` → du HTML d'e-mail) est le patron exact à décliner.

- `[ ]` **D-10** — moteur de rendu PDF (WeasyPrint).
- `[ ]` **D-11** — écran des gabarits PDF.
- `[ ]` **D-05** — certificat de formation (aujourd'hui `# TODO`).
- `[ ]` **D-12** — restitution de questionnaire en PDF.

### Phase 10 — rapports périodiques · ~3 j

`envoyer_le_recapitulatif_quotidien()` existe (`emailing/admin_alerts.py`) mais
est figé : une cadence, des indicateurs en dur, aucun réglage.

- `[ ]` **D-13** — préférences par destinataire, cadences cumulables.
- `[ ]` **D-14** — rapport d'inscriptions (quotidien / hebdo / mensuel).
- `[ ]` **D-15** — rapport d'activité en **compteurs** : questionnaires,
  commandes, rendez-vous, prospects, visites. Jusqu'à l'annuel.
- `[ ]` **D-16** — écran de réglage et gabarits au catalogue.

*Deux points à trancher avant d'écrire* : les cadences longues ne peuvent pas
passer par `cron_24h` seul — mémoriser la dernière période envoyée, sur le
modèle de `GoogleCalendarConfig.last_digest_sent_on`. Et il faut des compteurs
avec comparaison à la période précédente, pas des listes : sur un mois, une
liste ne dit rien.

### Phase 11 — tests · ~2 j

- `[x]` **Q-04a** — `templatetags` : 1 459 lignes, **aucun test**, et c'est là
  que vivent `sanitize`, `css_value`, `tojson`. Le code le plus sensible du
  paquet est le moins couvert.
- `[x]` **Q-04b** — `administration` (2 %) et `administration_menu`.

### Phase 12 — accompagnement · ~4 j · reporté

- `[ ]` **D-01** — assistant de mise en route, relançable, plus tableau de bord
  d'installation. `walkthrough.md` fait 0 octet ; c'est le manque fonctionnel le
  plus lourd pour un produit vendu à des non-techniciens.

### Phase 13 — CSP · ~3,5 j · à terme

- `[ ]` **S-03** — la CSP est en `Report-Only`, donc n'empêche rien. Son
  passage en application est bloqué par **129 `onclick=` inline dans 35
  gabarits** et 40 exports `window.*`. Sortir les `onclick` d'abord.
- `[ ]` **S-02** — Quill servi en local avec SRI (indépendant, peut être avancé).

### Phase 14 — bibliothèque de modèles · ~3 j · à terme

- `[ ]` **Q-06** — `model_source` est écrit et jamais lu. Aperçu, renommage,
  compteur d'usages, suppression avertie : E1 à E6 de `AUDIT_EDITOR.md`.

---

### S-18b — le défaut réintroduit par la porte d'à côté · corrigé le 04/09

**Trouvé en vérifiant la publication**, pas autrement. La page produit affichait
enfin « Équipe », le JSON-LD portait le bon nom — et annonçait toujours
`OutOfStock`.

`CreationTypeDeProduit` posait `kind` et `is_physical`, mais **pas**
`requires_shipping`, qui vaut `True` par défaut. Un type créé « service » se
retrouvait donc à exiger une expédition. Or c'est ce champ, et lui seul, que
consultent le panier, le JSON-LD et le décrément de stock depuis le correctif
S-18.

Autrement dit : **le défaut corrigé la veille dans le produit, réintroduit par
le point d'entrée qui crée les types.** Trois champs disent la même chose, et
n'en renseigner que deux suffit à les faire diverger — c'est précisément
pourquoi S-18 avait consisté à n'en garder qu'un comme autorité.

`expedition` découle désormais de la nature, se force explicitement quand c'est
voulu (un « service » qui expédie un support imprimé existe ; l'inverse, non),
et **apparaît en lecture** : la taire l'avait rendue invisible.

Ajout de `PATCH /types-de-produit/<id>/`. Sans lui, un type mal créé restait
faux pour toujours : le code est unique, la création ne se rejoue pas. Corriger
la nature entraîne l'expédition, sans quoi la correction laisserait le produit
invendable pour la raison qu'on croyait avoir réglée.

**Ce que cet épisode enseigne.** Ramener une règle à une source unique ne suffit
pas : il faut aussi que tous les CHEMINS D'ÉCRITURE la respectent. Un correctif
de lecture laisse intactes les portes qui écrivent — et la vérification en ligne
est le seul endroit où ça se voit.

---

### S-18 — aucun service n'était vendable · corrigé le 03/09

**Le symptôme.** Les trois formules JEIKO — 19, 39, 99 € par mois — ne
pouvaient pas être achetées. Pas « mal affichées » : **invendables.** Le panier
refusait l'ajout (« plus disponible en quantité suffisante »), la mise à jour
ramenait la quantité à zéro et supprimait la ligne, et Google recevait
`availability: OutOfStock`.

**La cause : une divergence, pas un oubli.** Trois notions coexistaient pour
répondre à « ce produit s'épuise-t-il ? » :

* `ProductType.requires_shipping` — ce que consulte le décrément de stock **à
  la commande**, et qui était juste ;
* `ProductType.is_physical` — le même champ en plus ancien, intitulé
  « legacy » jusque dans son `verbose_name` ;
* `Product.allow_negative_stock` — un réglage de dépassement, que le panier
  prenait pour une nature.

Le panier refusait donc ce que la commande aurait servi **sans toucher au
stock**. Deux chemins, deux critères, et rien pour les confronter — jusqu'à ce
qu'on essaie de vendre un abonnement. C'est aussi pourquoi « ça fonctionnait
avant » : le chemin de commande, lui, n'a jamais été fautif.

**Le correctif : une seule règle, `Product.suit_le_stock`**, alignée sur
`requires_shipping` — l'autorité, puisque c'est elle qui bouge réellement le
stock. Quatre appelants la partagent désormais : ajout au panier, mise à jour
du panier, décrément à la commande, JSON-LD. Plus les alertes de rupture, qui
prévenaient l'exploitant qu'un abonnement était épuisé.

**Deux tests du dépôt encodaient le défaut** : ils vérifiaient le plafonnement
par stock sur une *formation*, c'est-à-dire qu'ils vérifiaient que le panier
refuse de vendre ce qui ne s'épuise pas. Corrigés, et doublés d'un contrôle
inverse.

`shop/tests/test_achat_service.py` parcourt le chemin complet — panier, mise à
jour, commande — sur un abonnement à stock zéro. C'est le seul contrôle qui
aurait attrapé le défaut : **chaque étape prise isolément avait l'air
correcte.**

---

### Phase 17 — menus, calendrier, mesures · 03/09

**Menus** (`vues_menus.py`, rôle « Agent menus »). La structure et les liens,
pas le design — demandé explicitement. `copie_de` à la création duplique un
menu, arborescence comprise : c'est le geste qui fait les **sous-sites**, où
« Électricité » et « Plomberie » ont des menus identiques à l'œil et des liens
différents. L'affectation se fait sur `Category.main_menu`.

Deux 500 fermées : une disposition posée sur un pied de page (aucune n'y est
autorisée, et une contrainte `CheckViolation` le rendait comme une panne
serveur), et un second menu par défaut sur le même emplacement — transféré
plutôt que refusé, comme la page racine.

**Calendrier** (`vues_calendrier.py`, rôles « Agent calendrier » et « Agent
agenda (lecture) »). Types de rendez-vous et **disponibilités** en écriture ;
créneaux et rendez-vous en **lecture seule**.

Ce découpage n'est pas prudentiel, il est structurel : **on ne crée pas un
créneau**, on déclare une disponibilité qui les génère — et `generate_slots()`
nettoie ceux qui sortent de la plage. Un créneau posé ou fermé à la main serait
défait au prochain passage, sans le dire. Le geste de « je ne suis pas
disponible ce jeudi » est une date exclue sur la plage.

Le garde qui compte : `Slot.availability` et `Appointment.slot` sont tous deux
en CASCADE. Supprimer une disponibilité effacerait **les rendez-vous pris
dessus** — des personnes réelles, disparues de l'agenda sans un mot. L'API
refuse, et dit de fermer la plage à la place.

Deux rôles parce qu'`Appointment` porte le **nom et l'adresse** du client :
une clé qui pose des créneaux n'a pas à lire qui a réservé.

**Mesures PageSpeed** (`GET /pages/<id>/mesures/`, lecture seule). Scores,
Core Web Vitals terrain et laboratoire, contrôles SEO, audits ratés. Un agent
qui construit ne peut pas juger de ce qu'il produit : il voit son HTML, pas le
temps de chargement chez un visiteur. **Rien ne se déclenche** — une analyse
consomme un quota facturé, et une boucle d'agent le viderait en une
après-midi.

**55 routes, toutes documentées avec leur permission. Huit rôles. 953 tests.**

---

### Phase 16 — l'API s'étend à tout le site · 03/09

Quatre surfaces ouvertes, quatre rôles distincts. Le découpage n'est pas
cosmétique : chacun donne un mandat qu'on peut confier séparément.

**Questionnaires** (`vues_questionnaires.py`, rôle « Agent questionnaires »).
Le test, ses profils, ses questions, ses réponses et **leurs poids**, ses
combinaisons et leurs critères. C'est la surface où le travail manuel est le
plus ingrat — vingt questions × quatre réponses × cinq profils font quatre
cents poids à saisir un par un.

Un questionnaire mal construit **ne plante pas : il répond faux.** D'où des
contrôles qui portent sur ce que le calcul verra, pas sur les codes HTTP. Trois
refus ajoutés parce que la base les acceptait : un poids vers le profil d'un
AUTRE test, un intervalle de score inversé (aucun score ne pourrait l'attribuer),
et « ~= » sans tolérance (qui revient à « == »). Plus une 500 fermée :
`parent_profile` est NOT NULL.

Les pages de résultat gagnent enfin leurs clés plates — `[%profil%]`,
`[%profil_description%]`, `[%score%]`, `[%test%]`. Le contexte ne portait que
des OBJETS : écrire `[%profil%]` laissait la chaîne visible sur la page
publique. Même défaut que `[%titre%]` sur les fiches. **Rien qui identifie le
visiteur n'y figure** — une page de résultat est partageable, son URL circule.

Et le bouton « Commencer le test » vérifie que le questionnaire existe : un
slug inconnu produisait un bouton qui ne mène nulle part.

**E-mails** (`vues_emails.py`, rôle « Agent e-mails »). Sujet, corps,
expéditeur, activation. Le corps **est une page** — donc construit par les
mêmes routes que le reste du site. `GET /emails/evenements/` donne les 67
événements du catalogue **avec leurs clés et ce qu'elles contiennent** : c'est
le contrat, et sans lui un agent écrirait des jetons au jugé.

Deux refus qui comptent ici plus qu'ailleurs, parce qu'**un e-mail parti ne
revient pas** : un `[%jeton%]` que l'événement ne fournit pas (il partirait tel
quel sous les yeux du destinataire), et la désactivation d'un e-mail
obligatoire — sans la réinitialisation de mot de passe, un utilisateur qui
l'oublie perd son compte.

**Identité visuelle** (`vues_identite.py`, rôle « Agent design »). Dix couleurs
nommées par leur RÔLE, onze rôles de police × trois appareils × dix attributs :
330 valeurs. Modification partielle partout — une écriture totale obligerait à
renvoyer les 330 pour en changer une, et la première oubliée repartirait à son
défaut. Les valeurs traversent `clean_css_value` : elles finissent dans des
déclarations `--jk-x: …;` sur `:root`.

Rôle à part parce qu'**une erreur d'identité abîme toutes les pages à la fois**,
sans qu'aucune ne paraisse en cause.

**Champs de page** : catégorie et sous-catégorie (par slug, par identifiant ou
par nom — certaines catégories ne servent qu'au regroupement et n'ont pas de
slug), drapeaux de nature, métadonnées **dès la création**. Deux contrôles
ajoutés : une sous-catégorie doit appartenir à sa catégorie (la base accepte
l'incohérence, ce sont deux clés étrangères indépendantes), et déclarer une
nouvelle racine transfère l'ancienne au lieu de lever une `UniqueViolation`
rendue en 500.

`is_protected` reste fermé : c'est un contrôle d'accès, pas de contenu.

**Politique de version, inscrite dans le guide.** La v1 promet que le nom et le
sens d'une clé, le chemin d'une route et la permission qu'elle exige ne
bougeront pas. Le jour où l'un doit bouger, une `/v2/` sera servie **à côté**,
le temps que les agents migrent — jamais à la place. Les refus de clés
inconnues rendent cette promesse tenable.

42 routes, toutes documentées avec leur permission. **907 tests.**

---

### A-27 — les clés inconnues étaient avalées · corrigé le 03/09

Deux appels ont renvoyé **200 OK sans rien écrire**, pendant le montage des
formules :

* `PUT /blocs/604/contenu/` avec `texte_questionnaire` — l'API attend
  `text_questionnaire`. `corps.get(type.lower()) or {}` transformait la faute
  de frappe en succès, et le gabarit restait vide ;
* `PATCH /pages/88/` avec `active` — le champ s'appelle `publiee`. La page est
  restée en brouillon, et la réponse disait 200.

Trouvés en ouvrant la page publique, pas autrement. Les clés inconnues sont
désormais refusées, avec un message qui dit quoi écrire.

**`TEXT_QUESTIONNAIRE` a été FERMÉ.** Aucun gabarit ne le rend — zéro
occurrence dans `templates/`. Il s'enregistrait, se relisait par l'API, et
n'affichait rien. Les jetons `[%code%]` d'une page modèle vont dans un bloc
**TEXT ordinaire** : le besoin était déjà couvert, et proposer un outil qui ne
fait rien est pire que ne pas le proposer.

Et les fiches exposent `[%titre%]`, `[%title%]`, `[%slug%]` sans qu'on ait à
déclarer un champ — un champ déclaré du même nom l'emporte.

---

### S-17 — le journal des appels d'agents était vide partout · corrigé le 03/09

**Constat de Guillaume :** aucun appel n'apparaît sur la fiche de l'agent,
alors que l'API travaillait depuis deux jours. Pas un seul — depuis la mise en
service, sur toutes les installations.

**La cause.** `get_client_ip` renvoie la chaîne `"unknown"` quand `REMOTE_ADDR`
est absent. C'est une clé de compteur, valable pour `bucket_key`. Mais
`AppelAgent.ip` est un `GenericIPAddressField`, et PostgreSQL refuse d'écrire
« unknown » dans un `inet`. `_tracer` attrapait l'exception — à raison, tracer
ne doit pas casser l'appel — la consignait dans les logs et rendait la main
**sans rien avoir écrit**.

**Pourquoi c'était invisible, et général.** `REMOTE_ADDR` est absent dans le cas
NORMAL : gunicorn est servi sur une socket unix
(`scripts/11_configure_nginx.sh`, `proxy_pass http://unix:…`), où il n'existe
pas d'adresse distante. Le défaut touchait donc **toutes les installations
produites par l'INSTALLER, et aucune installation de développement.** Une liste
vide ressemble par ailleurs à un agent qui n'a pas travaillé : rien n'attire
l'œil.

**Deux autres conséquences, du même défaut, plus graves que le journal :**

* **Toutes les limites par IP tombaient dans un seul compteur.** Formulaires,
  réservations, plafonds d'agents : chaque visiteur partageait le seau
  `"unknown"`. Un seul appelant abusif épuisait le quota de tous les autres —
  c'est un déni de service à portée de main, et il aurait été attribué à une
  « limitation trop stricte ».
* **La liste d'IP autorisées d'un agent ne pouvait jamais correspondre.** Un
  agent restreint par IP était refusé quoi qu'il arrive. La garde existait, et
  ne gardait rien.

**Les correctifs, deux verrous :**

* `throttling.ip_stockable()` sépare l'adresse ENREGISTRÉE de la clé COMPTÉE.
  Une adresse absente ou malformée devient `None` au lieu de faire disparaître
  la trace. `get_client_ip` lit aussi `X-Real-IP`, que nginx pose et qui survit
  à une réécriture de la chaîne.
* Le gabarit de settings active `JEIKO_TRUST_X_FORWARDED_FOR`, si bien qu'il y
  a une vraie adresse à écrire. **Ce n'est sûr qu'à une condition, et elle est
  remplie :** nginx écrase l'en-tête à chaque requête et gunicorn n'écoute que
  la socket. Un déploiement qui exposerait gunicorn directement doit repasser
  ce réglage à False — sinon n'importe qui annonce l'adresse de son choix. Le
  commentaire du gabarit le dit.

L'un des deux verrous suffit à rétablir le journal. Ensemble, une adresse
manquante ou malformée ne peut plus faire disparaître une trace.

`agents/tests/test_journal.py` — 5 tests.

**Ce que ce défaut enseigne.** `_tracer` avale ses exceptions, et c'est le bon
choix. Mais un avaleur silencieux transforme une panne en absence, et une
absence ne se remarque pas. Partout où l'on protège un chemin secondaire par
un `except`, il faut se demander à quoi ressemble la panne vue de l'exploitant.
Ici, elle ressemblait à un agent inactif.

---

### O-02 — la migration 0004 ne faisait rien, en silence · corrigé le 03/09

Elle cherchait le rôle parmi les `auth.Group` de Django. **JEIKO a les siens**
(`users.Role`, `users.RolePermission`, `users.RoleAssignment`). La requête ne
trouvait rien, le garde-fou « rôle absent, on ne devine pas » avalait le cas,
Django enregistrait la migration comme appliquée — et aucune permission n'était
posée. En ligne, l'agent s'est retrouvé avec les nouvelles routes et sans le
droit de les appeler.

Corriger `0004` suffit pour une base neuve, pas pour une base où elle est déjà
inscrite : Django ne rejoue pas une migration appliquée. D'où
`0005_rattrapage_role_agent_types`, qui refait le même travail — l'opération
est idempotente, la rejouer ne change rien.

Encore la même famille : **une écriture qui réussit et ne produit rien.**

---

### A-24 — l'API ne savait pas DÉFINIR un type de fiche · livré le 03/09

Elle savait remplir une fiche « Formule », à condition qu'un humain ait
d'abord déclaré le type « Formule » et ses champs depuis l'administration.
« Fais-moi trois formules » s'arrêtait donc au milieu, et l'obstacle n'était
pas une règle de sécurité : c'était un manque.

Ajouté : `POST /modeles/creer/` (type + champs + marquage de la page gabarit),
`GET|PATCH /modeles/<id>/`, `GET /types-de-produit/` et
`POST /types-de-produit/creer/`. Migration `0004_role_agent_types` : le rôle
« Agent fiches et boutique » gagne `add/change_customobjectmodel`,
`add/change_customobjectfield`, `add/change_producttype`.

Deux règles, et leur raison :

* **Un code de champ ne se renomme pas.** Il est écrit dans le gabarit sous la
  forme `[%code%]` et dans chaque fiche déjà remplie. Le changer casserait les
  deux en silence — le jeton cesserait d'être reconnu et resterait affiché en
  clair sur la page publique. Le PATCH ajoute, il ne rebaptise pas.
* **La page gabarit est marquée d'office.** `page_template` n'accepte que des
  pages `is_custom_object_template` ; laisser ce marquage à l'appelant
  produirait une erreur de validation opaque et un aller-retour dont le seul
  effet serait de rendre l'appel possible.

**Aucune suppression**, comme pour les pages : supprimer un type emporte ses
champs, ses fiches et leurs valeurs.

**Et de quoi s'en servir : un bloc ressource peut enfin dire QUOI lister.**
`DYN_RESOURCE_GRID` et `DYN_RESOURCE_CAROUSEL` exposaient leurs colonnes et
leur source, mais pas leur cible : une grille ne savait dire que « des
produits », jamais « les abonnements ». C'est pourtant tout l'intérêt du bloc —
une page qui liste les formules et renvoie vers chacune, sans un seul lien
écrit à la main, et où une formule ajoutée demain apparaît toute seule. Ajouté :
`type_de_produit` (par code) et `modele_de_fiche` (par slug). Désignés par code
et par slug, jamais par identifiant numérique : la relecture doit pouvoir être
renvoyée telle quelle, et `product_type: 4` ne se relit pas.

Le guide documente désormais aussi **les champs des contenus non dynamiques**
(`document` + `champs` au catalogue) : sans cela `type_de_produit` existait
sans que personne puisse le deviner. Un test refuse qu'un contenu simple reste
muet.

`agents/tests/test_types_de_fiches.py` — 14 tests.

---

### A-25 — table de prix : « 0 » à la place d'un tarif absent · corrigé le 03/09

Basculer sur « Annuel » affichait **« 0 /an »** sur toutes les offres quand
aucun tarif annuel n'était saisi. Un visiteur y lisait un produit gratuit.

`Number('')` vaut `0`, et `Number.isFinite(0)` est vrai : un prix vide devenait
zéro. Corrigé — un prix vide est un prix ABSENT. Et la bascule mensuel/annuel
ne s'affiche plus que s'il existe au moins un tarif annuel à montrer.

Deux autres corrections dans le même bloc :

* **Le symbole suit le nombre en français** — « 19 € », pas « € 19 ». La règle
  est grossière (anglais devant, le reste derrière) mais elle couvre les
  locales servies, et vaut mieux qu'une convention fausse par défaut.
* **La couleur d'accent du thème est utilisée** : bouton, bordure de l'offre
  mise en avant, pastille « Populaire ». Le bloc était figé en `#111`.

**Découverte structurelle : `alpine-blocks.min.js` est maintenu à la main**, et
c'est LUI que sert `base.html` en production. `staticfiles.py` minifie le CSS à
`collectstatic` mais pas le JS, et le dit. Corriger la version lisible seule ne
livre donc rien — exactement ce qui était arrivé au CSS, où `main.min.css`
avait divergé de onze mois et 175 sélecteurs, sauf qu'ici aucune minification
automatique ne rattrapera l'oubli.

`administration_pages/tests/test_js_jumeaux.py` vérifie que des marqueurs choisis
sont présents des deux côtés. Il attrape l'oubli, pas l'équivalence — ce serait
le travail d'un minifieur. **La vraie sortie est de minifier le JS à
`collectstatic`, comme le CSS.** À mettre au plan (voir Q-12 ci-dessous).

---

### A-26 — accès au panier dans le menu · livré le 03/09

Une icône panier en haut à droite, dans les quatre dispositions de menu,
gouvernée par une nouvelle option `Menu.show_cart` (décochée par défaut : les
sites en service ne voient rien changer).

**Le piège, qui a décidé de la forme.** `menu_tags.render_main_menu` met le
HTML du menu en cache **trente jours**, par identifiant de menu et sans
contexte de requête. Deux idées naturelles sont donc exclues :

* un **compteur d'articles** afficherait à tous le panier du premier visiteur
  servi ;
* un affichage **conditionné à l'existence de produits** resterait faux un mois
  après la création du premier produit.

Une option de menu est la seule des trois formes qui reste juste — modifier le
menu invalide sa clé de cache. Un compteur exact demanderait de le remplir côté
navigateur, après le rendu, et un point d'entrée public de plus.

`administration_menu/tests/test_panier.py` — 5 tests, dont un qui refuse qu'une
disposition soit oubliée : c'est déjà arrivé (voir `tests_layouts.py`).

---

### A-22 — les blocs dynamiques écrits par l'API restaient vides · corrigé le 03/09

**Le symptôme.** Une table de tarifs posée par l'API : trois offres en base,
relues correctement par l'API elle-même, et une table **vide** sur la page
publique. Aucune erreur, aucun journal.

**La cause.** `Content.data` n'est pas un cache d'agrément. **Treize des
quatorze gabarits `content/dyn/*.html` ne lisent QUE lui** : ils le sérialisent
dans un `<script type="application/json">` et laissent Alpine construire le DOM.
Seul le carrousel parcourt encore les lignes filles en gabarit. Le formulaire de
l'éditeur le savait — il appelle `_snapshot_for_content()` après chaque
`formset.save()`. L'API ne le faisait pas.

Le docstring de cette fonction disait « snapshot […] optionnel côté front ».
Il a coûté ce défaut, et il est corrigé : rien n'y est optionnel.

**Un second piège, juste derrière.** Écrire les options fait
`content.data = options` — un remplacement *complet*, qui efface la projection.
Régler la facturation en annuel aurait donc vidé la table de ses offres. D'où
une reprojection systématique, non conditionnée à l'envoi d'« elements ».

**Ce que le test a trouvé en plus.** `DYN_FILTER` déclarait le lien
`live_filter_items` quand le modèle dit `livefilter_items` : **ce type était
entièrement inutilisable par l'API**, et rien ne le signalait. Le test qui
parcourt les quatorze types l'a sorti au premier passage.

`agents/tests/test_projection.py` — 7 tests. Le contrôle porte sur `Content.data`,
c'est-à-dire sur ce que le navigateur lit : vérifier les lignes filles, comme le
faisait la relecture par l'API, revenait à contrôler précisément la moitié de
l'état qui ne sert pas au rendu.

Même famille qu'A-12 et A-17 : **une écriture qui réussit et n'affiche rien.**
C'est le défaut que ce paquet paie le plus souvent, et le seul remède est un
test qui regarde le rendu, pas la base.

---

### A-23 — animations : vérifiées en ligne · 03/09

Elles fonctionnent. La vérification précédente était fausse, pour une raison
qui mérite d'être notée : **le volet de prévisualisation faisait 294 px de
large**, donc « téléphone », et les animations de la page portent
`enable_phone: false`. Elles étaient correctement désactivées, et j'ai lu cette
absence comme une panne.

Mesuré à 1280 px, sur `ateliersderouineau.com/jeiko-presentation/` :

* section 114 — `je-fade-in`, 0,7 s, déclenchement au chargement, **saisie en
  cours de fondu à 26 % d'opacité** ;
* blocs 579 à 584 — `je-slide-in`, 0,55 s, pilotées par le défilement
  (`animation-timeline: --v-<id>`). Opacités relevées à trois hauteurs :
  `0 → 0,79 / 0,73 / 0,66 → 1`. Le décalage entre les cartes est visible dans
  les chiffres.

**À retenir pour les prochaines vérifications d'affichage : contrôler la
largeur du volet avant de conclure.** Un réglage par appareil rend toute mesure
faite à la mauvaise largeur non seulement inutile, mais trompeuse.

---

### Phase 15 — API pour agents IA · commencée le 02/09

`jeiko/agents/` — une API à jeton porteur qui permet à un programme de
construire et modifier des pages. **Livré et éprouvé (46 tests) :**

- `[x]` **Identité.** Un agent **possède un `User`** : le système de rôles, les
  permissions, le journal de sécurité continuent de fonctionner sans une ligne
  de plus. Inventer des droits parallèles aurait produit deux vérités sur « qui
  a le droit de quoi », et l'une aurait fini par mentir. Le compte porteur ne
  peut pas se connecter (mot de passe inutilisable, ni staff ni superuser).

- `[x]` **Jeton.** `jk_ag_<préfixe>_<secret>`. Le secret n'est **jamais**
  enregistré, seulement son SHA-256 : une base lue ne livre pas d'accès. Affiché
  une seule fois. SHA-256 et non PBKDF2 — le secret fait 256 bits tirés au sort,
  il n'y a rien à deviner, et le jeton est vérifié à chaque appel.

- `[x]` **Sept gardes empilées** : HTTPS obligatoire, en-tête `Authorization`
  seul (jamais l'URL), comparaison à temps constant, agent actif, expiration,
  liste d'IP, plafonds par jeton et par IP. Tous les appels journalisés.
  **La garde la plus importante : la session n'authentifie pas.** Un
  administrateur connecté sans jeton est refusé comme un inconnu — c'est ce qui
  rend l'exemption CSRF de ces vues légitime au lieu d'être un trou. Le test
  `test_une_session_de_navigateur_n_authentifie_pas` ne doit jamais tomber.

- `[x]` **Les refus ne s'expliquent pas.** Même message, même code, quelle que
  soit la cause. Le motif précis va au journal — il est pour l'exploitant.

- `[x]` **Écrans d'administration** (Réglages ▸ Agents IA) : créer, modifier,
  désactiver, **réinitialiser le jeton**, voir les cinquante derniers appels.

- `[x]` **Rôle livré « Agent éditeur de pages »** — `view/add/change_page`,
  **pas** `delete_page`. C'est la seconde barrière contre la suppression de
  page ; la première est l'absence de route.

- `[x]` **API des pages** : lire l'arbre complet d'un seul tenant, créer une
  page (en brouillon, toujours), créer/modifier/supprimer sections, lignes et
  blocs, poser du contenu. Écritures unitaires plutôt qu'un `PUT` de l'arbre :
  un moteur de comparaison déciderait seul de supprimer ce qui manque dans le
  document reçu, et un agent distrait effacerait du contenu sans l'avoir
  demandé.

- `[x]` **Tous les paramètres** : marges, paddings, tailles (4 appareils),
  couleur et **image de fond avec ses sept réglages**, animation (16 champs),
  bordure, CSS personnalisé (14 champs dont les variantes par appareil).
  Modifications **partielles** : ce qui n'est pas envoyé n'est pas touché.

- `[x]` **Catalogue complet des outils dans le guide** (03/09, à sa demande).
  Les vingt-quatre types de bloc, chacun avec sa phrase de rôle, ses options
  (lues dans `DYNAMIC_DEFAULTS`) et ses clés d'élément (lues dans `TYPES`) ; et
  **la permission exigée par chaque route**, lue sur la classe de vue. Un agent
  sait donc avant d'appeler s'il a le droit, au lieu de le découvrir sur un 403.
  Les listes d'éléments sont retirées des « options » : les y montrer ferait
  croire qu'on peut les écrire directement, ce qui enregistrerait puis serait
  écrasé à la reprojection suivante. Quatre tests refusent qu'un type ouvert ou
  une route montée manque au document.

- `[x]` **Mode d'emploi auto-généré** (`GET /api/agent/v1/`) — le point
  d'entrée le plus important. Une IA y trouve en un appel la forme de l'arbre,
  le piège de vocabulaire (`colonne` n'est pas un rang), les documents
  attendus et un exemple complet. **Tout ce qui peut être déduit du code l'est**
  — noms de champs, routes, gabarits, types ouverts — et neuf tests vérifient
  qu'il ne ment pas. Une documentation recopiée devient fausse au premier
  changement, et une documentation fausse se trompe avec autorité.

- `[x]` **`administration_pages/fabrique.py`** — la création d'une section
  (treize objets liés selon le gabarit) vivait dans `views.SectionCreate`,
  atteignable seulement par un POST de formulaire. Extraite, elle sert
  maintenant l'éditeur ET l'API. La recopier aurait garanti la divergence :
  c'est le défaut qu'A-20 a coûté ailleurs.

**Reste à faire :**

- `[ ]` **API-1 — ouvrir les 25 autres types de contenu.** Trois le sont
  (`TEXT`, `BUTTON`, `IMAGE`). Les autres se lisent mais ne se modifient pas :
  chacun a sa forme et ses objets liés (FAQ, onglets, carrousel, table de prix,
  formulaire, calendrier, graphique…). Les ouvrir un par un, avec un test
  chacun — les ouvrir en bloc ferait une API qui prétend savoir faire ce
  qu'elle ne sait pas.
- `[ ]` **API-2 — déplacer et réordonner** sections, lignes et blocs. Les vues
  de l'éditeur le font déjà (`section_move_up`…) : à extraire dans la fabrique
  comme le reste, plutôt qu'à réécrire.
- `[ ]` **API-3 — dupliquer** une section ou une page depuis un modèle
  (`section_duplicate` existe).
- `[ ]` **API-4 — médiathèque en lecture** : lister les images disponibles avec
  leur identifiant, pour qu'un agent puisse choisir une image de fond sans
  passer par l'administration. Le téléversement, lui, doit rester dans
  l'administration : c'est là que s'appliquent les validateurs de S-10.

---

### Chantier d'outillage — mettre le code sous git · ~0,5 j

- `[ ]` **O-01 — dépôt git, sur GitHub** *(décidé le 21/08)*. Aujourd'hui
  `Art` et `packages` ne sont sous aucun contrôle de version : la seule
  mémoire est `packages/.sauvegardes/`, des copies datées à la main. C'est ce
  qui a permis de dater la régression A-17 — en comparant à la sauvegarde du
  17/08 — mais au prix d'un `diff -rq` sur tout l'arbre, sans savoir *pourquoi*
  une ligne avait changé.

  Trois précautions au moment de le faire :
  * `.gitignore` d'abord — `ENV/` en entier sauf `site-packages/jeiko/`, qui
    est le code ; `mediadir/`, `staticdir/`, `*.pyc`, `.DS_Store`, `.env` ;
  * **aucun secret dans l'historique** : vérifier `main/settings.py` et les
    éventuels JSON de compte de service avant le premier commit — un secret
    poussé sur GitHub est à considérer comme divulgué, même après suppression ;
  * sortir d'abord `site-packages` d'iCloud (Q-09), sans quoi les doublons
    « fichier 2.py » entreront dans le dépôt.

### Phase à venir — la médiathèque · noté le 07/09

Trois choses tenues ensemble : l'API ne sait que **désigner** une image déjà
téléversée, l'administration n'a **aucun écran** pour en ajouter, revoir ou
retirer, et la suppression d'une image est aujourd'hui **dangereuse**. Le
troisième point interdit d'écrire le deuxième tel quel.

- `[x]` **M-01 — supprimer une image détruirait des sections entières.**
  Vérifié le 07/09 en lisant les `on_delete` de tout ce qui pointe vers
  `ImageContent` :

      Section.background_image     CASCADE   ← supprime LA SECTION
      Line.background_image        CASCADE   ← supprime LA LIGNE
      Bloc.background_image        CASCADE   ← supprime LE BLOC
      ContentImage.image_content   CASCADE   ← supprime le contenu du bloc
      DynCarouselSlide.image       CASCADE
      DynTestimonialItem.avatar    CASCADE
      DynGalleryItem.image         CASCADE
      CustomObject.main_image      PROTECT   ← refuse, et c'est le bon geste
      ExpertTest.main_image        PROTECT
      ProductImage.image           PROTECT
      Page.main_image              SET_NULL
      ContentVideo.poster          SET_NULL
      CustomObjectValue.image      SET_NULL

  Retirer de la médiathèque une image servant de fond à une section
  **emporterait la section, ses lignes, ses blocs et leurs contenus** — sans
  confirmation, sans trace, et sans que rien ne le laisse deviner à l'écran.
  Les trois régimes coexistent sans raison lisible : le même geste protège
  ici, met à `NULL` là, et détruit ailleurs.

  À trancher avant tout écran de suppression : passer les fonds en `SET_NULL`
  (une section sans fond reste une section), garder `PROTECT` là où l'image
  est le sujet, et n'accepter `CASCADE` que sur les éléments dont l'image EST
  le contenu — une diapositive de carrousel, un avatar de témoignage.

- `[x]` **M-02 — partage d'une image entre fonds et blocs IMAGE.** Les fonds
  sont des `ForeignKey` en `SET_NULL` depuis 0059. Le reste, confirmé le
  15/09 (`ContentImage.image_content` unique et refus du second bloc par
  l'API), est corrigé le 17/09 par la nouvelle migration 0062 : `ForeignKey`
  toujours en `PROTECT`, sans migration de données ni suppression. Chaque
  bloc garde son satellite de réglages propre. L'inventaire compte les deux
  usages ; suppression métier et suppression ORM restent refusées ; retirer
  un bloc préserve le média et l'autre bloc. Tests API et ORM ajoutés dans
  les dossiers `tests/` des deux modules. **Activation sur la base de travail
  en attente de l'application des migrations 0058–0062**, non exécutées ici.
  Avant un rollback rétablissant l'unicité, résoudre les usages multiples.

- `[x]` **M-03 — supprimer un bloc laisse des `ContentImage` orphelins.**
  Sans gravité — l'image de la médiathèque, elle, survit bien à la suppression
  du bloc, ce qui est le comportement attendu — mais la table grossit de
  lignes que plus rien ne référence. À nettoyer une fois M-01 tranché.

- `[x]` **M-04 — l'écran de médiathèque.** Voir toutes les images, en ajouter,
  en supprimer, et savoir **où chacune sert** avant de la retirer. C'est ce
  dernier point qui fait l'écran utile : une liste de vignettes sans ses
  usages ne permet de supprimer qu'à l'aveugle. À faire après M-01 et M-02.

- `[ ]` **E-07 — Quill doit montrer le rendu réel : PRIORITAIRE, 17/09.** Quill affiche
  son propre style, pas celui de la page : la police du site, ses tailles, ses
  couleurs, les règles de `main.css` qui s'appliquent sous `.content`. On
  compose donc à l'aveugle, et on ne découvre l'écart qu'en publiant — c'est
  le même défaut de fond que partout ailleurs ici : ce qui est vrai en base
  n'est pas ce qui s'affiche.

  **Nouvelle consigne de Guillaume, 17/09 :** ce décalage l'embête beaucoup
  et n'est plus à différer au motif que la rédaction passe par l'API. Il
  signale que le rendu ne correspond plus depuis la mise en place de l'IA
  via l'API. C'est une régression rapportée à reproduire, pas une preuve que
  l'API ou un correctif particulier en est la cause. **À reprendre en priorité
  après la pause, avant A-02/A-03 ; pas d'implémentation maintenant.**

  **Objectif :** même rendu du contenu dans Quill et sur la page réelle,
  hors barres/outils d'édition, à largeur et contexte comparables : polices,
  tailles, couleurs, interlignes, espacements, titres, paragraphes, listes,
  alignements, liens et emphases. Les contenus saisis manuellement et ceux
  créés/modifiés par l'API doivent rester éditables sans perte de mise en
  forme lors d'une ouverture, modification puis sauvegarde dans Quill.

  **Diagnostic à faire :** comparer sur les mêmes contenus le HTML reçu par
  l'API, celui conservé en base, sa conversion par Quill et les styles
  réellement appliqués dans l'éditeur et au rendu public. Vérifier styles
  Quill, classes/attributs autorisés, assainissement, variables de thème,
  polices et ordre/spécificité des CSS avant de choisir le correctif.

  **Observations complémentaires de Guillaume :** le CSS ajouté dans les
  options CSS n'est pas reflété dans la zone Quill ; l'IA semble également
  produire de l'italique via CSS alors que Quill propose un format natif.
  Reproduire ces deux cas et distinguer formatage natif du texte et styles
  personnalisés : corriger l'aperçu ne signifie pas supprimer le CSS utile
  ni convertir automatiquement les contenus déjà enregistrés.

  **Livrable obligatoire : notice API à jour.** Reprendre le guide/notice
  consommé par les agents IA en même temps que le correctif E-07, pour
  éviter de reproduire ces écarts. Documenter les formes de contenu réellement
  compatibles avec Quill et conservées par l'API ; privilégier les formats
  natifs (italique, gras, etc.) lorsqu'ils expriment le besoin, réserver les
  options CSS aux styles personnalisés nécessaires et expliquer leur portée
  dans l'aperçu et au rendu réel. Fournir des exemples validés sur les vraies
  routes, y compris reprise dans Quill d'un contenu créé par l'API, édition
  puis sauvegarde. Les limites doivent être explicites : ne pas promettre une
  prise en charge non testée ni modifier la notice avant de vérifier le
  contrat réel. Verrouiller les exemples/contrats par des tests ; la mise à
  jour de la notice fait partie des critères de fin du chantier, pas d'un
  complément facultatif après livraison.

  **Consigne centrale à transmettre aux IA : natif d'abord, au maximum.**
  Avant de produire du HTML/CSS sur mesure, lire et réutiliser les possibilités
  natives réellement exposées par JEIKO : thème du site, palette et rôles de
  couleurs, polices et rôles typographiques, paramètres des éléments/blocs,
  composants existants et formats Quill. Ne pas recréer ces réglages par des
  polices/couleurs codées en dur ou du CSS dupliqué lorsqu'un mécanisme natif
  couvre le besoin ; conserver l'héritage du thème et utiliser les variables
  disponibles pour les extensions nécessaires. Ne pas modifier un réglage
  global pour résoudre un besoin local sans vérifier sa portée et l'accord
  de l'exploitant. **Le CSS personnalisé est vraiment le dernier recours**,
  après vérification des options natives, pas un raccourci par facilité.
  Si un besoin reste non couvert, choisir la portée correspondant au besoin :
  CSS global du site, configurable dans l'administration (E-08), pour les
  styles communs afin de garder un rendu harmonieux sans duplication ; options
  CSS de section, ligne ou bloc pour les exceptions locales. Ne pas généraliser
  une exception locale à tout le site ni copier un style commun dans chaque
  bloc. Le CSS global reste lui aussi un dernier recours après le natif.
  Toute exception est expliquée et testée, sans casser les changements de
  thème ni l'édition Quill ; son effet doit aussi être reflété dans l'aperçu.
  La future notice comprend cet ordre de décision, des
  exemples natifs pour polices/couleurs/thèmes et la méthode de découverte
  des options disponibles ; elle n'invente pas de champs ou d'API absents.

  **Piste, à confirmer par inspection :** partager les styles de contenu du
  site et ses variables/polices avec la zone de saisie, sans contaminer les
  outils de l'éditeur. Ne pas présupposer une iframe ou une réécriture de
  l'API. Ne pas assouplir les protections HTML pour masquer l'écart.

  **Validation attendue :** comparaison visuelle côte à côte et styles
  calculés dans un vrai navigateur, à plusieurs largeurs, avec exemples
  manuels/API ; tests de non-régression sur les allers-retours édition et
  sauvegarde et sur l'assainissement. La compilation des templates seule
  ne suffit pas à déclarer ce chantier terminé.

  **Condition explicite de Guillaume : tout doit continuer à fonctionner.**
  Préserver les contenus et mises en forme déjà enregistrés, les parcours
  manuels et API, les substitutions de gabarits, le rendu public et les
  autres usages des composants partagés, notamment les e-mails. Pas de
  correction visuelle par suppression de contenu, désactivation d'un format
  existant ou relâchement des protections HTML. Avancer par petits correctifs
  réversibles ; vérifier les parcours concernés dans le navigateur et rejouer
  la suite officielle PostgreSQL. Une régression ou incompatibilité reste
  bloquante et explicitement signalée, pas masquée par une réussite visuelle.

- `[ ]` **E-08 — CSS global du site configurable dans l'administration.**
  Demande de Guillaume, 17/09 : prévoir un réglage dans l'administration pour
  les styles personnalisés communs à tout le site. Emplacement précis à choisir
  lors de l'implémentation ; pas de développement maintenant. Priorité aux
  thèmes, polices, couleurs et composants natifs ; CSS personnalisé uniquement
  si nécessaire. Conserver les options de section, ligne et bloc pour les
  exceptions locales, sans conversion automatique des contenus existants.
  Relier ce réglage au chantier E-07 : son effet, comme celui du CSS local,
  doit être reflété dans Quill sans modifier les outils ni l'interface de
  l'administration. Vérifier droits de modification, sauvegarde, ordre et
  portée des styles, aperçu et non-régression du rendu public/édition.
  Inspecter l'existant avant de choisir le stockage et le contrat API ; ne
  pas présenter cette capacité comme déjà disponible dans la notice.

- `[x]` **M-05 — le téléversement par l'API.** Aujourd'hui `GET /images/` ne
  fait que lister l'existant : un agent qui monte un site depuis zéro ne peut
  poser aucune image, et dépend d'un humain pour chaque fichier. À ouvrir
  seulement une fois les gardes d'`uploads.py` (S-10 / S-11) éprouvées sur ce
  chemin-là.


### Demande client — CRM et suivi des rendez-vous · ajoutée le 17/09/2026

**À planifier, pas à développer maintenant.** Guillaume transmet une demande
client : JEIKO doit permettre de suivre les prospects et les clients, avec
une fiche de contact, leurs rendez-vous, des notes et des comptes rendus.
Ce chantier est distinct des correctifs en cours ; aucune échéance ni
implémentation n'est engagée par cet ajout au plan.

Un **CRM** (gestion de la relation client) rassemble les contacts et
entreprises, l'historique des échanges, les actions à faire et le suivi
commercial. Il ne se limite pas à conserver les formulaires de rendez-vous.
La demande ci-dessous sert de point de départ ; le périmètre d'un « vrai
CRM » sera précisé avec le client avant de choisir les modèles et écrans.

#### Besoins expressément demandés par le client

- `[ ]` **CRM-01 — informations demandées à la réservation configurables.**
  Lors de la création/configuration d'un calendrier proposé dans une page,
  l'administrateur choisit les informations demandées au visiteur : e-mail,
  nom, prénom, entreprise, fonction, et éventuellement d'autres informations.
  Prévoir le choix des champs affichés, leur ordre et ceux obligatoires.
  **À arbitrer :** catalogue de champs fixes, champs personnalisés ou formule
  mixte ; configuration portée par calendrier, type de rendez-vous ou bloc
  dans la page. Ne pas figer cette décision dans la présente note.
  L'impression « actuellement seulement l'e-mail » est un retour client à
  confronter au parcours réel, pas un constat technique vérifié ici.

- `[ ]` **CRM-02 — enregistrer les informations en base PostgreSQL.**
  Les réponses sont conservées et consultables depuis le rendez-vous et la
  fiche de la personne, pas seulement présentes dans un e-mail. Une évolution
  de la configuration des champs ne doit pas effacer les anciennes réponses.
  **À cadrer :** données de contact à jour et copie des informations fournies
  lors de chaque réservation, types/validation des champs personnalisés,
  compatibilité et reprise des rendez-vous déjà existants.

- `[ ]` **CRM-03 — contact CRM sans obligation de compte utilisateur.**
  Une personne peut réserver sans inscription et possède néanmoins une fiche
  de contact liée à son rendez-vous. Un contact/prospect CRM n'est pas
  automatiquement un utilisateur autorisé à se connecter. **À décider :**
  rapprochement des réservations récurrentes et liaison à un compte créé
  plus tard, gestion des doublons et entreprises ; ne pas fusionner ni
  écraser une identité existante sur une simple saisie publique non vérifiée.

- `[ ]` **CRM-04 — notes internes et rapports de rendez-vous.**
  Depuis un rendez-vous et la fiche du contact, ajouter et retrouver les
  notes de suivi et les comptes rendus, avec auteur et dates. Séparer les
  notes privées du contenu destiné à la personne ; aucun partage implicite.
  **À cadrer :** édition, historique des modifications, pièces jointes et
  visibilité selon les droits des gestionnaires.

- `[ ]` **CRM-05 — transmettre éventuellement un compte rendu au contact.**
  Action explicite après relecture : choisir le rapport à transmettre et le
  destinataire, sans envoyer les notes internes. Conserver la version
  effectivement partagée et l'état de l'envoi ; un échec reste visible.
  **À arbitrer :** corps d'e-mail, document joint ou lien de consultation
  protégé ; aucune création de compte imposée pour le parcours retenu.

#### Compléments proposés pour cadrer un véritable CRM — à valider

Ces points sont des suggestions de périmètre, **pas des demandes client
déjà détaillées ni des fonctionnalités promises**.

- `[ ]` **CRM-06 — fiches contacts et entreprises.** Listes avec recherche,
  filtres et pagination ; coordonnées, statut prospect/client, entreprise
  et fonction, origine du contact, gestionnaire responsable, tags et champs
  personnalisés. Une entreprise peut réunir plusieurs interlocuteurs.

- `[ ]` **CRM-07 — historique et prochaines actions.** Vue chronologique des
  rendez-vous, notes, rapports partagés et échanges enregistrés ; tâches de
  suivi, dates de relance et rappels. Définir ce qui est saisi manuellement
  et ce qui remonte automatiquement des modules JEIKO.

- `[ ]` **CRM-08 — suivi commercial.** Opportunités liées à un contact ou une
  entreprise, étapes de progression configurables, responsable, prochaine
  action, montant/devise si pertinent, conclusion gagnée/perdue et motif.
  Définir le besoin réel avant d'ajouter un pipeline complexe ; devis et
  facturation ne sont pas inclus automatiquement dans cette demande.

- `[ ]` **CRM-09 — droits, maîtrise des données et échanges avec JEIKO.**
  Définir qui voit/modifie/exporte quoi, accès aux notes internes, traçabilité,
  règles de conservation et traitement des demandes sur les données.
  Séparer suivi opérationnel et préférences de communication commerciale.
  Cadrer import/export, doublons et relations aux calendriers, utilisateurs,
  e-mails et commandes, puis les besoins d'API agents. La création d'un
  contact ne doit pas ouvrir automatiquement son historique à une API.

- `[ ]` **CRM-10 — tableau de bord et validation progressive.** Indicateurs
  utiles à confirmer (contacts, relances, rendez-vous, opportunités), puis
  tests sur PostgreSQL et vérification des parcours et permissions. Prévoir
  notamment réservation anonyme, réponses obligatoires, configuration
  modifiée, rendez-vous historiques, séparation privé/partagé, destinataire
  et échec d'envoi. Ne déclarer aucun sous-lot livré sur la seule présence
  d'un écran ou d'un modèle.

**Ordre proposé pour plus tard :** cadrage avec le client → contacts et
réservations enrichies (CRM-01 à CRM-03) → notes/rapports et partage maîtrisé
(CRM-04/05) → suivi et fonctions commerciales retenues (CRM-06 à CRM-08).
Les droits et la maîtrise des données (CRM-09) sont conçus dès le socle,
les tests (CRM-10) accompagnent chaque lot. Une éventuelle application CRM
distincte reste une décision d'architecture future, pas un dossier à créer
maintenant.

---

## 3. Hors plan, à connaître

- **S-16 — l'intégrité de la chaîne de mise à jour repose sur un sha256 publié
  par le même canal que le wheel.** Cela protège d'un téléchargement corrompu,
  pas d'un dépôt compromis. Une signature détachée serait la vraie réponse.
- **Q-13 — le cron qui annonce une mise à jour disponible ne fonctionne pas.**
  Signalé le 04/09, **à traiter en urgence** : sans lui, un exploitant ne sait
  pas qu'une version est sortie, et la chaîne de mise à jour ne sert à rien si
  personne ne la déclenche. Chercher du côté de `INSTALLER/updater/` et de la
  tâche planifiée posée par `14_finalize.sh`. Vérifier d'abord que le cron
  s'exécute (journal), avant de suspecter la comparaison de versions.

- **Q-07 — internationalisation : la MÉCANIQUE est posée (04/09), la traduction reste à faire.** : 11 marquages
  `gettext`, aucun `.po`. Ce n'est pas une dette, c'est un plafond à connaître
  avant de promettre du multilingue. Compter 5 à 8 jours.

  **Priorités données le 04/09.** D'abord **l'espace d'administration**, en
  dur ou assisté — c'est là que l'absence gêne tout de suite : un exploitant
  non francophone ne peut pas se servir de JEIKO. Ensuite seulement un moteur
  multilingue pour le site public, « si besoin ».

  Le cadrage à retenir : **95 % des sites sont monolingues, mais pas forcément
  en français.** Ce n'est donc pas d'abord un problème de traduction de
  contenu — c'est un problème de LANGUE DE L'OUTIL. Traduire l'admin sert
  tout le monde ; un moteur multilingue de contenu ne sert que les 5 %
  restants, et coûte bien plus cher. Faire les deux dans cet ordre.
- **Q-14 — deux endroits règlent la police du menu, et celui du site ne sert
  à rien.** `base_style.html` génère `.menu a` depuis le rôle « menu » des
  polices du site ; `MenuStyle` génère la sienne, plus spécifique, et l'emporte
  toujours. Régler le rôle « menu » dans Réglages ▸ Polices n'a donc aucun
  effet visible — on croit à un cache, on purge, rien ne change.

  À trancher : soit le rôle « menu » disparaît des polices du site (une seule
  vérité, dans le menu), soit `MenuStyle` ne pose sa police que lorsqu'elle est
  explicitement choisie. La seconde est plus douce pour les sites en service.
  Signalé le 04/09.

- **Q-12 — le JS n'est pas minifié à `collectstatic`, contrairement au CSS.**
  `alpine-blocks.min.js` est écrit à la main et c'est lui qui part en
  production : tout correctif doit être appliqué deux fois. C'est le montage
  qui avait fait diverger `main.min.css` de onze mois. `tests_js_jumeaux.py`
  attrape l'oubli sur des marqueurs choisis ; il ne remplace pas un minifieur.
- **Q-09 — `site-packages` est dans un dossier synchronisé iCloud**, d'où les
  doublons « fichier 2.py ». À sortir de la synchronisation.
