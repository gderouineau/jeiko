"""La suppression d'un produit valide ses dépendances avant l'effacement."""

from decimal import Decimal

from django.contrib.auth import get_user_model
from django.db.models.deletion import ProtectedError
from django.test import TestCase
from django.urls import reverse

from jeiko.administration_pages.models import Page
from jeiko.custom_objects.models import CustomObject, CustomObjectModel
from jeiko.shop.models import Cart, CartItem, Product, ProductStockMovement, ProductType


class SuppressionProduitTests(TestCase):
    def setUp(self):
        self.admin = get_user_model().objects.create_superuser(
            "admin-produit", "admin-produit@example.test", "mot-de-passe"
        )
        self.client.force_login(self.admin)
        page = Page.objects.create(
            title="Gabarit produit", url_tag="gabarit-produit-suppression",
            is_custom_object_template=True,
        )
        modele = CustomObjectModel.objects.create(
            name="Produit", slug="produit-admin-suppression", page_template=page,
            is_product=True,
        )
        type_produit = ProductType.objects.create(
            name="Service", code="service-admin-suppression", content_model=modele,
        )
        fiche = CustomObject.objects.create(model=modele, title="Produit", slug="produit")
        self.produit = Product.objects.create(
            type=type_produit, content=fiche, sku="sku-admin-suppression",
            price_ht=Decimal("10.00"), tax_rate=Decimal("20.00"),
        )
        self.type_produit = type_produit

    def _supprimer(self):
        return self.client.post(reverse(
            "jeiko_administration_shop:product_delete",
            kwargs={"type_pk": self.type_produit.pk, "pk": self.produit.pk},
        ))

    def test_produit_dans_un_panier_est_refuse_sans_500(self):
        utilisateur = get_user_model().objects.create_user("client-suppression")
        panier = Cart.objects.create(user=utilisateur)
        CartItem.objects.create(
            cart=panier, product=self.produit, quantity=1,
            unit_price_ht=Decimal("10.00"), tax_rate=Decimal("20.00"), currency="EUR",
        )
        reponse = self._supprimer()
        self.assertEqual(reponse.status_code, 302)
        self.assertTrue(Product.objects.filter(pk=self.produit.pk).exists())

    def test_historique_de_stock_est_protege_sans_500(self):
        ProductStockMovement.objects.create(
            product=self.produit, movement_type=ProductStockMovement.IN, quantity=2,
        )
        reponse = self._supprimer()
        self.assertEqual(reponse.status_code, 302)
        self.assertTrue(Product.objects.filter(pk=self.produit.pk).exists())

    def test_historique_de_stock_bloque_une_suppression_orm_directe(self):
        mouvement = ProductStockMovement.objects.create(
            product=self.produit, movement_type=ProductStockMovement.OUT,
            quantity=1, reason="Commande historique",
        )
        with self.assertRaises(ProtectedError):
            Product.objects.filter(pk=self.produit.pk).delete()
        self.assertTrue(Product.objects.filter(pk=self.produit.pk).exists())
        self.assertTrue(ProductStockMovement.objects.filter(pk=mouvement.pk).exists())

    def test_produit_sans_dependance_est_supprime(self):
        reponse = self._supprimer()
        self.assertEqual(reponse.status_code, 302)
        self.assertFalse(Product.objects.filter(pk=self.produit.pk).exists())
