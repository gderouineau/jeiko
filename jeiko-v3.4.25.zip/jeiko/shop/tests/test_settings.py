from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.template.loader import render_to_string
from django.test import SimpleTestCase, TestCase
from django.urls import reverse

from jeiko.administration_pages.models import Page
from jeiko.shop.forms import DeliveryZoneForm, ProductForm, ShopSettingsForm
from jeiko.shop.models import DeliveryZone, ProductType, ShopSettings


class DeliveryZoneFormTests(SimpleTestCase):
    def test_normalise_pays_et_prefixes(self):
        form = DeliveryZoneForm(data={
            "code": "france-metropole",
            "name": "France métropolitaine",
            "country_codes": "fr; be,FR",
            "postal_code_prefixes": "75, 77",
            "price_ttc": "6.90",
            "free_from": "80",
            "is_active": "on",
            "position": "1",
        })
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.cleaned_data["country_codes"], "FR, BE")
        self.assertEqual(form.cleaned_data["postal_code_prefixes"], "75, 77")

    def test_une_zone_resout_pays_et_code_postal(self):
        zone = DeliveryZone(
            country_codes="FR, BE",
            postal_code_prefixes="75, 77",
            is_active=True,
        )
        self.assertTrue(zone.matches("fr", "75001"))
        self.assertFalse(zone.matches("FR", "33000"))
        self.assertFalse(zone.matches("DE", "75001"))


class ShopPriceSettingsTests(TestCase):
    def test_la_saisie_ttc_est_convertie_en_ht_dans_le_produit(self):
        ShopSettings.objects.create(pk=1, prices_include_tax=True)
        product_type = ProductType.objects.create(
            name="Produit test",
            code="produit-test-prix",
            default_tax_rate=Decimal("20.00"),
        )
        form = ProductForm(
            data={
                "type": product_type.pk,
                "sku": "TEST-PRIX-TTC",
                "is_active": "on",
                "price_ht": "120.00",
                "tax_rate": "20.00",
                "currency": "EUR",
                "stock_quantity": "0",
                "allow_negative_stock": "on",
                "weight_kg": "0",
            },
            product_type=product_type,
        )
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.cleaned_data["price_ht"], Decimal("100.00"))

    def test_le_selecteur_de_devise_normalise_le_code(self):
        form = ShopSettingsForm(data={
            "is_online": "on",
            "homepage": "",
            "prices_include_tax": "",
            "display_prices_including_tax": "on",
            "default_tax_rate": "20",
            "currency": "chf",
            "free_shipping_from": "",
        })
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.cleaned_data["currency"], "CHF")


class ShopSettingsPageTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.admin = User.objects.create_superuser(
            "admin-shop-settings",
            "admin-shop-settings@example.test",
            "Mot-de-passe-42",
        )
        self.client.force_login(self.admin)
        self.url = reverse("jeiko_administration_shop:settings")

    def test_la_page_enregistre_page_options_et_zone(self):
        page = Page.objects.create(
            title="Accueil boutique",
            url_tag="accueil-boutique",
            active=True,
        )
        response = self.client.post(self.url, {
            "active_tab": "shipping",
            "is_online": "on",
            "homepage": page.pk,
            "prices_include_tax": "on",
            "display_prices_including_tax": "on",
            "default_tax_rate": "20",
            "currency": "CHF",
            "free_shipping_from": "100",
            "zones-TOTAL_FORMS": "1",
            "zones-INITIAL_FORMS": "0",
            "zones-MIN_NUM_FORMS": "0",
            "zones-MAX_NUM_FORMS": "1000",
            "zones-0-code": "suisse",
            "zones-0-name": "Suisse",
            "zones-0-country_codes": "ch",
            "zones-0-postal_code_prefixes": "",
            "zones-0-price_ttc": "8.50",
            "zones-0-free_from": "120",
            "zones-0-is_active": "on",
            "zones-0-position": "0",
        })
        self.assertEqual(response.status_code, 302)
        settings = ShopSettings.objects.get(pk=1)
        self.assertEqual(settings.homepage_id, page.pk)
        self.assertTrue(settings.prices_include_tax)
        self.assertEqual(settings.currency, "CHF")
        zone = settings.delivery_zones.get()
        self.assertEqual(zone.country_codes, "CH")

    def test_boutique_desactivee_bloque_le_panier(self):
        ShopSettings.objects.create(pk=1, is_online=False)
        response = self.client.get(reverse("jeiko_client_shop:cart_detail"))
        self.assertEqual(response.status_code, 404)
        paiement = self.client.get(reverse("jeiko_payments_client:checkout"))
        self.assertEqual(paiement.status_code, 404)

    def test_l_accueil_boutique_redirige_vers_la_page_choisie(self):
        page = Page.objects.create(
            title="Accueil boutique",
            url_tag="accueil-boutique-2",
            active=True,
        )
        ShopSettings.objects.create(pk=1, homepage=page)
        response = self.client.get(reverse("jeiko_client_shop:shop_home"))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response["Location"], page.get_absolute_url())

    def test_l_icone_du_menu_suit_l_etat_de_la_boutique(self):
        from jeiko.administration_menu.models import Menu, MenuPlace

        menu = Menu.objects.create(
            name="Principal settings",
            place=MenuPlace.MAIN,
            layout="logo-left-menu-right",
            show_cart=True,
        )
        ShopSettings.objects.create(pk=1, is_online=False)
        html = render_to_string("menu/partials/panier.html", {"menu": menu})
        self.assertNotIn('class="menu-cart"', html)
        ShopSettings.objects.update(is_online=True)
        html = render_to_string("menu/partials/panier.html", {"menu": menu})
        self.assertIn('class="menu-cart"', html)

    def test_le_changement_de_reglage_invalide_le_menu_mis_en_cache(self):
        from jeiko.administration_menu.models import Menu, MenuPlace

        menu = Menu.objects.create(
            name="Principal cache",
            place=MenuPlace.MAIN,
            layout="logo-left-menu-right",
            show_cart=True,
        )
        cache.set(f"menu:render:{menu.pk}", "ancien rendu")
        ShopSettings.objects.create(pk=1, is_online=False)
        self.assertIsNone(cache.get(f"menu:render:{menu.pk}"))
