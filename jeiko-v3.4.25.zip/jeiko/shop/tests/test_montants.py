"""Les montants visibles et facturables restent au centime."""

from decimal import Decimal

from django.test import SimpleTestCase

from jeiko.shop.models import CartItem, OrderLine, Product
from jeiko.shop.services import to_minor_units


class ArrondiDesMontantsTests(SimpleTestCase):
    def test_prix_ttc_du_produit_est_arrondi(self):
        produit = Product(price_ht=Decimal("99.00"), tax_rate=Decimal("20.00"))
        self.assertEqual(produit.price_ttc, Decimal("118.80"))

    def test_totaux_de_panier_et_de_commande_sont_arrondis(self):
        panier = CartItem(
            unit_price_ht=Decimal("8.33"), quantity=1, tax_rate=Decimal("20.00")
        )
        ligne = OrderLine(
            unit_price_ht=Decimal("8.33"), quantity=1, tax_rate=Decimal("20.00")
        )
        self.assertEqual(panier.total_ttc, Decimal("10.00"))
        self.assertEqual(ligne.total_ttc, Decimal("10.00"))

    def test_les_devises_sans_decimales_ne_sont_pas_multipliees_par_cent(self):
        self.assertEqual(to_minor_units(Decimal("100"), "JPY"), 100)
        self.assertEqual(to_minor_units(Decimal("100"), "EUR"), 10000)
