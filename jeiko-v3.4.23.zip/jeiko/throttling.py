"""
Garde-fous anti-abus des points d'entrée publics en écriture.

Le module `calendars` s'était doté d'un dispositif complet — leurre, plafonds
par IP et par adresse, refus volontairement vague — et il était le seul. Les
autres points d'entrée publics qui écrivent en base ou déclenchent un envoi
n'avaient rien :

- la soumission de formulaire (`administration_pages`) enregistre une ligne
  **et déclenche deux e-mails** : une boucle suffisait à saturer la base, à
  noyer la boîte de l'exploitant et à faire blacklister le domaine d'envoi ;
- l'enregistrement du consentement cookies (`cookies`) crée une ligne et force
  la création d'une session à chaque appel ;
- la mesure de temps de lecture (`stats`) écrit sans authentification.

Ce module porte les primitives communes. La *politique* — quelles limites, quel
message de refus — reste au point d'appel, parce qu'elle diffère réellement d'un
endpoint à l'autre : trois réservations par jour et par adresse n'a pas de sens
pour un consentement cookies.

⚠️ Les compteurs vivent dans le cache Django. Avec `LocMemCache`, ils sont **par
processus** : sous gunicorn à N workers, les limites sont multipliées par N. Un
vrai plafond suppose un cache partagé — c'est le cas en production, où l'alias
`jeiko_throttle` pointe sur memcached.
"""

import logging
import re
import time

from django.conf import settings
from django.core.cache import InvalidCacheBackendError, caches

logger = logging.getLogger(__name__)

#: Champ leurre : invisible pour l'humain (masqué en CSS), rempli par la
#: plupart des robots qui remplissent tout ce qu'ils trouvent.
HONEYPOT_FIELD = "company"


def _cache():
    """
    Cache des compteurs.

    Alias dédié quand il existe : un `cache.clear()` applicatif ne doit pas
    remettre à zéro les garde-fous, et inversement.
    """
    try:
        return caches["jeiko_throttle"]
    except InvalidCacheBackendError:
        return caches["default"]


def reset_counters():
    """
    Vide les compteurs. Destiné aux tests.

    À utiliser plutôt qu'un `cache.clear()`, qui ne touche que le cache par
    défaut et laisse les compteurs intacts — piège qui avait silencieusement
    neutralisé l'isolation de toute la suite `calendars`.
    """
    _cache().clear()


#: Ce qu'on renvoie quand on n'a pas d'adresse. C'est une CLÉ DE COMPTEUR,
#: pas une adresse : elle est valable pour `bucket_key`, jamais pour un champ
#: `GenericIPAddressField`, qui la refuse (« invalid input syntax for type
#: inet »). Toute écriture en base doit passer par `ip_stockable`.
INCONNUE = "unknown"


def ip_stockable(request):
    """
    L'adresse de l'appelant, ou `None` si on ne l'a pas.

    À utiliser partout où l'adresse est ENREGISTRÉE, par opposition à comptée.
    `get_client_ip` renvoie une clé, jamais None, parce qu'un compteur a besoin
    d'un seau même pour les appelants sans adresse. Écrire cette clé dans un
    champ IP lève une `DataError` — et c'est ce qui a vidé le journal des
    agents sur toutes les installations : le traçage attrapait l'exception,
    la consignait dans les logs, et rendait la main sans rien avoir écrit.
    """
    from django.core.exceptions import ValidationError
    from django.core.validators import validate_ipv46_address

    valeur = get_client_ip(request)
    if not valeur or valeur == INCONNUE:
        return None
    try:
        validate_ipv46_address(valeur)
    except ValidationError:
        return None
    return valeur


def get_client_ip(request):
    """
    Adresse de l'appelant, ou `INCONNUE` — une clé de compteur, pas une adresse.

    Pour enregistrer l'adresse, utiliser `ip_stockable`.

    `X-Forwarded-For` n'est lu que si `JEIKO_TRUST_X_FORWARDED_FOR` est activé :
    sans reverse-proxy qui le réécrit, cet en-tête est falsifiable et rendrait
    toute limitation inopérante — il suffirait d'en changer à chaque requête.
    """
    if getattr(settings, "JEIKO_TRUST_X_FORWARDED_FOR", False):
        forwarded = request.META.get("HTTP_X_FORWARDED_FOR", "")
        if forwarded:
            return forwarded.split(",")[0].strip()
        # nginx pose aussi `X-Real-IP`, et c'est la seule des deux qui survit
        # quand une couche intermédiaire réécrit la chaîne.
        reel = request.META.get("HTTP_X_REAL_IP", "").strip()
        if reel:
            return reel
    return request.META.get("REMOTE_ADDR") or INCONNUE


def bucket_key(name, value):
    """Clé de compteur. `name` porte la portée, ex. « form:submit »."""
    safe = re.sub(r"[^a-zA-Z0-9_.@:-]", "_", str(value))[:120]
    return f"jeiko:throttle:{name}:{safe}"


def hit(name, value, limit, window):
    """
    Incrémente un compteur à fenêtre fixe. Retourne True si la limite est
    dépassée.
    """
    key = bucket_key(name, value)
    cache = _cache()
    if cache.add(key, 1, window):
        return 1 > limit
    try:
        count = cache.incr(key)
    except ValueError:
        # La clé a expiré entre le add et le incr : on repart à 1.
        cache.set(key, 1, window)
        count = 1
    return count > limit


#: Compagne du compteur : l'instant où sa fenêtre a commencé.
#:
#: Elle existe parce que l'API de cache de Django ne sait pas relire le temps
#: restant d'une clé — memcached ne l'expose pas. Sans elle, on ne pourrait
#: dire à un appelant refusé que « réessayez dans une heure », quel que soit
#: le moment où la fenêtre a commencé.
def _cle_debut(name, value):
    return bucket_key(name, value) + ":debut"


def hit_avec_reste(name, value, limit, window):
    """
    Comme `hit`, mais renvoie `(depasse, secondes_avant_remise_a_zero)`.

    À n'utiliser que là où le refus s'EXPLIQUE à l'appelant — sur un point
    d'entrée public, dire quand réessayer rend le plafond contournable à
    l'heure près.

    Si la borne de début manque — cache vidé, éviction, clé posée par un
    ancien `hit` — on renvoie la fenêtre entière. Une borne haute honnête vaut
    mieux qu'un « réessayez tout de suite » faux, qui ferait boucler un agent
    sur un refus.
    """
    cache = _cache()
    debut_cle = _cle_debut(name, value)
    # Posée AVANT de compter, et seulement si absente : `add` ne touche pas une
    # fenêtre déjà commencée.
    cache.add(debut_cle, time.time(), window)

    if not hit(name, value, limit, window):
        return False, 0

    debut = cache.get(debut_cle)
    reste = window if not debut else int(window - (time.time() - debut))
    # Jamais zéro : un `Retry-After: 0` invite à réessayer immédiatement.
    return True, max(1, min(reste, window))


def peek(name, value, limit):
    """Lit un compteur sans l'incrémenter."""
    return (_cache().get(bucket_key(name, value)) or 0) >= limit


def get_limits(setting_name, defaults):
    """Limites par défaut, surchargeables par un réglage de site."""
    limits = dict(defaults)
    limits.update(getattr(settings, setting_name, {}) or {})
    return limits


def honeypot_filled(data):
    """
    True si le champ leurre a été rempli.

    Accepte un dict comme un QueryDict. Un humain ne remplit jamais ce champ :
    il est masqué et sans étiquette visible.
    """
    if not data:
        return False
    try:
        valeur = data.get(HONEYPOT_FIELD) or ""
    except AttributeError:
        return False
    return bool(str(valeur).strip())


def rate_limited(request, name, limit, window, *, quiet=False):
    """
    Plafond simple par adresse IP, pour un point d'entrée donné.

    Retourne True si l'appel doit être refusé. `quiet` évite d'inonder le
    journal pour les endpoints à fort volume légitime (mesure d'audience).
    """
    ip = get_client_ip(request)
    if hit(name, ip, limit, window):
        if not quiet:
            logger.warning("%s refusé (plafond atteint) ip=%s", name, ip)
        return True
    return False
