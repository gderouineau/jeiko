"""
Interpolation sûre de valeurs éditables dans une feuille de style.

Le problème que ce module résout
-------------------------------
Une quinzaine de gabarits construisent un bloc `<style>` à partir de champs
saisis en administration : couleurs, familles de police, marges, ombres. Or
l'échappement HTML de Django est, à cet endroit précis, à la fois **inefficace
et nuisible**.

*Inefficace* : `escape()` ne touche ni `{`, ni `}`, ni `;`, ni `@`. Une couleur
valant `red; } body{display:none} nav{` sort telle quelle et ajoute des règles
arbitraires — page blanche, calque invisible par-dessus l'interface, ou
détournement de clic. Le rédacteur n'a besoin que d'un rôle délégué pour ça.

*Nuisible* : le contenu d'un élément `<style>` n'est pas analysé comme du HTML,
donc les entités n'y sont **pas** décodées. Une famille de police
`"Playfair Display"` échappée en `&quot;Playfair Display&quot;` arrive
littéralement au moteur CSS et ne correspond à aucune police. C'est cette gêne
qui avait conduit à poser un `|safe` sur `font_family` dans le style de menu —
et ce `|safe`, lui, rouvrait la porte au `</style><script>`.

La bonne réponse n'est donc ni d'échapper, ni de marquer sûr : c'est de retirer
les caractères qui ont une *structure* en CSS, puis de marquer sûr.

Portée
------
`css_value` garantit qu'une valeur ne peut pas **sortir de sa déclaration** :
ni fermer le bloc, ni en ouvrir un autre, ni terminer l'élément `<style>`, ni
introduire une règle « at ». Il ne prétend pas valider que la valeur est un CSS
correct — une couleur absurde reste une couleur absurde, simplement inoffensive.

⚠️ À réserver au contenu d'un élément `<style>`. Dans un attribut
`style="…"`, les guillemets — que ce filtre conserve, car les familles de
police en ont besoin — permettraient de sortir de l'attribut. Aucun gabarit du
package n'interpole de champ éditable dans un attribut `style` ; si cela devait
arriver, l'échappement HTML standard y est la bonne réponse.
"""

import re

from django import template
from django.utils.safestring import mark_safe

register = template.Library()

# Les caractères qui portent une structure en CSS :
#   { }  ouvrent et ferment un bloc de déclarations
#   ;    termine une déclaration et en autorise une suivante
#   @    introduit une règle « at » (@import, @media…)
#   < >  permettraient de former </style> et de quitter l'élément
#   \    ouvre une séquence d'échappement CSS
#   /* */ ouvrent et ferment un commentaire, autre moyen de sortir d'une valeur
_CSS_STRUCTURE_RE = re.compile(r"[{};@<>\\]|/\*|\*/")

# Un saut de ligne ne casse rien en CSS mais rend le bloc généré illisible, et
# une valeur multi-lignes n'a aucun usage légitime ici.
_WHITESPACE_RE = re.compile(r"\s+")


def clean_css_value(value):
    """
    Retourne la valeur débarrassée de ses caractères de structure CSS.

    Chaîne nue (non marquée sûre) : c'est au filtre de gabarit de la marquer,
    pour que chaque `mark_safe` du code reste visible.
    """
    if value is None:
        return ""

    text = _CSS_STRUCTURE_RE.sub("", str(value))
    return _WHITESPACE_RE.sub(" ", text).strip()


# --------------------------------------------------------------------------- #
#  Un BLOC de CSS, par opposition à une valeur
# --------------------------------------------------------------------------- #
#
# `css_value` ci-dessus traite une VALEUR — une couleur, une famille de police —
# et lui retire tout ce qui a une structure. Appliqué à un bloc entier il le
# détruirait : les accolades et les points-virgules y sont légitimes.
#
# Mais laisser Django échapper un bloc de CSS ne marche pas non plus, et c'est
# ce qui se faisait : `{{ css.custom }}` dans un `<style>`. Le contenu d'un
# élément `<style>` n'est pas analysé comme du HTML, donc les entités n'y sont
# **jamais** décodées. Conséquences constatées sur un site en service :
#
#     font-family:'EB Garamond'   →  font-family:&#x27;EB Garamond&#x27;
#     .content ol > li            →  .content ol &gt; li
#     ?family=A&family=B          →  ?family=A&amp;family=B
#
# Le navigateur jette la déclaration invalide et applique le reste de la règle.
# L'API répond 200, la valeur est en base, intacte — et rien ne s'affiche.
# Impossible à deviner sans lire le HTML servi.
#
# La bonne réponse est la même que pour les valeurs, à la maille du bloc : on
# retire ce qui permettrait de SORTIR de l'élément `<style>` ou d'appeler un
# tiers, puis on marque sûr. Tout le reste du CSS passe tel qu'il a été écrit.

#: `</` est la seule façon de fermer `<style>`. Aucun CSS n'en a besoin.
_SORTIE_DE_STYLE_RE = re.compile(r"</")

#: Une règle `@import`, jusqu'à son point-virgule ou sa fin de ligne.
#: Rendue après d'autres règles, elle est de toute façon ignorée par les
#: navigateurs — mais si elle chargeait, elle enverrait l'adresse IP du
#: visiteur chez un tiers. L'API la refuse à l'écriture ; ici on couvre ce qui
#: est DÉJÀ en base et ce que l'éditeur laisse écrire à la main.
_IMPORT_RE = re.compile(r"@\s*import[^;\n]*;?", re.IGNORECASE)

#: Une `url()` qui désigne un autre hôte. Les adresses du site — `/media/…` —
#: et les `data:` passent : c'est l'appel au tiers qu'on retire, pas `url()`.
_URL_DISTANTE_RE = re.compile(
    r"""url\(\s*['"]?\s*(?:https?:)?//[^)]*\)""", re.IGNORECASE
)


def clean_css_block(value):
    """
    Un bloc de CSS, débarrassé de ce qui sort du `<style>` ou appelle un tiers.

    Ce qu'il NE fait pas : valider le CSS. Une déclaration absurde reste
    absurde ; elle est simplement sans effet au-delà de sa propre règle.
    """
    if value is None:
        return ""

    texte = str(value)
    texte = _IMPORT_RE.sub("", texte)
    texte = _URL_DISTANTE_RE.sub("none", texte)
    return _SORTIE_DE_STYLE_RE.sub("", texte)


@register.filter
def css_bloc(value):
    """
    Interpole un bloc de CSS éditable dans un élément `<style>`.

        #section-12 { {{ css.current|css_bloc }} }
        {{ css.custom|css_bloc }}

    À réserver au contenu d'un `<style>`, comme `css_value`, et pour la même
    raison : dans un attribut `style="…"`, les guillemets — que ce filtre
    conserve, puisqu'ils sont le sujet — permettraient d'en sortir.
    """
    return mark_safe(clean_css_block(value))


@register.filter
def css_value(value):
    """
    Interpole une valeur éditable dans un bloc `<style>`.

        color: {{ font.color|css_value }};
        font-family: {{ font.family|css_value }};

    Marque le résultat sûr **après** nettoyage : sans cela l'échappement HTML
    de Django casserait les familles de police entre guillemets, les entités
    n'étant pas décodées dans un élément `<style>`.
    """
    return mark_safe(clean_css_value(value))
