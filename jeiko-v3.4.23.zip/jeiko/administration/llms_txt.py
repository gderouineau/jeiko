"""
`/llms.txt` — la carte du site à l'usage des modèles de langue.

Ce que c'est
------------
Une convention récente (llmstxt.org) : un fichier Markdown à la racine du
domaine, qui dit en clair ce qu'est le site et quelles pages comptent. Un
assistant qui doit répondre sur ce site le lit d'abord, plutôt que d'aspirer
le HTML de trente pages pour en extraire la structure.

C'est l'équivalent de `robots.txt` pour une autre population de lecteurs, avec
une différence de nature : `robots.txt` dit ce qu'on interdit, `llms.txt` dit
ce qu'on offre — et il l'écrit en phrases, pas en chemins.

Rempli tout seul
----------------
Rien à saisir. Le fichier se construit à chaque requête depuis ce que le site
sait déjà de lui-même : l'identité, les pages publiées avec leurs
métadonnées, les catégories qui les regroupent, et les fiches. Un site qui
publie une page la voit apparaître ici sans y penser — c'est le seul moyen
qu'un tel fichier reste vrai plus de trois semaines.

Ce qu'on n'y met pas
--------------------
**Rien que le site n'expose déjà publiquement.** On réutilise `public_pages()`
et le drapeau `google_index` : une page qu'on cache aux moteurs de recherche
n'a aucune raison d'être offerte à un modèle. Les brouillons, les gabarits
d'e-mail et de fiche, les pages protégées n'y figurent pas.

**Aucune description inventée.** Sans métadonnées, on donne le titre et
l'adresse, un point. Résumer une page à sa place produirait une description
plausible et fausse, et c'est précisément ce qu'un fichier de ce genre est
censé éviter.
"""

from django.db.models import Q
from django.http import HttpResponse
from django.urls import NoReverseMatch, reverse
from django.views.decorators.cache import cache_control
from django.views.decorators.http import require_GET

#: Au-delà, on renvoie au plan du site plutôt que d'allonger indéfiniment.
#: Un llms.txt de plusieurs centaines de kilo-octets ne sera pas lu en entier,
#: et le tronquer sans le dire donnerait une carte incomplète qui se croit
#: complète.
PLAFOND_PAR_SECTION = 200


def _ligne(titre, adresse, description=""):
    """Une entrée de liste Markdown, description seulement si elle existe."""
    titre = " ".join(str(titre or "").split()) or adresse
    entree = f"- [{titre}]({adresse})"
    description = " ".join(str(description or "").split())
    return f"{entree} : {description}" if description else entree


def _pages_publiques():
    """Les pages réellement servies, indexables, avec de quoi les décrire."""
    from jeiko.administration_pages.models import Page
    from jeiko.administration_pages.querysets import public_pages

    return (
        public_pages(Page.objects.filter(active=True, google_index=True))
        .select_related(
            "metadata", "category", "sub_category", "sub_category__main_category"
        )
        .order_by("category__name", "sub_category__name", "title")
    )


def _fiches_publiees():
    from jeiko.custom_objects.models import CustomObject

    return (
        CustomObject.objects.filter(is_published=True)
        # Même règle que le sitemap : une fiche dont le produit n'est plus
        # vendable n'a pas à être mise en avant.
        .exclude(product__is_active=False)
        .select_related("model", "metadata", "product")
        .order_by("model__name", "title")
    )


def _entete(site, identite):
    """Le titre et la phrase d'accroche, dans cet ordre de préférence."""
    nom = (
        (getattr(identite, "name", "") or "").strip()
        or (getattr(site, "website_name", "") or "").strip()
        or "Site"
    )
    lignes = [f"# {nom}", ""]

    # La description vient des métadonnées de la page d'accueil : c'est la
    # phrase que l'exploitant a écrite pour se présenter aux moteurs de
    # recherche, donc la meilleure dont on dispose. À défaut, on n'invente pas.
    from jeiko.administration_pages.models import Page

    racine = Page.objects.filter(is_root=True).select_related("metadata").first()
    presentation = " ".join(
        str(getattr(getattr(racine, "metadata", None), "description", "") or "").split()
    )
    if presentation:
        lignes += [f"> {presentation}", ""]
    return lignes


def _section(titre, entrees):
    """Une section Markdown, ou rien si elle est vide."""
    if not entrees:
        return []
    lignes = [f"## {titre}", ""]
    if len(entrees) > PLAFOND_PAR_SECTION:
        gardees = entrees[:PLAFOND_PAR_SECTION]
        gardees.append(
            f"- (et {len(entrees) - PLAFOND_PAR_SECTION} autres — voir /sitemap.xml)"
        )
        entrees = gardees
    return lignes + entrees + [""]


@require_GET
@cache_control(public=True, max_age=3600)
def llms_txt(request):
    from jeiko.administration.website_cache import get_website_data

    site = get_website_data()
    identite = getattr(site, "identity", None)

    lignes = _entete(site, identite)

    # Les pages, groupées par catégorie. Le groupement n'est pas cosmétique :
    # c'est ce qui distingue une liste d'adresses d'une carte utilisable.
    par_categorie = {}
    for page in _pages_publiques():
        rubrique = (
            getattr(page.category, "name", None) or "Pages"
        ) if page.category_id else "Pages"
        description = getattr(getattr(page, "metadata", None), "description", "") or ""
        par_categorie.setdefault(rubrique, []).append(
            _ligne(page.title, page.get_absolute_url(), description)
        )

    # « Pages » d'abord — l'accueil et les pages hors catégorie — puis les
    # rubriques dans l'ordre alphabétique.
    for rubrique in sorted(par_categorie, key=lambda r: (r != "Pages", r.lower())):
        lignes += _section(rubrique, par_categorie[rubrique])

    # Les fiches, groupées par modèle : produits, articles, formations.
    par_modele = {}
    for fiche in _fiches_publiees():
        adresse = fiche.get_absolute_url() if hasattr(fiche, "get_absolute_url") else ""
        if not adresse:
            continue
        description = getattr(getattr(fiche, "metadata", None), "description", "") or ""
        par_modele.setdefault(
            getattr(fiche.model, "name", "Fiches"), []
        ).append(_ligne(fiche.title, adresse, description))

    for modele in sorted(par_modele, key=str.lower):
        lignes += _section(modele, par_modele[modele])

    # « Optional » est un mot-clé de la convention, pas un titre : il désigne
    # la section qu'un lecteur pressé peut ignorer sans rien perdre
    # d'essentiel. On le laisse en anglais au milieu d'un fichier français
    # pour cette raison — le traduire lui ferait perdre son sens pour le
    # lecteur auquel il s'adresse.
    #
    # On y met le plan du site : la ressource complète, quand la carte
    # ci-dessus ne suffit pas.
    try:
        lignes += _section("Optional", [
            _ligne("Plan du site (XML)", reverse("sitemap_xml"),
                   "Toutes les adresses publiques, à jour."),
        ])
    except NoReverseMatch:
        pass

    corps = "\n".join(lignes).rstrip() + "\n"
    return HttpResponse(corps, content_type="text/plain; charset=utf-8")
