# jeiko/administration/tests_veille_javascript.py
"""
`requestIdleCallback` et `setTimeout` n'ont pas la même signature.

Le défaut
---------
`consent.js` contenait :

    (window.requestIdleCallback || window.setTimeout)(fn, 0);

L'aiguillage paraît raisonnable — prendre la fonction disponible — mais les
deux n'attendent pas le même second argument. `setTimeout` veut un délai en
millisecondes ; `requestIdleCallback` veut un objet `{ timeout: … }`. Passer
`0` aux deux fait échouer la seconde, et Chrome lève :

    TypeError: Failed to execute 'requestIdleCallback' on 'Window':
    The provided value is not of type 'IdleRequestOptions'.

L'exception interrompait `init()`, donc les quatre aides publiques déclarées
juste après — `jeikoOpenCookiePanel`, `jeikoOpenCookieBanner`,
`jeikoResetConsent`, `jeikoGetConsentStatus` — n'étaient jamais posées.
Vérifié sur un site en service : les quatre valaient `undefined`.

Pourquoi personne ne l'a vu
---------------------------
Trois raisons qui se sont additionnées :

* le corps de la fonction était VIDE — un emplacement réservé à des travaux
  qui ne sont jamais venus. Rien ne manquait visiblement ;
* Firefox et Safari n'implémentent pas `requestIdleCallback` : ils tombaient
  sur `setTimeout`, qui accepte un nombre. Le défaut ne se voyait que sur
  Chrome et Edge ;
* aucun gabarit livré n'appelle ces aides. Seul un exploitant qui avait
  branché un lien « gérer mes cookies » voyait un lien mort — et le RGPD
  demande qu'il soit aussi simple de retirer son consentement que de le
  donner.

Ce test lit les fichiers LIVRÉS, pas un rendu : c'est ce fichier-là qui part
chez le client.
"""

import pathlib
import re

from django.test import SimpleTestCase

#: Racine des scripts livrés avec le paquet.
JS = pathlib.Path(__file__).resolve().parent.parent / "static" / "jeiko" / "js"

#: Un aiguillage `(a || b)(…)` entre deux fonctions d'ordonnancement.
#:
#: On ne cherche pas `requestIdleCallback` tout court : l'employer seul, avec
#: son objet d'options, est parfaitement légitime. Ce qu'on interdit, c'est de
#: le confondre avec `setTimeout` derrière un `||`, parce que l'appel unique
#: qui suit ne peut pas convenir aux deux.
_AIGUILLAGE = re.compile(
    r"\(\s*window\.requestIdleCallback\s*\|\|\s*window\.setTimeout\s*\)"
    r"|\(\s*window\.setTimeout\s*\|\|\s*window\.requestIdleCallback\s*\)"
)

#: Les commentaires — retirés avant l'analyse, sans quoi celui qui RACONTE le
#: défaut se ferait prendre pour le défaut.
_COMMENTAIRE = re.compile(r"//[^\n]*|/\*.*?\*/", re.DOTALL)


def _sans_commentaires(texte):
    return _COMMENTAIRE.sub(
        lambda trouve: "\n" * trouve.group().count("\n"), texte
    )


class AiguillageDOrdonnancementTests(SimpleTestCase):
    def test_aucun_script_ne_confond_les_deux_fonctions(self):
        coupables = []
        for fichier in sorted(JS.rglob("*.js")):
            if ".min." in fichier.name:
                continue
            contenu = _sans_commentaires(fichier.read_text(errors="ignore"))
            for numero, ligne in enumerate(contenu.splitlines(), 1):
                if _AIGUILLAGE.search(ligne):
                    coupables.append(
                        f"{fichier.relative_to(JS)}:{numero} — {ligne.strip()[:90]}"
                    )

        self.assertEqual(
            coupables, [],
            "Aiguillage entre requestIdleCallback et setTimeout :\n  "
            + "\n  ".join(coupables)
            + "\nLeurs seconds arguments diffèrent — un délai en millisecondes "
              "d'un côté, un objet { timeout: … } de l'autre. L'appel unique "
              "qui suit lèvera sur l'une des deux branches, et l'exception "
              "interrompra le reste de la fonction. Écrire deux appels "
              "distincts.",
        )


class AidesPubliquesDuConsentementTests(SimpleTestCase):
    """
    Les quatre aides doivent être déclarées, et rien ne doit lever avant.

    Elles sont l'interface publique du bandeau : un exploitant les branche sur
    son lien « gérer mes cookies ». Les perdre rend le consentement
    irrévocable côté visiteur, ce que le RGPD n'admet pas.

    On lit la source plutôt que d'exécuter le script : monter un navigateur
    pour vérifier la présence de quatre affectations coûterait bien plus que
    ce que ça rapporte, et l'aiguillage fautif est déjà fermé au-dessus.
    """

    FICHIER = JS / "cookies" / "consent.js"

    AIDES = (
        "jeikoOpenCookiePanel",
        "jeikoOpenCookieBanner",
        "jeikoResetConsent",
        "jeikoGetConsentStatus",
    )

    def test_les_quatre_aides_sont_declarees(self):
        source = self.FICHIER.read_text()
        for aide in self.AIDES:
            with self.subTest(aide=aide):
                self.assertIn(f"window.{aide} =", source)
