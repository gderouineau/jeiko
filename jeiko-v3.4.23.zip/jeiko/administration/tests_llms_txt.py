# jeiko/administration/tests_llms_txt.py
"""
`/llms.txt` ne doit offrir que ce que le site publie déjà.

Ce que le fichier est
---------------------
Une carte du site à l'usage des modèles de langue (convention llmstxt.org) :
le nom, une phrase de présentation, puis les pages qui comptent, groupées et
décrites. Un assistant le lit d'abord plutôt que d'aspirer trente pages de
HTML pour en deviner la structure.

Le risque, et c'est le seul qui compte
--------------------------------------
Un fichier de ce genre est une invitation à publier trop. Il se remplit tout
seul, personne ne le relit, et il suffit d'un filtre oublié pour qu'un
brouillon, un gabarit d'e-mail ou une page volontairement retirée des moteurs
de recherche s'y retrouve — en clair, sur une adresse que tout le monde peut
lire.

Ces tests vérifient donc surtout des ABSENCES. C'est ce qui les rend utiles :
le contenu attendu se voit à l'œil nu, la fuite non.
"""

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Metadata, Page


@override_settings(ALLOWED_HOSTS=["*"])
class LlmsTxtTests(TestCase):
    def _corps(self):
        reponse = self.client.get("/llms.txt")
        self.assertEqual(reponse.status_code, 200)
        self.assertTrue(reponse["Content-Type"].startswith("text/plain"))
        return reponse.content.decode()

    # ------------------------------------------------------------------ #
    #  Ce qui doit y être
    # ------------------------------------------------------------------ #
    def test_une_page_publiee_y_figure_avec_sa_description(self):
        page = Page.objects.create(
            title="Nos tarifs", url_tag="tarifs", active=True, google_index=True
        )
        Metadata.objects.create(
            page=page, title="Tarifs", description="Trois formules, sans engagement."
        )
        corps = self._corps()
        self.assertIn("[Nos tarifs](/tarifs/)", corps)
        self.assertIn("Trois formules, sans engagement.", corps)

    def test_une_page_sans_metadonnees_est_listee_sans_description(self):
        """
        On n'invente pas de résumé.

        Décrire une page à sa place produirait une phrase plausible et fausse
        — exactement ce qu'un fichier de ce genre est censé éviter.
        """
        Page.objects.create(
            title="Nue", url_tag="nue", active=True, google_index=True
        )
        self.assertIn("- [Nue](/nue/)\n", self._corps())

    def test_le_plan_du_site_est_proposé_en_dernier(self):
        corps = self._corps()
        self.assertIn("## Optional", corps)
        self.assertIn("/sitemap.xml", corps)

    # ------------------------------------------------------------------ #
    #  Ce qui ne doit PAS y être — l'essentiel
    # ------------------------------------------------------------------ #
    def test_un_brouillon_n_y_figure_pas(self):
        Page.objects.create(
            title="Brouillon", url_tag="brouillon-llms", active=False
        )
        self.assertNotIn("brouillon-llms", self._corps())

    def test_une_page_retiree_des_moteurs_n_y_figure_pas(self):
        """
        `google_index=False` est une décision d'exploitant.

        Une page qu'on cache aux moteurs de recherche n'a aucune raison d'être
        offerte à un modèle : c'est la même intention, et la trahir ici serait
        d'autant plus sournois que personne ne pense à relire ce fichier.
        """
        Page.objects.create(
            title="Discrète", url_tag="discrete-llms",
            active=True, google_index=False,
        )
        self.assertNotIn("discrete-llms", self._corps())

    def test_les_gabarits_n_y_figurent_pas(self):
        """
        Corps d'e-mail, PDF, gabarit de fiche : des pages qui ne sont pas des
        pages. Le sitemap a déjà connu cette fuite — les corps d'e-mails s'y
        retrouvaient « explorés, non indexés » dans la Search Console.
        """
        for champ, tag in (
            ("is_mail_template", "mail-llms"),
            ("is_pdf", "pdf-llms"),
            ("is_custom_object_template", "gabarit-llms"),
        ):
            Page.objects.create(
                title=f"Gabarit {tag}", url_tag=tag, active=True,
                google_index=True, **{champ: True},
            )
        corps = self._corps()
        for tag in ("mail-llms", "pdf-llms", "gabarit-llms"):
            with self.subTest(tag=tag):
                self.assertNotIn(tag, corps)

    def test_une_fiche_non_publiee_n_y_figure_pas(self):
        from jeiko.custom_objects.models import CustomObject, CustomObjectModel

        gabarit = Page.objects.create(
            title="Gabarit", url_tag="gabarit-fiche-llms",
            is_custom_object_template=True,
        )
        modele = CustomObjectModel.objects.create(
            name="Article", slug="article-llms", page_template=gabarit
        )
        CustomObject.objects.create(
            model=modele, title="Caché", slug="cache-llms", is_published=False
        )
        self.assertNotIn("cache-llms", self._corps())

    # ------------------------------------------------------------------ #
    #  La borne
    # ------------------------------------------------------------------ #
    def test_une_section_trop_longue_est_bornee_et_le_dit(self):
        """
        Tronquer sans le dire donnerait une carte incomplète qui se croit
        complète — le pire des deux mondes.
        """
        from jeiko.administration.llms_txt import PLAFOND_PAR_SECTION

        for numero in range(PLAFOND_PAR_SECTION + 5):
            Page.objects.create(
                title=f"Page {numero}", url_tag=f"masse-{numero}",
                active=True, google_index=True,
            )
        corps = self._corps()
        self.assertIn("autres — voir /sitemap.xml", corps)


@override_settings(ALLOWED_HOSTS=["*"])
class AnnonceDansRobotsTests(TestCase):
    """
    `robots.txt` annonce `llms.txt` — et se tait quand on lui demande de se taire.
    """

    def _robots(self):
        return self.client.get("/robots.txt").content.decode()

    def test_llms_txt_est_annonce(self):
        corps = self._robots()
        self.assertIn("Allow: /llms.txt", corps)
        self.assertIn("/llms.txt", corps)

    def test_l_allow_ne_masque_pas_les_interdictions_d_administration(self):
        """Un « Allow » mal placé peut annuler un « Disallow » plus général."""
        corps = self._robots()
        for interdit in ("/admin/", "/administration/", "/pass-test/"):
            with self.subTest(chemin=interdit):
                self.assertIn(f"Disallow: {interdit}", corps)

    @override_settings(JEIKO_ROBOTS_DISALLOW_ALL=True)
    def test_un_site_ferme_reste_ferme(self):
        """
        L'exploitant qui coupe tout ne doit pas voir une porte rouverte.

        C'est le seul cas où la discrétion l'emporte sur la découvrabilité :
        `JEIKO_ROBOTS_DISALLOW_ALL` est une décision explicite, et y glisser un
        « Allow » — fût-ce pour un fichier utile — la contredirait sans
        prévenir personne.
        """
        corps = self._robots()
        self.assertEqual(corps.strip(), "User-agent: *\nDisallow: /")
        self.assertNotIn("llms.txt", corps)
