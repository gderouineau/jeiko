# jeiko/agents/authentification.py
"""
Qui appelle, et a-t-il le droit. Le point d'entrée unique de l'API des agents.

Une seule façon d'entrer
------------------------
**Le jeton porteur, et rien d'autre.** Si l'en-tête `Authorization` ne porte
pas un jeton valide, la requête est refusée — même si elle arrive avec un
cookie de session d'administrateur parfaitement valide.

Ce n'est pas de la rigueur pour la rigueur. Une API qui accepterait aussi la
session serait manipulable depuis le navigateur d'un administrateur connecté :
une page piégée lui ferait modifier son propre site à son insu, exactement
comme une faille CSRF. En n'acceptant que l'en-tête — qu'un formulaire ne peut
pas poser en requête inter-origines — le problème n'existe pas, et l'exemption
CSRF de ces vues devient sûre au lieu d'être un trou.

C'est aussi pour cela que le jeton ne se lit **jamais** dans l'URL : une URL
part dans les journaux du serveur, dans l'en-tête `Referer`, dans l'historique
du navigateur et dans les captures d'écran.

Les refus ne s'expliquent pas — sauf un
--------------------------------------
Toute erreur d'authentification renvoie le même message. Distinguer « jeton
inconnu » de « agent expiré » de « IP non autorisée » apprend à un appelant
hostile l'état du système et lui dit quoi corriger. Le motif précis va dans le
journal (`AppelAgent.motif_refus`), qui est pour l'exploitant.

**Le plafond d'appels fait exception, et lui seul.** On ne l'atteint qu'APRÈS
avoir présenté un jeton valide : celui qui le rencontre détient déjà le secret,
et lui répondre « 429, réessayez dans 812 secondes » ne lui apprend rien qu'il
ne puisse mesurer en comptant ses propres appels. Le taire, en revanche, coûte
cher : un agent légitime qui reçoit le même 401 qu'un jeton mort conclut que sa
clé est morte, la fait remplacer, et recommence — c'est exactement ce qui s'est
passé en montant jeiko.fr, puis sur un site client. Un refus qu'on ne peut pas
distinguer d'une panne EST une panne.

Le plafond des ÉCHECS par IP, lui, reste muet : on l'atteint sans jeton valide,
et annoncer sa limite à qui essaie des clés au hasard lui dit à quel rythme
ralentir, ou quand changer d'adresse.

Ce que cette couche ne fait pas
-------------------------------
Elle dit QUI appelle. Elle ne dit pas ce qu'il a le droit de faire : cela reste
la permission Django, portée par les rôles du compte de l'agent. Une vue qui
oublierait de vérifier sa permission serait ouverte à tout agent authentifié —
d'où `PermissionAgentMixin`, qui rend l'oubli impossible en exigeant une
permission déclarée.
"""

import logging
from collections import namedtuple
from functools import wraps
from hmac import compare_digest

from django.conf import settings
from django.db import transaction
from django.http import JsonResponse
from django.utils import timezone

from jeiko.throttling import (
    get_client_ip, get_limits, hit, hit_avec_reste, ip_stockable,
)

from . import jetons
from .models import Agent, AgentToken, AppelAgent

logger = logging.getLogger(__name__)

#: Message unique, volontairement muet. Voir l'en-tête du module.
REFUS = "Authentification requise ou refusée."

#: Ce qu'`identifier` rend quand elle refuse : le motif pour le journal, le
#: code HTTP, et — pour le seul plafond — de quoi composer une réponse qui
#: s'explique. `agent` et `prefixe` ne sont renseignés que lorsqu'on SAIT à qui
#: l'on parle : le journal peut alors accrocher le refus à la fiche de l'agent,
#: là où l'exploitant va le chercher.
Refus = namedtuple(
    "Refus",
    "motif statut reessayer_dans plafond agent prefixe",
    defaults=(401, 0, None, None, ""),
)

#: (nombre maximum, fenêtre en secondes)
PLAFONDS_PAR_DEFAUT = {
    # Par jeton : un agent légitime travaille par rafales, on est large.
    "jeton": (600, 3600),
    # Par IP, jetons invalides uniquement : c'est le compteur qui arrête
    # quelqu'un qui essaie des jetons au hasard.
    "echecs_ip": (20, 900),
}

#: On n'écrit `derniere_utilisation_le` que si la valeur a vieilli : sinon
#: chaque lecture de l'API deviendrait une écriture en base.
FRAICHEUR_DERNIER_APPEL_SECONDES = 300


def plafonds():
    return get_limits("JEIKO_AGENTS_LIMITS", PLAFONDS_PAR_DEFAUT)


def _https_exige():
    """
    Un jeton qui voyage en clair est un jeton divulgué.

    Désactivable pour le développement local uniquement. En production, le
    réglage n'a pas à être touché : l'installeur sert le site en HTTPS.
    """
    return not getattr(settings, "JEIKO_AGENTS_AUTORISER_HTTP", settings.DEBUG)


def _jeton_de_la_requete(request):
    """Lit l'en-tête `Authorization: Bearer …`. Rien d'autre n'est accepté."""
    entete = request.META.get("HTTP_AUTHORIZATION", "")
    if not entete:
        return ""
    morceaux = entete.split(None, 1)
    if len(morceaux) != 2 or morceaux[0].lower() != "bearer":
        return ""
    return morceaux[1].strip()


def _tracer(request, agent, prefixe, statut, motif=""):
    """
    Écrit le journal. Ne lève jamais : tracer ne doit pas casser l'appel.
    """
    try:
        AppelAgent.objects.create(
            agent=agent,
            prefixe_jeton=prefixe or "",
            methode=request.method[:10],
            chemin=request.path[:300],
            statut=statut,
            motif_refus=motif[:60],
            # `ip_stockable` et non `get_client_ip` : ce dernier renvoie la
            # chaîne « unknown » quand l'adresse manque, et Postgres refuse de
            # l'écrire dans un champ `inet`. L'exception était attrapée plus
            # bas — le journal restait donc VIDE, sans que rien ne le dise.
            # C'est le cas normal derrière une socket unix, c'est-à-dire sur
            # toutes les installations produites par l'INSTALLER.
            ip=ip_stockable(request),
        )
    except Exception:
        logger.exception("Journalisation d'un appel d'agent impossible.")


def _marquer_utilisation(agent, jeton, ip):
    """Horodate l'usage, sans transformer chaque lecture en écriture."""
    maintenant = timezone.now()
    seuil = maintenant - timezone.timedelta(seconds=FRAICHEUR_DERNIER_APPEL_SECONDES)

    try:
        with transaction.atomic():
            if not agent.derniere_utilisation_le or agent.derniere_utilisation_le < seuil:
                Agent.objects.filter(pk=agent.pk).update(
                    derniere_utilisation_le=maintenant, derniere_ip=ip
                )
            if (
                not jeton.derniere_utilisation_le
                or jeton.derniere_utilisation_le < seuil
            ):
                AgentToken.objects.filter(pk=jeton.pk).update(
                    derniere_utilisation_le=maintenant
                )
    except Exception:
        logger.exception("Horodatage de l'appel d'agent impossible.")


def identifier(request):
    """
    Renvoie `(agent, jeton, refus)`, `refus` étant `None` quand tout va bien.

    `agent` est `None` dès qu'il y a un refus. Le motif porté par le refus est
    un code court, destiné au journal — jamais à la réponse, à la seule
    exception du plafond (voir l'en-tête du module).
    """
    ip = get_client_ip(request)

    if _https_exige() and not request.is_secure():
        return None, None, Refus("http")

    presente = _jeton_de_la_requete(request)
    if not presente:
        return None, None, Refus("absent")

    prefixe, secret = jetons.decouper(presente)
    if not prefixe:
        return None, None, Refus("malforme")

    limites = plafonds()

    jeton = (
        AgentToken.objects.select_related("agent", "agent__user")
        .filter(prefixe=prefixe)
        .first()
    )

    # Comparaison à temps constant, et toujours effectuée : sur un préfixe
    # inconnu on compare contre une empreinte factice, pour que le temps de
    # réponse ne dise pas si le préfixe existe.
    attendue = jeton.empreinte if jeton else "0" * 64
    correspond = compare_digest(jetons.empreinte(secret), attendue)

    if jeton is None or not correspond:
        if hit("agents:echecs", ip, *limites["echecs_ip"]):
            logger.warning("Trop de jetons d'agent refusés depuis %s.", ip)
            return None, None, Refus("plafond_echecs")
        return None, None, Refus("inconnu")

    if jeton.revoque:
        return None, None, Refus("revoque")

    agent = jeton.agent
    if not agent.utilisable:
        return None, None, Refus(agent.raison_de_refus or "inutilisable")

    if not agent.ip_autorisee(ip):
        logger.warning(
            "Agent « %s » appelé depuis %s, hors de sa liste d'adresses.",
            agent.nom, ip,
        )
        return None, None, Refus("ip")

    # Le plafond de CET agent l'emporte sur celui du site.
    #
    # Le plafond par défaut — six cents appels par heure — est large pour un
    # agent qui entretient un site, et trop juste pour un agent qui en
    # construit un : monter une dizaine de pages en demande plusieurs
    # centaines, chaque bloc coûtant deux ou trois appels. Un réglage unique
    # ne peut pas servir les deux usages, et c'est l'usage initial — le plus
    # légitime — qui se trouvait empêché.
    maximum, fenetre = limites["jeton"]
    if agent.plafond_horaire:
        maximum, fenetre = agent.plafond_horaire, 3600

    depasse, reessayer_dans = hit_avec_reste(
        "agents:appels", prefixe, maximum, fenetre
    )
    if depasse:
        logger.warning(
            "Agent « %s » a atteint son plafond : %s appels par %s s.",
            agent.nom, maximum, fenetre,
        )
        return None, None, Refus(
            "plafond",
            statut=429,
            reessayer_dans=reessayer_dans,
            plafond=(maximum, fenetre),
            # Le jeton est vérifié : on sait à qui l'on refuse, et le journal
            # doit le dire. C'est le seul refus dans ce cas.
            agent=agent,
            prefixe=prefixe,
        )

    _marquer_utilisation(agent, jeton, ip)
    return agent, jeton, None


def _reponse_de_refus(refus):
    """
    La réponse à rendre. Muette par défaut, explicite pour le seul plafond.

    Le `Retry-After` n'est pas décoratif : c'est lui qu'une bibliothèque
    cliente lit pour attendre au lieu de marteler, et sans lui un agent poli
    n'a aucun moyen de l'être.
    """
    if refus.statut != 429:
        reponse = JsonResponse({"erreur": REFUS}, status=401)
        reponse["WWW-Authenticate"] = 'Bearer realm="jeiko"'
        return reponse

    maximum, fenetre = refus.plafond
    par = "heure" if fenetre == 3600 else f"tranche de {fenetre} secondes"
    reponse = JsonResponse(
        {
            "erreur": (
                f"Plafond d'appels atteint pour ce jeton : {maximum} appels "
                f"par {par}. Réessayez dans {refus.reessayer_dans} secondes, "
                "ou faites relever le plafond de cet agent dans "
                "l'administration du site."
            ),
            "plafond": {"maximum": maximum, "fenetre_secondes": fenetre},
            "reessayer_dans_secondes": refus.reessayer_dans,
        },
        status=429,
    )
    reponse["Retry-After"] = str(refus.reessayer_dans)
    return reponse


def exige_un_agent(vue):
    """
    Décorateur : refuse tout ce qui n'est pas un agent authentifié.

    Pose `request.agent` et **remplace** `request.user` par le compte porteur.
    Le remplacement est délibéré : à partir d'ici, tout le code de permissions
    de JEIKO raisonne sur ce compte, et une session de navigateur qui traînerait
    sur la requête n'a plus aucun effet.
    """

    @wraps(vue)
    def enveloppe(request, *args, **kwargs):
        agent, jeton, refus = identifier(request)

        if refus is not None:
            _tracer(
                request, refus.agent, refus.prefixe, refus.statut, refus.motif
            )
            return _reponse_de_refus(refus)

        request.agent = agent
        request.jeton_agent = jeton
        request.user = agent.user

        reponse = vue(request, *args, **kwargs)
        _tracer(request, agent, jeton.prefixe, getattr(reponse, "status_code", 0))
        return reponse

    return enveloppe
