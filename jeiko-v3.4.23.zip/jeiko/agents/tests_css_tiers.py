# jeiko/agents/tests_css_tiers.py
"""
Un champ de CSS ne charge rien depuis un autre domaine.

Ce qui s'est passé
------------------
Sur un site client, un agent a construit une page très correcte — chaque
sélecteur préfixé par `.content`, comme le guide le demande — et a posé en
tête du CSS de la section :

    @import url(https://fonts.googleapis.com/css?family=EB+Garamond|Inter);

Deux défauts d'un coup, et l'agent n'avait aucun moyen de les voir.

**Ça ne marchait pas.** Le CSS personnalisé est rendu dans un `<style>` que
quatre règles précèdent (`styles/section.html`). Un `@import` placé après une
règle est ignoré par tous les navigateurs : la page retombait sur Georgia et
sur la police système, sans que rien ne le signale.

**Et si ça avait marché, ce serait pire.** L'adresse IP de chaque visiteur
serait partie chez Google, à chaque page, avant tout consentement. Le produit
auto-héberge ses polices exprès, et `administration/tests_ressources_externes`
(R-06) interdit ces hôtes — mais il ne regarde que les GABARITS. La
dépendance revenait par les DONNÉES.

Ce que ces tests gardent
------------------------
* le refus, et sa raison, à l'écriture par l'API ;
* le refus dit OÙ aller — sans cela on ne fait que déplacer le problème ;
* ce qui reste permis : les adresses du site, la médiathèque, `data:`.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Page

from .tests import SocleMixin, donner_le_role


#: Le CSS réellement reçu sur le site client, réduit à ce qui compte.
CSS_DU_SITE_CLIENT = (
    "@import url(https://fonts.googleapis.com/css?family=EB+Garamond:400|Inter:300);\n"
    ".content .ah-h1{font-family:EB Garamond,Georgia,serif;color:#26201B}"
)


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class CssQuiAppelleUnTiersTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(self.agent.user, "view_page", "add_page", "change_page")
        self.page = Page.objects.create(title="Params", url_tag="params-css")
        self.section = json.loads(self.json_post(
            f"/api/agent/v1/pages/{self.page.id}/sections/", {}, self.jeton
        ).content)["section"]

    def patch(self, corps):
        return self.client.patch(
            f"/api/agent/v1/sections/{self.section['id']}/",
            data=json.dumps(corps),
            content_type="application/json",
            **self.entetes(self.jeton),
        )

    def _refus(self, valeurs):
        reponse = self.patch({"css": valeurs})
        self.assertEqual(reponse.status_code, 400)
        return json.loads(reponse.content)["erreur"]

    def test_le_css_du_site_client_est_refuse(self):
        erreur = self._refus({"custom": CSS_DU_SITE_CLIENT})
        self.assertIn("@import", erreur)

    def test_le_refus_dit_ou_regler_les_polices(self):
        """
        Un refus qui ne nomme pas la solution ne fait que déplacer le
        problème : l'agent réessaiera autrement, et souvent moins bien.
        """
        erreur = self._refus({"custom": CSS_DU_SITE_CLIENT})
        self.assertIn("identite", erreur)
        self.assertIn("polices", erreur)

    def test_import_dans_n_importe_quel_champ(self):
        """Douze champs portent du CSS ; le refus ne vise pas que `custom`."""
        for champ in ("before", "current", "after", "hover",
                      "current_phone", "current_laptop"):
            with self.subTest(champ=champ):
                erreur = self._refus({champ: "@IMPORT url('//x.tld/a.css');"})
                self.assertIn(champ, erreur)

    def test_une_police_appelee_en_font_face_est_refusee_aussi(self):
        """
        Contourner l'`@import` par un `@font-face` distant reviendrait au
        même pour le visiteur : c'est l'appel au tiers qu'on refuse, pas le
        mot-clé.
        """
        erreur = self._refus({"custom": (
            "@font-face{font-family:X;src:url(https://cdn.tld/x.woff2)}"
        )})
        self.assertIn("domaine", erreur)

    def test_les_ressources_du_site_restent_permises(self):
        """
        Le refus vise le tiers, pas la propriété `url()`. Une image de la
        médiathèque, une donnée en ligne, une adresse relative : rien à
        redire.
        """
        reponse = self.patch({"css": {"custom": (
            ".content .x{background:url(/media/images/fond.webp)}"
            ".content .y{background:url('data:image/gif;base64,R0lGOD')}"
        )}})
        self.assertEqual(reponse.status_code, 200, reponse.content[:300])


class LeGuideLeDitTests(TestCase):
    """
    Le refus ne suffit pas : un agent doit le savoir AVANT d'écrire sa page.

    Le guide est le premier appel d'un agent ; s'il n'y dit pas où se règlent
    les polices, chaque agent redécouvrira le mur par un 400 — au mieux.
    """

    def _guide(self):
        from jeiko.agents.guide import PROSE

        return PROSE

    def test_le_guide_renvoie_a_l_identite_pour_les_polices(self):
        guide = self._guide()
        self.assertIn("@import", guide)
        self.assertIn("/api/agent/v1/identite/", guide)
        self.assertIn("url_google_fonts", guide)

    def test_le_guide_explique_les_categories_de_pages(self):
        guide = self._guide()
        self.assertIn("sous_categorie", guide)
        self.assertIn("categorie_parente", guide)

    def test_le_guide_reclame_des_metadonnees(self):
        guide = self._guide()
        self.assertIn("metadonnees", guide)
        self.assertIn("description", guide)
