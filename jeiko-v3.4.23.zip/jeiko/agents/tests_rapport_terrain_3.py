# jeiko/agents/tests_rapport_terrain_3.py
"""
Second rapport de terrain (07/09) : ce qui restait après vérification.

Le rapport listait huit points. Quatre étaient déjà corrigés au moment où il
est arrivé — il décrivait des observations antérieures à la mise à jour. Deux
autres ont été vérifiés et ne se reproduisent pas : le nom de catégorie en
double rend bien 400, et une catégorie désignée par identifiant ou par nom
s'écrit bien. Restaient deux vrais défauts, que ces tests verrouillent.

**Une clé inconnue à la CRÉATION était ignorée.** `POST /pages/<id>/sections/`
avec `{"zzz": 1}` créait une section vide et répondait 201, là où le `PATCH`
équivalent rend un 400 exemplaire. Sept routes de création étaient dans ce
cas. Une faute de frappe — `gabarit_de_section` au lieu de `gabarit` —
produisait donc un objet à moitié voulu, sans un mot, et l'agent
recommençait. Le terrain l'a payé en sondes laissées en base.

**Une catégorie ne se supprimait pas.** Son slug est unique et ne se modifie
plus : une catégorie créée pour essayer restait là pour toujours. Elle se
supprime maintenant, mais VIDE seulement — `Page.category` étant en
`SET_NULL`, supprimer une catégorie pleine déclasserait ses pages, changerait
leur adresse et casserait les liens publiés sans qu'aucune erreur n'apparaisse.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Category, Page, Section

from .tests import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class CleInconnueALaCreationTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(self.agent.user, "view_page", "add_page", "change_page")
        self.page = Page.objects.create(title="Sonde", url_tag="sonde-cles")
        self.section = json.loads(self.json_post(
            f"/api/agent/v1/pages/{self.page.id}/sections/", {}, self.jeton
        ).content)["section"]

    def test_une_section_n_est_pas_creee_pour_une_cle_inconnue(self):
        avant = Section.objects.count()
        reponse = self.json_post(
            f"/api/agent/v1/pages/{self.page.id}/sections/", {"zzz": 1}, self.jeton
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("zzz", json.loads(reponse.content)["erreur"])
        self.assertEqual(
            Section.objects.count(), avant,
            "Une sonde d'introspection ne doit pas laisser de déchet en base.",
        )

    def test_le_refus_nomme_les_cles_acceptees(self):
        reponse = self.json_post(
            f"/api/agent/v1/pages/{self.page.id}/sections/", {"zzz": 1}, self.jeton
        )
        self.assertIn("gabarit", json.loads(reponse.content)["erreur"])

    def test_les_creations_de_ligne_et_de_bloc_aussi(self):
        chemins = (
            f"/api/agent/v1/sections/{self.section['id']}/lignes/",
            f"/api/agent/v1/pages/{self.page.id}/sections/",
        )
        for chemin in chemins:
            with self.subTest(chemin=chemin):
                self.assertEqual(
                    self.json_post(chemin, {"zzz": 1}, self.jeton).status_code, 400
                )

    def test_la_creation_de_page_refuse_aussi(self):
        reponse = self.json_post(
            "/api/agent/v1/pages/creer/",
            {"titre": "Essai", "gabarit_de_section": "HERO"}, self.jeton,
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertFalse(Page.objects.filter(title="Essai").exists())

    def test_ce_qui_est_legitime_passe_toujours(self):
        reponse = self.json_post(
            f"/api/agent/v1/pages/{self.page.id}/sections/",
            {"gabarit": "CLASSIC"}, self.jeton,
        )
        self.assertEqual(reponse.status_code, 201, reponse.content[:200])


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class SuppressionDeCategorieTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(self.agent.user, "view_page", "add_page", "change_page")
        self.categorie = Category.objects.create(name="ZZ sonde", slug="zz-sonde")

    def _supprimer(self, categorie):
        return self.client.delete(
            f"/api/agent/v1/categories/{categorie.id}/", **self.entetes(self.jeton)
        )

    def test_une_categorie_vide_se_supprime(self):
        self.assertEqual(self._supprimer(self.categorie).status_code, 200)
        self.assertFalse(Category.objects.filter(pk=self.categorie.pk).exists())

    def test_une_categorie_qui_classe_des_pages_est_refusee(self):
        Page.objects.create(
            title="Classée", url_tag="classee", category=self.categorie
        )
        reponse = self._supprimer(self.categorie)
        self.assertEqual(reponse.status_code, 400)
        erreur = json.loads(reponse.content)["erreur"]
        self.assertIn("1 page", erreur)
        self.assertTrue(Category.objects.filter(pk=self.categorie.pk).exists())

    def test_une_categorie_avec_une_fille_est_refusee(self):
        Category.objects.create(
            name="Fille", slug="fille", main_category=self.categorie
        )
        reponse = self._supprimer(self.categorie)
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("sous-catégorie", json.loads(reponse.content)["erreur"])
