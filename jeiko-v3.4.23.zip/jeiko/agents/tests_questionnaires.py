# jeiko/agents/tests_questionnaires.py
"""
Construire un questionnaire par l'API : profils, questions, poids, arbitrages.

Pourquoi ces tests sont écrits comme ça
----------------------------------------
Un questionnaire mal construit ne plante pas. Il répond — et il répond faux.
Un poids posé sur la mauvaise réponse, un profil emprunté à un autre test, un
intervalle de score inversé : rien de tout cela ne lève, rien ne s'affiche en
rouge. Le défaut se découvre en passant le test, ou pire, ne se découvre pas.

Les contrôles portent donc sur ce que le CALCUL verra, pas sur les codes de
réponse HTTP. Vérifier qu'un POST renvoie 201 ne dit rien de la justesse des
poids qu'il a écrits.

Trois familles :

* **le calcul est bien alimenté** — les poids relus sont ceux qu'on a envoyés,
  attachés aux bonnes réponses ;
* **rien n'est écrit à moitié** — une liste refusée en son milieu ne laisse pas
  une question à demi réécrite, état qui fausserait le test sans se voir ;
* **les données personnelles restent hors de portée** — aucune route ne mène
  aux passages ni aux prospects, et c'est vérifié plutôt que supposé.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Page
from jeiko.questionnaires_expert.models import (
    ExpertAnswer, ExpertProfileType, ExpertQuestion, ExpertTest,
)

from .tests import SocleMixin, donner_le_role

RACINE = "/api/agent/v1"
CREER = f"{RACINE}/questionnaires/creer/"

DROITS = (
    "view_experttest", "add_experttest", "change_experttest",
    "view_expertprofiletype", "add_expertprofiletype", "change_expertprofiletype",
    "view_expertquestion", "add_expertquestion", "change_expertquestion",
    "view_expertanswer", "add_expertanswer", "change_expertanswer",
    "view_expertanswerprofileweight", "add_expertanswerprofileweight",
    "change_expertanswerprofileweight",
    "view_expertprofilecombination", "add_expertprofilecombination",
    "change_expertprofilecombination",
    "view_expertprofilecriterion", "add_expertprofilecriterion",
    "change_expertprofilecriterion",
)


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class SocleQuestionnaire(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, *DROITS,
            app="questionnaires_expert", nom="Rôle de test questionnaires",
        )
        self.test = ExpertTest.objects.create(
            title="Quel artisan êtes-vous ?", slug="artisan", is_active=False
        )
        self.rapide = ExpertProfileType.objects.create(
            test=self.test, name="Le rapide", slug="rapide"
        )
        self.minutieux = ExpertProfileType.objects.create(
            test=self.test, name="Le minutieux", slug="minutieux"
        )

    def _patch(self, chemin, corps):
        return self.client.patch(
            chemin, data=json.dumps(corps), content_type="application/json",
            **self.entetes(self.jeton),
        )


class ConstructionTests(SocleQuestionnaire):
    def test_un_questionnaire_nait_inactif(self):
        """
        À moitié construit — ses questions, pas ses poids — il donnerait des
        résultats faux à qui le passerait entre-temps.
        """
        reponse = self.json_post(
            CREER, {"titre": "Nouveau test", "slug": "nouveau"}, self.jeton
        )
        self.assertEqual(reponse.status_code, 201)
        self.assertFalse(ExpertTest.objects.get(slug="nouveau").is_active)

    def test_une_question_arrive_avec_ses_reponses_et_ses_poids(self):
        reponse = self.json_post(
            f"{RACINE}/questionnaires/{self.test.id}/questions/",
            {
                "texte": "Vous commencez un chantier :",
                "type": "single",
                "reponses": [
                    {"texte": "Je fonce", "poids": {"rapide": 3, "minutieux": 0}},
                    {"texte": "Je mesure deux fois",
                     "poids": {"rapide": 0, "minutieux": 3}},
                ],
            },
            self.jeton,
        )
        self.assertEqual(reponse.status_code, 201)

        document = reponse.json()["question"]
        self.assertEqual(len(document["reponses"]), 2)
        self.assertEqual(
            document["reponses"][0]["poids"], {"rapide": 3.0, "minutieux": 0.0},
            "Les poids relus doivent être ceux envoyés, sur la bonne réponse : "
            "c'est tout ce que le calcul verra.",
        )
        self.assertEqual(document["reponses"][1]["poids"]["minutieux"], 3.0)

    def test_reecrire_les_reponses_remplace_la_liste(self):
        question = ExpertQuestion.objects.create(
            test=self.test, text="Q", order=1, question_type="single"
        )
        ExpertAnswer.objects.create(question=question, text="Ancienne", order=1)

        self._patch(f"{RACINE}/questions/{question.id}/", {
            "reponses": [{"texte": "Nouvelle", "poids": {"rapide": 1}}]
        })
        self.assertEqual(
            list(question.answers.values_list("text", flat=True)), ["Nouvelle"],
            "Fusionner par position mettrait un poids sur la mauvaise réponse.",
        )

    def test_un_profil_porte_sa_page_de_resultat(self):
        page = Page.objects.create(title="Résultat rapide", url_tag="res-rapide")
        reponse = self.json_post(
            f"{RACINE}/questionnaires/{self.test.id}/profils/",
            {"nom": "L'organisé", "page_de_resultat": page.id,
             "attribue_par_score": True, "score_min": 10, "score_max": 20},
            self.jeton,
        )
        self.assertEqual(reponse.status_code, 201)
        profil = ExpertProfileType.objects.get(slug="lorganise")
        self.assertEqual(profil.result_page, page)
        self.assertEqual(profil.min_score, 10)


class RefusTests(SocleQuestionnaire):
    """Ce que l'API doit refuser, et refuser AVANT d'écrire."""

    def test_un_poids_vers_le_profil_d_un_autre_test_est_refuse(self):
        """
        La base l'accepterait : ce sont deux `ExpertProfileType`. Le calcul
        deviendrait faux sans que rien ne le signale.
        """
        autre = ExpertTest.objects.create(title="Autre", slug="autre")
        ExpertProfileType.objects.create(test=autre, name="Étranger", slug="etranger")

        reponse = self.json_post(
            f"{RACINE}/questionnaires/{self.test.id}/questions/",
            {"texte": "Q", "reponses": [
                {"texte": "R", "poids": {"etranger": 2}}
            ]},
            self.jeton,
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("etranger", reponse.json()["erreur"])

    def test_une_liste_refusee_en_son_milieu_n_ecrit_rien(self):
        question = ExpertQuestion.objects.create(
            test=self.test, text="Q", order=1, question_type="single"
        )
        ExpertAnswer.objects.create(question=question, text="Intacte", order=1)

        reponse = self._patch(f"{RACINE}/questions/{question.id}/", {
            "reponses": [
                {"texte": "Bonne", "poids": {"rapide": 1}},
                {"texte": "Mauvaise", "poids": {"inexistant": 1}},
            ]
        })
        self.assertEqual(reponse.status_code, 400)
        self.assertEqual(
            list(question.answers.values_list("text", flat=True)), ["Intacte"],
            "Une question à moitié réécrite fausse le test sans se voir.",
        )

    def test_un_intervalle_de_score_inverse_est_refuse(self):
        reponse = self.json_post(
            f"{RACINE}/questionnaires/{self.test.id}/profils/",
            {"nom": "Impossible", "attribue_par_score": True,
             "score_min": 20, "score_max": 10},
            self.jeton,
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertFalse(ExpertProfileType.objects.filter(slug="impossible").exists())

    def test_un_poids_non_numerique_est_refuse(self):
        reponse = self.json_post(
            f"{RACINE}/questionnaires/{self.test.id}/questions/",
            {"texte": "Q", "reponses": [
                {"texte": "R", "poids": {"rapide": "beaucoup"}}
            ]},
            self.jeton,
        )
        self.assertEqual(reponse.status_code, 400)

    def test_une_cle_inconnue_est_refusee(self):
        reponse = self.json_post(
            CREER, {"titre": "T", "activee": True}, self.jeton
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("activee", reponse.json()["erreur"])


class CombinaisonTests(SocleQuestionnaire):
    def test_une_combinaison_arbitre_deux_profils_proches(self):
        reponse = self.json_post(
            f"{RACINE}/questionnaires/{self.test.id}/combinaisons/",
            {
                "titre": "Rapide ou minutieux",
                "profil_parent": "rapide",
                "profil_prefere": "minutieux",
                "criteres": [
                    {"profil_a": "rapide", "profil_b": "minutieux",
                     "comparaison": "~=", "tolerance": 2},
                ],
            },
            self.jeton,
        )
        self.assertEqual(reponse.status_code, 201)
        document = reponse.json()["combinaison"]
        self.assertEqual(len(document["criteres"]), 1)
        self.assertEqual(document["criteres"][0]["tolerance"], 2)

    def test_un_profil_parent_est_obligatoire(self):
        """
        `parent_profile` est NOT NULL : l'omettre levait une 500. Et une
        combinaison sans profil parent n'a pas de sens — c'est lui qu'on
        arbitre.
        """
        reponse = self.json_post(
            f"{RACINE}/questionnaires/{self.test.id}/combinaisons/",
            {"titre": "Sans parent", "profil_prefere": "minutieux"},
            self.jeton,
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("profil_parent", reponse.json()["erreur"])

    def test_proche_de_sans_tolerance_est_refuse(self):
        """Sans tolérance, « ~= » revient à « == » : le critère est inopérant."""
        reponse = self.json_post(
            f"{RACINE}/questionnaires/{self.test.id}/combinaisons/",
            {"titre": "Sans tolérance", "profil_parent": "rapide", "criteres": [
                {"profil_a": "rapide", "profil_b": "minutieux", "comparaison": "~="}
            ]},
            self.jeton,
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("tolerance", reponse.json()["erreur"])


class DonneesPersonnellesTests(SocleQuestionnaire):
    def test_aucune_route_ne_mene_aux_passages_ni_aux_prospects(self):
        """
        `ExpertTestData` et `Prospect` portent les réponses de personnes
        identifiables. L'absence de route est la barrière — une permission
        oubliée se rattrape, une route ouverte se découvre trop tard.

        ⚠️ Le mot « réponse » désigne deux choses opposées dans ce domaine :
        une réponse PROPOSÉE par le questionnaire (`ExpertAnswer`, c'est sa
        définition, et l'API l'écrit déjà sous la clé « reponses ») et une
        réponse DONNÉE par un visiteur (dans le JSON d'`ExpertTestData`). Ce
        test gardait le mot lui-même, ce qui interdisait la première au motif
        de protéger la seconde. Il garde maintenant ce qui porte vraiment des
        données personnelles, et vérifie séparément que la route « reponses/ »
        ne mène qu'à la définition.
        """
        from jeiko.agents.urls_api import urlpatterns

        chemins = " ".join(str(m.pattern) for m in urlpatterns)
        for interdit in ("passage", "prospect", "resultat", "testdata", "datas"):
            with self.subTest(mot=interdit):
                self.assertNotIn(interdit, chemins)

    def test_la_route_des_reponses_ne_touche_que_la_definition(self):
        """
        Une seule méthode, DELETE, sur `ExpertAnswer` — pas de listage, donc
        aucun moyen de remonter à ce qu'une personne a répondu.
        """
        from jeiko.agents.vues_questionnaires import DetailReponse

        methodes = {
            m for m in ("get", "post", "put", "patch", "delete")
            if hasattr(DetailReponse, m)
        }
        self.assertEqual(methodes, {"delete"})


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class BoutonVersUnTestTests(SocleMixin, TestCase):
    """
    Le bouton « Commencer le test » doit viser un questionnaire QUI EXISTE.

    `ContentButton.test_slug` est une chaîne libre : n'importe quelle valeur
    s'enregistre, et le bouton apparaît normalement sur la page. Il ne mène
    simplement nulle part. Encore une panne muette — visible seulement en
    cliquant, c'est-à-dire par un visiteur.
    """

    def setUp(self):
        from jeiko.administration_pages.models import Bloc, Line, Section

        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent pages pour boutons",
        )
        ExpertTest.objects.create(title="Quel artisan ?", slug="artisan")

        page = Page.objects.create(title="Accueil", url_tag="accueil-bouton")
        section = Section.objects.create(page=page, position=0)
        ligne = Line.objects.create(
            section=section, position=0, columns_type="12", columns_number=1
        )
        self.bloc = Bloc.objects.create(
            line=ligne, position=1, position_in_column=0
        )

    def _poser(self, bouton):
        return self.client.put(
            f"{RACINE}/blocs/{self.bloc.id}/contenu/",
            data=json.dumps({"type": "BUTTON", "bouton": bouton}),
            content_type="application/json", **self.entetes(self.jeton),
        )

    def test_un_bouton_vers_un_test_existant_passe(self):
        reponse = self._poser({
            "libelle": "Commencer le test", "questionnaire": "artisan"
        })
        self.assertEqual(reponse.status_code, 200)
        self.bloc.refresh_from_db()
        self.assertEqual(self.bloc.content.content_button.test_slug, "artisan")

    def test_un_bouton_vers_un_test_inexistant_est_refuse(self):
        reponse = self._poser({
            "libelle": "Commencer le test", "questionnaire": "inexistant"
        })
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("artisan", reponse.json()["erreur"])
