# jeiko/agents/vues_questionnaires.py
"""
Les questionnaires experts — définir le test, ses profils, ses questions, ses poids.

Ce que c'est
------------
Un `ExpertTest` pose des questions ; chaque réponse porte des **poids** vers un
ou plusieurs **profils** ; à la fin, le profil le plus lourd gagne, et sa
**page de résultat** est affichée au visiteur. Un profil peut aussi être
attribué par un **score global** (`min_score` / `max_score`), et des
**combinaisons** arbitrent les cas où deux profils se disputent la première
place.

Autrement dit c'est le même mécanisme que les fiches de la boutique — une page
dessinée une fois, rendue avec les valeurs du moment — mais où le choix de la
page dépend d'un calcul au lieu d'une clé.

Pourquoi cette API existe
-------------------------
Construire un questionnaire à la main est long et ingrat : vingt questions,
quatre réponses chacune, cinq profils, et **quatre cents poids** à saisir un
par un dans un formulaire. C'est précisément le genre de travail qu'un agent
fait sans se tromper et sans se lasser — à condition qu'on lui donne la porte.

Ce qui est délibérément absent
------------------------------
**La suppression d'un test, d'une question ou d'un profil.** Un test supprimé
emporte ses questions, ses réponses, ses poids et **les passages déjà
enregistrés** — c'est-à-dire des données de visiteurs, parfois nominatives.
Même règle que les pages : un agent crée et corrige, il n'efface pas.

**Les passages et les prospects.** `ExpertTestData` et `Prospect` contiennent
des réponses de personnes identifiables. L'API de construction n'a aucune
raison de les lire, et une clé qui traîne ne doit pas pouvoir les exfiltrer.
Aucune route ne les expose.

**`is_restricted`** se règle, mais c'est un contrôle d'accès : voir le
commentaire à sa déclaration.

La règle d'écriture des listes
------------------------------
Envoyer « reponses » sur une question REMPLACE la liste entière, poids
compris. Comme partout ailleurs dans cette API : une liste ordonnée n'a pas de
clé stable sur laquelle fusionner, et rapprocher par position mettrait un poids
sur la mauvaise réponse — une erreur qui ne se voit qu'en passant le test.
"""

from django.db import transaction
from django.shortcuts import get_object_or_404
from django.utils.text import slugify

from jeiko.administration_pages.models import ImageContent, Page
from jeiko.questionnaires_expert.models import (
    ExpertAnswer, ExpertAnswerProfileWeight, ExpertProfileCombination,
    ExpertProfileCriterion, ExpertProfileType, ExpertQuestion, ExpertTest,
)

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR = "questionnaires_expert.view_experttest"
AJOUTER = "questionnaires_expert.add_experttest"
MODIFIER = "questionnaires_expert.change_experttest"

#: Types de question, lus sur le modèle pour qu'ils ne puissent pas dériver.
TYPES_DE_QUESTION = [
    code for code, _ in ExpertQuestion._meta.get_field("question_type").choices
]

#: Comparaisons acceptées par un critère de combinaison.
COMPARAISONS = [c for c, _ in ExpertProfileCriterion.COMPARISON_CHOICES]


# --------------------------------------------------------------------------- #
#  Sérialisation
# --------------------------------------------------------------------------- #
def _profil_en_dict(profil):
    return {
        "id": profil.id,
        "nom": profil.name,
        "slug": profil.slug,
        "description": profil.description or "",
        "page_de_resultat": profil.result_page_id,
        "complexe": profil.is_complex,
        "attribue_par_score": profil.is_score_profile,
        "score_min": profil.min_score,
        "score_max": profil.max_score,
    }


def _reponse_en_dict(reponse):
    """
    Une réponse et ses poids.

    ⚠️ `ExpertAnswerProfileWeight.profile_type` est **nullable** : un poids
    enregistré depuis l'administration sans choisir de profil existe en base,
    et il ne compte pour rien dans le calcul. Lire `p.profile_type.slug` sur
    lui levait une `AttributeError` — donc un **500 sur tout le
    questionnaire**, dont on ne pouvait alors plus rien corriger par l'API.
    C'est ce qui bloquait le questionnaire nº 6 d'accompagnementhumain.com.

    On ne l'expose donc plus dans `poids` — il n'y a pas de clé à lui donner —
    mais on le COMPTE. Le taire complètement laisserait un agent chercher
    pourquoi un questionnaire ne se comporte pas comme sa description : une
    donnée cassée qu'on masque est pire qu'une donnée cassée qu'on nomme.
    """
    poids = {}
    orphelins = 0
    for p in reponse.profile_weights.select_related("profile_type"):
        if p.profile_type_id is None:
            orphelins += 1
            continue
        poids[p.profile_type.slug or str(p.profile_type_id)] = p.weight

    document = {
        "id": reponse.id,
        "texte": reponse.text,
        "rang": reponse.order,
        "active": reponse.is_active,
        # Les poids sont la matière du calcul : les taire obligerait à un
        # second appel pour relire ce qu'on vient d'écrire.
        "poids": poids,
    }
    if orphelins:
        document["poids_sans_profil"] = orphelins
    return document


def _question_en_dict(question):
    return {
        "id": question.id,
        "texte": question.text,
        "rang": question.order,
        "type": question.question_type,
        "active": question.is_active,
        "reponses": [
            _reponse_en_dict(r)
            for r in question.answers.all().order_by("order", "id")
        ],
    }


def _combinaison_en_dict(combinaison):
    return {
        "id": combinaison.id,
        "slug": combinaison.slug,
        "titre": combinaison.title or "",
        "profil_parent": combinaison.parent_profile_id,
        "profil_prefere": combinaison.preferred_profile_id,
        "profil_alternatif": combinaison.alternative_profile_id,
        "criteres": [
            {
                "profil_a": c.profile_a_id,
                "profil_b": c.profile_b_id,
                "comparaison": c.comparison,
                "tolerance": c.tolerance,
            }
            for c in combinaison.criteria.all()
        ],
    }


def _test_en_resume(test):
    return {
        "id": test.id,
        "titre": test.title,
        "slug": test.slug,
        "description": test.description or "",
        "actif": test.is_active,
        "acces_restreint": test.is_restricted,
        "image_principale_id": test.main_image_id,
        "page_de_presentation": test.presentation_page_id,
    }


def _test_en_dict(test):
    document = _test_en_resume(test)
    document["profils"] = [
        _profil_en_dict(p) for p in test.profiles.all().order_by("id")
    ]
    document["questions"] = [
        _question_en_dict(q)
        for q in test.questions.prefetch_related(
            "answers__profile_weights__profile_type"
        ).order_by("order", "id")
    ]
    document["combinaisons"] = [
        _combinaison_en_dict(c)
        for c in test.combinations.prefetch_related("criteria")
    ]
    return document


# --------------------------------------------------------------------------- #
#  Aides
# --------------------------------------------------------------------------- #
def _page(identifiant, quoi):
    """Une page par son identifiant, ou None. Lève si elle n'existe pas."""
    if identifiant in (None, "", 0):
        return None
    page = Page.objects.filter(pk=identifiant).first()
    if page is None:
        raise CorpsInvalide(f"Aucune page nº {identifiant} pour « {quoi} ».")
    return page


def _refuser_si_deja_passe(test, quoi):
    """
    On ne supprime pas ce dont des résultats dépendent.

    Les passages sont enregistrés dans `ExpertTestData.data`, un document JSON
    qui cite les questions et les réponses par identifiant — sans clé
    étrangère, donc sans que la base s'y oppose. Supprimer une question déjà
    répondue ne casse rien visiblement : cela rend illisibles des résultats
    déjà rendus à des personnes, en silence, et sans retour possible.

    `active: false` fait le travail dans ce cas : la question disparaît des
    passages à venir et les anciens restent interprétables. C'est d'ailleurs le
    contournement qu'un agent avait trouvé seul sur le terrain, faute de
    pouvoir supprimer — il avait raison.
    """
    if test.datas.exists():
        raise CorpsInvalide(
            f"Ce questionnaire a déjà été passé : supprimer {quoi} rendrait "
            f"illisibles des résultats déjà rendus. Passer « active » à false "
            f"la retire des passages à venir sans toucher aux anciens."
        )


def _profil_du_test(test, designation, quoi):
    """
    Un profil du test, désigné par slug ou par identifiant.

    Borné au test : sans ce filtre, un poids pourrait viser le profil d'un
    AUTRE questionnaire. La base l'accepterait — les deux sont des
    `ExpertProfileType` — et le calcul deviendrait faux sans rien signaler.
    """
    if designation in (None, ""):
        return None

    texte = str(designation).strip()
    profil = test.profiles.filter(slug=texte).first()
    if profil is None and texte.isdigit():
        profil = test.profiles.filter(pk=int(texte)).first()
    if profil is None:
        connus = list(test.profiles.values_list("slug", flat=True))
        raise CorpsInvalide(
            f"Aucun profil « {designation} » dans ce questionnaire "
            f"(« {quoi} »). Profils : {', '.join(c for c in connus if c) or 'aucun'}."
        )
    return profil


def _refuser_les_cles(corps, connues, quoi):
    inconnues = sorted(set(corps) - set(connues))
    if inconnues:
        raise CorpsInvalide(
            f"Clé(s) inconnue(s) pour {quoi} : {', '.join(inconnues)}. "
            f"Acceptées : {', '.join(sorted(connues))}."
        )


# --------------------------------------------------------------------------- #
#  Questionnaires
# --------------------------------------------------------------------------- #
class ListeDesQuestionnaires(VueAgent):
    permission_requise = VOIR

    def get(self, request):
        tests = ExpertTest.objects.order_by("title")
        return ok({"questionnaires": [_test_en_resume(t) for t in tests]})


class CreationQuestionnaire(VueAgent):
    permission_requise = AJOUTER

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)
        _refuser_les_cles(
            corps,
            {"titre", "slug", "description", "actif", "acces_restreint",
             "image_principale_id", "page_de_presentation"},
            "un questionnaire",
        )

        titre = str(corps.get("titre") or "").strip()
        if not titre:
            raise CorpsInvalide("« titre » est obligatoire.")

        slug = slugify(str(corps.get("slug") or titre).strip())
        if not slug:
            raise CorpsInvalide("« slug » ne donne rien d'utilisable.")
        if ExpertTest.objects.filter(slug=slug).exists():
            raise CorpsInvalide(
                f"Le slug « {slug} » est déjà pris : il entre dans l'URL du test."
            )

        image = None
        if corps.get("image_principale_id"):
            image = ImageContent.objects.filter(
                pk=corps["image_principale_id"]
            ).first()
            if image is None:
                raise CorpsInvalide(
                    f"Aucune image nº {corps['image_principale_id']}. Voir /images/."
                )

        test = ExpertTest.objects.create(
            title=titre[:200],
            slug=slug,
            description=str(corps.get("description") or ""),
            # Comme une page ou une fiche : inactif à la création. Un
            # questionnaire à moitié construit, avec ses questions et sans ses
            # poids, donnerait des résultats faux à qui le passerait.
            is_active=False,
            is_restricted=bool(corps.get("acces_restreint", False)),
            main_image=image,
            presentation_page=_page(
                corps.get("page_de_presentation"), "page_de_presentation"
            ),
        )
        return ok({"questionnaire": _test_en_resume(test)}, statut=201)


class DetailQuestionnaire(VueAgent):
    """L'arbre complet d'un questionnaire, ou la modification de son entête."""

    permission_requise = VOIR

    def get(self, request, test_id):
        test = get_object_or_404(
            ExpertTest.objects.prefetch_related("profiles", "questions"), pk=test_id
        )
        return ok({"questionnaire": _test_en_dict(test)})

    @transaction.atomic
    def patch(self, request, test_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification de questionnaire non autorisée.", statut=403)

        test = get_object_or_404(ExpertTest, pk=test_id)
        corps = self.corps(request)
        _refuser_les_cles(
            corps,
            {"titre", "description", "actif", "acces_restreint",
             "image_principale_id", "page_de_presentation"},
            "un questionnaire",
        )

        modifies = []
        if "titre" in corps:
            test.title = str(corps["titre"]).strip()[:200]
            modifies.append("title")
        if "description" in corps:
            test.description = str(corps["description"])
            modifies.append("description")
        if "actif" in corps:
            test.is_active = bool(corps["actif"])
            modifies.append("is_active")
        if "acces_restreint" in corps:
            test.is_restricted = bool(corps["acces_restreint"])
            modifies.append("is_restricted")
        if "page_de_presentation" in corps:
            test.presentation_page = _page(
                corps["page_de_presentation"], "page_de_presentation"
            )
            modifies.append("presentation_page")
        if "image_principale_id" in corps:
            identifiant = corps["image_principale_id"]
            test.main_image = (
                ImageContent.objects.filter(pk=identifiant).first()
                if identifiant else None
            )
            modifies.append("main_image")

        if modifies:
            test.save(update_fields=modifies)
        return ok({"questionnaire": _test_en_resume(test), "modifie": modifies})


# --------------------------------------------------------------------------- #
#  Profils — les résultats possibles
# --------------------------------------------------------------------------- #
CLES_PROFIL = {
    "nom", "slug", "description", "page_de_resultat", "complexe",
    "attribue_par_score", "score_min", "score_max",
}


def _ecrire_le_profil(profil, corps, creation):
    if creation:
        nom = str(corps.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide("« nom » est obligatoire pour un profil.")
        profil.name = nom[:200]
        profil.slug = slugify(str(corps.get("slug") or nom).strip())
    else:
        if "nom" in corps:
            profil.name = str(corps["nom"]).strip()[:200]
        # Le slug ne se modifie PAS : il est dans l'URL de la page de résultat
        # (`/…/resultat/<slug>/`), donc dans des liens déjà partagés et dans
        # les e-mails déjà envoyés. Le changer les casserait sans un mot.

    if "description" in corps:
        profil.description = str(corps["description"])
    if "page_de_resultat" in corps:
        profil.result_page = _page(corps["page_de_resultat"], "page_de_resultat")
    if "complexe" in corps:
        profil.is_complex = bool(corps["complexe"])
    if "attribue_par_score" in corps:
        profil.is_score_profile = bool(corps["attribue_par_score"])

    for cle, champ in (("score_min", "min_score"), ("score_max", "max_score")):
        if cle in corps:
            valeur = corps[cle]
            if valeur in (None, ""):
                setattr(profil, champ, None)
                continue
            # `float("bas")` lève une ValueError, qui remontait jusqu'au 500 :
            # une faute de saisie devenait une panne serveur, et l'agent n'avait
            # pas le nom du champ fautif. Tout le reste de cette API refuse en
            # 400 en nommant ce qu'elle attend ; ce coin-là ne le faisait pas.
            try:
                setattr(profil, champ, float(valeur))
            except (TypeError, ValueError):
                raise CorpsInvalide(
                    f"« {cle} » attend un nombre — reçu {valeur!r}. "
                    f"Les bornes de score sont numériques : 0, 20, 12.5."
                )

    # Un intervalle inversé n'attribue jamais rien : le profil existerait sans
    # pouvoir sortir, et le test renverrait tout le monde ailleurs sans erreur.
    if (
        profil.is_score_profile
        and profil.min_score is not None
        and profil.max_score is not None
        and profil.min_score > profil.max_score
    ):
        raise CorpsInvalide(
            f"score_min ({profil.min_score}) dépasse score_max "
            f"({profil.max_score}) : aucun score ne pourrait attribuer ce profil."
        )


class ProfilsDuQuestionnaire(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def post(self, request, test_id):
        test = get_object_or_404(ExpertTest, pk=test_id)
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_PROFIL, "un profil")

        profil = ExpertProfileType(test=test)
        _ecrire_le_profil(profil, corps, creation=True)

        if test.profiles.filter(slug=profil.slug).exists():
            raise CorpsInvalide(
                f"Un profil « {profil.slug} » existe déjà dans ce questionnaire."
            )
        profil.save()
        return ok({"profil": _profil_en_dict(profil)}, statut=201)


class DetailProfil(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def patch(self, request, profil_id):
        profil = get_object_or_404(ExpertProfileType, pk=profil_id)
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_PROFIL - {"slug"}, "un profil")

        _ecrire_le_profil(profil, corps, creation=False)
        profil.save()
        return ok({"profil": _profil_en_dict(profil)})


# --------------------------------------------------------------------------- #
#  Questions, réponses et poids
# --------------------------------------------------------------------------- #
CLES_QUESTION = {"texte", "rang", "type", "active", "reponses"}
CLES_REPONSE = {"texte", "rang", "active", "poids"}


def _ecrire_les_reponses(question, reponses):
    """
    Remplace les réponses d'une question, poids compris.

    Tout est validé AVANT le premier effacement : une question à moitié
    réécrite, dont la troisième réponse a été refusée, laisserait le
    questionnaire dans un état qui fausse le calcul sans être visible.
    """
    if not isinstance(reponses, list):
        raise CorpsInvalide("« reponses » doit être une liste.")

    prepares = []
    for rang, brut in enumerate(reponses, 1):
        if not isinstance(brut, dict):
            raise CorpsInvalide(f"Réponse nº {rang} : un objet est attendu.")
        _refuser_les_cles(brut, CLES_REPONSE, f"la réponse nº {rang}")

        texte = str(brut.get("texte") or "").strip()
        if not texte:
            raise CorpsInvalide(f"Réponse nº {rang} : « texte » est obligatoire.")

        poids = brut.get("poids") or {}
        if not isinstance(poids, dict):
            raise CorpsInvalide(
                f"Réponse nº {rang} : « poids » est un objet "
                f"{{profil: valeur}}, pas une liste."
            )

        resolus = {}
        for designation, valeur in poids.items():
            profil = _profil_du_test(
                question.test, designation, f"le poids de la réponse nº {rang}"
            )
            try:
                resolus[profil] = float(valeur)
            except (TypeError, ValueError):
                raise CorpsInvalide(
                    f"Réponse nº {rang} : le poids vers « {designation} » "
                    f"doit être un nombre, pas « {valeur} »."
                )

        prepares.append({
            "text": texte[:300],
            "order": int(brut.get("rang", rang)),
            "is_active": bool(brut.get("active", True)),
            "poids": resolus,
        })

    question.answers.all().delete()
    for valeurs in prepares:
        poids = valeurs.pop("poids")
        reponse = ExpertAnswer.objects.create(question=question, **valeurs)
        for profil, valeur in poids.items():
            ExpertAnswerProfileWeight.objects.create(
                answer=reponse, profile_type=profil, weight=valeur
            )


class QuestionsDuQuestionnaire(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def post(self, request, test_id):
        test = get_object_or_404(ExpertTest, pk=test_id)
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_QUESTION, "une question")

        texte = str(corps.get("texte") or "").strip()
        if not texte:
            raise CorpsInvalide("« texte » est obligatoire pour une question.")

        type_question = str(corps.get("type") or "single").strip()
        if type_question not in TYPES_DE_QUESTION:
            raise CorpsInvalide(
                f"Type « {type_question} » inconnu. "
                f"Acceptés : {', '.join(TYPES_DE_QUESTION)}."
            )

        rang = corps.get("rang")
        if rang is None:
            dernier = test.questions.order_by("-order").first()
            rang = (dernier.order + 1) if dernier else 1

        question = ExpertQuestion.objects.create(
            test=test, text=texte, order=int(rang),
            question_type=type_question,
            is_active=bool(corps.get("active", True)),
        )
        if "reponses" in corps:
            _ecrire_les_reponses(question, corps["reponses"])

        question.refresh_from_db()
        return ok({"question": _question_en_dict(question)}, statut=201)


class DetailQuestion(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def patch(self, request, question_id):
        question = get_object_or_404(
            ExpertQuestion.objects.select_related("test"), pk=question_id
        )
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_QUESTION, "une question")

        modifies = []
        if "texte" in corps:
            question.text = str(corps["texte"])
            modifies.append("text")
        if "rang" in corps:
            question.order = int(corps["rang"])
            modifies.append("order")
        if "active" in corps:
            question.is_active = bool(corps["active"])
            modifies.append("is_active")
        if "type" in corps:
            if corps["type"] not in TYPES_DE_QUESTION:
                raise CorpsInvalide(
                    f"Type « {corps['type']} » inconnu. "
                    f"Acceptés : {', '.join(TYPES_DE_QUESTION)}."
                )
            question.question_type = corps["type"]
            modifies.append("question_type")

        if modifies:
            question.save(update_fields=modifies)
        if "reponses" in corps:
            _ecrire_les_reponses(question, corps["reponses"])
            modifies.append("reponses")

        question.refresh_from_db()
        return ok({"question": _question_en_dict(question), "modifie": modifies})

    @transaction.atomic
    def delete(self, request, question_id):
        question = get_object_or_404(
            ExpertQuestion.objects.select_related("test"), pk=question_id
        )
        _refuser_si_deja_passe(question.test, "cette question")
        question.delete()
        return ok({"supprime": question_id})


class DetailReponse(VueAgent):
    """
    Une réponse, et sa suppression.

    Elle était déjà supprimable en creux — `PATCH /questions/<id>/` avec
    « reponses » REMPLACE la liste, donc omettre une réponse l'efface. Mais
    supprimer une réponse sur trois obligeait alors à réécrire les deux autres
    et tous leurs poids, ce qui est exactement l'occasion de se tromper.
    """

    permission_requise = MODIFIER

    @transaction.atomic
    def delete(self, request, reponse_id):
        reponse = get_object_or_404(
            ExpertAnswer.objects.select_related("question__test"), pk=reponse_id
        )
        _refuser_si_deja_passe(reponse.question.test, "cette réponse")
        reponse.delete()
        return ok({"supprime": reponse_id})


# --------------------------------------------------------------------------- #
#  Combinaisons — l'arbitrage entre profils
# --------------------------------------------------------------------------- #
#
# Quand deux profils arrivent au coude à coude, le plus lourd ne dit pas
# toujours la bonne chose. Une combinaison décrit ce cas : « si A et B sont
# proches, alors montrer le profil préféré plutôt que le gagnant brut ».
#
# C'est la partie la plus délicate à saisir à la main — des triplets de profils
# et des comparaisons — et donc celle où une API rend le plus service.

CLES_COMBINAISON = {
    "slug", "titre", "profil_parent", "profil_prefere", "profil_alternatif",
    "criteres",
}
CLES_CRITERE = {"profil_a", "profil_b", "comparaison", "tolerance"}


class CombinaisonsDuQuestionnaire(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def post(self, request, test_id):
        test = get_object_or_404(ExpertTest, pk=test_id)
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_COMBINAISON, "une combinaison")

        titre = str(corps.get("titre") or "").strip()
        slug = slugify(str(corps.get("slug") or titre).strip())
        if not slug:
            raise CorpsInvalide(
                "« slug » (ou « titre », qui en tient lieu) est obligatoire."
            )
        if ExpertProfileCombination.objects.filter(slug=slug).exists():
            raise CorpsInvalide(f"La combinaison « {slug} » existe déjà.")

        # `parent_profile` est NOT NULL en base : l'omettre levait une
        # `NotNullViolation`, c'est-à-dire une 500. Une combinaison sans profil
        # parent n'aurait de toute façon aucun sens — c'est LUI qu'on arbitre.
        parent = _profil_du_test(test, corps.get("profil_parent"), "profil_parent")
        if parent is None:
            raise CorpsInvalide(
                "« profil_parent » est obligatoire : c'est le profil dont on "
                "arbitre le résultat. Les profils préféré et alternatif, eux, "
                "sont facultatifs."
            )

        combinaison = ExpertProfileCombination.objects.create(
            test=test,
            slug=slug,
            title=titre[:150],
            parent_profile=parent,
            preferred_profile=_profil_du_test(
                test, corps.get("profil_prefere"), "profil_prefere"
            ),
            alternative_profile=_profil_du_test(
                test, corps.get("profil_alternatif"), "profil_alternatif"
            ),
        )
        _ecrire_les_criteres(combinaison, corps.get("criteres") or [])

        return ok({"combinaison": _combinaison_en_dict(combinaison)}, statut=201)


def _ecrire_les_criteres(combinaison, criteres):
    """
    Remplace les critères d'une combinaison. Tout validé avant d'effacer.
    """
    if not isinstance(criteres, list):
        raise CorpsInvalide("« criteres » doit être une liste.")

    test = combinaison.test
    prepares = []
    for rang, brut in enumerate(criteres, 1):
        if not isinstance(brut, dict):
            raise CorpsInvalide(f"Critère nº {rang} : un objet est attendu.")
        _refuser_les_cles(brut, CLES_CRITERE, f"le critère nº {rang}")

        comparaison = str(brut.get("comparaison") or "").strip()
        if comparaison not in COMPARAISONS:
            raise CorpsInvalide(
                f"Critère nº {rang} : comparaison « {comparaison} » inconnue. "
                f"Acceptées : {', '.join(COMPARAISONS)}."
            )

        # « ~= » est la seule comparaison qui consomme la tolérance. L'exiger
        # ailleurs n'a pas de sens, mais l'oublier ici rend le critère
        # inopérant : proche à zéro près, c'est-à-dire égal.
        tolerance = brut.get("tolerance")
        if comparaison == "~=" and tolerance in (None, ""):
            raise CorpsInvalide(
                f"Critère nº {rang} : « ~= » (proche de) demande une "
                f"« tolerance ». Sans elle, le critère revient à « == »."
            )

        prepares.append({
            "profile_a": _profil_du_test(
                test, brut.get("profil_a"), f"le critère nº {rang}"
            ),
            "profile_b": _profil_du_test(
                test, brut.get("profil_b"), f"le critère nº {rang}"
            ),
            "comparison": comparaison,
            "tolerance": int(tolerance) if tolerance not in (None, "") else 0,
        })

    combinaison.criteria.all().delete()
    for valeurs in prepares:
        ExpertProfileCriterion.objects.create(combination=combinaison, **valeurs)


class DetailCombinaison(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def patch(self, request, combinaison_id):
        combinaison = get_object_or_404(
            ExpertProfileCombination.objects.select_related("test"),
            pk=combinaison_id,
        )
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_COMBINAISON - {"slug"}, "une combinaison")

        test = combinaison.test
        modifies = []
        if "titre" in corps:
            combinaison.title = str(corps["titre"]).strip()[:150]
            modifies.append("title")
        for cle, champ in (
            ("profil_parent", "parent_profile"),
            ("profil_prefere", "preferred_profile"),
            ("profil_alternatif", "alternative_profile"),
        ):
            if cle in corps:
                profil = _profil_du_test(test, corps[cle], cle)
                if profil is None and champ == "parent_profile":
                    raise CorpsInvalide(
                        "« profil_parent » ne peut pas être retiré : c'est le "
                        "profil dont on arbitre le résultat."
                    )
                setattr(combinaison, champ, profil)
                modifies.append(champ)

        if modifies:
            combinaison.save(update_fields=modifies)
        if "criteres" in corps:
            _ecrire_les_criteres(combinaison, corps["criteres"])
            modifies.append("criteres")

        return ok({
            "combinaison": _combinaison_en_dict(combinaison), "modifie": modifies
        })
