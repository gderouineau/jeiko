# jeiko/agents/vues_identite.py
"""
L'identité visuelle du site — les couleurs et les polices, en un seul endroit.

Ce que ça recouvre
------------------
**Le thème** : dix couleurs nommées par leur RÔLE, pas par leur teinte —
`accent`, `accent_survol`, `sur_accent`, `secondaire`, `tertiaire`, `texte`,
`texte_attenue`, `fond`, `fond_attenue`, `bordure`. Elles sortent en variables
CSS (`--jk-accent`…) posées sur `:root`, et tout ce qui s'y réfère change
ensemble. Changer l'accent ici repeint les boutons, les bordures des offres
mises en avant, les pastilles — partout où le produit l'utilise.

**Les polices** : onze rôles (`text`, `h1` à `h4`, `links`, `menu`…) déclinés
sur **trois appareils** (téléphone, tablette, ordinateur). Chaque rôle porte
dix attributs : famille, taille, graisse, interlignage, couleur… Cela fait
330 valeurs, et c'est précisément le genre de saisie qu'on ne fait pas deux
fois à la main.

Pourquoi c'est une API à part
------------------------------
Ce n'est pas du contenu : c'est ce qui décide de quoi TOUT le contenu a l'air.
Une erreur ici ne casse pas une page, elle les casse toutes en même temps —
d'où un rôle distinct, qu'on donne à un agent chargé du design et à personne
d'autre.

Ce qui est refusé
-----------------
**Créer ou supprimer un site.** `WebSite` est un singleton de configuration :
il existe, on le modifie. En créer un second n'aurait pas de sens, et le
supprimer emporterait polices et thème.

**Les couleurs ne sont pas validées comme des couleurs.** Elles traversent
`clean_css_value` (le même assainissement que le CSS personnalisé des blocs),
qui retire ce qui pourrait s'échapper de la déclaration. Une valeur inventée
donnera une couleur inopérante, pas une injection.
"""

from django.db import transaction

from jeiko.administration.models import Font, Fonts, Theme, WebSite
from jeiko.templatetags.css_extras import clean_css_value

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR = "administration.view_website"
MODIFIER = "administration.change_website"

#: Les dix rôles de couleur, lus sur le modèle : la liste ne peut pas dériver
#: de celle qu'applique `as_css_variables`.
COULEURS = [champ for champ, _ in Theme.VARIABLES]

#: Les attributs d'un rôle de police.
ATTRIBUTS_DE_POLICE = {
    "famille": "family",
    "secours": "fallback",
    "taille": "size",
    "graisse": "weight",
    "style": "style",
    "variante": "variant",
    "etirement": "stretch",
    "couleur": "color",
    "interlignage": "line_height",
    "url_google_fonts": "google_fonts_url",
}

#: Les rôles de police, lus sur le modèle `Fonts`.
ROLES_DE_POLICE = [
    champ.name for champ in Fonts._meta.get_fields()
    if champ.one_to_one and champ.concrete
]

#: Les trois jeux de polices d'un site, et leur nom côté API.
APPAREILS = {
    "telephone": "fonts_phone",
    "tablette": "fonts_tablet",
    "ordinateur": "fonts_computer",
}


def _site():
    """
    Le site, ou une erreur explicite.

    `WebSite` est créé à l'installation. Son absence signifie une base montée
    autrement, et la deviner produirait une configuration fantôme que personne
    ne verrait s'appliquer.
    """
    site = WebSite.objects.select_related(
        "theme", "fonts_phone", "fonts_tablet", "fonts_computer"
    ).first()
    if site is None:
        raise CorpsInvalide(
            "Aucun site configuré : `WebSite` est créé à l'installation. "
            "Rien à modifier tant qu'il n'existe pas."
        )
    return site


def _police_en_dict(police):
    if police is None:
        return None
    return {
        cle: getattr(police, champ) for cle, champ in ATTRIBUTS_DE_POLICE.items()
    }


def _jeu_en_dict(jeu):
    if jeu is None:
        return None
    return {role: _police_en_dict(getattr(jeu, role, None)) for role in ROLES_DE_POLICE}


def _identite_en_dict(site):
    theme = site.theme
    return {
        "nom_du_site": site.name,
        "couleurs": (
            {champ: getattr(theme, champ) for champ in COULEURS}
            if theme else None
        ),
        "variables_css": (
            {variable: getattr(theme, champ) for champ, variable in Theme.VARIABLES}
            if theme else None
        ),
        "polices": {
            appareil: _jeu_en_dict(getattr(site, champ))
            for appareil, champ in APPAREILS.items()
        },
    }


class Identite(VueAgent):
    """
    Lit ou modifie l'identité visuelle : couleurs du thème, polices.

    La modification est PARTIELLE partout : envoyer la seule couleur d'accent
    ne touche pas aux neuf autres, et régler la taille du `h1` sur téléphone
    ne touche ni à sa famille, ni au `h1` des autres appareils. C'est la règle
    de toute cette API, et elle compte doublement ici : une écriture totale
    obligerait à renvoyer 330 valeurs pour en changer une, et la première
    oubliée repartirait à sa valeur par défaut.
    """

    permission_requise = VOIR

    def get(self, request):
        return ok({"identite": _identite_en_dict(_site())})

    @transaction.atomic
    def patch(self, request):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification de l'identité non autorisée.", statut=403)

        site = _site()
        corps = self.corps(request)
        inconnues = sorted(set(corps) - {"nom_du_site", "couleurs", "polices"})
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Acceptées : nom_du_site, couleurs, polices."
            )

        modifies = []

        if "nom_du_site" in corps:
            site.name = str(corps["nom_du_site"]).strip()[:200]
            site.save(update_fields=["name"])
            modifies.append("nom_du_site")

        if "couleurs" in corps:
            modifies += _ecrire_les_couleurs(site, corps["couleurs"])

        if "polices" in corps:
            modifies += _ecrire_les_polices(site, corps["polices"])

        site.refresh_from_db()
        document = {"identite": _identite_en_dict(_site()), "modifie": modifies}

        remarque = _remarque_sur_le_menu(modifies)
        if remarque:
            document["remarque"] = remarque
        return ok(document)


def _remarque_sur_le_menu(modifies):
    """
    Le rôle « menu » ne fait pas tout ce qu'il a l'air de faire.

    La FAMILLE de police du menu vient bien d'ici. Sa TAILLE et sa COULEUR,
    non : elles sortent du style de menu (`MenuStyle`), qui pose des variables
    CSS sur `nav.top-menu[data-menu-id="…"]` — spécificité (0,2,2) contre
    (0,1,1) pour les règles de police. Le style de menu gagne, toujours.

    Le style de menu n'est **pas** ouvert à l'API, et c'est un choix de
    l'exploitant : un style se partage entre plusieurs menus, le changer depuis
    une clé d'édition repeindrait des menus qu'on ne visait pas.

    Résultat pour un agent qui règle la police du menu : la famille change, la
    taille et la couleur ne bougent pas, et rien ne le lui dit. Un état
    incohérent qu'on ne s'explique pas vaut, à l'usage, un défaut. D'où cette
    remarque — elle ne change rien à ce qui a été écrit, elle dit ce qui n'a
    pas pu l'être.
    """
    if not any(champ.endswith(".menu") or champ == "menu" for champ in modifies):
        return ""
    return (
        "La famille de police du menu est bien appliquée, mais sa TAILLE et sa "
        "COULEUR viennent du style de menu, qui l'emporte en spécificité CSS et "
        "n'est pas ouvert à l'API — c'est un choix de l'exploitant, un style "
        "étant partagé entre plusieurs menus. Demandez-lui de les régler dans "
        "Administration → Menus → style, sinon le menu gardera l'ancienne "
        "taille avec la nouvelle police."
    )


def _ecrire_les_couleurs(site, couleurs):
    if not isinstance(couleurs, dict):
        raise CorpsInvalide("« couleurs » doit être un objet {role: valeur}.")

    inconnues = sorted(set(couleurs) - set(COULEURS))
    if inconnues:
        raise CorpsInvalide(
            f"Rôle(s) de couleur inconnu(s) : {', '.join(inconnues)}. "
            f"Les couleurs se nomment par leur RÔLE, pas par leur teinte : "
            f"{', '.join(COULEURS)}."
        )

    theme = site.theme
    if theme is None:
        theme = Theme.objects.create()
        site.theme = theme
        site.save(update_fields=["theme"])

    modifies = []
    for champ, valeur in couleurs.items():
        # `clean_css_value` est le même assainissement que le CSS personnalisé
        # des blocs : la valeur finit dans une déclaration `--jk-x: …;` sur
        # `:root`, et un point-virgule y ouvrirait une déclaration de plus.
        setattr(theme, champ, clean_css_value(str(valeur)))
        modifies.append(f"couleur:{champ}")

    if modifies:
        theme.save()
    return modifies


def _ecrire_les_polices(site, polices):
    if not isinstance(polices, dict):
        raise CorpsInvalide(
            "« polices » doit être un objet {appareil: {role: {attribut: valeur}}}."
        )

    inconnus = sorted(set(polices) - set(APPAREILS))
    if inconnus:
        raise CorpsInvalide(
            f"Appareil(s) inconnu(s) : {', '.join(inconnus)}. "
            f"Attendus : {', '.join(APPAREILS)}."
        )

    modifies = []
    for appareil, roles in polices.items():
        if not isinstance(roles, dict):
            raise CorpsInvalide(f"« polices.{appareil} » doit être un objet.")

        jeu = getattr(site, APPAREILS[appareil])
        if jeu is None:
            raise CorpsInvalide(
                f"Le site n'a pas de jeu de polices pour « {appareil} ». "
                f"Il est créé à l'installation ; l'API ne l'invente pas."
            )

        inconnus_roles = sorted(set(roles) - set(ROLES_DE_POLICE))
        if inconnus_roles:
            raise CorpsInvalide(
                f"Rôle(s) de police inconnu(s) pour « {appareil} » : "
                f"{', '.join(inconnus_roles)}. "
                f"Attendus : {', '.join(sorted(ROLES_DE_POLICE))}."
            )

        for role, attributs in roles.items():
            if not isinstance(attributs, dict):
                raise CorpsInvalide(
                    f"« polices.{appareil}.{role} » doit être un objet "
                    f"{{attribut: valeur}}."
                )

            inconnus_attributs = sorted(set(attributs) - set(ATTRIBUTS_DE_POLICE))
            if inconnus_attributs:
                raise CorpsInvalide(
                    f"Attribut(s) inconnu(s) pour « {appareil}.{role} » : "
                    f"{', '.join(inconnus_attributs)}. "
                    f"Attendus : {', '.join(sorted(ATTRIBUTS_DE_POLICE))}."
                )

            police = getattr(jeu, role, None)
            if police is None:
                police = Font.objects.create()
                setattr(jeu, role, police)
                jeu.save(update_fields=[role])

            champs = []
            for cle, valeur in attributs.items():
                champ = ATTRIBUTS_DE_POLICE[cle]
                # Même raison que pour les couleurs : ces valeurs finissent
                # dans des déclarations CSS générées.
                setattr(police, champ, clean_css_value(str(valeur)))
                champs.append(champ)

            if champs:
                police.save(update_fields=champs)
                modifies.append(f"{appareil}.{role}")

    return modifies
