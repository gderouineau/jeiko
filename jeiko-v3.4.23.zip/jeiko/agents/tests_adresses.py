# jeiko/agents/tests_adresses.py
"""
Ce qui doit être unique, c'est l'ADRESSE — pas le nom, pas le slug.

Le besoin
---------
« Actualités » sous « Formations » et « Actualités » sous « Coaching » sont
deux rubriques légitimes : elles donnent /formations/actualites/ et
/coaching/actualites/, que rien ne confond. L'API refusait pourtant le second
slug, ce qui obligeait à inventer « actualites-2 » — un défaut visible par le
visiteur, dans l'adresse publique, pour protéger une contrainte qui n'avait pas
lieu d'être.

La contrepartie, et c'est elle qui est piégeuse
------------------------------------------------
Cette souplesse ne tient qu'aussi longtemps que le segment parent est là.
**Décocher « afficher dans l'URL » sur une catégorie remonte toutes ses pages
d'un cran**, jusqu'à la racine du site s'il s'agit de la catégorie principale.
Les deux /…/tarifs/ deviennent /tarifs/ : une seule page répond, l'autre
devient inatteignable. Aucune erreur, aucun écran — la contrainte de base
`uniq_url_tag_when_no_category` ne couvre que les pages SANS catégorie, pas
celles dont la catégorie est masquée.

Le même raisonnement vaut pour la création d'une page : comparer
(url_tag, catégorie, sous-catégorie) croyait distinctes deux pages rangées
dans deux catégories masquées, qui tombent en réalité à la même adresse.

Ce que ces tests gardent
------------------------
* le slug se répète tant que le chemin le distingue ;
* il est refusé quand plus rien ne le distingue ;
* un slug ambigu ne se résout plus « au premier venu » ;
* et aucun changement n'est accepté s'il fait tomber deux pages à la même
  adresse — c'est la seule question qui compte.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Category, Page
from jeiko.administration_pages import adresses

from .tests import SocleMixin, donner_le_role

CREER_CATEGORIE = "/api/agent/v1/categories/creer/"


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class SocleAdresses(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(self.agent.user, "view_page", "add_page", "change_page")

    def _creer_categorie(self, **corps):
        return self.json_post(CREER_CATEGORIE, corps, self.jeton)

    def _patch_categorie(self, categorie, corps):
        return self.client.patch(
            f"/api/agent/v1/categories/{categorie.id}/",
            data=json.dumps(corps), content_type="application/json",
            **self.entetes(self.jeton),
        )

    def _creer_page(self, **corps):
        return self.json_post("/api/agent/v1/pages/creer/", corps, self.jeton)


class SlugRepeteTests(SocleAdresses):
    def test_deux_sous_categories_de_meme_slug_sous_deux_parentes(self):
        self.assertEqual(
            self._creer_categorie(nom="Formations", slug="formations").status_code, 201
        )
        self.assertEqual(
            self._creer_categorie(nom="Coaching", slug="coaching").status_code, 201
        )

        premiere = self._creer_categorie(
            nom="Actualités", slug="actualites", categorie_parente="formations"
        )
        seconde = self._creer_categorie(
            nom="Actualités", slug="actualites", categorie_parente="coaching"
        )
        self.assertEqual(premiere.status_code, 201)
        self.assertEqual(
            seconde.status_code, 201,
            "Deux chemins distincts : /formations/actualites/ et "
            "/coaching/actualites/. Rien ne justifie de refuser.",
        )

    def test_le_meme_chemin_reste_refuse(self):
        self._creer_categorie(nom="Formations", slug="formations")
        premiere = self._creer_categorie(
            nom="Actualités", slug="actualites", categorie_parente="formations"
        )
        self.assertEqual(premiere.status_code, 201)

        doublon = self._creer_categorie(
            nom="Actus", slug="actualites", categorie_parente="formations"
        )
        self.assertEqual(doublon.status_code, 400)
        self.assertIn("/formations/actualites/", json.loads(doublon.content)["erreur"])

    def test_deux_categories_invisibles_de_meme_slug_sont_refusees(self):
        """Sans chemin, plus rien ne les sépare — ni pour l'URL, ni pour l'API."""
        self.assertEqual(
            self._creer_categorie(
                nom="Regroupement", slug="groupe", afficher_dans_l_url=False
            ).status_code, 201
        )
        second = self._creer_categorie(
            nom="Autre regroupement", slug="groupe", afficher_dans_l_url=False
        )
        self.assertEqual(second.status_code, 400)
        self.assertIn("invisibles", json.loads(second.content)["erreur"])


class DesignationAmbigueTests(SocleAdresses):
    def test_un_slug_porte_par_deux_categories_ne_se_devine_pas(self):
        """
        `.first()` classait la page dans une catégorie tirée au hasard, et la
        réponse annonçait le succès. C'est le pire des cas : faux, et muet.
        """
        for parente in ("formations", "coaching"):
            self._creer_categorie(nom=parente.title(), slug=parente)
            self._creer_categorie(
                nom="Actualités", slug="actualites", categorie_parente=parente
            )

        page = Page.objects.create(title="Une page", url_tag="une-page")
        reponse = self.client.patch(
            f"/api/agent/v1/pages/{page.id}/",
            data=json.dumps({"sous_categorie": "actualites"}),
            content_type="application/json",
            **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 400)
        erreur = json.loads(reponse.content)["erreur"]
        self.assertIn("Plusieurs catégories", erreur)
        self.assertIn("identifiant", erreur)

        page.refresh_from_db()
        self.assertIsNone(page.sub_category_id)


class RetirerUneCategorieDesUrlTests(SocleAdresses):
    def setUp(self):
        super().setUp()
        self.formations = Category.objects.create(
            name="Formations", slug="formations", show_cat_in_url=True
        )
        self.coaching = Category.objects.create(
            name="Coaching", slug="coaching", show_cat_in_url=True
        )
        Page.objects.create(
            title="Tarifs des formations", url_tag="tarifs", category=self.formations
        )
        # Celle-ci vit déjà à la racine : c'est l'adresse que les pages de
        # « Formations » viendraient réclamer si la catégorie se retirait.
        self.racine = Page.objects.create(title="Tarifs du site", url_tag="tarifs")

    def test_le_retrait_qui_ferait_collision_est_refuse(self):
        reponse = self._patch_categorie(
            self.formations, {"afficher_dans_l_url": False}
        )
        self.assertEqual(reponse.status_code, 400, reponse.content[:300])
        erreur = json.loads(reponse.content)["erreur"]
        self.assertIn("/tarifs/", erreur)
        self.assertIn("Tarifs du site", erreur)

        self.formations.refresh_from_db()
        self.assertTrue(
            self.formations.show_cat_in_url,
            "Le drapeau ne doit pas avoir bougé : le refus doit être total.",
        )

    def test_deux_categories_masquees_qui_se_rejoindraient(self):
        """Le cas sans page à la racine : deux catégories qui convergent."""
        self.racine.delete()
        Page.objects.create(
            title="Tarifs du coaching", url_tag="tarifs", category=self.coaching
        )
        self._patch_categorie(self.coaching, {"afficher_dans_l_url": False})

        reponse = self._patch_categorie(
            self.formations, {"afficher_dans_l_url": False}
        )
        self.assertEqual(reponse.status_code, 400, reponse.content[:300])
        self.assertIn("Tarifs du coaching", json.loads(reponse.content)["erreur"])

    def test_le_retrait_sans_collision_passe(self):
        self.racine.delete()
        reponse = self._patch_categorie(
            self.formations, {"afficher_dans_l_url": False}
        )
        self.assertEqual(reponse.status_code, 200, reponse.content[:300])
        self.formations.refresh_from_db()
        self.assertFalse(self.formations.show_cat_in_url)


class AdresseDePageTests(SocleAdresses):
    def test_deux_pages_de_meme_tag_dans_deux_categories_visibles(self):
        for slug in ("formations", "coaching"):
            Category.objects.create(name=slug.title(), slug=slug, show_cat_in_url=True)

        premiere = self._creer_page(titre="Tarifs", categorie="formations")
        seconde = self._creer_page(titre="Tarifs", categorie="coaching")
        self.assertEqual(premiere.status_code, 201)
        self.assertEqual(
            seconde.status_code, 201,
            "/formations/tarifs/ et /coaching/tarifs/ sont deux adresses.",
        )

    def test_deux_categories_masquees_font_bien_une_collision(self):
        """
        Le triplet (url_tag, catégorie, sous-catégorie) les croyait distinctes.
        Elles tombent pourtant toutes deux en /tarifs/.
        """
        for slug in ("formations", "coaching"):
            Category.objects.create(name=slug.title(), slug=slug, show_cat_in_url=False)

        self.assertEqual(
            self._creer_page(titre="Tarifs", categorie="formations").status_code, 201
        )
        seconde = self._creer_page(titre="Tarifs", categorie="coaching")
        self.assertEqual(seconde.status_code, 409)
        self.assertIn("/tarifs/", json.loads(seconde.content)["erreur"])


class FonctionsDAdresseTests(TestCase):
    """La primitive, testée pour elle-même : c'est elle qu'on réutilisera."""

    def test_l_adresse_prevue_suit_la_visibilite(self):
        visible = Category.objects.create(
            name="Formations", slug="formations", show_cat_in_url=True
        )
        masquee = Category.objects.create(
            name="Interne", slug="interne", show_cat_in_url=False
        )
        self.assertEqual(
            adresses.adresse_prevue(url_tag="tarifs", categorie=visible),
            "/formations/tarifs/",
        )
        self.assertEqual(
            adresses.adresse_prevue(url_tag="tarifs", categorie=masquee), "/tarifs/"
        )

    def test_page_a_cette_adresse_trouve_et_ignore_la_page_exclue(self):
        page = Page.objects.create(title="Tarifs", url_tag="tarifs")
        self.assertEqual(adresses.page_a_cette_adresse("/tarifs/"), page)
        self.assertIsNone(
            adresses.page_a_cette_adresse("/tarifs/", sauf_page_id=page.id)
        )
        self.assertIsNone(adresses.page_a_cette_adresse("/inconnue/"))


class NomEnDoubleTests(SocleAdresses):
    """
    Le nom reste unique au même niveau : deux « Actualités » sous la même
    parente ne se distingueraient pas dans les écrans de l'administration.
    Cette règle est portée par la base — la vue doit la dire, pas la laisser
    remonter en 500.
    """

    def test_deux_fois_le_meme_nom_au_meme_niveau(self):
        premier = self._creer_categorie(nom="Actualités", slug="actualites")
        self.assertEqual(premier.status_code, 201)

        second = self._creer_categorie(nom="Actualités", slug="actus")
        self.assertEqual(
            second.status_code, 400,
            "Une contrainte de base ne doit jamais remonter en 500.",
        )
        self.assertIn("Actualités", json.loads(second.content)["erreur"])
