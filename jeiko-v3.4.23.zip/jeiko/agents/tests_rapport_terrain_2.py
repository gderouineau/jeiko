# jeiko/agents/tests_rapport_terrain_2.py
"""
Deux 500 remontés du terrain, et ce qui les rendait invisibles.

D'où ils viennent
-----------------
Rapport d'un agent qui refondait accompagnementhumain.com, les 6 et 7 septembre
2026. Les deux défauts ont la même forme : une donnée que le modèle autorise,
et un code de lecture qui ne l'avait pas prévue.

**1. `GET /questionnaires/6/` rendait 500, et lui seul.** Sept autres
questionnaires se lisaient normalement. `ExpertAnswerProfileWeight.profile_type`
est nullable — un poids enregistré depuis l'administration sans choisir de
profil est une ligne valide — et la sérialisation lisait `p.profile_type.slug`
sans regarder. Conséquence disproportionnée : une ligne inutile en base rendait
**tout le questionnaire illisible par l'API**, donc incorrigible, alors que le
test était actif en production.

**2. Un score non numérique rendait 500 au lieu de 400.** `float("bas")` lève
une `ValueError` qui n'était pas attrapée. Le reste de cette API refuse
proprement en nommant le champ ; ce coin-là faisait exception, et l'agent
recevait une page HTML d'erreur sans savoir quoi corriger.

Ce que ces tests gardent
------------------------
* un poids orphelin ne casse plus la lecture — et il est COMPTÉ, pas masqué ;
* une valeur non numérique donne un 400 qui nomme le champ.
"""

import json

from django.test import TestCase, override_settings

from jeiko.questionnaires_expert.models import (
    ExpertAnswer, ExpertAnswerProfileWeight, ExpertProfileType, ExpertQuestion,
    ExpertTest,
)

from .tests import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class PoidsSansProfilTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_experttest", "change_experttest",
            app="questionnaires_expert",
        )
        self.test = ExpertTest.objects.create(
            title="Intelligence émotionnelle", slug="intelligence-emotionnelle"
        )
        self.profil = ExpertProfileType.objects.create(
            test=self.test, name="Empathique", slug="empathique"
        )
        question = ExpertQuestion.objects.create(test=self.test, text="Une question ?")
        self.reponse = ExpertAnswer.objects.create(question=question, text="Oui")
        ExpertAnswerProfileWeight.objects.create(
            answer=self.reponse, profile_type=self.profil, weight=2.0
        )
        # La ligne fautive : le modèle l'autorise, l'administration la produit.
        ExpertAnswerProfileWeight.objects.create(
            answer=self.reponse, profile_type=None, weight=1.0
        )

    def _lire(self):
        return self.client.get(
            f"/api/agent/v1/questionnaires/{self.test.id}/",
            **self.entetes(self.jeton),
        )

    def test_le_questionnaire_se_lit_malgre_un_poids_orphelin(self):
        reponse = self._lire()
        self.assertEqual(
            reponse.status_code, 200,
            "Une ligne sans profil rendait tout le questionnaire illisible.",
        )

    def test_les_poids_valides_sont_intacts(self):
        document = json.loads(self._lire().content)
        poids = document["questionnaire"]["questions"][0]["reponses"][0]["poids"]
        self.assertEqual(poids, {"empathique": 2.0})

    def test_l_orphelin_est_compte_et_non_masque(self):
        """
        Le masquer ferait chercher longtemps pourquoi le test ne se comporte
        pas comme sa description. On le nomme, l'exploitant peut le nettoyer.
        """
        document = json.loads(self._lire().content)
        premiere = document["questionnaire"]["questions"][0]["reponses"][0]
        self.assertEqual(premiere["poids_sans_profil"], 1)

    def test_rien_n_est_annonce_quand_tout_est_sain(self):
        ExpertAnswerProfileWeight.objects.filter(profile_type__isnull=True).delete()
        document = json.loads(self._lire().content)
        premiere = document["questionnaire"]["questions"][0]["reponses"][0]
        self.assertNotIn("poids_sans_profil", premiere)


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class ScoreNonNumeriqueTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_experttest", "change_experttest",
            app="questionnaires_expert",
        )
        self.test = ExpertTest.objects.create(title="Sonde", slug="sonde")

    def _creer_profil(self, corps):
        return self.json_post(
            f"/api/agent/v1/questionnaires/{self.test.id}/profils/",
            corps, self.jeton,
        )

    def test_un_score_en_lettres_donne_400_et_nomme_le_champ(self):
        reponse = self._creer_profil({
            "nom": "Sonde erreur",
            "attribue_par_score": True,
            "score_min": "bas",
        })
        self.assertEqual(reponse.status_code, 400)
        erreur = json.loads(reponse.content)["erreur"]
        self.assertIn("score_min", erreur)
        self.assertIn("nombre", erreur)

    def test_un_score_bien_type_passe_toujours(self):
        reponse = self._creer_profil({
            "nom": "Sonde correcte",
            "attribue_par_score": True,
            "score_min": 0,
            "score_max": 20,
        })
        self.assertEqual(reponse.status_code, 201, reponse.content[:300])
