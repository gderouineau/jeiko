# jeiko/agents/tests_suppressions_questionnaire.py
"""
Supprimer une question ou une réponse — et jamais un questionnaire.

Pourquoi cette asymétrie
------------------------
L'API créait des questions sans pouvoir en retirer aucune : un questionnaire
monté pour essayer le moteur restait en base, et il fallait ouvrir
l'administration pour le nettoyer. Une API qui crée sans défaire oblige à
finir à la main ce qu'elle a commencé toute seule.

Le questionnaire, lui, n'est pas supprimable, et c'est délibéré — même règle
que pour les pages : ce qui emporte des résultats déjà rendus à des personnes
ne se supprime pas depuis un jeton. L'absence de route est la barrière.

Ce que ces tests gardent
------------------------
* les deux suppressions marchent, et ne débordent pas ;
* elles sont refusées dès que le test a été passé — un résultat déjà rendu
  cite ses questions par identifiant, sans clé étrangère : rien ne casserait
  visiblement, on rendrait simplement illisible ce qui a déjà été montré ;
* le questionnaire n'a toujours aucune route de suppression.
"""

import json

from django.test import TestCase, override_settings

from jeiko.questionnaires_expert.models import (
    ExpertAnswer, ExpertQuestion, ExpertTest, ExpertTestData,
)

from .tests import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class SuppressionsTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_experttest", "change_experttest",
            app="questionnaires_expert",
        )
        self.test = ExpertTest.objects.create(title="Sonde", slug="sonde-suppr")
        self.question = ExpertQuestion.objects.create(
            test=self.test, text="Une question ?"
        )
        self.reponse = ExpertAnswer.objects.create(
            question=self.question, text="Oui"
        )
        ExpertAnswer.objects.create(question=self.question, text="Non")

    def _supprimer(self, chemin):
        return self.client.delete(chemin, **self.entetes(self.jeton))

    def test_supprimer_une_question(self):
        reponse = self._supprimer(f"/api/agent/v1/questions/{self.question.id}/")
        self.assertEqual(reponse.status_code, 200, reponse.content[:300])
        self.assertFalse(ExpertQuestion.objects.filter(pk=self.question.id).exists())

    def test_supprimer_une_reponse_laisse_les_autres(self):
        reponse = self._supprimer(f"/api/agent/v1/reponses/{self.reponse.id}/")
        self.assertEqual(reponse.status_code, 200, reponse.content[:300])
        self.assertFalse(ExpertAnswer.objects.filter(pk=self.reponse.id).exists())
        self.assertEqual(self.question.answers.count(), 1)

    def test_un_test_deja_passe_refuse_la_suppression(self):
        ExpertTestData.objects.create(test=self.test, data={"reponses": []})

        reponse = self._supprimer(f"/api/agent/v1/questions/{self.question.id}/")
        self.assertEqual(reponse.status_code, 400)
        erreur = json.loads(reponse.content)["erreur"]
        self.assertIn("active", erreur)
        self.assertTrue(ExpertQuestion.objects.filter(pk=self.question.id).exists())

    def test_le_refus_vaut_aussi_pour_une_reponse(self):
        ExpertTestData.objects.create(test=self.test, data={"reponses": []})
        self.assertEqual(
            self._supprimer(f"/api/agent/v1/reponses/{self.reponse.id}/").status_code,
            400,
        )

    def test_aucune_suppression_de_questionnaire(self):
        """
        L'absence est la barrière : une méthode oubliée sur la vue serait un
        trou, et il ne se verrait qu'une fois un test effacé.
        """
        from jeiko.agents.vues_questionnaires import DetailQuestionnaire

        self.assertFalse(hasattr(DetailQuestionnaire, "delete"))
        self.assertEqual(
            self._supprimer(f"/api/agent/v1/questionnaires/{self.test.id}/").status_code,
            405,
        )
