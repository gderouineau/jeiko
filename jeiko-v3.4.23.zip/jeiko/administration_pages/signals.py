# signals.py
import logging
import os
import threading
from concurrent.futures import ThreadPoolExecutor
from threading import Lock

logger = logging.getLogger(__name__)

from django.conf import settings
from django.core.files.storage import default_storage
from django.db import transaction
from django.db.models import Q
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

from .models import (
    Animation, BackgroundImageParameters, Border, CustomCSS, ImageContent,
    Page, Section, Line, Bloc, Content,
    PageInsights, Size, StyleBox,
)
from .page_cache import bump_page_body_version

from typing import Optional, Tuple




# --------------------------
# GESTION DES IMAGES
# --------------------------


# Petit pool (léger)
_EXECUTOR = ThreadPoolExecutor(max_workers=2)

# === Guard anti-boucle ===
_IN_FLIGHT = set()
_IN_FLIGHT_LOCK = Lock()

def _mark_in_flight(pk: int) -> bool:
    """Retourne True si on vient d'ajouter pk (donc pas encore en cours).
       Retourne False si déjà en cours (donc ne pas relancer)."""
    with _IN_FLIGHT_LOCK:
        if pk in _IN_FLIGHT:
            return False
        _IN_FLIGHT.add(pk)
        return True

def _unmark_in_flight(pk: int) -> None:
    with _IN_FLIGHT_LOCK:
        _IN_FLIGHT.discard(pk)

def _file_exists(fieldfile) -> bool:
    try:
        name = getattr(fieldfile, "name", "")
        return bool(name) and default_storage.exists(name)
    except Exception:
        return False

def _needs_generation(instance: ImageContent) -> bool:
    """
    True s'il manque au moins une variante (fichier absent),
    ou si son nom ne correspond pas à la base actuelle (sans extension).
    """
    if not instance.original_image:
        return False

    base, _ = os.path.splitext(instance.original_image.name)
    for field_name, _, suffix in instance.TARGETS:
        f = getattr(instance, field_name)
        if not _file_exists(f):
            return True
        # compare sans extension, tolère les suffixes uniques du storage
        current_no_ext = os.path.splitext(f.name)[0]
        expected_prefix = f"{base}-{suffix}"
        if not current_no_ext.startswith(expected_prefix):
            return True

    return False

def _generate_variants(imagecontent_id: int):
    logger.info(f"[worker] start pk={imagecontent_id}")
    try:
        ic = ImageContent.objects.get(pk=imagecontent_id)
    except ImageContent.DoesNotExist:
        logger.info(f"[worker] skip pk={imagecontent_id} (not found)")
        _unmark_in_flight(imagecontent_id)
        return

    try:
        if not ic.original_image:
            logger.info(f"[worker] skip pk={ic.pk} (no original)")
            return

        base, _ = os.path.splitext(ic.original_image.name)
        to_update = []

        for field_name, width, suffix in ic.TARGETS:
            f = getattr(ic, field_name)
            expected_prefix = f"{base}-{suffix}"

            need_regen = False
            if _file_exists(f):
                # If existing file name doesn't start with the expected prefix → obsolete
                current_no_ext = os.path.splitext(f.name)[0]
                if not current_no_ext.startswith(expected_prefix):
                    # delete obsolete file from storage, and mark for regeneration
                    try:
                        ic._delete_storage_file(f)
                    except Exception:
                        pass
                    # clear field value so update_fields rewrites a clean name
                    setattr(ic, field_name, "")
                    need_regen = True
                else:
                    # correct prefix and exists → nothing to do for this target
                    need_regen = False
            else:
                # missing file → regenerate
                need_regen = True

            if need_regen:
                new_name = ic._make_derivative_webp(width, suffix)
                if new_name:
                    setattr(ic, field_name, new_name)
                    to_update.append(field_name)

        if to_update:
            to_update.append("updated_at")
            ic.save(update_fields=to_update)
            logger.info(f"[worker] done pk={ic.pk} updated={to_update}")
        else:
            logger.info(f"[worker] noop pk={ic.pk} (already up-to-date)")
    except Exception as e:
        logger.info(f"[worker] error pk={imagecontent_id}: {e}")
    finally:
        _unmark_in_flight(imagecontent_id)


@receiver(post_save, sender=ImageContent)
def imagecontent_post_save(sender, instance: ImageContent, **kwargs):
    async_mode = getattr(settings, "JEIKO_IMAGES_ASYNC", False)
    logger.debug(f"[signal] post_save pk={instance.pk} async={async_mode}")

    if not async_mode:
        logger.debug(f"[signal] skip pk={instance.pk} (async disabled)")
        return

    # Si une génération est déjà en cours pour ce PK, on NE reprogramme pas
    if not _mark_in_flight(instance.pk):
        logger.debug(f"[signal] skip pk={instance.pk} (already in flight)")
        return

    # Si pas besoin, on libère le guard et on sort
    if not _needs_generation(instance):
        logger.debug(f"[signal] skip pk={instance.pk} (no generation needed)")
        _unmark_in_flight(instance.pk)
        return

    logger.debug(f"[signal] enqueue pk={instance.pk}")
    transaction.on_commit(lambda: _EXECUTOR.submit(_generate_variants, instance.pk))

# --------------------------
# GESTION DE IS_HERO (Section → Line → Content)
# --------------------------



# Types de contenus visuels éligibles en dernier recours (après Section/Line)
HERO_ELIGIBLE_TYPES = {
    "IMAGE",
    "DYN_CAROUSEL",
    # "DYN_GALLERY_FILTER",
}


def _imagecontent_has_any_file(img) -> bool:
    """
    True si un ImageContent possède au moins un fichier exploitable.
    (On ne va pas au storage ici : suffisamment fiable pour le LCP côté rendu.)
    """
    return bool(
        img
        and (
            getattr(img, "original_image", None)
            or getattr(img, "full_size", None)
            or getattr(img, "computer_size", None)
            or getattr(img, "laptop_size", None)
            or getattr(img, "tablet_size", None)
            or getattr(img, "mobile_size", None)
        )
    )


def _has_section_bg(section: Section) -> bool:
    return _imagecontent_has_any_file(getattr(section, "background_image", None))


def _has_line_bg(line: Line) -> bool:
    return _imagecontent_has_any_file(getattr(line, "background_image", None))


def _content_has_visual(content: Content) -> bool:
    """
    True si le content possède un visuel affichable.
    - IMAGE: Content.content_image.image_content présent (original ou dérivés)
    - DYN_CAROUSEL: au moins un slide avec image (ou external_src)
    """
    ct = content.content_type

    if ct == "IMAGE":
        ci = getattr(content, "content_image", None)
        im = getattr(ci, "image_content", None) if ci else None
        return _imagecontent_has_any_file(im)

    if ct == "DYN_CAROUSEL":
        slides_qs = getattr(content, "carousel_slides", None)
        if not slides_qs:
            return False
        for s in slides_qs.all():
            if getattr(s, "external_src", None):
                return True
            if _imagecontent_has_any_file(getattr(s, "image", None)):
                return True
        return False

    # if ct == "DYN_GALLERY_FILTER":  # activer plus tard si besoin
    #     return True/False selon ton modèle d’items

    return False


def _pick_hero_candidate(page: Page) -> Tuple[Optional[str], Optional[object]]:
    """
    Retourne ('section', Section) ou ('line', Line) ou ('content', Content)
    selon la première occurrence trouvée dans l’ordre visuel, sinon (None, None).
    Priorité : Section.bg → Line.bg → Content visuel éligible.
    """
    # Préfetch utiles pour limiter N+1 sur le chemin “content”
    sections = page.sections.order_by("position", "id").prefetch_related(
        "lines__blocs__content__content_image__image_content",
        "lines__blocs__content__carousel_slides__image",
    )

    for section in sections:
        # 1) Section avec background ⇒ héros
        if _has_section_bg(section):
            return "section", section

        # 2) Parcours des lignes
        for line in section.lines.all().order_by("position", "id"):
            # 2a) Line avec background ⇒ héros
            if _has_line_bg(line):
                return "line", line

            # 3) Parcours des blocs/contents
            for bloc in line.blocs.all().order_by("position", "id"):
                content = getattr(bloc, "content", None)
                if not content:
                    continue
                if content.content_type in HERO_ELIGIBLE_TYPES and _content_has_visual(content):
                    return "content", content

    return None, None


def recompute_page_hero(page: Page) -> None:
    """
    Sur une page donnée :
      - remet TOUTES les Sections/Lines/Contents is_hero à False,
      - choisit le nouveau héros selon la priorité,
      - active uniquement celui-ci.
    """
    if not page:
        return

    kind, obj = _pick_hero_candidate(page)

    with transaction.atomic():
        # Tout mettre à False (idempotent)
        Section.objects.filter(page=page, is_hero=True).update(is_hero=False)
        Line.objects.filter(section__page=page, is_hero=True).update(is_hero=False)
        Content.objects.filter(bloc__line__section__page=page, is_hero=True).update(is_hero=False)

        # Activer le nouveau s’il existe
        if not kind or not obj:
            return

        if kind == "section":
            Section.objects.filter(pk=obj.pk).update(is_hero=True)
        elif kind == "line":
            Line.objects.filter(pk=obj.pk).update(is_hero=True)
        else:  # "content"
            Content.objects.filter(pk=obj.pk).update(is_hero=True)


# --------------------------
# Helpers pour retrouver la page depuis n’importe quel niveau
# --------------------------

def _page_of_section(section: Section) -> Optional[Page]:
    return getattr(section, "page", None)


def _page_of_line(line: Line) -> Optional[Page]:
    sec = getattr(line, "section", None)
    return getattr(sec, "page", None) if sec else None


def _page_of_bloc(bloc: Bloc) -> Optional[Page]:
    line = getattr(bloc, "line", None)
    return _page_of_line(line) if line else None


def _page_of_content(content: Content) -> Optional[Page]:
    bloc = getattr(content, "bloc", None)
    return _page_of_bloc(bloc) if bloc else None

# --------------------------
# Helpers "safe" à base d'IDs (aucun accès relationnel)
# --------------------------
def _page_id_of_section(section: Section) -> int | None:
    return getattr(section, "page_id", None)

def _page_id_from_section_id(sec_id, using: str = "default") -> int | None:
    if not sec_id:
        return None
    return (
        Section.objects.using(using)
        .filter(id=sec_id)
        .values_list("page_id", flat=True)
        .first()
    )


def _page_id_from_line_id(line_id, using: str = "default") -> int | None:
    """
    Line n'a PAS de FK directe vers Page : seulement section_id.

    Les versions précédentes tentaient `Line.objects.values_list("page_id")`, ce qui levait
    systématiquement FieldError. L'exception était avalée par un `except Exception: pass`,
    si bien que le héros n'était jamais recalculé lors d'une modification de bloc ou de
    contenu — seules les sections et les lignes déclenchaient réellement le recalcul.
    """
    if not line_id:
        return None
    sec_id = (
        Line.objects.using(using)
        .filter(id=line_id)
        .values_list("section_id", flat=True)
        .first()
    )
    return _page_id_from_section_id(sec_id, using=using)


def _page_id_of_line(line: Line, using: str = "default") -> int | None:
    # On évite line.section : on passe par l'ID déjà chargé.
    return _page_id_from_section_id(getattr(line, "section_id", None), using=using)

def _page_id_of_bloc(bloc: Bloc, using: str = "default") -> int | None:
    # On évite bloc.line : on passe par l'ID.
    return _page_id_from_line_id(getattr(bloc, "line_id", None), using=using)

def _page_id_of_content(content: Content, using: str = "default") -> int | None:
    # On évite content.bloc : on ne charge que le line_id du bloc.
    bloc_id = getattr(content, "bloc_id", None)
    if not bloc_id:
        return None
    line_id = (
        Bloc.objects.using(using)
        .filter(id=bloc_id)
        .values_list("line_id", flat=True)
        .first()
    )
    return _page_id_from_line_id(line_id, using=using)

# --------------------------
# Helpers : retrouver la page depuis un SATELLITE de style
# --------------------------
#
# Un élément stylable ne porte pas son décor : il le désigne. Modifier le CSS
# personnalisé d'une section, sa bordure, son animation, une marge ou une
# taille n'écrit donc PAS la section — seulement l'objet lié. Aucun signal ne
# partait, et le corps de page restait servi depuis le cache.
#
# Le symptôme, remonté du terrain : `PATCH /sections/<id>/` répond 200, la
# relecture par l'API montre la nouvelle valeur, et la page publique sert
# l'ancienne — même avec un paramètre anti-cache. On en conclut que l'écriture
# n'a pas pris. Le contournement trouvé sur place était de toucher la page
# elle-même, ce qui la sauvegarde et déclenche le signal existant.
#
# Ces résolveurs coûtent une à trois requêtes, et seulement à l'ÉCRITURE d'un
# décor. Les lectures publiques n'en voient rien.

def _page_id_de_rattachement(objet, using: str = "default") -> int | None:
    """La page d'un satellite qui porte section/line/bloc (CustomCSS, Border…)."""
    if getattr(objet, "section_id", None):
        return _page_id_from_section_id(objet.section_id, using=using)
    if getattr(objet, "line_id", None):
        return _page_id_from_line_id(objet.line_id, using=using)
    bloc_id = getattr(objet, "bloc_id", None)
    if bloc_id:
        line_id = (
            Bloc.objects.using(using)
            .filter(id=bloc_id).values_list("line_id", flat=True).first()
        )
        return _page_id_from_line_id(line_id, using=using)
    return None


def _champs_pointant_vers(modele, cible) -> list:
    """Les FK de `modele` qui désignent `cible`, lues sur le modèle."""
    return [
        champ.name for champ in modele._meta.get_fields()
        if getattr(champ, "many_to_one", False) and champ.related_model is cible
    ]


def _page_id_de_la_boite(boite, using: str = "default") -> int | None:
    """
    La page d'une `StyleBox` ou d'une `Size`.

    Celles-ci ne savent pas à qui elles appartiennent : ce sont Section, Line
    et Bloc qui les désignent, par huit champs chacun (quatre appareils ×
    marge/padding). On interroge donc les trois porteurs, une requête chacun,
    et les champs sont LUS sur les modèles — un cinquième appareil ajouté
    demain serait couvert sans que personne y pense.
    """
    cible = type(boite)
    for modele in (Section, Line, Bloc):
        champs = _champs_pointant_vers(modele, cible)
        if not champs:
            continue
        condition = Q()
        for champ in champs:
            condition |= Q(**{champ: boite.pk})
        porteur = modele.objects.using(using).filter(condition).first()
        if porteur is None:
            continue
        if modele is Section:
            return _page_id_of_section(porteur)
        if modele is Line:
            return _page_id_of_line(porteur, using=using)
        return _page_id_of_bloc(porteur, using=using)
    return None


_hero_state = threading.local()


def _pending_hero_pages() -> set:
    pages = getattr(_hero_state, "pages", None)
    if pages is None:
        pages = set()
        _hero_state.pages = pages
    return pages


def _flush_pending_pages(using=None) -> None:
    """Traite le lot de pages accumulé, une seule fois par transaction."""
    pending = _pending_hero_pages()
    if not pending:
        return  # déjà vidé par un callback précédent du même commit
    page_ids = list(pending)
    pending.clear()

    for page_id in page_ids:
        try:
            qs = Page.objects.using(using) if using else Page.objects
            qs.filter(pk=page_id).update(is_default_legal_template=False)
            page = Page.objects.filter(id=page_id).first()
            if page:
                recompute_page_hero(page)
        except Exception:
            # On ne casse jamais la requête, mais on ne l'avale plus en silence.
            logger.exception("Recalcul du héros impossible pour la page %s", page_id)

        # Invalidation du cache du corps de page (page_cache.py) : ce lot est
        # déjà dédupliqué et déclenché au commit, donc N modifications sur une
        # même page = un seul bump. On l'isole pour qu'un échec de cache ne
        # compromette jamais le recalcul du héros ci-dessus.
        try:
            bump_page_body_version(page_id)
        except Exception:
            logger.exception("Invalidation du cache de page impossible pour %s", page_id)


def _schedule_page_refresh(page_id, using=None) -> None:
    """
    Planifie le recalcul du héros + le démarquage de template légal, en différé et dédupliqué.

    Auparavant chaque save() de Section/Line/Bloc/Content déclenchait immédiatement un
    parcours complet de la page. Dupliquer une section de 3 lignes x 3 blocs représente
    ~22 save(), donc 22 parcours complets à l'intérieur d'une même transaction.

    Ici on empile les page_id et on ne déclenche le travail qu'au commit : N save() sur
    une même page = 1 seul recalcul. Les callbacks surnuméraires trouvent le lot vide et
    ne font rien.
    """
    if not page_id:
        return
    _pending_hero_pages().add(page_id)
    transaction.on_commit(lambda: _flush_pending_pages(using), using=using)


def _recompute_for_page_id(page_id: int | None) -> None:
    _schedule_page_refresh(page_id)


def _recompute_for_page(page: Optional[Page]) -> None:
    if page:
        _schedule_page_refresh(page.pk)


def _mark_page_non_default(page_id, using=None):
    """
    Conservé pour compatibilité : le démarquage est désormais fait par _flush_pending_pages,
    en même temps que le recalcul du héros, pour ne pas payer un UPDATE par save().
    """
    _schedule_page_refresh(page_id, using=using)
# --------------------------
# Signaux : on recalcule après SAVE/DELETE
# --------------------------

def _on_element_changed(resolve_page_id):
    """
    Fabrique un récepteur qui planifie le rafraîchissement de la page concernée.
    Le travail réel (démarquage template légal + recalcul du héros) est différé au
    commit et dédupliqué : voir _schedule_page_refresh.
    """
    def _receiver(sender, instance, using, **kwargs):
        try:
            _schedule_page_refresh(resolve_page_id(instance, using), using=using)
        except Exception:
            # On ne casse jamais la requête, mais on garde une trace.
            logger.exception(
                "Planification du rafraîchissement impossible (%s pk=%s)",
                sender.__name__, getattr(instance, "pk", None),
            )
    return _receiver


_section_changed = _on_element_changed(lambda obj, using: _page_id_of_section(obj))
_line_changed    = _on_element_changed(lambda obj, using: _page_id_of_line(obj, using=using))
_bloc_changed    = _on_element_changed(lambda obj, using: _page_id_of_bloc(obj, using=using))
_content_changed = _on_element_changed(lambda obj, using: _page_id_of_content(obj, using=using))

# Les satellites de style : leur écriture ne touche pas l'élément porteur.
_rattachement_changed = _on_element_changed(
    lambda obj, using: _page_id_de_rattachement(obj, using=using)
)
_boite_changed = _on_element_changed(
    lambda obj, using: _page_id_de_la_boite(obj, using=using)
)

for _model, _handler in (
    (Section, _section_changed),
    (Line,    _line_changed),
    (Bloc,    _bloc_changed),
    (Content, _content_changed),
    (CustomCSS, _rattachement_changed),
    (Animation, _rattachement_changed),
    (Border, _rattachement_changed),
    (StyleBox, _boite_changed),
    (Size, _boite_changed),
    # Désigné par l'élément, comme les boîtes — pas de rattachement propre.
    (BackgroundImageParameters, _boite_changed),
):
    post_save.connect(_handler, sender=_model, dispatch_uid=f"jeiko_hero_save_{_model.__name__}")
    post_delete.connect(_handler, sender=_model, dispatch_uid=f"jeiko_hero_delete_{_model.__name__}")


@receiver(post_save, sender=Page)
def _page_saved(sender, instance, created, using, **kwargs):
    """
    À l’UPDATE d’une page (pas lors de la création), on enlève le flag template légal.
    Évite d’écraser les pages seeds/migrations qui naissent avec True.
    """
    try:
        if not created:
            _mark_page_non_default(instance.pk, using)
    except Exception:
        pass


# --------------------------
# Signaux : INSIGHT
# --------------------------



@receiver(post_save, sender=PageInsights)
def prune_old_insights(sender, instance: PageInsights, created: bool, **kwargs):
    """
    Après chaque sauvegarde d'un PageInsights, on ne conserve que le plus récent
    pour la paire (page, strategy). La logique "latest-only" est somit forcée ici.
    """
    if instance.page_id is None:
        # Si la FK est nulle (cas improbable dans ton usage), rien à faire.
        return

    # On définit le "dernier" par fetched_at DESC puis id DESC (sécurité en cas d'égalité).
    with transaction.atomic():
        qs = (
            PageInsights.objects
            .filter(page_id=instance.page_id, strategy=instance.strategy)
            .exclude(pk=instance.pk)
            .order_by("-fetched_at", "-pk")
        )
        # L'instance courante est déjà la plus récente (sauvegardée à l'instant).
        # On purge tous les autres (latest-only).
        qs.delete()
