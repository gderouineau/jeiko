"""
Changer le DÉCOR d'une section doit se voir tout de suite (rapport terrain nº 4).

Ce qui se passait
-----------------
`PATCH /api/agent/v1/sections/<id>/` avec un nouveau `css.custom` répondait
200, la relecture par l'API montrait bien la nouvelle valeur — et la page
publique continuait de servir l'ancien CSS, y compris avec un paramètre
anti-cache dans l'URL. On en concluait, légitimement, que l'écriture n'avait
pas pris. Le contournement trouvé sur le terrain était de toucher la PAGE,
même sans rien y changer : cela la sauvegarde, et le signal existant partait.

La cause : un élément stylable ne porte pas son décor, il le DÉSIGNE. Écrire
le CSS personnalisé, la bordure, l'animation, une marge ou une taille n'écrit
pas la section — seulement l'objet lié. Or seuls Section, Line, Bloc et
Content étaient branchés sur l'invalidation. Le cache du corps de page n'était
donc jamais invalidé pour une modification de décor, par l'API comme par
l'éditeur.

Pourquoi ces tests portent sur le COMPORTEMENT
-----------------------------------------------
Même raison que `administration/tests_invalidation_cache` : vérifier qu'un
signal est branché reviendrait à relire le code depuis le code. Ce qui compte
est observable — la version du corps de page doit changer.
"""

from django.test import TestCase

from jeiko.administration_pages.models import (
    Border, CustomCSS, Page, Section, StyleBox,
)
from jeiko.administration_pages.page_cache import page_body_version


class InvalidationDuDecorTests(TestCase):
    def setUp(self):
        self.page = Page.objects.create(title="Décor", url_tag="decor")
        self.section = Section.objects.create(page=self.page)
        self.avant = page_body_version(self.page.id)

    def _apres(self):
        return page_body_version(self.page.id)

    def _dans_un_commit(self, action):
        """Le lot est vidé au commit : sans cela, rien ne part en test."""
        with self.captureOnCommitCallbacks(execute=True):
            action()

    def test_le_css_personnalise_invalide_la_page(self):
        self._dans_un_commit(lambda: CustomCSS.objects.create(
            section=self.section, custom=".content .t{color:red}"
        ))
        self.assertGreater(self._apres(), self.avant)

    def test_modifier_un_css_deja_pose_invalide_aussi(self):
        """
        Le cas exact du rapport : le satellite existe déjà, on ne fait que
        réécrire un champ.
        """
        css = CustomCSS.objects.create(section=self.section, custom="")
        self.avant = page_body_version(self.page.id)

        def modifier():
            css.custom = ".content .t{font-family:'EB Garamond',serif}"
            css.save(update_fields=["custom"])

        self._dans_un_commit(modifier)
        self.assertGreater(self._apres(), self.avant)

    def test_la_bordure_invalide_la_page(self):
        self._dans_un_commit(lambda: Border.objects.create(
            section=self.section, border_width="2px"
        ))
        self.assertGreater(self._apres(), self.avant)

    def test_une_marge_invalide_la_page(self):
        """
        Une `StyleBox` ne sait pas à qui elle appartient : c'est la section qui
        la désigne. Le résolveur doit la retrouver.
        """
        boite = StyleBox.objects.create(top="0", right="0", bottom="0", left="0")
        Section.objects.filter(pk=self.section.pk).update(margin_computer=boite)
        self.avant = page_body_version(self.page.id)

        def modifier():
            boite.top = "40px"
            boite.save(update_fields=["top"])

        self._dans_un_commit(modifier)
        self.assertGreater(self._apres(), self.avant)

    def test_une_boite_orpheline_ne_casse_rien(self):
        """
        Une boîte que personne ne désigne — reste d'un élément supprimé — ne
        doit ni lever, ni invalider une page au hasard.
        """
        orpheline = StyleBox.objects.create(top="", right="", bottom="", left="")
        self._dans_un_commit(lambda: orpheline.save())
        self.assertEqual(self._apres(), self.avant)
