"""
Le CSS personnalisé ne doit plus être échappé en HTML (rapport terrain nº 3).

Ce qui se passait
-----------------
`{{ css.custom }}` était rendu dans un `<style>` avec l'auto-échappement de
Django. Or les entités ne sont **jamais** décodées à l'intérieur d'un
`<style>` : ce qui en sortait n'était plus du CSS.

    font-family:'EB Garamond'   →  font-family:&#x27;EB Garamond&#x27;
    .content ol > li            →  .content ol &gt; li
    ?family=A&family=B          →  ?family=A&amp;family=B

Le navigateur jette la déclaration invalide et applique le reste de la règle.
Symptôme vécu sur accompagnementhumain.com : tous les titres restaient en
Georgia alors que le `line-height` de la même règle passait — l'API répondait
200, la valeur était en base, intacte.

C'est la famille de défauts la plus coûteuse de ce produit : ça compile, ça
enregistre, et ça ne fait rien.

Ce que ces tests gardent
------------------------
* ce qui doit survivre : guillemets, `>`, `&`, accolades, points-virgules ;
* ce qui ne doit pas : la sortie de l'élément `<style>`, l'appel à un tiers ;
* et le fait que les trois gabarits appliquent réellement le filtre — un
  `{{ css.x }}` remis à nu passerait autrement inaperçu jusqu'au prochain site.
"""

import pathlib
import re

from django.template import Context, Template
from django.test import SimpleTestCase

from jeiko.templatetags.css_extras import clean_css_block

GABARITS = (
    pathlib.Path(__file__).resolve().parent.parent
    / "templates" / "administration_pages" / "styles"
)

#: Les treize champs de CustomCSS rendus par chaque gabarit.
CHAMPS = (
    "before", "current", "after", "hover", "custom",
    "current_phone", "current_tablet", "current_computer", "current_laptop",
    "hover_phone", "hover_tablet", "hover_computer", "hover_laptop",
)


class CeQuiDoitSurvivreTests(SimpleTestCase):
    def test_les_guillemets_restent_des_guillemets(self):
        css = ".content .t{font-family:'EB Garamond',serif}"
        self.assertEqual(clean_css_block(css), css)

    def test_le_selecteur_enfant_reste_intact(self):
        css = ".content ol > li{color:red}"
        self.assertEqual(clean_css_block(css), css)

    def test_l_esperluette_reste_intacte(self):
        css = '.content .t{background:url("/media/a?x=1&y=2")}'
        self.assertEqual(clean_css_block(css), css)

    def test_une_media_query_passe(self):
        css = "@media(max-width:767px){.content .t{font-size:19px}}"
        self.assertEqual(clean_css_block(css), css)

    def test_le_rendu_en_gabarit_ne_produit_aucune_entite(self):
        sortie = Template(
            "{% load css_extras %}<style>{{ css|css_bloc }}</style>"
        ).render(Context({"css": ".content .t{font-family:'EB Garamond' ; }"}))
        self.assertNotIn("&#x27;", sortie)
        self.assertNotIn("&amp;", sortie)
        self.assertIn("'EB Garamond'", sortie)


class CeQuiNeDoitPasPasserTests(SimpleTestCase):
    def test_on_ne_sort_pas_de_l_element_style(self):
        sortie = clean_css_block("}</style><script>alert(1)</script>")
        self.assertNotIn("</style", sortie)
        self.assertNotIn("</script", sortie)

    def test_l_import_est_retire(self):
        """
        Refusé à l'écriture par l'API depuis le même passage — mais ce filtre
        couvre ce qui est DÉJÀ en base, et ce que l'éditeur laisse saisir à la
        main.
        """
        sortie = clean_css_block(
            "@import url(https://fonts.googleapis.com/css?family=A|B);\n"
            ".content .t{color:red}"
        )
        self.assertNotIn("@import", sortie)
        self.assertNotIn("fonts.googleapis.com", sortie)
        self.assertIn(".content .t{color:red}", sortie)

    def test_une_url_distante_est_neutralisee_pas_le_reste(self):
        sortie = clean_css_block(
            ".content .t{background:url(https://cdn.tld/a.png);color:red}"
        )
        self.assertNotIn("cdn.tld", sortie)
        self.assertIn("color:red", sortie)

    def test_les_ressources_du_site_passent(self):
        css = ".content .t{background:url(/media/images/fond.webp)}"
        self.assertEqual(clean_css_block(css), css)


class LesGabaritsAppliquentLeFiltreTests(SimpleTestCase):
    """
    Un test de SOURCE, volontairement.

    Le défaut d'origine ne se voyait ni à l'écriture, ni à la lecture par
    l'API, ni dans un test qui n'ouvre pas le HTML servi. Vérifier que le
    filtre est écrit là où il faut est le seul garde-fou qui tienne à la
    relecture.
    """

    def _source(self, nom):
        return (GABARITS / nom).read_text(encoding="utf-8")

    def test_les_trois_gabarits_filtrent_leurs_treize_champs(self):
        for nom in ("section.html", "line.html", "bloc.html"):
            source = self._source(nom)
            with self.subTest(gabarit=nom):
                self.assertIn("{% load editor_responsive css_extras %}", source)
                for champ in CHAMPS:
                    self.assertIn(
                        f"{{{{ css.{champ}|default:\"\"|css_bloc }}}}", source,
                        f"{nom} : « css.{champ} » n'est plus filtré.",
                    )

    def test_aucun_champ_de_css_ne_reste_a_nu(self):
        nu = re.compile(r'\{\{\s*css\.[a-z_]+\|default:""\s*\}\}')
        for nom in ("section.html", "line.html", "bloc.html"):
            with self.subTest(gabarit=nom):
                self.assertFalse(nu.search(self._source(nom)))
