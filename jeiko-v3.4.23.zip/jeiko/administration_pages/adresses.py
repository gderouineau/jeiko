"""
Deux pages ne doivent jamais tomber à la même adresse — et ça ne se voit pas.

Ce que le classement fait à une adresse
---------------------------------------
`Page.get_absolute_url` construit l'adresse depuis la CATÉGORIE, et seulement
si celle-ci est marquée `show_cat_in_url` :

    /<cat>/<sous-cat>/<url_tag>/   les deux visibles
    /<cat>/<url_tag>/              la catégorie seule visible
    /<url_tag>/                    catégorie masquée, ou absente

La conséquence n'est pas intuitive : **décocher « afficher dans l'URL » sur une
catégorie remonte toutes ses pages à la racine du site.** Deux pages rangées
dans deux catégories différentes, qui vivaient tranquillement en
`/formations/tarifs/` et `/coaching/tarifs/`, se retrouvent toutes deux en
`/tarifs/`. Une seule répondra ; l'autre devient inatteignable. Aucune erreur,
aucune migration, aucun écran ne le dit — la contrainte de base
`uniq_url_tag_when_no_category` ne couvre que les pages SANS catégorie, pas
celles dont la catégorie est masquée.

C'est la contrepartie d'une souplesse voulue : deux sous-catégories peuvent
porter le même nom et le même slug tant que leur parente paraît dans l'URL,
parce que le chemin complet les distingue. La souplesse est utile — « Actualités »
sous « Formations » et sous « Coaching » est un besoin réel — mais elle ne tient
qu'aussi longtemps que le segment parent est là.

Ce que ce module fait, et ne fait pas
--------------------------------------
Il SIMULE le changement et compare les adresses obtenues, en appelant
`get_absolute_url` — jamais en réécrivant la règle. La dupliquer garantirait
qu'elle diverge : c'est déjà arrivé ailleurs dans ce paquet.

Il ne signale que les collisions **nouvelles**. Un site qui en porte déjà ne
doit pas voir tous ses changements refusés au nom d'un défaut antérieur : on
refuse ce que l'appelant s'apprête à casser, pas ce qu'il a trouvé cassé.
"""

from collections import Counter, defaultdict


def chemin_de_categorie(categorie):
    """
    Le préfixe d'URL qu'une catégorie ajoute, ou `None` si elle n'en ajoute pas.

    `None` n'est pas une erreur : une catégorie qui ne sert qu'à regrouper est
    invisible dans les adresses, et son slug ne peut donc entrer en collision
    avec rien.
    """
    if categorie is None or not categorie.show_cat_in_url or not categorie.slug:
        return None

    parente = categorie.main_category
    if parente is None:
        return f"/{categorie.slug}/"

    # Une sous-catégorie ne se montre pas sans sa parente : c'est la règle de
    # `get_absolute_url`, et l'API la fait respecter à la création.
    if not parente.show_cat_in_url or not parente.slug:
        return None
    return f"/{parente.slug}/{categorie.slug}/"


def categories_au_meme_chemin(categorie, *, exclure_pk=None):
    """
    Les catégories qui occuperaient le même chemin public que celle-ci.

    Deux catégories invisibles ne se gênent pas : elles n'ont pas de chemin.
    """
    from .models import Category

    chemin = chemin_de_categorie(categorie)
    if chemin is None:
        return []

    autres = Category.objects.select_related("main_category")
    if exclure_pk:
        autres = autres.exclude(pk=exclure_pk)
    return [c for c in autres if chemin_de_categorie(c) == chemin]


def adresse_prevue(*, url_tag, categorie=None, sous_categorie=None, racine=False):
    """
    L'adresse qu'AURAIT une page ainsi classée, sans rien enregistrer.

    On fabrique une `Page` non sauvegardée et on lui demande son adresse :
    c'est `get_absolute_url` qui fait foi, ici comme ailleurs. Réécrire la
    règle à côté serait la garantie qu'elles divergent un jour.
    """
    from .models import Page

    page = Page(url_tag=url_tag, is_root=racine)
    page.category = categorie
    page.sub_category = sous_categorie
    return page.get_absolute_url()


def page_a_cette_adresse(adresse, *, sauf_page_id=None):
    """
    La page qui répond déjà à cette adresse, ou `None`.

    C'est LA question à poser avant d'écrire — pas « ce nom est-il pris » ni
    « ce slug existe-t-il ». Deux pages peuvent porter le même `url_tag` sans
    se gêner tant que leurs catégories les séparent ; et deux pages aux
    catégories différentes peuvent se cogner dès que l'une d'elles cesse de
    paraître dans l'URL. Seule l'adresse finale tranche.

    Le dernier segment d'une adresse est toujours l'`url_tag` : on ne compare
    donc que les pages qui portent le même, au lieu de calculer l'adresse de
    tout le site.
    """
    from .models import Page

    segments = [s for s in str(adresse).split("/") if s]
    tag = segments[-1] if segments else ""

    candidates = Page.objects.select_related(
        "category__main_category", "sub_category"
    )
    candidates = candidates.filter(url_tag=tag) if tag else candidates.filter(
        is_root=True
    )
    if sauf_page_id:
        candidates = candidates.exclude(pk=sauf_page_id)

    for page in candidates:
        if page.get_absolute_url() == adresse:
            return page
    return None


def _pages_avec_leur_classement():
    from .models import Page

    return list(
        Page.objects.select_related("category__main_category", "sub_category")
        .exclude(is_root=True)
    )


def _adresses(pages, remplacement=None):
    """
    Les adresses des pages, la catégorie `remplacement` substituée en mémoire.

    La substitution ne touche pas la base : c'est une simulation, et elle doit
    le rester tant que l'appelant n'a pas décidé.
    """
    obtenues = {}
    for page in pages:
        if remplacement is not None:
            if page.category_id == remplacement.pk:
                page.category = remplacement
            if page.sub_category_id == remplacement.pk:
                page.sub_category = remplacement
        obtenues[page.pk] = (page, page.get_absolute_url())
    return obtenues


def collisions_si_on_change(categorie, **changements):
    """
    Les adresses qui deviendraient partagées si l'on appliquait `changements`.

    Renvoie une liste de `(adresse, [titres de pages])`, vide si tout va bien.
    Seules les collisions NOUVELLES sont rendues.
    """
    from .models import Category

    pages = _pages_avec_leur_classement()
    if not pages:
        return []

    avant = Counter(url for _, url in _adresses(pages).values())

    # Un clone en mémoire : on ne modifie jamais l'objet de l'appelant, qui
    # pourrait l'enregistrer ensuite en croyant n'avoir rien fait.
    simulee = Category.objects.select_related("main_category").get(pk=categorie.pk)
    for champ, valeur in changements.items():
        setattr(simulee, champ, valeur)

    apres = _adresses(_pages_avec_leur_classement(), remplacement=simulee)

    par_adresse = defaultdict(list)
    for page, url in apres.values():
        par_adresse[url].append(page)

    conflits = []
    for url, concernees in sorted(par_adresse.items()):
        if len(concernees) > 1 and len(concernees) > avant.get(url, 0):
            conflits.append((url, [p.title for p in concernees]))
    return conflits


def message_de_conflit(conflits):
    """Le refus, en clair : ce qui se cognerait, et où."""
    details = "; ".join(
        f"« {adresse} » réclamée par {', '.join(titres)}"
        for adresse, titres in conflits[:5]
    )
    reste = "" if len(conflits) <= 5 else f" (et {len(conflits) - 5} autres)"
    return (
        f"Ce changement ferait tomber des pages à la même adresse : {details}"
        f"{reste}. Une seule répondrait, l'autre deviendrait inatteignable sans "
        f"qu'aucune erreur ne le signale. Renommez leur « url_tag », ou "
        f"laissez la catégorie paraître dans l'URL."
    )
