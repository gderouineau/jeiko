# views_client.py
from django.http import Http404
from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import TemplateView
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.contrib.auth import get_user_model
import json
from urllib.parse import quote
from django.db import transaction
from django.db.models import Q, Prefetch
from django.utils.safestring import mark_safe
from jeiko.questionnaires_expert.emails import (
    send_test_result_email, send_admin_test_notification
)


from jeiko.questionnaires_expert.models import (
    ExpertTest, ExpertQuestion, ExpertAnswer, ExpertProfileType,
    ExpertProfileCombination, ExpertProfileCriterion, ExpertTestData
)
from jeiko.questionnaires_expert.models import Prospect
from jeiko.questionnaires_expert.forms import ProspectForm

User = get_user_model()

from django.contrib import messages
from django.urls import reverse, NoReverseMatch

def home_url():
    """
    URL de repli après un refus d'accès.

    Tous les sites jeiko ne déclarent pas une route nommée « home » : un
    reverse() direct lèverait NoReverseMatch et transformerait le refus en 500.
    """
    try:
        return reverse("home")
    except NoReverseMatch:
        return "/"


class ExpertTestAccessMixin:
    """
    Charge le test dans `self.test` et refuse l'accès aux tests restreints.

    Un test restreint n'est accessible qu'aux membres du staff (prévisualisation)
    et aux utilisateurs disposant d'un UserTestAccess — accordé manuellement par
    un staff ou automatiquement à l'achat du produit lié.
    """

    def get_test(self):
        if not hasattr(self, "_test"):
            self._test = get_object_or_404(ExpertTest, slug=self.kwargs.get('slug'))
        return self._test

    def dispatch(self, request, *args, **kwargs):
        self.test = self.get_test()

        # Un test désactivé n'existe plus pour le public ; le staff garde l'accès
        # pour pouvoir le relire et le corriger avant réouverture.
        if not self.test.is_active and not request.user.is_staff:
            raise Http404("Ce questionnaire n'est pas disponible.")

        if self.test.is_restricted:
            if not request.user.is_authenticated:
                login_url = f"{reverse('jeiko_allauth:login')}?next={quote(request.get_full_path())}"
                return redirect(login_url)

            has_access = (
                request.user.is_staff
                or request.user.is_superuser
                or self.test.user_accesses.filter(user=request.user).exists()
            )

            if not has_access:
                messages.error(request, "Vous n'avez pas accès à ce questionnaire.")
                return redirect(home_url())

        return super().dispatch(request, *args, **kwargs)


SESSION_KEY = "expert_answers"


def active_questions(test):
    """Les questions réellement posées : actives, dans l'ordre."""
    return test.questions.filter(is_active=True).order_by("order", "id")


def get_session_answers(request, test):
    """Réponses déjà données pour CE test : {question_id (str): [answer_id (int)]}."""
    return (request.session.get(SESSION_KEY) or {}).get(test.slug, {})


def store_session_answer(request, test, question, answer_ids):
    store = request.session.get(SESSION_KEY) or {}
    store.setdefault(test.slug, {})[str(question.id)] = answer_ids
    request.session[SESSION_KEY] = store


def clear_session_answers(request, test):
    store = request.session.get(SESSION_KEY) or {}
    if store.pop(test.slug, None) is not None:
        request.session[SESSION_KEY] = store


def first_unanswered_position(request, test):
    """
    Index de la première question sans réponse, ou None si le test est complet.
    Sert à reprendre le parcours là où il s'est arrêté plutôt que de tout perdre.
    """
    answers = get_session_answers(request, test)
    for index, question in enumerate(active_questions(test)):
        if not answers.get(str(question.id)):
            return index
    return None


@method_decorator(never_cache, name='dispatch')
class ExpertTestIntroView(ExpertTestAccessMixin, View):

    @method_decorator(never_cache)
    def get(self, request, slug):
        # Reprendre un test signifie répondre à nouveau : on repart d'une ardoise propre.
        clear_session_answers(request, self.test)
        return render(request, "questionnaires_expert_client/test_intro.html", {"test": self.test})


@method_decorator(never_cache, name='dispatch')
class ExpertTestQuestionView(ExpertTestAccessMixin, View):

    def get_question(self, position):
        questions = list(active_questions(self.test))
        if 0 <= position < len(questions):
            return questions[position], len(questions)
        return None, len(questions)

    @method_decorator(never_cache)
    def get(self, request, slug, position):
        question, total = self.get_question(position)
        if question is None:
            return redirect("jeiko_client_questionnaires_expert:test_result_input", slug=slug)

        return render(request, "questionnaires_expert_client/question.html", {
            "test": self.test,
            "question": question,
            "answers": question.active_answers.order_by("order", "id"),
            "selected": get_session_answers(request, self.test).get(str(question.id), []),
            "position": position,
            "total": total,
        })

    @method_decorator(never_cache)
    def post(self, request, slug, position):
        question, _ = self.get_question(position)
        if question is None:
            return redirect("jeiko_client_questionnaires_expert:test_result_input", slug=slug)

        submitted = request.POST.getlist("answer")

        # Le contenu du POST est piloté par le visiteur : on ne conserve que des
        # identifiants numériques correspondant à une réponse active de CETTE
        # question. Auparavant une valeur non numérique remontait jusqu'au
        # scoring et y levait une ValueError (500).
        allowed_ids = set(question.active_answers.values_list("id", flat=True))
        answer_ids = [
            int(value) for value in submitted
            if value.isdigit() and int(value) in allowed_ids
        ]
        if question.question_type != 'multiple':
            answer_ids = answer_ids[:1]

        if not answer_ids:
            messages.error(request, "Merci de sélectionner une réponse.")
            return redirect(
                "jeiko_client_questionnaires_expert:test_question",
                slug=slug, position=position,
            )

        store_session_answer(request, self.test, question, answer_ids)
        return redirect(
            "jeiko_client_questionnaires_expert:test_question",
            slug=slug, position=position + 1,
        )

def get_score_profile(test, total_score):
    """
    Retourne le profil `is_score_profile` dont la plage contient total_score.

    Une borne laissée vide est traitée comme non contraignante (cf. help_text
    du modèle) : min vide = pas de minimum, max vide = pas de maximum.
    On ordonne par min_score pour que le résultat soit déterministe si
    plusieurs plages se chevauchent.
    """
    return (
        ExpertProfileType.objects
        .filter(test=test, is_score_profile=True)
        .filter(Q(min_score__isnull=True) | Q(min_score__lte=total_score))
        .filter(Q(max_score__isnull=True) | Q(max_score__gt=total_score))
        .order_by('min_score', 'id')
        .first()
    )


def compute_total_score(test, profile_scores):
    """
    Score global du test : somme des profils simples, c'est-à-dire exactement
    ceux qui sont restitués au visiteur.

    Y inclure les profils complexes gonflerait un total que personne ne peut
    recomposer depuis les scores affichés.
    """
    simple_ids = ExpertProfileType.objects.filter(
        test=test, is_complex=False, is_score_profile=False
    ).values_list("id", flat=True)
    return sum(profile_scores.get(pid, 0) for pid in simple_ids)


def resolve_profiles(test, profile_scores):
    """
    Applique les combinaisons du test aux scores calculés.

    Une combinaison est retenue lorsque TOUS ses critères sont satisfaits ;
    l'évaluation s'arrête à la première (les combinaisons sont ordonnées par id,
    et les critères par priorité). À défaut, on retombe sur le profil par score
    global s'il en existe un.

    Retourne (result_profile, preferred, alternative).
    """
    combinations = (
        ExpertProfileCombination.objects
        .filter(test=test)
        .select_related("parent_profile", "preferred_profile", "alternative_profile")
        .prefetch_related(
            Prefetch("criteria", queryset=ExpertProfileCriterion.objects.order_by("priority", "id"))
        )
    )

    for combination in combinations:
        criteria = list(combination.criteria.all())
        if not criteria:
            continue

        if all(criterion.evaluate(profile_scores) for criterion in criteria):
            return (
                combination.parent_profile,
                combination.preferred_profile,
                combination.alternative_profile,
            )

    return get_score_profile(test, compute_total_score(test, profile_scores)), None, None

def score_session_answers(test, answers):
    """
    Transforme les réponses en session en (profile_scores, answers_data).

    Les réponses sont préchargées avec leurs poids : le scoring faisait
    auparavant une requête par réponse sélectionnée.
    """
    questions = active_questions(test).prefetch_related(
        Prefetch(
            "answers",
            queryset=ExpertAnswer.objects.filter(is_active=True).prefetch_related("profile_weights"),
        )
    )

    profile_scores = {}
    answers_data = []

    for question in questions:
        answer_ids = answers.get(str(question.id)) or []
        selected = [a for a in question.answers.all() if a.id in set(answer_ids)]
        if not selected:
            continue

        question_answers_data = []
        for answer in selected:
            question_answers_data.append({
                "answer_id": answer.id,
                "answer_text": answer.text,
            })
            for weight in answer.profile_weights.all():
                # Un poids peut ne cibler aucun profil (profile_type nullable) :
                # il ne doit alors compter dans aucun score.
                if weight.profile_type_id is None:
                    continue
                profile_scores[weight.profile_type_id] = (
                    profile_scores.get(weight.profile_type_id, 0) + weight.weight
                )

        answers_data.append({
            "question_id": question.id,
            "question_text": question.text,
            "answers": question_answers_data,
        })

    return profile_scores, answers_data


def resolve_prospect(form, request):
    """
    Retourne le Prospect à rattacher au résultat.

    Une fiche dont l'email a été vérifié n'est jamais réutilisée par un tiers
    saisissant la même adresse : on crée alors une fiche distincte, non
    vérifiée, pour ne pas polluer la fiche du titulaire légitime.
    """
    email = form.cleaned_data["email"]
    existing = Prospect.objects.filter(email__iexact=email).order_by("id").first()

    if existing is None or existing.email_verified:
        return Prospect.objects.create(
            firstname=form.cleaned_data["firstname"],
            lastname=form.cleaned_data["lastname"],
            email=email,
            phone=form.cleaned_data["phone"],
        )

    # Fiche non vérifiée : on complète les champs restés vides, sans écraser.
    updated = []
    for field in ("firstname", "lastname", "phone"):
        if not getattr(existing, field) and form.cleaned_data.get(field):
            setattr(existing, field, form.cleaned_data[field])
            updated.append(field)
    if updated:
        existing.save(update_fields=updated)
    return existing


def record_consent(form, request, test):
    """Trace le consentement RGPD recueilli avec les coordonnées."""
    try:
        from jeiko.users.models import Consent, ConsentType
    except ImportError:
        return

    source = f"questionnaire:{test.slug}"
    Consent.objects.create(
        user=request.user if request.user.is_authenticated else None,
        anonymous_key=(request.session.session_key or "")[:64],
        consent_type=ConsentType.PRIVACY,
        granted=True,
        ip_address=request.META.get("REMOTE_ADDR") or None,
        source=source,
    )
    if form.cleaned_data.get("marketing_optin"):
        Consent.objects.create(
            user=request.user if request.user.is_authenticated else None,
            anonymous_key=(request.session.session_key or "")[:64],
            consent_type=ConsentType.MARKETING,
            granted=True,
            ip_address=request.META.get("REMOTE_ADDR") or None,
            source=source,
        )
    if form.cleaned_data.get("contact_optin"):
        Consent.objects.create(
            user=request.user if request.user.is_authenticated else None,
            anonymous_key=(request.session.session_key or "")[:64],
            consent_type=ConsentType.CONTACT,
            granted=True,
            ip_address=request.META.get("REMOTE_ADDR") or None,
            source=source,
        )


@method_decorator(never_cache, name='dispatch')
class ExpertTestResultInputView(ExpertTestAccessMixin, View):

    def incomplete_redirect(self, request, slug):
        """
        Renvoie à la première question sans réponse plutôt qu'à l'introduction :
        le visiteur ne perd pas ce qu'il a déjà saisi.
        """
        position = first_unanswered_position(request, self.test)
        if position is None:
            return None
        return redirect(
            "jeiko_client_questionnaires_expert:test_question",
            slug=slug, position=position,
        )

    @method_decorator(never_cache)
    def get(self, request, slug):
        incomplete = self.incomplete_redirect(request, slug)
        if incomplete:
            return incomplete

        return render(
            request,
            "questionnaires_expert_client/prospect_form.html",
            {
                "test": self.test,
                "form": ProspectForm(),
                "user_is_authenticated": request.user.is_authenticated,
            }
        )

    @method_decorator(never_cache)
    def post(self, request, slug):
        test = self.test

        # Le POST est aussi un point d'entrée : la complétude doit y être
        # vérifiée, sinon un envoi direct enregistrait un résultat vide.
        incomplete = self.incomplete_redirect(request, slug)
        if incomplete:
            return incomplete

        form = None
        if not request.user.is_authenticated:
            form = ProspectForm(request.POST)
            if not form.is_valid():
                return render(
                    request,
                    "questionnaires_expert_client/prospect_form.html",
                    {"test": test, "form": form, "user_is_authenticated": False},
                )

        answers = get_session_answers(request, test)
        profile_scores, answers_data = score_session_answers(test, answers)

        simple_profiles = ExpertProfileType.objects.filter(test=test, is_complex=False)
        score_list = []
        for p in simple_profiles:
            score_list.append({
                "profile_id": p.id,
                "slug": p.slug,
                "name": p.name,
                "score": profile_scores.get(p.id, 0),
                "color": p.color,
            })

        total_score = compute_total_score(test, profile_scores)
        result_profile, preferred, alternative = resolve_profiles(test, profile_scores)

        result_block = {
            "dominant": {
                "id": result_profile.id if result_profile else None,
                "slug": result_profile.slug if result_profile else None,
                "name": result_profile.name if result_profile else None
            } if result_profile else None,
            "preferred": {
                "id": preferred.id if preferred else None,
                "slug": preferred.slug if preferred else None,
                "name": preferred.name if preferred else None
            } if preferred else None,
            "alternative": {
                "id": alternative.id if alternative else None,
                "slug": alternative.slug if alternative else None,
                "name": alternative.name if alternative else None
            } if alternative else None,
        }

        test_data = ExpertTestData.objects.create(
            user=request.user if request.user.is_authenticated else None,
            prospect=None,
            test=test,
            result_profile=result_profile,
            preferred_profile=preferred,
            alternative_profile=alternative,
            data={
                "test_id": test.id,
                "test_title": test.title,
                "results": result_block,
                "scores": score_list,
                "answers": answers_data,
                "total_score": total_score,  # Ajout au JSON, utile à l’affichage
            }
        )

        if form is not None:
            test_data.prospect = resolve_prospect(form, request)
            test_data.save()
            record_consent(form, request, test)

        # Emails : le lien de résultat au visiteur, la notification à l'équipe.
        # Envoyés après COMMIT — le visiteur n'attend pas le serveur SMTP, et on
        # n'envoie pas de lien vers un résultat qu'une transaction annulée aurait
        # fait disparaître. Les deux helpers renvoient (success, error) au lieu
        # de lever : un échec d'envoi ne doit pas coûter son résultat au visiteur.
        transaction.on_commit(lambda: send_test_result_email(test_data, request))
        transaction.on_commit(lambda: send_admin_test_notification(test_data, request))

        clear_session_answers(request, test)

        return redirect("jeiko_client_questionnaires_expert:test_result_token", token=test_data.public_token)


EMPTY_CHART_JSON = '{"labels":[],"datasets":[]}'


def build_chart_json(test_data):
    """Sérialise les scores d'un résultat pour le canvas, ou un graphe vide."""
    scores = (test_data.data or {}).get("scores") if test_data else None
    if not scores:
        return mark_safe(EMPTY_CHART_JSON)

    chart_data = {
        "labels": [s["name"] for s in scores],
        "datasets": [{
            "label": test_data.test.title,
            "data": [float(s["score"]) for s in scores],
            "backgroundColor": [s.get("color") or "#cccccc" for s in scores],
        }]
    }
    return mark_safe(json.dumps(chart_data, ensure_ascii=False))


@method_decorator(never_cache, name='dispatch')
class ExpertTestResultTokenView(TemplateView):
    """
    Page de résultat personnelle : le jeton de l'URL désigne le ExpertTestData
    et vaut autorisation. C'est cette vue qui affiche les scores du visiteur ;
    le lien envoyé par email pointe ici.
    """
    template_name = 'pages/main.html'

    def confirm_email_if_requested(self, test_data):
        """
        Marque l'email du prospect comme vérifié si l'URL porte la signature
        présente uniquement dans le message envoyé à cette adresse.
        """
        signature = self.request.GET.get("c")
        prospect = test_data.prospect
        if not signature or prospect is None or prospect.email_verified:
            return
        if test_data.check_confirmation_token(signature):
            prospect.email_verified = True
            prospect.save(update_fields=["email_verified"])

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        test_data = get_object_or_404(
            ExpertTestData.objects.select_related("test", "result_profile", "prospect"),
            public_token=self.kwargs["token"],
        )
        self.confirm_email_if_requested(test_data)
        profile = test_data.result_profile

        context["test_data"] = test_data
        context["test"] = test_data.test
        context["profile"] = profile
        context["page"] = profile.result_page if profile else None
        context["chart_id"] = f"res-{test_data.pk}"
        context["chart_data_json"] = build_chart_json(test_data)
        context["show_chart"] = True
        return context


@method_decorator(never_cache, name='dispatch')
class ExpertTestResultView(ExpertTestAccessMixin, TemplateView):
    """
    Page de présentation d'un profil, sans données personnelles.

    Conservée pour les liens existants. Le résultat chiffré d'un visiteur n'est
    consultable que via ExpertTestResultTokenView : cette vue ne doit jamais
    afficher les scores d'un passage, car rien ici n'identifie le visiteur.
    """
    template_name = 'pages/main.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profile = get_object_or_404(
            ExpertProfileType, slug=self.kwargs.get("result_slug"), test=self.test
        )

        context["profile"] = profile
        context["test"] = self.test
        context["page"] = profile.result_page
        context["chart_id"] = f"res-{profile.id}"
        context["chart_data_json"] = mark_safe(EMPTY_CHART_JSON)
        context["show_chart"] = False
        return context


