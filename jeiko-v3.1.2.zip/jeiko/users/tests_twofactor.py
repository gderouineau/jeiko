"""
Second facteur par e-mail, journal de sécurité, sessions.

Le sujet de ces tests n'est pas « le code fonctionne » mais « la connexion est
réellement bloquée tant que le code n'est pas fourni ». C'est exactement ce qui
manquait : les écrans existaient, la vérification non.
"""

from django.contrib.auth import get_user_model
from django.core import mail
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from jeiko.users import twofactor
from jeiko.users.models import (
    SecurityEvent,
    SecurityEventType,
    TwoFactorDevice,
    TwoFactorType,
    UserSession,
)

User = get_user_model()
LOCMEM = "django.core.mail.backends.locmem.EmailBackend"


class DecorMail(TestCase):
    """`emailing.sending` refuse tout envoi sans MailSettings active."""

    def setUp(self):
        from jeiko.administration.models import MailSettings, WebSite

        twofactor_reset()
        site = WebSite.objects.first()
        if site is not None:
            site.mail_settings = MailSettings.objects.create(
                host="localhost", port=587, active=True,
                default_from_email="site@exemple.test",
            )
            site.save(update_fields=["mail_settings"])

        self.user = User.objects.create_user(
            "camille", "camille@exemple.test", "motdepasse-solide-1"
        )
        mail.outbox = []

    def activer_2fa(self):
        return TwoFactorDevice.objects.create(
            user=self.user, device_type=TwoFactorType.EMAIL,
            is_active=True, confirmed_at=timezone.now(),
        )

    def connexion(self):
        return self.client.post(
            reverse("account_login"),
            {"login": "camille", "password": "motdepasse-solide-1"},
        )


def twofactor_reset():
    from jeiko.throttling import reset_counters
    reset_counters()


@override_settings(EMAIL_BACKEND=LOCMEM)
class SansSecondFacteurTests(DecorMail):
    def test_la_connexion_ordinaire_reste_directe(self):
        self.connexion()
        self.assertTrue(self.client.session.get("_auth_user_id"))


@override_settings(EMAIL_BACKEND=LOCMEM)
class AvecSecondFacteurTests(DecorMail):
    def setUp(self):
        super().setUp()
        self.device = self.activer_2fa()

    def test_le_mot_de_passe_seul_n_ouvre_pas_la_session(self):
        self.connexion()
        self.assertIsNone(
            self.client.session.get("_auth_user_id"),
            "Le mot de passe seul a suffi : le second facteur ne sert à rien.",
        )

    def test_un_code_est_envoye(self):
        self.connexion()
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("camille@exemple.test", mail.outbox[0].to)

    def test_le_code_n_est_pas_stocke_en_clair(self):
        self.connexion()
        self.device.refresh_from_db()
        self.assertTrue(self.device.challenge_hash)
        # Une empreinte Django est préfixée par son algorithme.
        self.assertIn("$", self.device.challenge_hash)

    def test_le_bon_code_ouvre_la_session(self):
        self.connexion()
        code = twofactor.issue_code(self.device)  # code maîtrisé par le test
        self.client.post(reverse("jeiko_allauth:twofa_verify"), {"code": code})
        self.assertTrue(self.client.session.get("_auth_user_id"))

    def test_un_mauvais_code_n_ouvre_rien(self):
        self.connexion()
        twofactor.issue_code(self.device)
        reponse = self.client.post(
            reverse("jeiko_allauth:twofa_verify"), {"code": "000000"}
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertIsNone(self.client.session.get("_auth_user_id"))

    def test_le_code_ne_sert_qu_une_fois(self):
        self.connexion()
        code = twofactor.issue_code(self.device)
        self.client.post(reverse("jeiko_allauth:twofa_verify"), {"code": code})
        self.client.logout()

        self.connexion()
        self.client.post(reverse("jeiko_allauth:twofa_verify"), {"code": code})
        self.assertIsNone(self.client.session.get("_auth_user_id"))

    def test_un_code_expire_est_refuse(self):
        self.connexion()
        code = twofactor.issue_code(self.device)
        TwoFactorDevice.objects.filter(pk=self.device.pk).update(
            challenge_expires_at=timezone.now() - timezone.timedelta(minutes=1)
        )
        self.client.post(reverse("jeiko_allauth:twofa_verify"), {"code": code})
        self.assertIsNone(self.client.session.get("_auth_user_id"))

    def test_les_essais_sont_bornes(self):
        self.connexion()
        code = twofactor.issue_code(self.device)
        for _ in range(twofactor.MAX_ATTEMPTS + 1):
            self.client.post(
                reverse("jeiko_allauth:twofa_verify"), {"code": "111111"}
            )
        # Le bon code ne doit plus passer : le défi a été brûlé.
        self.client.post(reverse("jeiko_allauth:twofa_verify"), {"code": code})
        self.assertIsNone(self.client.session.get("_auth_user_id"))

    def test_l_ecran_de_saisie_ne_designe_pas_le_compte(self):
        """Rien dans l'URL ni le formulaire ne doit nommer l'utilisateur."""
        self.connexion()
        page = self.client.get(reverse("jeiko_allauth:twofa_verify"))
        self.assertNotContains(page, "camille@exemple.test")
        self.assertContains(page, "@exemple.test")  # adresse masquée

    def test_sans_attente_en_session_on_repart_a_la_connexion(self):
        page = self.client.get(reverse("jeiko_allauth:twofa_verify"))
        self.assertEqual(page.status_code, 302)

    def test_un_code_de_secours_fonctionne(self):
        codes = twofactor.generate_backup_codes(self.device, nombre=2)
        self.connexion()
        self.client.post(
            reverse("jeiko_allauth:twofa_verify"), {"code": codes[0]}
        )
        self.assertTrue(self.client.session.get("_auth_user_id"))

    def test_un_code_de_secours_ne_sert_qu_une_fois(self):
        codes = twofactor.generate_backup_codes(self.device, nombre=2)
        self.connexion()
        self.client.post(reverse("jeiko_allauth:twofa_verify"), {"code": codes[0]})
        self.client.logout()

        self.connexion()
        self.client.post(reverse("jeiko_allauth:twofa_verify"), {"code": codes[0]})
        self.assertIsNone(self.client.session.get("_auth_user_id"))

    def test_un_dispositif_totp_est_ignore(self):
        """Aucun code ne l'honore : mieux vaut ne pas bloquer sur du vide."""
        self.device.device_type = TwoFactorType.TOTP
        self.device.save(update_fields=["device_type"])
        self.connexion()
        self.assertTrue(self.client.session.get("_auth_user_id"))


@override_settings(EMAIL_BACKEND=LOCMEM)
class JournalEtSessionsTests(DecorMail):
    def test_la_connexion_est_journalisee(self):
        self.connexion()
        self.assertTrue(
            SecurityEvent.objects.filter(
                user=self.user, event_type=SecurityEventType.LOGIN_SUCCESS
            ).exists()
        )

    def test_un_echec_est_journalise(self):
        self.client.post(
            reverse("account_login"),
            {"login": "camille", "password": "faux"},
        )
        self.assertTrue(
            SecurityEvent.objects.filter(
                event_type=SecurityEventType.LOGIN_FAILURE
            ).exists()
        )

    def test_la_session_est_enregistree(self):
        self.connexion()
        self.assertTrue(UserSession.objects.filter(user=self.user).exists())

    def test_la_cle_de_session_n_est_pas_stockee_en_clair(self):
        self.connexion()
        ligne = UserSession.objects.get(user=self.user)
        self.assertNotEqual(ligne.session_key_hash, self.client.session.session_key)
        self.assertEqual(len(ligne.session_key_hash), 64)  # sha256 hexadécimal

    def test_la_revocation_ferme_reellement_la_session(self):
        from django.contrib.sessions.models import Session

        from jeiko.users.security_log import revoke_sessions

        self.connexion()
        ligne = UserSession.objects.get(user=self.user)
        cle = self.client.session.session_key
        self.assertTrue(Session.objects.filter(session_key=cle).exists())

        revoke_sessions([ligne.id])
        self.assertFalse(
            Session.objects.filter(session_key=cle).exists(),
            "La session est restée valide : « déconnecter partout » ne "
            "déconnecte rien.",
        )


@override_settings(EMAIL_BACKEND=LOCMEM)
class DesactiveParDefautTests(DecorMail):
    """
    Garantie structurante : sans action explicite, aucun compte n'est protégé.

    Si la 2FA s'activait d'elle-même — par défaut de modèle, par migration ou
    par signal — personne ne pourrait se connecter la première fois, et un
    déploiement enfermerait tout le monde dehors.
    """

    def test_un_compte_neuf_n_a_pas_de_second_facteur(self):
        nouveau = User.objects.create_user("neuf", "neuf@exemple.test", "mdp")
        self.assertFalse(twofactor.user_requires_2fa(nouveau))
        self.assertEqual(TwoFactorDevice.objects.filter(user=nouveau).count(), 0)

    def test_aucun_dispositif_n_existe_apres_les_migrations(self):
        self.assertEqual(TwoFactorDevice.objects.count(), 0)

    def test_le_compte_neuf_se_connecte_directement(self):
        User.objects.create_user("neuf", "neuf@exemple.test", "motdepasse-solide-1")
        self.client.post(
            reverse("account_login"),
            {"login": "neuf", "password": "motdepasse-solide-1"},
        )
        self.assertTrue(self.client.session.get("_auth_user_id"))


@override_settings(EMAIL_BACKEND=LOCMEM)
class SelfServiceTests(DecorMail):
    """Activation et désactivation par l'utilisateur lui-même."""

    def setUp(self):
        super().setUp()
        self.client.force_login(self.user)
        self.url = reverse("jeiko_users_client:profile-twofa")

    def test_activation(self):
        self.client.post(self.url, {"action": "enable",
                                    "password": "motdepasse-solide-1"})
        self.assertTrue(twofactor.user_requires_2fa(self.user))

    def test_l_activation_exige_le_mot_de_passe(self):
        """Une session détournée ne doit pas pouvoir armer la protection."""
        self.client.post(self.url, {"action": "enable", "password": "faux"})
        self.assertFalse(twofactor.user_requires_2fa(self.user))

    def test_la_desactivation_exige_le_mot_de_passe(self):
        self.activer_2fa()
        self.client.post(self.url, {"action": "disable", "password": "faux"})
        self.assertTrue(
            twofactor.user_requires_2fa(self.user),
            "La protection a sauté sans mot de passe : une session volée "
            "suffirait à la retirer.",
        )

    def test_desactivation(self):
        self.activer_2fa()
        self.client.post(self.url, {"action": "disable",
                                    "password": "motdepasse-solide-1"})
        self.assertFalse(twofactor.user_requires_2fa(self.user))

    def test_des_codes_de_secours_sont_remis_a_l_activation(self):
        self.client.post(self.url, {"action": "enable",
                                    "password": "motdepasse-solide-1"})
        page = self.client.get(reverse("jeiko_users_client:profile-detail"))
        self.assertContains(page, "codes de secours")

    def test_les_changements_sont_journalises(self):
        self.client.post(self.url, {"action": "enable",
                                    "password": "motdepasse-solide-1"})
        self.assertTrue(
            SecurityEvent.objects.filter(
                user=self.user, event_type=SecurityEventType.TWOFA_ENABLED
            ).exists()
        )

    def test_un_anonyme_ne_peut_rien_activer(self):
        self.client.logout()
        reponse = self.client.post(self.url, {"action": "enable",
                                              "password": "motdepasse-solide-1"})
        self.assertEqual(reponse.status_code, 302)
        self.assertFalse(twofactor.user_requires_2fa(self.user))
