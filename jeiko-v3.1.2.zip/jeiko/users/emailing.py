# jeiko/users/emailing.py
"""
E-mails du module « Compte & sécurité ».

Ce fichier ne compose aucun message : il traduit un utilisateur (et le contexte
de la requête) en variables de catalogue, puis délègue à
`jeiko.emailing.services.send_email`, où sujets et mises en page restent
éditables en back-office. Aucune fonction ne lève : un e-mail qui ne part pas ne
doit jamais faire échouer une inscription, une réinitialisation ou une action
d'administration.

Les envois sont déclenchés :
  - par l'adaptateur allauth pour les mails d'action porteurs d'un lien
    (réinitialisation, vérification / changement d'adresse) — voir `adapters.py` ;
  - par les signaux allauth pour les notifications de sécurité
    (bienvenue, mot de passe modifié, alerte de changement d'adresse) — voir
    `signals.py` ;
  - par la fiche utilisateur de l'administration pour la désactivation de compte.

Codes utilisés — account_welcome, account_email_verify, password_reset_request,
password_changed, email_change_confirm, email_changed_alert, account_deactivated.
"""

import logging

from django.conf import settings
from django.urls import NoReverseMatch, reverse
from django.utils import timezone

from allauth.account import app_settings as allauth_settings

from jeiko.emailing.render import site_base_url
from jeiko.emailing.services import send_email

logger = logging.getLogger(__name__)


# =========================
#  Helpers de contexte
# =========================

def _now_label():
    """Date et heure locales, format lisible pour un e-mail."""
    return timezone.localtime().strftime("%d/%m/%Y à %H:%M")


def _client_ip(request):
    if request is None:
        return "—"
    forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR") or "—"


def _device_label(request):
    """Étiquette lisible d'après le User-Agent, sans dépendance externe."""
    if request is None:
        return "—"
    ua = request.META.get("HTTP_USER_AGENT", "") or ""
    if not ua:
        return "—"

    browser = "Navigateur inconnu"
    for needle, label in (
        ("Edg", "Edge"), ("OPR", "Opera"), ("Chrome", "Chrome"),
        ("Firefox", "Firefox"), ("Safari", "Safari"),
    ):
        if needle in ua:
            browser = label
            break

    system = ""
    for needle, label in (
        ("Windows", "Windows"), ("iPhone", "iPhone"), ("iPad", "iPad"),
        ("Android", "Android"), ("Mac OS", "macOS"), ("Linux", "Linux"),
    ):
        if needle in ua:
            system = label
            break

    return f"{browser} sur {system}" if system else browser


def _absolute_url(request, url_name):
    """URL absolue vers une vue nommée, avec repli hors requête."""
    try:
        path = reverse(url_name)
    except NoReverseMatch:
        path = "/"
    if request is not None:
        return request.build_absolute_uri(path)
    return f"{site_base_url().rstrip('/')}{path}"


def _days_label(days):
    days = int(days or 0)
    if days <= 0:
        return "24 heures"
    if days == 1:
        return "24 heures"
    return f"{days} jours"


def _reset_expiration():
    """Durée de validité d'un lien de réinitialisation (réglage Django)."""
    seconds = getattr(settings, "PASSWORD_RESET_TIMEOUT", 259200)
    return _days_label(round(seconds / 86400))


def _confirm_expiration():
    """Durée de validité d'un lien de confirmation d'adresse (réglage allauth)."""
    return _days_label(allauth_settings.EMAIL_CONFIRMATION_EXPIRE_DAYS)


# =========================
#  Mails d'action (adaptateur allauth)
# =========================

def send_password_reset(user, email, url, request=None):
    """Lien de réinitialisation du mot de passe."""
    send_email(
        "password_reset_request",
        email,
        {
            "lien_action": url,
            "expiration": _reset_expiration(),
            "ip": _client_ip(request),
        },
        user=user,
    )


def send_email_verification(user, email, url):
    """Vérification de l'adresse à l'inscription (si la vérification est active)."""
    send_email(
        "account_email_verify",
        email,
        {
            "lien_action": url,
            "expiration": _confirm_expiration(),
        },
        user=user,
    )


def send_email_change_confirm(user, new_email, url):
    """Confirmation envoyée à la NOUVELLE adresse demandée."""
    send_email(
        "email_change_confirm",
        new_email,
        {
            "lien_action": url,
            "nouvel_email": new_email,
            "expiration": _confirm_expiration(),
        },
        user=user,
    )


# =========================
#  Notifications de sécurité (signaux allauth)
# =========================

def send_welcome(user, request=None):
    """Bienvenue, après la validation de l'inscription."""
    if not getattr(user, "email", None):
        return
    send_email(
        "account_welcome",
        user.email,
        {"lien_action": _absolute_url(request, "jeiko_users:profile-detail")},
        user=user,
    )


def notify_password_changed(user, request=None):
    """Notification de sécurité : le mot de passe vient d'être modifié."""
    if not getattr(user, "email", None):
        return
    send_email(
        "password_changed",
        user.email,
        {
            "date_heure": _now_label(),
            "ip": _client_ip(request),
            "appareil": _device_label(request),
        },
        user=user,
    )


def notify_email_changed(user, from_email, to_email, request=None):
    """Alerte envoyée à l'ANCIENNE adresse pour signaler le changement."""
    if not from_email:
        return
    send_email(
        "email_changed_alert",
        from_email,
        {
            "nouvel_email": to_email,
            "date_heure": _now_label(),
        },
        user=user,
    )


# =========================
#  Administration
# =========================

def notify_account_deactivated(user):
    """Confirmation envoyée à l'utilisateur dont le compte vient d'être désactivé."""
    if not getattr(user, "email", None):
        return
    send_email(
        "account_deactivated",
        user.email,
        {"date_heure": _now_label()},
        user=user,
    )


def _set_password_url(user, request=None):
    """
    Lien « définir mon mot de passe » pour un compte créé par l'administration.

    Réutilise EXACTEMENT le mécanisme de réinitialisation d'allauth (même
    générateur de jeton, même vue « reset from key ») : l'utilisateur arrive sur
    l'écran de choix de mot de passe, sans qu'on ait eu à lui en attribuer un.
    """
    from allauth.account.adapter import get_adapter
    from allauth.account.forms import default_token_generator
    from allauth.account.utils import user_pk_to_url_str

    temp_key = default_token_generator.make_token(user)
    uid = user_pk_to_url_str(user)
    key = f"{uid}-{temp_key}"
    return get_adapter(request).get_reset_password_from_key_url(key)


def send_account_created_by_admin(user, request=None):
    """
    Prévient un utilisateur qu'un compte vient d'être créé pour lui en
    administration, avec le lien pour définir son mot de passe.
    """
    if not getattr(user, "email", None):
        return
    try:
        url = _set_password_url(user, request)
    except Exception:
        logger.exception("Lien de définition du mot de passe indisponible (user=%s)", user.pk)
        return
    send_email(
        "account_created_by_admin",
        user.email,
        {
            "lien_action": url,
            "expiration": _reset_expiration(),
        },
        user=user,
    )


def send_twofa_state_changed(user, *, enabled):
    """
    Prévient l'utilisateur que la vérification en deux étapes vient d'être
    activée ou désactivée sur son compte.

    C'est une notification de sécurité, pas une confirmation de confort : si
    quelqu'un d'autre désactive la protection, le titulaire doit l'apprendre
    même s'il n'a rien demandé. On n'échoue donc jamais silencieusement sur
    l'absence d'adresse — on le journalise.
    """
    destinataire = (getattr(user, "email", "") or "").strip()
    if not destinataire:
        logger.warning(
            "Changement d'état 2FA non notifié : le compte %s n'a pas d'adresse.",
            getattr(user, "pk", None),
        )
        return

    send_email(
        "twofa_enabled" if enabled else "twofa_disabled",
        destinataire,
        {},
        user=user,
    )
