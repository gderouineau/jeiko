from django.contrib.auth.decorators import permission_required
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.cache import cache
from django.http import Http404
from django.shortcuts import render, redirect, get_object_or_404

from django.views import View
from django.views.generic.base import TemplateView

from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache

from django.db import transaction, IntegrityError
from django.db.models import Case, When, Value, IntegerField
from django.core.cache import cache
from django.db import IntegrityError
from django.core.exceptions import ValidationError

from jeiko.administration_menu.forms import (
    MenuItemForm, MenuForm, MenuStyleForm
)
from jeiko.administration_menu.models import (
    Menu, MenuItem, MenuPlace, MenuLayout, MenuStyle
)
from jeiko.administration_menu.models import _invalidate_menu_cache_by_ids

from jeiko.administration.models import Logo

from jeiko.administration.models import WebSite


decorators = [never_cache]


class MenuAdminAccessMixin(LoginRequiredMixin, PermissionRequiredMixin):
    """
    Gestion des menus = configuration du site. Réservée aux profils disposant
    de la permission « Modifier la configuration du site ».
    """
    permission_required = "users.config_edit_site"
    raise_exception = True


@method_decorator(never_cache, name='dispatch')
class Main(MenuAdminAccessMixin, View):

    template_name = 'administration_menu/main.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        menu_items_up = MenuItem.objects.filter(
            is_sub_menu=False,
            place="U",
        )
        menu_items_down = MenuItem.objects.filter(
            is_sub_menu=False,
            place="D",
        )

        context = {
            'menu_items_up': menu_items_up,
            'menu_items_down': menu_items_down,
            # Regroupement pour un rendu homogène (haut / bas).
            'menu_groups': [
                {'label': 'Menu du haut', 'place': 'U', 'items': menu_items_up},
                {'label': 'Menu du bas (footer)', 'place': 'D', 'items': menu_items_down},
            ],
        }

        return render(request, self.template_name, context)


@method_decorator(never_cache, name='dispatch')
class All(MenuAdminAccessMixin, View):

    template_name = 'administration_menu/view.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        place = kwargs['place']

        menu_items = MenuItem.objects.filter(
            place=place,
            is_sub_menu=False,

        )

        context = {
            'place': place,
            'menu_items': menu_items,
        }

        return render(request, self.template_name, context)


@method_decorator(never_cache, name='dispatch')
class MenuList(MenuAdminAccessMixin, View):
    template_name = 'administration_menu/menu/list.html'

    def get(self, request):
        # Ordre des emplacements: MAIN, FOOTER, puis NULL
        place_order = Case(
            When(place=MenuPlace.MAIN, then=Value(0)),
            When(place=MenuPlace.FOOTER, then=Value(1)),
            default=Value(2),
            output_field=IntegerField(),
        )
        # Par défaut d’abord (is_default=True)
        default_first = Case(
            When(is_default=True, then=Value(0)),
            default=Value(1),
            output_field=IntegerField(),
        )

        menus = (
            Menu.objects
            .select_related('menu_style')
            .annotate(_place_order=place_order, _default_first=default_first)
            .order_by('_place_order', '_default_first', 'name')
        )

        ctx = {
            'menus': menus,
            # Within each place: defaults first, then alpha
            'menus_main': Menu.objects.filter(place=MenuPlace.MAIN).order_by('-is_default', 'name'),
            'menus_footer': Menu.objects.filter(place=MenuPlace.FOOTER).order_by('-is_default', 'name'),
            'menus_neutral': Menu.objects.filter(place=MenuPlace.NULL).order_by('-is_default', 'name'),
        }
        return render(request, self.template_name, ctx)


@method_decorator(never_cache, name='dispatch')
class MenuDetail(MenuAdminAccessMixin, View):
    """
    Détail d’un menu : montre les items top-level + leurs sous-menus
    """
    template_name = 'administration_menu/menu/view.html'

    def get(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        items = (
            MenuItem.objects
            .filter(menu=menu, main_menu__isnull=True)
            .order_by('position', 'pk')
            .prefetch_related('submenus')
        )
        ctx = {
            'menu': menu,
            'items': items,
        }
        return render(request, self.template_name, ctx)


def _invalidate_menu_cache(menu: Menu):
    # Invalidation ciblée (évite cache.clear()). On délègue au helper du modèle
    # pour garder une seule source de vérité sur les clés réellement écrites
    # (menu:render:<id>, menu:place:<place>:generic).
    _invalidate_menu_cache_by_ids(menu_id=menu.pk, place=menu.place)


@method_decorator(never_cache, name='dispatch')
class MenuCreate(MenuAdminAccessMixin, View):
    template_name = 'administration_menu/menu/form.html'
    form_class = MenuForm
    style_form_class = MenuStyleForm

    def get(self, request):
        form = self.form_class()
        style_form = self.style_form_class()
        return render(
            request,
            self.template_name,
            {
                'form': form,
                'style_form': style_form,
                'update': False,
                'submit_text': 'Créer',
                'website_data': WebSite.objects.first(),
            },
        )

    def post(self, request):
        # IMPORTANT: inclure request.FILES pour capter le nouveau logo
        form = self.form_class(request.POST, request.FILES)
        style_form = self.style_form_class(request.POST)

        if form.is_valid() and style_form.is_valid():
            try:
                with transaction.atomic():
                    style = style_form.save()  # crée le style
                    menu = form.save(commit=False)
                    menu.menu_style = style

                    # Si un nouveau logo est uploadé, il prend le dessus
                    new_logo_file = form.cleaned_data.get("new_logo_full_size")
                    if new_logo_file:
                        logo = Logo(full_size=new_logo_file)
                        logo.save()  # génère les variantes via le .save() custom
                        menu.logo = logo
                        # NB: si un logo était sélectionné dans la liste, il est ignoré au profit du nouvel upload

                    menu.save()

                # Invalidate cache si helper dispo
                try:
                    _invalidate_menu_cache(menu)
                except Exception:
                    pass

                return redirect('jeiko_administration_menu:menu_list')

            except IntegrityError as e:
                msg = str(e)
                if "uniq_default_menu_main" in msg:
                    form.add_error('is_default', "Un menu par défaut pour MAIN existe déjà.")
                elif "uniq_default_menu_footer" in msg:
                    form.add_error('is_default', "Un menu par défaut pour FOOTER existe déjà.")
                elif "menu_layout_required_for_main_only" in msg:
                    form.add_error('layout', "Incohérence place/layout : MAIN ⇒ layout requis, FOOTER/NULL ⇒ pas de layout.")
                else:
                    form.add_error(None, "Contrainte de base de données violée.")

            except ValidationError as e:
                form.add_error(None, e)

        return render(
            request,
            self.template_name,
            {
                'form': form,
                'style_form': style_form,
                'update': False,
                'submit_text': 'Créer',
                'website_data': WebSite.objects.first(),
            },
        )


@method_decorator(never_cache, name='dispatch')
class MenuUpdate(MenuAdminAccessMixin, View):
    template_name = 'administration_menu/menu/form.html'
    form_class = MenuForm
    style_form_class = MenuStyleForm

    def get(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        form = self.form_class(instance=menu)
        style_form = self.style_form_class(instance=menu.menu_style or None)
        ctx = {
            'form': form,
            'style_form': style_form,
            'update': True,
            'menu': menu,
            'submit_text': 'Modifier',
            'website_data': WebSite.objects.first(),
        }
        return render(request, self.template_name, ctx)

    def post(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        # IMPORTANT: inclure request.FILES pour capter un nouveau logo
        form = self.form_class(request.POST, request.FILES, instance=menu)
        style_form = self.style_form_class(request.POST, instance=menu.menu_style or None)

        if form.is_valid() and style_form.is_valid():
            try:
                with transaction.atomic():
                    style = style_form.save()  # crée ou met à jour le style

                    menu_obj = form.save(commit=False)
                    if not menu_obj.menu_style_id:
                        menu_obj.menu_style = style

                    # Nouveau logo uploadé ? -> prioritaire
                    new_logo_file = form.cleaned_data.get("new_logo_full_size")
                    if new_logo_file:
                        logo = Logo(full_size=new_logo_file)
                        logo.save()
                        menu_obj.logo = logo
                        # NB: si un logo existant a été choisi dans la liste, il est supplanté par cet upload

                    menu_obj.save()

                try:
                    _invalidate_menu_cache(menu_obj)
                except Exception:
                    pass

                return redirect('jeiko_administration_menu:menu_list')

            except IntegrityError as e:
                msg = str(e)
                if "uniq_default_menu_main" in msg:
                    form.add_error('is_default', "Un menu par défaut pour MAIN existe déjà.")
                elif "uniq_default_menu_footer" in msg:
                    form.add_error('is_default', "Un menu par défaut pour FOOTER existe déjà.")
                elif "menu_layout_required_for_main_only" in msg:
                    form.add_error('layout', "Incohérence place/layout : MAIN ⇒ layout requis, FOOTER/NULL ⇒ pas de layout.")
                else:
                    form.add_error(None, "Contrainte de base de données violée.")
            except ValidationError as e:
                form.add_error(None, e)

        ctx = {
            'form': form,
            'style_form': style_form,
            'update': True,
            'menu': menu,
            'submit_text': 'Modifier',
            'website_data': WebSite.objects.first(),
        }
        return render(request, self.template_name, ctx)


@method_decorator(never_cache, name='dispatch')
class MenuDelete(MenuAdminAccessMixin, View):
    template_name = 'administration_menu/menu_confirm_delete.html'

    def get(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        return render(request, self.template_name, {'menu': menu})

    def post(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        menu.delete()
        return redirect('jeiko_administration_menu:menu_list')


# ========= CRÉATION / MÀJ / SUPPRESSION — ITEM TOP-LEVEL =========
@method_decorator(never_cache, name='dispatch')
class MenuItemCreate(MenuAdminAccessMixin, View):
    template_name = 'administration_menu/menu_item/form.html'
    form_class = MenuItemForm

    def get(self, request, menu_id):
        menu = get_object_or_404(Menu, pk=menu_id)
        instance = MenuItem(menu=menu, main_menu=None)
        form = self.form_class(prefix='menu_item_', instance=instance)
        return render(request, self.template_name, {
            'menu': menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })

    def post(self, request, menu_id):
        menu = get_object_or_404(Menu, pk=menu_id)
        instance = MenuItem(menu=menu, main_menu=None)
        form = self.form_class(request.POST, request.FILES, prefix='menu_item_', instance=instance)

        if form.is_valid():
            item = form.save(commit=False)
            try:
                item.save()  # full_clean() + position auto via save()
            except ValidationError as e:
                if hasattr(e, "message_dict"):
                    for field, msgs in e.message_dict.items():
                        for msg in msgs:
                            if field in form.fields:
                                form.add_error(field, msg)
                            else:
                                form.add_error(None, msg)
                else:
                    for msg in e.messages:
                        form.add_error(None, msg)

                return render(request, self.template_name, {
                    'menu': menu,
                    'form': form,
                    'update': False,
                    'submit_text': 'Créer',
                })

            return redirect('jeiko_administration_menu:menu_detail', pk=menu.pk)

        return render(request, self.template_name, {
            'menu': menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })



@method_decorator(never_cache, name='dispatch')
class MenuItemUpdate(MenuAdminAccessMixin, View):
    template_name = 'administration_menu/menu_item/form.html'
    form_class = MenuItemForm

    def get(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        form = self.form_class(instance=item, prefix='menu_item_')
        return render(request, self.template_name, {
            'menu': item.menu,
            'item': item,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        form = self.form_class(request.POST, instance=item, prefix='menu_item_')
        if form.is_valid():
            # on NE modifie PAS menu/main_menu ici
            form.save()
            return redirect('jeiko_administration_menu:menu_detail', pk=item.menu.pk)
        return render(request, self.template_name, {
            'menu': item.menu,
            'item': item,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })


@method_decorator(never_cache, name='dispatch')
class MenuItemDelete(MenuAdminAccessMixin, View):
    template_name = 'administration_menu/menu_item/confirm_delete.html'

    def get(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        return render(request, self.template_name, {'item': item, 'menu': item.menu})

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        item.delete()
        return redirect('jeiko_administration_menu:menu_detail', pk=item.menu.pk)


@method_decorator(never_cache, name='dispatch')
class MenuItemMoveUp(MenuAdminAccessMixin, View):

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        item.move_up()
        return redirect('jeiko_administration_menu:menu_detail', pk=item.menu_id)

    def get(self, request, pk):
        # fallback pratique pour les liens <a>, uniquement en admin
        return self.post(request, pk)


@method_decorator(never_cache, name='dispatch')
class MenuItemMoveDown(MenuAdminAccessMixin, View):

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        item.move_down()
        return redirect('jeiko_administration_menu:menu_detail', pk=item.menu_id)

    def get(self, request, pk):
        return self.post(request, pk)


# ========= CRÉATION / MÀJ / SUPPRESSION — SOUS-MENU =========
# ========= CRÉATION — SOUS-MENU =========
@method_decorator(never_cache, name='dispatch')
class SubMenuCreate(MenuAdminAccessMixin, View):
    template_name = 'administration_menu/menu_sub_item/form.html'
    form_class = MenuItemForm

    def get(self, request, parent_id):
        parent = get_object_or_404(MenuItem, pk=parent_id)
        # On pré-remplit l'instance avec le menu et le parent
        instance = MenuItem(menu=parent.menu, main_menu=parent)
        form = self.form_class(prefix='menu_item_', instance=instance)
        return render(request, self.template_name, {
            'parent': parent,
            'menu': parent.menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })

    def post(self, request, parent_id):
        parent = get_object_or_404(MenuItem, pk=parent_id)
        # Idem en POST : l'instance porte déjà menu & main_menu
        instance = MenuItem(menu=parent.menu, main_menu=parent)
        form = self.form_class(request.POST, request.FILES, prefix='menu_item_', instance=instance)

        if form.is_valid():
            sub = form.save(commit=False)
            # Optionnel: sub._assign_position_if_needed() (save() le fait déjà)
            try:
                sub.save()  # appelle full_clean() -> cohérence parent/menu vérifiée
            except ValidationError as e:
                # Réinjecte proprement les erreurs éventuelles
                if hasattr(e, "message_dict"):
                    for field, msgs in e.message_dict.items():
                        for msg in msgs:
                            if field in form.fields:
                                form.add_error(field, msg)
                            else:
                                form.add_error(None, msg)
                else:
                    for msg in e.messages:
                        form.add_error(None, msg)

                return render(request, self.template_name, {
                    'parent': parent,
                    'menu': parent.menu,
                    'form': form,
                    'update': False,
                    'submit_text': 'Créer',
                })

            return redirect('jeiko_administration_menu:menu_detail', pk=parent.menu_id)

        return render(request, self.template_name, {
            'parent': parent,
            'menu': parent.menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })



@method_decorator(never_cache, name='dispatch')
class SubMenuUpdate(MenuAdminAccessMixin, View):
    template_name = 'administration_menu/menu_sub_item/form.html'
    form_class = MenuItemForm

    def get(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        if not sub.main_menu_id:
            return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

        form = self.form_class(instance=sub, prefix='menu_item_')
        return render(request, self.template_name, {
            'parent': sub.main_menu,
            'menu': sub.menu,
            'sub': sub,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })

    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        if not sub.main_menu_id:
            return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

        form = self.form_class(request.POST, instance=sub, prefix='menu_item_')
        if form.is_valid():
            sub = form.save(commit=False)

            sub.menu_id = sub.menu_id
            sub.main_menu_id = sub.main_menu_id
            try:
                sub.full_clean()
                sub.save()
            except ValidationError as e:
                form.add_error(None, e.messages)
                return render(request, self.template_name, {
                    'parent': sub.main_menu,
                    'menu': sub.menu,
                    'sub': sub,
                    'form': form,
                    'update': True,
                    'submit_text': 'Modifier',
                })

            return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

        return render(request, self.template_name, {
            'parent': sub.main_menu,
            'menu': sub.menu,
            'sub': sub,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })


@method_decorator(never_cache, name='dispatch')
class SubMenuDelete(MenuAdminAccessMixin, View):
    template_name = 'administration_menu/menu_sub_item/confirm_delete.html'

    def get(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        return render(request, self.template_name, {
            'sub': sub,
            'menu': sub.menu,
            'parent': sub.main_menu
        })

    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        menu_id = sub.menu_id
        sub.delete()
        return redirect('jeiko_administration_menu:menu_detail', pk=menu_id)


@method_decorator(never_cache, name='dispatch')
class SubMenuMoveUp(MenuAdminAccessMixin, View):
    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        sub.move_up()
        return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

    def get(self, request, pk):
        # fallback pratique pour les liens <a> en admin
        return self.post(request, pk)


@method_decorator(never_cache, name='dispatch')
class SubMenuMoveDown(MenuAdminAccessMixin, View):
    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        sub.move_down()
        return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

    def get(self, request, pk):
        return self.post(request, pk)

