# stats/middleware.py
import logging
import re
import uuid
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from django.conf import settings
from django.db import connections
from django.utils import timezone
from django.urls import reverse, NoReverseMatch
from .models import PageView

logger = logging.getLogger("jeiko.stats")

# Pool dédié à l'écriture des vues de page hors du chemin de réponse. Deux
# threads suffisent : un INSERT est court, et on ne veut pas ouvrir une nuée de
# connexions PostgreSQL en pic de trafic. À l'arrêt de l'interpréteur,
# concurrent.futures joint les threads en cours : les INSERT en vol se terminent.
_PERSIST_EXECUTOR = ThreadPoolExecutor(max_workers=2, thread_name_prefix="jeiko-pageview")


def _persist_pageview_async(fields):
    """
    Crée le PageView dans un thread du pool. Django ouvre une connexion propre
    au thread ; on la ferme en fin de tâche pour ne pas laisser filer une
    connexion par thread réutilisé (CONN_MAX_AGE la garderait sinon ouverte).
    """
    try:
        PageView.objects.create(**fields)
    except Exception:
        logger.exception("Enregistrement PageView asynchrone impossible (path=%s)",
                         fields.get("path"))
    finally:
        connections.close_all()

BOT_RE = re.compile(
    r"("
    r"bot|crawler|spider|slurp|uptime|monitor|pingdom|crawl|scan|checker|fetch|proxy|archiver|"
    r"googlebot|bingbot|yandex|baiduspider|duckduckbot|sogou|exabot|qwantify|"
    r"gptbot|claudebot|anthropic|perplexitybot|bytespider|ccbot|cohere-ai|omgilibot|diffbot|facebookbot|turnitinbot|imagesiftbot|youbot|"
    r"semrushbot|ahrefsbot|mj12bot|dotbot|seznambot|screaming\s*frog|dataforseobot|linkdexbot|serpstatbot|rogersbot|siteauditbot|"
    r"python-requests|python-urllib|httpx|aiohttp|curl/|wget/|httpie|go-http-client|java/|postmanruntime|insomnia|axios|node-fetch|libwww-perl|zgrab|nmap|masscan|nikto|sqlmap|censys|shodan|"
    r"facebookexternalhit|twitterbot|linkedinbot|whatsapp|telegrambot|discordbot|applebot|slackbot|skypeuripreview|"
    r"headlesschrome|phantomjs|selenium|puppeteer|playwright|cypress|webdriver"
    r")",
    re.I
)

MOBILE_RE = re.compile(r"(android|iphone|ipad|ipod|mobile|blackberry|iemobile|opera mini)", re.I)

IGNORED_EXTENSIONS = (
    ".ico", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".css", ".js",
    ".map", ".xml", ".json", ".txt", ".php", ".pdf", ".zip", ".gz", ".woff",
    ".woff2", ".ttf", ".eot", ".mp3", ".mp4"
)

IGNORED_PATH_PREFIXES = (
    "/.well-known/", "/robots.txt", "/favicon.ico", "/sitemap.xml",
    "/apple-touch-icon", "/.env", "/.git", "/wp-", "/phpmyadmin"
)

def _is_probably_bot(user_agent: str) -> bool:
    if not user_agent or not user_agent.strip():
        return True
    return bool(BOT_RE.search(user_agent))

def _is_mobile_device(user_agent: str) -> bool:
    if not user_agent:
        return False
    return bool(MOBILE_RE.search(user_agent))

def _safe_int(v):
    try:
        return int(v)
    except Exception:
        return None

def _path_is_ignored(path: str) -> bool:
    path_lower = path.lower()
    
    if any(path_lower.endswith(ext) for ext in IGNORED_EXTENSIONS):
        return True
        
    if any(path_lower.startswith(prefix) for prefix in IGNORED_PATH_PREFIXES):
        return True

    prefixes = getattr(settings, "STATS_IGNORE_PATH_PREFIXES", [])
    if prefixes:
        for p in prefixes:
            if path.startswith(p):
                return True
    return False

def _canon_host(h: str | None) -> str:
    if not h:
        return ""
    h = h.split(":")[0].strip().lower()
    if h.startswith("www."):
        h = h[4:]
    return h

def _is_internal_by_host(request, ref_netloc: str | None) -> bool:
    if not ref_netloc:
        return True
    try:
        cur_host = request.get_host()
    except Exception:
        cur_host = request.META.get("HTTP_HOST", "")
    cur = _canon_host(cur_host)
    ref = _canon_host(ref_netloc)
    if cur and ref == cur:
        return True
    extra = getattr(settings, "STATS_INTERNAL_HOSTS", [])
    extra_norm = {_canon_host(x) for x in extra if x}
    return ref in extra_norm

def _beacon_url() -> str:
    try:
        return reverse("stats_track_exit")
    except NoReverseMatch:
        return getattr(settings, "STATS_TRACK_EXIT_URL", "/stats/track-exit/")

def _try_inject_beacon_script(response, pageview_id: str):
    try:
        if getattr(response, "streaming", False):
            return
        
        if response.has_header("Content-Encoding"):
            return
            
        content = response.content
        if not isinstance(content, (bytes, bytearray)):
            return
            
        body_close = b"</body>"
        idx = content.lower().rfind(body_close)
        if idx == -1:
            return

        beacon = _beacon_url()
        snippet = f"""
<script>
(function(){{try{{
    var start = performance.now(), sent=false;
    function send(ms){{
        if(sent) return; sent=true;
        var data = JSON.stringify({{id:"{pageview_id}", d: Math.round(ms)}});
        navigator.sendBeacon("{beacon}", new Blob([data], {{type:"application/json"}}));
    }}
    function handler(){{ send(performance.now()-start); }}
    document.addEventListener("visibilitychange", function(){{ if(document.visibilityState==="hidden"){{ handler(); }} }});
    window.addEventListener("pagehide", handler);
}}catch(e){{}}}})();
</script>
""".encode("utf-8")
        response.content = content[:idx] + snippet + content[idx:]
        if response.has_header("Content-Length"):
            response["Content-Length"] = str(len(response.content))
    except Exception:
        pass

class PageViewCounterMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        try:
            if request.method != "GET":
                return response

            user = getattr(request, "user", None)
            if user and getattr(user, "is_authenticated", False) and (user.is_staff or user.is_superuser):
                return response

            path = request.path or "/"

            admin_url = getattr(settings, "ADMIN_URL", "/admin/")
            if path.startswith(admin_url):
                return response

            if _path_is_ignored(path):
                return response

            status = getattr(response, "status_code", 0) or 0
            if status != 200:
                return response

            ct = response.get("Content-Type", "")
            if not ct.startswith("text/html"):
                return response

            ua = request.META.get("HTTP_USER_AGENT", "")
            is_bot = _is_probably_bot(ua)
            is_mobile = _is_mobile_device(ua)

            if is_bot and getattr(settings, "STATS_IGNORE_BOTS", False):
                return response

            ref_raw = request.META.get("HTTP_REFERER", "")
            referrer_path = None
            referrer_domain = None
            is_internal_referrer = False

            if ref_raw:
                p = urlparse(ref_raw)
                if _is_internal_by_host(request, p.netloc):
                    is_internal_referrer = True
                    referrer_path = p.path or "/"
                else:
                    is_internal_referrer = False
                    referrer_domain = _canon_host(p.netloc) or "direct"
            else:
                referrer_domain = "direct"

            is_entry = (not is_internal_referrer) and (not is_bot)

            # La PK est un UUID à défaut Python (PageView.id = UUIDField) : on la
            # génère ici, sans toucher la base. Le beacon peut donc être injecté
            # immédiatement et l'INSERT partir en tâche de fond — l'écriture ne
            # bloque plus le TTFB. content_length est lu AVANT l'injection (comme
            # avant) : c'est la taille du corps effectivement rendu par la vue.
            fields = dict(
                id=uuid.uuid4(),
                path=path,
                referrer_path=referrer_path,
                referrer_domain=referrer_domain,
                day=timezone.localdate(),
                status_code=status,
                is_internal_referrer=is_internal_referrer,
                is_entry=is_entry,
                is_authenticated=bool(user and getattr(user, "is_authenticated", False)),
                is_bot=is_bot,
                is_mobile=is_mobile,
                content_length=_safe_int(response.get("Content-Length")),
            )

            if getattr(settings, "STATS_ASYNC", True):
                # submit() ne lève pas : la file est en mémoire, l'INSERT arrive
                # au thread de fond. Si le pool est saturé, la tâche patiente ;
                # elle ne retarde jamais la réponse.
                _PERSIST_EXECUTOR.submit(_persist_pageview_async, fields)
            else:
                # Mode synchrone (tests, diagnostic) : même connexion que la
                # requête, pas de fermeture — on ne casse pas la transaction de
                # test.
                PageView.objects.create(**fields)

            if not is_bot and getattr(settings, "STATS_ENABLE_DWELL", True):
                _try_inject_beacon_script(response, str(fields["id"]))

        except Exception:
            pass

        return response
