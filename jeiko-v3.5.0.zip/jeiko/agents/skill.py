# jeiko/agents/skill.py
"""
La skill d'un site — la méthode de travail, à côté des outils du MCP.

Pourquoi
--------
Le serveur MCP donne à un assistant les OUTILS du site ; il ne lui dit pas
comment s'en servir BIEN. Cette méthode existait, dispersée : dans le guide de
l'API, et dans ce que les premiers montages de sites ont appris à leurs dépens
(A-22 → A-50). Une skill la donne à l'assistant au moment où il travaille sur
le site, et seulement là.

Même contenu pour tous les sites, séparée par site
-------------------------------------------------
Le corps est identique partout ; changent le NOM (`jeiko-<domaine>`), la
description — qui dit à l'assistant QUAND s'en servir : pour CE site — et
l'adresse du serveur MCP. Deux sites, deux skills : un assistant qui travaille
sur l'un ne confond pas ses outils avec ceux de l'autre.

Ce qu'elle ne contient pas : aucun jeton. Le jeton se déclare dans la
configuration du connecteur MCP, jamais dans un fichier qui se partage.
"""

import io
import re
import zipfile

from django.utils.text import slugify


def nom_de_la_skill(domaine):
    """`jeiko-<domaine>`, dans la forme qu'exigent les skills : minuscules,
    chiffres, tirets, 64 caractères au plus."""
    base = slugify((domaine or "site").split(":")[0].replace(".", "-")) or "site"
    return f"jeiko-{base}"[:64].rstrip("-")


def _une_ligne(texte):
    return re.sub(r"\s+", " ", texte).strip()


def contenu_skill(domaine, nom_du_site, url_mcp):
    """Le SKILL.md du site, prêt à écrire."""
    nom = nom_de_la_skill(domaine)
    serveur = nom  # le serveur MCP porte le même nom que la skill
    description = _une_ligne(f"""
        Construire et modifier le site « {nom_du_site or domaine} » ({domaine}),
        propulsé par JEIKO, avec les outils de son serveur MCP ({url_mcp}). À
        utiliser dès qu'on demande de créer ou modifier des pages, sections,
        blocs, menus, catégories, couleurs, polices, e-mails, questionnaires,
        rendez-vous, fiches ou produits sur {domaine}.
    """)[:1024]

    return f"""---
name: {nom}
description: {description}
---

# Travailler sur {nom_du_site or domaine} ({domaine})

Ce site tourne sous JEIKO. Tu agis dessus par les outils du serveur MCP
**{serveur}** (`{url_mcp}`). Chaque outil appelle l'API des agents du site :
tu as les droits du rôle de ton agent, ni plus ni moins.

Si les outils de ce serveur ne sont pas disponibles, dis-le et demande qu'on
ajoute le connecteur MCP `{url_mcp}`, avec l'en-tête
`Authorization: Bearer <jeton de l'agent>` (le jeton se crée dans
Administration → Agents IA). N'invente jamais de jeton.

## Toujours commencer ainsi

1. `guide` — le mode d'emploi de CE site : modèle de page, vocabulaire,
   catalogue des blocs, pièges connus. Chaque outil décrit en plus ses
   propres champs et leurs valeurs permises : lis ce schéma avant d'appeler.
2. `qui_suis_je` — ce que ton agent a le droit de faire. Un refus 403 veut
   dire « pas ce droit », pas « réessaie ».
3. Lis avant d'écrire : `lister_pages`, `lire_page`, `lire_identite`,
   `lister_categories`, `lister_images`.

## Construire une page

`creer_page` → `ajouter_page_sections` → `ajouter_section_lignes` →
`ajouter_ligne_blocs` → `ecrire_bloc_contenu`, puis **relis** avec
`lire_page`. Préfère toujours l'outil dédié ; `appeler_api` ne sert que si
aucun outil ne convient.

- **Une ligne se déclare avec son nombre de colonnes** : la répartition doit
  décrire TOUS les blocs, sur chaque appareil. Trois blocs empilés sur
  téléphone s'écrivent `"12-12-12"`, pas `"12"` — sinon deux blocs tombent à
  trente pixels.
- **Lis les `avertissements`** de chaque réponse d'écriture de texte : ils
  nomment ce que le site a retiré (balise, attribut, style). Une liste vide
  signifie que rien n'a été touché.
- **Un lien ne peut pas envelopper des blocs** : `<a><p>…</p><p>…</p></a>` se
  scinde en plusieurs liens. Mets le lien sur le titre.
- Les styles en ligne admis se limitent à la couleur, la couleur de fond,
  l'alignement, la graisse, l'italique et le soulignement. Une couleur
  s'écrit `#rrggbb`, `rgb(…)`, un nom CSS ou `var(--jk-…)`.
- Une page naît en brouillon : publie-la explicitement (`modifier_page` avec
  `{{"publiee": true}}`), et vérifie son adresse publique (elle dépend de sa
  catégorie).

## Règles du site

- **Une clé inconnue est refusée**, jamais ignorée : lis le message d'erreur,
  il dit quoi écrire à la place. Un 200 veut dire que c'est fait.
- **Réglages de site** (`modifier_identite`) : ils valent partout. Les couleurs
  se nomment par leur rôle (`accent`, `texte`…), pas par leur teinte. Les rôles
  de survol des polices n'ont pas de taille.
- **Catégories** : un tag d'URL peut exister dans deux catégories ; le slug
  d'une catégorie ne se modifie pas. Supprimer une catégorie qui contient des
  pages est refusé : reclasse d'abord les pages.
- **Images** : le site a une MÉDIATHÈQUE. Réutilise l'identifiant d'une image
  de `lister_images` ; pour en ajouter une, `creer_image` avec le fichier en
  base64 (`fichier_base64`), et un texte alternatif (`alt`) — ou
  `decorative: true` si elle n'apporte aucune information.
- **Plafond d'appels** : un 429 donne le délai d'attente. Respecte-le, ne
  change pas de jeton.

## Rendre compte

À la fin, donne l'adresse publique des pages touchées et ce qui a été
modifié. Signale tout avertissement que tu n'as pas pu résoudre.
"""


def archive_skill(domaine, nom_du_site, url_mcp):
    """Le zip à ajouter dans Claude : `<nom>/SKILL.md`. Rend (nom, octets)."""
    nom = nom_de_la_skill(domaine)
    tampon = io.BytesIO()
    with zipfile.ZipFile(tampon, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(f"{nom}/SKILL.md", contenu_skill(domaine, nom_du_site, url_mcp))
    return nom, tampon.getvalue()
