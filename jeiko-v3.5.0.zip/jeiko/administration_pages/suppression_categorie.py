"""
Supprimer une catégorie ou une sous-catégorie sans rien casser (demande du
28/09/2026).

Pourquoi ce n'était pas proposé
-------------------------------
Supprimer une catégorie a trois effets, dont aucun ne se voit :

* ses **sous-catégories partent avec elle** (`Category.main_category` est en
  `CASCADE`) ;
* ses **pages ne disparaissent pas, elles se déclassent** (`Page.category` et
  `Page.sub_category` sont en `SET_NULL`) — or l'adresse d'une page hérite
  des slugs de sa catégorie et de sa sous-catégorie visibles : `/formations/
  coaching/tarifs/` devient `/tarifs/`. Les liens publiés, les favoris et le
  référencement pointent sur l'ancienne ;
* deux pages de même tag rangées dans deux catégories différentes
  (`/formations/tarifs/`, `/coaching/tarifs/`) arrivent sur la même adresse.
  La contrainte d'unicité refuse alors l'écriture : une suppression brute
  (admin Django, shell) lève `IntegrityError` au milieu du `SET_NULL` —
  vérifié le 28/09. L'administration de JEIKO n'offrait aucun bouton, et
  l'API des agents refuse toute catégorie non vide.

S'y ajoutent les menus propres à la catégorie (ses pages reprennent ceux du
site) et les blocs dynamiques filtrés sur elle (le filtre saute, le bloc
affiche tout).

Ce que fait ce module
---------------------
`evaluer()` calcule tout cela AVANT d'écrire quoi que ce soit : pour chaque
page touchée, l'adresse avant et après ; les collisions, qui BLOQUENT ; les
effets de bord, qui demandent une confirmation explicite. `supprimer()`
recalcule le bilan dans la transaction — celui affiché à l'écran a pu vieillir
— puis reclasse les pages et supprime.

Les anciennes adresses ne tombent pas pour autant en 404 : la vue publique
retrouve une page par son tag quand la catégorie de l'adresse n'existe plus,
et redirige en 301 vers l'adresse canonique (voir `views_client.PageView`).
Ce repli ne vaut que si le tag désigne UNE page : c'est précisément ce que
garantit le refus des collisions.

Ce que ce module ne fait pas : il ne reclasse pas les pages dans une autre
catégorie. Le faire avant la suppression, depuis chaque page, reste possible
et donne alors une nouvelle adresse choisie plutôt que subie.
"""

from dataclasses import dataclass, field

from django.db import transaction


@dataclass
class PageTouchee:
    page: object
    avant: str
    apres: str

    @property
    def change_d_adresse(self):
        return self.avant != self.apres


@dataclass
class Bilan:
    categorie: object
    sous_categories: list = field(default_factory=list)
    pages: list = field(default_factory=list)
    #: Empêchent la suppression. Phrases prêtes à afficher.
    blocages: list = field(default_factory=list)
    #: N'empêchent rien, mais doivent être lus et confirmés.
    avertissements: list = field(default_factory=list)

    @property
    def adresses_changees(self):
        return [p for p in self.pages if p.change_d_adresse]

    @property
    def possible(self):
        return not self.blocages

    @property
    def confirmation_requise(self):
        return bool(self.avertissements)


class SuppressionImpossible(Exception):
    def __init__(self, bilan):
        super().__init__("; ".join(bilan.blocages))
        self.bilan = bilan


def _cle_d_unicite(page, categorie_id, sous_categorie_id):
    """La clé que les contraintes de `Page` rendent unique (voir Page.Meta)."""
    if categorie_id is None:
        return ("racine", page.url_tag)
    if sous_categorie_id is None:
        return ("categorie", categorie_id, page.url_tag)
    return ("sous", categorie_id, sous_categorie_id, page.url_tag)


def evaluer(categorie):
    """Bilan de la suppression de `categorie`, sans rien écrire."""
    from django.db.models import Q

    from jeiko.administration_pages.models import Category, DynResourceConfig, Page

    sous_categories = list(categorie.sub_categories.order_by("name"))
    supprimees = {categorie.pk, *(c.pk for c in sous_categories)}
    bilan = Bilan(categorie=categorie, sous_categories=sous_categories)

    if categorie.is_protected:
        bilan.blocages.append(
            f"« {categorie.name} » est une catégorie protégée : elle ne se "
            f"supprime pas."
        )
    protegees = [c.name for c in sous_categories if c.is_protected]
    if protegees:
        bilan.blocages.append(
            "Sous-catégorie(s) protégée(s), qui partiraient avec elle : "
            + ", ".join(f"« {nom} »" for nom in protegees) + "."
        )

    toutes = list(
        Page.objects.select_related("category", "sub_category").order_by("title")
    )
    futur = {}
    for page in toutes:
        cat_id, sous_id = page.category_id, page.sub_category_id
        touchee = cat_id in supprimees or sous_id in supprimees
        if touchee:
            avant = page.get_absolute_url()
            if cat_id in supprimees:
                cat_id, sous_id = None, None
            if sous_id in supprimees:
                sous_id = None
            # Adresse future : même calcul que le modèle, sur une copie non
            # enregistrée — une seule règle d'URL, pas une seconde à côté.
            copie = Page(
                pk=page.pk, url_tag=page.url_tag, is_root=page.is_root,
                category=page.category if cat_id else None,
                sub_category=page.sub_category if sous_id else None,
            )
            bilan.pages.append(PageTouchee(page, avant, copie.get_absolute_url()))
            futur[page.pk] = (cat_id, sous_id, copie.get_absolute_url())
        else:
            futur[page.pk] = (cat_id, sous_id, page.get_absolute_url())

    touchees = {p.page.pk for p in bilan.pages}

    # Collisions : une page touchée arrive sur la clé d'unicité ou sur
    # l'adresse d'une autre page. La première ferait lever la base, la
    # seconde rendrait deux pages sur une même adresse.
    par_cle, par_adresse = {}, {}
    for page in toutes:
        cat_id, sous_id, adresse = futur[page.pk]
        if page.url_tag:
            par_cle.setdefault(_cle_d_unicite(page, cat_id, sous_id), []).append(page)
        if not page.is_root and not page.is_mail_template:
            par_adresse.setdefault(adresse, []).append(page)

    signalees = set()
    for groupe in list(par_cle.values()) + list(par_adresse.values()):
        ids = frozenset(p.pk for p in groupe)
        if len(groupe) < 2 or not (ids & touchees) or ids in signalees:
            continue
        signalees.add(ids)
        adresse = futur[groupe[0].pk][2]
        bilan.blocages.append(
            f"Adresse {adresse} : elle serait prise par "
            + " et ".join(f"« {p.title} »" for p in groupe)
            + ". Changez le tag d'URL de l'une d'elles, ou reclassez-la, "
              "avant de supprimer."
        )

    # Une page qui passe à la racine ne doit ni masquer une route du système,
    # ni prendre le slug d'une catégorie qui reste.
    restantes = set(
        Category.objects.exclude(pk__in=supprimees)
        .exclude(slug__isnull=True).values_list("slug", flat=True)
    )
    for touchee in bilan.pages:
        page = touchee.page
        if futur[page.pk][0] is not None or page.is_root or not page.url_tag:
            continue
        if Page._is_reserved_root_slug(page.url_tag):
            bilan.blocages.append(
                f"« {page.title} » arriverait sur {touchee.apres}, adresse "
                f"réservée par le système. Changez son tag d'URL d'abord."
            )
        elif page.url_tag in restantes:
            bilan.blocages.append(
                f"« {page.title} » arriverait sur {touchee.apres}, qui est "
                f"aussi l'adresse d'une catégorie. Changez son tag d'URL d'abord."
            )

    # Ce qui se confirme.
    if sous_categories:
        bilan.avertissements.append(
            f"{len(sous_categories)} sous-catégorie(s) seront supprimées avec "
            f"elle : " + ", ".join(f"« {c.name} »" for c in sous_categories) + "."
        )
    changees = bilan.adresses_changees
    if changees:
        bilan.avertissements.append(
            f"{len(changees)} page(s) changeront d'adresse (détail ci-dessous). "
            f"Les anciennes adresses redirigeront vers les nouvelles (301), "
            f"mais mettez à jour les liens que vous maîtrisez : réseaux "
            f"sociaux, e-mails, campagnes."
        )
    sans_changement = len(bilan.pages) - len(changees)
    if sans_changement:
        bilan.avertissements.append(
            f"{sans_changement} page(s) perdront leur classement sans changer "
            f"d'adresse (catégorie masquée dans les URL)."
        )
    avec_menus = [
        c.name for c in [categorie, *sous_categories]
        if c.main_menu_id or c.footer_menu_id
    ]
    if avec_menus:
        bilan.avertissements.append(
            "Menus propres à " + ", ".join(f"« {n} »" for n in avec_menus)
            + " : leurs pages reprendront les menus par défaut du site."
        )
    blocs = DynResourceConfig.objects.filter(
        Q(category_id__in=supprimees) | Q(sub_category_id__in=supprimees)
    ).count()
    if blocs:
        bilan.avertissements.append(
            f"{blocs} bloc(s) dynamique(s) filtrent sur cette catégorie : "
            f"le filtre disparaîtra et ils listeront tout."
        )
    return bilan


def supprimer(categorie):
    """Supprime `categorie` si le bilan le permet. Retourne le bilan appliqué.

    Lève `SuppressionImpossible` si un blocage est apparu depuis l'affichage.
    """
    from jeiko.administration_menu.models import _invalidate_menus_referencing_page
    from jeiko.administration_pages.models import Category, Page
    from jeiko.administration_pages.page_cache import bump_page_body_version

    with transaction.atomic():
        categorie = Category.objects.select_for_update().get(pk=categorie.pk)
        bilan = evaluer(categorie)
        if not bilan.possible:
            raise SuppressionImpossible(bilan)

        supprimees = [categorie.pk, *(c.pk for c in bilan.sous_categories)]
        # Reclasser explicitement AVANT de supprimer : le SET_NULL ferait la
        # même chose, mais sans ordre garanti entre catégorie et
        # sous-catégorie. `update()` et non `save()` : la sauvegarde d'une
        # page lève le drapeau « modèle légal par défaut » (signals.py), ce
        # qu'un reclassement n'est pas.
        Page.objects.filter(category_id__in=supprimees).update(
            category=None, sub_category=None
        )
        Page.objects.filter(sub_category_id__in=supprimees).update(sub_category=None)
        Category.objects.filter(pk__in=supprimees).delete()

        ids = [p.page.pk for p in bilan.pages]

        def _rafraichir():
            # Les menus et les corps de page mis en cache portent les
            # anciennes adresses.
            for page_id in ids:
                _invalidate_menus_referencing_page(page_id)
                bump_page_body_version(page_id)

        transaction.on_commit(_rafraichir)
    return bilan
