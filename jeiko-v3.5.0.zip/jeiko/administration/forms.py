from django import forms
from django.forms import inlineformset_factory



from .models import (
    Font, Logo, Favicon, MailSettings, GoogleApi, Legals, SiteIdentity,
    SocialLink, SocialProvider, WebSite,
)

from jeiko.administration_pages.models import Page



class FontForm(forms.ModelForm):

    class Meta:
        model = Font
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(FontForm, self).__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form'


class HoverFontForm(FontForm):
    """Rôle de SURVOL : tout sauf la taille (A-41).

    Une taille de survol différente de celle de l'état normal faisait grossir
    le lien sous le curseur — la ligne tressautait, le clic ratait. Le survol
    sert à changer la couleur ou la graisse, pas l'encombrement : la taille
    est celle du rôle de base, et la feuille générée ne la lit plus.
    """

    class Meta(FontForm.Meta):
        fields = None
        exclude = ["size"]


class FontFamilyUpdateAllForm(forms.Form):

    family = forms.CharField(
        label="Nouvelle famille de police",
        max_length=100,
        help_text='Ex: Inter, Roboto, Playfair Display, Georgia…',
        widget=forms.TextInput(attrs={"placeholder": "Inter"})
    )

    def clean_family(self):
        v = (self.cleaned_data.get("family") or "").strip()
        if not v:
            raise forms.ValidationError("La famille de police ne peut pas être vide.")
        # normalisation soft: espaces internes réduits
        v = " ".join(v.split())
        return v


class LogoForm(forms.ModelForm):
    """
    Le logo du site, et son remplaçant facultatif pour les e-mails.

    `mail_logo` n'a pas de case « activer » : le renseigner l'active, le vider
    revient au logo du site. Voir `Logo.mail_logo` pour le pourquoi.
    """

    class Meta:
        model = Logo
        fields = [
            'full_size',
            'mail_logo',
        ]


class FaviconForm(forms.ModelForm):

    class Meta:
        model = Favicon
        fields = [
            'source',
        ]


def _secret_conserve_si_vide(form, nom):
    """
    Un champ secret laissé vide garde la valeur enregistrée (Fable 1 §1.5).

    Ces secrets étaient rendus avec `render_value=True` (ou dans un `<textarea>`) :
    le masque n'était que visuel, la valeur repartait en clair dans le HTML à
    chaque ouverture de l'écran — une capture ou un partage d'écran suffisait.
    On ne la renvoie plus ; ne rien saisir ne doit donc pas l'effacer. Même
    règle que `payments/forms.py` pour les clés Stripe.
    """
    valeur = (form.cleaned_data.get(nom) or "").strip()
    if valeur:
        return valeur
    return getattr(form.instance, nom, "") if form.instance.pk else ""


def _annoncer_secret(champ, enregistre):
    champ.required = False
    champ.help_text = (
        "Une valeur est enregistrée. Laisser vide pour la conserver, "
        "ou saisir la nouvelle pour la remplacer."
        if enregistre else "Aucune valeur enregistrée pour le moment."
    )


class MailSettingsForm(forms.ModelForm):
    host_password = forms.CharField(
        label="Mot de passe SMTP",
        widget=forms.PasswordInput(render_value=False, attrs={"autocomplete": "new-password"}),
        required=False,
        help_text="Mot de passe du serveur SMTP"
    )

    class Meta:
        model = MailSettings
        fields = [
            "host", "port", "use_tls", "use_ssl", "host_user", "host_password",
            "default_from_email", "reply_to_email", "active", "test_receiver"
        ]
        labels = {
            "default_from_email": "Adresse d'envoi par défaut",
            "reply_to_email": "Adresse de réponse",
        }
        help_texts = {
            "default_from_email": "Tous les e-mails du site partent de cette adresse.",
            "reply_to_email": (
                "Reçoit les réponses des clients et les demandes envoyées par les "
                "formulaires du site."
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Obligatoires dans l'écran (le modèle reste permissif pour les sites
        # déjà en service) : sans adresse de réponse, les demandes des
        # formulaires n'avaient nulle part où arriver.
        self.fields["default_from_email"].required = True
        self.fields["reply_to_email"].required = True
        _annoncer_secret(self.fields["host_password"], bool(self.instance.host_password))

    def clean_host_password(self):
        return _secret_conserve_si_vide(self, "host_password")


class GoogleApiForm(forms.ModelForm):
    class Meta:
        model = GoogleApi
        fields = ["psi_api_key"]
        widgets = {
            "psi_api_key": forms.PasswordInput(render_value=False, attrs={"autocomplete": "new-password"}),
        }
        labels = {
            "psi_api_key": "Clé API PageSpeed Insights",
        }
        help_texts = {
            "psi_api_key": "Colle ici ta clé PSI. Laisse vide pour utiliser la variable d'environnement.",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.psi_api_key:
            _annoncer_secret(self.fields["psi_api_key"], True)

    def clean_psi_api_key(self):
        # Le champ n'était déjà pas renvoyé au navigateur, mais l'enregistrer
        # vide effaçait la clé : ouvrir l'écran et valider suffisait à la perdre.
        return _secret_conserve_si_vide(self, "psi_api_key")


class LegalsAdminForm(forms.ModelForm):
    class Meta:
        model = Legals
        fields = ["privacy_page", "cgv_page", "cgu_page", "mentions_page"]  # pas de 'site' ici

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        qs = Page.objects.all()
        for fname in ("privacy_page", "cgv_page", "cgu_page", "mentions_page"):
            self.fields[fname].queryset = qs
            self.fields[fname].required = False

class SiteIdentityForm(forms.ModelForm):
    type = forms.ChoiceField(
        choices=SiteIdentity.TYPE_CHOICES,
        widget=forms.RadioSelect
    )

    class Meta:
        model = SiteIdentity
        fields = [
            "type", "name", "url", "telephone",
            "street_address", "address_locality", "address_region",
            "postal_code", "address_country",
            "geo_lat", "geo_lng", "price_range", "default_share_image",
        ]
        help_texts = {
            "address_country": "Code pays ISO-3166-1 alpha-2 (ex: FR, CH, BE).",
            "default_share_image": (
                "Image utilisée par défaut lors d'un partage si la page ou la fiche "
                "n'a pas d'image principale. Elle vient de la médiathèque."
            ),
        }

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("type") == SiteIdentity.TYPE_LOCAL:
            required = ["name", "street_address", "address_locality", "postal_code", "address_country"]
            for f in required:
                if not cleaned.get(f):
                    self.add_error(f, "Champ requis pour LocalBusiness.")
        return cleaned


class SocialLinkForm(forms.ModelForm):
    """Édition d'un profil public qui alimente aussi le JSON-LD ``sameAs``."""

    class Meta:
        model = SocialLink
        fields = [
            "platform", "profile_url", "handle", "display_name",
            "aria_label", "position", "is_active",
        ]
        labels = {
            "platform": "Réseau",
            "profile_url": "URL du profil",
            "handle": "Identifiant / @pseudo",
            "display_name": "Nom affiché",
            "aria_label": "Libellé pour lecteur d'écran",
            "position": "Ordre",
            "is_active": "Afficher ce réseau",
        }
        help_texts = {
            "profile_url": "Adresse publique complète, par exemple https://www.instagram.com/mon-compte/.",
            "aria_label": "Facultatif : un libellé explicite comme « Suivre Atelier X sur Instagram ».",
        }

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("is_active") and not cleaned.get("profile_url"):
            self.add_error(
                "profile_url",
                "Une URL publique est obligatoire pour afficher ce réseau.",
            )
        return cleaned


SocialLinkFormSet = inlineformset_factory(
    WebSite,
    SocialLink,
    form=SocialLinkForm,
    extra=1,
    can_delete=True,
)

class SocialProviderForm(forms.ModelForm):
    """
    Un formulaire par fournisseur. Les libellés/champs sensibles s'adaptent
    au provider (Apple a des champs supplémentaires : Team ID + clé .p8).
    """

    class Meta:
        model = SocialProvider
        fields = ["enabled", "client_id", "secret", "key", "certificate_key"]
        widgets = {
            "secret": forms.PasswordInput(render_value=False, attrs={"autocomplete": "new-password"}),
            "certificate_key": forms.Textarea(attrs={"rows": 5, "autocomplete": "off"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        provider = getattr(self.instance, "provider", None)

        for name, field in self.fields.items():
            css = "form"
            if name == "enabled":
                css = "form-check"
            field.widget.attrs.setdefault("class", css)

        # Apple : garder Team ID + certificat ; sinon les retirer du formulaire.
        if provider != SocialProvider.PROVIDER_APPLE:
            self.fields.pop("key", None)
            self.fields.pop("certificate_key", None)
        else:
            self.fields["client_id"].label = "Services ID"
            self.fields["secret"].label = "Key ID"
            self.fields["key"].label = "Team ID"

        _annoncer_secret(self.fields["secret"], bool(self.instance.secret))
        if "certificate_key" in self.fields:
            # Un `<textarea>` n'a pas de `render_value` : on vide sa valeur
            # initiale, sans quoi la clé privée s'affichait en toutes lettres.
            self.initial["certificate_key"] = ""
            _annoncer_secret(self.fields["certificate_key"], bool(self.instance.certificate_key))

    def clean_secret(self):
        return _secret_conserve_si_vide(self, "secret")

    def clean_certificate_key(self):
        return _secret_conserve_si_vide(self, "certificate_key")

    def clean(self):
        cleaned = super().clean()
        # On empêche d'activer un provider sans identifiants complets.
        if cleaned.get("enabled"):
            provider = getattr(self.instance, "provider", None)
            missing = not cleaned.get("client_id") or not cleaned.get("secret")
            if provider == SocialProvider.PROVIDER_APPLE:
                missing = missing or not cleaned.get("key") or not cleaned.get("certificate_key")
            if missing:
                raise forms.ValidationError(
                    "Renseigne tous les identifiants avant d'activer ce fournisseur."
                )
        return cleaned
