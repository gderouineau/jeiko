# jeiko/checks.py
"""
Contrôles au démarrage : JEIKO s'installe entier, ou pas du tout.

Pourquoi ce fichier existe
--------------------------
Le package se présente comme quatorze applications Django séparées. Ce n'en est
pas : le graphe d'imports comporte douze paires mutuelles — `administration` et
`emailing` s'appellent l'un l'autre, `shop` et `custom_objects` aussi, et ainsi
de suite. Rien ne casse aujourd'hui parce que ces imports sont différés à
l'intérieur des fonctions, mais l'équilibre est instable.

La décision a été prise : **JEIKO est une application indivisible**. On cesse
donc d'entretenir la fiction inverse, et on la rend vérifiable — une intention
écrite dans un fichier se perd, un contrôle qui échoue au démarrage non.

Ce que ce contrôle évite
------------------------
Sans lui, installer une partie seulement des applications produit un
`ImportError` ou un `NoReverseMatch` tardif, loin de sa cause : la personne
cherche un bug dans le code alors que son `INSTALLED_APPS` est incomplet. Le
message ci-dessous nomme précisément ce qui manque.
"""

from django.core.checks import Error, Warning, register
from django.db import OperationalError, ProgrammingError

#: Les applications qui composent JEIKO. Elles s'installent ensemble.
#:
#: Ajouter une application au package, c'est l'ajouter ici ET dans le gabarit
#: `INSTALLED_APPS` de l'installeur — sans quoi les sites existants ne la
#: verront jamais.
JEIKO_APPS = (
    "jeiko",
    "jeiko.administration",
    "jeiko.administration_menu",
    "jeiko.administration_pages",
    "jeiko.agents",
    "jeiko.calendars",
    "jeiko.cookies",
    "jeiko.courses",
    "jeiko.custom_objects",
    "jeiko.emailing",
    "jeiko.payments",
    "jeiko.questionnaires_expert",
    "jeiko.shop",
    "jeiko.stats",
    "jeiko.users",
)


@register()
def check_jeiko_apps_installed(app_configs, **kwargs):
    """Refuse un démarrage où JEIKO n'est installé qu'à moitié."""
    from django.apps import apps

    installees = {config.name for config in apps.get_app_configs()}
    manquantes = [nom for nom in JEIKO_APPS if nom not in installees]
    if not manquantes:
        return []

    return [
        Error(
            "JEIKO est installé partiellement : %s application(s) manquent dans "
            "INSTALLED_APPS." % len(manquantes),
            hint=(
                "JEIKO ne se compose pas à la carte : ses applications "
                "s'appellent mutuellement et doivent être installées ensemble. "
                "Ajouter à INSTALLED_APPS :\n    "
                + "\n    ".join(f"'{nom}'," for nom in manquantes)
            ),
            id="jeiko.E001",
        )
    ]


@register()
def check_stripe_webhook_secret(app_configs, **kwargs):
    """
    Signale une configuration Stripe active qui refuserait ses webhooks.

    AVERTISSEMENT et non erreur : une erreur de `check` bloque aussi
    `migrate`, `runserver` et `test`. Or `jeiko-client-update` lance
    `migrate` — chez un client dans ce cas, la mise à jour se serait arrêtée
    en plein milieu, sur un site en service, pour un réglage que seul
    l'exploitant peut corriger. L'avertissement s'affiche sans rien bloquer.
    """
    from jeiko.payments.models import PaymentGateway

    try:
        passerelles = PaymentGateway.objects.filter(
            code="stripe", is_active=True
        ).only("pk", "webhook_secret")
        sans_secret = [
            passerelle
            for passerelle in passerelles
            if not (passerelle.webhook_secret or "").strip()
        ]
    except (OperationalError, ProgrammingError):
        # La base peut ne pas encore exister pendant une installation ou une
        # migration. Les commandes Django concernées signaleront elles-mêmes
        # cet état ; ce contrôle porte uniquement sur les données accessibles.
        return []

    return [
        Warning(
            "La passerelle Stripe est active sans secret de webhook : les "
            "notifications de paiement seront refusées.",
            hint=(
                "Renseigner le secret de signature du point de terminaison "
                "Stripe dans Administration > Paiements, ou désactiver la "
                "passerelle jusqu'à sa configuration complète."
            ),
            obj=passerelle,
            id="jeiko.W002",
        )
        for passerelle in sans_secret
    ]


#: L'adaptateur allauth que JEIKO exige. Voir `check_account_adapter`.
ADAPTATEUR_JEIKO = "jeiko.users.adapters.JeikoAccountAdapter"


@register()
def check_account_adapter(app_configs, **kwargs):
    """
    Signale un site où allauth n'emploie pas l'adaptateur de JEIKO (S-22,
    rapport Fable 1 §1.1).

    Trois comportements de sécurité et d'envoi vivent dans
    `JeikoAccountAdapter`, et aucun ne se voit quand il manque :

    * la confirmation d'adresse part par les réglages SMTP du site
      (`MailSettings`) ; sans l'adaptateur, allauth emploie la connexion
      globale de Django — `localhost:25` sur un site installé — et le message
      ne part pas, alors que l'e-mail de test et le rapport journalier, eux,
      arrivent ;
    * le second facteur est demandé dans `pre_login` ; sans l'adaptateur, le
      mot de passe seul ouvre la session d'un compte qui a activé la 2FA ;
    * le bouton « Renvoyer l'e-mail » connaît le compte en attente par la
      session que l'adaptateur remplit.

    Le gabarit de settings de l'installeur l'a oublié jusqu'au 26/09/2026, et
    un `settings.py` local qui le déclarait masquait l'oubli en développement.
    Une sous-classe est acceptée : un site peut spécialiser, pas remplacer.

    AVERTISSEMENT et non erreur, comme jeiko.W002 : une erreur de `check`
    bloque `migrate`, donc `jeiko-client-update` — la mise à jour qui apporte
    justement le bon gabarit se serait arrêtée en plein milieu, sur un site en
    service.

    Ce contrôle ne dit rien de la délivrabilité (SPF, DKIM, boîte pleine) :
    il garantit seulement que le message emprunte le bon chemin.
    """
    from django.conf import settings
    from django.utils.module_loading import import_string

    chemin = getattr(settings, "ACCOUNT_ADAPTER", None)
    classe = None
    if chemin:
        try:
            classe = import_string(chemin)
        except ImportError:
            classe = None

    from jeiko.users.adapters import JeikoAccountAdapter

    if isinstance(classe, type) and issubclass(classe, JeikoAccountAdapter):
        return []

    return [
        Warning(
            "allauth n'emploie pas l'adaptateur de JEIKO (ACCOUNT_ADAPTER = %r) : "
            "les e-mails de confirmation ne passent pas par les réglages SMTP "
            "du site et le second facteur n'est jamais demandé." % (chemin,),
            hint="Dans settings.py :\n    ACCOUNT_ADAPTER = %r\n"
                 "Le gabarit de l'installeur le déclare ; un site mis à jour "
                 "par jeiko-client-update le reçoit." % ADAPTATEUR_JEIKO,
            id="jeiko.W003",
        )
    ]


ADAPTATEUR_SOCIAL_JEIKO = "jeiko.users.adapters.JeikoSocialAccountAdapter"


@register()
def check_social_adapter(app_configs, **kwargs):
    """
    Signale un site dont allauth n'utilise pas l'adaptateur social de JEIKO.

    Rapport Fable 1, §1.5 : les secrets des connexions sociales ne sont plus
    recopiés en clair dans la table d'allauth, c'est cet adaptateur qui les
    lui fournit. Sans lui, les boutons Google, Apple et Facebook échouent.
    Avertissement, pour la même raison que jeiko.W003.
    """
    from django.conf import settings

    if getattr(settings, "SOCIALACCOUNT_ADAPTER", "") == ADAPTATEUR_SOCIAL_JEIKO:
        return []
    return [
        Warning(
            "allauth n'utilise pas l'adaptateur social de JEIKO : les connexions "
            "Google, Apple et Facebook n'ont pas accès à leurs secrets.",
            hint=f'Ajouter SOCIALACCOUNT_ADAPTER = "{ADAPTATEUR_SOCIAL_JEIKO}" au settings.py.',
            id="jeiko.W005",
        )
    ]


@register()
def check_adresse_de_reponse(app_configs, **kwargs):
    """
    Signale une messagerie sans adresse de réponse.

    C'est elle qui reçoit les demandes des formulaires de contact (quand un
    formulaire n'a pas de destinataire propre) et les réponses des clients.
    Vide, les demandes partaient vers l'adresse d'envoi — souvent une boîte
    que personne ne relève.
    """
    from django.db import OperationalError, ProgrammingError

    try:
        from jeiko.emailing.sending import get_mail_settings

        reglages = get_mail_settings()
    except (OperationalError, ProgrammingError):
        return []
    if reglages is None or (getattr(reglages, "reply_to_email", "") or "").strip():
        return []
    return [
        Warning(
            "Aucune adresse de réponse dans Réglages ▸ E-mails : les demandes des "
            "formulaires partent vers l'adresse d'envoi par défaut.",
            hint="Renseigner l'adresse de réponse (la boîte que vous relevez).",
            id="jeiko.W004",
        )
    ]

