# jeiko/agents/mcp.py
"""
Serveur MCP du site — l'API des agents, parlée dans le protocole des assistants.

Pourquoi
--------
Un assistant (Claude, ChatGPT…) savait déjà construire un site par l'API des
agents, mais à la main : il fabriquait chaque requête HTTP, relisait le guide,
recopiait le jeton dans ses appels. Le Model Context Protocol lui donne des
OUTILS nommés et décrits, qu'il appelle comme une fonction ; la connexion se
déclare une fois, dans le client, et le jeton reste dans cette configuration.

Un serveur PAR SITE : chaque installation JEIKO sert le sien, à
`/api/agent/mcp/`, avec les jetons de SES agents. Deux sites, deux connexions —
et un jeton d'un site n'ouvre jamais l'autre.

Ce qu'il fait, et ce qu'il ne fait pas
--------------------------------------
Il ne réimplémente RIEN. Chaque outil est rejoué, dans le même processus, sur
la vraie vue de l'API (`urls_api.py`) : mêmes droits (le rôle de l'agent), mêmes
validations, mêmes refus, même journal d'appels. Un outil ne peut donc pas
faire plus que l'API — ni moins, puisque `appeler_api` ouvre toutes ses routes,
y compris celles qui s'ajouteront.

Protocole : « Streamable HTTP », sans état (spécification MCP 2025-06-18).
Chaque POST porte un message JSON-RPC et reçoit sa réponse en JSON. Pas de flux
SSE — aucun outil n'en a besoin —, donc GET répond 405, comme le prévoit la
spécification.

Sécurité
--------
* Le jeton se présente dans `Authorization: Bearer …`, jamais ailleurs, et
  passe par `identifier()` — les sept gardes de l'API, HTTPS compris.
* Un appel d'outil ne s'authentifie PAS ici : la vue rejouée le fait, avec
  le même en-tête. Le quota compte donc un appel par message, pas deux.
* `appeler_api` ne peut viser que l'API des agents : le chemin est ramené
  sous `/api/agent/v1/`, et la vue résolue doit appartenir à `jeiko.agents`.
"""

import json
import logging
from urllib.parse import urlencode

from django.http import HttpRequest, HttpResponse, JsonResponse, QueryDict
from django.urls import Resolver404, resolve
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt

from .authentification import _reponse_de_refus, _tracer, identifier

logger = logging.getLogger(__name__)

PREFIXE_API = "/api/agent/v1/"
VERSIONS_DU_PROTOCOLE = ("2025-06-18", "2025-03-26", "2024-11-05")
METHODES_HTTP = ("GET", "POST", "PUT", "PATCH", "DELETE")

#: En-têtes recopiés sur la requête rejouée : ceux dont dépendent
#: l'authentification (jeton, adresse, HTTPS) et la construction d'URL.
_ENTETES_TRANSMIS = (
    "HTTP_AUTHORIZATION", "REMOTE_ADDR", "HTTP_X_FORWARDED_FOR", "HTTP_X_REAL_IP",
    "HTTP_X_FORWARDED_PROTO", "HTTP_X_FORWARDED_HOST", "HTTP_HOST",
    "SERVER_NAME", "SERVER_PORT", "wsgi.url_scheme", "HTTP_USER_AGENT",
)


# --------------------------------------------------------------------------- #
#  Outils
# --------------------------------------------------------------------------- #

#: Routes de l'API qui ne deviennent pas des outils : un alias, le filet des
#: URL inconnues.
_ROUTES_ECARTEES = {"guide_explicite", "route_inconnue", "fiches",
                    # Déjà dans le schéma de chaque outil.
                    "contrats"}

#: Noms imposés, là où la règle générale donnerait un nom obscur.
_NOMS_IMPOSES = {("guide", "GET"): "guide", ("whoami", "GET"): "qui_suis_je",
                 ("deplacer", "POST"): "deplacer",
                 # Objet unique du site : on le lit, on ne le liste pas.
                 ("identite", "GET"): "lire_identite"}

_VERBES = {"GET": "lire", "PATCH": "modifier", "DELETE": "supprimer", "PUT": "ecrire"}


def _nom_d_outil(route, methode, avec_identifiant):
    if (route, methode) in _NOMS_IMPOSES:
        return _NOMS_IMPOSES[(route, methode)]
    if methode == "GET" and not avec_identifiant:
        return f"lister_{route}"
    if methode == "POST":
        if route.endswith("_creer"):
            return f"creer_{route[:-len('_creer')]}"
        return f"ajouter_{route}"
    return f"{_VERBES[methode]}_{route}"


def _outils_generes():
    """
    Un outil par couple (route, méthode) de `urls_api.py`, calculé à chaque
    démarrage : une route ajoutée à l'API devient un outil sans une ligne de
    plus, et la liste ne peut pas prendre de retard sur l'API.
    """
    from django.urls.converters import IntConverter

    from . import urls_api
    from .contrats import tous_les_contrats
    from .guide import ROLE_DES_ROUTES

    contrats = tous_les_contrats()
    outils = {}
    for motif in urls_api.urlpatterns:
        route = motif.name
        vue = getattr(motif.callback, "view_class", None)
        if not route or route in _ROUTES_ECARTEES or vue is None:
            continue
        convertisseurs = getattr(motif.pattern, "converters", {})
        variables = {
            nom: ({"type": "integer", "minimum": 1} if isinstance(conv, IntConverter)
                  else {"type": "string"})
            for nom, conv in convertisseurs.items()
        }
        resume = (vue.__doc__ or "").strip().split("\n")[0].strip()
        for methode in ("GET", "POST", "PUT", "PATCH", "DELETE"):
            if not hasattr(vue, methode.lower()):
                continue
            nom = _nom_d_outil(route, methode, bool(variables))
            contrat = contrats.get((route, methode), {})
            proprietes = {
                cle: {**schema, **contrat.get("variables", {}).get(cle, {})}
                for cle, schema in variables.items()
            }
            requis = sorted(variables)
            if methode == "GET":
                # Une route sans filtre ne propose pas de « parametres » : un
                # argument qui ne sert à rien fait chercher ce qu'il pourrait
                # contenir.
                if contrat.get("parametres"):
                    proprietes["parametres"] = contrat["parametres"]
            elif methode == "DELETE" and not contrat.get("corps"):
                pass  # une suppression ne prend pas de corps
            else:
                # Le contrat donne la forme exacte du corps : une IA remplit
                # les champs d'après ce schéma, sans lire le guide.
                proprietes["corps"] = contrat.get("corps") or {
                    "type": "object",
                    "description": "Objet JSON envoyé à la route : champs décrits par l'outil « guide ».",
                }
                if methode in ("PUT", "PATCH") or contrat.get("corps", {}).get("required"):
                    requis.append("corps")
            chemin = f"/api/agent/v1/{motif.pattern}"
            quoi = contrat.get("description") or ROLE_DES_ROUTES.get(route, ("", resume))[1] or resume
            description = (f"{quoi} " if quoi else "") + f"({methode} {chemin})"
            outils[nom] = {
                "definition": {
                    "name": nom,
                    "description": description,
                    "inputSchema": {
                        "type": "object",
                        "properties": proprietes,
                        "required": requis,
                        "additionalProperties": False,
                    },
                },
                "route": route,
                "methode": methode,
                "variables": variables,
            }
    return outils


OUTIL_GENERIQUE = {
    "name": "appeler_api",
    "description": (
        "Appelle n'importe quelle route de l'API des agents de ce site (voir "
        "l'outil « guide »), si aucun outil dédié ne convient. `chemin` est "
        "relatif à /api/agent/v1/, par exemple « pages/12/sections/ » ; "
        "`corps` est l'objet JSON envoyé (POST, PUT, PATCH) ; `parametres` la "
        "chaîne de requête (GET). Mêmes droits, mêmes validations et même "
        "journal qu'un appel HTTP direct."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {
            "methode": {"type": "string", "enum": list(METHODES_HTTP)},
            "chemin": {"type": "string"},
            "corps": {"type": "object"},
            "parametres": {"type": "object"},
        },
        "required": ["methode", "chemin"],
        "additionalProperties": False,
    },
}


def liste_des_outils():
    return [o["definition"] for o in _outils_generes().values()] + [OUTIL_GENERIQUE]


class ArgumentsInvalides(Exception):
    pass


def _cible_de_l_outil(nom, arguments):
    """(méthode, chemin, corps, paramètres) d'un appel d'outil."""
    from django.urls import reverse

    if not isinstance(arguments, dict):
        raise ArgumentsInvalides("« arguments » doit être un objet.")

    if nom == OUTIL_GENERIQUE["name"]:
        inconnus = set(arguments) - {"methode", "chemin", "corps", "parametres"}
        if inconnus:
            raise ArgumentsInvalides(f"Argument(s) inconnu(s) : {', '.join(sorted(inconnus))}.")
        methode = str(arguments.get("methode", "")).upper()
        if methode not in METHODES_HTTP:
            raise ArgumentsInvalides(f"« methode » doit valoir {', '.join(METHODES_HTTP)}.")
        chemin = arguments.get("chemin")
        if not isinstance(chemin, str):
            raise ArgumentsInvalides("« chemin » doit être une chaîne.")
        corps = arguments.get("corps")
        parametres = arguments.get("parametres") or {}
        if corps is not None and not isinstance(corps, dict):
            raise ArgumentsInvalides("« corps » doit être un objet JSON.")
        if not isinstance(parametres, dict):
            raise ArgumentsInvalides("« parametres » doit être un objet.")
        return methode, chemin, corps, parametres

    outil = _outils_generes().get(nom)
    if outil is None:
        raise KeyError(nom)

    schema = outil["definition"]["inputSchema"]
    inconnus = set(arguments) - set(schema["properties"])
    manquants = set(schema["required"]) - set(arguments)
    if inconnus or manquants:
        attendus = ", ".join(sorted(schema["properties"])) or "aucun"
        raise ArgumentsInvalides(
            f"Arguments de « {nom} » : {attendus} (obligatoires : "
            f"{', '.join(schema['required']) or 'aucun'})."
        )

    valeurs = {}
    for cle, type_attendu in outil["variables"].items():
        valeur = arguments[cle]
        if type_attendu["type"] == "integer":
            if isinstance(valeur, bool) or not isinstance(valeur, int) or valeur < 1:
                raise ArgumentsInvalides(f"« {cle} » doit être un entier positif.")
        elif not isinstance(valeur, str) or not valeur or "/" in valeur:
            raise ArgumentsInvalides(f"« {cle} » doit être une chaîne sans « / ».")
        valeurs[cle] = valeur

    corps = arguments.get("corps")
    if corps is not None and not isinstance(corps, dict):
        raise ArgumentsInvalides("« corps » doit être un objet JSON.")
    parametres = arguments.get("parametres") or {}
    if not isinstance(parametres, dict):
        raise ArgumentsInvalides("« parametres » doit être un objet.")

    chemin = reverse(f"jeiko_agents_api:{outil['route']}", kwargs=valeurs)
    if outil["methode"] == "POST" and corps is None:
        corps = {}
    return outil["methode"], chemin, corps, parametres


def _chemin_dans_l_api(chemin):
    """Ramène `chemin` sous /api/agent/v1/, ou refuse d'en sortir."""
    chemin = chemin.strip()
    if "://" in chemin or chemin.startswith("//") or "\\" in chemin:
        raise ArgumentsInvalides("« chemin » est relatif à /api/agent/v1/, sans domaine.")
    chemin = chemin.split("?", 1)[0].lstrip("/")
    if chemin.startswith("api/agent/v1/"):
        chemin = chemin[len("api/agent/v1/"):]
    if any(segment == ".." for segment in chemin.split("/")):
        raise ArgumentsInvalides("« chemin » ne peut pas remonter l'arborescence.")
    if chemin and not chemin.endswith("/"):
        chemin += "/"
    return PREFIXE_API + chemin


class _RequeteRejouee(HttpRequest):
    """Requête interne : garde le schéma (HTTPS) de la requête MCP d'origine."""

    def __init__(self, origine):
        super().__init__()
        self._schema = origine.scheme

    def _get_scheme(self):
        return self._schema


def rejouer(request, methode, chemin, corps=None, parametres=None):
    """Exécute la vue de l'API visée, comme un appel HTTP. Rend (statut, données)."""
    chemin = _chemin_dans_l_api(chemin)
    try:
        correspondance = resolve(chemin)
    except Resolver404:
        return 404, {"erreur": f"Aucune route de l'API à « {chemin} »."}
    if not correspondance.func.__module__.startswith("jeiko.agents"):
        return 404, {"erreur": f"Aucune route de l'API à « {chemin} »."}

    sous = _RequeteRejouee(request)
    sous.method = methode
    sous.path = sous.path_info = chemin
    sous.META = {cle: request.META[cle] for cle in _ENTETES_TRANSMIS if cle in request.META}
    sous.META["REQUEST_METHOD"] = methode
    corps_brut = json.dumps(corps).encode() if corps is not None else b""
    sous._body = corps_brut
    sous.META["CONTENT_TYPE"] = "application/json"
    sous.META["CONTENT_LENGTH"] = str(len(corps_brut))
    requete = urlencode(parametres or {}, doseq=True)
    sous.META["QUERY_STRING"] = requete
    sous.GET = QueryDict(requete)
    sous.session = getattr(request, "session", None)

    reponse = correspondance.func(sous, *correspondance.args, **correspondance.kwargs)
    try:
        donnees = json.loads(reponse.content or b"null")
    except ValueError:
        donnees = {"contenu": reponse.content.decode("utf-8", "replace")}
    return reponse.status_code, donnees


# --------------------------------------------------------------------------- #
#  JSON-RPC
# --------------------------------------------------------------------------- #

def _resultat(identifiant, resultat):
    return {"jsonrpc": "2.0", "id": identifiant, "result": resultat}


def _erreur(identifiant, code, message):
    return {"jsonrpc": "2.0", "id": identifiant, "error": {"code": code, "message": message}}


def _nom_du_serveur(request):
    """Même nom que la skill et que la commande de la fiche agent :
    `jeiko-<domaine>` — un identifiant, pas un libellé."""
    from .skill import nom_de_la_skill

    return nom_de_la_skill(request.get_host())


def _version_du_paquet():
    from jeiko.administration.update_check import installed_version

    return installed_version() or "inconnue"


class _JetonRefuse(Exception):
    """Un outil rejoué a reçu 401 : le jeton n'ouvre plus rien."""


def _refus_mcp(request, refus):
    """
    Le refus du serveur MCP, avec ce qu'il faut à claude.ai pour se connecter.

    `WWW-Authenticate: Bearer resource_metadata="…"` sur le 401 : c'est ce qui
    déclenche l'autorisation OAuth chez Claude (voir `oauth.py`). Le plafond
    (429) garde sa réponse explicite.
    """
    from .authentification import REFUS
    from .oauth import entete_www_authenticate

    if refus is not None and refus.statut == 429:
        return _reponse_de_refus(refus)
    reponse = JsonResponse({"erreur": REFUS}, status=401)
    reponse["WWW-Authenticate"] = entete_www_authenticate(request)
    return reponse


@method_decorator(csrf_exempt, name="dispatch")
@method_decorator(never_cache, name="dispatch")
class ServeurMcp(View):
    """`/api/agent/mcp/` — voir l'en-tête du module."""

    http_method_names = ["post", "get", "delete", "options"]

    def get(self, request):
        # Pas de flux SSE côté serveur : la spécification demande 405.
        return HttpResponse(status=405)

    def delete(self, request):
        # Sans état : il n'y a pas de session MCP à fermer.
        return HttpResponse(status=405)

    def post(self, request):
        try:
            message = json.loads(request.body or b"")
        except ValueError:
            return JsonResponse(_erreur(None, -32700, "JSON illisible."), status=400)

        # Lots JSON-RPC : chaque message est traité, les notifications n'ont pas
        # de réponse.
        lot = isinstance(message, list)
        messages = message if lot else [message]
        if not messages:
            return JsonResponse(_erreur(None, -32600, "Lot vide."), status=400)

        # Tout ce qui n'est pas un appel d'outil s'authentifie ici ; l'appel
        # d'outil, par la vue qu'il rejoue (un seul décompte du quota).
        if not all(isinstance(m, dict) and m.get("method") == "tools/call" for m in messages):
            agent, jeton, refus = identifier(request)
            if refus is not None:
                _tracer(request, refus.agent, refus.prefixe, refus.statut, refus.motif)
                return _refus_mcp(request, refus)
            _tracer(request, agent, jeton.prefixe, 200)

        try:
            reponses = [r for r in (self._traiter(request, m) for m in messages) if r is not None]
        except _JetonRefuse:
            # Un appel d'outil dont la vue rejouée refuse le jeton (révoqué,
            # agent désactivé…) : un vrai 401 HTTP, pas une erreur d'outil.
            # Sinon claude.ai affiche l'erreur sans jamais proposer de se
            # reconnecter, et le connecteur reste mort (P-04).
            return _refus_mcp(request, None)
        if not reponses:
            return HttpResponse(status=202)
        return JsonResponse(reponses if lot else reponses[0], safe=False)

    def _traiter(self, request, message):
        if not isinstance(message, dict) or message.get("jsonrpc") != "2.0":
            return _erreur(None, -32600, "Message JSON-RPC 2.0 attendu.")
        identifiant = message.get("id")
        methode = message.get("method")
        params = message.get("params") or {}
        notification = "id" not in message

        if methode is None:
            return None  # réponse d'un client à une requête : rien à faire
        if notification:
            return None  # notifications/initialized, annulations…

        if methode == "initialize":
            demandee = params.get("protocolVersion")
            version = demandee if demandee in VERSIONS_DU_PROTOCOLE else VERSIONS_DU_PROTOCOLE[0]
            return _resultat(identifiant, {
                "protocolVersion": version,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": _nom_du_serveur(request), "version": _version_du_paquet()},
                "instructions": (
                    "Serveur MCP d'un site JEIKO. Appelez d'abord l'outil « guide » : "
                    "il décrit chaque route et les pièges connus. « appeler_api » "
                    "ouvre toute l'API des agents de ce site."
                ),
            })
        if methode == "ping":
            return _resultat(identifiant, {})
        if methode == "tools/list":
            return _resultat(identifiant, {"tools": liste_des_outils()})
        if methode == "tools/call":
            return self._appeler_un_outil(request, identifiant, params)
        return _erreur(identifiant, -32601, f"Méthode inconnue : {methode}.")

    def _appeler_un_outil(self, request, identifiant, params):
        nom = params.get("name")
        try:
            methode, chemin, corps, parametres = _cible_de_l_outil(nom, params.get("arguments") or {})
            statut, donnees = rejouer(request, methode, chemin, corps, parametres)
        except KeyError:
            return _erreur(identifiant, -32602, f"Outil inconnu : {nom}.")
        except ArgumentsInvalides as souci:
            return _erreur(identifiant, -32602, str(souci))

        if statut == 401:
            raise _JetonRefuse()
        # Un plafond (429) remonte comme toute erreur d'outil, avec le message
        # de l'API, qui dit quand réessayer.
        texte = json.dumps({"statut": statut, "reponse": donnees}, ensure_ascii=False, indent=2)
        return _resultat(identifiant, {
            "content": [{"type": "text", "text": texte}],
            "isError": statut >= 400,
        })
