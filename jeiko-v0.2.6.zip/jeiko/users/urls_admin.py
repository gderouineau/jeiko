from django.urls import path

from .views_admin import (
    # Utilisateurs
    AdminUserListView, AdminUserDetailView, AdminUserUpdateView,

    # Rôles & permissions
    RoleListView, RoleCreateView, RoleUpdateView, RoleDeleteView,
    RolePermissionCreateView, RolePermissionDeleteView,
    RoleAssignmentCreateView, RoleAssignmentDeleteView,
    BulkAssignRoleView, BulkRevokeRoleView,

    # Providers (allauth)
    ProviderListView, ProviderCreateView, ProviderUpdateView, ProviderDeleteView,

    # Sécurité / 2FA / Sessions / Audit
    TwoFactorDeviceListView, TwoFactorDeviceCreateView, TwoFactorDeviceUpdateView, TwoFactorDeviceDeleteView,
    UserSessionRevokeView, SecurityEventListView,

    # Consentements & préférences
    ConsentCreateView, MarketingPreferenceUpdateView,

    # Notifications
    NotificationChannelCreateView, NotificationComposeView, BulkNotificationView,

    # Bridge User ↔ Prospect
    ProspectLinkCreateView, ProspectLinkDeleteView,
)

app_name = 'jeiko_administration_users'

urlpatterns = [
    # ---------------------------
    # Utilisateurs
    # ---------------------------
    path('users/', AdminUserListView.as_view(), name='user_list'),
    path('user/<int:pk>/', AdminUserDetailView.as_view(), name='user_detail'),
    path('user/<int:pk>/edit/', AdminUserUpdateView.as_view(), name='user_edit'),

    # ---------------------------
    # Rôles & permissions
    # ---------------------------
    path('roles/', RoleListView.as_view(), name='role_list'),
    path('roles/new/', RoleCreateView.as_view(), name='role_create'),
    path('roles/<int:pk>/edit/', RoleUpdateView.as_view(), name='role_update'),
    path('roles/<int:pk>/delete/', RoleDeleteView.as_view(), name='role_delete'),

    path('roles/permission/new/', RolePermissionCreateView.as_view(), name='role_permission_create'),
    path('roles/permission/<int:pk>/delete/', RolePermissionDeleteView.as_view(), name='role_permission_delete'),

    path('roles/assign/new/', RoleAssignmentCreateView.as_view(), name='role_assignment_create'),
    path('roles/assign/<int:pk>/delete/', RoleAssignmentDeleteView.as_view(), name='role_assignment_delete'),

    path('roles/assign/bulk/', BulkAssignRoleView.as_view(), name='role_assignment_bulk'),
    path('roles/revoke/bulk/', BulkRevokeRoleView.as_view(), name='role_revoke_bulk'),

    # ---------------------------
    # Providers (allauth)
    # ---------------------------
    path('providers/', ProviderListView.as_view(), name='provider_list'),
    path('providers/new/', ProviderCreateView.as_view(), name='provider_create'),
    path('providers/<int:pk>/edit/', ProviderUpdateView.as_view(), name='provider_update'),
    path('providers/<int:pk>/delete/', ProviderDeleteView.as_view(), name='provider_delete'),

    # ---------------------------
    # Sécurité / 2FA / Sessions / Audit
    # ---------------------------
    path('security/twofa/', TwoFactorDeviceListView.as_view(), name='twofa_list'),
    path('security/twofa/new/', TwoFactorDeviceCreateView.as_view(), name='twofa_create'),
    path('security/twofa/<int:pk>/edit/', TwoFactorDeviceUpdateView.as_view(), name='twofa_update'),
    path('security/twofa/<int:pk>/delete/', TwoFactorDeviceDeleteView.as_view(), name='twofa_delete'),

    path('security/sessions/revoke/', UserSessionRevokeView.as_view(), name='session_revoke'),
    path('security/events/', SecurityEventListView.as_view(), name='security_event_list'),

    # ---------------------------
    # Consentements & préférences
    # ---------------------------
    path('consents/new/', ConsentCreateView.as_view(), name='consent_create'),
    path('marketing/<int:pk>/edit/', MarketingPreferenceUpdateView.as_view(), name='marketing_pref_update'),

    # ---------------------------
    # Notifications
    # ---------------------------
    path('notifications/channel/new/', NotificationChannelCreateView.as_view(), name='notif_channel_create'),
    path('notifications/compose/', NotificationComposeView.as_view(), name='notif_compose'),
    path('notifications/bulk/', BulkNotificationView.as_view(), name='notif_bulk'),

    # ---------------------------
    # Bridge User ↔ Prospect
    # ---------------------------
    path('prospects/link/new/', ProspectLinkCreateView.as_view(), name='prospect_link_create'),
    path('prospects/link/<int:pk>/delete/', ProspectLinkDeleteView.as_view(), name='prospect_link_delete'),
]
