"""
Codes promo : est-ce que ce code vaut pour ce panier, et combien il retire.

Deux fonctions, appelées par le panier (pour afficher) et par
`preparer_commande` (pour facturer) — le même calcul des deux côtés, comme
pour le port.

* `verifier` dit POURQUOI un code ne vaut pas. Un code ignoré en silence est
  la première réclamation d'une boutique : le client croit avoir eu sa remise.
* `remise` répartit la réduction sur les lignes concernées, au prorata de leur
  TTC, et en déduit la TVA retirée taux par taux.

Un code limité (« les 100 premiers ») compte ses usages PAYÉS, mais aussi
ceux RÉSERVÉS : une commande en attente de paiement garde son usage pendant
`RESERVATION` (comme WooCommerce garde le stock et les codes d'une commande
impayée). Sans cela, deux clients qui préparaient leur paiement en même temps
passaient tous deux le contrôle du dernier usage, et payaient tous les deux.
La préparation verrouille la ligne du code (`services.preparer_commande`) :
deux préparations simultanées comptent l'une après l'autre.

Ce que ce module ne fait PAS : cumuler plusieurs codes (un seul par panier,
comme le réglage par défaut de PrestaShop et Shopify) ; ni refuser un paiement
arrivé après la fin de la réservation — un client resté plus de trente minutes
sur l'écran de paiement, pendant que d'autres ont pris les derniers usages, a
payé : on honore, le plafond est dépassé d'autant.

La réservation part de la PREMIÈRE préparation qui porte le code
(`Order.coupon_reserved_at`) et n'est PAS prolongée en réaffichant l'écran de
paiement : sinon un panier gardait un usage sans fin, sans jamais payer, et
bloquait un code « N premiers » pour les vrais clients (P6-b).
"""

from datetime import timedelta
from decimal import Decimal

from django.db.models import Q
from django.utils import timezone
from django.utils.translation import gettext as _

from .models import Coupon, Order, _montant

USAGES_COMPTES = (
    Order.PAYMENT_STATUS_PAID, *Order.PAYMENT_STATUSES_REMBOURSEMENT,
)

# Durée pendant laquelle une commande impayée garde son usage du code. Elle
# couvre la saisie de la carte et une authentification 3-D Secure, pas un
# panier oublié.
RESERVATION = timedelta(minutes=30)


class CodeInvalide(Exception):
    """Le message s'adresse au client."""


def trouver(code):
    code = (code or "").strip().upper()
    coupon = Coupon.objects.filter(code=code).first() if code else None
    if coupon is None:
        raise CodeInvalide(_("Ce code promo n'existe pas."))
    return coupon


def lignes_concernees(coupon, lignes):
    types = set(coupon.product_types.values_list("pk", flat=True))
    produits = set(coupon.products.values_list("pk", flat=True))
    if not types and not produits:
        return list(lignes)
    return [l for l in lignes if l.product_id in produits or l.product.type_id in types]


def usages(coupon, panier=None):
    """Commandes qui consomment un usage : payées, ou réservées (voir en tête).

    Celle de `panier` est exclue : un client ne se dispute pas son propre
    usage d'une préparation à l'autre.
    """
    depuis = timezone.now() - RESERVATION
    # On compte sur `coupon_reserved_at` (figé à la première préparation), pas
    # sur `updated_at` que chaque préparation rafraîchit : sinon la réservation
    # se renouvelait à chaque affichage de l'écran de paiement, sans fin (P6-b).
    qs = Order.objects.filter(coupon=coupon).filter(
        Q(payment_status__in=USAGES_COMPTES)
        | Q(payment_status=Order.PAYMENT_STATUS_PENDING, coupon_reserved_at__gte=depuis)
    )
    return qs.exclude(cart=panier) if panier is not None else qs


def verifier(coupon, user, lignes, panier=None):
    """Lève `CodeInvalide` si le code ne vaut pas pour ce panier."""
    maintenant = timezone.now()
    if not coupon.is_active:
        raise CodeInvalide(_("Ce code promo n'est plus actif."))
    if coupon.starts_at and maintenant < coupon.starts_at:
        raise CodeInvalide(_("Ce code promo n'est pas encore valable."))
    if coupon.ends_at and maintenant > coupon.ends_at:
        raise CodeInvalide(_("Ce code promo a expiré."))

    payees = usages(coupon, panier)
    if coupon.usage_limit is not None and payees.count() >= coupon.usage_limit:
        raise CodeInvalide(_("Ce code promo a atteint son nombre d'utilisations."))
    if (coupon.usage_limit_per_user is not None and user is not None
            and getattr(user, "is_authenticated", False)
            and payees.filter(user=user).count() >= coupon.usage_limit_per_user):
        raise CodeInvalide(_("Vous avez déjà utilisé ce code promo."))

    concernees = lignes_concernees(coupon, lignes)
    if not concernees:
        raise CodeInvalide(_("Ce code promo ne s'applique à aucun article du panier."))
    total = sum((l.total_ttc for l in lignes), Decimal("0"))
    if coupon.minimum_amount is not None and total < coupon.minimum_amount:
        raise CodeInvalide(
            _("Ce code promo demande un panier d'au moins %(minimum)s.")
            % {"minimum": coupon.minimum_amount}
        )


def remise(coupon, lignes):
    """`(ttc, tva)` retirés par le code. Zéro pour la livraison offerte."""
    zero = Decimal("0.00")
    if coupon is None or coupon.kind == Coupon.KIND_FREE_SHIPPING:
        return zero, zero
    concernees = lignes_concernees(coupon, lignes)
    base = sum((l.total_ttc for l in concernees), Decimal("0"))
    if not base:
        return zero, zero
    if coupon.kind == Coupon.KIND_PERCENT:
        ttc = _montant(base * min(coupon.value, Decimal("100")) / 100)
    else:
        ttc = _montant(min(coupon.value, base))
    # TVA retirée : chaque ligne perd sa part de remise, à son propre taux.
    ht = sum(
        (ttc * l.total_ttc / base / (1 + l.tax_rate / Decimal("100")) for l in concernees),
        Decimal("0"),
    )
    return ttc, _montant(ttc - ht)


def repartir(coupon, lignes, remise_ttc):
    """{id de ligne: part de la remise}, au prorata du TTC des lignes concernées."""
    if coupon is None or not remise_ttc:
        return {}
    concernees = lignes_concernees(coupon, lignes)
    base = sum((l.total_ttc for l in concernees), Decimal("0"))
    return {l.pk: remise_ttc * l.total_ttc / base for l in concernees} if base else {}


def livraison_offerte(coupon):
    return coupon is not None and coupon.kind == Coupon.KIND_FREE_SHIPPING
