"""
Factures et avoirs : ventiler la TVA, numéroter, sans trou.

Pourquoi ici et pas dans la vue de la facture
---------------------------------------------
Une facture française porte un numéro unique, attribué dans un ordre
chronologique continu — un trou ou un doublon se remarque en contrôle fiscal.
Le numéro se prend donc au RÈGLEMENT, dans la transaction de
`mark_order_paid`, sous verrou de la ligne des réglages : deux paiements
simultanés ne peuvent pas recevoir le même. Une commande jamais payée n'en
consomme aucun.

Un remboursement après facture ne modifie pas la facture : il fait l'objet
d'un AVOIR, numéroté de la même façon (`numeroter_avoir`).

La ventilation de la TVA par taux est calculée à la préparation de la
commande (`ventiler`), quand on sait encore quelles lignes la remise concerne
et lesquelles sont expédiées.

La facture et l'avoir sont UN gabarit (`shop/invoice.html`), servi en page
imprimable, en PDF à télécharger, et joint en PDF à l'e-mail de règlement
(`piece_jointe_facture`, moteur `jeiko.pdf.moteur`). Le contexte se construit ici, une fois,
pour que les trois ne puissent pas diverger.
"""

from decimal import Decimal

from django.db import transaction
from django.utils import timezone
from django.utils.translation import gettext as _

from .models import ShopSettings, _montant

CENT = Decimal("0.01")


def ventiler(lignes, remise_par_ligne, port_ttc, expediees, taux_par_defaut):
    """
    `{taux: {"ht", "tva", "ttc"}}` en Decimal, dont les TTC somment exactement
    au total à payer.

    * `remise_par_ligne` : {id de ligne: TTC retiré} ;
    * le port se répartit sur les lignes expédiées au prorata de leur TTC —
      la règle de l'accessoire — ou sur le taux par défaut à défaut.
    """
    ttc_par_taux = {}

    def ajouter(taux, montant):
        cle = Decimal(taux).quantize(CENT)
        ttc_par_taux[cle] = ttc_par_taux.get(cle, Decimal("0")) + montant

    for l in lignes:
        ajouter(l.tax_rate, l.total_ttc - remise_par_ligne.get(l.pk, Decimal("0")))

    if port_ttc:
        base = sum((l.total_ttc for l in expediees), Decimal("0"))
        if base:
            for l in expediees:
                ajouter(l.tax_rate, port_ttc * l.total_ttc / base)
        else:
            ajouter(taux_par_defaut, port_ttc)

    total = _montant(sum(ttc_par_taux.values(), Decimal("0")))
    resultat = {taux: _montant(v) for taux, v in ttc_par_taux.items() if v}
    # Les arrondis par taux ne doivent pas déplacer le total d'un centime :
    # l'écart va au taux le plus lourd.
    if resultat:
        ecart = total - sum(resultat.values(), Decimal("0"))
        if ecart:
            lourd = max(resultat, key=resultat.get)
            resultat[lourd] += ecart
    return {
        taux: {"ttc": ttc, "ht": _montant(ttc / (1 + taux / 100)),
               "tva": ttc - _montant(ttc / (1 + taux / 100))}
        for taux, ttc in sorted(resultat.items())
    }


def en_json(ventilation):
    return {str(t): {k: str(v) for k, v in m.items()} for t, m in ventilation.items()}


def ventilation_de(order):
    """La ventilation d'une commande, en Decimal ; reconstituée pour une commande antérieure."""
    if order.vat_breakdown:
        return {
            Decimal(t): {k: Decimal(v) for k, v in m.items()}
            for t, m in order.vat_breakdown.items()
        }
    # Commande antérieure à la ventilation : ses lignes seules.
    lignes = list(order.lines.all())
    return ventiler(lignes, {}, order.shipping_ttc, [], ShopSettings.get_solo().default_tax_rate)


def ventilation_avoir(refund):
    """La TVA d'un avoir : celle de la facture, au prorata du montant remboursé."""
    order = refund.order
    if not order.total_ttc:
        return {}
    part = Decimal(refund.amount) / order.total_ttc
    lignes = {}
    for taux, m in ventilation_de(order).items():
        ttc = _montant(m["ttc"] * part)
        if ttc:
            ht = _montant(ttc / (1 + taux / 100))
            lignes[taux] = {"ttc": ttc, "ht": ht, "tva": ttc - ht}
    if lignes:
        ecart = _montant(refund.amount) - sum((m["ttc"] for m in lignes.values()), Decimal("0"))
        if ecart:
            lourd = max(lignes, key=lambda t: lignes[t]["ttc"])
            lignes[lourd]["ttc"] += ecart
            lignes[lourd]["tva"] = lignes[lourd]["ttc"] - lignes[lourd]["ht"]
    return lignes


def _prochain(reglages, prefixe, champ_annee, champ_compteur):
    annee = timezone.localdate().year
    if getattr(reglages, champ_annee) != annee:
        setattr(reglages, champ_annee, annee)
        setattr(reglages, champ_compteur, 0)
    setattr(reglages, champ_compteur, getattr(reglages, champ_compteur) + 1)
    reglages.save(update_fields=[champ_annee, champ_compteur])
    return f"{prefixe}{annee}-{getattr(reglages, champ_compteur):05d}"


@transaction.atomic
def numeroter_facture(order):
    """Attribue le numéro de facture d'une commande réglée. Idempotent."""
    if order.invoice_number:
        return order.invoice_number
    ShopSettings.get_solo()
    reglages = ShopSettings.objects.select_for_update().get(pk=1)
    order.invoice_number = _prochain(reglages, reglages.invoice_prefix, "invoice_year", "invoice_counter")
    order.invoiced_at = timezone.now()
    order.save(update_fields=["invoice_number", "invoiced_at"])
    return order.invoice_number


@transaction.atomic
def numeroter_avoir(refund):
    """Attribue son numéro à l'avoir d'un remboursement d'une commande facturée."""
    if refund.credit_note_number or not refund.order.invoice_number:
        return refund.credit_note_number
    ShopSettings.get_solo()
    reglages = ShopSettings.objects.select_for_update().get(pk=1)
    refund.credit_note_number = _prochain(
        reglages, reglages.credit_note_prefix, "credit_note_year", "credit_note_counter")
    refund.save(update_fields=["credit_note_number"])
    return refund.credit_note_number


# --------------------------------------------------------------------------
#  Le document : page, PDF, pièce jointe
# --------------------------------------------------------------------------

def _entete():
    from jeiko.administration.models import WebSite

    site = WebSite.objects.select_related("identity").first()
    return {
        "vendeur": getattr(site, "identity", None) if site else None,
        "reglages": ShopSettings.get_solo(),
    }


def contexte_facture(order):
    return {
        **_entete(), "order": order, "lines": order.lines.all(),
        "ventilation": ventilation_de(order), "titre": _("Facture"),
        "numero": order.invoice_number, "date": order.invoiced_at,
    }


def contexte_avoir(refund):
    return {
        **_entete(), "order": refund.order, "refund": refund,
        "ventilation": ventilation_avoir(refund), "titre": _("Avoir"),
        "numero": refund.credit_note_number, "date": refund.created_at,
    }


def document_pdf(contexte):
    """Lève `jeiko.pdf.moteur.MoteurPDFAbsent` sur un serveur sans moteur."""
    from jeiko.pdf.moteur import gabarit_en_pdf

    return gabarit_en_pdf("shop/invoice.html", {**contexte, "en_pdf": True})


def nom_du_fichier(contexte):
    return f"{contexte['titre']}-{contexte['numero']}.pdf".replace(" ", "-")


def piece_jointe_facture(order):
    """`(nom, octets, type)` pour un e-mail ; None sans facture ou sans moteur."""
    from jeiko.pdf.moteur import MoteurPDFAbsent

    if not order.invoice_number:
        return None
    contexte = contexte_facture(order)
    try:
        return nom_du_fichier(contexte), document_pdf(contexte), "application/pdf"
    except MoteurPDFAbsent:
        return None
