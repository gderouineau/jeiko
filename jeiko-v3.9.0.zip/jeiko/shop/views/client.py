from django.contrib import messages
from django.http import Http404, HttpResponsePermanentRedirect, HttpResponseRedirect
from django.shortcuts import render, get_object_or_404, redirect
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import ensure_csrf_cookie

from jeiko.custom_objects.models import CustomObject
from jeiko.custom_objects.services import OBJECT_VALUE_PREFETCH, contexte_de_fiche
from jeiko.shop.models import Product, ProductType, Cart, CartItem, ShopSettings
from jeiko.shop import promotions
from jeiko.shop.services import compute_order_totals, rafraichir_les_prix
from jeiko.shop.state import require_shop_online
from jeiko.administration_pages.querysets import public_pages
from django.utils.translation import gettext_lazy as _


class BoutiqueEnLigneRequiredMixin:
    """Garde commune aux fiches, au panier et à ses actions."""

    def dispatch(self, request, *args, **kwargs):
        require_shop_online()
        return super().dispatch(request, *args, **kwargs)


@method_decorator(ensure_csrf_cookie, name="get")
class ProductView(BoutiqueEnLigneRequiredMixin, View):
    """
    Vue client pour afficher un produit.
    URL canonique : /shop/<product_type_code>/<product_sku>/

    C'est la page de référence de la fiche : elle rend le même gabarit que
    CustomObjectView, augmenté du prix, du stock et du panier.

    Sur un site en plusieurs langues, `/en/shop/…` sert le MÊME produit — un
    prix, un stock, une référence — avec la version anglaise de sa fiche, ou
    sa fiche d'origine tant qu'elle n'est pas traduite.
    """

    # `pages/main.html`, comme PageView, plus ce qui vient SOUS la fiche —
    # avis et produits associés — hors du corps mis en cache.
    template_name = "shop/product_page.html"

    def get(self, request, *args, **kwargs):
        product_sku = kwargs["product_sku"]
        product_type_code = kwargs["product_type_code"]

        qs = Product.objects.select_related("type")

        # Un produit retiré de la vente ne doit pas être servi au public : sans
        # ce filtre, il suffisait de connaître le SKU. Le staff garde l'accès
        # pour la prévisualisation, comme sur CustomObjectView.
        en_preversion = request.user.is_staff
        if not en_preversion:
            qs = qs.filter(is_active=True)

        # Le code du type était extrait de l'URL puis ignoré : n'importe quelle
        # valeur menait à la fiche. On l'exige — par son code traduit dans la
        # langue lue, sinon par son code d'origine (jeiko/modeles_par_langue.py).
        langue = getattr(request, "langue_du_prefixe", "")
        product = get_object_or_404(
            qs,
            sku=product_sku,
            type__in=ProductType.par_adresse(product_type_code, langue),
        )

        # La fiche servie : sous /en/, la version anglaise ; à défaut — et sans
        # préfixe — la fiche d'origine. Une fiche encore en brouillon n'est pas
        # servie au public, pas plus qu'un produit retiré de la vente.
        fiches = (
            CustomObject.objects
            .select_related(
                "model", "model__page_template", "metadata",
                "product__type", "traduction_de__product__type",
            )
            .prefetch_related(*OBJECT_VALUE_PREFETCH)
        )
        if not en_preversion:
            fiches = fiches.filter(is_published=True)
        obj = (
            fiches.filter(traduction_de_id=product.content_id, langue=langue).first()
            if langue else None
        ) or fiches.filter(pk=product.content_id).first()
        if obj is None:
            raise Http404("La fiche de ce produit n'est pas publiée.")

        # Une seule adresse par langue : `/en/shop/ateliers/…` mène à
        # `/en/shop/workshops/…` dès que le type a son code anglais. 302 sous
        # un préfixe, comme pour une page : une traduction se pose et se
        # retire, l'adresse qui répond change avec elle.
        canonical_path = obj.get_absolute_url()
        if request.path != canonical_path:
            if langue:
                return HttpResponseRedirect(canonical_path)
            return HttpResponsePermanentRedirect(canonical_path)

        shop_settings = ShopSettings.get_solo()

        context = {
            "product": product,
            "product_price": (
                product.price_ttc
                if shop_settings.display_prices_including_tax
                else product.price_ht
            ),
            "product_price_ttc": product.price_ttc,
            "product_price_ht": product.price_ht,
            "product_price_includes_tax": shop_settings.display_prices_including_tax,
            "product_sku": product.sku,
            "product_stock": product.stock_quantity,
            # `est_disponible` et non le stock brut : un service n'est pas
            # épuisé parce que personne n'a saisi de quantité.
            "product_is_in_stock": product.est_disponible,
            # Les déclinaisons, pour le sélecteur du bouton « Ajouter au
            # panier » : libellé, prix affiché, disponibilité.
            "product_variants": [
                {
                    "id": v.pk, "label": v.label, "sku": v.sku,
                    "price": v.price_ttc if shop_settings.display_prices_including_tax else v.prix_ht,
                    "available": v.est_disponible,
                }
                for v in product.variantes_actives
            ],
        }

        # Sous la fiche : avis clients et « Vous aimerez aussi », selon les
        # réglages de la boutique.
        from jeiko.shop import catalogue
        from jeiko.shop.models import ProductReview

        if shop_settings.reviews_enabled:
            moyenne, nombre = catalogue.note(product)
            context.update({
                "avis_actifs": True,
                "avis": ProductReview.objects.filter(product=product, is_approved=True)[:30],
                "avis_moyenne": moyenne,
                "avis_nombre": nombre,
                "avis_possible": catalogue.a_achete(request.user, product),
                "mon_avis": (ProductReview.objects.filter(product=product, user=request.user).first()
                             if request.user.is_authenticated else None),
            })
        if shop_settings.show_related_products:
            context["produits_associes"] = catalogue.associes(product)
        # « Prévenez-moi » : sur un produit épuisé, ou une déclinaison épuisée.
        context["alerte_variantes"] = [v for v in context["product_variants"] if not v["available"]]
        context["alerte_stock"] = (not product.est_disponible) or bool(context["alerte_variantes"])
        context["envies_actives"] = shop_settings.wishlist_enabled
        if shop_settings.wishlist_enabled and request.user.is_authenticated:
            from jeiko.shop.models import WishlistItem
            context["dans_mes_envies"] = WishlistItem.objects.filter(
                user=request.user, product=product).exists()

        # La fiche, dans le gabarit de sa langue. APRÈS les clés du produit :
        # un champ que le modèle déclare l'emporte sur ce que la boutique
        # offre sous le même nom, comme pour les jetons réservés.
        context.update(contexte_de_fiche(request, obj))

        return render(request, self.template_name, context)


class ShopHomeView(BoutiqueEnLigneRequiredMixin, View):
    """Point d'entrée `/shop/`, redirigé vers une page classique choisie."""

    def get(self, request):
        settings = ShopSettings.get_solo()
        page = settings.homepage
        if page is None:
            # Sans choix explicite, on évite d'inventer une page de boutique :
            # le site garde sa page d'accueil normale et l'admin peut revenir
            # ici pour choisir la page dédiée.
            # … dans la langue que lit le visiteur (site en plusieurs langues).
            from jeiko.langues_du_site import accueil
            return redirect(accueil())
        if not public_pages().filter(pk=page.pk).exists():
            from django.http import Http404
            raise Http404("La page d’accueil de la boutique n’est pas publiée.")
        return redirect(page.get_absolute_url())


# ----------------------------------------------------------------------
#  Cart Views
# ----------------------------------------------------------------------

# Le panier a déménagé dans `jeiko.shop.cart` : sa reprise à la connexion est
# branchée sur un signal, et le module n'a donc pas à importer les vues. Le nom
# reste exposé ici, plusieurs appelants l'important depuis ce module.
from ..cart import get_or_create_cart  # noqa: E402,F401


class CartDetailView(BoutiqueEnLigneRequiredMixin, View):
    template_name = "shop/cart_detail.html"

    def get(self, request):
        cart = get_or_create_cart(request)
        # Le panier montre le prix d'aujourd'hui, celui qu'on encaissera.
        rafraichir_les_prix(cart)
        items = cart.items.select_related("product", "product__content", "variant").all()
        shop_settings = ShopSettings.get_solo()
        
        total_ht, total_tva, total_ttc = compute_order_totals(items)

        # Un code qui ne vaut plus (expiré, épuisé, panier sous le minimum)
        # est retiré EN LE DISANT : le client ne doit pas croire à une remise
        # qu'il n'aura pas.
        remise_ttc = remise_tva = 0
        if cart.coupon_id:
            try:
                promotions.verifier(cart.coupon, request.user, list(items), panier=cart)
            except promotions.CodeInvalide as exc:
                messages.warning(request, _("Le code %(code)s a été retiré : %(motif)s") % {
                    "code": cart.coupon.code, "motif": exc})
                cart.coupon = None
                cart.save(update_fields=["coupon", "updated_at"])
            else:
                remise_ttc, remise_tva = promotions.remise(cart.coupon, list(items))

        context = {
            "cart": cart,
            "items": items,
            "coupon": cart.coupon,
            "remise_ttc": remise_ttc,
            "total_ht": total_ht,
            "total_tva": total_tva - remise_tva,
            "total_ttc": total_ttc - remise_ttc,
            "sous_total_ttc": total_ttc,
            "display_prices_including_tax": shop_settings.display_prices_including_tax,
            "shop_currency": shop_settings.currency,
        }
        return render(request, self.template_name, context)


class AddToCartView(BoutiqueEnLigneRequiredMixin, View):
    def post(self, request, product_id):
        cart = get_or_create_cart(request)
        # Même filtre que ProductView : un produit retiré de la vente ou dont
        # la fiche est en brouillon ne doit pas pouvoir entrer dans un panier,
        # même en connaissant son identifiant.
        product = get_object_or_404(
            Product,
            pk=product_id,
            is_active=True,
            content__is_published=True,
        )

        try:
            quantity = int(request.POST.get("quantity", 1))
        except (TypeError, ValueError):
            quantity = 1
        if quantity < 1:
            quantity = 1

        # Un produit à déclinaisons ne se met au panier qu'avec l'une d'elles.
        # Depuis une grille de produits, où le bouton n'en propose pas, on
        # renvoie à la fiche pour la choisir.
        variante = None
        if product.variantes_actives:
            variante = next(
                (v for v in product.variantes_actives
                 if str(v.pk) == (request.POST.get("variant") or "")), None)
            if variante is None:
                messages.info(request, _("Choisissez une option pour « %(title)s ».") % {"title": product.title})
                return redirect(product.get_absolute_url())

        # Un produit qui ne s'épuise pas — service, abonnement, formation —
        # est toujours servable : voir `Product.suit_le_stock`.
        if not product.peut_servir(quantity, variante):
            messages.error(
                request,
                _("« %(title)s » n'est plus disponible en quantité suffisante.") % {"title": product.title},
            )
            return redirect("jeiko_client_shop:cart_detail")

        # On cherche si l'item existe déjà
        item, created = CartItem.objects.get_or_create(
            cart=cart,
            product=product,
            variant=variante,
            defaults={
                "quantity": 0, # On ajoutera la quantité juste après
                "unit_price_ht": product.price_ht,
                "tax_rate": product.tax_rate,
                "currency": product.currency,
            }
        )
        # Le prix du jour, toujours : le panier n'en fige aucun.
        item.unit_price_ht = item.prix_ht_actuel
        item.tax_rate = product.tax_rate
        
        item.quantity += quantity
        item.save()
        
        return redirect("jeiko_client_shop:cart_detail")


#: Quantité maximale par ligne de panier. Une commande légitime reste très en
#: dessous ; au-delà, c'est une saisie erronée ou une tentative de faire
#: déborder les calculs de total.
MAX_CART_QUANTITY = 999


class UpdateCartItemView(BoutiqueEnLigneRequiredMixin, View):
    def post(self, request, item_id):
        cart = get_or_create_cart(request)
        item = get_object_or_404(CartItem, pk=item_id, cart=cart)

        action = request.POST.get("action")

        if action == "update":
            # `int()` était appelé sans garde : une valeur non numérique
            # renvoyait une 500. `AddToCartView`, deux fonctions plus haut,
            # protégeait déjà le même appel.
            try:
                quantity = int(request.POST.get("quantity", item.quantity))
            except (TypeError, ValueError):
                messages.error(request, _("Quantité invalide."))
                return redirect("jeiko_client_shop:cart_detail")

            if quantity <= 0:
                item.delete()
                return redirect("jeiko_client_shop:cart_detail")

            quantity = min(quantity, MAX_CART_QUANTITY)

            # Le stock n'était vérifié qu'à l'ajout : on pouvait porter une
            # ligne au-delà du disponible en passant par la mise à jour.
            produit = item.product
            if produit and not item.peut_servir(quantity):
                quantity = max((item.variant or produit).stock_quantity or 0, 0)
                if quantity == 0:
                    item.delete()
                    messages.error(
                        request,
                        _("« %(title)s » n'est plus disponible.") % {"title": produit.title},
                    )
                    return redirect("jeiko_client_shop:cart_detail")
                messages.warning(
                    request,
                    _("Quantité ramenée à %(quantity)s : c'est tout ce qu'il reste de « %(title)s ».") % {"quantity": quantity, "title": produit.title},
                )

            item.quantity = quantity
            item.save()

        return redirect("jeiko_client_shop:cart_detail")


class RemoveCartItemView(BoutiqueEnLigneRequiredMixin, View):
    def post(self, request, item_id):
        cart = get_or_create_cart(request)
        item = get_object_or_404(CartItem, pk=item_id, cart=cart)
        item.delete()
        return redirect("jeiko_client_shop:cart_detail")


class CouponView(BoutiqueEnLigneRequiredMixin, View):
    """
    Saisir ou retirer le code promo du panier.

    Plafonné par adresse IP : sans limite, ce formulaire permet d'essayer des
    codes à la chaîne jusqu'à en trouver un.
    """

    def post(self, request):
        from jeiko.throttling import rate_limited

        cart = get_or_create_cart(request)
        if request.POST.get("action") == "retirer":
            cart.coupon = None
            cart.save(update_fields=["coupon", "updated_at"])
            return redirect("jeiko_client_shop:cart_detail")

        if rate_limited(request, "shop:coupon", 20, 3600):
            messages.error(request, _("Trop de codes essayés. Réessayez plus tard."))
            return redirect("jeiko_client_shop:cart_detail")
        try:
            coupon = promotions.trouver(request.POST.get("code"))
            promotions.verifier(coupon, request.user, list(cart.items.select_related("product")), panier=cart)
        except promotions.CodeInvalide as exc:
            messages.error(request, str(exc))
        else:
            cart.coupon = coupon
            cart.save(update_fields=["coupon", "updated_at"])
            messages.success(request, _("Code %(code)s appliqué.") % {"code": coupon.code})
        return redirect("jeiko_client_shop:cart_detail")


class ReviewView(BoutiqueEnLigneRequiredMixin, View):
    """
    Déposer ou reprendre son avis sur un produit.

    Réservé à qui l'a acheté (`catalogue.a_achete`) : c'est ce qui fait d'un
    avis un « achat vérifié », et ce qui ferme la porte au spam sans captcha.
    """

    def post(self, request, product_id):
        from django.contrib.auth.views import redirect_to_login

        from jeiko.shop import catalogue
        from jeiko.shop.models import ProductReview

        product = get_object_or_404(Product, pk=product_id, is_active=True)
        retour = product.get_absolute_url() + "#avis"
        reglages = ShopSettings.get_solo()
        if not reglages.reviews_enabled:
            raise Http404
        if not request.user.is_authenticated:
            return redirect_to_login(retour)
        if not catalogue.a_achete(request.user, product):
            messages.error(request, _("Seuls les clients qui ont acheté ce produit peuvent le noter."))
            return redirect(retour)
        try:
            note = int(request.POST.get("rating", 0))
        except (TypeError, ValueError):
            note = 0
        if not 1 <= note <= 5:
            messages.error(request, _("Choisissez une note de 1 à 5 étoiles."))
            return redirect(retour)

        nom = (request.user.first_name or request.user.get_username() or "").strip()
        if request.user.last_name:
            nom = f"{nom} {request.user.last_name.strip()[:1]}."
        ProductReview.objects.update_or_create(
            product=product, user=request.user,
            defaults={
                "rating": note,
                "title": (request.POST.get("title") or "").strip()[:120],
                "body": (request.POST.get("body") or "").strip()[:3000],
                "author_name": nom[:80],
                "is_approved": not reglages.reviews_moderated,
            },
        )
        messages.success(request, _("Merci pour votre avis !") if not reglages.reviews_moderated
                         else _("Merci ! Votre avis sera publié après relecture."))
        return redirect(retour)


class SearchView(BoutiqueEnLigneRequiredMixin, View):
    """
    `/shop/recherche/?q=` : les produits en vente dont le titre — dans
    n'importe quelle langue — ou la référence contient les mots tapés.

    Hors index (robots.txt) : une page par mot tapé n'a rien à faire dans
    Google. # ponytail: `icontains` sur le titre et la référence ; une
    recherche plein texte PostgreSQL quand un catalogue dépassera le millier.
    """

    def get(self, request):
        from django.db.models import Q

        from jeiko.shop.catalogue import produits_en_vente

        q = (request.GET.get("q") or "").strip()[:100]
        resultats = []
        if q:
            filtre = Q()
            for mot in q.split()[:5]:
                filtre &= (Q(content__title__icontains=mot) | Q(sku__icontains=mot)
                           | Q(content__traductions__title__icontains=mot)
                           | Q(variants__sku__icontains=mot))
            resultats = list(
                produits_en_vente().filter(filtre).distinct()
                .select_related("type", "content").prefetch_related("variants")[:60]
            )
        return render(request, "shop/search.html", {"q": q, "resultats": resultats})


def _acces_au_document(request, order):
    """Le client de la commande, ou l'exploitant. Rend la redirection, ou None."""
    from django.contrib.auth.views import redirect_to_login

    if not request.user.is_authenticated:
        return redirect_to_login(request.get_full_path())
    if order.user_id != request.user.pk and not request.user.has_perm("shop.view_order"):
        raise Http404
    return None


def _servir_le_document(request, contexte):
    """La page imprimable, ou son PDF avec `?format=pdf`."""
    from jeiko.pdf import moteur as pdf
    from jeiko.shop.facturation import document_pdf, nom_du_fichier

    if request.GET.get("format") == "pdf":
        from jeiko.throttling import hit, rate_limited

        # Un PDF coûte du calcul (WeasyPrint) : un compte qui en redemanderait
        # en boucle chargerait le serveur. 60 par heure — bien au-delà d'un
        # usage réel ; au-delà, la page imprimable reste, sans le lien (pas de
        # message : cette page autonome n'en affiche pas, il resurgirait plus
        # tard, hors de propos). On plafonne par ADRESSE ET par COMPTE : un
        # client connecté disposant de milliers d'adresses (un /64 IPv6)
        # contournait sinon la seule limite par IP (P5-a). Le document n'est
        # servi qu'à un utilisateur connecté (contrôle d'accès plus haut).
        trop = rate_limited(request, "shop:document_pdf", 60, 3600)
        if not trop and request.user.is_authenticated:
            trop = hit("shop:document_pdf:compte", str(request.user.pk), 60, 3600)
        if trop:
            return render(request, "shop/invoice.html", {**contexte, "pdf_disponible": False})
        try:
            octets = document_pdf(contexte)
        except pdf.MoteurPDFAbsent:
            # Serveur sans Pango : la page imprimable reste le recours (le
            # lien n'y est d'ailleurs pas proposé).
            pass
        else:
            from django.http import HttpResponse

            reponse = HttpResponse(octets, content_type="application/pdf")
            reponse["Content-Disposition"] = f'attachment; filename="{nom_du_fichier(contexte)}"'
            return reponse
    return render(request, "shop/invoice.html", {**contexte, "pdf_disponible": pdf.disponible()})


class InvoiceView(View):
    """La facture d'une commande réglée : page imprimable, ou PDF."""

    def get(self, request, pk):
        from jeiko.shop.facturation import contexte_facture
        from jeiko.shop.models import Order

        order = get_object_or_404(Order.objects.exclude(invoice_number=""), pk=pk)
        return _acces_au_document(request, order) or _servir_le_document(request, contexte_facture(order))


class CreditNoteView(View):
    """L'avoir d'un remboursement d'une commande facturée."""

    def get(self, request, pk):
        from jeiko.shop.facturation import contexte_avoir
        from jeiko.shop.models import OrderRefund

        refund = get_object_or_404(
            OrderRefund.objects.select_related("order").exclude(credit_note_number=""), pk=pk)
        return _acces_au_document(request, refund.order) or _servir_le_document(request, contexte_avoir(refund))


class StockAlertView(BoutiqueEnLigneRequiredMixin, View):
    """
    « Prévenez-moi » sur un produit épuisé. Ouvert aux visiteurs sans compte,
    donc plafonné par adresse IP et gardé par un leurre, comme l'inscription.
    """

    def post(self, request, product_id):
        from django.core.validators import validate_email
        from django.core.exceptions import ValidationError

        from jeiko.shop.models import StockAlert
        from jeiko.throttling import honeypot_filled, rate_limited

        product = get_object_or_404(Product, pk=product_id, is_active=True)
        retour = product.get_absolute_url()
        if honeypot_filled(request.POST) or rate_limited(request, "shop:alerte_stock", 10, 3600):
            messages.error(request, _("Trop de demandes. Réessayez plus tard."))
            return redirect(retour)
        email = (request.user.email if request.user.is_authenticated
                 else (request.POST.get("email") or "").strip())
        try:
            validate_email(email)
        except ValidationError:
            messages.error(request, _("Indiquez une adresse e-mail valide."))
            return redirect(retour)
        variante = next((v for v in product.variantes_actives
                         if str(v.pk) == (request.POST.get("variant") or "")), None)
        StockAlert.objects.get_or_create(
            product=product, variant=variante, email__iexact=email,
            defaults={"email": email,
                      "user": request.user if request.user.is_authenticated else None},
        )
        messages.success(request, _("C'est noté : nous vous écrirons dès son retour."))
        return redirect(retour)


class WishlistToggleView(BoutiqueEnLigneRequiredMixin, View):
    """Ajouter un produit à ses envies, ou l'en retirer."""

    def post(self, request, product_id):
        from django.contrib.auth.views import redirect_to_login

        from jeiko.shop.models import WishlistItem

        product = get_object_or_404(Product, pk=product_id)
        retour = request.POST.get("retour") or product.get_absolute_url()
        if not retour.startswith("/") or retour.startswith("//"):
            retour = product.get_absolute_url()
        if not request.user.is_authenticated:
            return redirect_to_login(retour)
        envie, creee = WishlistItem.objects.get_or_create(user=request.user, product=product)
        if not creee:
            envie.delete()
            messages.info(request, _("Retiré de vos envies."))
        else:
            messages.success(request, _("Ajouté à vos envies."))
        return redirect(retour)


class WishlistView(BoutiqueEnLigneRequiredMixin, View):
    """`/shop/envies/` : les produits mis de côté."""

    def get(self, request):
        from django.contrib.auth.views import redirect_to_login

        from jeiko.shop.catalogue import produits_en_vente

        if not request.user.is_authenticated:
            return redirect_to_login(request.get_full_path())
        produits = list(
            produits_en_vente().filter(wishlisted_by__user=request.user)
            .select_related("type", "content").prefetch_related("variants")
            .order_by("-wishlisted_by__created_at")
        )
        return render(request, "shop/wishlist.html", {"produits": produits})


def _articles_du_flux(request):
    """Une entrée par produit — ou par déclinaison, regroupées par produit."""
    from jeiko.shop.lisible import base_url, donnees_produit, produits_publics

    base = base_url(request)
    for produit in produits_publics():
        d = donnees_produit(produit, base + produit.get_absolute_url(), base)
        if d["declinaisons"]:
            for v in d["declinaisons"]:
                yield d, {"id": v["sku"], "titre": f"{d['titre']} — {v['libelle']}",
                          "prix": v["prix_ttc"], "disponible": v["disponible"], "groupe": d["sku"]}
        else:
            yield d, {"id": d["sku"], "titre": d["titre"], "prix": d["prix_ttc"],
                      "disponible": d["disponible"], "groupe": ""}


class GoogleFeedView(BoutiqueEnLigneRequiredMixin, View):
    """
    `/shop/flux/google.xml` : le flux produits de Google Merchant Center
    (RSS 2.0, espace « g: »). À déclarer une fois dans Merchant Center ; il se
    tient à jour seul, comme le sitemap. Une déclinaison est un article,
    rattaché à son produit par `item_group_id`.
    """

    def get(self, request):
        from xml.sax.saxutils import escape as x

        from django.http import HttpResponse

        site = request.get_host()
        lignes = ['<?xml version="1.0" encoding="UTF-8"?>',
                  '<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0"><channel>',
                  f"<title>{x(site)}</title><link>{x(request.build_absolute_uri('/'))}</link>",
                  "<description>Catalogue</description>"]
        for d, a in _articles_du_flux(request):
            champs = [
                ("g:id", a["id"]), ("g:title", a["titre"][:150]),
                ("g:description", (d["description"] or a["titre"])[:5000]),
                ("g:link", d["url"]), ("g:image_link", d["image"] or ""),
                ("g:availability", "in_stock" if a["disponible"] else "out_of_stock"),
                ("g:price", f"{a['prix']:.2f} {d['devise']}"),
                ("g:condition", "new"), ("g:brand", d["marque"]),
                ("g:item_group_id", a["groupe"]),
                ("g:product_type", " > ".join(d["categories"][:3])),
            ]
            if d["gtin"] and not a["groupe"]:
                champs.append(("g:gtin", d["gtin"]))
            else:
                champs.append(("g:identifier_exists", "no"))
            lignes.append("<item>" + "".join(
                f"<{balise}>{x(str(valeur))}</{balise}>" for balise, valeur in champs if valeur
            ) + "</item>")
        lignes.append("</channel></rss>")
        return HttpResponse("\n".join(lignes), content_type="application/xml; charset=utf-8")


class CatalogueJsonView(BoutiqueEnLigneRequiredMixin, View):
    """
    `/shop/catalogue.json` : le catalogue pour un agent ou un assistant —
    titre, adresse, prix TTC, disponibilité, déclinaisons, note. Ce qu'il
    trouverait en lisant chaque fiche, en une requête.
    """

    def get(self, request):
        from django.http import JsonResponse

        from jeiko.shop.lisible import base_url, donnees_produit, produits_publics

        base = base_url(request)
        produits = []
        for produit in produits_publics():
            d = donnees_produit(produit, base + produit.get_absolute_url(), base)
            produits.append({
                "titre": d["titre"], "url": d["url"], "description": d["description"],
                "image": d["image"], "reference": d["sku"], "gtin": d["gtin"] or None,
                "marque": d["marque"], "categories": d["categories"],
                "prix_ttc": f"{d['prix_ttc']:.2f}", "devise": d["devise"],
                "disponible": d["disponible"],
                "declinaisons": [
                    {"libelle": v["libelle"], "reference": v["sku"],
                     "prix_ttc": f"{v['prix_ttc']:.2f}", "disponible": v["disponible"]}
                    for v in d["declinaisons"]
                ],
                "note": str(d["note"]) if d["note"] is not None else None,
                "nombre_avis": d["nombre_avis"],
            })
        reglages = ShopSettings.get_solo()
        return JsonResponse({
            "boutique": request.get_host(), "devise": reglages.currency,
            "prix_affiches": "TTC",
            "retours_jours": reglages.return_days,
            "produits": produits,
        }, json_dumps_params={"ensure_ascii": False})
