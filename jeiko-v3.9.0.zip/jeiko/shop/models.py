from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

from jeiko.modeles_par_langue import NomEtAdresseParLangue

User = get_user_model()
CENTIME = Decimal("0.01")


def _montant(valeur):
    """Montant affichable et facturable, arrondi au centime supérieur usuel."""
    return Decimal(valeur or 0).quantize(CENTIME, rounding=ROUND_HALF_UP)


def _ttc(montant_ht, taux):
    """TTC au centime d'un montant HT non arrondi."""
    return _montant(
        Decimal(montant_ht or 0) * (Decimal("1") + Decimal(taux or 0) / Decimal("100"))
    )



class ShopSettings(models.Model):
    """
    Les réglages de la boutique, pour le site entier.

    Pourquoi ce modèle n'existait pas, et pourquoi il manque
    ---------------------------------------------------------
    La TVA se réglait produit par produit (`Product.tax_rate`), avec un défaut
    par type (`ProductType.default_tax_rate`). Cela suffit tant qu'on a trois
    produits ; passé la dizaine, changer un taux — parce que la loi bouge, ou
    parce qu'on s'était trompé — demande de reprendre chaque fiche, et le
    premier oubli passe inaperçu jusqu'à la facture.

    Il manquait donc l'étage au-dessus : **une valeur de référence pour le
    site**, dont les types héritent quand ils ne disent rien.

    Ce que ce modèle ne fait PAS
    ----------------------------
    Il ne réécrit rien. Un produit ou un type qui porte déjà un taux garde le
    sien : changer ici ne doit pas modifier en silence le prix de commandes en
    cours de préparation. Le taux du site sert de **défaut**, consulté à la
    création d'un type qui n'en précise pas.

    Singleton, comme `MailSettings` : il y a une boutique par site.
    """

    is_online = models.BooleanField(
        default=True,
        verbose_name=_("Boutique en ligne active"),
        help_text=(
            _("Désactivée, les fiches, le panier et le paiement ne sont plus "
            "accessibles au public. Les produits et commandes restent conservés.")
        ),
    )

    # L'accès au panier dans le menu du site. Il se réglait menu par menu
    # (`Menu.show_cart`) : sur un site à plusieurs menus il fallait le cocher
    # sur chacun, et on le cherchait ici. Une boutique, un réglage. Décoché
    # par défaut : un site qui ne vend rien n'affiche pas un panier vide.
    show_cart = models.BooleanField(
        default=False,
        verbose_name=_("Afficher le panier"),
        help_text=(
            _("Une petite icône de panier dans le menu du site : en haut à "
            "droite sur ordinateur, juste sous le menu sur mobile.")
        ),
    )

    homepage = models.ForeignKey(
        "administration_pages.Page",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="shop_homepage_for",
        verbose_name=_("Page d’accueil de la boutique"),
        help_text=(
            _("Une page classique publiée, utilisée à l’adresse /shop/. "
            "Elle n’est pas transformée en page spéciale.")
        ),
    )

    prices_include_tax = models.BooleanField(
        default=False,
        verbose_name=_("Les prix saisis incluent la TVA"),
        help_text=(
            _("Le formulaire produit convertit alors le montant TTC saisi en "
            "montant HT conservé en base.")
        ),
    )

    display_prices_including_tax = models.BooleanField(
        default=True,
        verbose_name=_("Afficher les prix TTC dans la boutique"),
        help_text=_("Détermine l'affichage public des prix et du panier."),
    )

    default_tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("20.00"),
        verbose_name=_("TVA par défaut (%)"),
        help_text=(
            _("Taux appliqué aux nouveaux types de produit qui n'en précisent "
            "pas. Ne modifie aucun produit ni aucune commande existante.")
        ),
    )

    currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name=_("Devise"),
        help_text=_("Code ISO à trois lettres : EUR, CHF, CAD…"),
    )

    #: Seuil commun aux zones de livraison qui n'ont pas le leur
    #: (`DeliveryZone.free_from` l'emporte). Voir `jeiko.shop.livraison`.
    free_shipping_from = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        verbose_name=_("Livraison offerte à partir de (TTC)"),
        help_text=_("Laisser vide pour ne jamais offrir la livraison."),
    )

    # Facturation. Une facture française porte l'identité du vendeur (celle du
    # site : nom, adresse), son SIRET, son numéro de TVA s'il en a un, et les
    # mentions propres à son régime (« TVA non applicable, art. 293 B du
    # CGI », pénalités de retard…). Les numéros sont continus, sans trou :
    # attribués au règlement, sous verrou (`shop.facturation`).
    siret = models.CharField(max_length=20, blank=True, verbose_name=_("SIRET"))
    vat_number = models.CharField(max_length=20, blank=True, verbose_name=_("N° de TVA intracommunautaire"))
    invoice_mentions = models.TextField(
        blank=True, verbose_name=_("Mentions légales des factures"),
        help_text=_("Ex : « TVA non applicable, art. 293 B du CGI ». Imprimées en bas de chaque facture."),
    )
    invoice_prefix = models.CharField(max_length=10, default="F", verbose_name=_("Préfixe des factures"))
    credit_note_prefix = models.CharField(max_length=10, default="A", verbose_name=_("Préfixe des avoirs"))
    invoice_year = models.PositiveIntegerField(default=0, editable=False)
    invoice_counter = models.PositiveIntegerField(default=0, editable=False)
    credit_note_year = models.PositiveIntegerField(default=0, editable=False)
    credit_note_counter = models.PositiveIntegerField(default=0, editable=False)

    # Politique de retour, annoncée à Google et aux assistants (JSON-LD,
    # flux). Vide : rien n'est annoncé — on ne promet pas ce qu'on ignore.
    return_days = models.PositiveIntegerField(
        null=True, blank=True, verbose_name=_("Délai de retour (jours)"),
        help_text=_("Ex : 14. Vide : aucune politique de retour n'est annoncée aux moteurs."),
    )

    # Sous la fiche produit, hors du corps mis en cache. Décochés par défaut :
    # un site déjà en ligne ne voit rien apparaître sans l'avoir demandé.
    show_related_products = models.BooleanField(
        default=False, verbose_name=_("Afficher « Vous aimerez aussi » sous les fiches"),
    )
    wishlist_enabled = models.BooleanField(
        default=False, verbose_name=_("Liste d'envies"),
        help_text=_("Un bouton « Ajouter à mes envies » sous chaque fiche ; la liste est à /shop/envies/."),
    )
    reviews_enabled = models.BooleanField(
        default=False, verbose_name=_("Avis clients"),
        help_text=_("Seuls les clients qui ont acheté le produit peuvent le noter."),
    )
    reviews_moderated = models.BooleanField(
        default=True, verbose_name=_("Valider les avis avant publication"),
    )

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Réglages de la boutique")
        verbose_name_plural = _("Réglages de la boutique")

    def __str__(self):
        return _("Réglages de la boutique")

    @classmethod
    def get_solo(cls):
        """
        Les réglages du site, créés au premier accès.

        `get_or_create` sur `pk=1` plutôt que `first()` : deux requêtes
        concurrentes sur une page d'administration fraîchement ouverte
        créeraient sinon deux lignes, et la seconde deviendrait invisible.
        """
        objet, __ = cls.objects.get_or_create(pk=1)
        return objet


class DeliveryZone(models.Model):
    """Zone de livraison déclarée dans les réglages de la boutique."""

    settings = models.ForeignKey(
        ShopSettings,
        on_delete=models.CASCADE,
        related_name="delivery_zones",
        verbose_name=_("Réglages de la boutique"),
    )
    code = models.SlugField(
        max_length=50,
        verbose_name=_("Code"),
        help_text=_("Identifiant interne de la zone (ex : france-metropolitaine)."),
    )
    name = models.CharField(max_length=120, verbose_name=_("Nom de la zone"))
    country_codes = models.CharField(
        max_length=500,
        verbose_name=_("Pays (codes ISO)"),
        help_text=_("Ex : FR, BE, LU. Utiliser * pour tous les pays."),
    )
    postal_code_prefixes = models.CharField(
        max_length=500,
        blank=True,
        verbose_name=_("Préfixes postaux"),
        help_text=_("Optionnel. Ex : 75, 77, 78. Vide = tout le pays."),
    )
    price_ttc = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name=_("Frais de livraison (TTC)"),
    )
    free_from = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        verbose_name=_("Gratuite à partir de (TTC)"),
        help_text=_("Laisser vide pour ne jamais offrir cette zone gratuitement."),
    )
    is_active = models.BooleanField(default=True, verbose_name=_("Zone active"))
    position = models.PositiveIntegerField(default=0, verbose_name=_("Ordre"))

    class Meta:
        ordering = ["position", "name", "id"]
        constraints = [
            models.UniqueConstraint(
                fields=("settings", "code"),
                name="shop_delivery_zone_code_unique",
            ),
        ]
        verbose_name = _("Zone de livraison")
        verbose_name_plural = _("Zones de livraison")

    def __str__(self):
        return self.name

    def matches(self, country_code, postal_code=""):
        """Indique si une adresse appartient à la zone."""
        if not self.is_active:
            return False
        pays = (country_code or "").strip().upper()
        autorises = {
            code.strip().upper()
            for code in (self.country_codes or "").replace(";", ",").split(",")
            if code.strip()
        }
        if "*" not in autorises and pays not in autorises:
            return False
        prefixes = {
            prefix.strip().upper()
            for prefix in (self.postal_code_prefixes or "").replace(";", ",").split(",")
            if prefix.strip()
        }
        if not prefixes:
            return True
        postal = (postal_code or "").strip().upper()
        return any(postal.startswith(prefix) for prefix in prefixes)


class ProductType(NomEtAdresseParLangue):
    """
    Type métier du produit (couche "conceptuelle") :
    - produit_physique
    - formation_en_ligne
    - seance_1to1
    - abonnement
    etc.

    Chaque ProductType pointe vers un CustomObjectModel qui gère la fiche
    (contenu + template) côté "administration_pages".

    Son nom et son code — le segment de l'adresse de ses produits — se
    traduisent en place (`traductions`, voir `jeiko/modeles_par_langue.py`) :
    `/en/shop/workshops/<référence>/`. Il n'y a qu'UN type, pour toutes les
    langues : c'est lui qui porte la TVA, la nature et l'expédition.
    """

    #: Le segment d'adresse d'origine est le code.
    champ_d_adresse = "code"

    name = models.CharField(
        max_length=150,
        verbose_name=_("Nom du type de produit"),
    )
    code = models.SlugField(
        max_length=100,
        unique=True,
        verbose_name=_("Code interne"),
        help_text=_("Identifiant technique (ex : produit_physique, formation, seance…)."),
    )

    content_model = models.ForeignKey(
        "custom_objects.CustomObjectModel",
        on_delete=models.PROTECT,
        related_name="product_types",
        verbose_name=_("Modèle de contenu"),
        null=True,
        blank=True,
        help_text=(
            _("Modèle de contenu (CustomObjectModel) utilisé pour les fiches "
            "de ce type de produit.")
        ),
    )

    # Flags fonctionnels
    KIND_PHYSICAL = "physical"
    KIND_COURSE = "course"
    KIND_QUESTIONNAIRE = "questionnaire"
    KIND_APPOINTMENT = "appointment"
    KIND_SERVICE = "service"

    KIND_CHOICES = (
        (KIND_PHYSICAL, _("Produit physique")),
        (KIND_COURSE, _("Formation en ligne")),
        (KIND_QUESTIONNAIRE, _("Questionnaire expert")),
        (KIND_APPOINTMENT, _("Rendez-vous / Crédits")),
        (KIND_SERVICE, _("Service")),
    )

    kind = models.CharField(
        max_length=20,
        choices=KIND_CHOICES,
        default=KIND_PHYSICAL,
        verbose_name=_("Nature du produit"),
    )

    is_physical = models.BooleanField(
        default=True,
        verbose_name=_("Produit physique (legacy)"),
        help_text=_("Si coché, le produit nécessite une gestion de stock et de livraison."),
    )
    requires_shipping = models.BooleanField(
        default=True,
        verbose_name=_("Nécessite une expédition"),
        help_text=_("Ex : colis, lettre. Décoche pour les produits 100 % digitaux."),
    )
    is_subscription = models.BooleanField(
        default=False,
        verbose_name=_("Abonnement"),
        help_text=_("Produit facturé de manière récurrente."),
    )

    # TVA par défaut (en %)
    default_tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("20.00"),
        verbose_name=_("TVA par défaut (%)"),
    )

    default_currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name=_("Devise par défaut"),
        help_text=_("Code ISO (ex : EUR, USD)."),
    )

    date_created = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_("Date de création"),
    )

    class Meta:
        verbose_name = _("Type de produit")
        verbose_name_plural = _("Types de produit")
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name

    def clean(self):
        self.verifier_les_traductions()


class Product(models.Model):
    """
    Produit vendable (couche e-commerce).
    Il est relié :
      - à un ProductType (logique métier),
      - à un CustomObject (contenu + template).
    """

    type = models.ForeignKey(
        ProductType,
        on_delete=models.PROTECT,
        related_name="products",
        verbose_name=_("Type de produit"),
    )

    content = models.OneToOneField(
        "custom_objects.CustomObject",
        on_delete=models.PROTECT,
        related_name="product",
        verbose_name=_("Fiche contenu"),
        help_text=_("Objet custom (CustomObject) qui porte la fiche produit et le template."),
    )

    sku = models.CharField(
        max_length=64,
        unique=True,
        verbose_name=_("Référence (SKU)"),
        help_text=_("Identifiant unique du produit (SKU)."),
    )

    is_active = models.BooleanField(
        default=True,
        verbose_name=_("Actif (vendable)"),
    )

    # Prix
    #
    # Quatre décimales, pas deux (rapport Fable 1, §3.3). Une boutique qui
    # saisit ses prix TTC les voit convertis en HT ; arrondi au centime, ce HT
    # ne redonnait pas toujours le TTC saisi — 1,05 € TTC à 20 % devenait
    # 0,88 € HT, soit 1,06 € affichés et encaissés. Un prix sur dix entre 1 et
    # 200 € était concerné. À quatre décimales, l'écart reste sous le
    # dix-millième et l'arrondi du TTC retombe toujours sur le prix saisi.
    price_ht = models.DecimalField(
        max_digits=12,
        decimal_places=4,
        verbose_name=_("Prix HT"),
    )
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("20.00"),
        verbose_name="TVA (%)",
        help_text=_("Laisse vide pour utiliser la TVA du type (si tu gères ce comportement plus tard)."),
    )
    currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name=_("Devise"),
        help_text=_("Code ISO (ex : EUR, USD)."),
    )

    # Identifiants lus par Google Shopping et les assistants : sans GTIN, un
    # produit de marque est souvent écarté des fiches comparatives.
    gtin = models.CharField(
        max_length=14, blank=True, verbose_name=_("GTIN / EAN"),
        help_text=_("Le code-barres du produit (8, 12, 13 ou 14 chiffres), s'il en a un."),
    )
    brand = models.CharField(
        max_length=120, blank=True, verbose_name=_("Marque"),
        help_text=_("Vide : le nom du site."),
    )

    # Catalogue. Les catégories sont celles du site (celles des pages) : une
    # grille « Produits » filtrée sur une catégorie les lit, comme l'éditeur
    # le proposait déjà sans que rien ne filtre.
    categories = models.ManyToManyField(
        "administration_pages.Category", blank=True, related_name="products",
        verbose_name=_("Catégories"),
    )
    # « Vous aimerez aussi » sous la fiche. Vide : les produits des mêmes
    # catégories, sinon du même type (`shop.catalogue.associes`).
    related_products = models.ManyToManyField(
        "self", blank=True, symmetrical=False, related_name="+",
        verbose_name=_("Produits associés"),
    )

    # Stock (simple)
    stock_quantity = models.IntegerField(
        default=0,
        verbose_name=_("Quantité en stock"),
    )
    allow_negative_stock = models.BooleanField(
        default=False,
        verbose_name=_("Autoriser le stock négatif"),
    )

    # Logistique
    weight_kg = models.DecimalField(
        max_digits=7,
        decimal_places=3,
        default=Decimal("0.000"),
        verbose_name=_("Poids (kg)"),
    )

    # Liens spécifiques (selon le kind)
    linked_expert_test = models.ForeignKey(
        "questionnaires_expert.ExpertTest",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name=_("Questionnaire lié"),
        help_text=_("Si ce produit vend l'accès à un questionnaire."),
    )
    linked_appointment_type = models.ForeignKey(
        "calendars.AppointmentType",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name=_("Type de RDV lié"),
        help_text=_("Si ce produit vend des crédits pour un type de RDV."),
    )
    # Seuil d'alerte de stock, par produit.
    #
    # NULL plutôt qu'une valeur sentinelle (-1) pour dire « pas d'alerte » :
    # rien, dans un entier, ne distingue un drapeau d'un seuil, et quelqu'un
    # finirait par saisir -1 en pensant « une commande en attente ». NULL se lit
    # sans convention à connaître.
    #
    #   NULL -> aucune alerte pour ce produit
    #   0    -> alerte à la rupture
    #   n    -> alerte dès qu'il reste n unités ou moins
    stock_alert_threshold = models.PositiveIntegerField(
        null=True,
        blank=True,
        verbose_name=_("Seuil d'alerte de stock"),
        help_text=_("Laisser vide pour ne recevoir aucune alerte. 0 = alerte à la rupture."),
    )
    credits_amount = models.IntegerField(
        default=0,
        verbose_name=_("Crédits offerts"),
        help_text=_("Nombre de crédits/RDV crédités à l'achat."),
    )
    linked_course = models.ForeignKey(
        "courses.Course",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="products",
        verbose_name=_("Formation liée"),
        help_text=_("Si ce produit donne accès à une formation en ligne."),
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_("Créé le"),
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name=_("Mis à jour le"),
    )

    class Meta:
        verbose_name = _("Produit")
        verbose_name_plural = _("Produits")
        ordering = ["sku"]

    def __str__(self) -> str:
        # content.title vient du CustomObject
        return f"{self.sku} – {self.content.title}"

    @property
    def suit_le_stock(self):
        """
        Ce produit s'épuise-t-il ?

        Un pot de cornichons, oui. Une séance de coaching, un abonnement, une
        formation en ligne : non. Ces produits n'ont pas de stock, personne
        n'en saisit, et `stock_quantity` y reste à zéro pour toujours.

        Or zéro était traité comme « épuisé » partout : l'ajout au panier était
        REFUSÉ, la mise à jour du panier ramenait la quantité à zéro et
        supprimait la ligne, et le JSON-LD annonçait `OutOfStock` à Google.
        Autrement dit, **aucun service n'était vendable** tant que personne
        n'avait pensé à cocher « stock négatif autorisé » — un réglage dont le
        nom ne suggère rien de tel.

        Trois notions coexistaient, et c'est ce qui a produit le défaut :

        * `ProductType.requires_shipping` — « nécessite une expédition » ;
        * `ProductType.is_physical` — le même champ en plus ancien, marqué
          « legacy » jusque dans son intitulé ;
        * `Product.allow_negative_stock` — un réglage de dépassement, pas une
          nature.

        Le décrément de stock (`services.py`, à la commande) tranchait déjà sur
        `requires_shipping` — et c'est lui l'autorité, puisque c'est lui qui
        bouge réellement le stock. Le panier, lui, tranchait sur
        `allow_negative_stock` : deux critères pour une même question, d'où un
        panier qui refuse ce que la commande aurait servi sans y toucher.

        On s'aligne donc sur `requires_shipping`, ici et une seule fois.
        """
        return bool(getattr(self.type, "requires_shipping", True))

    @property
    def est_disponible(self):
        """
        Y a-t-il de quoi servir une commande ?

        Toujours vrai pour ce qui ne s'épuise pas. Sinon, le stock tranche —
        ou le dépassement autorisé. Avec des déclinaisons, il suffit que l'une
        d'elles soit disponible.
        """
        declinaisons = self.variantes_actives
        if declinaisons:
            return any(self.peut_servir(1, v) for v in declinaisons)
        return self.peut_servir(1)

    def peut_servir(self, quantite, variante=None):
        """Le même contrôle, pour une quantité donnée — d'une déclinaison, le cas échéant."""
        if not self.suit_le_stock or self.allow_negative_stock:
            return True
        stock = variante.stock_quantity if variante is not None else self.stock_quantity
        return (stock or 0) >= quantite

    @property
    def variantes_actives(self):
        """Les déclinaisons en vente, dans l'ordre. Mémorisé pour la requête."""
        if not hasattr(self, "_variantes_actives"):
            self._variantes_actives = [v for v in self.variants.all() if v.is_active]
        return self._variantes_actives

    # Ce qu'un produit montre au VISITEUR — titre, image, description — vient
    # de la fiche qu'il lit : sa version publiée dans sa langue, sinon la
    # fiche d'origine. Une grille de produits, une ligne de panier et le
    # JSON-LD suivent donc la langue sans rien savoir d'elle. Hors du site
    # public (administration, API, e-mails) : la fiche d'origine. Ce qui se
    # CONSERVE — le libellé d'une ligne de commande — lit `content.title`.
    @property
    def fiche_lue(self):
        from jeiko.langues_du_site import version_lue

        return version_lue(self.content)

    @property
    def main_image(self):
        return self.fiche_lue.main_image

    @property
    def title(self):
        return self.fiche_lue.title

    @property
    def name(self):
        return self.title

    @property
    def description(self):
        return self.fiche_lue.description

    @property
    def excerpt(self):
        return self.description

    def get_absolute_url(self):
        return self.content.get_absolute_url()

    def clean(self):
        """
        Sécurité : on impose que le CustomObject utilise bien le CustomObjectModel
        attendu par le ProductType.
        """
        if self.content_id and self.type_id:
            if self.content.model_id != self.type.content_model_id:
                raise ValidationError(
                    {
                        "content": (
                            _("Cet objet n'utilise pas le modèle de contenu attendu "
                            "pour ce type de produit.")
                        )
                    }
                )

    @property
    def price_ttc(self) -> Decimal:
        return _ttc(self.price_ht, self.tax_rate)


class ProductVariant(models.Model):
    """
    Une déclinaison d'un produit : « Rouge / M », « 500 g », « Édition reliée ».

    La fiche reste UNIQUE — un titre, une description, des images, une adresse,
    une version par langue — et le produit porte ses déclinaisons. Chacune a
    sa référence et son stock ; son prix, quand il diffère, sinon celui du
    produit. C'est le modèle de Shopify et de WooCommerce (« produit
    variable »), sans la combinatoire d'attributs : une déclinaison est un
    libellé libre.
    `# ponytail: libellé libre ; des axes (couleur × taille) générant les
    combinaisons quand un catalogue en aura des dizaines par produit.`

    Un produit qui a des déclinaisons actives ne se met au panier qu'avec
    l'une d'elles : le stock du produit lui-même n'est alors plus lu.
    """

    product = models.ForeignKey(
        "Product", on_delete=models.CASCADE, related_name="variants",
        verbose_name=_("Produit"),
    )
    label = models.CharField(
        max_length=120, verbose_name=_("Libellé"),
        help_text=_("Ce que voit le client : « Rouge / M », « 500 g »…"),
    )
    sku = models.CharField(max_length=64, unique=True, verbose_name=_("Référence (SKU)"))
    price_ht = models.DecimalField(
        max_digits=12, decimal_places=4, null=True, blank=True,
        verbose_name=_("Prix HT"),
        help_text=_("Vide : le prix du produit."),
    )
    stock_quantity = models.IntegerField(default=0, verbose_name=_("Quantité en stock"))
    is_active = models.BooleanField(default=True, verbose_name=_("Active"))
    position = models.PositiveIntegerField(default=0, verbose_name=_("Ordre"))

    class Meta:
        verbose_name = _("Déclinaison")
        verbose_name_plural = _("Déclinaisons")
        ordering = ["product", "position", "id"]

    def __str__(self):
        return f"{self.product.sku} – {self.label}"

    @property
    def prix_ht(self):
        return self.price_ht if self.price_ht is not None else self.product.price_ht

    @property
    def price_ttc(self):
        return _ttc(self.prix_ht, self.product.tax_rate)

    @property
    def est_disponible(self):
        return self.product.peut_servir(1, self)


class ProductImage(models.Model):
    """
    Images liées à un produit.
    On réutilise ton ImageContent de l'app administration_pages.
    """

    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name="images",
        verbose_name=_("Produit"),
    )
    image = models.ForeignKey(
        "administration_pages.ImageContent",
        on_delete=models.PROTECT,
        related_name="product_images",
        verbose_name=_("Image"),
    )
    is_main = models.BooleanField(
        default=False,
        verbose_name=_("Image principale"),
    )
    position = models.PositiveIntegerField(
        default=0,
        verbose_name=_("Ordre d'affichage"),
    )

    class Meta:
        verbose_name = _("Image de produit")
        verbose_name_plural = _("Images de produit")
        ordering = ["product", "position", "id"]

    def __str__(self) -> str:
        return f"Image {self.product.sku} (pos={self.position})"


class ProductStockMovement(models.Model):
    """
    Historique des mouvements de stock (optionnel mais pratique).
    Ex :
      - commande -1
      - correction inventaire +10
      - retour client +1
    """

    IN = "IN"
    OUT = "OUT"
    MOVEMENT_TYPES = [
        (IN, _("Entrée")),
        (OUT, _("Sortie")),
    ]

    product = models.ForeignKey(
        Product,
        # Un mouvement est une pièce d'historique, pas un détail jetable du
        # produit. Même une suppression ORM directe doit obliger l'appelant à
        # désactiver le produit ou à traiter explicitement cet historique.
        on_delete=models.PROTECT,
        related_name="stock_movements",
        verbose_name=_("Produit"),
    )
    variant = models.ForeignKey(
        ProductVariant, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="stock_movements", verbose_name=_("Déclinaison"),
    )
    movement_type = models.CharField(
        max_length=3,
        choices=MOVEMENT_TYPES,
        verbose_name=_("Type de mouvement"),
    )
    quantity = models.IntegerField(
        verbose_name=_("Quantité"),
        help_text=_("Positive ou négative selon ton usage, mais le type IN/OUT est là pour clarifier."),
    )
    reason = models.CharField(
        max_length=255,
        blank=True,
        verbose_name=_("Raison"),
        help_text=_("Ex : commande #123, ajustement, retour, etc."),
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_("Date du mouvement"),
    )
    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="stock_movements",
        verbose_name=_("Utilisateur"),
    )

    class Meta:
        verbose_name = _("Mouvement de stock")
        verbose_name_plural = _("Mouvements de stock")
        ordering = ["-created_at", "-id"]

    def __str__(self) -> str:
        return f"{self.product.sku} – {self.movement_type} {self.quantity}"


class ProductReview(models.Model):
    """
    Un avis client : une note de 1 à 5 et un texte.

    Réservé aux acheteurs du produit — un avis est un « achat vérifié » ou
    n'existe pas. C'est ce qui le rend crédible, pour le visiteur comme pour
    Google (étoiles dans les résultats, `aggregateRating`), et ce qui ferme la
    porte au spam sans captcha. Un avis par client et par produit ; le
    reprendre le remplace.
    """

    product = models.ForeignKey(
        "Product", on_delete=models.CASCADE, related_name="reviews", verbose_name=_("Produit"),
    )
    user = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="product_reviews", verbose_name=_("Client"),
    )
    rating = models.PositiveSmallIntegerField(
        verbose_name=_("Note"), choices=[(i, str(i)) for i in range(1, 6)],
    )
    title = models.CharField(max_length=120, blank=True, verbose_name=_("Titre"))
    body = models.TextField(blank=True, max_length=3000, verbose_name=_("Avis"))
    author_name = models.CharField(max_length=80, verbose_name=_("Nom affiché"))
    is_approved = models.BooleanField(default=False, verbose_name=_("Publié"))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_("Le"))

    class Meta:
        verbose_name = _("Avis client")
        verbose_name_plural = _("Avis clients")
        ordering = ["-created_at", "-id"]
        constraints = [
            models.UniqueConstraint(fields=("product", "user"), name="shop_un_avis_par_client"),
        ]

    def __str__(self):
        return f"{self.product.sku} – {self.rating}/5"


class StockAlert(models.Model):
    """
    « Prévenez-moi quand il revient » : une adresse en attente d'un produit
    (ou d'une déclinaison) épuisé.

    Un visiteur sans compte peut s'inscrire — c'est souvent un visiteur de
    passage. Le message part une fois, au retour en stock (tâche des 30
    minutes, `shop.relances`), et l'inscription est alors SUPPRIMÉE : une
    adresse n'a pas à rester en base une fois la promesse tenue.
    """

    product = models.ForeignKey("Product", on_delete=models.CASCADE, related_name="stock_alerts")
    variant = models.ForeignKey(
        ProductVariant, on_delete=models.CASCADE, null=True, blank=True, related_name="stock_alerts")
    email = models.EmailField(verbose_name=_("E-mail"))
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name="stock_alerts")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("Alerte de retour en stock")
        verbose_name_plural = _("Alertes de retour en stock")
        ordering = ["-created_at"]


class WishlistItem(models.Model):
    """Un produit mis de côté par un client : sa liste d'envies."""

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="wishlist")
    product = models.ForeignKey("Product", on_delete=models.CASCADE, related_name="wishlisted_by")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("Envie")
        verbose_name_plural = _("Listes d'envies")
        ordering = ["-created_at"]
        constraints = [
            models.UniqueConstraint(fields=("user", "product"), name="shop_une_envie_par_produit"),
        ]


class Coupon(models.Model):
    """
    Un code promo, saisi par le client dans son panier.

    Trois sortes, celles qu'on trouve partout (WooCommerce, PrestaShop,
    Shopify) : un pourcentage, un montant fixe, la livraison offerte. Le reste
    est une affaire de conditions — période, montant minimum, plafonds,
    produits concernés — vérifiées par `shop.promotions.verifier`, qui dit au
    client pourquoi un code ne marche pas plutôt que de l'ignorer.

    La remise porte sur les articles concernés seulement, TVA comprise, et
    réduit la TVA au prorata : une remise n'est pas un paiement, elle baisse
    le prix (et donc la TVA due).
    """

    KIND_PERCENT = "percent"
    KIND_FIXED = "fixed"
    KIND_FREE_SHIPPING = "free_shipping"
    KIND_CHOICES = [
        (KIND_PERCENT, _("Pourcentage")),
        (KIND_FIXED, _("Montant fixe (TTC)")),
        (KIND_FREE_SHIPPING, _("Livraison offerte")),
    ]

    code = models.CharField(
        max_length=40, unique=True, verbose_name=_("Code"),
        help_text=_("Ce que le client saisit. Majuscules et minuscules sont confondues."),
    )
    description = models.CharField(
        max_length=200, blank=True, verbose_name=_("Description interne"),
    )
    kind = models.CharField(
        max_length=20, choices=KIND_CHOICES, default=KIND_PERCENT, verbose_name=_("Type de remise"),
    )
    value = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("0"),
        verbose_name=_("Valeur"),
        help_text=_("Un pourcentage (10 = 10 %) ou un montant TTC. Ignorée pour la livraison offerte."),
    )
    minimum_amount = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
        verbose_name=_("Montant minimum du panier (TTC)"),
    )
    starts_at = models.DateTimeField(null=True, blank=True, verbose_name=_("Valable à partir du"))
    ends_at = models.DateTimeField(null=True, blank=True, verbose_name=_("Valable jusqu'au"))
    usage_limit = models.PositiveIntegerField(
        null=True, blank=True, verbose_name=_("Nombre d'utilisations maximum"),
        help_text=_("Toutes commandes payées confondues. Vide : illimité."),
    )
    usage_limit_per_user = models.PositiveIntegerField(
        null=True, blank=True, verbose_name=_("Utilisations maximum par client"),
    )
    product_types = models.ManyToManyField(
        ProductType, blank=True, related_name="coupons",
        verbose_name=_("Types de produits concernés"),
        help_text=_("Vide, avec les produits vides : tout le panier."),
    )
    products = models.ManyToManyField(
        "Product", blank=True, related_name="coupons",
        verbose_name=_("Produits concernés"),
    )
    is_active = models.BooleanField(default=True, verbose_name=_("Actif"))
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("Code promo")
        verbose_name_plural = _("Codes promo")
        ordering = ["-created_at", "-id"]

    def __str__(self):
        return self.code

    def save(self, *args, **kwargs):
        self.code = (self.code or "").strip().upper()
        super().save(*args, **kwargs)


# ----------------------------------------------------------------------
#  Panier (Cart) + Commandes (Order)
#  La partie paiement ira dans l'app "payments" (FK depuis Order).
# ----------------------------------------------------------------------


class Cart(models.Model):
    """
    Panier simple :
    - lié éventuellement à un user,
    - ou à une session (anonyme).
    """

    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="carts",
        verbose_name=_("Utilisateur"),
    )
    session_key = models.CharField(
        max_length=40,
        blank=True,
        db_index=True,
        verbose_name=_("Session"),
        help_text=_("Clé de session pour les paniers anonymes."),
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_("Créé le"),
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name=_("Mis à jour le"),
    )

    is_locked = models.BooleanField(
        default=False,
        verbose_name=_("Verrouillé"),
        help_text=_("Un panier verrouillé ne peut plus être modifié (ex : transformé en commande)."),
    )
    coupon = models.ForeignKey(
        Coupon, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+", verbose_name=_("Code promo"),
    )

    class Meta:
        verbose_name = _("Panier")
        verbose_name_plural = _("Paniers")
        ordering = ["-updated_at", "-id"]

    def __str__(self) -> str:
        if self.user:
            return f"Panier #{self.pk} – {self.user}"
        return f"Panier #{self.pk} (session={self.session_key})"


class CartItem(models.Model):
    """
    Ligne de panier.
    On snapshot le prix au moment où on ajoute l'article.
    """

    cart = models.ForeignKey(
        Cart,
        on_delete=models.CASCADE,
        related_name="items",
        verbose_name=_("Panier"),
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name="cart_items",
        verbose_name=_("Produit"),
    )
    # Une déclinaison supprimée sort des paniers : un panier n'engage personne.
    variant = models.ForeignKey(
        ProductVariant, on_delete=models.CASCADE, null=True, blank=True,
        related_name="cart_items", verbose_name=_("Déclinaison"),
    )
    quantity = models.PositiveIntegerField(
        default=1,
        verbose_name=_("Quantité"),
    )

    unit_price_ht = models.DecimalField(
        max_digits=12,
        decimal_places=4,
        verbose_name=_("Prix unitaire HT (snapshot)"),
    )
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        verbose_name="TVA (%)",
    )
    currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name=_("Devise"),
    )

    class Meta:
        verbose_name = _("Ligne de panier")
        verbose_name_plural = _("Lignes de panier")

    def __str__(self) -> str:
        return f"{self.sku} x {self.quantity} (panier #{self.cart_id})"

    @property
    def sku(self):
        return self.variant.sku if self.variant_id else self.product.sku

    @property
    def prix_ht_actuel(self):
        """Le prix d'aujourd'hui de ce qui est au panier."""
        return self.variant.prix_ht if self.variant_id else self.product.price_ht

    def peut_servir(self, quantite=None):
        return self.product.peut_servir(
            self.quantity if quantite is None else quantite, self.variant
        )

    @property
    def total_ht(self) -> Decimal:
        return _montant(self.unit_price_ht * self.quantity)

    @property
    def unit_price_ttc(self) -> Decimal:
        return _ttc(self.unit_price_ht, self.tax_rate)

    @property
    def total_ttc(self) -> Decimal:
        # Sur le HT NON arrondi : arrondir d'abord le HT puis y appliquer la
        # TVA décalait le TTC d'un centime (voir `Product.price_ht`).
        return _ttc(self.unit_price_ht * self.quantity, self.tax_rate)


class Order(models.Model):
    """
    Commande client.
    La relation avec les paiements (Stripe, etc.) se fera dans l'app payments.
    """

    ORDER_STATUS_DRAFT = "draft"
    ORDER_STATUS_CONFIRMED = "confirmed"
    ORDER_STATUS_PROCESSING = "processing"
    ORDER_STATUS_SHIPPED = "shipped"
    ORDER_STATUS_COMPLETED = "completed"
    ORDER_STATUS_CANCELLED = "cancelled"

    ORDER_STATUS_CHOICES = [
        (ORDER_STATUS_DRAFT, _("Brouillon")),
        (ORDER_STATUS_CONFIRMED, _("Confirmée")),
        (ORDER_STATUS_PROCESSING, _("En cours de traitement")),
        (ORDER_STATUS_SHIPPED, _("Expédiée")),
        (ORDER_STATUS_COMPLETED, _("Terminée")),
        (ORDER_STATUS_CANCELLED, _("Annulée")),
    ]

    PAYMENT_STATUS_PENDING = "pending"
    PAYMENT_STATUS_PAID = "paid"
    PAYMENT_STATUS_FAILED = "failed"
    PAYMENT_STATUS_REFUNDED = "refunded"
    PAYMENT_STATUS_PARTIALLY_REFUNDED = "partially_refunded"

    PAYMENT_STATUS_CHOICES = [
        (PAYMENT_STATUS_PENDING, _("En attente")),
        (PAYMENT_STATUS_PAID, _("Payée")),
        (PAYMENT_STATUS_FAILED, _("Échouée")),
        (PAYMENT_STATUS_PARTIALLY_REFUNDED, _("Remboursée en partie")),
        (PAYMENT_STATUS_REFUNDED, _("Remboursée")),
    ]

    #: Ces deux statuts ne se posent pas à la main : ils suivent les
    #: remboursements enregistrés (`OrderRefund`), faute de quoi une commande
    #: s'affichait remboursée sans qu'un centime soit rendu (Fable 1, §3.6).
    PAYMENT_STATUSES_REMBOURSEMENT = (
        PAYMENT_STATUS_PARTIALLY_REFUNDED, PAYMENT_STATUS_REFUNDED,
    )

    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="orders",
        verbose_name=_("Utilisateur"),
    )

    cart = models.OneToOneField(
        Cart,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="order",
        verbose_name=_("Panier source"),
        help_text=_("Panier dont est issue cette commande (pour debug / tracking)."),
    )

    # L'intention de paiement Stripe en cours pour cette commande (Fable 1,
    # §1.4). Sans elle, rien ne rattachait un paiement à la version de la
    # commande qu'il réglait : une intention créée pour un panier à 10 €
    # restait payable après que la commande fut passée à 110 €.
    payment_intent_id = models.CharField(
        max_length=255, blank=True, default="", db_index=True,
        verbose_name=_("Intention de paiement"),
    )

    order_status = models.CharField(
        max_length=20,
        choices=ORDER_STATUS_CHOICES,
        default=ORDER_STATUS_DRAFT,
        verbose_name=_("Statut Commande"),
    )
    
    payment_status = models.CharField(
        max_length=20,
        choices=PAYMENT_STATUS_CHOICES,
        default=PAYMENT_STATUS_PENDING,
        verbose_name=_("Statut Paiement"),
    )

    # Totaux snapshot
    currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name=_("Devise"),
    )
    total_ht = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name=_("Total HT"),
    )
    total_tva = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name=_("Total TVA"),
    )
    total_ttc = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name=_("Total TTC"),
    )

    # Frais de port, figés au moment de la commande (Fable 1, §3.5 : les
    # zones de livraison se réglaient, et aucun produit expédié ne payait de
    # port). Compris dans les totaux ci-dessus ; `shipping_method` garde le
    # nom de la zone appliquée, pour qu'on sache plus tard pourquoi ce prix.
    shipping_ttc = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("0.00"),
        verbose_name=_("Frais de port TTC"),
    )
    shipping_tva = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("0.00"),
        verbose_name=_("TVA sur les frais de port"),
    )
    shipping_method = models.CharField(
        max_length=120, blank=True, verbose_name=_("Livraison"),
    )

    # Remise d'un code promo, figée comme le port : le code peut être modifié
    # ou supprimé ensuite, la commande garde ce qu'elle a accordé.
    coupon = models.ForeignKey(
        Coupon, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="orders", verbose_name=_("Code promo"),
    )
    coupon_code = models.CharField(max_length=40, blank=True, verbose_name=_("Code promo utilisé"))
    #: Quand le code a été RÉSERVÉ par cette commande (première préparation qui
    #: le porte). Fige le début des 30 min de réservation d'un code « N
    #: premiers » : réafficher l'écran de paiement ne le renouvelle PAS, sinon
    #: un panier pouvait garder un usage indéfiniment sans payer (P6-b). On
    #: compte dessus, pas sur `updated_at` que chaque préparation rafraîchit.
    coupon_reserved_at = models.DateTimeField(null=True, blank=True, editable=False)
    discount_ttc = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("0.00"),
        verbose_name=_("Remise TTC"),
    )
    discount_tva = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("0.00"),
        verbose_name=_("TVA de la remise"),
    )

    # Coordonnées. L'adresse proprement dite (rue, complément) reste un texte
    # libre ; code postal et pays sont à part parce que la zone de livraison
    # se choisit sur eux.
    billing_name = models.CharField(max_length=200, blank=True, verbose_name=_("Nom (facturation)"))
    billing_address = models.TextField(blank=True, verbose_name=_("Adresse (facturation)"))
    billing_postal_code = models.CharField(max_length=20, blank=True, verbose_name=_("Code postal (facturation)"))
    billing_city = models.CharField(max_length=120, blank=True, verbose_name=_("Ville (facturation)"))
    billing_country = models.CharField(max_length=2, blank=True, verbose_name=_("Pays (facturation)"))
    billing_phone = models.CharField(max_length=40, blank=True, verbose_name=_("Téléphone"))
    shipping_name = models.CharField(max_length=200, blank=True, verbose_name=_("Nom (livraison)"))
    shipping_address = models.TextField(blank=True, verbose_name=_("Adresse (livraison)"))
    shipping_postal_code = models.CharField(max_length=20, blank=True, verbose_name=_("Code postal (livraison)"))
    shipping_city = models.CharField(max_length=120, blank=True, verbose_name=_("Ville (livraison)"))
    shipping_country = models.CharField(max_length=2, blank=True, verbose_name=_("Pays (livraison)"))
    customer_note = models.TextField(
        blank=True, verbose_name=_("Note du client"),
        help_text=_("Laissée par le client au moment de commander."),
    )

    # La TVA par taux, figée à la préparation : {"20.00": {"ht", "tva",
    # "ttc"}}. Remise et port y sont déjà répartis sur les taux des articles
    # qu'ils concernent — ce qu'on ne saurait plus refaire une fois le code
    # promo modifié ou le type d'un produit changé. C'est elle que la facture
    # imprime.
    vat_breakdown = models.JSONField(default=dict, blank=True, verbose_name=_("Ventilation de la TVA"))
    invoice_number = models.CharField(
        max_length=30, blank=True, default="", db_index=True, verbose_name=_("N° de facture"),
    )
    invoiced_at = models.DateTimeField(null=True, blank=True, verbose_name=_("Facturée le"))

    # Expédition. Le message « commande expédiée » déclarait déjà transporteur
    # et numéro de suivi, qui partaient vides faute de champ où les saisir.
    carrier = models.CharField(max_length=80, blank=True, verbose_name=_("Transporteur"))
    tracking_number = models.CharField(max_length=120, blank=True, verbose_name=_("Numéro de suivi"))
    tracking_url = models.URLField(max_length=500, blank=True, verbose_name=_("Lien de suivi"))

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_("Créée le"),
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name=_("Mise à jour le"),
    )

    class Meta:
        verbose_name = _("Commande")
        verbose_name_plural = _("Commandes")
        ordering = ["-created_at", "-id"]

    def __str__(self) -> str:
        return f"Commande #{self.pk} – {self.order_status} / {self.payment_status}"

    @property
    def items_ttc(self) -> Decimal:
        """Le total des articles avant remise, sans le port."""
        return _montant(self.total_ttc - self.shipping_ttc + self.discount_ttc)

    @property
    def amount_refunded(self) -> Decimal:
        return _montant(
            self.refunds.aggregate(s=models.Sum("amount"))["s"] or 0
        )

    @property
    def amount_refundable(self) -> Decimal:
        return _montant(self.total_ttc - self.amount_refunded)

    @staticmethod
    def _bloc_adresse(nom, adresse, code_postal, ville, pays):
        lignes = [nom, adresse, " ".join(x for x in (code_postal, ville) if x), pays]
        return "\n".join(l.strip() for l in lignes if l and l.strip())

    @property
    def billing_block(self) -> str:
        return self._bloc_adresse(self.billing_name, self.billing_address,
                                  self.billing_postal_code, self.billing_city,
                                  self.billing_country)

    @property
    def shipping_block(self) -> str:
        return self._bloc_adresse(self.shipping_name, self.shipping_address,
                                  self.shipping_postal_code, self.shipping_city,
                                  self.shipping_country)


class OrderRefund(models.Model):
    """
    Un remboursement, total ou partiel, d'une commande.

    Le statut « remboursée » se posait à la main, sans que rien parte chez
    Stripe ; et un remboursement fait depuis le tableau de bord Stripe ne
    touchait jamais la commande (Fable 1, §3.6). Chaque remboursement est
    désormais une ligne, quelle que soit son origine : le site (Stripe ou
    hors ligne) ou Stripe lui-même, relu par le webhook `charge.refunded`.
    Le statut de paiement de la commande se déduit de leur somme.
    """

    SOURCE_STRIPE_SITE = "site"
    SOURCE_STRIPE_DASHBOARD = "stripe"
    SOURCE_HORS_LIGNE = "manual"
    SOURCE_CHOICES = [
        (SOURCE_STRIPE_SITE, _("Depuis le site, par Stripe")),
        (SOURCE_STRIPE_DASHBOARD, _("Depuis le tableau de bord Stripe")),
        (SOURCE_HORS_LIGNE, _("Hors ligne (virement, espèces…)")),
    ]

    order = models.ForeignKey(
        Order, on_delete=models.CASCADE, related_name="refunds",
        verbose_name=_("Commande"),
    )
    amount = models.DecimalField(
        max_digits=10, decimal_places=2, verbose_name=_("Montant remboursé"),
    )
    reason = models.CharField(max_length=255, blank=True, verbose_name=_("Motif"))
    source = models.CharField(
        max_length=10, choices=SOURCE_CHOICES, default=SOURCE_STRIPE_SITE,
        verbose_name=_("Origine"),
    )
    stripe_refund_id = models.CharField(
        max_length=255, blank=True, default="", verbose_name=_("Remboursement Stripe"),
    )
    restocked = models.BooleanField(default=False, verbose_name=_("Remis en stock"))
    # L'avoir qui annule (en tout ou partie) la facture : un remboursement
    # après facture ne s'efface pas, il se documente.
    credit_note_number = models.CharField(
        max_length=30, blank=True, default="", verbose_name=_("N° d'avoir"),
    )
    created_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+", verbose_name=_("Par"),
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_("Le"))

    class Meta:
        verbose_name = _("Remboursement")
        verbose_name_plural = _("Remboursements")
        ordering = ["created_at", "id"]

    def __str__(self) -> str:
        return f"Remboursement {self.amount} – commande #{self.order_id}"


class OrderLine(models.Model):
    """
    Ligne de commande (snapshot du produit et du prix au moment de la commande).
    """

    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE,
        related_name="lines",
    )

    product = models.ForeignKey(
        Product,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="order_lines",
        help_text=_("Produit d'origine (peut être supprimé plus tard)."),
    )
    variant = models.ForeignKey(
        ProductVariant, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="order_lines", verbose_name=_("Déclinaison"),
    )

    label = models.CharField(
        max_length=255,
        verbose_name=_("Description"),
        help_text=_("Texte affiché pour cette ligne (titre produit, options, etc.)."),
    )
    sku = models.CharField(
        max_length=64,
        blank=True,
        verbose_name=_("SKU (snapshot)"),
    )

    quantity = models.PositiveIntegerField(
        default=1,
        verbose_name=_("Quantité"),
    )

    unit_price_ht = models.DecimalField(
        max_digits=12,
        decimal_places=4,
        verbose_name=_("Prix unitaire HT"),
    )
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        verbose_name="TVA (%)",
    )
    # Ce qui en est déjà revenu en stock par un remboursement : on ne remet
    # pas deux fois le même article sur l'étagère.
    restocked_quantity = models.PositiveIntegerField(
        default=0, verbose_name=_("Quantité remise en stock"),
    )

    class Meta:
        verbose_name = _("Ligne de commande")
        verbose_name_plural = _("Lignes de commande")

    def __str__(self) -> str:
        return f"Commande #{self.order_id} – {self.label} x {self.quantity}"

    @property
    def unit_price_ttc(self) -> Decimal:
        return _ttc(self.unit_price_ht, self.tax_rate)

    @property
    def total_ht(self) -> Decimal:
        return _montant(self.unit_price_ht * self.quantity)

    @property
    def total_ttc(self) -> Decimal:
        # Sur le HT NON arrondi : arrondir d'abord le HT puis y appliquer la
        # TVA décalait le TTC d'un centime (voir `Product.price_ht`).
        return _ttc(self.unit_price_ht * self.quantity, self.tax_rate)
