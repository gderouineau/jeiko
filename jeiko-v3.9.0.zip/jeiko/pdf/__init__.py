"""
PDF de JEIKO : le moteur (`moteur.py`, D-10) et, à venir, les gabarits PDF
réglables à l'écran (D-11), le certificat de formation (D-05), la restitution
de questionnaire (D-12).

App inscrite dans `INSTALLED_APPS` dès le moteur, sans modèle encore : la
ligne du gabarit de settings part avec cette version, et D-11 n'aura pas à
toucher une seconde fois aux réglages des serveurs.
"""
