# jeiko/administration_pages/tests_horodatage.py
"""
Les horodatages qui servent de clé de cache doivent bouger. Toujours.

Le défaut
---------
`base.html` met le `<head>` en cache trente jours sous une clé qui contient
`metadata.updated_at`. L'API des agents écrivait le titre et la description
par `save(update_fields=["title", "description"])` — et Django n'écrit pas un
champ `auto_now` absent de `update_fields`. L'horodatage restait donc figé,
la clé de cache aussi, et la page continuait d'annoncer aux moteurs de
recherche l'ancien titre et l'ancienne description. Pendant trente jours.

Le symptôme était particulièrement traître : la base était juste. Relire la
page par l'API confirmait la nouvelle valeur. Seul le HTML servi au visiteur
mentait — et personne ne le compare à la base.

Ce qu'on verrouille
-------------------
Deux choses, parce que la première seule ne tiendrait pas :

* le comportement — une sauvegarde partielle fait bouger l'horodatage, sur
  chacun des modèles concernés ;
* la liste elle-même — toute clé `{% cache %}` de `base.html` qui repose sur
  un `updated_at` doit correspondre à un modèle inscrit ici. Sans ce second
  test, la clé de cache ajoutée l'an prochain ramènerait le défaut intact.
"""

import pathlib
import re
import time

from django.test import TestCase

from jeiko.administration.models import Logo, SiteIdentity, WebSite
from jeiko.administration_pages.models import Metadata, Page
from jeiko.custom_objects.models import CustomObjectMetadata

#: Les modèles dont un `auto_now` sert de clé de cache dans `base.html`,
#: indexés par le NOM DU FRAGMENT de cache — pas par le nom de la variable.
#:
#: La première version indexait par variable, et c'est une leçon en soi :
#: `base.html` appelle « metadata » deux modèles DIFFÉRENTS selon la branche
#: — `Metadata` pour une page ordinaire, `CustomObjectMetadata` pour une
#: fiche. Le test passait donc en ne vérifiant que le premier, et le second
#: est resté sans protection alors qu'il porte le titre de chaque page
#: produit d'une boutique.
#:
#: Le nom du fragment, lui, est unique par définition : c'est la clé de cache.
SOUS_CACHE = {
    "head_meta_block": Metadata,
    "head_meta_block_co": CustomObjectMetadata,
    "site_identity_block": (SiteIdentity, Logo),
    "site_assets_block": None,          # clé de version, pas d'horodatage
}


class SauvegardePartielleTests(TestCase):
    """Le comportement, modèle par modèle."""

    def _verifier(self, objet, champ, valeur):
        avant = objet.updated_at
        self.assertIsNotNone(avant, "l'objet doit être horodaté au départ")
        time.sleep(0.01)  # la résolution est large ; on s'assure d'un écart

        setattr(objet, champ, valeur)
        objet.save(update_fields=[champ])   # SANS updated_at : c'est le piège
        objet.refresh_from_db()

        self.assertGreater(
            objet.updated_at, avant,
            f"{type(objet).__name__}.updated_at n'a pas bougé après une "
            f"sauvegarde partielle. Toute clé de cache qui en dépend est "
            f"désormais figée. Faire hériter le modèle de "
            f"jeiko.horodatage.HorodatageFiable.",
        )

    def test_metadonnees_de_page(self):
        page = Page.objects.create(title="Essai", url_tag="essai-horodatage")
        meta = Metadata.objects.create(page=page, title="Avant", description="x")
        self._verifier(meta, "title", "Après")

    def test_identite_du_site(self):
        site = WebSite.objects.first() or WebSite.objects.create()
        identite = getattr(site, "identity", None) or SiteIdentity.objects.create(
            website=site, name="Avant"
        )
        self._verifier(identite, "name", "Nouveau nom")

    def test_logo(self):
        logo = Logo.objects.create()
        self._verifier(logo, "mail_logo", "images/logo/mail/essai.png")


class ToutesLesClesSontCouvertesTests(TestCase):
    """
    La liste ci-dessus doit suivre le gabarit, pas l'inverse.

    On lit les fragments `{% cache %}` de `base.html` et on vérifie que chacun
    de ceux qui reposent sur un `updated_at` est déclaré ici. Un fragment
    nouveau, ou renommé, fait échouer avec le nom qui manque.
    """

    GABARIT = (
        pathlib.Path(__file__).resolve().parent.parent
        / "templates" / "base.html"
    )

    #: `{% cache <durée> "<nom>" … %}` — on capture le nom et la clé entière.
    _CACHE = re.compile(r"\{%\s*cache\s+\S+\s+\"([^\"]+)\"(.*?)%\}", re.DOTALL)

    def _fragments(self):
        return self._CACHE.findall(self.GABARIT.read_text())

    def test_tout_fragment_horodate_est_declare(self):
        manquants = sorted(
            nom for nom, cle in self._fragments()
            if "updated_at" in cle and nom not in SOUS_CACHE
        )
        self.assertEqual(
            manquants, [],
            "Fragment de cache appuyé sur un updated_at et non déclaré : "
            + ", ".join(manquants)
            + ". Si son modèle peut être sauvegardé partiellement, son "
              "horodatage ne bougera pas et le fragment restera figé trente "
              "jours. L'ajouter à SOUS_CACHE et lui faire hériter de "
              "HorodatageFiable.",
        )

    def test_chaque_modele_declare_survit_a_une_sauvegarde_partielle(self):
        """
        Le lien entre la liste et le comportement.

        `SauvegardePartielleTests` éprouve trois modèles nommément. Celui-ci
        éprouve TOUS ceux que la liste déclare, y compris ceux qu'on y
        ajoutera demain — sans quoi la liste deviendrait une déclaration
        d'intention.
        """
        for nom, modeles in SOUS_CACHE.items():
            if modeles is None:
                continue
            for modele in (modeles if isinstance(modeles, tuple) else (modeles,)):
                with self.subTest(fragment=nom, modele=modele.__name__):
                    self.assertTrue(
                        any(
                            getattr(champ, "auto_now", False)
                            for champ in modele._meta.fields
                        ),
                        f"{modele.__name__} n'a aucun champ auto_now.",
                    )
                    self.assertIn(
                        "HorodatageFiable",
                        [classe.__name__ for classe in modele.__mro__],
                        f"{modele.__name__} porte une clé de cache mais n'hérite "
                        f"pas de HorodatageFiable : une sauvegarde partielle "
                        f"laisserait son horodatage figé.",
                    )
