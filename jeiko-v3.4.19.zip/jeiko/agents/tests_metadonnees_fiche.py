# jeiko/agents/tests_metadonnees_fiche.py
"""
Le SEO d'une fiche vit sur la FICHE — et l'API doit pouvoir l'écrire.

Le manque
---------
Trois objets se suivent dans une boutique JEIKO : le modèle décrit la forme,
la fiche porte le contenu, le produit ajoute le commerce. Le titre et la
description des résultats de recherche appartiennent à la **fiche**, dans un
modèle à part (`CustomObjectMetadata`).

Pourquoi pas ailleurs :

* pas sur la page gabarit — elle est unique et sert toutes les fiches d'un
  modèle : un titre posé là vaudrait pour toutes à la fois ;
* pas sur le produit — il n'en a aucun, il emprunte ceux de sa fiche.

L'API des agents ne les exposait pas du tout. Une boutique montée par un
agent sortait donc avec, pour chaque produit, le titre brut de la fiche et
**aucune description**. Google reprend alors un morceau du corps de la page —
souvent le menu, ou un prix isolé. Rien ne le signalait : la fiche était
créée, publiée, correcte.

L'horodatage, au passage
------------------------
`CustomObjectMetadata.updated_at` sert de clé au fragment `head_meta_block_co`
de `base.html`. Il lui fallait donc `HorodatageFiable`, comme à `Metadata`
(A-42) — et il ne l'avait pas, parce que le test de couverture indexait les
clés de cache par NOM DE VARIABLE, et que `base.html` appelle « metadata » ces
deux modèles distincts selon la branche. Le test est désormais indexé sur le
nom du fragment, qui est unique.
"""

import json

from django.test import TestCase, override_settings

from .tests import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class MetadonneesDeFicheTests(SocleMixin, TestCase):
    def setUp(self):
        from jeiko.administration_pages.models import Page
        from jeiko.custom_objects.models import CustomObject, CustomObjectModel

        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_customobject", "change_customobject",
            app="custom_objects", nom="Agent fiches",
        )
        gabarit = Page.objects.create(
            title="Gabarit prestation", url_tag="gabarit-prestation",
            is_custom_object_template=True,
        )
        modele = CustomObjectModel.objects.create(
            name="Prestation", slug="prestation", page_template=gabarit
        )
        self.fiche = CustomObject.objects.create(
            model=modele, title="Dépannage électrique", slug="depannage"
        )

    def _lire(self):
        reponse = self.client.get(
            f"/api/agent/v1/objets/{self.fiche.id}/", **self.entetes(self.jeton)
        )
        return reponse.json()["objet"]

    def _ecrire(self, corps):
        return self.client.patch(
            f"/api/agent/v1/objets/{self.fiche.id}/", data=json.dumps(corps),
            content_type="application/json", **self.entetes(self.jeton),
        )

    def test_les_metadonnees_sont_lisibles_meme_absentes(self):
        """
        Un champ absent de la réponse est un champ qu'on n'imagine pas écrire.

        Le modèle n'existe pas tant qu'on ne l'a pas créé : sans ce repli, la
        clé aurait disparu de la lecture, et un agent n'aurait eu aucune
        raison de la chercher.
        """
        self.assertEqual(
            self._lire()["metadonnees"], {"titre": "", "description": ""}
        )

    def test_on_peut_les_ecrire(self):
        reponse = self._ecrire({"metadonnees": {
            "titre": "Dépannage électrique 24h/24 — Paris 6ᵉ",
            "description": "Intervention sous 2 h.",
        }})
        self.assertEqual(reponse.status_code, 200, reponse.content[:300])
        self.assertIn("metadonnees.title", reponse.json()["modifies"])
        meta = self._lire()["metadonnees"]
        self.assertEqual(meta["titre"], "Dépannage électrique 24h/24 — Paris 6ᵉ")
        self.assertEqual(meta["description"], "Intervention sous 2 h.")

    def test_l_ecriture_est_partielle(self):
        """Régler la description ne doit pas effacer le titre."""
        self._ecrire({"metadonnees": {"titre": "Un titre", "description": "Une desc"}})
        self._ecrire({"metadonnees": {"description": "Une autre"}})
        meta = self._lire()["metadonnees"]
        self.assertEqual(meta["titre"], "Un titre")
        self.assertEqual(meta["description"], "Une autre")

    def test_une_cle_inconnue_est_refusee(self):
        reponse = self._ecrire({"metadonnees": {"seo_title": "x"}})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("seo_title", reponse.json()["erreur"])

    def test_l_horodatage_bouge_sur_une_ecriture_partielle(self):
        """
        Sans quoi le `<head>` de la fiche resterait figé trente jours.

        C'est exactement A-42, sur le modèle qui sert les pages produit d'une
        boutique — celles dont le référencement compte le plus.
        """
        import time

        from jeiko.custom_objects.models import CustomObjectMetadata

        self._ecrire({"metadonnees": {"titre": "Avant"}})
        meta = CustomObjectMetadata.objects.get(obj=self.fiche)
        avant = meta.updated_at

        time.sleep(0.01)
        self._ecrire({"metadonnees": {"titre": "Après"}})
        meta.refresh_from_db()
        self.assertGreater(meta.updated_at, avant)
