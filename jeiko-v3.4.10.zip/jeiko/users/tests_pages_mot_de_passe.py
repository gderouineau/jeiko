# jeiko/users/tests_pages_mot_de_passe.py
"""
Les pages « mot de passe » doivent ressembler au site.

Ce qui s'est passé
------------------
Constat de l'exploitant le 04/09 : « la page de réinitialisation est super
moche ». Elle l'était : JEIKO ne surchargeait aucun gabarit de cette famille,
et allauth servait les siens — qui s'appuient sur ses propres bases. Résultat :
pas de menu, pas de feuille de style, du HTML de navigateur nu.

À l'endroit précis où quelqu'un vient de perdre son mot de passe, la page qui
l'accueille n'avait rien à voir avec le site sur lequel il croyait être. C'est
aussi celle où l'on hésite le plus à saisir son adresse.

Ce que ces tests gardent
------------------------
Ils vérifient que **nos** gabarits sont bien ceux qui servent — pas que le HTML
est joli, ce qui ne se teste pas. Le contrôle porte sur l'héritage de
`base.html` et sur l'enveloppe `content-allauth`, les deux choses qui font
qu'une page appartient au site.

Le second contrôle est de fond : la page qui suit l'envoi ne doit **pas** dire
si un compte existe pour l'adresse saisie. Le dire en ferait un outil de
vérification d'adresses — on saurait, sans rien d'autre, qui est client.
"""

from django.test import TestCase
from django.urls import reverse

from jeiko.users.testing import creer_compte_verifie, reinitialiser_les_plafonds


class PagesDuMotDePasseTests(TestCase):
    def setUp(self):
        reinitialiser_les_plafonds()

    def test_la_demande_utilise_notre_gabarit(self):
        reponse = self.client.get(reverse("account_reset_password"))
        self.assertEqual(reponse.status_code, 200)
        self.assertTemplateUsed(reponse, "account/password_reset.html")
        self.assertTemplateUsed(
            reponse, "base.html",
            "Sans le socle du site, la page sort sans menu ni feuille de style.",
        )
        self.assertContains(reponse, "content-allauth")
        self.assertContains(reponse, "Mot de passe oublié")

    def test_la_confirmation_utilise_notre_gabarit(self):
        creer_compte_verifie("marie", email="marie@exemple.fr", password="Mot-De-Passe-42")
        reponse = self.client.post(
            reverse("account_reset_password"), {"email": "marie@exemple.fr"},
            follow=True,
        )
        self.assertTemplateUsed(reponse, "account/password_reset_done.html")
        self.assertContains(reponse, "indésirables")

    def test_la_confirmation_ne_dit_pas_si_le_compte_existe(self):
        """
        Le dire ferait de cette page un outil de vérification d'adresses : on
        saurait qui est client en essayant des e-mails, sans rien d'autre.
        """
        connue = self.client.post(
            reverse("account_reset_password"), {"email": "marie@exemple.fr"},
            follow=True,
        )
        creer_compte_verifie("paul", email="paul@exemple.fr", password="Mot-De-Passe-42")
        reinitialiser_les_plafonds()
        inconnue = self.client.post(
            reverse("account_reset_password"), {"email": "personne@exemple.fr"},
            follow=True,
        )
        self.assertEqual(
            connue.status_code, inconnue.status_code,
            "Une adresse connue et une inconnue doivent donner la même page.",
        )

    def test_un_lien_perime_explique_et_propose_une_suite(self):
        """
        Allauth s'arrête sur un refus. Une personne qui lit « non » referme ;
        il faut lui dire pourquoi et où recommencer.
        """
        reponse = self.client.get("/accounts/password/reset/key/0-invalide/")
        self.assertTemplateUsed(reponse, "account/password_reset_from_key.html")
        self.assertContains(reponse, "n'est plus valable")
        self.assertContains(reponse, reverse("account_reset_password"))

    def test_le_changement_depuis_le_compte_utilise_notre_gabarit(self):
        creer_compte_verifie("luc", email="luc@exemple.fr", password="Mot-De-Passe-42")
        self.client.login(username="luc", password="Mot-De-Passe-42")
        reponse = self.client.get(reverse("account_change_password"))
        self.assertTemplateUsed(reponse, "account/password_change.html")
        self.assertContains(reponse, "content-allauth")


class AucuneFamilleOubliee(TestCase):
    """
    Un inventaire : les écrans de compte servis par allauth doivent tous être
    à la charte.

    Il existe parce que le défaut s'est glissé exactement là — cinq gabarits
    manquants sur une famille entière, sans que rien ne le signale. Une page
    laide ne lève aucune exception.
    """

    ECRANS = (
        ("account_reset_password", "account/password_reset.html"),
        ("account_login", None),
        ("account_signup", None),
    )

    def test_chaque_ecran_herite_du_socle_du_site(self):
        for nom, _ in self.ECRANS:
            with self.subTest(ecran=nom):
                reponse = self.client.get(reverse(nom))
                self.assertContains(
                    reponse, "content-allauth",
                    msg_prefix=f"{nom} ne porte pas l'enveloppe du site",
                )
