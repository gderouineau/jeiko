# jeiko/liens.py
"""
Le contrôle unique des URL que JEIKO écrit dans un `href` ou un `src`.

Pourquoi (rapport Fable 2, §1.1)
--------------------------------
Les écritures de l'API faisaient `setattr(objet, "external_url", valeur)`
sans `full_clean()` : le `URLField` du modèle ne validait donc jamais. Le rendu
posait la valeur telle quelle — `href="{{ btn_url }}"`, `src` d'une iframe,
`:href` Alpine qui ne filtre aucun schéma. `javascript:…` écrit par un agent
(légitime ou détourné) s'exécutait chez chaque visiteur de la page publiée,
administrateurs compris.

Un seul module pour toutes les URL, à l'écriture (`url_sure`, qui refuse en
nommant la règle) ET au rendu (`url_neutralisee`, qui rend une chaîne vide) :
ce qui a été écrit avant la correction ne s'exécute pas non plus.

Ce que ça ne fait pas : vérifier qu'une URL mène quelque part, ni juger un
domaine. `https://site-douteux.example` est une URL sûre au sens de ce module.
"""

import re
from urllib.parse import urlsplit

#: Ce qu'autorise chaque usage.
USAGES = {
    # Un lien cliquable : bouton, lien d'élément, bouton de fiche.
    "lien": {"schemas": {"http", "https", "mailto", "tel"}, "relatif": True},
    # Un média chargé par la page : iframe vidéo, image externe.
    "media": {"schemas": {"http", "https"}, "relatif": True},
    # Une feuille chargée depuis un tiers : Google Fonts.
    "https": {"schemas": {"https"}, "relatif": False},
}

# Un navigateur retire tabulations et sauts de ligne AVANT de lire le
# schéma : « java\tscript: » s'exécute. Tout caractère de contrôle ou espace
# interne est donc refusé d'emblée, plutôt que de tenter de le normaliser.
_INVISIBLES = re.compile(r"[\x00-\x20\x7f]")

LONGUEUR_MAX = 2000


def _raison(valeur, usage):
    regle = USAGES[usage]
    if len(valeur) > LONGUEUR_MAX:
        return f"trop longue (plus de {LONGUEUR_MAX} caractères)"
    if _INVISIBLES.search(valeur):
        return "contient un espace ou un caractère invisible"
    if valeur.startswith("//"):
        return "adresse sans schéma : écrire https://…"
    if valeur.startswith(("/", "#", "?")):
        return None if regle["relatif"] else "une adresse complète en https:// est attendue"
    try:
        morceaux = urlsplit(valeur)
    except ValueError:
        return "adresse illisible"
    schema = morceaux.scheme.lower()
    if not schema:
        return None if regle["relatif"] and not ":" in valeur.split("/")[0] else (
            "une adresse complète est attendue (https://…)"
        )
    if schema not in regle["schemas"]:
        return f"le schéma « {schema}: » n'est pas autorisé ({', '.join(sorted(regle['schemas']))})"
    if schema in ("http", "https") and not morceaux.netloc:
        return "adresse sans domaine"
    return None


def url_sure(valeur, usage="lien", champ="url"):
    """
    Rend la valeur nettoyée, ou lève `ValueError` avec un message lisible.

    Une valeur vide reste vide : c'est l'absence de lien, pas une erreur.
    """
    valeur = "" if valeur is None else str(valeur).strip()
    if not valeur:
        return ""
    raison = _raison(valeur, usage)
    if raison:
        raise ValueError(f"« {champ} » refusée : {raison}.")
    return valeur


def url_neutralisee(valeur, usage="lien"):
    """Au rendu : la valeur si elle est sûre, sinon une chaîne vide."""
    try:
        return url_sure(valeur, usage)
    except ValueError:
        return ""
