"""
La langue de l'INTERFACE, par opposition à celle du contenu.

Le besoin
---------
95 % des sites JEIKO sont monolingues — mais pas forcément en français. Un
exploitant hispanophone qui tient un site en espagnol se heurtait à une
administration entièrement française : ce n'est pas un problème de traduction
de contenu, c'est un problème de langue de l'OUTIL. C'est celui-là qu'on règle
ici, et il touche tout le monde ; un moteur multilingue de contenu ne servirait
que les 5 % restants.

Pourquoi un middleware maison
------------------------------
`LocaleMiddleware` de Django décide de la langue à partir du cookie, puis de
l'en-tête `Accept-Language`. Il s'exécute **avant** `AuthenticationMiddleware`
— l'ordre est imposé par Django — donc `request.user` n'existe pas encore et
il ne peut pas consulter une préférence de compte.

D'où cette pièce, placée après l'authentification : sur un écran
d'administration, elle relit la préférence de la personne, puis le réglage du
site ; partout ailleurs, elle impose la langue du site, quel que soit le
navigateur. La préférence suit ainsi le
compte, pas le navigateur — un exploitant qui se connecte depuis un autre poste
retrouve son interface dans sa langue.

Ce que ce module ne fait PAS
-----------------------------
Il ne touche pas à la langue du **contenu** des pages publiques. Un site en
français reste en français pour ses visiteurs, quelle que soit la langue dans
laquelle son administrateur travaille. Les deux réglages sont indépendants, et
les confondre ferait qu'un exploitant anglophone publierait sans le vouloir un
site en anglais.
"""

import logging

from django.conf import settings
from django.utils import translation

from jeiko import langues_du_site

logger = logging.getLogger("jeiko")


def langues_disponibles():
    """Les couples (code, nom) proposés, tels que le projet les déclare."""
    return list(getattr(settings, "LANGUAGES", []))


def est_disponible(code):
    """
    Une langue proposée par ce site, et elle seule.

    Sans ce filtre, une valeur restée en base après un changement de
    configuration — ou glissée par un formulaire — activerait une langue sans
    traduction. L'interface retomberait silencieusement sur l'anglais de
    Django, ce qui ressemble à une panne plutôt qu'à un choix.
    """
    if not code:
        return False
    return any(code == disponible for disponible, _ in langues_disponibles())


def langue_de_l_utilisateur(user):
    """
    La langue d'administration d'une personne, ou `None` si elle n'a rien choisi.

    `None` et non la langue par défaut : l'appelant doit pouvoir distinguer
    « cette personne veut l'espagnol » de « cette personne n'a rien demandé ».
    Le second cas doit suivre le site, y compris quand celui-ci change de
    langue par la suite.
    """
    profil = getattr(user, "profile", None)
    code = getattr(profil, "langue_admin", "") if profil else ""
    return code if est_disponible(code) else None


def langue_de_l_administration():
    """
    La langue de l'administration réglée pour le site, ou `None`.

    Lue sur `WebSite`, déjà en cache pour chaque page : la consulter à chaque
    requête d'administration ne coûte pas de requête SQL.
    """
    from jeiko.administration.website_cache import get_website_data

    site = get_website_data()
    code = getattr(site, "langue_admin", "") if site else ""
    return code if est_disponible(code) else None


def langue_de_travail(user):
    """
    La langue dans laquelle une personne lit l'ADMINISTRATION : la sienne,
    sinon celle réglée pour le site, sinon `LANGUAGE_CODE`.

    Un seul endroit pour cette règle : le middleware la suit sur les écrans
    d'administration, et la barre d'administration la suit sur le site public
    — où la langue de la requête est celle du visiteur, pas celle de qui
    administre.
    """
    code = None
    if user is not None and getattr(user, "is_authenticated", False):
        code = langue_de_l_utilisateur(user)
    return code or langue_de_l_administration() or settings.LANGUAGE_CODE


#: Ce qui n'est ouvert qu'aux administrateurs : le tableau de bord et tout ce
#: que son menu atteint, et l'éditeur de pages. Tous les modules montent leurs
#: écrans d'administration sous ces deux préfixes (voir `jeiko/urls.py`).
PREFIXES_D_ADMINISTRATION = ("/administration/", "/jeiko/administration/")


def est_un_ecran_d_administration(request):
    return request.path.startswith(PREFIXES_D_ADMINISTRATION)


#: Ce qui n'est lu par aucun visiteur : l'API des agents et les fichiers.
#: Aucune langue de site n'y a cours — une page y donne son adresse propre, et
#: aucun cookie de langue n'y est posé. Le reste de `/api/` n'y figure PAS :
#: le bandeau cookies, la réservation et l'envoi d'un formulaire y répondent à
#: un visiteur, dans sa langue.
#: Les plans du site aussi : ils listent CHAQUE version à son adresse propre,
#: quel que soit le cookie de qui les demande.
#: L'administration de Django (`/admin/`) non plus : ses liens « voir sur le
#: site » doivent mener à l'adresse propre de l'objet.
PREFIXES_SANS_LANGUE = (
    "/api/agent/", "/static/", "/media/", "/oauth/", "/.well-known/",
    "/sitemap.xml", "/robots.txt", "/llms.txt", "/admin/",
)


def _est_une_page(view_func):
    """
    La vue qui sert une page du site (accueil compris), une fiche ou un
    produit : ce qui a une version par langue, donc une adresse par langue.
    """
    from jeiko.administration_pages.views_client import PageView, RootPage
    from jeiko.custom_objects.views.client import CustomObjectView
    from jeiko.shop.views.client import ProductView

    return getattr(view_func, "view_class", None) in (
        PageView, RootPage, CustomObjectView, ProductView,
    )


class LangueDeLAdministrationMiddleware:
    """
    Décide de la langue de la requête.

    * Un écran d'administration : la langue choisie par la personne sur son
      profil, sinon celle réglée pour le site (Réglages › Langue de
      l'administration), sinon `LANGUAGE_CODE`.
    * Tout le reste — le site public, la connexion, le compte d'un client, le
      panier : `LANGUAGE_CODE`, sauf sur un site en plusieurs langues (voir
      plus bas).

    À placer **après** `AuthenticationMiddleware` : avant, `request.user`
    n'existe pas et la préférence est invisible.

    Le navigateur n'a pas voix au chapitre. `LocaleMiddleware`, passé avant,
    a suivi `Accept-Language` : sur un site français, un visiteur au navigateur
    anglais recevait les messages de Django en anglais au milieu d'un contenu
    français — et depuis que les libellés de JEIKO sont traduisibles, il aurait
    reçu aussi le libellé anglais d'un champ sous une page rédigée en français.
    Le contenu d'un site n'existe que dans UNE langue ; ce qui l'entoure doit
    la parler aussi.

    **Un site en plusieurs langues** (`jeiko/langues_du_site.py`) : le visiteur
    lit alors la langue que dit l'adresse — `/en/…` —, et hors des pages celle
    que retient son cookie. Le navigateur, lui, n'a toujours pas voix.

    * `/en/pricing/` : le préfixe est retiré de `path_info`, si bien que les
      routes existantes servent la page sans rien savoir des langues ;
      `request.path` garde l'adresse complète. Il en va de même d'une fiche
      (`/en/co/…`) et d'un produit (`/en/shop/<type>/<référence>/`).
    * `/en/` devant autre chose (`/en/shop/cart/`, `/en/accounts/login/`) :
      redirigé vers l'adresse sans préfixe — ces écrans n'en ont pas, le
      cookie suffit.
    * Une page, une fiche ou un produit sans préfixe est dans la langue
      d'origine, quel que soit le cookie : `/` montre toujours la même chose,
      à Google comme au cache.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Les langues actives, lues une fois pour toute la requête.
        actives = langues_du_site.retenir_les_langues_actives()
        try:
            code = None
            langue_lue = None
            if est_un_ecran_d_administration(request):
                code = langue_de_travail(getattr(request, "user", None))
            elif not request.path.startswith(PREFIXES_SANS_LANGUE):
                langue_lue = self._langue_du_visiteur(request)
                code = langue_lue or None

            jeton = langues_du_site.fixer_la_langue(langue_lue)
            try:
                self._activer(request, code or settings.LANGUAGE_CODE)
                response = self.get_response(request)
                self._retenir(request, response)
                # La langue dans laquelle CETTE réponse est écrite. On la dit
                # ici : `LocaleMiddleware` la lit à son retour, c'est-à-dire
                # après que nous avons rendu la langue (voir ci-dessous).
                response.headers.setdefault("Content-Language", translation.get_language())
                return response
            finally:
                langues_du_site.oublier_la_langue(jeton)
                # Ne rien laisser derrière soi. `translation.activate()` vaut
                # pour le FIL D'EXÉCUTION, pas pour la requête : après une
                # page servie en anglais, tout ce qui s'exécutait ensuite dans
                # ce fil sans passer par ici — une tâche, un test — parlait
                # anglais. Relevé par un test d'export RGPD qui échouait une
                # fois sur dix, selon ce qui l'avait précédé (01/10/2026).
                translation.deactivate()
        finally:
            langues_du_site.oublier_les_langues_actives(actives)

    @staticmethod
    def _activer(request, code):
        if code != translation.get_language():
            translation.activate(code)
            # `request.LANGUAGE_CODE` est ce que lisent les gabarits et
            # `{% get_current_language %}`. Le laisser à la valeur posée
            # par LocaleMiddleware afficherait un sélecteur en désaccord
            # avec la page qu'il surmonte.
            request.LANGUAGE_CODE = translation.get_language()

    @staticmethod
    def _langue_du_visiteur(request):
        """
        "" (langue d'origine) ou le code d'une langue ajoutée ; `None` quand
        le site n'a qu'une langue — rien ne doit alors changer.
        """
        actives = langues_du_site.langues_actives()
        if not actives:
            return None
        prefixe, reste = langues_du_site.prefixe_de_langue(request.path_info)
        if prefixe:
            request.langue_du_prefixe = prefixe
            request.path_info = reste
            return prefixe
        retenue = request.COOKIES.get(settings.LANGUAGE_COOKIE_NAME)
        return retenue if retenue in actives else ""

    def process_view(self, request, view_func, view_args, view_kwargs):
        if langues_du_site.langue_du_site() is None:
            return None
        if _est_une_page(view_func):
            # L'adresse fait foi, pas le cookie.
            langue = getattr(request, "langue_du_prefixe", "")
            langues_du_site.fixer_la_langue(langue)
            self._activer(request, langue or settings.LANGUAGE_CODE)
            return None
        if getattr(request, "langue_du_prefixe", None):
            from django.http import HttpResponseRedirect

            suite = request.META.get("QUERY_STRING", "")
            response = HttpResponseRedirect(request.path_info + (f"?{suite}" if suite else ""))
            self._retenir(request, response)
            return response
        return None

    @staticmethod
    def _retenir(request, response):
        """
        Retient la langue lue dans un cookie — seulement s'il y a quelque chose
        à retenir : un visiteur qui n'a jamais quitté la langue d'origine n'en
        reçoit pas, et ses réponses restent identiques pour un cache en amont.
        """
        langue = langues_du_site.langue_du_site()
        if langue is None:
            return
        retenue = request.COOKIES.get(settings.LANGUAGE_COOKIE_NAME)
        voulue = langue or langues_du_site.langue_d_origine()
        if retenue == voulue or (retenue is None and not langue):
            return
        response.set_cookie(
            settings.LANGUAGE_COOKIE_NAME, voulue,
            max_age=60 * 60 * 24 * 365, samesite="Lax",
            secure=request.is_secure(),
        )
