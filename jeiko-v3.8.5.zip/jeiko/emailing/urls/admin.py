from django.urls import path
from jeiko.emailing.views import admin as admin_views

app_name = "jeiko_administration_emailing"

urlpatterns = [
    # AVANT « <slug:code>/ », qui prendrait « envois » pour un code d'e-mail.
    path("envois/", admin_views.HistoriqueDesEnvois.as_view(), name="envois"),
    path("envois/<int:pk>/", admin_views.DetailDUnEnvoi.as_view(), name="envoi"),
    path("envois/<int:pk>/renvoyer/", admin_views.RenvoyerUnEnvoi.as_view(), name="envoi_renvoyer"),
    path(
        "",
        admin_views.EmailTemplateListView.as_view(),
        name="template_list",
    ),
    path(
        "<slug:code>/",
        admin_views.EmailTemplateUpdateView.as_view(),
        name="template_edit",
    ),
    path(
        "<slug:code>/apercu/",
        admin_views.EmailTemplatePreviewView.as_view(),
        name="template_preview",
    ),
    path(
        "<slug:code>/activer/",
        admin_views.EmailTemplateToggleActiveView.as_view(),
        name="template_toggle_active",
    ),
    path(
        "<slug:code>/reinitialiser/",
        admin_views.EmailTemplateResetView.as_view(),
        name="template_reset",
    ),
]