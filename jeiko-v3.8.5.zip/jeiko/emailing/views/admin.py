# jeiko/emailing/views/admin.py
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.clickjacking import xframe_options_sameorigin

from jeiko.emailing import registry, render as email_render
from jeiko.emailing.builder import apply_seed
from jeiko.emailing.forms import EmailTemplateForm
from jeiko.emailing.models import EmailTemplate
from jeiko.emailing.seeds import get_seed
from django.utils.translation import gettext_lazy as _

# Réutilise la permission des réglages email tant que l'app n'a pas les siennes.
EMAILING_PERMISSION = "users.config_edit_mail"


class EmailTemplateListView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """Catalogue des e-mails, groupé par catégorie."""

    template_name = "emailing/admin/template_list.html"
    permission_required = EMAILING_PERMISSION

    def get(self, request):
        templates_by_code = {t.code: t for t in EmailTemplate.objects.select_related("page")}

        categories = []
        for key, label, events in registry.events_by_category():
            rows = [
                {
                    "code": code,
                    "event": event,
                    "audience_label": registry.AUDIENCE_LABELS.get(event["audience"], ""),
                    "template": templates_by_code.get(code),
                    "has_seed": get_seed(code) is not None,
                    # Un e-mail obligatoire ne se coupe pas : la liste affiche
                    # le verrou et le motif plutôt qu'un bouton qui échouerait.
                    "mandatory": registry.is_mandatory(code),
                    "branche": registry.est_branche(code),
                    "mandatory_reason": registry.mandatory_reason(code),
                }
                for code, event in events
            ]
            categories.append({
                "key": key,
                "label": label,
                "rows": rows,
                "configured": sum(1 for row in rows if row["template"]),
                "total": len(rows),
            })

        # Templates dont le code a disparu du catalogue.
        orphans = [t for t in templates_by_code.values() if t.is_orphan]

        return render(request, self.template_name, {
            "categories": categories,
            "orphans": orphans,
            "total_events": len(registry.EMAIL_EVENTS),
            "total_configured": sum(1 for t in templates_by_code.values() if not t.is_orphan),
        })


class EmailTemplateUpdateView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Édition du sujet et des réglages d'envoi d'un e-mail.

    Le template est créé à la volée au premier accès : le catalogue fait foi,
    la base ne stocke que ce qui a été personnalisé.
    """

    template_name = "emailing/admin/template_form.html"
    permission_required = EMAILING_PERMISSION

    def get_object(self, code):
        event = registry.get_event(code)
        if event is None:
            # Code hors catalogue : on n'édite que ce qui existe déjà en base.
            return get_object_or_404(EmailTemplate, code=code)

        template, __ = EmailTemplate.objects.get_or_create(
            code=code,
            defaults={"subject": f"[%site_nom%] — {event['label']}"},
        )
        return template

    def get_context(self, template, form):
        context = email_render.sample_context(template.code)
        __, warnings = email_render.render_page(template.page, context)

        return {
            "template": template,
            "form": form,
            "variables": template.available_variables(),
            "is_transactional": registry.is_transactional(template.code),
            "preview_subject": template.render_subject(context),
            "preview_warnings": warnings,
            "preview_url": reverse(
                "jeiko_administration_emailing:template_preview",
                args=[template.code],
            ),
            "has_seed": get_seed(template.code) is not None,
        }

    def get(self, request, code):
        template = self.get_object(code)
        form = EmailTemplateForm(instance=template)
        return render(request, self.template_name, self.get_context(template, form))

    def post(self, request, code):
        template = self.get_object(code)
        form = EmailTemplateForm(request.POST, instance=template)

        if form.is_valid():
            form.save()
            messages.success(request, _("Modèle d'e-mail enregistré."))
            return redirect(reverse("jeiko_administration_emailing:template_edit", args=[code]))

        return render(request, self.template_name, self.get_context(template, form))


class EmailTemplateResetView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Remet un e-mail dans son état d'origine.

    Passe par le même `apply_seed` que l'installation : un e-mail réinitialisé
    est rigoureusement identique à un e-mail fraîchement posé. L'ancienne page
    n'est pas supprimée mais archivée, pour qu'un clic malheureux ne fasse pas
    perdre le travail de mise en page.
    """

    permission_required = EMAILING_PERMISSION

    def post(self, request, code):
        get_object_or_404(EmailTemplate, code=code)

        outcome = apply_seed(code, force=True)

        if outcome == "no_seed":
            messages.error(
                request,
                _("Aucun contenu par défaut n'est déclaré pour cet e-mail."),
            )
        else:
            messages.success(
                request,
                _("Contenu réinitialisé. La version précédente a été archivée "
                "et reste consultable dans les pages désactivées."),
            )

        # Réinitialiser depuis la liste doit y ramener, pas ouvrir l'édition.
        if request.POST.get("next") == "list":
            return redirect(reverse("jeiko_administration_emailing:template_list"))

        return redirect(reverse("jeiko_administration_emailing:template_edit", args=[code]))


@method_decorator(xframe_options_sameorigin, name="dispatch")
class EmailTemplatePreviewView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Rendu e-mail brut, destiné à être affiché dans une iframe.

    Indispensable : l'éditeur visuel montre le rendu web (grille CSS, media
    queries), pas ce qui sera réellement envoyé.

    `xframe_options_sameorigin` autorise l'encadrement DEPUIS le site lui-même,
    et seulement ici. Le réglage global est passé à `DENY` : le site entier est
    désormais inencadrable, ce qui ferme le détournement de clic. Ces écrans
    d'aperçu étaient les deux seuls à avoir besoin d'une iframe interne — c'est
    pour eux que `SAMEORIGIN` avait été mis partout, ce qui laissait toutes les
    autres pages encadrables par elles-mêmes.
    """

    permission_required = EMAILING_PERMISSION

    def get(self, request, code):
        template = get_object_or_404(EmailTemplate, code=code)
        context = email_render.sample_context(code)
        html, __ = email_render.render_page(template.page, context)

        if not html:
            html = (
                "<!DOCTYPE html><html><body "
                "style=\"font-family:Arial,sans-serif;padding:24px;color:#888;\">"
                "Aucun contenu à afficher.</body></html>"
            )

        return HttpResponse(html)


class EmailTemplateToggleActiveView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Active ou coupe un e-mail, en un geste depuis la liste.

    Le drapeau `EmailTemplate.active` existait et `services.send_email` le
    respectait déjà, mais aucun écran ne permettait de le changer : l'état était
    affiché sans pouvoir être touché.

    Certains e-mails refusent d'être coupés (`registry.MANDATORY_CODES`). Sans
    ce garde-fou, une case décochée par mégarde enfermerait des utilisateurs
    dehors — l'envoi échouant en silence, par conception, personne ne s'en
    apercevrait avant les réclamations.

    POST uniquement : c'est un changement d'état, il n'a rien à faire derrière
    un lien qu'un préchargement peut déclencher.
    """

    permission_required = EMAILING_PERMISSION

    def post(self, request, code):
        template = get_object_or_404(EmailTemplate, code=code)
        libelle = registry.get_event(code) or {}
        nom = libelle.get("label", code)

        if template.active and registry.is_mandatory(code):
            messages.error(
                request,
                _("« %(nom)s » ne peut pas être désactivé. %(mandatory_reason)s") % {"nom": nom, "mandatory_reason": registry.mandatory_reason(code)},
            )
        else:
            template.active = not template.active
            template.save(update_fields=["active", "updated_at"])
            if template.active:
                messages.success(request, _("« %(nom)s » sera de nouveau envoyé.") % {"nom": nom})
            else:
                messages.success(
                    request,
                    _("« %(nom)s » ne sera plus envoyé, jusqu'à réactivation.") % {"nom": nom},
                )

        return redirect(reverse("jeiko_administration_emailing:template_list"))


# --------------------------------------------------------------------------- #
#  Historique des envois (A-88)
# --------------------------------------------------------------------------- #
def renvoyable(log):
    """
    Un envoi se renvoie s'il a ÉCHOUÉ et que le journal en a tout gardé.

    Le journal retire les secrets (liens d'action, codes : voir
    `services.contexte_consigne`) ; renvoyer une réinitialisation de mot de
    passe enverrait un lien vide. L'effacement RGPD vide l'adresse : il n'y a
    plus personne à qui renvoyer.
    """
    from jeiko.emailing.services import RETIRE_DU_JOURNAL

    contexte = log.context if isinstance(log.context, dict) else {}
    return (log.status == log.STATUS_FAILED and bool(log.to_email)
            and RETIRE_DU_JOURNAL not in contexte.values())


class HistoriqueDesEnvois(LoginRequiredMixin, PermissionRequiredMixin, View):
    """Les e-mails partis (ou non) du site, filtrables. Lecture : rien ne s'y modifie."""

    template_name = "emailing/admin/envois.html"
    permission_required = EMAILING_PERMISSION
    raise_exception = True
    par_page = 50

    def get(self, request):
        from datetime import datetime, timedelta

        from django.core.paginator import Paginator
        from django.utils import timezone

        from jeiko.emailing.models import EmailLog

        envois = EmailLog.objects.order_by("-queued_at")
        evenement = request.GET.get("evenement", "")
        if evenement in registry.EMAIL_EVENTS:
            envois = envois.filter(template_code=evenement)
        destinataire = (request.GET.get("destinataire") or "").strip()
        if destinataire:
            envois = envois.filter(to_email__icontains=destinataire)
        statut = request.GET.get("statut", "")
        if statut in dict(EmailLog.STATUS_CHOICES):
            envois = envois.filter(status=statut)
        for cle, condition in (("du", "queued_at__gte"), ("au", "queued_at__lt")):
            try:
                jour = datetime.strptime(request.GET.get(cle, ""), "%Y-%m-%d")
            except ValueError:
                continue
            if cle == "au":
                jour += timedelta(days=1)
            envois = envois.filter(**{condition: timezone.make_aware(jour)})

        page = Paginator(envois, self.par_page).get_page(request.GET.get("page"))
        parametres = request.GET.copy()
        parametres.pop("page", None)
        return render(request, self.template_name, {
            "page_obj": page, "is_paginated": page.has_other_pages(),
            "envois": page.object_list,
            "parametres_sans_page": parametres.urlencode(),
            "evenements": sorted(((c, e["label"]) for c, e in registry.EMAIL_EVENTS.items()),
                                 key=lambda x: x[1]),
            "statuts": EmailLog.STATUS_CHOICES,
            "filtres": {"evenement": evenement, "destinataire": destinataire, "statut": statut,
                        "du": request.GET.get("du", ""), "au": request.GET.get("au", "")},
            "libelles": {c: e["label"] for c, e in registry.EMAIL_EVENTS.items()},
        })


class DetailDUnEnvoi(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "emailing/admin/envoi.html"
    permission_required = EMAILING_PERMISSION
    raise_exception = True

    def get(self, request, pk):
        from jeiko.emailing.models import EmailLog

        envoi = get_object_or_404(EmailLog, pk=pk)
        return render(request, self.template_name, {
            "envoi": envoi,
            "libelle": (registry.get_event(envoi.template_code) or {}).get("label", envoi.template_code),
            "contexte": sorted((envoi.context or {}).items()) if isinstance(envoi.context, dict) else [],
            "renvoyable": renvoyable(envoi),
        })


class RenvoyerUnEnvoi(LoginRequiredMixin, PermissionRequiredMixin, View):
    """Rejoue un envoi raté, sur la MÊME ligne de journal (pas de doublon)."""
    permission_required = EMAILING_PERMISSION
    raise_exception = True

    def post(self, request, pk):
        from jeiko.emailing.models import EmailLog
        from jeiko.emailing.services import send_email

        envoi = get_object_or_404(EmailLog, pk=pk)
        if not renvoyable(envoi):
            messages.error(request, _("Cet envoi ne peut pas être renvoyé."))
        else:
            envoi.attempts += 1
            envoi.save(update_fields=["attempts"])
            parti, erreur = send_email(envoi.template_code, envoi.to_email, context=envoi.context,
                                       user=envoi.user, log=envoi)
            if parti:
                messages.success(request, _("E-mail renvoyé."))
            else:
                messages.error(request, _("Nouvel échec : %(erreur)s") % {"erreur": erreur})
        return redirect("jeiko_administration_emailing:envoi", pk=pk)

