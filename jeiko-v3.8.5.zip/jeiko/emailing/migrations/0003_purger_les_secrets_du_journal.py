"""
Purge des clés d'accès déjà consignées dans `EmailLog` (Fable 1 §1.6).

`services.contexte_consigne` empêche désormais de les écrire ; il reste celles
écrites avant, conservées jusqu'à un an. La règle est recopiée ici plutôt
qu'importée : une migration doit rester vraie même si le code bouge.

Les entrées encore en file (`queued`) sont laissées intactes : elles ont
besoin de leur contexte pour être envoyées.
"""

from django.db import migrations

RETIRE = "[retiré du journal]"


def _est_secrete(cle):
    cle = str(cle).lower()
    return cle in {"code", "mot_de_passe"} or cle.startswith("lien")


def purger(apps, schema_editor):
    EmailLog = apps.get_model("emailing", "EmailLog")
    for log in EmailLog.objects.exclude(status="queued").iterator():
        contexte = log.context if isinstance(log.context, dict) else {}
        propre = {
            cle: (RETIRE if _est_secrete(cle) and valeur else valeur)
            for cle, valeur in contexte.items()
        }
        if propre != contexte:
            EmailLog.objects.filter(pk=log.pk).update(context=propre)


class Migration(migrations.Migration):
    dependencies = [("emailing", "0002_seed_email_templates")]
    operations = [migrations.RunPython(purger, migrations.RunPython.noop)]
