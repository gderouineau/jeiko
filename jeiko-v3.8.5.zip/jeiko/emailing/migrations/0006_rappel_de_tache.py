"""
`crm_task_reminder` : le rappel d'une tâche de suivi du CRM (04/10/2026).
Pose son contenu par défaut s'il manque, sans rien écraser.
"""
from django.db import migrations


def poser(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    apply_seed("crm_task_reminder", force=False)


class Migration(migrations.Migration):
    dependencies = [
        ("emailing", "0005_compte_rendu_de_rendez_vous"),
        ("administration_pages", "0079_recalculer_les_heros_apres_la_quarantaine"),
    ]
    operations = [migrations.RunPython(poser, migrations.RunPython.noop)]
