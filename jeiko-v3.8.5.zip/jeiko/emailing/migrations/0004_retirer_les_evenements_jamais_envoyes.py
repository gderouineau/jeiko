"""
Les onze événements que rien n'envoie encore (A-85) restent au catalogue.

Une première version de cette migration les retirait, modèle et page compris.
Guillaume a tranché le 03/10/2026 : on les GARDE, ils seront branchés plus
tard (newsletter, relances de questionnaire, enquête, réactivation, campagne,
retour en stock, export RGPD prêt). Cette version ne retire donc rien : elle
repose le contenu par défaut d'un de ces e-mails s'il manquait — sans rien
écraser (`force=False`). Sur un site en service, elle ne fait rien.

Le nom du fichier reste : 0005 en dépend.
"""
from django.db import migrations

EN_ATTENTE = (
    "rgpd_data_export_ready", "test_invitation", "test_abandoned_reminder",
    "test_retake_reminder", "product_back_in_stock", "newsletter_double_optin",
    "newsletter_welcome", "newsletter_unsubscribe_confirm", "reactivation",
    "nps_survey", "campaign_manual",
)


def reposer(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    for code in EN_ATTENTE:
        apply_seed(code, force=False)


class Migration(migrations.Migration):
    dependencies = [
        ("emailing", "0003_purger_les_secrets_du_journal"),
        ("administration_pages", "0071_champ_de_formulaire_nomme_comme_le_leurre"),
    ]
    operations = [migrations.RunPython(reposer, migrations.RunPython.noop)]
