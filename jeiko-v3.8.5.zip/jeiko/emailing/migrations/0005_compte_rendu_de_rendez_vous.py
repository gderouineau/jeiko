"""
`appointment_followup` devient le compte rendu de rendez-vous du CRM
(CRM-05) : nouvelles variables (`compte_rendu`, `rdv_type`), nouveau contenu.

Sur les sites en service, son contenu est l'ancien — un remerciement avec un
lien d'avis, semé par 0002 mais jamais envoyé : rien ne le déclenchait (A-85).
On repose le contenu par défaut ; l'ancien est ARCHIVÉ, pas supprimé, comme
le fait « Revenir à la version par défaut ».

Même choix que 0002 : le constructeur et `seeds.py` du code courant, pas les
modèles historiques — le contenu par défaut n'existe que là.
"""
from django.db import migrations


def reposer(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    apply_seed("appointment_followup", force=True)


class Migration(migrations.Migration):
    dependencies = [
        ("emailing", "0004_retirer_les_evenements_jamais_envoyes"),
        ("users", "0015_notes_du_crm"),
    ]
    operations = [migrations.RunPython(reposer, migrations.RunPython.noop)]
