# jeiko/cache.py
"""
Un cache memcached qu'on peut vider sans vider celui des voisins.

Le problème (rapport Fable 1, §1.7)
-----------------------------------
Tous les sites d'une machine partagent le même memcached (`127.0.0.1:11211`),
séparés par leur `KEY_PREFIX`. Mais `cache.clear()` sur `PyMemcacheCache`
envoie `flush_all` : le préfixe n'y change rien, c'est le serveur entier qui
est vidé. Le bouton « Vider le cache » d'un site, ou la mise à jour d'un site
par `jeiko-client-update`, remettaient donc à zéro le cache de contenu, les
menus ET les compteurs anti-abus (`jeiko_throttle`) de tous les sites de la
machine — une fenêtre de contournement des plafonds à chaque clic, et l'alias
dédié qui devait justement protéger ces compteurs ne protégeait de rien.

La réponse : une génération, pas un effacement
----------------------------------------------
Chaque clé est préfixée par un numéro de génération propre au site, rangé dans
memcached lui-même. `clear()` n'efface rien : il change de génération. Les
anciennes entrées deviennent introuvables et expirent d'elles-mêmes (leur
`TIMEOUT`), ou sont évincées par memcached quand la place manque.

La génération lue est gardée en mémoire deux secondes, pour ne pas doubler
chaque accès au cache d'un aller-retour. Conséquence assumée : après un
`clear()`, les autres processus du même site peuvent servir l'ancienne
génération jusqu'à deux secondes — un vidage de cache n'a jamais été
instantané pour une requête déjà en cours.

Si memcached évince la clé de génération elle-même, la suivante part de
l'heure courante : elle est plus grande que toutes les précédentes (sauf à
vider plus d'une fois par seconde depuis la mise en service), et ne ressuscite
donc pas d'anciennes entrées.

Ce que ça ne fait pas
---------------------
Ça ne cloisonne pas les sites contre un site malveillant de la même machine :
memcached n'a pas d'authentification, n'importe quel processus local lit et
écrit tout. C'est une isolation de bon voisinage, pas une frontière de
sécurité. Pour cela, une instance memcached par site (socket Unix à droits
restreints).
"""

import time

from django.core.cache.backends.memcached import PyMemcacheCache


class CacheDuSite(PyMemcacheCache):
    DUREE_MEMO = 2.0

    def __init__(self, server, params):
        super().__init__(server, params)
        self._memo = (0.0, None)

    @property
    def _cle_generation(self):
        return f"{self.key_prefix}:jeiko-generation"

    def _generation(self):
        instant, valeur = self._memo
        maintenant = time.monotonic()
        if valeur is not None and maintenant - instant < self.DUREE_MEMO:
            return valeur

        valeur = self._cache.get(self._cle_generation)
        if valeur is None:
            # Premier accès, ou clé évincée. `add` : si un autre processus
            # vient de la poser, c'est la sienne qui compte — on la relit.
            self._cache.add(self._cle_generation, int(time.time()), expire=0, noreply=False)
            valeur = self._cache.get(self._cle_generation)
            if valeur is None:
                # memcached injoignable (`ignore_exc`) : rien n'est lu ni
                # écrit de toute façon ; ne pas mémoriser.
                return 0
        valeur = int(valeur)
        self._memo = (maintenant, valeur)
        return valeur

    def make_key(self, key, version=None):
        if version is None:
            version = self.version
        return self.key_func(key, f"{self.key_prefix}:g{self._generation()}", version)

    def clear(self):
        """Change de génération : le cache de CE site seulement est vidé."""
        if self._cache.incr(self._cle_generation, 1, noreply=False) is None:
            self._cache.set(self._cle_generation, int(time.time()), expire=0, noreply=False)
        self._memo = (0.0, None)
