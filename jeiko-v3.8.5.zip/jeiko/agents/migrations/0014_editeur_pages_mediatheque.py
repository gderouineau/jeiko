"""
L'agent éditeur de pages peut enrichir la médiathèque (28/09/2026).

Constaté en construisant une page de bout en bout par le serveur MCP : le rôle
« Agent éditeur de pages » posait des blocs IMAGE mais ne pouvait pas envoyer
d'image — `creer_image` répondait 403. Une page ne se construisait qu'avec les
images déjà là. L'envoi passe par les mêmes validations que l'administration
(poids, format réel, dimensions, texte alternatif).
"""

from django.db import migrations

AJOUTS = {"agent-editeur-pages": {"administration_pages": ("view_imagecontent", "add_imagecontent")}}


def peupler(apps, schema_editor):
    from django.apps import apps as registre_reel
    from django.contrib.auth.management import create_permissions

    create_permissions(registre_reel.get_app_config("administration_pages"), verbosity=0)

    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")
    for slug, par_application in AJOUTS.items():
        role = Role.objects.filter(slug=slug).first()
        if role is None:
            continue
        for app_label, codenames in par_application.items():
            for codename in codenames:
                permission = Permission.objects.filter(
                    codename=codename, content_type__app_label=app_label
                ).first()
                if permission is not None:
                    RolePermission.objects.get_or_create(role=role, permission=permission)


class Migration(migrations.Migration):

    dependencies = [("jeiko_agents", "0013_role_questionnaires_dimensions_et_style")]

    operations = [migrations.RunPython(peupler, migrations.RunPython.noop)]
