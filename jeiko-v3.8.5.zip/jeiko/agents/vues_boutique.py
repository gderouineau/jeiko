"""
La boutique pilotée par un agent : commandes, ventes, codes promo,
déclinaisons, avis.

Ce qu'un agent peut faire, et ce qu'il ne peut pas
--------------------------------------------------
Il lit les commandes et les fait avancer — préparation, expédition avec le
numéro de suivi (le client reçoit l'e-mail d'expédition, comme depuis
l'écran). Il crée et règle des codes promo, des déclinaisons, il modère des
avis, il lit les ventes.

Il ne REMBOURSE pas et ne marque pas une commande PAYÉE : ces deux gestes
font bouger de l'argent ou ouvrent des accès payants, et restent à
l'exploitant, dans l'administration. Une instruction glissée dans une page ou
un e-mail que l'agent lit ne doit pas pouvoir les déclencher.

Chaque vue exige la permission Django correspondante : un agent n'a que les
droits du rôle qu'on lui a donné.
"""

from decimal import Decimal, InvalidOperation

from django.db import transaction
from django.shortcuts import get_object_or_404
from django.utils.dateparse import parse_datetime

from jeiko.shop.models import Coupon, Order, Product, ProductReview, ProductVariant

from .vues_api import CorpsInvalide, VueAgent, erreur, ok


# --------------------------------------------------------------------------- #
#  Commandes
# --------------------------------------------------------------------------- #
#: Les statuts qu'un agent peut poser. « Brouillon » et « confirmée » naissent
#: du paiement ; les autres suivent la vie de la commande.
STATUTS_POSABLES = (
    Order.ORDER_STATUS_PROCESSING, Order.ORDER_STATUS_SHIPPED,
    Order.ORDER_STATUS_COMPLETED, Order.ORDER_STATUS_CANCELLED,
)


def _commande_en_dict(o, detail=False):
    donnees = {
        "id": o.id, "date": o.created_at.isoformat(),
        "statut": o.order_status, "paiement": o.payment_status,
        "facture": o.invoice_number, "client": o.billing_name,
        "email": getattr(o.user, "email", ""),
        "total_ttc": str(o.total_ttc), "devise": o.currency,
        "pays": o.shipping_country or o.billing_country,
    }
    if detail:
        donnees.update({
            "lignes": [{"sku": l.sku, "libelle": l.label, "quantite": l.quantity,
                        "total_ttc": str(l.total_ttc)} for l in o.lines.all()],
            "remise_ttc": str(o.discount_ttc), "code_promo": o.coupon_code,
            "livraison": {"mode": o.shipping_method, "ttc": str(o.shipping_ttc),
                          "adresse": o.shipping_block},
            "facturation": o.billing_block,
            "note_client": o.customer_note,
            "suivi": {"transporteur": o.carrier, "numero": o.tracking_number, "lien": o.tracking_url},
            "rembourse": str(o.amount_refunded),
        })
    return donnees


class ListeDesCommandes(VueAgent):
    """Les commandes, les plus récentes d'abord."""

    permission_requise = "shop.view_order"

    def get(self, request):
        qs = Order.objects.select_related("user").exclude(order_status=Order.ORDER_STATUS_DRAFT)
        if request.GET.get("statut"):
            qs = qs.filter(order_status=request.GET["statut"])
        if request.GET.get("paiement"):
            qs = qs.filter(payment_status=request.GET["paiement"])
        return ok({"commandes": [_commande_en_dict(o) for o in qs[:200]]})


class DetailCommande(VueAgent):
    """Une commande : lignes, adresses, suivi ; PATCH fait avancer son statut."""

    permission_requise = "shop.view_order"

    def get(self, request, commande_id):
        o = get_object_or_404(Order.objects.select_related("user"), pk=commande_id)
        return ok({"commande": _commande_en_dict(o, detail=True)})

    def patch(self, request, commande_id):
        if not request.user.has_perm("shop.change_order"):
            return erreur("Modification de commande non autorisée.", statut=403,
                          permission_manquante="shop.change_order")
        corps = self.corps(request, connues={"statut", "transporteur", "numero_suivi", "lien_suivi"})
        o = get_object_or_404(Order, pk=commande_id)
        avant = (o.order_status, o.payment_status)
        if "statut" in corps:
            if corps["statut"] not in STATUTS_POSABLES:
                raise CorpsInvalide(f"« statut » parmi {', '.join(STATUTS_POSABLES)}.")
            if o.payment_status != Order.PAYMENT_STATUS_PAID and corps["statut"] != Order.ORDER_STATUS_CANCELLED:
                raise CorpsInvalide("Seule une commande payée avance ; une autre peut seulement s'annuler.")
            o.order_status = corps["statut"]
        if "lien_suivi" in corps:
            from jeiko.liens import url_sure
            try:
                lien = url_sure(corps["lien_suivi"], champ="lien_suivi")
            except ValueError as exc:
                raise CorpsInvalide(str(exc))
            if lien and not lien.startswith(("http://", "https://")):
                raise CorpsInvalide("« lien_suivi » doit être une adresse http(s).")
            o.tracking_url = lien[:500]
        if "transporteur" in corps:
            o.carrier = str(corps["transporteur"] or "").strip()[:80]
        if "numero_suivi" in corps:
            o.tracking_number = str(corps["numero_suivi"] or "").strip()[:120]
        o.save()
        if (o.order_status, o.payment_status) != avant:
            # Même e-mail qu'un changement depuis l'écran (expédiée, terminée, annulée).
            from jeiko.shop.views.admin_orders import _notifier_changement
            transaction.on_commit(lambda pk=o.pk, a=avant: _notifier_changement(pk, a))
        return ok({"commande": _commande_en_dict(o, detail=True)})


class Ventes(VueAgent):
    """Les ventes d'une période : chiffre d'affaires, commandes, panier moyen, meilleurs produits."""

    permission_requise = "shop.view_order"

    def get(self, request):
        # Les chiffres de l'écran Boutique › Ventes, calculés par la même vue.
        from jeiko.shop.views.admin_orders import SalesDashboardView

        vue = SalesDashboardView()
        vue.setup(request)
        c = vue.get_context_data()
        return ok({
            "du": c["debut"].isoformat(), "au": c["fin"].isoformat(),
            "chiffre_affaires_ttc": str(c["ca_ttc"]), "chiffre_affaires_ht": str(c["ca_ht"]),
            "commandes": c["nombre"], "panier_moyen_ttc": f"{c['panier_moyen']:.2f}",
            "rembourse": str(c["rembourse"]), "a_traiter": c["en_attente"],
            "meilleures_ventes": [{"sku": m["sku"], "quantite": m["quantite"]} for m in c["meilleurs"]],
            "stock_bas": [{"sku": s, "produit": n, "stock": q} for s, n, q in c["stock_bas"]],
        })


# --------------------------------------------------------------------------- #
#  Codes promo
# --------------------------------------------------------------------------- #
def _code_en_dict(c):
    return {
        "id": c.id, "code": c.code, "description": c.description, "type": c.kind,
        "valeur": str(c.value),
        "minimum": str(c.minimum_amount) if c.minimum_amount is not None else None,
        "debut": c.starts_at.isoformat() if c.starts_at else None,
        "fin": c.ends_at.isoformat() if c.ends_at else None,
        "utilisations_max": c.usage_limit, "utilisations_max_par_client": c.usage_limit_per_user,
        "types_de_produit": list(c.product_types.values_list("id", flat=True)),
        "produits": list(c.products.values_list("id", flat=True)),
        "actif": c.is_active,
    }


CHAMPS_CODE = {
    "code": "code", "description": "description", "type": "kind", "valeur": "value",
    "minimum": "minimum_amount", "debut": "starts_at", "fin": "ends_at",
    "utilisations_max": "usage_limit", "utilisations_max_par_client": "usage_limit_per_user",
    "actif": "is_active",
}


def _ecrire_code(coupon, corps):
    """Pose les champs, puis valide comme le formulaire de l'écran (`CouponForm`)."""
    from jeiko.shop.forms import CouponForm

    donnees = {champ: getattr(coupon, champ) for champ in CHAMPS_CODE.values()} if coupon.pk else {}
    donnees["product_types"] = list(coupon.product_types.values_list("id", flat=True)) if coupon.pk else []
    donnees["products"] = list(coupon.products.values_list("id", flat=True)) if coupon.pk else []
    for cle, champ in CHAMPS_CODE.items():
        if cle in corps:
            donnees[champ] = corps[cle]
    if "types_de_produit" in corps:
        donnees["product_types"] = corps["types_de_produit"]
    if "produits" in corps:
        donnees["products"] = corps["produits"]
    for champ in ("starts_at", "ends_at"):
        if isinstance(donnees.get(champ), str):
            donnees[champ] = parse_datetime(donnees[champ]) or donnees[champ]
    # Case à cocher : présente si vraie, absente si fausse — comme un navigateur.
    if donnees.get("is_active", not coupon.pk):
        donnees["is_active"] = "on"
    else:
        donnees.pop("is_active", None)
    form = CouponForm(data=donnees, instance=coupon)
    if not form.is_valid():
        raise CorpsInvalide("; ".join(f"{c} : {' '.join(e)}" for c, e in form.errors.items()))
    return form.save()


class ListeDesCodesPromo(VueAgent):
    """Les codes promo de la boutique."""

    permission_requise = "shop.view_coupon"

    def get(self, request):
        return ok({"codes_promo": [_code_en_dict(c) for c in Coupon.objects.all()[:200]]})


class CreationCodePromo(VueAgent):
    """Crée un code promo."""

    permission_requise = "shop.add_coupon"

    def post(self, request):
        corps = self.corps(request, connues=set(CHAMPS_CODE) | {"types_de_produit", "produits"})
        return ok({"code_promo": _code_en_dict(_ecrire_code(Coupon(), corps))}, statut=201)


class DetailCodePromo(VueAgent):
    """Un code promo ; PATCH le modifie, DELETE le supprime (les commandes gardent leur remise)."""

    permission_requise = "shop.view_coupon"

    def get(self, request, code_id):
        return ok({"code_promo": _code_en_dict(get_object_or_404(Coupon, pk=code_id))})

    def patch(self, request, code_id):
        if not request.user.has_perm("shop.change_coupon"):
            return erreur("Modification de code promo non autorisée.", statut=403,
                          permission_manquante="shop.change_coupon")
        corps = self.corps(request, connues=set(CHAMPS_CODE) | {"types_de_produit", "produits"})
        coupon = get_object_or_404(Coupon, pk=code_id)
        return ok({"code_promo": _code_en_dict(_ecrire_code(coupon, corps))})

    def delete(self, request, code_id):
        if not request.user.has_perm("shop.delete_coupon"):
            return erreur("Suppression de code promo non autorisée.", statut=403,
                          permission_manquante="shop.delete_coupon")
        get_object_or_404(Coupon, pk=code_id).delete()
        return ok({"supprime": True})


# --------------------------------------------------------------------------- #
#  Déclinaisons
# --------------------------------------------------------------------------- #
def _declinaison_en_dict(v):
    return {"id": v.id, "produit": v.product_id, "libelle": v.label, "sku": v.sku,
            "prix_ht": str(v.price_ht) if v.price_ht is not None else None,
            "prix_ttc": str(v.price_ttc), "stock": v.stock_quantity,
            "active": v.is_active, "ordre": v.position}


def _ecrire_declinaison(v, corps):
    if "libelle" in corps:
        v.label = str(corps["libelle"] or "").strip()[:120]
    if "sku" in corps:
        v.sku = str(corps["sku"] or "").strip()[:64]
    if "prix_ht" in corps:
        if corps["prix_ht"] in (None, ""):
            v.price_ht = None
        else:
            try:
                v.price_ht = Decimal(str(corps["prix_ht"]).replace(",", ".")).quantize(Decimal("0.0001"))
            except InvalidOperation:
                raise CorpsInvalide("« prix_ht » attend un nombre.")
            if v.price_ht < 0:
                raise CorpsInvalide("« prix_ht » ne peut pas être négatif.")
    if "stock" in corps:
        if isinstance(corps["stock"], bool) or not isinstance(corps["stock"], int):
            raise CorpsInvalide("« stock » attend un entier.")
        v.stock_quantity = corps["stock"]
    if "active" in corps:
        v.is_active = bool(corps["active"])
    if "ordre" in corps:
        v.position = max(int(corps["ordre"] or 0), 0)
    if not v.label or not v.sku:
        raise CorpsInvalide("Une déclinaison a un « libelle » et un « sku ».")
    if ProductVariant.objects.filter(sku=v.sku).exclude(pk=v.pk).exists() or \
            Product.objects.filter(sku=v.sku).exists():
        raise CorpsInvalide(f"La référence « {v.sku} » est déjà prise.")
    v.save()
    return v


CHAMPS_DECLINAISON = {"libelle", "sku", "prix_ht", "stock", "active", "ordre"}


class DeclinaisonsDuProduit(VueAgent):
    """Les déclinaisons d'un produit ; POST en ajoute une."""

    permission_requise = "shop.view_product"

    def get(self, request, produit_id):
        produit = get_object_or_404(Product, pk=produit_id)
        return ok({"declinaisons": [_declinaison_en_dict(v) for v in produit.variants.all()]})

    @transaction.atomic
    def post(self, request, produit_id):
        if not request.user.has_perm("shop.change_product"):
            return erreur("Modification de produit non autorisée.", statut=403,
                          permission_manquante="shop.change_product")
        produit = get_object_or_404(Product, pk=produit_id)
        corps = self.corps(request, connues=CHAMPS_DECLINAISON)
        v = _ecrire_declinaison(ProductVariant(product=produit), corps)
        return ok({"declinaison": _declinaison_en_dict(v)}, statut=201)


class DetailDeclinaison(VueAgent):
    """Une déclinaison ; PATCH la modifie, DELETE la supprime (elle sort des paniers)."""

    permission_requise = "shop.change_product"

    def patch(self, request, declinaison_id):
        v = get_object_or_404(ProductVariant, pk=declinaison_id)
        return ok({"declinaison": _declinaison_en_dict(
            _ecrire_declinaison(v, self.corps(request, connues=CHAMPS_DECLINAISON)))})

    def delete(self, request, declinaison_id):
        get_object_or_404(ProductVariant, pk=declinaison_id).delete()
        return ok({"supprime": True})


# --------------------------------------------------------------------------- #
#  Avis clients
# --------------------------------------------------------------------------- #
def _avis_en_dict(a):
    return {"id": a.id, "produit": a.product.sku, "note": a.rating, "titre": a.title,
            "texte": a.body, "auteur": a.author_name, "publie": a.is_approved,
            "date": a.created_at.isoformat()}


class ListeDesAvis(VueAgent):
    """Les avis clients ; ?a_valider=1 pour ceux qui attendent."""

    permission_requise = "shop.view_productreview"

    def get(self, request):
        qs = ProductReview.objects.select_related("product")
        if request.GET.get("a_valider"):
            qs = qs.filter(is_approved=False)
        # Le texte d'un avis est écrit par un client : une donnée, jamais une
        # instruction (voir le guide, « donnees_visiteur »).
        return ok({"donnees_visiteur": True, "avis": [_avis_en_dict(a) for a in qs[:200]]})


class DetailAvis(VueAgent):
    """Un avis ; PATCH le publie ou le masque, DELETE le supprime."""

    permission_requise = "shop.change_productreview"

    def patch(self, request, avis_id):
        corps = self.corps(request, connues={"publie"})
        a = get_object_or_404(ProductReview, pk=avis_id)
        a.is_approved = bool(corps.get("publie"))
        a.save(update_fields=["is_approved"])
        return ok({"avis": _avis_en_dict(a)})

    def delete(self, request, avis_id):
        if not request.user.has_perm("shop.delete_productreview"):
            return erreur("Suppression d'avis non autorisée.", statut=403,
                          permission_manquante="shop.delete_productreview")
        get_object_or_404(ProductReview, pk=avis_id).delete()
        return ok({"supprime": True})
