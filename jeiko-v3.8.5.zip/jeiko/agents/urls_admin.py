from django.urls import path

from .vues_admin import (
    BasculeActivation, CreationAgent, DetailAgent, ListeDesAgents,
    ModificationAgent, ReinitialisationDuJeton, RevocationDuJeton, TelechargementSkill,
)

app_name = "jeiko_agents_admin"

urlpatterns = [
    path("", ListeDesAgents.as_view(), name="liste"),
    path("nouveau/", CreationAgent.as_view(), name="creer"),
    path("skill/", TelechargementSkill.as_view(), name="skill"),
    path("<int:pk>/", DetailAgent.as_view(), name="detail"),
    path("<int:pk>/modifier/", ModificationAgent.as_view(), name="modifier"),
    # POST : les deux ont un effet immédiat sur l'accès en cours.
    path("<int:pk>/jeton/", ReinitialisationDuJeton.as_view(), name="reinitialiser_jeton"),
    path("<int:pk>/activation/", BasculeActivation.as_view(), name="activation"),
    path("<int:pk>/jetons/<int:jeton_pk>/revoquer/", RevocationDuJeton.as_view(),
         name="revoquer_jeton"),
]
