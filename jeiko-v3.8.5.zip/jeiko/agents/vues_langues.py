# jeiko/agents/vues_langues.py
"""
Le site en plusieurs langues, par l'API des agents.

Ce qu'un agent peut faire
-------------------------
* lire l'option et les langues du site, les changer s'il a le droit sur les
  réglages du site (`administration.change_website`) ;
* créer la version d'une page dans une langue : la page d'origine est
  dupliquée, en brouillon — c'est ensuite une page comme une autre, que les
  routes habituelles (sections, lignes, blocs, contenus) traduisent.

Ce qu'il ne peut pas faire
--------------------------
* **Traduire automatiquement.** JEIKO ne traduit rien : c'est l'agent qui écrit
  le texte et le dépose. Aucun service de traduction n'est branché ici.
* **Supprimer une version.** Aucune route de l'API ne supprime une page ; une
  version se dépublie (`publiee: false`), elle se supprime dans
  l'administration.

Les règles d'ensemble sont dans `jeiko/langues_du_site.py`.
"""

from django.db import transaction
from django.shortcuts import get_object_or_404

from jeiko import langues_du_site
from jeiko.administration.models import WebSite
from jeiko.administration_pages.models import Page
from jeiko.administration_pages.versions import (
    VersionImpossible, creer_version, regler_les_langues,
)

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR = "administration.view_website"
MODIFIER = "administration.change_website"
CREER_UNE_PAGE = "administration_pages.add_page"


def _langues_en_dict():
    # Lu EN BASE, pas dans le cache du site que sert `langues_actives()` : un
    # agent qui vient de faire activer l'option doit lire ce qui est
    # enregistré. Le 02/10, ateliersderouineau.com répondait `multilingue:
    # false` à l'API alors que l'option venait d'être cochée (A-87).
    # L'option elle-même, et non « il y a des langues actives ».
    site = WebSite.objects.only("multilingue", "langues_du_site").first()
    choisies = set((site.langues_du_site or []) if site else [])
    return {
        "multilingue": bool(site and site.multilingue),
        "langue_d_origine": langues_du_site.langue_d_origine(),
        "langues": [c for c in langues_du_site.codes_proposes() if c in choisies],
        # Ce qu'on peut activer : les langues dont JEIKO a les textes.
        "langues_proposees": langues_du_site.codes_proposes(),
    }


class Langues(VueAgent):
    """
    L'option « site en plusieurs langues » et les langues ajoutées.

    La langue d'origine n'est pas dans `langues` : c'est celle du site, sans
    préfixe d'adresse. **Retirer une langue dépublie ses pages et ses fiches**
    (sans les supprimer) ; la réponse en donne le nombre.
    """

    permission_requise = VOIR

    def get(self, request):
        return ok({"langues_du_site": _langues_en_dict()})

    @transaction.atomic
    def patch(self, request):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification des réglages du site non autorisée.", statut=403)
        site = WebSite.objects.first()
        if site is None:
            raise CorpsInvalide("Aucun site n'est configuré.")

        corps = self.corps(request, connues={"multilingue", "langues"})
        langues = corps.get("langues", site.langues_du_site)
        if not isinstance(langues, list):
            raise CorpsInvalide("« langues » est une liste de codes, par exemple [\"en\"].")
        inconnues = sorted(set(map(str, langues)) - set(langues_du_site.codes_proposes()))
        if inconnues:
            raise CorpsInvalide(
                f"Langue(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Proposées : {', '.join(langues_du_site.codes_proposes())}."
            )
        multilingue = bool(corps.get("multilingue", site.multilingue))
        if multilingue and not langues:
            raise CorpsInvalide("Un site en plusieurs langues a besoin d'au moins une langue ajoutée.")
        try:
            depubliees = regler_les_langues(site, multilingue=multilingue, langues=langues)
        except VersionImpossible as refus:
            raise CorpsInvalide(str(refus)) from refus
        return ok({
            "langues_du_site": _langues_en_dict(),
            "pages_depubliees": depubliees.pages,
            "fiches_depubliees": depubliees.fiches,
        })


class VersionsDeLaPage(VueAgent):
    """
    Crée la version d'une page dans une langue du site, par duplication.

    `{"langue": "en"}` — la réponse est la nouvelle page : mêmes sections,
    mêmes images, même adresse que l'originale, et **en brouillon**. Reste à
    traduire son titre, son `url_tag`, ses métadonnées (PATCH /pages/<id>/) et
    son contenu, puis à la publier.
    """

    permission_requise = CREER_UNE_PAGE

    @transaction.atomic
    def post(self, request, page_id):
        from .vues_pages import _page_en_resume

        page = get_object_or_404(Page, pk=page_id)
        corps = self.corps(request, connues={"langue"})
        try:
            version = creer_version(page, str(corps.get("langue") or ""))
        except VersionImpossible as refus:
            return erreur(str(refus), statut=409)
        return ok({"page": _page_en_resume(version)}, statut=201)
