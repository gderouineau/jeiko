# jeiko/agents/oauth.py
"""
L'OAuth du serveur MCP — brancher un site sur claude.ai et l'app mobile (P-04).

Pourquoi
--------
Claude Code et Claude Desktop se branchent sur `/api/agent/mcp/` avec un jeton
collé dans un en-tête. claude.ai et l'application Claude du téléphone, non :
leurs connecteurs personnalisés n'acceptent qu'une autorisation OAuth. Sans ce
module, piloter un site depuis le téléphone est impossible.

Reprise de l'implémentation d'Avantion (`quantapp/api/oauth.py`, 28/09/2026),
relue et éprouvée là-bas : mêmes exigences des clients, mêmes gardes.

Ce que c'est : une façon de remettre un jeton d'agent ordinaire
---------------------------------------------------------------
Au bout du parcours, le client reçoit un `AgentToken` comme les autres — celui
qu'on aurait créé dans l'administration et collé à la main. Rien d'autre ne
change : `authentification.identifier` le vérifie, le rôle de l'agent décide,
le plafond compte, le journal note. **Aucun chemin d'autorisation nouveau.**

**Le jeton est celui d'un AGENT, jamais celui de la personne qui autorise.**
La page de consentement fait choisir l'agent — donc le rôle. Donner à un
assistant le compte de l'exploitant lui donnerait tout.

**N'autorise que qui peut déjà créer un agent** (`auth.change_user`, la
permission des écrans d'agents) : autoriser, c'est créer un jeton. Le
consentement n'ouvre pas ce droit à plus de monde. La connexion passe par le
formulaire du site, double authentification comprise.

Pourquoi hors de `/api/agent/`
------------------------------
Ces routes ne portent pas de jeton d'agent : elles en délivrent. Sous
`/api/agent/`, elles tomberaient sous la logique de l'API (jeton exigé,
journal des appels). `/oauth/token` rend le jeton en clair : il ne doit être
recopié nulle part. La trace du consentement est dans `CodeOAuth`, et le
jeton délivré porte le nom du client dans son libellé.

Ce que les clients exigent (relevé par Avantion le 28/09/2026)
-------------------------------------------------------------
- un 401 avec `WWW-Authenticate: Bearer resource_metadata="…"` sur le serveur
  MCP (voir `mcp.py`) ;
- les métadonnées de la ressource (RFC 9728), `resource` égal À LA LETTRE à
  l'adresse saisie dans le client ;
- les métadonnées du serveur d'autorisation (RFC 8414), avec
  `code_challenge_methods_supported: ["S256"]` ;
- l'enregistrement dynamique (RFC 7591) ;
- `/oauth/token` en `application/x-www-form-urlencoded`, `/oauth/register`
  en JSON ;
- des adresses de retour fixes, plus le retour « loopback » de Claude Code.

Côté serveur : nginx refuse tout chemin qui commence par un point
(`location ~ /\\.`). L'installeur ouvre `/.well-known/oauth-` vers
l'application — sans quoi claude.ai reçoit un 403 et abandonne.

Ce qu'il ne fait pas
--------------------
**Pas de jeton de rafraîchissement.** Le jeton délivré n'expire pas, comme
ceux de l'administration ; il se révoque (fiche de l'agent), et l'agent peut
porter une date d'expiration. Un jeton révoqué rend 401 : le client relance
l'autorisation — une révocation doit repasser par un humain.

**Pas de portée (scope).** Les droits sont ceux du rôle de l'agent ; une
portée OAuth serait un second modèle de permission. Une portée demandée est
ignorée.

**Le jeton n'est pas lié à la ressource.** C'est un jeton d'agent : il ouvre
toute l'API des agents, pas seulement le serveur MCP — avec les droits de
l'agent, ni plus ni moins que le jeton collé à la main.

**« Réinitialiser le jeton »** sur la fiche de l'agent révoque tous ses
jetons, ceux délivrés par OAuth compris : l'assistant devra se reconnecter.
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
import secrets
from datetime import timedelta
from urllib.parse import urlencode, urlsplit

from django.contrib.auth.views import redirect_to_login
from django.db import transaction
from django.http import HttpResponseRedirect, JsonResponse
from django.shortcuts import render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from jeiko.throttling import get_client_ip, hit

from . import jetons
from .authentification import _https_exige
from .models import Agent, AgentToken, ClientOAuth, CodeOAuth

#: La permission des écrans d'agents (`vues_admin.PERM`). Autoriser un client,
#: c'est créer un jeton d'agent : même droit.
PERM = "auth.change_user"

#: Durée de vie d'un code. Dix minutes est le plafond de la RFC 6749 (§4.1.2) :
#: le code ne sert qu'à franchir la redirection.
DUREE_DU_CODE = timedelta(minutes=10)

#: LES ADRESSES DE RETOUR ADMISES — là où un code peut être envoyé.
#:
#: L'enregistrement est ouvert à tous (RFC 7591, c'est son principe). Sans
#: cette liste, n'importe qui déclarerait un client qui renvoie chez lui, et
#: il ne resterait que la vigilance de celui qui clique « Autoriser ».
#: L'application Claude (web, bureau, téléphone) ; `claude.com` est annoncé
#: comme la future adresse. Un nouveau client s'ajoute ICI, et nulle part
#: ailleurs.
ADRESSES_DE_RETOUR = (
    "https://claude.ai/api/mcp/auth_callback",
    "https://claude.com/api/mcp/auth_callback",
)
RETOURS_PAR_MOTIF: tuple = ()

#: Le retour « loopback » d'un client natif (RFC 8252) : Claude Code écoute sur
#: un port éphémère, différent à chaque session. Le port est ignoré à la
#: comparaison (§7.3).
HOTES_LOOPBACK = ("127.0.0.1", "localhost", "::1")

#: L'enregistrement est une ÉCRITURE SANS JETON. Claude enregistre un client à
#: chaque nouvelle connexion : ces bornes laissent une large marge à un
#: exploitant et arrêtent qui martèle.
ENREGISTREMENTS_PAR_HEURE = 30
ENREGISTREMENTS_PAR_IP_ET_PAR_HEURE = 10

#: Un client réel déclare une ou deux adresses de retour.
RETOURS_PAR_CLIENT = 5

#: Un client qui n'a obtenu aucun code en un jour ne servira plus : effacé au
#: prochain enregistrement. Rien à planifier.
VIE_D_UN_CLIENT_INUTILE = timedelta(days=1)


# ── Les adresses ────────────────────────────────────────────────────────────


def _site(request) -> str:
    """`https://domaine` — l'émetteur, lu sur la requête (ALLOWED_HOSTS garde l'hôte)."""
    return request.build_absolute_uri("/").rstrip("/")


def chemin_mcp() -> str:
    return reverse("agents_mcp")


def ressource(request, chemin: str | None = None) -> str:
    """L'adresse du serveur MCP, telle que le client la saisit."""
    return _site(request) + (chemin or chemin_mcp())


def _chemin_saisi(request) -> str:
    """
    Le chemin du serveur MCP TEL QUE LE CLIENT L'APPELLE, avec ou sans barre
    finale : claude.ai compare `resource` à la lettre à l'adresse saisie.
    """
    if request.path.rstrip("/") == chemin_mcp().rstrip("/"):
        return request.path
    return chemin_mcp()


def adresse_des_metadonnees(request) -> str:
    """Où lire les métadonnées de la ressource (RFC 9728, forme suffixée)."""
    return f"{_site(request)}/.well-known/oauth-protected-resource{_chemin_saisi(request)}"


def entete_www_authenticate(request) -> str:
    """L'en-tête du 401 qui déclenche l'autorisation chez Claude."""
    return f'Bearer realm="jeiko", resource_metadata="{adresse_des_metadonnees(request)}"'


def _est_loopback(adresse: str) -> bool:
    parties = urlsplit(adresse)
    return parties.scheme == "http" and (parties.hostname or "") in HOTES_LOOPBACK


def retour_admis(adresse) -> bool:
    """Cette adresse de retour peut-elle être enregistrée ?"""
    if (not isinstance(adresse, str) or not adresse or len(adresse) > 500
            or "#" in adresse or any(ord(c) < 33 or ord(c) == 127 for c in adresse)):
        # Un caractère de contrôle (CR/LF) finirait dans l'en-tête `Location`.
        return False
    if adresse in ADRESSES_DE_RETOUR:
        return True
    if any(m.fullmatch(adresse) for m in RETOURS_PAR_MOTIF):
        return True
    return _est_loopback(adresse)


def _sans_port(adresse: str) -> tuple:
    p = urlsplit(adresse)
    return (p.scheme, p.hostname, p.path, p.query)


def retour_enregistre(client: ClientOAuth, adresse: str) -> bool:
    """
    L'adresse fait-elle partie de celles que le client a enregistrées ?

    Comparaison EXACTE, sauf le port d'un retour loopback (RFC 8252 §7.3).
    Une comparaison par préfixe laisserait passer
    `https://claude.ai/api/mcp/auth_callback/../../ailleurs`.
    """
    if adresse in client.adresses_de_retour:
        return True
    if _est_loopback(adresse):
        cle = _sans_port(adresse)
        return any(_est_loopback(a) and _sans_port(a) == cle
                   for a in client.adresses_de_retour)
    return False


def _meme_ressource(request, demandee: str) -> bool:
    """`resource` (RFC 8707) désigne-t-il bien notre serveur MCP ?"""
    return demandee.rstrip("/") == ressource(request).rstrip("/")


def _https_manquant(request) -> bool:
    """Même règle que l'API : un jeton ne voyage jamais en clair."""
    return _https_exige() and not request.is_secure()


# ── Les métadonnées ─────────────────────────────────────────────────────────


def metadonnees_ressource(request, suffixe: str = ""):
    """
    RFC 9728. Servie à la racine ET sous la forme suffixée par le chemin du
    serveur MCP — c'est celle-ci que pointe le 401, et Claude essaie les deux.

    `resource` doit égaler À LA LETTRE l'adresse saisie dans le client : on
    rend celle que désigne le suffixe, avec ou sans barre finale.
    """
    chemin = "/" + suffixe if suffixe else chemin_mcp()
    if chemin.rstrip("/") != chemin_mcp().rstrip("/"):
        return JsonResponse({"error": "ressource inconnue"}, status=404)
    from jeiko.administration.models import WebSite

    site = WebSite.objects.only("name").first()
    return JsonResponse({
        "resource": ressource(request, chemin),
        "authorization_servers": [_site(request)],
        "bearer_methods_supported": ["header"],
        "scopes_supported": [],
        "resource_name": (site.name if site and site.name else request.get_host()),
    })


def metadonnees_serveur(request):
    """RFC 8414 — ce que le serveur d'autorisation sait faire."""
    site = _site(request)
    return JsonResponse({
        "issuer": site,
        "authorization_endpoint": f"{site}{reverse('oauth_authorize')}",
        "token_endpoint": f"{site}{reverse('oauth_token')}",
        "registration_endpoint": f"{site}{reverse('oauth_register')}",
        "response_types_supported": ["code"],
        "grant_types_supported": ["authorization_code"],
        "code_challenge_methods_supported": ["S256"],
        "token_endpoint_auth_methods_supported": ["none"],
        "scopes_supported": [],
        # RFC 9207 : le retour porte `iss`.
        "authorization_response_iss_parameter_supported": True,
    })


# ── L'enregistrement (RFC 7591) ─────────────────────────────────────────────


def _erreur(code: str, description: str, statut: int = 400):
    reponse = JsonResponse({"error": code, "error_description": description}, status=statut)
    reponse["Cache-Control"] = "no-store"
    return reponse


@csrf_exempt
@require_http_methods(["POST"])
def enregistrer(request):
    """
    Un client se déclare et reçoit un `client_id`. Client PUBLIC : aucun
    secret n'est délivré (`token_endpoint_auth_method: none`).

    Exempt de CSRF : l'appel vient d'un serveur, sans cookie ni session ; il
    ne peut agir au nom de personne, il ne fait que se présenter.
    """
    if _https_manquant(request):
        return _erreur("invalid_request", "HTTPS requis.")
    try:
        demande = json.loads(request.body or b"{}")
    except (ValueError, UnicodeDecodeError):
        return _erreur("invalid_client_metadata", "Le corps doit être du JSON.")
    if not isinstance(demande, dict):
        return _erreur("invalid_client_metadata", "Le corps doit être un objet JSON.")

    retours = demande.get("redirect_uris")
    if not isinstance(retours, list) or not retours:
        return _erreur("invalid_redirect_uri", "redirect_uris est requis.")
    if len(retours) > RETOURS_PAR_CLIENT:
        return _erreur("invalid_redirect_uri", f"Au plus {RETOURS_PAR_CLIENT} adresses de retour.")
    refusees = [r for r in retours if not retour_admis(r)]
    if refusees:
        return _erreur("invalid_redirect_uri",
                       f"Adresse de retour non admise : {str(refusees[0])[:200]!r}. "
                       "Seuls l'application Claude et un retour local (Claude Code) "
                       "sont acceptés.")

    if demande.get("token_endpoint_auth_method", "none") != "none":
        return _erreur("invalid_client_metadata",
                       "Client public seulement : token_endpoint_auth_method doit "
                       "valoir « none » (le PKCE protège l'échange).")

    if hit("oauth:enregistrement", get_client_ip(request),
           ENREGISTREMENTS_PAR_IP_ET_PAR_HEURE, 3600):
        return _erreur("temporarily_unavailable",
                       "Trop d'enregistrements depuis cette adresse ; réessayez plus tard.", 429)

    maintenant = timezone.now()
    # Le ménage d'abord, pour que la borne compte ce qui vit vraiment.
    ClientOAuth.objects.filter(cree_le__lt=maintenant - VIE_D_UN_CLIENT_INUTILE,
                               codes__isnull=True).delete()
    if ClientOAuth.objects.filter(cree_le__gte=maintenant - timedelta(hours=1)).count() \
            >= ENREGISTREMENTS_PAR_HEURE:
        return _erreur("temporarily_unavailable",
                       "Trop d'enregistrements dans l'heure ; réessayez plus tard.", 429)

    client = ClientOAuth.objects.create(
        client_id=secrets.token_urlsafe(24),
        nom=str(demande.get("client_name") or "")[:120],
        adresses_de_retour=retours,
    )
    reponse = JsonResponse({
        "client_id": client.client_id,
        "client_id_issued_at": int(client.cree_le.timestamp()),
        "client_name": client.nom,
        "redirect_uris": client.adresses_de_retour,
        "grant_types": ["authorization_code"],
        "response_types": ["code"],
        "token_endpoint_auth_method": "none",
    }, status=201)
    reponse["Cache-Control"] = "no-store"
    return reponse


# ── L'autorisation ──────────────────────────────────────────────────────────


def agents_delegables():
    """
    Les agents au nom desquels un client peut agir : utilisables, et dont le
    compte n'a AUCUN statut d'administration.

    Un compte d'agent passé superutilisateur ou staff est écarté : le jeton
    vaudrait alors tous les droits du site, et « l'assistant agit avec le rôle
    de l'agent » ne tiendrait que par la façon dont les comptes ont été montés.
    """
    maintenant = timezone.now()
    return (Agent.objects.select_related("user")
            .filter(actif=True, user__is_active=True,
                    user__is_superuser=False, user__is_staff=False)
            .exclude(expire_le__lte=maintenant)
            .order_by("nom"))


def _page(request, contexte, statut=200):
    return render(request, "agents/oauth_autoriser.html", contexte, status=statut)


def _page_d_erreur(request, message: str, statut: int = 400):
    """
    Une erreur AVANT que l'adresse de retour soit établie s'affiche ici, et ne
    redirige pas : renvoyer vers une adresse non vérifiée ferait de cette page
    un redirecteur ouvert (RFC 6749 §4.1.2.1).
    """
    return _page(request, {"erreur": message}, statut)


def _retour(request, adresse: str, **parametres) -> HttpResponseRedirect:
    parametres["iss"] = _site(request)
    parametres = {k: v for k, v in parametres.items() if v not in (None, "")}
    separateur = "&" if urlsplit(adresse).query else "?"
    return HttpResponseRedirect(adresse + separateur + urlencode(parametres))


@never_cache
@require_http_methods(["GET", "POST"])
def autoriser(request):
    """
    La page de consentement.

    Un visiteur non connecté est renvoyé à la connexion AVEC LA REQUÊTE
    COMPLÈTE : on revient ici avec le client et le défi, sinon l'autorisation
    échouerait sans dire pourquoi.
    """
    if _https_manquant(request):
        return _page_d_erreur(request, "Cette page n'est servie qu'en HTTPS.")
    if not request.user.is_authenticated:
        return redirect_to_login(request.get_full_path())
    if hasattr(request.user, "agent"):
        # Un compte d'agent n'a pas de session, mais la règle se dit.
        return _page_d_erreur(request, "Un agent ne peut pas en autoriser un autre.", 403)

    p = request.POST if request.method == "POST" else request.GET
    client = ClientOAuth.objects.filter(client_id=p.get("client_id", "")).first()
    if client is None:
        return _page_d_erreur(request, "Client inconnu. Relancez la connexion depuis Claude.")
    adresse = p.get("redirect_uri", "")
    if not retour_enregistre(client, adresse):
        return _page_d_erreur(request, "Adresse de retour non enregistrée pour ce client.")

    # À partir d'ici, l'adresse est sûre : les erreurs y repartent.
    etat = p.get("state", "")
    if p.get("response_type") != "code":
        return _retour(request, adresse, error="unsupported_response_type", state=etat)
    defi = p.get("code_challenge", "")
    if p.get("code_challenge_method") != "S256" or not (43 <= len(defi) <= 128):
        return _retour(request, adresse, error="invalid_request", state=etat,
                       error_description="PKCE S256 requis.")
    demandee = p.get("resource", "")
    if demandee and not _meme_ressource(request, demandee):
        return _retour(request, adresse, error="invalid_target", state=etat)

    if not request.user.has_perm(PERM):
        return _page_d_erreur(
            request,
            "Votre compte ne peut pas autoriser un assistant : il faut le droit "
            "de gérer les agents (celui des comptes utilisateurs).", 403)

    agents = list(agents_delegables())
    contexte = {
        "client": client,
        "hote_de_retour": urlsplit(adresse).hostname,
        "retour_local": _est_loopback(adresse),
        "agents": agents,
        "url_agents": reverse("jeiko_agents_admin:liste"),
        "champs": {k: p.get(k, "") for k in (
            "client_id", "redirect_uri", "response_type", "state",
            "code_challenge", "code_challenge_method", "resource", "scope")},
    }
    if request.method == "GET":
        return _page(request, contexte)

    if p.get("decision") != "autoriser":
        return _retour(request, adresse, error="access_denied", state=etat)
    agent = next((a for a in agents if str(a.pk) == p.get("agent")), None)
    if agent is None:
        contexte["erreur_agent"] = "Choisissez l'agent au nom duquel l'assistant agira."
        return _page(request, contexte, 400)

    code = secrets.token_urlsafe(32)
    CodeOAuth.objects.create(
        empreinte_code=jetons.empreinte(code), client=client, agent=agent,
        autorise_par=request.user, adresse_de_retour=adresse,
        defi_pkce=defi, ressource=demandee[:300])
    return _retour(request, adresse, code=code, state=etat)


# ── Le jeton ────────────────────────────────────────────────────────────────


def verifier_pkce(verificateur: str, defi: str) -> bool:
    """RFC 7636 §4.6 : BASE64URL(SHA256(verificateur)) == défi."""
    if not (43 <= len(verificateur) <= 128):
        return False
    calcule = base64.urlsafe_b64encode(
        hashlib.sha256(verificateur.encode("ascii", "replace")).digest()
    ).rstrip(b"=").decode("ascii")
    return secrets.compare_digest(calcule, defi)


@csrf_exempt
@require_http_methods(["POST"])
def jeton(request):
    """
    Échange un code contre un jeton de l'agent choisi.

    Un code ne sert qu'UNE fois : verrouillé et consommé dans la transaction.
    Présenté de nouveau, il révoque le jeton qu'il a déjà donné — un code
    rejoué est un code volé, et le jeton qu'il a produit l'est peut-être aussi.
    """
    if _https_manquant(request):
        return _erreur("invalid_request", "HTTPS requis.")
    p = request.POST
    if p.get("grant_type") != "authorization_code":
        return _erreur("unsupported_grant_type", "Seul authorization_code est pris en charge.")
    code_clair = p.get("code", "")
    if not code_clair:
        return _erreur("invalid_request", "code manquant.")

    # TOUT L'ÉCHANGE DANS UNE TRANSACTION, verrou pris sur le code. Le jeton est
    # rattaché au code avant que le verrou tombe : un rejeu concurrent attend,
    # puis trouve le jeton et le révoque. Un `return` dans le bloc VALIDE la
    # transaction : le code consommé le reste, même quand l'échange est refusé.
    with transaction.atomic():
        code = (CodeOAuth.objects.select_for_update()
                .select_related("client", "agent")
                .filter(empreinte_code=jetons.empreinte(code_clair)).first())
        if code is None:
            return _erreur("invalid_grant", "Code inconnu.")
        if code.utilise_le is not None:
            if code.jeton_id:
                AgentToken.objects.filter(pk=code.jeton_id, revoque_le__isnull=True
                                          ).update(revoque_le=timezone.now())
            return _erreur("invalid_grant", "Code déjà utilisé.")
        # Consommé AVANT toute autre vérification : un code essayé avec un
        # mauvais vérificateur ne doit pas pouvoir être retenté.
        code.utilise_le = timezone.now()
        code.save(update_fields=["utilise_le"])

        if code.utilise_le - code.cree_le > DUREE_DU_CODE:
            return _erreur("invalid_grant", "Code expiré.")
        if p.get("client_id", "") != code.client.client_id:
            return _erreur("invalid_grant", "Ce code n'a pas été délivré à ce client.")
        if p.get("redirect_uri", "") != code.adresse_de_retour:
            return _erreur("invalid_grant", "redirect_uri différente de l'autorisation.")
        if not verifier_pkce(p.get("code_verifier", ""), code.defi_pkce):
            return _erreur("invalid_grant", "Vérificateur PKCE invalide.")
        demandee = p.get("resource", "")
        if demandee and not _meme_ressource(request, demandee):
            return _erreur("invalid_target", "Ressource inconnue.")
        if not agents_delegables().filter(pk=code.agent_id).exists():
            # L'agent a pu être désactivé ou promu entre la page et l'échange.
            return _erreur("invalid_grant", "Cet agent n'est plus utilisable.")

        nom = code.client.nom or "client OAuth"
        objet, clair = AgentToken.creer(
            code.agent, libelle=f"OAuth — {nom}"[:150], cree_par=code.autorise_par)
        code.jeton = objet
        code.save(update_fields=["jeton"])

    reponse = JsonResponse({"access_token": clair, "token_type": "Bearer"})
    # RFC 6749 §5.1 : une réponse qui porte un jeton ne se met pas en cache.
    reponse["Cache-Control"] = "no-store"
    reponse["Pragma"] = "no-cache"
    return reponse
