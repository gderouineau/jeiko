"""
Le site en plusieurs langues — la langue que LIT le visiteur.

Le besoin
---------
Un site JEIKO s'écrivait dans une seule langue. Un exploitant qui reçoit des
demandes de l'étranger veut la même page en anglais, à une adresse que Google
range avec les pages anglaises. C'est une option du site (Réglages › Langues du
site) : désactivée, rien de ce module n'agit et le site se comporte comme
avant.

Les règles, telles qu'elles ont été arrêtées
--------------------------------------------
* **La langue d'origine n'a pas de préfixe.** `/nos-tarifs/` reste
  `/nos-tarifs/` : aucune adresse existante ne change, donc aucun référencement
  perdu. Seules les langues ajoutées vivent sous `/en/`, `/es/`…
* **Une page par langue.** La version anglaise est une `Page` à part entière,
  reliée à l'originale par `traduction_de`. L'éditeur l'ouvre comme n'importe
  quelle page ; il n'a rien à savoir des langues.
* **Un lien suit le lecteur.** Menus, pieds de page et boutons désignent une
  page, pas une adresse : sur une page anglaise, le lien mène à la version
  anglaise de sa cible, directement — pas de redirection en chaîne.
* **Une page non traduite s'affiche quand même**, dans la langue d'origine,
  sous le préfixe du lecteur (`/en/nos-tarifs/`) : il garde son menu, son pied
  de page et son lien « accueil » en anglais. Elle déclare l'originale comme
  adresse de référence (`canonical`) et n'entre ni au plan du site ni dans les
  `hreflang` — Google n'y voit pas un doublon.
* **Une fiche, un produit : comme une page.** Une version par langue
  (`CustomObject.langue`, `traduction_de`), créée par duplication, brouillon,
  publiée à part ; `/en/shop/…` et `/en/co/…` servent la version anglaise, ou
  la fiche d'origine tant qu'elle n'est pas traduite. Le produit, lui, est
  unique : un prix, un stock, une référence, quelle que soit la langue. Toutes
  les fonctions de ce module valent pour une page comme pour une fiche.
* **Hors des pages et des fiches** (panier, compte, rendez-vous…), pas de
  préfixe : la langue du visiteur est retenue dans un cookie, posé par la
  dernière page qu'il a lue — ou par son choix sur l'écran « Langues »
  (`/lang/`), que le pied de page propose partout.

Ce que ce module ne fait PAS
----------------------------
* Il ne traduit rien. Les textes s'écrivent à la main, version par version.
* Il ne regarde jamais le navigateur (`Accept-Language`) : rediriger un
  visiteur selon sa langue supposée est déconseillé par Google, et empêche de
  lire la version qu'on a demandée.
* Il ne s'applique pas aux écrans d'administration ni à l'API : là,
  `langue_du_site()` vaut `None` et chaque page donne son adresse propre.
"""

from contextvars import ContextVar

from django.conf import settings

#: Le premier segment de l'écran « Langues » (`/lang/`), où le visiteur choisit
#: sa langue. Réservé ICI et non dans les réglages du projet : la route vient
#: avec le paquet, sa réservation aussi — un site mis à jour n'a rien à
#: déclarer pour qu'une page ne vienne pas s'y loger.
SEGMENT_DES_LANGUES = "lang"

#: La langue que lit le visiteur de la requête en cours ("" = langue
#: d'origine), ou `None` hors du site public. Un `ContextVar` et non un
#: attribut de requête : `Page.get_absolute_url()` est appelée depuis des
#: gabarits et des modèles qui n'ont pas la requête sous la main.
_langue = ContextVar("jeiko_langue_du_site", default=None)

#: Les versions publiées dans la langue du visiteur, chargées une fois par
#: requête, par modèle (pages, fiches) : {(modèle, langue): {id de l'originale:
#: version}}. Sans elle, chaque lien d'un menu coûterait sa requête.
_versions = ContextVar("jeiko_versions_du_site", default=None)

#: Les langues actives, lues UNE fois par requête par le middleware. Une page
#: les demande une demi-douzaine de fois (préfixe, pages publiques, cache,
#: sélecteur, hreflang) : sans ce relais, autant de lectures du cache du site.
#: `None` hors d'une requête : on relit alors à chaque appel.
_actives = ContextVar("jeiko_langues_actives", default=None)


def langue_d_origine():
    """Le code de la langue dans laquelle le site est écrit (« fr »)."""
    return settings.LANGUAGE_CODE.split("-")[0].lower()


def codes_proposes():
    """Les langues qu'un site peut ajouter : celles du projet, sauf l'origine."""
    return [c for c, _ in getattr(settings, "LANGUAGES", []) if c != langue_d_origine()]


def langues_actives():
    """
    Les langues ajoutées au site, dans l'ordre du projet ; vide si l'option
    est désactivée. Lu sur `WebSite`, déjà en cache : aucune requête.
    """
    retenues = _actives.get()
    if retenues is not None:
        return list(retenues)
    return _lire_les_langues_actives()


def _lire_les_langues_actives():
    from jeiko.administration.website_cache import get_website_data

    site = get_website_data()
    if site is None or not getattr(site, "multilingue", False):
        return []
    choisies = set(getattr(site, "langues_du_site", None) or [])
    return [c for c in codes_proposes() if c in choisies]


def retenir_les_langues_actives():
    """
    Lit les langues actives pour la durée de la requête. Rend le jeton à
    passer à `oublier_les_langues_actives` — appelé par le middleware.
    """
    return _actives.set(tuple(_lire_les_langues_actives()))


def oublier_les_langues_actives(jeton=None):
    """
    Fin de requête (avec le jeton), ou réglage qui vient de changer (sans) :
    la suite de la requête doit voir les nouvelles langues, pas les anciennes.
    """
    if jeton is not None:
        _actives.reset(jeton)
    else:
        _actives.set(None)


def nom_de_la_langue(code):
    """« English » pour « en » — le nom que la langue se donne."""
    return dict(getattr(settings, "LANGUAGES", [])).get(code or langue_d_origine(), code)


def est_un_slug_reserve(slug):
    """
    Un slug qu'une page ou une catégorie de premier niveau ne peut pas porter.

    Les routes du système, l'écran « Langues » et les codes de langue : `/en/`
    désigne l'accueil anglais, une page nommée « en » serait inatteignable le
    jour où la langue s'active. Réservés même quand l'option est éteinte —
    sinon l'activer dépendrait de ce que le site a publié entre-temps.
    """
    if not slug:
        return False
    slug = slug.lower()
    reserves = getattr(settings, "JEIKO_RESERVED_ROOT_SLUGS", set())
    return (
        slug in reserves
        or slug == SEGMENT_DES_LANGUES
        or slug in {c for c, _ in getattr(settings, "LANGUAGES", [])}
    )


# --------------------------------------------------------------------------
# La langue de la requête
# --------------------------------------------------------------------------

def langue_du_site():
    """La langue du visiteur ("" = origine), ou `None` hors du site public."""
    return _langue.get()


def fixer_la_langue(code):
    """Pose la langue du visiteur. Rend le jeton à passer à `oublier_la_langue`."""
    _versions.set(None)
    return _langue.set(code)


def oublier_la_langue(jeton):
    _langue.reset(jeton)
    _versions.set(None)


def prefixe_de_langue(chemin):
    """
    ("en", "/pricing/") pour "/en/pricing/" si « en » est une langue active ;
    ("", chemin) sinon.
    """
    segments = chemin.split("/", 2)
    # « /en//ailleurs.example/ » donnerait « //ailleurs.example/ » : une
    # adresse que le navigateur lit comme un AUTRE site. Ce n'est pas un
    # préfixe de langue, on n'y touche pas.
    if (len(segments) >= 3 and segments[1] in langues_actives()
            and not segments[2].startswith("/")):
        return segments[1], "/" + segments[2]
    return "", chemin


def accueil():
    """
    L'adresse de la page d'accueil pour qui lit : « / », ou « /en/ ».

    À écrire partout où un gabarit ou une vue renvoie « à l'accueil » — le
    logo, « Retour à l'accueil », la redirection après connexion. Écrire
    « / » en dur ramène le visiteur anglais sur le site français, et lui fait
    perdre sa langue au premier clic.
    """
    from django.urls import NoReverseMatch, reverse

    # `reverse` et non « / » : un site servi dans un sous-chemin garde le sien.
    try:
        racine = reverse("jeiko_pages:root_page")
    except NoReverseMatch:
        racine = "/"
    langue = langue_du_site()
    return f"{racine}{langue}/" if langue else racine


# --------------------------------------------------------------------------
# L'adresse d'un lien
# --------------------------------------------------------------------------

def _versions_publiees(modele, langue):
    """
    {id de l'originale: version publiée dans `langue`}, pour un modèle (`Page`,
    `CustomObject`) — une requête par modèle, par langue et par requête HTTP.

    Chaque modèle dit lui-même ce que « publiée » veut dire et ce qu'il faut
    charger pour écrire une adresse : `modele.versions_publiees(langue)`.
    """
    connues = _versions.get()
    if connues is None:
        connues = {}
        _versions.set(connues)
    cle = (modele, langue)
    if cle not in connues:
        # ponytail: toutes les versions publiées d'une langue en une requête —
        # juste pour des centaines de fiches ; au-delà, charger à la demande.
        connues[cle] = {v.traduction_de_id: v for v in modele.versions_publiees(langue)}
    return connues[cle]


def version_publiee(page, langue):
    """La version publiée de `page` — ou d'une fiche — dans `langue`, ou `None`."""
    if page.langue == langue:
        return page
    origine = page.origine
    if not langue:
        return origine if origine.est_publiee else None
    return _versions_publiees(type(origine), langue).get(origine.pk)


def version_lue(page):
    """
    Ce que lit le visiteur à la place de `page` : sa version publiée dans sa
    langue, sinon `page` elle-même. Hors du site public, `page`.

    Pour ce qui AFFICHE une page ou une fiche sans en être la vue — une
    grille, une ligne de panier, le titre d'un produit.
    """
    langue = langue_du_site()
    if not langue:
        return page
    return version_publiee(page, langue) or page


def adresse_dans(page, langue):
    """
    L'adresse où un lecteur de `langue` lit `page` (ou une fiche). Trois cas,
    dans l'ordre :

      1. la page est déjà dans sa langue → son adresse propre ;
      2. elle a une version publiée dans sa langue → l'adresse de cette version ;
      3. elle n'en a pas → l'originale, servie sous le préfixe du lecteur. Un
         lecteur de la langue d'origine qui suit un lien vers une page qui
         n'existe qu'en traduction reçoit l'adresse de cette traduction : il
         n'y a rien d'autre à lui montrer.
    """
    if langue == page.langue or not page.pk:
        return page.adresse_propre()
    version = version_publiee(page, langue)
    if version is not None:
        return version.adresse_propre()
    if not langue:
        return page.adresse_propre()
    return page.origine._adresse(langue)


def adresse_pour_le_visiteur(page):
    """
    L'adresse à écrire dans un lien vers `page` — voir `Page.get_absolute_url`.
    Hors du site public (administration, API), personne ne lit : son adresse propre.
    """
    langue = langue_du_site()
    if langue is None:
        return page.adresse_propre()
    return adresse_dans(page, langue)
