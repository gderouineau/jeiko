from django import forms

from .models import PaymentGateway
from django.utils.translation import gettext_lazy as _

#: Clés qui ne doivent jamais repartir vers le navigateur.
CHAMPS_SECRETS = ("secret_key", "webhook_secret")


class PaymentGatewayForm(forms.ModelForm):
    """
    Les deux clés secrètes étaient rendues avec `PasswordInput(render_value=True)` :
    le masque n'est que visuel, la valeur partait en clair dans l'attribut
    `value` du HTML. Une fois la clé enregistrée, on ne la renvoie plus — un
    champ laissé vide conserve la valeur en base.
    """

    class Meta:
        model = PaymentGateway
        fields = [
            'name', 'code', 'is_active',
            'api_key', 'secret_key', 'webhook_secret',
            'test_mode',
        ]
        widgets = {
            'secret_key': forms.PasswordInput(render_value=False),
            'webhook_secret': forms.PasswordInput(render_value=False),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        deja_enregistre = bool(self.instance and self.instance.pk)
        for nom in CHAMPS_SECRETS:
            champ = self.fields[nom]
            champ.required = False
            if deja_enregistre and getattr(self.instance, nom, ""):
                champ.help_text = _(
                    "Une clé est enregistrée. Laisser vide pour la conserver, "
                    "ou saisir la nouvelle pour la remplacer."
                )
            else:
                champ.help_text = _("Aucune clé enregistrée pour le moment.")

    def _conserver_si_vide(self, nom):
        valeur = (self.cleaned_data.get(nom) or "").strip()
        if valeur:
            return valeur
        # Champ laissé vide : on garde ce qui est en base plutôt que de
        # l'effacer par inadvertance.
        return getattr(self.instance, nom, "") if self.instance.pk else ""

    def clean_secret_key(self):
        return self._conserver_si_vide("secret_key")

    def clean_webhook_secret(self):
        return self._conserver_si_vide("webhook_secret")


class CoordonneesForm(forms.Form):
    """
    Coordonnées de la commande : facturation, livraison, note.

    Rien ne les demandait : la commande partait sans adresse, et le port ne
    pouvait donc pas se calculer (Fable 1, §3.5). La livraison n'est demandée
    que pour un panier qui contient un article à expédier ; sans « livrer à
    une autre adresse », elle reprend la facturation.
    """

    billing_name = forms.CharField(label=_("Nom complet"), max_length=200)
    billing_address = forms.CharField(
        label=_("Adresse"), widget=forms.Textarea(attrs={"rows": 2}), max_length=500,
    )
    billing_postal_code = forms.CharField(label=_("Code postal"), max_length=20)
    billing_city = forms.CharField(label=_("Ville"), max_length=120)
    billing_country = forms.ChoiceField(label=_("Pays"))
    billing_phone = forms.CharField(label=_("Téléphone"), max_length=40, required=False)

    ship_elsewhere = forms.BooleanField(label=_("Livrer à une autre adresse"), required=False)
    shipping_name = forms.CharField(label=_("Nom complet"), max_length=200, required=False)
    shipping_address = forms.CharField(
        label=_("Adresse"), widget=forms.Textarea(attrs={"rows": 2}),
        max_length=500, required=False,
    )
    shipping_postal_code = forms.CharField(label=_("Code postal"), max_length=20, required=False)
    shipping_city = forms.CharField(label=_("Ville"), max_length=120, required=False)
    shipping_country = forms.ChoiceField(label=_("Pays"), required=False)

    customer_note = forms.CharField(
        label=_("Note pour la commande"), required=False, max_length=1000,
        widget=forms.Textarea(attrs={"rows": 3}),
        help_text=_("Une précision pour la livraison, par exemple."),
    )

    # Pour un visiteur sans compte : le compte se crée ici (users/compte_acheteur.py).
    email = forms.EmailField(label=_("Adresse e-mail"), max_length=254)
    password = forms.CharField(
        label=_("Choisissez un mot de passe"), strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password"}),
        help_text=_("Votre compte client se crée avec la commande : vous y retrouverez commandes, factures et achats."),
    )
    #: Leurre anti-robot, comme à l'inscription (users/throttling.py).
    company = forms.CharField(required=False, label="", widget=forms.TextInput(
        attrs={"autocomplete": "off", "tabindex": "-1", "aria-hidden": "true", "class": "jk-leurre"}))

    CHAMPS_LIVRAISON = ("name", "address", "postal_code", "city", "country")

    def __init__(self, *args, expedition=False, avec_compte=False, **kwargs):
        from jeiko.shop.livraison import TOUS_LES_PAYS, pays_livrables

        super().__init__(*args, **kwargs)
        self.expedition = expedition
        self.avec_compte = avec_compte
        if not avec_compte:
            for nom in ("email", "password", "company"):
                del self.fields[nom]
        self.fields["billing_country"].choices = [(c, c) for c in TOUS_LES_PAYS]
        livrables = [(c, c) for c in pays_livrables()]
        self.fields["shipping_country"].choices = [("", "—")] + livrables
        if not expedition:
            for nom in list(self.fields):
                if nom.startswith("shipping_") or nom == "ship_elsewhere":
                    del self.fields[nom]

    def clean_email(self):
        from jeiko.users.compte_acheteur import adresse_deja_prise

        email = self.cleaned_data["email"].strip()
        if adresse_deja_prise(email):
            raise forms.ValidationError(
                _("Un compte existe déjà avec cette adresse : connectez-vous pour commander."),
                code="compte_existant",
            )
        return email

    def clean_password(self):
        from django.contrib.auth.password_validation import validate_password

        mot_de_passe = self.cleaned_data["password"]
        validate_password(mot_de_passe)
        return mot_de_passe

    def clean(self):
        data = super().clean()
        if not self.expedition:
            return data
        if data.get("ship_elsewhere"):
            for suffixe in self.CHAMPS_LIVRAISON:
                if not data.get(f"shipping_{suffixe}"):
                    self.add_error(f"shipping_{suffixe}", _("Ce champ est obligatoire."))
        else:
            for suffixe in self.CHAMPS_LIVRAISON:
                data[f"shipping_{suffixe}"] = data.get(f"billing_{suffixe}", "")
        return data
