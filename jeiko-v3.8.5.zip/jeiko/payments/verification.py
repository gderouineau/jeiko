# jeiko/payments/verification.py
"""
Un paiement ne règle une commande que s'il en a le montant (Fable 1, §1.4).

Le webhook et le retour navigateur marquaient la commande payée dès qu'une
intention Stripe réussie la désignait dans ses métadonnées — sans comparer ce
qui avait été encaissé à ce qui était dû. Or la préparation du paiement
réécrit la commande à chaque appel : panier à 10 €, intention n° 1 ; ajout
d'articles pour 110 €, commande réécrite ; le client règle l'intention n° 1,
encore valide. Commande de 110 € payée 10 €, accès accordés, stock
décrémenté.

`payments/reconcile.py` et `calendars/payments.py` faisaient déjà ce
contrôle ; les deux chemins de paiement des commandes, non. Ils passent
désormais tous deux par `ecart_de_paiement`.

Ce que ça ne fait pas : rembourser. Un paiement non conforme reste encaissé
chez Stripe ; l'exploitant est alerté et tranche (remboursement ou
régularisation).
"""

import logging

from jeiko.shop.services import to_minor_units

logger = logging.getLogger(__name__)


def _lire(intent, cle):
    try:
        return intent.get(cle)
    except AttributeError:
        return getattr(intent, cle, None)


def ecart_de_paiement(order, intent):
    """`None` si l'intention règle exactement la commande, sinon la raison."""
    identifiant = _lire(intent, "id") or ""
    if order.payment_intent_id and identifiant != order.payment_intent_id:
        return (f"intention {identifiant} ≠ intention en cours de la commande "
                f"({order.payment_intent_id}) : paiement d'une version périmée")

    devise = str(_lire(intent, "currency") or "").lower()
    if devise and devise != str(order.currency or "").lower():
        return f"devise encaissée {devise} ≠ devise de la commande {order.currency}"

    attendu = to_minor_units(order.total_ttc, order.currency)
    encaisse = int(_lire(intent, "amount_received") or 0)
    if encaisse != attendu:
        return (f"encaissé {encaisse} ≠ dû {attendu} (unités mineures, "
                f"{order.currency} {order.total_ttc})")
    return None


def signaler_paiement_non_conforme(order, intent, ecart, source):
    """Journalise et alerte l'exploitant ; ne lève jamais."""
    identifiant = _lire(intent, "id") or "?"
    logger.error("Paiement %s NON appliqué à la commande #%s (%s) : %s",
                 identifiant, order.pk, source, ecart)
    try:
        from jeiko.emailing.admin_alerts import notifier_erreur

        notifier_erreur(
            "Paiement non conforme à la commande",
            f"Le paiement {identifiant} désigne la commande #{order.pk} mais ne la "
            f"règle pas : {ecart}. La commande n'a PAS été marquée payée ; aucun "
            f"accès n'a été accordé. À vérifier dans Stripe (remboursement ou "
            f"régularisation).",
        )
    except Exception:
        logger.exception("Alerte de paiement non conforme impossible")
