from django import template

from .. import state

register = template.Library()


@register.simple_tag
def boutique_en_ligne():
    """Expose l'état de la boutique aux gabarits publics (bouton « panier »)."""
    return state.shop_is_online()


@register.simple_tag
def panier_au_menu():
    """Vrai si le menu du site montre l'icône du panier — voir `state.panier_au_menu`."""
    return state.panier_au_menu()


@register.simple_tag
def prix_affiche(produit):
    """
    Le prix d'un produit tel que la boutique l'affiche : TTC ou HT selon
    `ShopSettings.display_prices_including_tax` — même règle que la fiche
    produit (`shop/views/client.py`), pour qu'une carte de grille ne montre
    pas un autre prix que la page où elle mène.
    """
    from ..models import ShopSettings

    if ShopSettings.get_solo().display_prices_including_tax:
        return produit.price_ttc
    return produit.price_ht
