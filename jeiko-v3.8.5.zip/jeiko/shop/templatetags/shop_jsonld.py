# shop/templatetags/shop_jsonld.py
import json
from decimal import Decimal, ROUND_HALF_UP

from django import template
from django.utils.safestring import mark_safe

from jeiko.templatetags.json_extras import JSON_SCRIPT_ESCAPES

register = template.Library()


def _abs_url(request, url, site_url=None):
    """URL absolue à partir d'une URL relative (même logique que site_identity_tags)."""
    if not url:
        return None
    if url.startswith("http://") or url.startswith("https://"):
        return url
    if request:
        return request.build_absolute_uri(url)
    if site_url:
        return f"{site_url.rstrip('/')}/{url.lstrip('/')}"
    return url


def _price_str(value):
    """Prix normalisé à 2 décimales, sans symbole (format attendu par schema.org)."""
    if value is None:
        return None
    try:
        return str(Decimal(value).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
    except (ArithmeticError, TypeError, ValueError):
        return None


@register.simple_tag(takes_context=True)
def product_jsonld(context, product):
    """
    Le JSON-LD schema.org d'une fiche produit : `Product` + `Offer`, ou
    `ProductGroup` et ses déclinaisons ; note et avis, livraison, retours
    quand la boutique les déclare. Le contenu vient de `shop.lisible`, qui
    nourrit aussi le flux Google et le catalogue JSON : les trois ne peuvent
    pas se contredire.

    Retourne "" si le produit est absent ou n'a pas de prix exploitable.
    """
    if not product or _price_str(getattr(product, "price_ttc", None)) is None:
        return ""

    from jeiko.shop.lisible import base_url, donnees_produit, jsonld

    request = context.get("request")
    # URL canonique absolue de la fiche. Lue sous /en/ sans y être traduite,
    # la page déclare l'adresse d'origine comme référence (`canonical_url`) :
    # le JSON-LD dit la même, pas celle du préfixe.
    try:
        path = product.get_absolute_url()
    except Exception:
        path = None
    url_abs = context.get("canonical_url") or (_abs_url(request, path) if path else None)

    data = jsonld(donnees_produit(product, url_abs, base_url(request) if request else ""))

    # Inséré tel quel dans un <script type="application/ld+json">
    # (includes/product_jsonld.html). `json.dumps` n'échappe ni `<`, ni `>`,
    # ni `&` : un titre de produit ou un nom de marque contenant `</script>`
    # refermait le bloc et faisait exécuter la suite. Même table que `tojson`,
    # importée plutôt que recopiée.
    json_str = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return mark_safe(json_str.translate(JSON_SCRIPT_ESCAPES))
