import logging

from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db import transaction
from django.db.models import Q
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse_lazy
from django.utils.translation import gettext as _
from django.views import View
from django.views.generic import ListView, TemplateView, UpdateView

from ..forms import OrderAdminForm, RemboursementForm
from ..models import Order
from ..remboursement import RemboursementImpossible, rembourser
from ..services import mark_order_paid

logger = logging.getLogger(__name__)


class OrderListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    # Ces deux vues n'avaient qu'un contrôle de connexion : tout compte
    # authentifié — un simple client — pouvait lister les commandes du site et
    # modifier leurs statuts et adresses par l'URL. Le menu, lui, les gardait
    # déjà par `shop.view_order`.
    permission_required = "shop.view_order"

    model = Order
    template_name = 'shop/admin/order_list.html'
    context_object_name = 'orders'
    paginate_by = 20

    def get_queryset(self):
        queryset = super().get_queryset()
        order_status = self.request.GET.get('order_status')
        payment_status = self.request.GET.get('payment_status')
        search = self.request.GET.get('search')

        if order_status:
            queryset = queryset.filter(order_status=order_status)

        if payment_status:
            queryset = queryset.filter(payment_status=payment_status)

        if search:
            queryset = queryset.filter(
                Q(pk__icontains=search) |
                Q(invoice_number__icontains=search) |
                Q(user__email__icontains=search) |
                Q(billing_name__icontains=search)
            )

        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['order_status_choices'] = Order.ORDER_STATUS_CHOICES
        context['payment_status_choices'] = Order.PAYMENT_STATUS_CHOICES
        return context


class OrderUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    permission_required = "shop.change_order"

    model = Order
    form_class = OrderAdminForm
    template_name = 'shop/admin/order_form.html'
    success_url = reverse_lazy('jeiko_shop_admin_orders:order_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['lines'] = self.object.lines.select_related("product", "product__type")
        context['refunds'] = self.object.refunds.select_related("created_by")
        context['refund_form'] = kwargs.get('refund_form') or RemboursementForm(
            initial={'amount': self.object.amount_refundable}
        )
        context['peut_rembourser'] = self.object.payment_status in (
            Order.PAYMENT_STATUS_PAID, Order.PAYMENT_STATUS_PARTIALLY_REFUNDED,
        )
        return context

    def form_valid(self, form):
        """
        Prévient le client quand le statut change réellement.

        On compare aux valeurs d'avant enregistrement : sans cela, corriger une
        adresse de facturation renverrait un avis d'expédition. L'envoi part
        après COMMIT, pour ne rien annoncer qu'un échec effacerait.
        """
        precedent = Order.objects.get(pk=self.object.pk)
        avant = (precedent.order_status, precedent.payment_status)

        # Payée à la main (virement reçu) : le même règlement qu'un paiement
        # par carte. Poser le statut sans plus laissait la commande sans
        # accès ouverts, sans stock décompté et sans confirmation.
        regler = (form.cleaned_data.get("payment_status") == Order.PAYMENT_STATUS_PAID
                  and precedent.payment_status != Order.PAYMENT_STATUS_PAID)
        if regler:
            form.instance.payment_status = precedent.payment_status

        reponse = super().form_valid(form)
        if regler:
            mark_order_paid(self.object, source=f"admin:{self.request.user.pk}")
            self.object.refresh_from_db()
            avant = (self.object.order_status, self.object.payment_status)

        apres = (self.object.order_status, self.object.payment_status)
        if avant != apres:
            transaction.on_commit(
                lambda pk=self.object.pk, a=avant: _notifier_changement(pk, a)
            )
        return reponse


def _notifier_changement(order_id, avant):
    """
    Traduit une transition de statut en e-mail. Ne lève jamais.

    Le remboursement n'est plus un statut qu'on choisit ici : son e-mail part
    de `shop.remboursement`, avec le montant réellement rendu.
    """
    from ..emailing import (
        send_order_cancelled_email,
        send_order_completed_email,
        send_order_shipped_email,
    )

    try:
        order = (
            Order.objects.select_related("user").prefetch_related("lines").get(pk=order_id)
        )
    except Order.DoesNotExist:
        return

    statut_avant, __ = avant

    try:
        if order.order_status == statut_avant:
            return

        if order.order_status == Order.ORDER_STATUS_SHIPPED:
            send_order_shipped_email(order)
        elif order.order_status == Order.ORDER_STATUS_COMPLETED:
            send_order_completed_email(order)
        elif order.order_status == Order.ORDER_STATUS_CANCELLED:
            send_order_cancelled_email(order)
    except Exception:
        logger.exception(
            "E-mail de changement de statut impossible (commande #%s)", order_id
        )


class OrderRefundView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Le bouton « Rembourser » de la fiche commande.

    Les quantités à remettre en stock arrivent en `restock_<id de ligne>`.
    """

    permission_required = "shop.change_order"

    def post(self, request, pk):
        order = get_object_or_404(Order, pk=pk)
        form = RemboursementForm(request.POST)
        if not form.is_valid():
            vue = OrderUpdateView()
            vue.setup(request, pk=pk)
            vue.object = order
            return vue.render_to_response(vue.get_context_data(
                form=OrderAdminForm(instance=order), refund_form=form,
            ))
        remise = {
            cle.removeprefix("restock_"): valeur
            for cle, valeur in request.POST.items()
            if cle.startswith("restock_") and valeur.strip().isdigit()
        }
        try:
            rembourser(
                order, form.cleaned_data["amount"], motif=form.cleaned_data["reason"],
                remise_en_stock=remise, par=request.user,
                hors_ligne=form.cleaned_data["hors_ligne"],
            )
        except RemboursementImpossible as exc:
            messages.error(request, str(exc))
        else:
            messages.success(request, _("Remboursement enregistré ; le client est prévenu."))
        return redirect("jeiko_shop_admin_orders:order_update", pk=pk)


PAYEES = (Order.PAYMENT_STATUS_PAID, Order.PAYMENT_STATUS_PARTIALLY_REFUNDED,
          Order.PAYMENT_STATUS_REFUNDED)


def _periode(request, defaut_jours=30):
    """(début, fin) depuis ?debut=AAAA-MM-JJ&fin=…, ou les `defaut_jours` derniers jours."""
    from datetime import datetime, time, timedelta

    from django.utils import timezone

    def lire(nom):
        try:
            return datetime.strptime(request.GET.get(nom, ""), "%Y-%m-%d").date()
        except ValueError:
            return None

    fin = lire("fin") or timezone.localdate()
    debut = lire("debut") or fin - timedelta(days=defaut_jours - 1)
    tz = timezone.get_current_timezone()
    return (debut, fin, timezone.make_aware(datetime.combine(debut, time.min), tz),
            timezone.make_aware(datetime.combine(fin, time.max), tz))


def _nombre(valeur):
    """Montant au format d'un tableur français : virgule décimale."""
    return f"{valeur:.2f}".replace(".", ",")


class OrderExportView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Les commandes réglées d'une période, en CSV pour le comptable.

    Une ligne par commande, avec la ventilation de la TVA par taux en
    colonnes — ce que réclame une saisie comptable. Séparateur « ; », virgule
    décimale et marque d'ordre UTF-8 : le fichier s'ouvre tel quel dans Excel
    en français.
    """

    permission_required = "shop.view_order"

    def get(self, request):
        import csv

        from django.http import HttpResponse

        from ..facturation import ventilation_de

        debut, fin, apres, avant = _periode(request)
        commandes = list(
            Order.objects.filter(payment_status__in=PAYEES, created_at__range=(apres, avant))
            .select_related("user").prefetch_related("refunds", "lines").order_by("created_at", "id")
        )
        ventilations = {o.pk: ventilation_de(o) for o in commandes}
        taux = sorted({t for v in ventilations.values() for t in v})

        reponse = HttpResponse(content_type="text/csv; charset=utf-8")
        reponse["Content-Disposition"] = f'attachment; filename="commandes-{debut}-{fin}.csv"'
        reponse.write("\ufeff")
        ecrit = csv.writer(reponse, delimiter=";")
        ecrit.writerow(
            ["Date", "Commande", "Facture", "Client", "E-mail", "Pays", "Statut",
             "Paiement", "Code promo", "Remise TTC", "Port TTC", "Total HT", "TVA",
             "Total TTC", "Remboursé", "Devise"]
            + [f"{c} {t.normalize():f} %".replace(".", ",") for t in taux for c in ("Base HT", "TVA")]
        )
        for o in commandes:
            v = ventilations[o.pk]
            ecrit.writerow(
                [o.created_at.strftime("%d/%m/%Y"), o.pk, o.invoice_number, o.billing_name,
                 getattr(o.user, "email", ""), o.billing_country, o.get_order_status_display(),
                 o.get_payment_status_display(), o.coupon_code, _nombre(o.discount_ttc),
                 _nombre(o.shipping_ttc), _nombre(o.total_ht), _nombre(o.total_tva),
                 _nombre(o.total_ttc), _nombre(o.amount_refunded), o.currency]
                + [_nombre(v[t][c]) if t in v else "" for t in taux for c in ("ht", "tva")]
            )
        return reponse


class SalesDashboardView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    """Les ventes d'une période : chiffre d'affaires, panier moyen, meilleurs produits."""

    permission_required = "shop.view_order"
    template_name = "shop/admin/sales_dashboard.html"

    def get_context_data(self, **kwargs):
        from django.db.models import Count, F, Sum
        from django.db.models.functions import TruncMonth

        from ..models import OrderLine, OrderRefund

        contexte = super().get_context_data(**kwargs)
        debut, fin, apres, avant = _periode(self.request, int(self.request.GET.get("jours") or 30))
        payees = Order.objects.filter(payment_status__in=PAYEES, created_at__range=(apres, avant))
        totaux = payees.aggregate(ttc=Sum("total_ttc"), ht=Sum("total_ht"), nombre=Count("id"))
        rembourse = OrderRefund.objects.filter(
            created_at__range=(apres, avant)).aggregate(s=Sum("amount"))["s"] or 0
        nombre = totaux["nombre"] or 0
        contexte.update({
            "debut": debut, "fin": fin,
            "ca_ttc": totaux["ttc"] or 0, "ca_ht": totaux["ht"] or 0,
            "nombre": nombre,
            "panier_moyen": (totaux["ttc"] or 0) / nombre if nombre else 0,
            "rembourse": rembourse,
            "en_attente": Order.objects.filter(
                payment_status=Order.PAYMENT_STATUS_PAID,
                order_status__in=(Order.ORDER_STATUS_CONFIRMED, Order.ORDER_STATUS_PROCESSING),
            ).count(),
            "meilleurs": (
                OrderLine.objects.filter(order__in=payees)
                .values("sku", "label")
                .annotate(quantite=Sum("quantity"),
                          ca_ht=Sum(F("quantity") * F("unit_price_ht")))
                .order_by("-quantite")[:10]
            ),
            "par_mois": (
                payees.annotate(mois=TruncMonth("created_at")).values("mois")
                .annotate(ttc=Sum("total_ttc"), nombre=Count("id")).order_by("mois")
            ),
            "stock_bas": _stock_bas(),
        })
        return contexte


def _stock_bas():
    """Les produits expédiés sous leur seuil d'alerte, ou épuisés."""
    from django.db.models import F, Q

    from ..models import Product, ProductVariant

    produits = list(
        Product.objects.filter(is_active=True, type__requires_shipping=True, variants__isnull=True)
        .filter(Q(stock_quantity__lte=F("stock_alert_threshold")) | Q(stock_quantity__lte=0))
        .select_related("content")[:20]
    )
    declinaisons = list(
        ProductVariant.objects.filter(is_active=True, product__is_active=True,
                                      product__type__requires_shipping=True)
        .filter(Q(stock_quantity__lte=F("product__stock_alert_threshold")) | Q(stock_quantity__lte=0))
        .select_related("product", "product__content")[:20]
    )
    return [(p.sku, p.content.title, p.stock_quantity) for p in produits] + [
        (v.sku, f"{v.product.content.title} — {v.label}", v.stock_quantity) for v in declinaisons
    ]


class ManualOrderView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Saisir une commande pour un client : vente par téléphone, sur un salon.

    Le même chemin qu'une commande en ligne — un panier, puis
    `preparer_commande` —, donc le même port, le même stock et la même TVA.
    La commande naît « en attente » ; « Payée » sur sa fiche la règle quand le
    virement arrive (accès, stock, confirmation, facture).
    """

    permission_required = "shop.add_order"
    template_name = "shop/admin/order_manual.html"

    def _rendre(self, request, client, lignes, coordonnees):
        from django.shortcuts import render

        return render(request, self.template_name, {
            "client_form": client, "lignes": lignes, "coordonnees": coordonnees,
        })

    def get(self, request):
        from jeiko.payments.forms import CoordonneesForm

        from ..forms import CommandeManuelleForm, LignesManuellesFormSet

        return self._rendre(request, CommandeManuelleForm(), LignesManuellesFormSet(prefix="lignes"),
                            CoordonneesForm(expedition=True, initial={"billing_country": "FR"}))

    def post(self, request):
        from jeiko.payments.forms import CoordonneesForm

        from ..models import Cart, CartItem, Product, ProductVariant
        from ..services import CommandeImpossible, preparer_commande
        from ..forms import CommandeManuelleForm, LignesManuellesFormSet

        client = CommandeManuelleForm(request.POST)
        lignes = LignesManuellesFormSet(request.POST, prefix="lignes")
        coordonnees = CoordonneesForm(request.POST, expedition=True)
        if not (client.is_valid() and lignes.is_valid() and coordonnees.is_valid()):
            return self._rendre(request, client, lignes, coordonnees)

        articles = []
        for f in lignes:
            sku = (f.cleaned_data.get("sku") or "").strip()
            if not sku:
                continue
            variante = ProductVariant.objects.select_related("product").filter(sku=sku).first()
            produit = variante.product if variante else Product.objects.filter(sku=sku).first()
            if produit is None:
                f.add_error("sku", _("Référence inconnue."))
                return self._rendre(request, client, lignes, coordonnees)
            articles.append((produit, variante, f.cleaned_data.get("quantity") or 1))
        if not articles:
            coordonnees.add_error(None, _("Ajoutez au moins un article."))
            return self._rendre(request, client, lignes, coordonnees)

        try:
            with transaction.atomic():
                panier = Cart.objects.create(user=client.compte)
                for produit, variante, quantite in articles:
                    CartItem.objects.create(
                        cart=panier, product=produit, variant=variante, quantity=quantite,
                        unit_price_ht=variante.prix_ht if variante else produit.price_ht,
                        tax_rate=produit.tax_rate, currency=produit.currency,
                    )
                order = preparer_commande(client.compte, panier, coordonnees.cleaned_data)
                # Le panier a servi de brouillon : il ne doit pas réapparaître
                # dans la session du client.
                panier.is_locked = True
                panier.save(update_fields=["is_locked"])
        except CommandeImpossible as exc:
            coordonnees.add_error(None, str(exc))
            return self._rendre(request, client, lignes, coordonnees)

        messages.success(request, _("Commande créée, en attente de paiement. Passez-la en « Payée » à réception du règlement."))
        return redirect("jeiko_shop_admin_orders:order_update", pk=order.pk)
