"""
Le catalogue : trier les produits, proposer des produits associés, compter
les avis.

Ce que les grilles (`templatetags/dynamic_resources.py`), la fiche produit et
le JSON-LD partagent. Un seul calcul de la note moyenne, par exemple : la
fiche qui affiche 4,5 étoiles et le JSON-LD qui en annonce 4,3 à Google, c'est
précisément le genre d'écart qui fait retirer les étoiles des résultats.
"""

from decimal import Decimal

from django.db.models import Avg, Count, DecimalField, ExpressionWrapper, F, Q, Sum

from .models import Order, Product, ProductReview

PAYEES = (Order.PAYMENT_STATUS_PAID, Order.PAYMENT_STATUS_PARTIALLY_REFUNDED)


def produits_en_vente():
    return Product.objects.filter(is_active=True, content__is_published=True)


def trier(qs, ordre):
    """Applique l'ordre d'une grille à un queryset de produits."""
    if ordre in ("price_asc", "price_desc"):
        qs = qs.annotate(_prix_ttc=ExpressionWrapper(
            F("price_ht") * (1 + F("tax_rate") / Decimal("100")),
            output_field=DecimalField(max_digits=14, decimal_places=4)))
        return qs.order_by("_prix_ttc" if ordre == "price_asc" else "-_prix_ttc", "-id")
    if ordre == "best_sellers":
        qs = qs.annotate(_ventes=Sum(
            "order_lines__quantity", filter=Q(order_lines__order__payment_status__in=PAYEES)))
        return qs.order_by(F("_ventes").desc(nulls_last=True), "-id")
    if ordre == "name":
        return qs.order_by("content__title", "id")
    if ordre == "oldest":
        return qs.order_by("id")
    return qs.order_by("-id")


def associes(produit, nombre=4):
    """
    « Vous aimerez aussi » : les produits associés à la main ; à défaut, ceux
    des mêmes catégories ; à défaut, ceux du même type.
    """
    base = produits_en_vente().exclude(pk=produit.pk).select_related("type", "content")
    choisis = list(base.filter(pk__in=produit.related_products.values("pk"))[:nombre])
    if choisis:
        return choisis
    categories = list(produit.categories.values_list("pk", flat=True))
    if categories:
        proches = list(trier(base.filter(categories__in=categories).distinct(), "best_sellers")[:nombre])
        if proches:
            return proches
    return list(trier(base.filter(type_id=produit.type_id), "best_sellers")[:nombre])


def note(produit):
    """`(moyenne arrondie au dixième, nombre)` des avis publiés, ou `(None, 0)`."""
    stats = ProductReview.objects.filter(product=produit, is_approved=True).aggregate(
        moyenne=Avg("rating"), nombre=Count("id"))
    if not stats["nombre"]:
        return None, 0
    return round(Decimal(stats["moyenne"]), 1), stats["nombre"]


def a_achete(user, produit):
    """Le client a-t-il une commande payée contenant ce produit ?"""
    if not getattr(user, "is_authenticated", False):
        return False
    return Order.objects.filter(
        user=user, payment_status__in=PAYEES, lines__product=produit,
    ).exists()
