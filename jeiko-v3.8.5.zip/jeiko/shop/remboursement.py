"""
Rembourser une commande, en tout ou en partie.

Avant ce module, « remboursée » était un statut que l'exploitant posait à la
main : rien ne partait chez Stripe, et le client recevait quand même l'e-mail
de remboursement. À l'inverse, un remboursement fait depuis le tableau de bord
Stripe ne touchait jamais la commande, restée « payée » (rapport Fable 1,
§3.6).

Deux entrées, une seule écriture :

* `rembourser` — le bouton de la fiche de commande. Rembourse chez Stripe
  (ou enregistre un remboursement fait hors ligne, pour une commande réglée
  par virement), remet en stock ce qu'on lui dit, prévient le client ;
* `rembourser_depuis_stripe` — le webhook `charge.refunded`. Stripe donne le
  cumul remboursé sur le paiement ; on enregistre la différence avec ce que
  la commande connaît déjà, ce qui rend l'appel idempotent et fait que le
  webhook qui suit un remboursement du site n'en crée pas un second.

Les deux verrouillent la commande : le webhook peut arriver pendant que le
bouton attend encore la réponse de Stripe.

Ce que le module ne fait pas : rembourser au-delà de ce qui a été encaissé,
ni annuler la commande — rembourser et annuler restent deux gestes.
"""

import logging
from decimal import Decimal

from django.db import transaction
from django.utils.translation import gettext as _

from .models import Order, OrderRefund, ProductStockMovement
from .services import ZERO_DECIMAL_CURRENCIES, to_minor_units, to_money

logger = logging.getLogger(__name__)


class RemboursementImpossible(Exception):
    """Message destiné à l'exploitant."""


def _depuis_unites_mineures(montant, devise):
    if (devise or "").lower() in ZERO_DECIMAL_CURRENCIES:
        return to_money(montant)
    return to_money(Decimal(montant) / 100)


def _statut(order):
    """Statut de paiement déduit des remboursements enregistrés."""
    rembourse = order.amount_refunded
    if rembourse <= 0:
        return Order.PAYMENT_STATUS_PAID
    if rembourse >= order.total_ttc:
        return Order.PAYMENT_STATUS_REFUNDED
    return Order.PAYMENT_STATUS_PARTIALLY_REFUNDED


def _remettre_en_stock(order, remise_en_stock, par):
    """`remise_en_stock` : {id de ligne: quantité}. Retourne True si un article est rentré."""
    rentre = False
    for ligne in order.lines.select_related("product", "product__type", "variant"):
        demande = int(remise_en_stock.get(ligne.pk) or remise_en_stock.get(str(ligne.pk)) or 0)
        quantite = min(max(demande, 0), ligne.quantity - ligne.restocked_quantity)
        produit = ligne.product
        if quantite <= 0 or produit is None or not produit.suit_le_stock:
            continue
        stocke = ligne.variant or produit
        stocke.stock_quantity += quantite
        stocke.save(update_fields=["stock_quantity"])
        ligne.restocked_quantity += quantite
        ligne.save(update_fields=["restocked_quantity"])
        ProductStockMovement.objects.create(
            product=produit, variant=ligne.variant, movement_type=ProductStockMovement.IN,
            quantity=quantite, reason=f"Remboursement commande #{order.pk}", user=par,
        )
        rentre = True
    return rentre


def _enregistrer(order, montant, **champs):
    from .facturation import numeroter_avoir

    remboursement = OrderRefund.objects.create(order=order, amount=montant, **champs)
    numeroter_avoir(remboursement)
    order.payment_status = _statut(order)
    order.save(update_fields=["payment_status", "updated_at"])
    transaction.on_commit(lambda: _prevenir(order.pk, montant))
    return remboursement


def _prevenir(order_id, montant):
    try:
        from .emailing import send_order_refunded_email

        send_order_refunded_email(Order.objects.select_related("user").get(pk=order_id), montant)
    except Exception:
        logger.exception("E-mail de remboursement impossible (commande #%s)", order_id)


@transaction.atomic
def rembourser(order, montant, *, motif="", remise_en_stock=None, par=None, hors_ligne=False):
    """
    Rembourse `montant` (TTC) sur la commande. Retourne l'`OrderRefund` créé.

    `hors_ligne=True` enregistre un remboursement fait par un autre moyen
    (virement…) sans rien demander à Stripe.
    """
    order = Order.objects.select_for_update().get(pk=order.pk)
    if order.payment_status not in (Order.PAYMENT_STATUS_PAID, Order.PAYMENT_STATUS_PARTIALLY_REFUNDED):
        raise RemboursementImpossible(_("Seule une commande payée peut être remboursée."))

    try:
        montant = to_money(montant)
    except Exception:
        raise RemboursementImpossible(_("Montant invalide."))
    if montant <= 0:
        raise RemboursementImpossible(_("Le montant doit être supérieur à zéro."))
    if montant > order.amount_refundable:
        raise RemboursementImpossible(
            _("Il reste au plus %(reste)s %(devise)s à rembourser.")
            % {"reste": order.amount_refundable, "devise": order.currency}
        )

    refund_id = ""
    if not hors_ligne:
        if not order.payment_intent_id:
            raise RemboursementImpossible(
                _("Cette commande n'a pas été réglée par Stripe : enregistrez un remboursement hors ligne.")
            )
        refund_id = _rembourser_chez_stripe(order, montant)

    rentre = _remettre_en_stock(order, remise_en_stock or {}, par)
    return _enregistrer(
        order, montant, reason=(motif or "")[:255], restocked=rentre, created_by=par,
        stripe_refund_id=refund_id,
        source=OrderRefund.SOURCE_HORS_LIGNE if hors_ligne else OrderRefund.SOURCE_STRIPE_SITE,
    )


def _rembourser_chez_stripe(order, montant):
    import stripe

    from jeiko.payments.models import PaymentGateway

    passerelle = PaymentGateway.objects.filter(code="stripe", is_active=True).first()
    if not passerelle or not passerelle.secret_key:
        raise RemboursementImpossible(_("Stripe n'est pas configuré : remboursement en ligne indisponible."))
    stripe.api_key = passerelle.secret_key
    try:
        refund = stripe.Refund.create(
            payment_intent=order.payment_intent_id,
            amount=to_minor_units(montant, order.currency),
            metadata={"jeiko_order_id": str(order.pk)},
        )
    except Exception:
        logger.exception("Remboursement Stripe refusé (commande #%s)", order.pk)
        raise RemboursementImpossible(_("Stripe a refusé le remboursement ; rien n'a été enregistré."))
    return refund.get("id", "") if hasattr(refund, "get") else getattr(refund, "id", "")


@transaction.atomic
def rembourser_depuis_stripe(charge):
    """Répercute un `charge.refunded` sur la commande payée par cette intention."""
    intent_id = charge.get("payment_intent")
    if not intent_id:
        return None
    order = Order.objects.select_for_update().filter(payment_intent_id=intent_id).first()
    if order is None or order.payment_status not in (
        Order.PAYMENT_STATUS_PAID, Order.PAYMENT_STATUS_PARTIALLY_REFUNDED,
    ):
        return None

    cumul = _depuis_unites_mineures(charge.get("amount_refunded") or 0, order.currency)
    ecart = to_money(cumul - order.amount_refunded)
    if ecart <= 0:
        return None
    logger.info("Remboursement Stripe de %s répercuté sur la commande #%s", ecart, order.pk)
    return _enregistrer(
        order, ecart, source=OrderRefund.SOURCE_STRIPE_DASHBOARD,
        stripe_refund_id=charge.get("id") or "",
        reason=_("Remboursé depuis le tableau de bord Stripe"),
    )
