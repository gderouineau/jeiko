"""
La boutique lisible par les machines : moteurs, comparateurs, assistants.

Une boutique se vend aujourd'hui autant dans les résultats enrichis de Google,
Google Shopping et les réponses des assistants (ChatGPT, Claude, Perplexity)
que sur ses propres pages. Ces lecteurs ne regardent pas la page : ils lisent
des données structurées. Ce module les produit, une seule fois, pour quatre
sorties :

* le JSON-LD de la fiche (`templatetags/shop_jsonld.py`) ;
* le flux Google Merchant (`/shop/flux/google.xml`) ;
* le catalogue JSON (`/shop/catalogue.json`), pour les agents ;
* la section boutique de `/llms.txt`.

Les quatre partagent `donnees_produit`, si bien qu'un prix, une
disponibilité ou une note ne peuvent pas différer d'une sortie à l'autre —
l'écart que Google sanctionne en retirant les étoiles ou l'offre.

Ce qu'on n'y met pas : rien que la page ne montre pas. Pas d'avis non
publiés, pas de politique de retour que l'exploitant n'a pas déclarée, pas de
GTIN inventé.
"""

from decimal import Decimal

from .models import ShopSettings

DISPO = {True: "https://schema.org/InStock", False: "https://schema.org/OutOfStock"}


def _prix(valeur):
    return f"{Decimal(valeur or 0):.2f}"


def base_url(request=None):
    if request is not None:
        return request.build_absolute_uri("/").rstrip("/")
    from jeiko.emailing.render import site_base_url

    return (site_base_url() or "").rstrip("/")


def absolu(base, chemin):
    if not chemin:
        return None
    if chemin.startswith(("http://", "https://")):
        return chemin
    return f"{base}{chemin}" if base else chemin


def url_image(image):
    for champ in ("full_size", "computer_size", "original_image"):
        fichier = getattr(image, champ, None) if image else None
        if fichier and getattr(fichier, "name", None):
            try:
                return fichier.url
            except ValueError:
                continue
    return None


def _vendeur():
    from jeiko.administration.website_cache import get_website_data

    site = get_website_data()
    identite = getattr(site, "identity", None) if site else None
    return (getattr(identite, "name", None) or getattr(site, "website_name", None) or ""), identite


def _livraison(produit, reglages):
    """Les zones de livraison, en `OfferShippingDetails` — produits expédiés seulement."""
    if not getattr(produit.type, "requires_shipping", False):
        return []
    details = []
    for zone in reglages.delivery_zones.filter(is_active=True):
        pays = [c.strip().upper() for c in zone.country_codes.replace(";", ",").split(",")
                if c.strip() and c.strip() != "*"]
        if not pays:
            continue
        details.append({
            "@type": "OfferShippingDetails",
            "shippingRate": {"@type": "MonetaryAmount", "value": _prix(zone.price_ttc),
                             "currency": reglages.currency},
            "shippingDestination": [{"@type": "DefinedRegion", "addressCountry": c} for c in pays],
        })
    return details


def _retours(reglages, identite):
    if not reglages.return_days:
        return None
    return {
        "@type": "MerchantReturnPolicy",
        "applicableCountry": (getattr(identite, "address_country", "") or "FR").upper(),
        "returnPolicyCategory": "https://schema.org/MerchantReturnFiniteReturnWindow",
        "merchantReturnDays": reglages.return_days,
        "returnMethod": "https://schema.org/ReturnByMail",
    }


def donnees_produit(produit, url, base):
    """
    Tout ce qu'un lecteur automatique doit savoir d'un produit, en un dict :
    identité, prix TTC, disponibilité, déclinaisons, note, livraison, retours.
    """
    from . import catalogue

    reglages = ShopSettings.get_solo()
    marque, identite = _vendeur()
    note, nombre = catalogue.note(produit) if reglages.reviews_enabled else (None, 0)
    return {
        "produit": produit,
        "url": url,
        "titre": produit.title,
        "description": str(produit.description or ""),
        "image": absolu(base, url_image(produit.main_image)),
        "sku": produit.sku,
        "gtin": produit.gtin,
        "marque": produit.brand or marque,
        "vendeur": marque,
        "devise": produit.currency or reglages.currency,
        "prix_ttc": produit.price_ttc,
        "disponible": produit.est_disponible,
        "categories": [c.name for c in produit.categories.all()],
        "declinaisons": [
            {"sku": v.sku, "libelle": v.label, "prix_ttc": v.price_ttc,
             "disponible": v.est_disponible, "gtin": ""}
            for v in produit.variantes_actives
        ],
        "note": note,
        "nombre_avis": nombre,
        "avis": list(produit.reviews.filter(is_approved=True)[:5]) if nombre else [],
        "livraison": _livraison(produit, reglages),
        "retours": _retours(reglages, identite),
    }


def _offre(d, prix, disponible, sku=None):
    offre = {
        "@type": "Offer",
        "price": _prix(prix),
        "priceCurrency": d["devise"],
        "availability": DISPO[bool(disponible)],
        "itemCondition": "https://schema.org/NewCondition",
    }
    if sku:
        offre["sku"] = sku
    if d["url"]:
        offre["url"] = d["url"]
    if d["vendeur"]:
        offre["seller"] = {"@type": "Organization", "name": d["vendeur"]}
    if d["livraison"]:
        offre["shippingDetails"] = d["livraison"]
    if d["retours"]:
        offre["hasMerchantReturnPolicy"] = d["retours"]
    return offre


def jsonld(d):
    """Le JSON-LD schema.org : `Product`, ou `ProductGroup` avec ses déclinaisons."""
    commun = {"name": d["titre"]}
    if d["description"]:
        commun["description"] = d["description"]
    if d["image"]:
        commun["image"] = [d["image"]]
    if d["marque"]:
        commun["brand"] = {"@type": "Brand", "name": d["marque"]}
    if d["categories"]:
        commun["category"] = " > ".join(d["categories"][:3])
    if d["nombre_avis"]:
        commun["aggregateRating"] = {
            "@type": "AggregateRating", "ratingValue": str(d["note"]),
            "reviewCount": d["nombre_avis"], "bestRating": "5", "worstRating": "1",
        }
        commun["review"] = [
            {"@type": "Review",
             "reviewRating": {"@type": "Rating", "ratingValue": str(a.rating), "bestRating": "5"},
             "author": {"@type": "Person", "name": a.author_name},
             "datePublished": a.created_at.date().isoformat(),
             **({"name": a.title} if a.title else {}),
             **({"reviewBody": a.body} if a.body else {})}
            for a in d["avis"]
        ]

    if d["declinaisons"]:
        donnees = {
            "@context": "https://schema.org", "@type": "ProductGroup",
            "productGroupID": d["sku"], **commun,
            "hasVariant": [
                {"@type": "Product", "name": f"{d['titre']} — {v['libelle']}", "sku": v["sku"],
                 "offers": _offre(d, v["prix_ttc"], v["disponible"], v["sku"])}
                for v in d["declinaisons"]
            ],
        }
    else:
        donnees = {
            "@context": "https://schema.org", "@type": "Product", **commun,
            "sku": d["sku"],
            "offers": _offre(d, d["prix_ttc"], d["disponible"]),
        }
        if d["gtin"]:
            donnees["gtin"] = d["gtin"]
    if d["url"]:
        donnees["@id"] = f"{d['url']}#product"
        donnees["url"] = d["url"]
    return donnees


def produits_publics():
    """Les produits que le site montre : en vente, fiche publiée."""
    from .catalogue import produits_en_vente

    return (produits_en_vente()
            .select_related("type", "content", "content__metadata", "content__main_image")
            .prefetch_related("variants", "categories")
            .order_by("type__name", "content__title"))
