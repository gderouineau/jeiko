"""
Règlement d'une commande : ce qui se passe une fois le paiement encaissé.

Cette logique existait en double — dans `PaymentCheckView` (retour navigateur)
et dans le dispatcher webhook — et les deux versions divergeaient : seul le
retour navigateur accordait les accès. Comme le webhook était par ailleurs
injoignable (route masquée par la fiche produit), une commande dont le client
fermait l'onglet n'était jamais honorée.

Les deux chemins appellent désormais `mark_order_paid`, qui est idempotent :
peu importe lequel arrive en premier, ou que les deux arrivent.
"""

import logging
from decimal import ROUND_HALF_UP, Decimal

from django.db import transaction

from django.utils.translation import gettext as _

from . import promotions
from .models import Order, OrderLine, Product, ProductStockMovement

logger = logging.getLogger(__name__)

CENTS = Decimal("0.01")


def to_money(value):
    """Arrondit un montant au centime (ROUND_HALF_UP, comme une facture)."""
    return Decimal(value or 0).quantize(CENTS, rounding=ROUND_HALF_UP)


ZERO_DECIMAL_CURRENCIES = {
    "bif", "clp", "djf", "gnf", "jpy", "kmf", "krw", "mga",
    "pyg", "rwf", "ugx", "vnd", "vuv", "xaf", "xof", "xpf",
}


def to_minor_units(amount, currency="EUR"):
    """
    Convertit un montant en plus petite unité monétaire, pour Stripe.

    `int(amount * 100)` tronquait : un prix TTC calculé par multiplication
    (prix HT × taux) tombe régulièrement sur 19.9999… et partait à 1999 au
    lieu de 2000. On arrondit d'abord au centime, sauf pour les devises sans
    décimales comme le JPY.
    """
    if (currency or "").lower() in ZERO_DECIMAL_CURRENCIES:
        return int(to_money(amount))
    return int(to_money(amount) * 100)


def compute_order_totals(items):
    """
    Totaux HT / TVA / TTC pour un itérable de lignes (panier ou commande).

    `total_tva` n'était jamais renseigné sur Order : la commande partait avec
    une TVA à 0, ce qui fausse toute reprise comptable.
    """
    total_ht = to_money(sum((item.total_ht for item in items), Decimal("0")))
    total_ttc = to_money(sum((item.total_ttc for item in items), Decimal("0")))
    return total_ht, to_money(total_ttc - total_ht), total_ttc


class CommandeImpossible(Exception):
    """La commande ne peut pas être préparée ; le message s'adresse au client."""


def rafraichir_les_prix(cart):
    """
    Remet chaque ligne du panier au prix et au taux actuels du produit.

    Le prix n'était relu qu'à l'ajout au panier : une ligne dont on changeait
    seulement la quantité gardait l'ancien prix, et c'est lui qu'on facturait
    (Fable 1, §3.7). Appelé à l'affichage du panier et à la préparation de la
    commande. Retourne les lignes dont le prix a bougé.
    """
    changees = []
    for item in cart.items.select_related("product", "variant"):
        produit = item.product
        if (item.unit_price_ht, item.tax_rate) != (item.prix_ht_actuel, produit.tax_rate):
            item.unit_price_ht = item.prix_ht_actuel
            item.tax_rate = produit.tax_rate
            item.save(update_fields=["unit_price_ht", "tax_rate"])
            changees.append(item)
    return changees


#: Les champs d'adresse qu'accepte `preparer_commande`.
CHAMPS_ADRESSE = (
    "billing_name", "billing_address", "billing_postal_code", "billing_city",
    "billing_country", "billing_phone",
    "shipping_name", "shipping_address", "shipping_postal_code",
    "shipping_city", "shipping_country", "customer_note",
)


@transaction.atomic
def preparer_commande(user, cart, adresses=None):
    """
    Crée ou remet à jour la commande brouillon d'un panier, prête à payer.

    Le seul endroit où se calcule ce que le client va payer : prix actuels
    (§3.7), disponibilité (§3.4), frais de port de l'adresse (§3.5). L'écran
    de paiement et la création de l'intention Stripe l'appellent tous deux,
    si bien que le montant affiché est celui demandé à Stripe.

    `adresses` — un dict de `CHAMPS_ADRESSE` — remplace les coordonnées de la
    commande ; absent, on garde celles déjà enregistrées.

    Lève `CommandeImpossible` (panier vide, commande déjà réglée, article
    épuisé, adresse hors zone de livraison).
    """
    from .livraison import LivraisonImpossible, frais_de_port, panier_a_expedier
    from .models import Cart, ShopSettings

    # Verrou de ligne : deux préparations simultanées — double clic, onglet
    # rejoué — créaient deux intentions de paiement pour la même commande.
    Cart.objects.select_for_update().get(pk=cart.pk)

    rafraichir_les_prix(cart)
    items = list(cart.items.select_related(
        "product", "product__type", "product__content", "variant",
    ).prefetch_related("product__variants"))
    if not items:
        raise CommandeImpossible(_("Votre panier est vide."))

    for item in items:
        # Ligne posée avant que le produit ait des déclinaisons : on ne sait
        # pas laquelle expédier.
        if item.variant_id is None and item.product.variantes_actives:
            raise CommandeImpossible(
                _("Choisissez une option pour « %(title)s » : retirez-le du panier et ajoutez-le depuis sa fiche.")
                % {"title": item.product.title}
            )
        if item.variant_id and not item.variant.is_active:
            raise CommandeImpossible(
                _("« %(title)s — %(option)s » n'est plus en vente.")
                % {"title": item.product.title, "option": item.variant.label}
            )
        if not item.peut_servir():
            raise CommandeImpossible(
                _("« %(title)s » n'est plus disponible en quantité suffisante.")
                % {"title": item.product.title}
            )

    order, __ = Order.objects.get_or_create(
        cart=cart,
        defaults={
            "user": user,
            "currency": ShopSettings.get_solo().currency,
        },
    )
    if order.payment_status in (Order.PAYMENT_STATUS_PAID, *Order.PAYMENT_STATUSES_REMBOURSEMENT):
        raise CommandeImpossible(_("Cette commande a déjà été réglée."))
    # Brouillon laissé par l'ancien parcours invité, ou panier repris à la
    # connexion : la commande doit suivre le compte.
    order.user = user

    for champ in CHAMPS_ADRESSE if adresses is not None else ():
        setattr(order, champ, (adresses.get(champ) or "").strip())

    expedition = panier_a_expedier(items)
    if not expedition:
        for champ in ("shipping_name", "shipping_address", "shipping_postal_code",
                      "shipping_city", "shipping_country"):
            setattr(order, champ, "")
    # Le code promo du panier, revérifié : il a pu expirer ou s'épuiser
    # depuis qu'on l'a saisi. Le panier le retire en le disant
    # (`CartDetailView`) ; ici on refuse simplement de facturer sans lui.
    coupon = cart.coupon
    if coupon is not None:
        try:
            promotions.verifier(coupon, user, items)
        except promotions.CodeInvalide as exc:
            raise CommandeImpossible(str(exc))
    remise_ttc, remise_tva = promotions.remise(coupon, items)

    total_ht, total_tva, total_ttc = compute_order_totals(items)
    try:
        port_ttc, port_tva, libelle = frais_de_port(
            items, order.shipping_country, order.shipping_postal_code,
            total_articles=total_ttc - remise_ttc,
        )
    except LivraisonImpossible as exc:
        raise CommandeImpossible(str(exc))
    if promotions.livraison_offerte(coupon):
        port_ttc = port_tva = Decimal("0.00")

    order.coupon = coupon
    order.coupon_code = coupon.code if coupon else ""
    order.discount_ttc, order.discount_tva = remise_ttc, remise_tva
    order.shipping_ttc, order.shipping_tva, order.shipping_method = port_ttc, port_tva, libelle

    # Les totaux viennent de la TVA ventilée par taux — celle que la facture
    # imprime : le total de la facture et celui de la commande ne peuvent pas
    # diverger d'un centime.
    from .facturation import en_json, ventiler
    from .livraison import a_expedier

    ventilation = ventiler(
        items, promotions.repartir(coupon, items, remise_ttc), port_ttc,
        [i for i in items if a_expedier(i)], ShopSettings.get_solo().default_tax_rate,
    )
    order.vat_breakdown = en_json(ventilation)
    order.total_ttc = to_money(total_ttc - remise_ttc + port_ttc)
    order.total_tva = to_money(sum((m["tva"] for m in ventilation.values()), Decimal("0")))
    order.total_ht = to_money(order.total_ttc - order.total_tva)
    order.save()

    # Les lignes suivent le panier : on les réécrit à chaque préparation.
    order.lines.all().delete()
    OrderLine.objects.bulk_create(
        OrderLine(
            order=order,
            product=item.product,
            variant=item.variant,
            label=f"{item.sku} - {item.product.content.title}"
                  + (f" — {item.variant.label}" if item.variant_id else ""),
            sku=item.sku,
            quantity=item.quantity,
            unit_price_ht=item.unit_price_ht,
            tax_rate=item.tax_rate,
        )
        for item in items
    )
    return order


@transaction.atomic
def mark_order_paid(order, *, source="unknown"):
    """
    Passe la commande en payée et honore son contenu. Idempotent.

    Retourne True si c'est cet appel qui a réglé la commande, False si elle
    l'était déjà (webhook et retour navigateur arrivent tous les deux).
    """
    # verrou de ligne : le webhook et le retour navigateur peuvent tomber en
    # même temps, et tous deux accordent des accès.
    order = Order.objects.select_for_update().get(pk=order.pk)

    if order.payment_status == Order.PAYMENT_STATUS_PAID:
        return False

    order.payment_status = Order.PAYMENT_STATUS_PAID
    order.order_status = Order.ORDER_STATUS_CONFIRMED
    order.save(update_fields=["payment_status", "order_status", "updated_at"])

    lines = list(order.lines.select_related("product", "product__type").all())

    _grant_access(order, lines)
    _consume_stock(order, lines)

    # Le numéro de facture se prend au règlement, dans cette transaction :
    # une commande jamais payée n'en consomme aucun, la suite reste sans trou.
    from .facturation import numeroter_facture

    numeroter_facture(order)

    if order.cart and not order.cart.is_locked:
        order.cart.is_locked = True
        order.cart.save(update_fields=["is_locked", "updated_at"])

    # Confirmation + reçu au client, notification à l'exploitant. Après COMMIT :
    # une transaction annulée ne doit pas laisser derrière elle l'annonce d'une
    # commande qui n'existe pas. `mark_order_paid` étant idempotent, l'envoi
    # n'a lieu qu'une fois, quel que soit celui du webhook ou du retour
    # navigateur qui arrive en premier.
    transaction.on_commit(lambda pk=order.pk: _notify_order_paid(pk))

    logger.info("Commande #%s réglée (source=%s).", order.pk, source)
    return True


def _notify_order_paid(order_id):
    """Envoi des e-mails de règlement. Ne lève jamais."""
    try:
        from .emailing import send_order_paid_emails

        send_order_paid_emails(
            Order.objects.select_related("user").prefetch_related("lines").get(
                pk=order_id
            )
        )
    except Exception:
        logger.exception(
            "E-mails de règlement impossibles pour la commande #%s", order_id
        )


def _grant_access(order, lines):
    """Ouvre les accès achetés : questionnaires et formations."""
    if not order.user_id:
        # Ne devrait plus arriver : le tunnel de commande exige un compte
        # (`CheckoutView` / `CreatePaymentIntentView`). Ce cas correspondait à
        # un achat invité, où Stripe encaissait, la commande passait en payée,
        # le stock était décrémenté — et rien n'était délivré, sans la moindre
        # trace. On journalise donc en erreur plutôt que de sortir en silence :
        # une commande réglée sans destinataire doit se voir.
        rattachables = [
            l.sku for l in lines
            if l.product and (l.product.linked_course_id
                              or l.product.linked_expert_test_id)
        ]
        if rattachables:
            logger.error(
                "Commande #%s réglée sans compte : les accès %s n'ont pas pu "
                "être accordés. À rattacher à la main.",
                order.pk, ", ".join(rattachables),
            )
        return

    from jeiko.courses.models import CourseEnrollment
    from jeiko.questionnaires_expert.models import UserTestAccess

    for line in lines:
        product = line.product
        if product is None:
            continue

        if product.linked_expert_test_id:
            UserTestAccess.objects.get_or_create(
                user=order.user,
                test_id=product.linked_expert_test_id,
                defaults={"source": "PURCHASE"},
            )

        if product.linked_course_id:
            CourseEnrollment.objects.get_or_create(
                user=order.user,
                course_id=product.linked_course_id,
                defaults={
                    "status": CourseEnrollment.STATUS_ACTIVE,
                    "has_payed": True,
                    "order": order,
                    "granted_by": None,  # accordé par l'achat, pas par un admin
                },
            )


def _consume_stock(order, lines):
    """
    Décrémente le stock des produits qui en tiennent un.

    Le stock n'était jamais décrémenté et ProductStockMovement n'était écrit
    nulle part : le compteur affiché sur la fiche ne bougeait pas après un
    achat.

    Les produits sont verrouillés le temps du décrément (Fable 1, §3.4) : deux
    paiements simultanés du dernier exemplaire lisaient le même stock. La
    disponibilité est contrôlée avant de payer (`preparer_commande`) ; si le
    stock a fondu entre-temps, l'argent est déjà encaissé — on décrémente
    quand même, et l'exploitant est alerté de la survente plutôt que de la
    découvrir à l'emballage.
    """
    from .models import ProductVariant

    ids = sorted({l.product_id for l in lines if l.product_id})
    # Dans l'ordre des clés : deux commandes qui se croisent ne s'interbloquent pas.
    verrouilles = {p.pk: p for p in Product.objects.select_for_update().select_related("type").filter(pk__in=ids).order_by("pk")}
    ids_v = sorted({l.variant_id for l in lines if l.variant_id})
    declinaisons = {v.pk: v for v in ProductVariant.objects.select_for_update().filter(pk__in=ids_v).order_by("pk")}
    survendus = []
    for line in lines:
        product = verrouilles.get(line.product_id)
        if product is None:
            continue
        variante = declinaisons.get(line.variant_id)

        # Seuls les produits à expédier consomment du stock ; une formation ou
        # un questionnaire est reproductible à l'infini.
        #
        # `suit_le_stock` porte cette règle pour tout le monde — panier,
        # JSON-LD, alertes. On l'appelle plutôt que de relire `requires_shipping`
        # ici : c'est la divergence entre ce test et celui du panier qui avait
        # rendu tout service invendable.
        if not product.suit_le_stock:
            continue

        stocke = variante or product
        if not product.peut_servir(line.quantity, variante):
            survendus.append(f"{line.sku} (stock {stocke.stock_quantity}, commandé {line.quantity})")
        stocke.stock_quantity -= line.quantity
        stocke.save(update_fields=["stock_quantity"] + ([] if variante else ["updated_at"]))

        ProductStockMovement.objects.create(
            product=product,
            variant=variante,
            movement_type=ProductStockMovement.OUT,
            quantity=line.quantity,
            reason=f"Commande #{order.pk}",
            user=order.user,
        )

    if survendus:
        logger.error("Commande #%s survendue : %s", order.pk, ", ".join(survendus))
        transaction.on_commit(lambda: _alerter_survente(order.pk, survendus))


def _alerter_survente(order_id, survendus):
    try:
        from jeiko.emailing.admin_alerts import notifier_erreur

        notifier_erreur(
            "Commande payée au-delà du stock",
            f"La commande #{order_id} est réglée, mais le stock ne couvrait plus "
            f": {', '.join(survendus)}. Le stock est passé en négatif. À "
            f"réapprovisionner, ou à rembourser depuis la fiche de la commande.",
        )
    except Exception:
        logger.exception("Alerte de survente impossible (commande #%s)", order_id)
