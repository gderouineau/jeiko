"""État public partagé de la boutique."""

from django.core.cache import cache
from django.http import Http404

from .models import ShopSettings

#: « Le menu montre-t-il le panier ? » — demandé à CHAQUE page publique de
#: chaque site, boutique ou non. Gardé en cache, vidé à l'enregistrement des
#: réglages (`signals.py`) ; le délai ne couvre qu'un signal manqué.
CLE_PANIER_AU_MENU = "jeiko:shop:panier_au_menu"
DUREE_PANIER_AU_MENU = 60 * 60 * 24


def shop_is_online():
    """Retourne l'état d'ouverture sans dupliquer la lecture du singleton."""
    return bool(ShopSettings.get_solo().is_online)


def require_shop_online():
    """Bloque une URL publique de la boutique lorsqu'elle est désactivée."""
    if not shop_is_online():
        raise Http404("La boutique en ligne est actuellement désactivée.")


def panier_au_menu():
    """
    Le menu du site montre l'icône du panier : l'option est cochée dans les
    réglages de la boutique, ET la boutique est en ligne — une icône qui mène
    à une page 404 ne rend service à personne.

    `filter().first()` et non `get_solo()` : lire une page d'un site qui ne
    vend rien ne doit pas y créer des réglages de boutique.
    """
    visible = cache.get(CLE_PANIER_AU_MENU)
    if visible is None:
        reglages = ShopSettings.objects.filter(pk=1).only("is_online", "show_cart").first()
        visible = bool(reglages and reglages.is_online and reglages.show_cart)
        cache.set(CLE_PANIER_AU_MENU, visible, DUREE_PANIER_AU_MENU)
    return visible
