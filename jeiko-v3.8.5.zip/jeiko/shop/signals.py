"""
Signaux de la boutique.

Un seul pour l'instant : la reprise du panier anonyme à la connexion. Elle est
branchée sur `user_logged_in` plutôt que dans la vue de connexion, parce que
les entrées sont multiples — formulaire allauth, connexion sociale, connexion
programmée après inscription — et qu'un panier perdu selon le chemin emprunté
serait impossible à diagnostiquer.
"""

from django.contrib.auth.signals import user_logged_in
from django.db.models.signals import post_save
from django.dispatch import receiver

from .cart import merge_session_cart_safe
from .models import ProductType, ShopSettings


@receiver(user_logged_in, dispatch_uid="jeiko_shop_merge_session_cart")
def reprendre_le_panier_anonyme(sender, request, user, **kwargs):
    if request is None:
        return
    merge_session_cart_safe(request, user)


@receiver(post_save, sender=ShopSettings, dispatch_uid="jeiko_shop_invalidate_cart_menu")
def invalider_les_menus_apres_reglages(sender, instance, **kwargs):
    """L'icône du panier doit suivre les réglages de la boutique, tout de suite."""
    from django.core.cache import cache

    from .state import CLE_PANIER_AU_MENU

    cache.delete(CLE_PANIER_AU_MENU)
    # Le rendu d'un menu peut être mémorisé trente jours (`render_main_menu`),
    # icône comprise : sans cette invalidation, cocher la case ne changerait
    # rien avant l'expiration. Tous les menus : le réglage vaut pour tous.
    # L'import local évite le cycle shop -> menu -> shop.
    from jeiko.administration_menu.models import Menu, _invalidate_menu_cache_by_ids

    for menu in Menu.objects.only("id", "place"):
        _invalidate_menu_cache_by_ids(menu_id=menu.id, place=menu.place)


@receiver(post_save, sender=ProductType, dispatch_uid="jeiko_shop_type_liens")
def invalider_les_liens_apres_un_type(sender, instance, **kwargs):
    """
    Le code d'un type — traduit ou non — est dans l'adresse de tous ses
    produits (`jeiko/modeles_par_langue.py`). Le changer change ces adresses,
    donc les liens écrits dans le corps des pages gardé en cache. Sans effet
    sur un site monolingue : sa clé de cache ne porte pas la version des liens.
    """
    from jeiko.administration_pages.page_cache import bump_links_version

    bump_links_version()
