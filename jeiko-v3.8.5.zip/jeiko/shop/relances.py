"""
Les relances de la boutique : panier abandonné, retour en stock.

Le panier abandonné était déjà relancé chaque nuit
(`emailing.campaigns.relancer_les_paniers_abandonnes`), mais sans les
articles, le montant ni le lien que son e-mail affiche : le message disait
« pour un total de  » et son bouton ne menait nulle part. `contexte_panier`
les fournit.

Le retour en stock (`product_back_in_stock`) était au catalogue sans que rien
l'envoie. Les inscriptions (`StockAlert`) sont balayées toutes les 30 minutes
plutôt qu'à l'enregistrement du produit : un stock remis par l'API, par
l'écran ou par un remboursement passe par le même chemin, et un envoi raté se
retente au passage suivant.
"""

import logging

from django.urls import reverse
from django.utils.html import escape

from jeiko.emailing.render import site_base_url

from .models import ShopSettings, StockAlert, _montant

logger = logging.getLogger(__name__)


def _absolu(chemin):
    base = site_base_url()
    return f"{base}{chemin}" if base else chemin


def contexte_panier(panier):
    """Ce que l'e-mail `cart_abandoned` déclare : articles, total, lien de reprise."""
    devise = ShopSettings.get_solo().currency
    cellule = 'style="padding:8px 10px;border-bottom:1px solid #e5e7eb;"'
    lignes, total = [], 0
    for item in panier.items.select_related("product", "product__content", "variant"):
        total += item.total_ttc
        libelle = item.product.content.title + (f" — {item.variant.label}" if item.variant_id else "")
        lignes.append(
            f"<tr><td {cellule}>{escape(libelle)}</td><td {cellule}>{item.quantity}</td>"
            f"<td {cellule}>{_montant(item.total_ttc):.2f} {escape(devise)}</td></tr>"
        )
    tableau = (
        "<table role='presentation' cellpadding='0' cellspacing='0' "
        "style='width:100%;border-collapse:collapse;font-size:14px;'>"
        + "".join(lignes) + "</table>"
    )
    return {
        "bloc_lignes": tableau,
        "panier_total": f"{_montant(total):.2f} {devise}",
        "lien_action": _absolu(reverse("jeiko_client_shop:cart_detail")),
    }


def _disponible(alerte):
    produit = alerte.product
    if not produit.is_active or not produit.content.is_published:
        return False
    if alerte.variant_id:
        return alerte.variant.is_active and produit.peut_servir(1, alerte.variant)
    return produit.est_disponible


def prevenir_les_retours_en_stock():
    """Envoie les alertes dont le produit est revenu. Retourne le nombre d'envois."""
    from jeiko.emailing.services import send_email

    if not ShopSettings.get_solo().is_online:
        return 0
    envoyes = 0
    attente = (StockAlert.objects.all()
               .select_related("product", "product__content", "product__type", "variant", "user"))
    for alerte in attente.iterator(chunk_size=200):
        if not _disponible(alerte):
            continue
        produit = alerte.product
        prix = alerte.variant.price_ttc if alerte.variant_id else produit.price_ttc
        nom = produit.content.title + (f" — {alerte.variant.label}" if alerte.variant_id else "")
        try:
            ok, _motif = send_email("product_back_in_stock", alerte.email, {
                "prenom": getattr(alerte.user, "first_name", "") or "",
                "produit_nom": nom,
                "produit_prix": f"{prix:.2f} {produit.currency}",
                "lien_action": _absolu(produit.get_absolute_url()),
            }, user=alerte.user)
        except Exception:
            logger.exception("Retour en stock : échec pour l'alerte %s", alerte.pk)
            continue
        if ok:
            # Promesse tenue : l'adresse n'a plus de raison d'être gardée.
            alerte.delete()
            envoyes += 1
    return envoyes
