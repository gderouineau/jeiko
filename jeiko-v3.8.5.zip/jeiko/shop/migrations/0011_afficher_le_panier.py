"""
« Afficher le panier » passe du menu aux réglages de la boutique.

L'icône se réglait menu par menu (`Menu.show_cart`). Elle se règle désormais
une fois, dans les réglages de la boutique. Un site qui l'avait cochée sur au
moins un de ses menus la garde : rien ne disparaît à la mise à jour. Le champ
du menu est retiré ensuite, par `administration_menu.0021`.
"""

from django.db import migrations, models


def reprendre_le_reglage_des_menus(apps, schema_editor):
    Menu = apps.get_model("administration_menu", "Menu")
    if not Menu.objects.filter(show_cart=True).exists():
        return
    ShopSettings = apps.get_model("shop", "ShopSettings")
    reglages, _cree = ShopSettings.objects.get_or_create(pk=1)
    reglages.show_cart = True
    reglages.save(update_fields=["show_cart"])


class Migration(migrations.Migration):

    dependencies = [
        ("shop", "0010_intention_de_paiement"),
        # Le champ qu'on relit vit encore à cette migration-là.
        ("administration_menu", "0020_site_multilingue"),
    ]

    operations = [
        migrations.AddField(
            model_name="shopsettings",
            name="show_cart",
            field=models.BooleanField(
                default=False,
                help_text=(
                    "Une petite icône de panier dans le menu du site : en haut à "
                    "droite sur ordinateur, juste sous le menu sur mobile."
                ),
                verbose_name="Afficher le panier",
            ),
        ),
        # Sans retour : le champ du menu n'existe plus après `0021`, et le
        # réglage de la boutique dit déjà tout ce qu'il y a à savoir.
        migrations.RunPython(reprendre_le_reglage_des_menus, migrations.RunPython.noop),
    ]
