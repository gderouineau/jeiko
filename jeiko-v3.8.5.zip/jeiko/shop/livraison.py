"""
Frais de port d'un panier.

Les zones de livraison se réglaient depuis le 04/09 (Boutique › Réglages), et
rien ne les lisait : chaque produit expédié partait avec 0 € de port
(rapport Fable 1, §3.5). Ce module est le seul endroit où le port se calcule ;
la préparation de la commande et l'écran de paiement l'appellent tous deux, et
c'est ce qui garantit que le montant affiché est celui encaissé.

La règle :

* un panier sans article à expédier ne paie pas de port et n'a pas besoin
  d'adresse de livraison ;
* une boutique sans zone active livre partout, gratuitement — c'était le
  comportement de fait jusqu'ici, et un site qui n'a rien réglé ne doit pas
  se retrouver incapable de vendre ;
* sinon, la première zone (dans l'ordre de l'écran) qui couvre le pays et le
  code postal fixe le prix ; aucune zone → on ne livre pas à cette adresse ;
* la livraison est offerte au-delà du seuil de la zone, ou à défaut de celui
  de la boutique, comparé au total TTC des articles.

La TVA du port suit celle des marchandises expédiées, au prorata de leur
montant quand les taux diffèrent — la règle française de l'accessoire. Ce
module ne fait PAS de tarif au poids ni de transporteur au choix : une zone,
un prix.
"""

from decimal import Decimal

from django.utils.translation import gettext_lazy as _

from .models import ShopSettings, _montant

#: Les codes ISO 3166-1 alpha-2. Le nom affiché est laissé au navigateur
#: (`Intl.DisplayNames`), qui le connaît dans la langue du visiteur.
TOUS_LES_PAYS = (
    "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI "
    "BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN "
    "CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK "
    "FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM "
    "HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN "
    "KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK "
    "ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP "
    "NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW "
    "SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF "
    "TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI "
    "VN VU WF WS YE YT ZA ZM ZW"
).split()


class LivraisonImpossible(Exception):
    """Aucune zone ne couvre l'adresse donnée."""


def a_expedier(ligne):
    produit = ligne.product
    return bool(produit and getattr(produit.type, "requires_shipping", False))


def panier_a_expedier(lignes):
    return any(a_expedier(l) for l in lignes)


def _zones_actives():
    return list(ShopSettings.get_solo().delivery_zones.filter(is_active=True))


def pays_livrables():
    """Les pays proposés à l'écran de paiement, dans l'ordre alphabétique."""
    codes = set()
    for zone in _zones_actives():
        for code in (zone.country_codes or "").replace(";", ",").split(","):
            code = code.strip().upper()
            if code == "*":
                return list(TOUS_LES_PAYS)
            if code:
                codes.add(code)
    return sorted(codes) or list(TOUS_LES_PAYS)


def frais_de_port(lignes, pays, code_postal="", total_articles=None):
    """
    `(ttc, tva, libellé)` du port pour ces lignes livrées à cette adresse.

    `total_articles` : le montant comparé au seuil de gratuité — après remise
    quand un code promo s'applique. Par défaut, le TTC des lignes.

    Lève `LivraisonImpossible` quand des articles sont à expédier et qu'aucune
    zone active ne couvre l'adresse.
    """
    lignes = list(lignes)
    expediees = [l for l in lignes if a_expedier(l)]
    zero = Decimal("0.00")
    if not expediees:
        return zero, zero, ""

    zones = _zones_actives()
    if not zones:
        return zero, zero, ""

    zone = next((z for z in zones if z.matches(pays, code_postal)), None)
    if zone is None:
        raise LivraisonImpossible(
            _("Nous ne livrons pas encore à cette adresse.")
        )

    reglages = ShopSettings.get_solo()
    seuil = zone.free_from if zone.free_from is not None else reglages.free_shipping_from
    if total_articles is None:
        total_articles = sum((l.total_ttc for l in lignes), zero)
    if seuil is not None and total_articles >= seuil:
        return zero, zero, zone.name

    ttc = _montant(zone.price_ttc)
    return ttc, _tva_du_port(ttc, expediees, reglages.default_tax_rate), zone.name


def _tva_du_port(ttc, expediees, taux_par_defaut):
    """TVA comprise dans `ttc`, ventilée au prorata des taux expédiés."""
    if not ttc:
        return Decimal("0.00")
    par_taux = {}
    for l in expediees:
        par_taux[l.tax_rate] = par_taux.get(l.tax_rate, Decimal("0")) + l.total_ttc
    base = sum(par_taux.values(), Decimal("0"))
    if not base:
        par_taux, base = {taux_par_defaut: Decimal("1")}, Decimal("1")
    ht = sum(
        (ttc * part / base / (1 + taux / Decimal("100")) for taux, part in par_taux.items()),
        Decimal("0"),
    )
    return _montant(ttc - ht)
