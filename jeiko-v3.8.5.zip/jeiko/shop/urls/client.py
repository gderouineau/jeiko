from django.urls import path
from jeiko.shop.views import client as client_views

app_name = "jeiko_client_shop"

urlpatterns = [
    path("", client_views.ShopHomeView.as_view(), name="shop_home"),
    
    # Cart
    path("cart/", client_views.CartDetailView.as_view(), name="cart_detail"),
    path("cart/add/<int:product_id>/", client_views.AddToCartView.as_view(), name="cart_add"),
    path("cart/coupon/", client_views.CouponView.as_view(), name="cart_coupon"),
    path("avis/<int:product_id>/", client_views.ReviewView.as_view(), name="review"),
    path("alerte-stock/<int:product_id>/", client_views.StockAlertView.as_view(), name="stock_alert"),
    path("envies/", client_views.WishlistView.as_view(), name="wishlist"),
    path("envies/<int:product_id>/", client_views.WishlistToggleView.as_view(), name="wishlist_toggle"),
    path("recherche/", client_views.SearchView.as_view(), name="search"),
    path("flux/google.xml", client_views.GoogleFeedView.as_view(), name="google_feed"),
    path("catalogue.json", client_views.CatalogueJsonView.as_view(), name="catalogue_json"),
    path("facture/<int:pk>/", client_views.InvoiceView.as_view(), name="invoice"),
    path("avoir/<int:pk>/", client_views.CreditNoteView.as_view(), name="credit_note"),
    path("cart/update/<int:item_id>/", client_views.UpdateCartItemView.as_view(), name="cart_update"),
    path("cart/remove/<int:item_id>/", client_views.RemoveCartItemView.as_view(), name="cart_remove"),

    # EN DERNIER : `<type>/<référence>/` capte toute adresse à deux segments.
    # Placée avant, elle avalait `cart/coupon/` (405 sur le POST) — le même
    # piège avait rendu le webhook Stripe injoignable.
    path("<slug:product_type_code>/<slug:product_sku>/", client_views.ProductView.as_view(), name="product_detail"),
]
