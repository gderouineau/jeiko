from django.urls import path
from jeiko.shop.views import admin as admin_views

app_name = "jeiko_administration_shop"

urlpatterns = [
    # Types de produit
    path("types/", admin_views.ProductTypeListView.as_view(), name="product_type_list"),
    # Réglages de la boutique : TVA, devise, livraison. Ce qui vaut pour
    # tout le site, par opposition à ce qui se règle produit par produit.
    path("reglages/", admin_views.ShopSettingsUpdateView.as_view(), name="settings"),
    # Avis clients
    path("avis/", admin_views.ReviewListView.as_view(), name="review_list"),
    path("avis/<int:pk>/", admin_views.ReviewActionView.as_view(), name="review_action"),
    # Codes promo
    path("codes-promo/", admin_views.CouponListView.as_view(), name="coupon_list"),
    path("codes-promo/add/", admin_views.CouponCreateView.as_view(), name="coupon_create"),
    path("codes-promo/<int:pk>/edit/", admin_views.CouponUpdateView.as_view(), name="coupon_update"),
    path("codes-promo/<int:pk>/delete/", admin_views.CouponDeleteView.as_view(), name="coupon_delete"),
    path("types/add/", admin_views.ProductTypeCreateView.as_view(), name="product_type_create"),
    path("types/<int:pk>/edit/", admin_views.ProductTypeUpdateView.as_view(), name="product_type_update"),
    path("types/<int:pk>/delete/", admin_views.ProductTypeDeleteView.as_view(), name="product_type_delete"),

    # Produits d’un type
    path(
        "products/",
        admin_views.AllProductListView.as_view(),
        name="product_list_all",
    ),
    path(
        "types/<int:type_pk>/products/",
        admin_views.ProductListView.as_view(),
        name="product_list",
    ),
    path(
        "types/<int:type_pk>/products/add/",
        admin_views.ProductCreateView.as_view(),
        name="product_create",
    ),
    path(
        "types/<int:type_pk>/products/<int:pk>/edit/",
        admin_views.ProductUpdateView.as_view(),
        name="product_update",
    ),
    path(
        "types/<int:type_pk>/products/<int:pk>/delete/",
        admin_views.ProductDeleteView.as_view(),
        name="product_delete",
    ),
    # Site en plusieurs langues : la version de la fiche d'un produit.
    path(
        "types/<int:type_pk>/products/<int:pk>/versions/<slug:langue>/creer/",
        admin_views.ProductVersionCreateView.as_view(),
        name="product_version_creer",
    ),
    path(
        "types/<int:type_pk>/products/<int:pk>/versions/<slug:langue>/supprimer/",
        admin_views.ProductVersionDeleteView.as_view(),
        name="product_version_supprimer",
    ),
]
