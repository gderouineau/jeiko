from django.urls import path
from ..views.admin_orders import ManualOrderView, OrderExportView, OrderListView, OrderRefundView, OrderUpdateView, SalesDashboardView

app_name = 'jeiko_shop_admin_orders'

urlpatterns = [
    path('orders/', OrderListView.as_view(), name='order_list'),
    path('orders/nouvelle/', ManualOrderView.as_view(), name='order_manual'),
    path('orders/export.csv', OrderExportView.as_view(), name='order_export'),
    path('ventes/', SalesDashboardView.as_view(), name='sales_dashboard'),
    path('orders/<int:pk>/', OrderUpdateView.as_view(), name='order_update'),
    path('orders/<int:pk>/rembourser/', OrderRefundView.as_view(), name='order_refund'),
]
