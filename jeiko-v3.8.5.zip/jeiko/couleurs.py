"""
Contraste des couleurs saisies — rendre lisible sans changer la teinte.

Le problème
-----------
Une couleur choisie dans un sélecteur se juge à l'œil, sur un écran lumineux.
Le lien « En savoir plus » de la bannière de cookies sortait en `#D97757` sur
`#f5f7fa` : 2,9:1, là où les règles d'accessibilité (WCAG 1.4.3) demandent
4,5:1 pour du texte courant. PageSpeed le relevait sur toutes les pages, et
c'est un lien que le visiteur doit pouvoir lire avant de consentir.

Ce que fait ce module
---------------------
`lisible_sur(couleur, fond)` rend la couleur d'origine si elle atteint déjà le
seuil, sinon la même teinte, assombrie (fond clair) ou éclaircie (fond foncé)
juste assez pour l'atteindre. On ne remplace pas le choix de l'exploitant par
une autre couleur : on le rend conforme.

Ce qu'il ne fait pas : il ne comprend que `#rgb` et `#rrggbb`. Une autre
écriture (`rgb()`, `var(--…)`, nom CSS) est rendue telle quelle — mieux vaut
ne rien corriger que corriger à l'aveugle.
"""

import re

SEUIL_TEXTE = 4.5

_HEX = re.compile(r"^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


def _rvb(couleur):
    m = _HEX.match((couleur or "").strip())
    if not m:
        return None
    h = m.group(1)
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _luminance(rvb):
    def canal(c):
        c = c / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, v, b = (canal(c) for c in rvb)
    return 0.2126 * r + 0.7152 * v + 0.0722 * b


def contraste(couleur, fond):
    """Rapport de contraste WCAG entre deux couleurs hexadécimales, ou None."""
    a, b = _rvb(couleur), _rvb(fond)
    if a is None or b is None:
        return None
    la, lb = sorted((_luminance(a), _luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def lisible_sur(couleur, fond, seuil=SEUIL_TEXTE):
    """`couleur`, ajustée vers le noir ou le blanc jusqu'à `seuil` sur `fond`."""
    rvb, rvb_fond = _rvb(couleur), _rvb(fond)
    if rvb is None or rvb_fond is None:
        return couleur
    if contraste(couleur, fond) >= seuil:
        return couleur

    cible = 0 if _luminance(rvb_fond) > 0.18 else 255
    for pas in range(1, 101):
        t = pas / 100
        melange = tuple(round(c + (cible - c) * t) for c in rvb)
        hexa = "#%02x%02x%02x" % melange
        if contraste(hexa, fond) >= seuil:
            return hexa
    return "#000000" if cible == 0 else "#ffffff"
