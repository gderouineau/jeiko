"""
Notes et comptes rendus d'un contact (CRM-04, CRM-05).

Une note est PRIVÉE : elle ne quitte jamais l'administration. Un compte rendu
peut être TRANSMIS au contact, et seulement par un geste explicite, après
relecture :

* à l'adresse de la fiche, et à aucune autre — un compte rendu ne part pas
  vers une adresse saisie au moment de l'envoi ;
* par l'e-mail du catalogue `appointment_followup`, que l'exploitant habille
  comme les autres ; le journal d'envoi (`EmailLog`) en garde la preuve ;
* jamais par un agent : l'API et le MCP n'ont aucune route qui envoie. Une
  phrase glissée dans un formulaire de contact, lue par un agent, ne doit pas
  pouvoir faire partir des données par e-mail.

Un envoi qui échoue reste visible : la note ne porte une date de transmission
que si l'e-mail est parti.
"""
from django.utils import timezone
from django.utils.html import escape, linebreaks
from django.utils.safestring import mark_safe

from jeiko.users.models import Comments


def ajouter(contact, auteur, texte, nature=Comments.Nature.NOTE, rendez_vous=None):
    # La personne concernée, quand elle a un compte lié à la fiche.
    lien = contact.user_links.select_related("user").first()
    return Comments.objects.create(
        prospect=contact, author=auteur, text=texte[:5000], kind=nature,
        appointment=rendez_vous, user=lien.user if lien else None,
    )


def transmettre(note, acteur):
    """
    Envoie le compte rendu à l'adresse de la fiche. Rend (envoyé, erreur).
    """
    from jeiko.emailing.services import send_email

    contact = note.prospect
    if note.kind != Comments.Nature.COMPTE_RENDU:
        return False, "Seul un compte rendu se transmet ; une note reste privée."
    if contact is None or not contact.email:
        return False, "La fiche n'a pas d'adresse e-mail."

    rdv = note.appointment
    contexte = {
        "prenom": contact.firstname or contact.nom_complet,
        "nom": contact.lastname,
        "email": contact.email,
        "rdv_date": timezone.localtime(rdv.start).strftime("%d/%m/%Y") if rdv else "",
        "rdv_type": rdv.type.name if rdv and rdv.type_id else "",
        # Le texte est échappé puis mis en paragraphes : saisi comme du texte,
        # il ne devient jamais du HTML dans la boîte du destinataire.
        "compte_rendu": mark_safe(linebreaks(escape(note.text))),
        "pro_nom": (acteur.get_full_name() or acteur.get_username()) if acteur else "",
    }
    envoye, erreur = send_email("appointment_followup", contact.email, contexte)
    if envoye:
        note.shared_at = timezone.now()
        note.shared_to = contact.email
        note.save(update_fields=["shared_at", "shared_to", "updated_at"])
    return envoye, erreur
