"""
Le CRM de JEIKO : la fiche d'une personne et ce que le site sait d'elle.

Ce paquet n'a pas de modèle à lui, et ce n'est pas un oubli :

* la fiche est `questionnaires_expert.Prospect`, présentée sous le nom de
  « contact » (voir sa docstring : la déplacer coûterait leurs droits à tous
  les rôles en service) ;
* l'historique n'est PAS recopié : `historique.py` le lit dans les modules qui
  le détiennent — rendez-vous, liste d'attente, formulaires, questionnaires,
  commandes, formations, e-mails —, par l'adresse e-mail de la fiche et par le
  compte qui lui est lié. Rien à synchroniser, rien qui se périme ;
* le RGPD d'une personne SANS compte vit dans `rgpd.py` : `users/rgpd.py` part
  toujours d'un compte, et ne pouvait rien pour elle.

Ce que ce paquet ne fait pas : fusionner des fiches. Une saisie publique n'est
jamais vérifiée ; deux fiches à la même adresse restent deux fiches tant qu'un
humain ne les a pas rapprochées.

Voir PLAN_ACTION.md, CRM-01 à CRM-10 et « Propositions pour la mise en place ».
"""
