"""
Rattacher une entrée publique — réservation, liste d'attente, formulaire de
contact — à une fiche du CRM (CRM-03).

La règle est celle du questionnaire (`questionnaires_expert.views.client.
resolve_prospect`), adaptée à un nom saisi d'un seul tenant :

* une fiche à cette adresse existe et le nom concorde (ou l'un des deux est
  vide) → c'est la sienne ; on complète ce qui y manquait, sans jamais rien
  écraser ;
* la fiche existante est VÉRIFIÉE → on n'y touche pas : une saisie publique ne
  modifie jamais une fiche dont le titulaire a prouvé son adresse. L'entrée
  apparaît quand même dans son historique, qui se lit par l'adresse ;
* le nom ne concorde pas → une seconde fiche, distincte : deux personnes
  partagent peut-être une adresse, et les fusionner ferait lire les échanges
  de l'une sous le nom de l'autre. Le rapprochement est un geste humain.

Ne lève JAMAIS : un rattachement manqué ne doit pas faire échouer la
réservation ni l'envoi du formulaire — l'historique, lu par l'adresse, n'en
dépend pas.
"""
import logging

logger = logging.getLogger(__name__)


def separer_le_nom(nom):
    """« Marie Curie » → (« Marie », « Curie ») ; un seul mot → prénom."""
    morceaux = (nom or "").split()
    if not morceaux:
        return "", ""
    return morceaux[0][:200], " ".join(morceaux[1:])[:200]


def _concorde(fiche, nom):
    connu = f"{fiche.firstname} {fiche.lastname}".strip().casefold()
    saisi = " ".join((nom or "").split()).casefold()
    return not connu or not saisi or connu == saisi


def rattacher(email, *, nom="", telephone="", societe="", fonction="", origine):
    """Rend la fiche de cette entrée (créée au besoin), ou None."""
    from django.db import transaction

    try:
        # Un point de sauvegarde à lui : une erreur de base ici, même attrapée,
        # empoisonnerait sinon la transaction de la réservation.
        with transaction.atomic():
            return _rattacher(email, nom=nom, telephone=telephone, societe=societe,
                              fonction=fonction, origine=origine)
    except Exception:
        logger.exception("Rattachement d'une entrée publique au CRM impossible")
        return None


def _rattacher(email, *, nom, telephone, societe, fonction, origine):
    from jeiko.questionnaires_expert.models import Prospect

    email = (email or "").strip().lower()
    if not email:
        return None

    fiches = list(Prospect.objects.filter(email__iexact=email).order_by("id"))
    verifiee = next((f for f in fiches if f.email_verified), None)
    if verifiee is not None:
        return verifiee

    prenom, nom_de_famille = separer_le_nom(nom)
    complements = {"phone": (telephone or "")[:20], "company": societe or "", "job_title": fonction or ""}

    fiche = next((f for f in fiches if _concorde(f, nom)), None)
    if fiche is not None:
        if not (fiche.firstname or fiche.lastname):
            complements.update(firstname=prenom, lastname=nom_de_famille)
        vides = [champ for champ, valeur in complements.items() if valeur and not getattr(fiche, champ)]
        for champ in vides:
            setattr(fiche, champ, complements[champ])
        if vides:
            fiche.save(update_fields=vides + ["updated_at"])
        return fiche

    return Prospect.objects.create(
        email=email, firstname=prenom, lastname=nom_de_famille, origin=origine, **complements)


# ponytail: le nom et la société d'un formulaire se reconnaissent à leur NOM
# technique, une liste courte — un champ « votre_identite » ne sera pas lu.
# Ajouter un rôle CRM par champ dans l'éditeur de formulaire si cela manque.
NOMS = {"nom", "name", "nom_complet", "fullname", "full_name", "lastname", "last_name"}
PRENOMS = {"prenom", "firstname", "first_name"}
SOCIETES = {"societe", "entreprise", "company_name", "organisation", "organization", "structure"}


def rattacher_un_envoi(formulaire, valeurs):
    """
    Un envoi de formulaire de contact rejoint la fiche de son auteur. L'adresse
    et le téléphone se lisent au TYPE du champ (`email`, `phone`) ; le nom et
    la société, à son nom technique (voir ci-dessus). Sans champ e-mail,
    aucun rattachement : rien ne relierait l'envoi à une personne.
    """
    from jeiko.questionnaires_expert.models import Prospect

    lu = {"email": "", "telephone": "", "nom": "", "prenom": "", "societe": ""}
    try:
        champs = list(formulaire.fields.all())
    except Exception:
        logger.exception("Lecture des champs du formulaire impossible")
        return None
    for champ in champs:
        valeur = (valeurs.get(champ.name) or "").strip()
        nom = champ.name.lower()
        if champ.type == "email" and not lu["email"]:
            lu["email"] = valeur
        elif champ.type == "phone" and not lu["telephone"]:
            lu["telephone"] = valeur
        elif nom in PRENOMS:
            lu["prenom"] = valeur
        elif nom in NOMS:
            lu["nom"] = valeur
        elif nom in SOCIETES:
            lu["societe"] = valeur
    return rattacher(
        lu["email"], nom=" ".join(p for p in (lu["prenom"], lu["nom"]) if p),
        telephone=lu["telephone"], societe=lu["societe"],
        origine=Prospect.Origine.FORMULAIRE,
    )

