from django import forms
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _

from jeiko.questionnaires_expert.models import Prospect


class ContactForm(forms.ModelForm):
    """La fiche d'un contact, telle que l'exploitant la tient."""

    tags = forms.CharField(
        label=_("Étiquettes"), required=False,
        help_text=_("Séparées par des virgules : « devis, salon 2026 »."),
    )

    class Meta:
        model = Prospect
        # La prochaine action ne se saisit plus ici : c'est la tâche ouverte la
        # plus proche, gérée sur la fiche (jeiko/crm/taches.py).
        fields = ["firstname", "lastname", "email", "phone", "entreprise", "company", "job_title",
                  "status", "owner", "tags", "task_reminders"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Un responsable est quelqu'un qui travaille sur le site, pas un client.
        self.fields["owner"].queryset = get_user_model().objects.filter(
            is_staff=True, is_active=True).order_by("first_name", "last_name", "username")
        self.initial["tags"] = ", ".join(self.instance.tags or [])
        self.fields["entreprise"].help_text = _("Choisie, elle remplace le texte « Société » par son nom.")

    def clean_tags(self):
        vues, propres = set(), []
        for brut in (self.cleaned_data.get("tags") or "").split(","):
            tag = brut.strip()[:50]
            if tag and tag.casefold() not in vues:
                vues.add(tag.casefold())
                propres.append(tag)
        return propres

    def clean(self):
        donnees = super().clean()
        if not any(donnees.get(c) for c in ("firstname", "lastname", "email", "company")):
            raise forms.ValidationError(_("Renseignez au moins un nom, une adresse e-mail ou une société."))
        return donnees


class RendezVousDuContactForm(forms.Form):
    """
    Un rendez-vous pris depuis la fiche d'un contact : sur un créneau libre
    de l'agenda, ou à une heure choisie librement (un appel, une réunion qui
    ne suit pas les disponibilités publiées). Dans le second cas, le temps
    est réservé quand même : les créneaux qu'il chevauche se ferment
    (`calendars.models.periodes_occupees`).
    """

    MODES = [("creneau", _("Sur un créneau libre")), ("libre", _("À une date et une heure libres"))]
    mode = forms.ChoiceField(label=_("Quand"), choices=MODES, initial="creneau", widget=forms.RadioSelect)
    slot = forms.ModelChoiceField(queryset=None, required=False, label=_("Créneau"),
                                  empty_label=_("Choisissez un créneau"))
    type = forms.ModelChoiceField(queryset=None, required=False, label=_("Type de rendez-vous"))
    date = forms.DateField(required=False, label=_("Date"), widget=forms.DateInput(attrs={"type": "date"}))
    heure = forms.TimeField(required=False, label=_("Heure"), widget=forms.TimeInput(attrs={"type": "time"}))
    message = forms.CharField(required=False, label=_("Objet ou note pour le rendez-vous"),
                              widget=forms.Textarea(attrs={"rows": 2}), max_length=2000)
    envoyer = forms.BooleanField(required=False, initial=True,
                                 label=_("Envoyer la confirmation au contact"))

    def __init__(self, *args, gestionnaire=None, superviseur=False, **kwargs):
        from django.utils import timezone

        from jeiko.calendars.forms import AppointmentClientCreateForm
        from jeiko.calendars.models import AppointmentType, Slot

        super().__init__(*args, **kwargs)
        creneaux = Slot.objects.filter(is_available=True, remaining_places__gt=0,
                                       start__gte=timezone.now()).select_related("type", "availability")
        types = AppointmentType.objects.all()
        if not superviseur:
            creneaux = creneaux.filter(availability__user=gestionnaire)
            types = types.filter(user=gestionnaire)
        self.fields["slot"].queryset = creneaux.order_by("start")
        self.fields["slot"].label_from_instance = AppointmentClientCreateForm._label
        self.fields["type"].queryset = types.order_by("name")

    def clean(self):
        donnees = super().clean()
        if donnees.get("mode") == "creneau":
            if not donnees.get("slot"):
                self.add_error("slot", _("Choisissez un créneau."))
        else:
            for champ in ("type", "date", "heure"):
                if not donnees.get(champ):
                    self.add_error(champ, _("Ce champ est obligatoire."))
        return donnees



class EntrepriseForm(forms.ModelForm):
    class Meta:
        from jeiko.questionnaires_expert.models import Company
        model = Company
        fields = ["name", "website", "email", "phone", "address", "postal_code", "city",
                  "country", "siret", "owner", "notes"]
        widgets = {"address": forms.Textarea(attrs={"rows": 2}), "notes": forms.Textarea(attrs={"rows": 4})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["owner"].queryset = get_user_model().objects.filter(
            is_staff=True, is_active=True).order_by("first_name", "last_name", "username")

    def clean_country(self):
        return (self.cleaned_data.get("country") or "").strip().upper()
