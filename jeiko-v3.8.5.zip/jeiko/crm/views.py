"""
Les écrans du CRM : la liste des contacts, une fiche, son historique.

Droits : ceux du modèle `Prospect` (voir, ajouter, modifier, supprimer), plus
deux permissions propres — lire les notes, exporter —, qu'aucun rôle par
défaut ne donne.
"""
import json

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.generic import CreateView, DetailView, ListView, UpdateView

from jeiko.listes import ListeRechercheeEtPaginee
from jeiko.questionnaires_expert.models import Prospect

from . import historique, rgpd
from .forms import ContactForm

VOIR = "questionnaires_expert.view_prospect"
AJOUTER = "questionnaires_expert.add_prospect"
MODIFIER = "questionnaires_expert.change_prospect"
SUPPRIMER = "questionnaires_expert.delete_prospect"
EXPORTER = "questionnaires_expert.export_contacts"
NOTES = "questionnaires_expert.view_contact_notes"


class _Acces(LoginRequiredMixin, PermissionRequiredMixin):
    raise_exception = True


@method_decorator(never_cache, name="dispatch")
class ListeDesContacts(_Acces, ListeRechercheeEtPaginee, ListView):
    permission_required = VOIR
    template_name = "crm/admin/liste.html"
    context_object_name = "contacts"
    champs_de_recherche = ("firstname", "lastname", "email", "company", "phone")

    def get_queryset(self):
        qs = Prospect.objects.select_related("owner").order_by("-updated_at", "-date_created")
        statut = self.request.GET.get("statut")
        if statut in Prospect.Statut.values:
            qs = qs.filter(status=statut)
        return self.rechercher(qs)


@method_decorator(never_cache, name="dispatch")
class ProspectsDesQuestionnaires(ListeDesContacts):
    """Les contacts qui ont passé un questionnaire — même écran, même recherche."""

    def get_queryset(self):
        return super().get_queryset().filter(test_datas__isnull=False).distinct()

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["titre"] = _("Prospects des questionnaires")
        return ctx


@method_decorator(never_cache, name="dispatch")
class ExportCsv(ListeDesContacts):
    """La liste telle qu'elle est filtrée à l'écran, en CSV (csv_contacts.py)."""
    permission_required = (VOIR, EXPORTER)
    paginate_by = None

    def get(self, request, *args, **kwargs):
        from .csv_contacts import exporter

        reponse = HttpResponse(exporter(self.get_queryset()), content_type="text/csv; charset=utf-8")
        reponse["Content-Disposition"] = 'attachment; filename="contacts.csv"'
        return reponse


@method_decorator(never_cache, name="dispatch")
class ImportCsv(_Acces, View):
    permission_required = (AJOUTER, EXPORTER)
    template_name = "crm/admin/import.html"

    def get(self, request):
        from django.shortcuts import render
        return render(request, self.template_name)

    def post(self, request):
        from django.shortcuts import render

        from .csv_contacts import ImportImpossible, importer

        fichier = request.FILES.get("fichier")
        if fichier is None:
            messages.error(request, _("Choisissez un fichier CSV."))
            return render(request, self.template_name, status=400)
        try:
            bilan = importer(fichier)
        except ImportImpossible as refus:
            messages.error(request, str(refus))
            return render(request, self.template_name, status=400)
        return render(request, self.template_name, {"bilan": bilan})

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["statuts"] = Prospect.Statut.choices
        ctx["statut"] = self.request.GET.get("statut", "")
        return ctx


@method_decorator(never_cache, name="dispatch")
class FicheDuContact(_Acces, DetailView):
    permission_required = VOIR
    model = Prospect
    template_name = "crm/admin/fiche.html"
    context_object_name = "contact"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["historique"] = historique.historique(self.object)
        from django.contrib.auth import get_user_model

        self.object_taches = self.object.tasks.select_related("assignee").order_by("done_at", "due_on", "id")
        ctx["taches_ouvertes"] = [t for t in self.object_taches if t.done_at is None]
        ctx["taches_faites"] = [t for t in self.object_taches if t.done_at is not None][-10:]
        ctx["equipe"] = get_user_model().objects.filter(is_staff=True, is_active=True).order_by("first_name", "username")
        ctx["aujourdhui"] = timezone.localdate()
        # Les messages envoyés par les formulaires, en entier, en tête de fiche.
        ctx["messages_envoyes"] = historique.messages_du_contact((self.object.email or "").strip())
        if self.request.user.has_perm(NOTES):
            from jeiko.users.models import Comments

            ctx["notes"] = (Comments.objects.filter(prospect=self.object)
                            .select_related("author", "appointment__type").order_by("-date_created"))
            ctx["natures"] = Comments.Nature.choices
            ctx["rendez_vous"] = historique.rendez_vous_du_contact(self.object)
        ctx["doublons"] = (
            Prospect.objects.filter(email__iexact=self.object.email).exclude(pk=self.object.pk)
            if self.object.email else Prospect.objects.none()
        )
        return ctx


class _Edition(_Acces):
    model = Prospect
    form_class = ContactForm
    template_name = "crm/admin/formulaire.html"
    context_object_name = "contact"

    def form_valid(self, form):
        # Rattaché à une entreprise, le texte « Société » en prend le nom.
        if form.instance.entreprise_id:
            form.instance.company = form.instance.entreprise.name
        return super().form_valid(form)

    def get_success_url(self):
        return reverse("jeiko_crm:fiche", args=[self.object.pk])


@method_decorator(never_cache, name="dispatch")
class NouveauContact(_Edition, CreateView):
    permission_required = AJOUTER

    def get_initial(self):
        # « Ajouter une personne » depuis la fiche d'une entreprise.
        initial = super().get_initial()
        if (self.request.GET.get("entreprise") or "").isdigit():
            initial["entreprise"] = int(self.request.GET["entreprise"])
        return initial

    def form_valid(self, form):
        form.instance.origin = Prospect.Origine.MANUEL
        return super().form_valid(form)


@method_decorator(never_cache, name="dispatch")
class ModifierLeContact(_Edition, UpdateView):
    permission_required = MODIFIER


@method_decorator(never_cache, name="dispatch")
class ExportDuContact(_Acces, View):
    """Droit d'accès d'une personne sans compte : sa fiche et son historique, en JSON."""
    permission_required = EXPORTER

    def get(self, request, pk):
        contact = get_object_or_404(Prospect, pk=pk)
        reponse = HttpResponse(
            json.dumps(rgpd.exporter(contact), ensure_ascii=False, indent=2),
            content_type="application/json",
        )
        reponse["Content-Disposition"] = f'attachment; filename="contact-{contact.pk}.json"'
        return reponse


@method_decorator(never_cache, name="dispatch")
class EffacerLeContact(_Acces, View):
    """Droit à l'effacement : POST seulement, après la confirmation de la fiche."""
    permission_required = SUPPRIMER

    def post(self, request, pk):
        contact = get_object_or_404(Prospect, pk=pk)
        resume = rgpd.effacer(contact, acteur=request.user, motif=request.POST.get("motif", "")[:200])
        messages.success(request, _(
            "Contact effacé : %(fiches)s fiche(s), %(rdv)s rendez-vous anonymisé(s), "
            "%(envois)s envoi(s) de formulaire supprimé(s)."
        ) % {"fiches": resume.get("fiches_supprimees", 0),
             "rdv": resume.get("rendez_vous_anonymises", 0),
             "envois": resume.get("envois_de_formulaire_supprimes", 0)})
        if resume.get("comptes_lies_non_touches"):
            messages.warning(request, _(
                "Un compte utilisateur porte aussi cette personne : il s'efface depuis sa "
                "fiche utilisateur."))
        return redirect("jeiko_crm:liste")


class EffacerLaSelection(_Acces, View):
    """
    Supprimer les contacts cochés dans la liste — un ou cent.

    Chacun passe par le même effacement que la fiche (`rgpd.effacer`) : ses
    envois de formulaire, ses passages de questionnaire et ses notes partent
    avec lui, ses rendez-vous sont anonymisés. Nettoyer cent fiches nées du
    spam une à une n'était pas praticable.
    """

    permission_required = SUPPRIMER

    def post(self, request):
        from jeiko.questionnaires_expert.models import Prospect

        brut = request.POST.get("contact_ids", "")
        ids = [int(x) for x in (i.strip() for i in brut.split(",")) if x.isdigit()]
        if not ids:
            messages.warning(request, _("Aucun contact sélectionné."))
        else:
            effaces = 0
            for pk in ids:
                # Une fiche déjà partie avec un doublon de la même adresse.
                contact = Prospect.objects.filter(pk=pk).first()
                if contact is None:
                    continue
                resume = rgpd.effacer(contact, acteur=request.user, motif="suppression en masse depuis la liste")
                effaces += resume.get("fiches_supprimees", 1)
            messages.success(request, _("%(n)s contact(s) supprimé(s).") % {"n": effaces})
        suite = request.POST.get("next") or ""
        if suite.startswith("/") and not suite.startswith("//"):
            return redirect(suite)
        return redirect("jeiko_crm:liste")


# --------------------------------------------------------------------------- #
#  Notes et comptes rendus (CRM-04, CRM-05) — voir comptes_rendus.py
# --------------------------------------------------------------------------- #
@method_decorator(never_cache, name="dispatch")
class AjouterUneNote(_Acces, View):
    permission_required = NOTES

    def post(self, request, pk):
        from jeiko.calendars.models import Appointment
        from jeiko.users.models import Comments

        from . import comptes_rendus

        contact = get_object_or_404(Prospect, pk=pk)
        texte = (request.POST.get("texte") or "").strip()
        nature = request.POST.get("nature")
        if not texte or nature not in Comments.Nature.values:
            messages.error(request, _("Une note a besoin d'un texte."))
            return redirect("jeiko_crm:fiche", pk=pk)
        # Seulement un rendez-vous de CE contact : l'identifiant vient du navigateur.
        rdv_id = request.POST.get("rendez_vous")
        rdv = None
        if rdv_id:
            rdv = historique.rendez_vous_du_contact(contact).filter(pk=rdv_id).first()
        comptes_rendus.ajouter(contact, request.user, texte, nature, rdv)
        return redirect(reverse("jeiko_crm:fiche", args=[pk]) + "#notes")


@method_decorator(never_cache, name="dispatch")
class SupprimerUneNote(_Acces, View):
    """L'auteur supprime sa note ; un superutilisateur, toute note."""
    permission_required = NOTES

    def post(self, request, pk, note_id):
        from jeiko.users.models import Comments

        note = get_object_or_404(Comments, pk=note_id, prospect_id=pk)
        if note.author_id != request.user.pk and not request.user.is_superuser:
            messages.error(request, _("Seul son auteur peut supprimer une note."))
        else:
            note.delete()
        return redirect(reverse("jeiko_crm:fiche", args=[pk]) + "#notes")


@method_decorator(never_cache, name="dispatch")
class TransmettreLeCompteRendu(_Acces, View):
    permission_required = (NOTES, MODIFIER)

    def post(self, request, pk, note_id):
        from jeiko.users.models import Comments

        from . import comptes_rendus

        note = get_object_or_404(Comments, pk=note_id, prospect_id=pk)
        envoye, erreur = comptes_rendus.transmettre(note, request.user)
        if envoye:
            messages.success(request, _("Compte rendu envoyé à %(email)s.") % {"email": note.shared_to})
        else:
            messages.error(request, _("Le compte rendu n'est pas parti : %(erreur)s") % {"erreur": erreur})
        return redirect(reverse("jeiko_crm:fiche", args=[pk]) + "#notes")


# --------------------------------------------------------------------------- #
#  Relances (point 5 des propositions) : une prochaine action par contact
# --------------------------------------------------------------------------- #
def contacts_a_relancer(jusqu_au=None):
    """
    Les contacts dont la prochaine action est due, la plus ancienne d'abord,
    avec `recontact` : la personne a-t-elle accepté d'être recontactée (case
    de la réservation) ? Relancer est une autre finalité que réserver ; la
    liste le dit plutôt que de le taire.
    """
    from django.db.models import Exists, OuterRef
    from django.utils import timezone

    from jeiko.calendars.models import Appointment

    jusqu_au = jusqu_au or timezone.localdate()
    return (
        Prospect.objects.filter(next_action_on__lte=jusqu_au)
        .annotate(recontact=Exists(Appointment.objects.filter(
            email__iexact=OuterRef("email"), contact_consent=True)))
        .select_related("owner").order_by("next_action_on", "pk")
    )


@method_decorator(never_cache, name="dispatch")
class ARelancer(_Acces, ListView):
    permission_required = VOIR
    template_name = "crm/admin/relances.html"
    context_object_name = "contacts"
    paginate_by = 100

    def get_queryset(self):
        qs = contacts_a_relancer()
        if self.request.GET.get("moi"):
            qs = qs.filter(owner=self.request.user)
        return qs


@method_decorator(never_cache, name="dispatch")
class RelanceFaite(_Acces, View):
    """
    Termine la prochaine action — la tâche ouverte la plus proche — et la garde
    en note, pour l'historique de la fiche. La suivante devient la prochaine.
    """
    permission_required = MODIFIER

    def post(self, request, pk):
        from jeiko.users.models import Comments

        from . import comptes_rendus, taches

        contact = get_object_or_404(Prospect, pk=pk)
        tache = taches.ouvertes(contact).first()
        # Une fiche sans tâche peut encore porter une prochaine action posée
        # avant les tâches : on la traite de la même façon.
        prevue = tache.due_on if tache else contact.next_action_on
        if prevue is not None:
            if request.user.has_perm(NOTES):
                comptes_rendus.ajouter(
                    contact, request.user,
                    _("Relance faite (prévue le %(date)s) : %(action)s") % {
                        "date": prevue.strftime("%d/%m/%Y"),
                        "action": (tache.title if tache else contact.next_action) or "—"},
                    Comments.Nature.NOTE)
            if tache is not None:
                taches.terminer(tache)
            else:
                taches.refleter(contact)
        retour = request.POST.get("retour")
        if retour == "fiche":
            return redirect("jeiko_crm:fiche", pk=pk)
        return redirect("jeiko_crm:relances")


@method_decorator(never_cache, name="dispatch")
class Rapprocher(_Acces, View):
    """Rapprocher un doublon (même adresse) dans la fiche qu'on regarde."""
    permission_required = (MODIFIER, SUPPRIMER)
    template_name = "crm/admin/rapprocher.html"

    def _fiches(self, pk, doublon_id):
        gardee = get_object_or_404(Prospect, pk=pk)
        doublon = get_object_or_404(Prospect, pk=doublon_id, email__iexact=gardee.email or "\0")
        if doublon.pk == gardee.pk:
            from django.http import Http404
            raise Http404
        return gardee, doublon

    def get(self, request, pk, doublon_id):
        from django.shortcuts import render

        gardee, doublon = self._fiches(pk, doublon_id)
        return render(request, self.template_name, {"gardee": gardee, "doublon": doublon})

    def post(self, request, pk, doublon_id):
        from .rapprochement import rapprocher

        gardee, doublon = self._fiches(pk, doublon_id)
        rapprocher(gardee, doublon, request.user)
        messages.success(request, _("Fiches rapprochées."))
        return redirect("jeiko_crm:fiche", pk=gardee.pk)



# --------------------------------------------------------------------------- #
#  Tâches de suivi (CRM-07) — voir taches.py
# --------------------------------------------------------------------------- #
class AjouterUneTache(_Acces, View):
    permission_required = MODIFIER

    def post(self, request, pk):
        from django.contrib.auth import get_user_model
        from django.utils.dateparse import parse_date

        from . import taches

        contact = get_object_or_404(Prospect, pk=pk)
        titre = (request.POST.get("title") or "").strip()
        echeance = parse_date(request.POST.get("due_on") or "")
        if not titre or echeance is None:
            messages.error(request, _("Une tâche a un intitulé et une échéance."))
            return redirect(reverse("jeiko_crm:fiche", args=[pk]) + "#taches")
        responsable = get_user_model().objects.filter(
            pk=request.POST.get("assignee") or 0, is_staff=True, is_active=True).first()
        taches.ajouter(contact, titre, echeance, responsable=responsable, par=request.user)
        messages.success(request, _("Tâche ajoutée."))
        return redirect(reverse("jeiko_crm:fiche", args=[pk]) + "#taches")


class ChangerUneTache(_Acces, View):
    """Terminer, rouvrir ou supprimer une tâche (POST action=…)."""

    permission_required = MODIFIER

    def post(self, request, pk, tache_id):
        from jeiko.questionnaires_expert.models import ContactTask

        from . import taches

        tache = get_object_or_404(ContactTask, pk=tache_id, prospect_id=pk)
        {"terminer": taches.terminer, "rouvrir": taches.rouvrir,
         "supprimer": taches.supprimer}.get(request.POST.get("action"), lambda t: None)(tache)
        return redirect(reverse("jeiko_crm:fiche", args=[pk]) + "#taches")


class BasculerLesRappels(_Acces, View):
    """Le rappel des tâches par e-mail, activé ou non sur cette fiche."""

    permission_required = MODIFIER

    def post(self, request, pk):
        contact = get_object_or_404(Prospect, pk=pk)
        contact.task_reminders = request.POST.get("actif") == "1"
        contact.save(update_fields=["task_reminders", "updated_at"])
        messages.success(request, _("Rappels par e-mail activés.") if contact.task_reminders
                         else _("Rappels par e-mail désactivés."))
        return redirect(reverse("jeiko_crm:fiche", args=[pk]) + "#taches")


# --------------------------------------------------------------------------- #
#  Prendre un rendez-vous depuis la fiche
# --------------------------------------------------------------------------- #
class RendezVousDuContact(_Acces, View):
    """
    Un rendez-vous pour ce contact, rattaché à sa fiche par son adresse — et à
    son compte s'il en a un. Confirmé d'emblée ; la confirmation part au
    contact si on le demande. Le rendez-vous rejoint l'agenda Google du
    praticien comme tout autre (signal de `calendars`).
    """

    permission_required = (VOIR, "calendars.add_appointment")
    template_name = "crm/admin/rendez_vous.html"

    def _formulaire(self, request, data=None):
        from jeiko.calendars.mixins import is_calendar_supervisor

        from .forms import RendezVousDuContactForm
        return RendezVousDuContactForm(data, gestionnaire=request.user,
                                       superviseur=is_calendar_supervisor(request.user))

    def get(self, request, pk):
        contact = get_object_or_404(Prospect, pk=pk)
        return render(request, self.template_name, {"contact": contact, "form": self._formulaire(request)})

    def post(self, request, pk):
        from datetime import datetime

        from django.db import transaction

        from jeiko.calendars.models import Appointment, Slot, recalculer_les_creneaux
        from jeiko.calendars.views import send_booking_emails_safe

        contact = get_object_or_404(Prospect, pk=pk)
        form = self._formulaire(request, request.POST)
        if not form.is_valid():
            return render(request, self.template_name, {"contact": contact, "form": form})
        d = form.cleaned_data
        comptes = historique.comptes_lies(contact)
        commun = dict(
            user_id=min(comptes) if comptes else None,
            email=contact.email or "", client_name=contact.nom_complet,
            phone=(contact.phone or "")[:30], company=contact.company, job_title=contact.job_title,
            message=d.get("message") or "", places=1, status=Appointment.Status.CONFIRMED,
        )
        with transaction.atomic():
            if d["mode"] == "creneau":
                slot = Slot.objects.select_for_update().select_related("type", "availability").get(pk=d["slot"].pk)
                if not slot.is_available or slot.remaining_places < 1:
                    form.add_error("slot", _("Ce créneau vient d'être pris : choisissez-en un autre."))
                    return render(request, self.template_name, {"contact": contact, "form": form})
                rdv = Appointment.objects.create(type=slot.type, slot=slot, start=slot.start, end=slot.end, **commun)
                slot.sync_remaining_places()
                slot.availability.update_slots_availability()
            else:
                debut = timezone.make_aware(datetime.combine(d["date"], d["heure"]))
                rdv = Appointment.objects.create(type=d["type"], start=debut,
                                                 end=debut + d["type"].duration, **commun)
                recalculer_les_creneaux(d["type"].user_id, rdv.start, rdv.end)
            if d.get("envoyer"):
                transaction.on_commit(lambda pk=rdv.pk: send_booking_emails_safe(pk))
        messages.success(request, _("Rendez-vous du %(date)s créé pour %(nom)s.") % {
            "date": f"{timezone.localtime(rdv.start):%d/%m/%Y %H:%M}", "nom": contact.nom_complet})
        return redirect("jeiko_crm:fiche", pk=pk)



# --------------------------------------------------------------------------- #
#  Entreprises (CRM-06)
# --------------------------------------------------------------------------- #
def _entreprise():
    from jeiko.questionnaires_expert.models import Company
    return Company


@method_decorator(never_cache, name="dispatch")
class ListeDesEntreprises(_Acces, ListeRechercheeEtPaginee, ListView):
    permission_required = VOIR
    template_name = "crm/admin/entreprises.html"
    context_object_name = "entreprises"
    champs_de_recherche = ("name", "city", "email", "phone", "siret")

    def get_queryset(self):
        from django.db.models import Count
        return self.rechercher(_entreprise().objects.annotate(nb_contacts=Count("contacts")))


@method_decorator(never_cache, name="dispatch")
class FicheEntreprise(_Acces, DetailView):
    permission_required = VOIR
    template_name = "crm/admin/entreprise.html"
    context_object_name = "entreprise"

    def get_queryset(self):
        return _entreprise().objects.all()

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["contacts"] = self.object.contacts.select_related("owner").order_by("lastname", "firstname")
        return ctx


class _EditionEntreprise(_Acces):
    template_name = "crm/admin/entreprise_formulaire.html"
    context_object_name = "entreprise"

    def get_form_class(self):
        from .forms import EntrepriseForm
        return EntrepriseForm

    def get_queryset(self):
        return _entreprise().objects.all()

    def get_success_url(self):
        return reverse("jeiko_crm:entreprise", args=[self.object.pk])


@method_decorator(never_cache, name="dispatch")
class NouvelleEntreprise(_EditionEntreprise, CreateView):
    permission_required = AJOUTER


@method_decorator(never_cache, name="dispatch")
class ModifierLEntreprise(_EditionEntreprise, UpdateView):
    permission_required = MODIFIER

    def form_valid(self, form):
        reponse = super().form_valid(form)
        # Le nom suit sur le texte « Société » de ses contacts.
        self.object.contacts.update(company=self.object.name)
        return reponse


class SupprimerLEntreprise(_Acces, View):
    """Supprime l'entreprise ; ses contacts restent, sans entreprise."""
    permission_required = SUPPRIMER

    def post(self, request, pk):
        entreprise = get_object_or_404(_entreprise(), pk=pk)
        entreprise.delete()
        messages.success(request, _("Entreprise supprimée ; ses contacts sont conservés."))
        return redirect("jeiko_crm:entreprises")


class RattacherUnContact(_Acces, View):
    """Rattacher un contact existant (par son adresse) à l'entreprise, ou l'en détacher."""
    permission_required = MODIFIER

    def post(self, request, pk):
        entreprise = get_object_or_404(_entreprise(), pk=pk)
        if request.POST.get("detacher", "").isdigit():
            Prospect.objects.filter(pk=request.POST["detacher"], entreprise=entreprise).update(entreprise=None)
            return redirect("jeiko_crm:entreprise", pk=pk)
        email = (request.POST.get("email") or "").strip()
        contact = Prospect.objects.filter(email__iexact=email).order_by("id").first() if email else None
        if contact is None:
            messages.error(request, _("Aucun contact avec cette adresse : créez-le avec « Ajouter une personne »."))
        else:
            contact.entreprise, contact.company = entreprise, entreprise.name
            contact.save(update_fields=["entreprise", "company", "updated_at"])
            messages.success(request, _("%(nom)s rattaché(e) à l'entreprise.") % {"nom": contact.nom_complet})
        return redirect("jeiko_crm:entreprise", pk=pk)
