"""
Les tâches de suivi d'un contact (CRM-07, 04/10/2026).

Une fiche portait UNE prochaine action. Guillaume en veut plusieurs, avec un
rappel par e-mail qu'il active contact par contact.

La source est `ContactTask`. Les champs `next_action` / `next_action_on` de
la fiche restent, recalculés à chaque changement (`refleter`) : la tâche
ouverte la plus proche. C'est ce que lisent la liste « À relancer », l'export
CSV et l'API des agents — ils n'ont pas eu à changer.

Le rappel : le jour de l'échéance (ou au premier passage après, si la tâche
est en retard), une seule fois, au responsable de la tâche — à défaut celui
de la fiche, à défaut son auteur. La tâche quotidienne l'envoie
(`administration/management/commands/cron_24h.py`).
"""

import logging

from django.db import transaction
from django.urls import reverse
from django.utils import timezone

logger = logging.getLogger(__name__)


def _modeles():
    from jeiko.questionnaires_expert.models import ContactTask, Prospect
    return ContactTask, Prospect


def ouvertes(contact):
    ContactTask, _ = _modeles()
    return ContactTask.objects.filter(prospect=contact, done_at__isnull=True).order_by("due_on", "id")


def refleter(contact):
    """La prochaine action de la fiche = la tâche ouverte la plus proche."""
    premiere = ouvertes(contact).first()
    contact.next_action_on = premiere.due_on if premiere else None
    contact.next_action = premiere.title if premiere else ""
    contact.save(update_fields=["next_action_on", "next_action", "updated_at"])


@transaction.atomic
def ajouter(contact, titre, echeance, responsable=None, par=None):
    ContactTask, _ = _modeles()
    tache = ContactTask.objects.create(
        prospect=contact, title=titre.strip()[:200], due_on=echeance,
        assignee=responsable or contact.owner, created_by=par,
    )
    refleter(contact)
    return tache


@transaction.atomic
def terminer(tache):
    tache.done_at = timezone.now()
    tache.save(update_fields=["done_at"])
    refleter(tache.prospect)


@transaction.atomic
def rouvrir(tache):
    tache.done_at = None
    tache.save(update_fields=["done_at"])
    refleter(tache.prospect)


@transaction.atomic
def supprimer(tache):
    contact = tache.prospect
    tache.delete()
    refleter(contact)


def destinataire(tache):
    for compte in (tache.assignee, tache.prospect.owner, tache.created_by):
        if compte is not None and compte.is_active and compte.email:
            return compte
    return None


def envoyer_les_rappels():
    """Les rappels du jour. Retourne le nombre d'e-mails partis."""
    from jeiko.emailing.render import site_base_url
    from jeiko.emailing.services import send_email

    ContactTask, _ = _modeles()
    aujourdhui = timezone.localdate()
    a_rappeler = (ContactTask.objects
                  .filter(done_at__isnull=True, due_on__lte=aujourdhui, reminded_on__isnull=True,
                          prospect__task_reminders=True)
                  .select_related("prospect", "assignee", "prospect__owner", "created_by"))
    partis = 0
    for tache in a_rappeler:
        compte = destinataire(tache)
        if compte is None:
            continue
        contact = tache.prospect
        lien = (site_base_url() or "") + reverse("jeiko_crm:fiche", args=[contact.pk])
        try:
            ok, _motif = send_email("crm_task_reminder", compte.email, {
                "prenom": compte.first_name or "",
                "tache": tache.title,
                "echeance": tache.due_on.strftime("%d/%m/%Y"),
                "contact_nom": contact.nom_complet,
                "lien_action": lien,
            }, user=compte)
        except Exception:
            logger.exception("Rappel de la tâche %s impossible", tache.pk)
            continue
        if ok:
            tache.reminded_on = aujourdhui
            tache.save(update_fields=["reminded_on"])
            partis += 1
    return partis
