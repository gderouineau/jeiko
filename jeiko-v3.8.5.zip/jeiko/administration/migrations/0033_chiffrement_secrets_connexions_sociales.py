"""
Fable 1 §1.5 — chiffrement des secrets des connexions sociales et de la clé
PageSpeed déjà enregistrés, et retrait de leur copie en clair chez allauth.

Les champs deviennent chiffrés ; les valeurs déjà en base restent lisibles
(le champ rend tel quel ce qu'il ne sait pas déchiffrer) mais demeurent EN
CLAIR tant qu'on ne les réécrit pas. La reprise les réécrit — comme
`calendars/0017` pour les clés Google Agenda.

`sync_to_allauth` recopiait aussi le secret et la clé privée Apple dans
`socialaccount_socialapp`, en clair. Ils y sont effacés : c'est désormais
`JeikoSocialAccountAdapter` qui les fournit à allauth, en mémoire.

La marche arrière rend les colonnes en clair et ne recopie rien chez allauth :
réenregistrer l'écran Connexions sociales resynchronise.
"""

import jeiko.encrypted
from django.db import migrations


def chiffrer(apps, schema_editor):
    SocialProvider = apps.get_model("administration", "SocialProvider")
    GoogleApi = apps.get_model("administration", "GoogleApi")
    for config in SocialProvider.objects.all():
        # `update_fields` : `updated_at` (auto_now) date la dernière saisie.
        config.save(update_fields=["secret", "certificate_key"])
    for config in GoogleApi.objects.all():
        config.save(update_fields=["psi_api_key"])

    SocialApp = apps.get_model("socialaccount", "SocialApp")
    fournisseurs = set(SocialProvider.objects.values_list("provider", flat=True))
    for app in SocialApp.objects.filter(provider__in=fournisseurs):
        reglages = dict(app.settings or {})
        reglages.pop("certificate_key", None)
        app.secret = ""
        app.settings = reglages
        app.save(update_fields=["secret", "settings"])


def dechiffrer(apps, schema_editor):
    """Réécrit les valeurs en clair, en SQL : l'ORM les rechiffrerait."""
    for modele, champs in (
        ("SocialProvider", ("secret", "certificate_key")),
        ("GoogleApi", ("psi_api_key",)),
    ):
        Modele = apps.get_model("administration", modele)
        table = Modele._meta.db_table
        with schema_editor.connection.cursor() as curseur:
            for objet in Modele.objects.all():
                for champ in champs:
                    curseur.execute(
                        f"UPDATE {table} SET {champ} = %s WHERE id = %s",
                        [getattr(objet, champ) or "", objet.pk],
                    )


class Migration(migrations.Migration):

    dependencies = [
        ('administration', '0032_website_css_global'),
        ('socialaccount', '0006_alter_socialaccount_extra_data'),
    ]

    operations = [
        migrations.AlterField(
            model_name='googleapi',
            name='psi_api_key',
            field=jeiko.encrypted.EncryptedCharField(blank=True, default='', max_length=300, verbose_name='PageSpeed Insights API key'),
        ),
        migrations.AlterField(
            model_name='socialprovider',
            name='certificate_key',
            field=jeiko.encrypted.EncryptedTextField(blank=True, default='', help_text='Apple uniquement : contenu du fichier .p8 (clé privée).', verbose_name='Clé privée (.p8)'),
        ),
        migrations.AlterField(
            model_name='socialprovider',
            name='secret',
            field=jeiko.encrypted.EncryptedCharField(blank=True, default='', help_text='Google/Facebook : Client Secret. Apple : Key ID.', max_length=500, verbose_name='Client Secret'),
        ),
        migrations.RunPython(chiffrer, dechiffrer),
    ]
