"""
Un nom et un segment d'adresse, traduits EN PLACE.

Le besoin
---------
Une fiche a une version par langue (`jeiko/langues_du_site.py`). Mais son
adresse porte aussi ce qui la range : le slug de son modèle
(`/co/article/le-pain/`) ou, pour un produit, le code de son type
(`/shop/ateliers/atelier-1/`). Restés d'origine, ils donnaient
`/en/co/article/bread/` et `/en/shop/ateliers/…` : une adresse anglaise à
moitié.

Un modèle de fiche et un type de produit ne se dupliquent pas par langue — un
type porte la TVA, la nature, l'expédition ; il n'y en a qu'un. Ils gardent
leur nom et leur segment d'origine, et rangent leurs traductions dans un champ
JSON, exactement comme une catégorie (`Category.traductions`) :

    {"en": {"name": "Workshops", "slug": "workshops"}}

Une langue absente retombe sur le nom et le segment d'origine : rien ne
change tant qu'on n'a rien traduit.

Ce que ce module ne fait pas
----------------------------
* Il ne sert pas aux catégories : elles ont leurs propres règles d'unicité
  (entre sœurs, slugs réservés à la racine) et gardent leur code.
* Il ne redirige rien : c'est la vue qui, par son contrôle canonique, envoie
  l'ancienne adresse (`/en/co/article/…`) vers la nouvelle.
"""

from django.core.exceptions import ValidationError
from django.db import models
from django.utils.translation import gettext_lazy as _


class NomEtAdresseParLangue(models.Model):
    traductions = models.JSONField(default=dict, blank=True)

    #: Le champ qui porte le segment d'adresse d'origine : `slug` pour un
    #: modèle de fiche, `code` pour un type de produit. Dans le JSON, il se
    #: range toujours sous « slug ».
    champ_d_adresse = "slug"

    class Meta:
        abstract = True

    def _traduit(self, langue, cle):
        return ((self.traductions or {}).get(langue) or {}).get(cle)

    def slug_pour(self, langue):
        """Le segment d'adresse dans cette langue ; celui d'origine si elle n'est pas traduite."""
        return self._traduit(langue, "slug") or getattr(self, self.champ_d_adresse)

    def nom_pour(self, langue):
        return self._traduit(langue, "name") or self.name

    @classmethod
    def par_adresse(cls, segment, langue=""):
        """
        Ce que `segment` désigne pour un lecteur de `langue`, dans l'ordre :
        l'objet dont c'est le segment TRADUIT, puis celui dont c'est le
        segment d'origine — non traduit, il sert aussi dans cette langue ;
        traduit depuis, la vue redirige vers la nouvelle adresse.
        """
        trouves = []
        if langue:
            trouves += list(cls.objects.filter(**{f"traductions__{langue}__slug": segment})[:1])
        trouves += [
            objet for objet in cls.objects.filter(**{cls.champ_d_adresse: segment})[:1]
            if objet not in trouves
        ]
        return trouves

    def verifier_les_traductions(self):
        """
        Dans une langue, un segment d'adresse désigne UN seul objet. Lève une
        `ValidationError` générale — et non par champ : `traductions` n'est
        pas un champ de formulaire.

        « Dans les deux sens », comme pour les catégories : le segment traduit
        de celui-ci contre celui (traduit ou non) des autres, ET son segment
        d'origine contre le segment traduit d'un autre. « Ateliers » nommé
        « workshops » en anglais et un type « workshops » se retrouveraient
        tous deux en /en/shop/workshops/.
        """
        autres = list(type(self).objects.exclude(pk=self.pk))
        codes = set(self.traductions or {})
        for autre in autres:
            codes |= set(autre.traductions or {})
        for code in sorted(codes):
            segment = self.slug_pour(code)
            for autre in autres:
                # Deux segments d'origine identiques : c'est l'unicité du champ qui le refuse.
                if autre.slug_pour(code) == segment and (
                        self._traduit(code, "slug") or autre._traduit(code, "slug")):
                    raise ValidationError(
                        _("L'adresse « %(slug)s » est déjà prise dans cette langue.")
                        % {"slug": segment})
