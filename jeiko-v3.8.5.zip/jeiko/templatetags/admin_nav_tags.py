"""Expose la navigation de l'administration au gabarit du menu."""

from django import template

from jeiko.administration.admin_nav import build_nav, onglets_de_la_page

register = template.Library()


@register.simple_tag(takes_context=True)
def admin_nav(context):
    """Sections visibles par l'utilisateur courant, état actif résolu.

    Usage : ``{% admin_nav as sections %}`` puis une boucle. Toute la logique
    (permissions, résolution d'URL, surbrillance) vit dans `admin_nav.py` ; le
    gabarit ne fait que dessiner.
    """
    request = context.get("request")
    if request is None or not getattr(request, "user", None):
        return []
    match = getattr(request, "resolver_match", None)
    return build_nav(
        request.user,
        match.view_name if match else "",
        request.path,
    )


@register.simple_tag(takes_context=True)
def onglets_admin(context):
    """La barre d'onglets de l'écran courant (voir `onglets_de_la_page`), ou None."""
    request = context.get("request")
    if request is None or not getattr(request, "user", None):
        return None
    match = getattr(request, "resolver_match", None)
    return onglets_de_la_page(request.user, match.view_name if match else "")
