"""
Filtres de rendu HTML des contenus.

`html_unescape` faisait auparavant :

    mark_safe(html.unescape(value or ""))

soit exactement l'inverse d'une protection : il ré-activait du HTML qui avait
déjà été neutralisé. `&lt;script&gt;alert(1)&lt;/script&gt;` ressortait en
`<script>alert(1)</script>`, exécuté chez tous les visiteurs — administrateurs
compris, donc avec vol de session à la clé.

Le dé-échappement reste nécessaire (les contenus sont stockés échappés par
l'éditeur), mais il est désormais suivi d'un assainissement par liste blanche.
Voir jeiko/sanitize.py pour la liste des balises et attributs autorisés, et le
réglage JEIKO_SANITIZE_HTML.
"""

import html
import re

from django import template
from django.utils.safestring import SafeData, mark_safe

from jeiko.sanitize import clean_html

register = template.Library()

# Un contenu Quill est toujours découpé en blocs (`<p>`, `<h1>`…`<h6>`, `<ul>`,
# `<blockquote>`…). Ce motif détecte un tel début de bloc pour savoir si le
# contenu porte déjà sa propre structure.
_BLOCK_START_RE = re.compile(
    r"^\s*<(?:h[1-6]|p|ul|ol|li|dl|blockquote|pre|figure|table|div|hr|section|article)\b",
    re.IGNORECASE,
)


#: Une vraie balise : `<` suivi d'une lettre ou d'une barre.
_UNE_BALISE = re.compile(r"<[A-Za-z/!]")


@register.filter
def html_unescape(value):
    """
    Restitue le HTML stocké, après assainissement.

    La mise en forme est conservée ; `<script>`, les attributs `on*` et les URL
    `javascript:` sont retirés.

    On ne déséchappe QUE les contenus anciens, stockés entièrement échappés
    (`&lt;p&gt;Bonjour&lt;/p&gt;`) : ceux-là ne contiennent aucune vraie balise.
    Un contenu en HTML réel — tout ce qu'écrivent l'éditeur et l'API — garde
    ses échappements. Avant le 28/09/2026, tout était déséchappé : un texte qui
    MONTRAIT une balise (`Un &lt;a&gt; ne peut pas…`) en fabriquait une vraie.
    Relevé sur jeiko.fr : un `&lt;p&gt;` dans un cadre de code ouvrait un
    paragraphe au milieu, et la fin du cadre s'affichait en texte sombre sur
    fond sombre.
    """
    valeur = value or ""
    if not _UNE_BALISE.search(valeur):
        valeur = html.unescape(valeur)
    return mark_safe(clean_html(valeur))


@register.filter
def ensure_block(value):
    """
    Garantit que le contenu texte porte un élément de bloc de premier niveau.

    L'éditeur Quill enveloppe déjà chaque ligne dans un bloc (`<p>`, `<h1>`…
    `<h6>`, `<ul>`, `<blockquote>`…) : dans ce cas on renvoie le contenu tel
    quel, pour laisser les titres remonter comme vrais `<h1>`…`<h6>` (bon pour
    le référencement) au lieu d'être enfermés dans un `<p>` — imbrication HTML
    invalide qui cassait la sémantique.

    Seul un contenu hérité stocké en texte brut (avant Quill) n'a pas de bloc :
    on l'enveloppe alors dans un `<p>` pour qu'il garde la police du corps de
    texte (`.content p`).
    """
    if not value:
        return value
    if _BLOCK_START_RE.match(str(value)):
        return value
    return mark_safe("<p>" + str(value) + "</p>")


@register.filter
def images_adaptatives(value):
    """
    Donne aux images d'un texte les tailles de la médiathèque (`srcset`).

    Voir `administration_pages/images_adaptatives.py`. Un contenu qui n'est pas
    déjà du HTML de confiance est rendu tel quel : ce filtre ajoute des
    attributs, il n'a pas à décider de ce qui est sûr.
    """
    if not value or not isinstance(value, SafeData):
        return value
    from jeiko.administration_pages.images_adaptatives import enrichir

    return mark_safe(enrichir(str(value)))


@register.filter
def liens_dans_la_langue(value):
    """
    Fait suivre la langue du lecteur aux liens internes d'un texte.

    Voir `administration_pages/liens_internes.py`. Sans effet pour un lecteur
    de la langue d'origine, et sur ce qui n'est pas du HTML de confiance.
    """
    if not value or not isinstance(value, SafeData):
        return value
    from jeiko.administration_pages.liens_internes import suivre_la_langue

    return mark_safe(suivre_la_langue(str(value)))


@register.filter
def sanitize_html(value):
    """
    Assainit du HTML BRUT (déjà stocké tel quel, non échappé) avant rendu.

    À utiliser à la place de `|safe` sur un contenu éditable : la mise en forme
    est conservée mais `<script>`, les attributs `on*` et les URL `javascript:`
    sont retirés (liste blanche, cf. jeiko/sanitize.py).
    """
    return mark_safe(clean_html(value or ""))


#: Balises qu'un titre de bloc peut prendre.
BALISES_DE_TITRE = ("h1", "h2", "h3", "h4", "h5", "h6", "p", "div")


@register.filter
def balise_sure(valeur, defaut="h2"):
    """
    Un nom de balise de titre lu dans les options d'un bloc, ou `defaut`.

    La FAQ écrivait `<{{ …main_title_tag|safe }}>` : une valeur absente
    affichait « <> » sur la page, et n'importe quelle chaîne écrite dans les
    options — par l'administration ou par l'API — devenait une balise HTML.
    """
    valeur = str(valeur or "").strip().lower()
    return valeur if valeur in BALISES_DE_TITRE else defaut



@register.filter
def icone(code):
    """L'icône de bouton `code`, dessinée en SVG (voir jeiko/icones.py)."""
    from jeiko.icones import svg

    return svg(code)
