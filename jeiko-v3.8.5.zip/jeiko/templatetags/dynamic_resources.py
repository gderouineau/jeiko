from django import template
from django.db.models import QuerySet

# Imports wrapped in try/except to avoid hard errors if apps are missing/changed
try:
    from jeiko.shop.models import Product
except ImportError:
    Product = None

try:
    from jeiko.custom_objects.models import CustomObject
except ImportError:
    CustomObject = None

try:
    from jeiko.administration_pages.models import Page
    from jeiko.administration_pages.querysets import public_pages
except ImportError:
    Page = None
    public_pages = None

try:
    from jeiko.questionnaires_expert.models import ExpertTest
except ImportError:
    ExpertTest = None

register = template.Library()

@register.simple_tag
def get_resources(config):
    """
    Fetches resources based on DynResourceConfig.
    Returns a QuerySet or list of objects.

    Le rendu d'une grille est gardé en cache avec le corps de sa page : ce
    qu'elle liste et ce que ses cartes montrent doit figurer dans
    `page_cache.RESOURCE_MODELS`. Ajouter une source ici, ou un champ aux
    cartes, sans compléter cette liste laisse la grille figée sept jours.
    """
    if not config:
        return []

    qs = []

    if config.source_type == 'PRODUCT' and Product:
        # La fiche n'est publiable que si le produit est en vente ET que son
        # CustomObject est publié : mêmes conditions que ProductView.
        qs = (
            Product.objects
            .filter(is_active=True, content__is_published=True)
            .select_related("type", "content", "content__main_image")
            .prefetch_related("categories", "variants")
        )
        # L'éditeur proposait déjà de filtrer une grille de produits par
        # catégorie ; rien ne filtrait, faute de catégories sur le produit.
        if config.category_id:
            qs = qs.filter(categories=config.category_id)
        if config.sub_category_id:
            qs = qs.filter(categories=config.sub_category_id)

        if config.product_type:
            # Le champ de Product s'appelle `type` : filtrer sur
            # `product_type` levait un FieldError sur tout carrousel ou
            # grille configuré avec un type de produit.
            qs = qs.filter(type=config.product_type)

    elif config.source_type == 'CUSTOM_OBJECT' and CustomObject:
        if config.custom_object_model:
            qs = (
                CustomObject.objects
                # Les fiches d'ORIGINE : leurs versions traduites ne s'ajoutent
                # pas à la grille, elles y remplacent l'originale pour qui lit
                # cette langue (voir plus bas).
                .filter(model=config.custom_object_model, langue="", is_published=True)
                # `product__type` : l'adresse d'une fiche demande si elle
                # porte un produit — une requête par carte, sinon.
                .select_related("model", "main_image", "product__type")
            )


    elif config.source_type == 'PAGE' and Page:
        # public_pages() écarte les gabarits (mail / pdf / objet custom) : une
        # grille de pages ne doit jamais afficher de lien vers /mail_…/ ou une
        # page PDF, qui répondent 404 et rouvriraient une porte de crawl.
        # Les pages d'ORIGINE : leurs versions traduites ne s'ajoutent pas à la
        # grille, elles y remplacent l'originale pour qui lit cette langue.
        base = Page.objects.filter(active=True, langue="")
        qs = public_pages(base) if public_pages else base
        if config.category:
            qs = qs.filter(category=config.category)
        if config.sub_category:
             qs = qs.filter(sub_category=config.sub_category)

    elif config.source_type == 'EXPERT_TEST' and ExpertTest:
         # Assuming ExpertTest has is_active or similar
         qs = ExpertTest.objects.all()
         if hasattr(ExpertTest, 'is_active'):
             qs = qs.filter(is_active=True)

    # Ordre choisi dans l'éditeur. Prix et meilleures ventes n'ont de sens
    # que pour des produits ; les autres sources retombent sur le plus récent.
    ordre = getattr(config, "sort", "") or "recent"
    if config.source_type == 'PRODUCT' and Product and hasattr(qs, 'order_by'):
        from jeiko.shop.catalogue import trier
        qs = trier(qs.distinct(), ordre)
    elif hasattr(qs, 'order_by'):
        if ordre == "oldest":
            qs = qs.order_by('id')
        elif ordre == "name" and config.source_type in ('PAGE', 'CUSTOM_OBJECT'):
            qs = qs.order_by('title', 'id')
        else:
            qs = qs.order_by('-id')

    # Limiting
    if config.limit and isinstance(config.limit, int) and config.limit > 0:
        qs = qs[:config.limit]

    # Site en plusieurs langues : chaque page, chaque fiche se montre dans la
    # version que lit le visiteur — son titre, son image — et l'originale là où
    # elle n'est pas traduite (son lien reste sous le préfixe du lecteur). Un
    # produit reste lui-même : c'est lui qui va chercher la fiche lue
    # (`Product.fiche_lue`).
    if config.source_type in ('PAGE', 'CUSTOM_OBJECT'):
        from jeiko.langues_du_site import langue_du_site, version_lue
        if langue_du_site():
            return [version_lue(element) for element in qs]

    return qs


@register.simple_tag
def categories_des(items):
    """Les catégories présentes parmi des produits — les choix de la barre de filtres."""
    vues = {}
    for item in items:
        categories = getattr(item, "categories", None)
        if categories is None:
            continue
        for categorie in categories.all():
            vues.setdefault(categorie.pk, categorie)
    return sorted(vues.values(), key=lambda c: c.name)
