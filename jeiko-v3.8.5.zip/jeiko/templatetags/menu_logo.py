# jeiko/administration_menu/templatetags/menu_logo.py
from django import template

register = template.Library()

@register.simple_tag
def effective_logo_for_menu(menu=None):
    """
    Retourne l'objet Logo à utiliser :
      - menu.logo si défini,
      - sinon WebSite.logo,
      - sinon None.
    """
    # 1) override du menu
    if menu and getattr(menu, "logo_id", None):
        return menu.logo

    # 2) logo du site
    try:
        from jeiko.administration.models import WebSite
        site = WebSite.objects.select_related('logo').first()
        return getattr(site, 'logo', None)
    except Exception:
        return None


@register.filter
def url_sure(fichier):
    """URL d'un champ fichier, ou chaîne vide s'il n'a pas de fichier.

    `{{ logo.full_size.url|default:'' }}` ne protège de rien : `.url` d'un champ
    vide lève une ValueError AVANT que `default` n'intervienne, et Django ne
    l'avale pas. Un Logo créé sans fichier faisait donc tomber l'écran de
    création de menu en erreur 500 (28/09/2026).
    """
    try:
        return fichier.url if fichier else ""
    except ValueError:
        return ""
