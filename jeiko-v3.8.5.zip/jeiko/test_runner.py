"""
Le lanceur de tests de JEIKO : la suite ne touche ni aux médias du site, ni à
Google.

Ce qui s'est passé
------------------
Le site de test local s'éditait en Playfair Display et s'affichait, côté
public, dans la police de secours. Son fichier de polices locales
(`MEDIA_ROOT/fonts/site-1.css`) était vide — ou portait « EB Garamond », une
police qu'aucun réglage du site ne nomme. C'était la suite de tests (constaté
le 01/10/2026) :

* enregistrer une police reconstruit le fichier du site
  (`fonts_selfhost.rebuild_for_websites`) ; les tests de l'identité le font,
  sur le site de la base de TEST — qui porte le même identifiant que le vrai ;
* la reconstruction écrit dans `MEDIA_ROOT`, que rien ne détournait : donc
  dans les médias du vrai site, dont elle remplaçait le fichier, avant de
  supprimer les dossiers des polices « devenues inutiles » ;
* et elle téléchargeait ces polices chez Google, à chaque passage.

Chaque passage de la suite défaisait donc les polices du site de travail, sans
une erreur. Une douzaine de tests détournent déjà `MEDIA_ROOT` chacun pour soi ;
le défaut venait de ceux qui n'ont aucune raison d'y penser.

Ce que fait ce lanceur
----------------------
Pour TOUTE la durée d'un passage, `MEDIA_ROOT` désigne un dossier temporaire,
supprimé à la fin, et le rapatriement des polices est coupé
(`JEIKO_FONTS_SELFHOST`). Avec `--parallel`, chaque processus de travail relit
les réglages du projet : ils y sont reposés par `preparer_le_processus`.

Ce qu'il ne fait pas
--------------------
Il ne protège que si le projet le désigne : `TEST_RUNNER` dans ses réglages
(le gabarit de l'installeur le fait). Un test de `tests_transversaux` échoue
dans le cas contraire, plutôt que de laisser le défaut revenir en silence.
"""

import os
import shutil
import tempfile

from django.conf import settings
from django.test.runner import DiscoverRunner, ParallelTestSuite
from django.test.utils import override_settings

#: Le dossier temporaire, transmis aux processus de travail par l'environnement
#: — la seule chose qu'un processus lancé par `spawn` hérite de son parent.
VARIABLE = "JEIKO_TESTS_MEDIA_ROOT"

#: Ce qui reconnaît le dossier, pour le test qui vérifie que la suite est isolée.
PREFIXE = "jeiko-tests-medias-"


def preparer_le_processus(*_):
    """
    Dans un processus de travail, avant `django.setup()` : repose les deux
    réglages que le processus parent a détournés. Une fonction de module, et
    non une méthode : `multiprocessing` doit pouvoir la retrouver par son nom.
    """
    chemin = os.environ.get(VARIABLE)
    if chemin:
        settings.MEDIA_ROOT = chemin
        settings.JEIKO_FONTS_SELFHOST = False


class SuiteParallele(ParallelTestSuite):
    process_setup = preparer_le_processus


class LanceurDeTests(DiscoverRunner):
    parallel_test_suite = SuiteParallele

    def setup_test_environment(self, **kwargs):
        super().setup_test_environment(**kwargs)
        self._medias = tempfile.mkdtemp(prefix=PREFIXE)
        os.environ[VARIABLE] = self._medias
        self._reglages = override_settings(MEDIA_ROOT=self._medias, JEIKO_FONTS_SELFHOST=False)
        self._reglages.enable()

    def teardown_test_environment(self, **kwargs):
        self._reglages.disable()
        os.environ.pop(VARIABLE, None)
        shutil.rmtree(self._medias, ignore_errors=True)
        super().teardown_test_environment(**kwargs)
