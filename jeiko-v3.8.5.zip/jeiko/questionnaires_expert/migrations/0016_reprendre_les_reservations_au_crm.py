"""
Le CRM arrive REMPLI (décision de Guillaume, 03/10/2026) : une fiche pour
chaque adresse qui a réservé, attendu une place ou écrit par un formulaire de
contact avant son ouverture.

Une adresse qui a déjà sa fiche (un questionnaire, le plus souvent) n'en
reçoit pas une seconde : son historique, lu par l'adresse, y remonte déjà.
Le nom vient de la réservation la plus récente ; la fiche naît à la date de
la première activité. Rien n'est envoyé : les modèles historiques d'une
migration n'émettent pas les signaux qui préviennent l'administrateur.
"""
import random
import string

from django.db import migrations
from django.utils.text import slugify


def _slug(Prospect, nom):
    base = slugify(nom)[:80].strip("-") or "contact"
    while True:
        suffixe = "".join(random.choices(string.ascii_lowercase + string.digits, k=6))
        slug = f"{base}-{suffixe}"
        if not Prospect.objects.filter(slug=slug).exists():
            return slug


def reprendre(apps, schema_editor):
    Prospect = apps.get_model("questionnaires_expert", "Prospect")
    Appointment = apps.get_model("calendars", "Appointment")
    WaitlistEntry = apps.get_model("calendars", "WaitlistEntry")
    ContentFormField = apps.get_model("administration_pages", "ContentFormField")
    ContentFormSubmission = apps.get_model("administration_pages", "ContentFormSubmission")

    connues = {e.lower() for e in Prospect.objects.exclude(email="").values_list("email", flat=True)}
    vues = {}  # adresse → {nom, telephone, societe, fonction, origine, date}

    def noter(email, date, origine, nom="", telephone="", societe="", fonction=""):
        email = (email or "").strip().lower()
        if not email or "@" not in email or email in connues:
            return
        fiche = vues.setdefault(email, {"date": date, "origine": origine, "nom": "", "telephone": "",
                                        "societe": "", "fonction": "", "recente": None})
        if date and (fiche["date"] is None or date < fiche["date"]):
            fiche["date"], fiche["origine"] = date, origine
        # Les coordonnées de l'entrée la plus récente l'emportent.
        if date and (fiche["recente"] is None or date >= fiche["recente"]):
            fiche["recente"] = date
            for cle, valeur in (("nom", nom), ("telephone", telephone),
                                ("societe", societe), ("fonction", fonction)):
                if valeur:
                    fiche[cle] = valeur

    for r in Appointment.objects.exclude(email="").iterator():
        noter(r.email, r.created, "rendez_vous", r.client_name, r.phone, r.company, r.job_title)
    for w in WaitlistEntry.objects.exclude(email="").iterator():
        noter(w.email, w.created, "rendez_vous", w.client_name, w.phone, w.company, w.job_title)
    champs_email = {}
    for formulaire_id, nom in ContentFormField.objects.filter(type="email").values_list("formulaire_id", "name"):
        champs_email.setdefault(formulaire_id, []).append(nom)
    for envoi in ContentFormSubmission.objects.filter(formulaire_id__in=champs_email).iterator():
        for nom in champs_email[envoi.formulaire_id]:
            noter((envoi.data or {}).get(nom), envoi.submitted_at, "formulaire")

    for email, f in vues.items():
        morceaux = (f["nom"] or "").split()
        prenom = morceaux[0][:200] if morceaux else ""
        nom = " ".join(morceaux[1:])[:200]
        fiche = Prospect.objects.create(
            email=email[:200], firstname=prenom, lastname=nom,
            phone=(f["telephone"] or "")[:20], company=(f["societe"] or "")[:200],
            job_title=(f["fonction"] or "")[:200], origin=f["origine"],
            slug=_slug(Prospect, f"{prenom}-{nom}"),
        )
        if f["date"]:
            Prospect.objects.filter(pk=fiche.pk).update(date_created=f["date"])


class Migration(migrations.Migration):
    dependencies = [
        ("questionnaires_expert", "0015_contact_du_crm"),
        ("calendars", "0019_champs_demandes_a_la_reservation"),
        ("administration_pages", "0071_champ_de_formulaire_nomme_comme_le_leurre"),
    ]
    operations = [migrations.RunPython(reprendre, migrations.RunPython.noop)]
