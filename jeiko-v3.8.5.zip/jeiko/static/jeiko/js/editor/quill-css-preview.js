import {tr} from './textes.js';
/** E-07 : aperçu du brouillon CSS dans le contenu isolé uniquement.
 * Le serveur réutilise le formulaire et le gabarit publics, sans sauvegarde.
 * L'échec d'un aperçu ne modifie ni le CSS précédent ni les champs saisis.
 */
export function brancherApercuCssQuill(form, contexte, editorEl) {
    const url = form?.dataset.quillCssPreview;
    if (!url) return;
    const prefix = 'customcss_bloc_-';
    const classe = form.elements.namedItem(prefix + 'object_classes');
    let classesActuelles = String(classe?.value || '').split(/\s+/).filter(Boolean);
    let timer, controller, sequence = 0;
    const message = document.createElement('p');
    message.setAttribute('role', 'status');
    message.hidden = true;
    editorEl.before(message);

    async function actualiser() {
        if (!form.isConnected) return;
        controller?.abort();
        controller = new AbortController();
        const numero = ++sequence;
        const data = new FormData();
        for (const field of form.elements) {
            if (field.name?.startsWith(prefix) || field.name === 'csrfmiddlewaretoken') data.append(field.name, field.value);
        }
        try {
            const response = await fetch(url, {method:'POST', body:data, signal:controller.signal, headers:{'X-Requested-With':'XMLHttpRequest'}});
            if (numero !== sequence || !form.isConnected) return;
            if (!response.headers.get('Content-Type')?.includes('application/json')) throw new Error(tr("Réponse HTTP %(statut)s, fermez puis réouvrez le bloc.", { statut: response.status }));
            const result = await response.json();
            if (!response.ok || result.status !== 'ok') throw new Error(result.message || tr("Paramètres CSS invalides."));
            contexte.actualiserCss(result.css, result.classes, classesActuelles);
            classesActuelles = String(result.classes).split(/\s+/).filter(Boolean);
            message.hidden = true;
        } catch (error) {
            if (error.name === 'AbortError' || numero !== sequence || !form.isConnected) return;
            message.textContent = tr("Aperçu CSS non actualisé : %(erreur)s Le brouillon reste dans le formulaire.", { erreur: error.message });
            message.hidden = false;
        }
    }
    function planifier(event) {
        if (!event.target.name?.startsWith(prefix)) return;
        clearTimeout(timer);
        // Invalider immédiatement une requête en vol, pas seulement après
        // le délai : une ancienne réponse ne doit pas remplacer le brouillon.
        controller?.abort();
        sequence++;
        timer = setTimeout(actualiser, 400);
    }
    form.addEventListener('input', planifier);
    form.addEventListener('change', planifier);
    actualiser();
}
