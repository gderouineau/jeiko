// textes.js — les textes de l'éditeur, dans la langue de l'administration.
//
// Les scripts de l'éditeur écrivent leurs messages en français. `base_editor.html`
// pose `window.JK_TEXTES` : un dictionnaire { texte français : traduction },
// vide quand l'administration est en français. `tr()` y cherche le texte et
// retombe sur le français — une traduction manquante n'est jamais un écran vide.
//
// La liste des textes traduisibles vit côté Python
// (`administration_pages/textes_editeur.py`) : c'est elle que lisent les
// catalogues. Un test compare les deux ; ajouter un `tr("…")` ici sans
// l'ajouter là-bas le fait échouer.
//
// Les variables s'écrivent `%(nom)s`, comme dans les catalogues :
//     tr("Supprimer le champ « %(label)s » ?", { label })
export function tr(texte, valeurs) {
    const textes = (typeof globalThis !== "undefined" && globalThis.JK_TEXTES) || {};
    let rendu = textes[texte] || texte;
    for (const [cle, valeur] of Object.entries(valeurs || {})) {
        rendu = rendu.split(`%(${cle})s`).join(String(valeur));
    }
    return rendu;
}
