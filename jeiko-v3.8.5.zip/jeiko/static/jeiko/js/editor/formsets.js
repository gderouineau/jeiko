// static/jeiko/js/formsets.js
(function (w, d) {
  /* =======================
   * Parents (formset principal)
   * ======================= */
  function renumber(prefix, itemSelector){
    const list  = d.getElementById(`${prefix}-list`);
    if (!list) return;
    const items = Array.from(list.querySelectorAll(itemSelector));
    items.forEach((el, i) => {
      const orderInput = el.querySelector('input[name$="-order"], input[name$="-ORDER"]');
      if (orderInput) orderInput.value = i + 1; // 1..n
    });
  }

  function addInline(prefix, itemSelector){
    const total  = d.getElementById(`id_${prefix}-TOTAL_FORMS`);
    const tmplEl = d.getElementById(`tmpl-${prefix}-empty`);
    const wrap   = d.getElementById(`${prefix}-list`);
    if (!total || !tmplEl || !wrap) {
      console.warn('[Formsets.addInline] manquants:', {total: !!total, tmpl: !!tmplEl, wrap: !!wrap, prefix});
      return;
    }
    const idx  = parseInt(total.value || '0', 10);
    const html = tmplEl.innerHTML.replaceAll('__prefix__', idx);
    wrap.insertAdjacentHTML('beforeend', html);
    total.value = idx + 1;
    renumber(prefix, itemSelector);
  }

  function moveUp(btn, prefix, itemSelector){
    const item = btn.closest(itemSelector);
    if (!item || !item.previousElementSibling) return;
    item.parentNode.insertBefore(item, item.previousElementSibling);
    renumber(prefix, itemSelector);
  }

  function moveDown(btn, prefix, itemSelector){
    const item = btn.closest(itemSelector);
    if (!item || !item.nextElementSibling) return;
    item.parentNode.insertBefore(item.nextElementSibling, item);
    renumber(prefix, itemSelector);
  }

  /* =======================
   * Enfants (sous-formsets)
   * Convention : prefix = "xxx-<pk>", éléments dans #<prefix>-list,
   * template #tmpl-<prefix>-empty, management inputs id_<prefix>-*
   * ======================= */
  function renumberChild(prefix, itemSelector){
    const list  = d.getElementById(`${prefix}-list`);
    if (!list) return;
    const items = Array.from(list.querySelectorAll(itemSelector));
    items.forEach((el, i) => {
      const orderInput = el.querySelector('input[name$="-order"], input[name$="-ORDER"]');
      if (orderInput) orderInput.value = i + 1;
    });
  }

  function addInlineChild(prefix, itemSelector){
    const total  = d.getElementById(`id_${prefix}-TOTAL_FORMS`);
    const tmplEl = d.getElementById(`tmpl-${prefix}-empty`);
    const wrap   = d.getElementById(`${prefix}-list`);
    if (!total || !tmplEl || !wrap) {
      console.warn('[Formsets.addInlineChild] manquants:', {total: !!total, tmpl: !!tmplEl, wrap: !!wrap, prefix});
      return;
    }
    const idx  = parseInt(total.value || '0', 10);
    const html = tmplEl.innerHTML.replaceAll('__prefix__', idx);
    wrap.insertAdjacentHTML('beforeend', html);
    total.value = idx + 1;
    renumberChild(prefix, itemSelector);
  }

  function moveChildUp(btn, itemSelector){
    const item = btn.closest(itemSelector);
    if (!item || !item.previousElementSibling) return;
    item.parentNode.insertBefore(item, item.previousElementSibling);
    const listId = item.parentElement && item.parentElement.id; // ex: "accch-12-list"
    if (!listId) return;
    const prefix = listId.replace(/-list$/, '');
    renumberChild(prefix, itemSelector);
  }

  function moveChildDown(btn, itemSelector){
    const item = btn.closest(itemSelector);
    if (!item || !item.nextElementSibling) return;
    item.parentNode.insertBefore(item.nextElementSibling, item);
    const listId = item.parentElement && item.parentElement.id;
    if (!listId) return;
    const prefix = listId.replace(/-list$/, '');
    renumberChild(prefix, itemSelector);
  }

  /* =======================
   * Auto-détection (bouton à l'intérieur d'un scope enfant)
   * ======================= */
  function addInlineChildFromButton(btn, itemSelector){
    const scope = btn.closest('[data-formset-scope]');
    if (!scope) return;
    // management form → ex: id_accch-12-TOTAL_FORMS
    const total = scope.querySelector('input[id$="-TOTAL_FORMS"]');
    if (!total) return;
    const prefix = total.id.replace(/^id_/, '').replace(/-TOTAL_FORMS$/, ''); // "accch-12" (ou autre)
    const tmplEl = d.getElementById(`tmpl-${prefix}-empty`);
    const list   = d.getElementById(`${prefix}-list`);
    if (!tmplEl || !list) return;
    const idx  = parseInt(total.value || '0', 10);
    const html = tmplEl.innerHTML.replaceAll('__prefix__', idx);
    list.insertAdjacentHTML('beforeend', html);
    total.value = idx + 1;
    renumberChild(prefix, itemSelector);
  }

  /* =======================
   * Countdown (countdown & countdown CTA)
   * ======================= */
  const Countdown = (function(){
    function _pad(n){ n = Number(n)||0; return (n<10?'0':'')+n; }
    function _fmtForInput(dt, el){
      if (el && String(el.type).toLowerCase() === 'datetime-local') {
        return dt.getFullYear() + '-' + _pad(dt.getMonth()+1) + '-' + _pad(dt.getDate())
             + 'T' + _pad(dt.getHours()) + ':' + _pad(dt.getMinutes());
      }
      return dt.getFullYear() + '-' + _pad(dt.getMonth()+1) + '-' + _pad(dt.getDate())
           + ' ' + _pad(dt.getHours()) + ':' + _pad(dt.getMinutes());
    }
    function _parseAny(v){
      if(!v) return null;
      let d1 = new Date(v);
      if(!isNaN(d1)) return d1;
      let d2 = new Date(String(v).replace(' ', 'T'));
      return isNaN(d2) ? null : d2;
    }
    function _humanDiff(to){
      if(!to) return '—';
      const now = new Date();
      const ms  = to - now;
      if (ms <= 0) return ((window.JK_TEXTES || {})['Expiré']) || 'Expiré';
      const s = Math.floor(ms/1000);
      const d = Math.floor(s/86400);
      const h = Math.floor((s%86400)/3600);
      const m = Math.floor((s%3600)/60);
      const ss= s%60;
      return `${d} j ${_pad(h)} h ${_pad(m)} m ${_pad(ss)} s`;
    }
    function _findScope(scope){ return scope || d.getElementById('content-edit-form') || d; }
    function _findInput(scope){
      const root = _findScope(scope);
      return root.querySelector('input[name$="-deadline"], input[id$="-deadline"]');
    }
    function _findPreview(scope){
      const root = _findScope(scope);
      return root.querySelector('#cd-preview-text');
    }
    function render(scope){
      const input = _findInput(scope);
      const out   = _findPreview(scope);
      if (!input || !out) return;
      const dt = _parseAny(String(input.value||'').trim());
      out.textContent = _humanDiff(dt);
    }
    function setMinutes(mins, scope){
      const input = _findInput(scope);
      if (!input) { console.warn('[Countdown.setMinutes] input deadline introuvable'); return; }
      const dt = new Date(Date.now() + (Number(mins)||0)*60000);
      input.value = _fmtForInput(dt, input);
      render(scope);
    }
    function clear(scope){
      const input = _findInput(scope);
      if (!input) return;
      input.value = '';
      render(scope);
    }
    function boot(scope){
      const input = _findInput(scope);
      if (!input) return;
      if (!String(input.value||'').trim()){
        input.value = _fmtForInput(new Date(), input);
      }
      input.addEventListener('input', function(){ render(scope); });
      render(scope);
      if (!input._cdPreviewTimer) {
        input._cdPreviewTimer = setInterval(function(){ render(scope); }, 1000);
      }
    }
    return { setMinutes, clear, boot };
  })();

  /* Expose objets */
  w.Formsets = {
    // parents
    addInline, moveUp, moveDown, renumberOrders: renumber,
    // enfants
    addInlineChild, moveChildUp, moveChildDown, renumberChild,
    // auto-détection enfant
    addInlineChildFromButton,
    // countdown
    Countdown
  };

  // Boot countdown automatiquement
  if (d.readyState === 'loading') {
    d.addEventListener('DOMContentLoaded', function(){ Countdown.boot(d); });
  } else {
    Countdown.boot(d);
  }
})(window, document);

/* Wrappers globaux — UN SEUL jeu pour tout l'éditeur (Q-05).
 *
 * Sept écrans de blocs (FAQ, onglets, étapes, stepper, filtre, témoignages ×2)
 * redéfinissaient addInline / moveUp / moveDown / renumberOrders dans leur
 * propre <script>. Chargés dans l'éditeur, ils remplaçaient ces fonctions pour
 * toute la session : après un bloc Onglets, les flèches d'un Carrousel
 * appelaient la version des Onglets — mauvais éléments, aperçu en erreur.
 *
 * Désormais ces fonctions ne se redéfinissent plus. Chaque ajout ou
 * déplacement est ANNONCÉ par l'événement `jeiko:formset` ({prefix, element}),
 * que l'écran écoute pour rafraîchir son aperçu.
 *
 * Les éléments : `.<prefix>-item` quand la liste en contient, sinon les enfants
 * directs de `#<prefix>-list` (les onglets s'appellent `.tab-item`). Un bouton
 * qui n'indique pas son préfixe le tient de la liste qui le contient. */
(function (w, d) {
  function prefixeDe(btn) {
    const liste = btn && btn.closest('[id$="-list"]');
    return liste ? liste.id.replace(/-list$/, '') : '';
  }
  function elements(p, sel) {
    if (sel) return sel;
    const liste = d.getElementById(`${p}-list`);
    return liste && liste.querySelector(`.${p}-item`) ? `.${p}-item` : `#${p}-list > *`;
  }
  function annoncer(prefix, element) {
    d.dispatchEvent(new CustomEvent('jeiko:formset', { detail: { prefix, element } }));
  }
  w.addInline = (p, sel) => {
    w.Formsets.addInline(p, elements(p, sel));
    const liste = d.getElementById(`${p}-list`);
    annoncer(p, liste && liste.lastElementChild);
  };
  w.moveUp = (btn, p, sel) => {
    p = p || prefixeDe(btn);
    w.Formsets.moveUp(btn, p, elements(p, sel));
    annoncer(p, null);
  };
  w.moveDown = (btn, p, sel) => {
    p = p || prefixeDe(btn);
    w.Formsets.moveDown(btn, p, elements(p, sel));
    annoncer(p, null);
  };
  w.renumberOrders = (p, sel) => w.Formsets.renumberOrders(p, elements(p, sel));
})(window, document);

window.addInlineChild   = (prefix)         => Formsets.addInlineChild(prefix, '.plf-item'); // (pricing features)
window.moveFeatUp       = (btn)            => Formsets.moveChildUp(btn, '.plf-item');
window.moveFeatDown     = (btn)            => Formsets.moveChildDown(btn, '.plf-item');
window.renumberFeatures = (prefix)         => Formsets.renumberChild(prefix, '.plf-item');

/* Accordéon avancé (enfants) */
window.addAccChild      = (btn)            => Formsets.addInlineChildFromButton(btn, '.acc-child');
window.moveAccChildUp   = (btn)            => Formsets.moveChildUp(btn, '.acc-child');
window.moveAccChildDown = (btn)            => Formsets.moveChildDown(btn, '.acc-child');

/* Countdown boutons */
window.cdSetMinutes     = (mins, scope)    => Formsets.Countdown.setMinutes(mins, scope);
window.cdClear          = (scope)          => Formsets.Countdown.clear(scope);
