import {tr} from './textes.js';
/** E-07 : reprendre les vrais sélecteurs dans un document distinct.
 * Aucun CSS du site n'entre dans l'habillage de la modale. Le document ne
 * reçoit qu'une copie du contexte public, les feuilles de contenu et Quill,
 * jamais les scripts ou contrôles de la page.
 *
 * Ce que montre ce document : LE BLOC QU'ON ÉDITE, et lui seul, sur toute la
 * fenêtre d'édition. Avec le style global du site et le CSS de sa section, de
 * sa ligne et le sien — polices, couleurs, fonds, espacements du texte. Sans
 * la mise en page : ni colonnes, ni marges de section. On écrit un texte ; où
 * il se place sur la page, c'est la page qui le montre.
 */
// Sous cette hauteur, on n'écrit plus : le cadre ne descend jamais plus bas,
// quitte à faire défiler la modale.
const HAUTEUR_MINIMALE = 300;
// L'air laissé autour du bloc, en pixels : un texte collé au bord du cadre se
// lit mal, et le fond de sa section doit rester visible autour de lui.
const MARGE = 16;
// Ce qui tient un élément à l'écart des bords de son parent.
const BORD_A_BORD = {
    margin: '0', padding: '0', border: '0', width: '100%', 'max-width': 'none',
    'min-width': '0', height: 'auto', 'min-height': '0', 'max-height': 'none',
};

/** Les libellés que Quill écrit par CSS, dans la langue de l'administration.
 *
 * Sa feuille les donne en anglais — `content: 'Heading 1'`, « Visit URL: » —
 * et rien ne les atteint : ni gabarit, ni dictionnaire. On repose donc les
 * mêmes sélecteurs, après elle, avec les nôtres. Ne sont repris que les
 * libellés que cet éditeur montre : titres, tailles, bulle de lien.
 */
export function libellesDeQuill() {
    const regle = (selecteur, texte, pseudo = 'before') => `${selecteur}::${pseudo}{content:${JSON.stringify(texte)}}`;
    const choix = (liste, valeur, texte) => ['label', 'item'].map(quoi => regle(
        `.ql-snow .ql-picker.ql-${liste} .ql-picker-${quoi}${valeur ? `[data-value="${valeur}"]` : ''}`, texte,
    )).join('');
    return [
        choix('header', '', tr("Normal")),
        ...[1, 2, 3, 4, 5, 6].map(niveau => choix('header', niveau, tr("Titre %(niveau)s", {niveau}))),
        choix('size', '', tr("Normal")),
        choix('size', 'small', tr("Petit")),
        choix('size', 'large', tr("Grand")),
        choix('size', 'huge', tr("Très grand")),
        regle('.ql-snow .ql-tooltip', tr("Ouvrir le lien :")),
        regle('.ql-snow .ql-tooltip[data-mode=link]', tr("Adresse du lien :")),
        regle('.ql-snow .ql-tooltip a.ql-action', tr("Modifier"), 'after'),
        regle('.ql-snow .ql-tooltip.ql-editing a.ql-action', tr("Enregistrer"), 'after'),
        regle('.ql-snow .ql-tooltip a.ql-remove', tr("Retirer le lien")),
    ].join('');
}

export function appliquerCssGlobalAuContenu() {
    const data = document.getElementById('jk-editor-global-css');
    const content = document.querySelector('.content');
    if (!data || !content || content.querySelector('[data-jk-editor-global-style]')) return;
    const style = document.createElement('style');
    style.dataset.jkEditorGlobalStyle = '';
    style.textContent = JSON.parse(data.textContent);
    content.prepend(style);
}

export function selecteursPublics(sheet) {
    // base_style contient aussi d'anciennes branches :is(.ql-editor, ...)
    // à spécificité plus élevée. Elles n'existent pas au rendu public : ne
    // garder que les branches publiques, sans modifier le gabarit partagé.
    for (const rule of [...sheet.cssRules]) {
        // Descendre dans @media/@container — sans s'y arrêter : depuis
        // l'imbrication CSS, une règle de style porte ELLE AUSSI `cssRules`
        // (une liste vide, donc « vraie »). S'en servir pour reconnaître un
        // groupe faisait sauter toutes les règles : rien n'était filtré, et
        // `:is(.ql-editor, …) h3` — (0,3,1) — battait dans ce cadre le CSS
        // écrit à la main sur un bloc, qui gagne pourtant sur le site.
        if (rule.cssRules?.length) selecteursPublics(rule);
        if (!rule.selectorText?.includes('.ql-editor')) continue;
        const parts = [];
        let depth = 0, start = 0, quote = null;
        for (let i = 0; i < rule.selectorText.length; i++) {
            const c = rule.selectorText[i];
            if (c === '\\') { i++; continue; }
            if (quote) { if (c === quote) quote = null; continue; }
            if (c === '"' || c === "'") { quote = c; continue; }
            if (c === '(' || c === '[') depth++;
            if (c === ')' || c === ']') depth--;
            if (c === ',' && depth === 0) { parts.push(rule.selectorText.slice(start,i)); start=i+1; }
        }
        parts.push(rule.selectorText.slice(start));
        rule.selectorText = parts.filter(p => !p.includes('.ql-editor')).join(',') || ':not(*)';
    }
}

export function htmlPourSauvegarde(quill) {
    const copie = quill.root.cloneNode(true);
    // Parchment peut porter des éléments UI hors du document : puces de
    // liste et fond du bloc. Ils ne doivent pas devenir du contenu enregistré.
    for (const el of copie.querySelectorAll('.ql-ui')) el.remove();
    return copie.innerHTML;
}

export function retirerStylesContenuSnow(sheet) {
    for (let i = sheet.cssRules.length - 1; i >= 0; i--) {
        const selector = sheet.cssRules[i].selectorText;
        // Snow colore aussi les liens par .ql-snow a, sans .ql-editor.
        // Garder l'habillage des contrôles, pas celui du texte public.
        if (selector?.includes('.ql-editor') || selector === '.ql-snow a') sheet.deleteRule(i);
    }
}

export function quillAvecRacinePublique(Quill, emplacement) {
    // addContainer est le point de création natif de Quill 2.0.3. Placer sa
    // vraie racine à l'emplacement public évite un parent artificiel et
    // conserve les sélecteurs >, nth-child et :has, sans réécrire le CSS.
    return class extends Quill {
        addContainer(container, refNode = null) {
            if (container === 'ql-editor') {
                const root = emplacement.ownerDocument.createElement('div');
                root.classList.add('ql-editor');
                emplacement.replaceWith(root);
                return root;
            }
            return super.addContainer(container, refNode);
        }
    };
}

/** Ne laisser paraître que le bloc édité.
 *
 * La copie garde TOUTE la page : c'est ce qui laisse une règle écrite à la
 * main — `.section:nth-child(2) .line + .line p`, `:has(…)` — viser le texte
 * comme sur le site. La MONTRER entière noyait en revanche le bloc qu'on édite
 * sous les sections et les colonnes voisines. On masque donc, sans rien
 * retirer du document, tout ce qui n'est pas sur le chemin du bloc : les autres
 * sections, les autres lignes, les autres colonnes, les autres blocs de sa
 * colonne.
 *
 * Restent ses ancêtres — section, ligne, colonne — avec leurs classes, leur
 * CSS et leur image de fond : un texte blanc se lit sur le fond sombre de sa
 * section, pas sur du blanc. Mais ils ne le tiennent plus à l'écart des bords :
 * ni marges, ni largeurs, ni hauteurs, et la colonne prend toute la ligne.
 * Laisser au bloc sa place dans la grille — un tiers, un quart de la page —
 * donnait le rendu exact des retours à la ligne, et pour écrire un petit carré
 * dans un grand cadre vide. On édite un texte : sa mise en page est l'affaire
 * de la page, pas de cette fenêtre. Seul l'élément qui porte le bloc garde un
 * peu d'air (`MARGE`), sur le fond de sa section.
 *
 * Ce que ça ne fait pas :
 *  - les retours à la ligne ne sont pas ceux du site, ni une règle qui dépend
 *    de la largeur du bloc (`@container`) : le bloc est ici plus large ;
 *  - un compteur CSS (`counter-increment`) ignore un élément masqué — une
 *    numérotation de sections repartirait de 1.
 */
export function neMontrerQue(bloc, racine) {
    for (let el = bloc; el && el !== racine; el = el.parentElement) {
        const parent = el.parentElement;
        if (!parent) break;
        for (const voisin of parent.children) {
            if (voisin !== el && !voisin.classList.contains('bg-img')) {
                voisin.style.setProperty('display', 'none', 'important');
            }
        }
        if (parent === racine) break;
        for (const [propriete, valeur] of Object.entries(BORD_A_BORD)) {
            parent.style.setProperty(propriete, valeur, 'important');
        }
        if (parent.classList.contains('line')) el.style.setProperty('grid-column', '1 / -1', 'important');
    }
    bloc.parentElement?.style.setProperty('padding', `${MARGE}px`, 'important');
}

/** `:last-child` ne vise pas le dernier paragraphe d'un bloc — ici non plus.
 *
 * Sur le site, chaque bloc se termine par sa feuille de style : son dernier
 * enfant est un `<style>`, jamais un paragraphe. `.carte p:last-child` n'y
 * touche donc rien, et `:only-child` non plus. Ici le bloc est la racine de
 * Quill, qui n'admet que du texte : rien ne suit le dernier paragraphe, et la
 * même règle s'appliquerait — une marge retirée dans l'éditeur, présente sur le
 * site. On retire donc à ces deux sélecteurs les enfants directs du bloc
 * édité. `:where()` ne pèse rien : la spécificité de la règle ne bouge pas.
 *
 * ponytail : `:nth-last-child()` n'est pas décalé d'un rang — il compte la
 * feuille sur le site, pas ici. À traiter s'il se rencontre un jour.
 */
export function sansDernierEnfantDuBloc(sheet, id) {
    for (const rule of [...sheet.cssRules]) {
        if (rule.cssRules?.length) sansDernierEnfantDuBloc(rule, id);
        if (!/:(?:last|only)-child/.test(rule.selectorText || '')) continue;
        rule.selectorText = rule.selectorText.replace(/:(?:last|only)-child/g, `$&:not(:where(#${id} > *))`);
    }
}

export async function preparerContexteQuill(editorEl, blocId) {
    const source = document.getElementById(`bloc-${blocId}`);
    const content = source?.closest('.content');
    if (!source || !content) throw new Error(tr("Contexte public du bloc introuvable."));
    const script = [...document.scripts].find(s => /\/quill(?:\.min)?\.js(?:\?|$)/.test(s.src));
    if (!script) throw new Error(tr("Chargement Quill introuvable."));

    const frame = document.createElement('iframe');
    frame.title = tr("Texte éditable dans le contexte du site");
    // Le viewport de la page, pas la largeur du dialogue : les mêmes
    // @media s'appliquent. C'est `max-width:none` qui le garantit : la règle
    // générale `iframe{max-width:100%}` de main.css ramenait le cadre à la
    // largeur de la modale, et un bloc édité sur ordinateur s'y affichait avec
    // les réglages de la tablette, voire du téléphone. Le cadre est donc plus
    // large que la modale : `cadre` en coupe ce qui dépasse, et le contenu se
    // tient dans la partie visible (`fenetre`, plus bas).
    const viewportSource = source.closest('.editor-body');
    const largeur = (viewportSource && parseFloat(getComputedStyle(viewportSource).width)) || window.innerWidth;
    frame.style.cssText = `width:${largeur}px;max-width:none;height:${HAUTEUR_MINIMALE}px;margin:0;border:0;display:block;`;
    const cadre = document.createElement('div');
    cadre.style.cssText = 'max-width:100%;overflow:hidden;margin-top:8px;';
    cadre.append(frame);
    editorEl.after(cadre);
    const doc = frame.contentDocument;
    const base = doc.createElement('base');
    base.href = document.baseURI;
    doc.head.append(base);

    // Snow ne doit pas redéfinir la typographie du contenu. On conserve ses
    // règles de toolbar, puis les styles publics prennent la priorité.
    const feuilles = [];
    for (const link of document.querySelectorAll('head link[rel="stylesheet"]')) {
        if (/quill|\/css\/main\/|fonts\.googleapis\.com|\/fonts\//.test(link.href)) {
            const copy = doc.importNode(link, true);
            if (/quill/.test(link.href)) copy.crossOrigin = 'anonymous';
            feuilles.push(new Promise((resolve, reject) => {
                copy.onload = () => {
                    // Snow définit .ql-snow .ql-editor h3 avec une priorité
                    // supérieure à .content h3. Garder seulement son habillage
                    // évite cette divergence, même si la police est copiée.
                    if (/quill/.test(copy.href)) {
                        try {
                            retirerStylesContenuSnow(copy.sheet);
                        } catch (error) { reject(new Error(tr("La feuille Quill ne peut pas être isolée."))); return; }
                    }
                    resolve();
                };
                copy.onerror = () => reject(new Error(tr("Une feuille de contenu ne peut pas être chargée.")));
            }));
            doc.head.append(copy);
        }
    }
    const reset = doc.createElement('style');
    reset.textContent = 'body{margin:0}.ql-container{font:inherit;border:0!important;display:contents}.ql-editor{padding:0;overflow:visible;white-space:normal;line-height:inherit;font:inherit;height:auto;min-height:100px}.ql-toolbar{position:sticky;top:0;z-index:10;background:white}' + libellesDeQuill();
    doc.head.append(reset);
    for (const style of document.querySelectorAll('[data-jk-content-style]')) {
        const copy = doc.importNode(style, true);
        doc.head.append(copy);
        selecteursPublics(copy.sheet);
    }
    const globalData = document.getElementById('jk-editor-global-css');
    if (globalData) {
        const style = doc.createElement('style');
        style.textContent = JSON.parse(globalData.textContent);
        doc.head.append(style);
    }
    // Conserver les frères : retirer une colonne change la grille et les
    // sélecteurs nth-child/:has. Aucun comportement de la page n'est exécuté.
    // Ils restent dans le document, pas à l'écran : voir `neMontrerQue`.
    const viewport = doc.createElement('div');
    viewport.className = 'editor-body';
    viewport.style.cssText = 'container-type:inline-size;container-name:editor-body;';
    doc.body.append(viewport);
    // La partie du cadre que la modale laisse voir. Le contenu s'y tient et
    // y défile : sa barre de défilement reste ainsi à portée, au lieu de se
    // perdre au bord d'un cadre plus large que la modale.
    const fenetre = doc.createElement('div');
    fenetre.style.cssText = 'height:100vh;overflow:auto;';
    viewport.append(fenetre);
    const page = doc.importNode(content, true);
    // Tout ce que l'éditeur ajoute à la page sort de la copie : les contrôles,
    // le bouton « ajouter une section » et sa propre copie du CSS global. Ils
    // n'existent pas sur le site, et y laisser l'un d'eux décale les
    // sélecteurs de position — `.section:last-child` ne visait plus rien.
    for (const el of page.querySelectorAll('script,iframe,object,embed,.overlay-section-bg,.overlay-section-controls,.overlay-line-bg,.overlay-line-controls,.overlay-block-bg,.overlay-block-controls,[data-empty-state],.section-add,[data-jk-editor-global-style]')) el.remove();
    for (const el of [page, ...page.querySelectorAll('*')]) {
        for (const attr of [...el.attributes]) {
            if (/^on|^x-|^hx-/i.test(attr.name) || attr.name === 'contenteditable') el.removeAttribute(attr.name);
        }
    }
    fenetre.append(page);
    doc.addEventListener('click', event => {
        if (event.target.closest('a') && !event.target.closest('.ql-toolbar,.ql-tooltip')) event.preventDefault();
    });
    doc.addEventListener('submit', event => event.preventDefault());
    const original = doc.getElementById(source.id);
    const background = original.querySelector(':scope > .bg-img');
    neMontrerQue(original, page);
    const emplacement = doc.createComment('racine Quill publique');
    // Les feuilles locales restent LÀ OÙ le site les rend, à la fin de leur
    // section, de leur ligne, de leur bloc : c'est leur place dans le
    // document qui décide de leur ordre, et de ce que vise `:last-child`
    // autour d'elles. Seule celle du bloc édité doit en sortir — Quill fait du
    // bloc sa racine et n'y tolère que son texte : elle se pose juste après
    // lui, au même rang parmi les feuilles. Voir `sansDernierEnfantDuBloc`.
    original.after(...original.querySelectorAll('style'));
    original.replaceWith(emplacement);
    const mount = doc.createElement('div');
    // Le conteneur natif reste connecté pour l'émetteur/les tooltips, mais
    // hors de .content : aucun parent supplémentaire autour du texte.
    mount.style.cssText = 'position:fixed!important;inset:0!important;width:100%!important;height:100%!important;display:block!important;pointer-events:none;z-index:50';
    const controles = doc.createElement('style');
    controles.textContent = '.ql-container > .ql-tooltip{pointer-events:auto}';
    doc.head.append(controles);
    doc.body.append(mount);
    let timer;
    try {
        await Promise.race([Promise.all(feuilles).then(() => new Promise((resolve, reject) => {
            const load = doc.createElement('script');
            load.src = script.src;
            load.onload = resolve;
            load.onerror = () => reject(new Error(tr("Quill ne peut pas être chargé dans le contexte isolé.")));
            doc.head.append(load);
        })), new Promise((resolve, reject) => {
            timer = setTimeout(() => reject(new Error(tr("Délai de chargement du contexte dépassé."))), 20000);
        })]);
    } catch (error) {
        cadre.remove();
        throw error;
    } finally {
        clearTimeout(timer);
    }
    for (const sheet of doc.styleSheets) {
        // Une feuille d'un autre domaine (polices) ne se lit pas : elle ne
        // porte que des @font-face, rien à y corriger.
        try { sansDernierEnfantDuBloc(sheet, source.id); } catch (error) { /* illisible */ }
    }
    return {
        // `limites` : là où Quill doit tenir ses bulles (lien, formule). Sans
        // elle il les cale sur le document, plus large que ce qu'on en voit.
        mount, limites: fenetre, Quill: quillAvecRacinePublique(frame.contentWindow.Quill, emplacement),
        actualiserCss(css, classes, anciennesClasses) {
            if (!frame.isConnected) return;
            let style = doc.querySelector(`style[data-jk-bloc-style="${blocId}"]`);
            if (!style) {
                style = doc.createElement('style');
                style.dataset.jkBlocStyle = String(blocId);
                doc.head.append(style);
            }
            // textContent ne peut pas faire sortir une réponse du <style>.
            style.textContent = css;
            sansDernierEnfantDuBloc(style.sheet, source.id);
            const root = doc.getElementById(source.id);
            const reserves = new Set(['ql-editor', 'ql-blank', 'bloc', `bloc-${blocId}`, ...[...source.classList].filter(c => c.startsWith('bloc-'))]);
            for (const name of anciennesClasses) if (!reserves.has(name)) root.classList.remove(name);
            for (const name of String(classes).split(/\s+/).filter(Boolean)) root.classList.add(name);
        },
        finaliser(quill) {
            // Le bloc devient la racine éditable : #bloc-ID > p reste vrai,
            // sans wrapper supplémentaire entre le bloc et ses paragraphes.
            quill.root.id = source.id;
            for (const name of source.classList) quill.root.classList.add(name);
            // ParentBlot.attachUI exclut ce noeud du document et de ses
            // mutations, tout en gardant l'image à sa place dans le bloc.
            if (background) quill.scroll.attachUI(background);
            quill.root.setAttribute('aria-label', tr("Contenu du texte"));
            // La toolbar reste dans la modale, hors du document qui reçoit
            // le CSS du site : même un CSS local général ne la repeint pas.
            const libelles = document.createElement('style');
            libelles.textContent = libellesDeQuill();
            editorEl.before(libelles, quill.getModule('toolbar').container);
            editorEl.hidden = true;
            // Le bloc remplit la fenêtre d'édition, quels que soient sa
            // largeur, ses marges et sa hauteur sur la page. Son fond, sa
            // bordure et ses marges INTÉRIEURES restent : c'est son allure.
            for (const [propriete, valeur] of Object.entries({
                width: '100%', 'max-width': 'none', margin: '0', height: 'auto', 'max-height': 'none',
            })) quill.root.style.setProperty(propriete, valeur, 'important');
            // Le cadre prend ce que la modale laisse sous la barre d'outils,
            // et le suit quand la fenêtre change de taille. Sa LARGEUR ne
            // bouge pas : c'est celle de la page, dont dépendent les @media ;
            // seul ce qu'on en voit (`fenetre`) s'aligne sur la modale.
            const corps = cadre.closest('.modal-body');
            const ajuster = () => {
                const visible = cadre.clientWidth;
                if (!frame.isConnected || !visible) return;
                let hauteur = HAUTEUR_MINIMALE;
                if (corps) {
                    const dessus = cadre.getBoundingClientRect().top - corps.getBoundingClientRect().top + corps.scrollTop;
                    const dessous = parseFloat(getComputedStyle(corps).paddingBottom) || 0;
                    hauteur = Math.max(hauteur, Math.floor(corps.clientHeight - dessus - dessous));
                }
                frame.style.height = `${hauteur}px`;
                fenetre.style.width = `${Math.min(largeur, visible)}px`;
                quill.root.style.setProperty('min-height', `${hauteur - 2 * MARGE}px`, 'important');
            };
            const observateur = new ResizeObserver(ajuster);
            observateur.observe(cadre);
            if (corps) observateur.observe(corps);
            // Sans attendre l'observateur : il ne se déclenche qu'au prochain
            // rendu, et le cadre s'ouvrirait à sa hauteur minimale.
            ajuster();
        },
    };
}

export function enregistrerAttributsQuill(Quill) {
    const Parchment = Quill.import('parchment');
    // Les classes utilisateur restent des attributs de document lors d'une
    // scission de paragraphe ; les classes ql-* restent gérées par Quill.
    class Classes extends Parchment.Attributor {
        value(node) { return [...node.classList].filter(c => !c.startsWith('ql-')).join(' '); }
        add(node, value) {
            this.remove(node);
            for (const name of String(value).split(/\s+/).filter(Boolean)) node.classList.add(name);
            return true;
        }
        remove(node) { for (const c of [...node.classList]) if (!c.startsWith('ql-')) node.classList.remove(c); }
    }
    for (const [name, scope] of [['Block', Parchment.Scope.BLOCK_ATTRIBUTE], ['Inline', Parchment.Scope.INLINE_ATTRIBUTE]]) {
        Quill.register(new Classes(`jkClasses${name}`, 'class', {scope}), true);
        Quill.register(new Parchment.Attributor(`jkId${name}`, 'id', {scope}), true);
    }
}
