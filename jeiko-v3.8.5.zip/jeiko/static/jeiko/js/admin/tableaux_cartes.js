/*
 * A-15 — Les tableaux de l'administration deviennent des cartes sur téléphone.
 *
 * Sur un petit écran, un tableau de dix colonnes ne se lit qu'en le faisant défiler
 * de travers, sur deux ou trois largeurs d'écran : c'est ainsi qu'on lisait
 * la liste des utilisateurs depuis un téléphone — poste de travail quotidien
 * de l'exploitant. La classe `.jk-en-cartes` fait afficher chaque ligne comme
 * une carte « Colonne : valeur » (admin_ui.css) :
 *   - toujours sous 768 px (téléphone) ;
 *   - entre 768 et 991 px (tablette), seulement si le tableau déborde ;
 *   - jamais au-delà. Recalculé à la rotation de l'écran.
 *
 * Ce script ne fait qu'une chose : recopier l'intitulé de chaque colonne sur
 * ses cellules (`data-label`), pour que la carte sache quoi écrire. Il évite
 * de réécrire les vingt-huit gabarits de tableaux, et couvre d'office le
 * vingt-neuvième. Sans lui, rien ne casse : le tableau reste un tableau qui
 * défile (A-20).
 *
 * Il pose aussi les rôles ARIA de table : certains navigateurs retirent la
 * sémantique d'un tableau dès que son affichage devient « block », et un
 * lecteur d'écran n'y lirait plus qu'une suite de textes.
 *
 * Un tableau s'exclut avec la classe `jk-sans-cartes`.
 */
(function () {
  "use strict";

  function intitules(table) {
    var ligne = table.tHead && table.tHead.rows[table.tHead.rows.length - 1];
    if (!ligne) return null;
    var textes = [];
    for (var i = 0; i < ligne.cells.length; i++) {
      var cellule = ligne.cells[i];
      var texte = (cellule.textContent || "").replace(/\s+/g, " ").trim();
      var largeur = cellule.colSpan || 1;
      for (var j = 0; j < largeur; j++) textes.push(texte);
      cellule.setAttribute("role", "columnheader");
    }
    return textes;
  }

  function preparer(table) {
    if (table.classList.contains("jk-sans-cartes") || table.dataset.cartes) return;
    var textes = intitules(table);
    if (!textes || !textes.length) return;

    table.setAttribute("role", "table");
    for (var s = 0; s < table.tBodies.length; s++) {
      var corps = table.tBodies[s];
      corps.setAttribute("role", "rowgroup");
      for (var r = 0; r < corps.rows.length; r++) {
        var ligne = corps.rows[r];
        ligne.setAttribute("role", "row");
        var colonne = 0;
        for (var c = 0; c < ligne.cells.length; c++) {
          var cellule = ligne.cells[c];
          cellule.setAttribute("role", cellule.tagName === "TH" ? "rowheader" : "cell");
          // Une cellule qui couvre toute la ligne (« Aucun résultat ») n'a
          // pas d'intitulé à porter.
          if ((cellule.colSpan || 1) < textes.length && !cellule.hasAttribute("data-label")) {
            cellule.setAttribute("data-label", textes[colonne] || "");
          }
          colonne += cellule.colSpan || 1;
        }
      }
    }
    if (table.tHead) table.tHead.setAttribute("role", "rowgroup");
    table.classList.add("jk-cartes");
    table.dataset.cartes = "1";
  }

  function disposer() {
    var largeur = window.innerWidth;
    var tables = document.querySelectorAll("table.jk-cartes");
    for (var i = 0; i < tables.length; i++) {
      var table = tables[i];
      // On mesure le tableau sous sa forme de tableau, jamais sous ses cartes.
      table.classList.remove("jk-en-cartes");
      var enCartes = largeur < 768 || (
        largeur < 992 && table.parentElement &&
        table.scrollWidth > table.parentElement.clientWidth + 1
      );
      if (enCartes) table.classList.add("jk-en-cartes");
    }
  }

  var attente = null;
  window.addEventListener("resize", function () {
    clearTimeout(attente);
    attente = setTimeout(disposer, 150);
  });

  function tout() {
    // Tous les tableaux du contenu, quel que soit leur conteneur : la moitié
    // des listes (utilisateurs, pages, catégories…) n'utilisent pas
    // `.admin-table-scroll`. Un tableau sans en-tête est laissé tel quel.
    var tables = document.querySelectorAll(".admin-content table");
    for (var i = 0; i < tables.length; i++) preparer(tables[i]);
    disposer();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", tout);
  } else {
    tout();
  }
})();
