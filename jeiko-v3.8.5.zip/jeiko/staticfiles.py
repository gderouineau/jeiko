# jeiko/staticfiles.py
"""
Minification du CSS et du JavaScript au moment de `collectstatic`.

Le problème que ce module résout
--------------------------------
Le paquet livrait deux exemplaires de chaque feuille de style : la source
(`main.css`) et une version minifiée écrite à la main (`main.min.css`). Les
gabarits chargeaient la première en `DEBUG`, la seconde en production.

Rien ne garantissait qu'elles disent la même chose. Au constat du 17/08/2026,
`main.min.css` datait de neuf mois et `menu.min.css` de onze : **175 sélecteurs
sur 370 manquaient en production**. L'éditeur affichait la mise en forme à
jour, le visiteur celle de novembre 2025 — c'est l'origine des écarts observés
entre l'éditeur et le site réel.

Le décalage était structurel : minifier était un geste manuel, donc oublié.

Ce que fait ce module
---------------------
La minification devient une étape de `collectstatic`. Les gabarits ne
référencent plus qu'un seul fichier — la source — et c'est le déploiement qui
produit la version compacte. **Il ne peut plus y avoir deux versions
divergentes, puisqu'il n'y a plus qu'un fichier écrit à la main.**

Pourquoi ici, et pas ailleurs
-----------------------------
*Pas un cron* : `ManifestStaticFilesStorage` appose une empreinte au nom de
chaque fichier, et nginx les sert en `immutable` pour un an. Réécrire un
fichier après coup produirait un cache empoisonné, sans moyen de le purger.

*Pas à la publication* : ce serait un fichier de plus à maintenir dans le
paquet, donc le même risque de divergence sous une autre forme.

`collectstatic` est le seul endroit où la minification précède le calcul de
l'empreinte : celle-ci porte alors sur le contenu réellement servi. Et
l'étape se déclenche à chaque `jeiko-client-update`, sur chaque site, sans
rien ajouter à l'installeur.

En développement (`DEBUG=True`), `collectstatic` n'intervient pas : les
sources sont servies telles quelles, lisibles et déboguables. C'est le
comportement voulu.

Précautions
-----------
- L'échec d'un fichier n'interrompt pas le déploiement : on journalise et on
  garde l'original. Une feuille non minifiée reste une feuille valide.
- Les fichiers déjà nommés `.min.css` / `.min.js`, et tout ce qui vit dans un
  dossier `vendor/`, sont laissés tels quels : ce sont des dépendances tierces
  livrées compactées.

Le JavaScript (Q-12, 28/09/2026)
--------------------------------
Il en était exclu, et PageSpeed le relevait (« réduire le JavaScript » sur
`cookies/consent.js`). `rjsmin` ne fait que retirer commentaires et blancs,
sans rien renommer ni réécrire : il préserve les chaînes, les expressions
régulières et les gabarits entre accents graves. Vérifié sur les neuf fichiers
du paquet — chacun reste valide pour `node --check`, 35 % plus léger. Les
commentaires `/*! … */` (licences) sont conservés.
- L'opération porte sur la copie déposée dans `STATIC_ROOT`, jamais sur les
  sources du paquet.
"""

import logging
import os

from django.conf import settings
from django.contrib.staticfiles.storage import ManifestStaticFilesStorage

logger = logging.getLogger("jeiko")


class MinifyingManifestStaticFilesStorage(ManifestStaticFilesStorage):
    """`ManifestStaticFilesStorage`, suivi d'une passe de minification."""

    #: Extensions traitées. Chacune a son minifieur (`_charger_minifieur`).
    EXTENSIONS = (".css", ".js")

    def post_process(self, paths, dry_run=False, **options):
        """
        Laisse Django empreindre et réécrire les URL, PUIS minifie le résultat.

        L'ordre est imposé par Django, et l'inverse ne fonctionne pas :
        `HashedFilesMixin` relit chaque fichier depuis le stockage **d'origine**
        — celui du finder, dans le paquet — et non depuis `STATIC_ROOT`.
        Minifier la copie déposée dans `STATIC_ROOT` avant lui n'a donc aucun
        effet sur le fichier réellement servi ; c'est la source intacte qui est
        empreinte et recopiée.

        On minifie donc après coup, sur les fichiers produits. L'empreinte
        continue de dériver de la source : elle change dès que la source
        change, ce qui est tout ce qu'on lui demande pour invalider les caches.
        """
        produits = set()
        for resultat in super().post_process(paths, dry_run=dry_run, **options):
            # (nom d'origine, nom empreint, traité). Le nom empreint est celui
            # qui sera réellement servi.
            nom, nom_empreint = resultat[0], resultat[1]
            if isinstance(nom_empreint, str):
                produits.add(nom_empreint)
            produits.add(nom)
            yield resultat

        # Exécuté une fois le générateur épuisé, donc après que Django a écrit
        # ses fichiers empreints et son manifeste.
        if not dry_run:
            self._minifier_sorties(produits)

    # -- interne ------------------------------------------------------------

    def _minifier_sorties(self, produits):
        """
        Minifie les feuilles de style PRODUITES PAR CE DÉPLOIEMENT.

        La première version balayait tout `STATIC_ROOT`. C'était une erreur :
        `collectstatic` n'efface jamais rien. Les fichiers retirés du paquet —
        les `main.min.css` maintenus à la main, précisément — restent sur le
        disque des sites indéfiniment, avec toutes leurs versions empreintes.
        Le balayage les reprenait à chaque déploiement, et l'un d'eux, généré
        de longue date, contenait une syntaxe que `csscompressor` ne sait pas
        lire : dix traces d'erreur à chaque mise à jour, pour des fichiers que
        plus personne ne sert.

        On se limite donc à ce que `post_process` vient de produire. C'est
        aussi le bon périmètre au sens strict : ce qui n'a pas été déposé par
        ce déploiement ne nous appartient pas.
        """
        minifieurs = {ext: self._charger_minifieur(ext) for ext in self.EXTENSIONS}

        racine = getattr(settings, "STATIC_ROOT", None)
        if not racine or not os.path.isdir(racine):
            logger.warning(
                "STATIC_ROOT introuvable : minification ignorée."
            )
            return

        traites = gagnes = 0
        for chemin in sorted(produits):
            if not self._a_minifier(chemin):
                continue
            compress = minifieurs.get(os.path.splitext(chemin)[1].lower())
            if compress is None:
                continue
            absolu = os.path.join(racine, chemin)
            if not os.path.isfile(absolu):
                continue
            gain = self._minifier_un(absolu, compress)
            if gain is not None:
                traites += 1
                gagnes += gain

        if traites:
            logger.info(
                "Minification : %s fichier(s), %s octets économisés.",
                traites, gagnes,
            )

    def _charger_minifieur(self, extension):
        """
        Retourne la fonction de compression de cette extension, ou None.

        Absente, on sert les sources : le site reste correct, simplement plus
        lourd. Un déploiement ne doit pas échouer pour une question de poids.
        """
        paquet = {".css": "csscompressor", ".js": "rjsmin"}.get(extension)
        try:
            if extension == ".css":
                from csscompressor import compress
                return compress
            if extension == ".js":
                from rjsmin import jsmin
                return lambda source: jsmin(source, keep_bang_comments=True)
        except ImportError:
            logger.warning(
                "%s n'est pas installé : les fichiers %s seront servis non "
                "minifiés. Il figure dans requirements.txt — un `pip install "
                "-r requirements.txt` rétablit la compression.", paquet, extension,
            )
        return None

    def _a_minifier(self, chemin):
        """
        Ce fichier doit-il être compacté ?

        Le contrôle « déjà minifié » ne peut pas se faire sur le suffixe :
        `ManifestStaticFilesStorage` insère l'empreinte AVANT l'extension, si
        bien qu'un `vendor.min.css` devient `vendor.min.a1b2c3d4.css`, qui ne
        se termine pas par `.min.css`. On cherche donc « .min. » n'importe où
        dans le nom.
        """
        nom = os.path.basename(chemin).lower()
        if not nom.endswith(self.EXTENSIONS):
            return False
        # Dépendances tierces : on ne retouche pas un code qu'on n'a pas écrit.
        if "vendor" in chemin.replace("\\", "/").lower().split("/"):
            return False
        # Déjà compacté à la source (dépendances tierces), sous sa forme brute
        # comme sous sa forme empreinte.
        return ".min." not in nom

    def _minifier_un(self, absolu, compress):
        """Minifie un fichier en place. Retourne les octets gagnés, ou None."""
        chemin = os.path.relpath(absolu, getattr(settings, "STATIC_ROOT", ""))
        try:
            with open(absolu, encoding="utf-8") as f:
                avant = f.read()
            apres = compress(avant)
        except Exception:
            logger.exception(
                "Minification impossible pour %s — le fichier est servi tel "
                "quel.", chemin,
            )
            return None

        # Un minifieur qui renvoie du vide sur une source non vide s'est trompé :
        # écrire ce résultat effacerait la feuille de style du site.
        if avant.strip() and not apres.strip():
            logger.error(
                "Minification vide pour %s — original conservé.", chemin,
            )
            return None

        try:
            with open(absolu, "w", encoding="utf-8") as f:
                f.write(apres)
        except OSError:
            logger.exception("Écriture impossible pour %s.", chemin)
            return None

        return len(avant) - len(apres)
