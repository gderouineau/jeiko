"""
Le spam des formulaires de contact.

Ce qui existait, et pourquoi ça ne suffisait pas
------------------------------------------------
Un champ leurre (« company ») et des plafonds par adresse IP
(`administration_pages/throttling.py`). Les robots d'aujourd'hui ignorent les
champs masqués et changent d'adresse à chaque envoi : Guillaume recevait du
spam en quantité (04/10/2026).

Trois contrôles de plus, invisibles pour le visiteur
----------------------------------------------------
1. **Le chronomètre.** Le formulaire porte un jeton signé, posé à l'affichage
   (la page qui contient un formulaire n'est jamais mise en cache, voir
   `page_cache.UNCACHEABLE_CONTENT_TYPES`). Un envoi sans jeton valide, ou
   moins de trois secondes après l'affichage, n'a pas été tapé par un humain.
2. **La preuve de JavaScript.** Le vrai formulaire envoie par JavaScript, qui
   ajoute un second champ dérivé du jeton. Un robot qui poste directement
   l'adresse du formulaire — le cas le plus courant — ne l'a pas.
3. **Le contenu.** Plusieurs liens, du balisage de lien, les mots du spam de
   référencement, de crypto ou de casino : un score, pas un mot interdit.

Rien n'est jeté
---------------
Un envoi jugé suspect n'est PAS refusé : il est gardé en **quarantaine**
(`ContentFormSubmission.is_spam`), sans e-mail ni fiche au CRM, et visible
dans Pages › Messages reçus, où « Ce n'est pas un spam » le délivre. Un
contrôle trop sévère coûte un clic, jamais un client. Le robot, lui, reçoit
la même réponse qu'un envoi réussi : rien ne lui dit qu'il a été repéré.

Ce que ça ne fait pas : arrêter un humain payé pour remplir des formulaires,
ni un robot qui exécute réellement la page dans un navigateur et attend.
Pour ceux-là, un captcha (Cloudflare Turnstile) reste possible.
"""

import re
import time

from django.core import signing

SEL = "jeiko.formulaire.antispam"
DELAI_MINIMUM = 3                    # secondes entre l'affichage et l'envoi
DUREE_DE_VIE = 7 * 24 * 3600         # un onglet laissé ouvert une semaine
SEUIL = 3                            # score à partir duquel l'envoi est suspect

CHAMP_JETON = "jk_t"
CHAMP_JS = "jk_js"

LIEN = re.compile(r"https?://|www\.", re.I)
BALISAGE = re.compile(r"<a\s+href|\[url[=\]]|\[link[=\]]", re.I)
MOTS = re.compile(
    r"\b(seo|backlinks?|search engine|first page of google|rank(ing)? your|"
    r"guest post|link building|crypto|bitcoin|forex|casino|viagra|cialis|"
    r"loan|payday|escort|porn|onlyfans|whatsapp me|telegram me|"
    r"web ?design (services|company)|lead generation|increase your sales|"
    r"unsubscribe|opt[- ]out)\b",
    re.I,
)


def jeton(formulaire_id):
    """Le jeton posé dans le formulaire à son affichage."""
    return signing.dumps({"f": formulaire_id, "t": int(time.time())}, salt=SEL, compress=True)


def champs_d_un_humain(formulaire_id, il_y_a=10):
    """
    Ce que le vrai formulaire envoie en plus des champs : jeton et preuve de
    JavaScript, comme affichés `il_y_a` secondes plus tôt. Pour les tests.
    """
    brut = signing.dumps({"f": formulaire_id, "t": int(time.time()) - il_y_a}, salt=SEL, compress=True)
    return {CHAMP_JETON: brut, CHAMP_JS: brut[::-1]}


def _controle_du_jeton(formulaire_id, donnees):
    brut = donnees.get(CHAMP_JETON) or ""
    if not brut:
        return "jeton absent (envoi hors du formulaire)"
    try:
        valeur = signing.loads(brut, salt=SEL, max_age=DUREE_DE_VIE)
    except signing.SignatureExpired:
        return "formulaire affiché il y a plus d'une semaine"
    except signing.BadSignature:
        return "jeton invalide"
    if valeur.get("f") != formulaire_id:
        return "jeton d'un autre formulaire"
    if time.time() - valeur.get("t", 0) < DELAI_MINIMUM:
        return "envoyé moins de 3 secondes après l'affichage"
    if (donnees.get(CHAMP_JS) or "") != brut[::-1]:
        return "envoyé sans JavaScript"
    return None


def score_du_contenu(valeurs):
    """Un score : chaque indice de spam ajoute des points. Retourne (score, indices)."""
    texte = " ".join(str(v) for v in valeurs.values())
    indices, score = [], 0
    liens = len(LIEN.findall(texte))
    if liens >= 2:
        score += liens
        indices.append(f"{liens} liens")
    if BALISAGE.search(texte):
        score += 3
        indices.append("balisage de lien")
    mots = {m.group(0).lower() for m in MOTS.finditer(texte)}
    if mots:
        score += 2 * len(mots)
        indices.append("mots : " + ", ".join(sorted(mots)))
    return score, indices


def verdict(formulaire_id, donnees, valeurs):
    """Le motif de la quarantaine, ou None si l'envoi paraît humain."""
    motif = _controle_du_jeton(formulaire_id, donnees)
    if motif:
        return motif
    score, indices = score_du_contenu(valeurs)
    if score >= SEUIL:
        return "contenu : " + " ; ".join(indices)
    return None


GARDER_LES_INDESIRABLES = 30  # jours


def delivrer(envoi, request=None):
    """
    « Ce n'est pas un spam » : l'envoi sort de quarantaine et fait ce qu'il
    aurait fait d'emblée — e-mails à l'équipe et au visiteur, fiche au CRM.
    """
    from jeiko.administration_pages.emailing import send_contact_form_emails
    from jeiko.crm.rattachement import rattacher_un_envoi

    envoi.is_spam, envoi.spam_reason = False, ""
    envoi.save(update_fields=["is_spam", "spam_reason"])
    formulaire = envoi.formulaire
    libelles = {f.name: f.label for f in formulaire.fields.all()}
    valeurs = envoi.data or {}
    rattacher_un_envoi(formulaire, valeurs)
    send_contact_form_emails(
        formulaire, {libelles.get(k, k): v for k, v in valeurs.items()}, valeurs, request=request)


def purger_les_indesirables():
    """Les envois en quarantaine depuis plus de 30 jours : des données personnelles à ne pas garder."""
    from datetime import timedelta

    from django.utils import timezone

    from .models import ContentFormSubmission

    limite = timezone.now() - timedelta(days=GARDER_LES_INDESIRABLES)
    return ContentFormSubmission.objects.filter(is_spam=True, submitted_at__lt=limite).delete()[0]
