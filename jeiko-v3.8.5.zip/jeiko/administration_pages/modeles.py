"""
La bibliothèque de modèles de l'éditeur : section, ligne ou bloc enregistrés
pour être réutilisés (Q-06, AUDIT_EDITOR E1 à E6).

Deux usages, au choix à l'insertion (décision de Guillaume, 04/10/2026)
-----------------------------------------------------------------------
* **Copie libre** — le modèle sert de point de départ : l'insérer en fait une
  copie indépendante, qu'on retouche à volonté. Modifier le modèle ensuite
  ne la touche pas.
* **Copie synchronisée** — comme un « bloc global » : chaque mise à jour du
  modèle la remplace. Un pied de page, un bandeau promotionnel posés sur
  vingt pages se corrigent une fois.

La mise à jour n'est pas automatique à chaque frappe : on modifie le modèle
tranquillement dans son atelier, puis « Mettre à jour les N pages » publie le
résultat d'un coup (`synchroniser`). Une copie synchronisée retouchée sur sa
page perd cette retouche à la mise à jour suivante — l'écran le dit, et
propose de la DÉTACHER (elle redevient libre).

Éditer un modèle
----------------
Un modèle n'appartient à aucune page ; l'éditeur ne travaille que page par
page. Chaque modèle reçoit donc, au premier « Modifier », une page atelier
cachée (`Page.is_model_workshop`, exclue du public comme les gabarits
d'e-mail) qui le porte — avec la section, ou la section et la ligne, qu'il
faut à une ligne ou à un bloc pour exister.

Supprimer un modèle
-------------------
Permis : les copies déjà posées restent sur leurs pages, détachées (décision
du 04/10). Son atelier part avec lui.
"""

import logging

from django.db import transaction
from django.utils.text import slugify

from .models import Bloc, Line, Page, Section, StyleBox

logger = logging.getLogger(__name__)

GENRES = {"section": Section, "line": Line, "bloc": Bloc}


def genre_de(objet):
    return {Section: "section", Line: "line", Bloc: "bloc"}[type(objet)]


# --------------------------------------------------------------------------- #
#  L'atelier
# --------------------------------------------------------------------------- #
def page_du_modele(modele):
    """La page où vit le modèle, s'il a déjà un atelier."""
    if isinstance(modele, Section):
        return modele.page
    if isinstance(modele, Line):
        return modele.section.page if modele.section_id else None
    return modele.line.section.page if modele.line_id else None


@transaction.atomic
def atelier(modele):
    """La page atelier du modèle, créée au besoin. C'est elle qu'on ouvre dans l'éditeur."""
    page = page_du_modele(modele)
    if page is not None and page.is_model_workshop:
        return page

    genre = genre_de(modele)
    page = Page.objects.create(
        title=f"Modèle — {modele.model_name or modele.pk}"[:100],
        url_tag=f"atelier-{genre}-{modele.pk}-{slugify(modele.model_name or '')[:40]}".strip("-")[:100],
        active=False, google_index=False, is_model_workshop=True,
    )
    if isinstance(modele, Section):
        modele.page, modele.position = page, 0
        modele.save(update_fields=["page", "position"])
        return page

    from . import fabrique

    porteuse = fabrique.creer_section(page, position=0)
    if isinstance(modele, Line):
        modele.section, modele.position = porteuse, 0
        modele.save(update_fields=["section", "position"])
        return page

    ligne = fabrique.creer_ligne(porteuse, position=0, colonnes=1)
    modele.line, modele.position = ligne, 1
    modele.save(update_fields=["line", "position"])
    return page


def modele_de_l_atelier(page):
    """Le modèle que porte une page atelier, ou None."""
    if not page.is_model_workshop:
        return None
    for section in page.sections.all():
        if section.is_model:
            return section
        for ligne in section.lines.all():
            if ligne.is_model:
                return ligne
            for bloc in ligne.blocs.all():
                if bloc.is_model:
                    return bloc
    return None


# --------------------------------------------------------------------------- #
#  Les copies
# --------------------------------------------------------------------------- #
def copies(modele, synchronisees=None):
    qs = type(modele).objects.filter(model_source=modele, is_model=False)
    return qs if synchronisees is None else qs.filter(model_sync=synchronisees)


def _supprimer(objet):
    """Supprime une section, une ligne ou un bloc, ses marges et paddings compris."""
    boites = [getattr(objet, f"{b}_{a}_id", None) for b in ("margin", "padding")
              for a in ("phone", "tablet", "laptop", "computer")]
    objet.delete()
    StyleBox.objects.filter(id__in=[b for b in boites if b]).delete()


@transaction.atomic
def synchroniser(modele):
    """
    Remplace chaque copie synchronisée par une copie fraîche du modèle, à la
    même place. Retourne le nombre de copies mises à jour.
    """
    from .utils import bloc_duplicate, line_duplicate, section_duplicate

    total = 0
    for copie in list(copies(modele, synchronisees=True).select_related()):
        if isinstance(modele, Section):
            neuve = section_duplicate(modele, target_page=copie.page, position=copie.position)
        elif isinstance(modele, Line):
            neuve = line_duplicate(modele, target_section=copie.section, position=copie.position)
        else:
            neuve = bloc_duplicate(modele, target_line=copie.line, position=copie.position)
        neuve.is_model, neuve.model_name = False, None
        neuve.model_source, neuve.model_sync = modele, True
        neuve.save(update_fields=["is_model", "model_name", "model_source", "model_sync"])
        _supprimer(copie)
        total += 1
    logger.info("Modèle %s %s : %s copie(s) synchronisée(s)", genre_de(modele), modele.pk, total)
    return total


def detacher(copie):
    """La copie redevient libre : le modèle ne la touchera plus."""
    copie.model_sync = False
    copie.save(update_fields=["model_sync"])


@transaction.atomic
def supprimer_modele(modele):
    """Supprime le modèle et son atelier ; ses copies restent, détachées."""
    copies(modele).update(model_sync=False)
    page = page_du_modele(modele)
    _supprimer(modele)
    if page is not None and page.is_model_workshop:
        for section in list(page.sections.all()):
            _supprimer(section)
        page.delete()


def nom_pris(genre, nom, sauf=None):
    """Deux modèles d'un même genre ne portent pas le même nom (E3)."""
    qs = GENRES[genre].objects.filter(is_model=True, model_name__iexact=(nom or "").strip())
    if sauf is not None:
        qs = qs.exclude(pk=sauf.pk)
    return qs.exists()
