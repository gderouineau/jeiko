"""
Recalcul du visuel « héros » — DÉPLACÉ en 0068 (28/09/2026), sans effet ici.

Cette migration appelait la vraie fonction `recompute_page_hero`, qui lit le
schéma COURANT des modèles. Or `0064` ajoute ensuite `ImageContent.decorative` :
à cette étape la colonne n'existe pas, et le calcul échouait pour chaque page
de chaque site — rien n'était recalculé, et le journal de mise à jour se
remplissait d'une trace par page. Le recalcul se fait désormais après la
dernière migration de schéma (`0068_recalculer_les_heros_apres_le_schema`).

Gardée, vide, pour ne pas casser le graphe des bases qui l'ont déjà jouée.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0062_share_contentimage_media"),
    ]

    operations = []
