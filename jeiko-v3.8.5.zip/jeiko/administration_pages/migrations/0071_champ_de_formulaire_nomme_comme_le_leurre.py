"""
Renomme les champs de formulaire nommés « company » — le nom du champ leurre
anti-robot (`jeiko.throttling.HONEYPOT_FIELD`).

Dans le formulaire rendu, le vrai champ et le leurre partageaient la même clé :
la valeur gardée était celle du leurre, vide. Ce que le visiteur tapait était
perdu, et un champ obligatoire rendait le formulaire impossible à envoyer. Le
modèle refuse désormais ce nom ; ceux qui existent déjà prennent « societe »
(ou « societe_2 »… si le nom est pris dans le même formulaire).

Les envois passés ne sont pas réécrits : leur valeur était déjà vide.
"""
from django.db import migrations


def renommer(apps, schema_editor):
    Champ = apps.get_model("administration_pages", "ContentFormField")
    for champ in Champ.objects.filter(name__iexact="company"):
        pris = set(Champ.objects.filter(formulaire_id=champ.formulaire_id)
                   .values_list("name", flat=True))
        nom, n = "societe", 1
        while nom in pris:
            n += 1
            nom = f"societe_{n}"
        # update() : le save() du modèle historique n'a pas la garde, mais
        # rien ne sert de passer par lui.
        Champ.objects.filter(pk=champ.pk).update(name=nom)


class Migration(migrations.Migration):
    dependencies = [("administration_pages", "0070_recalculer_les_heros_apres_les_langues")]
    operations = [migrations.RunPython(renommer, migrations.RunPython.noop)]
