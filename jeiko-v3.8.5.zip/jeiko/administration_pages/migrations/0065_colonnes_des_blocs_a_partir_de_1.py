"""
Les colonnes des blocs posés par l'API recommencent à 1 (28/09/2026).

L'éditeur, le rendu et la base numérotent les colonnes d'une ligne à partir
de 1. La fabrique de l'API écrivait à partir de 0. Deux cas en base :

* une ligne ENTIÈREMENT construite par l'API — colonnes de 0 à n-1 : on
  décale tout d'un cran, l'ordre et le contenu ne changent pas ;
* une ligne faite à l'éditeur (1 à n) où l'API a ajouté un bloc en
  « colonne 0 », qui voulait dire « première colonne » : ce bloc rejoint la
  colonne 1, sous ceux qui s'y trouvaient. Sans cela, la ligne comptait une
  colonne de trop et l'affichage masquait la dernière.
"""

from django.db import migrations
from django.db.models import Max


def reparer(apps, schema_editor):
    Bloc = apps.get_model("administration_pages", "Bloc")
    Line = apps.get_model("administration_pages", "Line")

    lignes = Line.objects.filter(blocs__position=0).distinct()
    for ligne in lignes:
        blocs = Bloc.objects.filter(line=ligne)
        plus_haute = blocs.aggregate(m=Max("position"))["m"] or 0
        if plus_haute <= max(0, (ligne.columns_number or 1) - 1):
            # Numérotation 0 à n-1 : tout glisser d'un cran, en partant de la
            # droite pour ne jamais faire coïncider deux colonnes.
            for bloc in blocs.order_by("-position", "position_in_column"):
                bloc.position += 1
                bloc.save(update_fields=["position"])
        else:
            dernier = (
                blocs.filter(position=1).aggregate(m=Max("position_in_column"))["m"]
            )
            rang = -1 if dernier is None else dernier
            for bloc in blocs.filter(position=0).order_by("position_in_column", "id"):
                rang += 1
                bloc.position = 1
                bloc.position_in_column = rang
                bloc.save(update_fields=["position", "position_in_column"])


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0064_imagecontent_decorative"),
    ]

    operations = [
        migrations.RunPython(reparer, migrations.RunPython.noop),
    ]
