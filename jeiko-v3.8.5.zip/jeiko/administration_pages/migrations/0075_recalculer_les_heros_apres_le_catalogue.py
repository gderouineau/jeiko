"""
Vide depuis le 04/10/2026 au soir : le recalcul des héros est passé en 0077,
après `0076_bibliotheque_de_modeles` (voir 0077 et
`tests/test_migration_des_heros.py`). Gardée pour la chaîne déjà jouée.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0074_catalogue"),
    ]

    operations = []
