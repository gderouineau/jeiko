"""
Vide depuis le 04/10/2026 : le recalcul des héros est passé en 0075, après
`0074_catalogue` (voir 0075 et `tests/test_migration_des_heros.py`). Gardée
pour la chaîne des migrations déjà jouées.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0072_redirections"),
    ]

    operations = []
