"""
Vide depuis le 04/10/2026 : le recalcul des héros est passé en 0079, après
`0078_quarantaine_des_formulaires` (voir 0079 et `tests/test_migration_des_heros.py`).
Gardée pour la chaîne déjà jouée.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0076_bibliotheque_de_modeles"),
    ]

    operations = []
