"""
Recalcul du visuel « héros » — DÉPLACÉ en 0070 (01/10/2026), sans effet ici.

Même règle qu'en 0063 : le recalcul appelle le code COURANT, il doit donc
passer après toute migration de schéma de ce module — et `0069` en est une
(les langues du site). Il se fait désormais en
`0070_recalculer_les_heros_apres_les_langues`.

Gardée, vide, pour ne pas casser le graphe des bases qui l'ont déjà jouée.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0067_icones_de_bouton_en_svg"),
    ]

    operations = []
