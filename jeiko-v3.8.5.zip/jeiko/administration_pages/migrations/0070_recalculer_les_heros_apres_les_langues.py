"""
Recalcul du visuel « héros » — DÉPLACÉ en 0073 (03/10/2026), sans effet ici.

`0072` (les redirections) est une migration de schéma ; le recalcul, qui lit
le code courant, doit passer après elle. Il se fait désormais en
`0073_recalculer_les_heros_apres_les_redirections`.

Gardée, vide, pour ne pas casser le graphe des bases qui l'ont déjà jouée.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0069_site_multilingue"),
    ]

    operations = []
