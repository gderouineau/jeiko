"""
Recalcule le visuel « héros » de chaque page — en fin de chaîne (04/10/2026, soir).

Même règle que 0063, 0068, 0070, 0073, 0075 et 0077 : le recalcul appelle le code
COURANT, il doit donc passer après toute migration de schéma de ce module
(`tests/test_migration_des_heros.py`). `0078` ajoute la quarantaine des
formulaires : 0077 est vide, le recalcul vit ici. Une base qui avait joué
0077 recalcule une seconde fois — sans effet, le calcul est
idempotent.
Voir 0070 pour le pourquoi du recalcul lui-même.
"""

import logging

from django.db import migrations
from django.db.utils import OperationalError, ProgrammingError

logger = logging.getLogger(__name__)


def recalculer(apps, schema_editor):
    from django.db import transaction

    from jeiko.administration_pages.models import Page
    from jeiko.administration_pages.signals import recompute_page_hero

    try:
        with transaction.atomic():
            pages = list(Page.objects.all().only("pk"))
    except (OperationalError, ProgrammingError):
        logger.warning("Recalcul des héros sauté : schéma en avance sur cette étape.")
        return

    for page in pages:
        try:
            with transaction.atomic():
                recompute_page_hero(page)
        except (OperationalError, ProgrammingError):
            logger.warning(
                "Recalcul des héros arrêté : le schéma n'est pas celui qu'attend le "
                "code (page %s). Les héros se recalculent à la modification des pages.",
                page.pk,
            )
            return
        except Exception:
            # Une page abîmée ne doit pas bloquer la mise à jour du site.
            logger.exception("Héros non recalculé pour la page %s", page.pk)


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0078_quarantaine_des_formulaires"),
    ]

    operations = [
        migrations.RunPython(recalculer, migrations.RunPython.noop),
    ]
