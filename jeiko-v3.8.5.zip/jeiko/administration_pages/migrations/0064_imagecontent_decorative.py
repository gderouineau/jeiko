"""
A-09 — une image est décrite, ou déclarée décorative (28/09/2026).

Ajoute `ImageContent.decorative`, puis marque décoratives les images SANS
texte alternatif qui ne servent QUE de fond (section, ligne, bloc) : un fond
est rendu `aria-hidden`, il ne porte jamais d'information. Toutes les autres
images sans texte restent « à compléter » : on ne devine pas si une photo
est décorative, c'est à l'exploitant de le dire.
"""

from django.db import migrations, models

FONDS = {
    ("administration_pages", "section", "background_image"),
    ("administration_pages", "line", "background_image"),
    ("administration_pages", "bloc", "background_image"),
}


def marquer_les_fonds(apps, schema_editor):
    ImageContent = apps.get_model("administration_pages", "ImageContent")
    relations = [
        r for r in ImageContent._meta.related_objects
        if getattr(r, "field", None) is not None and not r.field.many_to_many
    ]
    sans_texte = ImageContent.objects.filter(
        models.Q(alt__isnull=True) | models.Q(alt="")
    ).values_list("pk", flat=True)

    decoratives = []
    for pk in sans_texte.iterator():
        en_fond = autre = False
        for relation in relations:
            modele = relation.related_model
            cle = (modele._meta.app_label, modele._meta.model_name, relation.field.name)
            if modele._base_manager.filter(**{f"{relation.field.name}_id": pk}).exists():
                if cle in FONDS:
                    en_fond = True
                else:
                    autre = True
                    break
        if en_fond and not autre:
            decoratives.append(pk)

    ImageContent.objects.filter(pk__in=decoratives).update(decorative=True)


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0063_recalculer_les_heros"),
    ]

    operations = [
        migrations.AddField(
            model_name="imagecontent",
            name="decorative",
            field=models.BooleanField(
                default=False,
                help_text=(
                    "À cocher si l'image n'apporte aucune information (ornement, "
                    "fond) : un lecteur d'écran la taira. Sinon, décrivez-la."
                ),
                verbose_name="Image décorative",
            ),
        ),
        migrations.RunPython(marquer_les_fonds, migrations.RunPython.noop),
    ]
