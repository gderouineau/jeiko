# jeiko/administration_pages/fabrique.py
"""
Création des sections, lignes et blocs — un seul endroit, deux appelants.

Pourquoi ce module existe
-------------------------
Créer une section, ce n'est pas créer une ligne en base : c'est en créer
**treize**. Un `Size` et deux `StyleBox` par appareil, plus la section
elle-même, avec des valeurs qui dépendent du gabarit choisi — une section
« pleine largeur » n'a pas les mêmes tailles qu'une section « classique ».

Cette logique vivait dans `views.SectionCreate`, atteignable seulement par un
POST de formulaire. L'API des agents en a besoin aussi. La recopier aurait
garanti que les deux divergent : le jour où l'on ajoute un gabarit ou que l'on
corrige une marge, un seul des deux chemins en profite, et l'écart ne se voit
pas — il produit des pages subtilement différentes selon qui les a créées.

C'est exactement le défaut qu'A-20 a coûté ailleurs : un outil correct que rien
ne relie à son second usage. On extrait donc, et les deux appelants lisent la
même source.

Ce que ce module ne fait pas
----------------------------
Il ne rend rien et ne répond à personne : ni HTML, ni JSON, ni redirection.
Les vues s'en chargent. Il ne vérifie pas non plus les permissions — c'est le
rôle de `EditorMutationMixin` côté éditeur et de `VueAgent` côté API, et les
deux le font avant d'arriver ici.
"""

from django.db import transaction

from .models import Bloc, Line, Section, Size, StyleBox

#: Gabarits de section. La différence tient aux largeurs par appareil : une
#: section « pleine largeur » occupe tout, une « classique » est centrée dans
#: une colonne de lecture.
GABARITS_SECTION = {
    "FULL": {
        "tailles": {
            "phone": "100%", "tablet": "100%", "laptop": "100%", "computer": "100%",
        },
    },
    "CLASSIC": {
        "tailles": {
            "phone": "92%", "tablet": "730px", "laptop": "950px", "computer": "1140px",
        },
    },
}

APPAREILS = ("phone", "tablet", "laptop", "computer")


def _boite(top="", right="", bottom="", left=""):
    return StyleBox.objects.create(top=top, right=right, bottom=bottom, left=left)


def _taille(largeur="", hauteur=""):
    return Size.objects.create(width=largeur, height=hauteur)


def _decor(tailles, marge=("0", "auto", "0", "auto"), padding=("0", "0", "0", "0")):
    """
    Les douze objets liés d'un élément stylable, en un dictionnaire prêt à
    passer en `**kwargs` à `objects.create`.
    """
    decor = {}
    for appareil in APPAREILS:
        decor[f"size_{appareil}"] = _taille(tailles.get(appareil, ""))
        decor[f"margin_{appareil}"] = _boite(*marge)
        decor[f"padding_{appareil}"] = _boite(*padding)
    return decor


def position_suivante(queryset):
    """
    La position à donner au prochain élément d'une famille.

    Passe par le maximum existant plutôt que par un décompte : après une
    suppression, compter donnerait une position déjà prise.
    """
    dernier = queryset.order_by("-position").first()
    if dernier is None or dernier.position is None:
        return 0
    return dernier.position + 1


@transaction.atomic
def creer_section(page, gabarit="CLASSIC", position=None):
    """Crée une section vide au gabarit demandé, en fin de page par défaut."""
    if gabarit not in GABARITS_SECTION:
        raise ValueError(
            f"Gabarit de section inconnu : « {gabarit} ». "
            f"Attendus : {', '.join(sorted(GABARITS_SECTION))}."
        )

    if position is None:
        position = position_suivante(Section.objects.filter(page=page))

    return Section.objects.create(
        page=page,
        position=position,
        is_model=False,
        **_decor(GABARITS_SECTION[gabarit]["tailles"]),
    )


#: Répartition par défaut, par nombre de colonnes, sur les grands écrans.
#:
#: Toutes figurent dans `Line.COLUMNS_ROWS_TYPE_CHOICES` : on ne fabrique pas
#: une valeur que le modèle refuserait.
REPARTITIONS_PAR_DEFAUT = {
    1: "12",
    2: "6-6",
    3: "4-4-4",
    4: "3-3-3-3",
    6: "2-2-2-2-2-2",
}


def repartition_par_defaut(colonnes, empilee=False):
    """
    Une répartition cohérente avec le nombre de colonnes demandé.

    `empilee` donne la version téléphone : chaque colonne pleine largeur, donc
    les blocs l'un sous l'autre. C'est presque toujours ce qu'on veut sur un
    écran de 375 px, et c'est en tout cas infiniment mieux que trois blocs
    serrés dans un tiers d'écran chacun.
    """
    colonnes = max(1, int(colonnes))
    if empilee:
        return "-".join(["12"] * colonnes)
    return REPARTITIONS_PAR_DEFAUT.get(colonnes, "-".join(["12"] * colonnes))


@transaction.atomic
def creer_ligne(section, position=None, colonnes=1):
    """
    Crée une ligne dans une section, avec une répartition qui la décrit.

    Le défaut du modèle pour `columns_type` est « 12 » — une seule colonne.
    Le poser tel quel sur une ligne qu'on vient de déclarer à trois colonnes
    produisait exactement le défaut que le mode d'emploi de l'API désigne
    comme le plus coûteux : les colonnes au-delà de la première ne reçoivent
    aucune largeur, et leurs blocs sont écrasés à trente pixels.

    Autrement dit, la voie normale de création fabriquait l'état cassé, en
    silence, et il fallait savoir corriger derrière par un `PATCH`. Un agent
    qui suit la documentation à la lettre — « crée une ligne à trois colonnes,
    pose trois blocs » — obtenait une page illisible sans qu'une seule erreur
    ne soit levée.

    La ligne naît donc décrite : partagée à parts égales sur les grands
    écrans, empilée sur téléphone. Ces valeurs restent modifiables par
    `PATCH` ; ce ne sont que des défauts, mais des défauts qui tiennent debout.
    """
    if position is None:
        position = position_suivante(Line.objects.filter(section=section))

    colonnes = max(1, int(colonnes))
    return Line.objects.create(
        section=section,
        position=position,
        columns_number=colonnes,
        columns_type=repartition_par_defaut(colonnes),
        columns_type_tablet=repartition_par_defaut(colonnes),
        columns_type_phone=repartition_par_defaut(colonnes, empilee=True),
        is_model=False,
        **_decor({appareil: "100%" for appareil in APPAREILS}),
    )


@transaction.atomic
def creer_bloc(line, colonne=1, position_in_column=None):
    """
    Crée un bloc dans une colonne d'une ligne.

    `colonne` est le champ `position` du bloc — le vocabulaire du modèle est
    trompeur : c'est un numéro de colonne, pas un rang vertical. Le rang, c'est
    `position_in_column`.

    Les colonnes sont numérotées À PARTIR DE 1, comme partout ailleurs :
    l'éditeur crée ses blocs de 1 à `columns_number` et ses boutons « gauche /
    droite » raisonnent ainsi. Cette fabrique numérotait à partir de 0 : un
    bloc posé par l'API en « première colonne » d'une ligne faite à l'éditeur
    ouvrait une colonne de trop, et l'affichage — qui ne montre que
    `columns_number` colonnes — faisait disparaître la dernière. L'API garde
    sa numérotation à partir de 0 (c'est son contrat) et traduit à l'entrée.
    """
    if position_in_column is None:
        dernier = (
            line.blocs.filter(position=colonne)
            .order_by("-position_in_column")
            .first()
        )
        position_in_column = (dernier.position_in_column + 1) if dernier else 0

    return Bloc.objects.create(
        line=line,
        position=colonne,
        position_in_column=position_in_column,
        **_decor({appareil: "100%" for appareil in APPAREILS}),
    )


# --------------------------------------------------------------------------- #
#  Déplacements d'un conteneur à l'autre
# --------------------------------------------------------------------------- #
#
# L'éditeur savait monter et descendre une ligne DANS sa section, un bloc DANS
# sa ligne ; pour changer de section ou de ligne, il fallait supprimer puis
# refaire. Les deux gestes vivent ici, pour servir l'éditeur et l'API des
# agents par le même chemin.


class DeplacementImpossible(ValueError):
    """Le déplacement demandé n'a pas de sens ; le message dit pourquoi."""


def _bloc_vide(bloc):
    """Un bloc sans contenu : la case que l'éditeur pose dans une colonne vide."""
    contenu = getattr(bloc, "content", None)
    return contenu is None or (contenu.content_type or "NOT_SET") == "NOT_SET"


def _renumeroter_la_colonne(line, colonne):
    for rang, bloc in enumerate(
        line.blocs.filter(position=colonne).order_by("position_in_column", "id")
    ):
        if bloc.position_in_column != rang:
            bloc.position_in_column = rang
            bloc.save(update_fields=["position_in_column"])


@transaction.atomic
def deplacer_ligne(ligne, section_cible, rang=None):
    """
    Déplace une ligne, et tout ce qu'elle contient, dans une autre section.

    Même page seulement : une ligne n'a pas de sens hors de sa page (ses
    blocs peuvent dépendre des jetons d'une page modèle, de ses ancres).
    Sans `rang`, elle arrive en bas de la section ; sinon à ce rang (à partir
    de 0), les suivantes glissant d'un cran.
    """
    if section_cible.page_id != ligne.section.page_id:
        raise DeplacementImpossible("Une ligne ne change de section qu'à l'intérieur de sa page.")
    if section_cible.pk == ligne.section_id:
        raise DeplacementImpossible("La ligne est déjà dans cette section.")

    lignes = list(section_cible.lines.order_by("position", "id"))
    if rang is None or rang >= len(lignes):
        rang = len(lignes)
    rang = max(0, int(rang))
    lignes.insert(rang, ligne)

    ligne.section = section_cible
    ligne.save(update_fields=["section"])
    for position, element in enumerate(lignes):
        if element.position != position or element.pk == ligne.pk:
            element.position = position
            element.save(update_fields=["position"])
    return ligne


@transaction.atomic
def deplacer_bloc(bloc, ligne_cible, colonne=1, rang=None):
    """
    Déplace un bloc, contenu compris, dans une colonne d'une autre ligne (ou
    une autre colonne de la sienne).

    `colonne` compte à partir de 1, comme l'éditeur. Deux règles de l'éditeur
    sont tenues : une colonne n'est jamais laissée vide (une case vide la
    remplace), et une case vide qui attendait dans la colonne d'arrivée
    s'efface devant le bloc qu'on y pose.
    """
    source = bloc.line
    if ligne_cible.section.page_id != source.section.page_id:
        raise DeplacementImpossible("Un bloc ne change de ligne qu'à l'intérieur de sa page.")
    colonnes = max(1, ligne_cible.columns_number or 1)
    if not 1 <= int(colonne) <= colonnes:
        raise DeplacementImpossible(
            f"La ligne d'arrivée a {colonnes} colonne(s) : choisir entre 1 et {colonnes}."
        )
    colonne = int(colonne)
    colonne_source = bloc.position

    # La case vide qui tenait la place s'efface — sauf si c'est le bloc lui-même.
    arrivee = [b for b in ligne_cible.blocs.filter(position=colonne).order_by("position_in_column", "id")
               if b.pk != bloc.pk]
    if len(arrivee) == 1 and _bloc_vide(arrivee[0]):
        arrivee[0].delete()
        arrivee = []

    if rang is None or rang >= len(arrivee):
        rang = len(arrivee)
    rang = max(0, int(rang))
    arrivee.insert(rang, bloc)

    bloc.line = ligne_cible
    bloc.position = colonne
    for position_in_column, element in enumerate(arrivee):
        element.position_in_column = position_in_column
        champs = ["position_in_column"] + (["line", "position"] if element.pk == bloc.pk else [])
        element.save(update_fields=champs)

    # La colonne quittée ne reste jamais vide.
    if not source.blocs.filter(position=colonne_source).exists():
        creer_bloc(source, colonne=colonne_source, position_in_column=0)
    else:
        _renumeroter_la_colonne(source, colonne_source)
    return bloc
