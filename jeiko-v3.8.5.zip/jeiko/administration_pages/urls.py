from django.urls import path
import jeiko.administration_pages.views
from .views_quill import ApercuCssQuill
from jeiko.administration_pages.views_api import (
    CategoryMainListAPI, SubCategoryListAPI, PageListAPI, PageGetAPI,
    ContentFormulaireAPI, ContentFormFieldAPI, FormulaireSubmitView,
    SectionModelCreateAPI, LineModelCreateAPI, BlocModelCreateAPI,
    ProductTypeListAPI, CustomObjectModelListAPI
)

app_name = 'jeiko_administration_pages'

urlpatterns = [

    # — Médiathèque —
    path('media/', jeiko.administration_pages.views.MediaLibraryList.as_view(), name='media_list'),
    path('media/add/', jeiko.administration_pages.views.MediaImageCreate.as_view(), name='media_add'),
    path('media/<int:pk>/update/', jeiko.administration_pages.views.MediaImageUpdate.as_view(), name='media_update'),
    path('media/<int:pk>/delete/', jeiko.administration_pages.views.MediaImageDelete.as_view(), name='media_delete'),

    # — Pages CRUD & éditeur —
    path(
        '',
        jeiko.administration_pages.views.Main.as_view(),
        name='main'
    ),
    path(
        'add/',
        jeiko.administration_pages.views.PageAdd.as_view(),
        name='page_add'
    ),
    path(
        '<int:page_id>/',
        jeiko.administration_pages.views.SeePage.as_view(),
        name='page_view'
    ),
    path('redirections/', jeiko.administration_pages.views.ListeDesRedirections.as_view(),
         name='redirections'),
    path('redirections/<int:pk>/supprimer/', jeiko.administration_pages.views.SupprimerUneRedirection.as_view(),
         name='redirection_supprimer'),
    path('<int:page_id>/adresse-changee/', jeiko.administration_pages.views.AdresseChangee.as_view(),
         name='adresse_changee'),
    path(
        '<int:page_id>/update/',
        jeiko.administration_pages.views.PageUpdate.as_view(),
        name='page_update'
    ),
    path(
        '<int:page_id>/versions/<slug:langue>/creer/',
        jeiko.administration_pages.views.VersionCreate.as_view(),
        name='version_creer'
    ),
    path(
        '<int:page_id>/duplicate/',
        jeiko.administration_pages.views.DuplicatePageView.as_view(),
        name='page_duplicate'
    ),
    path(
        '<int:page_id>/editor/',
        jeiko.administration_pages.views.PageEditor.as_view(),
        name='page_editor'
    ),
    path(
        '<int:page_id>/publish/',
        jeiko.administration_pages.views.PageTogglePublish.as_view(),
        name='page_toggle_publish'
    ),
    path(
        "<int:page_id>/insights/",
        jeiko.administration_pages.views.PageInsight.as_view(),
        name="page_insights"
    ),

    path(
        '<int:page_id>/delete/',
        jeiko.administration_pages.views.PageDelete.as_view(),
        name='page_delete'
    ),
    # — Modèles —
    path(
        "models/",
        jeiko.administration_pages.views.ModelLibrary.as_view(),
        name="model_library"
    ),
    path(
        "models/<str:model_type>/<int:pk>/delete/",
        jeiko.administration_pages.views.ModelDelete.as_view(),
        name="model_delete"
    ),
    path("messages/", jeiko.administration_pages.views.FormSubmissionList.as_view(),
         name="form_submissions"),
    path("messages/<int:pk>/", jeiko.administration_pages.views.FormSubmissionAction.as_view(),
         name="form_submission_action"),
    path("models/<str:model_type>/<int:pk>/edit/",
         jeiko.administration_pages.views.ModelEdit.as_view(), name="model_edit"),
    path("models/<str:model_type>/<int:pk>/sync/",
         jeiko.administration_pages.views.ModelSync.as_view(), name="model_sync"),
    path("models/<str:model_type>/<int:pk>/rename/",
         jeiko.administration_pages.views.ModelRename.as_view(), name="model_rename"),
    path("models/<str:model_type>/<int:pk>/detach/",
         jeiko.administration_pages.views.ModelDetach.as_view(), name="model_detach"),


    # — Sections —
    path(
        '<int:page_id>/sections/add/',
        jeiko.administration_pages.views.SectionCreate.as_view(),
        name='section_add'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/update/',
        jeiko.administration_pages.views.SectionUpdate.as_view(),
        name='section_update'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/delete/',
        jeiko.administration_pages.views.SectionDelete.as_view(),
        name='section_delete'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/move_up/',
        jeiko.administration_pages.views.SectionMoveUp.as_view(),
        name='section_move_up'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/move_down/',
        jeiko.administration_pages.views.SectionMoveDown.as_view(),
        name='section_move_down'
    ),

    # — Lignes —
    path(
        '<int:page_id>/sections/<int:section_id>/lines/add/',
        jeiko.administration_pages.views.LineCreate.as_view(),
        name='line_add'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/update/',
        jeiko.administration_pages.views.LineUpdate.as_view(),
        name='line_update'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/delete/',
        jeiko.administration_pages.views.LineDelete.as_view(),
        name='line_delete'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/move_up/',
        jeiko.administration_pages.views.LineMoveUp.as_view(),
        name='line_move_up'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/move_down/',
        jeiko.administration_pages.views.LineMoveDown.as_view(),
        name='line_move_down'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/move_to/',
        jeiko.administration_pages.views.LineMoveTo.as_view(),
        name='line_move_to'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/move_to/',
        jeiko.administration_pages.views.BlocMoveTo.as_view(),
        name='bloc_move_to'
    ),
    # — Contenus (Blocs) —
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/content/css-preview/',
        ApercuCssQuill.as_view(),
        name='content_css_preview'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/content/add/',
        jeiko.administration_pages.views.ContentTypeChoice.as_view(),
        name='content_add'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/content/add_from_model/',
        jeiko.administration_pages.views.ContentTypeChoiceFromModel.as_view(),
        name='content_add_from_model'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/content/edit/',
        jeiko.administration_pages.views.EditContent.as_view(),
        name='content_edit'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/content/reset/',
        jeiko.administration_pages.views.ResetContent.as_view(),
        name='content_reset'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/add/',
        jeiko.administration_pages.views.BlocCreate.as_view(),
        name='bloc_add'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/delete/',
        jeiko.administration_pages.views.BlocDelete.as_view(),
        name='bloc_delete'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/move_up/',
        jeiko.administration_pages.views.BlocMoveUp.as_view(),
        name='bloc_move_up'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/move_down/',
        jeiko.administration_pages.views.BlocMoveDown.as_view(),
        name='bloc_move_down'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/move_left/',
        jeiko.administration_pages.views.BlocMoveLeft.as_view(),
        name='bloc_move_left'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/move_right/',
        jeiko.administration_pages.views.BlocMoveRight.as_view(),
        name='bloc_move_right'
    ),
    path(
        'editing-menu/',
        jeiko.administration_pages.views.editing_menu,
        name='editing_menu'
    ),
    path(
        'editing-menu-section-line/',
        jeiko.administration_pages.views.editing_menu_section_line,
        name='editing_menu_section_line'
    ),
    # — Catégories —
    path(
        'categories/',
        jeiko.administration_pages.views.Categories.as_view(),
        name='categories'
    ),
    path(
        'categories/add/',
        jeiko.administration_pages.views.CategoryAdd.as_view(),
        name='main_category_add'
    ),
    path(
        'categories/<int:main_category_id>/update/',
        jeiko.administration_pages.views.CategoryUpdate.as_view(),
        name='main_category_update'
    ),
    path(
        'categories/<int:main_category_id>/sub/add/',
        jeiko.administration_pages.views.CategoryAdd.as_view(),
        name='sub_category_add'
    ),
    path(
        'categories/<int:main_category_id>/sub/<int:sub_category_id>/update/',
        jeiko.administration_pages.views.CategoryUpdate.as_view(),
        name='sub_category_update'
    ),
    path(
        'categories/<int:main_category_id>/delete/',
        jeiko.administration_pages.views.CategoryDelete.as_view(),
        name='main_category_delete'
    ),
    path(
        'categories/<int:main_category_id>/sub/<int:sub_category_id>/delete/',
        jeiko.administration_pages.views.CategoryDelete.as_view(),
        name='sub_category_delete'
    ),

    # — APIs génériques pour les listes dynamiques —
    path('api/categories/', CategoryMainListAPI.as_view(), name='api_category_list'),
    path('api/categories/<int:category_id>/sub/', SubCategoryListAPI.as_view(), name='api_subcategory_list'),
    path('api/shop/product-types/', ProductTypeListAPI.as_view(), name='api_product_type_list'),
    path('api/custom-objects/models/', CustomObjectModelListAPI.as_view(), name='api_custom_object_model_list'),

]
