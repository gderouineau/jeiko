"""
Servir les anciennes adresses d'une page (Q-20) — voir `models.Redirection`.

Le middleware n'agit que sur une réponse 404 : une page qui existe à cette
adresse l'emporte toujours, sans qu'on la cherche ici. Il ne regarde ni
l'administration, ni l'API, ni les fichiers. Il ne mène qu'à une page EN
LIGNE : rediriger vers un brouillon ferait une 404 de plus, sous une autre
adresse.

301 : l'ancienne adresse ne reviendra pas ; Google transfère le référencement.
"""
from django.db.models import F
from django.http import HttpResponsePermanentRedirect
from django.utils import timezone

PREFIXES_IGNORES = ("/administration/", "/jeiko/", "/api/", "/static/", "/media/",
                    "/accounts/", "/oauth/", "/.well-known/")


class RedirectionsMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        reponse = self.get_response(request)
        if (reponse.status_code != 404 or request.method not in ("GET", "HEAD")
                or request.path.startswith(PREFIXES_IGNORES)):
            return reponse
        from .models import Redirection

        redirection = (Redirection.objects.select_related("page")
                       .filter(adresse=request.path, page__active=True).first())
        if redirection is None:
            return reponse
        cible = redirection.page.get_absolute_url()
        if not cible or cible == request.path:
            return reponse
        Redirection.objects.filter(pk=redirection.pk).update(
            utilisations=F("utilisations") + 1, derniere_utilisation=timezone.now())
        if request.META.get("QUERY_STRING"):
            cible = f"{cible}?{request.META['QUERY_STRING']}"
        return HttpResponsePermanentRedirect(cible)
