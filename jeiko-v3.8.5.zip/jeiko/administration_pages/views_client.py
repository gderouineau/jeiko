
from django.shortcuts import render, get_object_or_404, redirect

from django.views import View

from django.utils.decorators import method_decorator
from django.views.decorators.csrf import ensure_csrf_cookie

from django.http import Http404, HttpResponsePermanentRedirect, HttpResponseRedirect
from django.utils.translation import gettext

from jeiko.langues_du_site import langue_du_site

from jeiko.administration_pages.models import Page, Category
from jeiko.administration_pages.querysets import public_pages, with_page_tree
from jeiko.administration_pages.page_cache import build_page_cache_context



def build_breadcrumb_for_page(page):
    # Dans la langue que lit le visiteur : le nom et le slug des catégories
    # suivent, et « Accueil » mène à l'accueil de cette langue.
    langue = langue_du_site() or ""
    prefixe = f"/{langue}" if langue else ""
    items = [{'name': gettext('Accueil'), 'url': f'{prefixe}/'}]
    cat = getattr(page, 'category', None)
    sub = getattr(page, 'sub_category', None)

    if cat:
        slug = cat.slug_pour(langue)
        items.append({'name': cat.nom_pour(langue), 'url': f'{prefixe}/{slug}/' if slug else None})
    if sub and sub.main_category_id == getattr(cat, 'id', None):
        items.append({
            'name': sub.nom_pour(langue),
            'url': f'{prefixe}/{cat.slug_pour(langue)}/{sub.slug_pour(langue)}/'
            if (cat and cat.slug and sub.slug) else None,
        })

    items.append({'name': page.title, 'url': None})
    return items


def contexte_de_langue(request, page):
    """
    Ce que `base.html` doit savoir de la langue d'une page servie.

    Une page d'origine lue sous le préfixe d'une autre langue (elle n'y est pas
    traduite) déclare son adresse propre comme référence : Google n'y voit pas
    un doublon, et elle n'annonce aucune traduction.
    """
    langue = getattr(request, "langue_du_prefixe", "")
    if page.langue != langue:
        return {"canonical_url": request.build_absolute_uri(page.adresse_propre())}
    return {}


@method_decorator(ensure_csrf_cookie, name='get')
class RootPage(View):

    template_name = 'pages/main.html'

    def get(self, request, *args, **kwargs):

        # /en/ : la version anglaise de l'accueil si elle est publiée, sinon
        # l'accueil d'origine, lu sous le préfixe anglais.
        langue = getattr(request, "langue_du_prefixe", "")
        qs = with_page_tree().select_related("metadata", "traduction_de")
        page = langue and qs.filter(
            langue=langue, traduction_de__is_root=True, active=True
        ).first()
        if not page:
            page = get_object_or_404(qs, is_root=True)

        context = {
            'page': page,
            'breadcrumb': build_breadcrumb_for_page(page),
        }
        context.update(contexte_de_langue(request, page))

        metadata = getattr(page, "metadata", None)
        if metadata is not None:
            context["metadata"] = metadata

        # Cache du corps de page : la home n'a ni formulaire per-requête ni objet
        # dynamique. build_page_cache_context écarte de lui-même les pages à bloc
        # FORM/CALENDAR.
        context.update(build_page_cache_context(page))

        return render(request, self.template_name, context)


@method_decorator(ensure_csrf_cookie, name='get')
class PageView(View):
    template_name = 'pages/main.html'

    def get(self, request, *args, **kwargs):
        category_slug = kwargs.get('category_slug')
        sub_category_slug = kwargs.get('sub_category_slug')
        url_tag = kwargs.get('url_tag')
        langue = getattr(request, "langue_du_prefixe", "")

        try:
            page = self._resolve_page(category_slug, sub_category_slug, url_tag, langue)
        except Http404:
            if not langue:
                raise
            # Pas de page anglaise à cette adresse : c'est peut-être l'adresse
            # d'origine, lue sous /en/. Si la page a depuis été traduite, le
            # contrôle canonique ci-dessous redirige vers sa version anglaise.
            # On cherche donc parmi les pages d'ORIGINE, mais les segments de
            # catégorie restent ceux de l'adresse lue : /en/our-services/audit/
            # désigne la catégorie par son slug ANGLAIS.
            page = self._resolve_page(category_slug, sub_category_slug, url_tag, "",
                                      langue_des_categories=langue)

        # Canonical check (toujours un slash final dans get_absolute_url()).
        # `get_absolute_url` répond pour la langue lue : l'adresse de la
        # version anglaise, ou l'originale sous /en/ — voir langues_du_site.
        canonical_path = page.get_absolute_url()
        if request.path != canonical_path:
            if langue:
                # 302 : une traduction se publie et se dépublie, l'adresse
                # qui répond à /en/… change avec elle. Un 301 resterait dans
                # le navigateur du visiteur après le changement.
                return HttpResponseRedirect(canonical_path)
            return HttpResponsePermanentRedirect(canonical_path)

        context = {
                'page': page,
                'breadcrumb': build_breadcrumb_for_page(page),
            }
        context.update(contexte_de_langue(request, page))

        metadata = getattr(page, "metadata", None)
        if metadata is not None:
            context["metadata"] = metadata

        # Cache du corps de page (écarté automatiquement si la page porte un
        # bloc FORM ou CALENDAR — cf. page_cache.page_is_cacheable).
        context.update(build_page_cache_context(page))

        return render(
            request,
            self.template_name,
            context
        )

    # ---------- Helpers ----------
    @staticmethod
    def _categories(slug, langue, parente=None):
        """
        Les catégories que peut désigner ce segment d'adresse dans cette
        langue : celle dont c'est le slug TRADUIT d'abord, puis celle dont
        c'est le slug d'origine (une catégorie non traduite garde le sien sous
        /en/). Le plus souvent une seule ; deux quand le slug anglais de l'une
        est le slug d'origine d'une autre — on les essaie alors dans l'ordre,
        plutôt que de rendre les pages de la seconde inatteignables.
        """
        qs = Category.objects.filter(main_category=parente)
        trouvees = []
        if langue:
            trouvees += list(qs.filter(**{f"traductions__{langue}__slug": slug})[:1])
        trouvees += [c for c in qs.filter(slug=slug)[:1] if c not in trouvees]
        return trouvees

    def _resolve_page(self, category_slug, sub_category_slug, url_tag, langue="", pages=None,
                      langue_des_categories=None):
        """
        Règles:
          - /cat/sub/page/  -> page avec (cat.slug, sub.slug, url_tag) si canonique, sinon on redirige
          - /cat/page/      -> page avec (cat.slug, url_tag) si cat visible; sinon on redirige
          - /page/          -> page 'global' (pas de cat OU cat masquée)
        On select_related() pour éviter N+1 lors du check canonique.

        Toujours parmi les pages d'UNE langue : /contact/ et /en/contact/ sont
        deux pages, les chercher ensemble en trouverait deux.

        `pages` : le queryset de départ. Par défaut les pages publiques avec
        tout leur arbre préchargé — ce qu'il faut pour RENDRE la page. Qui
        veut seulement savoir quelle page répond à une adresse (la réécriture
        des liens d'un texte) passe `public_pages()` et s'épargne l'arbre.

        `langue_des_categories` : la langue dans laquelle lire les segments de
        catégorie, quand ce n'est pas celle des pages cherchées — une page
        d'origine lue sous /en/ porte les slugs ANGLAIS de ses catégories.
        """
        langue_cat = langue if langue_des_categories is None else langue_des_categories
        # public_pages() écarte les gabarits (e-mail, PDF, objet custom) : sans lui,
        # un modèle d'e-mail serait servi publiquement sur son url_tag.
        if pages is None:
            pages = with_page_tree(public_pages())
        qs = pages.filter(langue=langue).select_related(
            'category', 'sub_category', 'sub_category__main_category', 'metadata',
            'traduction_de',
        )

        if category_slug and sub_category_slug:
            # 1) Cas /cat/sub/page/
            cats = self._categories(category_slug, langue_cat)
            # On cherche d'abord le match exact (cat + sub + url_tag)
            for cat in cats:
                for sub in self._categories(sub_category_slug, langue_cat, cat):
                    try:
                        return qs.get(category=cat, sub_category=sub, url_tag=url_tag)
                    except Page.DoesNotExist:
                        continue

            cat = cats[0] if cats else None
            if cat is None or not self._categories(sub_category_slug, langue_cat, cat):
                return self._repli_ancienne_adresse(qs, url_tag, cat)
            # fallback: si une page existe pour (cat, url_tag) avec sub différent/masqué, on la récupère,
            # la 301 se fera sur la canonique plus bas
            return get_object_or_404(qs, category=cat, url_tag=url_tag)

        if category_slug and not sub_category_slug:
            # 2) Cas /cat/page/
            cats = self._categories(category_slug, langue_cat)
            if not cats:
                return self._repli_ancienne_adresse(qs, url_tag)
            # On essaye d'abord sans sous-cat visible
            for cat in cats:
                try:
                    return qs.get(category=cat, url_tag=url_tag, sub_category__isnull=True)
                except Page.DoesNotExist:
                    continue
            # Peut-être une page avec sub définie mais non visible, ou une page 'cat_sub' -> on récupère et on 301
            for cat in cats[:-1]:
                try:
                    return qs.get(category=cat, url_tag=url_tag)
                except Page.DoesNotExist:
                    continue
            return get_object_or_404(qs, category=cats[-1], url_tag=url_tag)

        # 3) Cas /page/
        # Unicité garantie par la contrainte + clean() pour pages globales
        try:
            page = qs.get(url_tag=url_tag, category__isnull=True)
            return page
        except Page.DoesNotExist:
            # Catégorie masquée (show_cat_in_url=False)
            page = get_object_or_404(qs, url_tag=url_tag, category__show_cat_in_url=False)
            return page

    @staticmethod
    def _repli_ancienne_adresse(qs, url_tag, categorie=None):
        """
        Retrouve une page dont l'adresse a perdu sa catégorie ou sa
        sous-catégorie — supprimée depuis l'administration.

        Sans ce repli, `/formations/tarifs/` tombait en 404 dès que la
        catégorie « formations » disparaissait, alors que la page vit
        toujours, en `/tarifs/`. Les liens publiés et le référencement
        mouraient sans que rien ne le signale. La page retrouvée est rendue
        au contrôle canonique de `get()`, qui redirige en 301.

        On ne devine pas : si la catégorie restante désigne la page, on la
        prend ; sinon il faut que le tag désigne UNE seule page publique. Deux
        candidates, et c'est un 404 plutôt qu'un aiguillage au hasard — la
        suppression d'une catégorie refuse d'ailleurs de créer ce cas
        (suppression_categorie.evaluer).
        """
        if categorie is not None:
            candidates = list(qs.filter(category=categorie, url_tag=url_tag)[:2])
            if len(candidates) == 1:
                return candidates[0]
        candidates = list(qs.filter(url_tag=url_tag)[:2])
        if len(candidates) != 1:
            raise Http404("Aucune page à cette adresse.")
        return candidates[0]

