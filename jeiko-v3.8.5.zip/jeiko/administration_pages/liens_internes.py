"""
Les liens écrits dans un texte suivent, eux aussi, la langue du lecteur.

Un menu ou un bouton désigne une PAGE : son adresse se calcule à chaque rendu
(`Page.get_absolute_url`). Un lien tapé dans un paragraphe, lui, est une
adresse figée — `<a href="/nos-tarifs/">`. Sur la version anglaise d'une page,
ou sur une page lue sous `/en/`, il ramenait le visiteur en français : un
clic, et il perdait son menu et sa langue.

On réécrit donc, au rendu, les `href` qui désignent une page du site — ou une
fiche, ou un produit — vers l'adresse où CE lecteur la lit. Tout le reste est
laissé tel quel : adresses externes, ancres, fichiers, routes qui n'ont pas
d'adresse par langue (`/shop/cart/`), et adresses qui ne mènent à rien — un
lien cassé reste cassé, ce n'est pas ici qu'on le devine.

Rien ne se passe pour un lecteur de la langue d'origine, ni hors du site
public : le texte sort identique à ce qu'il était.
"""

import re

from django.http import Http404

from jeiko import langues_du_site

_HREF = re.compile(r'(<a\b[^>]*?\bhref=)(["\'])(/[^"\'#?]*)([#?][^"\']*)?\2', re.I)


def _page_a(chemin):
    """
    La page d'origine dont `chemin` est EXACTEMENT l'adresse, ou `None`.

    On s'appuie sur la résolution des adresses du site (`PageView`), puis on
    vérifie que la page trouvée vit bien à cette adresse : cette résolution
    sait aussi rattraper d'anciennes adresses (`/categorie-supprimee/page/`),
    et un lien vers `/shop/panier/` ne doit pas être réécrit parce qu'une page
    s'appelle « panier ».
    """
    from .models import Page
    from .querysets import public_pages
    from .views_client import PageView

    segments = [s for s in chemin.split("/") if s]
    if len(segments) > 3:
        return None
    attendue = "/" + "".join(f"{s}/" for s in segments)
    if not segments:
        page = Page.objects.filter(is_root=True).first()
    else:
        # /page/, /catégorie/page/ ou /catégorie/sous-catégorie/page/.
        categorie = segments[0] if len(segments) >= 2 else None
        sous_categorie = segments[1] if len(segments) == 3 else None
        try:
            # Sans l'arbre de la page : on ne veut que son adresse.
            page = PageView()._resolve_page(
                categorie, sous_categorie, segments[-1], "", pages=public_pages()
            )
        except (Http404, Page.MultipleObjectsReturned):
            return None
    if page is None or page.adresse_propre() != attendue:
        return None
    return page


def _fiche_a(chemin):
    """
    La fiche d'origine qui vit EXACTEMENT à `chemin` (`/co/…` ou la page d'un
    produit), ou `None`. On demande au routeur quelle vue sert cette adresse,
    plutôt que d'en redire la forme ici.
    """
    from django.urls import Resolver404, resolve

    from jeiko.custom_objects.models import CustomObject
    from jeiko.custom_objects.views.client import CustomObjectView
    from jeiko.shop.views.client import ProductView

    try:
        trouve = resolve(chemin)
    except Resolver404:
        return None
    vue = getattr(trouve.func, "view_class", None)
    fiches = CustomObject.objects.filter(langue="").select_related("model", "product__type")
    if vue is CustomObjectView:
        fiche = fiches.filter(
            model__slug=trouve.kwargs["model_slug"], slug=trouve.kwargs["object_slug"]
        ).first()
    elif vue is ProductView:
        fiche = fiches.filter(
            product__sku=trouve.kwargs["product_sku"],
            product__type__code=trouve.kwargs["product_type_code"],
        ).first()
    else:
        return None
    return fiche if fiche is not None and fiche.adresse_propre() == chemin else None


def suivre_la_langue(html):
    langue = langues_du_site.langue_du_site()
    if not langue or "href=" not in html:
        return html

    def remplacer(trouve):
        debut, guillemet, chemin, suite = trouve.groups()
        if chemin.startswith("//"):
            return trouve.group(0)
        prefixe, reste = langues_du_site.prefixe_de_langue(chemin)
        if prefixe:  # déjà écrit pour une langue : on n'y touche pas
            return trouve.group(0)
        page = _page_a(reste) or _fiche_a(reste)
        if page is None:
            return trouve.group(0)
        adresse = langues_du_site.adresse_dans(page, langue)
        return f"{debut}{guillemet}{adresse}{suite or ''}{guillemet}"

    return _HREF.sub(remplacer, html)
