"""
Les textes que les SCRIPTS de l'éditeur de pages affichent.

Le problème
-----------
Un gabarit se traduit avec `{% translate %}`. Un script servi en fichier
statique, non : `editor.js` écrit ses confirmations et ses erreurs en français,
et rien dans Django ne les voit. L'éditeur restait donc mi-français pour une
équipe qui travaille en anglais.

Ce que fait ce module
---------------------
Il tient la liste de ces textes, marqués pour les catalogues. `base_editor.html`
en tire un dictionnaire { français : traduction } posé dans `window.JK_TEXTES`,
que lit `tr()` (`static/jeiko/js/editor/textes.js`). En français le
dictionnaire est vide : le script affiche son propre texte.

La liste et les scripts doivent dire la même chose : `tests/test_textes_editeur.py`
compare les `tr("…")` des scripts à cette liste, dans les deux sens.

Ce qu'il ne fait pas : il ne couvre que l'éditeur. Le site public n'a pas de
script traduit par ce biais — ses textes viennent des gabarits.
"""

from django.utils.translation import gettext
# `gettext_noop` : la liste garde le texte FRANÇAIS, qui est la clé que le
# script connaît ; la traduction se fait au moment de bâtir le dictionnaire.
from django.utils.translation import gettext_noop as _

TEXTES = [
    _("Opération réussie"),
    _("Erreur réseau"),
    _("Merci de saisir un nom de modèle."),
    _("Erreur lors de la création du modèle."),
    _("Couleur du texte"),
    _("Couleur de fond"),
    _("Édition indisponible : %(erreur)s Fermez puis réouvrez le bloc."),
    _("Créer une section"),
    _("Section créée"),
    _("Modifier la section"),
    _("Cette action est définitive."),
    _("%(elements)s seront perdus. Cette action est définitive."),
    _(" et "),
    _("ligne"),
    _("lignes"),
    _("bloc"),
    _("blocs"),
    _("Supprimer cette section ?"),
    _("Section supprimée"),
    _("Aucune section créée pour l'instant"),
    _("Supprimer"),
    _("Section déplacée vers le haut"),
    _("Section déplacée vers le bas"),
    _("Modèle créé"),
    _("ID de section manquant."),
    _("Créer une ligne"),
    _("Ligne créée"),
    _("Modifier la ligne"),
    _("Supprimer cette ligne ?"),
    _("Ligne supprimée"),
    _("Déplacer la ligne vers une autre section"),
    _("Déplacer le bloc vers une autre ligne"),
    _("Ligne déplacée vers le haut"),
    _("Ligne déplacée vers le bas"),
    _("Modèle de ligne créé"),
    _("ID de ligne manquant."),
    _("Choisir le type de contenu"),
    _("Édition du contenu"),
    _("Remettre ce contenu à zéro ?"),
    _("Contenu réinitialisé"),
    _("Le contenu actuel sera effacé et vous choisirez un nouveau type."),
    _("Remettre à zéro"),
    _("Supprimer ce bloc ?"),
    _("Son contenu sera perdu. Cette action est définitive."),
    _("Modèle de contenu créé"),
    _("ID de contenu manquant."),
    _("Modèle de bloc créé"),
    _("ID de bloc manquant."),
    _("Erreur lors de l’insertion du modèle"),
    _("Bloc inséré depuis modèle"),
    _("Ajouter un champ"),
    _("Éditer le champ"),
    _("Label"),
    _("Nom technique"),
    _("Placeholder"),
    _("(facultatif)"),
    _("Type"),
    _("Obligatoire"),
    _("Options (JSON ou valeurs séparées par virgule pour select/checkbox)"),
    _("ou"),
    _("Ajouter"),
    _("Enregistrer"),
    _("Annuler"),
    _("Le label est obligatoire."),
    _("Le nom technique est obligatoire."),
    _("Zone d'édition introuvable (#field-inline-editor)."),
    _("Échec de l'ajout du champ."),
    _("Impossible de charger le champ."),
    _("Échec de la mise à jour du champ."),
    _("Supprimer le champ « %(label)s » ?"),
    _("Supprimer ce champ ?"),
    _("Les réponses déjà reçues ne sont pas supprimées."),
    _("Réordonnancement impossible."),
    _("nom :"),
    _("Éditer"),
    _("Monter"),
    _("Descendre"),
    _("Style enregistré ✔︎"),
    _("Erreur de chargement : %(url)s"),
    _("Confirmer"),
    _("Fermer"),
    _("Contexte public du bloc introuvable."),
    _("Chargement Quill introuvable."),
    _("Texte éditable dans le contexte du site"),
    _("La feuille Quill ne peut pas être isolée."),
    _("Une feuille de contenu ne peut pas être chargée."),
    _("Quill ne peut pas être chargé dans le contexte isolé."),
    _("Délai de chargement du contexte dépassé."),
    _("Contenu du texte"),
    # Les libellés que Quill écrit par CSS : voir `libellesDeQuill`.
    _("Normal"),
    _("Titre %(niveau)s"),
    _("Petit"),
    _("Grand"),
    _("Très grand"),
    _("Ouvrir le lien :"),
    _("Adresse du lien :"),
    _("Modifier"),
    _("Retirer le lien"),
    _("Réponse HTTP %(statut)s, fermez puis réouvrez le bloc."),
    _("Paramètres CSS invalides."),
    _("Aperçu CSS non actualisé : %(erreur)s Le brouillon reste dans le formulaire."),
    _("Expiré"),
]


def dictionnaire():
    """{ texte français : traduction }, limité aux textes réellement traduits."""
    return {t: gettext(t) for t in TEXTES if gettext(t) != t}
