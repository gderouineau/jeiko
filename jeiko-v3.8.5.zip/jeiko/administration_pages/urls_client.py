from django.urls import path
import jeiko.administration_pages.views_client as views
from jeiko.administration_pages import vues_langues
from jeiko.langues_du_site import SEGMENT_DES_LANGUES

app_name = 'jeiko_pages'
urlpatterns = [
    path('', views.RootPage.as_view(), name='root_page'),

    # L'écran « Langues » d'un site en plusieurs langues. AVANT les pages :
    # leurs motifs attrapent tout ce qui ressemble à un slug.
    path(f'{SEGMENT_DES_LANGUES}/', vues_langues.PageDesLangues.as_view(), name='langues'),
    path(f'{SEGMENT_DES_LANGUES}/<slug:code>/', vues_langues.LangueChoisie.as_view(), name='langue_choisie'),

    # /cat/sub/page/
    path('<slug:category_slug>/<slug:sub_category_slug>/<slug:url_tag>/',
         views.PageView.as_view(), name='page_view_cat_sub'),

    # /cat/page/
    path('<slug:category_slug>/<slug:url_tag>/',
         views.PageView.as_view(), name='page_view_cat'),

    # /page/
    path('<slug:url_tag>/',
         views.PageView.as_view(), name='page_view'),
]
