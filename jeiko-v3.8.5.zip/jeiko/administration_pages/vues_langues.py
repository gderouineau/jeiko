"""
L'écran « Langues » — où le visiteur d'un site en plusieurs langues choisit la
sienne. Voir `jeiko/langues_du_site.py` pour les règles du site multilingue.

Le besoin
---------
Le pied de page alignait une ligne de langues sous les liens obligatoires :
une rangée de plus sur chaque page, qui s'allonge à chaque langue ajoutée. Il
porte désormais UN lien, « Langues », rangé avec les mentions légales et la
connexion ; ce lien mène ici.

Ce que fait l'écran
-------------------
Il propose chaque langue du site sous son propre nom, et ramène le visiteur LÀ
D'OÙ IL VIENT, dans la langue choisie :

* **depuis une page du site** (`?p=<id>`) — chaque langue est un lien direct
  vers l'adresse de cette page dans cette langue : sa version si elle est
  publiée, l'originale sous le préfixe sinon. De vrais liens, que Google suit ;
  c'est la page d'arrivée qui retient la langue, comme toujours.
* **depuis une fiche ou un produit** (`?f=<id>` de la fiche d'origine) — de
  même : un lien direct vers cette fiche dans chaque langue.
* **depuis un autre écran** (`?retour=<chemin>` : panier, connexion, compte…)
  — ces écrans n'ont pas d'adresse par langue : leur langue est celle du
  cookie. Le choix passe donc par `LangueChoisie`, qui retient la langue et
  renvoie au même écran.

Ce qu'il ne fait pas
--------------------
* Il n'existe pas sur un site monolingue : `/lang/` y reste l'adresse d'une
  page ordinaire, et `/lang/<x>/` celle d'une page rangée dans une catégorie
  « lang », si le site en a. Une mise à jour ne doit cacher aucune page.
* Il ne devine rien : ni le navigateur ni l'adresse IP ne choisissent à la
  place du visiteur.
"""

from urllib.parse import urlencode

from django.shortcuts import redirect, render
from django.urls import reverse
from django.views import View

from jeiko import langues_du_site
from jeiko.administration_pages.models import Page
from jeiko.administration_pages.querysets import public_pages
from jeiko.redirections import destination_sure


class PageDesLangues(View):
    template_name = "pages/langues.html"

    def get(self, request):
        actives = langues_du_site.langues_actives()
        if not actives:
            # Site monolingue : cette adresse n'est pas la nôtre. Une page
            # nommée « lang » avant l'arrivée de cet écran reste servie.
            from jeiko.administration_pages.views_client import PageView

            return PageView.as_view()(request, url_tag=langues_du_site.SEGMENT_DES_LANGUES)

        # Une page ou une fiche : les deux savent dire leur adresse par langue.
        page = self._page(request.GET.get("p")) or self._fiche(request.GET.get("f"))
        retour = destination_sure(request, request.GET.get("retour"), "")
        origine = langues_du_site.langue_d_origine()
        courante = langues_du_site.langue_du_site() or ""
        choix = []
        for langue in ["", *actives]:
            code = langue or origine
            if page is not None:
                url = langues_du_site.adresse_dans(page, langue)
            else:
                url = reverse("jeiko_pages:langue_choisie", args=[code])
                if retour:
                    url += "?" + urlencode({"retour": retour})
            choix.append({
                "code": code,
                "nom": langues_du_site.nom_de_la_langue(langue),
                "url": url,
                "courante": langue == courante,
            })

        # L'adresse de cet écran, rebâtie avec ce qu'il a RETENU de sa requête :
        # le pied de page y renvoie, et n'a pas à recopier un paramètre que
        # personne n'a vérifié.
        if page is not None:
            suite = {"p" if isinstance(page, Page) else "f": page.pk}
        else:
            suite = {"retour": retour} if retour else {}
        reponse = render(request, self.template_name, {
            "choix": choix,
            # Un lien de bascule n'est pas une page : on ne l'offre pas aux robots.
            "liens_directs": page is not None,
            "adresse_de_l_ecran": reverse("jeiko_pages:langues") + (f"?{urlencode(suite)}" if suite else ""),
        })
        # Un écran utilitaire, décliné par `?p=` : rien à ranger dans un index.
        reponse["X-Robots-Tag"] = "noindex"
        return reponse

    @staticmethod
    def _page(identifiant):
        """La page d'où vient le visiteur — publique, ou rien."""
        try:
            return public_pages().filter(pk=int(identifiant)).first()
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _fiche(identifiant):
        """La fiche d'ORIGINE d'où vient le visiteur — publique, ou rien."""
        from jeiko.custom_objects.versions import fiches_publiques

        try:
            return fiches_publiques().filter(pk=int(identifiant), langue="").first()
        except (TypeError, ValueError):
            return None


class LangueChoisie(View):
    """
    Retient la langue choisie et renvoie d'où l'on vient.

    Un GET qui pose un cookie : c'est voulu. Choisir sa langue ne modifie rien
    sur le site, se rejoue sans dommage, et doit rester un simple lien — pas un
    formulaire à soumettre pour changer de langue sur l'écran de connexion.
    """

    def get(self, request, code):
        actives = langues_du_site.langues_actives()
        origine = langues_du_site.langue_d_origine()
        if not actives or code not in (origine, *actives):
            # Pas une langue de ce site : cette adresse n'est pas la nôtre. Un
            # site qui range ses pages dans une catégorie « lang » — les
            # langages d'un cours de programmation — continue de les servir ;
            # sinon c'est un 404, comme avant.
            from jeiko.administration_pages.views_client import PageView

            return PageView.as_view()(
                request, category_slug=langues_du_site.SEGMENT_DES_LANGUES, url_tag=code)
        # À partir d'ici la requête EST dans la langue choisie : le middleware
        # la retient dans le cookie au retour, par le même chemin que pour une
        # page lue — et l'accueil ci-dessous est celui de cette langue.
        langues_du_site.fixer_la_langue("" if code == origine else code)
        return redirect(destination_sure(request, request.GET.get("retour"), langues_du_site.accueil()))
