"""
Les images écrites dans un TEXTE servent, elles aussi, la taille qui convient.

Le problème
-----------
Un bloc image propose cinq fichiers (767, 991, 1200, 1500, 1920 px) et laisse
le navigateur choisir. Une image posée dans un bloc de texte — par l'éditeur,
ou par un agent qui écrit du HTML — n'est qu'un `<img src="…">` : un seul
fichier, en général la variante « ordinateur ». Un téléphone téléchargeait donc
1 500 px pour en afficher 700. PageSpeed le relevait sur chaque page d'un site
illustré de cette façon (accompagnementhumain.com : 64 Kio de trop sur 132).

Ce que fait ce module
---------------------
Au rendu public d'un texte, il reconnaît les `<img>` dont le `src` est une
variante d'une image de la médiathèque, et leur ajoute `srcset` (toutes les
variantes de la même image) et `sizes`. Le contenu enregistré n'est pas
modifié : remplacer l'image dans la médiathèque suffit à tout mettre à jour.

`sizes` vaut « la largeur de l'écran, sans dépasser celle du fichier d'origine ».
Ce plafond n'est pas décoratif : dès qu'une image porte un `srcset` en largeurs,
sa largeur naturelle devient la valeur de `sizes`. Sans plafond, une vignette
de 300 px posée dans un paragraphe se mettrait à occuper toute la ligne.

Ce qu'il ne fait pas
--------------------
* Il ne touche pas une image extérieure à la médiathèque, ni une image qui
  porte déjà un `srcset`, ni une image sans au moins deux largeurs différentes.
* Il ne connaît pas la mise en page : une image affichée en petit sur un grand
  écran (deux colonnes) reçoit encore un fichier plus large que nécessaire.
  Le gain est sur téléphone, où l'image occupe la largeur de l'écran.
"""
import re
from urllib.parse import unquote

from django.conf import settings
from django.db.models import Q
from django.utils.html import escape

#: Les variantes, de la plus étroite à la plus large. La largeur réelle se lit
#: sur le fichier : une image d'origine de 950 px n'est pas agrandie, et sa
#: variante « 1200 » fait 950 px.
VARIANTES = ("mobile_size", "tablet_size", "laptop_size", "computer_size", "full_size")
CHAMPS = VARIANTES + ("original_image",)

_IMG = re.compile(r"<img\b[^>]*>", re.IGNORECASE)
_SRC = re.compile(r"""\bsrc\s*=\s*(["'])(.*?)\1""", re.IGNORECASE | re.DOTALL)


def _largeur(fichier):
    """La largeur du fichier, ou `None` s'il est absent ou illisible."""
    if not fichier:
        return None
    try:
        return fichier.width
    except Exception:  # fichier manquant sur le disque, image corrompue…
        return None


def enrichir(html):
    """Ajoute `srcset` et `sizes` aux images de la médiathèque présentes dans `html`."""
    if "<img" not in html.lower():
        return html
    media = settings.MEDIA_URL
    cibles = {}  # balise complète → chemin du fichier dans MEDIA_ROOT
    for trouve in _IMG.finditer(html):
        balise = trouve.group(0)
        if "srcset" in balise.lower():
            continue
        src = _SRC.search(balise)
        if src and src.group(2).startswith(media):
            cibles[balise] = unquote(src.group(2)[len(media):])
    if not cibles:
        return html

    from .models import ImageContent

    chemins = set(cibles.values())
    filtre = Q()
    for champ in CHAMPS:
        filtre |= Q(**{f"{champ}__in": chemins})
    par_chemin = {}
    for image in ImageContent.objects.filter(filtre):
        for champ in CHAMPS:
            nom = getattr(image, champ).name
            if nom in chemins:
                par_chemin[nom] = image

    for balise, chemin in cibles.items():
        image = par_chemin.get(chemin)
        if image is None:
            continue
        candidats = {}  # largeur → adresse ; à largeur égale, la première suffit
        for champ in VARIANTES:
            fichier = getattr(image, champ)
            largeur = _largeur(fichier)
            if largeur:
                candidats.setdefault(largeur, fichier.url)
        if len(candidats) < 2:
            continue
        actuel = next(
            (getattr(image, c) for c in CHAMPS if getattr(image, c).name == chemin), None
        )
        plafond = _largeur(actuel) or max(candidats)
        srcset = ", ".join(f"{escape(url)} {l}w" for l, url in sorted(candidats.items()))
        ajout = f' srcset="{srcset}" sizes="(max-width: {plafond}px) 100vw, {plafond}px"'
        fin = "/>" if balise.rstrip().endswith("/>") else ">"
        neuve = balise.rstrip()[: -len(fin)].rstrip() + ajout + fin
        html = html.replace(balise, neuve)
    return html
