"""
Les versions d'une page dans les langues du site — créer, lister, éteindre.

Une page se présente UNE fois dans l'administration ; on bascule ensuite d'une
langue à l'autre de l'intérieur (réglages, éditeur). En dessous, chaque langue
est une `Page` complète reliée à l'originale : l'éditeur l'ouvre telle quelle,
sans rien savoir des langues. Les règles d'ensemble sont dans
`jeiko/langues_du_site.py`.

Ce que ce module ne fait pas : traduire. Une version naît copie conforme de
l'originale, brouillon ; c'est à la main qu'elle devient anglaise.
"""

from typing import NamedTuple

from django.db import transaction
from django.utils.translation import gettext as _

from jeiko import langues_du_site

from .models import Category, Page

#: Ce qui n'a PAS de version par langue : le corps d'un e-mail — les e-mails
#: partent dans la langue du site — et une page PDF. Le gabarit d'une fiche,
#: lui, en a une : c'est lui qui porte les textes fixes de la fiche anglaise
#: (« Description », « Ajouter au panier »), autour des valeurs de la fiche.
SANS_VERSION = ("is_mail_template", "is_pdf")


class VersionImpossible(ValueError):
    """Le message est destiné à l'administrateur, dans sa langue."""


class Depubliees(NamedTuple):
    """Ce qu'une langue retirée a sorti du site : ses pages, ses fiches."""

    pages: int
    fiches: int


def est_traduisible(page):
    """Une page du site ou le gabarit d'une fiche ; pas un e-mail, pas un PDF."""
    return not any(getattr(page, drapeau) for drapeau in SANS_VERSION)


def etat_des_versions(page):
    """
    Ce qu'affiche le sélecteur de langue d'une page : l'originale, puis une
    entrée par langue active — avec sa version si elle existe, `None` sinon.
    Vide pour un site monolingue ou une page qui ne se traduit pas.
    """
    actives = langues_du_site.langues_actives()
    if not actives or not est_traduisible(page):
        return []
    origine = page.origine
    existantes = {v.langue: v for v in origine.traductions.all()}
    return [
        {"code": langues_du_site.langue_d_origine(), "langue": "", "page": origine,
         "nom": langues_du_site.nom_de_la_langue(""), "courante": page.pk == origine.pk},
    ] + [
        {"code": code, "langue": code, "page": existantes.get(code),
         "nom": langues_du_site.nom_de_la_langue(code),
         "courante": bool(existantes.get(code)) and existantes[code].pk == page.pk}
        for code in actives
    ]


@transaction.atomic
def creer_version(page, langue):
    """
    Duplique l'originale de `page` dans `langue` et rend la nouvelle version.

    Elle naît BROUILLON, avec le titre, l'adresse, le contenu et la mise en
    page de l'originale : rien d'anglais n'est en ligne tant que la traduction
    n'est pas faite et publiée. Entre-temps le visiteur anglais lit l'originale
    sous /en/, comme pour toute page non traduite.
    """
    # Import tardif : `utils` importe les formulaires, qui importent les modèles.
    from .utils import duplicate_instance, section_duplicate

    origine = page.origine
    if langue not in langues_du_site.langues_actives():
        raise VersionImpossible(_("Cette langue n'est pas activée pour le site."))
    if not est_traduisible(origine):
        raise VersionImpossible(_("Le corps d'un e-mail et une page PDF n'ont pas de version par langue."))
    if origine.traductions.filter(langue=langue).exists():
        raise VersionImpossible(_("Cette page existe déjà dans cette langue."))

    version = duplicate_instance(
        origine,
        omit_fields=["id", "pk"],
        # Ce qui tient à l'originale et à elle seule ne se copie pas : son
        # rang d'accueil (la version l'est par elle), sa protection contre la
        # suppression, son drapeau de page légale « telle que livrée ».
        overrides={"langue": langue, "traduction_de": origine, "active": False,
                   "is_root": False, "is_protected": False,
                   "is_default_legal_template": False},
    )
    metadonnees = getattr(origine, "metadata", None)
    if metadonnees is not None:
        duplicate_instance(metadonnees, omit_fields=["id", "pk", "page"],
                           overrides={"page": version})
    for section in origine.sections.all().order_by("position", "id"):
        section_duplicate(section, target_page=version, position=section.position)
    return version


def codes_deja_pris(codes):
    """
    Parmi `codes`, ceux qu'une page ou une catégorie occupe déjà à la racine du
    site : `/en/` ne peut pas être à la fois une page et l'accueil anglais.
    Ces slugs sont réservés depuis l'arrivée des langues ; ne restent que ceux
    d'avant.
    """
    pris = set(
        Page.objects.filter(langue="", url_tag__in=codes)
        .exclude(category__show_cat_in_url=True).values_list("url_tag", flat=True)
    )
    pris |= set(
        Category.objects.filter(main_category__isnull=True, slug__in=codes, show_cat_in_url=True)
        .values_list("slug", flat=True)
    )
    return sorted(pris)


@transaction.atomic
def regler_les_langues(site, *, multilingue, langues):
    """
    Enregistre l'option et les langues du site.

    Une langue retirée — ou l'option éteinte — DÉPUBLIE les pages et les
    fiches de cette langue : elles ne sont plus servies, et ne reviennent pas
    en ligne toutes seules si la langue est réactivée. On ne supprime rien :
    le travail de traduction reste dans l'administration. Rend leur nombre
    (`Depubliees`).
    """
    from .page_cache import bump_links_version

    langues = [c for c in langues_du_site.codes_proposes() if c in set(langues)]
    pris = codes_deja_pris(langues) if multilingue else []
    if pris:
        raise VersionImpossible(
            _("Une page ou une catégorie occupe déjà l'adresse /%(code)s/ : "
              "renommez-la avant d'activer cette langue.") % {"code": pris[0]}
        )

    site.multilingue = bool(multilingue)
    site.langues_du_site = langues
    site.save(update_fields=["multilingue", "langues_du_site"])
    # Le signal de `save()` a vidé le cache du site — mais nous sommes dans une
    # transaction : une autre requête peut le relire AVANT le commit et y
    # remettre l'ancien réglage, pour vingt-quatre heures. On le vide donc une
    # seconde fois, une fois le changement visible de tous.
    from jeiko.administration.website_cache import invalidate_website_data
    transaction.on_commit(invalidate_website_data)

    # La suite de la requête (la réponse de l'API, par exemple) doit lire les
    # nouvelles langues, pas celles relevées en début de requête.
    langues_du_site.oublier_les_langues_actives()

    from jeiko.custom_objects.models import CustomObject

    restantes = langues if multilingue else []
    eteintes = Page.objects.exclude(langue="").exclude(langue__in=restantes).filter(active=True)
    pages = eteintes.update(active=False)
    fiches = (
        CustomObject.objects.exclude(langue="").exclude(langue__in=restantes)
        .filter(is_published=True).update(is_published=False)
    )
    # `.update()` n'émet aucun signal : on invalide à la main ce que les
    # adresses de ces pages et de ces fiches avaient laissé en cache.
    bump_links_version()
    from jeiko.administration_menu.models import invalider_tous_les_menus
    invalider_tous_les_menus()
    return Depubliees(pages, fiches)
