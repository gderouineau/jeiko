"""
Compte d'administration initial d'un site, prêt à la première connexion (O-05).

    DJANGO_SU_NAME=… DJANGO_SU_EMAIL=… DJANGO_SU_PASS=… manage.py jeiko_compte_initial

Appelée par l'installeur (`INSTALLER/scripts/14_finalize.sh`). Le mot de passe
passe par l'environnement du processus, jamais par la ligne de commande : il
n'apparaît ni dans `ps`, ni dans le journal d'installation.

Le problème
-----------
Depuis `ACCOUNT_EMAIL_VERIFICATION = "mandatory"`, allauth refuse la connexion
à tout compte dont l'adresse n'est pas confirmée dans SA table
(`account.EmailAddress`). `createsuperuser` n'y écrit rien : le superutilisateur
créé à l'installation, seul compte du site, ne pouvait pas entrer — il devait
d'abord recevoir un e-mail que le site, tout juste installé, n'a encore aucun
moyen d'envoyer (les réglages SMTP se saisissent… une fois connecté).

Ce que fait la commande
-----------------------
Elle crée le compte s'il n'existe pas, puis enregistre SON adresse comme
confirmée et principale. C'est une confiance accordée à celui qui installe le
serveur, pas une règle du site : aucun autre compte n'est touché, les
inscriptions publiques et les changements d'adresse restent soumis à
confirmation.

Elle refuse plutôt que d'annoncer un site utilisable quand :
* l'adresse est absente ou invalide — le compte ne pourrait pas se connecter ;
* l'adresse appartient déjà à un autre compte — la confirmer lui donnerait
  deux propriétaires ;
* le compte existe avec une AUTRE adresse — on ne réécrit pas l'identité d'un
  compte en service sur la foi d'une réinstallation.

Rejouable : relancée, elle ne crée aucun doublon et ne change jamais le mot de
passe d'un compte existant.
"""

import os

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.management.base import BaseCommand, CommandError
from django.core.validators import validate_email
from django.db import transaction


class Command(BaseCommand):
    help = (
        "Crée (ou complète) le compte d'administration initial et confirme son "
        "adresse. Lit DJANGO_SU_NAME, DJANGO_SU_EMAIL et DJANGO_SU_PASS."
    )

    def handle(self, *args, **options):
        from allauth.account.models import EmailAddress

        nom = os.environ.get("DJANGO_SU_NAME", "").strip()
        email = os.environ.get("DJANGO_SU_EMAIL", "").strip()
        mot_de_passe = os.environ.get("DJANGO_SU_PASS", "")

        if not nom:
            raise CommandError("DJANGO_SU_NAME est vide : aucun compte à créer.")
        if not email:
            raise CommandError(
                "Aucune adresse e-mail pour le compte initial. La connexion exige "
                "une adresse confirmée : sans elle, le compte ne pourrait pas entrer."
            )
        try:
            validate_email(email)
        except ValidationError:
            raise CommandError(f"Adresse e-mail invalide : {email!r}.")

        User = get_user_model()
        with transaction.atomic():
            compte = User.objects.select_for_update().filter(username=nom).first()

            # L'adresse ne doit appartenir à personne d'autre, ni dans la table
            # d'allauth, ni sur un compte Django.
            autre = (
                EmailAddress.objects.filter(email__iexact=email)
                .exclude(user=compte).select_related("user").first()
            )
            autre_compte = (
                User.objects.filter(email__iexact=email).exclude(pk=getattr(compte, "pk", None)).first()
            )
            if autre or autre_compte:
                titulaire = autre.user if autre else autre_compte
                raise CommandError(
                    f"L'adresse {email} appartient déjà au compte "
                    f"« {titulaire.get_username()} ». Choisissez une autre adresse "
                    f"pour le compte initial."
                )

            if compte is None:
                if len(mot_de_passe) < 12:
                    raise CommandError(
                        "DJANGO_SU_PASS absent ou trop court (12 caractères minimum)."
                    )
                compte = User.objects.create_superuser(nom, email, mot_de_passe)
                self.stdout.write(f"✅ Compte d'administration « {nom} » créé.")
            else:
                if compte.email and compte.email.lower() != email.lower():
                    raise CommandError(
                        f"Le compte « {nom} » existe déjà avec l'adresse "
                        f"{compte.email}, pas {email}. Rien n'a été modifié : "
                        f"corrigez l'adresse depuis l'administration si besoin."
                    )
                champs = []
                if not compte.email:
                    compte.email = email
                    champs.append("email")
                if not (compte.is_superuser and compte.is_staff):
                    compte.is_superuser = compte.is_staff = True
                    champs += ["is_superuser", "is_staff"]
                if champs:
                    compte.save(update_fields=champs)
                    self.stdout.write(f"✅ Compte « {nom} » complété ({', '.join(champs)}).")
                else:
                    self.stdout.write(
                        f"ℹ️  Compte « {nom} » déjà présent, mot de passe inchangé."
                    )

            adresse = EmailAddress.objects.filter(user=compte, email__iexact=email).first()
            if adresse is None:
                adresse = EmailAddress.objects.create(
                    user=compte, email=email, verified=True, primary=False
                )
            elif not adresse.verified:
                adresse.verified = True
                adresse.save(update_fields=["verified"])
            # Une seule adresse principale par compte : `set_as_primary`
            # d'allauth rétrograde les autres.
            if not adresse.primary:
                adresse.set_as_primary(conditional=False)

        self.stdout.write(f"✅ Adresse {email} confirmée : la première connexion est possible.")
