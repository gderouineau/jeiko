from django.contrib import admin

from .models import (
    # Rôles & permissions
    Role, RolePermission, RoleAssignment,
    # Providers OAuth/OIDC
    ProviderConfig,
    # Sécurité
    TwoFactorDevice, SecurityEvent, UserSession,
    # Consentements & marketing
    Consent, MarketingPreference,
    # Notifications
    NotificationChannel, Notification,
    # Bridge Prospect
    ProspectLink,
    # Tes modèles existants
    Profile, Comments,
)

# Enregistrement simple de tous les modèles
admin.site.register(Role)
admin.site.register(RolePermission)
admin.site.register(RoleAssignment)

# Les secrets chiffrés au repos ne sont pas montrés : le Django admin les
# afficherait déchiffrés (voir administration/admin.py).
@admin.register(ProviderConfig)
class ProviderConfigAdmin(admin.ModelAdmin):
    exclude = ("client_secret",)


@admin.register(TwoFactorDevice)
class TwoFactorDeviceAdmin(admin.ModelAdmin):
    exclude = ("secret_or_credential",)

admin.site.register(SecurityEvent)
admin.site.register(UserSession)

admin.site.register(Consent)
admin.site.register(MarketingPreference)

admin.site.register(NotificationChannel)
admin.site.register(Notification)

admin.site.register(ProspectLink)

admin.site.register(Profile)
admin.site.register(Comments)
