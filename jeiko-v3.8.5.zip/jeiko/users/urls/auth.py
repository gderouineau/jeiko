from django.urls import path
from ..views.auth import (
    CustomSignupView,
    CustomLoginView,
    CustomLogoutView,
    RenvoyerConfirmationView,
    TwoFactorVerifyView,
)

app_name = 'jeiko_allauth'

urlpatterns = [
    # Inscription / connexion / déconnexion
    path('signup/', CustomSignupView.as_view(), name='signup'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', CustomLogoutView.as_view(), name='logout'),

    # Second facteur : saisie du code reçu par e-mail.
    #
    # Était servi à `2fa/`, adresse de la page de gestion d'allauth.mfa
    # (`mfa_index`). Déclarée avant les URL d'allauth, celle-ci l'emportait :
    # la gestion de la double authentification renvoyait à la connexion
    # (28/09/2026). Les deux vivent désormais à des adresses distinctes.
    path('code-par-email/', TwoFactorVerifyView.as_view(), name='twofa_verify'),

    # Renvoi du lien de confirmation, depuis l'écran d'attente. POST seul : il
    # fait partir un e-mail.
    path('confirmation/renvoyer/', RenvoyerConfirmationView.as_view(),
         name='renvoyer_confirmation'),
]