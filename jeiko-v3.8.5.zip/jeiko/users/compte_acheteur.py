"""
Le compte créé au moment de commander.

Une commande exige un compte (`payments.views.client.CheckoutView`) : c'est lui
qui reçoit la formation ou le questionnaire acheté. Mais renvoyer l'acheteur
vers l'inscription au moment de payer, c'est lui faire saisir deux fois son
nom, valider un e-mail, revenir — le meilleur moyen de perdre la vente.
Décision de Guillaume (04/10/2026) : le compte se crée dans l'écran des
coordonnées. Il ne demande qu'un mot de passe ; le nom vient de l'adresse de
facturation, l'e-mail est celui qu'on lui demande à côté.

Ce qui diffère de l'inscription normale
---------------------------------------
L'adresse n'est **pas confirmée** quand la session s'ouvre : on ouvre la
session sans attendre le lien, sinon l'acheteur resterait bloqué devant le
paiement. Le lien de confirmation part quand même. Tant qu'il n'est pas
suivi, la règle du site s'applique aux connexions SUIVANTES : il faudra
confirmer pour revenir. La purge des comptes non confirmés épargne déjà
tout compte porteur d'une commande (`users/purge.py`).

Ce qui ne change pas : les plafonds anti-abus de l'inscription
(`users/throttling.py`) — créer un compte écrit en base et envoie un e-mail,
qu'on le fasse depuis /accounts/signup/ ou depuis le panier — et le refus
d'une adresse déjà prise : on ne rattache jamais une commande à un compte
existant sans que la personne s'y soit connectée.
"""

import logging

from django.contrib.auth import get_user_model, login
from django.db import transaction

logger = logging.getLogger(__name__)

BACKEND = "allauth.account.auth_backends.AuthenticationBackend"


def adresse_deja_prise(email):
    from allauth.account.models import EmailAddress

    User = get_user_model()
    return (
        EmailAddress.objects.filter(email__iexact=email).exists()
        or User.objects.filter(email__iexact=email).exists()
    )


def creer_et_connecter(request, email, mot_de_passe, nom_complet=""):
    """Crée le compte, envoie la confirmation, ouvre la session. Retourne le compte."""
    from allauth.account.models import EmailAddress
    from allauth.utils import generate_unique_username

    User = get_user_model()
    prenom, __, nom = (nom_complet or "").strip().partition(" ")
    with transaction.atomic():
        compte = User.objects.create_user(
            username=generate_unique_username([nom_complet, email, "client"]),
            email=email, password=mot_de_passe,
            first_name=prenom[:30], last_name=nom.strip()[:30],
        )
        adresse = EmailAddress.objects.create(
            user=compte, email=email, primary=True, verified=False,
        )
    try:
        adresse.send_confirmation(request, signup=True)
    except Exception:
        # La commande ne doit pas échouer pour un e-mail : le renvoi reste
        # possible depuis l'écran de connexion.
        logger.exception("Confirmation d'adresse non envoyée (compte %s)", compte.pk)
    # `user_logged_in` reprend le panier anonyme (shop.signals).
    login(request, compte, backend=BACKEND)
    logger.info("Compte %s créé à la commande", compte.pk)
    return compte
