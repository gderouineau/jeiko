from django.apps import AppConfig


#: Modules d'allauth qui gardent en cache un état DE SÉCURITÉ, et le lisent
#: dans le cache `default` sans réglage pour en choisir un autre :
#: - les compteurs anti-force-brute (connexion, inscription, réinitialisation) ;
#: - les codes TOTP déjà utilisés, qui empêchent de rejouer un code intercepté.
MODULES_ALLAUTH_A_ISOLER = (
    "allauth.core.internal.ratelimit",
    "allauth.mfa.totp.internal.auth",
)


def isoler_les_compteurs_allauth():
    """S-09 (28/09/2026) — les états de sécurité d'allauth vont dans `jeiko_throttle`.

    Le bouton « Vider le cache » de l'administration fait un `cache.clear()`
    du cache `default` : il remettait à zéro les plafonds de tentatives de
    connexion, et rendait de nouveau valable un code TOTP déjà servi pendant
    sa fenêtre de trente secondes. Vider le cache de contenu ne doit pas
    désarmer l'authentification.

    allauth importe `cache` au niveau du module : on remplace ce nom par un
    mandataire vers l'alias dédié. Un mandataire (`ConnectionProxy`), comme
    `django.core.cache.cache` lui-même, et non la connexion : chaque fil
    d'exécution doit garder son propre client memcached. Si une version
    d'allauth renomme ces modules, `test_cache_securite` échoue — on ne
    retombe pas en silence sur le cache partagé.
    """
    import importlib

    from django.conf import settings
    from django.core.cache import caches
    from django.utils.connection import ConnectionProxy

    if "jeiko_throttle" not in settings.CACHES:
        return
    dedie = ConnectionProxy(caches, "jeiko_throttle")
    for nom in MODULES_ALLAUTH_A_ISOLER:
        try:
            module = importlib.import_module(nom)
        except ImportError:  # allauth.mfa non installé sur ce site
            continue
        module.cache = dedie


class UsersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko.users'

    def ready(self):
        import jeiko.users.signals
        # Journal de sécurité et suivi des sessions, branchés sur les signaux
        # d'authentification (cf. security_log.py).
        import jeiko.users.security_log  # noqa: F401

        isoler_les_compteurs_allauth()
