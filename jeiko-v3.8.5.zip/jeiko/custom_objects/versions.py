"""
Les versions d'une fiche dans les langues du site — créer, lister, ouvrir.

Même principe que pour une page (`administration_pages/versions.py`, règles
d'ensemble dans `jeiko/langues_du_site.py`) : la fiche se présente UNE fois
dans l'administration, dans la langue d'origine ; un bouton de langue, à
l'intérieur, ouvre sa version — ou la crée, par duplication, en brouillon.
Une version est une fiche entière : son titre, son adresse, ses valeurs, ses
images, sa publication.

Ce qui reste unique : le PRODUIT. Il est porté par la fiche d'origine ; son
prix, son stock et sa référence valent pour toutes les langues. Une version
n'a pas de produit à elle.

Ce que ce module ne fait pas : traduire. Une version naît copie conforme de
l'originale ; c'est à la main — ou par un agent, par l'API — qu'elle devient
anglaise.
"""

from django.contrib import messages
from django.db import transaction
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.translation import gettext as _

from jeiko import langues_du_site
from jeiko.administration_pages.versions import VersionImpossible

from .models import CustomObject, CustomObjectMetadata, CustomObjectValue


@transaction.atomic
def dupliquer(fiche, **champs):
    """
    Recopie une fiche — ses valeurs et ses métadonnées de recherche — et rend
    la copie. `champs` remplace ce qui doit différer : l'adresse pour un
    doublon, la langue et l'originale pour une version.

    Les images sont PARTAGÉES, pas recopiées : la copie désigne les mêmes
    `ImageContent`. Remplacer une image sur l'une ne touche pas l'autre — le
    formulaire en crée une nouvelle à chaque envoi de fichier.
    """
    copie = CustomObject.objects.create(**{
        "model": fiche.model,
        "title": fiche.title,
        "slug": fiche.slug,
        "is_published": False,
        "main_image": fiche.main_image,
        **champs,
    })
    CustomObjectValue.objects.bulk_create([
        CustomObjectValue(
            obj=copie, field_id=valeur.field_id,
            value_text=valeur.value_text, image_id=valeur.image_id, video_url=valeur.video_url,
            button_label=valeur.button_label, button_page_id=valeur.button_page_id,
            button_test_slug=valeur.button_test_slug,
            button_external_url=valeur.button_external_url,
        )
        for valeur in fiche.values.all()
    ])
    meta = getattr(fiche, "metadata", None)
    CustomObjectMetadata.objects.create(
        obj=copie,
        title=meta.title if meta else "",
        description=meta.description if meta else "",
    )
    return copie


def creer_version(fiche, langue):
    """
    Duplique l'originale de `fiche` dans `langue` et rend la nouvelle version.

    Elle naît BROUILLON, avec le titre, l'adresse et le contenu de l'originale :
    rien d'anglais n'est en ligne tant que la traduction n'est pas faite et
    publiée. Entre-temps le visiteur anglais lit la fiche d'origine sous /en/.
    """
    origine = fiche.origine
    if langue not in langues_du_site.langues_actives():
        raise VersionImpossible(_("Cette langue n'est pas activée pour le site."))
    if origine.traductions.filter(langue=langue).exists():
        raise VersionImpossible(_("Cette fiche existe déjà dans cette langue."))
    return dupliquer(origine, langue=langue, traduction_de=origine)


@transaction.atomic
def supprimer_version(fiche, langue):
    """
    Supprime la version de `fiche` dans `langue` — jamais l'originale, qui
    emporterait toutes les autres et, pour un produit, se refuse à juste
    titre. Les images que la version était seule à utiliser partent avec elle.
    """
    from .services import discard_image_if_orphan

    version = fiche.origine.traductions.filter(langue=langue).first() if langue else None
    if version is None:
        raise VersionImpossible(_("Cette fiche n'a pas de version dans cette langue."))
    images = [version.main_image, *(valeur.image for valeur in version.values.all())]
    version.delete()
    for image in images:
        discard_image_if_orphan(image)


def repondre(request, fiche, langue, action):
    """
    Le corps commun des écrans « créer une version » et « supprimer une
    version » — celui des fiches et celui de la boutique, qui ne diffèrent que
    par la permission exigée. Rend la redirection vers l'écran à ouvrir.
    """
    nom = langues_du_site.nom_de_la_langue(langue)
    try:
        if action == "creer":
            version = creer_version(fiche, langue)
            messages.success(request, _(
                "La version %(langue)s de « %(title)s » est créée, en brouillon. "
                "Traduisez-la, puis publiez-la."
            ) % {"langue": nom, "title": fiche.origine.title})
            return redirect(ecran_d_edition(version))
        supprimer_version(fiche, langue)
        messages.success(request, _("La version %(langue)s de « %(title)s » est supprimée.")
                         % {"langue": nom, "title": fiche.origine.title})
    except VersionImpossible as refus:
        messages.error(request, str(refus))
    return redirect(ecran_d_edition(fiche.origine))


def etat_des_versions(fiche):
    """
    Ce qu'affiche le sélecteur de langue d'une fiche : l'originale, puis une
    entrée par langue active — avec sa version si elle existe, `None` sinon.
    Vide pour un site monolingue, ou pour une fiche pas encore enregistrée.
    """
    actives = langues_du_site.langues_actives()
    if not actives or not fiche.pk:
        return []
    origine = fiche.origine
    existantes = {v.langue: v for v in origine.traductions.all()}
    etats = [{"langue": "", "fiche": origine}] + [
        {"langue": code, "fiche": existantes.get(code)} for code in actives
    ]
    for etat in etats:
        etat["nom"] = langues_du_site.nom_de_la_langue(etat["langue"])
        etat["courante"] = bool(etat["fiche"]) and etat["fiche"].pk == fiche.pk
        etat["url"] = ecran_d_edition(etat["fiche"]) if etat["fiche"] else ""
        if etat["langue"]:
            etat["creer"] = _route(origine, etat["langue"], "creer")
            etat["supprimer"] = _route(origine, etat["langue"], "supprimer")
    return etats


def _route(origine, langue, action):
    """L'adresse qui crée ou supprime une version : côté boutique pour un produit."""
    produit = getattr(origine, "product", None)
    if produit is not None:
        return reverse(
            f"jeiko_administration_shop:product_version_{action}",
            kwargs={"type_pk": produit.type_id, "pk": produit.pk, "langue": langue},
        )
    return reverse(
        f"jeiko_administration_custom_objects:object_version_{action}",
        kwargs={"model_pk": origine.model_id, "pk": origine.pk, "langue": langue},
    )


def ecran_d_edition(fiche):
    """
    L'écran d'administration où cette fiche se modifie. Une fiche de produit
    se modifie sur l'écran du PRODUIT — sa version anglaise aussi, par
    `?langue=en` ; les autres sur l'écran des fiches.
    """
    origine = fiche.origine
    produit = getattr(origine, "product", None)
    if produit is not None:
        adresse = reverse(
            "jeiko_administration_shop:product_update",
            kwargs={"type_pk": produit.type_id, "pk": produit.pk},
        )
        return f"{adresse}?langue={fiche.langue}" if fiche.langue else adresse
    return reverse(
        "jeiko_administration_custom_objects:object_update",
        kwargs={"model_pk": fiche.model_id, "pk": fiche.pk},
    )


def fiches_publiques():
    """
    Les fiches que le site sert : publiées, dans une langue servie, et — pour
    celles qui portent un produit — encore en vente. Chaque version y est une
    ligne, à son adresse propre : c'est la liste des plans du site.
    """
    return (
        CustomObject.objects.filter(is_published=True)
        .filter(langue__in=["", *langues_du_site.langues_actives()])
        # Le produit est porté par l'originale, pour toutes ses versions.
        .exclude(product__is_active=False)
        .exclude(traduction_de__product__is_active=False)
        .select_related("model", "product__type", "traduction_de__product__type")
    )
