from django.db import models
from django.db.models import Q
from jeiko.horodatage import HorodatageFiable
from jeiko.modeles_par_langue import NomEtAdresseParLangue
from django.urls import NoReverseMatch, reverse
from django.utils.text import slugify
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _





class CustomObjectModel(NomEtAdresseParLangue):
    """
    Définit un "type" d’objet dynamique :
    - Article
    - Livre
    - Produit (côté shop)
    - Formation
    - Etc.

    Chaque modèle est associé à une Page template
    comportant des tokens [%code_champ%].

    Son nom et son slug se traduisent en place (`traductions`, voir
    `jeiko/modeles_par_langue.py`) : `/en/co/articles/…` plutôt que
    `/en/co/article/…`.
    """

    name = models.CharField(max_length=150)
    slug = models.SlugField(
        max_length=200,
        unique=True,
        help_text=_("Ex : article, produit, livre. Sert dans l’URL.")
    )

    page_template = models.ForeignKey(
        'administration_pages.Page',
        on_delete=models.PROTECT,
        related_name="custom_object_models",
        # La page d'ORIGINE : sa version anglaise, si elle existe, est prise
        # d'elle-même pour une fiche anglaise (`gabarit_pour`).
        limit_choices_to={"is_custom_object_template": True, "langue": ""},
        help_text=_("Page servant de gabarit visuel pour ce type d'objet.")
    )

    date_created = models.DateTimeField(auto_now_add=True)

    is_product = models.BooleanField(default=False)

    class Meta:
        verbose_name = _("Modèle d'objet personnalisé")
        verbose_name_plural = _("Modèles d'objets personnalisés")
        ordering = ["name"]

    def __str__(self):
        return self.name

    def clean(self):
        self.slug = slugify(self.slug or "")
        if not self.slug:
            raise ValidationError({"slug": _("Le slug du modèle est requis.")})
        self.verifier_les_traductions()

    def gabarit_pour(self, langue):
        """
        La page qui dessine une fiche de `langue` : la version publiée du
        gabarit dans cette langue, sinon le gabarit d'origine.

        Le gabarit porte les textes FIXES de la fiche — « Description »,
        « Ajouter au panier ». Il se traduit comme une page : une version par
        langue, publiée quand elle est prête. D'ici là, une fiche anglaise
        s'affiche dans le gabarit d'origine, ses valeurs traduites au milieu
        de titres qui ne le sont pas encore.
        """
        from jeiko.langues_du_site import version_publiee

        gabarit = self.page_template
        return (version_publiee(gabarit, langue) if langue else None) or gabarit


class CustomObjectField(models.Model):
    """
    Les champs définis sur un modèle d'objet.
    Ex :
        - title (text)
        - description (rich_text)
        - cover_image (image)
        - video_url (video)
        - cta_principal (button)
    """

    TEXT = "text"
    RICH_TEXT = "rich_text"
    IMAGE = "image"
    VIDEO = "video"
    BUTTON = "button"

    FIELD_TYPES = [
        (TEXT, _("Texte court")),
        (RICH_TEXT, _("Texte riche (Quill)")),
        (IMAGE, _("Image")),
        (VIDEO, _("Vidéo (URL)")),
        (BUTTON, _("Bouton / Lien")),
    ]

    model = models.ForeignKey(
        CustomObjectModel,
        on_delete=models.CASCADE,
        related_name="fields"
    )

    code = models.SlugField(
        max_length=100,
        help_text=_("Code utilisé dans les templates : [%code%].")
    )

    label = models.CharField(max_length=200)
    field_type = models.CharField(max_length=30, choices=FIELD_TYPES)

    required = models.BooleanField(default=False)
    help_text = models.CharField(max_length=255, blank=True)
    position = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = (("model", "code"),)
        ordering = ["position", "id"]
        verbose_name = _("Champ de modèle custom")
        verbose_name_plural = _("Champs de modèles custom")

    def __str__(self):
        return f"{self.model.name} > {self.label} ({self.code})"

    def clean(self):
        self.code = slugify(self.code or "")
        if not self.code:
            raise ValidationError({"code": _("Le code est requis.")})


class CustomObject(models.Model):
    """
    Une instance (enfant) d’un modèle.
    Ex :
        - Article : Les 5 erreurs à éviter
        - Produit : Gourde 500ml
        - Livre : Le guide complet du Flow
    """

    model = models.ForeignKey(
        CustomObjectModel,
        on_delete=models.PROTECT,
        related_name="custom_objects"
    )

    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200)

    is_published = models.BooleanField(default=False)

    main_image = models.ForeignKey(
        'administration_pages.ImageContent',
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name='related_custom_objects',
        verbose_name=_('Image Principale')
    )

    date_created = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)

    # --- Site en plusieurs langues (jeiko/langues_du_site.py) ---
    # Comme une page : vide pour la langue d'origine du site, et une version
    # par langue, reliée à sa fiche d'origine. Une version est une fiche
    # entière — son titre, son adresse, ses valeurs, ses images, sa
    # publication. Le produit, lui, reste unique et porté par l'originale : un
    # prix, un stock, une référence, quelle que soit la langue.
    langue = models.CharField(max_length=10, blank=True, default="", db_index=True)

    # CASCADE : supprimer l'originale supprime ses versions. C'est elle que
    # porte le produit ; une version orpheline n'aurait plus ni prix ni
    # adresse en boutique.
    traduction_de = models.ForeignKey(
        "self",
        on_delete=models.CASCADE,
        null=True, blank=True,
        related_name="traductions",
    )

    class Meta:
        constraints = [
            # L'adresse vaut PAR LANGUE : /co/article/pain/ et
            # /en/co/article/pain/ sont deux adresses, pas une collision.
            models.UniqueConstraint(
                fields=("model", "langue", "slug"),
                name="uniq_fiche_par_modele_langue_slug",
            ),
            # Une seule version par langue.
            models.UniqueConstraint(
                fields=("traduction_de", "langue"),
                condition=Q(traduction_de__isnull=False),
                name="uniq_version_de_fiche_par_langue",
            ),
            # Une version dit sa langue ; une originale n'en dit pas.
            models.CheckConstraint(
                name="fiche_traduction_et_langue_vont_ensemble",
                condition=(
                    (Q(traduction_de__isnull=True) & Q(langue=""))
                    | (Q(traduction_de__isnull=False) & ~Q(langue=""))
                ),
            ),
        ]
        ordering = ["-date_created"]
        verbose_name = _("Objet personnalisé")
        verbose_name_plural = _("Objets personnalisés")

    def __str__(self):
        suffixe = f" [{self.langue}]" if self.langue else ""
        return f"{self.model.name} – {self.title}{suffixe}"

    # Ce que `jeiko/langues_du_site.py` demande à tout ce qui a une version
    # par langue (voir `Page`, qui en dit autant).
    @property
    def origine(self):
        """La fiche d'origine : elle-même, sauf pour une version."""
        return self.traduction_de if self.traduction_de_id else self

    @property
    def est_publiee(self):
        return self.is_published

    @classmethod
    def versions_publiees(cls, langue):
        """Les versions publiées dans `langue`, avec de quoi écrire leur adresse."""
        return cls.objects.filter(langue=langue, is_published=True).select_related(
            "model", "main_image", "traduction_de__product__type"
        )

    def versions(self):
        """Toutes les versions de la fiche, l'originale en tête (tri en Python : voir `Page.versions`)."""
        origine = self.origine
        return [origine, *sorted(origine.traductions.all(), key=lambda v: v.langue)]

    def save(self, *args, **kwargs):
        # Une version est du MODÈLE de sa fiche d'origine, et le reste. Le
        # formulaire d'une fiche laisse changer de modèle : sans cela, la
        # version anglaise d'un article pouvait devenir un livre — une autre
        # adresse, d'autres champs — pendant que l'originale restait article.
        if self.traduction_de_id:
            self.model_id = self.traduction_de.model_id
        super().save(*args, **kwargs)
        ecrits = kwargs.get("update_fields")
        if self.traduction_de_id is None and (ecrits is None or "model" in ecrits):
            # `.update()` et non une boucle de `save()` : rien à valider, et
            # la plupart du temps rien à écrire.
            CustomObject.objects.filter(traduction_de=self).exclude(
                model_id=self.model_id).update(model_id=self.model_id)

    @property
    def description(self):
        """
        Retrieves description from metadata if available.
        """
        if hasattr(self, 'metadata'):
             return self.metadata.description
        return ""

    @property
    def excerpt(self):
        return self.description

    def _adresse(self, langue):
        """
        L'adresse de CETTE fiche pour un lecteur de `langue` : son adresse
        propre quand c'est sa langue, sinon elle-même sous le préfixe du
        lecteur — voir `langues_du_site.adresse_dans`.

        Quand la fiche porte un produit, la page de référence est celle de la
        boutique : elle seule expose le prix, le stock et le bouton panier. La
        renvoyer ici suffit à ce que le sitemap, robots.txt, les boutons et
        `Product.get_absolute_url` pointent tous au même endroit, et à ce que
        /co/… redirige vers elle plutôt que d'afficher une seconde version de
        la fiche, amputée de ses informations commerciales.

        Le produit est porté par la fiche d'ORIGINE, pour toutes ses versions.
        `product` est une relation inverse OneToOne : son absence lève une
        exception qui hérite d'AttributeError, d'où le getattr.
        """
        prefixe = f"/{langue}" if langue else ""
        product = getattr(self.origine, "product", None)
        if product is not None:
            try:
                return prefixe + reverse(
                    "jeiko_client_shop:product_detail",
                    kwargs={
                        # Le code du type dans la langue du lecteur, s'il est
                        # traduit : /en/shop/workshops/… — voir
                        # jeiko/modeles_par_langue.py.
                        "product_type_code": product.type.slug_pour(langue),
                        "product_sku": product.sku,
                    },
                )
            except NoReverseMatch:
                # SKU non conforme au convertisseur <slug:> : on retombe sur
                # l'URL objet, qui reste servie.
                pass

        # /co/<slug_model>/<slug_obj>/ — le slug du modèle dans la langue lue.
        return f"{prefixe}/co/{self.model.slug_pour(langue)}/{self.slug}/"

    def adresse_propre(self):
        """
        L'adresse de cette fiche, telle qu'elle est : sans préfixe pour une
        fiche d'origine, sous `/<langue>` pour une version. Pour qui ne lit pas
        (administration, API, plans du site).
        """
        return self._adresse(self.langue)

    def get_absolute_url(self):
        """
        L'adresse à mettre dans un lien vers cette fiche : celle où CE lecteur
        la lit — sa version dans sa langue si elle est publiée, la fiche
        d'origine sous son préfixe sinon. Hors du site public, son adresse
        propre. Voir jeiko/langues_du_site.py.
        """
        from jeiko.langues_du_site import adresse_pour_le_visiteur
        return adresse_pour_le_visiteur(self)

    def clean(self):
        self.slug = slugify(self.slug or "")
        if not self.slug:
            raise ValidationError({"slug": _("Le slug est requis pour cet objet.")})
        if not self.model_id:
            return
        # Une adresse appartient à UNE fiche, toutes langues confondues. Dans
        # sa propre langue, c'est la contrainte de base. Entre langues, c'est
        # ce qui garde une fiche non traduite atteignable : lue sous /en/, elle
        # répond à son adresse d'origine — qu'une version anglaise d'une AUTRE
        # fiche ne doit donc pas occuper. Dit ici, et non laissé à la
        # contrainte : `langue` n'est le champ d'aucun formulaire, Django ne
        # contrôlerait rien et l'enregistrement finirait en erreur 500.
        famille = self.traduction_de_id or self.pk
        autres = CustomObject.objects.filter(model_id=self.model_id, slug=self.slug).exclude(pk=self.pk)
        if famille:
            autres = autres.exclude(pk=famille).exclude(traduction_de_id=famille)
        if autres.exists():
            raise ValidationError(
                {"slug": _("Cette adresse est déjà celle d'une autre fiche de ce modèle.")}
            )


class CustomObjectValue(models.Model):
    """
    Valeur d'un champ pour une instance d'objet.
    Gère plusieurs types :
        - Texte / RichText → value_text
        - Image → image
        - Vidéo → video_url
        - Bouton → button_* (cible + label)
    """

    obj = models.ForeignKey(
        CustomObject,
        on_delete=models.CASCADE,
        related_name="values"
    )

    field = models.ForeignKey(
        CustomObjectField,
        on_delete=models.CASCADE,
        related_name="values"
    )

    value_text = models.TextField(blank=True)
    image = models.ForeignKey(
        'administration_pages.ImageContent',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    video_url = models.URLField(blank=True)

    button_label = models.CharField(
        max_length=200,
        blank=True,
        default="",
        verbose_name=_("Texte du bouton (optionnel)")
    )
    button_page = models.ForeignKey(
        'administration_pages.Page',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="customobject_button_values",
        verbose_name=_("Page cible (bouton)")
    )
    button_test_slug = models.CharField(
        max_length=100,
        blank=True,
        default="",
        verbose_name=_("Slug de test (bouton)")
    )
    button_external_url = models.URLField(
        blank=True,
        default="",
        verbose_name=_("URL externe (bouton)")
    )


    class Meta:
        unique_together = (("obj", "field"),)
        verbose_name = _("Valeur d'objet")
        verbose_name_plural = _("Valeurs d'objet")

    def __str__(self):
        return f"{self.obj} – {self.field.code}"

    def clean(self):
        # `field` est obligatoire mais peut manquer ici : ligne de formset
        # vide, ou champ retiré du POST. Y accéder sans garde lève un
        # RelatedObjectDoesNotExist — une exception, pas une ValidationError,
        # donc une 500 au lieu d'un formulaire en erreur. Le champ manquant
        # est déjà signalé par la validation du formulaire : on sort.
        if self.field_id is None:
            return

        # Validation simple : vérifier que le type correspond
        if self.field.field_type == CustomObjectField.TEXT and not self.value_text:
            if self.field.required:
                raise ValidationError(_("Ce champ texte est requis."))

        if self.field.field_type == CustomObjectField.RICH_TEXT and not self.value_text:
            if self.field.required:
                raise ValidationError(_("Ce champ riche est requis."))

        if self.field.field_type == CustomObjectField.IMAGE and not self.image:
            if self.field.required:
                raise ValidationError(_("Cette image est requise."))

        if self.field.field_type == CustomObjectField.VIDEO and not self.video_url:
            if self.field.required:
                raise ValidationError(_("L’URL vidéo est requise."))

        if self.field.field_type == CustomObjectField.BUTTON:
            filled = [
                bool(self.button_page),
                bool(self.button_test_slug.strip()),
                bool(self.button_external_url.strip()),
            ]
            if sum(filled) > 1:
                raise ValidationError(
                    _("Le bouton doit pointer soit vers une page, soit vers un test, soit vers une URL externe, pas plusieurs."))
            if self.field.required and sum(filled) == 0:
                raise ValidationError(_("Ce bouton doit avoir une destination (page, test ou lien externe)."))

# `updated_at` sert de clé au cache du <head> des fiches (base.html,
# bloc « head_meta_block_co ») : il doit bouger même sur une sauvegarde
# partielle, sinon le titre et la description restent gelés trente
# jours. Voir jeiko/horodatage.py et A-42.
class CustomObjectMetadata(HorodatageFiable):
    """
    SEO spécifique à chaque objet, indépendant du template.
    (contraire de Page.metadata qui est pour les pages classiques)
    """

    obj = models.OneToOneField(
        CustomObject,
        on_delete=models.CASCADE,
        related_name="metadata"
    )

    title = models.CharField(max_length=100, blank=True, default="")
    description = models.TextField(blank=True, default="")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Metadata (objet custom)")
        verbose_name_plural = _("Metadata (objets custom)")

    def __str__(self):
        return f"Metadata – {self.obj}"
