from django.http import Http404, HttpResponsePermanentRedirect, HttpResponseRedirect
from django.shortcuts import render
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import ensure_csrf_cookie

from jeiko.administration_pages.page_cache import build_page_cache_context

from ..models import CustomObject, CustomObjectModel
from ..services import OBJECT_VALUE_PREFETCH, contexte_de_fiche


@method_decorator(ensure_csrf_cookie, name="get")
class CustomObjectView(View):
    """
    Vue client pour afficher un objet custom :
    URL canonique : /co/<model_slug>/<object_slug>/

    Les objets qui portent une fiche produit sont redirigés vers la boutique
    par le contrôle canonique ci-dessous : leur page de référence est celle de
    `shop`, seule à disposer du prix, du stock et du panier.

    Sur un site en plusieurs langues (`jeiko/langues_du_site.py`), l'adresse
    fait foi comme pour une page : `/en/co/…` sert la version anglaise de la
    fiche — ou la fiche d'origine, tant qu'elle n'est pas traduite.
    """

    template_name = "pages/main.html"  # même template que PageView

    def get(self, request, *args, **kwargs):
        langue = getattr(request, "langue_du_prefixe", "")

        # Le premier segment désigne le modèle : par son slug traduit dans la
        # langue lue, sinon par son slug d'origine (jeiko/modeles_par_langue.py).
        modeles = CustomObjectModel.par_adresse(kwargs.get("model_slug"), langue)

        qs = (
            CustomObject.objects
            .filter(model__in=modeles, slug=kwargs.get("object_slug"))
            .select_related(
                "model",
                "model__page_template",
                "metadata",
                # `_adresse` interroge la fiche produit éventuelle — celle de
                # l'originale, pour une version.
                "product__type",
                "traduction_de__product__type",
            )
            .prefetch_related(*OBJECT_VALUE_PREFETCH)
        )

        # Les brouillons restent visibles pour le staff (préversion), mais sont
        # invisibles pour le public. Un objet absent ou non publié doit renvoyer
        # un 404 : un .get() nu levait DoesNotExist -> 500, ce qui fait chuter
        # le crawl Google.
        if not request.user.is_staff:
            qs = qs.filter(is_published=True)

        # /en/co/… : la version anglaise qui vit à cette adresse. À défaut, la
        # fiche d'ORIGINE de cette adresse, lue sous /en/ — si elle a depuis
        # été traduite, le contrôle canonique redirige vers sa version. Dans
        # l'ordre des modèles trouvés : le slug traduit passe devant.
        candidates = list(qs.filter(langue__in={langue, ""}))
        candidates.sort(key=lambda f: (f.langue != langue, modeles.index(f.model)))
        if not candidates:
            raise Http404("Aucune fiche à cette adresse.")
        obj = candidates[0]

        # `get_absolute_url` répond pour la langue lue : l'adresse de la
        # version anglaise, ou l'originale sous /en/ — voir langues_du_site.
        canonical_path = obj.get_absolute_url()
        if request.path != canonical_path:
            if langue:
                # 302 : une version se publie et se dépublie, l'adresse qui
                # répond à /en/… change avec elle (comme pour une page).
                return HttpResponseRedirect(canonical_path)
            return HttpResponsePermanentRedirect(canonical_path)

        context = contexte_de_fiche(request, obj)

        # Cache du corps de fiche : clé = gabarit + version + identité de l'objet
        # (id + version). Édition de l'objet -> sa version change ; édition du
        # gabarit -> version de la page change (invalide toutes ses fiches).
        context.update(build_page_cache_context(context["page"], obj=obj))

        return render(request, self.template_name, context)
