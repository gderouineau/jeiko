from jeiko.listes import ListeRechercheeEtPaginee
from django.contrib import messages
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import ProtectedError, RestrictedError
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db import transaction
from django.forms import inlineformset_factory
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse, reverse_lazy
from django.views.generic import (
    ListView,
    CreateView,
    UpdateView,
    DeleteView,
)
from django.views import View

from ..models import (
    CustomObjectModel,
    CustomObjectField,
    CustomObject,
    CustomObjectValue,
    CustomObjectMetadata,
)
from ..forms import (
    CustomObjectModelForm,
    CustomObjectFieldForm,
    CustomObjectForm,
    CustomObjectValueForm,
    CustomObjectMetadataForm,
)
from django.utils.translation import gettext_lazy as _


class CustomObjectAdminMixin(LoginRequiredMixin, PermissionRequiredMixin):
    """
    Contrôle d'accès de l'administration des objets personnalisés.

    Remplace un test qui ne regardait que `is_staff or is_superuser`. Ce test
    contredisait le système de rôles dans les deux sens : tout compte marqué
    « équipe » — rédacteur, formateur — obtenait l'écriture complète sur les
    objets et leurs modèles par l'URL directe alors que le menu lui masquait
    l'entrée ; et à l'inverse un porteur du super-rôle sans le drapeau
    `is_staff` voyait l'entrée et se prenait un 403.

    Les vues sont désormais gardées par les permissions réelles des modèles,
    celles-là mêmes que `templates/includes/admin_menu.html` interroge : le
    menu et la vue disent enfin la même chose.

    Pas de `raise_exception` ici : `AccessMixin.handle_no_permission` distingue
    déjà les deux cas — 403 pour un compte connecté sans droit, redirection vers
    la connexion pour un visiteur anonyme. Le forcer donnait un 403 sec à
    l'anonyme, qui n'a pas de moyen de comprendre qu'il lui suffit de se
    connecter. (Les vues de l'éditeur, elles, le forcent à dessein : elles
    répondent en JSON, où une redirection HTML n'a aucun sens.)
    """


# -------------------------------------------------------------------
#  Inline formsets
# -------------------------------------------------------------------

CustomObjectFieldFormSet = inlineformset_factory(
    CustomObjectModel,
    CustomObjectField,
    form=CustomObjectFieldForm,
    extra=0,
    can_delete=True,
)

CustomObjectValueFormSet = inlineformset_factory(
    CustomObject,
    CustomObjectValue,
    form=CustomObjectValueForm,
    extra=0,
    can_delete=False,
)


# -------------------------------------------------------------------
#  CustomObjectModel (parent : Article, Produit, Livre, etc.)
# -------------------------------------------------------------------

def editable_models():
    """
    Modèles d'objet pilotables depuis cet écran.

    Les modèles marqués `is_product` sont créés et maintenus par l'app shop
    pour porter les fiches produit : leur cycle de vie appartient au type de
    produit. Les exposer ici permettait de leur rattacher des objets sans
    Product associé — des fiches orphelines, publiées sans prix ni panier.
    """
    return CustomObjectModel.objects.filter(is_product=False)


def get_editable_model_or_404(model_pk):
    return get_object_or_404(editable_models(), pk=model_pk)


class CustomObjectModelListView(CustomObjectAdminMixin, ListView):
    permission_required = "custom_objects.view_customobjectmodel"

    model = CustomObjectModel
    template_name = "custom_objects/admin/model_list.html"
    context_object_name = "models"

    def get_queryset(self):
        return editable_models()


class CustomObjectModelCreateView(CustomObjectAdminMixin, CreateView):
    permission_required = "custom_objects.add_customobjectmodel"

    model = CustomObjectModel
    form_class = CustomObjectModelForm
    template_name = "custom_objects/admin/model_form.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.method == "POST":
            context["field_formset"] = CustomObjectFieldFormSet(self.request.POST)
        else:
            context["field_formset"] = CustomObjectFieldFormSet()
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        field_formset = context["field_formset"]

        if form.is_valid() and field_formset.is_valid():
            with transaction.atomic():
                self.object = form.save()
                field_formset.instance = self.object
                field_formset.save()
            messages.success(self.request, _("Modèle créé avec succès."))
            return redirect(self.get_success_url())

        return self.render_to_response(self.get_context_data(form=form))

    def get_success_url(self):
        return reverse("jeiko_administration_custom_objects:model_update", args=[self.object.pk])


class CustomObjectModelUpdateView(CustomObjectAdminMixin, UpdateView):
    permission_required = "custom_objects.change_customobjectmodel"

    model = CustomObjectModel
    form_class = CustomObjectModelForm
    template_name = "custom_objects/admin/model_form.html"

    def get_queryset(self):
        return editable_models()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.method == "POST":
            context["field_formset"] = CustomObjectFieldFormSet(
                self.request.POST,
                instance=self.object,
            )
        else:
            context["field_formset"] = CustomObjectFieldFormSet(instance=self.object)
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        field_formset = context["field_formset"]

        if field_formset.is_valid():
            self.object = form.save()
            field_formset.instance = self.object
            field_formset.save()
            messages.success(self.request, _("Modèle et champs mis à jour."))
            return redirect(self.get_success_url())

        # Si le formset est invalide, on renvoie les erreurs
        return self.render_to_response(self.get_context_data(form=form))

    def get_success_url(self):
        return reverse("jeiko_administration_custom_objects:model_update", args=[self.object.pk])


class CustomObjectModelDeleteView(CustomObjectAdminMixin, DeleteView):
    permission_required = "custom_objects.delete_customobjectmodel"

    model = CustomObjectModel
    template_name = "custom_objects/admin/model_confirm_delete.html"
    success_url = reverse_lazy("jeiko_administration_custom_objects:model_list")

    def get_queryset(self):
        return editable_models()

    # Depuis Django 4.0, DeleteView passe par form_valid() : la surcharge de
    # delete() n'était plus appelée et le message ne s'affichait jamais.
    def form_valid(self, form):
        messages.success(self.request, _("Modèle supprimé."))
        return super().form_valid(form)


# -------------------------------------------------------------------
#  CustomObject (enfant : un article concret, un produit concret, etc.)
#  NB : tout passe maintenant par l'URL /models/<model_pk>/objects/...
# -------------------------------------------------------------------

class CustomObjectListView(CustomObjectAdminMixin, ListeRechercheeEtPaginee, ListView):
    permission_required = "custom_objects.view_customobject"
    champs_de_recherche = ("title", "slug")

    model = CustomObject
    template_name = "custom_objects/admin/object_list.html"
    context_object_name = "objects"

    def get_queryset(self):
        """
        Liste uniquement les objets du modèle passé dans l'URL.
        """
        model_pk = self.kwargs["model_pk"]
        return self.rechercher(
            CustomObject.objects
            # Une ligne par fiche : ses versions par langue s'ouvrent de
            # l'intérieur, comme pour les pages.
            .filter(model_id=model_pk, model__is_product=False, langue="")
            .select_related("model")
            .order_by("title")
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        model_pk = self.kwargs["model_pk"]
        context["model"] = get_editable_model_or_404(model_pk)
        return context


class CustomObjectCreateView(CustomObjectAdminMixin, CreateView):
    permission_required = "custom_objects.add_customobject"

    """
    V1 : création de l'objet sans les valeurs.
    Après création, on redirige vers l'édition,
    où l'on gère les valeurs + SEO.
    """

    model = CustomObject
    form_class = CustomObjectForm
    template_name = "custom_objects/admin/object_form.html"

    def dispatch(self, request, *args, **kwargs):
        self.model_obj = get_editable_model_or_404(self.kwargs["model_pk"])
        return super().dispatch(request, *args, **kwargs)

    def get_initial(self):
        initial = super().get_initial()
        initial["model"] = self.model_obj
        return initial

    def form_valid(self, form):
        context = self.get_context_data()
        values_formset = context["values_formset"]

        # On force le modèle depuis l'URL
        form.instance.model = self.model_obj

        if form.is_valid() and values_formset.is_valid():
            with transaction.atomic():
                self.object = form.save()
                
                # Sauvegarde des valeurs
                values_formset.instance = self.object
                values_formset.save()
                
                # Création auto des metadata vides si besoin
                CustomObjectMetadata.objects.get_or_create(obj=self.object)

            messages.success(self.request, _("Objet créé avec succès."))
            return redirect(self.get_success_url())

        return self.render_to_response(self.get_context_data(form=form))

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["model"] = self.model_obj
        
        if self.request.method == "POST":
            context["values_formset"] = CustomObjectValueFormSet(
                self.request.POST,
                self.request.FILES
            )
        else:
            # Pré-remplir le formset avec tous les champs du modèle
            initial_data = []
            for field in self.model_obj.fields.all():
                initial_data.append({'field': field})
            
            context["values_formset"] = CustomObjectValueFormSet(
                initial=initial_data
            )
            # Important : dire au formset d'afficher autant de forms que de champs
            context["values_formset"].extra = len(initial_data)
            
        return context

    def get_success_url(self):
        return reverse(
            "jeiko_administration_custom_objects:object_update",
            kwargs={"model_pk": self.model_obj.pk, "pk": self.object.pk},
        )


class CustomObjectUpdateView(CustomObjectAdminMixin, UpdateView):
    permission_required = "custom_objects.change_customobject"

    model = CustomObject
    form_class = CustomObjectForm
    template_name = "custom_objects/admin/object_form.html"

    def get_queryset(self):
        """
        Sécurise : on ne peut éditer que des objets appartenant
        au modèle donné dans l'URL.
        """
        model_pk = self.kwargs["model_pk"]
        return (
            CustomObject.objects
            .filter(model_id=model_pk, model__is_product=False)
            .select_related("model")
        )

    def _ensure_all_values_exist(self, obj: CustomObject):
        """
        S'assure qu'il existe une CustomObjectValue pour
        chaque CustomObjectField du modèle.
        """
        existing = {v.field_id for v in obj.values.all()}
        # obj.model est une instance de CustomObjectModel,
        # et "fields" est le related_name de CustomObjectField
        for field in obj.model.fields.all():
            if field.id not in existing:
                CustomObjectValue.objects.create(obj=obj, field=field)

    def _get_metadata_instance(self):
        metadata, _created = CustomObjectMetadata.objects.get_or_create(obj=self.object)
        return metadata

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # modèle depuis l'objet courant
        context["model"] = self.object.model

        # Site en plusieurs langues : le bouton de langue de la fiche.
        from ..versions import etat_des_versions
        context["versions"] = etat_des_versions(self.object)

        # S'assurer que toutes les valeurs existent
        self._ensure_all_values_exist(self.object)

        # Les formulaires déjà validés (cas d'un POST en erreur) sont passés en
        # kwargs : les recréer ici perdrait les fichiers envoyés et les
        # messages d'erreur accumulés.
        if "values_formset" not in kwargs:
            context["values_formset"] = (
                CustomObjectValueFormSet(
                    self.request.POST, self.request.FILES, instance=self.object
                )
                if self.request.method == "POST"
                else CustomObjectValueFormSet(instance=self.object)
            )

        if "metadata_form" not in kwargs:
            metadata_instance = self._get_metadata_instance()
            context["metadata_form"] = (
                CustomObjectMetadataForm(
                    self.request.POST, instance=metadata_instance, prefix="meta"
                )
                if self.request.method == "POST"
                else CustomObjectMetadataForm(
                    instance=metadata_instance, prefix="meta"
                )
            )

        return context

    def form_valid(self, form):
        # IMPORTANT: Ne pas appeler get_context_data() ici car ça recrée les formsets
        # et perd les fichiers uploadés !
        # On recrée manuellement avec les mêmes données que lors de la validation
        values_formset = CustomObjectValueFormSet(
            self.request.POST,
            self.request.FILES,
            instance=self.object,
        )
        metadata_form = CustomObjectMetadataForm(
            self.request.POST,
            instance=self._get_metadata_instance(),
            prefix="meta",
        )

        if values_formset.is_valid() and metadata_form.is_valid():
            with transaction.atomic():
                self.object = form.save()

                # Valeurs
                values_formset.instance = self.object
                values_formset.save()

                # Metadata
                metadata = metadata_form.save(commit=False)
                metadata.obj = self.object
                metadata.save()

            messages.success(self.request, _("Objet et contenus mis à jour."))
            return redirect(self.get_success_url())

        # Si formset ou metadata invalide -> afficher erreurs
        return self.render_to_response(
            self.get_context_data(
                form=form,
                values_formset=values_formset,
                metadata_form=metadata_form,
            )
        )

    def get_success_url(self):
        return reverse(
            "jeiko_administration_custom_objects:object_update",
            kwargs={"model_pk": self.object.model_id, "pk": self.object.pk},
        )


class CustomObjectDeleteView(CustomObjectAdminMixin, DeleteView):
    permission_required = "custom_objects.delete_customobject"

    model = CustomObject
    template_name = "custom_objects/admin/object_confirm_delete.html"

    def get_queryset(self):
        """
        Même sécurité que pour Update : on ne supprime que l'objet du modèle
        indiqué dans l'URL. Les modèles produit restent visibles ici afin
        qu'une tentative de suppression puisse expliquer la dépendance au
        produit, au lieu de transformer le cas en 404 trompeur.
        """
        model_pk = self.kwargs["model_pk"]
        return CustomObject.objects.filter(model_id=model_pk)

    # Depuis Django 4.0, DeleteView passe par form_valid() : la surcharge de
    # delete() n'était plus appelée et le message ne s'affichait jamais.
    def form_valid(self, form):
        try:
            produit = self.object.product
        except ObjectDoesNotExist:
            produit = None
        if produit is not None:
            messages.error(
                self.request,
                _("Objet non supprimé : il porte le produit « %(sku)s ». Supprimez ou désactivez d'abord ce produit.") % {"sku": produit.sku},
            )
            return redirect(self.get_success_url())
        try:
            response = super().form_valid(form)
        except (ProtectedError, RestrictedError):
            messages.error(
                self.request,
                _("Objet non supprimé : il est encore utilisé par une donnée protégée. "
                "Retirez d'abord cette dépendance."),
            )
            return redirect(self.get_success_url())
        messages.success(self.request, _("Objet supprimé."))
        return response

    def get_success_url(self):
        return reverse(
            "jeiko_administration_custom_objects:object_list",
            kwargs={"model_pk": self.object.model_id},
        )


# -------------------------------------------------------------------
#  Versions d'une fiche dans les langues du site
# -------------------------------------------------------------------

class CustomObjectVersionCreateView(CustomObjectAdminMixin, View):
    """
    Crée la version d'une fiche dans une langue du site, par duplication.

    POST uniquement : l'action écrit une fiche entière. On arrive ensuite sur
    l'écran de la nouvelle version, en brouillon — son titre et son contenu
    sont encore ceux de l'originale, c'est ce qu'il reste à traduire.
    Les fiches de produit ont leur propre route, côté boutique.
    """

    permission_required = "custom_objects.add_customobject"
    action = "creer"

    def post(self, request, model_pk, pk, langue):
        from ..versions import repondre

        fiche = get_object_or_404(
            CustomObject, pk=pk, model_id=model_pk, model__is_product=False, langue="",
        )
        return repondre(request, fiche, langue, self.action)


class CustomObjectVersionDeleteView(CustomObjectVersionCreateView):
    """Supprime UNE version ; l'originale et les autres versions restent."""

    permission_required = "custom_objects.delete_customobject"
    action = "supprimer"


# -------------------------------------------------------------------
#  Duplication d'un CustomObject
# -------------------------------------------------------------------

class CustomObjectDuplicateView(CustomObjectAdminMixin, View):
    permission_required = "custom_objects.add_customobject"

    """
    Duplique un CustomObject existant :
    - même model, title, main_image
    - slug += suffixe aléatoire (6 caractères)
    - is_published = False
    - date_created / date_updated remis à zéro (auto par Django)
    - CustomObjectValue dupliquées
    - CustomObjectMetadata dupliquée
    """

    # En POST : la duplication crée des lignes. En GET, un préchargement de
    # navigateur ou un crawler authentifié suffisait à la déclencher, et la
    # requête échappait à la protection CSRF.
    def post(self, request, model_pk, pk):
        import uuid

        from ..versions import dupliquer

        # Une fiche d'ORIGINE : c'est elle que montre la liste. Ses versions
        # par langue ne suivent pas — le doublon est une nouvelle fiche, à
        # traduire à son tour si besoin.
        original = get_object_or_404(
            CustomObject.objects.select_related("model"),
            pk=pk,
            model_id=model_pk,
            model__is_product=False,
            langue="",
        )

        # Slug unique : slug original + suffixe aléatoire de 6 caractères
        suffix = uuid.uuid4().hex[:6]
        dupliquer(original, slug=f"{original.slug}-{suffix}")

        messages.success(request, _("Objet « %(title)s » dupliqué avec succès.") % {"title": original.title})
        return redirect(
            reverse(
                "jeiko_administration_custom_objects:object_list",
                kwargs={"model_pk": model_pk},
            )
        )
