"""
Invalidation du cache du corps des fiches d'objet custom.

Le corps rendu d'une fiche (pages/main.html) est mis en cache par
``CustomObjectView`` avec une clé qui inclut ``object_body_version(obj_id)``
(voir administration_pages/page_cache.py). Comme ``CustomObjectValue`` ne porte
aucun timestamp et que ``CustomObject.date_updated`` ne bouge qu'au save() du
parent, on ne peut pas se fier à une date : on bumpe explicitement la version de
l'objet dès qu'il — ou l'une de ses valeurs — change.
"""

import logging

from django.db.models.signals import post_save, post_delete

from jeiko.administration_pages.page_cache import bump_links_version, bump_object_body_version
from .models import CustomObject, CustomObjectModel, CustomObjectValue

logger = logging.getLogger(__name__)


def _bump_object(instance, **kwargs):
    try:
        bump_object_body_version(instance.pk)
    except Exception:
        logger.exception("Invalidation cache objet impossible (obj pk=%s)",
                          getattr(instance, "pk", None))


def _bump_object_of_value(instance, **kwargs):
    try:
        bump_object_body_version(getattr(instance, "obj_id", None))
    except Exception:
        logger.exception("Invalidation cache objet impossible (value pk=%s)",
                          getattr(instance, "pk", None))


def connect():
    """Branche les récepteurs (appelé depuis CustomObjectConfig.ready)."""
    post_save.connect(_bump_object, sender=CustomObject,
                      dispatch_uid="jeiko_co_body_save")
    post_delete.connect(_bump_object, sender=CustomObject,
                        dispatch_uid="jeiko_co_body_delete")
    post_save.connect(_bump_object_of_value, sender=CustomObjectValue,
                      dispatch_uid="jeiko_co_value_save")
    post_delete.connect(_bump_object_of_value, sender=CustomObjectValue,
                        dispatch_uid="jeiko_co_value_delete")
    # Site en plusieurs langues : le lien vers une fiche mène à sa version
    # dans la langue du lecteur, si elle est publiée. Publier, dépublier ou
    # renommer une version change donc l'adresse écrite dans le corps des
    # pages gardé en cache — comme pour une page (administration_pages/
    # signals.py). Sans effet sur un site monolingue : sa clé de cache ne
    # porte pas la version des liens.
    post_save.connect(bump_links_version, sender=CustomObject,
                      dispatch_uid="jeiko_co_liens_save")
    post_delete.connect(bump_links_version, sender=CustomObject,
                        dispatch_uid="jeiko_co_liens_delete")
    # Le slug d'un modèle — traduit ou non — est dans l'adresse de toutes ses
    # fiches (jeiko/modeles_par_langue.py) : le changer change ces adresses.
    post_save.connect(bump_links_version, sender=CustomObjectModel,
                      dispatch_uid="jeiko_co_modele_liens_save")
