"""
Ce qu'une réservation demande au visiteur, en plus de son nom et de son
adresse (CRM-01, CRM-02).

Un catalogue FIXE, réglé par type de rendez-vous : chaque champ est absent,
facultatif ou obligatoire. Pas de champs libres — un catalogue fixe se range
dans des colonnes, se relit dans la fiche du contact, et ne perd rien quand
on change la configuration : retirer « société » d'un type n'efface pas les
sociétés déjà saisies.

Les clés envoyées par le navigateur sont en français (`societe`…) : `company`
est le nom du champ LEURRE anti-robot (`jeiko.throttling.HONEYPOT_FIELD`), et
une réservation qui le remplit est refusée comme venant d'un robot.

Le nom et l'adresse restent à part : toujours demandés, toujours exigés.
"""
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

ABSENT = "absent"
FACULTATIF = "facultatif"
OBLIGATOIRE = "obligatoire"
ETATS = (ABSENT, FACULTATIF, OBLIGATOIRE)

#: clé envoyée par le navigateur → (champ du rendez-vous, libellé, longueur, zone de texte)
CATALOGUE = {
    "telephone": ("phone", _("Téléphone"), 30, False),
    "societe": ("company", _("Société"), 200, False),
    "fonction": ("job_title", _("Fonction"), 200, False),
    "message": ("message", _("Message"), 2000, True),
}


def valider_la_configuration(valeur):
    """Validateur de `AppointmentType.champs_demandes` : {clé: état}."""
    if not isinstance(valeur, dict):
        raise ValidationError(_("La configuration des champs doit être un objet."))
    inconnues = sorted(set(valeur) - set(CATALOGUE))
    if inconnues:
        raise ValidationError(
            _("Champ(s) inconnu(s) : %(cles)s. Possibles : %(possibles)s.")
            % {"cles": ", ".join(inconnues), "possibles": ", ".join(CATALOGUE)})
    mauvais = sorted(k for k, v in valeur.items() if v not in ETATS)
    if mauvais:
        raise ValidationError(
            _("État inconnu pour %(cles)s : absent, facultatif ou obligatoire.")
            % {"cles": ", ".join(mauvais)})


def champs_a_demander(appt_type):
    """Pour le navigateur : [{cle, libelle, obligatoire, zone}], dans l'ordre du catalogue."""
    reglage = appt_type.champs_demandes or {}
    return [
        {"cle": cle, "libelle": str(libelle), "obligatoire": reglage.get(cle) == OBLIGATOIRE,
         "zone": zone, "max": longueur}
        for cle, (_champ, libelle, longueur, zone) in CATALOGUE.items()
        if reglage.get(cle) in (FACULTATIF, OBLIGATOIRE)
    ]


def lire_les_champs(appt_type, donnees):
    """
    Ce que le visiteur a saisi, borné, pour les seuls champs demandés par ce
    type : {champ du modèle: valeur}. Lève `ValueError` (message pour le
    visiteur) si un champ obligatoire est vide.

    Le contrôle se fait ICI, côté serveur : l'obligation affichée par le
    navigateur se contourne en un appel.
    """
    reglage = appt_type.champs_demandes or {}
    retenus = {}
    for cle, (champ, libelle, longueur, _zone) in CATALOGUE.items():
        etat = reglage.get(cle, ABSENT)
        if etat == ABSENT:
            continue
        valeur = str((donnees or {}).get(cle) or "").strip()[:longueur]
        if etat == OBLIGATOIRE and not valeur:
            raise ValueError(_("Merci de renseigner : %(champ)s.") % {"champ": libelle})
        retenus[champ] = valeur
    return retenus
