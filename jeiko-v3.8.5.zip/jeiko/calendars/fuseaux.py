# jeiko/calendars/fuseaux.py
"""
Le fuseau du client, pour lui annoncer l'heure de SON rendez-vous.

Les instants sont stockés en UTC et la page de réservation les affiche dans le
fuseau du navigateur. Restent les e-mails, écrits côté serveur : ils
annonçaient l'heure du site sans le dire, et un client à New York lisait
« 09h00 » comme son heure. Ce module nomme les fuseaux et formate une heure
dans celui du client, avec l'heure du site à côté quand ils diffèrent.

Ce que ça ne fait pas : deviner un fuseau. Sans valeur transmise par le
navigateur (rendez-vous antérieurs, saisie depuis l'administration), on
retombe sur le fuseau du site, comme avant.
"""

from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from django.utils import timezone


def fuseau_valide(nom):
    """Le nom IANA s'il désigne un fuseau connu, sinon une chaîne vide."""
    nom = str(nom or "").strip()[:64]
    if not nom:
        return ""
    try:
        ZoneInfo(nom)
    except (ZoneInfoNotFoundError, ValueError, TypeError):
        return ""
    return nom


def fuseau_du_site():
    return timezone.get_default_timezone()


def fuseau_du_client(appt):
    """Le fuseau du client, ou None s'il est inconnu ou identique au site."""
    nom = fuseau_valide(getattr(appt, "client_timezone", ""))
    if not nom:
        return None
    site = getattr(fuseau_du_site(), "key", str(fuseau_du_site()))
    return None if nom == site else ZoneInfo(nom)


def nom_du_fuseau(tz):
    """« heure de New York » pour America/New_York."""
    cle = getattr(tz, "key", str(tz))
    return "heure de " + cle.split("/")[-1].replace("_", " ")
