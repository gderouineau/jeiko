from django.contrib import admin

# Register your models here.

from jeiko.calendars.models import AppointmentType, Appointment, Availability, Slot

# `GoogleCalendarConfig` n'y est pas : il porte la clé du compte de service
# Google, que le Django admin afficherait déchiffrée (voir administration/admin.py).
admin.site.register(AppointmentType)
admin.site.register(Appointment)
admin.site.register(Availability)
admin.site.register(Slot)
