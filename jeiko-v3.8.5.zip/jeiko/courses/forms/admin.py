"""
Admin forms for courses management.
"""
from django import forms
from django.core.exceptions import ValidationError
from ..models import (
    Course, Part, Chapter, Section,
    VideoStorageProvider, VideoContent, TextContent, PDFContent,
    QuizContent, QuizQuestion, QuizAnswer,
    CourseEnrollment
)
from django.utils.translation import gettext_lazy as _


class CourseForm(forms.ModelForm):
    """Création et modification d'une formation."""

    class Meta:
        model = Course
        fields = [
            'title', 'slug', 'description', 'thumbnail',
            'is_active', 'is_restricted', 'level', 'estimated_duration'
        ]
        labels = {
            'title': _("Titre de la formation"),
            'slug': _("Adresse de la formation"),
            'description': _("Description"),
            'thumbnail': _("Image de présentation"),
            'is_active': _("Formation visible"),
            'is_restricted': _("Accès réservé"),
            'level': _("Niveau"),
            'estimated_duration': _("Durée estimée (minutes)"),
        }
        help_texts = {
            'slug': _("Dernier segment de l'adresse, en minuscules et sans accent. "
                    "Exemple : « django-debutants »."),
            'description': _("Présentée sur la fiche de la formation, avant inscription."),
            'thumbnail': _("Vignette affichée dans la liste des formations."),
            'is_active': _("Décochée, la formation n'apparaît nulle part, même pour les inscrits."),
            'is_restricted': _("Cochée, la formation exige un achat ou un accès accordé à la main."),
            'estimated_duration': _("Indicatif : aide l'élève à savoir dans quoi il s'engage."),
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': _('Titre de la formation')}),
            'slug': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'django-debutants'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'level': forms.Select(attrs={'class': 'form-control'}),
            'estimated_duration': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': _('Durée en minutes')}),
        }


class PartForm(forms.ModelForm):
    """Création et modification d'une part de formation."""

    class Meta:
        model = Part
        # `course` est posé par la vue, pas par le formulaire : voir le commentaire
        # ci-dessus. L'y laisser rendait la création impossible.
        fields = ['title', 'description', 'content_details', 'is_published']
        labels = {
            'title': _("Titre"),
            'description': _("Description"),
            'content_details': _("Contenu détaillé"),
            'is_published': _("Publié"),
        }
        help_texts = {
            'description': _("Courte introduction, affichée avant d'ouvrir la partie."),
            'content_details': _("Notes internes ou complément affiché à l'élève."),
            'is_published': _("Décoché, la partie reste invisible pour les élèves."),
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'content_details': forms.Textarea(attrs={'class': 'form-control', 'rows': 6}),
        }


class ChapterForm(forms.ModelForm):
    """Création et modification d'une chapter de formation."""

    class Meta:
        model = Chapter
        # `part` est posé par la vue (cf. PartForm).
        fields = ['title', 'description', 'content_details', 'is_published']
        labels = {
            'title': _("Titre"),
            'description': _("Description"),
            'content_details': _("Contenu détaillé"),
            'is_published': _("Publié"),
        }
        help_texts = {
            'description': _("Courte introduction, affichée avant d'ouvrir le chapitre."),
            'content_details': _("Notes internes ou complément affiché à l'élève."),
            'is_published': _("Décoché, le chapitre reste invisible pour les élèves."),
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'content_details': forms.Textarea(attrs={'class': 'form-control', 'rows': 6}),
        }


class SectionForm(forms.ModelForm):
    """Création et modification d'une section de formation."""

    class Meta:
        model = Section
        # `chapter` est posé par la vue (cf. PartForm).
        fields = ['title', 'description', 'content_details', 'section_type', 'is_published']
        labels = {
            'title': _("Titre"),
            'description': _("Description"),
            'content_details': _("Contenu détaillé"),
            'is_published': _("Publié"),
            'section_type': _("Type de section"),
        }
        help_texts = {
            'description': _("Courte introduction, affichée avant d'ouvrir la section."),
            'content_details': _("Notes internes ou complément affiché à l'élève."),
            'is_published': _("Décoché, la section reste invisible pour les élèves."),
            'section_type': _("Vidéo, texte, PDF ou quiz — définit ce que l'élève verra."),
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'content_details': forms.Textarea(attrs={'class': 'form-control', 'rows': 6}),
            'content_details': forms.Textarea(attrs={'class': 'form-control', 'rows': 6}),
            'section_type': forms.Select(attrs={'class': 'form-control'}),
        }


class VideoStorageProviderForm(forms.ModelForm):
    """Form for creating/editing video storage providers."""
    
    config_help = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'readonly': True, 'rows': 8, 'class': 'help-text'}),
        initial="""
Exemples de configuration JSON selon le type:

Vimeo: {"access_token": "...", "client_id": "...", "client_secret": "..."}
Bunny: {"library_id": "...", "api_key": "...", "cdn_hostname": "...", "token_key": "..."}
S3: {"bucket": "...", "region": "...", "access_key": "...", "secret_key": "..."}
FTP: {"host": "...", "port": 21, "username": "...", "password": "...", "base_path": "..."}
        """.strip()
    )
    
    class Meta:
        model = VideoStorageProvider
        fields = ['name', 'provider_type', 'is_active', 'config', 'url_signing_enabled', 'url_expiry_seconds', 'notes']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: Vimeo Production'}),
            'provider_type': forms.Select(attrs={'class': 'form-control'}),
            'config': forms.Textarea(attrs={'class': 'form-control monospace', 'rows': 6, 'placeholder': '{"key": "value"}'}),
            'url_expiry_seconds': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': '3600'}),
            'notes': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # La configuration porte les clés d'API de l'hébergeur (jeton Vimeo, clé
        # Bunny, secret S3, mot de passe FTP). Rendue dans le `<textarea>`, elle
        # repartait en clair dans le HTML à chaque ouverture de l'écran — même
        # défaut que les secrets de Réglages (Fable 1 §1.5). Elle n'est plus
        # renvoyée ; un champ laissé vide conserve celle qui est enregistrée.
        enregistree = bool(self.instance.pk and self.instance.config)
        self.fields['config'] = forms.CharField(
            required=False,
            label=self.fields['config'].label,
            widget=self.fields['config'].widget,
            help_text=(
                _("Une configuration est enregistrée. Laisser vide pour la conserver, "
                "ou saisir le JSON complet pour la remplacer.")
                if enregistree else _("Configuration JSON du fournisseur.")
            ),
        )
        self.initial['config'] = ""

    def clean_config(self):
        """JSON objet, ou vide pour conserver la configuration enregistrée."""
        import json
        brut = (self.cleaned_data.get('config') or '').strip()
        if not brut:
            return self.instance.config if self.instance.pk else {}
        try:
            config = json.loads(brut)
        except json.JSONDecodeError as e:
            raise ValidationError(_("JSON invalide : %(e)s") % {"e": e})
        if not isinstance(config, dict):
            raise ValidationError(_('La configuration doit être un objet JSON : {"cle": "valeur"}.'))
        return config


class VideoContentForm(forms.ModelForm):
    """Form for creating/editing video content."""
    
    class Meta:
        model = VideoContent
        fields = [
            'section', 'title', 'description', 'duration_seconds', 'thumbnail', 'is_preview',
            'storage_type', 'video_file', 'remote_provider', 'remote_video_id', 'remote_video_hash',
            'direct_url', 'ftp_path'
        ]
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'duration_seconds': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': _('Durée en secondes')}),
            'storage_type': forms.Select(attrs={'class': 'form-control'}),
            'remote_video_id': forms.TextInput(attrs={'class': 'form-control', 'placeholder': _('ID de la vidéo')}),
            'remote_video_hash': forms.TextInput(attrs={'class': 'form-control', 'placeholder': _('Hash de la vidéo (ex: Vimeo non listée)')}),
            'direct_url': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'https://...'}),
            'ftp_path': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '/videos/...'}),
        }


class EnrollmentGrantForm(forms.Form):
    """Form to grant course access to a user."""
    
    user = forms.ModelChoiceField(
        queryset=None,  # Will be set in __init__
        widget=forms.Select(attrs={'class': 'form-control'}),
        label=_("Utilisateur")
    )
    course = forms.ModelChoiceField(
        queryset=None,  # Will be set in __init__
        widget=forms.Select(attrs={'class': 'form-control'}),
        label=_("Formation")
    )
    notes = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        label=_("Notes")
    )
    access_expires_at = forms.DateTimeField(
        required=False,
        widget=forms.DateTimeInput(attrs={'class': 'form-control', 'type': 'datetime-local'}),
        label=_("Date d'expiration (optionnel)")
    )
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from django.contrib.auth import get_user_model
        User = get_user_model()
        self.fields['user'].queryset = User.objects.filter(is_active=True).order_by('email')
        self.fields['course'].queryset = Course.objects.filter(is_active=True, is_restricted=True).order_by('title')
