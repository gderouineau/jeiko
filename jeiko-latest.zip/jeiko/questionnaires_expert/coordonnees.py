"""
Ce que la fin d'un questionnaire demande au visiteur, en plus de son nom et
de son adresse (retour client, 08/10/2026 : un questionnaire pour entreprise
veut la société et la fonction, comme une prise de rendez-vous).

Le même principe que `calendars.champs_de_reservation` : un catalogue FIXE,
chaque champ absent, facultatif ou obligatoire, réglé par questionnaire. Ce
qui est saisi remplit la fiche du contact (`Contact.phone`, `company`,
`job_title`) ; retirer un champ n'efface rien de ce qui a déjà été saisi.

Les clés sont en français : `company` est le nom du champ LEURRE anti-robot
(`jeiko.throttling.HONEYPOT_FIELD`), présent sur ce même formulaire. Une
société saisie dans un champ `company` ferait refuser l'envoi comme venant
d'un robot.

Le prénom, le nom et l'adresse restent à part : toujours demandés, toujours
exigés — ils décident du rattachement à une fiche existante.
"""
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

from jeiko.calendars.champs_de_reservation import ABSENT, ETATS, FACULTATIF, OBLIGATOIRE

#: clé du réglage et du formulaire → (champ de la fiche contact, libellé, longueur)
CATALOGUE = {
    "telephone": ("phone", _("Téléphone"), 20),
    "societe": ("company", _("Société"), 200),
    "fonction": ("job_title", _("Fonction"), 200),
}

CHOIX_ETATS = [
    (ABSENT, _("Non demandé")),
    (FACULTATIF, _("Facultatif")),
    (OBLIGATOIRE, _("Obligatoire")),
]


def par_defaut():
    """Ce que demandait un questionnaire avant ce réglage : le téléphone, facultatif."""
    return {"telephone": FACULTATIF}


def valider(valeur):
    """Validateur de `ExpertTest.champs_demandes` : {clé: état}."""
    if not isinstance(valeur, dict):
        raise ValidationError(_("La configuration des champs doit être un objet."))
    inconnues = sorted(set(valeur) - set(CATALOGUE))
    if inconnues:
        raise ValidationError(
            _("Champ(s) inconnu(s) : %(cles)s. Possibles : %(possibles)s.")
            % {"cles": ", ".join(inconnues), "possibles": ", ".join(CATALOGUE)})
    mauvais = sorted(k for k, v in valeur.items() if v not in ETATS)
    if mauvais:
        raise ValidationError(
            _("État inconnu pour %(cles)s : absent, facultatif ou obligatoire.")
            % {"cles": ", ".join(mauvais)})


def etat(test, cle):
    reglage = test.champs_demandes if test is not None else par_defaut()
    return (reglage or {}).get(cle, ABSENT)
