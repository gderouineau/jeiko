# urls_client.py
from django.urls import path
from . import views_client

app_name = "jeiko_client_questionnaires_expert"

urlpatterns = [
    # Page d'introduction du test (description, bouton commencer)
    path(
        "<slug:slug>/",
        views_client.ExpertTestIntroView.as_view(),
        name="test_intro"
    ),

    # Affichage d'une question selon sa position dans le test
    path(
        "<slug:slug>/question/<int:position>/",
        views_client.ExpertTestQuestionView.as_view(),
        name="test_question"
    ),

    # Formulaire d'enregistrement des coordonnées du prospect après les réponses
    path(
        "<slug:slug>/result/input/",
        views_client.ExpertTestResultInputView.as_view(),
        name="test_result_input"
    ),

    # Résultat final du test (page de profil)
    path(
        "<slug:slug>/result/<slug:result_slug>/",
        views_client.ExpertTestResultView.as_view(),
        name="test_result"
    ),
]
