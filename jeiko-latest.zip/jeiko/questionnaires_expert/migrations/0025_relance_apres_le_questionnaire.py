"""
La relance par e-mail après le questionnaire (23/10/2026) : son délai et ses
destinataires par questionnaire, la date d'envoi par résultat, et le contenu
par défaut de `test_relance_resultats`, posé s'il manque, sans rien écraser.
"""
import django.core.validators
from django.db import migrations, models


def poser(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    apply_seed("test_relance_resultats", force=False)


class Migration(migrations.Migration):

    dependencies = [
        ('questionnaires_expert', '0024_resultats_en_pdf'),
    ]

    operations = [
        migrations.AddField(
            model_name='experttest',
            name='relance_apres_jours',
            field=models.PositiveSmallIntegerField(blank=True, help_text="Vide : pas de relance. L'e-mail « Relance après le questionnaire » (Réglages › E-mails) renvoie ses résultats à la personne, une seule fois.", null=True, validators=[django.core.validators.MinValueValidator(1), django.core.validators.MaxValueValidator(365)], verbose_name='Relancer par e-mail après (jours)'),
        ),
        migrations.AddField(
            model_name='experttest',
            name='relance_destinataires',
            field=models.CharField(choices=[('recontact', "Seulement les personnes qui ont accepté d'être recontactées"), ('tous', 'Toutes les personnes qui ont laissé leur adresse')], default='recontact', max_length=10, verbose_name='Relance envoyée à'),
        ),
        migrations.AddField(
            model_name='experttestdata',
            name='relance_envoyee_le',
            field=models.DateTimeField(blank=True, null=True, verbose_name='Relance envoyée le'),
        ),
        migrations.RunPython(poser, migrations.RunPython.noop),
    ]
