# views_client.py
from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import TemplateView
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.contrib.auth import get_user_model
import json
from django.utils.safestring import mark_safe
from django.utils import timezone
from jeiko.administration.models import WebSite, MailSettings


from jeiko.questionnaires_expert.models import (
    ExpertTest, ExpertQuestion, ExpertAnswer, ExpertProfileType,
    ExpertProfileCombination, ExpertProfileCriterion, ExpertTestData
)
from jeiko.questionnaires_expert.models import Prospect

User = get_user_model()

from django.contrib import messages
from django.urls import reverse

class ExpertTestAccessMixin:
    def dispatch(self, request, *args, **kwargs):
        slug = kwargs.get('slug')
        test = get_object_or_404(ExpertTest, slug=slug)
        
        if test.is_restricted:
            if not request.user.is_authenticated:
                return redirect(f"{reverse('jeiko_allauth:login')}?next={request.path}")
            
            # Check if user has access via UserTestAccess
            has_access = (
                request.user.is_superuser or 
                test.user_accesses.filter(user=request.user).exists()
            )
            
            if not has_access:
                messages.error(request, "Vous n'avez pas accès à ce questionnaire.")
                return redirect("home")
        
        return super().dispatch(request, *args, **kwargs)


@method_decorator(never_cache, name='dispatch')
class ExpertTestIntroView(ExpertTestAccessMixin, View):

    @method_decorator(never_cache)
    def get(self, request, slug):
        test = get_object_or_404(ExpertTest, slug=slug)
        return render(request, "questionnaires_expert_client/test_intro.html", {"test": test})


@method_decorator(never_cache, name='dispatch')
class ExpertTestQuestionView(ExpertTestAccessMixin, View):

    @method_decorator(never_cache)
    def get(self, request, slug, position):
        test = get_object_or_404(ExpertTest, slug=slug)
        questions = test.questions.all().order_by("order")
        try:
            question = questions[int(position)]
        except IndexError:
            return redirect("jeiko_client_questionnaires_expert:test_result_input", slug=slug)

        return render(request, "questionnaires_expert_client/question.html", {
            "test": test,
            "question": question,
            "position": int(position),
            "total": questions.count(),
        })

    @method_decorator(never_cache)
    def post(self, request, slug, position):
        test = get_object_or_404(ExpertTest, slug=slug)
        questions = test.questions.all().order_by("order")
        try:
            question = questions[int(position)]
        except IndexError:
            return redirect("jeiko_client_questionnaires_expert:test_result_input", slug=slug)

        if question.question_type == 'multiple':
            selected_answers = request.POST.getlist("answer")
        else:
            selected_answers = request.POST.get("answer")

        if selected_answers:
            answers = request.session.get("answers", {})
            if isinstance(selected_answers, str):
                answers[str(question.id)] = [selected_answers]
            else:
                answers[str(question.id)] = selected_answers
            request.session["answers"] = answers

        return redirect("jeiko_client_questionnaires_expert:test_question", slug=slug, position=int(position) + 1)

@method_decorator(never_cache)
def get_score_profile(test, total_score):
    """
    Retourne le premier profil is_score_profile qui correspond au total_score.
    """
    return (
        ExpertProfileType.objects
        .filter(test=test, is_score_profile=True, min_score__lte=total_score, max_score__gt=total_score)
        .first()
    )

@method_decorator(never_cache, name='dispatch')
class ExpertTestResultInputView(ExpertTestAccessMixin, View):

    @method_decorator(never_cache)
    def get(self, request, slug):
        test = get_object_or_404(ExpertTest, slug=slug)
        questions = test.questions.all().order_by("order")
        answers = request.session.get("answers", {})

        if len(answers) < questions.count():
            return redirect("jeiko_client_questionnaires_expert:test_intro", slug=slug)

        # Si l’utilisateur est connecté, afficher un bouton "Voir mes résultats"
        # Sinon, afficher le formulaire
        return render(
            request,
            "questionnaires_expert_client/prospect_form.html",
            {
                "test": test,
                "user_is_authenticated": request.user.is_authenticated,
            }
        )

    @method_decorator(never_cache)
    def post(self, request, slug):
        test = get_object_or_404(ExpertTest, slug=slug)
        questions = test.questions.prefetch_related("answers").all()
        answers = request.session.get("answers", {})

        profile_scores = {}
        answers_data = []

        for question in questions:
            answer_ids = answers.get(str(question.id))
            if not answer_ids:
                continue
            if isinstance(answer_ids, str):
                answer_ids = [answer_ids]

            question_answers_data = []
            for answer_id in answer_ids:
                try:
                    answer = question.answers.get(id=answer_id)
                    question_answers_data.append({
                        "answer_id": answer.id,
                        "answer_text": answer.text
                    })
                    for weight in answer.profile_weights.all():
                        pid = weight.profile_type_id
                        profile_scores[pid] = profile_scores.get(pid, 0) + weight.weight
                except ExpertAnswer.DoesNotExist:
                    continue

            answers_data.append({
                "question_id": question.id,
                "question_text": question.text,
                "answers": question_answers_data
            })

        simple_profiles = ExpertProfileType.objects.filter(test=test, is_complex=False)
        score_list = []
        for p in simple_profiles:
            score_list.append({
                "profile_id": p.id,
                "slug": p.slug,
                "name": p.name,
                "score": profile_scores.get(p.id, 0),
                "color": p.color,
            })

        # === AJOUT POUR SCORING DIRECT ===
        total_score = sum(profile_scores.values())
        result_profile = None
        preferred = None
        alternative = None

        combinations = ExpertProfileCombination.objects.filter(test=test).prefetch_related(
            "criteria", "parent_profile", "preferred_profile", "alternative_profile"
        )

        for combination in combinations:
            all_criteria = combination.criteria.all().order_by("priority")
            if not all_criteria.exists():
                continue

            valid = True
            for criterion in all_criteria:
                score_a = profile_scores.get(criterion.profile_a_id, 0)
                score_b = profile_scores.get(criterion.profile_b_id, 0)
                if score_a < score_b:
                    valid = False
                    break

            if valid:
                result_profile = combination.parent_profile
                preferred = combination.preferred_profile
                alternative = combination.alternative_profile
                break

        # ===== FALLBACK : Profil par score direct =====
        if not result_profile:
            score_profile = get_score_profile(test, total_score)
            if score_profile:
                result_profile = score_profile
                preferred = None
                alternative = None

        result_block = {
            "dominant": {
                "id": result_profile.id if result_profile else None,
                "slug": result_profile.slug if result_profile else None,
                "name": result_profile.name if result_profile else None
            } if result_profile else None,
            "preferred": {
                "id": preferred.id if preferred else None,
                "slug": preferred.slug if preferred else None,
                "name": preferred.name if preferred else None
            } if preferred else None,
            "alternative": {
                "id": alternative.id if alternative else None,
                "slug": alternative.slug if alternative else None,
                "name": alternative.name if alternative else None
            } if alternative else None,
        }

        test_data = ExpertTestData.objects.create(
            user=request.user if request.user.is_authenticated else None,
            prospect=None,
            test=test,
            result_profile=result_profile,
            preferred_profile=preferred,
            alternative_profile=alternative,
            data={
                "test_id": test.id,
                "test_title": test.title,
                "results": result_block,
                "scores": score_list,
                "answers": answers_data,
                "total_score": total_score,  # Ajout au JSON, utile à l’affichage
            }
        )

        if not request.user.is_authenticated:
            email = request.POST.get("email")
            # Recherche d'un prospect existant avec cet email (insensible à la casse si tu veux)
            prospect = Prospect.objects.filter(email__iexact=email).first()
            if prospect is None:
                # Création seulement si aucun prospect trouvé
                prospect = Prospect.objects.create(
                    firstname=request.POST.get("firstname"),
                    lastname=request.POST.get("lastname"),
                    email=email,
                    phone=request.POST.get("phone"),
                )
            else:
                # (Optionnel) mettre à jour d'autres champs si tu veux garder les infos les plus récentes
                updated = False
                if not prospect.firstname and request.POST.get("firstname"):
                    prospect.firstname = request.POST.get("firstname")
                    updated = True
                if not prospect.lastname and request.POST.get("lastname"):
                    prospect.lastname = request.POST.get("lastname")
                    updated = True
                if not prospect.phone and request.POST.get("phone"):
                    prospect.phone = request.POST.get("phone")
                    updated = True
                if updated:
                    prospect.save()
            test_data.prospect = prospect
            test_data.save()


        # Envoi du mail à l'admin pour dire qu'un test a été passé.
        # On utilise un try/except pour éviter que le processus échoue si le mail
        # est mal configuré ou si l'envoi échoue pour quelque raison que ce soit.
        try:
            from jeiko.administration.emailing import send_simple_email
            
            mail_settings = MailSettings.objects.filter(active=True).select_related('website').first()
            if mail_settings and mail_settings.default_from_email:
                # Qui a passé le test ?
                if request.user.is_authenticated:
                    who = f"Utilisateur connecté: {request.user.get_full_name() or request.user.username} ({request.user.email})"
                else:
                    # On utilise les infos du prospect si dispo
                    if test_data.prospect:
                        who = f"Prospect: {test_data.prospect.firstname} {test_data.prospect.lastname} ({test_data.prospect.email})"
                    else:
                        who = "Prospect anonyme (non connecté, pas de prospect associé)"

                site_name = getattr(mail_settings.website.identity, "name", "Votre site")
                subject = f" Nouveau test passé : {test.title} [{site_name}]"
                body_lines = [
                    f"Un test vient d'être passé sur {site_name}.",
                    "",
                    f"Test : {test.title}",
                    f"Date : {timezone.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    who,
                    "",
                    f"Profil dominant : {result_profile.name if result_profile else 'N/A'}",
                ]
                body = "\n".join(body_lines)

                to_email = [mail_settings.reply_to_email, mail_settings.default_from_email]

                # Utiliser la nouvelle fonction d'envoi d'email
                send_simple_email(
                    subject=subject,
                    body=body,
                    to_recipients=to_email
                )
        except Exception as e:
            print(e)
            pass


        # Nettoyage de la session si besoin
        if "answers" in request.session:
            del request.session["answers"]

        return redirect(
            "jeiko_client_questionnaires_expert:test_result",
            slug=slug,
            result_slug=result_profile.slug if result_profile else "inconnu"
        )


@method_decorator(never_cache, name='dispatch')
class ExpertTestResultView(TemplateView):
    template_name = 'pages/main.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        result_slug = self.kwargs.get("result_slug")
        profile = get_object_or_404(ExpertProfileType, slug=result_slug)
        test = profile.test

        context["profile"] = profile
        context["test"] = test
        context["page"] = profile.result_page

        # id simple pour le canvas/JS
        context["chart_id"] = f"res-{profile.id}"

        # 🔑 Récupération du dernier ExpertTestData lié à ce test
        test_data = (
            ExpertTestData.objects
            .filter(test=test)
            .order_by("-created_at")
            .first()
        )

        chart_data = None
        if test_data and test_data.data and "scores" in test_data.data:
            scores = test_data.data["scores"]
            chart_data = {
                "labels": [s["name"] for s in scores],
                "datasets": [{
                    "label": test.title,
                    "data": [float(s["score"]) for s in scores],
                    "backgroundColor": [s.get("color") or "#cccccc" for s in scores],
                }]
            }

        # Si pas de données → fallback vide
        if chart_data:
            context["chart_data_json"] = mark_safe(json.dumps(chart_data, ensure_ascii=False))
        else:
            context["chart_data_json"] = mark_safe('{"labels":[],"datasets":[]}')

        context["show_chart"] = True
        return context


