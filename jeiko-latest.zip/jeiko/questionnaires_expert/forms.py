from django import forms
from django.forms import inlineformset_factory
from .models import (
    ExpertTest, ExpertQuestion, ExpertAnswer,
    ExpertAnswerProfileWeight, ExpertProfileType,
    ExpertProfileCombination,
    ExpertTestStyle, DEFAULT_TEST_STYLE, validate_test_style
)


class DynamicExpertTestForm(forms.Form):
    def __init__(self, test, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for question in test.questions.all():
            choices = [(a.id, a.text) for a in question.answers.all()]

            # On vérifie le type de la question
            is_multiple = question.question_type == 'multiple'

            field_class = forms.MultipleChoiceField if is_multiple else forms.ChoiceField
            widget = forms.CheckboxSelectMultiple() if is_multiple else forms.RadioSelect()

            # Style dynamique éventuel
            if hasattr(question, "style") and question.style:
                widget.attrs.update(question.style)

            self.fields[f"question_{question.id}"] = field_class(
                label=question.text,
                choices=choices,
                widget=widget,
                required=False  # Pour éviter les erreurs si la réponse est laissée vide
            )


class ExpertProfileTypeForm(forms.ModelForm):
    class Meta:
        model = ExpertProfileType
        fields = [
            "name", "description", "result_page", "is_complex",
            "parent_profiles",  # ManyToMany
            "is_score_profile", "min_score", "max_score", "score_axis",
            "color",
        ]
        widgets = {
            "parent_profiles": forms.CheckboxSelectMultiple,
            "description": forms.Textarea(attrs={"rows": 2}),
            "color": forms.TextInput(attrs={"type": "color"}),
        }

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("is_score_profile"):
            min_score = cleaned.get("min_score")
            max_score = cleaned.get("max_score")
            if min_score is None or max_score is None:
                raise forms.ValidationError(
                    "Pour un profil par score direct, vous devez définir min_score et max_score.")
            if min_score >= max_score:
                raise forms.ValidationError("min_score doit être inférieur à max_score.")
        return cleaned

    def __init__(self, *args, **kwargs):
        test = kwargs.pop('test', None)
        super().__init__(*args, **kwargs)
        if test:
            self.fields["parent_profiles"].queryset = ExpertProfileType.objects.filter(test=test)
        # Pour l’édition, limiter aussi score_axis aux profils du test (optionnel)
        if test and "score_axis" in self.fields:
            self.fields["score_axis"].queryset = ExpertProfileType.objects.filter(test=test)


class ExpertAnswerForm(forms.ModelForm):
    class Meta:
        model = ExpertAnswer
        fields = ["text"]


class ExpertAnswerProfileWeightForm(forms.ModelForm):
    class Meta:
        model = ExpertAnswerProfileWeight
        fields = ["profile_type", "weight"]

    def __init__(self, *args, **kwargs):
        answer = kwargs.pop("answer", None)
        super().__init__(*args, **kwargs)
        if answer:
            test = answer.question.test
            self.fields["profile_type"].queryset = ExpertProfileType.objects.filter(test=test)


AnswerProfileWeightFormSet = inlineformset_factory(
    parent_model=ExpertAnswer,
    model=ExpertAnswerProfileWeight,
    form=ExpertAnswerProfileWeightForm,
    extra=1,
    can_delete=True
)


class ExpertProfileCombinationForm(forms.ModelForm):
    class Meta:
        model = ExpertProfileCombination
        fields = ["title", "parent_profile", "preferred_profile", "alternative_profile"]

    def __init__(self, *args, **kwargs):
        test = kwargs.pop("test", None)
        super().__init__(*args, **kwargs)
        if test:
            queryset = ExpertProfileType.objects.filter(test=test)
            self.fields["parent_profile"].queryset = queryset
            self.fields["preferred_profile"].queryset = queryset
            self.fields["alternative_profile"].queryset = queryset




class ExpertTestStyleForm(forms.ModelForm):
    # on mappe des champs explicites aux clés du JSON
    font_family = forms.CharField(label="Police", required=False)

    title_color = forms.CharField(label="Couleur du titre", widget=forms.TextInput(attrs={"type": "color"}))
    title_size_mobile_px = forms.IntegerField(label="Taille titre · Mobile (px)", min_value=12, max_value=64)
    title_size_tablet_px = forms.IntegerField(label="Taille titre · Tablette (px)", min_value=12, max_value=64)
    title_size_desktop_px = forms.IntegerField(label="Taille titre · Ordinateur (px)", min_value=12, max_value=64)

    input_font_size_mobile_px = forms.IntegerField(label="Taille réponses · Mobile (px)", min_value=12, max_value=40)
    input_font_size_tablet_px = forms.IntegerField(label="Taille réponses · Tablette (px)", min_value=12, max_value=40)
    input_font_size_desktop_px = forms.IntegerField(label="Taille réponses · Ordinateur (px)", min_value=12, max_value=40)

    theme_color = forms.CharField(label="Couleur du thème", widget=forms.TextInput(attrs={"type": "color"}))
    body_bg = forms.CharField(label="Couleur de fond (body)", widget=forms.TextInput(attrs={"type": "color"}))

    answer_radius_px = forms.IntegerField(label="Arrondi des réponses (px)", min_value=0, max_value=40, required=False)

    class Meta:
        model = ExpertTestStyle
        fields = ["style"]  # on persiste dans style JSON, pas ces champs "virtuels"
        widgets = {"style": forms.HiddenInput()}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        st = {**DEFAULT_TEST_STYLE, **(self.instance.style or {})}

        for k, v in st.items():
            if k in self.fields:
                self.fields[k].initial = v

    def clean(self):
        cleaned = super().clean()
        # rebuild JSON style from the “virtual” fields
        keys = [
            "font_family",
            "title_color", "title_size_mobile_px", "title_size_tablet_px", "title_size_desktop_px",
            "input_font_size_mobile_px", "input_font_size_tablet_px", "input_font_size_desktop_px",
            "theme_color",
            "body_bg",
            "answer_radius_px"
        ]
        style = {}
        for k in keys:
            style[k] = self.cleaned_data.get(k, DEFAULT_TEST_STYLE.get(k))

        # validation centralisée
        validate_test_style(style)

        cleaned["style"] = style
        return cleaned