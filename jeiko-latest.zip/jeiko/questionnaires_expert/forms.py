from django import forms
from django.forms import inlineformset_factory
from .models import (
    ExpertTest, ExpertQuestion, ExpertAnswer,
    ExpertAnswerProfileWeight, ExpertProfileType,
    ExpertProfileCombination
)


class DynamicExpertTestForm(forms.Form):
    def __init__(self, test, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for question in test.questions.all():
            choices = [(a.id, a.text) for a in question.answers.all()]

            # On vérifie le type de la question
            is_multiple = question.question_type == 'multiple'

            field_class = forms.MultipleChoiceField if is_multiple else forms.ChoiceField
            widget = forms.CheckboxSelectMultiple() if is_multiple else forms.RadioSelect()

            # Style dynamique éventuel
            if hasattr(question, "style") and question.style:
                widget.attrs.update(question.style)

            self.fields[f"question_{question.id}"] = field_class(
                label=question.text,
                choices=choices,
                widget=widget,
                required=False  # Pour éviter les erreurs si la réponse est laissée vide
            )


class ExpertProfileTypeForm(forms.ModelForm):
    class Meta:
        model = ExpertProfileType
        fields = [
            "name", "description", "result_page", "is_complex",
            "parent_profiles",  # ManyToMany
            "is_score_profile", "min_score", "max_score", "score_axis",
            "color",
        ]
        widgets = {
            "parent_profiles": forms.CheckboxSelectMultiple,
            "description": forms.Textarea(attrs={"rows": 2}),
            "color": forms.TextInput(attrs={"type": "color"}),
        }

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("is_score_profile"):
            min_score = cleaned.get("min_score")
            max_score = cleaned.get("max_score")
            if min_score is None or max_score is None:
                raise forms.ValidationError(
                    "Pour un profil par score direct, vous devez définir min_score et max_score.")
            if min_score >= max_score:
                raise forms.ValidationError("min_score doit être inférieur à max_score.")
        return cleaned

    def __init__(self, *args, **kwargs):
        test = kwargs.pop('test', None)
        super().__init__(*args, **kwargs)
        if test:
            self.fields["parent_profiles"].queryset = ExpertProfileType.objects.filter(test=test)
        # Pour l’édition, limiter aussi score_axis aux profils du test (optionnel)
        if test and "score_axis" in self.fields:
            self.fields["score_axis"].queryset = ExpertProfileType.objects.filter(test=test)


class ExpertAnswerForm(forms.ModelForm):
    class Meta:
        model = ExpertAnswer
        fields = ["text"]


class ExpertAnswerProfileWeightForm(forms.ModelForm):
    class Meta:
        model = ExpertAnswerProfileWeight
        fields = ["profile_type", "weight"]

    def __init__(self, *args, **kwargs):
        answer = kwargs.pop("answer", None)
        super().__init__(*args, **kwargs)
        if answer:
            test = answer.question.test
            self.fields["profile_type"].queryset = ExpertProfileType.objects.filter(test=test)


AnswerProfileWeightFormSet = inlineformset_factory(
    parent_model=ExpertAnswer,
    model=ExpertAnswerProfileWeight,
    form=ExpertAnswerProfileWeightForm,
    extra=1,
    can_delete=True
)


class ExpertProfileCombinationForm(forms.ModelForm):
    class Meta:
        model = ExpertProfileCombination
        fields = ["title", "parent_profile", "preferred_profile", "alternative_profile"]

    def __init__(self, *args, **kwargs):
        test = kwargs.pop("test", None)
        super().__init__(*args, **kwargs)
        if test:
            queryset = ExpertProfileType.objects.filter(test=test)
            self.fields["parent_profile"].queryset = queryset
            self.fields["preferred_profile"].queryset = queryset
            self.fields["alternative_profile"].queryset = queryset
