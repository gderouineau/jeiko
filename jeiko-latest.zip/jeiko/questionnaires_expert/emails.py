"""
Emails du module questionnaires_expert.

Ce fichier ne compose plus de messages : il traduit un ExpertTestData en contexte
et délègue à `jeiko.emailing`, où le sujet et la mise en page sont éditables en
back-office (codes `test_completed_results` et `test_results_admin`).

Les vues n'appellent que `send_test_result_email()` et
`send_admin_test_notification()` : leurs signatures et leur contrat sont
inchangés — retour `(success, error)`, jamais d'exception, un échec d'envoi ne
doit pas coûter son résultat au visiteur.
"""

import logging

from django.utils.html import escape

from jeiko.emailing.services import send_email

logger = logging.getLogger(__name__)


def _admin_recipients():
    """Destinataires internes, d'après la configuration mail du site."""
    from jeiko.emailing.sending import admin_recipients
    return admin_recipients()


def _admin_url(name, **kwargs):
    """URL absolue d'une vue d'administration (pour les liens dans les e-mails)."""
    from django.urls import NoReverseMatch, reverse
    from jeiko.emailing.render import site_base_url

    try:
        path = reverse(name, kwargs=kwargs)
    except NoReverseMatch:
        return ""
    base = site_base_url()
    return f"{base}{path}" if base else path


def _nombre(valeur):
    """10.0 → « 10 », 7.5 → « 7,5 » : un score se lit, il ne se calcule pas."""
    if isinstance(valeur, bool) or not isinstance(valeur, (int, float)):
        return str(valeur if valeur is not None else "")
    return f"{valeur:g}".replace(".", ",")


def _scores_table(test_data):
    """
    Les scores par profil, injectés via [%bloc_resultats%].

    Construit ici plutôt que dans le modèle éditable : une boucle sur des données
    n'est pas exprimable avec de simples balises [%cle%]. Le rendu est en <table>
    à styles inline, seule forme fiable en messagerie.

    Une seule colonne, le score SOUS le nom : en deux colonnes, sur un
    téléphone, un nom long passait à la ligne et décalait son score face au
    profil suivant (signalé par Guillaume le 04/10/2026).
    """
    scores = (test_data.data or {}).get("scores") or []
    if not scores:
        return ""

    rows = []
    for entry in scores:
        name = escape(str(entry.get("name") or ""))
        value = escape(_nombre(entry.get("score", "")))
        color = str(entry.get("color") or "#cccccc")
        if not color.startswith("#"):
            color = "#cccccc"

        rows.append(
            '<tr>'
            '<td style="padding:8px;border-bottom:1px solid #eeeeee;">'
            f'<span style="display:inline-block;width:10px;height:10px;'
            f'background-color:{color};margin-right:8px;"></span>{name}'
            f'<br><strong style="display:inline-block;margin-top:2px;">{value}</strong></td>'
            '</tr>'
        )

    return (
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" '
        'border="0" style="width:100%;border-collapse:collapse;">'
        + "".join(rows) +
        '</table>'
    )


def _score_du_profil(test_data, profile):
    """
    Le score à côté de « Profil : » est celui DE CE profil.

    On y mettait `total_score`, la somme de tous les profils : « Fais plaisir,
    score 39 » quand Fais plaisir valait 10 (04/10/2026). Le total n'a de sens
    que pour un profil défini par une plage de total (`is_score_profile`) ; un
    profil de combinaison n'a pas de score à lui, la ligne reste vide.
    """
    data = test_data.data or {}
    if profile is None:
        return ""
    if getattr(profile, "is_score_profile", False):
        return _nombre(data.get("total_score", ""))
    for entry in data.get("scores") or []:
        if entry.get("profile_id") == profile.pk:
            return _nombre(entry.get("score", ""))
    return ""


def _dimensions_table(resultat):
    """
    Mode « dimensions » : chaque dimension et le titre de sa tranche, sans
    chiffre — même ordre que la page (la tête d'abord), même exigence :
    pas de pourcentage, pas de comparaison.

    Une seule colonne, la tranche SOUS la dimension, comme `_scores_table` :
    en deux colonnes, sur un téléphone, un nom long décalait la ligne
    (retour client, 08/10/2026).
    """
    rows = []
    for dimension in resultat.all:
        tranche = dimension.band.title if dimension.band and dimension.band.title else "—"
        color = dimension.color or "#cccccc"
        rows.append(
            '<tr>'
            '<td style="padding:8px;border-bottom:1px solid #eeeeee;">'
            f'<span style="display:inline-block;width:10px;height:10px;'
            f'background-color:{color};margin-right:8px;"></span>'
            f'{escape(dimension.profile.name)}'
            f'<br><strong style="display:inline-block;margin-top:2px;">{escape(tranche)}</strong></td>'
            '</tr>'
        )
    if not rows:
        return ""
    return (
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" '
        'border="0" style="width:100%;border-collapse:collapse;">'
        + "".join(rows) +
        '</table>'
    )


def _dimensions_context(test_data):
    """
    Les mêmes clés que le mode profil, remplies avec ce qui a un sens ici.

    Les modèles d'e-mail sont communs à tous les questionnaires d'un site et
    éditables : on ne peut pas y ajouter de condition par mode. Sans ceci, le
    message annonçait « Profil : » vide et un « Score » qui additionne des
    dimensions indépendantes — un nombre qui ne veut rien dire.
    """
    from jeiko.questionnaires_expert.dimensions import arrange, scores_from_test_data

    resultat = arrange(test_data.test, scores_from_test_data(test_data))
    if resultat.nuanced:
        profil = "Profil nuancé"
    else:
        profil = ", ".join(
            (d.band.title if d.band and d.band.title else d.profile.name)
            for d in resultat.head
        )
    return {
        "test_nom": test_data.test.title,
        "score": "",
        "profil": profil,
        "profil_description": "",
        "bloc_resultats": _dimensions_table(resultat),
    }


def _base_context(test_data):
    if test_data.test.uses_dimensions:
        return _dimensions_context(test_data)

    profile = test_data.result_profile

    return {
        "test_nom": test_data.test.title,
        "score": _score_du_profil(test_data, profile),
        "profil": profile.name if profile else "",
        "profil_description": profile.description if profile else "",
        "bloc_resultats": _scores_table(test_data),
    }


def _contexte_du_titulaire(test_data, request=None):
    """
    Ce que voit la personne qui a passé le test : son résultat, le lien signé
    vers sa page, le PDF s'il est proposé, son prénom. Commun à l'e-mail de
    fin et à la relance, pour qu'ils ne divergent pas.

    Sans requête (la relance part de la tâche quotidienne), les liens sont
    rendus absolus par l'adresse du site : un lien relatif dans un e-mail ne
    mène nulle part.
    """
    from jeiko.emailing.render import absolute_url

    def absolu(chemin):
        return request.build_absolute_uri(chemin) if request is not None else absolute_url(chemin)

    context = _base_context(test_data)
    # confirm=True : ce lien porte la signature qui vaut vérification de
    # l'adresse. Il ne doit figurer que dans le message au titulaire — la
    # notification interne reçoit la version non signée.
    context["lien_resultats"] = absolu(test_data.get_result_url(confirm=True))
    # D-12 : un LIEN vers le PDF, pas une pièce jointe — un envoi joint qui
    # échoue n'est jamais repris (emailing/services.py), et ce message-ci ne
    # doit pas se perdre pour un document que la page sait refaire.
    if test_data.test.pdf_des_resultats:
        from jeiko.questionnaires_expert.views.client import lien_du_pdf

        context["lien_resultats_pdf"] = absolu(lien_du_pdf(test_data))

    parts = (test_data.recipient_name or "").split()
    if parts:
        context["prenom"] = parts[0]
        context["nom"] = " ".join(parts[1:])
    return context


def send_test_result_email(test_data, request=None):
    """
    Envoie à la personne ayant passé le test le lien vers sa page de résultat.

    Retourne (success: bool, error: str|None).
    """
    recipient = test_data.recipient_email
    if not recipient:
        return False, "Aucune adresse email pour ce résultat"

    context = _contexte_du_titulaire(test_data, request)

    try:
        return send_email(
            "test_completed_results",
            recipient,
            context,
            user=test_data.user,
        )
    except Exception as exc:
        logger.exception("Échec de l'envoi du résultat #%s à %s", test_data.pk, recipient)
        return False, str(exc)


def send_admin_test_notification(test_data, request=None):
    """
    Notifie l'équipe qu'un test vient d'être passé, avec le lien vers le résultat.

    Retourne (success: bool, error: str|None).
    """
    recipients = _admin_recipients()
    if not recipients:
        return False, "Aucun destinataire administrateur configuré"

    context = _base_context(test_data)
    # Version non signée : ce lien ne doit pas valider l'adresse du répondant.
    context["lien_resultats"] = test_data.get_result_absolute_url(request)
    context["client_nom"] = test_data.recipient_name or "Répondant anonyme"
    context["client_email"] = test_data.recipient_email or "—"

    # Liens vers l'administration : détail du test, et fiche du prospect
    # lorsque le répondant n'a pas de compte.
    context["lien_testdata"] = _admin_url(
        "jeiko_administration_questionnaires_expert:test_data_detail",
        pk=test_data.pk,
    )
    if test_data.prospect_id:
        context["lien_prospect"] = _admin_url(
            "jeiko_crm:fiche",
            pk=test_data.prospect_id,
        )
    else:
        # Répondant connecté : pas de fiche prospect, on renvoie vers le test.
        context["lien_prospect"] = context["lien_testdata"]

    try:
        return send_email("test_results_admin", recipients, context)
    except Exception as exc:
        logger.exception("Échec de la notification admin pour le résultat #%s", test_data.pk)
        return False, str(exc)


# --------------------------------------------------------------------------- #
#  La relance, quelques jours après le passage (23/10/2026)
# --------------------------------------------------------------------------- #
#: Au-delà de son échéance, un résultat a encore une semaine pour être relancé
#: — le temps qu'une tâche quotidienne en panne reprenne. Sans cette borne,
#: activer la relance sur un questionnaire écrirait d'un coup à tous ses
#: répondants depuis des années.
# ponytail: fenêtre fixe de 7 jours ; une date « relance active depuis » si un
# exploitant veut rattraper une panne plus longue.
RATTRAPAGE_DE_LA_RELANCE_JOURS = 7


def a_relancer(test, maintenant=None):
    """Les résultats de ce questionnaire dont la relance est due aujourd'hui."""
    from datetime import timedelta

    from django.utils import timezone

    if not test.relance_apres_jours:
        return test.datas.none()
    echeance = (maintenant or timezone.now()) - timedelta(days=test.relance_apres_jours)
    resultats = test.datas.filter(
        relance_envoyee_le__isnull=True,
        created_at__lte=echeance,
        created_at__gt=echeance - timedelta(days=RATTRAPAGE_DE_LA_RELANCE_JOURS),
    ).select_related("test", "user", "prospect", "result_profile")
    if test.relance_destinataires != test.RELANCE_TOUS:
        # L'accord se lit sur la fiche : donné en fin de questionnaire, il y
        # est daté et prouvé (`record_consent`).
        resultats = resultats.filter(prospect__recontact_accepte_le__isnull=False)
    return resultats


def send_test_relance_email(test_data, maintenant=None):
    """La relance d'un résultat. Retourne (success, error), jamais d'exception."""
    from django.utils import timezone

    recipient = test_data.recipient_email
    if not recipient:
        return False, "Aucune adresse email pour ce résultat"
    passage = timezone.localtime(test_data.created_at)
    context = _contexte_du_titulaire(test_data)
    context["date_passage"] = passage.strftime("%d/%m/%Y")
    context["jours"] = str(((maintenant or timezone.now()) - test_data.created_at).days)
    try:
        return send_email("test_relance_resultats", recipient, context, user=test_data.user)
    except Exception as exc:
        logger.exception("Échec de la relance du résultat #%s à %s", test_data.pk, recipient)
        return False, str(exc)


def envoyer_les_relances(maintenant=None):
    """
    Les relances du jour, pour tous les questionnaires qui en demandent une.
    Un résultat n'est marqué qu'une fois l'e-mail parti : un envoi raté se
    retente le lendemain, dans la fenêtre de rattrapage. Retourne le nombre
    d'e-mails partis.
    """
    from django.utils import timezone

    from jeiko.questionnaires_expert.models import ExpertTest

    maintenant = maintenant or timezone.now()
    partis = 0
    for test in ExpertTest.objects.filter(relance_apres_jours__isnull=False):
        for resultat in a_relancer(test, maintenant):
            ok, _motif = send_test_relance_email(resultat, maintenant)
            if ok:
                resultat.relance_envoyee_le = maintenant
                resultat.save(update_fields=["relance_envoyee_le"])
                partis += 1
    return partis
