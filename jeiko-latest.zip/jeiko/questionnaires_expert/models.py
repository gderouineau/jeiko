from django.db import models
from django.utils.text import slugify
from jeiko.administration_pages.models import Page
from django.conf import settings
import uuid
import string
import random
from django.core.validators import RegexValidator
from copy import deepcopy
from decimal import Decimal
from django.core.exceptions import ValidationError

class ExpertTest(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    is_restricted = models.BooleanField(default=False, verbose_name="Accès restreint")

    def __str__(self):
        return self.title


class UserTestAccess(models.Model):
    ACCESS_SOURCE_CHOICES = [
        ('PURCHASE', 'Achat'),
        ('ADMIN', 'Administrateur'),
        ('FREE', 'Gratuit / Offert'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="test_accesses"
    )
    test = models.ForeignKey(
        ExpertTest,
        on_delete=models.CASCADE,
        related_name="user_accesses"
    )
    source = models.CharField(
        max_length=20,
        choices=ACCESS_SOURCE_CHOICES,
        default='ADMIN'
    )
    granted_at = models.DateTimeField(auto_now_add=True)
    granted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="granted_test_accesses",
        help_text="L'administrateur qui a donné l'accès (si applicable)"
    )

    class Meta:
        unique_together = ('user', 'test')
        verbose_name = "Accès au test"
        verbose_name_plural = "Accès aux tests"

    def __str__(self):
        return f"{self.user} -> {self.test} ({self.get_source_display()})"



ALLOWED_TEST_STYLE_SCHEMA = {
    # global
    "font_family": str,

    # titre
    "title_color": str,
    "title_size_mobile_px": int,
    "title_size_tablet_px": int,
    "title_size_desktop_px": int,

    # inputs/select/submit (tailles + couleur thème)
    "input_font_size_mobile_px": int,
    "input_font_size_tablet_px": int,
    "input_font_size_desktop_px": int,
    "submit_font_size_px": int,
    "theme_color": str,   # appliqué à: hover/select answer + bouton submit

    # fond global
    "body_bg": str,

    # petits bonus utiles
    "answer_radius_px": int,
    "submit_radius_px": int,
}

DEFAULT_TEST_STYLE = {
    "font_family": "Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif",

    "title_color": "#111111",
    "title_size_mobile_px": 22,
    "title_size_tablet_px": 26,
    "title_size_desktop_px": 30,

    "input_font_size_mobile_px": 18,
    "input_font_size_tablet_px": 18,
    "input_font_size_desktop_px": 20,
    "submit_font_size_px": 20,

    # ton orange par défaut
    "theme_color": "#FF4E0F",

    "body_bg": "#ffffff",

    "answer_radius_px": 20,
    "submit_radius_px": 20,
}

def default_test_style():
    return deepcopy(DEFAULT_TEST_STYLE)

def _coerce_int(d, key):
    if key in d and not isinstance(d[key], int):
        try:
            d[key] = int(d[key])
        except Exception:
            raise ValidationError(f"{key} doit être un entier.")


def _coerce_float(d, key):
    if key in d and not isinstance(d[key], (int, float, Decimal)):
        try:
            d[key] = float(d[key])
        except Exception:
            raise ValidationError(f"{key} doit être un nombre.")


def _hex_to_rgb(hex_str):
    s = hex_str.strip()
    if s.startswith("#"):
        s = s[1:]
    if len(s) == 3:
        s = "".join(ch*2 for ch in s)
    if len(s) != 6:
        raise ValueError("Couleur hex invalide")
    r = int(s[0:2], 16)
    g = int(s[2:4], 16)
    b = int(s[4:6], 16)
    return (r, g, b)


def _rgba_str(hex_str, alpha):
    r, g, b = _hex_to_rgb(hex_str)
    a = max(0.0, min(1.0, float(alpha)))
    return f"rgba({r},{g},{b},{a})"


def _lighten(hex_str, factor=0.18):
    """Éclaircit la couleur (0..1) -> hex."""
    r, g, b = _hex_to_rgb(hex_str)
    def L(c):
        return int(c + (255 - c) * factor)
    return "#{:02X}{:02X}{:02X}".format(L(r), L(g), L(b))


def validate_test_style(value):
    if not isinstance(value, dict):
        raise ValidationError("Le style doit être un objet JSON.")

    # Coercions simples
    ints = [
        "title_size_mobile_px", "title_size_tablet_px", "title_size_desktop_px",
        "input_font_size_mobile_px", "input_font_size_tablet_px", "input_font_size_desktop_px",
        "submit_font_size_px",
        "answer_radius_px", "submit_radius_px",
    ]
    for k in ints:
        _coerce_int(value, k)

    # Bornes raisonnables
    def in_range(k, v, lo, hi):
        if k in value and not (lo <= int(value[k]) <= hi):
            raise ValidationError(f"{k} doit être entre {lo} et {hi}. (valeur: {value[k]})")

    for k in ["title_size_mobile_px", "title_size_tablet_px", "title_size_desktop_px"]:
        in_range(k, value.get(k, 0), 12, 64)
    for k in ["input_font_size_mobile_px", "input_font_size_tablet_px", "input_font_size_desktop_px", "submit_font_size_px"]:
        in_range(k, value.get(k, 0), 12, 40)
    for k in ["answer_radius_px", "submit_radius_px"]:
        in_range(k, value.get(k, 0), 0, 40)

    # Validation simple couleurs: commence par # et 3/6 hexdigits
    import re
    hex_re = re.compile(r"^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")
    for k in ["title_color", "theme_color", "body_bg"]:
        if k in value and not hex_re.match(str(value[k]).strip()):
            raise ValidationError(f"{k} doit être un hex valide, ex: #FF4E0F")


class ExpertTestStyle(models.Model):
    test = models.OneToOneField(ExpertTest, on_delete=models.CASCADE, related_name="style_config")
    style = models.JSONField(default=default_test_style, validators=[validate_test_style])
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Style · {self.test.title}"

    def get_css_vars(self) -> dict:
        """
        Transforme le JSON en variables CSS prêtes à injecter dans le template.
        Pré-calcule une couleur 'hover' plus claire et une variante rgba.
        """
        s = {**DEFAULT_TEST_STYLE, **(self.style or {})}
        theme = s["theme_color"]
        return {
            "--q-font-family": s["font_family"],

            "--q-title-color": s["title_color"],
            "--q-title-size-mobile": f"{s['title_size_mobile_px']}px",
            "--q-title-size-tablet": f"{s['title_size_tablet_px']}px",
            "--q-title-size-desktop": f"{s['title_size_desktop_px']}px",

            "--q-input-size-mobile": f"{s['input_font_size_mobile_px']}px",
            "--q-input-size-tablet": f"{s['input_font_size_tablet_px']}px",
            "--q-input-size-desktop": f"{s['input_font_size_desktop_px']}px",
            "--q-submit-size": f"{s['submit_font_size_px']}px",

            "--q-theme": theme,
            "--q-theme-hover": _lighten(theme, 0.18),
            "--q-theme-rgba-40": _rgba_str(theme, 0.40),

            "--q-body-bg": s["body_bg"],

            "--q-answer-radius": f"{s['answer_radius_px']}px",
            "--q-submit-radius": f"{s['submit_radius_px']}px",
        }


class ExpertProfileType(models.Model):

    test = models.ForeignKey(ExpertTest, on_delete=models.CASCADE, related_name="profiles")
    name = models.CharField(
        max_length=100
    )

    description = models.TextField(
        blank=True
    )
    result_page = models.ForeignKey(
        Page,
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    slug = models.SlugField(
        max_length=100,
        unique=True,
        blank=True
    )
    is_complex = models.BooleanField(
        default=False,
        help_text="Profil majeur/complexe ou simple"
    )
    is_score_profile = models.BooleanField(
        default=False,
        help_text="Ce profil peut être assigné automatiquement en fonction d'un score global."
    )
    min_score = models.FloatField(
        null=True, blank=True,
        help_text="Score minimum (inclus) pour attribuer ce profil. Laisser vide si non applicable."
    )
    max_score = models.FloatField(
        null=True, blank=True,
        help_text="Score maximum (exclus) pour attribuer ce profil. Laisser vide si non applicable."
    )
    score_axis = models.CharField(
        max_length=100, blank=True,
        help_text="Nom du score à utiliser (laisse vide pour score global). Permet d'étendre aux tests multi-axes."
    )
    # Relation many-to-many récursive pour parents (et donc enfants en reverse)
    parent_profiles = models.ManyToManyField(
        'self',
        symmetrical=False,
        related_name='child_profiles',
        blank=True,
        help_text="Profils parents de ce profil (relation many-to-many récursive)"
    )

    color = models.CharField(
        max_length=7,
        blank=True,
        default="#cccccc",
        validators=[
            RegexValidator(
                regex=r"^#(?:[0-9a-fA-F]{3}){1,2}$",
                message="Entrez une couleur hexadécimale valide, ex : #3A4BC7"
            )
        ],
        help_text="Couleur associée au profil (ex : #FF0000)."
    )

    def save(self, *args, **kwargs):
        if not self.slug and self.name:
            base = slugify(self.name)
            suffix = str(uuid.uuid4())[:8]  # 8 caractères pour limiter la longueur
            self.slug = f"{base}-{suffix}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class ExpertQuestion(models.Model):
    test = models.ForeignKey(ExpertTest, on_delete=models.CASCADE, related_name='questions')
    text = models.TextField()
    order = models.PositiveIntegerField(default=0)
    question_type = models.CharField(
        max_length=50,
        choices=[('single', 'Choix unique'), ('multiple', 'Choix multiple')],
        default='single'
    )
    extra_config = models.JSONField(blank=True, null=True)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.text


class ExpertAnswer(models.Model):
    question = models.ForeignKey(ExpertQuestion, on_delete=models.CASCADE, related_name='answers')
    text = models.CharField(max_length=300)
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.text


class ExpertAnswerProfileWeight(models.Model):
    answer = models.ForeignKey(
        ExpertAnswer,
        on_delete=models.CASCADE,
        related_name='profile_weights',

    )
    profile_type = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    weight = models.FloatField(default=1.0)

    class Meta:
        unique_together = ('answer', 'profile_type')

    def __str__(self):
        return f"{self.answer.text} → {self.profile_type.name} (poids {self.weight})"


class ExpertProfileCombination(models.Model):
    test = models.ForeignKey(ExpertTest, on_delete=models.CASCADE, related_name="combinations")

    parent_profile = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        related_name='parent_combinations',

    )
    preferred_profile = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        related_name='preferred_combinations',

        blank=True, null=True
    )
    alternative_profile = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        related_name='alternative_combinations',

        blank=True, null=True
    )
    slug = models.SlugField(max_length=150, blank=True, unique=True)
    title = models.CharField(max_length=150, blank=True)

    def save(self, *args, **kwargs):
        if not self.slug and self.title:
            base = slugify(self.title)
            suffix = str(uuid.uuid4())[:8]  # 8 caractères pour limiter la longueur
            self.slug = f"{base}-{suffix}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title or f"Combinaison {self.id} pour {self.test.title}"



class ExpertProfileCriterion(models.Model):
    combination = models.ForeignKey(
        'ExpertProfileCombination',
        on_delete=models.CASCADE,
        related_name='criteria'
    )

    profile_a = models.ForeignKey(
        'ExpertProfileType',
        on_delete=models.CASCADE,
        related_name='criteria_as_a'
    )
    profile_b = models.ForeignKey(
        'ExpertProfileType',
        on_delete=models.CASCADE,
        related_name='criteria_as_b'
    )

    # Comparateur : >, <, >=, <=, ==, ~= (proche)
    COMPARISON_CHOICES = [
        ('>', 'Supérieur à'),
        ('<', 'Inférieur à'),
        ('>=', 'Supérieur ou égal à'),
        ('<=', 'Inférieur ou égal à'),
        ('==', 'Égal à'),
        ('~=', 'Proche de'),  # différence absolue <= tolerance
    ]
    comparison = models.CharField(
        max_length=4,
        choices=COMPARISON_CHOICES,
        default='>',
    )

    # Écart minimal toléré pour que la condition soit vraie (optionnel)
    tolerance = models.IntegerField(
        null=True,
        blank=True,
        help_text="Valeur utilisée uniquement pour '~=' (proximité)"
    )

    # Priorité dans l’évaluation (comme aujourd’hui)
    priority = models.IntegerField(default=0)

    # Type de sortie visé (parent / preferred / alternative)
    OUTPUT_CHOICES = [
        ('parent', 'Parent (dominant)'),
        ('preferred', 'Préféré'),
        ('alternative', 'Alternatif'),
    ]
    output_type = models.CharField(
        max_length=20,
        choices=OUTPUT_CHOICES,
        default='parent',
        help_text="Définit le type de profil ciblé si cette condition est satisfaite"
    )

    def __str__(self):
        return f"{self.profile_a} {self.comparison} {self.profile_b}"


class Prospect(models.Model):

    GENDER_TYPE_CHOICES = [
        ('MEN', 'Homme'),
        ('WOMEN', 'Femme'),
        ('OTHER', 'Autre'),
        ('NOT_PRECISED', 'Non précisé'),
        ('GENDER', 'Genre'),
    ]
    gender = models.CharField(
        default='GENDER',
        verbose_name='Genre',
        choices=GENDER_TYPE_CHOICES,
    )

    firstname = models.CharField(
        max_length=200,
        verbose_name='Prénom',

    )

    lastname = models.CharField(
        max_length=200,
        verbose_name='Nom'
    )

    date_created = models.DateTimeField(
        auto_now_add=True,
        blank=True,
    )

    email = models.EmailField(
        max_length=200,
        verbose_name="Email",
    )

    phone = models.CharField(
        max_length=20,
        verbose_name='Téléphone',
    )

    last_test_date = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Date du dernier test passé",
    )

    slug = models.SlugField(max_length=100, unique=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(f"{self.firstname}-{self.lastname}")
            self.slug = self._generate_unique_slug(base)
        super().save(*args, **kwargs)

    def _generate_unique_slug(self, base, size=6):
        chars = string.ascii_lowercase + string.digits
        while True:
            suffix = ''.join(random.choices(chars, k=size))
            new_slug = f"{base}-{suffix}"
            if not Prospect.objects.filter(slug=new_slug).exists():
                return new_slug



class ExpertTestData(models.Model):
    data = models.JSONField(
        null=True,
        blank=True,
        verbose_name="Données brutes du test",
        help_text="Contient les réponses, scores, profils, etc."
    )

    prospect = models.ForeignKey(
        Prospect,
        blank=True,
        null=True,
        on_delete=models.CASCADE,
        related_name="test_datas",
        help_text="Le prospect ayant passé le test (si non connecté)."
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
        related_name="expert_test_datas",
        help_text="Utilisateur connecté (si applicable)."
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Date de création"
    )

    test = models.ForeignKey(
        'ExpertTest',
        on_delete=models.CASCADE,
        related_name="datas",
        verbose_name="Test associé"
    )

    result_profile = models.ForeignKey(
        'ExpertProfileType',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="result_test_datas",
        help_text="Profil principal déterminé par le test"
    )

    preferred_profile = models.ForeignKey(
        'ExpertProfileType',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="preferred_test_datas",
        help_text="Profil préféré (si déterminé par une combinaison)"
    )

    alternative_profile = models.ForeignKey(
        'ExpertProfileType',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="alternative_test_datas",
        help_text="Profil alternatif (si applicable)"
    )

    def __str__(self):
        return f"Résultat {self.test.title} - {self.prospect or 'Anonyme'} ({self.created_at.date()})"

    def _update_prospect_last_test_date(self):
        """
        Met à jour prospect.last_test_date avec le created_at
        du dernier ExpertTestData lié à ce prospect.
        """
        if not self.prospect_id:
            return

        last = (
            self.prospect.test_datas
                .order_by('-created_at')
                .values_list('created_at', flat=True)
                .first()
        )

        self.prospect.last_test_date = last
        self.prospect.save(update_fields=['last_test_date'])

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        self._update_prospect_last_test_date()

    def delete(self, *args, **kwargs):
        prospect = self.prospect  # garder une ref avant delete
        super().delete(*args, **kwargs)
        if prospect:
            last = (
                prospect.test_datas
                    .order_by('-created_at')
                    .values_list('created_at', flat=True)
                    .first()
            )
            prospect.last_test_date = last
            prospect.save(update_fields=['last_test_date'])

