from django.core import signing
from django.db import models
from django.utils.text import slugify
from jeiko.administration_pages.models import Page
from django.conf import settings
import uuid
import string
import random
import re
from django.core.validators import MaxValueValidator, MinValueValidator, RegexValidator
from copy import deepcopy
from decimal import Decimal
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

from jeiko.questionnaires_expert import coordonnees


class ExpertTest(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    is_restricted = models.BooleanField(default=False, verbose_name=_("Accès restreint"))

    main_image = models.ForeignKey(
        'administration_pages.ImageContent',
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name='related_questionnaire',
        verbose_name=_('Image Principale')
    )

    presentation_page = models.ForeignKey(
        'administration_pages.Page',
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='questionnaires_presentation_page',
        verbose_name=_('Page de présentation')
    )

    intro_warning = models.TextField(
        blank=True, default="",
        verbose_name=_("Mention de précaution"),
        help_text=_("Affichée telle quelle avant la première question, sous la description."),
    )

    # Ce que la fin du questionnaire demande en plus du nom et de l'adresse :
    # téléphone, société, fonction. Voir `coordonnees.py`.
    champs_demandes = models.JSONField(
        default=coordonnees.par_defaut, blank=True, validators=[coordonnees.valider],
        verbose_name=_("Coordonnées demandées"),
    )

    # NEWS-01 — les deux cases facultatives de la fin : la newsletter, et
    # l'accord d'être recontacté. Vide : le réglage du site (CRM › Newsletter ›
    # Réglages) ; « oui » / « non » priment.
    CASE_CHOIX = [("", _("Comme le réglage du site")), ("oui", _("Proposée")), ("non", _("Non proposée"))]
    case_newsletter = models.CharField(_("Case « recevoir la newsletter »"), max_length=3, blank=True,
                                       default="", choices=CASE_CHOIX)
    liste_newsletter = models.ForeignKey(
        "emailing.Liste", on_delete=models.SET_NULL, null=True, blank=True, related_name="+",
        verbose_name=_("Liste de la newsletter"), help_text=_("Vide : la liste par défaut."),
    )
    case_recontact = models.CharField(_("Case « accepte d'être recontacté »"), max_length=3, blank=True,
                                      default="", choices=CASE_CHOIX)
    texte_recontact = models.CharField(
        _("Texte de la case « accepte d'être recontacté »"), max_length=300, blank=True,
        help_text=_("Vide : le texte du site (CRM › Newsletter › Réglages)."),
    )

    def texte_de_la_case_recontact(self):
        """Le texte de ce questionnaire, sinon celui du site, sinon le texte d'origine."""
        if self.texte_recontact.strip():
            return self.texte_recontact.strip()
        from jeiko.emailing.models import ReglagesNewsletter

        du_site = ReglagesNewsletter.du_site().questionnaire_texte_recontact.strip()
        return du_site or _("J'autorise à être recontacté(e) au sujet de mes résultats.")

    # La relance par e-mail, quelques jours après le passage : elle renvoie à
    # la personne ses résultats (modèle « Relance après le questionnaire »,
    # Réglages › E-mails). Vide : pas de relance. Par défaut, seulement à qui
    # a accepté d'être recontacté — relancer est une autre finalité que
    # répondre ; « tous » est un choix de l'exploitant, pas du logiciel.
    RELANCE_RECONTACT = "recontact"
    RELANCE_TOUS = "tous"
    RELANCE_CHOIX = [
        (RELANCE_RECONTACT, _("Seulement les personnes qui ont accepté d'être recontactées")),
        (RELANCE_TOUS, _("Toutes les personnes qui ont laissé leur adresse")),
    ]
    relance_apres_jours = models.PositiveSmallIntegerField(
        _("Relancer par e-mail après (jours)"), null=True, blank=True,
        validators=[MinValueValidator(1), MaxValueValidator(365)],
        help_text=_("Vide : pas de relance. L'e-mail « Relance après le questionnaire » "
                    "(Réglages › E-mails) renvoie ses résultats à la personne, une seule fois."),
    )
    relance_destinataires = models.CharField(
        _("Relance envoyée à"), max_length=10, choices=RELANCE_CHOIX, default=RELANCE_RECONTACT,
    )

    def propose(self, case):
        """`case` : "newsletter" ou "recontact". Le réglage du questionnaire, sinon celui du site."""
        valeur = getattr(self, f"case_{case}")
        if valeur:
            return valeur == "oui"
        from jeiko.emailing.models import ReglagesNewsletter

        reglages = ReglagesNewsletter.du_site()
        return reglages.questionnaire_case_email if case == "newsletter" else reglages.questionnaire_case_telephone

    # --- Résultat par dimensions -------------------------------------------
    # Le mode historique désigne UN profil gagnant et renvoie vers sa page.
    # Le mode « dimensions » montre CHAQUE profil simple, avec le contenu de la
    # tranche où tombe son propre score. Les deux coexistent : le mode par
    # défaut reste l'historique, et rien ne change pour les tests existants.
    RESULT_MODE_PROFILE = "profil"
    RESULT_MODE_DIMENSIONS = "dimensions"
    RESULT_MODE_CHOICES = [
        (RESULT_MODE_PROFILE, _("Un profil gagnant (page de résultat du profil)")),
        (RESULT_MODE_DIMENSIONS, _("Par dimensions (chaque profil selon son score)")),
    ]
    result_mode = models.CharField(
        max_length=20, choices=RESULT_MODE_CHOICES, default=RESULT_MODE_PROFILE,
        verbose_name=_("Présentation du résultat"),
    )
    dimension_scale_min = models.FloatField(
        default=0, verbose_name=_("Score minimal d'une dimension"),
    )
    dimension_scale_max = models.FloatField(
        default=18, verbose_name=_("Score maximal d'une dimension"),
    )
    nuanced_text = models.TextField(
        blank=True, default="", verbose_name=_("Texte « profil nuancé »"),
        help_text=_("Affiché quand toutes les dimensions tombent dans leur tranche du milieu."),
    )
    closing_text = models.TextField(
        blank=True, default="", verbose_name=_("Texte de fin"),
        help_text=_("Affiché en bas de la page de résultat, avant le bouton."),
    )
    cta_label = models.CharField(
        max_length=120, blank=True, default="", verbose_name=_("Texte du bouton"),
    )
    cta_page = models.ForeignKey(
        'administration_pages.Page',
        on_delete=models.SET_NULL, blank=True, null=True,
        related_name='questionnaires_cta_page',
        verbose_name=_("Page vers laquelle mène le bouton"),
    )

    # D-12 : le résultat en PDF, téléchargeable depuis la page de résultat et
    # par un lien dans l'e-mail. Éteint par défaut : une page de résultat
    # existante ne se voit pas ajouter un bouton qu'on n'a pas demandé.
    pdf_des_resultats = models.BooleanField(
        default=False, verbose_name=_("Proposer les résultats en PDF"),
        help_text=_("Un bouton « Télécharger mes résultats (PDF) » sous le résultat, et la variable [%lien_resultats_pdf%] pour l'e-mail."),
    )

    @property
    def uses_dimensions(self):
        return self.result_mode == self.RESULT_MODE_DIMENSIONS

    @property
    def variables_de_style(self):
        """
        Les variables `--q-…` des pages de questions. Le style ne se crée qu'à
        la première ouverture de « Gestion du style » : un questionnaire jamais
        stylé (créé par un agent, par exemple) n'avait AUCUNE variable — bouton
        « Question suivante » en blanc sur rien, réponse choisie invisible.
        Il prend désormais le style par défaut, sans rien écrire en base.
        """
        try:
            style = self.style_config
        except ExpertTestStyle.DoesNotExist:
            style = ExpertTestStyle(test=self)
        return style.get_css_vars()

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        # Le début du parcours public — même adresse que les boutons et les
        # e-mails d'invitation. Sans elle, une carte de questionnaire dans une
        # grille ou un carrousel n'avait aucun lien (Q-22).
        return f"/pass-test/{self.slug}/question/0/"

    @property
    def excerpt(self):
        return self.description


class UserTestAccess(models.Model):
    ACCESS_SOURCE_CHOICES = [
        ('PURCHASE', _('Achat')),
        ('ADMIN', _('Administrateur')),
        ('FREE', _('Gratuit / Offert')),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="test_accesses"
    )
    test = models.ForeignKey(
        ExpertTest,
        on_delete=models.CASCADE,
        related_name="user_accesses"
    )
    source = models.CharField(
        max_length=20,
        choices=ACCESS_SOURCE_CHOICES,
        default='ADMIN'
    )
    granted_at = models.DateTimeField(auto_now_add=True)
    granted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="granted_test_accesses",
        help_text=_("L'administrateur qui a donné l'accès (si applicable)")
    )

    class Meta:
        unique_together = ('user', 'test')
        verbose_name = _("Accès au test")
        verbose_name_plural = _("Accès aux tests")

    def __str__(self):
        return f"{self.user} -> {self.test} ({self.get_source_display()})"



ALLOWED_TEST_STYLE_SCHEMA = {
    # global
    "font_family": str,

    # titre
    "title_color": str,
    "title_size_mobile_px": int,
    "title_size_tablet_px": int,
    "title_size_desktop_px": int,

    # inputs/select/submit (tailles + couleur thème)
    "input_font_size_mobile_px": int,
    "input_font_size_tablet_px": int,
    "input_font_size_desktop_px": int,
    "submit_font_size_px": int,
    "theme_color": str,   # appliqué à: hover/select answer + bouton submit

    # fond global
    "body_bg": str,

    # petits bonus utiles
    "answer_radius_px": int,
    "submit_radius_px": int,
}

DEFAULT_TEST_STYLE = {
    "font_family": "Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif",

    "title_color": "#111111",
    "title_size_mobile_px": 22,
    "title_size_tablet_px": 26,
    "title_size_desktop_px": 30,

    "input_font_size_mobile_px": 18,
    "input_font_size_tablet_px": 18,
    "input_font_size_desktop_px": 20,
    "submit_font_size_px": 20,

    # ton orange par défaut
    "theme_color": "#FF4E0F",

    "body_bg": "#ffffff",

    "answer_radius_px": 20,
    "submit_radius_px": 20,
}

def default_test_style():
    return deepcopy(DEFAULT_TEST_STYLE)

def _coerce_int(d, key):
    if key in d and not isinstance(d[key], int):
        try:
            d[key] = int(d[key])
        except Exception:
            raise ValidationError(_("%(key)s doit être un entier.") % {"key": key})


def _coerce_float(d, key):
    if key in d and not isinstance(d[key], (int, float, Decimal)):
        try:
            d[key] = float(d[key])
        except Exception:
            raise ValidationError(_("%(key)s doit être un nombre.") % {"key": key})


def _hex_to_rgb(hex_str):
    s = hex_str.strip()
    if s.startswith("#"):
        s = s[1:]
    if len(s) == 3:
        s = "".join(ch*2 for ch in s)
    if len(s) != 6:
        raise ValueError("Couleur hex invalide")
    r = int(s[0:2], 16)
    g = int(s[2:4], 16)
    b = int(s[4:6], 16)
    return (r, g, b)


def _rgba_str(hex_str, alpha):
    r, g, b = _hex_to_rgb(hex_str)
    a = max(0.0, min(1.0, float(alpha)))
    return f"rgba({r},{g},{b},{a})"


def _lighten(hex_str, factor=0.18):
    """Éclaircit la couleur (0..1) -> hex."""
    r, g, b = _hex_to_rgb(hex_str)
    def L(c):
        return int(c + (255 - c) * factor)
    return "#{:02X}{:02X}{:02X}".format(L(r), L(g), L(b))


HEX_COLOR_RE = re.compile(r"^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


def validate_test_style(value):
    if not isinstance(value, dict):
        raise ValidationError(_("Le style doit être un objet JSON."))

    # Coercions simples
    ints = [
        "title_size_mobile_px", "title_size_tablet_px", "title_size_desktop_px",
        "input_font_size_mobile_px", "input_font_size_tablet_px", "input_font_size_desktop_px",
        "submit_font_size_px",
        "answer_radius_px", "submit_radius_px",
    ]
    for k in ints:
        _coerce_int(value, k)

    # Bornes raisonnables
    def in_range(k, lo, hi):
        if k in value and not (lo <= int(value[k]) <= hi):
            raise ValidationError(_("%(k)s doit être entre %(lo)s et %(hi)s. (valeur: %(k2)s)") % {"k": k, "lo": lo, "hi": hi, "k2": value[k]})

    for k in ["title_size_mobile_px", "title_size_tablet_px", "title_size_desktop_px"]:
        in_range(k, 12, 64)
    for k in ["input_font_size_mobile_px", "input_font_size_tablet_px", "input_font_size_desktop_px", "submit_font_size_px"]:
        in_range(k, 12, 40)
    for k in ["answer_radius_px", "submit_radius_px"]:
        in_range(k, 0, 40)

    # Validation simple couleurs: commence par # et 3/6 hexdigits
    for k in ["title_color", "theme_color", "body_bg"]:
        if k in value and not HEX_COLOR_RE.match(str(value[k]).strip()):
            raise ValidationError(_("%(k)s doit être un hex valide, ex: #FF4E0F") % {"k": k})


class ExpertTestStyle(models.Model):
    test = models.OneToOneField(ExpertTest, on_delete=models.CASCADE, related_name="style_config")
    style = models.JSONField(default=default_test_style, validators=[validate_test_style])
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Style · {self.test.title}"

    def get_css_vars(self) -> dict:
        """
        Transforme le JSON en variables CSS prêtes à injecter dans le template.
        Pré-calcule une couleur 'hover' plus claire et une variante rgba.
        """
        s = {**DEFAULT_TEST_STYLE, **(self.style or {})}
        theme = s["theme_color"]
        return {
            "--q-font-family": s["font_family"],

            "--q-title-color": s["title_color"],
            "--q-title-size-mobile": f"{s['title_size_mobile_px']}px",
            "--q-title-size-tablet": f"{s['title_size_tablet_px']}px",
            "--q-title-size-desktop": f"{s['title_size_desktop_px']}px",

            "--q-input-size-mobile": f"{s['input_font_size_mobile_px']}px",
            "--q-input-size-tablet": f"{s['input_font_size_tablet_px']}px",
            "--q-input-size-desktop": f"{s['input_font_size_desktop_px']}px",
            "--q-submit-size": f"{s['submit_font_size_px']}px",

            "--q-theme": theme,
            "--q-theme-hover": _lighten(theme, 0.18),
            "--q-theme-rgba-40": _rgba_str(theme, 0.40),

            "--q-body-bg": s["body_bg"],

            "--q-answer-radius": f"{s['answer_radius_px']}px",
            "--q-submit-radius": f"{s['submit_radius_px']}px",
        }


class ExpertProfileType(models.Model):

    test = models.ForeignKey(ExpertTest, on_delete=models.CASCADE, related_name="profiles")
    name = models.CharField(
        max_length=100
    )

    description = models.TextField(
        blank=True
    )
    result_page = models.ForeignKey(
        Page,
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    slug = models.SlugField(
        max_length=100,
        unique=True,
        blank=True
    )
    is_complex = models.BooleanField(
        default=False,
        help_text=_("Profil majeur/complexe ou simple")
    )
    is_score_profile = models.BooleanField(
        default=False,
        help_text=_("Ce profil peut être assigné automatiquement en fonction d'un score global.")
    )
    min_score = models.FloatField(
        null=True, blank=True,
        help_text=_("Score minimum (inclus) pour attribuer ce profil. Laisser vide si non applicable.")
    )
    max_score = models.FloatField(
        null=True, blank=True,
        help_text=_("Score maximum (exclus) pour attribuer ce profil. Laisser vide si non applicable.")
    )
    score_axis = models.CharField(
        max_length=100, blank=True,
        help_text=_("Réservé : le moteur n'utilise pour l'instant que le score global.")
    )
    # Relation many-to-many récursive pour parents (et donc enfants en reverse)
    parent_profiles = models.ManyToManyField(
        'self',
        symmetrical=False,
        related_name='child_profiles',
        blank=True,
        help_text=_("Profils parents de ce profil (relation many-to-many récursive)")
    )

    color = models.CharField(
        max_length=7,
        blank=True,
        default="#cccccc",
        validators=[
            RegexValidator(
                regex=r"^#(?:[0-9a-fA-F]{3}){1,2}$",
                message=_("Entrez une couleur hexadécimale valide, ex : #3A4BC7")
            )
        ],
        help_text=_("Couleur associée au profil (ex : #FF0000).")
    )

    # Mode « dimensions » : l'ordre fixe d'affichage et le nom des deux bouts
    # de la barre. Sans effet dans le mode historique.
    order = models.PositiveIntegerField(default=0, verbose_name=_("Rang d'affichage"))
    low_pole_label = models.CharField(
        max_length=120, blank=True, default="", verbose_name=_("Nom du pôle bas"),
    )
    high_pole_label = models.CharField(
        max_length=120, blank=True, default="", verbose_name=_("Nom du pôle haut"),
    )

    def save(self, *args, **kwargs):
        if not self.slug and self.name:
            base = slugify(self.name)
            suffix = str(uuid.uuid4())[:8]  # 8 caractères pour limiter la longueur
            self.slug = f"{base}-{suffix}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class ExpertDimensionBand(models.Model):
    """
    Une tranche de score d'une dimension, et ce qu'on dit à qui y tombe.

    Trois tranches au plus par dimension, une par position — bas, milieu,
    haut. Le nombre est FIXE à dessein : c'est ce qui rend l'écran d'édition
    et l'API lisibles sans leçon préalable. Une position laissée vide n'a
    simplement pas de contenu.

    Les bornes sont INCLUSIVES des deux côtés : « 0 à 6 », « 7 à 11 »,
    « 12 à 18 » s'écrivent comme on les dit. Un score qui ne tombe dans
    aucune tranche garde sa barre, sans texte.
    """

    LOW, MIDDLE, HIGH = "bas", "milieu", "haut"
    POSITION_CHOICES = [
        (LOW, _("Pôle bas")),
        (MIDDLE, _("Entre les deux")),
        (HIGH, _("Pôle haut")),
    ]

    profile = models.ForeignKey(
        ExpertProfileType, on_delete=models.CASCADE, related_name="bands",
    )
    position = models.CharField(max_length=10, choices=POSITION_CHOICES)
    min_score = models.FloatField(verbose_name=_("De"))
    max_score = models.FloatField(verbose_name=_("À (inclus)"))
    title = models.CharField(max_length=200, blank=True, default="", verbose_name=_("Titre"))
    text = models.TextField(blank=True, default="", verbose_name=_("Texte"))
    strengths = models.TextField(
        blank=True, default="", verbose_name=_("Forces"),
        help_text=_("Une force par ligne."),
    )
    watch_point = models.TextField(blank=True, default="", verbose_name=_("Point de vigilance"))
    reflection = models.TextField(blank=True, default="", verbose_name=_("Piste de réflexion"))

    class Meta:
        ordering = ["min_score", "id"]
        constraints = [
            models.UniqueConstraint(
                fields=["profile", "position"], name="qe_une_tranche_par_position",
            ),
        ]

    def strengths_list(self):
        return [ligne.strip() for ligne in self.strengths.splitlines() if ligne.strip()]

    def contains(self, score):
        return self.min_score <= score <= self.max_score

    def __str__(self):
        return f"{self.profile.name} · {self.get_position_display()}"


class ExpertQuestion(models.Model):
    test = models.ForeignKey(ExpertTest, on_delete=models.CASCADE, related_name='questions')
    text = models.TextField()
    order = models.PositiveIntegerField(default=0)
    question_type = models.CharField(
        max_length=50,
        choices=[('single', _('Choix unique')), ('multiple', _('Choix multiple'))],
        default='single'
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name=_("Question active"),
        help_text=_("Une question inactive reste éditable mais n'est plus posée aux visiteurs.")
    )
    extra_config = models.JSONField(blank=True, null=True)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.text

    @property
    def active_answers(self):
        return self.answers.filter(is_active=True)


class ExpertAnswer(models.Model):
    question = models.ForeignKey(ExpertQuestion, on_delete=models.CASCADE, related_name='answers')
    text = models.CharField(max_length=300)
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.text


class ExpertAnswerProfileWeight(models.Model):
    answer = models.ForeignKey(
        ExpertAnswer,
        on_delete=models.CASCADE,
        related_name='profile_weights',

    )
    profile_type = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    weight = models.FloatField(default=1.0)

    class Meta:
        unique_together = ('answer', 'profile_type')

    def __str__(self):
        # `profile_type` est nullable : un poids enregistré sans profil existe,
        # et son affichage ne doit pas faire tomber l'écran qui le liste.
        profil = self.profile_type.name if self.profile_type_id else "sans profil"
        return f"{self.answer.text} → {profil} (poids {self.weight})"


class ExpertProfileCombination(models.Model):
    test = models.ForeignKey(ExpertTest, on_delete=models.CASCADE, related_name="combinations")

    parent_profile = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        related_name='parent_combinations',

    )
    preferred_profile = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        related_name='preferred_combinations',

        blank=True, null=True
    )
    alternative_profile = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        related_name='alternative_combinations',

        blank=True, null=True
    )
    slug = models.SlugField(max_length=150, blank=True, unique=True)
    title = models.CharField(max_length=150, blank=True)

    class Meta:
        # L'évaluation s'arrête à la première combinaison satisfaite : sans ordre
        # explicite, le profil retourné dépendrait de l'ordre du SGBD.
        ordering = ['id']

    def save(self, *args, **kwargs):
        if not self.slug:
            suffix = str(uuid.uuid4())[:8]  # 8 caractères pour limiter la longueur
            base = slugify(self.title) if self.title else "combinaison"
            self.slug = f"{base}-{suffix}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title or f"Combinaison {self.id} pour {self.test.title}"



class ExpertProfileCriterion(models.Model):
    combination = models.ForeignKey(
        'ExpertProfileCombination',
        on_delete=models.CASCADE,
        related_name='criteria'
    )

    profile_a = models.ForeignKey(
        'ExpertProfileType',
        on_delete=models.CASCADE,
        related_name='criteria_as_a'
    )
    profile_b = models.ForeignKey(
        'ExpertProfileType',
        on_delete=models.CASCADE,
        related_name='criteria_as_b'
    )

    # Comparateur : >, <, >=, <=, ==, ~= (proche)
    COMPARISON_CHOICES = [
        ('>', _('Supérieur à')),
        ('<', _('Inférieur à')),
        ('>=', _('Supérieur ou égal à')),
        ('<=', _('Inférieur ou égal à')),
        ('==', _('Égal à')),
        ('~=', _('Proche de')),  # différence absolue <= tolerance
    ]
    comparison = models.CharField(
        max_length=4,
        choices=COMPARISON_CHOICES,
        default='>',
    )

    # Écart minimal toléré pour que la condition soit vraie (optionnel)
    tolerance = models.IntegerField(
        null=True,
        blank=True,
        help_text=_("Valeur utilisée uniquement pour '~=' (proximité)")
    )

    # Priorité dans l’évaluation (comme aujourd’hui)
    priority = models.IntegerField(default=0)

    # Type de sortie visé (parent / preferred / alternative)
    OUTPUT_CHOICES = [
        ('parent', _('Parent (dominant)')),
        ('preferred', _('Préféré')),
        ('alternative', _('Alternatif')),
    ]
    output_type = models.CharField(
        max_length=20,
        choices=OUTPUT_CHOICES,
        default='parent',
        help_text=_("Non utilisé : les profils résultants sont ceux de la combinaison.")
    )

    def evaluate(self, scores):
        """
        Évalue le critère sur un dict {profile_type_id: score}.
        Un profil absent du dict vaut 0.
        """
        a = scores.get(self.profile_a_id, 0)
        b = scores.get(self.profile_b_id, 0)

        if self.comparison == '>':
            return a > b
        if self.comparison == '<':
            return a < b
        if self.comparison == '>=':
            return a >= b
        if self.comparison == '<=':
            return a <= b
        if self.comparison == '==':
            return a == b
        if self.comparison == '~=':
            return abs(a - b) <= (self.tolerance or 0)
        return False

    def __str__(self):
        return f"{self.profile_a} {self.comparison} {self.profile_b}"


class Company(models.Model):
    """
    Une entreprise du CRM (CRM-06) : ses coordonnées, et les personnes qui y
    travaillent — plusieurs contacts peuvent s'y rattacher.

    Le texte « Société » d'un contact reste : c'est ce qu'écrit un visiteur
    dans un formulaire. Rattaché à une entreprise, il en reprend le nom.
    """

    name = models.CharField(_("Nom"), max_length=200, db_index=True)
    website = models.URLField(_("Site web"), blank=True)
    email = models.EmailField(_("E-mail"), blank=True)
    phone = models.CharField(_("Téléphone"), max_length=30, blank=True)
    address = models.TextField(_("Adresse"), blank=True)
    postal_code = models.CharField(_("Code postal"), max_length=20, blank=True)
    city = models.CharField(_("Ville"), max_length=120, blank=True)
    country = models.CharField(_("Pays"), max_length=2, blank=True, help_text=_("Code ISO : FR, BE…"))
    siret = models.CharField(_("SIRET"), max_length=20, blank=True)
    notes = models.TextField(_("Notes"), blank=True)
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="entreprises_suivies", verbose_name=_("Responsable"),
    )
    created_at = models.DateTimeField(_("Créée le"), auto_now_add=True)
    updated_at = models.DateTimeField(_("Modifiée le"), auto_now=True)

    class Meta:
        verbose_name = _("Entreprise")
        verbose_name_plural = _("Entreprises")
        ordering = ["name", "id"]

    def __str__(self):
        return self.name


class Prospect(models.Model):
    """
    La fiche d'une personne : le CONTACT du CRM (PLAN_ACTION, CRM-01 à CRM-10).

    Née avec les questionnaires, elle en garde le module : les rôles de JEIKO
    pointent sur des permissions Django rattachées à `questionnaires_expert`,
    et déplacer le modèle ferait perdre « voir les prospects », sans bruit, à
    tous les rôles de tous les sites. Le CRM la présente sous le nom de
    « contact » (`jeiko/crm/`) ; le code garde son nom.

    Ce qu'elle porte : l'identité saisie et le suivi commercial. Ce qu'elle ne
    recopie PAS : l'historique — rendez-vous, envois de formulaire,
    questionnaires, commandes, e-mails —, que `jeiko.crm.historique` lit dans
    les modules qui le détiennent, par l'adresse e-mail et le compte lié.
    """

    class Statut(models.TextChoices):
        PROSPECT = "prospect", _("Prospect")
        CLIENT = "client", _("Client")
        ANCIEN = "ancien", _("Ancien client")

    class Origine(models.TextChoices):
        QUESTIONNAIRE = "questionnaire", _("Questionnaire")
        RENDEZ_VOUS = "rendez_vous", _("Rendez-vous")
        FORMULAIRE = "formulaire", _("Formulaire de contact")
        IMPORT = "import", _("Import")
        MANUEL = "manuel", _("Saisie manuelle")
        NEWSLETTER = "newsletter", _("Newsletter")
        VISIO = "visio", _("Visio")

    GENDER_TYPE_CHOICES = [
        ('MEN', _('Homme')),
        ('WOMEN', _('Femme')),
        ('OTHER', _('Autre')),
        ('NOT_PRECISED', _('Non précisé')),
        ('GENDER', _('Genre')),
    ]
    gender = models.CharField(
        default='GENDER',
        verbose_name=_('Genre'),
        choices=GENDER_TYPE_CHOICES,
    )

    # Facultatifs : une fiche née d'une réservation ou d'un formulaire n'a
    # souvent qu'un nom d'un seul tenant, et presque jamais de téléphone.
    firstname = models.CharField(
        max_length=200,
        blank=True,
        verbose_name=_('Prénom'),

    )

    lastname = models.CharField(
        max_length=200,
        blank=True,
        verbose_name=_('Nom')
    )

    date_created = models.DateTimeField(
        auto_now_add=True,
        blank=True,
    )

    email = models.EmailField(
        max_length=200,
        blank=True,
        verbose_name=_("Email"),
    )

    phone = models.CharField(
        max_length=20,
        blank=True,
        verbose_name=_('Téléphone'),
    )

    # --- Le suivi (CRM) ---
    company = models.CharField(_("Société"), max_length=200, blank=True)
    entreprise = models.ForeignKey(
        "Company", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="contacts", verbose_name=_("Entreprise"),
    )
    job_title = models.CharField(_("Fonction"), max_length=200, blank=True)
    status = models.CharField(
        _("Statut"), max_length=16, choices=Statut.choices, default=Statut.PROSPECT, db_index=True,
    )
    # Les fiches d'avant le CRM sont toutes nées d'un questionnaire.
    origin = models.CharField(
        _("Origine"), max_length=16, choices=Origine.choices, default=Origine.QUESTIONNAIRE,
    )
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="contacts_suivis", verbose_name=_("Responsable"),
    )
    tags = models.JSONField(_("Étiquettes"), default=list, blank=True)
    # UNE prochaine action, pas un gestionnaire de tâches : la date et la
    # phrase suffisent à faire la liste « à relancer aujourd'hui », ce qu'un
    # indépendant regarde le matin (PLAN_ACTION, propositions CRM, point 5).
    next_action_on = models.DateField(_("Prochaine action le"), null=True, blank=True, db_index=True)
    next_action = models.CharField(_("Prochaine action"), max_length=200, blank=True)
    # Depuis le 04/10/2026, la prochaine action est la tâche ouverte la plus
    # proche (`ContactTask`) : ces deux champs en sont le reflet, recalculé
    # par `jeiko.crm.taches`, et restent lus par « À relancer », le CSV et
    # l'API. Le rappel par e-mail s'active fiche par fiche (demande de
    # Guillaume) : le jour venu, le responsable de la tâche le reçoit.
    # NEWS-01 — l'accord d'être recontacté, donné en fin de questionnaire :
    # quand, et la preuve (texte affiché, questionnaire). Visible sur la fiche.
    recontact_accepte_le = models.DateTimeField(_("Accepte d'être recontacté depuis le"), null=True, blank=True)
    recontact_preuve = models.CharField(_("Preuve de l'accord de recontact"), max_length=500, blank=True)
    task_reminders = models.BooleanField(
        _("Rappel des tâches par e-mail"), default=False,
        help_text=_("Le jour où une tâche arrive à échéance, son responsable reçoit un e-mail."),
    )
    updated_at = models.DateTimeField(_("Modifié le"), auto_now=True, null=True)

    last_test_date = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name=_("Date du dernier test passé"),
    )

    email_verified = models.BooleanField(
        default=False,
        verbose_name=_("Email vérifié"),
        help_text=(
            _("Vrai lorsque le destinataire a ouvert le lien de résultat reçu par email. "
            "Une fiche vérifiée ne peut plus être fusionnée par un tiers saisissant la même adresse.")
        )
    )

    slug = models.SlugField(max_length=100, unique=True, blank=True)

    class Meta:
        verbose_name = _("Contact")
        verbose_name_plural = _("Contacts")
        # Propres au CRM, absentes des rôles par défaut (semés une fois, à
        # l'installation) : lire les notes et exporter se donnent à part.
        permissions = [
            ("view_contact_notes", _("Lire les notes des contacts")),
            ("export_contacts", _("Exporter et importer les contacts")),
        ]

    def save(self, *args, **kwargs):
        if not self.slug:
            # Borné : un nom saisi de 150 caractères dépassait le slug (100).
            base = slugify(f"{self.firstname}-{self.lastname}")[:80].strip("-") or "contact"
            self.slug = self._generate_unique_slug(base)
        super().save(*args, **kwargs)

    @property
    def nom_complet(self):
        return " ".join(p for p in (self.firstname, self.lastname) if p).strip() or self.email

    def __str__(self):
        return self.nom_complet

    def _generate_unique_slug(self, base, size=6):
        chars = string.ascii_lowercase + string.digits
        while True:
            suffix = ''.join(random.choices(chars, k=size))
            new_slug = f"{base}-{suffix}"
            if not Prospect.objects.filter(slug=new_slug).exists():
                return new_slug



class ContactTask(models.Model):
    """
    Une tâche de suivi sur un contact : « rappeler pour le devis », « envoyer
    la documentation ». Plusieurs par contact (CRM-07). La plus proche des
    tâches ouvertes fait la « prochaine action » du contact.
    """

    prospect = models.ForeignKey(Prospect, on_delete=models.CASCADE, related_name="tasks",
                                 verbose_name=_("Contact"))
    title = models.CharField(_("Tâche"), max_length=200)
    due_on = models.DateField(_("Échéance"), db_index=True)
    assignee = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="contact_tasks", verbose_name=_("Responsable"),
    )
    done_at = models.DateTimeField(_("Faite le"), null=True, blank=True)
    reminded_on = models.DateField(_("Rappel envoyé le"), null=True, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+", verbose_name=_("Créée par"),
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("Tâche de suivi")
        verbose_name_plural = _("Tâches de suivi")
        ordering = ["due_on", "id"]

    def __str__(self):
        return f"{self.due_on:%d/%m/%Y} — {self.title}"


# Signature du lien de confirmation d'email envoyé avec le résultat.
EMAIL_CONFIRM_SALT = "questionnaires_expert.result_email_confirm"
EMAIL_CONFIRM_MAX_AGE = 60 * 60 * 24 * 90  # 90 jours


class ExpertTestData(models.Model):
    public_token = models.UUIDField(
        default=uuid.uuid4,
        editable=False,
        unique=True,
        verbose_name=_("Jeton public"),
        help_text=_("Identifiant non devinable servant à consulter ce résultat sans être connecté.")
    )

    data = models.JSONField(
        null=True,
        blank=True,
        verbose_name=_("Données brutes du test"),
        help_text=_("Contient les réponses, scores, profils, etc.")
    )

    prospect = models.ForeignKey(
        Prospect,
        blank=True,
        null=True,
        on_delete=models.CASCADE,
        related_name="test_datas",
        help_text=_("Le prospect ayant passé le test (si non connecté).")
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
        related_name="expert_test_datas",
        help_text=_("Utilisateur connecté (si applicable).")
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_("Date de création")
    )

    test = models.ForeignKey(
        'ExpertTest',
        on_delete=models.CASCADE,
        related_name="datas",
        verbose_name=_("Test associé")
    )

    result_profile = models.ForeignKey(
        'ExpertProfileType',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="result_test_datas",
        help_text=_("Profil principal déterminé par le test")
    )

    preferred_profile = models.ForeignKey(
        'ExpertProfileType',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="preferred_test_datas",
        help_text=_("Profil préféré (si déterminé par une combinaison)")
    )

    alternative_profile = models.ForeignKey(
        'ExpertProfileType',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="alternative_test_datas",
        help_text=_("Profil alternatif (si applicable)")
    )

    # Une seule relance par résultat : posée quand l'e-mail est parti.
    relance_envoyee_le = models.DateTimeField(_("Relance envoyée le"), null=True, blank=True)

    def __str__(self):
        return f"Résultat {self.test.title} - {self.prospect or 'Anonyme'} ({self.created_at.date()})"

    def make_confirmation_token(self):
        """
        Jeton signé placé UNIQUEMENT dans le lien envoyé par email.

        La redirection qui suit la soumission du questionnaire ne le porte pas :
        c'est ce qui permet de distinguer « le visiteur consulte son résultat »
        de « le titulaire de l'adresse a bien reçu le message », et donc de
        vérifier l'email sans imposer une étape supplémentaire.
        """
        return signing.dumps({"td": self.pk}, salt=EMAIL_CONFIRM_SALT)

    def check_confirmation_token(self, value, max_age=EMAIL_CONFIRM_MAX_AGE):
        try:
            payload = signing.loads(value, salt=EMAIL_CONFIRM_SALT, max_age=max_age)
        except (signing.BadSignature, signing.SignatureExpired):
            return False
        return payload.get("td") == self.pk

    def get_result_url(self, confirm=False):
        """URL (relative) de la page de résultat personnelle, portée par le jeton."""
        from django.urls import reverse
        url = reverse(
            "jeiko_client_questionnaires_expert:test_result_token",
            kwargs={"token": self.public_token},
        )
        if confirm:
            url = f"{url}?c={self.make_confirmation_token()}"
        return url

    def get_result_absolute_url(self, request=None, confirm=False):
        """URL absolue, à utiliser dans les emails."""
        url = self.get_result_url(confirm=confirm)
        return request.build_absolute_uri(url) if request is not None else url

    @property
    def recipient_email(self):
        """Email de la personne ayant passé le test (utilisateur connecté ou prospect)."""
        if self.user and self.user.email:
            return self.user.email
        if self.prospect and self.prospect.email:
            return self.prospect.email
        return None

    @property
    def recipient_name(self):
        if self.user:
            return self.user.get_full_name() or self.user.get_username()
        if self.prospect:
            return f"{self.prospect.firstname} {self.prospect.lastname}".strip()
        return ""


def refresh_prospect_last_test_date(prospect_id):
    """
    Recale Prospect.last_test_date sur le dernier résultat réellement présent.

    Piloté par signaux plutôt que par des overrides de save()/delete() : ces
    derniers étaient contournés par `queryset.delete()` et par la suppression en
    cascade d'un ExpertTest, laissant la date pointer sur un test disparu.
    """
    if not prospect_id:
        return

    last = (
        ExpertTestData.objects
        .filter(prospect_id=prospect_id)
        .order_by('-created_at')
        .values_list('created_at', flat=True)
        .first()
    )
    Prospect.objects.filter(pk=prospect_id).update(last_test_date=last)

