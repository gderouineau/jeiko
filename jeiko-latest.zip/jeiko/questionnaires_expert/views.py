from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.db import models, transaction
from django.db.models import Prefetch
from django.db.models import Max
import re

from django.views.generic import (
    ListView, DetailView, CreateView, UpdateView, DeleteView
)
from django.views import View

from django.contrib.auth import get_user_model
User = get_user_model()

from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy, reverse



from jeiko.questionnaires_expert.models import (
    ExpertTest, ExpertQuestion, ExpertAnswer,
    ExpertProfileType, ExpertProfileCombination,
    ExpertProfileCriterion, ExpertTestData,
    Prospect, ExpertAnswerProfileWeight
)
from jeiko.questionnaires_expert.forms import (
    ExpertAnswerForm, AnswerProfileWeightFormSet, ExpertProfileCombinationForm, ExpertProfileTypeForm
)
from jeiko.users.models import (
    Comments
)
from jeiko.users.forms_admin import CommentsForm





@method_decorator(never_cache, name='dispatch')
class ExpertTestListView(ListView):
    model = ExpertTest
    template_name = "questionnaires_expert/test_list.html"
    context_object_name = "tests"


@method_decorator(never_cache, name='dispatch')
class ExpertTestDetailView(DetailView):
    model = ExpertTest
    template_name = "questionnaires_expert/test_detail.html"
    context_object_name = "test"
    pk_url_kwarg = "test_id"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profiles = self.object.profiles.all()
        context['questions'] = self.object.questions.prefetch_related(
            Prefetch('answers', queryset=ExpertAnswer.objects.prefetch_related('profile_weights__profile_type'))
        ).all()
        context['simple_profiles'] = profiles.filter(is_complex=False, is_score_profile=False)
        context['complex_profiles'] = profiles.filter(is_complex=True, is_score_profile=False)
        context['score_profiles'] = profiles.filter(is_score_profile=True)
        context['profiles'] = profiles
        context['combinations'] = self.object.combinations.prefetch_related(
            'parent_profile', 'preferred_profile', 'alternative_profile'
        ).all()
        return context


@method_decorator(never_cache, name='dispatch')
class ExpertTestCreateView(CreateView):
    model = ExpertTest
    fields = "__all__"
    template_name = "questionnaires_expert/test_form.html"

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.id])


@method_decorator(never_cache, name='dispatch')
class ExpertTestUpdateView(UpdateView):
    model = ExpertTest
    fields = "__all__"
    template_name = "questionnaires_expert/test_form.html"
    pk_url_kwarg = "test_id"

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.id])


@method_decorator(never_cache, name='dispatch')
class ExpertTestDeleteView(DeleteView):
    model = ExpertTest
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "test_id"
    success_url = reverse_lazy("jeiko_administration_questionnaires_expert:test_list")


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionCreateView(CreateView):
    model = ExpertQuestion
    fields = ["text", "question_type", "extra_config"]  # on ne met plus "order" ici
    template_name = "questionnaires_expert/question_form.html"

    def form_valid(self, form):
        test = get_object_or_404(ExpertTest, id=self.kwargs['test_id'])
        form.instance.test = test
        # Calcul du prochain order
        last_order = (
            ExpertQuestion.objects.filter(test=test)
            .aggregate(Max('order'))['order__max']
        )
        form.instance.order = (last_order + 1) if last_order is not None else 0
        return super().form_valid(form)

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionUpdateView(UpdateView):
    model = ExpertQuestion
    fields = ["text"]
    template_name = "questionnaires_expert/question_form.html"
    pk_url_kwarg = "question_id"

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionDeleteView(DeleteView):
    model = ExpertQuestion
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "question_id"

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionMoveUp(View):
    def get(self, request, question_id):
        question = get_object_or_404(ExpertQuestion, id=question_id)
        prev_q = (
            ExpertQuestion.objects
            .filter(test=question.test, order__lt=question.order)
            .order_by('-order')
            .first()
        )
        if prev_q:
            question.order, prev_q.order = prev_q.order, question.order
            question.save()
            prev_q.save()
        return redirect(
            reverse("jeiko_administration_questionnaires_expert:test_detail", args=[question.test.id])
        )


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionMoveDown(View):
    def get(self, request, question_id):
        question = get_object_or_404(ExpertQuestion, id=question_id)
        next_q = (
            ExpertQuestion.objects
            .filter(test=question.test, order__gt=question.order)
            .order_by('order')
            .first()
        )
        if next_q:
            question.order, next_q.order = next_q.order, question.order
            question.save()
            next_q.save()
        return redirect(
            reverse("jeiko_administration_questionnaires_expert:test_detail", args=[question.test.id])
        )


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionDuplicate(View):
    def get(self, request, question_id):
        with transaction.atomic():
            # 0) Question d'origine
            original = get_object_or_404(ExpertQuestion, id=question_id)
            test = original.test
            old_order = original.order

            # 1) Décale les suivantes
            ExpertQuestion.objects.filter(
                test=test,
                order__gt=old_order
            ).update(order=models.F('order') + 1)

            # 2) Clone question (copie simple : pk=None)
            #    Astuce: on recharge l'objet pour éviter de modifier 'original' en mémoire
            q_src = ExpertQuestion.objects.get(pk=question_id)
            q_src.pk = None
            q_src.order = old_order + 1
            q_src.save()  # => q_clone

            # 3) Duplique réponses + poids
            #    On préfetch les poids pour éviter N+1
            answers = (ExpertAnswer.objects
                       .filter(question=original.pk)
                       .prefetch_related('profile_weights'))

            weights_to_create = []
            for ans in answers:
                # --- Cloner la réponse sans lister les champs à la main ---
                # Récupère tous les champs "concrets" (pas O2M/M2M)
                fields = [
                    f for f in ans._meta.get_fields()
                    if getattr(f, 'concrete', False)
                    and not getattr(f, 'many_to_many', False)
                    and not getattr(f, 'one_to_many', False)
                ]
                # Construit un dict {field_name: value} sauf pk/id/question
                payload = {}
                for f in fields:
                    if f.name in ('id', 'pk', 'question'):
                        continue
                    payload[f.name] = getattr(ans, f.name)

                # Force la nouvelle FK question
                payload['question'] = q_src
                ans_clone = ExpertAnswer.objects.create(**payload)

                # --- Cloner les poids par profil ---
                for w in ans.profile_weights.all():
                    weights_to_create.append(
                        ExpertAnswerProfileWeight(
                            answer=ans_clone,
                            profile_type=w.profile_type,
                            weight=w.weight
                        )
                    )

            if weights_to_create:
                # unique_together (answer, profile_type) -> aucun conflit attendu
                ExpertAnswerProfileWeight.objects.bulk_create(weights_to_create)

        return redirect(
            reverse("jeiko_administration_questionnaires_expert:test_detail", args=[test.id])
        )


def _normalize_question_text(s: str) -> str:
    """
    Normalise le texte pour la détection de doublons :
    - trim, lowercase
    - remplace les suites d'espaces (et \n, \t) par un seul espace
    - supprime espaces avant ponctuation courante
    """
    if not s:
        return ""
    s = s.strip().lower()
    s = re.sub(r"\s+", " ", s)  # collapse whitespace
    s = re.sub(r"\s+([?!;:,.])", r"\1", s)  # remove space before punctuation
    return s


@method_decorator(never_cache, name='dispatch')
class ExpertQuestionDedupeView(View):
    """
    POST /jeiko/administration/questionnaires/expert/<test_id>/dedupe/
    - Détecte les doublons de questions (par texte normalisé)
    - Conserve la 1ère occurrence (ordre croissant), supprime les suivantes.
    - Redirige vers test_detail.
    """
    http_method_names = ["get"]

    def get(self, request, test_id):
        test = get_object_or_404(ExpertTest, id=test_id)

        # On ordonne par 'order' puis 'id' pour conserver la première occurrence "la plus ancienne"
        questions = list(
            test.questions.order_by("order", "id").only("id", "text")
        )

        seen = {}
        ids_to_delete = []

        for q in questions:
            key = _normalize_question_text(q.text)
            if key in seen:
                ids_to_delete.append(q.id)
            else:
                seen[key] = q.id

        with transaction.atomic():
            if ids_to_delete:
                # Si pas de CASCADE sur ExpertAnswer, décommenter cette ligne :
                # ExpertAnswer.objects.filter(question_id__in=ids_to_delete).delete()
                ExpertQuestion.objects.filter(id__in=ids_to_delete).delete()

        # Optionnel: message framework si tu l’utilises
        # messages.success(request, f"{len(ids_to_delete)} doublon(s) supprimé(s).")

        return redirect(reverse(
            "jeiko_administration_questionnaires_expert:test_detail",
            args=[test.id]
        ))


@method_decorator(never_cache, name='dispatch')
class ExpertAnswerCreateView(CreateView):
    model = ExpertAnswer
    form_class = ExpertAnswerForm
    template_name = "questionnaires_expert/answer_form.html"

    def dispatch(self, request, *args, **kwargs):
        self.question = get_object_or_404(ExpertQuestion, id=self.kwargs['question_id'])
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        answer = ExpertAnswer(question=self.question)
        if self.request.POST:
            context['formset'] = AnswerProfileWeightFormSet(
                self.request.POST,
                instance=answer,
                form_kwargs={'answer': answer}
            )
        else:
            context['formset'] = AnswerProfileWeightFormSet(
                instance=answer,
                form_kwargs={'answer': answer}
            )
        return context

    def form_valid(self, form):
        form.instance.question = self.question
        # Ajout : calcul du prochain order pour la réponse
        last_order = (
            ExpertAnswer.objects.filter(question=self.question)
            .aggregate(Max('order'))['order__max']
        )
        form.instance.order = (last_order + 1) if last_order is not None else 0

        self.object = form.save()
        formset = AnswerProfileWeightFormSet(
            self.request.POST,
            instance=self.object,
            form_kwargs={'answer': self.object}
        )
        if formset.is_valid():
            formset.save()
            return redirect(self.get_success_url())
        else:
            return self.render_to_response(self.get_context_data(form=form, formset=formset))

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.question.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertAnswerUpdateView(UpdateView):
    model = ExpertAnswer
    form_class = ExpertAnswerForm
    template_name = "questionnaires_expert/answer_form.html"
    pk_url_kwarg = "answer_id"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.POST:
            context['formset'] = AnswerProfileWeightFormSet(
                self.request.POST,
                instance=self.object,
                form_kwargs={'answer': self.object}
            )
        else:
            context['formset'] = AnswerProfileWeightFormSet(
                instance=self.object,
                form_kwargs={'answer': self.object}
            )
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        formset = context['formset']
        if formset.is_valid():
            self.object = form.save()
            formset.instance = self.object
            formset.save()
            return redirect(self.get_success_url())
        return self.render_to_response(self.get_context_data(form=form))

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.question.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertAnswerDeleteView(DeleteView):
    model = ExpertAnswer
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "answer_id"

    def get_success_url(self):
        return reverse("jeiko_administration_questionnaires_expert:test_detail", args=[self.object.question.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertAnswerMoveUp(View):
    def get(self, request, answer_id):
        answer = get_object_or_404(ExpertAnswer, id=answer_id)
        prev_a = (
            ExpertAnswer.objects
            .filter(question=answer.question, order__lt=answer.order)
            .order_by('-order')
            .first()
        )
        if prev_a:
            answer.order, prev_a.order = prev_a.order, answer.order
            answer.save()
            prev_a.save()
        return redirect(
            reverse("jeiko_administration_questionnaires_expert:test_detail", args=[answer.question.test.id])
        )


@method_decorator(never_cache, name='dispatch')
class ExpertAnswerMoveDown(View):
    def get(self, request, answer_id):
        answer = get_object_or_404(ExpertAnswer, id=answer_id)
        next_a = (
            ExpertAnswer.objects
            .filter(question=answer.question, order__gt=answer.order)
            .order_by('order')
            .first()
        )
        if next_a:
            answer.order, next_a.order = next_a.order, answer.order
            answer.save()
            next_a.save()
        return redirect(
            reverse("jeiko_administration_questionnaires_expert:test_detail", args=[answer.question.test.id])
        )


@method_decorator(never_cache, name='dispatch')
class ExpertProfileTypeCreateView(CreateView):
    model = ExpertProfileType
    form_class = ExpertProfileTypeForm
    template_name = "questionnaires_expert/profil_form.html"

    def dispatch(self, request, *args, **kwargs):
        self.test = get_object_or_404(ExpertTest, id=self.kwargs['test_id'])
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        form.instance.test = self.test
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.test.id])

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        test_id = self.kwargs.get('test_id') or self.object.test_id
        kwargs['test'] = get_object_or_404(ExpertTest, pk=test_id)
        return kwargs


@method_decorator(never_cache, name='dispatch')
class ExpertProfileTypeUpdateView(UpdateView):
    model = ExpertProfileType
    form_class = ExpertProfileTypeForm
    template_name = "questionnaires_expert/profil_form.html"
    pk_url_kwarg = "pk"

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.test.id])

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        test_id = self.kwargs.get('test_id') or self.object.test_id
        kwargs['test'] = get_object_or_404(ExpertTest, pk=test_id)
        return kwargs

@method_decorator(never_cache, name='dispatch')
class ExpertProfileTypeDeleteView(DeleteView):
    model = ExpertProfileType
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "profile_id"

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCombinationCreateView(CreateView):
    model = ExpertProfileCombination
    form_class = ExpertProfileCombinationForm
    template_name = "questionnaires_expert/profile_combination_form.html"

    def dispatch(self, request, *args, **kwargs):
        self.test = get_object_or_404(ExpertTest, id=self.kwargs['test_id'])
        return super().dispatch(request, *args, **kwargs)

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        queryset = ExpertProfileType.objects.filter(test=self.test)
        form.fields['parent_profile'].queryset = queryset
        form.fields['preferred_profile'].queryset = queryset
        form.fields['alternative_profile'].queryset = queryset
        return form

    def form_valid(self, form):
        form.instance.test = self.test
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCombinationUpdateView(UpdateView):
    model = ExpertProfileCombination
    form_class = ExpertProfileCombinationForm
    template_name = "questionnaires_expert/profile_combination_form.html"
    pk_url_kwarg = "pk"

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        test_profiles = self.object.test.profiles.all()
        form.fields['parent_profile'].queryset = test_profiles
        form.fields['preferred_profile'].queryset = test_profiles
        form.fields['alternative_profile'].queryset = test_profiles
        return form


    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCombinationDeleteView(DeleteView):
    model = ExpertProfileCombination
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "pk"

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCriterionCreateView(CreateView):
    model = ExpertProfileCriterion
    fields = ['profile_a', 'profile_b', 'priority']
    template_name = "questionnaires_expert/profile_criterion_form.html"

    def dispatch(self, request, *args, **kwargs):
        self.combination = get_object_or_404(ExpertProfileCombination, id=self.kwargs['combination_id'])
        return super().dispatch(request, *args, **kwargs)

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        test = self.combination.test
        queryset = ExpertProfileType.objects.filter(test=test)
        form.fields['profile_a'].queryset = queryset
        form.fields['profile_b'].queryset = queryset
        return form

    def form_valid(self, form):
        form.instance.combination = self.combination
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.combination.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCriterionUpdateView(UpdateView):
    model = ExpertProfileCriterion
    fields = ['profile_a', 'profile_b', 'priority']
    template_name = "questionnaires_expert/profile_criterion_form.html"
    pk_url_kwarg = "criterion_id"

    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)
        profiles = self.object.combination.test.profiles.all()
        form.fields['profile_a'].queryset = profiles
        form.fields['profile_b'].queryset = profiles
        return form

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.combination.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertProfileCriterionDeleteView(DeleteView):
    model = ExpertProfileCriterion
    template_name = "questionnaires_expert/confirm_delete.html"
    pk_url_kwarg = "criterion_id"

    def get_success_url(self):
        return reverse('jeiko_administration_questionnaires_expert:test_detail', args=[self.object.combination.test.id])


@method_decorator(never_cache, name='dispatch')
class ExpertTestDataDetailView(View):
    def get(self, request, pk):
        test_data = get_object_or_404(ExpertTestData, pk=pk)
        user = test_data.user
        prospect = test_data.prospect
        comments = Comments.objects.filter(test_data=test_data).order_by('-date_created')
        comment_form = CommentsForm()

        # Préparer pour l’affichage (data dans le JSONField)
        result_data = test_data.data or {}

        return render(request, "questionnaires_expert/test_data_detail.html", {
            "test_data": test_data,
            "user": user,
            "prospect": prospect,
            "result_data": result_data,
            "comments": comments,
            "comment_form": comment_form,
        })

    def post(self, request, pk):
        test_data = get_object_or_404(ExpertTestData, pk=pk)
        user = test_data.user
        prospect = test_data.prospect
        comment_form = CommentsForm(request.POST)

        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.test_data = test_data
            if user:
                comment.user = user
            if prospect:
                comment.prospect = prospect
            comment.save()
            return redirect(reverse("jeiko_administration_questionnaires_expert:test_data_detail", args=[pk]))

        # En cas d’erreur, on réaffiche la page avec le form rempli
        comments = Comments.objects.filter(test_data=test_data).order_by('-date_created')
        result_data = test_data.data or {}
        return render(request, "questionnaires_expert/test_data_detail.html", {
            "test_data": test_data,
            "user": user,
            "prospect": prospect,
            "result_data": result_data,
            "comments": comments,
            "comment_form": comment_form,
        })

@method_decorator(never_cache, name='dispatch')
class ProspectListView(ListView):
    model = Prospect
    template_name = "questionnaires_expert/prospect_list.html"
    context_object_name = "prospects"
    paginate_by = 50  # optionnel

    def get_queryset(self):
        qs = Prospect.objects.all().order_by('-date_created')
        # Tu peux ajouter des filtres ici si besoin
        return qs

def prospects_for_test(request, test_id):
    test = get_object_or_404(ExpertTest, id=test_id)
    # Récupérer tous les prospects ayant passé ce test
    prospect_ids = ExpertTestData.objects.filter(test=test, prospect__isnull=False).values_list('prospect_id', flat=True)
    prospects = Prospect.objects.filter(id__in=prospect_ids).distinct()
    return render(request, "questionnaires_expert/prospect_list.html", {
        "prospects": prospects,
        "test": test,
    })

def prospect_detail(request, pk):
    prospect = get_object_or_404(Prospect, pk=pk)
    test_data_list = (
        ExpertTestData.objects
        .filter(prospect=prospect)
        .select_related('test')
        .order_by('-created_at')
    )
    return render(request, "questionnaires_expert/prospect_detail.html", {
        "prospect": prospect,
        "test_data_list": test_data_list,
    })