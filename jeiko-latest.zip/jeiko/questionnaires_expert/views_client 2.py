# views_client.py
from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import TemplateView
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.contrib.auth import get_user_model
import json
from .models import (
    ExpertTest, ExpertQuestion, ExpertAnswer, ExpertProfileType,
    ExpertProfileCombination, ExpertProfileCriterion, ExpertTestData
)
from jeiko.questionnaires_expert.models import Prospect

User = get_user_model()

@method_decorator(never_cache, name='dispatch')
class ExpertTestIntroView(View):
    def get(self, request, slug):
        test = get_object_or_404(ExpertTest, slug=slug)
        return render(request, "questionnaires_expert_client/test_intro.html", {"test": test})


@method_decorator(never_cache, name='dispatch')
class ExpertTestQuestionView(View):
    def get(self, request, slug, position):
        test = get_object_or_404(ExpertTest, slug=slug)
        questions = test.questions.all().order_by("order")
        try:
            question = questions[int(position)]
        except IndexError:
            return redirect("jeiko_client_questionnaires_expert:test_result_input", slug=slug)

        return render(request, "questionnaires_expert_client/question.html", {
            "test": test,
            "question": question,
            "position": int(position),
            "total": questions.count(),
        })

    def post(self, request, slug, position):
        test = get_object_or_404(ExpertTest, slug=slug)
        questions = test.questions.all().order_by("order")
        try:
            question = questions[int(position)]
        except IndexError:
            return redirect("jeiko_client_questionnaires_expert:test_result_input", slug=slug)

        if question.question_type == 'multiple':
            selected_answers = request.POST.getlist("answer")
        else:
            selected_answers = request.POST.get("answer")

        if selected_answers:
            answers = request.session.get("answers", {})
            if isinstance(selected_answers, str):
                answers[str(question.id)] = [selected_answers]
            else:
                answers[str(question.id)] = selected_answers
            request.session["answers"] = answers

        return redirect("jeiko_client_questionnaires_expert:test_question", slug=slug, position=int(position) + 1)

def get_score_profile(test, total_score):
    """
    Retourne le premier profil is_score_profile qui correspond au total_score.
    """
    return (
        ExpertProfileType.objects
        .filter(test=test, is_score_profile=True, min_score__lte=total_score, max_score__gt=total_score)
        .first()
    )

@method_decorator(never_cache, name='dispatch')
class ExpertTestResultInputView(View):
    def get(self, request, slug):
        test = get_object_or_404(ExpertTest, slug=slug)
        questions = test.questions.all().order_by("order")
        answers = request.session.get("answers", {})

        if len(answers) < questions.count():
            return redirect("jeiko_client_questionnaires_expert:test_intro", slug=slug)

        # Si l’utilisateur est connecté, afficher un bouton "Voir mes résultats"
        # Sinon, afficher le formulaire
        return render(
            request,
            "questionnaires_expert_client/prospect_form.html",
            {
                "test": test,
                "user_is_authenticated": request.user.is_authenticated,
            }
        )

    def post(self, request, slug):
        test = get_object_or_404(ExpertTest, slug=slug)
        questions = test.questions.prefetch_related("answers").all()
        answers = request.session.get("answers", {})

        profile_scores = {}
        answers_data = []

        for question in questions:
            answer_ids = answers.get(str(question.id))
            if not answer_ids:
                continue
            if isinstance(answer_ids, str):
                answer_ids = [answer_ids]

            question_answers_data = []
            for answer_id in answer_ids:
                try:
                    answer = question.answers.get(id=answer_id)
                    question_answers_data.append({
                        "answer_id": answer.id,
                        "answer_text": answer.text
                    })
                    for weight in answer.profile_weights.all():
                        pid = weight.profile_type_id
                        profile_scores[pid] = profile_scores.get(pid, 0) + weight.weight
                except ExpertAnswer.DoesNotExist:
                    continue

            answers_data.append({
                "question_id": question.id,
                "question_text": question.text,
                "answers": question_answers_data
            })

        simple_profiles = ExpertProfileType.objects.filter(test=test, is_complex=False)
        score_list = []
        for p in simple_profiles:
            score_list.append({
                "profile_id": p.id,
                "slug": p.slug,
                "name": p.name,
                "score": profile_scores.get(p.id, 0)
            })

        # === AJOUT POUR SCORING DIRECT ===
        total_score = sum(profile_scores.values())
        result_profile = None
        preferred = None
        alternative = None

        combinations = ExpertProfileCombination.objects.filter(test=test).prefetch_related(
            "criteria", "parent_profile", "preferred_profile", "alternative_profile"
        )

        for combination in combinations:
            all_criteria = combination.criteria.all().order_by("priority")
            if not all_criteria.exists():
                continue

            valid = True
            for criterion in all_criteria:
                score_a = profile_scores.get(criterion.profile_a_id, 0)
                score_b = profile_scores.get(criterion.profile_b_id, 0)
                if score_a < score_b:
                    valid = False
                    break

            if valid:
                result_profile = combination.parent_profile
                preferred = combination.preferred_profile
                alternative = combination.alternative_profile
                break

        # ===== FALLBACK : Profil par score direct =====
        if not result_profile:
            score_profile = get_score_profile(test, total_score)
            if score_profile:
                result_profile = score_profile
                preferred = None
                alternative = None

        result_block = {
            "dominant": {
                "id": result_profile.id if result_profile else None,
                "slug": result_profile.slug if result_profile else None,
                "name": result_profile.name if result_profile else None
            } if result_profile else None,
            "preferred": {
                "id": preferred.id if preferred else None,
                "slug": preferred.slug if preferred else None,
                "name": preferred.name if preferred else None
            } if preferred else None,
            "alternative": {
                "id": alternative.id if alternative else None,
                "slug": alternative.slug if alternative else None,
                "name": alternative.name if alternative else None
            } if alternative else None,
        }

        test_data = ExpertTestData.objects.create(
            user=request.user if request.user.is_authenticated else None,
            prospect=None,
            test=test,
            result_profile=result_profile,
            preferred_profile=preferred,
            alternative_profile=alternative,
            data={
                "test_id": test.id,
                "test_title": test.title,
                "results": result_block,
                "scores": score_list,
                "answers": answers_data,
                "total_score": total_score,  # Ajout au JSON, utile à l’affichage
            }
        )

        if not request.user.is_authenticated:
            email = request.POST.get("email")
            # Recherche d'un prospect existant avec cet email (insensible à la casse si tu veux)
            prospect = Prospect.objects.filter(email__iexact=email).first()
            if prospect is None:
                # Création seulement si aucun prospect trouvé
                prospect = Prospect.objects.create(
                    firstname=request.POST.get("firstname"),
                    lastname=request.POST.get("lastname"),
                    email=email,
                    phone=request.POST.get("phone"),
                )
            else:
                # (Optionnel) mettre à jour d'autres champs si tu veux garder les infos les plus récentes
                updated = False
                if not prospect.firstname and request.POST.get("firstname"):
                    prospect.firstname = request.POST.get("firstname")
                    updated = True
                if not prospect.lastname and request.POST.get("lastname"):
                    prospect.lastname = request.POST.get("lastname")
                    updated = True
                if not prospect.phone and request.POST.get("phone"):
                    prospect.phone = request.POST.get("phone")
                    updated = True
                if updated:
                    prospect.save()
            test_data.prospect = prospect
            test_data.save()

        # Nettoyage de la session si besoin
        if "answers" in request.session:
            del request.session["answers"]

        return redirect(
            "jeiko_client_questionnaires_expert:test_result",
            slug=slug,
            result_slug=result_profile.slug if result_profile else "inconnu"
        )


@method_decorator(never_cache, name='dispatch')
class ExpertTestResultView(TemplateView):
    template_name = 'pages/main.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        result_slug = self.kwargs.get("result_slug")
        profile = get_object_or_404(ExpertProfileType, slug=result_slug)
        test = profile.test
        context["profile"] = profile
        context["test"] = test
        context["page"] = profile.result_page

        # Scores utilisateur (facultatif)
        answers = self.request.session.get("answers", {})
        profile_scores = {}

        for answer_list in answers.values():
            for answer_id in answer_list:
                try:
                    answer = ExpertAnswer.objects.prefetch_related("profile_weights").get(id=answer_id)
                    for weight in answer.profile_weights.all():
                        pid = weight.profile_type_id
                        profile_scores[pid] = profile_scores.get(pid, 0) + weight.weight
                except ExpertAnswer.DoesNotExist:
                    continue

        simple_profiles = list(ExpertProfileType.objects.filter(test=test, is_complex=False))
        context["simple_profiles"] = simple_profiles  # Pour fallback côté template

        # Chart data si réponses dispo
        if profile_scores:
            chart_data = {
                "labels": [p.name for p in simple_profiles],
                "datasets": [{
                    "label": "Scores",
                    "data": [profile_scores.get(p.id, 0) for p in simple_profiles],
                    "backgroundColor": [p.color or "#cccccc" for p in simple_profiles],
                }]
            }
            context["chart_data_json"] = json.dumps(chart_data)
        else:
            context["chart_data_json"] = None  # <== JS gérera le fallback

        context["show_chart"] = True  # Toujours affiché si besoin
        print(context)
        return context

