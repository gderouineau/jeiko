from django.apps import AppConfig


class QuestionnairesExpertConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko.questionnaires_expert'
