# users/forms_admin.py

from django import forms
from django.contrib.auth.models import Group
from django.contrib.auth import get_user_model
User = get_user_model()

from jeiko.users.models import Comments

class AdminUserFilterForm(forms.Form):
    search = forms.CharField(
        required=False,
        label="Recherche",
        widget=forms.TextInput(attrs={'placeholder': 'Nom ou email'})
    )
    is_active = forms.ChoiceField(
        required=False,
        choices=[('', 'Tous'), ('1', 'Actifs'), ('0', 'Inactifs')],
        label="Statut actif"
    )
    group = forms.ModelChoiceField(
        queryset=Group.objects.all(),
        required=False,
        label="Groupe"
    )
    date_joined_from = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date'}),
        label="Inscrits depuis"
    )
    date_joined_to = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date'}),
        label="Inscrits jusqu’à"
    )

class AdminUserEditForm(forms.ModelForm):
    groups = forms.ModelMultipleChoiceField(
        queryset=Group.objects.all(),
        required=False,
        widget=forms.CheckboxSelectMultiple,
        label="Groupes"
    )

    class Meta:
        model = User
        fields = [
            'username',
            'email',
            'is_active',
            'is_staff',
            'is_superuser',
            'groups',
        ]

class CommentsForm(forms.ModelForm):

    class Meta:
        model = Comments
        fields = [
            'text'
        ]

    def __init__(self, *args, **kwargs):
        super(CommentsForm, self).__init__(*args, **kwargs)
        self.fields['text'].widget = forms.Textarea(
            attrs={
                'placeholder': 'Commentaire'
            }
        )