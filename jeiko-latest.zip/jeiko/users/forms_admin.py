# users/forms_admin.py

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.utils import timezone

from jeiko.users.models import (
    Role, RolePermission, RoleAssignment,
    ProviderConfig,
    TwoFactorDevice, TwoFactorType, SecurityEvent, UserSession,
    Consent, ConsentType, MarketingPreference,
    NotificationChannel, Notification, NotificationStatus,
    ProspectLink,
    Comments,
)
from jeiko.questionnaires_expert.models import Prospect, ExpertTestData

User = get_user_model()


# =========================================================
#  Tes formulaires existants (légèrement retouchés)
# =========================================================

class AdminUserFilterForm(forms.Form):
    search = forms.CharField(
        required=False,
        label="Recherche",
        widget=forms.TextInput(attrs={'placeholder': 'Nom ou email'})
    )
    is_active = forms.ChoiceField(
        required=False,
        choices=[('', 'Tous'), ('1', 'Actifs'), ('0', 'Inactifs')],
        label="Statut actif"
    )
    # Conserve Group pour compat, mais tu auras désormais Role (voir plus bas)
    group = forms.ModelChoiceField(
        queryset=Group.objects.all(),
        required=False,
        label="Groupe"
    )
    role = forms.ModelChoiceField(
        queryset=Role.objects.all(),
        required=False,
        label="Rôle"
    )
    date_joined_from = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date'}),
        label="Inscrits depuis"
    )
    date_joined_to = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date'}),
        label="Inscrits jusqu’à"
    )


class AdminUserEditForm(forms.ModelForm):
    groups = forms.ModelMultipleChoiceField(
        queryset=Group.objects.all(),
        required=False,
        widget=forms.CheckboxSelectMultiple,
        label="Groupes"
    )

    class Meta:
        model = User
        fields = [
            'username',
            'email',
            'is_active',
            'is_staff',
            'is_superuser',
            'groups',
        ]


class CommentsForm(forms.ModelForm):
    class Meta:
        model = Comments
        fields = ['text']

    def __init__(self, *args, **kwargs):
        super(CommentsForm, self).__init__(*args, **kwargs)
        self.fields['text'].widget = forms.Textarea(
            attrs={'placeholder': 'Commentaire'}
        )


# =========================================================
#  Rôles & Permissions (site)
# =========================================================

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.db import models

from jeiko.users.models import Role, RolePermission



# Libellés FR lisibles pour chaque permission (codename → label)
PERM_LABELS_FR = {
    # Pages (administration_pages)
    "view_page": "Voir les pages",
    "add_page": "Créer une page",
    "change_page": "Éditer la page",
    "delete_page": "Supprimer la page",
    "view_pages_menu": "Voir le menu « Pages »",

    # Calendars
    "view_googlecalendar": "Voir la config Google Calendar",
    "change_googlecalendar": "Éditer la config Google Calendar",
    "view_appointmenttype": "Voir les types de RDV",
    "add_appointmenttype": "Créer un type de RDV",
    "change_appointmenttype": "Éditer un type de RDV",
    "delete_appointmenttype": "Supprimer un type de RDV",
    "view_availability": "Voir les disponibilités",
    "add_availability": "Créer une disponibilité",
    "change_availability": "Éditer une disponibilité",
    "delete_availability": "Supprimer une disponibilité",
    "view_appointment": "Voir les RDV",
    "add_appointment": "Créer un RDV",
    "change_appointment": "Éditer un RDV",
    "delete_appointment": "Supprimer un RDV",
    "view_calendars_menu": "Voir le menu « Calendrier »",

    # Questionnaires & Prospects
    "view_questionnaire": "Voir les questionnaires",
    "add_questionnaire": "Créer un questionnaire",
    "change_questionnaire": "Éditer un questionnaire",
    "delete_questionnaire": "Supprimer un questionnaire",
    "view_prospect": "Voir les prospects",
    "add_prospect": "Créer un prospect",
    "change_prospect": "Éditer un prospect",
    "delete_prospect": "Supprimer un prospect",
    "view_questionnaires_menu": "Voir le menu « Questionnaires »",

    # Users / Rôles
    "view_user": "Voir les utilisateurs",
    "change_user": "Éditer un utilisateur",
    "delete_user": "Supprimer un utilisateur",
    "users_manage_role_permissions": "Gérer les permissions des rôles",
    "users_assign_role": "Assigner des rôles",
    "users_assign_prospect": "Assigner un prospect",
    "users_view_users_menu": "Voir le menu « Utilisateurs »",

    # Providers (connexion)
    "authprov_view_providerconfig": "Voir les providers",
    "authprov_add_providerconfig": "Ajouter un provider",
    "authprov_change_providerconfig": "Éditer un provider",
    "authprov_delete_providerconfig": "Supprimer un provider",
    "authprov_sync_socialapps": "Synchroniser avec allauth",
    "authprov_view_auth_menu": "Voir le menu « Connexion / Providers »",

    # Sécurité
    "sec_view_twofactordevice": "Voir les dispositifs 2FA",
    "sec_add_twofactordevice": "Ajouter un dispositif 2FA",
    "sec_change_twofactordevice": "Éditer un dispositif 2FA",
    "sec_delete_twofactordevice": "Supprimer un dispositif 2FA",
    "sec_view_usersession": "Voir les sessions",
    "sec_revoke_usersession": "Révoquer des sessions",
    "sec_view_securityevent": "Voir les événements sécurité",
    "sec_view_security_menu": "Voir le menu « Sécurité »",

    # Consentements & Marketing
    "cons_view_consent": "Voir les consentements",
    "cons_add_consent": "Ajouter un consentement",
    "cons_change_consent": "Éditer un consentement",
    "cons_delete_consent": "Supprimer un consentement",
    "cons_view_marketingpreference": "Voir les préférences marketing",
    "cons_change_marketingpreference": "Éditer les préférences marketing",
    "cons_view_consent_menu": "Voir le menu « Consentements »",

    # Notifications
    "notif_view_notificationchannel": "Voir les canaux de notif",
    "notif_add_notificationchannel": "Ajouter un canal de notif",
    "notif_change_notificationchannel": "Éditer un canal de notif",
    "notif_delete_notificationchannel": "Supprimer un canal de notif",
    "notif_view_notification": "Voir les notifications",
    "notif_add_notification": "Créer une notification",
    "notif_bulk_notification": "Envoyer des notifications en masse",
    "notif_view_notifications_menu": "Voir le menu « Notifications »",

    # Administration du site
    "admincfg_change_website": "Éditer le site",
    "admincfg_change_mailsettings": "Éditer les réglages email",
    "admincfg_change_fonts": "Éditer les polices",
    "admincfg_clear_cache": "Vider le cache",
    "admincfg_view_health": "Voir la santé du système",
    "admincfg_view_admin_menu": "Voir le menu « Administration »",
}

def label_perm_fr(perm: Permission):
    return PERM_LABELS_FR.get(perm.codename, perm.name)

def perms_by_codenames(codenames):
    return Permission.objects.select_related('content_type').filter(codename__in=codenames).order_by('content_type__app_label', 'codename')


class RoleForm(forms.ModelForm):
    """
    Formulaire de rôle avec permissions groupées par catégories.
    - Affiche des libellés FR lisibles.
    - Sauvegarde via le modèle intermédiaire RolePermission (granted_by).
    """
    # --- Groupes de permissions ---
    pages = forms.ModelMultipleChoiceField(
        queryset=perms_by_codenames([
            "view_page","add_page","change_page","delete_page","view_pages_menu"
        ]),
        required=False, label="Pages", widget=forms.SelectMultiple(attrs={"size": 8})
    )

    calendars = forms.ModelMultipleChoiceField(
        queryset=perms_by_codenames([
            "view_googlecalendar","change_googlecalendar",
            "view_appointmenttype","add_appointmenttype","change_appointmenttype","delete_appointmenttype",
            "view_availability","add_availability","change_availability","delete_availability",
            "view_appointment","add_appointment","change_appointment","delete_appointment",
            "view_calendars_menu"
        ]),
        required=False, label="Calendrier", widget=forms.SelectMultiple(attrs={"size": 12})
    )

    questionnaires = forms.ModelMultipleChoiceField(
        queryset=perms_by_codenames([
            "view_questionnaire","add_questionnaire","change_questionnaire","delete_questionnaire",
            "view_prospect","add_prospect","change_prospect","delete_prospect",
            "view_questionnaires_menu"
        ]),
        required=False, label="Questionnaires & Prospects", widget=forms.SelectMultiple(attrs={"size": 12})
    )

    users_perms = forms.ModelMultipleChoiceField(
        queryset=perms_by_codenames([
            "view_user","change_user","delete_user",
            "users_manage_role_permissions","users_assign_role","users_assign_prospect",
            "users_view_users_menu"
        ]),
        required=False, label="Utilisateurs & Rôles", widget=forms.SelectMultiple(attrs={"size": 10})
    )

    providers = forms.ModelMultipleChoiceField(
        queryset=perms_by_codenames([
            "authprov_view_providerconfig","authprov_add_providerconfig","authprov_change_providerconfig","authprov_delete_providerconfig",
            "authprov_sync_socialapps","authprov_view_auth_menu"
        ]),
        required=False, label="Providers (Connexion)", widget=forms.SelectMultiple(attrs={"size": 8})
    )

    security = forms.ModelMultipleChoiceField(
        queryset=perms_by_codenames([
            "sec_view_twofactordevice","sec_add_twofactordevice","sec_change_twofactordevice","sec_delete_twofactordevice",
            "sec_view_usersession","sec_revoke_usersession","sec_view_securityevent","sec_view_security_menu"
        ]),
        required=False, label="Sécurité", widget=forms.SelectMultiple(attrs={"size": 12})
    )

    consent = forms.ModelMultipleChoiceField(
        queryset=perms_by_codenames([
            "cons_view_consent","cons_add_consent","cons_change_consent","cons_delete_consent",
            "cons_view_marketingpreference","cons_change_marketingpreference","cons_view_consent_menu"
        ]),
        required=False, label="Consentements & Marketing", widget=forms.SelectMultiple(attrs={"size": 10})
    )

    notifications = forms.ModelMultipleChoiceField(
        queryset=perms_by_codenames([
            "notif_view_notificationchannel","notif_add_notificationchannel","notif_change_notificationchannel","notif_delete_notificationchannel",
            "notif_view_notification","notif_add_notification","notif_bulk_notification","notif_view_notifications_menu"
        ]),
        required=False, label="Notifications", widget=forms.SelectMultiple(attrs={"size": 12})
    )

    admincfg = forms.ModelMultipleChoiceField(
        queryset=perms_by_codenames([
            "admincfg_change_website","admincfg_change_mailsettings","admincfg_change_fonts",
            "admincfg_clear_cache","admincfg_view_health","admincfg_view_admin_menu"
        ]),
        required=False, label="Administration du site", widget=forms.SelectMultiple(attrs={"size": 10})
    )

    class Meta:
        model = Role
        fields = ['name', 'slug', 'description', 'is_active', 'is_protected',
                  # champs virtuels de permissions ⇒ on les rend “visibles” après les métadonnées
                  'pages','calendars','questionnaires','users_perms','providers','security','consent','notifications','admincfg'
        ]

    def __init__(self, *args, **kwargs):
        # pour enregistrer granted_by
        self.request = kwargs.pop("request", None)
        super().__init__(*args, **kwargs)
        # labels lisibles
        for fname in ("pages","calendars","questionnaires","users_perms","providers","security","consent","notifications","admincfg"):
            self.fields[fname].label_from_instance = label_perm_fr

        # Pré-cocher ce que le rôle a déjà
        if self.instance and self.instance.pk:
            current_ids = set(
                RolePermission.objects.filter(role=self.instance).values_list('permission_id', flat=True)
            )
            for fname in ("pages","calendars","questionnaires","users_perms","providers","security","consent","notifications","admincfg"):
                self.fields[fname].initial = [p.id for p in self.fields[fname].queryset if p.id in current_ids]

    def clean(self):
        data = super().clean()
        if self.instance and self.instance.pk and self.instance.is_protected and not data.get('is_protected', True):
            raise forms.ValidationError("Ce rôle est protégé : vous ne pouvez pas le déprotéger ici.")
        return data

    def save(self, commit=True):
        role = super().save(commit=commit)
        # Concaténer toutes les sélections
        selected_ids = set()
        for fname in ("pages","calendars","questionnaires","users_perms","providers","security","consent","notifications","admincfg"):
            selected_ids.update([p.id for p in self.cleaned_data.get(fname) or []])

        # État actuel
        current_ids = set(RolePermission.objects.filter(role=role).values_list('permission_id', flat=True))

        to_add = selected_ids - current_ids
        to_del = current_ids - selected_ids

        # Ajouts
        if to_add:
            perms_map = {p.id: p for p in Permission.objects.filter(id__in=to_add)}
            for pid in to_add:
                RolePermission.objects.get_or_create(
                    role=role,
                    permission=perms_map[pid],
                    defaults={'granted_by': getattr(self.request, 'user', None)}
                )

        # Suppressions
        if to_del:
            RolePermission.objects.filter(role=role, permission_id__in=to_del).delete()

        return role



class RolePermissionForm(forms.ModelForm):
    permission = forms.ModelChoiceField(
        queryset=Permission.objects.select_related('content_type').all(),
        widget=forms.Select
    )

    class Meta:
        model = RolePermission
        fields = ['role', 'permission']

    def clean(self):
        data = super().clean()
        role = data.get('role')
        perm = data.get('permission')
        if role and perm and RolePermission.objects.filter(role=role, permission=perm).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError("Cette permission est déjà attachée à ce rôle.")
        return data


class RoleAssignmentForm(forms.ModelForm):
    class Meta:
        model = RoleAssignment
        fields = ['user', 'role', 'expires_at', 'notes']
        widgets = {
            'expires_at': forms.DateTimeInput(attrs={'type': 'datetime-local'})
        }

    def clean_expires_at(self):
        expires_at = self.cleaned_data.get('expires_at')
        if expires_at and expires_at < timezone.now():
            raise forms.ValidationError("La date d’expiration doit être dans le futur.")
        return expires_at


class BulkAssignRoleForm(forms.Form):
    """
    Assigner un rôle à une sélection d'utilisateurs (IDs).
    """
    user_ids = forms.CharField(widget=forms.HiddenInput)
    role = forms.ModelChoiceField(queryset=Role.objects.filter(is_active=True), label="Rôle à assigner")

    def clean_user_ids(self):
        raw = self.cleaned_data['user_ids']
        try:
            ids = [int(x) for x in raw.split(',') if x.strip()]
        except ValueError:
            raise forms.ValidationError("Liste d'IDs invalide.")
        if not ids:
            raise forms.ValidationError("Aucun utilisateur sélectionné.")
        return ids


class BulkRevokeRoleForm(forms.Form):
    user_ids = forms.CharField(widget=forms.HiddenInput)
    role = forms.ModelChoiceField(queryset=Role.objects.all(), label="Rôle à révoquer")

    def clean_user_ids(self):
        raw = self.cleaned_data['user_ids']
        try:
            ids = [int(x) for x in raw.split(',') if x.strip()]
        except ValueError:
            raise forms.ValidationError("Liste d'IDs invalide.")
        if not ids:
            raise forms.ValidationError("Aucun utilisateur sélectionné.")
        return ids


# =========================================================
#  Providers (allauth) – config côté site
# =========================================================

class ProviderConfigForm(forms.ModelForm):
    client_secret = forms.CharField(
        widget=forms.PasswordInput(render_value=True),
        label="Client secret"
    )

    class Meta:
        model = ProviderConfig
        fields = [
            'provider', 'label',
            'client_id', 'client_secret',
            'enabled', 'callback_url', 'extra_config'
        ]
        widgets = {
            'extra_config': forms.Textarea(attrs={'rows': 3, 'placeholder': '{"scope": "..."}'})
        }


# =========================================================
#  Sécurité & Sessions
# =========================================================

class TwoFactorDeviceForm(forms.ModelForm):
    class Meta:
        model = TwoFactorDevice
        fields = ['user', 'device_type', 'name', 'secret_or_credential', 'is_active']

    def clean_secret_or_credential(self):
        val = self.cleaned_data.get('secret_or_credential', '').strip()
        if not val:
            raise forms.ValidationError("Secret/credential requis.")
        return val


class TwoFactorToggleForm(forms.Form):
    """
    Activer/Désactiver 2FA (niveau compte).
    """
    enable = forms.BooleanField(required=False, initial=True, label="Activer la double authentification")


class UserSessionRevokeForm(forms.Form):
    """
    Révoquer une ou plusieurs sessions (side admin).
    """
    session_ids = forms.CharField(widget=forms.HiddenInput)

    def clean_session_ids(self):
        raw = self.cleaned_data['session_ids']
        try:
            ids = [int(x) for x in raw.split(',') if x.strip()]
        except ValueError:
            raise forms.ValidationError("Liste d'IDs invalide.")
        if not ids:
            raise forms.ValidationError("Aucune session sélectionnée.")
        return ids


class SecurityEventFilterForm(forms.Form):
    """
    Filtrer l'audit sécurité (lecture seule).
    """
    user = forms.ModelChoiceField(queryset=User.objects.all(), required=False, label="Utilisateur")
    event_type = forms.ChoiceField(
        required=False,
        choices=[('', 'Tous')] + list(SecurityEvent._meta.get_field('event_type').choices),
        label="Type d’événement"
    )
    date_from = forms.DateTimeField(required=False, widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}))
    date_to = forms.DateTimeField(required=False, widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}))


# =========================================================
#  Consentements & Préférences
# =========================================================

class ConsentForm(forms.ModelForm):
    class Meta:
        model = Consent
        fields = [
            'user', 'anonymous_key',
            'consent_type', 'version_text',
            'granted', 'granted_at',
            'ip_address', 'evidence', 'source'
        ]
        widgets = {
            'granted_at': forms.DateTimeInput(attrs={'type': 'datetime-local'})
        }

    def clean(self):
        data = super().clean()
        user = data.get('user')
        anon = data.get('anonymous_key')
        if not user and not anon:
            raise forms.ValidationError("Renseigner un utilisateur ou un identifiant anonyme.")
        return data


class MarketingPreferenceForm(forms.ModelForm):
    class Meta:
        model = MarketingPreference
        fields = ['user', 'email_optin', 'sms_optin', 'whatsapp_optin', 'frequency', 'topics']
        widgets = {
            'topics': forms.Textarea(attrs={'rows': 2, 'placeholder': '["coaching","tests"]'})
        }


# =========================================================
#  Notifications
# =========================================================

class NotificationChannelForm(forms.ModelForm):
    class Meta:
        model = NotificationChannel
        fields = ['user', 'channel', 'enabled', 'quiet_hours']
        widgets = {
            'quiet_hours': forms.Textarea(attrs={'rows': 2, 'placeholder': '{"start":"22:00","end":"07:00"}'})
        }


class NotificationComposeForm(forms.ModelForm):
    """
    Composer/forcer l’envoi d’une notif (back-office côté site).
    """
    class Meta:
        model = Notification
        fields = ['user', 'notif_type', 'payload', 'status']
        widgets = {
            'payload': forms.Textarea(attrs={'rows': 3, 'placeholder': '{"subject":"...","message":"..."}'})
        }

    def clean_status(self):
        status = self.cleaned_data.get('status')
        if status not in [NotificationStatus.QUEUED, NotificationStatus.SENT]:
            # On interdit de créer directement en FAILED/OPENED ici
            raise forms.ValidationError("Statut non autorisé à la création.")
        return status


# =========================================================
#  Bridge User ↔ Prospect
# =========================================================

class ProspectLinkForm(forms.ModelForm):
    class Meta:
        model = ProspectLink
        fields = ['user', 'prospect']
        widgets = {
            'user': forms.Select(attrs={'class': 'form-control'}),
            'prospect': forms.Select(attrs={'class': 'form-control'}),
        }

    def clean(self):
        data = super().clean()
        user = data.get('user')
        prospect = data.get('prospect')
        if user and prospect and ProspectLink.objects.filter(user=user, prospect=prospect).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError("Ce User est déjà lié à ce Prospect.")
        return data


# --- Questionnaires Access ---
from jeiko.questionnaires_expert.models import UserTestAccess

class UserTestAccessForm(forms.ModelForm):
    class Meta:
        model = UserTestAccess
        fields = ['user', 'test', 'source']
        widgets = {
            'user': forms.HiddenInput(),
            'test': forms.Select(attrs={'class': 'form-control'}),
            'source': forms.Select(attrs={'class': 'form-control'}),
        }


# =========================================================
#  Utilitaires “site” (actions rapides)
# =========================================================

class SyncProviderToAllauthForm(forms.Form):
    """
    Déclenchera la synchronisation ProviderConfig -> allauth.SocialApp.
    """
    provider_config_id = forms.IntegerField(widget=forms.HiddenInput)


class BulkNotificationForm(forms.Form):
    """
    Envoi d’une notification à une sélection d’utilisateurs.
    """
    user_ids = forms.CharField(widget=forms.HiddenInput)
    notif_type = forms.CharField(max_length=64, label="Type interne")
    payload = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), required=False)

    def clean_user_ids(self):
        raw = self.cleaned_data['user_ids']
        try:
            ids = [int(x) for x in raw.split(',') if x.strip()]
        except ValueError:
            raise forms.ValidationError("Liste d'IDs invalide.")
        if not ids:
            raise forms.ValidationError("Aucun utilisateur sélectionné.")
        return ids
