# users/views_admin.py

from django.urls import reverse_lazy
from django.contrib.auth import get_user_model
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import ListView, DetailView, UpdateView
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.db.models import Q, Prefetch

from jeiko.users.forms_admin import AdminUserFilterForm, AdminUserEditForm
from jeiko.questionnaires_expert.models import ExpertTestData

User = get_user_model()

@method_decorator(never_cache, name='dispatch')
class AdminUserListView(LoginRequiredMixin, ListView):
    model = User
    template_name = "users/admin/user_list.html"
    context_object_name = "users"
    paginate_by = 25

    def get_queryset(self):
        qs = super().get_queryset().prefetch_related('groups', Prefetch('profile'))
        form = AdminUserFilterForm(self.request.GET)
        if form.is_valid():
            cd = form.cleaned_data
            if cd['search']:
                qs = qs.filter(
                    Q(username__icontains=cd['search']) |
                    Q(email__icontains=cd['search'])
                )
            if cd['is_active'] in ('0', '1'):
                qs = qs.filter(is_active=bool(int(cd['is_active'])))
            if cd['group']:
                qs = qs.filter(groups=cd['group'])
            if cd['date_joined_from']:
                qs = qs.filter(date_joined__gte=cd['date_joined_from'])
            if cd['date_joined_to']:
                qs = qs.filter(date_joined__lte=cd['date_joined_to'])
        return qs.order_by('-date_joined')

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['form'] = AdminUserFilterForm(self.request.GET)
        return ctx


@method_decorator(never_cache, name='dispatch')
class AdminUserDetailView(LoginRequiredMixin, UserPassesTestMixin, DetailView):
    model = User
    context_object_name = 'user_obj'
    template_name = 'users/admin/user_detail.html'

    def test_func(self):
        return self.request.user.is_staff  # ou toute autre condition

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        # On récupère toutes les données de test liées à cet user
        ctx['test_datas'] = ExpertTestData.objects.filter(user=self.object)
        return ctx

@method_decorator(never_cache, name='dispatch')
class AdminUserUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = User
    form_class = AdminUserEditForm
    context_object_name = 'user_obj'
    template_name = 'users/admin/user_form.html'
    success_url = reverse_lazy('jeiko_administration_users:user_list')

    def test_func(self):
        return self.request.user.is_staff