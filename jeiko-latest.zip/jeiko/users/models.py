from django.conf import settings
from django.db import models

from jeiko.questionnaires_expert.models import ExpertTestData, Prospect

class Profile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='profile'
    )
    avatar = models.ImageField(
        upload_to='avatars/',
        null=True,
        blank=True
    )
    bio = models.TextField(
        blank=True
    )
    phone_number = models.CharField(
        max_length=20,
        blank=True
    )
    date_of_birth = models.DateField(
        null=True,
        blank=True
    )
    location = models.CharField(
        max_length=255,
        blank=True
    )
    website = models.URLField(
        blank=True
    )
    # TODO: ajouter d'autres champs spécifiques si besoin

    def __str__(self):
        return f"Profil de {self.user.get_full_name() or self.user.email}"



class Comments(models.Model):

    date_created = models.DateTimeField(
        auto_now_add=True,
        blank=True,
    )

    text = models.TextField(
        max_length=5000,
    )

    test_data = models.ForeignKey(
        ExpertTestData,
        on_delete=models.CASCADE,
        related_name='comments',
        null=True,
        blank=True,
    )

    prospect = models.ForeignKey(
        Prospect,
        on_delete=models.CASCADE,
        related_name='comments',
        null=True,
        blank=True,
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='comments',
        null=True,
        blank=True,
    )