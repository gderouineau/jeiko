from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import DetailView, UpdateView, ListView, CreateView, DeleteView
from django.shortcuts import get_object_or_404, redirect

from ..forms import ProfileForm, AddressForm
from ..models import Profile, Address
from jeiko.shop.models import Order

class ProfileDetailView(LoginRequiredMixin, DetailView):
    model = Profile
    template_name = 'users/client/profile_detail.html'

    def get_object(self):
        # Crée le profile si l'utilisateur n'en a pas déjà un
        profile, created = Profile.objects.get_or_create(user=self.request.user)
        return profile

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Add orders
        context['orders'] = Order.objects.filter(user=self.request.user).order_by('-created_at')
        # Add addresses
        context['addresses'] = Address.objects.filter(user=self.request.user)
        return context


class ProfileUpdateView(LoginRequiredMixin, UpdateView):
    model = Profile
    form_class = ProfileForm
    template_name = 'users/client/profile_form.html'
    success_url = reverse_lazy('jeiko_users_client:profile-detail')

    def get_object(self):
        profile, created = Profile.objects.get_or_create(user=self.request.user)
        return profile

class OrderDetailView(LoginRequiredMixin, DetailView):
    model = Order
    template_name = 'users/client/order_detail.html'
    context_object_name = 'order'

    def get_queryset(self):
        # Ensure user can only see their own orders
        return Order.objects.filter(user=self.request.user)


# =========================
#  Address Views
# =========================

class AddressListView(LoginRequiredMixin, ListView):
    model = Address
    template_name = 'users/client/address_list.html'
    context_object_name = 'addresses'

    def get_queryset(self):
        return Address.objects.filter(user=self.request.user)


class AddressCreateView(LoginRequiredMixin, CreateView):
    model = Address
    form_class = AddressForm
    template_name = 'users/client/address_form.html'
    success_url = reverse_lazy('jeiko_users_client:profile-detail') # Or address list

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


class AddressUpdateView(LoginRequiredMixin, UpdateView):
    model = Address
    form_class = AddressForm
    template_name = 'users/client/address_form.html'
    success_url = reverse_lazy('jeiko_users_client:profile-detail')

    def get_queryset(self):
        return Address.objects.filter(user=self.request.user)


class AddressDeleteView(LoginRequiredMixin, DeleteView):
    model = Address
    template_name = 'users/client/address_confirm_delete.html' # Optional, can use a modal or simple post
    success_url = reverse_lazy('jeiko_users_client:profile-detail')

    def get_queryset(self):
        return Address.objects.filter(user=self.request.user)
