from django.urls import path
from ..views.client import (
    ProfileDetailView,
    ProfileUpdateView,
    OrderDetailView,
    AddressCreateView,
    AddressUpdateView,
    AddressDeleteView
)

app_name = 'jeiko_users_client'

urlpatterns = [
    # Profil utilisateur
    path('profile/', ProfileDetailView.as_view(), name='profile-detail'),
    path('profile/edit/', ProfileUpdateView.as_view(), name='profile-edit'),
    
    # Adresses
    path('profile/address/new/', AddressCreateView.as_view(), name='address-create'),
    path('profile/address/<int:pk>/edit/', AddressUpdateView.as_view(), name='address-edit'),
    path('profile/address/<int:pk>/delete/', AddressDeleteView.as_view(), name='address-delete'),

    # Commandes
    path('orders/<int:pk>/', OrderDetailView.as_view(), name='order_detail'),
]
