# users/views.py

from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from allauth.account.views import SignupView, LoginView, LogoutView
from django.views.generic import DetailView, UpdateView

from jeiko.users.forms import CustomSignupForm, ProfileForm, CustomLoginForm
from jeiko.users.models import Profile


class CustomSignupView(SignupView):
    form_class = CustomSignupForm
    template_name = 'account/signup.html'
    success_url = reverse_lazy('jeiko_users:profile-detail')


class CustomLoginView(LoginView):
    form_class = CustomLoginForm
    template_name = 'users/client/login.html'


class CustomLogoutView(LogoutView):
    template_name = 'account/logout.html'


class ProfileDetailView(LoginRequiredMixin, DetailView):
    model = Profile
    template_name = 'users/client/profile_detail.html'

    def get_object(self):
        # Crée le profile si l'utilisateur n'en a pas déjà un
        profile, created = Profile.objects.get_or_create(user=self.request.user)
        return profile


class ProfileUpdateView(LoginRequiredMixin, UpdateView):
    model = Profile
    form_class = ProfileForm
    template_name = 'users/client/profile_form.html'
    success_url = reverse_lazy('jeiko_users:profile-detail')

    def get_object(self):
        profile, created = Profile.objects.get_or_create(user=self.request.user)
        return profile
