from django import forms
from django.contrib.auth import get_user_model
from allauth.account.forms import SignupForm, LoginForm
from django.utils import timezone
import re

from jeiko.users.models import Profile

User = get_user_model()


class ProfileForm(forms.ModelForm):
    """
    Formulaire pour que l’utilisateur modifie son profil.
    - Validation avatar: type & taille
    - Date de naissance: pas dans le futur
    - Téléphone: nettoyage simple
    """
    MAX_AVATAR_MB = 5
    ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/png", "image/webp"}

    class Meta:
        model = Profile
        fields = [
            'avatar',
            'bio',
            'phone_number',
            'date_of_birth',
            'location',
            'website',
        ]
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
        }

    def clean_avatar(self):
        f = self.cleaned_data.get('avatar')
        if not f:
            return f
        # Taille
        if f.size > self.MAX_AVATAR_MB * 1024 * 1024:
            raise forms.ValidationError(
                f"L’image est trop lourde (>{self.MAX_AVATAR_MB} Mo)."
            )
        # Type MIME (si disponible via uploaded file)
        content_type = getattr(f, "content_type", None)
        if content_type and content_type.lower() not in self.ALLOWED_CONTENT_TYPES:
            raise forms.ValidationError("Format d’image non supporté (jpeg, png, webp).")
        return f

    def clean_date_of_birth(self):
        dob = self.cleaned_data.get('date_of_birth')
        if not dob:
            return dob
        if dob > timezone.now().date():
            raise forms.ValidationError("La date de naissance ne peut pas être dans le futur.")
        # Optionnel : interdire des dates irréalistes (avant 1900)
        if dob.year < 1900:
            raise forms.ValidationError("Merci de saisir une date réaliste (≥ 1900).")
        return dob

    def clean_phone_number(self):
        phone = (self.cleaned_data.get('phone_number') or '').strip()
        if not phone:
            return phone
        # Nettoyage simple : on retire espaces, points, tirets
        normalized = re.sub(r"[.\s\-()]", "", phone)
        # Vérif très souple (commence par + ou chiffre, au moins 6-7 chiffres)
        if not re.match(r"^\+?\d{6,}$", normalized):
            raise forms.ValidationError("Numéro de téléphone invalide.")
        return normalized


class CustomSignupForm(SignupForm):
    """
    Formulaire d’inscription Allauth enrichi pour demander le prénom et le nom.
    """
    first_name = forms.CharField(
        max_length=30,
        label="Prénom",
        widget=forms.TextInput(attrs={'placeholder': 'Prénom'}),
    )
    last_name = forms.CharField(
        max_length=30,
        label="Nom",
        widget=forms.TextInput(attrs={'placeholder': 'Nom'}),
    )

    def clean_first_name(self):
        return (self.cleaned_data.get('first_name') or '').strip()

    def clean_last_name(self):
        return (self.cleaned_data.get('last_name') or '').strip()

    def save(self, request):
        # Crée l'utilisateur via Allauth (gère email/password/username selon ta config)
        user = super().save(request)
        # Complète prénom/nom ; le profile sera créé par signal
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.save(update_fields=["first_name", "last_name"])
        return user


class CustomLoginForm(LoginForm):
    login = forms.CharField(
        label="Identifiant",
        widget=forms.TextInput(attrs={
            'placeholder': "Email ou nom d'utilisateur",
            'class': 'form-control',
            'autocomplete': 'username',
        }),
        help_text="Saisissez votre e-mail ou votre nom d’utilisateur"
    )
    password = forms.CharField(
        label="Mot de passe",
        widget=forms.PasswordInput(attrs={
            'placeholder': '••••••••',
            'class': 'form-control',
            'autocomplete': 'current-password',
        })
    )
