from django.apps import AppConfig


class UsersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko.users'

    def ready(self):
        import jeiko.users.signals

