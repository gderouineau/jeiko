from django.urls import path
from jeiko.users.views import (

    ProfileDetailView,
    ProfileUpdateView,
)

app_name = 'jeiko_users'

urlpatterns = [


    # Profil utilisateur
    path('profile/', ProfileDetailView.as_view(), name='profile-detail'),
    path('profile/edit/', ProfileUpdateView.as_view(), name='profile-edit'),
]