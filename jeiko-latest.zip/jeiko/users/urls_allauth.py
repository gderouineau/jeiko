from django.urls import path
from jeiko.users.views_allauth import (
    CustomSignupView,
    CustomLoginView,
    CustomLogoutView,

)

app_name = 'jeiko_allauth'

urlpatterns = [
    # Inscription / connexion / déconnexion
    path('signup/', CustomSignupView.as_view(), name='signup'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', CustomLogoutView.as_view(), name='logout'),


]