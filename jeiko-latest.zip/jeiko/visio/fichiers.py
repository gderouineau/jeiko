"""
Les fichiers déposés dans une salle (VISIO-01, V2).

Qui dépose : qui peut parler (hôte, intervenant, participant d'une réunion,
spectateur à qui l'hôte a donné la parole). Qui télécharge : tout invité de
la salle, par son lien — personne d'autre.

Ce qui protège un fichier déposé :
* une liste de formats permis — documents, tableurs, présentations, images,
  PDF, archives ; jamais de HTML, de SVG ni de script, qui s'exécuteraient
  dans l'origine du site ;
* un plafond de poids (`JEIKO_VISIO_FICHIER_MO`, 20 Mo par défaut) ; au-dessus,
  nginx refuse déjà au-delà de 25 Mo ;
* un nom imprévisible sur le disque, sous `/media/visio/` que nginx ferme ;
  le fichier est servi par X-Accel-Redirect (`/protected-media/`, comme les
  supports de formation) après contrôle du lien, toujours en TÉLÉCHARGEMENT
  et avec `nosniff` : jamais affiché dans la page.

Ce que cela ne fait pas : analyser le contenu (un PDF peut porter du
JavaScript, un document des macros). Ce sont des fichiers entre personnes
invitées, comme une pièce jointe d'e-mail.
"""
import os

from django.conf import settings
from django.http import FileResponse, HttpResponse
from django.utils.encoding import iri_to_uri
from django.utils.translation import gettext as _

EXTENSIONS = {
    ".pdf", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".txt", ".csv", ".md",
    ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".ods", ".odp", ".rtf",
    ".zip", ".mp3", ".m4a", ".mp4",
}


class FichierRefuse(Exception):
    pass


def plafond_mo():
    return int(getattr(settings, "JEIKO_VISIO_FICHIER_MO", 20) or 20)


def deposer(invitation, televerse):
    """Enregistre le fichier et l'annonce dans le chat. Rend le message d'annonce."""
    from . import livekit
    from .models import FichierDeSalle, MessageDeChat

    nom = os.path.basename(televerse.name or "")[:200] or "fichier"
    extension = os.path.splitext(nom)[1].lower()
    if extension not in EXTENSIONS:
        raise FichierRefuse(_("Format non accepté. Formats permis : %(liste)s.") % {
            "liste": ", ".join(sorted(e.lstrip(".") for e in EXTENSIONS))})
    if televerse.size > plafond_mo() * 1024 * 1024:
        raise FichierRefuse(_("Fichier trop lourd : %(max)s Mo au plus.") % {"max": plafond_mo()})
    if extension == ".pdf":
        from jeiko.uploads import SIGNATURE_PDF

        debut = televerse.read(len(SIGNATURE_PDF))
        televerse.seek(0)
        if not debut.startswith(SIGNATURE_PDF):
            raise FichierRefuse(_("Ce fichier ne semble pas être un PDF."))
    fichier = FichierDeSalle(salle=invitation.salle, auteur=invitation, nom=nom, taille=televerse.size)
    fichier.fichier.save(nom, televerse, save=False)
    fichier.save()
    from .acces import lieu

    groupe, nom_livekit = lieu(invitation)
    message = MessageDeChat.objects.create(salle=invitation.salle, auteur=invitation, nom=invitation.nom,
                                           texte=nom, fichier=fichier, sous_salle=groupe)
    livekit.diffuser(nom_livekit, "chat", message.en_donnees())
    return message


def servir(fichier):
    """Le fichier, en téléchargement, par nginx (X-Accel) ou, en développement, par Django."""
    from urllib.parse import quote

    disposition = f"attachment; filename*=UTF-8''{quote(fichier.nom)}"
    prefixe = getattr(settings, "COURSES_XACCEL_MEDIA_PREFIX", None)
    if prefixe:
        reponse = HttpResponse(content_type="application/octet-stream")
        reponse["X-Accel-Redirect"] = iri_to_uri(prefixe.rstrip("/") + "/" + fichier.fichier.name.lstrip("/"))
    else:
        reponse = FileResponse(fichier.fichier.open("rb"), content_type="application/octet-stream")
    reponse["Content-Disposition"] = disposition
    reponse["X-Content-Type-Options"] = "nosniff"
    return reponse
