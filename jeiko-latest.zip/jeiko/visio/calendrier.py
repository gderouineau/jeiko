"""
Les rendez-vous « en visio » du calendrier (VISIO-01).

Un type de rendez-vous coché « En visio » (`AppointmentType.en_visio`) a lieu
dans la visio du site :

* un rendez-vous en TÊTE-À-TÊTE a sa salle (`Salle.rendez_vous`), format
  rendez-vous ;
* un cours COLLECTIF (plus d'une place par créneau) a une salle par
  créneau (`Salle.creneau`), format conférence : le praticien sur scène,
  les inscrits en spectateurs, la parole donnée à la main levée.

Le praticien (`type.user`) en est l'hôte ; chaque réservation reçoit son lien
personnel. Pas de salle d'attente : seuls des inscrits ont un lien.

La salle naît à la PREMIÈRE demande de lien (confirmation, rappel, page du
compte) et suit l'horaire du rendez-vous s'il est déplacé. Une annulation
révoque le lien de la réservation — et ferme la salle d'un tête-à-tête.

Ne lève jamais : une visio en panne ne doit pas bloquer une réservation ni
un e-mail de rendez-vous.
"""
import logging

from django.db import transaction

logger = logging.getLogger(__name__)


def _en_visio(appt):
    return bool(appt.type_id and appt.type.en_visio)


def salle_du_rendez_vous(appt, creer=True):
    """La salle d'un rendez-vous en visio (créée au besoin), ou None."""
    if not _en_visio(appt):
        return None
    with transaction.atomic():
        return _salle(appt, creer)


def _salle(appt, creer):
    from .acces import creer_salle, inviter
    from .models import Invitation, Salle

    collectif = (appt.type.capacity or 1) > 1 and appt.slot_id
    if collectif:
        # Deux réservations simultanées ne font pas deux salles : le créneau
        # est verrouillé le temps de chercher et de créer.
        from jeiko.calendars.models import Slot

        Slot.objects.select_for_update().filter(pk=appt.slot_id).first()
        salle = Salle.objects.filter(creneau_id=appt.slot_id).first()
        debut, fin = appt.slot.start, appt.slot.end
    else:
        salle = Salle.objects.filter(rendez_vous=appt).first()
        debut, fin = appt.start, appt.end
    if salle is None:
        if not creer:
            return None
        lien = {"creneau_id": appt.slot_id} if collectif else {"rendez_vous": appt}
        salle = creer_salle(
            titre=appt.type.name if collectif else f"{appt.type.name} — {appt.client_name or appt.email}"[:200],
            debut=debut, fin=fin, hote=False, salle_d_attente=False,
            format=Salle.Format.CONFERENCE if collectif else Salle.Format.RENDEZ_VOUS, **lien)
        if appt.type.user_id:
            inviter(salle, user=appt.type.user, role=Invitation.Role.HOTE)
    elif (salle.debut, salle.fin) != (debut, fin):
        # Le rendez-vous a été déplacé : la salle suit.
        salle.debut, salle.fin = debut, fin
        salle.save(update_fields=["debut", "fin"])
    return salle


def invitation_du_client(appt, creer=True):
    from .acces import inviter
    from .models import Invitation

    salle = salle_du_rendez_vous(appt, creer=creer)
    if salle is None or not (appt.email or appt.user_id):
        return None
    if not creer:
        # Sans compte à la réservation, l'invitation a pu retrouver le compte
        # par l'adresse (`inviter`) : on la cherche donc par l'adresse.
        filtre = {"user": appt.user} if appt.user_id else {"email__iexact": appt.email}
        return salle.invitations_actives().filter(role=Invitation.Role.PARTICIPANT, **filtre).first()
    return inviter(salle, nom=appt.client_name or "", email=appt.email or "", user=appt.user,
                   role=Invitation.Role.PARTICIPANT)


def lien_visio(appt, *, pour_le_client=True):
    """Le lien absolu de la visio d'un rendez-vous ("" s'il n'est pas en visio). Ne lève jamais."""
    from jeiko.emailing.admin_alerts import _lien_absolu

    from .models import Invitation

    try:
        if not _en_visio(appt) or getattr(appt, "is_cancelled", False):
            return ""
        if pour_le_client:
            invitation = invitation_du_client(appt)
        else:
            salle = salle_du_rendez_vous(appt)
            invitation = salle.invitations_actives().filter(role=Invitation.Role.HOTE).first() if salle else None
        return _lien_absolu("jeiko_visio:salle", invitation.code) if invitation else ""
    except Exception:
        logger.exception("Visio du rendez-vous #%s indisponible", appt.pk)
        return ""


def envoyer_le_lien(appt):
    """L'e-mail d'invitation au client d'un rendez-vous en visio, une fois. Ne lève jamais."""
    from .emails import envoyer_l_invitation

    try:
        if not _en_visio(appt):
            return
        invitation = invitation_du_client(appt)
        if invitation is not None and not invitation.envoyee_le:
            envoyer_l_invitation(invitation)
    except Exception:
        logger.exception("Visio du rendez-vous #%s : lien non envoyé", appt.pk)


def au_rendez_vous_annule(appt):
    """Révoque le lien de la réservation ; un tête-à-tête ferme aussi sa salle. Ne lève jamais."""
    from . import acces

    try:
        invitation = invitation_du_client(appt, creer=False)
        if invitation is not None:
            acces.revoquer(invitation)
        salle = salle_du_rendez_vous(appt, creer=False)
        if salle is not None and salle.rendez_vous_id == appt.pk and not salle.terminee:
            acces.terminer(salle)
    except Exception:
        logger.exception("Visio du rendez-vous annulé #%s : lien non révoqué", appt.pk)
