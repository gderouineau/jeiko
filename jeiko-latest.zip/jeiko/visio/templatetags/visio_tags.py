"""
La visio dans les gabarits du calendrier et du compte (VISIO-01).

    {% load visio_tags %}
    {% lien_visio appt as lien %}      — le lien personnel du client
    {% salle_visio appt as salle %}    — la séance, côté praticien

Rien hors des rendez-vous « en visio » ; jamais d'erreur dans la page.
"""
from django import template

register = template.Library()


@register.simple_tag
def lien_visio(appt):
    from jeiko.visio.calendrier import invitation_du_client

    try:
        if not appt.en_visio or appt.is_cancelled:
            return ""
        invitation = invitation_du_client(appt)
        return invitation.get_absolute_url() if invitation else ""
    except Exception:
        return ""


@register.simple_tag
def salle_visio(appt):
    from jeiko.visio.calendrier import salle_du_rendez_vous

    try:
        return None if appt.is_cancelled else salle_du_rendez_vous(appt)
    except Exception:
        return None
