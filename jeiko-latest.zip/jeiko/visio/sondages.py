"""
Les sondages d'une séance (VISIO-01, V2).

L'hôte prépare (à l'avance dans la fiche, ou en direct), lance, clôt. Lancer
diffuse la question à toute la salle ; chacun vote une fois (et peut changer
d'avis tant que c'est ouvert) ; clore diffuse les résultats. Un seul sondage
ouvert à la fois : en lancer un autre clôt le précédent.

Concurrence (VISIO-03) : lancer verrouille la séance — deux lancements
simultanés ne laissent jamais deux sondages ouverts ; voter et clore
verrouillent le sondage — un vote arrivé pendant la clôture est refusé, pas
compté en douce après les résultats.

Groupes de travail : un sondage lancé pendant que les groupes sont ouverts
est diffusé aussi dans chaque groupe — chacun y vote comme dans la salle
principale. Ce qui n'existe pas : un sondage propre à UN groupe.

Qui vote : tout invité admis dans la salle, hôtes compris. Les votes sont
gardés par invitation (une voix chacun) ; ni l'écran ni l'API ne disent qui a
voté quoi — seulement les totaux.
"""
from django.db import transaction
from django.utils import timezone
from django.utils.translation import gettext as _

from . import livekit
from .acces import Refus
from .models import Sondage, Vote

MAX_CHOIX = 8


def preparer(salle, question, choix, plusieurs=False):
    if not isinstance(question, (str, type(None))) or not isinstance(choix, (list, tuple, type(None))):
        raise Refus(_("La question est un texte, les choix une liste."))
    question = (question or "").strip()[:300]
    choix = [str(c).strip()[:120] for c in (choix or []) if str(c).strip()]
    if not question:
        raise Refus(_("La question est vide."))
    if not 2 <= len(choix) <= MAX_CHOIX:
        raise Refus(_("Entre 2 et %(n)s choix.") % {"n": MAX_CHOIX})
    return Sondage.objects.create(salle=salle, question=question, choix=choix, plusieurs=bool(plusieurs))


def _diffuser(sondage):
    salle = sondage.salle
    donnees = sondage.en_donnees()
    if salle.groupes_ouverts:
        for groupe in salle.sous_salles.filter(archivee=False):
            try:
                livekit.diffuser(groupe.identifiant_livekit, "sondage", donnees)
            except livekit.LiveKitIndisponible:
                pass  # la liste des sondages se relit : le groupe le verra à la suivante
    livekit.diffuser(salle.identifiant_livekit, "sondage", donnees)


def lancer(sondage):
    from .models import Salle

    with transaction.atomic():
        Salle.objects.select_for_update().filter(pk=sondage.salle_id).first()
        clos = []
        for ouvert in sondage.salle.sondages.select_for_update().filter(etat=Sondage.Etat.OUVERT).exclude(pk=sondage.pk):
            ouvert.etat, ouvert.clos_le = Sondage.Etat.CLOS, timezone.now()
            ouvert.save(update_fields=["etat", "clos_le"])
            clos.append(ouvert)
        sondage.etat, sondage.ouvert_le, sondage.clos_le = Sondage.Etat.OUVERT, timezone.now(), None
        sondage.save(update_fields=["etat", "ouvert_le", "clos_le"])
    for ouvert in clos:
        _diffuser(ouvert)
    _diffuser(sondage)


def clore(sondage):
    with transaction.atomic():
        Sondage.objects.select_for_update().filter(pk=sondage.pk).first()
        sondage.etat, sondage.clos_le = Sondage.Etat.CLOS, timezone.now()
        sondage.save(update_fields=["etat", "clos_le"])
    _diffuser(sondage)


@transaction.atomic
def voter(sondage, invitation, choix):
    # Relu sous verrou : une clôture en cours passe avant, ou attend ce vote.
    sondage = Sondage.objects.select_for_update().get(pk=sondage.pk)
    if sondage.etat != Sondage.Etat.OUVERT:
        raise Refus(_("Ce sondage n'est pas ouvert."))
    try:
        retenus = sorted({int(c) for c in (choix or [])})
    except (TypeError, ValueError):
        raise Refus(_("Choix invalide."))
    if not retenus or any(not 0 <= c < len(sondage.choix) for c in retenus):
        raise Refus(_("Choix invalide."))
    if len(retenus) > 1 and not sondage.plusieurs:
        raise Refus(_("Un seul choix possible."))
    Vote.objects.update_or_create(sondage=sondage, invitation=invitation, defaults={"choix": retenus})
