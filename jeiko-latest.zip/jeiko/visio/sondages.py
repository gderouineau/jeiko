"""
Les sondages d'une séance (VISIO-01, V2).

L'hôte prépare (à l'avance dans la fiche, ou en direct), lance, clôt. Lancer
diffuse la question à toute la salle ; chacun vote une fois (et peut changer
d'avis tant que c'est ouvert) ; clore diffuse les résultats. Un seul sondage
ouvert à la fois : en lancer un autre clôt le précédent.

Qui vote : tout invité admis dans la salle, hôtes compris. Les votes sont
gardés par invitation (une voix chacun) ; ni l'écran ni l'API ne disent qui a
voté quoi — seulement les totaux.
"""
from django.db import transaction
from django.utils import timezone
from django.utils.translation import gettext as _

from . import livekit
from .acces import Refus
from .models import Sondage, Vote

MAX_CHOIX = 8


def preparer(salle, question, choix, plusieurs=False):
    question = (question or "").strip()[:300]
    choix = [str(c).strip()[:120] for c in (choix or []) if str(c).strip()]
    if not question:
        raise Refus(_("La question est vide."))
    if not 2 <= len(choix) <= MAX_CHOIX:
        raise Refus(_("Entre 2 et %(n)s choix.") % {"n": MAX_CHOIX})
    return Sondage.objects.create(salle=salle, question=question, choix=choix, plusieurs=bool(plusieurs))


def _diffuser(sondage):
    livekit.diffuser(sondage.salle.identifiant_livekit, "sondage", sondage.en_donnees())


def lancer(sondage):
    with transaction.atomic():
        for ouvert in sondage.salle.sondages.filter(etat=Sondage.Etat.OUVERT).exclude(pk=sondage.pk):
            clore(ouvert)
        sondage.etat, sondage.ouvert_le, sondage.clos_le = Sondage.Etat.OUVERT, timezone.now(), None
        sondage.save(update_fields=["etat", "ouvert_le", "clos_le"])
    _diffuser(sondage)


def clore(sondage):
    sondage.etat, sondage.clos_le = Sondage.Etat.CLOS, timezone.now()
    sondage.save(update_fields=["etat", "clos_le"])
    _diffuser(sondage)


def voter(sondage, invitation, choix):
    if sondage.etat != Sondage.Etat.OUVERT:
        raise Refus(_("Ce sondage n'est pas ouvert."))
    try:
        retenus = sorted({int(c) for c in (choix or [])})
    except (TypeError, ValueError):
        raise Refus(_("Choix invalide."))
    if not retenus or any(not 0 <= c < len(sondage.choix) for c in retenus):
        raise Refus(_("Choix invalide."))
    if len(retenus) > 1 and not sondage.plusieurs:
        raise Refus(_("Un seul choix possible."))
    Vote.objects.update_or_create(sondage=sondage, invitation=invitation, defaults={"choix": retenus})
