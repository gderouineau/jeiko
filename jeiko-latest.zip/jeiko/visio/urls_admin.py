from django.urls import path

from . import vues_admin as vues

app_name = "jeiko_visio_admin"

urlpatterns = [
    path("", vues.Seances.as_view(), name="seances"),
    path("nouvelle/", vues.NouvelleSeance.as_view(), name="nouvelle"),
    path("serveur/", vues.Serveur.as_view(), name="serveur"),
    path("<int:pk>/", vues.Fiche.as_view(), name="fiche"),
    path("<int:pk>/inviter/", vues.Inviter.as_view(), name="inviter"),
    path("<int:pk>/inscriptions/", vues.Inscriptions.as_view(), name="inscriptions"),
    path("<int:pk>/entrer/", vues.Entrer.as_view(), name="entrer"),
    path("<int:pk>/supprimer/", vues.Supprimer.as_view(), name="supprimer"),
    path("<int:pk>/presence.csv", vues.PresenceCsv.as_view(), name="presence_csv"),
    path("<int:pk>/ecrire/", vues.EcrireAuxInvites.as_view(), name="ecrire"),
    path("<int:pk>/fichiers/<int:fichier_pk>/", vues.FichierDeLaSeance.as_view(), name="fichier"),
    path("<int:pk>/sondages/", vues.PreparerSondage.as_view(), name="preparer_sondage"),
    path("<int:pk>/invitations/<int:invitation_pk>/<str:action>/", vues.ActionSurUneInvitation.as_view(),
         name="invitation"),
]
