"""
La visio dans le droit d'accès et le droit à l'effacement (VISIO-01).

Une personne invitée laisse : ses invitations (nom, adresse, présence) et ce
qu'elle a écrit dans le chat. On les retrouve par son compte ET par son
adresse — un contact sans compte n'a que l'adresse.

À l'effacement, l'invitation est ANONYMISÉE et révoquée plutôt que
supprimée : la séance garde son nombre d'invités et de présents, sans plus
dire qui. Les messages qu'elle a écrits et les fichiers qu'elle a déposés
sont supprimés — ce sont ses mots et ses documents. Une place en liste
d'attente est supprimée.
"""
from django.db.models import Q
from django.utils import timezone


def _invitations(user=None, email=""):
    from .models import Invitation

    filtre = Q(pk__in=[])
    if user is not None and user.pk:
        filtre |= Q(user=user)
    if email:
        filtre |= Q(email__iexact=email)
    return Invitation.objects.filter(filtre).select_related("salle")


def export_de(user=None, email=""):
    lignes = []
    for i in _invitations(user, email):
        lignes.append({
            "seance": i.salle.titre, "debut": i.salle.debut.isoformat(), "role": i.get_role_display(),
            "nom": i.nom, "email": i.email,
            "arrivee": i.arrivee_le.isoformat() if i.arrivee_le else None,
            "sortie": i.sortie_le.isoformat() if i.sortie_le else None,
            "messages": [{"date": m.envoye_le.isoformat(), "texte": m.texte} for m in i.messages.all()],
            "fichiers_deposes": [f.nom for f in i.fichiers.all()],
            "inscrite": i.inscrite, "montant_paye": str(i.montant_paye),
            "desinscrite_le": i.desinscrite_le.isoformat() if i.desinscrite_le else None,
        })
    for a in _attentes(user, email):
        lignes.append({"seance": a.salle.titre, "debut": a.salle.debut.isoformat(), "liste_d_attente": True,
                       "nom": a.nom, "email": a.email, "depuis": a.cree_le.isoformat()})
    return lignes


def _attentes(user=None, email=""):
    from .models import Attente

    filtre = Q(pk__in=[])
    if user is not None and user.pk:
        filtre |= Q(user=user)
    if email:
        filtre |= Q(email__iexact=email)
    return Attente.objects.filter(filtre).select_related("salle")


def effacer_de(user=None, email=""):
    """Rend le nombre d'invitations anonymisées."""
    from .models import FichierDeSalle, MessageDeChat

    invitations = _invitations(user, email)
    _attentes(user, email).delete()
    MessageDeChat.objects.filter(auteur__in=invitations).delete()
    # Ses fichiers aussi — et du disque (signal post_delete).
    for fichier in FichierDeSalle.objects.filter(auteur__in=invitations):
        fichier.delete()
    return invitations.update(nom="—", email="", user=None, contact=None,
                              revoquee_le=timezone.now())
