"""
VISIO-03 (17/10/2026) : l'organisateur annule une séance — grille de
remboursement par délai, figée à l'achat ; e-mail `visio_annulee` posé s'il
manque, sans rien écraser.
"""
from django.db import migrations, models

import jeiko.visio.models


def poser(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    apply_seed("visio_annulee", force=False)


class Migration(migrations.Migration):
    dependencies = [
        ("visio", "0014_evenements_et_remboursements"),
    ]
    operations = [
        migrations.AddField(
            model_name="salle", name="remboursement_annulation",
            field=models.JSONField(blank=True, default=jeiko.visio.models._tout_rembourser,
                                   verbose_name="Remboursement si la séance est annulée")),
        migrations.AddField(
            model_name="salle", name="annulee_le",
            field=models.DateTimeField(blank=True, null=True, verbose_name="Annulée le")),
        migrations.AddField(
            model_name="salle", name="motif_annulation",
            field=models.CharField(blank=True, max_length=500, verbose_name="Motif de l'annulation")),
        migrations.AddField(
            model_name="invitation", name="remboursement_annulation",
            field=models.JSONField(blank=True, null=True)),
        migrations.RunPython(poser, migrations.RunPython.noop),
    ]
