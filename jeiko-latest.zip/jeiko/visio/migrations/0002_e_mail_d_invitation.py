"""
`visio_invitation` : l'e-mail qui porte le lien personnel d'un invité
(VISIO-01, 12/10/2026). Pose son contenu par défaut s'il manque, sans rien
écraser.
"""
from django.db import migrations


def poser(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    apply_seed("visio_invitation", force=False)


class Migration(migrations.Migration):
    dependencies = [
        ("visio", "0001_initial"),
        ("emailing", "0013_rebonds"),
    ]
    operations = [migrations.RunPython(poser, migrations.RunPython.noop)]
