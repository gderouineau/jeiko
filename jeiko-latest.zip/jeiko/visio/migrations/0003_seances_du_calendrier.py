# VISIO-01 — séances nées du calendrier (12/10/2026).

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('calendars', '0023_type_en_visio'),
        ('visio', '0002_e_mail_d_invitation'),
    ]

    operations = [
        migrations.AddField(
            model_name='salle',
            name='creneau',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='salles_visio', to='calendars.slot', verbose_name='Créneau'),
        ),
        migrations.AddField(
            model_name='salle',
            name='rendez_vous',
            field=models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='salle_visio', to='calendars.appointment', verbose_name='Rendez-vous'),
        ),
    ]
