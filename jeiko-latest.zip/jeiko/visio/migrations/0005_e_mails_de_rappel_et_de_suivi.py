"""
`visio_rappel` (la veille, une heure avant) et `visio_message` (un message
de l'hôte aux invités, absents compris) : VISIO-01, V2, 12/10/2026. Pose
leur contenu par défaut s'il manque, sans rien écraser.
"""
from django.db import migrations


def poser(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    for code in ("visio_rappel", "visio_message"):
        apply_seed(code, force=False)


class Migration(migrations.Migration):
    dependencies = [
        ("visio", "0004_rappels_et_presences"),
    ]
    operations = [migrations.RunPython(poser, migrations.RunPython.noop)]
