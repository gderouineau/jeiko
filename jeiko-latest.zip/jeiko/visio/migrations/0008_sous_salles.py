# VISIO-01, V2 — sous-salles (12/10/2026).

import django.db.models.deletion
import uuid
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('visio', '0007_sondages'),
    ]

    operations = [
        migrations.AddField(
            model_name='salle',
            name='groupes_fin_le',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='salle',
            name='groupes_ouverts',
            field=models.BooleanField(default=False),
        ),
        migrations.CreateModel(
            name='SousSalle',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('numero', models.PositiveSmallIntegerField()),
                ('nom_livekit', models.UUIDField(default=uuid.uuid4, editable=False, unique=True)),
                ('salle', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='sous_salles', to='visio.salle')),
            ],
            options={
                'verbose_name': 'Groupe de travail',
                'verbose_name_plural': 'Groupes de travail',
                'ordering': ['numero'],
            },
        ),
        migrations.AddField(
            model_name='invitation',
            name='sous_salle',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='membres', to='visio.soussalle'),
        ),
        migrations.AddField(
            model_name='messagedechat',
            name='sous_salle',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='messages', to='visio.soussalle'),
        ),
    ]
