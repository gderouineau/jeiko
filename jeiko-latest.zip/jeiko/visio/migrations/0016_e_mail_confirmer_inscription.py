"""
`visio_confirmer_inscription` (VISIO-03, 17/10/2026) : une inscription gratuite
sans compte vérifié confirme d'abord son adresse. Pose le contenu par défaut
s'il manque, sans rien écraser.
"""
from django.db import migrations


def poser(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    apply_seed("visio_confirmer_inscription", force=False)


class Migration(migrations.Migration):
    dependencies = [
        ("visio", "0015_annulation_par_l_organisateur"),
    ]
    operations = [migrations.RunPython(poser, migrations.RunPython.noop)]
