# VISIO-01, V2 — sondages (12/10/2026).

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('visio', '0006_fichiers_de_salle'),
    ]

    operations = [
        migrations.CreateModel(
            name='Sondage',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('question', models.CharField(max_length=300, verbose_name='Question')),
                ('choix', models.JSONField(default=list, verbose_name='Choix')),
                ('plusieurs', models.BooleanField(default=False, verbose_name='Plusieurs réponses possibles')),
                ('etat', models.CharField(choices=[('prepare', 'Préparé'), ('ouvert', 'Ouvert'), ('clos', 'Clos')], default='prepare', max_length=10)),
                ('cree_le', models.DateTimeField(auto_now_add=True)),
                ('ouvert_le', models.DateTimeField(blank=True, null=True)),
                ('clos_le', models.DateTimeField(blank=True, null=True)),
                ('salle', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='sondages', to='visio.salle')),
            ],
            options={
                'verbose_name': 'Sondage de visio',
                'verbose_name_plural': 'Sondages de visio',
                'ordering': ['cree_le', 'pk'],
            },
        ),
        migrations.CreateModel(
            name='Vote',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('choix', models.JSONField(default=list)),
                ('vote_le', models.DateTimeField(auto_now=True)),
                ('invitation', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='votes', to='visio.invitation')),
                ('sondage', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='votes', to='visio.sondage')),
            ],
            options={
                'constraints': [models.UniqueConstraint(fields=('sondage', 'invitation'), name='visio_un_vote_par_personne')],
            },
        ),
    ]
