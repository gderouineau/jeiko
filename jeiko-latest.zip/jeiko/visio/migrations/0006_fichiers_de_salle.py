# VISIO-01, V2 — fichiers déposés dans une salle (12/10/2026).

import django.db.models.deletion
import jeiko.visio.models
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('visio', '0005_e_mails_de_rappel_et_de_suivi'),
    ]

    operations = [
        migrations.CreateModel(
            name='FichierDeSalle',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nom', models.CharField(max_length=200, verbose_name='Nom')),
                ('fichier', models.FileField(max_length=255, upload_to=jeiko.visio.models._chemin_du_fichier)),
                ('taille', models.PositiveBigIntegerField(default=0)),
                ('depose_le', models.DateTimeField(auto_now_add=True)),
                ('auteur', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='fichiers', to='visio.invitation')),
                ('salle', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='fichiers', to='visio.salle')),
            ],
            options={
                'verbose_name': 'Fichier de visio',
                'verbose_name_plural': 'Fichiers de visio',
                'ordering': ['depose_le'],
            },
        ),
        migrations.AddField(
            model_name='messagedechat',
            name='fichier',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='annonces', to='visio.fichierdesalle'),
        ),
    ]
