"""
V2-E — la séance à inscription, gratuite ou vendue (visio/vente.py) : places,
prix, liste d'attente, remboursement, produit de la boutique, page publique.

`jeton_public` est un UUID unique ajouté à une table qui a déjà des lignes :
ajouté tel quel, toutes recevraient la MÊME valeur (le défaut n'est calculé
qu'une fois) et l'unicité casserait. Comme Django le documente : nullable,
rempli ligne à ligne, puis unique.
"""
import decimal
import uuid

import django.core.validators
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


def remplir_les_jetons(apps, schema_editor):
    Salle = apps.get_model("visio", "Salle")
    for salle in Salle.objects.filter(jeton_public__isnull=True).only("pk"):
        Salle.objects.filter(pk=salle.pk).update(jeton_public=uuid.uuid4())


class Migration(migrations.Migration):
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("shop", "0026_credits_de_seance"),
        ("visio", "0008_sous_salles"),
    ]

    operations = [
        migrations.AddField(
            model_name="salle", name="inscriptions",
            field=models.BooleanField(default=False, help_text="Une page publique où chacun s'inscrit — ou achète sa place — et reçoit son lien personnel.", verbose_name="Inscriptions ouvertes au public"),
        ),
        migrations.AddField(
            model_name="salle", name="places",
            field=models.PositiveSmallIntegerField(blank=True, null=True, help_text="Vide : jusqu'au plafond de 50 personnes par séance, hôtes compris.", validators=[django.core.validators.MinValueValidator(1), django.core.validators.MaxValueValidator(50)], verbose_name="Places"),
        ),
        migrations.AddField(
            model_name="salle", name="prix",
            field=models.DecimalField(decimal_places=2, default=decimal.Decimal("0"), help_text="0 : inscription gratuite. Au-delà, la place se paie par la boutique du site.", max_digits=10, validators=[django.core.validators.MinValueValidator(0)], verbose_name="Prix TTC"),
        ),
        migrations.AddField(
            model_name="salle", name="liste_d_attente",
            field=models.BooleanField(default=True, help_text="Séance complète : on peut s'inscrire en attente. Une place libérée prévient toute la liste par e-mail ; le premier qui s'inscrit la prend.", verbose_name="Liste d'attente"),
        ),
        migrations.AddField(
            model_name="salle", name="remboursement",
            field=models.JSONField(blank=True, default=list, verbose_name="Remboursement à la désinscription"),
        ),
        migrations.AddField(
            model_name="salle", name="produit",
            field=models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="salle_visio", to="shop.product", verbose_name="Produit de la boutique"),
        ),
        migrations.AddField(
            model_name="salle", name="jeton_public",
            field=models.UUIDField(editable=False, null=True),
        ),
        migrations.RunPython(remplir_les_jetons, migrations.RunPython.noop),
        migrations.AlterField(
            model_name="salle", name="jeton_public",
            field=models.UUIDField(default=uuid.uuid4, editable=False, unique=True),
        ),
        migrations.AddField(
            model_name="invitation", name="inscrite",
            field=models.BooleanField(default=False, verbose_name="Inscrite par la page publique"),
        ),
        migrations.AddField(
            model_name="invitation", name="commande",
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="invitations_visio", to="shop.order", verbose_name="Commande"),
        ),
        migrations.AddField(
            model_name="invitation", name="montant_paye",
            field=models.DecimalField(decimal_places=2, default=decimal.Decimal("0"), max_digits=10, verbose_name="Montant payé"),
        ),
        migrations.AddField(
            model_name="invitation", name="desinscrite_le",
            field=models.DateTimeField(blank=True, null=True, verbose_name="Désinscrite le"),
        ),
        migrations.CreateModel(
            name="Attente",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("nom", models.CharField(max_length=200, verbose_name="Nom")),
                ("email", models.EmailField(max_length=254, verbose_name="E-mail")),
                ("cree_le", models.DateTimeField(auto_now_add=True)),
                ("prevenue_le", models.DateTimeField(blank=True, null=True, verbose_name="Prévenue le")),
                ("salle", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="attentes", to="visio.salle")),
                ("user", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="attentes_visio", to=settings.AUTH_USER_MODEL)),
            ],
            options={
                "verbose_name": "Liste d'attente de visio",
                "verbose_name_plural": "Listes d'attente de visio",
                "ordering": ["cree_le", "pk"],
                "constraints": [models.UniqueConstraint(fields=("salle", "email"), name="visio_une_attente_par_adresse")],
            },
        ),
    ]
