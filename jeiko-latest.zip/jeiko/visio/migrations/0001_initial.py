# VISIO-01 — salles, invitations, chat (12/10/2026).

import django.core.validators
import django.db.models.deletion
import jeiko.visio.models
import uuid
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('questionnaires_expert', '0023_origine_visio'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Invitation',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('role', models.CharField(choices=[('hote', 'Hôte'), ('intervenant', 'Intervenant'), ('participant', 'Spectateur / participant')], default='participant', max_length=20, verbose_name='Rôle')),
                ('nom', models.CharField(max_length=200, verbose_name='Nom affiché')),
                ('email', models.EmailField(blank=True, max_length=254, verbose_name='E-mail')),
                ('code', models.CharField(default=jeiko.visio.models._nouveau_code, editable=False, max_length=64, unique=True)),
                ('revoquee_le', models.DateTimeField(blank=True, null=True, verbose_name='Révoquée le')),
                ('admise', models.BooleanField(default=False)),
                ('attente_vue_le', models.DateTimeField(blank=True, null=True)),
                ('parole', models.BooleanField(default=False)),
                ('envoyee_le', models.DateTimeField(blank=True, null=True, verbose_name='Invitation envoyée le')),
                ('arrivee_le', models.DateTimeField(blank=True, null=True, verbose_name='Arrivée')),
                ('derniere_arrivee_le', models.DateTimeField(blank=True, null=True)),
                ('sortie_le', models.DateTimeField(blank=True, null=True, verbose_name='Sortie')),
                ('cree_le', models.DateTimeField(auto_now_add=True)),
                ('contact', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='invitations_visio', to='questionnaires_expert.prospect', verbose_name='Contact')),
                ('user', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='invitations_visio', to=settings.AUTH_USER_MODEL, verbose_name='Compte')),
            ],
            options={
                'verbose_name': 'Invitation en visio',
                'verbose_name_plural': 'Invitations en visio',
                'ordering': ['role', 'nom'],
            },
        ),
        migrations.CreateModel(
            name='Salle',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('titre', models.CharField(max_length=200, verbose_name='Titre')),
                ('format', models.CharField(choices=[('reunion', 'Réunion — tout le monde parle'), ('conference', 'Conférence — les intervenants parlent, le public écoute'), ('rendez_vous', 'Rendez-vous — en tête-à-tête')], default='reunion', max_length=20, verbose_name='Format')),
                ('description', models.TextField(blank=True, verbose_name='Description')),
                ('debut', models.DateTimeField(db_index=True, verbose_name='Début')),
                ('fin', models.DateTimeField(verbose_name='Fin')),
                ('ouverture_avant', models.PositiveIntegerField(default=30, help_text="Les participants peuvent entrer à partir de ce moment. Avant, leur page sert à régler caméra et micro, et les fait entrer à l'ouverture.", validators=[django.core.validators.MaxValueValidator(1440)], verbose_name='Ouverture avant le début (minutes)')),
                ('salle_d_attente', models.BooleanField(default=True, help_text="Les participants attendent qu'un hôte les fasse entrer. Hôtes et intervenants entrent directement.", verbose_name="Salle d'attente")),
                ('verrouillee', models.BooleanField(default=False, help_text="Plus personne de nouveau n'entre ; les personnes déjà admises peuvent revenir.", verbose_name='Verrouillée')),
                ('qualite', models.CharField(choices=[('economie', 'Économie — 540p, pour les connexions faibles'), ('standard', 'Standard — 720p'), ('haute', 'Haute — 1080p')], default='haute', max_length=10, verbose_name="Qualité de l'image")),
                ('son', models.CharField(choices=[('voix', "Voix — réduction du bruit et de l'écho"), ('musique', 'Musique — haute fidélité, sans filtre')], default='voix', help_text="« Musique » pour un cours de musique ou une séance avec fond sonore : casque conseillé, l'écho n'est plus filtré.", max_length=10, verbose_name='Son')),
                ('nom_livekit', models.UUIDField(default=uuid.uuid4, editable=False, unique=True)),
                ('terminee_le', models.DateTimeField(blank=True, null=True, verbose_name='Terminée le')),
                ('cree_le', models.DateTimeField(auto_now_add=True)),
                ('cree_par', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='salles_visio_creees', to=settings.AUTH_USER_MODEL, verbose_name='Créée par')),
            ],
            options={
                'verbose_name': 'Séance en visio',
                'verbose_name_plural': 'Séances en visio',
                'ordering': ['-debut'],
            },
        ),
        migrations.CreateModel(
            name='MessageDeChat',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nom', models.CharField(max_length=200)),
                ('texte', models.TextField(max_length=2000)),
                ('envoye_le', models.DateTimeField(auto_now_add=True, db_index=True)),
                ('auteur', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='messages', to='visio.invitation')),
                ('salle', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='messages', to='visio.salle')),
            ],
            options={
                'verbose_name': 'Message de chat',
                'verbose_name_plural': 'Messages de chat',
                'ordering': ['envoye_le', 'pk'],
            },
        ),
        migrations.AddField(
            model_name='invitation',
            name='salle',
            field=models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='invitations', to='visio.salle'),
        ),
    ]
