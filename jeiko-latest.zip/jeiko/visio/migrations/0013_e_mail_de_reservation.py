"""
`visio_reservation` : la confirmation d'une place prise sur la page publique
(VISIO-02, 14/10/2026). Pose son contenu par défaut s'il manque, sans rien
écraser.
"""
from django.db import migrations


def poser(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    apply_seed("visio_reservation", force=False)


class Migration(migrations.Migration):
    dependencies = [
        ("visio", "0012_suivi_apres_seance"),
        ("emailing", "0016_rapports_d_activite"),
    ]
    operations = [migrations.RunPython(poser, migrations.RunPython.noop)]
