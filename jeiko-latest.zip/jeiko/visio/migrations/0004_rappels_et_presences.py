# VISIO-01, V2 — rappels et présences (12/10/2026).

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('visio', '0003_seances_du_calendrier'),
    ]

    operations = [
        migrations.AddField(
            model_name='invitation',
            name='rappel_heure_le',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='invitation',
            name='rappel_veille_le',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='salle',
            name='rappels',
            field=models.BooleanField(default=True, help_text='Chaque invité reçoit son lien la veille et une heure avant. Les rendez-vous du calendrier ont déjà leurs propres rappels.', verbose_name='Rappels par e-mail'),
        ),
        migrations.CreateModel(
            name='Presence',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('arrivee', models.DateTimeField(db_index=True, verbose_name='Arrivée')),
                ('sortie', models.DateTimeField(blank=True, null=True, verbose_name='Sortie')),
                ('invitation', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='presences', to='visio.invitation')),
            ],
            options={
                'verbose_name': 'Présence en visio',
                'verbose_name_plural': 'Présences en visio',
                'ordering': ['arrivee'],
            },
        ),
    ]
