"""
`visio_place_liberee` (V2-E, 12/10/2026) : une place libérée prévient la liste
d'attente. Pose son contenu par défaut s'il manque, sans rien écraser.
"""
from django.db import migrations


def poser(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    apply_seed("visio_place_liberee", force=False)


class Migration(migrations.Migration):
    dependencies = [
        ("visio", "0009_seances_a_inscription"),
    ]
    operations = [migrations.RunPython(poser, migrations.RunPython.noop)]
