"""
Les pages publiques d'une séance à inscription (VISIO-01, V2-E) : la page de
la séance (`/visio/seance/<jeton>/`) et la désinscription par le lien
personnel (`/visio/<code>/desinscrire/`).

Gratuit : nom et adresse, puis le lien par e-mail. Payant : la page met le
produit au panier (`jeiko_client_shop:cart_add`) ; la boutique fait le reste
et le paiement inscrit (`vente.inscrire_la_commande`). Complet : liste
d'attente.

Confirmer (VISIO-03) : une inscription gratuite, ou la liste d'attente,
sans compte à l'adresse vérifiée, part d'abord en lien de confirmation
(signé, 48 h). La place n'est prise qu'au clic : une adresse inventée ou
celle d'un autre ne retient plus rien, et personne ne reçoit d'invitation
qu'il n'a pas demandée. Rien n'est gardé en base d'ici là — le lien porte
tout.

Désinscrire, comme confirmer : GET annonce, POST agit — un antivirus qui suit
les liens d'un e-mail ne désinscrit ni n'inscrit personne.
"""
from django.core import signing
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.http import Http404
from django.shortcuts import get_object_or_404, render
from django.utils.translation import gettext as _
from django.views.decorators.cache import never_cache

from jeiko.throttling import honeypot_filled, rate_limited

from . import acces, vente
from .models import Salle
from .vues_publiques import _prive


SEL_CONFIRMATION = "jeiko.visio.confirmation"
VALIDITE = 48 * 3600


@never_cache
def seance(request, jeton):
    salle = get_object_or_404(Salle, jeton_public=jeton, inscriptions=True)
    contexte = {"salle": salle}
    if request.user.is_authenticated:
        contexte.update(nom=request.user.get_full_name(), email=request.user.email)
    if request.method == "POST":
        contexte.update(_inscrire(request, salle))
    return _page(request, salle, contexte)


@never_cache
def confirmer(request, jeton, cle):
    """Le lien de l'e-mail : GET montre un bouton, POST inscrit (ou met en attente)."""
    salle = get_object_or_404(Salle, jeton_public=jeton, inscriptions=True)
    try:
        demande = signing.loads(cle, salt=SEL_CONFIRMATION, max_age=VALIDITE)
    except signing.BadSignature:
        return _page(request, salle, {"erreur": _("Ce lien de confirmation n'est plus valable : "
                                                  "inscrivez-vous à nouveau.")})
    if demande.get("s") != salle.pk:
        raise Http404
    contexte = {"nom": demande.get("n", ""), "email": demande.get("e", "")}
    if request.method != "POST":
        return _page(request, salle, {**contexte, "confirmation": demande.get("a")})
    try:
        if demande.get("a") == "attente":
            vente.rejoindre_l_attente(salle, nom=contexte["nom"], email=contexte["email"])
        else:
            vente.inscrire(salle, nom=contexte["nom"], email=contexte["email"])
    except vente.DejaInscrite:
        return _page(request, salle, {**contexte, "fait": "inscrire"})
    except acces.Refus as refus:
        return _page(request, salle, {**contexte, "erreur": str(refus)})
    return _page(request, salle, {**contexte, "fait": demande.get("a")})


def _demander_la_confirmation(request, salle, action, nom, email):
    from jeiko.emailing.services import send_email
    from django.urls import reverse
    from django.utils import formats, timezone

    cle = signing.dumps({"s": salle.pk, "a": action, "n": nom, "e": email}, salt=SEL_CONFIRMATION)
    lien = request.build_absolute_uri(reverse("jeiko_visio:confirmer", args=[salle.jeton_public, cle]))
    send_email("visio_confirmer_inscription", email, {
        "invite_nom": nom or email.split("@")[0], "titre": salle.titre,
        "date": formats.date_format(timezone.localtime(salle.debut), "l j F Y \\à H\\hi"),
        "attente": "Vous serez sur la liste d'attente : si une place se libère, vous serez prévenu(e)."
                   if action == "attente" else "",
        "lien_action": lien,
    })


def _page(request, salle, contexte):
    contexte.setdefault("salle", salle)
    from jeiko.shop.models import ShopSettings

    restantes = vente.places_restantes(salle)
    contexte.update({
        "ouverte": vente.ouverte(salle), "restantes": restantes, "complet": restantes <= 0,
        "payante": salle.prix > 0, "conditions": vente.conditions(salle),
        "conditions_d_annulation": vente.conditions_d_annulation(salle),
        "boutique_ouverte": ShopSettings.get_solo().is_online,
        "deja_inscrit": request.user.is_authenticated and salle.invitations_actives().filter(
            user=request.user, inscrite=True).exists(),
    })
    return render(request, "visio/seance.html", contexte)


def _inscrire(request, salle):
    """Le POST de la page : s'inscrire (gratuit) ou rejoindre la liste d'attente."""
    action = request.POST.get("action")
    if action not in ("inscrire", "attente") or (action == "inscrire" and salle.prix > 0):
        raise Http404
    if rate_limited(request, "visio_inscription", 10, 3600):
        return {"erreur": _("Trop de tentatives. Réessayez plus tard.")}
    nom = (request.POST.get("nom") or "").strip()[:200]
    email = (request.POST.get("email") or "").strip().lower()
    try:
        validate_email(email)
    except ValidationError:
        return {"erreur": _("Cette adresse e-mail n'est pas valide."), "nom": nom, "email": email}
    # Un robot reçoit la même réponse qu'un humain : rien ne lui dit qu'il est repéré.
    if honeypot_filled(request.POST):
        return {"fait": action}
    user = request.user if request.user.is_authenticated and request.user.email.lower() == email else None
    if user is None:
        # Une adresse que rien ne prouve : on lui écrit d'abord (VISIO-03).
        if action == "inscrire" and not vente.ouverte(salle):
            return {"erreur": _("Les inscriptions à cette séance sont closes."), "nom": nom, "email": email}
        _demander_la_confirmation(request, salle, action, nom, email)
        return {"fait": "a_confirmer", "email": email}
    try:
        if action == "inscrire":
            vente.inscrire(salle, nom=nom, email=email, user=user)
        else:
            vente.rejoindre_l_attente(salle, nom=nom, email=email, user=user)
    except acces.Refus as refus:
        return {"erreur": str(refus), "nom": nom, "email": email}
    return {"fait": action, "email": email}


@never_cache
def desinscrire(request, code):
    invitation = acces.trouver(code)
    if invitation is None:
        return _prive(render(request, "visio/lien_invalide.html", status=404))
    contexte = {"invitation": invitation, "salle": invitation.salle,
                "possible": vente.peut_se_desinscrire(invitation),
                "montant": vente.montant_rembourse(invitation)}
    if request.method == "POST" and contexte["possible"]:
        try:
            contexte["rembourse"] = vente.desinscrire(invitation)
            contexte["fait"] = True
        except acces.Refus as refus:
            contexte["erreur"] = str(refus)
    return _prive(render(request, "visio/desinscription.html", contexte))
