"""
Les pages publiques d'une séance à inscription (VISIO-01, V2-E) : la page de
la séance (`/visio/seance/<jeton>/`) et la désinscription par le lien
personnel (`/visio/<code>/desinscrire/`).

Gratuit : nom et adresse, puis le lien par e-mail. Payant : la page met le
produit au panier (`jeiko_client_shop:cart_add`) ; la boutique fait le reste
et le paiement inscrit (`vente.inscrire_la_commande`). Complet : liste
d'attente.

Désinscrire : GET annonce ce qui sera remboursé, POST agit — un antivirus
qui suit les liens d'un e-mail ne désinscrit personne.
"""
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.http import Http404
from django.shortcuts import get_object_or_404, render
from django.utils.translation import gettext as _
from django.views.decorators.cache import never_cache

from jeiko.throttling import honeypot_filled, rate_limited

from . import acces, vente
from .models import Salle
from .vues_publiques import _prive


@never_cache
def seance(request, jeton):
    salle = get_object_or_404(Salle, jeton_public=jeton, inscriptions=True)
    contexte = {"salle": salle}
    if request.user.is_authenticated:
        contexte.update(nom=request.user.get_full_name(), email=request.user.email)
    if request.method == "POST":
        contexte.update(_inscrire(request, salle))
    from jeiko.shop.models import ShopSettings

    restantes = vente.places_restantes(salle)
    contexte.update({
        "ouverte": vente.ouverte(salle), "restantes": restantes, "complet": restantes <= 0,
        "payante": salle.prix > 0, "conditions": vente.conditions(salle),
        "boutique_ouverte": ShopSettings.get_solo().is_online,
        "deja_inscrit": request.user.is_authenticated and salle.invitations_actives().filter(
            user=request.user, inscrite=True).exists(),
    })
    return render(request, "visio/seance.html", contexte)


def _inscrire(request, salle):
    """Le POST de la page : s'inscrire (gratuit) ou rejoindre la liste d'attente."""
    action = request.POST.get("action")
    if action not in ("inscrire", "attente") or (action == "inscrire" and salle.prix > 0):
        raise Http404
    if rate_limited(request, "visio_inscription", 10, 3600):
        return {"erreur": _("Trop de tentatives. Réessayez plus tard.")}
    nom = (request.POST.get("nom") or "").strip()[:200]
    email = (request.POST.get("email") or "").strip().lower()
    try:
        validate_email(email)
    except ValidationError:
        return {"erreur": _("Cette adresse e-mail n'est pas valide."), "nom": nom, "email": email}
    # Un robot reçoit la même réponse qu'un humain : rien ne lui dit qu'il est repéré.
    if honeypot_filled(request.POST):
        return {"fait": action}
    user = request.user if request.user.is_authenticated and request.user.email.lower() == email else None
    try:
        if action == "inscrire":
            vente.inscrire(salle, nom=nom, email=email, user=user)
        else:
            vente.rejoindre_l_attente(salle, nom=nom, email=email, user=user)
    except acces.Refus as refus:
        return {"erreur": str(refus), "nom": nom, "email": email}
    return {"fait": action, "email": email}


@never_cache
def desinscrire(request, code):
    invitation = acces.trouver(code)
    if invitation is None:
        return _prive(render(request, "visio/lien_invalide.html", status=404))
    contexte = {"invitation": invitation, "salle": invitation.salle,
                "possible": vente.peut_se_desinscrire(invitation),
                "montant": vente.montant_rembourse(invitation)}
    if request.method == "POST" and contexte["possible"]:
        try:
            contexte["rembourse"] = vente.desinscrire(invitation)
            contexte["fait"] = True
        except acces.Refus as refus:
            contexte["erreur"] = str(refus)
    return _prive(render(request, "visio/desinscription.html", contexte))
