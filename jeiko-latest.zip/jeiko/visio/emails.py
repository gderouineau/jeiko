"""
L'e-mail d'invitation : le lien personnel, la date, le rôle (VISIO-01).

Le contenu est un e-mail du catalogue (`visio_invitation`), modifiable dans
Emailing comme les autres ; le lien n'est jamais gardé au journal des envois
(`emailing.services.contexte_consigne` retire tout ce qui commence par
« lien »).
"""
import logging

from django.utils import formats, timezone

logger = logging.getLogger(__name__)

ROLES = {"hote": "hôte", "intervenant": "intervenant", "participant": "participant"}


def _duree(minutes):
    if minutes and minutes % 60 == 0:
        heures = minutes // 60
        return f"{heures} heure{'s' if heures > 1 else ''}"
    return f"{minutes} minutes"


def envoyer_l_invitation(invitation):
    """(envoyé, raison). Ne lève jamais : une invitation reste valable sans e-mail."""
    from jeiko.emailing.admin_alerts import _lien_absolu
    from jeiko.emailing.services import send_email

    from .vente import paragraphe_de_desinscription

    if not invitation.email:
        return False, "Pas d'adresse e-mail"
    salle = invitation.salle
    # Le contenu des e-mails reste en français (décision I-05) : le format de
    # date suit la langue du site, que `send_email` impose.
    date = formats.date_format(timezone.localtime(salle.debut), "l j F Y \\à H\\hi")
    try:
        envoye, raison = send_email("visio_invitation", invitation.email, {
            "invite_nom": invitation.nom,
            "titre": salle.titre,
            "date": date,
            "role": ROLES.get(invitation.role, invitation.role),
            "ouverture": _duree(salle.ouverture_avant),
            "description": salle.description,
            "lien_action": _lien_absolu("jeiko_visio:salle", invitation.code),
            "lien_desinscription": paragraphe_de_desinscription(invitation),
        }, user=invitation.user)
    except Exception as erreur:
        logger.exception("Invitation visio #%s non envoyée", invitation.pk)
        return False, str(erreur)
    if envoye:
        invitation.envoyee_le = timezone.now()
        invitation.save(update_fields=["envoyee_le"])
    return envoye, raison
