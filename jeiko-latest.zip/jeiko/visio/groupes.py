"""
Les sous-salles — groupes de travail d'une séance (VISIO-01, V2).

L'hôte ouvre N groupes (2 à 10) : les personnes présentes dans la salle
principale (hôtes exceptés) y sont réparties au hasard, ou comme il l'a dit.
Chaque groupe est une salle LiveKit à part, avec son propre chat ; tout le
monde y parle et peut montrer son écran.

Le basculement est l'affaire du navigateur : il reçoit l'annonce (sujet
« groupes ») et redemande à entrer — `acces.entrer` le fait alors entrer dans
son groupe, ou de retour dans la salle principale. C'est donc toujours JEIKO
qui décide où va chacun.

La fin : l'hôte ferme les groupes, ou leur heure de fin passe. L'heure fait
foi CÔTÉ SERVEUR (`en_cours`) : un groupe se ferme à l'heure même si l'onglet
de l'hôte est fermé — le premier navigateur qui redemande à entrer après
l'heure ramène tout le monde.
"""
import logging
import random

from django.db import transaction
from django.utils import timezone
from django.utils.translation import gettext as _

from . import livekit
from .acces import Refus
from .models import Invitation, SousSalle

logger = logging.getLogger(__name__)

MAX_GROUPES = 10


def en_cours(salle):
    """Vrai si les groupes sont ouverts ; les ferme si leur heure est passée."""
    if not salle.groupes_ouverts:
        return False
    if salle.groupes_fin_le and timezone.now() >= salle.groupes_fin_le:
        fermer(salle)
        return False
    return True


def _annoncer(salle, donnees, *, principale=True, groupes=True):
    noms = ([salle.identifiant_livekit] if principale else []) + (
        [g.identifiant_livekit for g in salle.sous_salles.all()] if groupes else [])
    for nom in noms:
        try:
            livekit.diffuser(nom, "groupes", donnees)
        except livekit.LiveKitIndisponible as panne:
            # Les navigateurs se recalent d'eux-mêmes à leur prochaine entrée.
            logger.warning("Visio : annonce aux groupes non transmise — %s", panne)


def etat(salle):
    return {
        "ouverts": bool(salle.groupes_ouverts),
        "fin": timezone.localtime(salle.groupes_fin_le).isoformat() if salle.groupes_fin_le else None,
        "groupes": [{"numero": g.numero, "membres": [i.nom for i in g.membres.exclude(role=Invitation.Role.HOTE)]}
                    for g in salle.sous_salles.prefetch_related("membres")],
    }


def ouvrir(salle, nombre, duree_minutes=0, repartition=None):
    """
    `repartition` : {identité LiveKit: numéro de groupe} pour une répartition à
    la main ; sinon, au hasard, entre les personnes présentes (hôtes exceptés).
    """
    nombre = int(nombre or 0)
    if not 2 <= nombre <= MAX_GROUPES:
        raise Refus(_("Entre 2 et %(n)s groupes.") % {"n": MAX_GROUPES})
    presents = {p.get("identity") for p in livekit.participants(salle.identifiant_livekit)}
    personnes = [i for i in salle.invitations_actives().exclude(role=Invitation.Role.HOTE)
                 if i.identite in presents]
    if repartition is None:
        random.shuffle(personnes)
        affectation = {i.pk: n % nombre + 1 for n, i in enumerate(personnes)}
    else:
        affectation = {i.pk: int(repartition.get(i.identite) or 0) for i in personnes}
        if any(not 1 <= n <= nombre for n in affectation.values()):
            raise Refus(_("Chaque personne présente doit avoir un groupe, de 1 à %(n)s.") % {"n": nombre})
    with transaction.atomic():
        salle.sous_salles.all().delete()
        groupes = {n: SousSalle.objects.create(salle=salle, numero=n) for n in range(1, nombre + 1)}
        salle.invitations.update(sous_salle=None)
        for pk, n in affectation.items():
            Invitation.objects.filter(pk=pk).update(sous_salle=groupes[n])
        salle.groupes_ouverts = True
        salle.groupes_fin_le = timezone.now() + timezone.timedelta(minutes=int(duree_minutes)) if duree_minutes else None
        salle.save(update_fields=["groupes_ouverts", "groupes_fin_le"])
    for groupe in groupes.values():
        livekit.ouvrir_la_salle(groupe.identifiant_livekit)
    _annoncer(salle, etat(salle), groupes=False)
    return etat(salle)


def fermer(salle):
    """Tout le monde revient dans la salle principale."""
    salle.groupes_ouverts = False
    salle.groupes_fin_le = None
    salle.save(update_fields=["groupes_ouverts", "groupes_fin_le"])
    _annoncer(salle, {"ouverts": False})
    salle.invitations.update(sous_salle=None)


def visiter(salle, hote, numero):
    """L'hôte passe dans un groupe (numero), ou revient dans la salle principale (0)."""
    groupe = salle.sous_salles.filter(numero=numero).first() if numero else None
    if numero and groupe is None:
        raise Refus(_("Ce groupe n'existe pas."))
    Invitation.objects.filter(pk=hote.pk).update(sous_salle=groupe)


def annoncer_aux_groupes(salle, texte):
    texte = (texte or "").strip()[:300]
    if not texte:
        raise Refus(_("Message vide."))
    _annoncer(salle, {"annonce": texte}, principale=False)
