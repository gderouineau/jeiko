"""
Qui entre dans une salle, quand, et avec quels droits (VISIO-01).

Le lien d'une invitation est la seule clé : JEIKO ne délivre le jeton
LiveKit qu'ici, après avoir vérifié, dans cet ordre :

1. la salle n'est pas terminée ;
2. le lien d'un HÔTE n'ouvre la salle qu'à son compte, connecté — un lien
   d'hôte transféré par erreur ne donne pas les commandes à un inconnu ;
3. un participant n'entre pas avant l'ouverture de la salle (`ouverture_avant`,
   30 minutes par défaut) ni plus de deux heures après la fin — hôtes et
   intervenants, quand ils veulent. Avant l'ouverture, sa page reste utile :
   elle règle caméra et micro, et le fait entrer à l'heure ;
4. une salle verrouillée n'admet plus personne de nouveau ;
5. la salle d'attente retient un participant jusqu'à ce qu'un hôte l'admette.
   Il n'a AUCUN jeton tant qu'il attend : il ne voit ni n'entend rien.

Les droits du jeton (parler, montrer l'écran) viennent du rôle, du format de
la salle et de la parole donnée — `Invitation.peut_publier()`.

Ce que ce module ne fait pas : compter les présents. LiveKit refuse lui-même
le 51e (`max_participants`), et le nombre d'invitations est plafonné à 50
(`inviter`).
"""
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from django.utils.translation import gettext as _

from . import livekit
from .models import Invitation, MessageDeChat, Presence, Salle, SousSalle

PROLONGATION = timedelta(hours=2)
#: Au-delà, une personne en salle d'attente qui ne s'est plus manifestée a
#: fermé sa page : l'hôte ne la voit plus.
ATTENTE_VIVANTE = timedelta(seconds=15)


class Refus(Exception):
    """Un geste refusé, avec la phrase à montrer."""


# --- Créer et inviter ---

def creer_salle(*, titre, debut, fin, cree_par=None, hote=True, **champs):
    """Une salle, et l'invitation d'hôte de la personne qui la crée."""
    with transaction.atomic():
        salle = Salle.objects.create(titre=titre, debut=debut, fin=fin, cree_par=cree_par, **champs)
        if hote and cree_par is not None:
            inviter(salle, user=cree_par, role=Invitation.Role.HOTE)
    return salle


def inviter(salle, *, nom="", email="", role=Invitation.Role.PARTICIPANT, user=None, contact=None):
    """
    Ajoute une invitation. Le compte se retrouve par l'adresse quand il n'est
    pas donné ; la fiche du CRM aussi, créée au besoin (règle de
    `crm.rattachement`) — sauf pour un compte de l'équipe. Refuse au-delà de
    50 invitations actives.
    """
    from jeiko.crm.rattachement import rattacher
    from jeiko.questionnaires_expert.models import Prospect

    email = (email or (user.email if user else "") or "").strip().lower()
    if user is None and email:
        user = get_user_model().objects.filter(email__iexact=email, is_active=True).first()
    if not nom:
        nom = (user.get_full_name() or user.username) if user else email.split("@")[0]
    # Un hôte admet, exclut, termine : son lien ne s'ouvre qu'avec SON compte.
    # Sans compte, le lien seul donnait les commandes à qui le tenait (audit V-11).
    if role == Invitation.Role.HOTE and user is None:
        raise Refus(_("Un hôte doit avoir un compte sur le site : créez-le d'abord, avec cette adresse."))
    with transaction.atomic():
        # Le plafond se compte sous verrou : deux ajouts simultanés ne font pas 51.
        Salle.objects.select_for_update().get(pk=salle.pk)
        if salle.invitations_actives().count() >= livekit.MAX_PARTICIPANTS:
            raise Refus(_("Une séance accueille %(n)s personnes au plus.") % {"n": livekit.MAX_PARTICIPANTS})
        # Une personne, un lien : par son compte, ou par son adresse sans compte.
        deja = (salle.invitations_actives().filter(user=user).first() if user is not None
                else salle.invitations_actives().filter(user__isnull=True, email__iexact=email).first()
                if email else None)
        if deja is not None:
            return deja
        # L'équipe du site n'a rien à faire dans les contacts : seuls les
        # invités extérieurs rejoignent le CRM.
        if contact is None and email and not (user is not None and user.is_staff):
            contact = rattacher(email, nom=nom, origine=Prospect.Origine.VISIO)
        return Invitation.objects.create(salle=salle, role=role, nom=nom[:200], email=email,
                                         user=user, contact=contact,
                                         admise=role != Invitation.Role.PARTICIPANT)


def revoquer(invitation):
    if invitation.revoquee_le is None:
        invitation.revoquee_le = timezone.now()
        invitation.save(update_fields=["revoquee_le"])


# --- Entrer ---

def trouver(code):
    """L'invitation de ce lien, ou None (inconnue ou révoquée)."""
    if not code or len(code) > 64:
        return None
    return (Invitation.objects.select_related("salle", "user")
            .filter(code=code, revoquee_le__isnull=True).first())


def etat_d_entree(invitation, user):
    """
    Ce qui empêche d'entrer maintenant, ou None. Un code : `terminee`,
    `connexion`, `trop_tot`, `verrouillee`, `attente`.
    """
    salle = invitation.salle
    maintenant = timezone.now()
    if salle.terminee:
        return "terminee"
    if invitation.est_hote and (not invitation.user_id or getattr(user, "pk", None) != invitation.user_id):
        return "connexion"
    if invitation.anime:
        return None
    if maintenant < salle.ouverte_le:
        return "trop_tot"
    if maintenant > salle.fin + PROLONGATION:
        return "terminee"
    if invitation.admise:
        return None
    if salle.verrouillee:
        return "verrouillee"
    if salle.salle_d_attente:
        return "attente"
    return None


def entrer(invitation, user, adresse):
    """
    {"etat": "ok", jeton…} ou {"etat": <code>} — voir `etat_d_entree`. Une
    personne en salle d'attente est notée vivante ; une entrée, notée arrivée.
    """
    etat = etat_d_entree(invitation, user)
    maintenant = timezone.now()
    if etat == "attente":
        Invitation.objects.filter(pk=invitation.pk).update(attente_vue_le=maintenant)
        return {"etat": "attente"}
    if etat:
        reponse = {"etat": etat}
        if etat == "trop_tot":
            reponse["ouverture"] = timezone.localtime(invitation.salle.ouverte_le).isoformat()
        return reponse

    salle = invitation.salle
    groupe, nom_livekit = lieu(invitation)
    livekit.ouvrir_la_salle(nom_livekit)
    jeton = livekit.jeton_d_entree(
        nom_livekit, invitation.identite, nom=invitation.nom,
        # Dans un groupe de travail, tout le monde parle et montre son écran.
        publier=True if groupe else invitation.peut_publier(),
        sources=TOUTES_LES_SOURCES if groupe else invitation.sources(),
        metadonnees={"role": invitation.role},
    )
    Invitation.objects.filter(pk=invitation.pk).update(
        admise=True, attente_vue_le=None, derniere_arrivee_le=maintenant,
        arrivee_le=invitation.arrivee_le or maintenant)
    # Un passage ouvert qui traîne (page fermée sans adieu, reconnexion) se
    # referme à la nouvelle entrée : on ne compte pas deux fois le même temps.
    Presence.objects.filter(invitation=invitation, sortie__isnull=True).update(sortie=maintenant)
    Presence.objects.create(invitation=invitation, arrivee=maintenant)
    reponse = {"etat": "ok", "jeton": jeton, "adresse": adresse, "groupe": None}
    if groupe is not None:
        reponse["groupe"] = {"numero": groupe.numero, "fin": (timezone.localtime(salle.groupes_fin_le).isoformat()
                                                             if salle.groupes_fin_le else None)}
    return reponse


TOUTES_LES_SOURCES = ["camera", "microphone", "screen_share", "screen_share_audio"]


def lieu(invitation):
    """(groupe de travail ou None, nom LiveKit) : où se trouve la personne en ce moment."""
    from . import groupes

    salle = invitation.salle
    if groupes.en_cours(salle):
        groupe = SousSalle.objects.filter(membres__pk=invitation.pk).first()
        if groupe is not None:
            return groupe, groupe.identifiant_livekit
    return None, salle.identifiant_livekit


def sortir(invitation):
    maintenant = timezone.now()
    Invitation.objects.filter(pk=invitation.pk).update(sortie_le=maintenant)
    Presence.objects.filter(invitation=invitation, sortie__isnull=True).update(sortie=maintenant)


# --- Les gestes de l'hôte ---

def en_attente(salle):
    limite = timezone.now() - ATTENTE_VIVANTE
    return list(salle.invitations_actives().filter(admise=False, attente_vue_le__gte=limite)
                .order_by("attente_vue_le"))


def cible(salle, identite):
    """L'invitation d'une personne de cette salle, par son identité LiveKit (`i<pk>`)."""
    if not (identite or "").startswith("i") or not identite[1:].isdigit():
        raise Refus(_("Personne inconnue."))
    invitation = salle.invitations.filter(pk=int(identite[1:])).first()
    if invitation is None:
        raise Refus(_("Personne inconnue."))
    return invitation


def admettre(salle, invitation):
    Invitation.objects.filter(pk=invitation.pk, salle=salle).update(admise=True)


def donner_la_parole(salle, invitation, accorder):
    """Le micro (et la caméra) à un participant — ou les lui reprendre."""
    if invitation.anime:
        raise Refus(_("Un hôte ou un intervenant a toujours la parole."))
    invitation.parole = accorder
    invitation.save(update_fields=["parole"])
    livekit.permissions(salle.identifiant_livekit, invitation.identite,
                        publier=invitation.peut_publier(), sources=invitation.sources())


def exclure(salle, invitation):
    """Retirer de la salle ET révoquer le lien : sinon il reviendrait aussitôt."""
    if invitation.est_hote:
        raise Refus(_("Un hôte ne s'exclut pas."))
    revoquer(invitation)
    retirer_partout(salle, invitation)


def retirer_partout(salle, invitation):
    """
    Retire une personne de la salle principale ET de son groupe de travail (audit
    V-03) : exclure dans un groupe visait la salle principale, où elle n'était pas.
    Ne lève pas si LiveKit est injoignable : le rattrapage (`reconcilier`) suit.
    """
    noms = {salle.identifiant_livekit} | {str(n) for n in salle.sous_salles.values_list("nom_livekit", flat=True)}
    for nom in noms:
        try:
            livekit.retirer(nom, invitation.identite)
        except livekit.LiveKitIndisponible:
            pass


def terminer(salle):
    """La fin pour tous : la salle principale ET les groupes de travail ferment (audit V-03)."""
    salle.terminee_le = timezone.now()
    salle.groupes_ouverts, salle.groupes_fin_le = False, None
    salle.save(update_fields=["terminee_le", "groupes_ouverts", "groupes_fin_le"])
    salle.invitations.update(sous_salle=None)
    for groupe in salle.sous_salles.all():
        try:
            livekit.fermer(groupe.identifiant_livekit)
        except livekit.LiveKitIndisponible:
            pass
    livekit.fermer(salle.identifiant_livekit)


def reconcilier_les_seances_en_cours():
    """cron_5m : le rattrapage pour les séances proches de leur horaire ou fermées depuis peu."""
    maintenant = timezone.now()
    salles = Salle.objects.filter(
        Q(terminee_le__isnull=True, debut__lte=maintenant + timedelta(hours=1), fin__gte=maintenant - PROLONGATION)
        | Q(terminee_le__gte=maintenant - timedelta(hours=6)))
    for salle in salles:
        reconcilier(salle)
    return len(salles)


def reconcilier(salle):
    """
    Rattrapage côté serveur (audit V-02). Avec LiveKit auto-hébergé, exclure
    quelqu'un n'invalide pas son jeton : il peut revenir avec, tant qu'il est
    valable (une dizaine de minutes, renouvelé par le serveur). Et une salle
    fermée se recrée si un ancien jeton s'y présente. On compare donc ce qui est
    chez LiveKit à ce que JEIKO autorise, et on corrige :

    * séance terminée : ses salles sont refermées ;
    * groupes fermés : leurs salles sont refermées ;
    * dans une salle ouverte : quiconque n'a plus de lien valable, ou n'est pas
      à sa place (dans un groupe qui n'est pas le sien), est retiré.

    Appelé quand l'hôte suit sa salle d'attente (toutes les quelques secondes,
    au plus une fois toutes les 20 s par séance) et par cron_5m. Ce que ça ne
    fait pas : empêcher la reconnexion pendant l'intervalle — il faudrait les
    webhooks de LiveKit (au plan). Ne lève pas : LiveKit injoignable, on réessaie au passage suivant.
    """
    from . import groupes

    try:
        if salle.terminee:
            for nom in [salle.identifiant_livekit] + [g.identifiant_livekit for g in salle.sous_salles.all()]:
                livekit.fermer(nom)
            return
        ouverts = groupes.en_cours(salle)
        actuels = {g.identifiant_livekit: g for g in groupes.actuels(salle)} if ouverts else {}
        for groupe in salle.sous_salles.all():
            if groupe.identifiant_livekit not in actuels:
                livekit.fermer(groupe.identifiant_livekit)
        valides = {i.identite: i for i in salle.invitations_actives()}
        for nom, groupe in [(salle.identifiant_livekit, None)] + [(n, g) for n, g in actuels.items()]:
            for p in livekit.participants(nom):
                identite = p.get("identity")
                invitation = valides.get(identite)
                hors_de_sa_place = invitation is not None and groupe is not None and not invitation.est_hote and (
                    invitation.sous_salle_id != groupe.pk)
                if invitation is None or hors_de_sa_place:
                    livekit.retirer(nom, identite)
    except livekit.LiveKitIndisponible as panne:
        import logging

        logging.getLogger(__name__).info("Visio : rattrapage de la séance %s remis — %s", salle.pk, panne)


# --- Le chat ---

def ecrire(invitation, texte):
    """Enregistre puis diffuse. Le message reste écrit même si la diffusion échoue."""
    texte = (texte or "").strip()[:2000]
    if not texte:
        raise Refus(_("Message vide."))
    groupe, nom_livekit = lieu(invitation)
    message = MessageDeChat.objects.create(salle=invitation.salle, auteur=invitation, sous_salle=groupe,
                                           nom=invitation.nom, texte=texte)
    livekit.diffuser(nom_livekit, "chat", message.en_donnees())
    return message
