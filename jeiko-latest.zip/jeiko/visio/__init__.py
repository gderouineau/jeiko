"""
La visio de JEIKO (VISIO-01) : réunions, conférences et rendez-vous en vidéo,
sur le serveur du site — « un Google Meet chez soi ».

* `models.py`  — salles, invitations (un lien personnel chacune), chat ;
* `livekit.py` — le serveur qui transporte le son et l'image ;
* `acces.py`   — qui entre, quand, avec quels droits ;
* `vues_publiques.py` — la page de la salle, ouverte par le lien ;
* `vues_admin.py`     — Conférence, dans l'administration.

Le cadrage (50 personnes au plus, pas d'enregistrement, LiveKit installé par
l'installeur) est dans PLAN_ACTION.md, VISIO-01.
"""
