"""
Les salles de visio, leurs invités et leur chat (VISIO-01).

Une SALLE est une séance datée : une réunion, une conférence, un rendez-vous.
On y entre par une INVITATION — un lien personnel, avec son code, qui dit qui
on est et ce qu'on peut y faire. Il n'y a pas de lien « ouvert » : chaque
personne a le sien, ce qui permet de savoir qui est venu, de révoquer un
lien seul et de rattacher chacun à sa fiche du CRM.

Le son et l'image ne passent jamais par JEIKO : ils vont de navigateur à
LiveKit (`livekit.py`). JEIKO garde ce qui doit durer — qui était invité, qui
est venu, ce qui s'est écrit dans le chat.
"""
import secrets
import uuid

from django.conf import settings
from decimal import Decimal

from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models.signals import post_delete
from django.dispatch import receiver
from django.urls import reverse
from django.utils import timezone
from django.utils.translation import gettext_lazy as _


def _nouveau_code():
    return secrets.token_urlsafe(24)


class Salle(models.Model):
    class Format(models.TextChoices):
        REUNION = "reunion", _("Réunion — tout le monde parle")
        CONFERENCE = "conference", _("Conférence — les intervenants parlent, le public écoute")
        RENDEZ_VOUS = "rendez_vous", _("Rendez-vous — en tête-à-tête")

    titre = models.CharField(_("Titre"), max_length=200)
    format = models.CharField(_("Format"), max_length=20, choices=Format.choices, default=Format.REUNION)
    description = models.TextField(_("Description"), blank=True)
    debut = models.DateTimeField(_("Début"), db_index=True)
    fin = models.DateTimeField(_("Fin"))
    ouverture_avant = models.PositiveIntegerField(
        _("Ouverture avant le début (minutes)"), default=30,
        validators=[MaxValueValidator(24 * 60)],
        help_text=_("Les participants peuvent entrer à partir de ce moment. Avant, leur page "
                    "sert à régler caméra et micro, et les fait entrer à l'ouverture."))
    salle_d_attente = models.BooleanField(
        _("Salle d'attente"), default=True,
        help_text=_("Les participants attendent qu'un hôte les fasse entrer. Hôtes et intervenants entrent directement."))
    verrouillee = models.BooleanField(
        _("Verrouillée"), default=False,
        help_text=_("Plus personne de nouveau n'entre ; les personnes déjà admises peuvent revenir."))
    # Ce qui fait qu'une visio paraît « nulle » (Guillaume, 12/10/2026) : une
    # image envoyée en 360-720p, un partage d'écran réglé pour la fluidité,
    # un son filtré pour la voix qui abîme la musique. Chaque personne envoie
    # PLUSIEURS versions de son image (simulcast) : un spectateur à faible
    # débit reçoit la petite sans dégrader celle des autres (salle.js).
    class Qualite(models.TextChoices):
        ECONOMIE = "economie", _("Économie — 540p, pour les connexions faibles")
        STANDARD = "standard", _("Standard — 720p")
        HAUTE = "haute", _("Haute — 1080p")

    class Son(models.TextChoices):
        VOIX = "voix", _("Voix — réduction du bruit et de l'écho")
        MUSIQUE = "musique", _("Musique — haute fidélité, sans filtre")

    qualite = models.CharField(_("Qualité de l'image"), max_length=10, choices=Qualite.choices,
                               default=Qualite.HAUTE)
    son = models.CharField(_("Son"), max_length=10, choices=Son.choices, default=Son.VOIX,
                           help_text=_("« Musique » pour un cours de musique ou une séance avec fond sonore : "
                                       "casque conseillé, l'écho n'est plus filtré."))
    rappels = models.BooleanField(
        _("Rappels par e-mail"), default=True,
        help_text=_("Chaque invité reçoit son lien la veille et une heure avant. Les rendez-vous du "
                    "calendrier ont déjà leurs propres rappels."))
    # Les sous-salles (groupes de travail) : ouvertes par l'hôte, closes par
    # lui ou à `groupes_fin_le` — l'heure fait foi côté serveur (groupes.py).
    groupes_ouverts = models.BooleanField(default=False)
    groupes_fin_le = models.DateTimeField(null=True, blank=True)
    #: Le nom de la salle chez LiveKit : imprévisible, il ne dit rien du site.
    nom_livekit = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    terminee_le = models.DateTimeField(_("Terminée le"), null=True, blank=True)
    # Une séance née du calendrier (visio/calendrier.py) : un rendez-vous en
    # tête-à-tête a SA salle ; un cours collectif, une salle par créneau.
    rendez_vous = models.OneToOneField("calendars.Appointment", on_delete=models.SET_NULL, null=True, blank=True,
                                       related_name="salle_visio", verbose_name=_("Rendez-vous"))
    creneau = models.ForeignKey("calendars.Slot", on_delete=models.SET_NULL, null=True, blank=True,
                                related_name="salles_visio", verbose_name=_("Créneau"))
    cree_par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
                                 related_name="salles_visio_creees", verbose_name=_("Créée par"))
    cree_le = models.DateTimeField(auto_now_add=True)
    # V2-E — la séance à inscription, gratuite ou vendue (visio/vente.py) :
    # une page publique, des places, une liste d'attente ; payante, un
    # produit de la boutique tenu à jour derrière (`produit`).
    inscriptions = models.BooleanField(
        _("Inscriptions ouvertes au public"), default=False,
        help_text=_("Une page publique où chacun s'inscrit — ou achète sa place — et reçoit son lien personnel."))
    places = models.PositiveSmallIntegerField(
        _("Places"), null=True, blank=True, validators=[MinValueValidator(1), MaxValueValidator(50)],
        help_text=_("Vide : jusqu'au plafond de 50 personnes par séance, hôtes compris."))
    prix = models.DecimalField(
        _("Prix TTC"), max_digits=10, decimal_places=2, default=Decimal("0"), validators=[MinValueValidator(0)],
        help_text=_("0 : inscription gratuite. Au-delà, la place se paie par la boutique du site."))
    liste_d_attente = models.BooleanField(
        _("Liste d'attente"), default=True,
        help_text=_("Séance complète : on peut s'inscrire en attente. Une place libérée prévient toute la liste "
                    "par e-mail ; le premier qui s'inscrit la prend."))
    #: [[heures avant le début, pourcentage remboursé], …] : `[]` jamais,
    #: `[[0, 100]]` toujours (jusqu'au début). Lu par `vente.taux_rembourse`.
    remboursement = models.JSONField(_("Remboursement à la désinscription"), default=list, blank=True)
    produit = models.OneToOneField("shop.Product", on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name="salle_visio", verbose_name=_("Produit de la boutique"))
    #: L'adresse de la page publique : imprévisible, elle ne dit pas combien de séances existent.
    jeton_public = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)

    class Meta:
        ordering = ["-debut"]
        verbose_name = _("Séance en visio")
        verbose_name_plural = _("Séances en visio")

    def __str__(self):
        return self.titre

    def get_absolute_url(self):
        return reverse("jeiko_visio_admin:fiche", args=[self.pk])

    @property
    def identifiant_livekit(self):
        return str(self.nom_livekit)

    @property
    def ouverte_le(self):
        """À partir de quand un participant entre."""
        from datetime import timedelta

        return self.debut - timedelta(minutes=self.ouverture_avant)

    @property
    def terminee(self):
        return self.terminee_le is not None

    @property
    def tout_le_monde_parle(self):
        return self.format != self.Format.CONFERENCE

    def invitations_actives(self):
        return self.invitations.filter(revoquee_le__isnull=True)


class SousSalle(models.Model):
    """Un groupe de travail : sa propre salle chez LiveKit, son propre chat."""
    salle = models.ForeignKey(Salle, on_delete=models.CASCADE, related_name="sous_salles")
    numero = models.PositiveSmallIntegerField()
    nom_livekit = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)

    class Meta:
        ordering = ["numero"]
        verbose_name = _("Groupe de travail")
        verbose_name_plural = _("Groupes de travail")

    def __str__(self):
        return _("Groupe %(n)s") % {"n": self.numero}

    @property
    def identifiant_livekit(self):
        return str(self.nom_livekit)


class Invitation(models.Model):
    class Role(models.TextChoices):
        HOTE = "hote", _("Hôte")
        INTERVENANT = "intervenant", _("Intervenant")
        PARTICIPANT = "participant", _("Spectateur / participant")

    salle = models.ForeignKey(Salle, on_delete=models.CASCADE, related_name="invitations")
    role = models.CharField(_("Rôle"), max_length=20, choices=Role.choices, default=Role.PARTICIPANT)
    nom = models.CharField(_("Nom affiché"), max_length=200)
    email = models.EmailField(_("E-mail"), blank=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
                             related_name="invitations_visio", verbose_name=_("Compte"))
    contact = models.ForeignKey("questionnaires_expert.Prospect", on_delete=models.SET_NULL, null=True,
                                blank=True, related_name="invitations_visio", verbose_name=_("Contact"))
    #: Le secret du lien. Comme le jeton public d'un rendez-vous : gardé en
    #: clair pour pouvoir renvoyer le lien ; révoquer une invitation le rend inutile.
    code = models.CharField(max_length=64, unique=True, default=_nouveau_code, editable=False)
    revoquee_le = models.DateTimeField(_("Révoquée le"), null=True, blank=True)
    #: Passée par la salle d'attente : revient sans attendre.
    admise = models.BooleanField(default=False)
    #: Dernier signe de vie en salle d'attente (la page interroge toutes les
    #: 3 s) : l'hôte ne voit que les personnes qui attendent ENCORE.
    attente_vue_le = models.DateTimeField(null=True, blank=True)
    #: Un participant à qui l'hôte a donné la parole la garde s'il se reconnecte.
    parole = models.BooleanField(default=False)
    #: Son groupe de travail tant que les groupes sont ouverts (l'hôte : celui qu'il visite).
    sous_salle = models.ForeignKey(SousSalle, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name="membres")
    envoyee_le = models.DateTimeField(_("Invitation envoyée le"), null=True, blank=True)
    rappel_veille_le = models.DateTimeField(null=True, blank=True)
    rappel_heure_le = models.DateTimeField(null=True, blank=True)
    arrivee_le = models.DateTimeField(_("Arrivée"), null=True, blank=True)
    derniere_arrivee_le = models.DateTimeField(null=True, blank=True)
    sortie_le = models.DateTimeField(_("Sortie"), null=True, blank=True)
    # V2-E — une place prise sur la page publique, gratuite ou payée.
    inscrite = models.BooleanField(_("Inscrite par la page publique"), default=False)
    commande = models.ForeignKey("shop.Order", on_delete=models.SET_NULL, null=True, blank=True,
                                 related_name="invitations_visio", verbose_name=_("Commande"))
    montant_paye = models.DecimalField(_("Montant payé"), max_digits=10, decimal_places=2, default=Decimal("0"))
    desinscrite_le = models.DateTimeField(_("Désinscrite le"), null=True, blank=True)
    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["role", "nom"]
        verbose_name = _("Invitation en visio")
        verbose_name_plural = _("Invitations en visio")

    def __str__(self):
        return f"{self.nom} ({self.get_role_display()})"

    def get_absolute_url(self):
        return reverse("jeiko_visio:salle", args=[self.code])

    @property
    def identite(self):
        """Le nom de la personne chez LiveKit."""
        return f"i{self.pk}"

    @property
    def revoquee(self):
        return self.revoquee_le is not None

    @property
    def anime(self):
        """Hôte ou intervenant : sur scène d'office, jamais en salle d'attente."""
        return self.role in (self.Role.HOTE, self.Role.INTERVENANT)

    @property
    def est_hote(self):
        return self.role == self.Role.HOTE

    def peut_publier(self):
        return self.anime or self.parole or self.salle.tout_le_monde_parle

    def sources(self):
        """Ce que la personne peut montrer : l'écran est réservé à qui anime, sauf en réunion."""
        if self.anime or self.salle.format == Salle.Format.REUNION:
            return ["camera", "microphone", "screen_share", "screen_share_audio"]
        return ["camera", "microphone"]


class Presence(models.Model):
    """
    Un passage dans la salle : de l'entrée à la sortie. Une personne qui
    revient (coupure, autre appareil) en a plusieurs ; leur somme est son
    temps de présence. La sortie vient du navigateur (`sendBeacon`) : une page
    fermée brutalement laisse un passage ouvert, que le rapport borne à la fin
    de la séance (`duree`).
    """
    invitation = models.ForeignKey(Invitation, on_delete=models.CASCADE, related_name="presences")
    arrivee = models.DateTimeField(_("Arrivée"), db_index=True)
    sortie = models.DateTimeField(_("Sortie"), null=True, blank=True)

    class Meta:
        ordering = ["arrivee"]
        verbose_name = _("Présence en visio")
        verbose_name_plural = _("Présences en visio")

    def duree(self, maintenant=None):
        from datetime import timedelta

        salle = self.invitation.salle
        borne = self.sortie or min(maintenant or timezone.now(), salle.terminee_le or salle.fin + timedelta(hours=2))
        return max(borne - self.arrivee, timedelta(0))


def _chemin_du_fichier(instance, nom):
    """Un nom imprévisible sous un dossier fermé par nginx : jamais servi en direct."""
    import os

    extension = os.path.splitext(nom)[1].lower()[:10]
    return f"visio/fichiers/{instance.salle.nom_livekit}/{uuid.uuid4().hex}{extension}"


class FichierDeSalle(models.Model):
    """
    Un fichier déposé dans une salle (VISIO-01, V2) : annoncé dans le chat,
    téléchargeable par les seuls invités, gardé avec la séance. Servi en
    téléchargement, jamais affiché dans la page (visio/fichiers.py).
    """
    salle = models.ForeignKey(Salle, on_delete=models.CASCADE, related_name="fichiers")
    auteur = models.ForeignKey(Invitation, on_delete=models.SET_NULL, null=True, blank=True,
                               related_name="fichiers")
    nom = models.CharField(_("Nom"), max_length=200)
    fichier = models.FileField(upload_to=_chemin_du_fichier, max_length=255)
    taille = models.PositiveBigIntegerField(default=0)
    depose_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["depose_le"]
        verbose_name = _("Fichier de visio")
        verbose_name_plural = _("Fichiers de visio")

    def __str__(self):
        return self.nom


class Sondage(models.Model):
    """
    Une question posée en séance (VISIO-01, V2) : préparée à l'avance ou en
    direct, lancée par l'hôte, close par lui. Les résultats ne sont montrés
    à tous qu'à la clôture — l'hôte les suit en direct.
    """
    class Etat(models.TextChoices):
        PREPARE = "prepare", _("Préparé")
        OUVERT = "ouvert", _("Ouvert")
        CLOS = "clos", _("Clos")

    salle = models.ForeignKey(Salle, on_delete=models.CASCADE, related_name="sondages")
    question = models.CharField(_("Question"), max_length=300)
    choix = models.JSONField(_("Choix"), default=list)
    plusieurs = models.BooleanField(_("Plusieurs réponses possibles"), default=False)
    etat = models.CharField(max_length=10, choices=Etat.choices, default=Etat.PREPARE)
    cree_le = models.DateTimeField(auto_now_add=True)
    ouvert_le = models.DateTimeField(null=True, blank=True)
    clos_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["cree_le", "pk"]
        verbose_name = _("Sondage de visio")
        verbose_name_plural = _("Sondages de visio")

    def __str__(self):
        return self.question

    def resultats(self):
        """[nombre de voix par choix], dans l'ordre des choix."""
        comptes = [0] * len(self.choix)
        for vote in self.votes.all():
            for i in vote.choix:
                if 0 <= i < len(comptes):
                    comptes[i] += 1
        return comptes

    def en_donnees(self, avec_resultats=False):
        donnees = {"id": self.pk, "question": self.question, "choix": self.choix, "plusieurs": self.plusieurs,
                   "etat": self.etat}
        if avec_resultats or self.etat == self.Etat.CLOS:
            donnees["resultats"] = self.resultats()
            donnees["votants"] = self.votes.count()
        return donnees


class Vote(models.Model):
    sondage = models.ForeignKey(Sondage, on_delete=models.CASCADE, related_name="votes")
    invitation = models.ForeignKey(Invitation, on_delete=models.CASCADE, related_name="votes")
    choix = models.JSONField(default=list)
    vote_le = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["sondage", "invitation"], name="visio_un_vote_par_personne")]


class Attente(models.Model):
    """
    Une personne en liste d'attente d'une séance complète (V2-E). Une place
    libérée prévient toute la liste ; s'inscrire retire de la liste.
    """
    salle = models.ForeignKey(Salle, on_delete=models.CASCADE, related_name="attentes")
    nom = models.CharField(_("Nom"), max_length=200)
    email = models.EmailField(_("E-mail"))
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
                             related_name="attentes_visio")
    cree_le = models.DateTimeField(auto_now_add=True)
    prevenue_le = models.DateTimeField(_("Prévenue le"), null=True, blank=True)

    class Meta:
        ordering = ["cree_le", "pk"]
        verbose_name = _("Liste d'attente de visio")
        verbose_name_plural = _("Listes d'attente de visio")
        constraints = [models.UniqueConstraint(fields=["salle", "email"], name="visio_une_attente_par_adresse")]

    def __str__(self):
        return self.email


class MessageDeChat(models.Model):
    salle = models.ForeignKey(Salle, on_delete=models.CASCADE, related_name="messages")
    auteur = models.ForeignKey(Invitation, on_delete=models.SET_NULL, null=True, blank=True,
                               related_name="messages")
    #: Le nom au moment de l'envoi : une invitation supprimée n'efface pas qui a parlé.
    nom = models.CharField(max_length=200)
    texte = models.TextField(max_length=2000)
    fichier = models.ForeignKey(FichierDeSalle, on_delete=models.SET_NULL, null=True, blank=True,
                                related_name="annonces")
    #: Écrit dans un groupe de travail : ne se lit que dans ce groupe.
    sous_salle = models.ForeignKey(SousSalle, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name="messages")
    envoye_le = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["envoye_le", "pk"]
        verbose_name = _("Message de chat")
        verbose_name_plural = _("Messages de chat")

    def en_donnees(self):
        donnees = {"id": self.pk, "nom": self.nom, "texte": self.texte,
                   "heure": timezone.localtime(self.envoye_le).strftime("%H:%M"),
                   "auteur": self.auteur.identite if self.auteur_id else ""}
        if self.fichier_id:
            donnees["fichier"] = {"id": self.fichier_id, "nom": self.fichier.nom, "taille": self.fichier.taille}
        return donnees


@receiver(post_delete, sender=Salle)
def _retirer_de_la_vente(sender, instance, **kwargs):
    """Une séance supprimée ne laisse pas en vente un produit qui ne sert plus rien."""
    if instance.produit_id:
        from jeiko.shop.models import Product

        Product.objects.filter(pk=instance.produit_id).update(is_active=False)


@receiver(post_delete, sender=FichierDeSalle)
def _retirer_du_disque(sender, instance, **kwargs):
    """Un fichier supprimé — ou sa séance — quitte aussi le disque."""
    if instance.fichier:
        instance.fichier.delete(save=False)
