"""
La séance à inscription, gratuite ou vendue (VISIO-01, V2-E).

« Comme un rendez-vous, mais en produit » (Guillaume, 12/10/2026) : tout se
règle dans la fiche de la séance — places, prix, liste d'attente,
remboursement —, jamais dans Produits. Une séance payante a derrière elle un
produit de la boutique (`synchroniser`), tenu à jour ici : c'est lui qui
passe par le panier, la caisse, Stripe et la facture. Sa disponibilité vient
de la salle (`Product.peut_servir` → `peut_vendre`), pas d'un stock : un
service n'en a pas.

Le parcours :
* gratuit : nom et adresse sur la page publique → invitation + e-mail ;
* payant : la page met le produit au panier ; le paiement (`mark_order_paid`)
  inscrit le compte de la commande (`inscrire_la_commande`) ;
* complet : liste d'attente. Une place libérée prévient TOUTE la liste ; le
  premier qui s'inscrit la prend — aucune place n'est tenue ;
* désinscription par le lien personnel, avant le début : le lien est
  révoqué, la part prévue par la grille remboursée chez Stripe, la liste
  d'attente prévenue. Une commande remboursée depuis la boutique révoque
  aussi le lien (`a_la_commande_remboursee`).

Ce que ça ne fait pas : tenir une place à la personne prévenue (premier
arrivé, premier servi — choix de la conception) ; vendre plusieurs places à
une même personne (une place par compte : quantité 1).
"""
import logging
from datetime import timedelta
from decimal import ROUND_HALF_UP, Decimal

from django.db import transaction
from django.utils import formats, timezone
from django.utils.html import escape
from django.utils.safestring import mark_safe
from django.utils.translation import gettext as _

from . import livekit
from .acces import Refus, inviter, revoquer
from .models import Attente, Invitation, Salle

logger = logging.getLogger(__name__)

CODE_DU_TYPE = "seances_visio"


# --- Places ---

#: Une place est retenue tant que sa commande attend son paiement, depuis sa
#: dernière préparation (VISIO-03). Au-delà, elle revient aux autres ; si le
#: paiement aboutit quand même et que la place est prise, il est remboursé (V-12).
#: ponytail : durée fixe ; un réglage avancé si 15 minutes ne suffisent pas.
RETENUE = timedelta(minutes=15)


def places_retenues(salle, sauf_panier_id=None):
    """Les places des commandes en cours de paiement — sauf celle du panier `sauf_panier_id` (la sienne)."""
    if not salle.produit_id:
        return 0
    from jeiko.shop.models import Order

    commandes = Order.objects.filter(payment_status=Order.PAYMENT_STATUS_PENDING,
                                     updated_at__gte=timezone.now() - RETENUE, lines__product_id=salle.produit_id)
    if sauf_panier_id:
        commandes = commandes.exclude(cart_id=sauf_panier_id)
    return commandes.distinct().count()


def places_restantes(salle, sauf_panier_id=None):
    """
    Ce qu'il reste à prendre : les places réglées, moins celles retenues par un
    paiement en cours, sous le plafond de 50 invitations actives.
    """
    actives = salle.invitations_actives()
    inscrites = actives.filter(inscrite=True).count()
    plafond = min(salle.places or livekit.MAX_PARTICIPANTS, livekit.MAX_PARTICIPANTS)
    retenues = places_retenues(salle, sauf_panier_id)
    return max(0, min(plafond - inscrites, livekit.MAX_PARTICIPANTS - actives.count()) - retenues)


def ouverte(salle):
    """Les inscriptions sont-elles possibles en ce moment (places mises à part) ?"""
    return salle.inscriptions and not salle.terminee and salle.debut > timezone.now()


def peut_vendre(salle, sauf_panier_id=None):
    return ouverte(salle) and places_restantes(salle, sauf_panier_id) > 0


# --- Remboursement ---

def lire_la_grille(texte):
    """
    « 48:100, 24:50 » → [[48, 100], [24, 50]] ; « toujours » → [[0, 100]] ;
    vide → [] (jamais). ValueError si illisible.
    """
    texte = (texte or "").strip().lower()
    if not texte:
        return []
    if texte in ("toujours", "always"):
        return [[0, 100]]
    grille = []
    for morceau in texte.replace(";", ",").split(","):
        heures, _sep, taux = morceau.strip().rstrip("%").partition(":")
        heures, taux = int(heures.strip().rstrip("h")), int(taux.strip().rstrip("%"))
        if heures < 0 or not 0 <= taux <= 100:
            raise ValueError(morceau)
        grille.append([heures, taux])
    return valider_la_grille(grille)


def valider_la_grille(grille):
    """La grille de l'API (liste de [heures, %]), vérifiée et triée. ValueError sinon."""
    propre = []
    for palier in grille or []:
        if not (isinstance(palier, (list, tuple)) and len(palier) == 2
                and all(isinstance(v, int) and not isinstance(v, bool) for v in palier)):
            raise ValueError(palier)
        heures, taux = palier
        if heures < 0 or not 0 <= taux <= 100:
            raise ValueError(palier)
        propre.append([heures, taux])
    return sorted(propre, reverse=True)


def grille_en_texte(grille):
    if not grille:
        return ""
    if grille == [[0, 100]]:
        return "toujours"
    return ", ".join(f"{h}:{t}" for h, t in grille)


def taux_rembourse(salle, maintenant=None, grille=None):
    """
    Le pourcentage remboursé à une désinscription faite maintenant : 0 une
    fois la séance commencée. `grille` : celle acceptée à l'achat (audit V-14).
    """
    heures_avant = (salle.debut - (maintenant or timezone.now())).total_seconds() / 3600
    if heures_avant < 0:
        return 0
    for heures, taux in sorted(salle.remboursement if grille is None else grille, reverse=True):
        if heures_avant >= heures:
            return taux
    return 0


def conditions(salle, grille=None):
    """La grille en une phrase, pour la page publique et les e-mails (en français, comme les e-mails)."""
    grille = sorted(salle.remboursement if grille is None else grille, reverse=True)
    if not salle.prix:
        return ""
    if not grille or all(t == 0 for _h, t in grille):
        return "Aucun remboursement en cas de désinscription."
    if grille == [[0, 100]]:
        return "Remboursement intégral en cas de désinscription avant le début."
    morceaux = [f"{t} % jusqu'à {h} h avant le début" if h else f"{t} % jusqu'au début" for h, t in grille]
    return "Remboursement en cas de désinscription : " + ", ".join(morceaux) + ", rien ensuite."


def montant_rembourse(invitation, maintenant=None):
    taux = taux_rembourse(invitation.salle, maintenant, invitation.remboursement)
    return (invitation.montant_paye * taux / 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


# --- Le produit derrière ---

def _type_de_produit():
    from django.utils.text import slugify

    from jeiko.administration_pages.models import Page
    from jeiko.custom_objects.models import CustomObjectModel
    from jeiko.shop.models import ProductType

    type_produit = ProductType.objects.filter(code=CODE_DU_TYPE).first()
    if type_produit is not None:
        return type_produit
    modele = CustomObjectModel.objects.filter(slug="seances-visio").first()
    if modele is None:
        # Le gabarit ne dessine rien : la fiche d'un produit de séance renvoie
        # à la page publique de la séance (shop.views.client.ProductView).
        tag, n = "gabarit-seances-visio", 2
        while Page.objects.filter(url_tag=tag, langue="").exists():
            tag, n = f"gabarit-seances-visio-{n}", n + 1
        gabarit = Page.objects.create(title="Gabarit — séances en visio", url_tag=tag,
                                      is_custom_object_template=True, active=True)
        modele = CustomObjectModel.objects.create(name="Séances en visio", slug=slugify("seances-visio"),
                                                  page_template=gabarit, is_product=True)
    return ProductType.objects.create(
        name="Séances en visio", code=CODE_DU_TYPE, content_model=modele, kind=ProductType.KIND_SERVICE,
        is_physical=False, requires_shipping=False)


@transaction.atomic
def synchroniser(salle):
    """
    Crée ou tient à jour le produit d'une séance payante ; le retire de la
    vente quand la séance redevient gratuite ou ferme ses inscriptions.
    """
    from jeiko.custom_objects.models import CustomObject, CustomObjectMetadata
    from jeiko.shop.models import Product

    vendue = salle.inscriptions and salle.prix > 0
    produit = salle.produit
    if produit is None:
        if not vendue:
            return None
        type_produit = _type_de_produit()
        fiche = CustomObject.objects.create(model=type_produit.content_model, title=salle.titre[:200],
                                            slug=f"seance-{salle.pk}", is_published=True)
        CustomObjectMetadata.objects.create(obj=fiche, title=salle.titre[:100], description=salle.description[:300])
        sku, n = f"visio-{salle.pk}", 2
        while Product.objects.filter(sku=sku).exists():
            sku, n = f"visio-{salle.pk}-{n}", n + 1
        produit = Product(type=type_produit, content=fiche, sku=sku, tax_rate=type_produit.default_tax_rate,
                          currency=type_produit.default_currency or "EUR")
    taux = produit.tax_rate or Decimal("0")
    produit.price_ht = (salle.prix * 100 / (100 + taux)).quantize(Decimal("0.0001"))
    produit.is_active = vendue
    produit.save()
    fiche = produit.content
    if fiche.title != salle.titre[:200]:
        fiche.title = salle.titre[:200]
        fiche.save(update_fields=["title"])
    CustomObjectMetadata.objects.filter(obj=fiche).update(title=salle.titre[:100],
                                                          description=salle.description[:300])
    if salle.produit_id != produit.pk:
        Salle.objects.filter(pk=salle.pk).update(produit=produit)
        salle.produit = produit
    return produit


# --- S'inscrire ---

@transaction.atomic
def inscrire(salle, *, nom="", email="", user=None, commande=None, montant=Decimal("0"), forcer=False):
    """
    L'invitation d'une personne inscrite, et son e-mail. `forcer` : une place
    payée est honorée même si les places réglées viennent d'être prises — le
    plafond de 50, lui, tient toujours (`inviter` refuse : Refus).
    """
    salle = Salle.objects.select_for_update().get(pk=salle.pk)
    if forcer:
        # Une place payée : honorée tant que la séance peut encore avoir lieu
        # (audit V-08 — après la fin, elle est remboursée, jamais un lien mort)…
        if salle.terminee or salle.fin <= timezone.now():
            raise Refus(_("Cette séance est terminée."))
    elif not ouverte(salle):
        raise Refus(_("Les inscriptions à cette séance sont closes."))
    # … et les places réglées tiennent, même payées : deux paniers sur la
    # dernière place, le second est remboursé (audit V-12). Sa propre retenue
    # ne compte pas contre soi (VISIO-03).
    if places_restantes(salle, commande.cart_id if commande is not None else None) <= 0:
        raise Refus(_("Cette séance est complète."))
    invitation = inviter(salle, nom=nom, email=email, user=user, role=Invitation.Role.PARTICIPANT)
    if invitation.inscrite and invitation.commande_id and commande is not None:
        raise DejaInscrite(invitation)
    invitation.inscrite = True
    if commande is not None:
        # Le montant NET payé pour cette place, et la grille acceptée : ce que
        # la désinscription rendra (audit V-06, V-14).
        invitation.commande, invitation.montant_paye = commande, montant
        invitation.remboursement = list(salle.remboursement or [])
        invitation.remboursement_annulation = list(salle.remboursement_annulation or [])
    invitation.save(update_fields=["inscrite", "commande", "montant_paye", "remboursement",
                                   "remboursement_annulation"])
    Attente.objects.filter(salle=salle, email__iexact=invitation.email).delete()
    transaction.on_commit(lambda: _envoyer(invitation.pk))
    return invitation


class DejaInscrite(Refus):
    """La personne a déjà payé sa place : la seconde commande se rembourse."""

    def __init__(self, invitation):
        super().__init__(_("Vous êtes déjà inscrit(e) à cette séance."))
        self.invitation = invitation


def _envoyer(invitation_pk):
    """VISIO-02 : une place prise reçoit la confirmation de sa réservation — un
    e-mail du catalogue à part (`visio_reservation`), avec son lien personnel."""
    from .emails import envoyer_l_invitation

    invitation = Invitation.objects.select_related("salle", "user").filter(pk=invitation_pk).first()
    if invitation is not None:
        envoyer_l_invitation(invitation, code="visio_reservation")


def inscrire_la_commande(order, lines):
    """
    Appelé par `mark_order_paid`, dans sa transaction : chaque séance de la
    commande inscrit son compte. Une place impossible (plafond de 50, déjà
    inscrit) est remboursée en entier après validation. Ne lève jamais.
    """
    from jeiko.shop import promotions

    # La remise d'un code promo, répartie sur les lignes comme sur la facture :
    # la place vaut ce qui a été PAYÉ pour elle (audit V-06).
    parts = promotions.repartir(order.coupon, lines, order.discount_ttc or 0) if order.coupon_id else {}
    for ligne in lines:
        salle = getattr(ligne.product, "salle_visio", None) if ligne.product_id else None
        if salle is None or order.user is None:
            continue
        montant = max(Decimal("0"), ligne.total_ttc - parts.get(ligne.pk, Decimal("0"))).quantize(Decimal("0.01"))
        try:
            with transaction.atomic():
                inscrire(salle, user=order.user, email=order.user.email, commande=order, montant=montant,
                         forcer=True)
        except Refus as refus:
            motif = str(refus)
        except Exception as erreur:  # noqa: BLE001 — une place non livrée se rembourse, elle ne disparaît pas
            logger.exception("Commande #%s : inscription à la séance #%s impossible", order.pk, salle.pk)
            motif = f"Inscription impossible : {erreur}"
        else:
            continue
        logger.warning("Commande #%s : place de la séance #%s impossible (%s) — remboursée.",
                       order.pk, salle.pk, motif)
        if montant > 0:
            mettre_en_file(order, salle, montant, motif)


# --- La file des remboursements (audit V-07) ---

#: Essais automatiques : aussitôt, puis 5, 15, 45 et 135 minutes après — moins
#: de 24 h en tout, la durée de la clé d'idempotence de Stripe.
ESSAIS = 5


def _delai(tentatives):
    return timedelta(minutes=5 * 3 ** (tentatives - 1))


def mettre_en_file(order, salle, montant, motif):
    """
    Inscrit le remboursement d'une place non livrée DANS la transaction en
    cours (celle du paiement) : il ne peut plus se perdre. Le premier essai
    part après validation ; les suivants, par cron_5m.
    """
    from .models import RemboursementDePlace

    a_faire = RemboursementDePlace.objects.create(commande=order, salle=salle, titre=salle.titre[:200],
                                                 montant=montant, motif=motif[:255])
    transaction.on_commit(lambda: executer(a_faire.pk))
    return a_faire


def executer(pk):
    """
    Un essai de remboursement. Rend l'entrée de la file à jour. Ne lève pas :
    un échec est compté, daté, et l'exploitant est alerté au premier et au
    dernier — l'entrée reste à l'écran Conférence › Remboursements.
    """
    from jeiko.shop.remboursement import RemboursementImpossible, rembourser

    from .models import RemboursementDePlace

    with transaction.atomic():
        a_faire = RemboursementDePlace.objects.select_for_update().select_related("commande").filter(pk=pk).first()
        if a_faire is None or a_faire.etat not in (RemboursementDePlace.Etat.A_FAIRE, RemboursementDePlace.Etat.EN_ECHEC):
            return a_faire
        maintenant = timezone.now()
        try:
            rembourser(a_faire.commande, a_faire.montant, motif=a_faire.motif,
                       cle_idempotence=a_faire.cle_stripe)
        except RemboursementImpossible as erreur:
            a_faire.tentatives += 1
            a_faire.derniere_erreur = str(erreur)[:2000]
            if a_faire.tentatives >= ESSAIS:
                a_faire.etat, a_faire.prochain_essai = RemboursementDePlace.Etat.EN_ECHEC, None
            else:
                a_faire.etat, a_faire.prochain_essai = RemboursementDePlace.Etat.A_FAIRE, maintenant + _delai(a_faire.tentatives)
            alerter = a_faire.tentatives == 1 or a_faire.etat == RemboursementDePlace.Etat.EN_ECHEC
            if alerter:
                a_faire.alerte_envoyee_le = maintenant
            a_faire.save()
            logger.error("Commande #%s : remboursement de la place (essai %s) impossible — %s",
                         a_faire.commande_id, a_faire.tentatives, erreur)
        else:
            alerter = False
            a_faire.etat, a_faire.regle_le, a_faire.prochain_essai = RemboursementDePlace.Etat.FAIT, maintenant, None
            a_faire.save()
    if alerter:
        _alerter(a_faire)
    return a_faire


def _alerter(a_faire):
    try:
        from jeiko.emailing.admin_alerts import notifier_erreur

        suite = ("Nouvel essai automatique dans quelques minutes." if a_faire.etat == a_faire.Etat.A_FAIRE
                 else "Les essais automatiques sont épuisés : à régler depuis Conférence › Remboursements.")
        notifier_erreur("Place de visio payée, ni livrée ni remboursée",
                        f"Commande #{a_faire.commande_id} — séance « {a_faire.titre} » : la place n'a pu être "
                        f"livrée ({a_faire.motif}) et le remboursement de {a_faire.montant} a échoué "
                        f"({a_faire.derniere_erreur}). {suite}")
    except Exception:  # noqa: BLE001 — l'alerte ne doit pas masquer le reste
        logger.exception("Alerte de la commande #%s non envoyée", a_faire.commande_id)


def relancer_les_remboursements():
    """cron_5m : les essais dont l'heure est venue — et un premier essai perdu (arrêt pendant le paiement)."""
    from django.db.models import Q

    from .models import RemboursementDePlace

    maintenant = timezone.now()
    dus = RemboursementDePlace.objects.filter(etat=RemboursementDePlace.Etat.A_FAIRE).filter(
        Q(prochain_essai__lte=maintenant)
        | Q(prochain_essai__isnull=True, tentatives=0, cree_le__lte=maintenant - timedelta(minutes=2)))
    faits = [executer(pk) for pk in dus.values_list("pk", flat=True)]
    return len(faits)


def regler_a_la_main(a_faire):
    """Remboursé hors du site (tableau de bord Stripe, virement) : la file l'oublie, sans rien envoyer."""
    from .models import RemboursementDePlace

    if a_faire.etat in (RemboursementDePlace.Etat.FAIT, RemboursementDePlace.Etat.A_LA_MAIN):
        raise Refus(_("Ce remboursement est déjà réglé."))
    RemboursementDePlace.objects.filter(pk=a_faire.pk).update(
        etat=RemboursementDePlace.Etat.A_LA_MAIN, regle_le=timezone.now(), prochain_essai=None)


def reessayer(a_faire):
    """« Réessayer » de l'écran : un essai tout de suite, compté comme les autres."""
    from .models import RemboursementDePlace

    if a_faire.etat not in (RemboursementDePlace.Etat.A_FAIRE, RemboursementDePlace.Etat.EN_ECHEC):
        raise Refus(_("Ce remboursement est déjà réglé."))
    return executer(a_faire.pk)


def places_payees(salle):
    """Les places payées encore valables : tant qu'il y en a, la séance ne se supprime pas (audit V-13)."""
    return salle.invitations_actives().filter(inscrite=True, montant_paye__gt=0)


# --- Se désinscrire ---

def peut_se_desinscrire(invitation):
    return (invitation.inscrite and not invitation.revoquee and not invitation.anime
            and invitation.salle.debut > timezone.now() and not invitation.salle.terminee)


@transaction.atomic
def desinscrire(invitation):
    """
    Révoque le lien, rembourse la part prévue, prévient la liste d'attente.
    Rend le montant remboursé. Un remboursement refusé par Stripe annule
    tout : la personne garde sa place (Refus).
    """
    from jeiko.shop.remboursement import RemboursementImpossible, rembourser

    invitation = Invitation.objects.select_for_update(of=("self",)).select_related("salle", "commande").get(pk=invitation.pk)
    if not peut_se_desinscrire(invitation):
        raise Refus(_("Cette inscription ne peut plus être annulée."))
    montant = montant_rembourse(invitation)
    if invitation.commande_id:
        # Jamais plus que ce qui reste à rendre sur la commande.
        montant = min(montant, invitation.commande.amount_refundable)
    invitation.revoquee_le = invitation.desinscrite_le = timezone.now()
    invitation.save(update_fields=["revoquee_le", "desinscrite_le"])
    if montant > 0 and invitation.commande_id:
        try:
            rembourser(invitation.commande, montant, motif=f"Désinscription : {invitation.salle.titre}"[:255])
        except RemboursementImpossible as erreur:
            raise Refus(_("Le remboursement a échoué ; votre place est gardée. Contactez l'organisateur.")) from erreur
    transaction.on_commit(lambda: prevenir_l_attente(invitation.salle_id))
    return montant


def rendre_la_place(order, salle):
    """La place de `order` dans `salle` est rendue (remboursement partiel depuis la boutique) ; rien d'autre."""
    from .acces import retirer_partout

    for invitation in order.invitations_visio.filter(salle=salle, revoquee_le__isnull=True):
        revoquer(invitation)
        retirer_partout(salle, invitation)
    transaction.on_commit(lambda: prevenir_l_attente(salle.pk))


def a_la_commande_remboursee(order):
    """Une commande remboursée en entier depuis la boutique : ses places sont rendues."""
    from .acces import retirer_partout

    salles = set()
    for invitation in order.invitations_visio.filter(revoquee_le__isnull=True).select_related("salle"):
        revoquer(invitation)
        retirer_partout(invitation.salle, invitation)  # déjà connecté : retiré aussi (audit V-03)
        salles.add(invitation.salle_id)
    for salle_id in salles:
        transaction.on_commit(lambda s=salle_id: prevenir_l_attente(s))


# --- L'organisateur annule (VISIO-03) ---

@transaction.atomic
def annuler(salle, motif=""):
    """
    Annule une séance pour tout le monde, avant son début : les liens sont
    révoqués, chaque place payée remboursée selon la grille d'annulation
    acceptée à l'achat — comptée à l'heure de l'annulation —, chaque invité
    prévenu par e-mail, la liste d'attente vidée, le produit retiré de la vente.

    Les remboursements passent par la file des places (`mettre_en_file`) :
    essais répétés, alerte à l'exploitant, écran Conférence › Remboursements.
    Rend le bilan : {"invites", "rembourses", "montant", "sans_remboursement"}.

    Ce qu'elle ne fait pas : reporter la séance (changer la date garde les
    inscrits) ; annuler une séance commencée (la terminer).
    """
    from .acces import retirer_partout, terminer

    salle = Salle.objects.select_for_update().get(pk=salle.pk)
    if salle.annulee_le or salle.terminee:
        raise Refus(_("Cette séance est déjà terminée ou annulée."))
    maintenant = timezone.now()
    if salle.debut <= maintenant:
        raise Refus(_("La séance a commencé : terminez-la plutôt que de l'annuler."))
    salle.annulee_le, salle.motif_annulation, salle.inscriptions = maintenant, (motif or "")[:500], False
    salle.save(update_fields=["annulee_le", "motif_annulation", "inscriptions"])
    try:
        terminer(salle)
    except livekit.LiveKitIndisponible:
        pass  # la salle n'a peut-être jamais existé chez LiveKit ; elle est close ici
    synchroniser(salle)
    bilan = {"invites": 0, "rembourses": 0, "montant": Decimal("0"), "sans_remboursement": 0}
    for invitation in (salle.invitations_actives().exclude(role=Invitation.Role.HOTE)
                       .select_related("commande")):
        montant = Decimal("0")
        if invitation.commande_id and invitation.montant_paye > 0:
            grille = (invitation.remboursement_annulation if invitation.remboursement_annulation is not None
                      else salle.remboursement_annulation)
            taux = taux_rembourse(salle, maintenant, grille)
            montant = min((invitation.montant_paye * taux / 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP),
                          invitation.commande.amount_refundable)
            if montant > 0:
                mettre_en_file(invitation.commande, salle, montant, f"Séance annulée : {salle.titre}")
                bilan["rembourses"] += 1
                bilan["montant"] += montant
            else:
                bilan["sans_remboursement"] += 1
        revoquer(invitation)
        retirer_partout(salle, invitation)
        bilan["invites"] += 1
        transaction.on_commit(lambda pk=invitation.pk, m=montant: _prevenir_de_l_annulation(pk, m))
    salle.attentes.all().delete()
    return bilan


def _prevenir_de_l_annulation(invitation_pk, montant):
    """L'e-mail `visio_annulee` (en français, comme les autres). Ne lève jamais."""
    from jeiko.emailing.services import send_email

    invitation = Invitation.objects.select_related("salle", "user").filter(pk=invitation_pk).first()
    if invitation is None or not invitation.email:
        return
    salle = invitation.salle
    if montant > 0:
        remboursement = (f"Votre place est remboursée : {montant:.2f} {salle.devise}, sur le moyen de paiement "
                         "utilisé, dans les prochains jours.").replace(".", ",", 1)
    elif invitation.montant_paye > 0:
        remboursement = "Selon les conditions acceptées à l'achat, cette annulation ne donne pas lieu à remboursement."
    else:
        remboursement = ""
    try:
        send_email("visio_annulee", invitation.email, {
            "invite_nom": invitation.nom, "titre": salle.titre,
            "date": formats.date_format(timezone.localtime(salle.debut), "l j F Y \\à H\\hi"),
            "motif": salle.motif_annulation, "remboursement": remboursement,
        }, user=invitation.user)
    except Exception:  # noqa: BLE001 — l'annulation est faite ; l'e-mail manqué se voit au journal
        logger.exception("Visio : annulation non envoyée à l'invitation #%s", invitation_pk)


def conditions_d_annulation(salle):
    """La grille d'annulation en une phrase (page publique, en français comme les e-mails)."""
    grille = sorted(salle.remboursement_annulation or [], reverse=True)
    if not salle.prix:
        return ""
    if grille == [[0, 100]]:
        return "Si l'organisateur annule la séance, votre place est remboursée en entier."
    if not grille or all(t == 0 for _h, t in grille):
        return "Si l'organisateur annule la séance, aucun remboursement n'est prévu."
    morceaux = [f"{t} % s'il annule plus de {h} h avant le début" if h else f"{t} % s'il annule avant le début"
                for h, t in grille]
    return "Si l'organisateur annule la séance : " + ", ".join(morceaux) + "."


# --- La liste d'attente ---

def rejoindre_l_attente(salle, *, nom="", email="", user=None):
    if not (salle.liste_d_attente and ouverte(salle)):
        raise Refus(_("Cette séance ne propose pas de liste d'attente."))
    email = (email or (user.email if user else "")).strip().lower()
    attente, _cree = Attente.objects.get_or_create(
        salle=salle, email=email,
        defaults={"nom": (nom or email.split("@")[0])[:200], "user": user})
    return attente


def prevenir_l_attente(salle_id):
    """Une place s'est libérée : toute la liste reçoit le lien de la page. Rend le nombre d'e-mails. Ne lève jamais."""
    from jeiko.emailing.admin_alerts import _lien_absolu
    from jeiko.emailing.services import send_email

    salle = Salle.objects.filter(pk=salle_id).first()
    if salle is None or not ouverte(salle) or places_restantes(salle) <= 0:
        return 0
    envoyes = 0
    date = formats.date_format(timezone.localtime(salle.debut), "l j F Y \\à H\\hi")
    for attente in salle.attentes.all():
        try:
            ok, _raison = send_email("visio_place_liberee", attente.email, {
                "invite_nom": attente.nom, "titre": salle.titre, "date": date,
                "lien_action": _lien_absolu("jeiko_visio:seance", salle.jeton_public),
            }, user=attente.user)
        except Exception:
            logger.exception("Visio : liste d'attente #%s non prévenue", attente.pk)
            ok = False
        if ok:
            Attente.objects.filter(pk=attente.pk).update(prevenue_le=timezone.now())
            envoyes += 1
    return envoyes


# --- Dans les e-mails ---

def paragraphe_de_desinscription(invitation):
    """
    Le lien « Me désinscrire » d'une personne inscrite, pour l'invitation et
    les rappels (variable `lien_desinscription` : jamais gardée au journal).
    Vide pour les autres.
    """
    from jeiko.emailing.admin_alerts import _lien_absolu

    if not peut_se_desinscrire(invitation):
        return ""
    lien = _lien_absolu("jeiko_visio:desinscrire", invitation.code)
    texte = escape(conditions(invitation.salle, invitation.remboursement))
    return mark_safe(f'<p>Vous ne pourrez pas venir ? <a href="{escape(lien)}">Me désinscrire</a> '
                     f"libère votre place pour une autre personne. {texte}</p>")
