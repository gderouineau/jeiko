from django import forms
import json
from datetime import datetime

from django.core.exceptions import ValidationError

from .models import Appointment, AppointmentType, Availability, GoogleCalendarConfig, Slot
from .recurrence import build_rrulestr, WEEKDAY_TOKENS


WEEKDAYS = [
    ("MO", "Lundi"),
    ("TU", "Mardi"),
    ("WE", "Mercredi"),
    ("TH", "Jeudi"),
    ("FR", "Vendredi"),
    ("SA", "Samedi"),
    ("SU", "Dimanche"),
]


def _parse_recurrence_block(rule_text: str):
    """
    Parse un bloc multi-lignes (DTSTART / RRULE / EXDATE) et renvoie:
    {
        'freq': 'DAILY' | 'WEEKLY' | None,
        'byday': ['MO','TU',...],
        'until_date': date | None,
        'exdates': ['YYYY-MM-DD', ...],
    }
    """
    out = {'freq': None, 'byday': [], 'until_date': None, 'exdates': []}
    if not rule_text:
        return out

    lines = [ln.strip() for ln in rule_text.splitlines() if ln and ln.strip()]
    rrule_line = next((ln for ln in lines if ln.startswith('RRULE:')), None)
    exdate_lines = [ln for ln in lines if ln.startswith('EXDATE:')]

    # RRULE
    if rrule_line:
        # ex: RRULE:FREQ=WEEKLY;BYDAY=TH;UNTIL=20251231T235959Z
        parts = rrule_line[len('RRULE:'):].split(';')
        kv = {}
        for p in parts:
            if '=' in p:
                k, v = p.split('=', 1)
                kv[k.upper()] = v

        freq = kv.get('FREQ')
        if freq in ('DAILY', 'WEEKLY'):
            out['freq'] = freq

        byday = kv.get('BYDAY')
        if byday:
            out['byday'] = [s.strip() for s in byday.split(',') if s.strip()]

        until = kv.get('UNTIL')
        if until:
            # formats typiques : 20251130T235959Z ou 20251130T235959
            until = until.rstrip('Z')
            try:
                dt = datetime.strptime(until, "%Y%m%dT%H%M%S")
                out['until_date'] = dt.date()
            except Exception:
                out['until_date'] = None

    # EXDATE
    exdates = []
    for ln in exdate_lines:
        # ex: EXDATE:20251111T140000Z
        val = ln[len('EXDATE:'):].strip().rstrip('Z')
        try:
            dt = datetime.strptime(val, "%Y%m%dT%H%M%S")
            exdates.append(dt.date().isoformat())
        except Exception:
            # si jamais format différent, on ignore
            pass
    out['exdates'] = exdates

    return out


class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ['slot', 'email']  # Ajoute 'user' côté vue si connecté

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Affiche seulement les slots disponibles
        self.fields['slot'].queryset = Slot.objects.filter(is_available=True, remaining_places__gt=0)
        self.fields['slot'].label = "Créneau souhaité"
        self.fields['slot'].empty_label = "Choisissez un créneau"

    def clean_slot(self):
        slot = self.cleaned_data['slot']
        if not slot.is_available or slot.remaining_places <= 0:
            raise ValidationError("Ce créneau n'est plus disponible, veuillez en choisir un autre.")
        return slot


class AppointmentFormAdmin(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ["type", "slot", "email", "is_paid", "start", "end"]

    def clean(self):
        cleaned = super().clean()
        slot = cleaned.get("slot")
        apptype = cleaned.get("type")
        if slot and apptype and slot.type_id != apptype.id:
            self.add_error("slot", "Le créneau choisi n’appartient pas à ce type de rendez-vous.")
        return cleaned


class AppointmentTypeForm(forms.ModelForm):
    class Meta:
        model = AppointmentType
        fields = [
            "name",
            "duration",
            "is_paid",
            "is_registration_required",
            "color",
            "font",
            "description",
            "capacity",
        ]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ex. Séance découverte"}),
            # DurationField attend un format 'HH:MM:SS' (Django natif). Tu peux accepter HH:MM aussi.
            "duration": forms.TextInput(attrs={"class": "form-control", "placeholder": "HH:MM:SS (ex. 01:30:00)"}),
            "is_paid": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "is_registration_required": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "color": forms.TextInput(attrs={"type": "color", "class": "form-control form-control-color"}),
            "font": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ex. Inter"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 4}),
            "capacity": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
        }

    def clean_color(self):
        color = self.cleaned_data.get("color", "").strip()
        # On tolère #RGB, #RRGGBB (simple)
        import re
        if not re.fullmatch(r"#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})", color):
            raise forms.ValidationError("Couleur invalide. Utilise un code hexadécimal (#RRGGBB).")
        return color


class AvailabilityForm(forms.ModelForm):
    # ----- Champs UI non-modèles -----
    recurrence_freq = forms.ChoiceField(
        choices=[("NONE", "Aucune"), ("DAILY", "Quotidien"), ("WEEKLY", "Hebdomadaire")],
        required=False, initial="NONE", label="Récurrence"
    )
    recurrence_until = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),  # <-- ajout du format
        label="Jusqu’au"
    )
    # Pour WEEKLY : jours inclus ; pour DAILY : jours à garder (exclure weekend, etc.)
    recurrence_byweekday = forms.MultipleChoiceField(
        choices=WEEKDAYS, required=False, label="Jours (BYDAY)"
    )
    recurrence_exdates_text = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={"rows": 3, "placeholder": "YYYY-MM-DD (une par ligne)"}),
        label="Dates à exclure (EXDATE)"
    )

    class Meta:
        model = Availability
        # IMPORTANT: on inclut 'recurrence_exdates' pour qu'il soit sauvé !
        fields = ['appointment_types', 'start', 'end', 'recurring_rule', 'recurrence_exdates', 'is_available']
        widgets = {
            'appointment_types': forms.SelectMultiple(),
            'start': forms.DateTimeInput(
                attrs={'type': 'datetime-local'},
                format='%Y-%m-%dT%H:%M'
            ),
            'end': forms.DateTimeInput(
                attrs={'type': 'datetime-local'},
                format='%Y-%m-%dT%H:%M'
            ),
            'recurring_rule': forms.Textarea(
                attrs={'rows': 3, 'placeholder': '(généré automatiquement)'}
            ),
            # on peut masquer la version JSON si tu ne veux pas l'afficher
            'recurrence_exdates': forms.HiddenInput(),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # formats date-heure
        for f in ['start', 'end']:
            if self.instance and getattr(self.instance, f):
                self.fields[f].initial = getattr(self.instance, f).strftime('%Y-%m-%dT%H:%M')
            self.fields[f].widget.format = '%Y-%m-%dT%H:%M'
            self.fields[f].localize = False

        # Aide si règle existante
        if self.instance and self.instance.recurring_rule:
            self.fields['recurring_rule'].help_text = "Règle iCal existante. Modifier plutôt via les champs ci-dessus."

        # Pré-remplissage des champs UI à partir de recurring_rule / recurrence_exdates
        if self.instance and (self.instance.recurring_rule or getattr(self.instance, 'recurrence_exdates', None)):
            parsed = _parse_recurrence_block(self.instance.recurring_rule or "")
            # freq
            if parsed['freq']:
                self.fields['recurrence_freq'].initial = parsed['freq']
                self.initial['recurrence_freq'] = parsed['freq']
            # BYDAY
            if parsed['byday']:
                self.fields['recurrence_byweekday'].initial = parsed['byday']
                self.initial['recurrence_byweekday'] = parsed['byday']
            # UNTIL
            if parsed['until_date']:
                self.fields['recurrence_until'].initial = parsed['until_date']
                self.initial['recurrence_until'] = parsed['until_date']
            # EXDATE (priorité au JSONField si présent, sinon parsing)
            ex_from_model = getattr(self.instance, 'recurrence_exdates', None)
            ex_list = ex_from_model if ex_from_model else parsed['exdates']
            if ex_list:
                text = "\n".join(ex_list)
                self.fields['recurrence_exdates_text'].initial = text
                self.initial['recurrence_exdates_text'] = text

        # Cases à cocher en ligne (chips)
        self.fields['recurrence_byweekday'].widget = forms.CheckboxSelectMultiple(choices=WEEKDAYS)
        self.fields['recurrence_byweekday'].widget.attrs.update({'class': 'weekday-checkboxes'})

    def clean(self):
        cleaned = super().clean()
        freq = cleaned.get("recurrence_freq") or "NONE"
        start = cleaned.get("start")
        end = cleaned.get("end")

        if not start or not end:
            return cleaned

        if freq == "NONE":
            cleaned['recurring_rule'] = ""
            cleaned['recurrence_exdates'] = []
            return cleaned

        byday = cleaned.get("recurrence_byweekday") or None
        until = cleaned.get("recurrence_until")

        # parse exdates textarea -> JSON list
        ex_text = cleaned.get("recurrence_exdates_text") or ""
        exdates = []
        for line in ex_text.splitlines():
            s = line.strip()
            if not s:
                continue
            # validation très simple YYYY-MM-DD
            try:
                y, m, d = map(int, s.split("-"))
                _ = f"{y:04d}-{m:02d}-{d:02d}"
                exdates.append(_)
            except Exception:
                raise forms.ValidationError(f"EXDATE invalide: {s} (format attendu YYYY-MM-DD)")

        # Si WEEKLY et aucun jour sélectionné => jour de start
        if freq == "WEEKLY" and not byday:
            # 0=lundi -> "MO"
            byday = [WEEKDAY_TOKENS[start.weekday()]]

        # Si DAILY et aucun byday, on garde tous les jours (MO..SU)
        if freq == "DAILY" and not byday:
            byday = WEEKDAY_TOKENS

        # Construit la règle iCal (DTSTART + RRULE + EXDATE...)
        rule = build_rrulestr(
            start=start, freq=freq, until_date=until, byday=byday, exdates=exdates
        )

        cleaned['recurring_rule'] = rule
        cleaned['recurrence_exdates'] = exdates  # <- sera bien sauvé car field inclus en Meta
        return cleaned


class GoogleCalendarConfigForm(forms.ModelForm):
    class Meta:
        model = GoogleCalendarConfig
        fields = ['name', 'credentials_json', 'calendar_id']
        widgets = {
            'credentials_json': forms.Textarea(attrs={
                'rows': 8,
                'placeholder': 'Collez ici le JSON des credentials Google Service Account'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        instance = kwargs.get('instance')
        if instance and instance.credentials_json:
            # on pretty-print dans le champ
            self.fields['credentials_json'].initial = json.dumps(instance.credentials_json, indent=2, ensure_ascii=False)

    def clean_credentials_json(self):
        data = self.cleaned_data['credentials_json']
        if isinstance(data, dict):
            return data
        try:
            return json.loads(data)
        except Exception:
            raise forms.ValidationError("Le champ doit contenir un JSON valide.")
