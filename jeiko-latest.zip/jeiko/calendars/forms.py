from django import forms
import json

from .models import Appointment, AppointmentType, Availability, GoogleCalendarConfig, Slot
from django.core.exceptions import ValidationError

class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ['slot', 'email']  # Ajoute 'user' côté vue si connecté

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Affiche seulement les slots disponibles
        self.fields['slot'].queryset = Slot.objects.filter(is_available=True, remaining_places__gt=0)
        self.fields['slot'].label = "Créneau souhaité"
        self.fields['slot'].empty_label = "Choisissez un créneau"

    def clean_slot(self):
        slot = self.cleaned_data['slot']
        if not slot.is_available or slot.remaining_places <= 0:
            raise ValidationError("Ce créneau n'est plus disponible, veuillez en choisir un autre.")
        return slot

class AppointmentFormAdmin(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ["type", "slot", "email", "is_paid", "start", "end"]
        # NOTE: Si tu veux éviter l’édition libre de start/end (et préférer le slot),
        # enlève start/end des fields, et en "clean" fais correspondre au slot.

    def clean(self):
        cleaned = super().clean()
        slot = cleaned.get("slot")
        apptype = cleaned.get("type")
        if slot and apptype and slot.type_id != apptype.id:
            self.add_error("slot", "Le créneau choisi n’appartient pas à ce type de rendez-vous.")
        return cleaned


class AppointmentTypeForm(forms.ModelForm):
    class Meta:
        model = AppointmentType
        fields = [
            "name",
            "duration",
            "is_paid",
            "is_registration_required",
            "color",
            "font",
            "description",
            "capacity",
        ]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ex. Séance découverte"}),
            # DurationField attend un format 'HH:MM:SS' (Django natif). Tu peux accepter HH:MM aussi.
            "duration": forms.TextInput(attrs={"class": "form-control", "placeholder": "HH:MM:SS (ex. 01:30:00)"}),
            "is_paid": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "is_registration_required": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "color": forms.TextInput(attrs={"type": "color", "class": "form-control form-control-color"}),
            "font": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ex. Inter"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 4}),
            "capacity": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
        }

    def clean_color(self):
        color = self.cleaned_data.get("color", "").strip()
        # On tolère #RGB, #RRGGBB (simple)
        import re
        if not re.fullmatch(r"#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})", color):
            raise forms.ValidationError("Couleur invalide. Utilise un code hexadécimal (#RRGGBB).")
        return color

### 3. Formulaire pour ajouter/modifier une plage de disponibilité (admin) ###
class AvailabilityForm(forms.ModelForm):

    class Meta:
        model = Availability
        fields = ['appointment_types', 'start', 'end', 'recurring_rule', 'is_available']
        widgets = {
            'appointment_types': forms.SelectMultiple(),
            'start': forms.DateTimeInput(
                attrs={'type': 'datetime-local'},
                format='%Y-%m-%dT%H:%M'   # <- Force le bon format pour l'input !
            ),
            'end': forms.DateTimeInput(
                attrs={'type': 'datetime-local'},
                format='%Y-%m-%dT%H:%M'
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for f in ['start', 'end']:
            if self.instance and getattr(self.instance, f):
                self.fields[f].initial = getattr(self.instance, f).strftime('%Y-%m-%dT%H:%M')
            # Surcharge le format (important si tu utilises localisation dans settings.py !)
            self.fields[f].widget.format = '%Y-%m-%dT%H:%M'
            self.fields[f].localize = False

class GoogleCalendarConfigForm(forms.ModelForm):
    class Meta:
        model = GoogleCalendarConfig
        fields = ['name', 'credentials_json']
        widgets = {
            'credentials_json': forms.Textarea(attrs={
                'rows': 8,
                'placeholder': 'Collez ici le JSON des credentials Google Service Account'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        instance = kwargs.get('instance')
        if instance and instance.credentials_json:
            # Ici : on met le JSON “pretty-printed” dans le champ du formulaire
            self.fields['credentials_json'].initial = json.dumps(instance.credentials_json, indent=2, ensure_ascii=False)

    def clean_credentials_json(self):
        data = self.cleaned_data['credentials_json']
        if isinstance(data, dict):
            return data
        try:
            return json.loads(data)
        except Exception:
            raise forms.ValidationError("Le champ doit contenir un JSON valide.")
