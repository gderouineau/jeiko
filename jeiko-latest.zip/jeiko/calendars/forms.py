from django import forms
import json

from .models import Appointment, AppointmentType, Availability, GoogleCalendarConfig
from django.core.exceptions import ValidationError

class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ['slot', 'email']  # Ajoute 'user' côté vue si connecté

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Affiche seulement les slots disponibles
        self.fields['slot'].queryset = Slot.objects.filter(is_available=True, remaining_places__gt=0)
        self.fields['slot'].label = "Créneau souhaité"
        self.fields['slot'].empty_label = "Choisissez un créneau"

    def clean_slot(self):
        slot = self.cleaned_data['slot']
        if not slot.is_available or slot.remaining_places <= 0:
            raise ValidationError("Ce créneau n'est plus disponible, veuillez en choisir un autre.")
        return slot

class AppointmentTypeForm(forms.ModelForm):
    class Meta:
        model = AppointmentType
        fields = [
            'name', 'duration', 'is_paid', 'is_registration_required',
            'color', 'font', 'description', 'capacity'
        ]
        widgets = {
            'color': forms.TextInput(attrs={'type': 'color'}),
            'duration': forms.TimeInput(attrs={'type': 'time', 'step': 900}),
            'font': forms.TextInput(attrs={'placeholder': 'Ex: Inter, Arial...'}),
        }

### 3. Formulaire pour ajouter/modifier une plage de disponibilité (admin) ###
class AvailabilityForm(forms.ModelForm):

    class Meta:
        model = Availability
        fields = ['appointment_types', 'start', 'end', 'recurring_rule', 'is_available']
        widgets = {
            'appointment_types': forms.SelectMultiple(),
            'start': forms.DateTimeInput(
                attrs={'type': 'datetime-local'},
                format='%Y-%m-%dT%H:%M'   # <- Force le bon format pour l'input !
            ),
            'end': forms.DateTimeInput(
                attrs={'type': 'datetime-local'},
                format='%Y-%m-%dT%H:%M'
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for f in ['start', 'end']:
            if self.instance and getattr(self.instance, f):
                self.fields[f].initial = getattr(self.instance, f).strftime('%Y-%m-%dT%H:%M')
            # Surcharge le format (important si tu utilises localisation dans settings.py !)
            self.fields[f].widget.format = '%Y-%m-%dT%H:%M'
            self.fields[f].localize = False

class GoogleCalendarConfigForm(forms.ModelForm):
    class Meta:
        model = GoogleCalendarConfig
        fields = ['name', 'credentials_json']
        widgets = {
            'credentials_json': forms.Textarea(attrs={
                'rows': 8,
                'placeholder': 'Collez ici le JSON des credentials Google Service Account'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        instance = kwargs.get('instance')
        if instance and instance.credentials_json:
            # Ici : on met le JSON “pretty-printed” dans le champ du formulaire
            self.fields['credentials_json'].initial = json.dumps(instance.credentials_json, indent=2, ensure_ascii=False)

    def clean_credentials_json(self):
        data = self.cleaned_data['credentials_json']
        if isinstance(data, dict):
            return data
        try:
            return json.loads(data)
        except Exception:
            raise forms.ValidationError("Le champ doit contenir un JSON valide.")
