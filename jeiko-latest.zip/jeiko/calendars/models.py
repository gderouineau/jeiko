# jeiko/calendars/models.py

from django.db import models, transaction
from django.contrib.auth import get_user_model
from django.utils import timezone
from datetime import timedelta

class GoogleCalendarConfig(models.Model):
    name = models.CharField(
        max_length=100,
        default="Primary"
    )
    credentials_json = models.JSONField(
        help_text="Copier-coller ici le JSON de credentials Google",
        default=dict,
    )
    updated_at = models.DateTimeField(
        auto_now=True
    )

    def __str__(self):
        return self.name

class AppointmentType(models.Model):
    name = models.CharField(
        "Nom du type",
        max_length=50
    )
    duration = models.DurationField(
        "Durée",
    )
    is_paid = models.BooleanField(
        "Payant",
        default=False
    )
    is_registration_required = models.BooleanField(
        "Réservation uniquement pour inscrits",
        default=False,
    )
    color = models.CharField(
        "Couleur",
        max_length=7,
        default="#2ecc40",
    )
    font = models.CharField(
        "Police",
        max_length=50,
        default="Inter"
    )
    description = models.TextField(
        "Description",
        blank=True
    )
    capacity = models.PositiveIntegerField(
        default=1,
        verbose_name="Nombre de places par créneau"
    )


    def __str__(self):
        return self.name

class Availability(models.Model):
    appointment_types = models.ManyToManyField(
        AppointmentType,
        related_name='availabilities',
        verbose_name="Types de rendez-vous possibles"
    )
    start = models.DateTimeField(
        "Début de disponibilité",
    )
    end = models.DateTimeField(
        "Fin de disponibilité",
    )
    recurring_rule = models.CharField(
        "Règle de récurrence iCal (optionnel)",
        max_length=200,
        blank=True,
    )
    is_available = models.BooleanField(
        "Disponible",
        default=True,
    )

    def __str__(self):
        types = ", ".join([str(t) for t in self.appointment_types.all()])
        return f"{types}: {self.start} - {self.end}"

    from datetime import timedelta
    def update_slots_availability(self):
        """
        Désactive les slots qui sont en conflit avec un slot déjà réservé.
        Réactive ceux qui ne sont plus en conflit.
        """
        from django.db.models import Q, F

        # 1. On récupère tous les slots déjà réservés (plus de places)
        booked_slots = self.slots.filter(is_available=False, remaining_places=0)

        # 2. Désactive les slots en conflit avec un slot réservé (conflit = chevauchement)
        for bslot in booked_slots:
            conflicting_slots = self.slots.filter(
                is_available=True,
                start__lt=bslot.end,
                end__gt=bslot.start
            ).exclude(pk=bslot.pk)
            conflicting_slots.update(is_available=False)

        # 3. Réactive les slots non réservés et non en conflit
        for slot in self.slots.filter(is_available=False, remaining_places__gt=0):
            # Si aucun slot réservé ne le chevauche, on réactive
            conflit = self.slots.filter(
                is_available=False,
                remaining_places=0,
                start__lt=slot.end,
                end__gt=slot.start
            ).exclude(pk=slot.pk).exists()
            if not conflit:
                slot.is_available = True
                slot.save(update_fields=["is_available"])

    def generate_slots(self):
        """
        Génère tous les slots, puis désactive ceux qui sont en conflit avec un Appointment existant.
        """
        types = self.appointment_types.all()
        slots_to_create = []
        existing_slots = {(s.start, s.end, s.type_id): s for s in self.slots.all()}

        for appt_type in types:
            duration = appt_type.duration
            capacity = appt_type.capacity
            slot_starts = []
            current = self.start
            while current + duration <= self.end:
                slot_starts.append(current)
                current += duration

            for slot_start in slot_starts:
                slot_end = slot_start + duration
                key = (slot_start, slot_end, appt_type.id)
                if key not in existing_slots:
                    slots_to_create.append(
                        Slot(
                            availability=self,
                            type=appt_type,
                            start=slot_start,
                            end=slot_end,
                            capacity=capacity,
                            remaining_places=capacity,
                            is_available=True
                        )
                    )
                else:
                    slot = existing_slots[key]
                    if slot.capacity != capacity:
                        slot.capacity = capacity
                        slot.save(update_fields=["capacity"])
                    if slot.remaining_places > 0 and not slot.is_available:
                        slot.is_available = True
                        slot.save(update_fields=["is_available"])

        # Bulk create pour les nouveaux slots
        if slots_to_create:
            Slot.objects.bulk_create(slots_to_create)

        # 1. Met à jour la dispo de tous les slots en fonction des RDV déjà pris
        self.update_slots_availability()

        # 2. Supprime/désactive les slots hors plage/type SANS réservation (comme avant)
        for slot in self.slots.all():
            key = (slot.start, slot.end, slot.type_id)
            slot_in_plage = (
                    slot.type in types
                    and self.start <= slot.start
                    and slot.end <= self.end
                    and slot.end > slot.start
            )
            if not slot_in_plage:
                if slot.remaining_places == slot.capacity:
                    slot.delete()
                else:
                    if slot.is_available:
                        slot.is_available = False
                        slot.save(update_fields=["is_available"])

    def save(self, *args, **kwargs):
        with transaction.atomic():
            is_new = self.pk is None
            super().save(*args, **kwargs)
            # Regénère les slots à la création OU si start/end/type ont changé
            self.generate_slots()
        # TODO : verifier que les générate slots fonctionne

class Slot(models.Model):
    availability = models.ForeignKey(
        'Availability',
        on_delete=models.CASCADE,
        related_name='slots',
        verbose_name="Plage de disponibilité"
    )
    type = models.ForeignKey(
        AppointmentType,
        on_delete=models.CASCADE,
        related_name="slots"
    )

    start = models.DateTimeField(
        verbose_name="Début du créneau"
    )
    end = models.DateTimeField(
        verbose_name="Fin du créneau"
    )
    is_available = models.BooleanField(
        default=False,
        verbose_name="Est disponible"
    )
    capacity = models.PositiveIntegerField(
        default=1
    )
    remaining_places = models.PositiveIntegerField(
        default=1
    )


    class Meta:
        ordering = ["start"]
        unique_together = (('availability', 'start', 'end'),)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if not self.is_available:
            self.availability.update_slots_availability()

    def __str__(self):
        return f"{self.type.name}: {self.start} - {self.end} ({self.remaining_places}/{self.capacity})"


class Appointment(models.Model):
    type = models.ForeignKey(
        AppointmentType,
        on_delete=models.PROTECT,
    )
    slot = models.ForeignKey(
        Slot,
        on_delete=models.CASCADE,
        related_name="appointments",
        null=True,
        blank=True
    )
    user = models.ForeignKey(
        get_user_model(),
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )
    start = models.DateTimeField(
        "Début"
    )
    end = models.DateTimeField(
        "Fin",
    )
    created = models.DateTimeField(
        auto_now_add=True
    )
    is_paid = models.BooleanField(
        default=False,
    )  # utile si tu veux vérifier le paiement
    email = models.EmailField(
        "Email du client",
        blank=True,
    )

    def __str__(self):
        return f"{self.type.name} - {self.start:%Y-%m-%d %H:%M}"

    def cancel(self):
        """
        Annule ce rendez-vous :
        - Libère le slot associé.
        - Met à jour la dispo des slots en conflit.
        - Supprime le rendez-vous.
        """
        slot = self.slot
        if slot:
            slot.appointment = None
            slot.remaining_places += 1
            if slot.remaining_places > 0:
                slot.is_available = True
            slot.save(update_fields=["remaining_places", "is_available"])
            # Met à jour la dispo des autres slots de la même plage
            slot.availability.update_slots_availability()
        self.delete()