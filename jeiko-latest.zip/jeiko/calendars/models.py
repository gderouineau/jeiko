# jeiko/calendars/models.py

import uuid

from django.conf import settings
from django.db import models, transaction
from django.contrib.auth import get_user_model
from django.urls import reverse
from django.utils import timezone
import re
from datetime import timedelta, datetime, time
from datetime import timezone as dt_timezone
from dateutil.rrule import rrulestr

from jeiko.encrypted import EncryptedJSONField
from jeiko.calendars.champs_de_reservation import valider_la_configuration
from django.utils.translation import gettext_lazy as _


_VALEUR_UTC = re.compile(r"(\d{8}T\d{6})Z")


def _regle_en_heure_locale(rule_str, fuseau):
    """
    Traduit un bloc iCal stocké en UTC vers l'heure murale naïve de `fuseau`.

    DTSTART est retiré (il est passé à part, en heure locale) ; chaque valeur
    `…Z` de UNTIL et d'EXDATE devient la même instant en heure locale, sans
    `Z` : dateutil refuse de mélanger un début naïf et des bornes aware.
    """
    def traduire(correspondance):
        instant = datetime.strptime(correspondance.group(1), "%Y%m%dT%H%M%S").replace(
            tzinfo=dt_timezone.utc
        )
        return timezone.localtime(instant, fuseau).strftime("%Y%m%dT%H%M%S")

    lignes = []
    for ligne in rule_str.splitlines():
        ligne = ligne.strip()
        if not ligne or ligne.upper().startswith("DTSTART"):
            continue
        lignes.append(_VALEUR_UTC.sub(traduire, ligne))
    return "\n".join(lignes)

import logging
logger = logging.getLogger(__name__)

WEEKDAY_TOKENS = ["MO","TU","WE","TH","FR","SA","SU"]

# Profondeur d'ouverture des réservations. Les créneaux ne sont matérialisés
# que jusque-là : au-delà, il faut que `jeiko_calendars_regenerate` soit passé.
DEFAULT_HORIZON_DAYS = 90


def default_horizon_days():
    from django.conf import settings
    try:
        return max(1, int(getattr(settings, "JEIKO_CALENDARS_HORIZON_DAYS", DEFAULT_HORIZON_DAYS)))
    except (TypeError, ValueError):
        return DEFAULT_HORIZON_DAYS


def _refund_after_commit(appt_pk):
    """Rembourse un rendez-vous après COMMIT (annulation client dans le délai)."""
    from . import payments
    try:
        payments.refund_appointment(appt_pk, by_system=True)
    except Exception:
        logger.exception("Remboursement automatique impossible (appt=%s)", appt_pk)


def _signaler_paiement_tardif(appt_pk, intention):
    """
    Un paiement est arrivé pour une réservation déjà libérée (F10) : l'argent
    est chez Stripe, le rendez-vous n'est pas confirmé. À l'exploitant de
    rembourser (fiche du rendez-vous) ou de rétablir la réservation.
    """
    logger.error("Paiement %s reçu après l'expiration du rendez-vous #%s", intention, appt_pk)
    try:
        from jeiko.emailing.admin_alerts import notifier_erreur

        notifier_erreur(
            "Paiement reçu après l'expiration d'une réservation",
            f"Le paiement {intention} est arrivé pour le rendez-vous #{appt_pk}, dont la réservation "
            "avait expiré et la place été libérée. L'encaissement est noté sur le rendez-vous, qui "
            "n'est PAS confirmé : rembourser depuis sa fiche, ou rétablir la réservation à la main.",
        )
    except Exception:
        logger.exception("Alerte de paiement tardif impossible (rendez-vous #%s)", appt_pk)


def periodes_occupees(user_id, debut, fin):
    """
    [(début, fin)] où le gestionnaire est pris hors de ses créneaux : un
    rendez-vous posé à une heure libre (slot vide), un événement de son
    agenda Google (`GoogleBusyPeriod`), une séance de visio dont il est
    l'hôte. Une séance née du calendrier (`Salle.rendez_vous`,
    `Salle.creneau`) n'y figure pas : son rendez-vous ou son créneau compte
    déjà — et un cours collectif fermerait sinon son propre créneau.
    """
    periodes = list(
        Appointment.objects.active()
        .filter(slot__isnull=True, type__user_id=user_id, start__lt=fin, end__gt=debut)
        .values_list("start", "end")
    )
    periodes += list(
        GoogleBusyPeriod.objects.filter(user_id=user_id, start__lt=fin, end__gt=debut)
        .values_list("start", "end")
    )
    periodes += list(_seances_de_visio(user_id, debut, fin).values_list("debut", "fin"))
    return periodes


def _seances_de_visio(user_id, debut, fin):
    from jeiko.visio.models import Salle

    return Salle.objects.filter(
        rendez_vous__isnull=True, creneau__isnull=True, annulee_le__isnull=True, terminee_le__isnull=True,
        debut__lt=fin, fin__gt=debut,
        invitations__user_id=user_id, invitations__role="hote", invitations__revoquee_le__isnull=True,
    ).distinct()


def temps_pris(user_id, debut, fin, sauf=None):
    """
    Le gestionnaire est-il déjà pris sur [début, fin] ? Un rendez-vous, sur
    créneau ou non, une séance de visio dont il est l'hôte, un événement de
    son agenda Google. Ce qui refuse un rendez-vous posé à une heure libre
    (écrans et API) ; `sauf` : le rendez-vous qu'on déplace, qui ne se gêne
    pas lui-même. Sans gestionnaire (type orphelin), rien ne se compare.
    """
    if not user_id:
        return False
    rendez_vous = Appointment.objects.active().filter(type__user_id=user_id, start__lt=fin, end__gt=debut)
    if sauf is not None:
        rendez_vous = rendez_vous.exclude(pk=sauf.pk)
    return (rendez_vous.exists()
            or GoogleBusyPeriod.objects.filter(user_id=user_id, start__lt=fin, end__gt=debut).exists()
            or _seances_de_visio(user_id, debut, fin).exists())


def recalculer_les_creneaux(user_id, debut, fin):
    """Rouvre ou ferme les créneaux d'un gestionnaire qui chevauchent [début, fin]."""
    if not user_id:
        return
    for dispo in Availability.objects.filter(
            user_id=user_id, slots__start__lt=fin, slots__end__gt=debut).distinct():
        dispo.update_slots_availability()


class GoogleBusyPeriod(models.Model):
    """
    Un moment où le praticien est pris dans son agenda Google, importé pour
    fermer les créneaux du site qui le chevauchent (Google → site, demande du
    04/10/2026). Le sens site → Google existait déjà (`google_api.upsert_event`).

    On ne garde que l'intervalle : ni le titre ni les invités de l'événement,
    qui ne regardent pas le site. Les événements que le site a lui-même posés
    dans Google (rendez-vous, disponibilités) sont écartés à l'import.
    """

    user = models.ForeignKey(get_user_model(), on_delete=models.CASCADE, related_name="google_busy_periods")
    google_event_id = models.CharField(max_length=255)
    start = models.DateTimeField(db_index=True)
    end = models.DateTimeField()

    class Meta:
        ordering = ["start"]


class GoogleCalendarConfig(models.Model):
    name = models.CharField(
        max_length=100,
        default="Primary"
    )
    user = models.OneToOneField(
        get_user_model(),
        on_delete=models.CASCADE,
        related_name='google_calendar_config',
        null=True,  # Temporary for migration
        blank=True
    )
    # Chiffré au repos (S-01) : ce JSON porte la CLÉ PRIVÉE RSA du compte de
    # service Google. En clair, une sauvegarde égarée suffisait à donner accès
    # aux agendas — et une clé qui a fuité ne se rattrape pas, il faut la
    # révoquer chez Google et reconfigurer chaque site.
    # Le formulaire ne la réaffiche jamais (`GoogleCalendarConfigForm`) ; le
    # chiffrement couvre l'autre moitié du problème, la lecture de la base.
    credentials_json = EncryptedJSONField(
        help_text=_("Copier-coller ici le JSON de credentials Google"),
        default=dict,
        blank=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True
    )

    calendar_id = models.CharField(

        max_length=300,
        default="",
        null=True,
        blank=True,
    )

    # Récapitulatif quotidien des rendez-vous du lendemain, envoyé le soir au
    # propriétaire du calendrier. Désactivé par défaut : c'est une sollicitation
    # supplémentaire, chaque praticien l'active pour son propre calendrier.
    daily_digest_enabled = models.BooleanField(
        _("Recevoir le récapitulatif quotidien des rendez-vous"),
        default=False,
    )
    # Heure d'envoi, choisie par calendrier : chaque praticien a ses horaires,
    # et une constante en dur dans le code n'était modifiable que par une mise
    # à jour du paquet. La tâche planifiée passe toutes les heures et ne
    # retient que les calendriers dont c'est l'heure — la planification systemd
    # reste donc inchangée quel que soit le réglage.
    daily_digest_hour = models.PositiveSmallIntegerField(
        _("Heure d'envoi du récapitulatif"),
        default=20,
        choices=[(h, f"{h:02d}h00") for h in range(24)],
        help_text=_("Heure locale à laquelle partira le récapitulatif des rendez-vous du lendemain."),
    )
    # Jour du dernier récap envoyé : garde d'idempotence, pour n'en envoyer
    # qu'un par jour même si la tâche planifiée repasse.
    last_digest_sent_on = models.DateField(
        _("Dernier récapitulatif envoyé le"), null=True, blank=True,
    )

    # Google → site : les événements de l'agenda ferment les créneaux qu'ils
    # chevauchent. Désactivé par défaut : un site déjà en service ne voit pas
    # ses créneaux se fermer sans l'avoir demandé.
    import_busy = models.BooleanField(
        _("Bloquer mes créneaux quand mon agenda Google est occupé"), default=False, db_default=False,
        help_text=_("Toutes les 30 minutes, les événements des 90 prochains jours de l'agenda "
                    "ferment les créneaux du site qu'ils chevauchent. L'agenda doit être partagé "
                    "avec le compte de service, en lecture des détails."),
    )
    busy_synced_at = models.DateTimeField(_("Dernière synchronisation"), null=True, blank=True)
    busy_sync_error = models.CharField(_("Dernière erreur de synchronisation"), max_length=300, blank=True,
                                       default="", db_default="")

    def __str__(self):
        return f"{self.user} -> {self.name}"


class AppointmentType(models.Model):
    name = models.CharField(
        _("Nom du type"),
        max_length=50
    )
    user = models.ForeignKey(
        get_user_model(),
        on_delete=models.CASCADE,
        related_name='appointment_types',
        null=True,  # Temporary for migration
        blank=True
    )
    duration = models.DurationField(
        _("Durée"),
    )
    is_paid = models.BooleanField(
        _("Payant"),
        default=False
    )
    price = models.DecimalField(
        _("Prix par place"),
        max_digits=8,
        decimal_places=2,
        default=0,
        blank=True,  # un type gratuit n'a pas à saisir « 0 »
        help_text=_("Montant à régler pour UNE place, en euros. Ignoré si le type n'est pas payant."),
    )
    is_registration_required = models.BooleanField(
        _("Réservation uniquement pour inscrits"),
        default=False,
    )
    color = models.CharField(
        _("Couleur"),
        max_length=7,
        default="#2ecc40",
    )
    font = models.CharField(
        _("Police"),
        max_length=50,
        default="Inter"
    )
    description = models.TextField(
        _("Description"),
        blank=True
    )
    capacity = models.PositiveIntegerField(
        default=1,
        verbose_name=_("Nombre de places par créneau")
    )
    max_places_per_booking = models.PositiveIntegerField(
        default=1,
        verbose_name=_("Places maximum par réservation"),
        help_text=(
            _("Nombre de places qu'un même client peut réserver d'un coup "
            "(1 = une place par réservation). Ne peut pas dépasser le nombre "
            "de places du créneau.")
        ),
    )
    allow_waitlist = models.BooleanField(
        _("Liste d'attente"),
        default=False,
        help_text=_("Autoriser les clients à s'inscrire en attente sur un créneau complet."),
    )
    cancellation_deadline_hours = models.PositiveIntegerField(
        _("Délai d'annulation remboursable (heures)"),
        default=24,
        help_text=(
            _("Un client qui annule au moins ce nombre d'heures avant un rendez-vous "
            "PAYANT est remboursé automatiquement. Passé ce délai, aucun remboursement "
            "automatique (le gestionnaire garde la main).")
        ),
    )
    # VISIO-01 : le rendez-vous a lieu dans la visio du site. Le praticien en
    # est l'hôte, chaque client reçoit son lien personnel (visio/calendrier.py).
    en_visio = models.BooleanField(
        _("En visio"), default=False,
        help_text=_("Le rendez-vous a lieu en visio sur le site : chaque client reçoit son lien personnel "
                    "dans la confirmation et les rappels. Un cours collectif a une salle par créneau."))
    # Ce que la réservation demande en plus du nom et de l'adresse (CRM-01) :
    # {"telephone": "obligatoire", "societe": "facultatif"…}. Catalogue fixe,
    # voir calendars/champs_de_reservation.py.
    champs_demandes = models.JSONField(
        _("Informations demandées"), default=dict, blank=True,
        validators=[valider_la_configuration],
    )

    def clean(self):
        super().clean()
        from django.core.exceptions import ValidationError
        errors = {}
        if self.max_places_per_booking and self.capacity and \
                self.max_places_per_booking > self.capacity:
            errors["max_places_per_booking"] = (
                "Un client ne peut pas réserver plus de places que n'en "
                f"compte le créneau ({self.capacity})."
            )
        if self.is_paid and (self.price or 0) <= 0:
            errors["price"] = _("Un type de rendez-vous payant doit avoir un prix supérieur à 0.")
        if errors:
            raise ValidationError(errors)

    @property
    def allows_multiple_places(self):
        return self.max_places_per_booking > 1

    @property
    def requires_payment(self):
        """Vrai si une réservation doit être réglée avant d'être confirmée."""
        return bool(self.is_paid and (self.price or 0) > 0)

    def amount_for(self, places=1):
        """Montant dû pour `places` places, en euros."""
        return (self.price or 0) * max(1, int(places or 1))

    def __str__(self):
        return self.name


class Availability(models.Model):
    appointment_types = models.ManyToManyField(
        AppointmentType,
        related_name='availabilities',
        verbose_name=_("Types de rendez-vous possibles")
    )
    user = models.ForeignKey(
        get_user_model(),
        on_delete=models.CASCADE,
        related_name='availabilities',
        null=True,  # Temporary for migration
        blank=True
    )
    start = models.DateTimeField(
        _("Début de disponibilité"),
    )
    end = models.DateTimeField(
        _("Fin de disponibilité"),
    )
    recurring_rule = models.TextField(
        _("Règle de récurrence iCal (optionnel)"),
        blank=True,
        help_text=_("Inclut éventuellement DTSTART, RRULE, EXDATE (une par ligne).")
    )
    is_available = models.BooleanField(
        _("Disponible"),
        default=True,
    )
    recurrence_exdates = models.JSONField(
        default=list, blank=True,
        help_text=_("Liste de dates à exclure, au format YYYY-MM-DD.")
    )

    google_event_id = models.CharField(
        max_length=128,
        null=True,
        blank=True,
        db_index=True
    )

    def __str__(self):
        types = ", ".join([str(t) for t in self.appointment_types.all()])
        return f"{types}: {self.start} - {self.end}"


    def update_slots_availability(self):
        """
        Recalcule la disponibilité des créneaux du gestionnaire sur cette fenêtre.

        Règle : dès qu'UNE place est prise sur un créneau, le gestionnaire est
        occupé sur cette tranche horaire — tous les créneaux qui la chevauchent
        se ferment. Le créneau entamé, lui, reste ouvert tant qu'il lui reste
        des places (cas des rendez-vous collectifs / conférences).

        Le calcul porte sur TOUS les créneaux du même gestionnaire sur la
        fenêtre, pas seulement ceux de cette disponibilité : deux plages qui se
        chevauchent ne doivent pas se réserver l'une l'autre.
        """
        own_slots = list(self.slots.all())
        if not own_slots:
            return

        window_start = min(s.start for s in own_slots)
        window_end = max(s.end for s in own_slots)

        if self.user_id:
            slots = list(
                Slot.objects.filter(
                    availability__user_id=self.user_id,
                    start__lt=window_end,
                    end__gt=window_start,
                )
            )
        else:
            # Disponibilité orpheline (antérieure à l'attribution des
            # calendriers) : on ne la compare qu'à elle-même.
            slots = own_slots

        booked = [s for s in slots if s.remaining_places < s.capacity]
        # Le temps occupé HORS créneau : rendez-vous pris à une heure libre
        # (depuis la fiche d'un contact), événements de son agenda Google.
        # Un créneau qui les chevauche n'est pas réservable.
        occupe = periodes_occupees(self.user_id, window_start, window_end) if self.user_id else []

        to_update = []
        for slot in slots:
            busy_elsewhere = any(
                b.pk != slot.pk and b.start < slot.end and b.end > slot.start
                for b in booked
            ) or any(debut < slot.end and fin > slot.start for debut, fin in occupe)
            available = (not busy_elsewhere) and slot.remaining_places > 0
            if slot.is_available != available:
                slot.is_available = available
                to_update.append(slot)

        if to_update:
            # bulk_update : ne repasse pas par Slot.save(), donc pas de récursion.
            Slot.objects.bulk_update(to_update, ["is_available"])

    def _duration(self):
        return self.end - self.start

    def _as_rruleset(self):
        """
        Le rruleset de la plage, développé en HEURE LOCALE du site.

        Fable 2 §4.2.1. La règle était développée depuis `self.start` tel que
        Django le relit — en UTC. « Tous les jeudis 9 h » devenait « tous les
        jeudis 07:00Z » : juste l'été, et 8 h tout l'hiver, dès le passage à
        l'heure d'hiver. Les créneaux générés se décalaient d'une heure sur la
        saison suivante, et les rendez-vous étaient pris et rappelés à la
        mauvaise heure.

        Le bloc stocké garde ses valeurs UTC (DTSTART, UNTIL, EXDATE), que
        Google Agenda et le formulaire relisent. On le traduit ici en heure
        murale naïve du fuseau du site, on développe, et `iter_occurrences`
        rattache chaque occurrence à son propre décalage (CEST ou CET).

        Ce que ça ne couvre pas : une heure qui n'existe pas (02:30 le jour du
        passage à l'heure d'été) reste telle quelle, sans être déplacée.
        """
        rule_str = (self.recurring_rule or "").strip()
        if not rule_str:
            return None
        fuseau = timezone.get_default_timezone()
        debut_local = timezone.localtime(self.start, fuseau).replace(tzinfo=None)
        return rrulestr(
            _regle_en_heure_locale(rule_str, fuseau), forceset=True, dtstart=debut_local
        )

    def iter_occurrences(self, start_from=None, until=None):
        """
        Génère les fenêtres (start, end) de la plage, une par occurrence.

        Sans récurrence : la seule fenêtre self.start/self.end. Sinon, la règle
        est développée en heure locale (voir `_as_rruleset`) et chaque
        occurrence revient en datetime aware, à son propre décalage.
        """
        dur = self._duration()
        if not (self.recurring_rule or "").strip():
            yield (self.start, self.end)
            return

        rs = self._as_rruleset()
        if not rs:
            yield (self.start, self.end)
            return

        if start_from is None:
            start_from = self.start
        if until is None:
            until = timezone.now() + timedelta(days=default_horizon_days())

        fuseau = timezone.get_default_timezone()

        def mural(dt):
            if timezone.is_naive(dt):
                return dt
            return timezone.localtime(dt, fuseau).replace(tzinfo=None)

        exdates = getattr(self, 'recurrence_exdates', []) or []
        for occ_local in rs.between(mural(start_from), mural(until), inc=True):
            # La date comparée aux exclusions est la date LOCALE : un créneau
            # de 00:30 à Paris tombe la veille en UTC.
            if exdates and occ_local.date().isoformat() in exdates:
                continue
            occ_start = timezone.make_aware(occ_local, fuseau)
            yield (occ_start, occ_start + dur)


    def _slots_with_history(self):
        """Créneaux de cette plage, avec le nombre de rendez-vous rattachés
        TOUS statuts confondus (annulés compris)."""
        from django.db.models import Count
        return self.slots.annotate(_appointments_total=Count("appointments"))

    @staticmethod
    def _slot_is_disposable(slot):
        """
        Vrai si le créneau peut être supprimé sans rien perdre.

        Un créneau porteur du moindre rendez-vous est conservé, même annulé :
        `Appointment.slot` est en CASCADE, le supprimer effacerait l'historique
        d'annulation — que seule la purge RGPD a vocation à effacer.
        `remaining_places == capacity` ne suffit donc pas : c'est aussi l'état
        d'un créneau dont tous les rendez-vous ont été annulés.
        """
        if getattr(slot, "_appointments_total", None) or slot.places_bloquees:
            return False
        return slot.remaining_places == slot.capacity

    def generate_slots(self, horizon_days=None):
        """
        Génère tous les slots pour CHAQUE occurrence (quotidienne/hebdomadaire),
        pour TOUS les types associés (durées différentes OK),
        puis met à jour les conflits et nettoie les slots hors plage.
        """
        types = list(self.appointment_types.all())
        if not types:
            return

        if horizon_days is None:
            horizon_days = default_horizon_days()

        type_ids = {t.id for t in types}
        horizon_end = timezone.now() + timedelta(days=horizon_days)
        windows = list(self.iter_occurrences(until=horizon_end))

        # Si aucune occurrence dans l'horizon -> on nettoie simplement
        if not windows:
            to_delete = []
            to_update = []
            for slot in self._slots_with_history():
                if self._slot_is_disposable(slot):
                    to_delete.append(slot.id)
                elif slot.is_available:
                    slot.is_available = False
                    to_update.append(slot)
            if to_delete:
                self.slots.filter(id__in=to_delete).delete()
            if to_update:
                Slot.objects.bulk_update(to_update, ["is_available"])
            return

        # Index des slots existants, avec le nombre de places réellement prises
        from django.db.models import Q as _Q, Sum
        existing_qs = self.slots.select_related("type").annotate(
            _booked=Sum(
                "appointments__places",
                filter=~_Q(appointments__status=Appointment.Status.CANCELLED),
            )
        )
        existing = {(s.start, s.end, s.type_id): s for s in existing_qs}

        to_create = []
        to_update = []

        def in_any_window(s, e):
            for ws, we in windows:
                if ws <= s and e <= we and e > s:
                    return True
            return False

        # Tessellation des fenêtres en pas = duration de chaque type
        for appt_type in types:
            step = appt_type.duration
            capacity = appt_type.capacity
            for ws, we in windows:
                cur = ws
                while cur + step <= we:
                    se = cur + step
                    key = (cur, se, appt_type.id)
                    slot = existing.get(key)
                    if slot is None:
                        to_create.append(Slot(
                            availability=self,
                            type=appt_type,
                            start=cur,
                            end=se,
                            capacity=capacity,
                            remaining_places=capacity,
                            is_available=True,
                        ))
                    else:
                        changed = False
                        # Capacité modifiée sur le type : on réaligne les places
                        # restantes sur les réservations réelles, sinon augmenter
                        # la capacité n'ouvrirait aucune place supplémentaire.
                        if slot.capacity != capacity:
                            booked = getattr(slot, "_booked", 0) or 0
                            slot.capacity = capacity
                            slot.remaining_places = max(0, capacity - booked - slot.places_bloquees)
                            changed = True
                        # Si non complet et désactivé → réactive
                        # (update_slots_availability refermera si conflit)
                        if slot.remaining_places > 0 and not slot.is_available:
                            slot.is_available = True
                            changed = True
                        if changed:
                            to_update.append(slot)
                    cur = se

        if to_create:
            Slot.objects.bulk_create(to_create)
        if to_update:
            Slot.objects.bulk_update(to_update, ["capacity", "remaining_places", "is_available"])

        # 1) Mise à jour de la dispo vs RDV pris (chevauchements avec slots complets)
        self.update_slots_availability()

        # 2) Nettoyage: tout slot qui ne tombe plus dans une fenêtre active ou dont le type a été retiré
        type_ids_set = type_ids  # alias lisible
        to_delete = []
        to_deactivate = []
        for slot in self._slots_with_history():
            if not in_any_window(slot.start, slot.end) or (slot.type_id not in type_ids_set):
                if self._slot_is_disposable(slot):
                    to_delete.append(slot.id)
                else:
                    if slot.is_available:
                        slot.is_available = False
                        to_deactivate.append(slot)

        if to_delete:
            self.slots.filter(id__in=to_delete).delete()
        if to_deactivate:
            Slot.objects.bulk_update(to_deactivate, ["is_available"])


    def save(self, *args, **kwargs):
        with transaction.atomic():

            super().save(*args, **kwargs)

            self.generate_slots()

        def _push(av_id):
            try:
                from .google_api import upsert_availability_event
                a = Availability.objects.get(pk=av_id)
                eid = upsert_availability_event(a)
                if eid and eid != a.google_event_id:
                    Availability.objects.filter(pk=av_id).update(google_event_id=eid)
            except Exception:
                logger.exception("Failed pushing availability to Google (id=%s)", av_id)

        transaction.on_commit(lambda av_id=self.id: _push(av_id))



class Slot(models.Model):
    availability = models.ForeignKey(
        'Availability',
        on_delete=models.CASCADE,
        related_name='slots',
        verbose_name=_("Plage de disponibilité")
    )
    type = models.ForeignKey(
        AppointmentType,
        on_delete=models.CASCADE,
        related_name="slots"
    )

    start = models.DateTimeField(
        verbose_name=_("Début du créneau")
    )
    end = models.DateTimeField(
        verbose_name=_("Fin du créneau")
    )
    is_available = models.BooleanField(
        default=False,
        verbose_name=_("Est disponible")
    )
    capacity = models.PositiveIntegerField(
        default=1
    )
    remaining_places = models.PositiveIntegerField(
        default=1
    )
    # CAL-01 — places retenues à la main, sans réservation en ligne : un
    # client au téléphone, un essai offert. Comptées comme prises par
    # `sync_remaining_places` ; un créneau qui en porte n'est jamais jeté par
    # la régénération (`_slot_is_disposable`).
    places_bloquees = models.PositiveIntegerField(_("Places bloquées"), default=0)
    note_de_blocage = models.CharField(_("Pour qui, pourquoi"), max_length=200, blank=True, default="")


    class Meta:
        ordering = ["start"]
        unique_together = (('availability', 'start', 'end', 'type'),)
        indexes = [
            models.Index(fields=["availability", "start"]),
            models.Index(fields=["start"]),
            models.Index(fields=["type", "start"]),
        ]

    def pending_claim_places(self):
        """
        Places tenues pour une personne prévenue sur la liste d'attente.

        Une entrée « prévenue » (NOTIFIED) dont la fenêtre de réservation court
        encore occupe la place : personne d'autre ne doit pouvoir la prendre. Un
        claim dont l'échéance est passée ne compte plus, même si le cron ne l'a
        pas encore marqué expiré — la place redevient libre aussitôt.
        """
        from django.db.models import Sum
        return self.waitlist_entries.filter(
            status=WaitlistEntry.Status.NOTIFIED,
            claim_expires_at__gt=timezone.now(),
        ).aggregate(n=Sum("places"))["n"] or 0

    def sync_remaining_places(self):
        """
        Réaligne les places restantes sur l'occupation réelle du créneau :
        rendez-vous actifs + places tenues pour la liste d'attente.

        Recalculer plutôt qu'incrémenter/décrémenter rend l'opération idempotente :
        une annulation rejouée, ou une suppression passée hors de `cancel()`, ne
        peut plus faire dériver le compteur.
        Retourne True si la valeur a changé.
        """
        from django.db.models import Sum
        taken = self.appointments.active().aggregate(n=Sum("places"))["n"] or 0
        taken += self.pending_claim_places() + self.places_bloquees
        remaining = max(0, self.capacity - taken)
        if remaining == self.remaining_places:
            return False
        self.remaining_places = remaining
        Slot.objects.filter(pk=self.pk).update(remaining_places=remaining)
        return True

    def bloquer(self, places, note=""):
        """
        Retient `places` places à la main (0 les libère toutes). Une valeur,
        pas un ajout : rejouée, elle donne le même état. Refuse de bloquer
        plus que ce que les réservations laissent libre. Libérer prévient la
        liste d'attente. Lève ValueError avec un message à afficher.
        """
        from django.db import transaction
        from django.db.models import Sum

        places = int(places)
        with transaction.atomic():
            slot = Slot.objects.select_for_update().select_related("type").get(pk=self.pk)
            reservees = (slot.appointments.active().aggregate(n=Sum("places"))["n"] or 0) + slot.pending_claim_places()
            if places < 0 or places > slot.capacity - reservees:
                raise ValueError(_("On peut bloquer de 0 à %(n)s place(s) sur ce créneau.")
                                 % {"n": max(0, slot.capacity - reservees)})
            liberees = places < slot.places_bloquees
            slot.places_bloquees = places
            slot.note_de_blocage = (note or "")[:200] if places else ""
            slot.save(update_fields=["places_bloquees", "note_de_blocage"])
            slot.sync_remaining_places()
            if liberees:
                from .waitlist import maybe_notify
                maybe_notify(slot)
        self.places_bloquees, self.note_de_blocage = slot.places_bloquees, slot.note_de_blocage
        self.remaining_places = slot.remaining_places
        return slot

    def __str__(self):
        return f"{self.type.name}: {self.start} - {self.end} ({self.remaining_places}/{self.capacity})"


class AppointmentQuerySet(models.QuerySet):
    """Un rendez-vous annulé occupe une ligne, jamais une place."""

    def active(self):
        """
        Rendez-vous qui OCCUPENT une place.

        Inclut les attentes de paiement : la place est tenue le temps du
        règlement, sinon deux clients pourraient payer le même créneau.
        """
        return self.exclude(status=Appointment.Status.CANCELLED)

    def firm(self):
        """Rendez-vous fermes : ni annulés, ni en attente de paiement."""
        return self.exclude(status__in=[
            Appointment.Status.CANCELLED, Appointment.Status.PENDING_PAYMENT,
        ])

    def awaiting_payment(self):
        return self.filter(status=Appointment.Status.PENDING_PAYMENT)

    def expired_holds(self):
        """Attentes de paiement dont le délai est dépassé."""
        return self.awaiting_payment().filter(hold_expires_at__lt=timezone.now())

    def cancelled(self):
        return self.filter(status=Appointment.Status.CANCELLED)

    def upcoming(self):
        return self.active().filter(start__gte=timezone.now())

    def to_review(self):
        """Rendez-vous passés dont la présence n'a pas encore été tranchée."""
        return self.filter(
            status=Appointment.Status.CONFIRMED, end__lt=timezone.now()
        )

    def upcoming_firm(self):
        return self.firm().filter(start__gte=timezone.now())


class Appointment(models.Model):

    class Status(models.TextChoices):
        # La place est tenue le temps du règlement, puis libérée si le paiement
        # n'aboutit pas (cf. `hold_expires_at` et `expire_unpaid_holds`).
        PENDING_PAYMENT = "pending_payment", _("En attente de paiement")
        CONFIRMED = "confirmed", _("Confirmé")
        HONOURED = "honoured", _("Honoré")
        NO_SHOW = "no_show", _("Absent")
        CANCELLED = "cancelled", _("Annulé")

    class CancelledBy(models.TextChoices):
        CLIENT = "client", _("Le client")
        MANAGER = "manager", _("Le gestionnaire")
        SYSTEM = "system", _("Le système")

    objects = AppointmentQuerySet.as_manager()

    type = models.ForeignKey(
        AppointmentType,
        on_delete=models.PROTECT,
    )
    slot = models.ForeignKey(
        Slot,
        on_delete=models.CASCADE,
        related_name="appointments",
        null=True,
        blank=True
    )
    user = models.ForeignKey(
        get_user_model(),
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )
    start = models.DateTimeField(
        _("Début")
    )
    end = models.DateTimeField(
        _("Fin"),
    )
    created = models.DateTimeField(
        auto_now_add=True
    )
    is_paid = models.BooleanField(
        default=False,
    )  # utile si tu veux vérifier le paiement
    client_name = models.CharField(
        _("Nom du client"),
        max_length=150,
        blank=True,
    )
    # Fuseau du navigateur au moment de réserver (ex. « America/New_York »).
    # Les e-mails au client annoncent l'heure dans CE fuseau, nommé, avec
    # l'heure du site entre parenthèses : un client à New York qui lit
    # « 09h00 » croirait à son heure. Vide pour les rendez-vous antérieurs
    # ou pris sans navigateur : on retombe alors sur le fuseau du site.
    client_timezone = models.CharField(
        _("Fuseau horaire du client"), max_length=64, blank=True, default="",
    )
    email = models.EmailField(
        _("Email du client"),
        blank=True,
    )
    places = models.PositiveIntegerField(
        _("Nombre de places"),
        default=1,
        help_text=_("Places occupées par cette réservation (accompagnants inclus)."),
    )

    # Ce que le visiteur a saisi en réservant, selon le type (CRM-01, CRM-02).
    # Des colonnes et non un JSON : changer la configuration d'un type ne doit
    # rien effacer de ce qui a été saisi.
    phone = models.CharField(_("Téléphone"), max_length=30, blank=True, default="")
    company = models.CharField(_("Société"), max_length=200, blank=True, default="")
    job_title = models.CharField(_("Fonction"), max_length=200, blank=True, default="")
    message = models.TextField(_("Message"), blank=True, default="")

    # Consentement, distinct de la relation liée au rendez-vous lui-même
    # (celui-ci relève de l'exécution du contrat) : autorisation FACULTATIVE
    # d'être recontacté au-delà de ce rendez-vous. La preuve horodatée est
    # aussi tracée dans users.Consent (type CONTACT).
    contact_consent = models.BooleanField(
        _("Autorise le recontact"),
        default=False,
        help_text=_("Le client autorise à être recontacté au-delà de ce rendez-vous."),
    )
    contact_consent_at = models.DateTimeField(
        _("Consentement de recontact le"),
        null=True,
        blank=True,
    )

    google_event_id = models.CharField(
        max_length=128, blank=True, null=True, db_index=True
    )

    public_token = models.UUIDField(
        _("Jeton public"),
        default=uuid.uuid4,
        editable=False,
        unique=True,
        help_text=_("Identifiant non devinable utilisé dans les liens envoyés au client."),
    )

    status = models.CharField(
        _("Statut"),
        max_length=16,
        choices=Status.choices,
        default=Status.CONFIRMED,
        db_index=True,
    )
    cancelled_at = models.DateTimeField(
        _("Annulé le"), null=True, blank=True
    )
    cancelled_by = models.CharField(
        _("Annulé par"), max_length=16, choices=CancelledBy.choices, blank=True
    )
    cancel_reason = models.TextField(
        _("Motif d'annulation"), blank=True
    )

    amount_due = models.DecimalField(
        _("Montant dû"),
        max_digits=8, decimal_places=2, default=0,
        help_text=_("Figé à la réservation : un changement de tarif ne réécrit pas l'historique."),
    )
    payment_intent_id = models.CharField(
        _("Référence de paiement"), max_length=255, blank=True, db_index=True
    )
    paid_at = models.DateTimeField(
        _("Payé le"), null=True, blank=True
    )
    # CAL-01 — réglé en crédits plutôt qu'en argent : le lot débité, combien,
    # et quand ils ont été rendus (annulation). Voir calendars/credits.py.
    lot_de_credits = models.ForeignKey(
        "calendars.LotDeCredits", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="rendez_vous", verbose_name=_("Crédits utilisés"),
    )
    credits_debites = models.PositiveIntegerField(_("Crédits débités"), default=0)
    credits_rendus_le = models.DateTimeField(_("Crédits rendus le"), null=True, blank=True)
    hold_expires_at = models.DateTimeField(
        _("Place tenue jusqu'à"), null=True, blank=True,
        help_text=_("Au-delà, une réservation non réglée libère sa place."),
    )
    refunded_at = models.DateTimeField(
        _("Remboursé le"), null=True, blank=True
    )
    refund_amount = models.DecimalField(
        _("Montant remboursé"), max_digits=8, decimal_places=2, default=0,
    )
    refund_id = models.CharField(
        _("Référence du remboursement"), max_length=255, blank=True, db_index=True
    )

    # Horodatage d'envoi des rappels : garde d'idempotence pour la tâche
    # planifiée. Non nul = rappel déjà envoyé, on ne le renvoie pas au passage
    # suivant du timer (qui tourne toutes les 5 minutes).
    reminder_24h_sent_at = models.DateTimeField(
        _("Rappel 24 h envoyé le"), null=True, blank=True,
    )
    reminder_2h_sent_at = models.DateTimeField(
        _("Rappel 2 h envoyé le"), null=True, blank=True,
    )
    # Rappel envoyé au praticien 1 h avant (distinct des rappels client).
    reminder_pro_1h_sent_at = models.DateTimeField(
        _("Rappel praticien 1 h envoyé le"), null=True, blank=True,
    )

    def __str__(self):
        return f"{self.type.name} - {self.start:%Y-%m-%d %H:%M}"

    # ------------------------------------------------------------------
    # Accès client (liens envoyés par e-mail)
    # ------------------------------------------------------------------
    def get_public_cancel_url(self):
        """URL relative d'annulation, à insérer dans les e-mails au client."""
        return reverse(
            "jeiko_calendars_public:appointment_cancel",
            kwargs={"token": str(self.public_token)},
        )

    def get_payment_url(self):
        """URL relative de la page de règlement."""
        return reverse(
            "jeiko_calendars_public:appointment_pay",
            kwargs={"token": str(self.public_token)},
        )

    def get_payment_return_url(self):
        """URL de retour après passage sur Stripe."""
        return reverse(
            "jeiko_calendars_public:appointment_pay_return",
            kwargs={"token": str(self.public_token)},
        )

    @property
    def is_past(self):
        return self.start <= timezone.now()

    @property
    def is_cancelled(self):
        return self.status == self.Status.CANCELLED

    @property
    def en_visio(self):
        """Par son type, ou mis en visio à la main (`visio.calendrier.mettre_en_visio`)."""
        from jeiko.visio.calendrier import _en_visio
        return _en_visio(self)

    @property
    def is_awaiting_payment(self):
        return self.status == self.Status.PENDING_PAYMENT

    @property
    def hold_has_expired(self):
        return bool(
            self.is_awaiting_payment
            and self.hold_expires_at
            and self.hold_expires_at < timezone.now()
        )

    def mark_paid(self, payment_intent_id=""):
        """
        Confirme le rendez-vous après encaissement.

        Idempotent : appelé à la fois au retour du client depuis la page de
        paiement ET par le webhook Stripe, qui arrivent dans un ordre non
        garanti (et parfois deux fois).
        Retourne True seulement au premier passage — c'est ce booléen qui
        décide de l'envoi des e-mails.
        """
        # Relu SOUS VERROU : le webhook et le retour du client, chacun avec son
        # instance « en attente », confirmaient tous les deux — deux séries
        # d'e-mails (audit du 11/10/2026, F11).
        with transaction.atomic():
            frais = type(self).objects.select_for_update().get(pk=self.pk)
            if frais.status == self.Status.PENDING_PAYMENT:
                frais.status = self.Status.CONFIRMED
                frais.is_paid = True
                frais.paid_at = timezone.now()
                frais.hold_expires_at = None
                if payment_intent_id:
                    frais.payment_intent_id = payment_intent_id
                frais.save(update_fields=[
                    "status", "is_paid", "paid_at", "hold_expires_at", "payment_intent_id",
                ])
                for champ in ("status", "is_paid", "paid_at", "hold_expires_at", "payment_intent_id"):
                    setattr(self, champ, getattr(frais, champ))
                return True
            # Paiement arrivé APRÈS l'expiration de la réservation : l'argent est
            # encaissé, la place a pu être reprise. On garde la trace de
            # l'encaissement (sans rien confirmer) et on prévient l'exploitant,
            # qui rembourse ou rétablit — avant, le paiement disparaissait
            # (F10). Une seule fois : un rejeu trouve is_paid déjà posé.
            if frais.status == self.Status.CANCELLED and not frais.is_paid and payment_intent_id:
                frais.is_paid = True
                frais.paid_at = timezone.now()
                frais.payment_intent_id = payment_intent_id
                frais.save(update_fields=["is_paid", "paid_at", "payment_intent_id"])
                for champ in ("is_paid", "paid_at", "payment_intent_id"):
                    setattr(self, champ, getattr(frais, champ))
                pk, intention = self.pk, payment_intent_id
                transaction.on_commit(lambda: _signaler_paiement_tardif(pk, intention))
            return False

    def release_expired_hold(self):
        """Libère la place d'une réservation non réglée dans le délai."""
        if not self.hold_has_expired:
            return False
        return self.cancel(
            by=self.CancelledBy.SYSTEM,
            reason="Paiement non finalisé dans le délai imparti.",
        )

    # ------------------------------------------------------------------
    # Remboursement
    # ------------------------------------------------------------------
    @property
    def is_refunded(self):
        return self.refunded_at is not None

    @property
    def is_refundable(self):
        """Un règlement encaissé, pas encore remboursé, peut l'être."""
        return bool(self.is_paid and self.paid_at and self.payment_intent_id
                    and not self.is_refunded)

    def cancellation_refund_deadline(self):
        """Instant limite pour une annulation client remboursable."""
        hours = self.type.cancellation_deadline_hours if self.type_id else 0
        return self.start - timedelta(hours=hours)

    def is_within_refund_window(self):
        """Vrai si l'on est encore avant le délai d'annulation remboursable."""
        return timezone.now() <= self.cancellation_refund_deadline()

    def _qualifies_for_auto_refund(self, by):
        """
        Politique : seule une annulation PAR LE CLIENT, sur un RDV payé et dans
        le délai, déclenche un remboursement automatique. L'annulation par le
        gestionnaire est laissée à sa main (bouton manuel).
        """
        if not self.is_refundable:
            return False
        if by != self.CancelledBy.CLIENT:
            return False
        return self.is_within_refund_window()

    def mark_refunded(self, amount, refund_id=""):
        """
        Enregistre un remboursement. Idempotent : ne fait rien si déjà remboursé.
        Retourne True seulement au premier passage.
        """
        if self.is_refunded:
            return False
        self.refunded_at = timezone.now()
        self.refund_amount = amount
        if refund_id:
            self.refund_id = refund_id
        self.save(update_fields=["refunded_at", "refund_amount", "refund_id"])
        return True

    def is_cancellable_by_client(self):
        """
        Un client ne peut annuler qu'un rendez-vous à venir et non déjà annulé.
        (Un délai de prévenance pourra être ajouté ici plus tard.)
        """
        return not self.is_past and not self.is_cancelled

    @property
    def owner(self):
        """Gestionnaire du calendrier auquel appartient ce rendez-vous."""
        return self.type.user if self.type_id else None

    def cancel(self, by=CancelledBy.CLIENT, reason=""):
        """
        Annule ce rendez-vous :
        - Passe le statut à « annulé ». La ligne est CONSERVÉE : historique,
          suivi des no-shows, déclenchement de la liste d'attente.
        - Libère la place et rouvre les créneaux qui étaient bloqués.
        - L'évènement Google est retiré par le signal post_save.

        Idempotent : retourne False si le rendez-vous était déjà annulé.
        """
        if self.pk is None or self.is_cancelled:
            # Déjà annulé (double clic, rejeu) : rien à faire.
            return False

        auto_refund = self._qualifies_for_auto_refund(by)
        with transaction.atomic():
            self.status = self.Status.CANCELLED
            self.cancelled_at = timezone.now()
            self.cancelled_by = by
            self.cancel_reason = reason or ""
            self.save(update_fields=[
                "status", "cancelled_at", "cancelled_by", "cancel_reason"
            ])
            self.release_slot()
            # VISIO-01 : le lien de la réservation ne sert plus.
            from jeiko.visio.calendrier import au_rendez_vous_annule
            au_rendez_vous_annule(self)
            # Réglé en crédits : rendus selon la même règle que le remboursement.
            if self.credits_debites:
                from .credits import rendre_si_du
                rendre_si_du(self, par_le_client=(by == self.CancelledBy.CLIENT))
            if auto_refund:
                # Le remboursement appelle Stripe : après COMMIT, hors transaction.
                appt_pk = self.pk
                transaction.on_commit(lambda pk=appt_pk: _refund_after_commit(pk))
        return True

    def creneaux_pour_deplacer(self):
        """
        Les créneaux où le client peut déplacer ce rendez-vous : ceux de son
        type, à venir, encore ouverts et avec assez de places — ce que propose
        le calendrier public. Les créneaux fermés par un autre rendez-vous, une
        séance de visio ou l'agenda Google le sont déjà (`update_slots_availability`).
        Même type : même durée, même prix, même praticien — rien à recalculer.
        """
        return (
            Slot.objects.filter(type_id=self.type_id, start__gt=timezone.now(), is_available=True,
                                remaining_places__gte=self.places)
            .exclude(pk=self.slot_id)
            .order_by("start")
        )

    def deplacer_sur(self, slot_id):
        """
        Déplace ce rendez-vous sur un autre créneau de son type (le client,
        depuis le lien de son e-mail). C'est la MÊME ligne : jeton, paiement,
        crédits et historique restent ; l'agenda Google suit par le signal
        post_save, la séance de visio par `invitation_du_client` — qui révoque
        aussi le lien d'un cours collectif dont on quitte le créneau.

        Retourne l'ancien début, ou None si le créneau n'est plus libre (pris
        entre l'affichage et l'envoi). Ce qui n'est pas vérifié ici : le délai
        — l'appelant le juge (`is_cancellable_by_client`).
        """
        with transaction.atomic():
            slot = (self.creneaux_pour_deplacer().select_for_update(of=("self",))
                    .select_related("availability", "type").filter(pk=slot_id).first())
            if slot is None:
                return None
            ancien_slot, ancien_debut, ancienne_fin = self.slot_id, self.start, self.end
            self.slot, self.start, self.end = slot, slot.start, slot.end
            self.save(update_fields=["slot", "start", "end"])
            self.suivre_le_deplacement(ancien_slot, ancien_debut, ancienne_fin)
        return ancien_debut

    def suivre_le_deplacement(self, ancien_slot_id, ancien_debut, ancienne_fin, ancien_gestionnaire=None):
        """
        Ce qui suit un rendez-vous DÉJÀ enregistré à son nouveau moment, qu'il
        vienne d'un créneau ou d'une date libre — commun au client
        (`deplacer_sur`) et à la fiche d'administration :

        * les places et les créneaux : le nouveau se ferme, l'ancien moment se
          rouvre, et la liste d'attente de l'ancien créneau est prévenue ;
        * les rappels repartent (ceux déjà envoyés annonçaient l'ancienne heure) ;
        * la séance de visio prend le même début et la même durée — un cours
          collectif change de salle, l'ancien lien est révoqué
          (`invitation_du_client`).

        L'agenda Google suit par le signal post_save ; les e-mails restent à
        l'appelant, qui sait qui a déplacé. Ne fait rien si rien n'a bougé.
        """
        if (ancien_slot_id, ancien_debut, ancienne_fin) == (self.slot_id, self.start, self.end):
            return
        type(self).objects.filter(pk=self.pk).update(
            reminder_24h_sent_at=None, reminder_2h_sent_at=None, reminder_pro_1h_sent_at=None)
        self.reminder_24h_sent_at = self.reminder_2h_sent_at = self.reminder_pro_1h_sent_at = None
        if self.slot_id != ancien_slot_id:
            for slot in Slot.objects.select_related("availability", "type").filter(
                    pk__in=[s for s in (ancien_slot_id, self.slot_id) if s]):
                slot.sync_remaining_places()
                slot.availability.update_slots_availability()
                if slot.pk == ancien_slot_id:
                    from . import waitlist
                    waitlist.maybe_notify(slot)
        # Les moments pris hors créneau ferment aussi des créneaux : on
        # recalcule autour de l'ancien et du nouveau.
        recalculer_les_creneaux(ancien_gestionnaire or self.type.user_id, ancien_debut, ancienne_fin)
        recalculer_les_creneaux(self.type.user_id, self.start, self.end)
        if self.en_visio:
            from jeiko.visio.calendrier import invitation_du_client
            invitation_du_client(self)

    def release_slot(self):
        """Rend la place au créneau, recalcule les chevauchements, et prévient
        la liste d'attente si une place s'est libérée."""
        slot = (
            Slot.objects
            .filter(pk=self.slot_id)
            .select_related("availability", "type")
            .first()
        )
        if slot is None:
            # Rendez-vous hors créneau : les créneaux qu'il fermait se rouvrent.
            if self.type_id:
                recalculer_les_creneaux(self.type.user_id, self.start, self.end)
            return
        slot.sync_remaining_places()
        slot.availability.update_slots_availability()
        from . import waitlist
        waitlist.maybe_notify(slot)

    def mark_attendance(self, honoured: bool):
        """Tranche la présence après coup (suivi des no-shows)."""
        if self.is_cancelled:
            return False
        self.status = self.Status.HONOURED if honoured else self.Status.NO_SHOW
        self.save(update_fields=["status"])
        return True

class WaitlistEntry(models.Model):
    """
    Inscription en attente sur un créneau complet.

    Cible un créneau PRÉCIS (pas un type) : le client veut cette date-là. Quand
    une place se libère, la personne en tête de liste est prévenue et la place
    lui est tenue le temps qu'elle réserve (cf. `jeiko.calendars.waitlist`).
    """

    class Status(models.TextChoices):
        WAITING = "waiting", _("En attente")
        NOTIFIED = "notified", _("Prévenue (place tenue)")
        CONVERTED = "converted", _("Convertie en rendez-vous")
        CANCELLED = "cancelled", _("Désinscrite")
        EXPIRED = "expired", _("Délai dépassé")

    slot = models.ForeignKey(
        "Slot",
        on_delete=models.CASCADE,
        related_name="waitlist_entries",
        verbose_name=_("Créneau visé"),
    )
    user = models.ForeignKey(
        get_user_model(),
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="waitlist_entries",
    )
    client_name = models.CharField(_("Nom du client"), max_length=150, blank=True)
    email = models.EmailField(_("Email du client"))
    places = models.PositiveIntegerField(_("Places souhaitées"), default=1)
    # Les mêmes réponses qu'une réservation : quand une place se libère, la
    # réservation reprend tout — sans quoi ce qui a été saisi se perdait.
    phone = models.CharField(_("Téléphone"), max_length=30, blank=True, default="")
    company = models.CharField(_("Société"), max_length=200, blank=True, default="")
    job_title = models.CharField(_("Fonction"), max_length=200, blank=True, default="")
    message = models.TextField(_("Message"), blank=True, default="")

    status = models.CharField(
        max_length=16, choices=Status.choices,
        default=Status.WAITING, db_index=True,
    )
    public_token = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)

    created = models.DateTimeField(auto_now_add=True)
    notified_at = models.DateTimeField(_("Prévenue le"), null=True, blank=True)
    claim_expires_at = models.DateTimeField(
        _("Place tenue jusqu'à"), null=True, blank=True,
        help_text=_("Au-delà, la place est proposée à la personne suivante."),
    )

    class Meta:
        ordering = ["created"]  # premier inscrit, premier prévenu
        # Une même adresse ne s'inscrit qu'une fois par créneau.
        unique_together = (("slot", "email"),)
        indexes = [
            models.Index(fields=["slot", "status"]),
            models.Index(fields=["status", "claim_expires_at"]),
        ]
        verbose_name = _("Inscription en liste d'attente")
        verbose_name_plural = _("Inscriptions en liste d'attente")

    def __str__(self):
        return f"{self.email} @ {self.slot_id} ({self.get_status_display()})"

    @property
    def is_active(self):
        """En jeu : attend son tour ou a été prévenue."""
        return self.status in (self.Status.WAITING, self.Status.NOTIFIED)

    @property
    def claim_has_expired(self):
        return bool(
            self.status == self.Status.NOTIFIED
            and self.claim_expires_at
            and self.claim_expires_at < timezone.now()
        )

    def get_claim_url(self):
        from django.urls import reverse
        return reverse(
            "jeiko_calendars_public:waitlist_claim",
            kwargs={"token": str(self.public_token)},
        )

    def get_leave_url(self):
        from django.urls import reverse
        return reverse(
            "jeiko_calendars_public:waitlist_leave",
            kwargs={"token": str(self.public_token)},
        )



class LotDeCredits(models.Model):
    """
    CAL-01 — des crédits de séance : une carte « 10 cours » achetée, les
    crédits d'un mois d'abonnement, ou des crédits offerts à la main.

    Un lot par origine, et non un solde unique : chaque lot a son expiration
    et sa provenance (la commande, l'abonnement), ce qu'un compteur perdrait.
    Le solde d'une personne est la somme de ses lots valides
    (calendars/credits.py). Un rendez-vous réglé en crédits garde le lot
    débité : une annulation y rend ce qu'elle a pris.

    `type` vide : valable pour tout type de rendez-vous payant. Supprimer un
    type ne fait pas perdre des crédits payés : le lot devient valable partout,
    au gestionnaire d'en décider.
    """

    class Origine(models.TextChoices):
        ACHAT = "achat", _("Achat")
        ABONNEMENT = "abonnement", _("Abonnement")
        OFFERT = "offert", _("Offert")

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="lots_de_credits",
        verbose_name=_("Membre"),
    )
    type = models.ForeignKey(
        AppointmentType, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="lots_de_credits", verbose_name=_("Type de rendez-vous"),
        help_text=_("Vide : valable pour tous les rendez-vous payants."),
    )
    credits_initiaux = models.PositiveIntegerField(_("Crédits du lot"))
    credits_restants = models.PositiveIntegerField(_("Crédits restants"))
    expire_le = models.DateTimeField(_("Expire le"), null=True, blank=True)
    origine = models.CharField(_("Origine"), max_length=20, choices=Origine.choices)
    commande = models.ForeignKey(
        "shop.Order", on_delete=models.SET_NULL, null=True, blank=True, related_name="lots_de_credits",
    )
    produit = models.ForeignKey(
        "shop.Product", on_delete=models.SET_NULL, null=True, blank=True, related_name="lots_de_credits",
    )
    #: L'abonnement Stripe qui l'a crédité : les lots d'un même abonnement
    #: se reportent l'un sur l'autre au renouvellement.
    abonnement = models.CharField(max_length=100, blank=True, default="", db_index=True)
    note = models.CharField(_("Note"), max_length=200, blank=True, default="")
    cree_le = models.DateTimeField(auto_now_add=True)
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="+",
    )

    class Meta:
        verbose_name = _("Lot de crédits")
        verbose_name_plural = _("Lots de crédits")
        ordering = ["-cree_le"]
        constraints = [
            # Une commande crédite une fois par produit : mark_order_paid est
            # appelé par le retour du client ET par le webhook.
            models.UniqueConstraint(fields=["commande", "produit"], name="un_lot_par_produit_commande",
                                    condition=models.Q(commande__isnull=False)),
        ]

    def __str__(self):
        return f"{self.credits_restants}/{self.credits_initiaux} — {self.user}"

    @property
    def est_valide(self):
        return self.credits_restants > 0 and (self.expire_le is None or self.expire_le > timezone.now())
