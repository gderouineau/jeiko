# jeiko/calendars/google_api.py
from __future__ import annotations
from datetime import timezone as dt_timezone
from django.conf import settings
from django.utils import timezone
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from .models import GoogleCalendarConfig, Appointment
import logging
logger = logging.getLogger(__name__)
SCOPES = ["https://www.googleapis.com/auth/calendar"]  # lecture/écriture


from jeiko.administration.models import WebSite


def _get_service():
    cfg = GoogleCalendarConfig.objects.first()
    if not cfg or not cfg.credentials_json or not cfg.calendar_id:
        return None, None, "Configuration Google Calendar manquante (credentials ou calendar_id)."
    creds = Credentials.from_service_account_info(cfg.credentials_json, scopes=SCOPES)
    service = build("calendar", "v3", credentials=creds)
    logger.info("Google Calendar service prêt, calendar_id=%s", cfg.calendar_id)
    return service, cfg.calendar_id, None

def _to_rfc3339_utc(dt):
    """Retourne un datetime RFC3339 en UTC avec 'Z'."""
    if timezone.is_naive(dt):
        dt = timezone.make_aware(dt, timezone.get_current_timezone())
    return dt.astimezone(dt_timezone.utc).isoformat().replace("+00:00", "Z")

# jeiko/calendars/google_api.py
from googleapiclient.errors import HttpError
import logging
logger = logging.getLogger(__name__)

SCOPES = ["https://www.googleapis.com/auth/calendar"]  # écriture

def upsert_event(appt):
    logger.warning("UPSERTEVENT start appt=%s", appt.pk)
    service, calendar_id, err = _get_service()
    if err:
        logger.error("upsert_event: %s", err)
        return None

    # Récupère le nom du site si dispo (sinon fallback)
    website = WebSite.objects.first()
    site_name = website.name if website else "JEIKO"

    desc = [
        f"Réservé via {site_name}",
        f"Email: {appt.email or '-'}",
        f"Payant: {'Oui' if appt.is_paid else 'Non'}",
        f"ID interne: {appt.pk}",
    ]

    body = {
        "summary": appt.type.name,
        "description": "\n".join(desc),
        "start": {"dateTime": appt.start.isoformat(), "timeZone": "Europe/Paris"},
        "end":   {"dateTime": appt.end.isoformat(),   "timeZone": "Europe/Paris"},
        "guestsCanInviteOthers": False,
        "guestsCanSeeOtherGuests": False,
        "extendedProperties": {"private": {"jeiko_appointment_id": str(appt.pk)}},
    }
    # ⚠️ NE PAS ENVOYER D'ATTENDEES AVEC UN SERVICE ACCOUNT SUR GMAIL PERSO
    # if appt.email:
    #     body["attendees"] = [{"email": appt.email}]

    try:
        if appt.google_event_id:
            logger.info("PATCH event Google id=%s (appt=%s)", appt.google_event_id, appt.pk)
            event = service.events().patch(
                calendarId=calendar_id,
                eventId=appt.google_event_id,
                body=body,
                sendUpdates="none",
            ).execute()
        else:
            logger.info("INSERT event Google (appt=%s) sur calendar_id=%s", appt.pk, calendar_id)
            event = service.events().insert(
                calendarId=calendar_id,
                body=body,
                sendUpdates="none",
            ).execute()

        eid = event.get("id")
        logger.warning("UPSERTEVENT OK appt=%s eid=%s", appt.pk, eid)
        return eid

    except HttpError as e:
        status = getattr(e, "status_code", None) or getattr(getattr(e, "resp", None), "status", None)
        content = getattr(e, "content", b"")
        try:
            content = content.decode() if isinstance(content, (bytes, bytearray)) else str(content)
        except Exception:
            content = str(content)
        logger.error("UPSERTEVENT HttpError status=%s calendar_id=%s content=%s",
                     status, calendar_id, content[:800])

        # Si l’event n’

def delete_event(appt: Appointment) -> bool:
    """Supprime l’événement Google s’il existe."""
    if not appt.google_event_id:
        return True
    service, calendar_id, err = _get_service()
    if err:
        return False
    try:
        service.events().delete(calendarId=calendar_id, eventId=appt.google_event_id).execute()
        return True
    except HttpError as e:
        # 410/404 => déjà supprimé
        if getattr(e, "status_code", None) in (404, 410):
            return True
        return False
    except Exception:
        return False
