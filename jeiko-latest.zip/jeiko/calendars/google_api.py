# jeiko/calendars/google_api.py
from __future__ import annotations
from datetime import timezone as dt_timezone
from django.conf import settings
from django.utils import timezone
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from .models import GoogleCalendarConfig, Appointment, Availability
import logging
logger = logging.getLogger(__name__)
SCOPES = ["https://www.googleapis.com/auth/calendar"]  # lecture/écriture

# Correspondance approximative hex → colorId Google Calendar (1-11)
# https://developers.google.com/calendar/api/v3/reference/colors/get
_GOOGLE_COLOR_MAP = {
    "1":  (161, 136, 127),  # Flamingo (rose-brun)
    "2":  (213,  78,  83),  # Tomato (rouge)
    "3":  (239, 108,  0),   # Tangerine (orange)
    "4":  (240, 230,  0),   # Banana (jaune)
    "5":  ( 51, 182,  121),  # Sage (vert clair)
    "6":  ( 11, 128,  67),  # Basil (vert foncé)
    "7":  ( 3, 155, 229),   # Peacock (bleu clair)
    "8":  ( 63,  81, 181),  # Blueberry (bleu-violet)
    "9":  (121,  85, 172),  # Lavender (violet)
    "10": ( 97,  97,  97),  # Graphite (gris)
    "11": ( 0, 172, 193),   # Cyan (turquoise)
}


def _hex_to_google_color_id(hex_color: str) -> str:
    """Retourne le colorId Google Calendar le plus proche d'une couleur hex."""
    try:
        h = hex_color.lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except Exception:
        return "10"  # Graphite par défaut
    best_id, best_dist = "10", float("inf")
    for cid, (cr, cg, cb) in _GOOGLE_COLOR_MAP.items():
        dist = (r - cr) ** 2 + (g - cg) ** 2 + (b - cb) ** 2
        if dist < best_dist:
            best_dist, best_id = dist, cid
    return best_id


from jeiko.administration.models import WebSite


def _get_service(user=None):
    if not user:
        return None, None, "Utilisateur non spécifié pour la configuration Google Calendar."
        
    cfg = GoogleCalendarConfig.objects.filter(user=user).first()
    if not cfg or not cfg.credentials_json or not cfg.calendar_id:
        return None, None, f"Configuration Google Calendar manquante pour {user}."
    creds = Credentials.from_service_account_info(cfg.credentials_json, scopes=SCOPES)
    service = build("calendar", "v3", credentials=creds)
    logger.info("Google Calendar service prêt, calendar_id=%s", cfg.calendar_id)
    return service, cfg.calendar_id, None

def _to_rfc3339_utc(dt):
    """Retourne un datetime RFC3339 en UTC avec 'Z'."""
    if timezone.is_naive(dt):
        dt = timezone.make_aware(dt, timezone.get_current_timezone())
    return dt.astimezone(dt_timezone.utc).isoformat().replace("+00:00", "Z")




def upsert_event(appt):
    logger.warning("UPSERTEVENT start appt=%s", appt.pk)
    # On utilise le user du type de RDV comme propriétaire du calendrier
    user = appt.type.user if appt.type else None
    service, calendar_id, err = _get_service(user)
    if err:
        logger.error("upsert_event: %s", err)
        return None

    # Récupère le nom du site si dispo (sinon fallback)
    website = WebSite.objects.first()
    site_name = website.name if website else "JEIKO"

    desc = [
        f"Réservé via {site_name}",
        f"Email: {appt.email or '-'}",
        f"Payant: {'Oui' if appt.is_paid else 'Non'}",
        f"ID interne: {appt.pk}",
    ]

    color_id = _hex_to_google_color_id(appt.type.color) if appt.type and appt.type.color else "10"

    body = {
        "summary": appt.type.name,
        "description": "\n".join(desc),
        "start": {"dateTime": appt.start.isoformat(), "timeZone": "Europe/Paris"},
        "end":   {"dateTime": appt.end.isoformat(),   "timeZone": "Europe/Paris"},
        "colorId": color_id,
        "guestsCanInviteOthers": False,
        "guestsCanSeeOtherGuests": False,
        "extendedProperties": {"private": {"jeiko_appointment_id": str(appt.pk)}},
    }
    # ⚠️ NE PAS ENVOYER D'ATTENDEES AVEC UN SERVICE ACCOUNT SUR GMAIL PERSO
    # if appt.email:
    #     body["attendees"] = [{"email": appt.email}]

    try:
        if appt.google_event_id:
            logger.info("PATCH event Google id=%s (appt=%s)", appt.google_event_id, appt.pk)
            event = service.events().patch(
                calendarId=calendar_id,
                eventId=appt.google_event_id,
                body=body,
                sendUpdates="none",
            ).execute()
        else:
            logger.info("INSERT event Google (appt=%s) sur calendar_id=%s", appt.pk, calendar_id)
            event = service.events().insert(
                calendarId=calendar_id,
                body=body,
                sendUpdates="none",
            ).execute()

        eid = event.get("id")
        logger.warning("UPSERTEVENT OK appt=%s eid=%s", appt.pk, eid)
        return eid

    except HttpError as e:
        status = getattr(e, "status_code", None) or getattr(getattr(e, "resp", None), "status", None)
        content = getattr(e, "content", b"")
        try:
            content = content.decode() if isinstance(content, (bytes, bytearray)) else str(content)
        except Exception:
            content = str(content)
        logger.error("UPSERTEVENT HttpError status=%s calendar_id=%s content=%s",
                     status, calendar_id, content[:800])

        # Si l’event n’

def delete_event(appt: Appointment) -> bool:
    """Supprime l’événement Google s’il existe."""
    if not appt.google_event_id:
        return True
    user = appt.type.user if appt.type else None
    service, calendar_id, err = _get_service(user)
    if err:
        return False
    try:
        service.events().delete(calendarId=calendar_id, eventId=appt.google_event_id).execute()
        return True
    except HttpError as e:
        # 410/404 => déjà supprimé
        if getattr(e, "status_code", None) in (404, 410):
            return True
        return False
    except Exception:
        return False



def _extract_recurrence_lines_from_availability(avail) -> list[str]:
    """
    Convertit Availability.recurring_rule (bloc multi-lignes) en liste 'recurrence' pour Google:
    garde uniquement les lignes qui commencent par 'RRULE:' ou 'EXDATE:'.
    """
    lines = []
    raw = (avail.recurring_rule or "").splitlines()
    for ln in raw:
        ln = (ln or "").strip()
        if not ln:
            continue
        if ln.startswith("RRULE:") or ln.startswith("EXDATE:"):
            lines.append(ln)
    return lines


def upsert_availability_event(avail: Availability) -> str | None:
    """
    Crée / met à jour dans Google Calendar un évènement (récurent ou non)
    représentant la fenêtre de disponibilité. Retourne google_event_id.
    - Un SEUL évènement par Availability (admin = enregistrement 'maître').
    - Les rendez-vous individuels continuent d'être créés via upsert_event(appt).
    """
    service, calendar_id, err = _get_service(avail.user)
    if err:
        logger.error("upsert_availability_event: %s", err)
        return None

    # Résumé et description
    try:
        type_names = ", ".join(avail.appointment_types.values_list("name", flat=True))
    except Exception:
        type_names = ""
    summary = "Disponibilités" + (f" — {type_names}" if type_names else "")
    desc = f"Fenêtre de disponibilité générée par JEIKO (Availability #{avail.pk})."

    # Start/End de la fenêtre (pas la durée des slots)
    start_iso = avail.start.isoformat()
    end_iso = avail.end.isoformat()

    # Couleur basée sur le premier AppointmentType associé
    first_type = avail.appointment_types.first()
    color_id = _hex_to_google_color_id(first_type.color) if first_type and first_type.color else "10"

    body = {
        "summary": summary,
        "description": desc,
        "start": {"dateTime": start_iso, "timeZone": "Europe/Paris"},
        "end": {"dateTime": end_iso, "timeZone": "Europe/Paris"},
        "colorId": color_id,
        "guestsCanInviteOthers": False,
        "guestsCanSeeOtherGuests": False,
        "extendedProperties": {"private": {"jeiko_availability_id": str(avail.pk)}},
    }

    # Récurrence si présente (RRULE/EXDATE)
    rec_lines = _extract_recurrence_lines_from_availability(avail)
    if rec_lines:
        body["recurrence"] = rec_lines

    try:
        if getattr(avail, "google_event_id", None):
            logger.info("PATCH availability event Google id=%s (avail=%s)", avail.google_event_id, avail.pk)
            event = service.events().patch(
                calendarId=calendar_id,
                eventId=avail.google_event_id,
                body=body,
                sendUpdates="none",
            ).execute()
        else:
            logger.info("INSERT availability event Google (avail=%s) sur calendar_id=%s", avail.pk, calendar_id)
            event = service.events().insert(
                calendarId=calendar_id,
                body=body,
                sendUpdates="none",
            ).execute()
        eid = event.get("id")
        logger.info("UPSERT AVAILABILITY OK avail=%s eid=%s", avail.pk, eid)
        return eid

    except HttpError as e:
        status = getattr(e, "status_code", None) or getattr(getattr(e, "resp", None), "status", None)
        content = getattr(e, "content", b"")
        try:
            content = content.decode() if isinstance(content, (bytes, bytearray)) else str(content)
        except Exception:
            content = str(content)
        logger.error("UPSERT AVAILABILITY HttpError status=%s calendar_id=%s content=%s",
                     status, calendar_id, content[:800])
        return None
    except Exception as e:
        logger.exception("UPSERT AVAILABILITY failed avail=%s: %s", avail.pk, e)
        return None


def delete_availability_event(avail: Availability) -> bool:
    """
    Supprime l'évènement Google d'une Availability s'il existe.
    """
    if not getattr(avail, "google_event_id", None):
        return True
    service, calendar_id, err = _get_service(avail.user)
    if err:
        logger.error("delete_availability_event: %s", err)
        return False
    try:
        service.events().delete(calendarId=calendar_id, eventId=avail.google_event_id).execute()
        logger.info("DELETE AVAILABILITY OK avail=%s eid=%s", avail.pk, avail.google_event_id)
        return True
    except HttpError as e:
        # 404/410 => déjà supprimé côté Google
        code = getattr(e, "status_code", None) or getattr(getattr(e, "resp", None), "status", None)
        if code in (404, 410):
            return True
        logger.error("DELETE AVAILABILITY HttpError avail=%s: %s", avail.pk, e)
        return False
    except Exception as e:
        logger.exception("DELETE AVAILABILITY failed avail=%s: %s", avail.pk, e)
        return False
