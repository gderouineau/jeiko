# jeiko/calendars/credits.py
"""
CAL-01 — les crédits de séance (Guillaume, 12/10/2026 : « il faut aussi que
l'on puisse acheter des crédits, genre 10 cours »).

Le problème : un cours collectif se vend à la carte. Sans crédits, le client
payait chaque séance par carte bancaire, et une carte « 10 cours » vendue en
boutique (le champ `Product.credits_amount` existait) ne créditait rien.

Ce que ce module fait :
* créditer : une commande payée crée un lot par produit qui porte des crédits
  (`crediter_la_commande`, appelé par `mark_order_paid`) ; un lot peut aussi
  être offert à la main (`offrir`) ;
* régler : un rendez-vous en attente de paiement se règle en crédits au lieu
  de la carte (`regler_en_credits`) — le lot qui expire le premier est
  débité, sous verrou ;
* rendre : une annulation rend les crédits selon la même règle que le
  remboursement (`rendre_si_du`) — toujours si le gestionnaire annule, dans
  le délai d'annulation si c'est le client.

* l'abonnement : chaque échéance payée crédite un lot valable jusqu'à la fin
  de la période ; avec le report, ce qui reste du lot précédent s'y ajoute,
  jusqu'au plafond (`crediter_l_echeance`, appelé par
  shop/abonnements.enregistrer_le_paiement).

Ce qu'il ne fait pas : rembourser un lot en argent.
"""
import logging

from django.db import transaction
from django.db.models import F, Q, Sum
from django.utils import timezone

logger = logging.getLogger(__name__)


def _valides(user, type_rdv=None):
    from .models import LotDeCredits

    maintenant = timezone.now()
    lots = LotDeCredits.objects.filter(user=user, credits_restants__gt=0).filter(
        Q(expire_le__isnull=True) | Q(expire_le__gt=maintenant))
    if type_rdv is not None:
        lots = lots.filter(Q(type=type_rdv) | Q(type__isnull=True))
    return lots


def solde(user, type_rdv=None):
    """Les crédits utilisables de `user` (pour `type_rdv`, ou tous types)."""
    if not getattr(user, "is_authenticated", False):
        return 0
    return _valides(user, type_rdv).aggregate(n=Sum("credits_restants"))["n"] or 0


def regler_en_credits(rendez_vous, user):
    """
    Règle un rendez-vous en attente de paiement avec les crédits de `user`.
    Rend True si c'est fait ; False si rien à régler (déjà confirmé, plus en
    attente, pas à cette personne, pas assez de crédits dans un même lot).
    Un seul lot paie tout le rendez-vous : couper une réservation de deux
    places entre deux lots rendrait une annulation ambiguë.
    """
    from .models import Appointment

    if not getattr(user, "is_authenticated", False):
        return False
    with transaction.atomic():
        rdv = Appointment.objects.select_for_update().select_related("type").get(pk=rendez_vous.pk)
        if rdv.status != Appointment.Status.PENDING_PAYMENT:
            return False
        a_lui = rdv.user_id == user.pk or (
            rdv.user_id is None and (rdv.email or "").strip().lower() == (user.email or "").strip().lower())
        if not a_lui:
            return False
        places = max(1, rdv.places or 1)
        lot = (_valides(user, rdv.type).filter(credits_restants__gte=places)
               .select_for_update().order_by(F("expire_le").asc(nulls_last=True), "cree_le").first())
        if lot is None:
            return False
        lot.credits_restants -= places
        lot.save(update_fields=["credits_restants"])
        rdv.status = Appointment.Status.CONFIRMED
        rdv.is_paid = True
        rdv.paid_at = timezone.now()
        rdv.hold_expires_at = None
        rdv.user_id = rdv.user_id or user.pk
        rdv.lot_de_credits = lot
        rdv.credits_debites = places
        rdv.save(update_fields=["status", "is_paid", "paid_at", "hold_expires_at", "user",
                                "lot_de_credits", "credits_debites"])
        intention = rdv.payment_intent_id
    for champ in ("status", "is_paid", "paid_at", "hold_expires_at", "user_id", "lot_de_credits_id", "credits_debites"):
        setattr(rendez_vous, champ, getattr(rdv, champ))
    if intention:
        # La page de paiement avait ouvert une intention Stripe : on la ferme,
        # pour qu'elle ne puisse plus être réglée en plus des crédits.
        transaction.on_commit(lambda: _annuler_l_intention(intention))
    return True


def _annuler_l_intention(intention):
    try:
        from jeiko.payments.services.stripe import StripeService
        StripeService().cancel_payment_intent(intention)
    except Exception:
        logger.warning("Intention %s non annulée après un règlement en crédits", intention, exc_info=True)


def rendre_si_du(rendez_vous, par_le_client):
    """
    Rend les crédits d'un rendez-vous annulé : toujours quand le gestionnaire
    annule (séance supprimée), dans le délai d'annulation quand c'est le
    client — au-delà, la séance est due, comme pour un paiement. Idempotent.
    """
    from .models import Appointment, LotDeCredits

    if not rendez_vous.credits_debites or not rendez_vous.lot_de_credits_id:
        return False
    if par_le_client and not rendez_vous.is_within_refund_window():
        return False
    with transaction.atomic():
        rdv = Appointment.objects.select_for_update().get(pk=rendez_vous.pk)
        if rdv.credits_rendus_le:
            return False
        LotDeCredits.objects.filter(pk=rdv.lot_de_credits_id).update(
            credits_restants=F("credits_restants") + rdv.credits_debites)
        rdv.credits_rendus_le = timezone.now()
        rdv.save(update_fields=["credits_rendus_le"])
    rendez_vous.credits_rendus_le = rdv.credits_rendus_le
    return True


def crediter_la_commande(order, lines):
    """
    Un lot par produit à crédits d'une commande payée (hors abonnement, qui
    crédite à chaque échéance). Idempotent : une contrainte d'unicité
    (commande, produit) refuse le doublon du webhook et du retour client.
    """
    from datetime import timedelta

    from .models import LotDeCredits

    if not order.user_id:
        return []
    crees = []
    for line in lines:
        produit = line.product
        if produit is None or produit.credits_amount <= 0 or produit.intervalle(line.variant):
            continue
        credits = produit.credits_amount * max(1, line.quantity or 1)
        expire = (timezone.now() + timedelta(days=produit.credits_validite_jours)
                  if produit.credits_validite_jours else None)
        lot, cree = LotDeCredits.objects.get_or_create(
            commande=order, produit=produit,
            defaults={"user_id": order.user_id, "type_id": produit.linked_appointment_type_id,
                      "credits_initiaux": credits, "credits_restants": credits, "expire_le": expire,
                      "origine": LotDeCredits.Origine.ACHAT},
        )
        if cree:
            crees.append(lot)
    return crees


def crediter_l_echeance(commande, abonnement):
    """
    Les crédits d'une échéance d'abonnement : `credits_amount` × quantité,
    valables jusqu'à la fin de la période payée. Sans report, les lots
    précédents du même abonnement tombent à zéro ; avec, ce qui leur reste
    s'ajoute au nouveau, sans dépasser le plafond. Idempotent (commande,
    produit), comme l'achat.
    """
    from .models import LotDeCredits

    produit = abonnement.product
    if produit is None or produit.credits_amount <= 0 or not commande.user_id:
        return None
    if LotDeCredits.objects.filter(commande=commande, produit=produit).exists():
        return None
    nouveaux = produit.credits_amount * max(1, abonnement.quantite or 1)
    with transaction.atomic():
        # Expirés compris : le lot précédent échoit à la fin de la période, et
        # l'avis du renouvellement arrive souvent juste après — le report ne
        # doit pas en dépendre.
        anciens = list(LotDeCredits.objects.filter(
            user_id=commande.user_id, abonnement=abonnement.stripe_subscription_id, credits_restants__gt=0,
        ).select_for_update())
        reste = sum(l.credits_restants for l in anciens)
        report = 0
        if produit.credits_cumulables:
            report = reste
            if produit.credits_plafond is not None:
                report = min(report, max(0, produit.credits_plafond - nouveaux))
        for lot in anciens:
            lot.note = ((lot.note + " · ") if lot.note else "") + (
                "reporté à l'échéance suivante" if report else "échu au renouvellement")
            lot.credits_restants = 0
            lot.save(update_fields=["credits_restants", "note"])
        return LotDeCredits.objects.create(
            user_id=commande.user_id, type_id=produit.linked_appointment_type_id,
            credits_initiaux=nouveaux + report, credits_restants=nouveaux + report,
            expire_le=abonnement.fin_de_periode, origine=LotDeCredits.Origine.ABONNEMENT,
            commande=commande, produit=produit, abonnement=abonnement.stripe_subscription_id,
            note=(f"dont {report} reporté(s)" if report else ""),
        )


def offrir(user, credits, type_rdv=None, expire_le=None, note="", par=None):
    """Des crédits donnés à la main (essai, geste commercial, report)."""
    from .models import LotDeCredits

    credits = int(credits)
    if credits <= 0:
        raise ValueError("Un nombre de crédits positif.")
    return LotDeCredits.objects.create(
        user=user, type=type_rdv, credits_initiaux=credits, credits_restants=credits,
        expire_le=expire_le, origine=LotDeCredits.Origine.OFFERT, note=(note or "")[:200], cree_par=par,
    )
