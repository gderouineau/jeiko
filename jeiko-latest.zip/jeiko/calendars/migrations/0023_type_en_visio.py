# VISIO-01 — séances nées du calendrier (12/10/2026).

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('calendars', '0022_credits_de_seance'),
    ]

    operations = [
        migrations.AddField(
            model_name='appointmenttype',
            name='en_visio',
            field=models.BooleanField(default=False, help_text='Le rendez-vous a lieu en visio sur le site : chaque client reçoit son lien personnel dans la confirmation et les rappels. Un cours collectif a une salle par créneau.', verbose_name='En visio'),
        ),
    ]
