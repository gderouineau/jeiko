
# jeiko/calendars/signals.py
from django.db.models.signals import post_save, m2m_changed
from django.dispatch import receiver
from .models import Availability

@receiver(post_save, sender=Availability)
def availability_post_save(sender, instance, created, **kwargs):
    # Si nouvel objet : on tentera quand même (au cas où il y a des defaults)
    # Mais la vraie génération se fera surtout après save_m2m (voir m2m_changed)
    if created:
        instance.generate_slots()

@receiver(m2m_changed, sender=Availability.appointment_types.through)
def availability_types_changed(sender, instance, action, **kwargs):
    if action in {"post_add", "post_remove", "post_clear"}:
        instance.generate_slots()