
# jeiko/calendars/signals.py
from django.db.models.signals import post_save, m2m_changed, post_delete
from django.dispatch import receiver
from django.db import transaction
import logging
logger = logging.getLogger(__name__)
from .google_api import upsert_event, delete_event

from .models import Availability, Appointment

@receiver(post_save, sender=Availability)
def availability_post_save(sender, instance, created, **kwargs):
    # Si nouvel objet : on tentera quand même (au cas où il y a des defaults)
    # Mais la vraie génération se fera surtout après save_m2m (voir m2m_changed)
    if created:
        instance.generate_slots()

@receiver(m2m_changed, sender=Availability.appointment_types.through)
def availability_types_changed(sender, instance, action, **kwargs):
    if action in {"post_add", "post_remove", "post_clear"}:
        instance.generate_slots()






@receiver(post_save, sender=Appointment)
def appointment_synced_to_google(sender, instance: Appointment, created, **kwargs):
    # Évite les appels pendant la transaction : exécute après COMMIT
    transaction.on_commit(lambda: _sync_after_commit(instance.pk))

def _sync_after_commit(appt_pk: int):
    from .models import Appointment  # import tardif pour éviter cycles
    appt = Appointment.objects.select_related("type").filter(pk=appt_pk).first()
    if not appt:
        return
    event_id = upsert_event(appt)
    if event_id and appt.google_event_id != event_id:
        # Update direct par QuerySet pour éviter de re-déclencher post_save
        Appointment.objects.filter(pk=appt.pk).update(google_event_id=event_id)

@receiver(post_delete, sender=Appointment)
def appointment_deleted_from_google(sender, instance: Appointment, **kwargs):
    transaction.on_commit(lambda: delete_event(instance))


@receiver(post_save, sender=Appointment)
def appointment_synced_to_google(sender, instance, created, **kwargs):
    logger.info("post_save Appointment pk=%s created=%s -> schedule sync", instance.pk, created)
    transaction.on_commit(lambda: _sync_after_commit(instance.pk))