# jeiko/calendars/emailing.py
import logging
from django.conf import settings
from django.core.mail import get_connection, EmailMultiAlternatives
from django.utils.timezone import localtime
from datetime import timedelta


from jeiko.administration.models import WebSite


logger = logging.getLogger(__name__)


def _get_mail_connection():
    """
    Récupère la connexion SMTP d’après WebSite.mail_settings.
    Retourne (connection | None, from_email | None, reply_to | None (list), admin_recipients | list).
    """
    site = WebSite.objects.select_related("mail_settings").first()
    ms = getattr(site, "mail_settings", None)
    if not ms or not ms.active:
        logger.info("Email non configuré ou inactif : aucun envoi.")
        return None, None, None, []

    try:
        conn = get_connection(
            backend="django.core.mail.backends.smtp.EmailBackend",
            host=ms.host,
            port=ms.port,
            username=(ms.host_user or None),
            password=(ms.host_password or None),
            use_tls=bool(ms.use_tls),
            use_ssl=bool(ms.use_ssl),
            timeout=10,
        )
    except Exception as e:
        logger.exception("Impossible d'initialiser la connexion SMTP : %s", e)
        return None, None, None, []

    from_email = ms.default_from_email or ms.host_user or getattr(settings, "DEFAULT_FROM_EMAIL", None)
    reply_to = [ms.reply_to_email] if ms.reply_to_email else None

    # Choix des destinataires admin : test_receiver (si rempli) + default_from_email
    admin_recipients = []
    if ms.default_from_email:
        admin_recipients.append(ms.default_from_email)
    if ms.test_receiver:
        admin_recipients.append(ms.test_receiver)
    # dedup
    admin_recipients = list(dict.fromkeys([a for a in admin_recipients if a]))

    return conn, from_email, reply_to, admin_recipients


def _fmt_dt_eu(dt):
    """
    Format simple et robuste (indépendant de la locale système).
    """
    d = localtime(dt)
    return f"{d.day:02d}/{d.month:02d}/{d.year} à {d.hour:02d}h{d.minute:02d}"


def _fmt_duration_minutes(start, end):
    mins = int((end - start).total_seconds() // 60)
    if mins < 60:
        return f"{mins} min"
    h, m = divmod(mins, 60)
    return f"{h}h{m:02d}" if m else f"{h}h"


def send_booking_emails(appt):
    """
    Envoie 2 e-mails :
      - au client (si email fourni)
      - à l’admin (d’après la config)
    N’échoue jamais "vers l’utilisateur" (catch des exceptions + log).
    """
    conn, from_email, reply_to, admin_rcpts = _get_mail_connection()
    if not conn or not from_email:
        logger.info("Envoi email désactivé/faute de configuration (from_email ou connexion manquants).")
        return

    site = WebSite.objects.first()
    site_name = getattr(site, "name", None) or "JEIKO"

    when = _fmt_dt_eu(appt.start)
    dur = _fmt_duration_minutes(appt.start, appt.end)
    typ = appt.type.name if appt.type_id else "Rendez-vous"

    # --------- CLIENT ----------
    if appt.email:
        subject_user = f"[{site_name}] Confirmation de rendez-vous — {typ}"
        text_user = (
            f"Bonjour,\n\n"
            f"Votre rendez-vous est confirmé :\n"
            f"• Date : {when}\n"
            f"• Durée : {dur}\n"
            f"• Type : {typ}\n\n"
            f"Si vous devez annuler ou modifier, répondez à ce mail.\n\n"
            f"À bientôt,\n{site_name}\n"
        )
        html_user = (
            f"<p>Bonjour,</p>"
            f"<p>Votre rendez-vous est confirmé :</p>"
            f"<ul>"
            f"<li><strong>Date :</strong> {when}</li>"
            f"<li><strong>Durée :</strong> {dur}</li>"
            f"<li><strong>Type :</strong> {typ}</li>"
            f"</ul>"
            f"<p>Si vous devez annuler ou modifier, répondez à ce mail.</p>"
            f"<p>À bientôt,<br>{site_name}</p>"
        )

        try:
            msg_user = EmailMultiAlternatives(
                subject=subject_user,
                body=text_user,
                from_email=from_email,
                to=[appt.email],
                reply_to=reply_to,
                connection=conn,
            )
            msg_user.attach_alternative(html_user, "text/html")
            msg_user.send()
            logger.info("Email client envoyé pour appt=%s -> %s", appt.pk, appt.email)
        except Exception as e:
            logger.exception("Échec envoi email client pour appt=%s : %s", appt.pk, e)

    # --------- ADMIN ----------
    if admin_rcpts:
        subject_admin = f"[{site_name}] Nouvelle réservation — {typ}"
        text_admin = (
            f"Nouvelle réservation :\n"
            f"• Date : {when}\n"
            f"• Durée : {dur}\n"
            f"• Type : {typ}\n"
            f"• Email client : {appt.email or '-'}\n"
            f"• ID interne : {appt.pk}\n"
        )
        html_admin = (
            f"<p><strong>Nouvelle réservation</strong></p>"
            f"<ul>"
            f"<li><strong>Date :</strong> {when}</li>"
            f"<li><strong>Durée :</strong> {dur}</li>"
            f"<li><strong>Type :</strong> {typ}</li>"
            f"<li><strong>Email client :</strong> {appt.email or '-'}</li>"
            f"<li><strong>ID interne :</strong> {appt.pk}</li>"
            f"</ul>"
        )
        try:
            msg_admin = EmailMultiAlternatives(
                subject=subject_admin,
                body=text_admin,
                from_email=from_email,
                to=admin_rcpts,
                reply_to=reply_to,
                connection=conn,
            )
            msg_admin.attach_alternative(html_admin, "text/html")
            msg_admin.send()
            logger.info("Email admin envoyé pour appt=%s -> %s", appt.pk, ", ".join(admin_rcpts))
        except Exception as e:
            logger.exception("Échec envoi email admin pour appt=%s : %s", appt.pk, e)
