from django.views import View
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse, reverse_lazy
import datetime
from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied
from django.shortcuts import render, redirect, get_object_or_404
from .forms import (
    GoogleCalendarConfigForm, AvailabilityForm, AppointmentTypeForm,
    AppointmentFormAdmin, AppointmentClientCreateForm,
)
from .models import GoogleCalendarConfig, Availability, AppointmentType, Appointment, Slot
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin, PermissionRequiredMixin
from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache
from django.utils import timezone
from django.http import JsonResponse

from .fuseaux import fuseau_valide
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from datetime import timedelta
from django.views.decorators.csrf import ensure_csrf_cookie
import json
from django.db import transaction
from django.db.models import Count, Q
import logging
from .google_api import upsert_event
from .emailing import (
    send_booking_emails, send_cancellation_emails, send_no_show_email,
    send_payment_pending_email, send_reschedule_email,
)
from .mixins import CalendarOwnerQuerysetMixin, get_target_user, is_calendar_supervisor
from .champs_de_reservation import champs_a_demander, lire_les_champs
from .throttling import check_booking_request, clean_booking_email, record_booking
from . import payments
from . import waitlist
from jeiko.redirections import destination_sure
from django.utils.translation import gettext_lazy as _
from django.utils.translation import ngettext

logger = logging.getLogger(__name__)


class SlotUnavailable(Exception):
    """Le créneau demandé n'est plus réservable (message destiné au client)."""


class LoginRequiredForBooking(Exception):
    """Le type de rendez-vous est réservé aux inscrits."""


class ChampManquant(Exception):
    """Un champ obligatoire du type de rendez-vous est vide (message pour le client)."""


def _rattacher_au_crm(entree):
    """
    La réservation (ou l'inscription en liste d'attente) rejoint la fiche de
    la personne au CRM, créée au besoin. Ne lève jamais : voir
    jeiko/crm/rattachement.py.
    """
    from jeiko.crm.rattachement import rattacher
    from jeiko.questionnaires_expert.models import Prospect

    rattacher(entree.email, nom=entree.client_name, telephone=entree.phone,
              societe=entree.company, fonction=entree.job_title,
              origine=Prospect.Origine.RENDEZ_VOUS)


def _client_ip(request):
    """Adresse enregistrable, selon la règle de confiance commune (Fable 1, §1.2)."""
    from jeiko.throttling import ip_stockable
    return ip_stockable(request)


def _record_contact_consent(request, appt):
    """
    Trace la preuve du consentement FACULTATIF de recontact recueilli à la
    réservation (horodatage, IP, source). Ne casse jamais la réservation.
    """
    try:
        from jeiko.users.models import Consent, ConsentType
        Consent.objects.create(
            user=request.user if request.user.is_authenticated else None,
            anonymous_key=(request.session.session_key or "")[:64],
            consent_type=ConsentType.CONTACT,
            granted=True,
            ip_address=_client_ip(request),
            source=f"rdv:{appt.id}",
        )
    except Exception:
        logger.exception("Trace du consentement de recontact impossible (rdv=%s)", appt.id)


def send_reschedule_email_safe(appt_id, old_start):
    """Envoi de l'e-mail « rendez-vous déplacé », à l'abri des exceptions."""
    try:
        appt = Appointment.objects.select_related("type", "type__user").get(pk=appt_id)
        send_reschedule_email(appt, old_start)
    except Exception:
        logger.exception("Échec de l'e-mail de déplacement du RDV %s", appt_id)


def send_booking_emails_safe(appt_id):
    """Envoi des e-mails de réservation, à l'abri des exceptions."""
    try:
        appt = Appointment.objects.select_related("type", "type__user").get(pk=appt_id)
        send_booking_emails(appt)
    except Exception as exc:
        logger.exception("send_emails failed for appt=%s: %s", appt_id, exc)


def send_appointment_email_safe(appt_id, sender):
    """
    Applique `sender` à un rendez-vous rechargé, à l'abri des exceptions.

    Rechargé plutôt que passé tel quel : l'envoi a lieu après COMMIT, l'instance
    en mémoire peut ne plus refléter la base (statut, motif d'annulation).
    """
    try:
        appt = Appointment.objects.select_related("type", "type__user").get(pk=appt_id)
        sender(appt)
    except Exception as exc:
        logger.exception("appointment email failed for appt=%s: %s", appt_id, exc)


@method_decorator(never_cache, name='dispatch')
class GoogleCalendarConfigListAllView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    """
    Supervision de TOUS les calendriers du site (super-administrateur uniquement).

    Sert de point d'entrée pour ouvrir la configuration d'un gestionnaire donné.
    """
    model = GoogleCalendarConfig
    template_name = "calendars/config_list_all.html"
    context_object_name = "configs"
    raise_exception = True

    def test_func(self):
        return is_calendar_supervisor(self.request.user)

    def get_queryset(self):
        now = timezone.now()
        return (
            GoogleCalendarConfig.objects
            .select_related('user')
            .annotate(
                nb_types=Count('user__appointment_types', distinct=True),
                nb_availabilities=Count('user__availabilities', distinct=True),
                nb_upcoming=Count(
                    'user__appointment_types__appointment',
                    filter=Q(user__appointment_types__appointment__start__gte=now)
                    & ~Q(user__appointment_types__appointment__status=Appointment.Status.CANCELLED),
                    distinct=True,
                ),
            )
            .order_by('user__username', 'name')
        )

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        User = get_user_model()
        # Gestionnaires qui ont des types de RDV mais aucune config Google :
        # ils travaillent sans synchronisation, autant le voir d'un coup d'œil.
        ctx["users_without_config"] = (
            User.objects
            .filter(appointment_types__isnull=False, google_calendar_config__isnull=True)
            .distinct()
            .order_by("username")
        )
        # Objets antérieurs à la migration 0007 (champ `user` ajouté après coup) :
        # sans propriétaire, ils n'appartiennent à aucun calendrier et ne sont donc
        # visibles que d'ici. Il faut les rattacher ou les supprimer.
        ctx["orphan_types"] = AppointmentType.objects.filter(user__isnull=True)
        ctx["orphan_availabilities"] = Availability.objects.filter(user__isnull=True)
        ctx["orphan_configs"] = GoogleCalendarConfig.objects.filter(user__isnull=True)
        ctx["has_orphans"] = any([
            ctx["orphan_types"].exists(),
            ctx["orphan_availabilities"].exists(),
            ctx["orphan_configs"].exists(),
        ])
        return ctx


@method_decorator(never_cache, name='dispatch')
class GoogleCalendarConfigView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Configuration Google d'UN calendrier.

    Sans `user_id` : le calendrier de l'utilisateur connecté.
    Avec `user_id`  : celui d'un autre gestionnaire — réservé au superviseur
    (cf. `get_target_user`, qui lève PermissionDenied sinon).
    """

    permission_required = 'calendars.view_googlecalendarconfig'
    raise_exception = True

    def _get_config(self, request, user_id=None):
        target = get_target_user(request, user_id)
        config, __ = GoogleCalendarConfig.objects.get_or_create(
            user=target, defaults={"name": "Primary"}
        )
        return target, config

    def _context(self, request, form, config, target):
        return {
            "form": form,
            "config": config,
            "target_user": target,
            "is_own_calendar": target == request.user,
            "is_calendar_supervisor": is_calendar_supervisor(request.user),
        }

    def get(self, request, user_id=None):
        target, config = self._get_config(request, user_id)
        form = GoogleCalendarConfigForm(instance=config)
        return render(request, "calendars/admin_config.html",
                      self._context(request, form, config, target))

    def post(self, request, user_id=None):
        target, config = self._get_config(request, user_id)
        if not request.user.has_perm('calendars.change_googlecalendarconfig'):
            raise PermissionDenied(_("Vous n'avez pas le droit de modifier cette configuration."))
        if request.POST.get("action") == "importer":
            # « Synchroniser maintenant » : sans attendre la tâche des 30 minutes.
            from .google_api import importer_les_occupations
            try:
                n = importer_les_occupations(config)
                messages.success(request, _("Agenda Google importé : %(n)s moment(s) occupé(s) sur 90 jours.") % {"n": n})
            except Exception as exc:
                GoogleCalendarConfig.objects.filter(pk=config.pk).update(busy_sync_error=str(exc)[:300])
                messages.error(request, _("Import impossible : %(erreur)s") % {"erreur": exc})
            if target != request.user:
                return redirect("jeiko_administration_calendars:google_config_user", user_id=target.pk)
            return redirect("jeiko_administration_calendars:google_config")
        form = GoogleCalendarConfigForm(request.POST, instance=config)
        if form.is_valid():
            form.save()
            messages.success(request, _("Configuration Google Calendar enregistrée avec succès !"))
            if target != request.user:
                return redirect("jeiko_administration_calendars:google_config_user", user_id=target.pk)
            return redirect("jeiko_administration_calendars:google_config")
        return render(request, "calendars/admin_config.html",
                      self._context(request, form, config, target))


@method_decorator(never_cache, name='dispatch')
class GoogleCalendarAdminListView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """Aperçu des événements Google d'un calendrier (le sien, ou celui d'un
    gestionnaire pour le superviseur)."""

    permission_required = 'calendars.view_googlecalendarconfig'
    raise_exception = True

    def get(self, request, user_id=None):
        target = get_target_user(request, user_id)
        config = GoogleCalendarConfig.objects.filter(user=target).first()
        events = []
        error = None

        if config and config.credentials_json:
            try:
                creds = Credentials.from_service_account_info(config.credentials_json)
                service = build('calendar', 'v3', credentials=creds)
                now = datetime.datetime.utcnow().isoformat() + 'Z'
                result = service.events().list(
                    calendarId=config.calendar_id,
                    timeMin=(datetime.datetime.utcnow() - datetime.timedelta(days=90)).isoformat() + 'Z',
                    maxResults=20,
                    singleEvents=True,
                    orderBy='startTime'
                ).execute()
                events = result.get('items', [])
            except Exception as e:
                error = f"Erreur lors de la récupération des événements : {e}"

        context = {
            "events": events,
            "error": error,
            "target_user": target,
            "is_own_calendar": target == request.user,
            "is_calendar_supervisor": is_calendar_supervisor(request.user),
        }
        return render(request, "calendars/calendar_list.html", context)


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeListView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                              PermissionRequiredMixin, ListView):
    model = AppointmentType
    template_name = "calendars/appointmenttype_list.html"
    context_object_name = "types"
    owner_lookup = "user"

    permission_required = 'calendars.view_appointmenttype'
    raise_exception = True

    def get_queryset(self):
        return super().get_queryset().select_related("user")


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = AppointmentType
    form_class = AppointmentTypeForm
    template_name = "calendars/appointmenttype_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointmenttype_list")

    permission_required = 'calendars.add_appointmenttype'
    raise_exception = True

    def form_valid(self, form):
        form.instance.user = self.request.user
        resp = super().form_valid(form)
        messages.success(self.request, _("Type de rendez-vous créé avec succès."))
        return resp


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeUpdateView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                                PermissionRequiredMixin, UpdateView):
    model = AppointmentType
    form_class = AppointmentTypeForm
    template_name = "calendars/appointmenttype_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointmenttype_list")
    owner_lookup = "user"

    permission_required = 'calendars.change_appointmenttype'
    raise_exception = True

    def form_valid(self, form):
        resp = super().form_valid(form)
        messages.success(self.request, _("Type de rendez-vous mis à jour avec succès."))
        return resp


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeDeleteView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                                PermissionRequiredMixin, DeleteView):
    model = AppointmentType
    template_name = "calendars/appointmenttype_confirm_delete.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointmenttype_list")
    owner_lookup = "user"

    permission_required = 'calendars.delete_appointmenttype'
    raise_exception = True

    # NB : depuis Django 4.1, DeleteView.post() passe par form_valid() —
    # surcharger delete() n'a plus aucun effet.
    def form_valid(self, form):
        messages.success(self.request, _("Type de rendez-vous supprimé avec succès."))
        return super().form_valid(form)


@method_decorator(never_cache, name='dispatch')
class AvailabilityListView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                           PermissionRequiredMixin, ListView):
    model = Availability
    template_name = "calendars/availability_list.html"
    context_object_name = "availabilities"
    owner_lookup = "user"

    permission_required = 'calendars.view_availability'
    raise_exception = True

    def get_queryset(self):
        # Les plus récentes en haut (demandé par Guillaume, 23/10/2026) : sans
        # ordre, la liste sortait dans celui de la base.
        return (super().get_queryset().select_related("user").prefetch_related("appointment_types")
                .order_by("-start", "-pk"))


@method_decorator(never_cache, name='dispatch')
class AvailabilityCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Availability
    form_class = AvailabilityForm
    template_name = "calendars/availability_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")

    permission_required = 'calendars.add_availability'
    raise_exception = True

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def form_valid(self, form):
        form.instance.user = self.request.user
        # super() enregistre l'objet PUIS les M2M (save_m2m) : les types sont
        # donc déjà rattachés quand on régénère les créneaux ci-dessous.
        resp = super().form_valid(form)
        self.object.generate_slots()
        messages.success(self.request, _("Disponibilité créée et créneaux générés."))
        return resp

@method_decorator(never_cache, name='dispatch')
class AvailabilityUpdateView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                             PermissionRequiredMixin, UpdateView):
    model = Availability
    form_class = AvailabilityForm
    template_name = "calendars/availability_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")
    owner_lookup = "user"

    permission_required = 'calendars.change_availability'
    raise_exception = True

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        # Les types proposés restent ceux du PROPRIÉTAIRE de la disponibilité,
        # même quand c'est le superviseur qui édite.
        kwargs['user'] = self.object.user
        return kwargs

    def form_valid(self, form):
        resp = super().form_valid(form)
        self.object.generate_slots()
        messages.success(self.request, _("Disponibilité mise à jour et créneaux régénérés."))
        return resp


@method_decorator(never_cache, name='dispatch')
class AvailabilityDeleteView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                             PermissionRequiredMixin, DeleteView):
    model = Availability
    template_name = "calendars/availability_confirm_delete.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")
    owner_lookup = "user"

    permission_required = 'calendars.delete_availability'
    raise_exception = True

    def form_valid(self, form):
        reponse = super().form_valid(form)
        messages.success(self.request, _("Disponibilité supprimée."))
        return reponse

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        # Avertissement : supprimer une dispo casse en cascade ses créneaux,
        # et donc les rendez-vous déjà réservés dessus.
        ctx["booked_appointments"] = (
            Appointment.objects.active()
            .filter(slot__availability=self.object, start__gte=timezone.now())
            .select_related("type")
            .order_by("start")
        )
        return ctx


@method_decorator(never_cache, name='dispatch')
class AppointmentAdminCancelView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Annulation d'un rendez-vous par le gestionnaire du calendrier.

    L'accès public par `pk` a été supprimé : il permettait à n'importe qui
    d'annuler n'importe quel rendez-vous (cf. AppointmentPublicCancelView).
    """
    template_name = "calendars/appointment_cancel_confirm.html"

    permission_required = 'calendars.delete_appointment'
    raise_exception = True

    def get_queryset(self):
        qs = Appointment.objects.select_related("type", "slot")
        if is_calendar_supervisor(self.request.user):
            return qs
        return qs.filter(type__user=self.request.user)

    def get(self, request, pk):
        appt = get_object_or_404(self.get_queryset(), pk=pk)
        return render(request, self.template_name, {"appointment": appt, "is_admin": True})

    def post(self, request, pk):
        appt = get_object_or_404(self.get_queryset(), pk=pk)
        # cancel() est idempotent : il ne renvoie True qu'au premier passage,
        # ce qui évite d'envoyer deux fois l'e-mail sur un double clic.
        if appt.cancel(
            by=Appointment.CancelledBy.MANAGER,
            reason=(request.POST.get("reason") or "").strip(),
        ):
            transaction.on_commit(
                lambda appt_id=appt.pk: send_appointment_email_safe(
                    appt_id, send_cancellation_emails
                )
            )
        messages.success(request, _("Le rendez-vous a bien été annulé."))
        return redirect("jeiko_administration_calendars:appointment_list_upcoming")


@method_decorator(never_cache, name='dispatch')
class AppointmentRefundView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Remboursement manuel d'un rendez-vous payé, par le gestionnaire.

    Complète la politique automatique (annulation client dans le délai) : le
    gestionnaire peut rembourser à tout moment un rendez-vous qu'il a annulé,
    ou une annulation client tardive, à sa discrétion.
    """
    permission_required = 'calendars.change_appointment'
    raise_exception = True

    def get_queryset(self):
        qs = Appointment.objects.select_related("type", "type__user")
        if is_calendar_supervisor(self.request.user):
            return qs
        return qs.filter(type__user=self.request.user)

    def post(self, request, pk):
        appt = get_object_or_404(self.get_queryset(), pk=pk)
        if not appt.is_refundable:
            messages.error(request, _("Ce rendez-vous n'a pas de paiement à rembourser."))
        else:
            try:
                payments.refund_appointment(appt, by_system=False)
                messages.success(request, _("Le remboursement a été émis."))
            except payments.RefundError as exc:
                messages.error(request, str(exc))
        return redirect(destination_sure(
            request,
            request.POST.get("next"),
            reverse("jeiko_administration_calendars:appointment_detail", kwargs={"pk": appt.pk}),
        ))


@method_decorator(never_cache, name='dispatch')
class NouveauRendezVousView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    « Nouveau rendez-vous » (Rendez-vous › À venir) : pour quelqu'un sans
    compte, par son nom et son adresse — sur un créneau ou à une heure libre,
    en visio ou non. Même formulaire et même enregistrement que depuis la
    fiche d'un contact (`crm.forms.RendezVousDuContactForm.enregistrer`). Un
    compte qui porte cette adresse reçoit le rendez-vous ; la fiche du CRM est
    retrouvée ou créée comme à une réservation publique.
    """
    template_name = "crm/admin/rendez_vous.html"
    permission_required = 'calendars.add_appointment'
    raise_exception = True

    def _formulaire(self, request, data=None):
        from jeiko.crm.forms import NouveauRendezVousForm
        return NouveauRendezVousForm(data, gestionnaire=request.user,
                                     superviseur=is_calendar_supervisor(request.user))

    def get(self, request):
        return render(request, self.template_name, {"form": self._formulaire(request)})

    def post(self, request):
        form = self._formulaire(request, request.POST)
        from jeiko.crm.rattachement import rattacher
        from jeiko.questionnaires_expert.models import Prospect

        rdv = None
        if form.is_valid():
            email = form.cleaned_data["email"].strip().lower()
            nom = form.cleaned_data["nom"].strip()
            compte = get_user_model().objects.filter(email__iexact=email, is_active=True).first()
            with transaction.atomic():
                # La fiche AVANT la séance de visio, qui la créerait sinon avec
                # l'origine « Visio » ; défaite avec le rendez-vous s'il échoue.
                rattacher(email, nom=nom, origine=Prospect.Origine.RENDEZ_VOUS)
                rdv = form.enregistrer(user_id=compte.pk if compte else None, email=email, client_name=nom)
                if rdv is None:
                    transaction.set_rollback(True)
        if rdv is None:
            return render(request, self.template_name, {"form": form})
        messages.success(request, _("Rendez-vous du %(date)s créé pour %(nom)s.") % {
            "date": f"{timezone.localtime(rdv.start):%d/%m/%Y %H:%M}", "nom": rdv.client_name})
        return redirect("jeiko_administration_calendars:appointment_list_upcoming")


@method_decorator(never_cache, name='dispatch')
class AppointmentClientCreateView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Création d'un rendez-vous par un gestionnaire POUR un client inscrit.

    Le client est désigné par l'URL (page de l'utilisateur). Le rendez-vous est
    confirmé d'emblée, rattaché au compte du client, et pris sur un créneau du
    calendrier du gestionnaire (tous les calendriers pour le superviseur).
    """
    template_name = "calendars/appointment/create_for_client.html"

    permission_required = 'calendars.add_appointment'
    raise_exception = True

    def _get_client(self, user_id):
        return get_object_or_404(get_user_model(), pk=user_id)

    def _form(self, request, data=None):
        return AppointmentClientCreateForm(
            data,
            manager=request.user,
            supervisor=is_calendar_supervisor(request.user),
        )

    def get(self, request, user_id):
        client = self._get_client(user_id)
        return render(request, self.template_name, {
            "client": client, "form": self._form(request),
        })

    def post(self, request, user_id):
        client = self._get_client(user_id)
        form = self._form(request, request.POST)
        if not form.is_valid():
            return render(request, self.template_name, {"client": client, "form": form})

        try:
            appt = self._create(form, client)
        except SlotUnavailable as exc:
            form.add_error("slot", str(exc))
            return render(request, self.template_name, {"client": client, "form": form})

        messages.success(
            request,
            _("Rendez-vous du %(date)s créé pour %(client)s.") % {
                "date": f"{timezone.localtime(appt.start):%d/%m/%Y %H:%M}",
                "client": client.get_full_name() or client.username,
            },
        )
        return redirect("jeiko_administration_users:user_detail", pk=client.pk)

    @transaction.atomic
    def _create(self, form, client):
        # Revérifie la place sous verrou : le créneau a pu se remplir entre
        # l'affichage du formulaire et la validation.
        slot = (
            Slot.objects.select_for_update()
            .select_related("type", "availability")
            .get(pk=form.cleaned_data["slot"].pk)
        )
        places = form.cleaned_data["places"]
        if not slot.is_available or places > slot.remaining_places:
            raise SlotUnavailable(_("Ce créneau n'a plus assez de places, veuillez en choisir un autre."))

        appt = Appointment.objects.create(
            type=slot.type,
            slot=slot,
            start=slot.start,
            end=slot.end,
            user=client,
            email=client.email or "",
            client_name=(client.get_full_name() or client.get_username()),
            places=places,
            is_paid=form.cleaned_data["is_paid"],
            status=Appointment.Status.CONFIRMED,
        )
        slot.sync_remaining_places()
        slot.availability.update_slots_availability()
        transaction.on_commit(lambda appt_id=appt.id: send_booking_emails_safe(appt_id))
        return appt


@method_decorator(never_cache, name='dispatch')
class AppointmentAttendanceView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Marque un rendez-vous passé comme honoré ou comme absence (no-show).
    """
    permission_required = 'calendars.change_appointment'
    raise_exception = True

    def post(self, request, pk):
        qs = Appointment.objects.select_related("type", "slot")
        if not is_calendar_supervisor(request.user):
            qs = qs.filter(type__user=request.user)
        appt = get_object_or_404(qs, pk=pk)

        attendance = request.POST.get("attendance")
        if attendance not in ("honoured", "no_show"):
            messages.error(request, _("Statut de présence inconnu."))
        elif not appt.mark_attendance(honoured=attendance == "honoured"):
            messages.error(request, _("Ce rendez-vous est annulé : sa présence ne se marque pas."))
        else:
            if attendance == "no_show":
                transaction.on_commit(
                    lambda appt_id=appt.pk: send_appointment_email_safe(
                        appt_id, send_no_show_email
                    )
                )
            messages.success(request, _("Rendez-vous marqué « %(get_status_display)s ».") % {"get_status_display": appt.get_status_display()})

        return redirect(destination_sure(
            request,
            request.POST.get("next"),
            "jeiko_administration_calendars:appointment_list_past",
        ))


@method_decorator(never_cache, name='dispatch')
class AppointmentPaymentView(View):
    """
    Page de règlement d'un rendez-vous, atteinte par jeton non devinable.

    Affiche Stripe Elements avec le `client_secret` du PaymentIntent. Le
    rendez-vous existe déjà et tient sa place ; il ne devient ferme qu'après
    encaissement.
    """
    template_name = "calendars/appointment_payment.html"

    def get(self, request, token):
        appt = get_object_or_404(
            Appointment.objects.select_related("type"), public_token=token
        )

        # Une place tenue trop longtemps est rendue : autant le dire ici plutôt
        # que d'encaisser un créneau qui vient d'être repris.
        if appt.hold_has_expired:
            appt.release_expired_hold()
            appt.refresh_from_db()

        context = {"appointment": appt, "deadline": appt.hold_expires_at}
        # CAL-01 : une personne connectée qui a assez de crédits peut régler
        # avec eux plutôt que par carte.
        if appt.is_awaiting_payment and request.user.is_authenticated:
            from .credits import solde
            context["credits"] = solde(request.user, appt.type)
            context["credits_suffisent"] = context["credits"] >= max(1, appt.places or 1)

        if appt.status == Appointment.Status.CONFIRMED:
            context["already_paid"] = True
            return render(request, self.template_name, context)

        if not appt.is_awaiting_payment:
            context["unavailable"] = _(
                "Cette réservation n'est plus en attente de paiement. "
                "Le créneau a peut-être été libéré ; merci de réserver à nouveau."
            )
            return render(request, self.template_name, context)

        try:
            client_secret, public_key = payments.create_payment_intent(appt)
        except payments.PaymentNotConfigured:
            context["unavailable"] = _(
                "Le paiement en ligne est momentanément indisponible. "
                "Merci de nous contacter directement."
            )
            return render(request, self.template_name, context)
        except Exception:
            logger.exception("Ouverture du paiement impossible (appt=%s)", appt.pk)
            context["unavailable"] = _(
                "Impossible d'ouvrir le paiement pour le moment, merci de réessayer."
            )
            return render(request, self.template_name, context)

        context.update({
            "client_secret": client_secret,
            "stripe_public_key": public_key,
            "return_url": request.build_absolute_uri(appt.get_payment_return_url()),
        })
        return render(request, self.template_name, context)


class AppointmentPayWithCreditsView(LoginRequiredMixin, View):
    """CAL-01 — régler un rendez-vous en attente avec ses crédits de séance."""

    def post(self, request, token):
        from .credits import regler_en_credits

        appt = get_object_or_404(Appointment.objects.select_related("type"), public_token=token)
        if regler_en_credits(appt, request.user):
            transaction.on_commit(lambda appt_id=appt.pk: send_booking_emails_safe(appt_id))
            return redirect(appt.get_payment_return_url())
        messages.error(request, _("Ce rendez-vous ne peut pas être réglé avec vos crédits "
                                  "(crédits insuffisants, expirés ou réservés à un autre type de séance)."))
        return redirect(reverse("jeiko_calendars_public:appointment_pay", kwargs={"token": appt.public_token}))


@method_decorator(never_cache, name='dispatch')
class AppointmentPaymentReturnView(View):
    """
    Retour du client depuis Stripe.

    Le statut n'est JAMAIS lu depuis les paramètres d'URL : on interroge Stripe
    avec l'identifiant de paiement. Le webhook confirme de son côté — les deux
    chemins sont idempotents et le premier arrivé gagne.
    """
    template_name = "calendars/appointment_payment_done.html"

    def get(self, request, token):
        appt = get_object_or_404(
            Appointment.objects.select_related("type"), public_token=token
        )

        intent_id = request.GET.get("payment_intent") or appt.payment_intent_id
        confirmed_now = False
        if intent_id and appt.is_awaiting_payment:
            checked, confirmed_now = payments.confirm_from_intent_id(intent_id)
            if checked is not None:
                appt = checked

        if confirmed_now:
            transaction.on_commit(
                lambda appt_id=appt.pk: send_booking_emails_safe(appt_id)
            )

        appt.refresh_from_db()
        return render(request, self.template_name, {
            "appointment": appt,
            "paid": appt.status == Appointment.Status.CONFIRMED,
            "still_pending": appt.is_awaiting_payment,
        })


@method_decorator(never_cache, name='dispatch')
class AppointmentPublicCancelView(View):
    """
    Annulation par le CLIENT, via le jeton non devinable reçu par e-mail.

    Le rendez-vous n'est jamais adressé par son `pk` : `public_token` est un
    UUID4, non énumérable. Un jeton inconnu renvoie 404, sans distinguer
    « n'existe pas » de « déjà annulé ».
    """
    template_name = "calendars/appointment_cancel_confirm.html"

    def get_appointment(self, token):
        return get_object_or_404(
            Appointment.objects.select_related("type", "slot"), public_token=token
        )

    def _refund_notice(self, appt):
        """Message indiquant au client s'il sera remboursé en annulant."""
        if not (appt.is_paid and appt.type_id and appt.type.requires_payment):
            return None
        if appt.is_refunded:
            return _("Ce rendez-vous a déjà été remboursé.")
        if appt.is_within_refund_window():
            return (
                _("En annulant maintenant, vous serez remboursé de %(montant)s €.")
                % {"montant": appt.amount_due}
            )
        return (
            _("L'annulation est trop tardive pour un remboursement automatique. "
            "Contactez-nous si vous pensez y avoir droit.")
        )

    def get(self, request, token):
        appt = self.get_appointment(token)
        return render(request, self.template_name, {
            "appointment": appt,
            "is_admin": False,
            "cancellable": appt.is_cancellable_by_client(),
            "refund_notice": self._refund_notice(appt),
        })

    def post(self, request, token):
        appt = self.get_appointment(token)
        if not appt.is_cancellable_by_client():
            return render(request, self.template_name, {
                "appointment": appt,
                "is_admin": False,
                "cancellable": False,
                "error": (
                    _("Ce rendez-vous a déjà été annulé.")
                    if appt.is_cancelled
                    else _("Ce rendez-vous est passé : il ne peut plus être annulé en ligne.")
                ),
            })
        if appt.cancel(by=Appointment.CancelledBy.CLIENT):
            transaction.on_commit(
                lambda appt_id=appt.pk: send_appointment_email_safe(
                    appt_id, send_cancellation_emails
                )
            )
        return render(request, "calendars/appointment_cancel_done.html")


@method_decorator(never_cache, name='dispatch')
class AppointmentUpcomingListView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                                  PermissionRequiredMixin, ListView):
    model = Appointment
    template_name = "calendars/appointment/list.html"
    context_object_name = "appointments"
    paginate_by = 50
    owner_lookup = "type__user"

    permission_required = 'calendars.view_appointment'
    raise_exception = True

    def get_queryset(self):
        qs = super().get_queryset().select_related("type", "type__user", "slot")
        today = timezone.localdate()
        # Inclut tous les RDV dont la date de début est >= aujourd’hui (0h00).
        # Les annulés sortent de l'agenda : ils restent consultables dans l'historique.
        return qs.active().filter(start__date__gte=today).order_by("start")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["now"] = timezone.now()
        ctx["today"] = timezone.localdate()
        ctx["scope"] = "upcoming"
        return ctx


@method_decorator(never_cache, name='dispatch')
class AppointmentPastListView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                              PermissionRequiredMixin, ListView):
    model = Appointment
    template_name = "calendars/appointment/list.html"
    context_object_name = "appointments"
    paginate_by = 50
    owner_lookup = "type__user"

    permission_required = 'calendars.view_appointment'
    raise_exception = True

    def get_queryset(self):
        qs = super().get_queryset().select_related("type", "type__user", "slot")
        today = timezone.localdate()
        # Tous les RDV avant aujourd’hui
        return qs.filter(start__date__lt=today).order_by("-start")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["now"] = timezone.now()
        ctx["today"] = timezone.localdate()
        ctx["scope"] = "past"
        return ctx


@method_decorator(never_cache, name='dispatch')
class AppointmentDetailView(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "calendars/appointment/detail.html"

    permission_required = 'calendars.view_appointment'
    raise_exception = True

    def get(self, request, pk):
        qs = Appointment.objects.select_related("type", "type__user", "slot")
        if not is_calendar_supervisor(request.user):
            qs = qs.filter(type__user=request.user)
        appt = get_object_or_404(qs, pk=pk)
        fiche = None
        if appt.email and request.user.has_perm("questionnaires_expert.view_prospect"):
            from jeiko.questionnaires_expert.models import Prospect
            fiche = Prospect.objects.filter(email__iexact=appt.email).order_by("id").first()
        return render(request, self.template_name, {
            "appointment": appt,
            "is_calendar_supervisor": is_calendar_supervisor(request.user),
            "fiche_du_contact": fiche,
        })


@method_decorator(never_cache, name='dispatch')
class AppointmentUpdateView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                            PermissionRequiredMixin, UpdateView):
    model = Appointment
    form_class = AppointmentFormAdmin
    template_name = "calendars/appointment/form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointment_list_upcoming")
    owner_lookup = "type__user"

    permission_required = 'calendars.change_appointment'
    raise_exception = True

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        # Restreint types & créneaux sélectionnables au calendrier du
        # propriétaire du RDV : sans ça, un POST forgé rattache le rendez-vous
        # au créneau d'un autre gestionnaire.
        kwargs['owner'] = self.object.owner
        return kwargs

    @transaction.atomic
    def form_valid(self, form):
        old = self.get_object()
        old_slot = old.slot
        old_start = old.start

        resp = super().form_valid(form)  # self.object est mis à jour

        # Le rendez-vous a-t-il été déplacé dans le temps ? On prévient le client
        # (après commit, à l'abri des exceptions), sauf s'il est annulé.
        if (
            old_start
            and self.object.start
            and old_start != self.object.start
            and self.object.status != Appointment.Status.CANCELLED
        ):
            transaction.on_commit(
                lambda appt_id=self.object.pk, os=old_start:
                send_reschedule_email_safe(appt_id, os)
            )

        # Gestion de la capacité si on change de slot
        new_slot = self.object.slot
        if old_slot and new_slot and old_slot.id != new_slot.id:
            # On libère l'ancien slot
            old_slot.remaining_places += 1
            if old_slot.remaining_places > 0:
                old_slot.is_available = True
            old_slot.save(update_fields=["remaining_places", "is_available"])
            old_slot.availability.update_slots_availability()

            # On occupe le nouveau slot (si dispo)
            # (Dans un vrai flux, tu peux vérifier la dispo ici aussi)
            new_slot.remaining_places = max(0, new_slot.remaining_places - 1)
            if new_slot.remaining_places <= 0:
                new_slot.is_available = False
            new_slot.save(update_fields=["remaining_places", "is_available"])
            new_slot.availability.update_slots_availability()

        messages.success(self.request, _("Rendez-vous mis à jour."))
        return resp




class APIBookAppointmentView(View):
    """
    Réservation publique (sans compte).

    S-07 (28/09/2026) — plus exemptée de CSRF. Elle rattache la réservation
    au compte connecté, et lit le corps quel que soit son type : un autre site
    pouvait poster en `text/plain` — sans requête préalable CORS — et réserver
    au nom d'un visiteur connecté. Le jeton vient du cookie `csrftoken`,
    déposé par `APIAvailabilitiesView`, que le calendrier appelle toujours
    avant de proposer un créneau.

    Point d'entrée ouvert : il est protégé par des garde-fous anti-abus
    (leurre, plafonds par IP et par e-mail) et ne renvoie jamais de détail
    technique au client.
    """

    def post(self, request):
        try:
            payload = json.loads(request.body or b"{}")
            if not isinstance(payload, dict):
                raise ValueError("payload")
        except Exception:
            return JsonResponse(
                {'success': False, 'message': _("Requête invalide.")}, status=400
            )

        email = clean_booking_email(payload.get('email'))
        if not email:
            return JsonResponse(
                {'success': False, 'message': _("Merci de saisir une adresse e-mail valide.")},
                status=400,
            )

        refusal = check_booking_request(request, payload, email)
        if refusal:
            return JsonResponse({'success': False, 'message': refusal}, status=429)

        contact_consent = bool(payload.get('contact_consent'))

        # Le navigateur demande le nom ; le serveur ne l'exige pas — une
        # réservation sans nom reste possible (test_booking_without_name_still_works).
        client_name = (payload.get('name') or "").strip()[:150]

        try:
            appt = self._book(
                request,
                payload.get('slot_id'),
                email,
                client_name=client_name,
                places=payload.get('places', 1),
                contact_consent=contact_consent,
                client_timezone=fuseau_valide(payload.get('timezone')),
                donnees=payload,
            )
        except ChampManquant as exc:
            return JsonResponse({'success': False, 'message': str(exc)}, status=400)
        except SlotUnavailable as exc:
            return JsonResponse({'success': False, 'message': str(exc)}, status=400)
        except LoginRequiredForBooking as exc:
            return JsonResponse(
                {'success': False, 'message': str(exc), 'login_required': True},
                status=403,
            )
        except payments.PaymentNotConfigured:
            logger.error(
                "Rendez-vous payant demandé alors qu'aucune passerelle de paiement "
                "n'est active (slot_id=%r).", payload.get('slot_id')
            )
            return JsonResponse(
                {'success': False,
                 'message': _("Le paiement en ligne est momentanément indisponible. "
                            "Merci de nous contacter directement.")},
                status=503,
            )
        except Exception:
            # Aucun détail technique vers le client : il finirait dans une
            # console de navigateur, voire indexé.
            logger.exception("Échec de réservation (slot_id=%r)", payload.get('slot_id'))
            return JsonResponse(
                {'success': False, 'message': _("Une erreur est survenue, merci de réessayer.")},
                status=500,
            )

        record_booking(request, email)

        if contact_consent:
            _record_contact_consent(request, appt)

        _rattacher_au_crm(appt)

        if appt.is_awaiting_payment:
            # La place est tenue : le client doit régler pour confirmer.
            return JsonResponse({
                'success': True,
                'payment_required': True,
                'amount': str(appt.amount_due),
                'payment_url': appt.get_payment_url(),
                'message': _("Créneau réservé. Il reste à régler pour confirmer."),
            })

        return JsonResponse({'success': True, 'message': _("Rendez-vous réservé avec succès !")})

    @staticmethod
    def _clean_places(raw, slot):
        """
        Valide le nombre de places demandé.

        Deux plafonds : celui fixé par le gestionnaire sur le type de rendez-vous
        (`max_places_per_booking`), et ce qu'il reste réellement sur le créneau.
        """
        try:
            places = int(raw)
        except (TypeError, ValueError):
            raise SlotUnavailable(_("Nombre de places invalide."))

        if places < 1:
            raise SlotUnavailable(_("Nombre de places invalide."))

        maximum = max(1, slot.type.max_places_per_booking)
        if places > maximum:
            raise SlotUnavailable(
                ngettext(
                    "Vous ne pouvez réserver que %(n)s place au maximum pour ce rendez-vous.",
                    "Vous ne pouvez réserver que %(n)s places au maximum pour ce rendez-vous.",
                    maximum,
                ) % {"n": maximum}
            )
        if places > slot.remaining_places:
            raise SlotUnavailable(
                ngettext(
                    "Il ne reste que %(n)s place sur ce créneau.",
                    "Il ne reste que %(n)s places sur ce créneau.",
                    slot.remaining_places,
                ) % {"n": slot.remaining_places}
            )
        return places

    @transaction.atomic
    def _book(self, request, slot_id, email, client_name="", places=1,
              contact_consent=False, client_timezone="", donnees=None):
        """
        Réserve une ou plusieurs places. La transaction couvre uniquement cette
        méthode : toute exception remonte et provoque bien un rollback —
        auparavant le `except` interne validait un état partiel.
        """
        # Rend d'abord les places des réservations non réglées dans le délai :
        # sans ça, un panier abandonné bloquerait le créneau jusqu'au prochain
        # passage du cron.
        payments.expire_holds(
            Appointment.objects.filter(slot_id=slot_id)
        )

        # `select_related` s'arrête à `type` : joindre `type__user`, nullable,
        # produirait une jointure externe que PostgreSQL refuse de verrouiller
        # (« FOR UPDATE cannot be applied to the nullable side of an outer join »).
        slot = Slot.objects.select_related("type").select_for_update().filter(
            id=slot_id,
            is_available=True,
            remaining_places__gt=0,
            start__gte=timezone.now()
        ).first()
        if not slot:
            raise SlotUnavailable(_("Créneau non disponible ou déjà réservé."))

        appt_type = slot.type

        # « Réservation uniquement pour inscrits » : jusqu'ici le drapeau était
        # affiché dans l'admin mais n'était appliqué nulle part.
        if appt_type.is_registration_required and not request.user.is_authenticated:
            raise LoginRequiredForBooking(
                _("Ce rendez-vous est réservé aux personnes inscrites. "
                "Merci de vous connecter avant de réserver.")
            )

        places = self._clean_places(places, slot)
        needs_payment = appt_type.requires_payment
        try:
            champs = lire_les_champs(appt_type, donnees)
        except ValueError as exc:
            raise ChampManquant(str(exc))

        if needs_payment and not payments.is_available():
            raise payments.PaymentNotConfigured()

        appt = Appointment.objects.create(
            type=appt_type,
            slot=slot,
            start=slot.start,
            end=slot.end,
            email=email,
            client_name=client_name,
            places=places,
            user=request.user if request.user.is_authenticated else None,
            status=(Appointment.Status.PENDING_PAYMENT if needs_payment
                    else Appointment.Status.CONFIRMED),
            amount_due=appt_type.amount_for(places) if needs_payment else 0,
            hold_expires_at=payments.hold_deadline() if needs_payment else None,
            contact_consent=bool(contact_consent),
            contact_consent_at=timezone.now() if contact_consent else None,
            client_timezone=client_timezone,
            **champs,
        )

        # Recompte depuis les rendez-vous réels (idempotent), puis referme les
        # créneaux qui chevauchent : le gestionnaire est désormais occupé.
        # Une réservation en attente de paiement occupe bien sa place.
        slot.sync_remaining_places()
        slot.availability.update_slots_availability()

        if needs_payment:
            # Ouvre le paiement dans la transaction : si Stripe refuse, la
            # réservation est annulée et la place jamais bloquée.
            payments.create_payment_intent(appt)
            # E-mail avec le lien de règlement : sans lui, un client qui ferme
            # l'onglet perd son lien et bloque la place jusqu'à expiration.
            transaction.on_commit(
                lambda appt_id=appt.id: send_appointment_email_safe(
                    appt_id, send_payment_pending_email
                )
            )
            return appt

        # La synchronisation Google est portée par le signal post_save de
        # Appointment. L'envoi des e-mails est déclenché après commit.
        transaction.on_commit(lambda appt_id=appt.id: send_booking_emails_safe(appt_id))
        return appt


class APIJoinWaitlistView(View):
    """
    Inscription publique en liste d'attente sur un créneau complet.

    Mêmes garde-fous anti-abus que la réservation : leurre, plafonds, e-mail
    validé, aucun détail technique renvoyé au client.
    """

    def post(self, request):
        try:
            payload = json.loads(request.body or b"{}")
            if not isinstance(payload, dict):
                raise ValueError
        except Exception:
            return JsonResponse({'success': False, 'message': _("Requête invalide.")}, status=400)

        email = clean_booking_email(payload.get('email'))
        if not email:
            return JsonResponse(
                {'success': False, 'message': _("Merci de saisir une adresse e-mail valide.")},
                status=400,
            )

        refusal = check_booking_request(request, payload, email)
        if refusal:
            return JsonResponse({'success': False, 'message': refusal}, status=429)

        slot = Slot.objects.select_related("type").filter(id=payload.get('slot_id')).first()
        if slot is None:
            return JsonResponse({'success': False, 'message': _("Créneau introuvable.")}, status=404)

        client_name = (payload.get('name') or "").strip()[:150]
        try:
            champs = lire_les_champs(slot.type, payload)
        except ValueError as exc:
            return JsonResponse({'success': False, 'message': str(exc)}, status=400)

        try:
            entry, created = waitlist.join(
                slot, email,
                client_name=client_name,
                places=payload.get('places', 1),
                user=request.user if request.user.is_authenticated else None,
                champs=champs,
            )
        except waitlist.WaitlistError as exc:
            return JsonResponse({'success': False, 'message': str(exc)}, status=400)
        except Exception:
            logger.exception("Inscription liste d'attente impossible (slot=%r)",
                             payload.get('slot_id'))
            return JsonResponse(
                {'success': False, 'message': _("Une erreur est survenue, merci de réessayer.")},
                status=500,
            )

        record_booking(request, email)
        _rattacher_au_crm(entry)
        position = waitlist.position_of(entry)
        message = (
            _("Vous êtes inscrit en liste d'attente (position %(position)s). "
              "Nous vous préviendrons par e-mail dès qu'une place se libère.")
            % {"position": position}
            if created or entry.status == entry.Status.WAITING else
            _("Vous étiez déjà inscrit en liste d'attente pour ce créneau.")
        )
        return JsonResponse({'success': True, 'message': message, 'position': position})


@method_decorator(never_cache, name='dispatch')
class WaitlistClaimView(View):
    """
    Réservation de la place tenue, atteinte par jeton non devinable.

    La place est déjà réservée pour cette personne (son entrée l'occupe) : on ne
    repasse donc pas par la disponibilité du créneau, on valide le jeton.
    """
    template_name = "calendars/waitlist_claim.html"

    def _entry(self, token):
        from .models import WaitlistEntry
        return get_object_or_404(
            WaitlistEntry.objects.select_related("slot", "slot__type"),
            public_token=token,
        )

    def get(self, request, token):
        entry = self._entry(token)
        context = {"entry": entry, "slot": entry.slot, "type": entry.slot.type}

        if entry.status == entry.Status.CONVERTED:
            context["already_done"] = True
        elif entry.claim_has_expired:
            context["expired"] = True
        elif entry.status != entry.Status.NOTIFIED:
            context["unavailable"] = True
        else:
            context["claimable"] = True
            context["amount"] = (
                entry.slot.type.amount_for(entry.places)
                if entry.slot.type.requires_payment else None
            )
            context["deadline"] = entry.claim_expires_at
        return render(request, self.template_name, context)

    def post(self, request, token):
        entry = self._entry(token)
        try:
            appt = self._convert(entry)
        except waitlist.WaitlistError as exc:
            return render(request, self.template_name, {
                "entry": entry, "slot": entry.slot, "type": entry.slot.type,
                "unavailable": True, "error": str(exc),
            })
        except payments.PaymentNotConfigured:
            return render(request, self.template_name, {
                "entry": entry, "slot": entry.slot, "type": entry.slot.type,
                "unavailable": True,
                "error": _("Le paiement en ligne est momentanément indisponible."),
            })

        if appt.is_awaiting_payment:
            return redirect(appt.get_payment_url())
        return render(request, "calendars/waitlist_claim_done.html", {
            "appointment": appt, "slot": entry.slot,
        })

    @transaction.atomic
    def _convert(self, entry):
        """
        Transforme l'entrée prévenue en rendez-vous.

        La place tenue par l'entrée passe au rendez-vous créé : occupation
        inchangée, aucune survente possible.
        """
        from .models import WaitlistEntry

        slot = (
            Slot.objects.select_for_update()
            .select_related("type", "availability")
            .get(pk=entry.slot_id)
        )
        entry = WaitlistEntry.objects.select_for_update().get(pk=entry.pk)

        if entry.status != WaitlistEntry.Status.NOTIFIED or entry.claim_has_expired:
            raise waitlist.WaitlistError(
                _("Ce lien n'est plus valable : le délai est peut-être dépassé.")
            )

        appt_type = slot.type
        needs_payment = appt_type.requires_payment
        if needs_payment and not payments.is_available():
            raise payments.PaymentNotConfigured()

        appt = Appointment.objects.create(
            type=appt_type, slot=slot, start=slot.start, end=slot.end,
            email=entry.email, client_name=entry.client_name, places=entry.places,
            user=entry.user,
            # Ce que la personne avait saisi en s'inscrivant en attente.
            phone=entry.phone, company=entry.company, job_title=entry.job_title,
            message=entry.message,
            status=(Appointment.Status.PENDING_PAYMENT if needs_payment
                    else Appointment.Status.CONFIRMED),
            amount_due=appt_type.amount_for(entry.places) if needs_payment else 0,
            hold_expires_at=payments.hold_deadline() if needs_payment else None,
        )

        entry.status = WaitlistEntry.Status.CONVERTED
        entry.claim_expires_at = None
        entry.save(update_fields=["status", "claim_expires_at"])

        slot.sync_remaining_places()
        slot.availability.update_slots_availability()

        if needs_payment:
            payments.create_payment_intent(appt)
            transaction.on_commit(
                lambda appt_id=appt.id: send_appointment_email_safe(
                    appt_id, send_payment_pending_email
                )
            )
        else:
            transaction.on_commit(lambda appt_id=appt.id: send_booking_emails_safe(appt_id))
        return appt


@method_decorator(never_cache, name='dispatch')
class WaitlistLeaveView(View):
    """Désinscription de la liste d'attente, par jeton non devinable."""
    template_name = "calendars/waitlist_leave.html"

    def _entry(self, token):
        from .models import WaitlistEntry
        return get_object_or_404(WaitlistEntry.objects.select_related("slot"), public_token=token)

    def get(self, request, token):
        entry = self._entry(token)
        return render(request, self.template_name, {
            "entry": entry, "slot": entry.slot, "active": entry.is_active,
        })

    def post(self, request, token):
        entry = self._entry(token)
        waitlist.leave(entry)
        return render(request, self.template_name, {
            "entry": entry, "slot": entry.slot, "done": True,
        })


@method_decorator(never_cache, name="dispatch")
@method_decorator(ensure_csrf_cookie, name="dispatch")
class APIAvailabilitiesView(View):
    # Dépose le cookie CSRF que la réservation exige (S-07) : la page qui
    # porte le calendrier peut venir du cache, sans jeton ni cookie.
    def get(self, request):
        appointment_type_id = request.GET.get("type")
        provider_id = request.GET.get("provider")

        # Créneaux réservables (place libre), PLUS les créneaux complets dont le
        # type propose la liste d'attente — ces derniers marqués `waitlist_open`.
        slots = Slot.objects.filter(start__gte=timezone.now()).filter(
            Q(is_available=True, remaining_places__gt=0)
            | Q(type__allow_waitlist=True, remaining_places=0)
        )
        if appointment_type_id:
            slots = slots.filter(type_id=appointment_type_id)

        if provider_id:
            slots = slots.filter(availability__user_id=provider_id)

        from .models import WaitlistEntry
        slots = slots.select_related("type").annotate(
            _waiting=Count(
                "waitlist_entries",
                filter=Q(waitlist_entries__status=WaitlistEntry.Status.WAITING),
            )
        )

        data = []
        for slot in slots.order_by('start'):
            display = f"{slot.start.strftime('%A %d %B à %Hh%M')} ({int((slot.end-slot.start).total_seconds()//60)} min)"
            waitlist_open = slot.remaining_places == 0 and slot.type.allow_waitlist
            data.append({
                "id": slot.id,
                "availability_id": slot.availability_id,
                "start": slot.start.isoformat(),
                "end": slot.end.isoformat(),
                "display": display,
                "type": slot.type.name,
                "slot_minutes": int((slot.end-slot.start).total_seconds()//60),
                "remaining_places": slot.remaining_places,
                "type_color": slot.type.color,
                # Plafond de places par réservation, borné par ce qu'il reste :
                # le front n'a plus qu'à proposer 1..max_places.
                "max_places": min(
                    max(1, slot.type.max_places_per_booking),
                    slot.remaining_places,
                ) if slot.remaining_places else 0,
                "waitlist_open": waitlist_open,
                "waitlist_count": slot._waiting if waitlist_open else 0,
                # Ce que la réservation demande pour ce type (CRM-01).
                "champs": champs_a_demander(slot.type),
            })
        return JsonResponse(data, safe=False)


@method_decorator(never_cache, name='dispatch')
class SeancesView(CalendarOwnerQuerysetMixin, LoginRequiredMixin,
                  PermissionRequiredMixin, ListView):
    """
    CAL-01 — les créneaux, et qui y est inscrit (Guillaume, 12/10/2026).

    La liste des rendez-vous les montre un par un : pour un cours collectif à
    douze places, il fallait recomposer la séance à la main. Ici, créneau par
    créneau à venir : son type, ses places prises sur le total, ses inscrits
    (places, paiement, statut) et sa liste d'attente dans l'ordre. Par
    défaut, les créneaux qui ont quelqu'un ; « vides aussi » montre le reste,
    et un type se choisit.
    """
    model = Slot
    template_name = "calendars/appointment/seances.html"
    context_object_name = "seances"
    paginate_by = 30
    owner_lookup = "type__user"

    permission_required = 'calendars.view_appointment'
    raise_exception = True

    def get_queryset(self):
        from django.db.models import Prefetch

        from .models import WaitlistEntry

        attente = (WaitlistEntry.Status.WAITING, WaitlistEntry.Status.NOTIFIED)
        occupants = [s for s in Appointment.Status.values if s != Appointment.Status.CANCELLED]
        qs = super().get_queryset().filter(end__gte=timezone.now())
        if self.request.GET.get("type", "").isdigit():
            qs = qs.filter(type_id=int(self.request.GET["type"]))
        if not self.request.GET.get("vides"):
            qs = qs.filter(Q(appointments__status__in=occupants)
                           | Q(waitlist_entries__status__in=attente)
                           | Q(places_bloquees__gt=0)).distinct()
        return (
            qs.select_related("type", "type__user")
            .prefetch_related(
                Prefetch("appointments", queryset=Appointment.objects.active().select_related("user").order_by("created"),
                         to_attr="inscrits"),
                Prefetch("waitlist_entries", queryset=WaitlistEntry.objects.filter(status__in=attente).order_by("created"),
                         to_attr="en_attente"),
            )
            .order_by("start")
        )

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        for seance in ctx["seances"]:
            seance.prises = sum(a.places for a in seance.inscrits)
        types = AppointmentType.objects.order_by("name")
        if not self.is_calendar_supervisor():
            types = types.filter(user=self.request.user)
        ctx["types"] = types
        ctx["type_choisi"] = self.request.GET.get("type", "")
        ctx["vides"] = bool(self.request.GET.get("vides"))
        ctx["peut_bloquer"] = self.request.user.has_perm("calendars.change_appointment")
        return ctx


class BloquerDesPlacesView(CalendarOwnerQuerysetMixin, LoginRequiredMixin, PermissionRequiredMixin, View):
    """CAL-01 — retenir des places à la main sur un créneau, ou les libérer (0)."""
    model = Slot
    owner_lookup = "type__user"
    permission_required = 'calendars.change_appointment'
    raise_exception = True

    def get_queryset(self):
        qs = Slot.objects.all()
        if self.is_calendar_supervisor():
            return qs
        return qs.filter(type__user=self.request.user)

    def post(self, request, pk):
        from django.utils.http import url_has_allowed_host_and_scheme

        slot = get_object_or_404(self.get_queryset(), pk=pk)
        brut = (request.POST.get("places", "") or "0").strip()
        if not brut.isdigit():
            messages.error(request, _("Indiquez un nombre de places (0 pour tout libérer)."))
        else:
            try:
                slot.bloquer(int(brut), request.POST.get("note", ""))
            except ValueError as souci:
                messages.error(request, str(souci))
            else:
                messages.success(request, _("Places bloquées : %(n)s.") % {"n": slot.places_bloquees})
        suite = request.POST.get("next", "")
        if not url_has_allowed_host_and_scheme(suite, allowed_hosts={request.get_host()}):
            suite = reverse("jeiko_administration_calendars:seances")
        return redirect(suite)



class OffrirDesCreditsView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """CAL-01 — offrir des crédits de séance à un membre, depuis sa fiche."""
    permission_required = 'calendars.change_appointment'
    raise_exception = True

    def post(self, request, user_id):
        from django.utils.dateparse import parse_date

        from .credits import offrir

        membre = get_object_or_404(get_user_model(), pk=user_id)
        retour = reverse("jeiko_administration_users:user_detail", args=[membre.pk])
        brut = (request.POST.get("credits") or "").strip()
        type_rdv = AppointmentType.objects.filter(pk=request.POST.get("type") or 0).first()
        jour = parse_date(request.POST.get("expire_le") or "")
        if not brut.isdigit() or int(brut) <= 0:
            messages.error(request, _("Indiquez un nombre de crédits."))
            return redirect(retour)
        expire = None
        if jour:
            expire = timezone.make_aware(datetime.datetime.combine(jour, datetime.time(23, 59)))
        offrir(membre, int(brut), type_rdv=type_rdv, expire_le=expire,
               note=request.POST.get("note", ""), par=request.user)
        messages.success(request, _("%(n)s crédit(s) offert(s).") % {"n": int(brut)})
        return redirect(retour + "#rdv")
