from django.views import View
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
import datetime
from django.shortcuts import render, redirect, get_object_or_404
from .forms import GoogleCalendarConfigForm, AvailabilityForm, AppointmentTypeForm, AppointmentFormAdmin
from .models import GoogleCalendarConfig, Availability, AppointmentType, Appointment, Slot
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin, PermissionRequiredMixin
from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache
from django.utils import timezone
from django.http import JsonResponse
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from datetime import timedelta
from django.views.decorators.csrf import csrf_exempt
import json
from django.db import transaction
import logging
from .google_api import upsert_event
from .emailing import send_booking_emails

logger = logging.getLogger(__name__)


@method_decorator(never_cache, name='dispatch')
class GoogleCalendarConfigListAllView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    """
    Liste TOUS les GoogleCalendarConfig (admin seulement)
    """
    model = GoogleCalendarConfig
    template_name = "calendars/config_list_all.html"
    context_object_name = "configs"
    
    def test_func(self):
        return self.request.user.is_staff or self.request.user.is_superuser
    
    def get_queryset(self):
        return GoogleCalendarConfig.objects.select_related('user').all().order_by('user__username', 'name')


@method_decorator(never_cache, name='dispatch')
class GoogleCalendarConfigView(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'calendars.view_googlecalendar'
    raise_exception = True

    def get(self, request):
        config, _ = GoogleCalendarConfig.objects.get_or_create(user=request.user, defaults={"name": "Primary"})
        form = GoogleCalendarConfigForm(instance=config)
        return render(request, "calendars/admin_config.html", {"form": form, "config": config})

    def post(self, request):
        config, _ = GoogleCalendarConfig.objects.get_or_create(user=request.user, defaults={"name": "Primary"})
        form = GoogleCalendarConfigForm(request.POST, instance=config)
        if form.is_valid():
            form.save()
            messages.success(request, "Clé Google Calendar enregistrée avec succès !")
            return redirect("jeiko_administration_calendars:google_config")
        return render(request, "calendars/admin_config.html", {"form": form, "config": config})


@method_decorator(never_cache, name='dispatch')
class GoogleCalendarAdminListView(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = 'calendars.view_googlecalendar'
    raise_exception = True

    def get(self, request):
        config = GoogleCalendarConfig.objects.filter(user=request.user).first()
        events = []
        error = None

        if config and config.credentials_json:
            try:
                creds = Credentials.from_service_account_info(config.credentials_json)
                service = build('calendar', 'v3', credentials=creds)
                now = datetime.datetime.utcnow().isoformat() + 'Z'
                result = service.events().list(
                    calendarId=config.calendar_id,
                    timeMin=(datetime.datetime.utcnow() - datetime.timedelta(days=90)).isoformat() + 'Z',
                    maxResults=20,
                    singleEvents=True,
                    orderBy='startTime'
                ).execute()
                events = result.get('items', [])
            except Exception as e:
                error = f"Erreur lors de la récupération des événements : {e}"

        context = {
            "events": events,
            "error": error
        }
        return render(request, "calendars/calendar_list.html", context)


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = AppointmentType
    template_name = "calendars/appointmenttype_list.html"
    context_object_name = "types"

    def get_queryset(self):
        return AppointmentType.objects.filter(user=self.request.user)

    permission_required = 'calendars.view_appointmenttype'
    raise_exception = True


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = AppointmentType
    form_class = AppointmentTypeForm
    template_name = "calendars/appointmenttype_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointmenttype_list")

    permission_required = 'calendars.add_appointmenttype'
    raise_exception = True

    def form_valid(self, form):
        form.instance.user = self.request.user
        resp = super().form_valid(form)
        messages.success(self.request, "Type de rendez-vous créé avec succès.")
        return resp


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = AppointmentType
    form_class = AppointmentTypeForm
    template_name = "calendars/appointmenttype_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointmenttype_list")

    permission_required = 'calendars.change_appointmenttype'
    raise_exception = True

    def form_valid(self, form):
        resp = super().form_valid(form)
        messages.success(self.request, "Type de rendez-vous mis à jour avec succès.")
        return resp


@method_decorator(never_cache, name='dispatch')
class AppointmentTypeDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = AppointmentType
    template_name = "calendars/appointmenttype_confirm_delete.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointmenttype_list")

    permission_required = 'calendars.delete_appointmenttype'
    raise_exception = True

    def delete(self, request, *args, **kwargs):
        messages.success(self.request, "Type de rendez-vous supprimé avec succès.")
        return super().delete(request, *args, **kwargs)@method_decorator(never_cache, name='dispatch')


@method_decorator(never_cache, name='dispatch')
class AvailabilityListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Availability
    template_name = "calendars/availability_list.html"
    context_object_name = "availabilities"

    def get_queryset(self):
        return Availability.objects.filter(user=self.request.user)

    permission_required = 'calendars.view_availability'
    raise_exception = True


@method_decorator(never_cache, name='dispatch')
class AvailabilityCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Availability
    form_class = AvailabilityForm
    template_name = "calendars/availability_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")

    permission_required = 'calendars.add_availability'
    raise_exception = True

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

    def form_valid(self, form):
        form.instance.user = self.request.user
        resp = super().form_valid(form)
        # IMPORTANT : ManyToMany n’est fixé qu’après form_valid -> form.save_m2m a déjà été appelé
        # mais selon la version de Django/form mixins, on s’assure :
        try:
            form.save_m2m()
        except Exception:
            pass
        # On force la génération maintenant pour retour immédiat en UI
        self.object.generate_slots()
        messages.success(self.request, "Disponibilité créée et créneaux générés.")
        return resp

@method_decorator(never_cache, name='dispatch')
class AvailabilityUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Availability
    form_class = AvailabilityForm
    template_name = "calendars/availability_form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")

    permission_required = 'calendars.change_availability'
    raise_exception = True

    def get_initial(self):
        initial = super().get_initial()
        print("get_initial:", initial)
        return initial

    def form_valid(self, form):
        resp = super().form_valid(form)
        try:
            form.save_m2m()
        except Exception:
            pass
        self.object.generate_slots()
        messages.success(self.request, "Disponibilité mise à jour et créneaux régénérés.")
        return resp


@method_decorator(never_cache, name='dispatch')
class AvailabilityDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Availability
    template_name = "calendars/availability_confirm_delete.html"
    success_url = reverse_lazy("jeiko_administration_calendars:availability_list")

    permission_required = 'calendars.delete_availability'
    raise_exception = True


@method_decorator(never_cache, name='dispatch')
class AppointmentCancelView(View):
    template_name = "calendars/appointment_cancel_confirm.html"

    def get(self, request, pk):
        appt = get_object_or_404(Appointment, pk=pk)
        return render(request, self.template_name, {"appointment": appt})

    def post(self, request, pk):
        appt = get_object_or_404(Appointment, pk=pk)
        appt.cancel()  # méthode vue plus haut dans le modèle
        messages.success(request, "Votre rendez-vous a bien été annulé.")
        return render(request, "calendars/appointment_cancel_done.html")


@method_decorator(never_cache, name='dispatch')
class AppointmentUpcomingListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Appointment
    template_name = "calendars/appointment/list.html"
    context_object_name = "appointments"
    paginate_by = 50

    permission_required = 'calendars.view_appointment'
    raise_exception = True

    def get_queryset(self):
        qs = super().get_queryset().select_related("type", "slot")
        qs = qs.filter(type__user=self.request.user)
        today = timezone.localdate()
        # Inclut tous les RDV dont la date de début est >= aujourd’hui (0h00)
        return qs.filter(start__date__gte=today).order_by("start")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["now"] = timezone.now()
        ctx["today"] = timezone.localdate()
        ctx["scope"] = "upcoming"
        return ctx


@method_decorator(never_cache, name='dispatch')
class AppointmentPastListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Appointment
    template_name = "calendars/appointment/list.html"
    context_object_name = "appointments"
    paginate_by = 50

    permission_required = 'calendars.view_appointment'
    raise_exception = True

    def get_queryset(self):
        qs = super().get_queryset().select_related("type", "slot")
        qs = qs.filter(type__user=self.request.user)
        today = timezone.localdate()
        # Tous les RDV avant aujourd’hui
        return qs.filter(start__date__lt=today).order_by("-start")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["now"] = timezone.now()
        ctx["today"] = timezone.localdate()
        ctx["scope"] = "past"
        return ctx


@method_decorator(never_cache, name='dispatch')
class AppointmentDetailView(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "calendars/appointment/detail.html"

    permission_required = 'calendars.view_appointment'
    raise_exception = True

    def get(self, request, pk):
        appt = get_object_or_404(Appointment.objects.select_related("type", "slot"), pk=pk)
        return render(request, self.template_name, {"appointment": appt})


@method_decorator(never_cache, name='dispatch')
class AppointmentUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Appointment
    form_class = AppointmentFormAdmin
    template_name = "calendars/appointment/form.html"
    success_url = reverse_lazy("jeiko_administration_calendars:appointment_list")

    permission_required = 'calendars.change_appointment'
    raise_exception = True

    @transaction.atomic
    def form_valid(self, form):
        old = self.get_object()
        old_slot = old.slot

        resp = super().form_valid(form)  # self.object est mis à jour

        # Gestion de la capacité si on change de slot
        new_slot = self.object.slot
        if old_slot and new_slot and old_slot.id != new_slot.id:
            # On libère l'ancien slot
            old_slot.remaining_places += 1
            if old_slot.remaining_places > 0:
                old_slot.is_available = True
            old_slot.save(update_fields=["remaining_places", "is_available"])
            old_slot.availability.update_slots_availability()

            # On occupe le nouveau slot (si dispo)
            # (Dans un vrai flux, tu peux vérifier la dispo ici aussi)
            new_slot.remaining_places = max(0, new_slot.remaining_places - 1)
            if new_slot.remaining_places <= 0:
                new_slot.is_available = False
            new_slot.save(update_fields=["remaining_places", "is_available"])
            new_slot.availability.update_slots_availability()

        messages.success(self.request, "Rendez-vous mis à jour.")
        return resp




@method_decorator(csrf_exempt, name='dispatch')
class APIBookAppointmentView(View):
    @transaction.atomic
    def post(self, request):
        try:
            data = json.loads(request.body)
            slot_id = data.get('slot_id')
            email = data.get('email', '').strip()

            slot = Slot.objects.select_for_update().filter(
                id=slot_id,
                is_available=True,
                remaining_places__gt=0,
                start__gte=timezone.now()
            ).first()
            if not slot:
                return JsonResponse({'success': False, 'message': "Créneau non disponible ou déjà réservé."}, status=400)

            # Double check pour éviter le surbooking
            if slot.remaining_places <= 0 or not slot.is_available:
                return JsonResponse({'success': False, 'message': "Ce créneau vient d'être réservé."}, status=400)

            # Création du rendez-vous
            appt = Appointment.objects.create(
                type=slot.type,
                slot=slot,
                start=slot.start,
                end=slot.end,
                email=email,
            )

            # Mise à jour du slot
            slot.remaining_places -= 1
            if slot.remaining_places <= 0:
                slot.is_available = False
            slot.save(update_fields=["remaining_places", "is_available"])

            # (Option) envoyer email, synchroniser Google, etc.
            # === Synchronisation Google ===
            def push_to_google(appt_id):
                try:
                    # relire pour éviter les objets sales
                    a = Appointment.objects.select_related("type").get(pk=appt_id)
                    eid = upsert_event(a)
                    if eid:
                        Appointment.objects.filter(pk=appt_id).update(google_event_id=eid)
                        logger.info("Google event created for appt=%s id=%s", appt_id, eid)
                    else:
                        logger.warning("Failed to create Google event for appt=%s (eid=None)", appt_id)
                except Exception as e:
                    logger.exception("push_after_commit failed for appt=%s: %s", appt_id, e)

            # === END Google ===

            # === Envoie des mails ===
            def send_emails(appt_id):
                try:
                    a = Appointment.objects.select_related("type").get(pk=appt_id)
                    send_booking_emails(a)
                except Exception as e:
                    logger.exception("send_emails failed for appt=%s: %s", appt_id, e)

            transaction.on_commit(lambda appt_id=appt.id: push_to_google(appt_id))
            transaction.on_commit(lambda appt_id=appt.id: send_emails(appt_id))


            return JsonResponse({'success': True, 'message': "Rendez-vous réservé avec succès !"})

        except Exception as e:
            return JsonResponse({'success': False, 'message': f"Erreur serveur : {str(e)}"}, status=500)


@method_decorator(never_cache, name="dispatch")
class APIAvailabilitiesView(View):
    def get(self, request):
        appointment_type_id = request.GET.get("type")
        provider_id = request.GET.get("provider")

        slots = Slot.objects.filter(
            is_available=True,
            start__gte=timezone.now(),
            remaining_places__gt=0,
        )
        if appointment_type_id:
            slots = slots.filter(type_id=appointment_type_id)
        
        if provider_id:
            slots = slots.filter(availability__user_id=provider_id)

        data = []
        for slot in slots.order_by('start'):
            display = f"{slot.start.strftime('%A %d %B à %Hh%M')} ({int((slot.end-slot.start).total_seconds()//60)} min)"
            data.append({
                "id": slot.id,
                "availability_id": slot.availability_id,
                "start": slot.start.isoformat(),
                "end": slot.end.isoformat(),
                "display": display,
                "type": slot.type.name,
                "slot_minutes": int((slot.end-slot.start).total_seconds()//60),
                "remaining_places": slot.remaining_places,
                "type_color": slot.type.color,
            })
        return JsonResponse(data, safe=False)
