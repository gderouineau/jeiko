from django.contrib import admin

# Register your models here.

from jeiko.calendars.models import GoogleCalendarConfig, AppointmentType, Appointment, Availability, Slot

admin.site.register(GoogleCalendarConfig)
admin.site.register(AppointmentType)
admin.site.register(Appointment)
admin.site.register(Availability)
admin.site.register(Slot)
