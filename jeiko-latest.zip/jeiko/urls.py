from django.urls import path
from django.conf import settings
from django.urls import path, include
import jeiko

urlpatterns = [

    path(
        'administration/',
        include('jeiko.administration.urls')
    ),


    path(
        '',
        include('jeiko.administration_pages.urls_client'),
    ),

    path(
        'jeiko/administration/pages/',
        include('jeiko.administration_pages.urls'),
    ),
    path(
        'api/pages/',
        include('jeiko.administration_pages.urls_api'),
    ),
    path(
        'administration/menu/',
        include('jeiko.administration_menu.urls'),
    ),
    path(
        'administration/questionnaires-expert/',
        include('jeiko.questionnaires_expert.urls'),
    ),
    path(
        'administration/calendars/',
        include('jeiko.calendars.urls'),
    ),
    path(
        'api/calendars/',
        include('jeiko.calendars.urls_api'),
    ),
    path(
        'accounts/',
        include('allauth.urls'),
    ),
    path(
        'users/',
        include('jeiko.users.urls'),
    ),
    path(
        'administration/users/',
        include('jeiko.users.urls_admin'),
    ),
    path(
        'questionnaires/',
        include('jeiko.questionnaires_expert.urls_client'),
    ),



]


