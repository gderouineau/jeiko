from django.urls import path
from django.conf import settings
from django.urls import path, include
import jeiko
from jeiko.administration.views import robots_txt, sitemap_xml
from django.http import HttpResponseForbidden, HttpResponseNotFound, HttpResponseServerError
urlpatterns = [

    path("robots.txt", robots_txt, name="robots_txt"),
    path('sitemap.xml', sitemap_xml, name='sitemap_xml'),

    # ADMINISTRATION
    path(
        'administration/',
        include('jeiko.administration.urls')
    ),

    # PAGES
    path(
        'jeiko/administration/pages/',
        include('jeiko.administration_pages.urls'),
    ),
    path(
        'api/pages/',
        include('jeiko.administration_pages.urls_api'),
    ),

    # MENUS
    path(
        'administration/menu/',
        include('jeiko.administration_menu.urls'),
    ),

    # CALENDARS
    path(
        'administration/calendars/',
        include('jeiko.calendars.urls'),
    ),
    path(
        'api/calendars/',
        include('jeiko.calendars.urls_api'),
    ),

    # ACCOUNTS
    path(
        'accounts/',
        include('jeiko.users.urls.auth'),
    ),
    path(
        'accounts/',
        include('allauth.urls'),
    ),

    # USERS
    path(
        'users/',
        include('jeiko.users.urls.client'),
    ),
    path(
        'administration/users/',
        include('jeiko.users.urls.admin'),
    ),

    # QUESTIONNAIRES
    path(
        'administration/questionnaires-expert/',
        include('jeiko.questionnaires_expert.urls.admin'),
    ),
    path(
        'pass-test/',
        include('jeiko.questionnaires_expert.urls.client'),
    ),

    # COOKIES
    path(
        'administration/cookies/',
        include('jeiko.cookies.urls_admin'),
    ),
    path(
        '',
        include('jeiko.cookies.urls'),
    ),

    # CUSTOM OBJECT
    path(
        'administration/custom_objects/',
        include('jeiko.custom_objects.urls.admin'),
    ),
    path("co/", include("jeiko.custom_objects.urls.client")),

    # COURSES
    path('', include('jeiko.courses.urls')),

    # SHOP
    path(
        'administration/shop/',
        include('jeiko.shop.urls.admin')
    ),
    path(
        'administration/shop/',
        include('jeiko.shop.urls.admin_orders')
    ),
    path(
        'shop/',
        include('jeiko.shop.urls.client')
    ),

    # PAYMENTS
    path(
        'administration/payments/',
        include('jeiko.payments.urls.admin')
    ),
    path(
        'shop/',
        include('jeiko.payments.urls.client')
    ),

    # STATS
    path(
        "stats/",
        include("jeiko.stats.urls.client")
    ),
    path(
        "administration/stats/",
        include("jeiko.stats.urls.admin")
    ),

    # PAGES
    path(
        '',
        include('jeiko.administration_pages.urls_client'),
    ),


]



