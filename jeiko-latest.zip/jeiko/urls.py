from django.urls import path
from django.conf import settings
from django.urls import path, include
import jeiko
from jeiko.administration.views import robots_txt, sitemap_xml
from django.http import HttpResponseForbidden, HttpResponseNotFound, HttpResponseServerError
urlpatterns = [

    path("robots.txt", robots_txt, name="robots_txt"),
    path('sitemap.xml', sitemap_xml, name='sitemap_xml'),

    path(
        'administration/',
        include('jeiko.administration.urls')
    ),


    path(
        '',
        include('jeiko.administration_pages.urls_client'),
    ),

    path(
        'jeiko/administration/pages/',
        include('jeiko.administration_pages.urls'),
    ),
    path(
        'api/pages/',
        include('jeiko.administration_pages.urls_api'),
    ),
    path(
        'administration/menu/',
        include('jeiko.administration_menu.urls'),
    ),
    path(
        'administration/questionnaires-expert/',
        include('jeiko.questionnaires_expert.urls'),
    ),
    path(
        'administration/calendars/',
        include('jeiko.calendars.urls'),
    ),
    path(
        'api/calendars/',
        include('jeiko.calendars.urls_api'),
    ),
    path(
        'accounts/',
        include('jeiko.users.urls_allauth'),
    ),
    path(
        'accounts/',
        include('allauth.urls'),
    ),
    path(
        'users/',
        include('jeiko.users.urls'),
    ),
    path(
        'administration/users/',
        include('jeiko.users.urls_admin'),
    ),
    path(
        'questionnaires/',
        include('jeiko.questionnaires_expert.urls_client'),
    ),
    path(
        'administration/cookies/',
        include('jeiko.cookies.urls_admin'),
    ),
    path(
        '/',
        include('jeiko.cookies.urls'),
    ),



]



