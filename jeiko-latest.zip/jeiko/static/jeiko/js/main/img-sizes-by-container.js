/* img-sizes-by-container.js
   Pilotage de <img srcset> par largeur de conteneur (et non par viewport).
   Usage: <img data-sizes="container" [data-sizes-container="closest:...|<css selector>"] ... >
*/
(() => {
  const SELECTOR = 'img[data-sizes="container"]';
  const map = new Map(); // img -> { container, last }

  const rafQueue = new Set();
  const schedule = (fn) => {
    rafQueue.add(fn);
    if (schedule._req) return;
    schedule._req = requestAnimationFrame(() => {
      const q = Array.from(rafQueue);
      rafQueue.clear();
      schedule._req = null;
      q.forEach(f => { try { f(); } catch(e){} });
    });
  };

  // Mesure fiable de la largeur (css px)
  const inlineSize = (entry) => {
    if (entry && entry.contentBoxSize) {
      const b = Array.isArray(entry.contentBoxSize) ? entry.contentBoxSize[0] : entry.contentBoxSize;
      if (b && typeof b.inlineSize === 'number') return b.inlineSize;
    }
    return entry?.contentRect?.width ?? 0;
  };

  const ro = new ResizeObserver(entries => {
    for (const entry of entries) {
      const imgs = entry.target.__imgs || [];
      const w = Math.max(0, Math.floor(inlineSize(entry)));
      if (!w) continue; // ignore conteneur non visible (0px)
      for (const img of imgs) {
        const st = map.get(img);
        if (!st) continue;
        if (w === st.last) continue;
        st.last = w;
        schedule(() => {
          const val = w + 'px';
          if (img.sizes !== val) img.sizes = val; // déclenche la (ré)sélection du srcset
        });
      }
    }
  });

  function resolveContainer(img) {
    const attr = img.getAttribute('data-sizes-container');
    if (attr) {
      if (attr.startsWith('closest:')) {
        const sel = attr.slice(8);
        try { const c = img.closest(sel); if (c) return c; } catch(e){}
      } else {
        try { const c = document.querySelector(attr); if (c) return c; } catch(e){}
      }
    }
    // défaut: parent direct
    return img.parentElement || img;
  }

  function attach(img) {
    if (map.has(img)) return;
    const container = resolveContainer(img);
    if (!container) return;
    if (!container.__imgs) container.__imgs = [];
    container.__imgs.push(img);
    map.set(img, { container, last: 0 });
    ro.observe(container);

    // première mesure
    const w = Math.floor(container.getBoundingClientRect().width);
    if (w > 0) {
      const val = w + 'px';
      if (img.sizes !== val) img.sizes = val;
    }
  }

  function detach(img) {
    const st = map.get(img);
    if (!st) return;
    const arr = st.container.__imgs || [];
    st.container.__imgs = arr.filter(x => x !== img);
    if (!st.container.__imgs.length) ro.unobserve(st.container);
    map.delete(img);
  }

  function scan(root = document) {
    root.querySelectorAll(SELECTOR).forEach(attach);
  }

  // MutationObserver pour DOM dynamique (AJAX / Alpine)
  const mo = new MutationObserver(muts => {
    for (const m of muts) {
      if (m.type === 'childList') {
        m.addedNodes.forEach(node => {
          if (node.nodeType !== 1) return;
          if (node.matches?.(SELECTOR)) attach(node);
          node.querySelectorAll?.(SELECTOR).forEach(attach);
        });
        m.removedNodes.forEach(node => {
          if (node.nodeType !== 1) return;
          if (node.matches?.(SELECTOR)) detach(node);
          node.querySelectorAll?.(SELECTOR).forEach(detach);
        });
      }
    }
  });

  function init(root = document) {
    scan(root);
    mo.observe(document.documentElement, { childList: true, subtree: true });
  }

  // API publique (si tu veux rescanner un subtree ponctuellement)
  window.refreshContainerSizes = scan;

  // Hook Alpine reinit (si défini)
  if (window.reinitAlpine) {
    const prev = window.reinitAlpine;
    window.reinitAlpine = (root) => { prev(root); scan(root || document); };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => init());
  } else {
    init();
  }
})();
