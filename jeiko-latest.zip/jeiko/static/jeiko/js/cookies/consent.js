// static/jeiko_cookies/js/consent.js
(function () {
    "use strict";

    // ---- Utils cookies/CSRF ----
    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(";").shift();
        return "";
    }
    function getCSRFToken() {
        return getCookie("csrftoken") || (document.querySelector('meta[name="csrf-token"]')?.content || "");
    }

    // ---- Utils DOM ----
    const qs = (id) => document.getElementById(id);
    const show = (el, yes = true) => { if (el) el.hidden = !yes; };
    const on = (el, evt, cb, opts) => { if (el) el.addEventListener(evt, cb, opts); };

    // ---- Fetch JSON helper ----
    async function fetchJSON(url, options = {}) {
        const resp = await fetch(url, Object.assign({
            credentials: "same-origin",
            headers: { "X-Requested-With": "XMLHttpRequest", "Accept": "application/json" }
        }, options));
        if (!resp.ok) {
            const text = await resp.text().catch(() => "");
            const err = new Error(`HTTP ${resp.status}`);
            err.status = resp.status;
            err.body = text;
            throw err;
        }
        return resp.json();
    }

    // ---- Scrollbar width helper (anti-CLS à l'ouverture du modal) ----
    function getScrollbarWidth() {
        const div = document.createElement("div");
        div.style.cssText = "position:absolute; top:-9999px; width:100px; height:100px; overflow:scroll;";
        document.body.appendChild(div);
        const w = div.offsetWidth - div.clientWidth;
        document.body.removeChild(div);
        return w;
    }

    // ---- Cat rows builder ----
    function buildCategoryRow(cat, currentChecked) {
        const id = `jk-cat-${cat.key}`;
        const row = document.createElement("div");
        row.className = "jk-cookie-cat";

        const label = document.createElement("label");
        label.className = "jk-cookie-cat__label";
        label.htmlFor = id;
        label.textContent = cat.label || cat.key;

        const desc = document.createElement("div");
        desc.className = "jk-cookie-cat__desc";
        desc.textContent = cat.description || "";

        const toggle = document.createElement("input");
        toggle.type = "checkbox";
        toggle.id = id;
        toggle.name = `cat__${cat.key}`;
        toggle.checked = !!(cat.is_essential ? true : currentChecked);
        toggle.disabled = !!cat.is_essential;

        const right = document.createElement("div");
        right.className = "jk-cookie-cat__right";
        right.appendChild(toggle);

        row.appendChild(label);
        row.appendChild(desc);
        row.appendChild(right);
        return row;
    }

    function readChoicesFrom(container) {
        const inputs = container.querySelectorAll("input[type='checkbox'][name^='cat__']");
        const choices = {};
        inputs.forEach((inp) => {
            const key = inp.name.replace("cat__", "");
            choices[key] = !!inp.checked;
        });
        return choices;
    }

    const computeAcceptAll = (cats) => Object.fromEntries(cats.map(c => [c.key, true]));
    const computeRefuseAll = (cats) => Object.fromEntries(cats.map(c => [c.key, !!c.is_essential]));
    const hasOnlyEssentials = (cats) => cats.every(c => !!c.is_essential);

    // ---- Main init ----
    function init() {
        const root = qs("jk-cookie-root");
        const banner = qs("jk-cookie-banner");
        const modal = qs("jk-cookie-modal");
        const list = qs("jk-cookie-list");

        const btnAccept = qs("jk-accept-all");
        const btnRefuse = qs("jk-refuse-all");
        const btnCustomize = qs("jk-customize");
        const btnMoreInfo = qs("jk-more-info");
        const btnCloseModal = qs("jk-close-modal");
        const btnSave = qs("jk-save-choices");
        const btnAccept2 = qs("jk-accept-all-2");
        const btnRefuse2 = qs("jk-refuse-all-2");
        const msg = qs("jk-cookie-banner-message");

        if (!root || !banner || !modal || !list || !msg) return;

        // URLs depuis data-* avec fallback sur constantes
        const STATUS_URL = root.dataset.statusUrl || "/api/cookies/status";
        const CONSENT_URL = root.dataset.consentUrl || "/api/cookies/consent";
        const POLICY_URL = root.dataset.policyUrl || "/cookies/";
        const CONSENT_COOKIE_NAME = root.dataset.cookieName || "site_consent";

        const state = {
            categories: [],
            choices: {},
            banner: null,
            policy_version: "1.0",
            tracking_allowed: true,
            busy: false
        };

        // --- Modal open/close avec anti-CLS (scrollbar compensation) ---
        let savedBodyPaddingRight = "";
        let savedHtmlOverflowY = "";

        function openModal() {
            renderModalCategories();

            // Anti-CLS: garder la scrollbar
            const sw = getScrollbarWidth();
            savedBodyPaddingRight = document.body.style.paddingRight;
            savedHtmlOverflowY = document.documentElement.style.overflowY;

            if (sw > 0) {
                document.body.style.paddingRight = sw + "px";
            }
            document.documentElement.style.overflowY = "scroll";
            document.body.classList.add("jk-cookie-no-scroll");

            show(modal, true);
            modal.setAttribute("aria-hidden", "false");
        }

        function closeModal() {
            document.body.classList.remove("jk-cookie-no-scroll");
            document.body.style.paddingRight = savedBodyPaddingRight;
            document.documentElement.style.overflowY = savedHtmlOverflowY || "";

            show(modal, false);
            modal.setAttribute("aria-hidden", "true");
        }

        // --- Render catégories dans le panel ---
        function renderModalCategories() {
            list.innerHTML = "";
            state.categories.forEach(cat => {
                const row = buildCategoryRow(cat, !!state.choices[cat.key]);
                list.appendChild(row);
            });
        }

        function showBanner() {
            show(root, true);
            show(banner, true);
            document.dispatchEvent(new CustomEvent('jeiko:cookies:banner-visible'));
        }
        function hideBanner() { show(banner, false); if (modal.hidden) show(root, false); }
        function cookieExists() { return document.cookie.includes(`${CONSENT_COOKIE_NAME}=`); }

        function setBusy(yes) {
            state.busy = !!yes;
            const btns = [btnAccept, btnRefuse, btnCustomize, btnSave, btnAccept2, btnRefuse2];
            btns.forEach(b => { if (b) b.disabled = state.busy; });
        }

        function toastError(text) {
            // Minimal feedback visible
            try {
                const id = "jk-cookie-toast";
                let el = document.getElementById(id);
                if (!el) {
                    el = document.createElement("div");
                    el.id = id;
                    el.style.cssText = "position:fixed;left:50%;bottom:90px;transform:translateX(-50%);background:#fee2e2;color:#991b1b;border:1px solid #fecaca;padding:8px 12px;border-radius:8px;font-size:13px;z-index:10000;";
                    document.body.appendChild(el);
                }
                el.textContent = text || "Erreur de sauvegarde des préférences.";
                el.hidden = false;
                setTimeout(() => { el.hidden = true; }, 3000);
            } catch (e) {
                // noop
            }
        }

        async function persist(choices, source) {
            if (state.busy) return;
            setBusy(true);

            const csrf = getCSRFToken();
            console.debug('[consent] csrf =', csrf);
            try {
                const data = await fetchJSON(CONSENT_URL, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRFToken": csrf,
                        "X-Requested-With": "XMLHttpRequest",
                        "Accept": "application/json"
                    },
                    body: JSON.stringify({ choices, source })
                });

                // On considère que l’API renvoie {choices, policy_version, ts, ...}
                state.choices = data.choices || state.choices;
                state.policy_version = data.policy_version || state.policy_version;

                // Dispatch global event
                document.dispatchEvent(new CustomEvent("jeiko:cookies:consent-updated", {
                    detail: { policy_version: state.policy_version, choices: state.choices, ts: data.ts }
                }));

                hideBanner();
                closeModal();
            } catch (err) {
                // Feedback visible + console
                console.error("Consent save failed:", err);
                if (err && err.status === 403) {
                    toastError("Accès refusé (CSRF). Rechargez la page.");
                } else {
                    toastError("Impossible d’enregistrer vos préférences.");
                }
            } finally {
                setBusy(false);
            }
        }

        function updateBannerTexts() {
            if (!state.banner) return;
            if (msg) msg.textContent = state.banner.message_text || "Nous utilisons des cookies essentiels au fonctionnement du site.";
            if (btnAccept) btnAccept.textContent = state.banner.accept_all_label || "Tout accepter";
            if (btnRefuse) btnRefuse.textContent = state.banner.refuse_all_label || "Tout refuser";
            if (btnCustomize) btnCustomize.textContent = state.banner.customize_label || "Personnaliser";
            if (btnSave) btnSave.textContent = state.banner.save_choices_label || "Enregistrer";
            if (btnAccept2) btnAccept2.textContent = state.banner.accept_all_label || "Tout accepter";
            if (btnRefuse2) btnRefuse2.textContent = state.banner.refuse_all_label || "Tout refuser";

            if (btnMoreInfo) {
                const href = state.banner.more_info_url || POLICY_URL || "#";
                btnMoreInfo.href = href;
                btnMoreInfo.textContent = state.banner.more_info_label || "En savoir plus";
                show(btnMoreInfo, !!href && href !== "#");
            }

            // Cacher “Tout refuser” si seulement des essentiels
            const onlyEssentials = hasOnlyEssentials(state.categories);
            if (onlyEssentials) {
                show(btnRefuse, false);
                show(btnRefuse2, false);
                show(btnCustomize, false);
            }
        }

        // --- Boot (status initial) ---
        async function boot() {
            try {
                const data = await fetchJSON(STATUS_URL);
                state.categories = data.categories || [];
                state.choices = data.choices || {};
                state.banner = data.banner || null;
                state.policy_version = data.policy_version || "1.0";
                state.tracking_allowed = !!data.tracking_allowed;

                updateBannerTexts();

                if (!cookieExists()) {
                    showBanner();
                } else {
                    hideBanner();
                }
            } catch (e) {
                // En cas d’échec, on ne bloque pas la navigation
                console.error("Cookie consent init error:", e);
                hideBanner();
            }
        }

        // --- Bindings ---
        on(btnAccept, "click", (e) => { e.preventDefault(); persist(computeAcceptAll(state.categories), "banner"); });
        on(btnRefuse, "click", (e) => { e.preventDefault(); persist(computeRefuseAll(state.categories), "banner"); });
        on(btnCustomize, "click", (e) => { e.preventDefault(); openModal(); });

        on(btnCloseModal, "click", (e) => { e.preventDefault(); closeModal(); });
        on(btnSave, "click", (e) => { e.preventDefault(); persist(readChoicesFrom(list), "panel"); });
        on(btnAccept2, "click", (e) => { e.preventDefault(); persist(computeAcceptAll(state.categories), "panel"); });
        on(btnRefuse2, "click", (e) => { e.preventDefault(); persist(computeRefuseAll(state.categories), "panel"); });

        // Boutons externes optionnels
        document.addEventListener("click", function (e) {
            const opener = e.target.closest?.("[data-open-cookies]");
            if (opener) { e.preventDefault(); show(root, true); openModal(); }

            const resetter = e.target.closest?.("[data-reset-cookies]");
            if (resetter) {
                e.preventDefault();
                document.cookie = (root.dataset.cookieName || "site_consent") + "=; Max-Age=0; path=/";
                show(root, true);
                show(banner, true);
            }
        }, { passive: false });

        // Lien “En savoir plus” par défaut si non rempli
        if (btnMoreInfo && !btnMoreInfo.getAttribute("href")) btnMoreInfo.href = POLICY_URL;

        // Démarrage (léger), puis charge lourd en idle si besoin
        boot();
        (window.requestIdleCallback || window.setTimeout)(function () {
            // Place pour des opérations non-critiques (e.g. traductions supplémentaires)
        }, 0);

        // Helpers globaux
        window.jeikoOpenCookiePanel = function () { show(root, true); openModal(); };
        window.jeikoOpenCookieBanner = function () { show(root, true); show(banner, true); };
        window.jeikoResetConsent = function () {
            document.cookie = (root.dataset.cookieName || "site_consent") + "=; Max-Age=0; path=/";
            show(root, true); show(banner, true);
        };
        window.jeikoGetConsentStatus = async function () {
            try { return await fetchJSON(STATUS_URL); } catch { return null; }
        };
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
