// static/jeiko_cookies/js/consent.js
(function () {
    "use strict";

    // ---- CONSTANTES (same-origin, fixes) ----
    const STATUS_URL  = "/api/cookies/status";
    const CONSENT_URL = "/api/cookies/consent";
    const POLICY_URL  = "/cookies/";
    const CONSENT_COOKIE_NAME = "site_consent";

    // ---- Utils courts ----
    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(";").shift();
    }
    function getCSRFToken() {
        return getCookie("csrftoken") || (document.querySelector('meta[name="csrf-token"]')?.content || "");
    }
    const qs = (id) => document.getElementById(id);
    const show = (el, yes = true) => { if (el) el.hidden = !yes; };
    const on = (el, evt, cb) => { if (el) el.addEventListener(evt, cb); };
    async function fetchJSON(url, options = {}) {
        const resp = await fetch(url, Object.assign({
            credentials: "same-origin",
            headers: { "X-Requested-With": "XMLHttpRequest" }
        }, options));
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        return resp.json();
    }
    function dispatchConsentEvent(detail) {
        document.dispatchEvent(new CustomEvent("jeiko:cookies:consent-updated", { detail }));
    }

    function buildCategoryRow(cat, currentChecked) {
        const id = `jk-cat-${cat.key}`;
        const row = document.createElement("div");
        row.className = "jk-cookie-cat";

        const label = document.createElement("label");
        label.className = "jk-cookie-cat__label";
        label.htmlFor = id;
        label.textContent = cat.label || cat.key;

        const desc = document.createElement("div");
        desc.className = "jk-cookie-cat__desc";
        desc.textContent = cat.description || "";

        const toggle = document.createElement("input");
        toggle.type = "checkbox";
        toggle.id = id;
        toggle.name = `cat__${cat.key}`;
        toggle.checked = !!(cat.is_essential ? true : currentChecked);
        toggle.disabled = !!cat.is_essential;

        const right = document.createElement("div");
        right.className = "jk-cookie-cat__right";
        right.appendChild(toggle);

        row.appendChild(label);
        row.appendChild(desc);
        row.appendChild(right);
        return row;
    }

    function readChoicesFrom(container) {
        const inputs = container.querySelectorAll("input[type='checkbox'][name^='cat__']");
        const choices = {};
        inputs.forEach((inp) => {
            const key = inp.name.replace("cat__", "");
            choices[key] = !!inp.checked;
        });
        return choices;
    }

    const computeAcceptAll = (cats) => Object.fromEntries(cats.map(c => [c.key, true]));
    const computeRefuseAll = (cats) => Object.fromEntries(cats.map(c => [c.key, !!c.is_essential]));
    const hasOnlyEssentials = (cats) => cats.every(c => !!c.is_essential);

    function init() {
        const root   = qs("jk-cookie-root");
        const banner = qs("jk-cookie-banner");
        const modal  = qs("jk-cookie-modal");
        const list   = qs("jk-cookie-list");

        const btnAccept = qs("jk-accept-all");
        const btnRefuse = qs("jk-refuse-all");
        const btnCustomize = qs("jk-customize");
        const btnMoreInfo  = qs("jk-more-info");
        const btnCloseModal = qs("jk-close-modal");
        const btnSave = qs("jk-save-choices");
        const btnAccept2 = qs("jk-accept-all-2");
        const btnRefuse2 = qs("jk-refuse-all-2");
        const msg = qs("jk-cookie-banner-message");

        if (!root || !banner || !modal || !list || !msg) return;

        const state = {
            categories: [],
            choices: {},
            banner: null,
            policy_version: "1.0",
            tracking_allowed: true,
        };

        function renderModalCategories() {
            list.innerHTML = "";
            state.categories.forEach(cat => {
                const row = buildCategoryRow(cat, !!state.choices[cat.key]);
                list.appendChild(row);
            });
        }
        function openModal() {
            renderModalCategories();
            show(modal, true);
            modal.setAttribute("aria-hidden", "false");
            document.body.classList.add("jk-cookie-no-scroll");
        }
        function closeModal() {
            show(modal, false);
            modal.setAttribute("aria-hidden", "true");
            document.body.classList.remove("jk-cookie-no-scroll");
        }
        function showBanner() { show(root, true); show(banner, true); }
        function hideBanner() { show(banner, false); if (modal.hidden) show(root, false); }
        function cookieExists() { return document.cookie.includes(`${CONSENT_COOKIE_NAME}=`); }

        async function persist(choices, source) {
            const csrf = getCSRFToken();
            try {
                const resp = await fetch(CONSENT_URL, {
                    method: "POST",
                    credentials: "same-origin",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRFToken": csrf,
                        "X-Requested-With": "XMLHttpRequest",
                    },
                    body: JSON.stringify({ choices, source })
                });
                if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
                const data = await resp.json();
                state.choices = data.choices || state.choices;
                dispatchConsentEvent({ policy_version: data.policy_version, choices: data.choices, ts: data.ts });
                hideBanner();
                closeModal();
            } catch (err) {
                console.error("Consent save failed:", err);
            }
        }

        function updateBannerTexts() {
            if (!state.banner) return;
            msg.textContent = state.banner.message_text || "Nous utilisons des cookies essentiels au fonctionnement du site.";
            if (btnAccept)   btnAccept.textContent   = state.banner.accept_all_label || "Tout accepter";
            if (btnRefuse)   btnRefuse.textContent   = state.banner.refuse_all_label || "Tout refuser";
            if (btnCustomize)btnCustomize.textContent= state.banner.customize_label || "Personnaliser";
            if (btnSave)     btnSave.textContent     = state.banner.save_choices_label || "Enregistrer";
            if (btnAccept2)  btnAccept2.textContent  = state.banner.accept_all_label || "Tout accepter";
            if (btnRefuse2)  btnRefuse2.textContent  = state.banner.refuse_all_label || "Tout refuser";

            if (btnMoreInfo) {
                const hasUrl = !!(state.banner.more_info_url || POLICY_URL);
                btnMoreInfo.href = state.banner.more_info_url || POLICY_URL;
                btnMoreInfo.textContent = state.banner.more_info_label || "En savoir plus";
                show(btnMoreInfo, hasUrl);
            }
            show(btnRefuse, !!state.banner.show_refuse_all);
            show(btnRefuse2, !!state.banner.show_refuse_all);
        }

        async function boot() {
            try {
                const data = await fetchJSON(STATUS_URL);
                state.categories = data.categories || [];
                state.choices = data.choices || {};
                state.banner = data.banner || null;
                state.policy_version = data.policy_version || "1.0";
                state.tracking_allowed = !!data.tracking_allowed;

                updateBannerTexts();

                const onlyEssentials = hasOnlyEssentials(state.categories);
                if (!cookieExists()) {
                    if (onlyEssentials) { show(btnRefuse, false); show(btnCustomize, false); }
                    showBanner();
                } else {
                    hideBanner();
                }
            } catch (e) {
                hideBanner();
                console.error("Cookie consent init error:", e);
            }
        }

        // --- Bindings simples ---
        on(btnAccept,   () => persist(computeAcceptAll(state.categories), "banner"));
        on(btnRefuse,   () => persist(computeRefuseAll(state.categories), "banner"));
        on(btnCustomize, openModal);
        on(btnCloseModal, closeModal);

        on(btnSave,   () => persist(readChoicesFrom(list), "panel"));
        on(btnAccept2,() => persist(computeAcceptAll(state.categories), "panel"));
        on(btnRefuse2,() => persist(computeRefuseAll(state.categories), "panel"));

        // data-attrs (au cas où tu veux un bouton externe)
        document.addEventListener("click", function (e) {
            const opener = e.target.closest("[data-open-cookies]");
            if (opener) { e.preventDefault(); show(root, true); openModal(); }
            const resetter = e.target.closest("[data-reset-cookies]");
            if (resetter) { e.preventDefault(); document.cookie = CONSENT_COOKIE_NAME + "=; Max-Age=0; path=/"; show(root, true); show(banner, true); }
        });

        // Lien En savoir plus par défaut
        if (btnMoreInfo && !btnMoreInfo.href) btnMoreInfo.href = POLICY_URL;

        // Démarrage
        boot();

        // Helpers globaux ultra-simples
        window.jeikoOpenCookiePanel = function () { show(root, true); openModal(); };
        window.jeikoOpenCookieBanner = function () { show(root, true); show(banner, true); };
        window.jeikoResetConsent = function () { document.cookie = CONSENT_COOKIE_NAME + "=; Max-Age=0; path=/"; show(root, true); show(banner, true); };
        window.jeikoGetConsentStatus = async function () {
            try { return await fetchJSON(STATUS_URL); } catch { return null; }
        };
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
})();
