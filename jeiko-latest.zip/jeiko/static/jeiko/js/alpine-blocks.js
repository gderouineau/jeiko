// static/js/alpine-blocks.js
(function () {
  'use strict';

  const parseProps = (raw, defaults = {}) => {
    try {
      return Object.assign({}, defaults, typeof raw === 'string' ? JSON.parse(raw) : (raw || {}));
    } catch {
      return Object.assign({}, defaults);
    }
  };
  const onDestroy = (el, cb) => el.addEventListener('alpine:destroy', cb, { once: true });
  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
  const pad2 = (n) => String(Number(n) || 0).padStart(2, '0');

  // helpers
  const num = (v, fb = null) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : fb;
  };
  const byOrder = (a, b) => (num(a?.order, 999) - num(b?.order, 999));

  // responsive images helpers (utilisés par galerie/carousel si besoin)
  function bestSrc(img) {
  if (!img) return '';
      // Fallback "intelligent": viser medium/haut d'abord pour éviter le flou
      return img.laptop || img.computer || img.full || img.tablet || img.mobile || img.src || '';
    }
  function srcset(img) {
      if (!img) return '';
      const p = [];
      // Paliers officiels: 767 / 991 / 1200 / 1500 / 1920
      if (img.mobile)   p.push(`${img.mobile} 767w`);
      if (img.tablet)   p.push(`${img.tablet} 991w`);
      if (img.laptop)   p.push(`${img.laptop} 1200w`);
      if (img.computer) p.push(`${img.computer} 1500w`);
      if (img.full)     p.push(`${img.full} 1920w`);
      return p.join(', ');
    }
  // ISO-ish parser: accepte "YYYY-MM-DD HH:MM"
  function parseDateLike(v) {
    if (!v) return null;
    const s = String(v).trim();
    let d = new Date(s);
    if (!isNaN(d)) return d;
    d = new Date(s.replace(' ', 'T'));
    return isNaN(d) ? null : d;
  }

  // ========= FACTORIES =========
  function faqFactory(raw) {
    const { items = [], multiple = false, firstOpen = null, title_tag = 'h4' } = parseProps(raw, {});
    const safeTag = (t => (['h1','h2','h3','h4','h5','h6'].includes((t||'').toLowerCase()) ? t.toLowerCase() : 'h4'))(title_tag);
    items.sort(byOrder);
    return {
      items,
      multiple,
      title_tag: safeTag,
      init() {
        if (firstOpen != null && this.items[firstOpen]) this.items[firstOpen].open = true;
      },
      toggle(i) {
        if (!this.items || i < 0 || i >= this.items.length) return;
        if (!this.multiple) this.items.forEach((it, idx) => idx !== i && (it.open = false));
        this.items[i].open = !this.items[i].open;
      }
    };
  }

  function tabsFactory(raw) {
    const o = parseProps(raw, {});
    const tabs = Array.isArray(o.tabs) ? o.tabs : (Array.isArray(o.items) ? o.items : []);
    tabs.sort(byOrder);
    const last = Math.max(0, tabs.length - 1);
    return {
      tabs,
      active: clamp(num(o.active, 0), 0, last),
      select(i) { if (i >= 0 && i < this.tabs.length) this.active = i; },
      onKeydown(e) {
        if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return;
        e.preventDefault();
        const last = this.tabs.length - 1;
        if (e.key === 'ArrowRight') this.active = this.active >= last ? 0 : this.active + 1;
        if (e.key === 'ArrowLeft')  this.active = this.active <= 0    ? last : this.active - 1;
        if (e.key === 'Home') this.active = 0;
        if (e.key === 'End')  this.active = last;
      }
    };
  }

  function carouselFactory(raw) {
  const o = parseProps(raw, {});
  const slides = Array.isArray(o.slides) ? o.slides : (Array.isArray(o.items) ? o.items : []);
  slides.sort(byOrder);
  const autoplay = typeof o.autoplay === 'boolean' ? o.autoplay : true;
  const interval = num(o.interval, 5000);

  return {
    slides,
    current: 0,
    autoplay,
    interval,
    t: null,
    hovering: false,
    visible: true,
    _onEnter: null,
    _onLeave: null,
    _onVis: null,

    init() {
      // Si utilisé dans un .column-item avec data-mode ≠ auto, on active un mode 'fill'
      try {
        const ci = this.$el.closest('.column-item');
        const mode = ci ? (ci.getAttribute('data-mode') || 'auto') : 'auto';
        if (mode !== 'auto') this.$el.classList.add('car-fill'); // la CSS locale du composant prend le relai (height:100%)
      } catch {}

      if (this.autoplay && this.slides.length > 1) this.start();

      // handlers nommés pour pouvoir les retirer proprement
      this._onEnter = () => { this.hovering = true;  this._sync(); };
      this._onLeave = () => { this.hovering = false; this._sync(); };
      this._onVis   = () => { this.visible  = !document.hidden; this._sync(); };

      this.$el.addEventListener('mouseenter', this._onEnter);
      this.$el.addEventListener('mouseleave', this._onLeave);
      document.addEventListener('visibilitychange', this._onVis);

      onDestroy(this.$el, () => {
        this.stop();
        document.removeEventListener('visibilitychange', this._onVis);
        this.$el.removeEventListener('mouseenter', this._onEnter);
        this.$el.removeEventListener('mouseleave', this._onLeave);
        this._onEnter = this._onLeave = this._onVis = null;
      });
    },
    _arm() {
      this.stop();
      if (!this.autoplay || this.hovering || !this.visible || this.slides.length < 2) return;
      this.t = setInterval(() => this.next(), this.interval);
    },
    _sync() { this._arm(); },
    start() { this.autoplay = true; this._arm(); },
    stop()  { if (this.t) { clearInterval(this.t); this.t = null; } },
    toggle(){ this.autoplay ? this.stop() : this.start(); },

    next() {
      if (!this.slides.length) return;
      this.current = (this.current + 1) % this.slides.length;
      this._arm();
    },
    prev() {
      if (!this.slides.length) return;
      this.current = (this.current - 1 + this.slides.length) % this.slides.length;
      this._arm();
    },
    go(i)   { if (i >= 0 && i < this.slides.length) { this.current = i; this._arm(); } },

    currentSlide() { return this.slides[this.current] || null; },

    // helpers image si utilisés par le template
    bestSrc: (img) => bestSrc(img),
    srcset:  (img) => srcset(img),
  };
}



  function progressFactory(raw) {
    const { progress = null, steps = [] } = parseProps(raw, {});
    steps.sort(byOrder);
    let p = progress;
    if (p == null && steps.length) {
      const done = steps.filter(s => !!s.done).length;
      p = done / steps.length;
    }
    return { progress: clamp(p ?? 0, 0, 1), steps };
  }

  function testimonialsFactory(raw) {
    const { autoplay = true, interval = 7000 } = parseProps(raw, {});
    // support items/testimonials/testimonial_items + fallback text/content -> quote
    let items = [];
    const r = parseProps(raw, {});
    if (Array.isArray(r.items)) items = r.items;
    else if (Array.isArray(r.testimonials)) items = r.testimonials;
    else if (Array.isArray(r.testimonial_items)) items = r.testimonial_items;
    items = items.map(it => {
      if (it && !it.quote) it.quote = it.text || it.content || '';
      return it || {};
    });
    items.sort(byOrder);

    return {
      items,
      current: 0,
      autoplay,
      interval,
      t: null,
      init() {
        if (this.autoplay && this.items.length > 1) this.start();
        onDestroy(this.$el, () => this.stop());
      },
      start() { this.stop(); this.t = setInterval(() => this.next(), this.interval); },
      stop()  { if (this.t) { clearInterval(this.t); this.t = null; } },
      pause() { this.stop(); },
      resume(){ if (this.autoplay && this.items.length > 1) this.start(); },
      next()  { if (!this.items.length) return; this.current = (this.current + 1) % this.items.length; },
      prev()  { if (!this.items.length) return; this.current = (this.current - 1 + this.items.length) % this.items.length; },
      go(i)   { if (i >= 0 && i < this.items.length) this.current = i; }
    };
  }

  function testimonialsGridFactory(raw) {
    const { perRow = 3, rotate = true, interval = 6000 } = parseProps(raw, {});
    let items = parseProps(raw, {}).items || [];
    items = items.map(it => {
      if (it && !it.quote) it.quote = it.text || it.content || '';
      return it || {};
    });
    items.sort(byOrder);
    return {
      items,
      perRow: Math.max(1, perRow),
      start: 0,
      rotate,
      interval,
      t: null,
      get visible() {
        if (this.items.length <= this.perRow) return this.items;
        const end = this.start + this.perRow;
        return end <= this.items.length
          ? this.items.slice(this.start, end)
          : [...this.items.slice(this.start), ...this.items.slice(0, end - this.items.length)];
      },
      init() {
        if (this.rotate && this.items.length > this.perRow)
          this.t = setInterval(() => this.next(), this.interval);
        onDestroy(this.$el, () => this.t && clearInterval(this.t));
      },
      next() { if (!this.items.length) return; this.start = (this.start + this.perRow) % this.items.length; },
      prev() { if (!this.items.length) return; this.start = (this.start - this.perRow + this.items.length) % this.items.length; }
    };
  }

  function pricingFactory(raw) {
    const o = parseProps(raw, {});
    const plans = Array.isArray(o.plans) ? o.plans
                : Array.isArray(o.items) ? o.items
                : Array.isArray(o.pricing_plans) ? o.pricing_plans : [];
    plans.sort(byOrder);
    const yearly   = !!o.yearly;
    const currency = o.currency || '€';
    const locale   = o.locale   || 'fr-FR';

    function priceFor(p, isYearly) {
      if (!p) return null;
      let raw = null;
      if (isYearly) {
        raw = p.price_yearly ?? p.priceYearly ?? (typeof p.price === 'object' ? p.price?.yearly : undefined) ?? (typeof p.prices === 'object' ? p.prices?.yearly : undefined);
      } else {
        raw = p.price_monthly ?? p.priceMonthly ?? (typeof p.price === 'object' ? p.price?.monthly : undefined) ?? (typeof p.prices === 'object' ? p.prices?.monthly : undefined);
      }
      if (raw == null && typeof p.price !== 'object') raw = p.price ?? null;
      const n = Number(raw);
      return Number.isFinite(n) ? n : (raw ?? null);
    }

    function formatted(n) {
      if (n === null || n === '') return '';
      if (typeof n === 'string') return n;
      try { return currency + ' ' + new Intl.NumberFormat(locale, { maximumFractionDigits: 2 }).format(n); }
      catch { return currency + ' ' + n; }
    }

    return {
      plans,
      yearly,
      currency,
      locale,
      toggle() { this.yearly = !this.yearly; },
      price(p) { return priceFor(p, this.yearly); },
      formattedPrice(p) { return formatted(this.price(p)); }
    };
  }

  function liveFilterFactory(raw) {
    const { items = [], keys = ['title', 'category'] } = parseProps(raw, {});
    return {
      items, keys, q: '',
      filtered() {
        const q = this.q.trim().toLowerCase();
        if (!q) return this.items;
        return this.items.filter(it => this.keys.some(k => (it?.[k] || '').toString().toLowerCase().includes(q)));
      }
    };
  }

  function countdownFactory(raw) {
    const o = parseProps(raw, {});
    const d = parseDateLike(o.deadline || o.deadlineISO);
    let timer = null;
    return {
      deadline: d,
      deadlineISO: d ? d.toISOString() : '',
      expired: false,
      dd: '00', hh: '00', mm: '00', ss: '00',
      ctaText: o.ctaText ?? null,
      ctaHref: o.ctaHref ?? null,

      init() {
        const tick = () => {
          if (!this.deadline) { this.expired = true; this.dd = this.hh = this.mm = this.ss = '00'; return; }
          const diffMs = this.deadline - new Date();
          if (diffMs <= 0) {
            this.expired = true; this.dd = this.hh = this.mm = this.ss = '00';
            if (timer) clearInterval(timer);
            return;
          }
          let s = Math.floor(diffMs / 1000);
          const d = Math.floor(s / 86400); s -= d * 86400;
          const h = Math.floor(s / 3600);  s -= h * 3600;
          const m = Math.floor(s / 60);    s -= m * 60;
          this.dd = pad2(d); this.hh = pad2(h); this.mm = pad2(m); this.ss = pad2(s);
          this.expired = false;
        };
        tick();
        timer = setInterval(tick, 1000);
        onDestroy(this.$el, () => timer && clearInterval(timer));
      }
    };
  }

  function galleryFilterFactory(raw) {
    const o = parseProps(raw, {});
    const items = Array.isArray(o.items) ? [...o.items] : [];
    items.sort(byOrder);
    const providedCats = Array.isArray(o.categories) ? o.categories : [];
    const autoCats = ['all', ...Array.from(new Set(items.map(i => (i?.category || '').trim()).filter(Boolean)))];
    const categories = providedCats.length ? providedCats : autoCats;
    const realCats = categories.filter(c => c.toLowerCase() !== 'all');

    return {
      items,
      categories,
      realCats,
      active: 'all',
      set(cat) { this.active = cat; },
      filtered() {
        if (this.active === 'all') return this.items;
        const a = (this.active || '').toLowerCase();
        return this.items.filter(it => (it?.category || '').toLowerCase() === a);
      },
      bestSrc: (img) => bestSrc(img),
      srcset:  (img) => srcset(img),
    };
  }

  function accordionAdvFactory(raw) {
    const o = parseProps(raw, {});
    // support sections/items
    const sections = Array.isArray(o.sections) ? o.sections : (Array.isArray(o.items) ? o.items : []);
    sections.sort(byOrder);
    // normaliser enfants par "children"
    sections.forEach(s => {
      if (Array.isArray(s.children)) return;
      if (Array.isArray(s.items)) s.children = s.items;
      else if (!s.children) s.children = [];
    });
    return {
      sections,
      multiple: o.multiple ?? true,
      toggle(i) {
        if (!this.sections || i < 0 || i >= this.sections.length) return;
        if (!this.multiple) this.sections.forEach((s, idx) => idx !== i && (s.open = false));
        this.sections[i].open = !this.sections[i].open;
      },
      toggleChild(i, j) {
        const s = this.sections[i];
        if (!s || !Array.isArray(s.children) || j < 0 || j >= s.children.length) return;
        s.children[j].open = !s.children[j].open;
      }
    };
  }

  function stepperFactory(raw) {
    const o = parseProps(raw, {});
    const steps = Array.isArray(o.steps) ? [...o.steps] : [];
    steps.sort(byOrder);
    return {
      steps,
      current: clamp(num(o.start, 0), 0, Math.max(steps.length - 1, 0)),
      next() { if (this.current < this.steps.length - 1) this.current++; },
      prev() { if (this.current > 0) this.current--; },
      go(i)  { this.current = clamp(i, 0, Math.max(this.steps.length - 1, 0)); },
      progress() { return this.steps.length ? (this.current + 1) / this.steps.length : 0; }
    };
  }

  function ratingFactory(raw) {
    const { rating = 0, count = 0, max = 5, editable = false } = parseProps(raw, {});
    return {
      rating: Number(rating),
      count:  Number(count),
      max: Math.max(1, Number(max)),
      editable: !!editable,
      hover: 0,
      set(i)  { if (this.editable) this.rating = i; },
      over(i) { if (this.editable) this.hover = i; },
      out()   { if (this.editable) this.hover = 0; },
      filled(i) {
        return this.editable && this.hover
          ? i <= this.hover
          : i <= Math.round(this.rating);
      }
    };
  }

  // === EXPORT GLOBALS (sécurité si utilisé avant Alpine) ===
  if (!window.faqBlock) window.faqBlock = faqFactory;
  if (!window.tabsBlock) window.tabsBlock = tabsFactory;
  if (!window.carouselBlock) window.carouselBlock = carouselFactory;
  if (!window.progressBlock) window.progressBlock = progressFactory;
  if (!window.testimonialsBlock) window.testimonialsBlock = testimonialsFactory;
  if (!window.liveFilterBlock) window.liveFilterBlock = liveFilterFactory;
  if (!window.countdownBlock) window.countdownBlock = countdownFactory;
  if (!window.accordionAdvancedBlock) window.accordionAdvancedBlock = accordionAdvFactory;
  if (!window.pricingTableBlock) window.pricingTableBlock = pricingFactory;
  if (!window.testimonialsGridBlock) window.testimonialsGridBlock = testimonialsGridFactory;
  if (!window.galleryFilterBlock) window.galleryFilterBlock = galleryFilterFactory;
  if (!window.stepperBlock) window.stepperBlock = stepperFactory;
  if (!window.ratingBlock) window.ratingBlock = ratingFactory;

  // re-init Alpine pour DOM remplacé (AJAX)
  if (!window.reinitAlpine) {
    window.reinitAlpine = (root) => {
      if (window.Alpine && typeof window.Alpine.initTree === 'function') {
        window.Alpine.initTree(root || document);
      }
    };
  }

  // === ENREGISTREMENT ALPINE ===
  document.addEventListener('alpine:init', () => {
    Alpine.data('faqBlock', faqFactory);
    Alpine.data('tabsBlock', tabsFactory);
    Alpine.data('carouselBlock', carouselFactory);
    Alpine.data('progressBlock', progressFactory);
    Alpine.data('testimonialsBlock', testimonialsFactory);
    Alpine.data('liveFilterBlock', liveFilterFactory);
    Alpine.data('countdownBlock', countdownFactory);
    Alpine.data('accordionAdvancedBlock', accordionAdvFactory);
    Alpine.data('pricingTableBlock', pricingFactory);
    Alpine.data('testimonialsGridBlock', testimonialsGridFactory);
    Alpine.data('galleryFilterBlock', galleryFilterFactory);
    Alpine.data('stepperBlock', stepperFactory);
    Alpine.data('ratingBlock', ratingFactory);
  });
})();
