import {
    getCookie,
    fetchHtml,
    showModal,
    showToast,
    showConfirmModal,
    closeModal
} from './utils.js';

const csrftoken = getCookie('csrftoken');

/* =========================
 *  Unification re-init UI
 * ========================= */
function reinitAlpine(root = document) {
  try {
    if (window.Alpine && typeof Alpine.initTree === 'function') {
      Alpine.initTree(root);
    }
  } catch (e) {
    console.warn('[reinitAlpine] Alpine.initTree a échoué:', e);
  }
}

function attachAjaxFormHandler(formId, updateDOMCallback, successMsg = "Opération réussie") {
  const form = document.getElementById(formId);
  if (!form || form._handlerAttached) return;

  form._handlerAttached = true;
  form.addEventListener('submit', async e => {
    e.preventDefault();


    const formData = new FormData(form);
    const url      = form.action || form.dataset.url;

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'X-CSRFToken': csrftoken,
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: formData,
    });

    let data, isJson = false;
    try {
      data = await res.clone().json();
      isJson = true;
    } catch {
      data = await res.text();
    }

    if (res.ok && isJson && (data.status === 'success' || data.status === 'ok')) {
      closeModal();
      // Laisse le callback faire le remplacement DOM ciblé
      updateDOMCallback(data);
      // Re-init UI (global au doc, ou mieux: sur la cible remplacée par le callback)
      reinitUI(document);
      showToast(successMsg);

    } else if (!isJson) {
      // Ré-injection du formulaire (avec erreurs) dans le modal
      const container = document.querySelector('.modal-body') || document.querySelector('.modal-content');
      if (container) container.innerHTML = data;
      // Re-attacher le handler et re-init le sous-arbre du modal
      setTimeout(() => {
        attachAjaxFormHandler(formId, updateDOMCallback, successMsg);
        reinitUI(container || document);
      }, 0);

    } else {
      showToast(data.message || 'Erreur serveur');
    }
  });
}

export function initOverlayHandlers(root = document) {
    const scope = root instanceof Element ? root : document;

    scope.querySelectorAll('.section').forEach(section => {
        // On ajoute les listeners de section une seule fois
        if (section.dataset.overlayBound !== '1') {
            section.dataset.overlayBound = '1';

            const overlaySection = section.querySelector('.overlay-section');
            const toggleOverlay = (overlay, show) => {
                if (!overlay) return;
                overlay.classList.toggle('visible', !!show);
            };

            section.addEventListener('mouseenter', () => toggleOverlay(overlaySection, true));
            section.addEventListener('mouseleave', () => toggleOverlay(overlaySection, false));
        }

        // ⚠️ Toujours (re)traite les colonnes, même si la section est déjà “bound”
        const overlaySection = section.querySelector('.overlay-section');
        section.querySelectorAll('.line .column').forEach(col => {
            if (col.dataset.overlayBound === '1') return;
            col.dataset.overlayBound = '1';

            const overlayCol = col.querySelector('.overlay-column');
            col.addEventListener('mouseenter', () => {
                if (overlayCol) overlayCol.classList.add('visible');
                if (overlaySection) overlaySection.classList.remove('visible');
            });
            col.addEventListener('mouseleave', () => {
                if (overlayCol) overlayCol.classList.remove('visible');
                // si la souris est encore sur la section, on ré-affiche l’overlay de section
                if (overlaySection && section.matches(':hover')) {
                    overlaySection.classList.add('visible');
                }
            });
        });
    });
}

function refreshOverlays(root = document) {
  initOverlayHandlers(root);
}

/** Re-init global unique, sur un sous-arbre si possible */
export function reinitUI(root = document) {
  // Alpine (composants dynamiques front)
  reinitAlpine(root);

  // Overlays (UI d’édition)
  refreshOverlays(root);

  // Images responsives pilotées par conteneur (si présent)
  try {
    if (window.ResponsiveImg && typeof window.ResponsiveImg.refresh === 'function') {
      window.ResponsiveImg.refresh(root);
    }
  } catch (e) {
    console.warn('[reinitUI] ResponsiveImg.refresh a échoué:', e);
  }

  // Préviews Countdown (countdown & countdown CTA) côté formulaires
  try {
    if (window.Formsets && Formsets.Countdown) {
      Formsets.Countdown.boot(root);
    }
  } catch (e) {
    console.warn('[reinitUI] Countdown.boot a échoué:', e);
  }
  return root;
}


// === Helpers QUILL (ajout de pickers natifs + utilitaires) ====================

// === Helpers QUILL (color utils + pickers natifs) ============================

// rgb/rgba/#abc → #rrggbb
function toHex(color, current = '#000000') {
  if (!color) return current;
  if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(color)) {
    if (color.length === 4) {
      return (
        '#' +
        color[1] + color[1] +
        color[2] + color[2] +
        color[3] + color[3]
      ).toLowerCase();
    }
    return color.toLowerCase();
  }
  const m = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
  if (m) {
    const r = Math.max(0, Math.min(255, parseInt(m[1], 10)));
    const g = Math.max(0, Math.min(255, parseInt(m[2], 10)));
    const b = Math.max(0, Math.min(255, parseInt(m[3], 10)));
    return (
      '#' +
      r.toString(16).padStart(2, '0') +
      g.toString(16).padStart(2, '0') +
      b.toString(16).padStart(2, '0')
    ).toLowerCase();
  }
  return current;
}

// Ajoute deux <input type="color"> (Texte + Fond) dans la toolbar Quill

function addQuillColorPickers(quill) {
  try {
    const toolbar = quill.getModule('toolbar');
    const bar = toolbar && toolbar.container;
    if (!bar) return;
    if (bar.querySelector('.ql-color-pickers')) return; // déjà injecté

    const group = document.createElement('span');
    group.className = 'ql-formats ql-color-pickers';

    // --- Picker couleur de TEXTE
    const colorWrap  = document.createElement('label');
    colorWrap.className = 'ql-color-picker';
    colorWrap.title = 'Couleur du texte';
    colorWrap.style.display = 'inline-flex';
    colorWrap.style.alignItems = 'center';

    const colorIcon = document.createElement('span');
    colorIcon.className = 'ql-picker-label';
    colorIcon.textContent = 'A';
    colorIcon.style.cssText = 'display:inline-block;font-weight:700;margin-right:6px;';

    const colorInput = document.createElement('input');
    colorInput.type = 'color';
    colorInput.value = '#333333';
    colorInput.style.cssText = 'width:28px;height:28px;padding:0;border:none;background:transparent;cursor:pointer;';
    colorInput.addEventListener('input', () => {
      // → couleur du TEXTE
      quill.format('color', colorInput.value || null);
    });

    colorWrap.appendChild(colorIcon);
    colorWrap.appendChild(colorInput);
    group.appendChild(colorWrap);

    // --- Picker couleur de FOND
    const bgWrap  = document.createElement('label');
    bgWrap.className = 'ql-bg-picker';
    bgWrap.title = 'Couleur de fond';
    bgWrap.style.display = 'inline-flex';
    bgWrap.style.alignItems = 'center';

    const bgIcon = document.createElement('span');
    bgIcon.className = 'ql-picker-label';
    bgIcon.textContent = '▧';
    bgIcon.style.cssText = 'display:inline-block;margin:0 6px 0 12px;';

    const bgInput = document.createElement('input');
    bgInput.type = 'color';
    bgInput.value = '#ffffff';
    bgInput.style.cssText = 'width:28px;height:28px;padding:0;border:none;background:transparent;cursor:pointer;';
    bgInput.addEventListener('input', () => {
      // → couleur de FOND
      quill.format('background', bgInput.value || null);
    });

    bgWrap.appendChild(bgIcon);
    bgWrap.appendChild(bgInput);
    group.appendChild(bgWrap);

    // Pas de palette Quill → on append à la fin du toolbar
    bar.appendChild(group);

    // synchro inverse (formats Quill -> inputs)
    const sync = () => {
      try {
        const range = quill.getSelection();
        if (!range) return;
        const fmt = quill.getFormat(range);
        if (fmt.color)      colorInput.value = toHex(fmt.color, colorInput.value);
        if (fmt.background) bgInput.value    = toHex(fmt.background, bgInput.value);
      } catch {}
    };
    quill.on('selection-change', sync);
    quill.on('text-change',      sync);

  } catch (e) {
    console.warn('[addQuillColorPickers] échec:', e);
  }
}

// === Initialisation QUILL dans le modal ======================================

export function initQuillInModal(body, blocId) {
  body.querySelectorAll('#text-editor').forEach(editorEl => {
    if (!window.Quill) return;

    // éviter double init
    if (editorEl.classList.contains('ql-container') || editorEl.querySelector('.ql-editor')) return;

    // 1) CAPTURER le contenu initial AVANT d'instancier Quill
    const initialHtmlRaw = editorEl.innerHTML?.trim() || '';

    // 2) Instancier Quill
    const toolbarOptions = [
      [{ header: [1,2,3,4,5,6,false] }],
      ['bold','italic','underline','strike'],
      ['link','blockquote','code-block'],
      [{ list: 'ordered' }, { list: 'bullet' }, { list: 'check' }],
      [{ script: 'sub' }, { script: 'super' }],
      [{ align: [] }],
      [{ size: ['small', false, 'large', 'huge'] }]
    ];
    const quill = new Quill(editorEl, {
      theme: 'snow',
      modules: { toolbar: toolbarOptions }
    });

    // 3) Récup de l'input caché (avec suffixe -text)
    const input = editorEl.parentNode.querySelector('input[type="hidden"][name$="-text"]')
               || body.querySelector('input[type="hidden"][name$="-text"]');

    // util: détecter "vide" (p, br, espaces)
    const isEmptyHtml = (html) => {
      if (!html) return true;
      const clean = html.replace(/\s+/g, ' ').trim().toLowerCase();
      return clean === '' || clean === '<p><br></p>' || clean === '<p></p>';
    };

    // 4) Déterminer la valeur initiale à injecter
    const inputContent = (input?.value || '').trim();
    const hasInitialDom = !isEmptyHtml(initialHtmlRaw);
    const hasInputValue = !isEmptyHtml(inputContent);

    if (hasInitialDom) {
      quill.root.innerHTML = initialHtmlRaw;
      if (input) input.value = quill.root.innerHTML;
    } else if (hasInputValue) {
      quill.root.innerHTML = inputContent;
    } // sinon, on garde l’état vide de Quill

    // 5) Sync en permanence vers l’input hidden
    if (input) {
      quill.on('text-change', () => {
        input.value = quill.root.innerHTML;
      });
    }

    // 6) Ajout des pickers couleur
    addQuillColorPickers(quill);

    // 7) Coller en texte brut (Alt = garder la mise en forme)
    quill.root.addEventListener('paste', (e) => {
      if (e.altKey) return;
      e.preventDefault();
      const text = (e.clipboardData || window.clipboardData)?.getData('text/plain') || '';
      if (!text) return;
      const sel = quill.getSelection(true);
      quill.deleteText(sel.index, sel.length, 'user');
      quill.insertText(sel.index, text, 'user');
      quill.setSelection(sel.index + text.length, 0, 'silent');
    });
  });

  const form = body.querySelector('#content-edit-form');
  if (form) {
    attachAjaxFormHandler('content-edit-form', editData => {
      if (editData.html) {
        const frag = editData.html;
        const old  = document.getElementById(`bloc-${blocId}`);
        if (old) {
          old.outerHTML = frag;
          const fresh = document.getElementById(`bloc-${blocId}`);
          reinitUI(fresh || document);
        }
        closeModal();
      }
    });
  }

  reinitUI(body);
}

// ===================== CRUD Sections ======================

export async function createSectionOLD(pageId) {
  const url  = `/jeiko/administration/pages/${pageId}/sections/add/`;
  const html = await fetchHtml(url);
  showModal(html, 'Créer une section');

  setTimeout(() => {
    attachAjaxFormHandler('section-form', data => {
      const frag    = data.html || data.section_html || data.content_html || '';
      const content = document.getElementById('content');
      if (!frag) return;
      let inserted = null;
      if (content) {
        const noSec = content.querySelector('h4');
        if (noSec && noSec.textContent.includes("Aucune section")) noSec.remove();
        const addBtn = content.querySelector('.section-add');
        if (addBtn) { addBtn.insertAdjacentHTML('beforebegin', frag); inserted = addBtn.previousElementSibling; }
        else        { content.insertAdjacentHTML('beforeend', frag); inserted = content.lastElementChild; }
      } else {
        document.body.insertAdjacentHTML('beforeend', frag);
      }
      reinitUI(inserted || document);
    });
  }, 0);
}

// ——— helper optionnel pour insérer le fragment section dans le DOM

function insertSectionFragment(fragHtml, pageId) {
  if (!fragHtml) return;
  const content = document.getElementById('content');
  let inserted = null;

  if (content) {
    const noSec = content.querySelector('h4');
    if (noSec && noSec.textContent.includes("Aucune section")) noSec.remove();
    const addBtn = content.querySelector('.section-add');
    if (addBtn) {
      addBtn.insertAdjacentHTML('beforebegin', fragHtml);
      inserted = addBtn.previousElementSibling;
    } else {
      content.insertAdjacentHTML('beforeend', fragHtml);
      inserted = content.lastElementChild;
    }
  } else {
    document.body.insertAdjacentHTML('beforeend', fragHtml);
  }
  reinitUI(inserted || document);
}

// ——— remplace intégralement ta fonction createSection actuelle par ceci

export async function createSection(pageId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/add/`;

  // On demande le modal de choix (JSON)
  const res = await fetch(url, {
    method: 'GET',
    headers: {
      'X-Requested-With': 'XMLHttpRequest',
      'X-CSRFToken': csrftoken
    }
  });

  if (!res.ok) {
    showToast('Erreur serveur');
    return;
  }

  let data;
  try { data = await res.json(); } catch {
    // fallback si jamais le serveur renvoie de l’HTML (peu probable)
    const html = await res.text();
    showModal(html, 'Créer une section');
    return;
  }

  if (data.status === 'choose_type' && data.html) {
    // Affiche le modal de choix (FULL / CLASSIC / MODEL:<id>)
    showModal(data.html, 'Créer une section');

    // On wire le submit du formulaire de choix
    setTimeout(() => {
      attachAjaxFormHandler('choose-section-form', postData => {
        // Le POST renvoie {status:'success', html, section_id}
        if (postData.status === 'success' && (postData.html || postData.section_html || postData.content_html)) {
          const frag = postData.html || postData.section_html || postData.content_html || '';
          insertSectionFragment(frag, pageId);
          showToast('Section créée');
        } else {
          showToast(postData.message || 'Erreur inattendue');
        }
      }, "Section créée");
      reinitUI(document.querySelector('.modal-body') || document);
    }, 0);

  } else if (data.status === 'success' && (data.html || data.section_html || data.content_html)) {
    // Dans le cas où la vue créerait directement (peu probable ici)
    const frag = data.html || data.section_html || data.content_html || '';
    insertSectionFragment(frag, pageId);

  } else {
    showToast(data.message || 'Réponse inattendue');
  }
}

export async function editSection(pageId, sectionId) {
  const url  = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/update/`;
  const html = await fetchHtml(url);
  showModal(html, 'Modifier la section');

  setTimeout(() => {
    attachAjaxFormHandler('section-form', data => {
      const frag = data.html || data.section_html || data.content_html || '';
      const old  = document.getElementById(`section-${sectionId}`);
      if (frag && old) {
        old.outerHTML = frag;
        const fresh = document.getElementById(`section-${sectionId}`);
        reinitUI(fresh || document);
      }
    });
  }, 0);
}

export function removeSection(pageId, sectionId) {
  showConfirmModal("Es-tu sûr ?", async () => {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/delete/`;
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'X-CSRFToken': csrftoken,
        'X-Requested-With': 'XMLHttpRequest'
      },
    });
    if (!res.ok) { showToast("Erreur lors de la suppression"); return; }
    const data = await res.json();
    if (data.status === 'success') {
      const el = document.getElementById(`section-${sectionId}`);
      if (el) el.remove();
      showToast("Section supprimée");
      const content = document.getElementById('content');
      if (content && !content.querySelector('.section')) {
        const msg = document.createElement('h4');
        msg.textContent = "Aucune section créée pour l'instant";
        content.querySelector('.section-add')?.insertAdjacentElement('beforebegin', msg);
      }
      reinitUI(document);
    } else {
      showToast(data.message || "Erreur lors de la suppression");
    }
  });
}

export async function moveSectionDown(pageId, sectionId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/move_down/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    },
  });
  if (!res.ok) { showToast('Erreur serveur'); return; }
  const data = await res.json();
  if (data.status === 'success') {
    const container = document.getElementById('content');
    const secs = Array.from(container.querySelectorAll('.section'));
    const idx = secs.findIndex(el => el.id === `section-${sectionId}`);
    if (idx < secs.length - 1) {
      container.insertBefore(secs[idx+1], secs[idx]);
      showToast('Section déplacée vers le bas');
      reinitUI(container);
    }
  } else {
    showToast(data.message || 'Erreur');
  }
}

export async function makeSectionModel(sectionId) {
  const input = document.getElementById('model-name-input');
  const feedback = document.getElementById('model-feedback');
  const name = (input?.value || '').trim();

  const paint = (msg, ok) => {
    if (!feedback) return;
    feedback.textContent = msg;
    feedback.style.color = ok ? '#0a7d32' : '#b00020';
  };

  if (!name) {
    paint("Merci de saisir un nom de modèle.", false);
    return;
  }

  try {
    const res = await fetch(`/api/pages/sections/${sectionId}/make_model/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRFToken': csrftoken,
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: JSON.stringify({ model_name: name })
    });

    if (!res.ok) {
      const txt = await res.text();
      paint(txt || "Erreur lors de la création du modèle.", false);
      showToast("Erreur lors de la création du modèle");
      return;
    }

    const data = await res.json();
    if (data.success) {
      paint("Modèle créé avec succès.", true);
      showToast("Modèle créé");
      // Optionnel : désactiver le bouton ou rafraîchir le panel
      // document.querySelector('button[onclick^="makeSectionModel"]')?.setAttribute('disabled', 'disabled');
    } else {
      paint(data.message || "Erreur lors de la création du modèle.", false);
      showToast(data.message || "Erreur");
    }
  } catch (e) {
    paint("Erreur réseau.", false);
    showToast("Erreur réseau");
  }
}

// ===================== CRUD Lines ======================

export async function createLine(pageId, sectionId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/add/`;
  const res = await fetch(url, {
    method: 'GET',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    }
  });

  if (!res.ok) {
    showToast('Erreur serveur');
    return;
  }

  // On tente de parser JSON, sinon on garde l’HTML
  let payload, isJson = false;
  try { payload = await res.clone().json(); isJson = true; } catch { payload = await res.text(); }

  // ----- Cas 1 : la vue renvoie {status:"choose_type", html:"..."} -----
  if (isJson && payload && payload.status === 'choose_type' && payload.html) {
    showModal(payload.html, 'Créer une ligne');

    // Le form d’options (#choose-line-form) POST vers la même URL et renvoie {status:"success", line_html:"..."}
    setTimeout(() => {
      attachAjaxFormHandler('choose-line-form', data => {
        const frag = data.line_html || data.html || '';
        const sectionEl = document.getElementById(`section-${sectionId}`);
        if (!frag || !sectionEl) return;

        // Supprime le message "Aucune ligne…" si présent
        const noLine = sectionEl.querySelector('h4');
        if (noLine && noLine.textContent.includes("Aucune ligne")) noLine.remove();

        // Insertion après la dernière ligne, sinon avant .overlay-section, sinon fin de section
        let inserted = null;
        const lines = Array.from(sectionEl.querySelectorAll('.line'));
        if (lines.length) {
          lines[lines.length - 1].insertAdjacentHTML('afterend', frag);
          inserted = lines[lines.length - 1].nextElementSibling;
        } else {
          const anchor = sectionEl.querySelector('.overlay-section');
          if (anchor) {
            anchor.insertAdjacentHTML('beforebegin', frag);
            inserted = anchor.previousElementSibling;
          } else {
            sectionEl.insertAdjacentHTML('beforeend', frag);
            inserted = sectionEl.lastElementChild;
          }
        }
        reinitUI(inserted || sectionEl);
      }, 'Ligne créée');
    }, 0);

    return;
  }

  // ----- Cas 2 : HTML direct (form complet) -----
  showModal(payload, 'Créer une ligne');

  setTimeout(() => {
    attachAjaxFormHandler('line-form', data => {
      const frag      = data.line_html || data.html || '';
      const sectionEl = document.getElementById(`section-${sectionId}`);
      if (!frag || !sectionEl) return;

      // Supprime le message "Aucune ligne…" si présent
      const noLine = sectionEl.querySelector('h4');
      if (noLine && noLine.textContent.includes("Aucune ligne")) noLine.remove();

      let inserted = null;
      const lines = Array.from(sectionEl.querySelectorAll('.line'));
      if (lines.length) {
        lines[lines.length - 1].insertAdjacentHTML('afterend', frag);
        inserted = lines[lines.length - 1].nextElementSibling;
      } else {
        const anchor = sectionEl.querySelector('.overlay-section');
        if (anchor) {
          anchor.insertAdjacentHTML('beforebegin', frag);
          inserted = anchor.previousElementSibling;
        } else {
          sectionEl.insertAdjacentHTML('beforeend', frag);
          inserted = sectionEl.lastElementChild;
        }
      }
      reinitUI(inserted || sectionEl);
    }, 'Ligne créée');
  }, 0);
}

export async function editLine(pageId, sectionId, lineId) {
  const url  = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/update/`;
  const html = await fetchHtml(url);
  showModal(html, 'Modifier la ligne');

  setTimeout(() => {
    attachAjaxFormHandler('line-form', data => {
      const frag = data.line_html || data.html || '';
      const old  = document.getElementById(`line-${lineId}`);
      if (frag && old) {
        old.outerHTML = frag;
        const fresh = document.getElementById(`line-${lineId}`);
        reinitUI(fresh || document);
      }
    });
  }, 0);
}

export function removeLine(pageId, sectionId, lineId) {
  showConfirmModal("Es-tu sûr de vouloir supprimer cette ligne ?", async () => {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/delete/`;
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'X-CSRFToken': csrftoken,
        'X-Requested-With': 'XMLHttpRequest'
      },
    });
    if (!res.ok) { showToast("Erreur lors de la suppression"); return; }
    const data = await res.json();
    if (data.status === 'success') {
      const el = document.getElementById(`line-${lineId}`);
      if (el) el.remove();
      showToast("Ligne supprimée");
      const sectionEl = document.getElementById(`section-${sectionId}`);
      if (sectionEl && !sectionEl.querySelector('.line')) {
        const msg = document.createElement('h4');
        msg.textContent = "Aucune ligne créée pour l'instant";
        sectionEl.querySelector('.overlay-section')?.insertAdjacentElement('beforebegin', msg);
      }
      reinitUI(document);
    } else {
      showToast(data.message || "Erreur lors de la suppression");
    }
  });
}

export async function moveSectionUp(pageId, sectionId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/move_up/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    },
  });
  if (!res.ok) { showToast('Erreur serveur'); return; }
  const data = await res.json();
  if (data.status === 'success') {
    const container = document.getElementById('content');
    const secs = Array.from(container.querySelectorAll('.section'));
    const idx = secs.findIndex(el => el.id === `section-${sectionId}`);
    if (idx > 0) {
      container.insertBefore(secs[idx], secs[idx-1]);
      showToast('Section déplacée vers le haut');
      reinitUI(container);
    }
  } else {
    showToast(data.message || 'Erreur');
  }
}

export async function moveLineUp(pageId, sectionId, lineId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/move_up/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    },
  });
  if (!res.ok) { showToast('Erreur serveur'); return; }
  const data = await res.json();
  if (data.status === 'success') {
    const sectionEl = document.getElementById(`section-${sectionId}`);
    if (!sectionEl) return;
    const lines = Array.from(sectionEl.querySelectorAll('.line'));
    const idx = lines.findIndex(el => el.id === `line-${lineId}`);
    if (idx > 0) {
      sectionEl.insertBefore(lines[idx], lines[idx - 1]);
      showToast('Ligne déplacée vers le haut');
      reinitUI(sectionEl);
    }
  } else {
    showToast(data.message || 'Erreur');
  }
}

export async function moveLineDown(pageId, sectionId, lineId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/move_down/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    },
  });
  if (!res.ok) { showToast('Erreur serveur'); return; }
  const data = await res.json();
  if (data.status === 'success') {
    const sectionEl = document.getElementById(`section-${sectionId}`);
    if (!sectionEl) return;
    const lines = Array.from(sectionEl.querySelectorAll('.line'));
    const idx = lines.findIndex(el => el.id === `line-${lineId}`);
    if (idx < lines.length - 1) {
      sectionEl.insertBefore(lines[idx + 1], lines[idx]);
      showToast('Ligne déplacée vers le bas');
      reinitUI(sectionEl);
    }
  } else {
    showToast(data.message || 'Erreur');
  }
}

export async function makeLineModel(lineId) {
  const input = document.getElementById('line-model-name-input');
  const feedback = document.getElementById('line-model-feedback');
  const name = (input?.value || '').trim();

  if (!lineId) {
    if (feedback) { feedback.style.color = '#b00020'; feedback.textContent = "ID de ligne manquant."; }
    return;
  }
  if (!name) {
    if (feedback) { feedback.style.color = '#b00020'; feedback.textContent = "Donne un nom au modèle ;)"; }
    return;
  }

  try {
    const res = await fetch(`/api/pages/lines/${lineId}/make_model/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRFToken': getCookie('csrftoken'),
      },
      body: JSON.stringify({ model_name: name })
    });

    if (!res.ok) {
      const msg = await res.text();
      if (feedback) { feedback.style.color = '#b00020'; feedback.textContent = msg || "Erreur serveur."; }
      return;
    }
    const data = await res.json();
    if (data.success) {
      if (feedback) { feedback.style.color = '#0a7d32'; feedback.textContent = "Modèle créé : " + (data.model?.name || "OK"); }
      showToast("Modèle de ligne créé");
    } else {
      if (feedback) { feedback.style.color = '#b00020'; feedback.textContent = data.message || "Erreur"; }
    }
  } catch (e) {
    if (feedback) { feedback.style.color = '#b00020'; feedback.textContent = "Erreur réseau."; }
  }
}


// ===================== CRUD Content (Blocs) ======================

export async function chooseContentType(pageId, sectionId, lineId, blocId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/add/`;
  const res = await fetch(url, {
    method: 'GET',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    }
  });
  if (!res.ok) {
    showToast('Erreur serveur');
    return;
  }
  const data = await res.json();

  if (data.status === 'choose_type') {
    showModal(data.html, 'Choisir le type de contenu');
    setTimeout(() => {
      attachAjaxFormHandler('choose-content-form', chooseData => {
        if (chooseData.status === 'success') {
          editContent(pageId, sectionId, lineId, blocId);
        } else {
          showToast(chooseData.message || 'Erreur inattendue');
        }
      });
      attachBlocModelHandler('choose-bloc-model-form', pageId, sectionId, lineId, blocId);

      reinitUI(document.querySelector('.modal-body') || document);
    }, 0);

  } else if (data.status === 'success') {
    editContent(pageId, sectionId, lineId, blocId);

  } else {
    showToast(data.message || 'Erreur inattendue');
  }
}

export function showEditingParameters(id) {
  document.querySelectorAll('.editing-parameters').forEach(section => {
    const isTarget = section.id === id;
    section.style.display = isTarget ? '' : 'none';
  });
}

async function fetchEditingMenu() {
  try {
    const response = await fetch(
      '/jeiko/administration/pages/editing-menu/',
      { headers: { 'X-Requested-With': 'XMLHttpRequest' } }
    );
    if (response.ok) {
      return await response.text();
    }
  } catch (e) {
    console.warn('Impossible de charger le menu d’édition :', e);
  }
  return '';
}

export async function editContent(pageId, sectionId, lineId, blocId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/edit/`;

  const res = await fetch(url, {
    method: 'GET',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    }
  });
  if (!res.ok) {
    showToast('Erreur serveur');
    return;
  }
  const data = await res.json();

  if (data.status === 'success' && data.html) {
    const menuHtml = await fetchEditingMenu();
    showModal(data.html, menuHtml || 'Édition du contenu');
    const body = document.querySelector('.modal-body');
    initQuillInModal(body, blocId);
    showEditingParameters('content-parameters');

    // Re-init tout ce qu’il faut dans le modal (formsets, countdown previews…)
    reinitUI(body);

    setTimeout(() => {
      attachAjaxFormHandler('content-edit-form', editData => {
        if (editData.html) {
          const frag = editData.html;
          const old  = document.getElementById(`bloc-${blocId}`);
          if (old) {
            old.outerHTML = frag;
            const fresh = document.getElementById(`bloc-${blocId}`);
            reinitUI(fresh || document);
          }
          closeModal();
        }
      });
    }, 0);
  } else {
    showToast(data.message || 'Erreur inattendue');
  }
}

export function resetContent(pageId, sectionId, lineId, blocId) {
  showConfirmModal("Remettre le contenu à zéro ?", async () => {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/reset/`;
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'X-CSRFToken': csrftoken,
        'X-Requested-With': 'XMLHttpRequest'
      },
    });
    if (!res.ok) { showToast("Erreur"); return; }
    const data = await res.json();
    if (data.status === 'reset') {
      showToast("Contenu réinitialisé");
      chooseContentType(pageId, sectionId, lineId, blocId);
      reinitUI(document);
    } else {
      showToast(data.message || "Erreur");
    }
  });
}


// ---- Content -> modèle ----
export async function makeContentModel(contentId) {
  const input    = document.getElementById('content-model-name-input');
  const feedback = document.getElementById('content-model-feedback');
  const name     = (input?.value || '').trim();

  const paint = (msg, ok) => {
    if (!feedback) return;
    feedback.textContent = msg;
    feedback.style.color = ok ? '#0a7d32' : '#b00020';
  };

  if (!contentId) { paint("ID de contenu manquant.", false); return; }
  if (!name)      { paint("Donne un nom au modèle ;)", false); return; }

  try {
    const res = await fetch(`/api/pages/contents/${contentId}/make_model/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRFToken': getCookie('csrftoken'),
      },
      body: JSON.stringify({ model_name: name })
    });

    if (!res.ok) {
      const msg = await res.text();
      paint(msg || "Erreur serveur.", false);
      return;
    }
    const data = await res.json();
    if (data.success) {
      paint("Modèle de contenu créé : " + (data.model?.name || "OK"), true);
      showToast?.("Modèle de contenu créé");
    } else {
      paint(data.message || "Erreur lors de la création du modèle.", false);
    }
  } catch (e) {
    paint("Erreur réseau.", false);
  }
}

// ---- Bloc -> modèle ----

export async function makeBlocModel(blocId) {
  const input    = document.getElementById('bloc-model-name-input');
  const feedback = document.getElementById('bloc-model-feedback');
  const name     = (input?.value || '').trim();

  const paint = (msg, ok) => {
    if (!feedback) return;
    feedback.textContent = msg;
    feedback.style.color = ok ? '#0a7d32' : '#b00020';
  };

  if (!blocId) { paint("ID de bloc manquant.", false); return; }
  if (!name)   { paint("Donne un nom au modèle ;)", false); return; }

  try {
    const res = await fetch(`/api/pages/blocs/${blocId}/make_model/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRFToken': getCookie('csrftoken'),
      },
      body: JSON.stringify({ model_name: name })
    });

    if (!res.ok) {
      const msg = await res.text();
      paint(msg || "Erreur serveur.", false);
      return;
    }
    const data = await res.json();
    if (data.success) {
      paint("Modèle de bloc créé : " + (data.model?.name || "OK"), true);
      showToast?.("Modèle de bloc créé");
    } else {
      paint(data.message || "Erreur lors de la création du modèle.", false);
    }
  } catch (e) {
    paint("Erreur réseau.", false);
  }
}


// ---- Remplacement par un bloc modèle ----
export function attachBlocModelHandler(formId, pageId, sectionId, lineId, blocId) {
  const form = document.getElementById(formId);
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/add_from_model/`;
    const formData = new FormData(form);

    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'X-CSRFToken': csrftoken, 'X-Requested-With': 'XMLHttpRequest' },
        body: formData
      });
      if (!res.ok) {
        showToast("Erreur lors de l’insertion du modèle");
        return;
      }
      const data = await res.json();

      if (data.status === 'success' && data.html) {
        // Remplacer le bloc actuel par le nouveau HTML
        const old = document.getElementById(`bloc-${blocId}`);
        if (old) {
          old.outerHTML = data.html;
          const fresh = document.getElementById(`bloc-${data.bloc_id}`);
          reinitUI(fresh || document);
        }
        closeModal();
        showToast("Bloc inséré depuis modèle");
      } else {
        showToast(data.message || "Erreur lors de l’insertion du modèle");
      }
    } catch (err) {
      console.error(err);
      showToast("Erreur réseau");
    }
  });
}


// ===================== CRUD Formulaire  ======================

function showAddFieldForm(formulaireId) {
  const modal = document.getElementById('add-edit-field-modal');
  modal.innerHTML = `
    <div style="border:1px solid #ccc; padding:1em; margin-top:1em;">
      <h5>Ajouter un champ</h5>
      <form id="add-field-form">
        <label>Label <input type="text" name="label" required></label><br>
        <label>Nom technique <input type="text" name="name" required></label><br>
        <label>Type
          <select name="type">
            <option value="text">Texte</option>
            <option value="email">Email</option>
            <option value="phone">Téléphone</option>
            <option value="textarea">Zone de texte</option>
            <option value="select">Liste déroulante</option>
            <option value="checkbox">Case à cocher</option>
            <option value="date">Date</option>
            <option value="number">Numérique</option>
          </select>
        </label><br>
        <label>Obligatoire <input type="checkbox" name="required"></label><br>
        <label>Options (JSON ou valeurs séparées par virgule pour select/checkbox)<br>
          <input type="text" name="options">
        </label><br>
        <button type="submit">Ajouter</button>
        <button type="button" onclick="closeFieldForm()">Annuler</button>
      </form>
    </div>
  `;
  modal.style.display = "";
  requestAnimationFrame(() => {
    const form = document.getElementById('add-field-form');
    if (!form) {
      alert("ERREUR: Le formulaire #add-field-form n'existe pas dans le DOM !");
      return;
    }
    form.onsubmit = async function(e) {
      e.preventDefault();
      const formData = new FormData(this);
      const data = {};
      formData.forEach((v,k) => data[k]=v);
      data.required = !!formData.get('required');

      if(data.options && (data.type === "select" || data.type === "checkbox")) {
        if(data.options.trim().startsWith('[')) {
          try { data.options = JSON.parse(data.options); } catch {}
        } else {
          data.options = data.options.split(',').map(s=>s.trim()).filter(Boolean);
        }
      }
      const res = await fetch(`/api/pages/formulaires/${formulaireId}/fields/`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRFToken': getCookie('csrftoken'), },
        body: JSON.stringify(data)
      });
      if(res.ok) {
        reloadFieldsList(formulaireId);
        closeFieldForm();
        reloadFieldsList(formulaireId);
      }
    }
  });
}

function closeFieldForm() {
  const modal = document.getElementById('add-edit-field-modal');
  modal.innerHTML = "";
  modal.style.display = "none";
}

async function deleteField(fieldId) {
  if(!confirm("Supprimer ce champ ?")) return;
  const formulaireId = document.querySelector('[data-formulaire-id]').dataset.formulaireId;
  const res = await fetch(`/api/pages/formulaires/${formulaireId}/fields/${fieldId}/`, {
    method: 'DELETE',
    headers: {'X-Requested-With': 'XMLHttpRequest'}
  });
  if(res.ok) reloadFieldsList(formulaireId);
}

async function moveFieldUp(fieldId) { await moveField(fieldId, -1); }

async function moveFieldDown(fieldId) { await moveField(fieldId, 1); }

async function moveField(fieldId, direction) {
  const fieldsList = Array.from(document.querySelectorAll('#fields-list li'));
  const idx = fieldsList.findIndex(li => li.dataset.fieldId == fieldId);
  if(idx === -1) return;
  const newIdx = idx + direction;
  if(newIdx < 0 || newIdx >= fieldsList.length) return;

  [fieldsList[idx], fieldsList[newIdx]] = [fieldsList[newIdx], fieldsList[idx]];

  const formulaireId = document.querySelector('[data-formulaire-id]').dataset.formulaireId;
  const newOrder = fieldsList.map((li,i) => ({id: li.dataset.fieldId, order: i}));
  await fetch(`/api/pages/formulaires/${formulaireId}/fields/`, {
    method: 'PATCH',
    headers: {'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest'},
    body: JSON.stringify({fields: newOrder})
  });
  reloadFieldsList(formulaireId);
}

async function reloadFieldsList(formulaireId) {
  const res = await fetch(`/api/pages/formulaires/${formulaireId}/`, {
    headers: {'X-Requested-With': 'XMLHttpRequest'}
  });
  if(!res.ok) return;
  const data = await res.json();
  const ul = document.getElementById('fields-list');
  ul.innerHTML = "";
  for(const field of data.fields) {
    ul.insertAdjacentHTML('beforeend', `
      <li data-field-id="${field.id}">
        <span>
          <strong>${field.label}</strong> <em>(${field.type})</em>${field.required ? ' <span style="color:red;">*</span>' : ''}
        </span>
        <button type="button" onclick="editField(${field.id})">éditer</button>
        <button type="button" onclick="deleteField(${field.id})">supprimer</button>
        <button type="button" onclick="moveFieldUp(${field.id})">&#x25B2;</button>
        <button type="button" onclick="moveFieldDown(${field.id})">&#x25BC;</button>
      </li>
    `);
  }
}



// ===================== Exports globaux ======================

window.createSection = createSection;
window.editSection   = editSection;
window.removeSection = removeSection;
window.moveSectionUp = moveSectionUp;
window.moveSectionDown = moveSectionDown;
window.makeSectionModel = makeSectionModel;

window.createLine = createLine;
window.editLine   = editLine;
window.removeLine = removeLine;
window.moveLineUp   = moveLineUp;
window.moveLineDown = moveLineDown;
window.makeLineModel = makeLineModel;

window.chooseContentType = chooseContentType;
window.editContent = editContent;
window.resetContent = resetContent;
window.showEditingParameters = showEditingParameters;
window.makeBlocModel = makeBlocModel;

window.showAddFieldForm = showAddFieldForm;
window.closeFieldForm = closeFieldForm;
window.deleteField = deleteField;
window.moveFieldUp = moveFieldUp;
window.moveFieldDown = moveFieldDown;
window.reloadFieldsList = reloadFieldsList;

// utile pour debug
window.reinitUI = reinitUI;

document.addEventListener('DOMContentLoaded', () => {
  reinitUI(document);
});
