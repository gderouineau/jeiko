// utils.js
let lastScrollTop = 0;

// Récupère le token CSRF depuis le cookie
export function getCSRF() {
    const name = 'csrftoken';
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
        let cookie = cookies[i].trim();
        if (cookie.startsWith(name + '=')) {
            return decodeURIComponent(cookie.substring(name.length + 1));
        }
    }
    return null;
}

export function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== "") {
        const cookies = document.cookie.split(";");
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Effectue un appel fetch classique et renvoie le HTML
export async function fetchHtml(url) {
    const response = await fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    });
    if (!response.ok) throw new Error(`Erreur de chargement : ${url}`);
    return await response.text();
}

// Effectue un POST d'un formulaire (FormData ou form HTML)
export async function postForm(formElement, callback) {
    const formData = new FormData(formElement);
    const url = formElement.action;
    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCSRF()
        },
        body: formData
    });
    const contentType = response.headers.get("content-type");
    if (response.ok) {
        if (contentType && contentType.includes("application/json")) {
            const json = await response.json();
            if (json.status === 'success') {
                callback(json);
            }
        } else {
            const html = await response.text();
            callback(html);
        }
    } else {
        console.error("Erreur dans postForm", response);
    }
}

export function showModal(html, header = "") {
  lastScrollTop = window.scrollY || document.documentElement.scrollTop;
  let modal = document.getElementById("editor-modal");
  const headerMarkup =
    (typeof header === 'string' && header.trim().startsWith('<'))
      ? header // HTML brut (menu)
      : (header ? `<h3>${header}</h3>` : ''); // texte simple → <h3>

  if (!modal) {
    modal = document.createElement("div");
    modal.id = "editor-modal";
    modal.innerHTML = `
      <div class="modal-background" onclick="this.parentElement.remove()"></div>
      <div class="modal-content">
        <div class="modal-header">
          ${headerMarkup}
        </div>
        <div class="modal-body">${html}</div>
      </div>
    `;
    document.body.appendChild(modal);
  } else {
    // si tu réutilises la modale
    modal.querySelector('.modal-header')?.replaceChildren();
    modal.querySelector('.modal-header')?.insertAdjacentHTML('afterbegin', headerMarkup);
    modal.querySelector('.modal-body')?.replaceChildren();
    modal.querySelector('.modal-body')?.insertAdjacentHTML('afterbegin', html);
  }
}

// Petit toast temporaire en bas de l'écran
export function showToast(message) {
    const toast = document.createElement("div");
    toast.className = "toast-message";
    toast.innerText = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

export function showConfirmModal(message, onConfirm) {
    const modal = document.createElement("div");
    modal.id = "confirm-modal";
    modal.innerHTML = `
        <div class="confirm-overlay"></div>
        <div class="confirm-box">
            <div class="confirm-header">
                <h3>Confirmation</h3>
                <button class="confirm-close">&times;</button>
            </div>
            <div class="confirm-body">
                <p>${message}</p>
                <div class="confirm-actions">
                    <button class="btn-cancel">Annuler</button>
                    <button class="btn-confirm">Confirmer</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);

    // Événements
    modal.querySelector(".confirm-close").addEventListener("click", () => modal.remove());
    modal.querySelector(".btn-cancel").addEventListener("click", () => modal.remove());
    modal.querySelector(".btn-confirm").addEventListener("click", () => {
        modal.remove();
        onConfirm();
    });
}

export function closeModal() {

  const modal = document.getElementById('editor-modal');
  if (modal) modal.remove();
  window.scrollTo(0, lastScrollTop);
}

