# jeiko/journal_gunicorn.py
"""
Le journal d'accès de gunicorn, sans les secrets des adresses (audit de la
visio V-19, audit du paquet S06).

Le journal de gunicorn gardait chaque adresse telle quelle : le code d'un
lien de visio, le jeton d'un devis à payer, d'un résultat de questionnaire.
Cette classe de journal remplace ces secrets par « … » avant d'écrire
(`jeiko/secrets_d_adresse.py`) ; la ligne garde la méthode, le statut, la
durée — ce qui sert à diagnostiquer.

Branchée par l'installeur (`--logger-class jeiko.journal_gunicorn.Journal`,
10_configure_gunicorn.sh) dès que le paquet la contient.
"""
from gunicorn.glogging import Logger

from jeiko.secrets_d_adresse import masquer_l_adresse, masquer_la_requete, masquer_les_secrets


class Journal(Logger):
    def atoms(self, resp, req, environ, request_time):
        # On masque l'ENVIRONNEMENT avant que gunicorn n'en tire quoi que ce
        # soit : il recopie aussi chaque variable (« {raw_uri}e »…) dans les
        # données du journal, pas seulement l'adresse de la ligne.
        chemin = masquer_les_secrets(environ.get("PATH_INFO") or "")
        requete = masquer_la_requete(environ.get("QUERY_STRING") or "")
        propre = dict(environ, PATH_INFO=chemin, QUERY_STRING=requete,
                      RAW_URI=chemin + (f"?{requete}" if requete else ""))
        if "HTTP_REFERER" in environ:
            propre["HTTP_REFERER"] = masquer_l_adresse(environ["HTTP_REFERER"])
        return super().atoms(resp, req, propre, request_time)
