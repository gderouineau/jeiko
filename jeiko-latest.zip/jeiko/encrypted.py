"""
Champs chiffrés au repos, adaptés aux conventions du package.

Pourquoi ne pas utiliser `encrypted_fields` directement
-------------------------------------------------------
Sa classe de base transforme toute valeur vide en `NULL` :

    def get_prep_value(self, value):
        if value:
            return self.f.encrypt(...)
        return None          # <- même pour ""

Or les champs concernés ici sont déclarés `blank=True` **sans** `null=True` :
leur valeur vide est la chaîne vide, et la colonne est NOT NULL. Utiliser la
bibliothèque telle quelle fait donc échouer tout enregistrement dont le secret
n'est pas renseigné — c'est-à-dire le cas courant d'une passerelle de paiement
à moitié configurée.

Passer les champs en `null=True` « pour que ça marche » aurait introduit deux
valeurs vides distinctes (`NULL` et `""`) sur des champs que tout le code teste
par `if gateway.secret_key`. On préfère conserver la convention du package et
adapter le champ.

Ce que fait le chiffrement, et ce qu'il ne fait pas
---------------------------------------------------
La clé est dérivée de `SECRET_KEY` (PBKDF2), qui vit dans le `.env` en 0600 et
jamais en base. Cela protège contre la **lecture de la base sans le fichier** :
sauvegarde égarée, disque de VPS revendu, accès en lecture seule, injection SQL.

Cela ne protège **pas** contre quelqu'un qui a déjà la main sur le serveur — il
lit le `.env` aussi — ni contre un administrateur du back-office, à qui les
écrans déchiffrent par construction.

Changer de clé (F07)
--------------------
Nouvelle `SECRET_KEY` dans le `.env`, l'ancienne dans `SECRET_KEY_FALLBACKS`,
redémarrer, puis `manage.py jeiko_rechiffrer` : tout est rechiffré avec la
nouvelle clé, et l'ancienne peut quitter le `.env`. Le sel des anciennes clés
les suit (gabarit de settings) — sans quoi l'ancienne clé était essayée avec
le NOUVEAU sel, et rien ne se déchiffrait.
"""

import json
import logging

from encrypted_fields.fields import (
    EncryptedCharField as _EncryptedCharField,
    EncryptedJSONField as _EncryptedJSONField,
    EncryptedTextField as _EncryptedTextField,
)

logger = logging.getLogger(__name__)

#: Le début de tout jeton Fernet (octet de version 0x80, puis l'horodatage).
DEBUT_DE_JETON = "gAAAAA"


def champs_chiffres():
    """[(modèle, champ)] de tous les champs chiffrés du projet."""
    from django.apps import apps
    from encrypted_fields.fields import EncryptedFieldMixin

    return [(modele, champ) for modele in apps.get_models() for champ in modele._meta.concrete_fields
            if isinstance(champ, EncryptedFieldMixin)]


def oublier_les_cles(**kwargs):
    """Les clés sont dérivées une fois par champ (`cached_property`) : après un
    changement de SECRET_KEY, SALT_KEY ou SECRET_KEY_FALLBACKS en cours de
    route (tests), on les dérive de nouveau. Un serveur, lui, redémarre."""
    if kwargs.get("setting") not in (None, "SECRET_KEY", "SALT_KEY", "SECRET_KEY_FALLBACKS"):
        return
    for _modele, champ in champs_chiffres():
        champ.__dict__.pop("keys", None)
        champ.__dict__.pop("f", None)


def illisible(champ, valeur):
    """Vrai si `valeur`, lue en base, porte encore un jeton qu'aucune clé ne déchiffre."""
    from cryptography.fernet import InvalidToken

    if isinstance(valeur, dict):
        return any(illisible(champ, v) for v in valeur.values())
    if isinstance(valeur, list):
        return any(illisible(champ, v) for v in valeur)
    if not (isinstance(valeur, str) and valeur.startswith(DEBUT_DE_JETON) and len(valeur) > 50):
        return False
    try:
        champ.f.decrypt(valeur.encode("utf-8"))
    except (InvalidToken, ValueError):
        return True
    return False


def _brancher_l_oubli():
    from django.core.signals import setting_changed

    setting_changed.connect(oublier_les_cles, dispatch_uid="jeiko_oublier_les_cles")


_brancher_l_oubli()


class _VideRestVideMixin:
    """Conserve la chaîne vide au lieu de la transformer en NULL."""

    def get_prep_value(self, value):
        prepare = super().get_prep_value(value)
        if prepare is None and not self.null:
            return ""
        return prepare


class EncryptedCharField(_VideRestVideMixin, _EncryptedCharField):
    pass


class EncryptedTextField(_VideRestVideMixin, _EncryptedTextField):
    pass


class EncryptedJSONField(_EncryptedJSONField):
    """
    Le JSON vide est `{}`, pas la chaîne vide : la règle ci-dessus ne
    s'applique pas, et un dict vide n'a de toute façon aucun secret à protéger.

    Ce que chiffre réellement ce champ
    ----------------------------------
    **Les valeurs, pas les clés.** En base on lit toujours
    `{"private_key": "gAAAA…", "client_email": "gAAAA…"}` : la colonne reste du
    `jsonb`, la structure du document reste lisible, seules les feuilles sont
    chiffrées. C'est suffisant ici — le secret est dans les valeurs — mais il
    ne faut pas y ranger un document dont les *noms de clés* seraient sensibles.

    **Les scalaires reviennent en chaînes.** La bibliothèque fait `str(value)`
    avant de chiffrer : un `21` ressort `"21"`, un `True` ressort `"True"`.
    N'y ranger que des chaînes, ou convertir à la lecture.

    Pourquoi ce `to_python`
    -----------------------
    Une ligne écrite **avant** le passage au champ chiffré n'est pas
    déchiffrable. La bibliothèque avale alors l'échec (`except InvalidToken:
    pass`) et renvoie… le texte JSON brut, c'est-à-dire une `str` là où tout le
    code attend un `dict` — d'où un `AttributeError` sur le premier `.get()`,
    loin de la cause. On rétablit le `dict` et on journalise.

    Deux causes possibles, que l'on ne sait pas distinguer à cet endroit : la
    ligne date d'avant le chiffrement (une migration de données la règle), ou
    `SECRET_KEY` a changé sans `SECRET_KEY_FALLBACKS` — et dans ce second cas le
    `dict` rendu contient du chiffré illisible. Le message dit les deux.
    """

    def get_prep_value(self, value):
        prepare = super().get_prep_value(value)
        if prepare is None and not self.null:
            return "{}"
        return prepare

    def to_python(self, value):
        valeur = super().to_python(value)
        if not isinstance(valeur, str):
            return valeur
        if hasattr(self, "_already_decrypted"):
            # Nettoyage d'un formulaire : la valeur vient du navigateur, pas de
            # la base. Rien à rattraper, et surtout rien à journaliser.
            return valeur
        try:
            rendu = json.loads(valeur)
        except ValueError:
            return valeur
        logger.warning(
            "%s.%s : valeur non déchiffrée — ligne antérieure au chiffrement, "
            "ou SECRET_KEY changée sans SECRET_KEY_FALLBACKS.",
            getattr(self, "model", None) and self.model.__name__,
            self.name,
        )
        return rendu
