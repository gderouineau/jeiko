# jeiko/emailing/registry.py
"""
Catalogue des e-mails envoyables par la plateforme.

Source de vérité unique : un code d'événement y est déclaré une fois, avec son
libellé, sa catégorie, son destinataire et les variables qu'il expose. Le reste
en découle — la notice affichée dans l'admin, la validation des clés saisies
dans un sujet, et le seed des contenus par défaut.

Les variables s'écrivent [%cle%] dans le sujet comme dans le corps, avec la même
syntaxe que les contenus d'administration_pages (voir TAG_PATTERN dans
templatetags/custom_tags.py).
"""

# =========================
#  Catégories
# =========================

CATEGORY_ACCOUNT = "account"
CATEGORY_APPOINTMENT = "appointment"
CATEGORY_TEST = "test"
CATEGORY_COURSE = "course"
CATEGORY_SHOP = "shop"
CATEGORY_SITE = "site"
CATEGORY_INTERNAL = "internal"
CATEGORY_MARKETING = "marketing"

CATEGORY_LABELS = {
    CATEGORY_ACCOUNT: "Compte & sécurité",
    CATEGORY_APPOINTMENT: "Rendez-vous",
    CATEGORY_TEST: "Questionnaires & tests",
    CATEGORY_COURSE: "Formations",
    CATEGORY_SHOP: "Boutique & paiements",
    CATEGORY_SITE: "Site & formulaires",
    CATEGORY_INTERNAL: "Interne & technique",
    CATEGORY_MARKETING: "Marketing & cycle de vie",
}

# Ordre d'affichage dans l'administration.
CATEGORY_ORDER = [
    CATEGORY_ACCOUNT,
    CATEGORY_APPOINTMENT,
    CATEGORY_TEST,
    CATEGORY_COURSE,
    CATEGORY_SHOP,
    CATEGORY_SITE,
    CATEGORY_INTERNAL,
    CATEGORY_MARKETING,
]

# =========================
#  Destinataires
# =========================

AUDIENCE_USER = "user"
AUDIENCE_PROSPECT = "prospect"
AUDIENCE_ADMIN = "admin"
AUDIENCE_PROVIDER = "provider"

AUDIENCE_LABELS = {
    AUDIENCE_USER: "Utilisateur / client",
    AUDIENCE_PROSPECT: "Prospect (sans compte)",
    AUDIENCE_ADMIN: "Administrateur",
    AUDIENCE_PROVIDER: "Praticien / intervenant",
}

# =========================
#  Variables globales
# =========================

# Injectées dans tous les e-mails, quel que soit l'événement.
GLOBAL_VARIABLES = {
    "site_nom": "Nom du site",
    "site_url": "URL du site (absolue)",
    "logo_url": "URL du logo (absolue)",
    "prenom": "Prénom du destinataire",
    "nom": "Nom du destinataire",
    "email": "Adresse e-mail du destinataire",
    "date": "Date du jour (JJ/MM/AAAA)",
    "annee": "Année en cours",
    "contact_email": "Adresse de contact du site",
    "contact_tel": "Téléphone de contact du site",
    "lien_compte": "Lien vers l'espace personnel",
    "lien_desabonnement": "Lien de désinscription (obligatoire sur le marketing)",
    "signature": "Signature configurée pour le site",
}

# =========================
#  Événements
# =========================

# Chaque entrée : label, category, audience, description, variables.
# `variables` ne liste QUE les variables propres à l'événement — les globales
# ci-dessus sont toujours disponibles en plus.
EMAIL_EVENTS = {

    # ---------- Compte & sécurité ----------
    "account_welcome": {
        "label": "Bienvenue",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé après la validation de l'inscription.",
        "variables": {
            "lien_action": "Lien vers l'espace personnel",
        },
    },
    "account_email_verify": {
        "label": "Vérification de l'adresse e-mail",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé à l'inscription pour confirmer l'adresse.",
        "variables": {
            "lien_action": "Lien de vérification",
            "code": "Code de vérification (si saisie manuelle)",
            "expiration": "Durée de validité du lien",
        },
    },
    "account_email_verify_reminder": {
        "label": "Rappel : adresse e-mail à confirmer",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Un compte jamais confirmé va être supprimé : 7 jours avant, puis la veille, avec un lien neuf.",
        "variables": {
            "prenom": "Prénom (peut être vide)",
            "lien_action": "Lien de confirmation, neuf",
            "expiration": "Durée de validité du lien",
            "quand": "« dans 7 jours » ou « demain »",
            "date_suppression": "Date de la suppression, ex. « 12 novembre 2026 »",
        },
    },
    "password_reset_request": {
        "label": "Réinitialisation du mot de passe",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé sur demande de réinitialisation.",
        "variables": {
            "lien_action": "Lien de réinitialisation",
            "expiration": "Durée de validité du lien",
            "ip": "Adresse IP à l'origine de la demande",
        },
    },
    "password_changed": {
        "label": "Mot de passe modifié",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Notification de sécurité, sans action attendue.",
        "variables": {
            "date_heure": "Date et heure de la modification",
            "ip": "Adresse IP",
            "appareil": "Navigateur / appareil",
        },
    },
    "account_created_by_admin": {
        "label": "Compte créé par l'administrateur",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Compte ouvert depuis l'administration.",
        "variables": {
            "lien_action": "Lien de définition du mot de passe",
            "expiration": "Durée de validité du lien",
        },
    },
    "email_change_confirm": {
        "label": "Confirmation de la nouvelle adresse",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé à la NOUVELLE adresse pour la confirmer.",
        "variables": {
            "lien_action": "Lien de confirmation",
            "nouvel_email": "Nouvelle adresse demandée",
            "expiration": "Durée de validité du lien",
        },
    },
    "email_changed_alert": {
        "label": "Alerte de changement d'adresse",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé à l'ANCIENNE adresse pour signaler le changement.",
        "variables": {
            "nouvel_email": "Nouvelle adresse",
            "date_heure": "Date et heure du changement",
        },
    },
    "twofa_code": {
        "label": "Code de double authentification",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Code à usage unique envoyé par e-mail.",
        "variables": {
            "code": "Code à usage unique",
            "expiration": "Durée de validité du code",
        },
    },
    "twofa_enabled": {
        "label": "Double authentification activée",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Notification de sécurité.",
        "variables": {
            "date_heure": "Date et heure de l'activation",
            "methode": "Méthode utilisée (application, e-mail…)",
        },
    },
    "twofa_disabled": {
        "label": "Double authentification désactivée",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Notification de sécurité.",
        "variables": {
            "date_heure": "Date et heure de la désactivation",
        },
    },
    "login_new_device": {
        "label": "Connexion depuis un nouvel appareil",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Déclenché sur une IP ou un appareil inconnu.",
        "variables": {
            "date_heure": "Date et heure de la connexion",
            "ip": "Adresse IP",
            "appareil": "Navigateur / appareil",
            "localisation": "Localisation approximative",
        },
    },
    "account_locked": {
        "label": "Compte temporairement bloqué",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Après plusieurs tentatives de connexion échouées.",
        "variables": {
            "duree_blocage": "Durée du blocage",
            "lien_action": "Lien de réinitialisation du mot de passe",
        },
    },
    "account_deactivated": {
        "label": "Compte désactivé",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Confirmation de désactivation ou de suppression.",
        "variables": {
            "date_heure": "Date et heure de la désactivation",
        },
    },

    # ---------- Rendez-vous ----------
    "rgpd_data_export_ready": {
        "label": "Export de données prêt",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Export RGPD disponible au téléchargement.",
        "variables": {
            "lien_action": "Lien de téléchargement",
            "expiration": "Durée de validité du lien",
        },
    },

    "appointment_confirmed": {
        "label": "Confirmation de rendez-vous",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé au client dès la réservation.",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "rdv_heure": "Heure du rendez-vous (côté client : dans son fuseau, avec l\'heure du site si elle diffère)",
            "rdv_fuseau": "Fuseau annoncé, ex. « heure de Paris »",
            "rdv_duree": "Durée",
            "rdv_type": "Type de rendez-vous",
            "pro_nom": "Nom du praticien",
            "lieu": "Lieu du rendez-vous",
            "lien_visio": "Lien de visioconférence",
            "lien_annulation": "Lien d'annulation / modification",
        },
    },
    "appointment_admin_new": {
        "label": "Nouvelle réservation (praticien)",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_PROVIDER,
        "description": "Copie envoyée au praticien et aux administrateurs.",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "rdv_heure": "Heure du rendez-vous (côté client : dans son fuseau, avec l\'heure du site si elle diffère)",
            "rdv_fuseau": "Fuseau annoncé, ex. « heure de Paris »",
            "rdv_duree": "Durée",
            "rdv_type": "Type de rendez-vous",
            "client_nom": "Nom du client",
            "client_email": "E-mail du client",
            "client_tel": "Téléphone du client",
            "rdv_id": "Identifiant interne",
        },
    },
    "appointment_reminder_24h": {
        "label": "Rappel — 24 h avant",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé la veille par la tâche planifiée.",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "rdv_heure": "Heure du rendez-vous (côté client : dans son fuseau, avec l\'heure du site si elle diffère)",
            "rdv_fuseau": "Fuseau annoncé, ex. « heure de Paris »",
            "rdv_duree": "Durée",
            "rdv_type": "Type de rendez-vous",
            "pro_nom": "Nom du praticien",
            "lieu": "Lieu du rendez-vous",
            "lien_visio": "Lien de visioconférence",
            "lien_annulation": "Lien d'annulation / modification",
        },
    },
    "appointment_reminder_2h": {
        "label": "Rappel — 2 h avant",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Rappel court, utile surtout en visioconférence.",
        "variables": {
            "rdv_heure": "Heure du rendez-vous (côté client : dans son fuseau, avec l\'heure du site si elle diffère)",
            "rdv_fuseau": "Fuseau annoncé, ex. « heure de Paris »",
            "rdv_type": "Type de rendez-vous",
            "lieu": "Lieu du rendez-vous",
            "lien_visio": "Lien de visioconférence",
        },
    },
    "appointment_cancelled_client": {
        "label": "Annulation par le client",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Accusé d'annulation, envoyé au client et au praticien.",
        "variables": {
            "rdv_date": "Date du rendez-vous annulé",
            "rdv_heure": "Heure du rendez-vous annulé",
            "rdv_type": "Type de rendez-vous",
            "lien_action": "Lien pour reprendre un rendez-vous",
        },
    },
    "appointment_cancelled_pro": {
        "label": "Annulation par le praticien",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Le praticien annule ; le client est invité à replanifier.",
        "variables": {
            "rdv_date": "Date du rendez-vous annulé",
            "rdv_heure": "Heure du rendez-vous annulé",
            "rdv_type": "Type de rendez-vous",
            "pro_nom": "Nom du praticien",
            "motif": "Motif de l'annulation",
            "lien_action": "Lien de nouvelle réservation",
        },
    },
    "appointment_rescheduled": {
        "label": "Rendez-vous déplacé",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Le créneau a changé.",
        "variables": {
            "rdv_date": "Nouvelle date",
            "rdv_heure": "Nouvelle heure",
            "ancienne_date": "Ancienne date",
            "ancienne_heure": "Ancienne heure",
            "rdv_type": "Type de rendez-vous",
            "pro_nom": "Nom du praticien",
            "lien_annulation": "Lien d'annulation / modification",
        },
    },
    "appointment_payment_pending": {
        "label": "Rendez-vous en attente de paiement",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Créneau réservé mais non réglé.",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "rdv_heure": "Heure du rendez-vous (côté client : dans son fuseau, avec l\'heure du site si elle diffère)",
            "rdv_fuseau": "Fuseau annoncé, ex. « heure de Paris »",
            "montant": "Montant à régler",
            "lien_action": "Lien de paiement",
            "expiration": "Délai avant libération du créneau",
        },
    },
    "appointment_followup": {
        "label": "Compte rendu de rendez-vous",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé depuis la fiche d'un contact, après relecture : le compte "
                       "rendu d'un rendez-vous (CRM). Jamais automatiquement.",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "rdv_type": "Type de rendez-vous",
            "compte_rendu": "Le texte du compte rendu",
            "pro_nom": "Nom de la personne qui l'envoie",
        },
    },
    "appointment_no_show": {
        "label": "Absence au rendez-vous",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Le client ne s'est pas présenté.",
        "variables": {
            "rdv_date": "Date du rendez-vous manqué",
            "rdv_heure": "Heure du rendez-vous manqué",
            "lien_action": "Lien de nouvelle réservation",
        },
    },
    "appointment_reminder_pro_1h": {
        "label": "Rappel praticien — 1 h avant",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_PROVIDER,
        "description": "Rappelle au praticien son rendez-vous imminent (tâche planifiée).",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "rdv_heure": "Heure du rendez-vous (côté client : dans son fuseau, avec l\'heure du site si elle diffère)",
            "rdv_fuseau": "Fuseau annoncé, ex. « heure de Paris »",
            "rdv_duree": "Durée",
            "rdv_type": "Type de rendez-vous",
            "client_nom": "Nom du client",
            "client_email": "E-mail du client",
            "lieu": "Lieu du rendez-vous",
        },
    },
    "appointment_daily_digest_pro": {
        "label": "Récapitulatif quotidien (praticien)",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_PROVIDER,
        "description": "Rendez-vous du lendemain, envoyé par la tâche planifiée.",
        "variables": {
            "date_cible": "Journée concernée",
            "nombre_rdv": "Nombre de rendez-vous",
            "bloc_rdv": "Tableau des rendez-vous (généré)",
        },
    },
    "appointment_waitlist_available": {
        "label": "Liste d'attente — une place s'est libérée",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Une place se libère sur un créneau complet ; la personne "
                       "en tête de liste est prévenue, place tenue quelques minutes.",
        "variables": {
            "prenom": "Prénom du client",
            "rdv_date": "Date du créneau",
            "rdv_heure": "Heure du créneau",
            "rdv_type": "Type de rendez-vous",
            "pro_nom": "Nom du praticien",
            "lien_action": "Lien de réservation en 1 clic",
            "lien_desinscription": "Lien pour quitter la liste d'attente",
            "expiration": "Heure jusqu'à laquelle la place est tenue",
        },
    },
    "appointment_refunded": {
        "label": "Rendez-vous remboursé",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Confirme au client le remboursement d'un rendez-vous payant annulé.",
        "variables": {
            "prenom": "Prénom du client",
            "rdv_date": "Date du rendez-vous annulé",
            "rdv_heure": "Heure du rendez-vous annulé",
            "rdv_type": "Type de rendez-vous",
            "montant": "Montant remboursé",
        },
    },

    # ---------- Questionnaires & tests ----------
    "test_access_granted": {
        "label": "Accès au test accordé",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_USER,
        "description": "Accès ouvert par achat, par un administrateur ou offert.",
        "variables": {
            "test_nom": "Nom du test",
            "lien_action": "Lien pour démarrer le test",
            "origine_acces": "Origine de l'accès (achat, admin, offert)",
        },
    },
    "test_completed_results": {
        "label": "Résultats du test",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_USER,
        "description": "Envoyé à la fin du test, avec le profil obtenu.",
        "variables": {
            "test_nom": "Nom du test",
            "score": "Score obtenu",
            "profil": "Profil identifié",
            "profil_description": "Description du profil",
            "bloc_resultats": "Détail des résultats (généré)",
            "lien_resultats": "Lien vers le rapport complet",
            "lien_resultats_pdf": "Lien vers les résultats en PDF (si le questionnaire les propose)",
        },
    },
    "test_relance_resultats": {
        "label": "Relance après le questionnaire",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_USER,
        "description": "Quelques jours après le passage, renvoie ses résultats à la personne "
                       "(délai et destinataires : réglages de chaque questionnaire).",
        "variables": {
            "test_nom": "Nom du test",
            "jours": "Nombre de jours depuis le passage",
            "date_passage": "Date du passage",
            "score": "Score obtenu",
            "profil": "Profil identifié",
            "profil_description": "Description du profil",
            "bloc_resultats": "Détail des résultats (généré)",
            "lien_resultats": "Lien vers le rapport complet",
            "lien_resultats_pdf": "Lien vers les résultats en PDF (si le questionnaire les propose)",
        },
    },
    "test_results_admin": {
        "label": "Résultats du test (praticien)",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_PROVIDER,
        "description": "Notifie l'administration qu'un test vient d'être passé.",
        "variables": {
            "test_nom": "Nom du test",
            "client_nom": "Nom du répondant",
            "client_email": "E-mail du répondant",
            "score": "Score obtenu",
            "profil": "Profil identifié",
            "bloc_resultats": "Détail des résultats (généré)",
            "lien_resultats": "Lien vers le rapport complet",
            "lien_prospect": "Lien vers la fiche du répondant (administration)",
            "lien_testdata": "Lien vers le détail du test passé (administration)",
        },
    },
    "test_invitation": {
        "label": "Invitation à passer le test",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_PROSPECT,
        "description": "Invitation à jeton, sans création de compte.",
        "variables": {
            "test_nom": "Nom du test",
            "lien_action": "Lien d'accès au test",
            "expiration": "Durée de validité du lien",
            "duree_estimee": "Durée estimée du test",
        },
    },

    "test_abandoned_reminder": {
        "label": "Relance — test non terminé",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_USER,
        "description": "Test commencé mais laissé en cours.",
        "variables": {
            "test_nom": "Nom du test",
            "progression": "Progression atteinte",
            "lien_action": "Lien pour reprendre le test",
        },
    },

    "prospect_captured_admin": {
        "label": "Nouveau prospect",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_ADMIN,
        "description": "Un prospect vient d'être enregistré.",
        "variables": {
            "client_nom": "Nom du prospect",
            "client_email": "E-mail du prospect",
            "client_tel": "Téléphone du prospect",
            "origine": "Origine de la capture",
            "lien_action": "Lien vers la fiche prospect",
        },
    },

    # ---------- Formations ----------
    "test_retake_reminder": {
        "label": "Invitation à repasser le test",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_USER,
        "description": "Relance à distance du dernier passage.",
        "variables": {
            "test_nom": "Nom du test",
            "date_dernier_passage": "Date du dernier passage",
            "lien_action": "Lien pour repasser le test",
        },
    },

    "course_enrolled": {
        "label": "Inscription à la formation",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Envoyé à la création de l'inscription.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "lien_action": "Lien vers la formation",
            "nombre_chapitres": "Nombre de chapitres",
        },
    },
    "course_access_granted_admin": {
        "label": "Accès formation accordé",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Accès ouvert par un administrateur.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "lien_action": "Lien vers la formation",
        },
    },
    "course_completed": {
        "label": "Formation terminée",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Félicitations et attestation.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "date_fin": "Date d'achèvement",
            "lien_attestation": "Lien vers l'attestation",
        },
    },
    "course_suspended": {
        "label": "Accès formation suspendu",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "L'inscription passe en statut suspendu.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "motif": "Motif de la suspension",
        },
    },
    "course_new_content": {
        "label": "Nouveau contenu publié",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Envoyé aux inscrits d'une formation enrichie.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "contenu_nom": "Titre du nouveau contenu",
            "lien_action": "Lien vers le contenu",
        },
    },
    "course_progress_stalled": {
        "label": "Relance — progression à l'arrêt",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Aucune progression depuis un certain temps.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "progression": "Progression actuelle (%)",
            "lien_action": "Lien pour reprendre",
            "jours_inactivite": "Nombre de jours d'inactivité",
        },
    },
    "quiz_passed": {
        "label": "Quiz réussi",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Résultat positif à un quiz.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "quiz_nom": "Nom du quiz",
            "score": "Score obtenu",
            "lien_action": "Lien vers la suite de la formation",
        },
    },
    "quiz_failed": {
        "label": "Quiz échoué",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Invitation à retenter le quiz.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "quiz_nom": "Nom du quiz",
            "score": "Score obtenu",
            "score_requis": "Score requis",
            "lien_action": "Lien pour retenter",
        },
    },

    # ---------- Boutique & paiements ----------
    "order_confirmation": {
        "label": "Confirmation de commande",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "La commande passe en statut confirmée.",
        "variables": {
            "commande_num": "Numéro de commande",
            "commande_date": "Date de la commande",
            "commande_total": "Montant total",
            "bloc_lignes": "Tableau des articles (généré)",
            "adresse_livraison": "Adresse de livraison",
            "lien_action": "Lien vers la commande",
        },
    },
    "payment_received": {
        "label": "Paiement reçu",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Le paiement est confirmé ; la facture est jointe.",
        "variables": {
            "commande_num": "Numéro de commande",
            "montant": "Montant réglé",
            "moyen_paiement": "Moyen de paiement",
            "lien_facture": "Lien vers la facture",
        },
    },
    "payment_failed": {
        "label": "Échec du paiement",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Le paiement a échoué ; lien de reprise.",
        "variables": {
            "commande_num": "Numéro de commande",
            "montant": "Montant dû",
            "motif": "Motif de l'échec",
            "lien_action": "Lien pour relancer le paiement",
        },
    },
    "order_admin_new": {
        "label": "Nouvelle commande (administrateur)",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_ADMIN,
        "description": "Notification interne de commande.",
        "variables": {
            "commande_num": "Numéro de commande",
            "commande_total": "Montant total",
            "client_nom": "Nom du client",
            "client_email": "E-mail du client",
            "bloc_lignes": "Tableau des articles (généré)",
            "lien_action": "Lien vers la commande en administration",
        },
    },
    "order_shipped": {
        "label": "Commande expédiée",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "La commande passe en statut expédiée.",
        "variables": {
            "commande_num": "Numéro de commande",
            "transporteur": "Transporteur",
            "numero_suivi": "Numéro de suivi",
            "lien_suivi": "Lien de suivi du colis",
            "date_livraison_estimee": "Date de livraison estimée",
        },
    },
    "order_cancelled": {
        "label": "Commande annulée",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "La commande passe en statut annulée.",
        "variables": {
            "commande_num": "Numéro de commande",
            "motif": "Motif de l'annulation",
            "montant": "Montant concerné",
        },
    },
    "order_refunded": {
        "label": "Remboursement effectué",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Le paiement passe en statut remboursé.",
        "variables": {
            "commande_num": "Numéro de commande",
            "montant": "Montant remboursé",
            "moyen_paiement": "Moyen de remboursement",
            "delai": "Délai avant réception",
        },
    },
    "order_completed": {
        "label": "Commande terminée",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Remerciement et demande d'avis.",
        "variables": {
            "commande_num": "Numéro de commande",
            "bloc_lignes": "Tableau des articles (généré)",
            "lien_action": "Lien vers le formulaire d'avis",
        },
    },
    "cart_abandoned": {
        "label": "Relance de panier",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Panier non converti après un délai.",
        "variables": {
            "bloc_lignes": "Tableau des articles du panier (généré)",
            "panier_total": "Montant du panier",
            "lien_action": "Lien de reprise du panier",
        },
    },
    "product_back_in_stock": {
        "label": "Retour en stock",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Envoyé aux inscrits à l'alerte stock.",
        "variables": {
            "produit_nom": "Nom du produit",
            "produit_prix": "Prix du produit",
            "lien_action": "Lien vers la fiche produit",
        },
    },

    # FACT-01 : devis et factures faits à la main.
    "quote_sent": {
        "label": "Devis envoyé",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Le devis part au client, avec son PDF et le lien pour l'accepter.",
        "variables": {
            "client_nom": "Nom du client",
            "piece_num": "Numéro du devis",
            "piece_objet": "Objet du devis",
            "montant": "Montant TTC",
            "validite": "Date de fin de validité",
            "lien_action": "Lien du devis (lecture et acceptation, sans compte)",
        },
    },
    "invoice_sent": {
        "label": "Facture envoyée",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "La facture part au client, avec son PDF et son lien.",
        "variables": {
            "client_nom": "Nom du client",
            "piece_num": "Numéro de la facture",
            "piece_objet": "Objet de la facture",
            "montant": "Montant TTC",
            "echeance": "Date d'échéance",
            "lien_action": "Lien de la facture, sans compte",
        },
    },
    "invoice_reminder": {
        "label": "Relance de facture",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Une facture n'est pas réglée à l'échéance (jours réglés dans Facturation).",
        "variables": {
            "client_nom": "Nom du client",
            "piece_num": "Numéro de la facture",
            "montant": "Reste à payer",
            "echeance": "Date d'échéance",
            "lien_action": "Lien de la facture, sans compte",
        },
    },
    # ---------- Visio (VISIO-01) ----------
    "visio_invitation": {
        "label": "Invitation à une visio",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Une personne est invitée à une séance en visio : son lien personnel, la date, son rôle.",
        "variables": {
            "invite_nom": "Nom de la personne invitée",
            "titre": "Titre de la séance",
            "date": "Date et heure du début, en toutes lettres",
            "role": "« intervenant », « hôte » ou « participant »",
            "ouverture": "Ouverture de la salle avant le début, ex. « 30 minutes »",
            "description": "Description de la séance (peut être vide)",
            "lien_action": "Lien personnel pour rejoindre la salle",
            "lien_desinscription": "Paragraphe « Me désinscrire » et conditions de remboursement, pour une place prise sur la page publique (généré, vide sinon)",
        },
    },
    "visio_reservation": {
        "label": "Réservation d'une visio confirmée",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Une personne s'inscrit à une séance ouverte au public, gratuite ou payée : la confirmation "
                       "de sa réservation, avec son lien personnel. Remplace l'invitation pour ces places.",
        "variables": {
            "invite_nom": "Nom de la personne",
            "titre": "Titre de la séance",
            "date": "Date et heure du début, en toutes lettres",
            "montant": "« Place réglée : 25,00 € » ou « Participation gratuite »",
            "ouverture": "Ouverture de la salle avant le début, ex. « 30 minutes »",
            "description": "Description de la séance (peut être vide)",
            "lien_action": "Lien personnel pour rejoindre la salle",
            "lien_desinscription": "Paragraphe « Me désinscrire » et conditions de remboursement (généré)",
        },
    },
    "visio_rappel": {
        "label": "Rappel d'une visio",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "La veille et une heure avant une séance en visio (hors rendez-vous du calendrier, qui ont les leurs).",
        "variables": {
            "invite_nom": "Nom de la personne invitée",
            "titre": "Titre de la séance",
            "date": "Date et heure du début, en toutes lettres",
            "quand": "« demain » ou « dans une heure »",
            "lien_action": "Lien personnel pour rejoindre la salle",
            "lien_desinscription": "Paragraphe « Me désinscrire » et conditions de remboursement, pour une place prise sur la page publique (généré, vide sinon)",
        },
    },
    "visio_place_liberee": {
        "label": "Place libérée dans une visio",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Une place s'est libérée dans une séance complète : toute la liste d'attente est prévenue, le premier qui s'inscrit la prend.",
        "variables": {
            "invite_nom": "Nom de la personne en attente",
            "titre": "Titre de la séance",
            "date": "Date et heure du début, en toutes lettres",
            "lien_action": "Page d'inscription de la séance",
        },
    },
    "visio_confirmer_inscription": {
        "label": "Confirmer une inscription à une visio",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Une inscription gratuite (ou la liste d'attente) sans compte vérifié : la personne confirme son adresse ; la place n'est prise qu'à ce moment.",
        "variables": {
            "invite_nom": "Nom donné à l'inscription",
            "titre": "Titre de la séance",
            "date": "Date et heure du début, en toutes lettres",
            "attente": "Phrase sur la liste d'attente (vide pour une inscription)",
            "lien_action": "Lien de confirmation, valable 48 heures",
        },
    },
    "visio_annulee": {
        "label": "Visio annulée",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "L'organisateur annule une séance : chaque invité est prévenu, et la personne qui avait payé sa place sait ce qui lui est remboursé.",
        "variables": {
            "invite_nom": "Nom de la personne invitée",
            "titre": "Titre de la séance",
            "date": "Date et heure prévues, en toutes lettres",
            "motif": "Motif donné par l'organisateur (peut être vide)",
            "remboursement": "Phrase sur le remboursement de la place (vide pour une place gratuite)",
        },
    },
    "visio_message": {
        "label": "Message après une visio",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Un message de l'organisateur aux invités d'une séance — par exemple aux absents (replay, prochaine date).",
        "variables": {
            "invite_nom": "Nom de la personne invitée",
            "titre": "Titre de la séance",
            "objet": "Objet saisi par l'organisateur",
            "message": "Message saisi par l'organisateur",
        },
    },
    "licence_delivered": {
        "label": "Licence JEIKO remise",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Une licence achetée sur jeiko.fr est créée ou prolongée : sa clé part au client (LIC-02).",
        "variables": {
            "client_nom": "Titulaire de la licence",
            "cle": "Clé de licence",
            "validite": "« à vie » ou « jusqu'au JJ/MM/AAAA »",
            "action": "« créée » ou « prolongée »",
            "domaine": "Domaine lié, ou « votre site, celui où vous la saisirez en premier » (se lit après « Elle sert à »)",
        },
    },
    "low_stock_admin": {
        "label": "Alerte stock bas",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_ADMIN,
        "description": "Un produit passe sous le seuil configuré.",
        "variables": {
            "produit_nom": "Nom du produit",
            "stock_restant": "Stock restant",
            "seuil": "Seuil d'alerte",
            "lien_action": "Lien vers la fiche produit en administration",
        },
    },

    # ---------- Site & formulaires ----------
    "contact_form_admin": {
        "label": "Formulaire de contact (administrateur)",
        "category": CATEGORY_SITE,
        "audience": AUDIENCE_ADMIN,
        "description": "Notification interne à chaque soumission.",
        "variables": {
            "formulaire_nom": "Nom du formulaire",
            "bloc_reponses": "Tableau des réponses (généré)",
            "expediteur_nom": "Nom du visiteur",
            "expediteur_email": "E-mail du visiteur",
            "page_origine": "Page d'où vient la soumission",
        },
    },
    "contact_form_receipt": {
        "label": "Accusé de réception (visiteur)",
        "category": CATEGORY_SITE,
        "audience": AUDIENCE_PROSPECT,
        "description": "Confirmation envoyée au visiteur.",
        "variables": {
            "formulaire_nom": "Nom du formulaire",
            "bloc_reponses": "Rappel des réponses (généré)",
            "delai_reponse": "Délai de réponse annoncé",
        },
    },

    # ---------- Interne & technique ----------
    "newsletter_double_optin": {
        "label": "Confirmation d'inscription newsletter",
        "category": CATEGORY_SITE,
        "audience": AUDIENCE_PROSPECT,
        "description": "Double opt-in : confirme l'inscription.",
        "variables": {
            "lien_action": "Lien de confirmation",
            "expiration": "Durée de validité du lien",
        },
    },

    "newsletter_welcome": {
        "label": "Bienvenue dans la newsletter",
        "category": CATEGORY_SITE,
        "audience": AUDIENCE_PROSPECT,
        "description": "Envoyé une fois l'inscription confirmée.",
        "variables": {
            "frequence": "Fréquence d'envoi annoncée",
        },
    },

    "newsletter_unsubscribe_confirm": {
        "label": "Confirmation de désinscription",
        "category": CATEGORY_SITE,
        "audience": AUDIENCE_PROSPECT,
        "description": "Accusé de désinscription.",
        "variables": {
            "lien_action": "Lien de réinscription",
        },
    },

    "smtp_test": {
        "label": "Test de configuration SMTP",
        "category": CATEGORY_INTERNAL,
        "audience": AUDIENCE_ADMIN,
        "description": "Envoyé par le bouton de test de la configuration mail.",
        "variables": {
            "serveur_smtp": "Serveur et port SMTP",
            "utilisateur_smtp": "Utilisateur SMTP",
            "date_heure": "Date et heure du test",
        },
    },
    "admin_new_user": {
        "label": "Nouvelle inscription (administrateur)",
        "category": CATEGORY_INTERNAL,
        "audience": AUDIENCE_ADMIN,
        "description": "Notification interne à chaque inscription.",
        "variables": {
            "client_nom": "Nom du nouvel inscrit",
            "client_email": "E-mail du nouvel inscrit",
            "date_heure": "Date et heure de l'inscription",
            "lien_action": "Lien vers la fiche utilisateur",
        },
    },
    "admin_daily_digest": {
        "label": "Récapitulatif quotidien",
        "category": CATEGORY_INTERNAL,
        "audience": AUDIENCE_ADMIN,
        "description": "Synthèse envoyée par la tâche planifiée.",
        "variables": {
            "date_cible": "Journée concernée",
            "bloc_rdv": "Rendez-vous du jour (généré)",
            "bloc_commandes": "Commandes du jour (généré)",
            "bloc_prospects": "Nouveaux prospects (généré)",
        },
    },
    "admin_periodic_report": {
        "label": "Rapport d'activité (quotidien, hebdomadaire, mensuel, annuel)",
        "category": CATEGORY_INTERNAL,
        "audience": AUDIENCE_ADMIN,
        "description": "Les compteurs de la période close, comparés à la précédente, à qui l'a demandé "
                       "dans E-mails › Rapports.",
        "variables": {
            "cadence": "quotidien, hebdomadaire, mensuel ou annuel",
            "periode": "La période (« du 05/10 au 11/10/2026 », « octobre 2026 »…)",
            "bloc_inscriptions": "Les inscriptions : comptes, newsletter, formations, séances (généré)",
            "bloc_activite": "L'activité : visites, commandes, rendez-vous, questionnaires, contacts (généré)",
            "lien_tableau_de_bord": "Lien vers le tableau de bord",
        },
    },
    "crm_task_reminder": {
        "label": "Rappel de tâche (CRM)",
        "category": CATEGORY_INTERNAL,
        "audience": AUDIENCE_ADMIN,
        "description": "Le jour où une tâche de suivi arrive à échéance, à son responsable — "
                       "si le rappel est activé sur la fiche du contact.",
        "variables": {
            "tache": "La tâche",
            "echeance": "Date d'échéance",
            "contact_nom": "Nom du contact",
            "lien_action": "Lien vers la fiche du contact",
        },
    },
    "admin_error_alert": {
        "label": "Alerte technique",
        "category": CATEGORY_INTERNAL,
        "audience": AUDIENCE_ADMIN,
        "description": "Échecs d'envoi répétés, erreur de webhook, etc.",
        "variables": {
            "type_erreur": "Type d'erreur",
            "detail_erreur": "Détail technique",
            "date_heure": "Date et heure",
            "occurrences": "Nombre d'occurrences",
        },
    },

    # ---------- Marketing & cycle de vie ----------
    "birthday_wishes": {
        "label": "Anniversaire",
        "category": CATEGORY_MARKETING,
        "audience": AUDIENCE_USER,
        "description": "Message d'anniversaire, éventuellement avec offre.",
        "variables": {
            "code_promo": "Code promotionnel",
            "expiration": "Validité de l'offre",
            "lien_action": "Lien vers l'offre",
        },
    },
    "reactivation": {
        "label": "Réactivation",
        "category": CATEGORY_MARKETING,
        "audience": AUDIENCE_USER,
        "description": "Relance des utilisateurs inactifs.",
        "variables": {
            "date_derniere_visite": "Date de la dernière visite",
            "lien_action": "Lien de retour sur le site",
        },
    },
    "nps_survey": {
        "label": "Enquête de satisfaction",
        "category": CATEGORY_MARKETING,
        "audience": AUDIENCE_USER,
        "description": "Sollicitation d'avis après une prestation.",
        "variables": {
            "prestation_nom": "Prestation concernée",
            "lien_action": "Lien vers l'enquête",
        },
    },
    "campaign_manual": {
        "label": "Campagne manuelle",
        "category": CATEGORY_MARKETING,
        "audience": AUDIENCE_USER,
        "description": "Envoi ponctuel déclenché depuis l'administration.",
        "variables": {
            "titre_campagne": "Titre de la campagne",
            "lien_action": "Lien principal de la campagne",
        },
    },



}

# Événements dont l'envoi est transactionnel : ils partent toujours, sans tenir
# compte des préférences marketing, et n'ont pas besoin de lien de désinscription.
#: Déclarés, avec leur contenu, mais qu'AUCUN code n'envoie encore : leur
#: déclencheur reste à écrire (A-85). Gardés à la demande de Guillaume
#: (03/10/2026). L'écran et l'API le disent ; brancher un envoi, c'est retirer
#: son code d'ici — `emailing/tests/test_catalogue_branche.py` y veille.
EN_ATTENTE_DE_BRANCHEMENT = frozenset({
    "rgpd_data_export_ready", "test_invitation", "test_abandoned_reminder",
    "test_retake_reminder",
    "newsletter_unsubscribe_confirm", "reactivation",
    "nps_survey", "campaign_manual",
})


def est_branche(code):
    """Vrai si du code envoie cet e-mail aujourd'hui."""
    return code not in EN_ATTENTE_DE_BRANCHEMENT


TRANSACTIONAL_CATEGORIES = {
    CATEGORY_ACCOUNT,
    CATEGORY_APPOINTMENT,
    CATEGORY_TEST,
    CATEGORY_COURSE,
    CATEGORY_SHOP,
    CATEGORY_SITE,
    CATEGORY_INTERNAL,
}


# =========================
#  Accès
# =========================

def get_event(code):
    """Retourne la déclaration d'un événement, ou None s'il n'est pas au catalogue."""
    return EMAIL_EVENTS.get(code)


def event_choices():
    """Choices Django, groupés par catégorie, dans l'ordre d'affichage."""
    groups = []
    for category in CATEGORY_ORDER:
        codes = [
            (code, event["label"])
            for code, event in EMAIL_EVENTS.items()
            if event["category"] == category
        ]
        if codes:
            groups.append((CATEGORY_LABELS[category], codes))
    return groups


def available_variables(code):
    """
    Variables utilisables dans le sujet et le corps d'un événement :
    ses variables propres, plus les globales.

    Retourne une liste de dicts triée — propres d'abord, globales ensuite —
    pour l'affichage de la notice.
    """
    event = get_event(code)
    own = event["variables"] if event else {}

    variables = [
        {"key": key, "description": description, "scope": "event"}
        for key, description in own.items()
    ]
    variables += [
        {"key": key, "description": description, "scope": "global"}
        for key, description in GLOBAL_VARIABLES.items()
        if key not in own
    ]
    return variables


def variable_keys(code):
    """Ensemble des clés autorisées pour un événement (validation des saisies)."""
    return {variable["key"] for variable in available_variables(code)}


def is_transactional(code):
    event = get_event(code)
    if not event:
        return True
    return event["category"] in TRANSACTIONAL_CATEGORIES


def events_by_category():
    """
    Catalogue groupé pour les écrans de liste :
    [(clé_catégorie, libellé, [(code, événement), ...]), ...]
    """
    grouped = []
    for category in CATEGORY_ORDER:
        events = [
            (code, event)
            for code, event in EMAIL_EVENTS.items()
            if event["category"] == category
        ]
        if events:
            grouped.append((category, CATEGORY_LABELS[category], events))
    return grouped


# ---------------------------------------------------------------------------
#  E-mails obligatoires
# ---------------------------------------------------------------------------
#
# Le modèle `EmailTemplate` porte un drapeau `active`, honoré par
# `services.send_email`. Rendre cet interrupteur accessible en administration
# suppose de protéger ce qui ne doit jamais être coupé : sans garde-fou, une
# case décochée par mégarde enferme des utilisateurs dehors, sans le moindre
# signal — l'envoi échoue en silence, par conception.
#
# Trois raisons rendent un e-mail obligatoire :
#
#   1. Il conditionne un ACCÈS. Sans lui, personne ne peut plus entrer :
#      réinitialisation de mot de passe, code de double authentification,
#      confirmation d'adresse.
#   2. Il porte une OBLIGATION vis-à-vis du client : confirmation de commande
#      et reçu de paiement font foi de l'achat.
#   3. Il relève de la SÉCURITÉ ou du RGPD : l'intéressé doit être prévenu même
#      s'il n'a rien demandé — c'est justement ce qui révèle une prise de
#      compte.
#
# Tout le reste — notifications de confort, rappels, marketing — reste
# librement désactivable.
MANDATORY_CODES = frozenset({
    # 1. Accès au compte
    "password_reset_request",
    "twofa_code",
    "account_email_verify",
    "email_change_confirm",
    "account_created_by_admin",
    # 2. Obligations commerciales
    "order_confirmation",
    "payment_received",
    # 3. Sécurité & RGPD
    "password_changed",
    "email_changed_alert",
    "twofa_enabled",
    "twofa_disabled",
    "account_deactivated",
})


def is_mandatory(code):
    """Un e-mail obligatoire ne peut pas être désactivé en administration."""
    return code in MANDATORY_CODES


def mandatory_reason(code):
    """Phrase affichée à l'administrateur pour expliquer le verrou."""
    if not is_mandatory(code):
        return ""
    if code in {"password_reset_request", "twofa_code", "account_email_verify",
                "email_change_confirm", "account_created_by_admin"}:
        return "Sans cet e-mail, l'utilisateur ne peut plus accéder à son compte."
    if code in {"order_confirmation", "payment_received"}:
        return "Cet e-mail fait foi de l'achat auprès du client."
    return "Notification de sécurité : l'intéressé doit être prévenu même s'il n'a rien demandé."
