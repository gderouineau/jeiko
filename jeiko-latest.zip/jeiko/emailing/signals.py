"""
Signaux de l'envoi d'e-mails.

Retirer son accord marketing, c'est quitter TOUTES les listes de la
newsletter (Guillaume, 16/10/2026, NEWS-03). Les deux accords vivaient
séparés : un compte qui coupait le marketing — par le lien d'un e-mail, ou
depuis sa fiche en administration — continuait de recevoir la newsletter.
Le signal porte la règle, quel que soit le chemin du retrait, présent ou à
venir. Le sens inverse existait déjà : se désinscrire de tout éteint la
préférence du compte (`newsletter.abonnes.desinscrire`).

Ce qu'il ne fait pas : réinscrire quand l'accord revient. Une inscription se
redemande, liste par liste — elle ne se déduit pas.
"""
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver

from jeiko.users.models import MarketingPreference


@receiver(pre_save, sender=MarketingPreference)
def _retenir_l_accord_d_avant(sender, instance, **kwargs):
    avant = sender.objects.filter(pk=instance.pk).values_list("email_optin", flat=True).first() if instance.pk else None
    instance._email_optin_avant = avant


@receiver(post_save, sender=MarketingPreference)
def _retrait_de_l_accord_marketing(sender, instance, **kwargs):
    if getattr(instance, "_email_optin_avant", None) is True and not instance.email_optin:
        email = (getattr(instance.user, "email", "") or "").strip()
        if email:
            from jeiko.newsletter.abonnes import desinscrire

            desinscrire(email, listes=None, couper_le_compte=False)
