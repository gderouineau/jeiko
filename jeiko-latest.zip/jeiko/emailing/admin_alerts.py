# jeiko/emailing/admin_alerts.py
"""
E-mails destinés à l'exploitant, pas au client.

Le catalogue les déclarait depuis le début — nouvelle inscription, stock bas,
alerte technique, récapitulatif du jour — et aucun n'était appelé. L'exploitant
n'apprenait donc rien de ce qui se passait sur son site sans aller le consulter.

Destinataires : `sending.admin_recipients()`, c'est-à-dire l'adresse d'expédition
et l'adresse de test configurées dans les réglages e-mail. Rien n'est envoyé si
elles ne sont pas renseignées — ces messages ne valent pas la peine d'inventer un
destinataire.

Tous ces e-mails sont **désactivables** depuis l'écran d'administration : aucun
n'est dans `registry.MANDATORY_CODES`. Un exploitant qui ne veut pas de
récapitulatif quotidien doit pouvoir le couper.
"""

import logging
from datetime import timedelta

from django.conf import settings
from django.urls import NoReverseMatch, reverse
from django.utils import timezone
from django.utils.html import escape
from django.utils.safestring import mark_safe

from .sending import admin_recipients
from .services import send_email

logger = logging.getLogger("jeiko.emailing.admin_alerts")

#: Seuil retenu quand un produit n'en déclare pas.
#:
#: Le seuil se règle produit par produit (`Product.stock_alert_threshold`), où
#: NULL signifie « aucune alerte ». Ce réglage global ne sert donc que si un
#: site veut une valeur par défaut au lieu du silence — il n'écrase jamais un
#: seuil saisi.
def _seuil_stock_par_defaut():
    """Lu à chaque passage (A-81) : un réglage fait à l'écran vaut sans redémarrer."""
    from jeiko.reglages_avances import valeur
    return valeur("stock_bas", None)


def _lien_absolu(nom_url, *args):
    from .render import site_base_url

    try:
        chemin = reverse(nom_url, args=args)
    except NoReverseMatch:
        return ""
    base = site_base_url()
    return f"{base}{chemin}" if base else chemin


def _envoyer_aux_admins(code, contexte):
    """Envoie aux destinataires internes. Retourne True si un envoi a eu lieu."""
    destinataires = admin_recipients()
    if not destinataires:
        logger.info("E-mail %s non envoyé : aucun destinataire interne configuré.",
                    code)
        return False
    ok, _motif = send_email(code, destinataires, contexte)
    return bool(ok)


# ---------------------------------------------------------------------------
#  Événements
# ---------------------------------------------------------------------------

def notifier_nouvelle_inscription(user):
    """Prévient l'exploitant qu'un compte vient d'être créé."""
    nom = (user.get_full_name() or user.get_username() or "").strip()
    return _envoyer_aux_admins("admin_new_user", {
        "client_nom": nom,
        "client_email": user.email or "",
        "date_heure": timezone.localtime().strftime("%d/%m/%Y à %H:%M"),
        "lien_action": _lien_absolu(
            "jeiko_administration_users:user_detail", user.pk
        ),
    })


def notifier_erreur(type_erreur, detail, occurrences=1):
    """
    Alerte technique.

    Ne lève jamais : une alerte d'erreur qui échoue ne doit pas produire une
    seconde erreur par-dessus la première.
    """
    try:
        return _envoyer_aux_admins("admin_error_alert", {
            "type_erreur": str(type_erreur)[:120],
            "detail_erreur": str(detail)[:2000],
            "date_heure": timezone.localtime().strftime("%d/%m/%Y à %H:%M"),
            "occurrences": str(occurrences),
        })
    except Exception:
        logger.exception("Alerte technique impossible (%s)", type_erreur)
        return False


def notifier_mise_a_jour_disponible(*, paquet="", installeur="", auto=False):
    """
    « Une mise à jour est disponible » (administration/mise_a_jour.py). Un
    e-mail TECHNIQUE, en texte simple : il n'est pas dans la bibliothèque des
    e-mails (décision de Guillaume, 18/10/2026) — on ne le personnalise pas.
    À l'adresse « répondre à » des réglages e-mail, l'adresse de contact du
    site ; sinon aux destinataires internes. Ne lève jamais.
    """
    from jeiko.administration.models import WebSite

    from .sending import get_mail_settings, send_message

    try:
        reglages = get_mail_settings()
        destinataires = ([reglages.reply_to_email] if reglages and reglages.reply_to_email
                         else admin_recipients())
        if not destinataires:
            logger.info("Mise à jour disponible non annoncée : aucune adresse de contact configurée.")
            return False
        site = WebSite.objects.first()
        nom = (getattr(site, "name", "") or "JEIKO").strip()
        # Le contenu des e-mails reste en français (règle de la maison) : pas de _().
        lignes = ["Bonjour,", "", "Une mise à jour est disponible pour le site " + nom + " :"]
        if paquet:
            lignes.append(f"  · JEIKO {paquet}, le site lui-même ;")
        if installeur:
            lignes.append(f"  · l'outillage du serveur {installeur}, qui passe en premier.")
        lignes += ["", "Elle se lance depuis l'administration, onglet Mises à jour : le serveur d'abord "
                       "s'il est concerné, puis le site. Une sauvegarde est faite avant, et le site revient "
                       "à son état d'avant si quelque chose échoue."]
        if auto:
            lignes += ["", "La mise à jour automatique est cochée : elle se fera seule dans la nuit de "
                           "dimanche à lundi."]
        lignes += ["", _lien_absolu("jeiko_administration:update_jeiko"), "", "— JEIKO"]
        ok, _erreur = send_message(f"[{nom}] Une mise à jour est disponible", "\n".join(lignes), destinataires)
        return bool(ok)
    except Exception:
        logger.exception("Annonce de mise à jour impossible")
        return False


# ---------------------------------------------------------------------------
#  Tâches quotidiennes
# ---------------------------------------------------------------------------

def alerter_sur_les_stocks_bas():
    """
    Signale les produits passés sous le seuil.

    Un seul message pour tous les produits concernés : recevoir dix e-mails
    parce que dix références sont basses ferait fermer la boîte, pas
    réapprovisionner.
    """
    # La règle (nature du produit, seuil du produit, repli global) vit dans
    # administration/notifications.py : la pastille « stock bas » du menu
    # (NOTIF-01) et cette alerte comptent exactement les mêmes produits.
    from jeiko.administration.notifications import produits_en_stock_bas

    SEUIL_STOCK_PAR_DEFAUT = _seuil_stock_par_defaut()
    produits = list(produits_en_stock_bas()[:50])
    if not produits:
        return 0

    def seuil_de(produit):
        return (produit.stock_alert_threshold
                if produit.stock_alert_threshold is not None
                else SEUIL_STOCK_PAR_DEFAUT)

    lignes = "".join(
        f"<li>{escape(p.title)} — <strong>{p.stock_quantity}</strong> "
        f"restant(s) (seuil : {seuil_de(p)})</li>"
        for p in produits
    )
    envoye = _envoyer_aux_admins("low_stock_admin", {
        "produit_nom": f"{len(produits)} produit(s) sous leur seuil",
        # Une liste HTML construite ici, chaque intitulé échappé : marquée sûre
        # pour que le rendu e-mail, qui échappe les variables, la laisse passer.
        "stock_restant": mark_safe(f"<ul>{lignes}</ul>"),
        "seuil": "défini par produit",
        "lien_action": _lien_absolu("jeiko_administration_shop:product_list_all"),
    })
    return len(produits) if envoye else 0


def envoyer_le_recapitulatif_quotidien():
    """
    Synthèse de la veille : rendez-vous, commandes, nouveaux comptes.

    Porte sur la journée écoulée, pas sur celle en cours : la tâche tourne la
    nuit, un récapitulatif du jour même serait vide.
    """
    from django.contrib.auth import get_user_model

    veille = timezone.localdate() - timedelta(days=1)
    debut = timezone.make_aware(
        timezone.datetime.combine(veille, timezone.datetime.min.time())
    )
    fin = debut + timedelta(days=1)

    def bloc(titre, elements):
        if not elements:
            return f"<p><strong>{titre}</strong> : aucun.</p>"
        items = "".join(f"<li>{escape(str(e))}</li>" for e in elements[:20])
        return f"<p><strong>{titre}</strong></p><ul>{items}</ul>"

    try:
        from jeiko.calendars.models import Appointment

        rdv = list(Appointment.objects.filter(start__gte=debut, start__lt=fin))
    except Exception:
        rdv = []

    try:
        from jeiko.shop.models import Order

        commandes = list(
            Order.objects.filter(created_at__gte=debut, created_at__lt=fin)
        )
    except Exception:
        commandes = []

    comptes = list(
        get_user_model().objects.filter(date_joined__gte=debut, date_joined__lt=fin)
    )

    # Rien de neuf : on n'écrit pas pour dire qu'il ne s'est rien passé.
    if not (rdv or commandes or comptes):
        return False

    return _envoyer_aux_admins("admin_daily_digest", {
        "date_cible": veille.strftime("%d/%m/%Y"),
        "bloc_rdv": bloc("Rendez-vous", rdv),
        "bloc_commandes": bloc("Commandes", commandes),
        "bloc_prospects": bloc("Nouveaux comptes", comptes),
    })
