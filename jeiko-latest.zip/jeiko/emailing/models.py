# jeiko/emailing/models.py
import re

from django.conf import settings
from django.db import models
from django.utils import timezone

from jeiko.emailing import registry
from jeiko.encrypted import EncryptedJSONField
from django.utils.translation import gettext_lazy as _

# Même syntaxe que les contenus d'administration_pages : [% cle %].
TAG_PATTERN = re.compile(r"\[\%\s*(\w+)\s*\%\]")


def render_tags(text, context):
    """Remplace les [%cle%] présentes dans `context`, laisse les autres intactes."""
    if not text:
        return ""

    def replace(match):
        key = match.group(1)
        if key in context:
            return str(context[key])
        return match.group(0)

    return TAG_PATTERN.sub(replace, str(text))


def extract_tags(text):
    """Clés [%cle%] présentes dans un texte."""
    return set(TAG_PATTERN.findall(text or ""))


class EmailTemplate(models.Model):
    """
    Surcharge d'un e-mail du catalogue (voir registry.EMAIL_EVENTS).

    Le sujet est modifiable ici ; le corps est une Page d'administration_pages
    marquée is_mail_template, éditée dans l'éditeur visuel. Les deux acceptent
    les variables [%cle%] déclarées par l'événement.
    """

    code = models.CharField(
        max_length=64,
        unique=True,
        db_index=True,
        verbose_name=_("Code de l'événement"),
        help_text=_("Identifiant du catalogue (registry.EMAIL_EVENTS)."),
    )

    subject = models.CharField(
        max_length=255,
        verbose_name=_("Sujet"),
        help_text=_("Accepte les variables [%cle%]. Ex : [%site_nom%] — Votre rendez-vous du [%rdv_date%]"),
    )

    page = models.OneToOneField(
        "administration_pages.Page",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="email_template",
        verbose_name=_("Page de contenu"),
        help_text=_("Page marquée is_mail_template, servant de corps à l'e-mail."),
    )

    active = models.BooleanField(
        default=True,
        verbose_name=_("Actif"),
        help_text=_("Décoché, l'e-mail n'est pas envoyé."),
    )

    from_email = models.CharField(
        max_length=200,
        blank=True,
        default="",
        verbose_name=_("Expéditeur (optionnel)"),
        help_text=_("Laisser vide pour utiliser l'expéditeur par défaut de la configuration mail."),
    )

    reply_to_email = models.CharField(
        max_length=200,
        blank=True,
        default="",
        verbose_name=_("Adresse de réponse (optionnelle)"),
        help_text=_("Laisser vide pour utiliser l'adresse de réponse par défaut."),
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Modèle d'e-mail")
        verbose_name_plural = _("Modèles d'e-mail")
        ordering = ["code"]

    def __str__(self):
        return f"{self.label} ({self.code})"

    # --- Catalogue ---

    @property
    def event(self):
        """Déclaration de l'événement, ou None si le code n'est plus au catalogue."""
        return registry.get_event(self.code)

    @property
    def label(self):
        event = self.event
        return event["label"] if event else self.code

    @property
    def category(self):
        event = self.event
        return event["category"] if event else ""

    @property
    def category_label(self):
        return registry.CATEGORY_LABELS.get(self.category, "Hors catalogue")

    @property
    def audience_label(self):
        event = self.event
        if not event:
            return ""
        return registry.AUDIENCE_LABELS.get(event["audience"], "")

    @property
    def description(self):
        event = self.event
        return event["description"] if event else ""

    @property
    def is_orphan(self):
        """Le code n'existe plus au catalogue : template à supprimer ou à renommer."""
        return self.event is None

    def available_variables(self):
        return registry.available_variables(self.code)

    def variable_keys(self):
        return registry.variable_keys(self.code)

    def unknown_subject_tags(self):
        """Clés du sujet qui ne correspondent à aucune variable de l'événement."""
        return sorted(extract_tags(self.subject) - self.variable_keys())

    # --- Rendu ---

    def render_subject(self, context):
        return render_tags(self.subject, context)


class EmailLog(models.Model):
    """
    Journal d'envoi.

    Distinct de users.Notification, dont le champ `user` est obligatoire : une
    large part des e-mails part à des destinataires sans compte (prospects,
    abonnés newsletter, visiteurs du formulaire de contact, clients ayant
    réservé un rendez-vous sans s'inscrire).
    """

    STATUS_QUEUED = "queued"
    STATUS_SENT = "sent"
    STATUS_FAILED = "failed"

    STATUS_CHOICES = [
        (STATUS_QUEUED, _("En file")),
        (STATUS_SENT, _("Envoyé")),
        (STATUS_FAILED, _("Échec")),
    ]

    template_code = models.CharField(max_length=64, db_index=True, verbose_name=_("Code de l'événement"))
    to_email = models.EmailField(verbose_name=_("Destinataire"))
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="email_logs",
        verbose_name=_("Utilisateur lié"),
    )

    subject = models.CharField(max_length=255, blank=True, default="", verbose_name=_("Sujet envoyé"))
    context = models.JSONField(default=dict, blank=True, verbose_name=_("Contexte de rendu"))

    status = models.CharField(
        max_length=16,
        choices=STATUS_CHOICES,
        default=STATUS_QUEUED,
        db_index=True,
        verbose_name=_("Statut"),
    )
    queued_at = models.DateTimeField(default=timezone.now, db_index=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    error_message = models.TextField(blank=True, default="")
    attempts = models.PositiveSmallIntegerField(default=0, verbose_name=_("Tentatives"))
    # Un envoi qui échoue est retenté (services.reprendre_les_echecs). Le
    # message est gardé TEL QU'IL DEVAIT PARTIR, chiffré, le temps des essais :
    # le contexte du journal est purgé de ses liens secrets (réinitialisation,
    # paiement) et ne permet pas de le recomposer. Vidé au succès comme au
    # dernier échec.
    a_reprendre = EncryptedJSONField(default=dict, blank=True, editable=False)
    reessayer_apres = models.DateTimeField(null=True, blank=True, db_index=True, editable=False)

    class Meta:
        verbose_name = _("Envoi d'e-mail")
        verbose_name_plural = _("Envois d'e-mail")
        ordering = ["-queued_at"]
        indexes = [
            models.Index(fields=["template_code", "status"]),
            models.Index(fields=["to_email"]),
        ]

    def __str__(self):
        return f"{self.template_code} → {self.to_email} [{self.get_status_display()}]"

    def mark_sent(self):
        self.status = self.STATUS_SENT
        self.sent_at = timezone.now()
        self.error_message = ""
        self.a_reprendre, self.reessayer_apres = {}, None
        self.save(update_fields=["status", "sent_at", "error_message", "a_reprendre", "reessayer_apres"])

    def mark_failed(self, message):
        self.status = self.STATUS_FAILED
        self.error_message = str(message)[:2000]
        self.save(update_fields=["status", "error_message"])


# NEWS-01 — la newsletter (listes, abonnés, envois).
from .models_newsletter import (  # noqa: E402,F401
    Abonne, ClicNewsletter, EnvoiNewsletter, Inscription, Liste, Newsletter, ReglagesNewsletter, Sequence,
)
