# jeiko/emailing/services.py
"""
Point d'entrée unique de l'envoi d'e-mails.

Tout le reste du projet passe par `send_email(code, to, context)` : aucun appel
direct à Django n'a besoin de connaître le SMTP, le rendu ni le journal.

    from jeiko.emailing.services import send_email

    send_email(
        "appointment_confirmed",
        appointment.email,
        {"rdv_date": ..., "rdv_heure": ...},
        user=appointment.user,
    )
"""

import logging
from datetime import timedelta

from django.utils import timezone

from jeiko.emailing import registry, render as email_render, sending
from jeiko.emailing.models import EmailLog, EmailTemplate

logger = logging.getLogger(__name__)

# Nombre de tentatives avant abandon définitif d'un envoi en file.
MAX_ATTEMPTS = 3

#: Après un échec d'envoi, trois nouveaux essais, de plus en plus espacés
#: (`reprendre_les_echecs`, tâche des cinq minutes) : un serveur d'envoi
#: indisponible un quart d'heure ne fait plus perdre de message.
DELAIS_DE_REPRISE = (timedelta(minutes=5), timedelta(minutes=30), timedelta(hours=2))


class Skipped(Exception):
    """L'envoi n'a pas lieu d'être — ce n'est pas une erreur."""


def _resolve_template(code):
    if registry.get_event(code) is None:
        raise Skipped(f"Code inconnu au catalogue : {code}")

    try:
        template = EmailTemplate.objects.select_related("page").get(code=code)
    except EmailTemplate.DoesNotExist:
        raise Skipped(f"Aucun modèle configuré pour {code}")

    if not template.active:
        raise Skipped(f"Modèle {code} inactif")

    return template


def _marketing_allowed(code, user):
    """
    Les e-mails transactionnels partent toujours. Les e-mails marketing exigent
    un opt-in explicite : sans utilisateur identifié, on s'abstient.
    """
    if registry.is_transactional(code):
        return True

    if user is None:
        return False

    preferences = getattr(user, "marketing_prefs", None)
    return bool(preferences and preferences.email_optin)


def _build_context(template, context, user, destinataire=None):
    """Complète le contexte fourni avec les valeurs d'identité du site."""
    site = email_render.site_context()

    values = {
        "site_nom": site["site_name"],
        "site_url": site["site_url"],
        "logo_url": site["logo_url"],
        "contact_tel": site["contact_tel"],
        "date": timezone.localtime().strftime("%d/%m/%Y"),
        "annee": timezone.localtime().strftime("%Y"),
    }

    if user is not None:
        values.update({
            "prenom": getattr(user, "first_name", "") or "",
            "nom": getattr(user, "last_name", "") or "",
            "email": getattr(user, "email", "") or "",
        })

    # Lien de désinscription — sur les e-mails marketing UNIQUEMENT.
    #
    # Le catalogue déclarait cette variable « obligatoire sur le marketing » et
    # le gabarit affichait le lien, mais personne ne la renseignait : l'adresse
    # partait vide, et le lecteur atterrissait sur la page d'accueil.
    #
    # Rien sur les e-mails transactionnels : proposer de se désinscrire d'une
    # confirmation de commande ou d'un code de connexion n'a pas de sens, et
    # laisserait croire qu'on peut couper des messages qui ne se coupent pas.
    if not registry.is_transactional(template.code):
        adresse = destinataire or values.get("email") or getattr(user, "email", "")
        if adresse:
            from .unsubscribe import build_url

            values["lien_desabonnement"] = build_url(adresse, user)

    # Le contexte de l'appelant prime toujours.
    values.update(context or {})
    return values


def send_email(*args, **kwargs):
    """
    Rend et envoie un e-mail du catalogue — TOUJOURS dans la langue du site.

    Les e-mails ne sont écrits que dans une langue. Depuis que le site peut se
    lire en plusieurs, la requête d'un visiteur anglais porte l'anglais actif :
    sans ce retour à `LANGUAGE_CODE`, les libellés que le rendu emprunte au
    code (dates, statuts, champs de modèle) sortiraient en anglais au milieu
    d'un e-mail français. Voir `_send_email` pour le reste.
    """
    from django.conf import settings
    from django.utils import translation

    from jeiko import langues_du_site

    # … et ses liens vers les pages du site sont ceux de la langue d'origine :
    # un bouton « voir ma commande » ne doit pas mener à /en/… dans un e-mail
    # écrit en français.
    jeton = langues_du_site.fixer_la_langue(None)
    try:
        with translation.override(settings.LANGUAGE_CODE):
            return _send_email(*args, **kwargs)
    finally:
        langues_du_site.oublier_la_langue(jeton)


def _send_email(code, to, context=None, user=None, attachments=None,
                connection=None, log=None, subject_override=None, reply_to=None,
                from_email=None):
    """
    Rend et envoie un e-mail du catalogue.

    `log` permet de reprendre une entrée déjà en file plutôt que d'en créer une
    seconde ; il n'est utilisé que par `flush_queue`.

    `subject_override` remplace le sujet du modèle. Réservé aux cas où le sujet
    est déjà configuré ailleurs par l'utilisateur (ex. le champ « objet » d'un
    formulaire de contact), pour ne pas lui imposer celui du catalogue. Il accepte
    les mêmes variables [%cle%].

    Retourne (success: bool, message: str | None). Ne lève jamais : un e-mail qui
    ne part pas ne doit pas faire échouer l'action qui l'a déclenché.
    """
    try:
        template = _resolve_template(code)
    except Skipped as reason:
        # Un e-mail ORDINAIRE qu'on n'envoie pas est une décision : le modèle
        # est décoché, le catalogue ne connaît pas le code. `info` suffit.
        #
        # Un e-mail OBLIGATOIRE qu'on n'envoie pas est une panne. Sans la
        # réinitialisation de mot de passe, l'utilisateur qui l'oublie perd son
        # compte ; sans la confirmation de commande, le client n'a plus de
        # preuve d'achat. Or rien ne le signalait : le destinataire ne reçoit
        # rien, l'exploitant ne voit rien, et l'échec dormait en `info` au
        # milieu du journal.
        _consigner_l_echec(code, str(reason), log)
        return False, str(reason)

    if not _marketing_allowed(code, user):
        logger.info("E-mail %s non envoyé : pas d'opt-in marketing", code)
        if log is not None:
            log.mark_failed("Pas d'opt-in marketing")
        return False, "Pas d'opt-in marketing"

    if isinstance(to, str):
        to = [to]
    to = [address for address in (to or []) if address]
    if not to:
        return False, "Aucun destinataire"

    values = _build_context(template, context, user)
    subject, html, text, warnings = email_render.render_email(template, values)

    if subject_override:
        from jeiko.emailing.models import render_tags
        subject = render_tags(subject_override, values)
    # Le journal garde le sujet tel qu'il part (send_message le ramène sur une
    # ligne : un en-tête n'en tolère pas d'autre).
    subject = sending.sujet_sur_une_ligne(subject)

    for warning in warnings:
        logger.warning("Rendu de %s : %s", code, warning)

    if not html:
        logger.error("E-mail %s sans corps : envoi abandonné.", code)
        if log is not None:
            log.mark_failed("Aucun contenu à envoyer")
        return False, "Aucun contenu à envoyer"

    if log is None:
        log = EmailLog.objects.create(
            template_code=code,
            to_email=to[0],
            user=user if getattr(user, "pk", None) else None,
            subject=subject,
            context=contexte_consigne(values),
            attempts=1,
        )
    else:
        log.subject = subject
        # L'entrée venait de la file, avec son contexte complet : c'est le
        # moment de le purger, l'envoi n'en aura plus jamais besoin (un échec
        # n'est pas repris, voir `flush_queue`).
        log.context = contexte_consigne(values)
        log.save(update_fields=["subject", "context"])

    success, error = sending.send_message(
        subject=subject,
        text_body=text,
        html_body=html,
        to=to,
        # Une adresse d'envoi réglée à la main par l'appelant (ex. sur un
        # formulaire) prime ; sinon celle du modèle, sinon le défaut du site.
        from_email=from_email or template.from_email or None,
        # `reply_to` de l'appelant d'abord (ex. l'adresse du visiteur sur une
        # notification de formulaire), puis celui du modèle, puis le défaut
        # du site, appliqué par `send_message`.
        reply_to=(reply_to or ([template.reply_to_email] if template.reply_to_email else None)),
        attachments=attachments,
        connection=connection,
    )

    if success:
        log.mark_sent()
    else:
        _consigner_l_echec(code, error, log)
        # Une pièce jointe (facture…) ne se garde pas : ces envois-là ne sont
        # pas repris — l'écran de la pièce permet de la renvoyer.
        if not attachments:
            _programmer_la_reprise(log, {
                "sujet": subject, "texte": text, "html": html, "a": to,
                "de": from_email or template.from_email or "",
                "repondre_a": list(reply_to or ([template.reply_to_email] if template.reply_to_email else [])),
            })

    return success, error


def _programmer_la_reprise(log, message):
    rang = max(log.attempts - 1, 0)
    if rang >= len(DELAIS_DE_REPRISE):
        log.a_reprendre, log.reessayer_apres = {}, None
    else:
        log.a_reprendre, log.reessayer_apres = message, timezone.now() + DELAIS_DE_REPRISE[rang]
    log.save(update_fields=["a_reprendre", "reessayer_apres"])


def reprendre_les_echecs(limite=50):
    """
    Renvoie les e-mails en échec dont l'heure de reprise est passée, tels
    qu'ils devaient partir. Rend (envoyés, échecs).
    """
    dus = list(EmailLog.objects.filter(status=EmailLog.STATUS_FAILED,
                                       reessayer_apres__lte=timezone.now())
               .order_by("reessayer_apres")[:limite])
    if not dus:
        return 0, 0
    connection, _, _ = sending.get_mail_connection()
    if not connection:
        # Rien ne peut partir : on retentera, sans user les essais.
        return 0, 0
    envoyes = echecs = 0
    for log in dus:
        message = log.a_reprendre or {}
        if not message.get("html"):
            log.reessayer_apres = None
            log.save(update_fields=["reessayer_apres"])
            continue
        log.attempts += 1
        log.save(update_fields=["attempts"])
        ok, erreur = sending.send_message(
            subject=message["sujet"], text_body=message.get("texte", ""), html_body=message["html"],
            to=message["a"], from_email=message.get("de") or None,
            reply_to=message.get("repondre_a") or None, connection=connection,
        )
        if ok:
            log.mark_sent()
            envoyes += 1
            continue
        echecs += 1
        log.error_message = str(erreur)[:2000]
        log.save(update_fields=["error_message"])
        _programmer_la_reprise(log, message)
        if log.reessayer_apres is None:
            _consigner_l_echec(log.template_code, f"abandonné après {log.attempts} essais : {erreur}")
    return envoyes, echecs


def _consigner_l_echec(code, raison, log=None):
    """
    Journalise un échec d'envoi, au niveau que sa gravité mérite.

    La distinction n'est pas cosmétique : `logger.error` part dans le canal des
    erreurs — celui qu'on surveille, celui qui déclenche l'alerte technique —
    là où `logger.info` se noie. Un e-mail obligatoire qui ne part pas est une
    panne fonctionnelle, pas une information.

    `registry.is_mandatory` est l'autorité : c'est déjà lui qui empêche de
    décocher ces e-mails dans l'administration, et qui refuse leur
    désactivation par l'API. Une seconde liste ici divergerait.
    """
    if registry.is_mandatory(code):
        logger.error(
            "E-MAIL OBLIGATOIRE NON ENVOYÉ — %s : %s. %s",
            code, raison, registry.mandatory_reason(code),
        )
    else:
        logger.info("E-mail %s non envoyé : %s", code, raison)

    if log is not None:
        log.mark_failed(str(raison))


def queue_email(code, to, context=None, user=None):
    """
    Dépose un e-mail en file sans l'envoyer.

    Utile pour ce qui n'a pas à ralentir une requête (relances, campagnes) et
    pour ce qui est planifié (rappel de rendez-vous la veille). La commande
    `send_pending_emails` le reprendra.
    """
    if isinstance(to, str):
        to = [to]
    to = [address for address in (to or []) if address]
    if not to:
        return None

    return EmailLog.objects.create(
        template_code=code,
        to_email=to[0],
        user=user if getattr(user, "pk", None) else None,
        context=_serialisable(context or {}),
        status=EmailLog.STATUS_QUEUED,
    )


def flush_queue(limit=100):
    """
    Envoie les e-mails en file, en réutilisant une seule connexion SMTP.

    Retourne (envoyés, échecs).
    """
    pending = (
        EmailLog.objects
        .filter(status=EmailLog.STATUS_QUEUED, attempts__lt=MAX_ATTEMPTS)
        .order_by("queued_at")[:limit]
    )
    pending = list(pending)
    if not pending:
        return 0, 0

    connection, _, _ = sending.get_mail_connection()
    if not connection:
        logger.info("File d'attente non traitée : configuration email inactive.")
        return 0, 0

    sent = failed = 0
    try:
        connection.open()
        for log in pending:
            log.attempts += 1
            log.save(update_fields=["attempts"])

            # `log=log` : l'entrée en file est reprise, pas dupliquée.
            success, _ = send_email(
                log.template_code,
                log.to_email,
                context=log.context,
                user=log.user,
                connection=connection,
                log=log,
            )

            if success:
                sent += 1
            else:
                failed += 1
    finally:
        try:
            connection.close()
        except Exception:
            # Les messages sont partis ou comptés en échec : une fermeture
            # ratée ne change rien, mais se trace.
            logger.debug("Fermeture de la connexion SMTP impossible", exc_info=True)

    return sent, failed


# Ce qu'un e-mail porte et que le journal ne doit pas garder (Fable 1 §1.6).
#
# `EmailLog` conserve le contexte de rendu jusqu'à un an, pour qu'on puisse
# dire à un client ce qu'on lui a écrit. Mais ce contexte contient le code de
# double authentification, le lien de réinitialisation du mot de passe, le
# lien « définir mon mot de passe », le lien de paiement, les liens à jeton des
# questionnaires, le lien de désinscription : autant de clés d'accès valides,
# lisibles par quiconque lit la base — précisément le cas contre lequel tout
# le chiffrement du projet est justifié (`users/twofactor.py` promet « jamais
# stocké en clair »).
#
# Toutes les variables `lien*` sont retirées, et pas seulement celles qu'on
# sait secrètes aujourd'hui : un lien vers l'espace personnel ne coûte rien à
# perdre, un lien à jeton ajouté demain sans y penser coûterait cher.
#
# Ce que ça ne couvre pas : le corps HTML n'est pas conservé (il ne l'était
# pas), et un e-mail mis en file par `queue_email` garde son contexte complet
# jusqu'à son envoi — il en a besoin pour être rendu.
#
# `cle` : la clé de licence remise par `licence_delivered` (LIC-02). Gardée
# chiffrée dans la licence, elle restait EN CLAIR ici — et l'écran « Détail
# d'un envoi » la montrait à tout compte qui gère les e-mails (vérification
# du 11/10/2026, C-04).
CLES_SECRETES = frozenset({"code", "mot_de_passe", "cle"})
RETIRE_DU_JOURNAL = "[retiré du journal]"


def _est_secrete(cle):
    cle = str(cle).lower()
    return cle in CLES_SECRETES or cle.startswith("lien")


def contexte_consigne(context):
    """Le contexte tel qu'on le garde au journal : sérialisable, sans secret."""
    return {
        cle: (RETIRE_DU_JOURNAL if _est_secrete(cle) and valeur else valeur)
        for cle, valeur in _serialisable(context).items()
    }


def _serialisable(context):
    """Ne conserve du contexte que ce qui tient dans un JSONField."""
    clean = {}
    for key, value in (context or {}).items():
        if value is None or isinstance(value, (str, int, float, bool)):
            clean[key] = value
        else:
            clean[key] = str(value)
    return clean
