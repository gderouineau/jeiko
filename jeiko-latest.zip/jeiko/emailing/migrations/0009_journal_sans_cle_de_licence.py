"""
Retire du journal des envois les clés de licence déjà consignées en clair
(vérification du 11/10/2026, C-04).

Jusqu'ici, `contexte_consigne` gardait la variable `cle` de
`licence_delivered` telle quelle : chaque clé vendue sur jeiko.fr se lisait
dans `EmailLog.context`. Désormais `cle` est retirée à l'envoi ; ceci purge
ce qui a été écrit avant. Un envoi encore EN FILE garde sa clé : il en a
besoin pour être rendu, et l'envoi la retirera.
"""
from django.db import migrations

RETIRE_DU_JOURNAL = "[retiré du journal]"


def purger(apps, schema_editor):
    EmailLog = apps.get_model("emailing", "EmailLog")
    for log in EmailLog.objects.filter(template_code="licence_delivered").exclude(status="queued"):
        contexte = log.context if isinstance(log.context, dict) else {}
        if contexte.get("cle") and contexte["cle"] != RETIRE_DU_JOURNAL:
            contexte["cle"] = RETIRE_DU_JOURNAL
            log.context = contexte
            log.save(update_fields=["context"])


class Migration(migrations.Migration):
    dependencies = [
        ("emailing", "0008_licence_remise"),
    ]
    operations = [migrations.RunPython(purger, migrations.RunPython.noop)]
