"""
`quote_sent`, `invoice_sent`, `invoice_reminder` : les e-mails des devis et
factures faits à la main (FACT-01, 10/10/2026). Pose leur contenu par défaut
s'il manque, sans rien écraser.
"""
from django.db import migrations


def poser(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    for code in ("quote_sent", "invoice_sent", "invoice_reminder"):
        apply_seed(code, force=False)


class Migration(migrations.Migration):
    dependencies = [
        ("emailing", "0006_rappel_de_tache"),
        ("administration_pages", "0080_libelle_fiches"),
    ]
    operations = [migrations.RunPython(poser, migrations.RunPython.noop)]
