"""
`licence_delivered` : l'e-mail qui remet une licence JEIKO achetée sur
jeiko.fr (LIC-02, 11/10/2026). Pose son contenu par défaut s'il manque, sans
rien écraser.
"""
from django.db import migrations


def poser(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    apply_seed("licence_delivered", force=False)


class Migration(migrations.Migration):
    dependencies = [
        ("emailing", "0007_devis_et_factures"),
    ]
    operations = [migrations.RunPython(poser, migrations.RunPython.noop)]
