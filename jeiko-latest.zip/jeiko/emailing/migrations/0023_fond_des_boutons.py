from django.db import migrations

#: Le gris que `seeds.py` donne aux boutons secondaires (« Modifier ou
#: annuler », « Détail du test », « Me réinscrire »).
GRIS = "#666666"
TRANSPARENT = "rgba(255,255,255,0)"


def degriser(apps, schema_editor):
    """
    Rend transparent le bloc des boutons secondaires des e-mails déjà posés.

    `builder.build_page` donnait la couleur du bouton AUSSI à son bloc : la
    colonne entière était peinte en gris, le bouton s'y fondait (26/10/2026).
    Ne touche que la signature exacte du défaut — un bloc d'e-mail gris dont
    le bouton est du même gris : un fond choisi à la main, d'une autre
    couleur que son bouton, reste tel quel.
    """
    Bloc = apps.get_model("administration_pages", "Bloc")
    Bloc.objects.filter(
        line__section__page__is_mail_template=True,
        background_color=GRIS,
        content__content_type="BUTTON",
        content__content_button__background_color=GRIS,
    ).update(background_color=TRANSPARENT)


class Migration(migrations.Migration):

    dependencies = [
        ("emailing", "0022_texte_de_la_case_recontact"),
        ("administration_pages", "0090_libelle_du_titre_du_calendrier"),
    ]

    operations = [
        migrations.RunPython(degriser, migrations.RunPython.noop),
    ]
