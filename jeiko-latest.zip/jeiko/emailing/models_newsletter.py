# jeiko/emailing/models_newsletter.py
"""
NEWS-01 — la newsletter : des listes, leurs abonnés, et les lettres envoyées.

Rangés dans l'application `emailing` (déjà installée) plutôt que dans une
application neuve : en ajouter une obligerait à toucher le `settings.py` de
chaque site. La logique vit dans `jeiko/newsletter/`, comme le CRM.

Le problème de fond est la PREUVE. Écrire à quelqu'un sans son accord est
interdit ; il faut pouvoir montrer, pour chaque adresse et chaque liste,
quand, d'où et sur quel texte l'accord a été donné — et quand il a été
retiré. C'est ce que porte `Inscription`. Un `Abonne` sans inscription active
ne reçoit rien ; une adresse BLOQUÉE (désinscrite de tout, ou en rebond
définitif) ne reçoit plus jamais rien, même réimportée.

Ce que ce module ne fait pas : la fiche de la personne. Le contact du CRM
(`questionnaires_expert.Prospect`) et le compte se retrouvent par l'adresse,
comme le fait `jeiko.crm.historique` ; on ne recopie rien.
"""
from django.conf import settings
from django.db import models

from jeiko.encrypted import EncryptedCharField
from django.db.models import Q
from django.utils import timezone
from django.utils.translation import gettext_lazy as _


class Liste(models.Model):
    nom = models.CharField(_("Nom"), max_length=120)
    description = models.TextField(_("Description"), blank=True)
    # Une seule liste par défaut, jamais supprimée : c'est celle que visent un
    # bloc d'inscription ou un questionnaire qui n'en désignent pas d'autre.
    par_defaut = models.BooleanField(_("Liste par défaut"), default=False)
    double_opt_in = models.BooleanField(
        _("Confirmation par e-mail"), default=True,
        help_text=_("Une inscription en ligne ne compte qu'après un clic sur le lien de confirmation."),
    )
    # Visible dans « Mes newsletters » du compte client : une liste interne
    # (« Clients VIP ») n'y a pas sa place.
    proposee_aux_clients = models.BooleanField(
        _("Proposée dans le compte client"), default=True,
        help_text=_("Les clients la voient dans « Mes newsletters » et peuvent s'y inscrire eux-mêmes."),
    )
    creee_le = models.DateTimeField(_("Créée le"), auto_now_add=True)

    class Meta:
        verbose_name = _("Liste de diffusion")
        verbose_name_plural = _("Listes de diffusion")
        ordering = ["-par_defaut", "nom"]
        constraints = [
            models.UniqueConstraint(fields=["par_defaut"], condition=Q(par_defaut=True),
                                    name="newsletter_une_seule_liste_par_defaut"),
        ]

    def __str__(self):
        return self.nom

    @classmethod
    def par_defaut_du_site(cls):
        liste = cls.objects.filter(par_defaut=True).first()
        if liste is None:
            liste = cls.objects.create(nom=str(_("Newsletter")), par_defaut=True)
        return liste


class Abonne(models.Model):
    class Blocage(models.TextChoices):
        DESINSCRIT = "desinscrit", _("Désinscrit de tout")
        REBOND = "rebond", _("Adresse en échec définitif")
        PLAINTE = "plainte", _("Signalé comme indésirable")

    email = models.EmailField(_("E-mail"), unique=True)
    prenom = models.CharField(_("Prénom"), max_length=120, blank=True)
    nom = models.CharField(_("Nom"), max_length=120, blank=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
                             related_name="abonnements_newsletter", verbose_name=_("Compte"))
    cree_le = models.DateTimeField(_("Créé le"), auto_now_add=True)
    # La liste de suppression : une adresse bloquée n'est plus jamais écrite,
    # ni réinscrite par un import ou par l'administration — seule la
    # personne peut se réinscrire elle-même, en ligne.
    bloque_le = models.DateTimeField(_("Bloqué le"), null=True, blank=True)
    blocage = models.CharField(_("Motif du blocage"), max_length=16, choices=Blocage.choices, blank=True)

    class Meta:
        verbose_name = _("Abonné")
        verbose_name_plural = _("Abonnés")
        ordering = ["-cree_le"]

    def __str__(self):
        return self.email

    def save(self, *args, **kwargs):
        self.email = (self.email or "").strip().lower()
        super().save(*args, **kwargs)


class Inscription(models.Model):
    class Statut(models.TextChoices):
        EN_ATTENTE = "attente", _("En attente de confirmation")
        INSCRIT = "inscrit", _("Inscrit")
        DESINSCRIT = "desinscrit", _("Désinscrit")

    class Source(models.TextChoices):
        BLOC = "bloc", _("Formulaire du site")
        QUESTIONNAIRE = "questionnaire", _("Questionnaire")
        IMPORT = "import", _("Import")
        MANUEL = "manuel", _("Ajout dans l'administration")
        API = "api", _("API")
        COMPTE = "compte", _("Compte client")

    abonne = models.ForeignKey(Abonne, on_delete=models.CASCADE, related_name="inscriptions")
    liste = models.ForeignKey(Liste, on_delete=models.CASCADE, related_name="inscriptions")
    statut = models.CharField(_("Statut"), max_length=12, choices=Statut.choices, db_index=True)
    # --- La preuve ---
    source = models.CharField(_("Source"), max_length=16, choices=Source.choices)
    detail_source = models.CharField(_("Détail de la source"), max_length=255, blank=True,
                                     help_text=_("Page, questionnaire, fichier importé, personne qui l'a ajouté…"))
    texte_consentement = models.TextField(_("Texte du consentement"), blank=True)
    ip = models.GenericIPAddressField(_("Adresse IP"), null=True, blank=True)
    demandee_le = models.DateTimeField(_("Demandée le"), default=timezone.now)
    confirmee_le = models.DateTimeField(_("Confirmée le"), null=True, blank=True)
    desinscrite_le = models.DateTimeField(_("Désinscrite le"), null=True, blank=True)

    class Meta:
        verbose_name = _("Inscription")
        verbose_name_plural = _("Inscriptions")
        constraints = [
            models.UniqueConstraint(fields=["abonne", "liste"], name="newsletter_une_inscription_par_liste"),
        ]

    def __str__(self):
        return f"{self.abonne} → {self.liste} ({self.get_statut_display()})"


class ReglagesNewsletter(models.Model):
    """Les réglages d'envoi, une seule ligne (`du_site`)."""

    envois_par_heure = models.PositiveIntegerField(
        _("Envois par heure"), default=300,
        help_text=_("Plafond du serveur d'envoi : au-delà, l'envoi continue l'heure suivante."),
    )
    expediteur = models.CharField(_("Expéditeur"), max_length=200, blank=True,
                                  help_text=_("Vide : celui de la configuration mail du site."))
    reponse_a = models.CharField(_("Adresse de réponse"), max_length=200, blank=True)
    texte_consentement = models.TextField(
        _("Texte du consentement"), blank=True,
        default=_("J'accepte de recevoir la newsletter par e-mail. Je peux me désinscrire à tout moment "
                  "par le lien présent dans chaque envoi."),
    )
    # Les consentements recueillis à la fin d'un questionnaire (le défaut du
    # site ; chaque questionnaire peut le changer).
    questionnaire_case_email = models.BooleanField(
        _("Questionnaires : proposer la newsletter"), default=True)
    questionnaire_case_telephone = models.BooleanField(
        _("Questionnaires : proposer d'être recontacté par téléphone"), default=True)
    # La boîte qui reçoit les avis de non-remise (souvent celle de
    # l'expéditeur), relevée toutes les heures (`newsletter/rebonds.py`).
    rebonds_hote = models.CharField(_("Serveur IMAP"), max_length=200, blank=True,
                                    help_text=_("Vide : les rebonds différés ne sont pas lus."))
    rebonds_port = models.PositiveIntegerField(_("Port IMAP"), default=993)
    rebonds_utilisateur = models.CharField(_("Identifiant IMAP"), max_length=200, blank=True)
    rebonds_mot_de_passe = EncryptedCharField(_("Mot de passe IMAP"), max_length=255, blank=True)
    rebonds_dossier = models.CharField(_("Dossier"), max_length=100, default="INBOX")
    rebonds_releve_le = models.DateTimeField(_("Dernier relevé"), null=True, blank=True, editable=False)
    rebonds_erreur = models.CharField(_("Dernière erreur de relevé"), max_length=300, blank=True, editable=False)

    class Meta:
        verbose_name = _("Réglages de la newsletter")
        verbose_name_plural = _("Réglages de la newsletter")

    @classmethod
    def du_site(cls):
        reglages = cls.objects.first()
        return reglages or cls.objects.create()


class Sequence(models.Model):
    """
    Une séquence automatique : des lettres envoyées d'elles-mêmes à chaque
    nouvel inscrit d'une liste, J+0, J+3, J+7… Ses étapes sont des
    `Newsletter` (champ `sequence`) : même éditeur, même rendu, même suivi,
    même désinscription que les lettres ordinaires.

    Ne concerne que les inscriptions confirmées APRÈS l'activation
    (`active_depuis`) : allumer une séquence n'écrit pas d'un coup à toute la
    liste. Une personne désinscrite en cours de route ne reçoit plus la suite.
    """

    nom = models.CharField(_("Nom"), max_length=120)
    liste = models.ForeignKey(Liste, on_delete=models.CASCADE, related_name="sequences", verbose_name=_("Liste"))
    active = models.BooleanField(_("Active"), default=False)
    active_depuis = models.DateTimeField(_("Active depuis"), null=True, blank=True)
    creee_le = models.DateTimeField(_("Créée le"), auto_now_add=True)

    class Meta:
        verbose_name = _("Séquence automatique")
        verbose_name_plural = _("Séquences automatiques")
        ordering = ["nom"]

    def __str__(self):
        return self.nom


class Newsletter(models.Model):
    class Statut(models.TextChoices):
        BROUILLON = "brouillon", _("Brouillon")
        PROGRAMMEE = "programmee", _("Programmée")
        EN_COURS = "en_cours", _("Envoi en cours")
        ENVOYEE = "envoyee", _("Envoyée")
        ANNULEE = "annulee", _("Annulée")

    objet = models.CharField(_("Objet"), max_length=200)
    pre_entete = models.CharField(_("Texte d'aperçu"), max_length=200, blank=True,
                                  help_text=_("Affiché après l'objet dans la boîte de réception."))
    page = models.OneToOneField("administration_pages.Page", on_delete=models.SET_NULL, null=True, blank=True,
                                related_name="newsletter", verbose_name=_("Corps"))
    listes = models.ManyToManyField(Liste, related_name="newsletters", blank=True, verbose_name=_("Listes"))
    statut = models.CharField(_("Statut"), max_length=12, choices=Statut.choices,
                              default=Statut.BROUILLON, db_index=True)
    programmee_le = models.DateTimeField(_("Envoi prévu le"), null=True, blank=True)
    envoi_commence_le = models.DateTimeField(_("Envoi commencé le"), null=True, blank=True)
    envoi_termine_le = models.DateTimeField(_("Envoi terminé le"), null=True, blank=True)
    # Relier au CRM : ne viser, parmi les inscrits des listes, que ceux dont
    # la fiche de contact porte l'une de ces étiquettes, et/ou ce statut.
    etiquettes_crm = models.JSONField(_("Étiquettes du CRM"), default=list, blank=True,
                                      help_text=_("Vide : tous les inscrits des listes."))
    statut_crm = models.CharField(_("Statut du contact"), max_length=16, blank=True,
                                  help_text=_("Vide : quel que soit le statut."))
    suivi_des_clics = models.BooleanField(
        _("Compter les clics"), default=True,
        help_text=_("Les liens passent par le site, qui compte les clics. Aucun pixel d'ouverture."),
    )
    # Étape d'une séquence automatique : envoyée `delai_jours` après la
    # confirmation de l'inscription, à chaque nouvel inscrit.
    sequence = models.ForeignKey(Sequence, on_delete=models.CASCADE, null=True, blank=True,
                                 related_name="etapes", verbose_name=_("Séquence"))
    delai_jours = models.PositiveIntegerField(_("Délai (jours après l'inscription)"), default=0)
    dupliquee_de = models.ForeignKey("self", on_delete=models.SET_NULL, null=True, blank=True,
                                     related_name="copies", verbose_name=_("Copie de"))
    creee_par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
                                  related_name="+", verbose_name=_("Créée par"))
    envoyee_par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
                                    related_name="+", verbose_name=_("Envoyée par"))
    creee_le = models.DateTimeField(_("Créée le"), auto_now_add=True)
    modifiee_le = models.DateTimeField(_("Modifiée le"), auto_now=True)

    class Meta:
        verbose_name = _("Newsletter")
        verbose_name_plural = _("Newsletters")
        ordering = ["-creee_le"]

    def __str__(self):
        return self.objet

    @property
    def modifiable(self):
        return self.statut in (self.Statut.BROUILLON, self.Statut.PROGRAMMEE)


class EnvoiNewsletter(models.Model):
    """Une ligne par destinataire : c'est le suivi, et la garde contre le doublon."""

    class Statut(models.TextChoices):
        A_ENVOYER = "a_envoyer", _("À envoyer")
        ENVOYE = "envoye", _("Envoyé")
        ECHEC = "echec", _("Échec")
        IGNORE = "ignore", _("Écarté")

    newsletter = models.ForeignKey(Newsletter, on_delete=models.CASCADE, related_name="envois")
    abonne = models.ForeignKey(Abonne, on_delete=models.SET_NULL, null=True, blank=True, related_name="envois")
    email = models.EmailField(_("Destinataire"))
    statut = models.CharField(_("Statut"), max_length=12, choices=Statut.choices,
                              default=Statut.A_ENVOYER, db_index=True)
    envoye_le = models.DateTimeField(_("Envoyé le"), null=True, blank=True)
    erreur = models.CharField(_("Erreur"), max_length=500, blank=True)
    clics = models.PositiveIntegerField(_("Clics"), default=0)
    premier_clic_le = models.DateTimeField(_("Premier clic le"), null=True, blank=True)
    desinscrit_le = models.DateTimeField(_("Désinscrit le"), null=True, blank=True)

    class Meta:
        verbose_name = _("Envoi de newsletter")
        verbose_name_plural = _("Envois de newsletter")
        constraints = [
            models.UniqueConstraint(fields=["newsletter", "email"], name="newsletter_un_envoi_par_adresse"),
        ]


class ClicNewsletter(models.Model):
    envoi = models.ForeignKey(EnvoiNewsletter, on_delete=models.CASCADE, related_name="clics_detail")
    url = models.URLField(_("Lien"), max_length=1000)
    le = models.DateTimeField(_("Le"), auto_now_add=True)

    class Meta:
        verbose_name = _("Clic")
        verbose_name_plural = _("Clics")
