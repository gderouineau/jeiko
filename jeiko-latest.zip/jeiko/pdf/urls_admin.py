from django.urls import path

from . import vues_admin

app_name = "jeiko_pdf_admin"

urlpatterns = [
    path("", vues_admin.documents, name="documents"),
    path("creer/", vues_admin.creer, name="creer"),
    path("<int:page_id>/apercu/", vues_admin.apercu, name="apercu"),
]
