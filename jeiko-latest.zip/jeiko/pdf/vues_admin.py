"""
Pages › Documents PDF (D-11) : la liste, la création, l'aperçu.

Le contenu se construit dans l'éditeur des pages ; publier, renommer et
supprimer passent par les écrans des pages, qui savent déjà le faire. Cet
écran ne fait que ce qu'aucun autre ne fait : lister les documents, en créer
un, et montrer le PDF tel qu'il sortira.
"""

import logging

from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.translation import gettext as _
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_POST

from .documents import adresse_publique, creer_document
from .moteur import MoteurPDFAbsent, disponible
from .pages import page_en_pdf

logger = logging.getLogger(__name__)


@login_required
@permission_required("administration_pages.view_page", raise_exception=True)
@never_cache
def documents(request):
    from jeiko.administration_pages.models import Page
    from jeiko.listes import paginer

    liste, pagination = paginer(request, Page.objects.filter(is_pdf=True).order_by("title", "langue", "pk"))
    for page in liste:
        page.adresse_pdf = adresse_publique(page)
    return render(request, "pdf/admin/documents.html", {
        **pagination, "documents": liste, "moteur_disponible": disponible(),
    })


@login_required
@permission_required("administration_pages.add_page", raise_exception=True)
@require_POST
def creer(request):
    titre = (request.POST.get("titre") or "").strip()[:200]
    if not titre:
        messages.error(request, _("Donnez un titre au document."))
        return redirect("jeiko_pdf_admin:documents")
    page = creer_document(titre)
    return redirect("jeiko_administration_pages:page_editor", page.pk)


@login_required
@permission_required("administration_pages.view_page", raise_exception=True)
@never_cache
def apercu(request, page_id):
    """Le PDF tel qu'il sortira — brouillon compris, publié ou non."""
    from jeiko.administration_pages.models import Page

    page = get_object_or_404(Page.editables, pk=page_id, is_pdf=True)
    try:
        contenu = page_en_pdf(page)
    except MoteurPDFAbsent:
        messages.error(request, _("Le serveur ne sait pas encore produire de PDF : lancez « Mettre à jour le serveur JEIKO »."))
        return redirect("jeiko_pdf_admin:documents")
    reponse = HttpResponse(contenu, content_type="application/pdf")
    reponse["Content-Disposition"] = f'inline; filename="{page.url_tag or "document"}.pdf"'
    return reponse
