"""
Les documents PDF construits dans l'éditeur (D-11) : création, copie en ligne.

Un document est une `Page` marquée `is_pdf` : l'éditeur, les blocs, les
versions par langue et l'API des agents la traitent comme toute page. Elle
n'est jamais servie en HTML (`querysets.TEMPLATE_ONLY_FLAGS`) ; publiée, elle
se télécharge à `/pdf/<url_tag>.pdf`.
"""

import hashlib

from django.db import transaction
from django.urls import reverse
from django.utils.text import slugify

from .pages import html_de_la_page, html_en_pdf_de


def adresse_publique(page):
    """L'adresse du PDF en ligne, ou "" si la page n'est pas un document publié."""
    if not (page.is_pdf and page.active and page.url_tag):
        return ""
    return reverse("jeiko_pdf:document", args=[page.url_tag])


@transaction.atomic
def creer_document(titre):
    from jeiko.administration_pages.fabrique import creer_section
    from jeiko.administration_pages.models import Page

    from django.core.exceptions import ValidationError

    page = Page(title=titre, is_pdf=True, show_default_main_menu=False,
                show_default_footer=False, google_index=False, active=False)
    # L'adresse vient du titre ; prise (par une page, une catégorie, une route
    # du système), elle reçoit un numéro : créer un document ne doit jamais
    # échouer pour une question d'adresse que l'on n'a pas choisie.
    base = slugify(titre)[:140] or "document"
    for n in range(1, 100):
        page.url_tag = base if n == 1 else f"{base}-{n}"
        try:
            page.clean()
            break
        except ValidationError:
            continue
    page.save()
    # Une première section vide : l'éditeur s'ouvre sur un document à remplir,
    # pas sur une page blanche sans prise.
    creer_section(page)
    return page


def document_en_ligne(url_tag):
    """Le document publié à cette adresse : la version d'origine d'abord."""
    from jeiko.administration_pages.models import Page

    return (Page.objects.filter(url_tag=url_tag, is_pdf=True, active=True)
            .order_by("langue", "pk").first())


def pdf_du_document(page) -> bytes:
    """Le PDF d'un document en ligne, refait seulement si son HTML a changé.

    Lève `MoteurPDFAbsent`.
    """
    from .models import CopiePdf

    html = html_de_la_page(page)
    empreinte = hashlib.sha256(html.encode("utf-8")).hexdigest()
    copie = CopiePdf.objects.filter(page=page, empreinte=empreinte).only("contenu").first()
    if copie is not None:
        return bytes(copie.contenu)
    # ponytail: deux visiteurs au même instant après une modification rendent
    # chacun le PDF ; le second écrase le premier, à l'identique. Un verrou
    # n'aurait de sens que pour un document téléchargé en rafale à la seconde.
    contenu = html_en_pdf_de(html)
    CopiePdf.objects.update_or_create(page=page, defaults={"empreinte": empreinte, "contenu": contenu})
    return contenu
