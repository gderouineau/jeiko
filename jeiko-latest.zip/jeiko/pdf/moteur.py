"""
Le moteur PDF de JEIKO (D-10) : du HTML rendu par Django, en PDF.

Le problème
-----------
La facture n'existait qu'en page imprimable : « Enregistrer en PDF » du
navigateur. Rien ne pouvait donc partir en pièce jointe d'un e-mail, ni être
téléchargé d'un clic. Les certificats de formation (D-05) et les restitutions
de questionnaire (D-12) attendent le même moteur.

Pourquoi WeasyPrint
-------------------
Il lit le HTML et le CSS que les gabarits écrivent déjà — le PDF est la page,
pas un second dessin à tenir à jour. Il demande une bibliothèque système,
Pango : l'installeur la pose (`03_check_dependencies.sh`).

Ce que le moteur va chercher : RIEN
-----------------------------------
WeasyPrint suit les `<img>`, `<link>` et `url()` du document, y compris vers
n'importe quelle adresse. Un document qui embarque un texte saisi par un
visiteur (un nom, une adresse) deviendrait une porte vers le réseau interne du
serveur (SSRF). Le moteur n'admet que le protocole `data:` : un gabarit PDF
embarque ses images et ses polices, ou s'en passe.

Ce que ça ne fait pas
---------------------
* Un site dont le serveur n'a pas Pango (installeur pas encore repassé) n'a
  pas de PDF : `MoteurPDFAbsent`, que l'appelant traite — la page imprimable
  reste, l'e-mail part sans pièce jointe. Le site, lui, démarre.
* Les pages construites dans l'éditeur passent par `pages.py` (D-11).
"""

import logging

logger = logging.getLogger(__name__)


class MoteurPDFAbsent(Exception):
    """WeasyPrint, ou Pango sous lui, n'est pas installé sur ce serveur."""


def disponible() -> bool:
    try:
        import weasyprint  # noqa: F401
    except (ImportError, OSError):
        return False
    return True


def html_en_pdf(html: str, base_url=None, url_fetcher=None, zoom=1) -> bytes:
    """Le PDF d'un document HTML complet. Lève `MoteurPDFAbsent`.

    Sans `url_fetcher`, seul `data:` est lu. Celui des pages de l'éditeur
    (`pages._lecteur`) lit aussi les fichiers du site, sur le disque.
    """
    try:
        from weasyprint import HTML
        from weasyprint.urls import URLFetcher
    except (ImportError, OSError) as souci:
        # OSError : le paquet est là, mais pas Pango (bibliothèque système).
        raise MoteurPDFAbsent(str(souci)) from souci
    if url_fetcher is None:
        url_fetcher = URLFetcher(allowed_protocols={"data"})
    return HTML(string=html, base_url=base_url, url_fetcher=url_fetcher).write_pdf(zoom=zoom)


def gabarit_en_pdf(gabarit: str, contexte: dict) -> bytes:
    from django.template.loader import render_to_string

    return html_en_pdf(render_to_string(gabarit, contexte))
