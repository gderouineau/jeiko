from django.db import models
from django.utils.translation import gettext_lazy as _


class CopiePdf(models.Model):
    """
    Le dernier PDF rendu d'un document en ligne (D-11), gardé en base.

    Pourquoi en base et pas dans le cache : le cache du site est un memcached,
    qui refuse sans bruit tout objet de plus d'un mégaoctet — la taille d'un
    PDF illustré. Le document serait alors refait à CHAQUE téléchargement :
    quelques secondes de calcul par visite, à la portée de quiconque recharge
    la page. Ici il n'est refait que lorsque son HTML change (`empreinte`).
    """

    page = models.OneToOneField("administration_pages.Page", on_delete=models.CASCADE,
                                related_name="copie_pdf")
    #: sha256 du HTML rendu : la page, le thème, une adresse, une image
    #: remplacée — tout ce qui change le document change l'empreinte.
    empreinte = models.CharField(max_length=64)
    contenu = models.BinaryField()
    rendu_le = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Copie d'un document PDF")
