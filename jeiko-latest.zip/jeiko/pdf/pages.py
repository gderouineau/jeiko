"""
Une page de l'éditeur, en PDF (D-11).

Le problème
-----------
Un document à télécharger — une plaquette, un guide offert, un programme de
formation — se faisait hors du site, dans un traitement de texte, puis
s'envoyait comme une image figée. `Page.is_pdf` était prévu depuis le début et
ne servait qu'à écarter ces pages du site. Ici, une page marquée PDF se
construit dans l'éditeur comme n'importe quelle page, avec les mêmes blocs, et
sort en PDF à son adresse `/pdf/<url_tag>.pdf`.

Le même rendu que le site
-------------------------
Ce sont les gabarits du site (`section.html` et ses styles) qui écrivent le
document : ce que l'éditeur montre est ce que le PDF imprime. Deux écarts,
voulus :

* Les règles `@media` de largeur sont tranchées pour un écran d'ordinateur
  (`LARGEUR_ECRAN`). WeasyPrint les évaluerait contre la largeur de la feuille
  — 180 mm, soit la mise en page TÉLÉPHONE, colonnes empilées : le PDF
  n'aurait pas ressemblé à ce qu'on a construit.
  La feuille est donc mise en page à cette largeur (`@page` de
  `pdf/page.html`), puis réduite à l'A4 (`zoom`) : 1 200 px de site tiennent
  dans 210 mm, comme une capture d'écran qu'on imprime.
* Ni menu, ni pied de page, ni script : une feuille n'exécute rien.

Ce que le moteur va chercher
----------------------------
Toujours rien sur le réseau (voir `moteur.py`, SSRF) : les adresses du site
sous `STATIC_URL` et `MEDIA_URL` sont lues SUR LE DISQUE, à l'intérieur de
leur dossier ; toute autre adresse est refusée. Une image collée depuis un
autre site ne s'imprime donc pas — la médiathèque, si.

Ce que ça ne fait pas
---------------------
* Les blocs animés (diaporama, onglets, compte à rebours…) s'impriment dans
  leur état de départ : le premier visuel, le premier onglet. L'éditeur d'une
  page PDF ne les propose pas (`content_types.groups_for`).
* Une vidéo n'est qu'un cadre vide : même raison.
"""

import os
import re

from django.conf import settings
from django.template.loader import render_to_string

from .moteur import html_en_pdf

#: Largeur d'écran pour laquelle les règles `@media` sont tranchées : celle
#: d'un ordinateur, la mise en page que l'on construit dans l'éditeur.
LARGEUR_ECRAN = 1200

#: La feuille A4 en px CSS (96 px par pouce) : 210 mm de large, 297 de haut.
LARGEUR_A4 = 793.7
HAUTEUR_A4 = 1122.5

#: Hôte fictif des adresses relatives du document : seul cet hôte est lu, et
#: seulement sur le disque.
_HOTE = "https://document.jeiko.invalid"

_MEDIA = re.compile(r"@media\s*([^{]+?)\s*\{", re.IGNORECASE)
_CONDITION = re.compile(r"\(\s*(min|max)-width\s*:\s*(\d+(?:\.\d+)?)px\s*\)", re.IGNORECASE)


def trancher_les_media(css: str, largeur: int = LARGEUR_ECRAN) -> str:
    """Les `@media` faits seulement de conditions de largeur en px, tranchés
    pour `largeur` : `@media all`, ou `@media speech` qui ne vaut jamais pour
    une feuille. WeasyPrint ne lit que des TYPES de média — ni `not all`, ni
    une condition de largeur : il écarte la règle entière, avertissement au
    journal. Les autres requêtes restent telles quelles (donc écartées)."""

    def _remplacer(m):
        requete = m.group(1)
        reste = _CONDITION.sub("", requete)
        if re.sub(r"\band\b|screen|all|\s", "", reste, flags=re.IGNORECASE):
            return m.group(0)  # orientation, hover, print… : WeasyPrint juge
        if not _CONDITION.search(requete):
            return m.group(0)
        vrai = all(
            (largeur >= float(n)) if sens.lower() == "min" else (largeur <= float(n))
            for sens, n in _CONDITION.findall(requete)
        )
        return "@media all {" if vrai else "@media speech {"

    return _MEDIA.sub(_remplacer, css)


def _fichier_local(url: str):
    """Le fichier du disque qu'une adresse du site désigne, ou None."""
    if not url.startswith(_HOTE + "/"):
        return None
    chemin = url[len(_HOTE):].split("?", 1)[0].split("#", 1)[0]
    from urllib.parse import unquote

    chemin = unquote(chemin)
    candidats = []
    if chemin.startswith(settings.MEDIA_URL):
        candidats.append((settings.MEDIA_ROOT, chemin[len(settings.MEDIA_URL):]))
    elif chemin.startswith(settings.STATIC_URL):
        relatif = chemin[len(settings.STATIC_URL):]
        if settings.STATIC_ROOT:
            candidats.append((settings.STATIC_ROOT, relatif))
        from django.contrib.staticfiles import finders

        trouve = finders.find(relatif)
        if trouve:
            candidats.append((os.path.dirname(trouve), os.path.basename(trouve)))
    for racine, relatif in candidats:
        racine = os.path.realpath(racine)
        fichier = os.path.realpath(os.path.join(racine, relatif))
        # Un `..` dans l'adresse ne sort pas du dossier.
        if fichier.startswith(racine + os.sep) and os.path.isfile(fichier):
            return fichier
    return None


def _lecteur():
    """Le `url_fetcher` de WeasyPrint : `data:` ou un fichier du site, rien d'autre."""
    import mimetypes

    from weasyprint.urls import URLFetcher, URLFetcherResponse

    class LecteurDuSite(URLFetcher):
        def fetch(self, url, headers=None):
            if url.startswith("data:"):
                return super().fetch(url, headers)
            fichier = _fichier_local(url)
            if fichier is None:
                raise ValueError(f"ressource refusée : {url[:200]}")
            with open(fichier, "rb") as f:
                contenu = f.read()
            type_mime = mimetypes.guess_type(fichier)[0] or "application/octet-stream"
            if type_mime == "text/css":
                contenu = trancher_les_media(contenu.decode("utf-8", "replace")).encode("utf-8")
            return URLFetcherResponse(url, contenu, {"Content-Type": type_mime})

    return LecteurDuSite(allowed_protocols={"data", "https"})


def _requete_anonyme():
    """Une requête de visiteur anonyme, pour les gabarits du site qui lisent
    `request`. Jamais celle de l'administrateur qui télécharge : le PDF est
    le même pour tous, sans les commandes de l'éditeur ni ce qu'il voit seul."""
    from django.contrib.auth.models import AnonymousUser
    from django.test import RequestFactory

    requete = RequestFactory().get("/")
    requete.user = AnonymousUser()
    return requete


def html_du_gabarit(gabarit, contexte=None, largeur=LARGEUR_ECRAN, paysage=False) -> str:
    """Un gabarit qui étend `pdf/base.html`, rendu pour une feuille de
    `largeur` px — A4 debout, ou couchée si `paysage`. `pdf` vaut vrai dans le
    contexte : un partiel du site y reconnaît qu'il s'imprime (le graphique
    devient des barres)."""
    rapport = (210 / 297) if paysage else (297 / 210)
    html = render_to_string(gabarit, {
        "largeur": largeur, "hauteur": round(largeur * rapport), "pdf": True,
        **(contexte or {})}, request=_requete_anonyme())
    return trancher_les_media(html, largeur)


def html_de_la_page(page, contexte=None) -> str:
    from jeiko.administration_pages.querysets import with_page_tree

    page = with_page_tree().select_related("traduction_de").get(pk=page.pk)
    return html_du_gabarit("pdf/page.html", {"page": page, **(contexte or {})})


def html_en_pdf_de(html: str, largeur=LARGEUR_ECRAN, paysage=False) -> bytes:
    """Le PDF d'un HTML produit par `html_du_gabarit`. Lève `MoteurPDFAbsent`."""
    return html_en_pdf(html, base_url=_HOTE + "/", url_fetcher=_lecteur(),
                       zoom=(HAUTEUR_A4 if paysage else LARGEUR_A4) / largeur)


def page_en_pdf(page, contexte=None) -> bytes:
    """Le PDF d'une page de l'éditeur, `[%cle%]` remplacées par `contexte`.

    Lève `MoteurPDFAbsent`."""
    return html_en_pdf_de(html_de_la_page(page, contexte))


def gabarit_en_pdf(gabarit, contexte=None, largeur=LARGEUR_ECRAN, paysage=False) -> bytes:
    """Le PDF d'un gabarit qui étend `pdf/base.html`. Lève `MoteurPDFAbsent`."""
    return html_en_pdf_de(html_du_gabarit(gabarit, contexte, largeur, paysage), largeur, paysage)
