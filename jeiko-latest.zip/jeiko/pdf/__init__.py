"""
PDF de JEIKO : le moteur (`moteur.py`, D-10), les pages de l'éditeur en PDF
(`pages.py`) et les documents à télécharger qu'on y construit (`documents.py`,
D-11) ; la restitution de questionnaire (D-12) et le certificat de formation
(D-05) s'en servent.
"""
