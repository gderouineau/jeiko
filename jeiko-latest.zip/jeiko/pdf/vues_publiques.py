"""Le téléchargement public d'un document PDF en ligne (D-11) : /pdf/<url_tag>.pdf."""

import logging

from django.http import Http404, HttpResponse
from django.utils.translation import gettext as _

from .documents import document_en_ligne, pdf_du_document
from .moteur import MoteurPDFAbsent

logger = logging.getLogger(__name__)


def document(request, url_tag):
    page = document_en_ligne(url_tag)
    if page is None:
        raise Http404
    try:
        contenu = pdf_du_document(page)
    except MoteurPDFAbsent:
        logger.error("Document PDF %s demandé, mais le serveur n'a pas de moteur PDF.", page.pk)
        return HttpResponse(_("Ce document est momentanément indisponible."), status=503,
                            content_type="text/plain; charset=utf-8")
    reponse = HttpResponse(contenu, content_type="application/pdf")
    # `inline` : le navigateur l'ouvre ; son bouton l'enregistre sous ce nom.
    reponse["Content-Disposition"] = f'inline; filename="{page.url_tag}.pdf"'
    if not page.google_index:
        reponse["X-Robots-Tag"] = "noindex"
    return reponse
