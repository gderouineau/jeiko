from django.urls import path

from . import vues_publiques

app_name = "jeiko_pdf"

urlpatterns = [
    path("<slug:url_tag>.pdf", vues_publiques.document, name="document"),
]
