"""
Les modèles de site, vus par un agent (TPL-01, 12/10/2026).

Monter un site de zéro, page par page, prend une longue série d'appels. Un
modèle pose d'un coup un site complet pour un métier — pages, menu, pied de
page, types de rendez-vous, couleurs et polices — que l'agent adapte ensuite
avec les routes habituelles. Mêmes règles que l'écran Pages › Modèles de site
(administration_pages/modeles_de_site.py) : rien n'est supprimé, les pages en
ligne passent hors ligne, l'état d'avant est journalisé.

Le droit demandé est celui de modifier le site (`administration.change_website`) :
poser un modèle change l'accueil, les menus et, si on le demande, le thème.
"""
from django.conf import settings

from jeiko.administration_pages import modeles_de_site

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR = "administration.view_website"
MODIFIER = "administration.change_website"


class ListeDesModelesDeSite(VueAgent):
    permission_requise = VOIR

    def get(self, request):
        from django.templatetags.static import static

        modeles = modeles_de_site.catalogue(settings.LANGUAGE_CODE)
        for m in modeles:
            # L'aperçu (TPL-02) : une adresse qu'on peut ouvrir, ou null.
            m["apercu"] = request.build_absolute_uri(static(m["apercu"])) if m["apercu"] else None
        return ok({"modeles": modeles})


class AppliquerUnModeleDeSite(VueAgent):
    permission_requise = VOIR

    def post(self, request):
        if not request.user.has_perm(MODIFIER):
            return erreur("Poser un modèle demande le droit de modifier le site.", statut=403,
                          permission_manquante=MODIFIER)
        corps = self.corps(request, connues={"modele", "couleurs"})
        if not corps.get("modele"):
            raise CorpsInvalide("« modele » est obligatoire : sa clé, lue dans GET /modeles-de-site/.")
        try:
            rapport = modeles_de_site.appliquer(
                str(corps["modele"]), settings.LANGUAGE_CODE,
                avec_couleurs=bool(corps.get("couleurs", True)), par=request.user)
        except modeles_de_site.ModeleInvalide as souci:
            raise CorpsInvalide(str(souci))
        return ok({"rapport": rapport}, statut=201)
