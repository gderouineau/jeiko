"""
Les réglages de base du site, vus par une IA qui le monte de zéro (07/10/2026).

Le besoin (Guillaume) : « quand on fabrique un site du commencement, l'IA va
voir ce qu'il y a à faire dans les réglages de base — cela permettra d'avoir
un site qui fonctionne ». Une seule lecture lui dit donc :

* `a_faire` — la liste « À finir de configurer » de Réglages › Général, la
  même, calculée comme pour un administrateur qui aurait TOUS les droits :
  l'IA doit voir ce qui manque même quand elle ne peut pas le faire — elle le
  dit alors à la personne ;
* `reglages` — l'état de chaque réglage de base ;
* pour chacun, OÙ le régler : la route de l'API, ou l'écran quand il est
  sensible.

Ce qu'une IA peut modifier ici (`PATCH`) : le logo et le favicon (une image de
la médiathèque), les textes du bandeau cookies de la langue du site, et les
MODULES montrés dans le menu de l'administration (MOD-01 — boutique,
rendez-vous, formations, questionnaires : les masquer ne supprime rien). Le reste
a déjà sa route (identité, langues, pages, menus, pages d'erreur).

Ce qui reste à l'ÉCRAN, à dessein : tout ce qui porte un secret ou engage le
site au-delà de son contenu — serveur d'e-mails (mot de passe), moyens de
paiement (clés), API Google et connexions sociales (clés), mise à jour
automatique, partage des rapports d'erreur. La lecture dit seulement s'ils
sont faits, jamais leur valeur.
"""

from django.core.files.base import ContentFile
from django.db import transaction

from jeiko.administration.models import Favicon, Logo, WebSite
from jeiko.administration.modules import MODULES, etat_des_modules

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR = "administration.view_website"
MODIFIER = "administration.change_website"

#: Où se règle chaque entrée de la liste « À finir de configurer ».
API_POUR = {
    "jeiko_administration:logo_update": "PATCH /reglages/ {\"logo\": id d'image}",
    "jeiko_administration:favicon_update": "PATCH /reglages/ {\"favicon\": id d'image}",
    "jeiko_administration:site_identity": "PATCH /identite/ {\"nom_du_site\", \"coordonnees\"}",
    "jeiko_administration_pages:main": "POST /pages/creer/, puis PATCH /pages/<id>/ {\"publiee\": true}",
    "jeiko_administration_pages:pages_erreur": "PATCH /pages/erreurs/",
}

#: Les textes du bandeau cookies qu'on peut écrire.
TEXTES_DU_BANDEAU = ("message_text", "accept_all_label", "refuse_all_label", "customize_label",
                     "save_choices_label", "more_info_label")


class _TousLesDroits:
    """Un administrateur imaginaire qui a tous les droits : voir TOUT ce qui manque."""
    is_staff = is_superuser = True

    def has_perm(self, perm):
        return True


def _bandeau():
    from django.contrib.sites.models import Site

    from jeiko.cookies.models import CookieBannerConfig, default_locale

    return (CookieBannerConfig.objects.filter(site=Site.objects.get_current(), locale=default_locale())
            .order_by("-is_active", "priority").first())


def _etat(site):
    from jeiko.administration.dashboard import setup_checklist
    from jeiko.administration.models import Legals, MailSettings
    from jeiko.administration_pages.models import Page
    from jeiko.payments.models import PaymentGateway

    legales = Legals.objects.filter(site=site).first()
    mail = MailSettings.objects.first()
    bandeau = _bandeau()
    a_faire = [
        {"a_faire": i["label"], "pourquoi": i["hint"], "ecran": i["url"],
         "api": API_POUR.get(i.get("code"), "à l'écran seulement (réglage sensible) : le demander à la personne")}
        for i in setup_checklist(_TousLesDroits(), site)
    ]
    return {
        "a_faire": [{k: str(v) for k, v in item.items()} for item in a_faire],
        "reglages": {
            "nom_du_site": {"valeur": site.name, "api": "PATCH /identite/"},
            "logo": {"fait": bool(site.logo_id and site.logo.full_size), "api": "PATCH /reglages/"},
            "favicon": {"fait": bool(site.favicon_id and site.favicon.png_32), "api": "PATCH /reglages/"},
            "identite": {"fait": bool(getattr(getattr(site, "identity", None), "name", "")),
                         "api": "GET/PATCH /identite/"},
            "langues": {"multilingue": site.multilingue, "langues": site.langues_du_site or [],
                        "api": "GET/PATCH /langues/"},
            "accueil": {"page": Page.objects.filter(is_root=True).values_list("pk", flat=True).first(),
                        "api": "GET/PATCH /pages/<id>/"},
            "pages_publiees": Page.objects.filter(active=True, langue="").count(),
            "pages_d_erreur": {"choisies": {str(c): getattr(site, f"page_{c}_id") for c in (404, 403, 500, 400)},
                               "api": "GET/PATCH /pages/erreurs/"},
            "pages_legales": {
                "pages": {cle: getattr(legales, f"{cle}_page_id", None) if legales else None
                          for cle in ("mentions", "privacy", "cgv", "cgu")},
                "api": "le contenu : routes des pages (/pages/<id>/sections/…) — pages protégées, jamais supprimées",
            },
            "bandeau_cookies": {
                "textes": {cle: getattr(bandeau, cle) for cle in TEXTES_DU_BANDEAU} if bandeau else None,
                "api": "PATCH /reglages/ {\"bandeau_cookies\": {…}}",
            },
            "serveur_email": {"fait": bool(mail and (mail.host or "").strip()),
                              "api": "à l'écran seulement : il porte un mot de passe"},
            "paiement": {"fait": PaymentGateway.objects.filter(is_active=True).exists(),
                         # STRIPE-01 : actif ne veut pas dire branché (webhook).
                         "stripe": _branchement_stripe(),
                         "api": "à l'écran seulement : il porte des clés (Paiements › Stripe, qui dit aussi quoi déclarer chez Stripe)"},
            "notifications": {"valeurs": _notifications(site),
                              "api": "PATCH /reglages/ {\"notifications\": {\"stock_bas\": false}} — les pastilles du menu de l'administration, une à une"},
            "modules": {"valeurs": etat_des_modules(site),
                        "api": "PATCH /reglages/ {\"modules\": {\"boutique\": true}} — masque ou montre la section dans le menu de l'administration, rien d'autre"},
            "mise_a_jour_auto": {"valeur": site.mise_a_jour_auto, "api": "à l'écran seulement"},
            "partage_des_erreurs": {"valeur": site.partager_les_erreurs, "api": "à l'écran seulement"},
        },
    }


def _notifications(site):
    from jeiko.administration.notifications import actives

    return actives(site)


def _branchement_stripe():
    from jeiko.payments.branchement import resume
    from jeiko.payments.models import PaymentGateway

    passerelle = PaymentGateway.objects.filter(code="stripe").first()
    return resume(passerelle) if passerelle else None


def _image(identifiant, cle):
    """Le fichier d'une image de la médiathèque, pour en faire un logo ou un favicon."""
    from jeiko.administration_pages.models import ImageContent

    if not isinstance(identifiant, int) or isinstance(identifiant, bool):
        raise CorpsInvalide(f"« {cle} » attend l'identifiant d'une image de la médiathèque (GET /images/).")
    image = ImageContent.objects.filter(pk=identifiant).first()
    fichier = image and (image.original_image or image.full_size)
    if not fichier:
        raise CorpsInvalide(f"« {cle} » : aucune image ne porte l'identifiant {identifiant}.")
    with fichier.open("rb") as source:
        return fichier.name.rsplit("/", 1)[-1], source.read()


class ReglagesDeBase(VueAgent):
    """
    `GET` : ce qui reste à faire, l'état des réglages de base, où régler chacun.
    `PATCH {"logo": 12, "favicon": 13, "bandeau_cookies": {"message_text": "…"}}` :
    partiel ; une clé absente ne change pas.
    """

    permission_requise = VOIR

    def get(self, request):
        return ok(_etat(WebSite.objects.first()))

    @transaction.atomic
    def patch(self, request):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification des réglages non autorisée.", statut=403, permission_manquante=MODIFIER)
        corps = self.corps(request, connues={"logo", "favicon", "bandeau_cookies", "modules", "notifications"})
        site = WebSite.objects.select_for_update().first()

        if "logo" in corps:
            nom, octets = _image(corps["logo"], "logo")
            logo = site.logo or Logo.objects.create()
            logo.full_size.save(nom, ContentFile(octets), save=False)
            logo.save()  # fabrique les variantes (ordinateur, tablette, téléphone)
            site.logo = logo
        if "favicon" in corps:
            nom, octets = _image(corps["favicon"], "favicon")
            favicon = site.favicon or Favicon.objects.create()
            favicon.source.save(nom, ContentFile(octets), save=False)
            favicon.save()  # fabrique les PNG 32 et 180
            site.favicon = favicon
        if "logo" in corps or "favicon" in corps:
            site.save(update_fields=["logo", "favicon"])

        if "modules" in corps:
            modules = corps["modules"]
            if (not isinstance(modules, dict) or set(modules) - set(MODULES)
                    or not all(isinstance(v, bool) for v in modules.values())):
                raise CorpsInvalide(f"« modules » : un objet {{code: true|false}}, codes parmi {', '.join(MODULES)}.")
            for code, actif in modules.items():
                setattr(site, MODULES[code][0], actif)
            site.save(update_fields=[MODULES[code][0] for code in modules])

        if "notifications" in corps:
            from jeiko.administration.notifications import NOTIFICATIONS, actives

            notes = corps["notifications"]
            if (not isinstance(notes, dict) or set(notes) - set(NOTIFICATIONS)
                    or not all(isinstance(v, bool) for v in notes.values())):
                raise CorpsInvalide(f"« notifications » : un objet {{code: true|false}}, codes parmi {', '.join(NOTIFICATIONS)}.")
            site.notifications = {**actives(site), **notes}
            site.save(update_fields=["notifications"])

        if "bandeau_cookies" in corps:
            textes = corps["bandeau_cookies"]
            if not isinstance(textes, dict) or set(textes) - set(TEXTES_DU_BANDEAU):
                raise CorpsInvalide(f"« bandeau_cookies » : un objet dont les clés sont parmi {', '.join(TEXTES_DU_BANDEAU)}.")
            bandeau = _bandeau()
            if bandeau is None:
                raise CorpsInvalide("Aucun bandeau cookies : ouvrez une fois Réglages › Cookies pour le créer.")
            for cle, valeur in textes.items():
                if not isinstance(valeur, str) or (cle != "message_text" and len(valeur) > 80):
                    raise CorpsInvalide(f"« {cle} » : un texte (80 caractères au plus, sauf le message).")
                setattr(bandeau, cle, valeur.strip())
            bandeau.save(update_fields=list(textes))
        return ok(_etat(site))
