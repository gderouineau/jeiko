"""
Devis, factures et avoirs par l'API (FACT-01, 10/10/2026).

Les mêmes opérations que l'écran, par les mêmes fonctions (`shop.pieces`) :
préparer un brouillon et ses lignes, l'émettre, transformer un devis en
facture, demander un acompte, enregistrer un règlement, créer un avoir.

Ce que l'API ne fait pas, et pourquoi
-------------------------------------
**Envoyer, exporter, supprimer** — la doctrine du CRM (`vues_contacts`) :
une fiche client peut porter un texte écrit par un visiteur ; lu par un
agent, il pourrait contenir des instructions. Aucune route ne fait donc
partir une pièce par e-mail ni ne sort un export : l'envoi au client se
fait à l'écran (« Envoyer au client »), par une personne. Pas de liste
complète non plus : une recherche, vingt pièces au plus.

Permissions : `shop.view_piecedevente` pour lire ; `add_piecedevente` pour
créer ; `change_piecedevente` pour modifier un brouillon et agir. Aucun rôle
d'agent par défaut ne les porte : elles se donnent sur l'écran des rôles.
"""
from decimal import Decimal, InvalidOperation

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404

from jeiko.shop import pieces
from jeiko.shop.models import LigneDePiece, PieceDeVente, Product, Reglement, ShopSettings, TaxRate

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR = "shop.view_piecedevente"
AJOUTER = "shop.add_piecedevente"
MODIFIER = "shop.change_piecedevente"

RESULTATS_MAX = 20

#: Le vocabulaire de l'API → les champs de la pièce.
CHAMPS_PIECE = {
    "objet": "objet", "client_nom": "client_nom", "client_adresse": "client_adresse",
    "client_email": "client_email", "client_tva": "client_tva", "notes": "notes",
    "contact_id": "contact_id", "entreprise_id": "entreprise_id",
    "echeance": "date_echeance", "validite": "date_validite", "relances": "relances_actives",
}

#: Les actions, et les clés que chacune accepte en plus de « action ».
ACTIONS = {
    "emettre": set(), "facturer": set(), "accepte": set(), "refuse": set(), "avoir": set(),
    "acompte": {"pourcentage"},
    "reglement": {"montant", "date", "moyen", "reference"},
}


def _date(d):
    return d.isoformat() if d else None


def piece_en_dict(p, complet=True):
    donnees = {
        "id": p.id, "nature": p.nature, "type": p.type_facture, "numero": p.numero or None,
        "etat": p.etat, "en_retard": p.en_retard, "objet": p.objet,
        "client": {"nom": p.client_nom, "email": p.client_email, "contact_id": p.contact_id,
                   "entreprise_id": p.entreprise_id},
        "emise_le": _date(p.date_emission), "echeance": _date(p.date_echeance), "validite": _date(p.date_validite),
        "devise": p.devise, "total_ht": str(p.total_ht), "total_ttc": str(p.total_ttc),
    }
    if p.nature == PieceDeVente.FACTURE:
        donnees["reste_a_payer"] = str(p.reste_a_payer)
    if complet:
        donnees.update({
            "client": {**donnees["client"], "adresse": p.client_adresse, "tva": p.client_tva},
            "notes": p.notes, "relances": p.relances_actives, "origine_id": p.origine_id,
            "suites": list(p.suites.values_list("id", flat=True)),
            "lignes": [{"libelle": l.libelle, "quantite": str(l.quantite), "unite": l.unite,
                        "prix_unitaire_ht": str(l.prix_unitaire_ht), "taux_tva": str(l.taux_tva),
                        "produit_id": l.produit_id} for l in p.lignes.all()],
            "reglements": [{"date": _date(r.date), "montant": str(r.montant), "moyen": r.moyen,
                            "reference": r.reference} for r in p.reglements.all()],
        })
    return donnees


def _nombre(valeur, cle, rang):
    try:
        nombre = Decimal(str(valeur).replace(",", "."))
    except (InvalidOperation, ValueError):
        raise CorpsInvalide(f"Ligne nº {rang} : « {cle} » attend un nombre — reçu {valeur!r}.")
    if not nombre.is_finite():
        raise CorpsInvalide(f"Ligne nº {rang} : « {cle} » attend un nombre fini.")
    return nombre


def _lignes(brut):
    """Valide TOUTES les lignes avant d'écrire quoi que ce soit."""
    if not isinstance(brut, list):
        raise CorpsInvalide("« lignes » est une liste.")
    proposes = set(TaxRate.objects.filter(is_active=True).values_list("rate", flat=True))
    defaut = ShopSettings.get_solo().default_tax_rate
    pretes = []
    for rang, l in enumerate(brut, start=1):
        if not isinstance(l, dict):
            raise CorpsInvalide(f"Ligne nº {rang} : un objet est attendu.")
        inconnues = sorted(set(l) - {"libelle", "quantite", "unite", "prix_unitaire_ht", "taux_tva", "produit_id"})
        if inconnues:
            raise CorpsInvalide(f"Ligne nº {rang} — clé(s) inconnue(s) : {', '.join(inconnues)}.")
        produit = None
        if l.get("produit_id"):
            produit = Product.objects.filter(pk=l["produit_id"]).first()
            if produit is None:
                raise CorpsInvalide(f"Ligne nº {rang} : aucun produit nº {l['produit_id']}.")
        libelle = str(l.get("libelle") or (produit.title if produit else "")).strip()
        if not libelle:
            raise CorpsInvalide(f"Ligne nº {rang} : une « libelle », ou un « produit_id ».")
        prix = _nombre(l["prix_unitaire_ht"], "prix_unitaire_ht", rang) if "prix_unitaire_ht" in l \
            else (produit.price_ht if produit else Decimal("0"))
        taux = _nombre(l["taux_tva"], "taux_tva", rang) if "taux_tva" in l \
            else (produit.tax_rate if produit else defaut)
        if proposes and Decimal(taux).quantize(Decimal("0.01")) not in proposes:
            raise CorpsInvalide(f"Ligne nº {rang} : le taux {taux} n'est pas un taux du site. Proposés : "
                                + ", ".join(f"{t.normalize():f}" for t in sorted(proposes)) + ".")
        quantite = _nombre(l.get("quantite", 1), "quantite", rang)
        pretes.append(dict(position=rang - 1, libelle=libelle[:5000], quantite=quantite,
                           unite=str(l.get("unite") or "")[:20], prix_unitaire_ht=prix, taux_tva=taux,
                           produit=produit))
    return pretes


def _appliquer(piece, corps):
    for cle, champ in CHAMPS_PIECE.items():
        if cle in corps:
            setattr(piece, champ, corps[cle] if corps[cle] is not None else ("" if champ not in (
                "contact_id", "entreprise_id", "date_echeance", "date_validite") else None))
    try:
        piece.full_clean(exclude=["jeton", "numero"])
    except ValidationError as souci:
        raise CorpsInvalide("; ".join(f"{k} : {' '.join(v)}" for k, v in souci.message_dict.items()))
    piece.save()
    if "lignes" in corps:
        pretes = _lignes(corps["lignes"])
        piece.lignes.all().delete()
        for ligne in pretes:
            LigneDePiece.objects.create(piece=piece, **ligne)


class ListeDesPieces(VueAgent):
    permission_requise = VOIR

    def get(self, request):
        qs = PieceDeVente.objects.all()
        if request.GET.get("nature"):
            qs = qs.filter(nature=request.GET["nature"])
        if request.GET.get("etat") == "en_retard":
            from django.utils import timezone

            qs = qs.filter(nature=PieceDeVente.FACTURE, date_echeance__lt=timezone.localdate(),
                           etat__in=(PieceDeVente.EMISE, PieceDeVente.PAYEE_EN_PARTIE))
        elif request.GET.get("etat"):
            qs = qs.filter(etat=request.GET["etat"])
        q = (request.GET.get("q") or "").strip()
        if q:
            qs = qs.filter(Q(numero__icontains=q) | Q(client_nom__icontains=q) | Q(objet__icontains=q))
        return ok({"pieces": [piece_en_dict(p, complet=False) for p in qs.prefetch_related("lignes")[:RESULTATS_MAX]],
                   "plafond": RESULTATS_MAX})


class CreationDePiece(VueAgent):
    permission_requise = AJOUTER

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request, connues={"nature", "lignes", *CHAMPS_PIECE})
        nature = corps.get("nature")
        if nature not in (PieceDeVente.DEVIS, PieceDeVente.FACTURE):
            raise CorpsInvalide("« nature » vaut « devis » ou « facture » (un avoir naît d'une facture : action « avoir »).")
        piece = PieceDeVente(nature=nature, devise=ShopSettings.get_solo().currency, cree_par=request.user)
        _appliquer(piece, corps)
        return ok({"piece": piece_en_dict(piece)}, statut=201)


class DetailDePiece(VueAgent):
    permission_requise = VOIR

    def get(self, request, piece_id):
        return ok({"piece": piece_en_dict(get_object_or_404(PieceDeVente, pk=piece_id))})

    @transaction.atomic
    def patch(self, request, piece_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification non autorisée.", statut=403)
        piece = get_object_or_404(PieceDeVente, pk=piece_id)
        if piece.est_figee or piece.etat not in (PieceDeVente.BROUILLON, PieceDeVente.EMISE):
            return erreur("Cette pièce est émise : elle ne se modifie plus. Une facture se corrige par un avoir.",
                          statut=409)
        _appliquer(piece, self.corps(request, connues={"lignes", *CHAMPS_PIECE}))
        return ok({"piece": piece_en_dict(piece)})


class ActionSurPiece(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, piece_id):
        piece = get_object_or_404(PieceDeVente, pk=piece_id)
        corps = self.corps(request, connues={"action", *set().union(*ACTIONS.values())})
        action = corps.get("action")
        if action not in ACTIONS:
            raise CorpsInvalide(f"« action » parmi : {', '.join(ACTIONS)}.")
        inconnues = sorted(set(corps) - {"action"} - ACTIONS[action])
        if inconnues:
            raise CorpsInvalide(f"Pour « {action} », clé(s) inconnue(s) : {', '.join(inconnues)}.")
        try:
            nee = self._faire(piece, action, corps)
        except ValidationError as souci:
            return erreur(" ".join(souci.messages), statut=409)
        piece.refresh_from_db()
        reponse = {"piece": piece_en_dict(piece)}
        if nee is not None:
            reponse["piece_creee"] = piece_en_dict(nee)
        return ok(reponse)

    def _faire(self, piece, action, corps):
        if action == "emettre":
            pieces.emettre(piece)
        elif action == "facturer":
            return pieces.transformer_en_facture(piece)
        elif action == "acompte":
            try:
                return pieces.creer_acompte(piece, Decimal(str(corps.get("pourcentage"))))
            except (InvalidOperation, ValueError):
                raise ValidationError("« pourcentage » attend un nombre entre 0 et 100.")
        elif action == "reglement":
            from datetime import date

            moyen = corps.get("moyen") or Reglement.VIREMENT
            if moyen not in dict(Reglement.MOYENS):
                raise ValidationError(f"« moyen » parmi : {', '.join(dict(Reglement.MOYENS))}.")
            try:
                jour = date.fromisoformat(corps["date"]) if corps.get("date") else None
                montant = Decimal(str(corps.get("montant")))
            except (InvalidOperation, ValueError, TypeError):
                raise ValidationError("« montant » est un nombre, « date » s'écrit AAAA-MM-JJ.")
            pieces.enregistrer_reglement(piece, montant, moyen, reference=str(corps.get("reference") or "")[:120],
                                         date=jour)
        elif action == "avoir":
            return pieces.avoir_de(piece)
        elif action == "accepte":
            return pieces.accepter(piece, self.request.user.get_username())
        elif action == "refuse":
            pieces.refuser(piece)
        return None
