"""
La visio pilotée par un agent (VISIO-01) : séances, invitations, chat, serveur.

Un agent prépare une séance (titre, format, horaires, salle d'attente,
qualité), invite — et envoie, s'il le demande, l'e-mail avec le lien
personnel —, révoque un lien, lit le chat et la présence. Il n'ENTRE jamais
dans une salle : un lien d'invitation est donné pour être transmis à une
personne, pas suivi par l'agent.

Droits : ceux du modèle `Salle` (voir, ajouter, modifier, supprimer), comme
l'écran Conférence.
"""
import logging

from django.db.models import Q
from django.shortcuts import get_object_or_404
from django.urls import reverse
from django.utils import timezone

from jeiko.visio import acces, emails, livekit, vente
from jeiko.visio.models import Invitation, Salle

from .vues_api import CorpsInvalide, VueAgent, erreur, ok
from .vues_calendrier import _instant

logger = logging.getLogger(__name__)

VOIR, AJOUTER, MODIFIER, SUPPRIMER = "visio.view_salle", "visio.add_salle", "visio.change_salle", "visio.delete_salle"

CHAMPS_SALLE = {"titre", "format", "debut", "fin", "description", "ouverture_avant", "salle_d_attente",
                "verrouillee", "rappels", "qualite", "son",
                "inscriptions", "places", "prix", "liste_d_attente", "remboursement"}


def _refus(permission):
    return erreur("Opération non autorisée.", statut=403, permission_manquante=permission)


def _invitation_en_dict(request, i):
    return {
        "id": i.pk, "nom": i.nom, "email": i.email, "role": i.role,
        "compte": i.user_id, "contact": i.contact_id,
        "lien": request.build_absolute_uri(i.get_absolute_url()) if not i.revoquee else None,
        "revoquee": i.revoquee, "envoyee_le": i.envoyee_le.isoformat() if i.envoyee_le else None,
        "arrivee_le": i.arrivee_le.isoformat() if i.arrivee_le else None,
        "sortie_le": i.sortie_le.isoformat() if i.sortie_le else None,
        "inscrite": i.inscrite, "montant_paye": str(i.montant_paye), "commande": i.commande_id,
        "desinscrite_le": i.desinscrite_le.isoformat() if i.desinscrite_le else None,
    }


def _salle_en_dict(request, s, *, detail=False):
    donnees = {
        "id": s.pk, "titre": s.titre, "format": s.format, "description": s.description,
        "debut": s.debut.isoformat(), "fin": s.fin.isoformat(), "ouverture_avant": s.ouverture_avant,
        "salle_d_attente": s.salle_d_attente, "verrouillee": s.verrouillee, "rappels": s.rappels,
        "qualite": s.qualite, "son": s.son,
        "terminee_le": s.terminee_le.isoformat() if s.terminee_le else None,
        "nb_invites": s.invitations_actives().count(),
        "inscriptions": s.inscriptions, "places": s.places, "prix": str(s.prix),
        "liste_d_attente": s.liste_d_attente, "remboursement": s.remboursement, "produit": s.produit_id,
    }
    if s.inscriptions:
        donnees["lien_public"] = request.build_absolute_uri(reverse("jeiko_visio:seance", args=[s.jeton_public]))
        donnees["places_restantes"] = vente.places_restantes(s)
        donnees["inscrits"] = s.invitations_actives().filter(inscrite=True).count()
        donnees["en_attente"] = s.attentes.count()
    if detail:
        from jeiko.visio.suivi import presence

        donnees["invitations"] = [{**_invitation_en_dict(request, ligne["invitation"]), "venue": ligne["venue"],
                                   "minutes_presentes": ligne["minutes"]} for ligne in presence(s)]
        donnees["nb_messages"] = s.messages.count()
        donnees["sondages"] = [{"id": p.pk, "question": p.question, "choix": p.choix, "plusieurs": p.plusieurs,
                                "etat": p.etat, "resultats": p.resultats(), "votants": p.votes.count()}
                               for p in s.sondages.prefetch_related("votes")]
        donnees["fichiers"] = [{"id": f.pk, "nom": f.nom, "taille": f.taille, "depose_le": f.depose_le.isoformat(),
                                "depose_par": f.auteur.nom if f.auteur_id else ""}
                               for f in s.fichiers.select_related("auteur")]
        donnees["attente"] = [{"nom": a.nom, "email": a.email, "depuis": a.cree_le.isoformat(),
                               "prevenue_le": a.prevenue_le.isoformat() if a.prevenue_le else None}
                              for a in s.attentes.all()]
    return donnees


def _ecrire(salle, corps):
    for champ in ("titre", "description"):
        if champ in corps:
            setattr(salle, champ, str(corps[champ] or "").strip())
    for champ, choix in (("format", Salle.Format), ("qualite", Salle.Qualite), ("son", Salle.Son)):
        if champ in corps:
            if corps[champ] not in choix.values:
                raise CorpsInvalide(f"« {champ} » : une valeur parmi {', '.join(choix.values)}.")
            setattr(salle, champ, corps[champ])
    for champ in ("debut", "fin"):
        if champ in corps:
            setattr(salle, champ, _instant(corps[champ], champ))
    if "ouverture_avant" in corps:
        minutes = corps["ouverture_avant"]
        if not isinstance(minutes, int) or not 0 <= minutes <= 24 * 60:
            raise CorpsInvalide("« ouverture_avant » : un nombre de minutes entre 0 et 1440.")
        salle.ouverture_avant = minutes
    for champ in ("salle_d_attente", "verrouillee", "rappels"):
        if champ in corps:
            setattr(salle, champ, bool(corps[champ]))
    for champ in ("inscriptions", "liste_d_attente"):
        if champ in corps:
            setattr(salle, champ, bool(corps[champ]))
    if "places" in corps:
        places = corps["places"]
        if places is not None and (not isinstance(places, int) or isinstance(places, bool) or not 1 <= places <= 50):
            raise CorpsInvalide("« places » : un nombre entre 1 et 50, ou null.")
        salle.places = places
    if "prix" in corps:
        from decimal import Decimal, InvalidOperation

        try:
            prix = Decimal(str(corps["prix"])).quantize(Decimal("0.01"))
        except InvalidOperation:
            prix = Decimal("-1")
        if prix < 0 or isinstance(corps["prix"], bool):
            raise CorpsInvalide("« prix » : un montant TTC, 0 ou plus.")
        salle.prix = prix
    if "remboursement" in corps:
        try:
            salle.remboursement = vente.valider_la_grille(corps["remboursement"])
        except (ValueError, TypeError):
            raise CorpsInvalide("« remboursement » : une liste de paliers [heures, pourcentage], "
                                "par exemple [[48, 100], [24, 50]].")
    if not salle.titre:
        raise CorpsInvalide("« titre » est obligatoire.")
    if not (salle.debut and salle.fin) or salle.fin <= salle.debut:
        raise CorpsInvalide("« debut » et « fin » sont obligatoires, la fin après le début.")
    return salle


class Seances(VueAgent):
    """Les séances à venir (ou passées avec ?passees=1)."""

    permission_requise = VOIR

    def get(self, request):
        maintenant = timezone.now()
        if request.GET.get("passees") in ("1", "true"):
            salles = Salle.objects.filter(Q(fin__lt=maintenant) | Q(terminee_le__isnull=False)).order_by("-debut")
        else:
            salles = Salle.objects.filter(fin__gte=maintenant, terminee_le__isnull=True).order_by("debut")
        return ok({"seances": [_salle_en_dict(request, s) for s in salles[:200]],
                   "visio_installee": livekit.est_configure()})


class CreationSeance(VueAgent):
    permission_requise = AJOUTER

    def post(self, request):
        corps = self.corps(request, connues=CHAMPS_SALLE | {"hote"})
        salle = _ecrire(Salle(), corps)
        hote = None
        if corps.get("hote"):
            from django.contrib.auth import get_user_model

            hote = get_user_model().objects.filter(pk=corps["hote"], is_active=True).first()
            if hote is None:
                raise CorpsInvalide("« hote » : aucun compte actif avec cet identifiant.")
        champs = {c: getattr(salle, c) for c in CHAMPS_SALLE - {"titre", "debut", "fin"}}
        salle = acces.creer_salle(titre=salle.titre, debut=salle.debut, fin=salle.fin, cree_par=hote, **champs)
        vente.synchroniser(salle)
        return ok({"seance": _salle_en_dict(request, salle, detail=True)}, statut=201)


class DetailSeance(VueAgent):
    permission_requise = VOIR

    def get(self, request, seance_id):
        return ok({"seance": _salle_en_dict(request, get_object_or_404(Salle, pk=seance_id), detail=True)})

    def patch(self, request, seance_id):
        if not request.user.has_perm(MODIFIER):
            return _refus(MODIFIER)
        salle = _ecrire(get_object_or_404(Salle, pk=seance_id), self.corps(request, connues=CHAMPS_SALLE))
        salle.save()
        vente.synchroniser(salle)
        return ok({"seance": _salle_en_dict(request, salle, detail=True)})

    def delete(self, request, seance_id):
        if not request.user.has_perm(SUPPRIMER):
            return _refus(SUPPRIMER)
        salle = get_object_or_404(Salle, pk=seance_id)
        try:
            livekit.fermer(salle.identifiant_livekit)
        except livekit.LiveKitIndisponible as panne:
            # Jamais ouverte, ou serveur arrêté : la supprimer ici suffit.
            logger.info("Visio : fermeture de la salle %s non transmise — %s", salle.pk, panne)
        salle.delete()
        return ok({"supprime": True})


class Inviter(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, seance_id):
        salle = get_object_or_404(Salle, pk=seance_id)
        corps = self.corps(request, connues={"email", "nom", "role", "compte", "envoyer"})
        role = corps.get("role", Invitation.Role.PARTICIPANT)
        if role not in Invitation.Role.values:
            raise CorpsInvalide(f"« role » : une valeur parmi {', '.join(Invitation.Role.values)}.")
        user = None
        if corps.get("compte"):
            from django.contrib.auth import get_user_model

            user = get_user_model().objects.filter(pk=corps["compte"], is_active=True).first()
            if user is None:
                raise CorpsInvalide("« compte » : aucun compte actif avec cet identifiant.")
        if not (user or corps.get("email")):
            raise CorpsInvalide("« email » ou « compte » est obligatoire.")
        try:
            invitation = acces.inviter(salle, nom=str(corps.get("nom") or ""), email=str(corps.get("email") or ""),
                                       role=role, user=user)
        except acces.Refus as refus:
            return erreur(str(refus), statut=409)
        reponse = {"invitation": _invitation_en_dict(request, invitation)}
        if corps.get("envoyer"):
            reponse["envoyee"], reponse["raison"] = emails.envoyer_l_invitation(invitation)
        return ok(reponse, statut=201)


class DetailInvitation(VueAgent):
    """POST : renvoyer le lien par e-mail (en corrigeant l'adresse) ; DELETE : révoquer le lien."""

    permission_requise = MODIFIER

    def post(self, request, seance_id, invitation_id):
        invitation = get_object_or_404(Invitation, pk=invitation_id, salle_id=seance_id, revoquee_le__isnull=True)
        corps = self.corps(request, obligatoire=False, connues={"email"})
        if corps.get("email"):
            from django.core.exceptions import ValidationError
            from django.core.validators import validate_email

            try:
                validate_email(corps["email"])
            except ValidationError:
                raise CorpsInvalide("« email » n'est pas une adresse valable.")
            invitation.email = str(corps["email"]).strip().lower()
            invitation.save(update_fields=["email"])
        envoyee, raison = emails.envoyer_l_invitation(invitation)
        return ok({"envoyee": envoyee, "raison": raison})

    def delete(self, request, seance_id, invitation_id):
        invitation = get_object_or_404(Invitation, pk=invitation_id, salle_id=seance_id)
        acces.revoquer(invitation)
        try:
            livekit.retirer(invitation.salle.identifiant_livekit, invitation.identite)
        except livekit.LiveKitIndisponible as panne:
            # Hors de la salle, ou serveur arrêté : le lien est révoqué, c'est l'essentiel.
            logger.info("Visio : retrait de %s non transmis — %s", invitation.identite, panne)
        return ok({"invitation": _invitation_en_dict(request, invitation)})


class EcrireAuxInvites(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, seance_id):
        from jeiko.visio.suivi import ecrire_aux_invites

        salle = get_object_or_404(Salle, pk=seance_id)
        corps = self.corps(request, connues={"destinataires", "objet", "message"})
        objet, message = str(corps.get("objet") or "").strip()[:200], str(corps.get("message") or "").strip()[:5000]
        if not (objet and message):
            raise CorpsInvalide("« objet » et « message » sont obligatoires.")
        destinataires = corps.get("destinataires", "absents")
        if destinataires not in ("absents", "presents", "tous"):
            raise CorpsInvalide("« destinataires » : absents, presents ou tous.")
        return ok({"envoyes": ecrire_aux_invites(salle, objet=objet, message=message, destinataires=destinataires)})


class PreparerSondage(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, seance_id):
        from jeiko.visio import sondages

        salle = get_object_or_404(Salle, pk=seance_id)
        corps = self.corps(request, connues={"question", "choix", "plusieurs"})
        if not isinstance(corps.get("choix"), list):
            raise CorpsInvalide("« choix » : une liste de 2 à 8 textes.")
        try:
            sondage = sondages.preparer(salle, corps.get("question"), corps["choix"], corps.get("plusieurs"))
        except acces.Refus as refus:
            raise CorpsInvalide(str(refus))
        return ok({"sondage": sondage.en_donnees(avec_resultats=True)}, statut=201)


class ChatDeLaSeance(VueAgent):
    permission_requise = VOIR

    def get(self, request, seance_id):
        salle = get_object_or_404(Salle, pk=seance_id)
        return ok({"messages": [m.en_donnees() for m in salle.messages.order_by("envoye_le", "pk")[:500]]})


class ServeurDeVisio(VueAgent):
    permission_requise = VOIR

    def get(self, request):
        etat = {"installee": livekit.est_configure(), "max_participants": livekit.MAX_PARTICIPANTS,
                "enregistrement": False}
        if etat["installee"]:
            try:
                etat["salles_ouvertes"] = livekit.tester()
                etat["repond"] = True
            except livekit.LiveKitIndisponible as panne:
                etat["repond"], etat["erreur"] = False, str(panne)
        return ok(etat)
