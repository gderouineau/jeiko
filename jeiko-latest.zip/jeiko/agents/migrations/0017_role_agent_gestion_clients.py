# jeiko/agents/migrations/0017_role_agent_gestion_clients.py
"""
Rôle « Agent gestion clients » — chercher un client, tenir sa fiche, lui
prendre un rendez-vous (26/10/2026).

Pourquoi un rôle à part
-----------------------
« Cherche tel contact, puis prends-lui un rendez-vous jeudi à 14 h, en
visio » : aucun rôle livré ne le permettait. Le CRM et les rendez-vous pris
sont des données personnelles ; « Agent calendrier » gère l'offre (types,
disponibilités) sans voir qui a réservé, « Agent agenda (lecture) » lit sans
écrire. Celui-ci voit, crée et modifie — c'est ce que Guillaume a demandé.

Ce qu'il porte : voir, créer et modifier un contact, lire et écrire ses notes
(les tâches suivent le droit de modifier) ; voir, créer et modifier un
rendez-vous ; lire les types de rendez-vous et les créneaux, sans quoi on ne
sait pas quoi réserver.

Ce qu'il ne porte pas : aucune suppression, aucun export en masse (l'API ne
liste pas les contacts, elle cherche), aucun envoi d'une note.

Peuplé dès sa création, permissions forcées d'abord : le piège réparé par 0011.
"""

from django.db import migrations

SLUG = "agent-gestion-clients"
NOM = "Agent gestion clients"

PERMISSIONS = {
    "questionnaires_expert": ("view_prospect", "add_prospect", "change_prospect", "view_contact_notes"),
    "calendars": ("view_appointment", "add_appointment", "change_appointment",
                  "view_appointmenttype", "view_availability"),
}


def creer_le_role(apps, schema_editor):
    from django.apps import apps as registre_reel
    from django.contrib.auth.management import create_permissions

    for app_label in PERMISSIONS:
        create_permissions(registre_reel.get_app_config(app_label), verbosity=0)

    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role, _ = Role.objects.get_or_create(
        slug=SLUG,
        defaults={
            "name": NOM,
            "description": (
                "Permet à un agent de chercher, créer et modifier les contacts du CRM, leurs notes et "
                "leurs tâches, et de leur prendre ou modifier un rendez-vous, en visio ou non. "
                "Données personnelles. N'autorise NI la suppression, NI l'export."
            ),
            "is_active": True,
        },
    )
    for app_label, codenames in PERMISSIONS.items():
        for codename in codenames:
            permission = Permission.objects.filter(
                codename=codename, content_type__app_label=app_label
            ).first()
            if permission is not None:
                RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer_le_role(apps, schema_editor):
    apps.get_model("users", "Role").objects.filter(slug=SLUG).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0016_role_agent_formations"),
        ("calendars", "0023_type_en_visio"),
        ("questionnaires_expert", "0026_texte_de_la_case_recontact"),
        ("users", "0001_initial"),
    ]

    operations = [migrations.RunPython(creer_le_role, retirer_le_role)]
