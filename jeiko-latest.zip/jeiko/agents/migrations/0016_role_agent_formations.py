# jeiko/agents/migrations/0016_role_agent_formations.py
"""
Rôle « Agent formations » — construire une formation, pas lire ses inscrits.

Pourquoi un rôle à part
-----------------------
Une formation voisine des données personnelles : inscriptions, progression,
tentatives de quiz, attestations. Même raison que pour les questionnaires :
fondre ces droits dans « Agent éditeur de pages » aurait donné à toute clé
d'édition ce voisinage.

Ce qu'il porte : voir, créer et modifier une formation — l'administration ne
demande rien de plus pour ses parties, chapitres et sections — et envoyer une
image dans la médiathèque, pour l'image de présentation.

Ce qu'il ne porte pas : aucune suppression (elle emporte la progression des
inscrits), aucun accès aux inscriptions — aucune route ne les expose.

Peuplé dès sa création, permissions forcées d'abord : le piège réparé par 0011.
"""

from django.db import migrations

SLUG = "agent-formations"
NOM = "Agent formations"

PERMISSIONS = {
    "courses": ("view_course", "add_course", "change_course"),
    "administration_pages": ("view_imagecontent", "add_imagecontent"),
}


def creer_le_role(apps, schema_editor):
    from django.apps import apps as registre_reel
    from django.contrib.auth.management import create_permissions

    for app_label in PERMISSIONS:
        create_permissions(registre_reel.get_app_config(app_label), verbosity=0)

    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role, _ = Role.objects.get_or_create(
        slug=SLUG,
        defaults={
            "name": NOM,
            "description": (
                "Permet à un agent de construire des formations par l'API : "
                "parties, chapitres, sections (texte, vidéo, PDF, quiz). "
                "N'autorise NI la suppression, NI l'accès aux inscriptions."
            ),
            "is_active": True,
        },
    )
    for app_label, codenames in PERMISSIONS.items():
        for codename in codenames:
            permission = Permission.objects.filter(
                codename=codename, content_type__app_label=app_label
            ).first()
            if permission is not None:
                RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer_le_role(apps, schema_editor):
    apps.get_model("users", "Role").objects.filter(slug=SLUG).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0015_clients_et_codes_oauth"),
        ("courses", "0007_code_d_attestation"),
        ("users", "0001_initial"),
    ]

    operations = [migrations.RunPython(creer_le_role, retirer_le_role)]
