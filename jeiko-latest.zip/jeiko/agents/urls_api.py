# jeiko/agents/urls_api.py
"""
Routes de l'API des agents.

Aucune route de suppression de page : voir l'en-tête de `vues_pages.py`. Ce
n'est pas un oubli, c'est la règle — et son absence ici est la première des
deux barrières.
"""

from . import vues_boutique, vues_cookies, vues_facturation, vues_formations, vues_newsletter, vues_visio
from django.urls import path

from .vues_api import Contrats, Guide, QuiSuisJe, RouteApiInconnue
from .vues_objets import (
    CreationModele, CreationObjet, CreationProduit, CreationTypeDeProduit,
    DetailModele, DetailObjet, DetailProduit, DetailTypeDeProduit,
    ListeDesModeles, ListeDesObjets, ListeDesProduits, ListeDesTypesDeProduit,
    VersionsDeLObjet,
)
from .vues_contacts import (
    ContactsARelancer, CreationDEntreprise, CreationDeContact, DetailDEntreprise,
    ModificationDuContact, NotesDuContact, RechercheDEntreprises, RechercheDeContacts,
    TacheDuContact, TachesDuContact,
)
from .vues_calendrier import (
    CreationDisponibilite, CreationTypeDeRdv, DetailDisponibilite,
    DetailTypeDeRdv, ListeDesCreneaux, BloquerDesPlaces, CreditsDeSeance, ListeDesDisponibilites,
    ListeDesRendezVous, ListeDesTypesDeRdv, CreationDeRendezVous, DetailDuRendezVous,
)
from .vues_identite import Identite
from .vues_reglages import PagesLegales, ReglagesDeBase
from .vues_modeles_de_site import AppliquerUnModeleDeSite, ListeDesModelesDeSite
from .vues_historique import HistoriqueDeLaPage
from .vues_langues import Langues, VersionsDeLaPage
from .vues_menus import (
    CreationMenu, DetailMenu, ListeDesMenus, MenusDeLaCategorie,
)
from .vues_emails import (
    CreationEmail, DetailEmail, ListeDesEmails, ListeDesEvenements,
    RapportsDActivite,
)
from .vues_questionnaires import (
    CombinaisonsDuQuestionnaire, CreationQuestionnaire, DetailCombinaison,
    DetailProfil, DetailQuestion, DetailQuestionnaire, DetailReponse,
    ListeDesQuestionnaires, ProfilsDuQuestionnaire, QuestionsDuQuestionnaire,
    SimulationDuResultat,
)
from .vues_pages import (
    BlocsDeLaLigne, ConstructionDeLigne, ConstructionDePage, DuplicationDePage, DuplicationDeSection, ConstructionDeSection,
    ContenuDuBloc, CreationCategorie, CreationDePage, Deplacement,
    DetailBloc, DetailLigne, DetailPage, DetailSection, LignesDeLaSection,
    CreationImage, DetailCategorie, ListeDesCategories, ListeDesImages, ListeDesPages,
    MesuresDeLaPage, PagesDErreur,
    SectionsDeLaPage,
)

app_name = "jeiko_agents_api"

urlpatterns = [
    # Le mode d'emploi, à la racine ET nommé : c'est le premier appel qu'un
    # agent doit faire, et il ne doit pas avoir à le chercher.
    path("", Guide.as_view(), name="guide"),
    path("guide/", Guide.as_view(), name="guide_explicite"),
    # La forme exacte de chaque appel (voir contrats.py).
    path("contrats/", Contrats.as_view(), name="contrats"),

    # Vérifier son jeton et découvrir ses droits.
    path("qui-suis-je/", QuiSuisJe.as_view(), name="whoami"),

    # Pages — lecture, création, modification. Jamais de suppression.
    path("pages/", ListeDesPages.as_view(), name="pages"),
    path("pages/creer/", CreationDePage.as_view(), name="page_creer"),
    path("pages/erreurs/", PagesDErreur.as_view(), name="pages_erreur"),
    path("pages/<int:page_id>/", DetailPage.as_view(), name="page"),
    path("pages/<int:page_id>/sections/", SectionsDeLaPage.as_view(), name="page_sections"),
    path("pages/<int:page_id>/construire/", ConstructionDePage.as_view(), name="page_construire"),
    path("pages/<int:page_id>/dupliquer/", DuplicationDePage.as_view(), name="page_dupliquer"),
    # Site en plusieurs langues : la version d'une page dans une langue, et le
    # réglage des langues du site. Voir vues_langues.py.
    path("pages/<int:page_id>/versions/", VersionsDeLaPage.as_view(), name="page_versions"),
    path("pages/<int:page_id>/historique/", HistoriqueDeLaPage.as_view(), name="page_historique"),
    path("langues/", Langues.as_view(), name="langues"),
    # Ce que Google mesure. Lecture seule : lancer une analyse consomme un
    # quota facturé, et une boucle d'agent le viderait en une après-midi.
    path("pages/<int:page_id>/mesures/", MesuresDeLaPage.as_view(), name="page_mesures"),

    # Sections
    path("sections/<int:section_id>/", DetailSection.as_view(), name="section"),
    path("sections/<int:section_id>/lignes/", LignesDeLaSection.as_view(), name="section_lignes"),
    path("sections/<int:section_id>/dupliquer/", DuplicationDeSection.as_view(), name="section_dupliquer"),
    path("sections/<int:section_id>/construire/", ConstructionDeSection.as_view(),
         name="section_construire"),

    # Lignes
    path("lignes/<int:ligne_id>/", DetailLigne.as_view(), name="ligne"),
    path("lignes/<int:ligne_id>/blocs/", BlocsDeLaLigne.as_view(), name="ligne_blocs"),
    path("lignes/<int:ligne_id>/construire/", ConstructionDeLigne.as_view(), name="ligne_construire"),

    # Blocs
    path("blocs/<int:bloc_id>/", DetailBloc.as_view(), name="bloc"),
    path("blocs/<int:bloc_id>/contenu/", ContenuDuBloc.as_view(), name="bloc_contenu"),

    # Déplacer un élément — un seul point d'entrée pour les trois niveaux.
    # `position` n'est volontairement pas modifiable par PATCH : l'écrire à la
    # main produirait deux éléments au même rang.
    path("deplacer/<str:niveau>/<int:element_id>/", Deplacement.as_view(), name="deplacer"),

    # Médiathèque — l'upload a sa propre permission et réutilise exactement les
    # validateurs de l'administration (poids, format et décompression).
    path("images/", ListeDesImages.as_view(), name="images"),
    path("images/creer/", CreationImage.as_view(), name="image_creer"),

    # Calendrier. On ne crée pas un créneau : on déclare une DISPONIBILITÉ,
    # qui les génère. Un créneau posé à la main serait effacé au prochain
    # passage de génération — voir l'en-tête de vues_calendrier.py.
    path("rdv/types/", ListeDesTypesDeRdv.as_view(), name="rdv_types"),
    path("rdv/types/creer/", CreationTypeDeRdv.as_view(), name="rdv_type_creer"),
    path("rdv/types/<int:type_id>/", DetailTypeDeRdv.as_view(), name="rdv_type"),
    path("rdv/disponibilites/", ListeDesDisponibilites.as_view(),
         name="rdv_disponibilites"),
    path("rdv/disponibilites/creer/", CreationDisponibilite.as_view(),
         name="rdv_disponibilite_creer"),
    path("rdv/disponibilites/<int:dispo_id>/", DetailDisponibilite.as_view(),
         name="rdv_disponibilite"),
    # Les créneaux se LISENT seulement : ils découlent d'une disponibilité,
    # et tout réglage posé sur eux serait défait à la prochaine génération.
    path("rdv/creneaux/", ListeDesCreneaux.as_view(), name="rdv_creneaux"),
    path("rdv/creneaux/<int:creneau_id>/bloquer/", BloquerDesPlaces.as_view(), name="rdv_creneau_bloquer"),
    path("rdv/credits/", CreditsDeSeance.as_view(), name="rdv_credits"),
    path("rdv/", ListeDesRendezVous.as_view(), name="rdv"),
    path("rdv/creer/", CreationDeRendezVous.as_view(), name="rdv_creer"),
    path("rdv/<int:rdv_id>/", DetailDuRendezVous.as_view(), name="rdv_un"),
    # CRM — lecture et écriture, jamais de suppression ni d'envoi (vues_contacts.py).
    path("contacts/", RechercheDeContacts.as_view(), name="contacts"),
    path("contacts/creer/", CreationDeContact.as_view(), name="contact_creer"),
    path("contacts/a-relancer/", ContactsARelancer.as_view(), name="contacts_a_relancer"),
    path("contacts/<int:contact_id>/", ModificationDuContact.as_view(), name="contact"),
    path("contacts/<int:contact_id>/notes/", NotesDuContact.as_view(), name="contact_notes"),
    path("contacts/<int:contact_id>/taches/", TachesDuContact.as_view(), name="contact_taches"),
    path("contacts/<int:contact_id>/taches/<int:tache_id>/", TacheDuContact.as_view(), name="contact_tache"),
    # FACT-01 : devis, factures, avoirs. Ni envoi, ni export, ni suppression.
    path("pieces/", vues_facturation.ListeDesPieces.as_view(), name="pieces"),
    path("pieces/creer/", vues_facturation.CreationDePiece.as_view(), name="piece_creer"),
    path("pieces/<int:piece_id>/", vues_facturation.DetailDePiece.as_view(), name="piece"),
    path("pieces/<int:piece_id>/action/", vues_facturation.ActionSurPiece.as_view(), name="piece_action"),
    path("entreprises/", RechercheDEntreprises.as_view(), name="entreprises"),
    path("entreprises/creer/", CreationDEntreprise.as_view(), name="entreprise_creer"),
    path("entreprises/<int:entreprise_id>/", DetailDEntreprise.as_view(), name="entreprise"),

    # Menus — la structure et les liens, pas le design. L'affectation d'un
    # menu à une catégorie est ce qui fait les sous-sites.
    path("menus/", ListeDesMenus.as_view(), name="menus"),
    path("menus/creer/", CreationMenu.as_view(), name="menu_creer"),
    path("menus/<int:menu_id>/", DetailMenu.as_view(), name="menu"),
    path("categories/<int:categorie_id>/menus/", MenusDeLaCategorie.as_view(),
         name="categorie_menus"),

    # Identité visuelle du site — couleurs du thème et polices. Un seul
    # point d'entrée : ce n'est pas du contenu mais ce qui décide de quoi tout
    # le contenu a l'air.
    path("identite/", Identite.as_view(), name="identite"),
    # Ce qui reste à faire pour qu'un site fonctionne, et où le régler (07/10).
    path("reglages/", ReglagesDeBase.as_view(), name="reglages"),
    # LEG-01 : les pages légales, leurs informations, le modèle à jour.
    path("pages-legales/", PagesLegales.as_view(), name="pages_legales"),
    # Un site complet pour un métier, posé d'un coup (TPL-01).
    path("modeles-de-site/", ListeDesModelesDeSite.as_view(), name="modeles_de_site"),
    path("modeles-de-site/appliquer/", AppliquerUnModeleDeSite.as_view(), name="modele_de_site_appliquer"),

    # E-mails transactionnels. Le corps est une PAGE : il se construit avec
    # les mêmes routes que le reste du site. Aucune route vers les journaux
    # d'envoi, qui portent les adresses des destinataires.
    path("emails/evenements/", ListeDesEvenements.as_view(), name="email_evenements"),
    # D-16 : le rapport d'activité, par personne et par cadence.
    path("emails/rapports/", RapportsDActivite.as_view(), name="rapports"),
    path("emails/", ListeDesEmails.as_view(), name="emails"),
    path("emails/creer/", CreationEmail.as_view(), name="email_creer"),
    path("emails/<int:email_id>/", DetailEmail.as_view(), name="email"),

    # Questionnaires experts — définir le test, ses profils, ses questions et
    # leurs poids. Aucune route de suppression, et aucune vers les passages :
    # ceux-ci contiennent des réponses de personnes identifiables.
    path("questionnaires/", ListeDesQuestionnaires.as_view(), name="questionnaires"),
    path("questionnaires/creer/", CreationQuestionnaire.as_view(),
         name="questionnaire_creer"),
    path("questionnaires/<int:test_id>/", DetailQuestionnaire.as_view(),
         name="questionnaire"),
    path("questionnaires/<int:test_id>/profils/", ProfilsDuQuestionnaire.as_view(),
         name="questionnaire_profils"),
    path("questionnaires/<int:test_id>/questions/", QuestionsDuQuestionnaire.as_view(),
         name="questionnaire_questions"),
    path("questionnaires/<int:test_id>/combinaisons/",
         CombinaisonsDuQuestionnaire.as_view(), name="questionnaire_combinaisons"),
    # Mode « dimensions » : composer la page de résultat pour des scores
    # donnés, sans enregistrer de passage.
    path("questionnaires/<int:test_id>/simuler/", SimulationDuResultat.as_view(),
         name="questionnaire_simuler"),
    path("profils/<int:profil_id>/", DetailProfil.as_view(), name="profil"),
    path("questions/<int:question_id>/", DetailQuestion.as_view(), name="question"),
    # Supprimer une réponse seule : sans cette route, il fallait réécrire la
    # liste entière et tous ses poids pour en retirer une.
    path("reponses/<int:reponse_id>/", DetailReponse.as_view(), name="reponse"),

    # Formations — la formation, ses parties, ses chapitres, ses sections et
    # leur contenu. Aucune suppression, aucune route vers les inscriptions :
    # voir l'en-tête de `vues_formations.py`.
    path("formations/", vues_formations.ListeDesFormations.as_view(), name="formations"),
    path("formations/creer/", vues_formations.CreationFormation.as_view(), name="formation_creer"),
    path("formations/<int:formation_id>/", vues_formations.DetailFormation.as_view(), name="formation"),
    path("formations/<int:formation_id>/parties/", vues_formations.PartiesDeLaFormation.as_view(),
         name="formation_parties"),
    path("formations/parties/<int:partie_id>/", vues_formations.DetailPartie.as_view(),
         name="partie_formation"),
    path("formations/parties/<int:partie_id>/chapitres/", vues_formations.ChapitresDeLaPartie.as_view(),
         name="partie_formation_chapitres"),
    path("formations/chapitres/<int:chapitre_id>/", vues_formations.DetailChapitre.as_view(),
         name="chapitre_formation"),
    path("formations/chapitres/<int:chapitre_id>/sections/", vues_formations.SectionsDuChapitre.as_view(),
         name="chapitre_formation_sections"),
    path("formations/sections/<int:section_id>/", vues_formations.DetailSectionFormation.as_view(),
         name="section_formation"),
    path("combinaisons/<int:combinaison_id>/", DetailCombinaison.as_view(),
         name="combinaison"),

    # Catégories de pages — à lire avant de classer une page.
    path("categories/", ListeDesCategories.as_view(), name="categories"),
    path("categories/creer/", CreationCategorie.as_view(), name="categorie_creer"),
    path("categories/<int:categorie_id>/", DetailCategorie.as_view(),
         name="categorie"),

    # Modèles de fiche — le contrat à lire avant de créer quoi que ce soit :
    # quels types existent, et quels champs les composent.
    path("modeles/", ListeDesModeles.as_view(), name="modeles"),
    path("modeles/creer/", CreationModele.as_view(), name="modele_creer"),
    path("modeles/<int:modele_id>/", DetailModele.as_view(), name="modele"),

    # Types de produit — la couche commerciale, reliée à un type de fiche.
    path("types-de-produit/", ListeDesTypesDeProduit.as_view(), name="types_produit"),
    path("types-de-produit/creer/", CreationTypeDeProduit.as_view(),
         name="type_produit_creer"),
    path("types-de-produit/<int:type_id>/", DetailTypeDeProduit.as_view(),
         name="type_produit"),

    # Fiches (objets personnalisés). Pas de suppression, comme pour les pages.
    path("objets/", ListeDesObjets.as_view(), name="objets"),
    # Alias documentaire : « fiche » est le terme métier, « objet » reste
    # conservé pour compatibilité avec les premières intégrations.
    path("fiches/", ListeDesObjets.as_view(), name="fiches"),
    path("objets/creer/", CreationObjet.as_view(), name="objet_creer"),
    path("objets/<int:objet_id>/", DetailObjet.as_view(), name="objet"),
    # Site en plusieurs langues : la version d'une fiche dans une langue.
    path("objets/<int:objet_id>/versions/", VersionsDeLObjet.as_view(), name="objet_versions"),

    # Produits — le commerce d'une fiche : référence, prix, TVA, stock.
    path("produits/", ListeDesProduits.as_view(), name="produits"),
    path("produits/creer/", CreationProduit.as_view(), name="produit_creer"),
    path("produits/<int:produit_id>/", DetailProduit.as_view(), name="produit"),
    path("produits/<int:produit_id>/declinaisons/", vues_boutique.DeclinaisonsDuProduit.as_view(),
         name="produit_declinaisons"),
    path("declinaisons/<int:declinaison_id>/", vues_boutique.DetailDeclinaison.as_view(),
         name="declinaison"),

    # La boutique au quotidien : commandes, ventes, codes promo, avis. Ni
    # remboursement ni « payée » : ces gestes restent à l'exploitant
    # (agents/vues_boutique.py).
    path("commandes/", vues_boutique.ListeDesCommandes.as_view(), name="commandes"),
    path("commandes/<int:commande_id>/", vues_boutique.DetailCommande.as_view(), name="commande"),
    path("ventes/", vues_boutique.Ventes.as_view(), name="ventes"),
    path("boutique/google/", vues_boutique.GoogleMerchant.as_view(), name="google_merchant"),
    path("codes-promo/", vues_boutique.ListeDesCodesPromo.as_view(), name="codes_promo"),
    path("codes-promo/creer/", vues_boutique.CreationCodePromo.as_view(), name="code_promo_creer"),
    path("codes-promo/<int:code_id>/", vues_boutique.DetailCodePromo.as_view(), name="code_promo"),
    path("avis/", vues_boutique.ListeDesAvis.as_view(), name="avis_clients"),
    path("avis/<int:avis_id>/", vues_boutique.DetailAvis.as_view(), name="avis_client"),

    # VISIO-01 — séances en visio, invitations (lien personnel), chat, serveur.
    path("visio/seances/", vues_visio.Seances.as_view(), name="visio_seances"),
    path("visio/seances/creer/", vues_visio.CreationSeance.as_view(), name="visio_seance_creer"),
    path("visio/seances/<int:seance_id>/", vues_visio.DetailSeance.as_view(), name="visio_seance"),
    path("visio/seances/<int:seance_id>/annuler/", vues_visio.AnnulationSeance.as_view(), name="visio_annuler"),
    path("visio/seances/<int:seance_id>/inviter/", vues_visio.Inviter.as_view(), name="visio_inviter"),
    path("visio/seances/<int:seance_id>/invitations/<int:invitation_id>/", vues_visio.DetailInvitation.as_view(),
         name="visio_invitation"),
    path("visio/seances/<int:seance_id>/chat/", vues_visio.ChatDeLaSeance.as_view(), name="visio_chat"),
    path("visio/seances/<int:seance_id>/ecrire/", vues_visio.EcrireAuxInvites.as_view(), name="visio_ecrire"),
    path("visio/seances/<int:seance_id>/sondages/", vues_visio.PreparerSondage.as_view(), name="visio_sondage"),
    path("visio/serveur/", vues_visio.ServeurDeVisio.as_view(), name="visio_serveur"),
    path("visio/remboursements/", vues_visio.RemboursementsDePlaces.as_view(), name="visio_remboursements"),
    # L-16 — les catégories de cookies et leurs textes par langue.
    path("cookies/categories/", vues_cookies.CategoriesDeCookies.as_view(), name="cookies_categories"),

    # NEWS-01 — tout le système : listes, abonnés, lettres, envoi (avec le droit
    # sur les e-mails du site), réglages (agents/vues_newsletter.py).
    path("newsletter/listes/", vues_newsletter.ListesNewsletter.as_view(), name="newsletter_listes"),
    path("newsletter/listes/creer/", vues_newsletter.CreationListeNewsletter.as_view(), name="newsletter_liste_creer"),
    path("newsletter/listes/<int:liste_id>/", vues_newsletter.DetailListeNewsletter.as_view(), name="newsletter_liste"),
    path("newsletter/abonnes/", vues_newsletter.AbonnesNewsletter.as_view(), name="newsletter_abonnes"),
    path("newsletter/abonnes/creer/", vues_newsletter.InscriptionNewsletter.as_view(), name="newsletter_abonne_creer"),
    path("newsletter/abonnes/desinscrire/", vues_newsletter.DesinscriptionNewsletter.as_view(),
         name="newsletter_desinscrire"),
    path("newsletter/lettres/", vues_newsletter.Newsletters.as_view(), name="newsletters"),
    path("newsletter/lettres/creer/", vues_newsletter.CreationNewsletter.as_view(), name="newsletter_creer"),
    path("newsletter/lettres/<int:newsletter_id>/", vues_newsletter.DetailNewsletter.as_view(), name="newsletter"),
    path("newsletter/lettres/<int:newsletter_id>/dupliquer/", vues_newsletter.DuplicationNewsletter.as_view(),
         name="newsletter_dupliquer"),
    path("newsletter/lettres/<int:newsletter_id>/programmer/", vues_newsletter.ProgrammationNewsletter.as_view(),
         name="newsletter_programmer"),
    path("newsletter/lettres/<int:newsletter_id>/annuler/", vues_newsletter.AnnulationNewsletter.as_view(),
         name="newsletter_annuler"),
    path("newsletter/lettres/<int:newsletter_id>/essai/", vues_newsletter.EssaiNewsletter.as_view(),
         name="newsletter_essai"),
    path("newsletter/lettres/<int:newsletter_id>/suivi/", vues_newsletter.SuiviNewsletter.as_view(),
         name="newsletter_suivi"),
    path("newsletter/reglages/", vues_newsletter.ReglagesNewsletterApi.as_view(), name="newsletter_reglages"),
    path("newsletter/sequences/", vues_newsletter.Sequences.as_view(), name="newsletter_sequences"),
    path("newsletter/sequences/creer/", vues_newsletter.CreationSequence.as_view(), name="newsletter_sequence_creer"),
    path("newsletter/sequences/<int:sequence_id>/", vues_newsletter.DetailSequence.as_view(), name="newsletter_sequence"),
    path("newsletter/sequences/<int:sequence_id>/etapes/", vues_newsletter.EtapesSequence.as_view(),
         name="newsletter_sequence_etapes"),

    # Toute faute de frappe reste une réponse JSON, même si aucune route plus
    # précise ne correspond.
    path("<path:inconnue>", RouteApiInconnue.as_view(), name="route_inconnue"),
]
