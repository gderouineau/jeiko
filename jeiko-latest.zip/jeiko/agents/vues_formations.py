# jeiko/agents/vues_formations.py
"""
Les formations — une formation, ses parties, ses chapitres, ses sections.

Ce que c'est
------------
Une `Course` se découpe en parties, chapitres et sections ; chaque section
porte UN contenu : un texte, une vidéo, un PDF ou un quiz. C'était le dernier
module que l'API ne savait pas construire : un agent montait un site entier,
sauf ses formations, qu'il fallait saisir écran par écran.

La règle de publication
-----------------------
Une formation naît INACTIVE : personne, hors personnel, ne la voit tant que
« active » n'est pas passé à vrai — c'est la protection, comme le brouillon
d'une page. Ses parties, chapitres et sections naissent PUBLIÉS (« publie »
à faux pour un ajout discret à une formation déjà en ligne) : sans quoi un
agent qui active sa formation la trouverait vide, et ne comprendrait pas
pourquoi.

Ce qui est délibérément absent
------------------------------
**La suppression**, à tous les niveaux. Une section supprimée emporte la
progression et les tentatives de quiz des inscrits. Un agent crée et corrige ;
une section de trop se met hors ligne (« publie » à faux).

**Les inscriptions, la progression, les attestations.** Elles nomment des
personnes ; aucune route ne les lit. Ouvrir une formation à quelqu'un passe
par l'achat ou par l'administration.

**L'envoi de fichiers.** Une vidéo ou un PDF se donne par son ADRESSE : le
stockage local, FTP ou chez un fournisseur se règle dans l'administration.
L'image de présentation, elle, se prend dans la médiathèque.

**Le type « lien externe »**, que la page de section ne sait pas afficher.

**Le changement de type d'une section.** Le contenu ne survivrait pas au
passage d'une vidéo à un quiz ; on crée une autre section.

La règle d'écriture des listes
------------------------------
Envoyer « questions » sur un quiz REMPLACE la liste entière, réponses
comprises — même raison que les réponses d'un questionnaire : rapprocher par
position mettrait la bonne réponse sur la mauvaise question.
"""

from django.core.exceptions import ValidationError
from django.core.files.base import ContentFile
from django.core.validators import URLValidator
from django.db import transaction
from django.db.models import Max
from django.shortcuts import get_object_or_404
from django.urls import reverse

from jeiko.courses.models import (
    Chapter, Course, Part, PDFContent, QuizAnswer, QuizContent, QuizQuestion,
    Section, TextContent, VideoContent,
)
from jeiko.sanitize import nettoyer_en_rendant_compte

from .vues_api import borne, CorpsInvalide, VueAgent, erreur, ok, slug_d_adresse
from .vues_reglages import _image as _image_de_la_mediatheque

VOIR = "courses.view_course"
AJOUTER = "courses.add_course"
MODIFIER = "courses.change_course"

#: Lus sur les modèles pour qu'ils ne puissent pas dériver.
NIVEAUX = [code for code, _ in Course.LEVEL_CHOICES]
TYPES_DE_SECTION = [
    code for code, _ in Section.SECTION_TYPE_CHOICES
    if code != Section.SECTION_TYPE_EXTERNAL_LINK
]
TYPES_DE_QUESTION = [code for code, _ in QuizQuestion.QUESTION_TYPE_CHOICES]

CHAMPS_FORMATION = {
    "titre", "slug", "description", "niveau", "duree_minutes",
    "acces_restreint", "active", "image",
}
CHAMPS_ELEMENT = {"titre", "description", "details", "rang", "publie"}
CLES_DE_CONTENU = {
    Section.SECTION_TYPE_TEXT: {"html"},
    Section.SECTION_TYPE_VIDEO: {"url", "duree_secondes", "apercu"},
    Section.SECTION_TYPE_PDF: {"url"},
    Section.SECTION_TYPE_QUIZ: {"titre", "score_reussite", "passer_autorise", "questions"},
}

_adresse_valide = URLValidator(schemes=["https", "http"])


# --------------------------------------------------------------------------- #
#  Lecture
# --------------------------------------------------------------------------- #
def _adresse(formation):
    return reverse(
        "jeiko_courses:jeiko_courses_client:course_detail",
        kwargs={"course_slug": formation.slug},
    )


def _formation_en_bref(formation):
    return {
        "id": formation.id,
        "titre": formation.title,
        "slug": formation.slug,
        "active": formation.is_active,
        "acces_restreint": formation.is_restricted,
        "niveau": formation.level,
        "duree_minutes": formation.estimated_duration,
        "adresse": _adresse(formation),
    }


def _element(objet):
    return {
        "id": objet.id,
        "titre": objet.title,
        "description": objet.description,
        "details": objet.content_details,
        "rang": objet.position,
        "publie": objet.is_published,
    }


def _contenu(section):
    """Le contenu de la section, sous la forme qu'on écrit pour le modifier."""
    t = section.section_type
    if t == Section.SECTION_TYPE_TEXT:
        texte = getattr(section, "text_content", None)
        return {"html": texte.content if texte else ""}
    if t == Section.SECTION_TYPE_VIDEO:
        video = getattr(section, "video_content", None)
        if not video:
            return None
        return {
            "url": video.direct_url, "duree_secondes": video.duration_seconds,
            "apercu": video.is_preview,
            # Un autre stockage que le lien direct vient de l'administration :
            # l'agent doit le savoir avant d'écrire une adresse par-dessus.
            "stockage": video.storage_type,
        }
    if t == Section.SECTION_TYPE_PDF:
        pdf = getattr(section, "pdf_content", None)
        if not pdf:
            return None
        return {"url": pdf.remote_url, "stockage": pdf.storage_type}
    if t == Section.SECTION_TYPE_QUIZ:
        quiz = getattr(section, "quiz_content", None)
        if not quiz:
            return None
        return {
            "titre": quiz.title, "score_reussite": quiz.passing_score,
            "passer_autorise": quiz.allow_skip,
            "questions": [
                {
                    "id": q.id, "texte": q.question_text, "type": q.question_type,
                    "points": q.points,
                    "reponses": [
                        {"id": r.id, "texte": r.answer_text, "correcte": r.is_correct}
                        for r in q.answers.order_by("position", "id")
                    ],
                }
                for q in quiz.questions.order_by("position", "id")
            ],
        }
    return None


def _section(section):
    return {**_element(section), "type": section.section_type, "contenu": _contenu(section)}


def _formation_complete(formation):
    image = formation.thumbnail.url if formation.thumbnail else None
    return {
        **_formation_en_bref(formation),
        "description": formation.description,
        "image": image,
        "parties": [
            {
                **_element(partie),
                "chapitres": [
                    {**_element(chapitre), "sections": [_section(s) for s in chapitre.sections.order_by("position")]}
                    for chapitre in partie.chapters.order_by("position")
                ],
            }
            for partie in formation.parts.order_by("position")
        ],
    }


# --------------------------------------------------------------------------- #
#  Écriture — validations communes
# --------------------------------------------------------------------------- #
def _booleen(corps, cle):
    valeur = corps[cle]
    if not isinstance(valeur, bool):
        raise CorpsInvalide(f"« {cle} » attend true ou false.")
    return valeur


def _entier(valeur, cle, mini=0, maxi=None):
    if not isinstance(valeur, int) or isinstance(valeur, bool) or valeur < mini or (
        maxi is not None and valeur > maxi
    ):
        borne_haute = f" et {maxi}" if maxi is not None else ""
        raise CorpsInvalide(f"« {cle} » attend un entier entre {mini}{borne_haute}.")
    return valeur


def _url(valeur, cle):
    texte = str(valeur or "").strip()
    try:
        _adresse_valide(texte)
    except ValidationError:
        raise CorpsInvalide(f"« {cle} » attend une adresse complète, en https://…")
    if len(texte) > 500:
        raise CorpsInvalide(f"« {cle} » fait au plus 500 caractères.")
    return texte


def _ecrire_formation(formation, corps):
    if "titre" in corps:
        formation.title = borne(Course, "title", corps["titre"])
        if not formation.title:
            raise CorpsInvalide("« titre » ne peut pas être vide.")
    if "slug" in corps:
        slug = slug_d_adresse(corps["slug"], "slug", longueur=255, a_la_racine=False)
        if Course.objects.filter(slug=slug).exclude(pk=formation.pk).exists():
            raise CorpsInvalide(f"Une autre formation porte déjà le slug « {slug} ».")
        formation.slug = slug
    if "description" in corps:
        formation.description = str(corps["description"] or "")
    if "niveau" in corps:
        if corps["niveau"] not in NIVEAUX:
            raise CorpsInvalide(f"« niveau » : {', '.join(NIVEAUX)}.")
        formation.level = corps["niveau"]
    if "duree_minutes" in corps:
        formation.estimated_duration = _entier(corps["duree_minutes"], "duree_minutes")
    if "acces_restreint" in corps:
        formation.is_restricted = _booleen(corps, "acces_restreint")
    if "active" in corps:
        formation.is_active = _booleen(corps, "active")
    image = None
    if "image" in corps:
        image = _image_de_la_mediatheque(corps["image"], "image")
    formation.save()
    if image:
        nom, octets = image
        formation.thumbnail.save(nom, ContentFile(octets), save=True)


def _placer(objet, freres, rang):
    """
    Range `objet` au rang voulu (1 = premier) et renumérote 1, 2, 3…

    En deux temps : `unique_together (parent, position)` refuse qu'un élément
    prenne une place encore occupée, même pour un instant — c'est le piège déjà
    contourné par `courses/views/admin_ordering.py`.
    """
    ordre = list(freres.exclude(pk=objet.pk).order_by("position", "pk"))
    rang = min(max(rang, 1), len(ordre) + 1)
    ordre.insert(rang - 1, objet)
    modele = type(objet)
    haut = (freres.aggregate(m=Max("position"))["m"] or 0) + 1
    for i, element in enumerate(ordre):
        modele.objects.filter(pk=element.pk).update(position=haut + i)
    for i, element in enumerate(ordre, start=1):
        modele.objects.filter(pk=element.pk).update(position=i)
    objet.position = rang


def _ecrire_element(objet, corps, freres, creation=False):
    """Les champs communs aux parties, chapitres et sections."""
    modele = type(objet)
    if "titre" in corps:
        objet.title = borne(modele, "title", corps["titre"])
    if not objet.title:
        raise CorpsInvalide("« titre » est obligatoire et ne peut pas être vide.")
    if "description" in corps:
        objet.description = str(corps["description"] or "")
    if "details" in corps:
        objet.content_details = str(corps["details"] or "")
    if "publie" in corps:
        objet.is_published = _booleen(corps, "publie")
    elif creation:
        objet.is_published = True
    if creation:
        objet.position = (freres.aggregate(m=Max("position"))["m"] or 0) + 1
    objet.save()
    if "rang" in corps:
        _placer(objet, freres, _entier(corps["rang"], "rang", mini=1))


def _questions_du_quiz(quiz, questions):
    """REMPLACE les questions du quiz. Valide tout avant d'effacer quoi que ce soit."""
    if not isinstance(questions, list):
        raise CorpsInvalide("« questions » attend une liste.")
    propres = []
    for n, q in enumerate(questions, start=1):
        if not isinstance(q, dict) or set(q) - {"texte", "type", "points", "reponses"}:
            raise CorpsInvalide(f"Question {n} : clés acceptées texte, type, points, reponses.")
        texte = str(q.get("texte") or "").strip()
        if not texte:
            raise CorpsInvalide(f"Question {n} : « texte » est obligatoire.")
        type_q = q.get("type", QuizQuestion.QUESTION_TYPE_SINGLE)
        if type_q not in TYPES_DE_QUESTION:
            raise CorpsInvalide(f"Question {n} : « type » vaut {', '.join(TYPES_DE_QUESTION)}.")
        points = _entier(q.get("points", 1), f"questions[{n}].points", mini=1)
        reponses = q.get("reponses")
        if not isinstance(reponses, list) or len(reponses) < 2:
            raise CorpsInvalide(f"Question {n} : au moins deux réponses.")
        lignes = []
        for r in reponses:
            if not isinstance(r, dict) or set(r) - {"texte", "correcte"}:
                raise CorpsInvalide(f"Question {n} : une réponse s'écrit {{\"texte\": …, \"correcte\": true|false}}.")
            texte_r = borne(QuizAnswer, "answer_text", r.get("texte"))
            if not texte_r:
                raise CorpsInvalide(f"Question {n} : une réponse sans texte.")
            lignes.append((texte_r, r.get("correcte") is True))
        justes = sum(1 for _, juste in lignes if juste)
        # La correction compare l'ensemble coché à l'ensemble juste : une
        # question sans bonne réponse ne se réussit jamais, et un choix unique
        # à deux bonnes réponses non plus — le visiteur ne peut en cocher qu'une.
        if justes == 0:
            raise CorpsInvalide(f"Question {n} : aucune réponse n'est marquée correcte.")
        if type_q != QuizQuestion.QUESTION_TYPE_MULTIPLE and justes != 1:
            raise CorpsInvalide(f"Question {n} : un choix unique ou un vrai/faux a exactement une bonne réponse.")
        propres.append((texte, type_q, points, lignes))

    quiz.questions.all().delete()
    for position, (texte, type_q, points, lignes) in enumerate(propres, start=1):
        question = QuizQuestion.objects.create(
            quiz=quiz, question_text=texte, question_type=type_q,
            points=points, position=position,
        )
        QuizAnswer.objects.bulk_create(
            QuizAnswer(question=question, answer_text=t, is_correct=j, position=p)
            for p, (t, j) in enumerate(lignes, start=1)
        )


def _ecrire_contenu(section, contenu):
    """Écrit le contenu selon le type de la section ; rend les avertissements."""
    t = section.section_type
    if not isinstance(contenu, dict):
        raise CorpsInvalide("« contenu » attend un objet.")
    inconnues = set(contenu) - CLES_DE_CONTENU[t]
    if inconnues:
        raise CorpsInvalide(
            f"Contenu « {t} » : clé(s) inconnue(s) {', '.join(sorted(inconnues))}. "
            f"Acceptées : {', '.join(sorted(CLES_DE_CONTENU[t]))}."
        )
    avertissements = []

    if t == Section.SECTION_TYPE_TEXT:
        if "html" in contenu:
            propre, avertissements = nettoyer_en_rendant_compte(str(contenu["html"] or ""))
            TextContent.objects.update_or_create(section=section, defaults={"content": propre})

    elif t == Section.SECTION_TYPE_VIDEO:
        video = getattr(section, "video_content", None) or VideoContent(
            section=section, title=section.title,
            storage_type=VideoContent.STORAGE_DIRECT_LINK,
        )
        if "url" in contenu:
            video.direct_url = _url(contenu["url"], "contenu.url")
            video.storage_type = VideoContent.STORAGE_DIRECT_LINK
        if "duree_secondes" in contenu:
            video.duration_seconds = _entier(contenu["duree_secondes"], "contenu.duree_secondes")
        if "apercu" in contenu:
            video.is_preview = _booleen(contenu, "apercu")
        if video.storage_type == VideoContent.STORAGE_DIRECT_LINK and not video.direct_url:
            raise CorpsInvalide("Une vidéo s'écrit avec son « url ».")
        video.save()

    elif t == Section.SECTION_TYPE_PDF:
        if "url" in contenu:
            PDFContent.objects.update_or_create(
                section=section,
                defaults={"remote_url": _url(contenu["url"], "contenu.url"),
                          "storage_type": PDFContent.STORAGE_REMOTE},
            )

    elif t == Section.SECTION_TYPE_QUIZ:
        quiz, _ = QuizContent.objects.get_or_create(section=section)
        if "titre" in contenu:
            quiz.title = borne(QuizContent, "title", contenu["titre"])
        if "score_reussite" in contenu:
            quiz.passing_score = _entier(contenu["score_reussite"], "contenu.score_reussite", maxi=100)
        if "passer_autorise" in contenu:
            quiz.allow_skip = _booleen(contenu, "passer_autorise")
        quiz.save()
        if "questions" in contenu:
            _questions_du_quiz(quiz, contenu["questions"])

    return avertissements


# --------------------------------------------------------------------------- #
#  Vues
# --------------------------------------------------------------------------- #
class ListeDesFormations(VueAgent):
    permission_requise = VOIR

    def get(self, request):
        return ok({"formations": [_formation_en_bref(f) for f in Course.objects.order_by("title")]})


class CreationFormation(VueAgent):
    """`POST {"titre", "slug", …}` — la formation naît INACTIVE, sauf « active » explicite."""

    permission_requise = AJOUTER

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request, connues=CHAMPS_FORMATION)
        if not str(corps.get("titre") or "").strip() or not corps.get("slug"):
            raise CorpsInvalide("« titre » et « slug » sont obligatoires.")
        formation = Course(is_active=False, created_by=request.user)
        _ecrire_formation(formation, corps)
        return ok(_formation_complete(formation), statut=201)


class DetailFormation(VueAgent):
    permission_requise = VOIR

    def get(self, request, formation_id):
        return ok(_formation_complete(get_object_or_404(Course, pk=formation_id)))

    @transaction.atomic
    def patch(self, request, formation_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification non autorisée.", statut=403, permission_manquante=MODIFIER)
        formation = get_object_or_404(Course.objects.select_for_update(), pk=formation_id)
        corps = self.corps(request, connues=CHAMPS_FORMATION)
        _ecrire_formation(formation, corps)
        return ok(_formation_complete(formation))


class _VueDElement(VueAgent):
    """Toute écriture sous une formation la modifie : un seul droit, comme l'administration."""

    permission_requise = MODIFIER


class PartiesDeLaFormation(_VueDElement):
    @transaction.atomic
    def post(self, request, formation_id):
        formation = get_object_or_404(Course, pk=formation_id)
        corps = self.corps(request, connues=CHAMPS_ELEMENT)
        partie = Part(course=formation)
        _ecrire_element(partie, corps, formation.parts.all(), creation=True)
        return ok(_element(partie), statut=201)


class DetailPartie(_VueDElement):
    @transaction.atomic
    def patch(self, request, partie_id):
        partie = get_object_or_404(Part, pk=partie_id)
        _ecrire_element(partie, self.corps(request, connues=CHAMPS_ELEMENT), partie.course.parts.all())
        return ok(_element(partie))


class ChapitresDeLaPartie(_VueDElement):
    @transaction.atomic
    def post(self, request, partie_id):
        partie = get_object_or_404(Part, pk=partie_id)
        corps = self.corps(request, connues=CHAMPS_ELEMENT)
        chapitre = Chapter(part=partie)
        _ecrire_element(chapitre, corps, partie.chapters.all(), creation=True)
        return ok(_element(chapitre), statut=201)


class DetailChapitre(_VueDElement):
    @transaction.atomic
    def patch(self, request, chapitre_id):
        chapitre = get_object_or_404(Chapter, pk=chapitre_id)
        _ecrire_element(chapitre, self.corps(request, connues=CHAMPS_ELEMENT), chapitre.part.chapters.all())
        return ok(_element(chapitre))


class SectionsDuChapitre(_VueDElement):
    """`POST {"titre", "type", "contenu": {…}}` — le type ne changera plus."""

    @transaction.atomic
    def post(self, request, chapitre_id):
        chapitre = get_object_or_404(Chapter, pk=chapitre_id)
        corps = self.corps(request, connues=CHAMPS_ELEMENT | {"type", "contenu"})
        if corps.get("type") not in TYPES_DE_SECTION:
            raise CorpsInvalide(f"« type » est obligatoire : {', '.join(TYPES_DE_SECTION)}.")
        if not isinstance(corps.get("contenu"), dict):
            raise CorpsInvalide("« contenu » est obligatoire : une section vide n'affiche rien.")
        section = Section(chapter=chapitre, section_type=corps["type"])
        _ecrire_element(section, corps, chapitre.sections.all(), creation=True)
        avertissements = _ecrire_contenu(section, corps["contenu"])
        reponse = _section(Section.objects.get(pk=section.pk))
        if avertissements:
            reponse["avertissements"] = avertissements
        return ok(reponse, statut=201)


class DetailSectionFormation(_VueDElement):
    @transaction.atomic
    def patch(self, request, section_id):
        section = get_object_or_404(Section, pk=section_id)
        corps = self.corps(request, connues=CHAMPS_ELEMENT | {"contenu"})
        _ecrire_element(section, corps, section.chapter.sections.all())
        avertissements = _ecrire_contenu(section, corps["contenu"]) if "contenu" in corps else []
        reponse = _section(Section.objects.get(pk=section.pk))
        if avertissements:
            reponse["avertissements"] = avertissements
        return ok(reponse)
