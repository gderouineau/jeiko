"""
La newsletter pilotée par un agent (NEWS-01) : listes, abonnés, brouillons.

Ce qu'un agent peut faire, et ce qu'il ne peut pas
--------------------------------------------------
Il crée et règle des listes, cherche un abonné, en inscrit un — en attestant
l'accord de la personne, gardé comme preuve avec le nom de l'agent —, en
désinscrit. Il prépare des newsletters : objet, listes, et le CORPS, qui est
une page (`page_id`) qu'il compose avec les outils des pages, comme un
e-mail du catalogue. Il les duplique et lit leur suivi.

Il peut aussi l'ENVOYER — maintenant ou à une date —, l'arrêter, envoyer un
essai (Guillaume, 12/10/2026 : « tout le système de newsletter doit être
accessible via le MCP »). Ces gestes demandent, comme dans l'écran, le droit
sur les e-mails du site (`users.config_edit_mail`) : un rôle d'agent qui ne
l'a pas prépare sans pouvoir envoyer. Le guide demande de n'envoyer qu'à la
demande explicite de l'exploitant.

Comme pour les contacts, l'API ne liste jamais tous les abonnés : elle
cherche (3 caractères au moins), et donne les effectifs par liste.
"""
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404

from jeiko.emailing.models import Abonne, Inscription, Liste, Newsletter
from jeiko.newsletter import abonnes as service, envoi as moteur

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR = "questionnaires_expert.view_prospect"
MODIFIER = "questionnaires_expert.change_prospect"
ENVOYER = "users.config_edit_mail"


def _refus():
    return erreur("Modification non autorisée.", statut=403, permission_manquante=MODIFIER)


# --- Listes ---

def _liste_en_dict(liste):
    statut = Inscription.Statut
    comptes = liste.inscriptions.aggregate(
        inscrits=Count("id", filter=Q(statut=statut.INSCRIT, abonne__bloque_le__isnull=True)),
        en_attente=Count("id", filter=Q(statut=statut.EN_ATTENTE)),
        desinscrits=Count("id", filter=Q(statut=statut.DESINSCRIT)))
    return {"id": liste.pk, "nom": liste.nom, "description": liste.description, "par_defaut": liste.par_defaut,
            "double_opt_in": liste.double_opt_in, "proposee_aux_clients": liste.proposee_aux_clients, **comptes}


def _ecrire_liste(liste, corps):
    if "nom" in corps:
        nom = str(corps["nom"] or "").strip()[:120]
        if not nom:
            raise CorpsInvalide("« nom » ne peut pas être vide.")
        liste.nom = nom
    if "description" in corps:
        liste.description = str(corps["description"] or "")
    if "double_opt_in" in corps:
        liste.double_opt_in = bool(corps["double_opt_in"])
    if "proposee_aux_clients" in corps:
        liste.proposee_aux_clients = bool(corps["proposee_aux_clients"])
    if not liste.nom:
        raise CorpsInvalide("« nom » est obligatoire.")
    liste.save()
    return liste


CHAMPS_LISTE = {"nom", "description", "double_opt_in", "proposee_aux_clients"}


class ListesNewsletter(VueAgent):
    """Les listes, avec leurs effectifs. La liste par défaut existe toujours."""

    permission_requise = VOIR

    def get(self, request):
        Liste.par_defaut_du_site()
        return ok({"listes": [_liste_en_dict(liste) for liste in Liste.objects.all()]})


class CreationListeNewsletter(VueAgent):
    permission_requise = MODIFIER

    def post(self, request):
        corps = self.corps(request, connues=CHAMPS_LISTE)
        return ok({"liste": _liste_en_dict(_ecrire_liste(Liste(), corps))}, statut=201)


class DetailListeNewsletter(VueAgent):
    permission_requise = VOIR

    def get(self, request, liste_id):
        return ok({"liste": _liste_en_dict(get_object_or_404(Liste, pk=liste_id))})

    def patch(self, request, liste_id):
        if not request.user.has_perm(MODIFIER):
            return _refus()
        corps = self.corps(request, connues=CHAMPS_LISTE)
        return ok({"liste": _liste_en_dict(_ecrire_liste(get_object_or_404(Liste, pk=liste_id), corps))})

    def delete(self, request, liste_id):
        if not request.user.has_perm(MODIFIER):
            return _refus()
        liste = get_object_or_404(Liste, pk=liste_id)
        if liste.par_defaut:
            return erreur("La liste par défaut ne se supprime pas.", statut=409)
        liste.delete()
        return ok({"supprime": True})


# --- Abonnés ---

def _abonne_en_dict(abonne):
    return {
        "email": abonne.email, "prenom": abonne.prenom, "nom": abonne.nom,
        "bloque": bool(abonne.bloque_le), "motif_du_blocage": abonne.blocage,
        "inscriptions": [{"liste": i.liste_id, "nom_de_la_liste": i.liste.nom, "statut": i.statut,
                          "source": i.source, "demandee_le": i.demandee_le.isoformat(),
                          "confirmee_le": i.confirmee_le.isoformat() if i.confirmee_le else None}
                         for i in abonne.inscriptions.select_related("liste")],
    }


class AbonnesNewsletter(VueAgent):
    """Cherche des abonnés (3 caractères au moins), 20 au plus."""

    permission_requise = VOIR

    def get(self, request):
        terme = (request.GET.get("q") or "").strip()
        if len(terme) < 3:
            return erreur("Paramètre « q » : 3 caractères au moins. L'API ne liste jamais tous les abonnés ; "
                          "les effectifs sont dans lister_newsletter_listes.")
        trouves = Abonne.objects.filter(Q(email__icontains=terme) | Q(prenom__icontains=terme)
                                        | Q(nom__icontains=terme)).order_by("email")[:20]
        return ok({"abonnes": [_abonne_en_dict(a) for a in trouves]})


class InscriptionNewsletter(VueAgent):
    """Inscrit une adresse, en attestant l'accord de la personne."""

    permission_requise = MODIFIER

    def post(self, request):
        corps = self.corps(request, connues={"email", "prenom", "nom", "listes", "accord", "preuve"})
        if corps.get("accord") is not True:
            raise CorpsInvalide("« accord »: true est obligatoire — vous attestez que la personne a accepté de "
                                "recevoir ces listes par e-mail. Sinon, proposez-lui le formulaire du site.")
        from django.core.exceptions import ValidationError
        from django.core.validators import validate_email

        email = str(corps.get("email") or "").strip()
        try:
            validate_email(email)
        except ValidationError:
            raise CorpsInvalide("« email » n'est pas une adresse valide.")
        listes = list(Liste.objects.filter(pk__in=corps.get("listes") or [])) or None
        if corps.get("listes") and listes is None:
            raise CorpsInvalide("Aucune des « listes » n'existe (lister_newsletter_listes).")
        detail = f"Agent {request.user.get_username()} : {str(corps.get('preuve') or '').strip()}"[:255]
        try:
            service.inscrire(email, listes, source=Inscription.Source.API, detail=detail,
                             prenom=str(corps.get("prenom") or ""), nom=str(corps.get("nom") or ""))
        except service.AdresseBloquee:
            return erreur("Cette adresse s'est désinscrite de tout ou ne reçoit plus : seule la personne peut "
                          "se réinscrire, depuis le site.", statut=409)
        return ok({"abonne": _abonne_en_dict(Abonne.objects.get(email=email.lower()))}, statut=201)


class DesinscriptionNewsletter(VueAgent):
    """Désinscrit une adresse d'une liste, ou de tout (elle ne reçoit alors plus rien)."""

    permission_requise = MODIFIER

    def post(self, request):
        corps = self.corps(request, connues={"email", "liste"})
        email = str(corps.get("email") or "").strip()
        if not email:
            raise CorpsInvalide("« email » est obligatoire.")
        liste = corps.get("liste")
        retirees = service.desinscrire(email, Liste.objects.filter(pk=liste) if liste else None)
        return ok({"inscriptions_retirees": retirees, "de_tout": not liste})


# --- Newsletters ---

def _lettre_en_dict(lettre, detail=False):
    donnees = {"id": lettre.pk, "objet": lettre.objet, "texte_d_apercu": lettre.pre_entete,
               "statut": lettre.statut, "listes": [l.pk for l in lettre.listes.all()],
               "page_id": lettre.page_id, "suivi_des_clics": lettre.suivi_des_clics,
               "etiquettes_crm": lettre.etiquettes_crm, "statut_crm": lettre.statut_crm,
               "sequence": lettre.sequence_id, "delai_jours": lettre.delai_jours,
               "programmee_le": lettre.programmee_le.isoformat() if lettre.programmee_le else None,
               "envoi_termine_le": lettre.envoi_termine_le.isoformat() if lettre.envoi_termine_le else None}
    if detail:
        donnees["suivi"] = moteur.statistiques(lettre)
        donnees["a_regler_avant_l_envoi"] = moteur.problemes(lettre) if lettre.modifiable else []
        donnees["destinataires_prevus"] = service.destinataires_de(lettre).count() if lettre.modifiable else None
    return donnees


CHAMPS_LETTRE = {"objet", "texte_d_apercu", "listes", "suivi_des_clics", "etiquettes_crm", "statut_crm", "delai_jours"}


def _ecrire_lettre(lettre, corps):
    if not lettre.modifiable:
        raise CorpsInvalide("Une newsletter envoyée ou en cours ne se modifie plus : dupliquez-la.")
    if "objet" in corps:
        lettre.objet = str(corps["objet"] or "").strip()[:200] or lettre.objet
    if "texte_d_apercu" in corps:
        lettre.pre_entete = str(corps["texte_d_apercu"] or "")[:200]
    if "suivi_des_clics" in corps:
        lettre.suivi_des_clics = bool(corps["suivi_des_clics"])
    if "delai_jours" in corps:
        if not lettre.sequence_id:
            raise CorpsInvalide("« delai_jours » ne vaut que pour une étape de séquence.")
        try:
            lettre.delai_jours = max(0, int(corps["delai_jours"]))
        except (TypeError, ValueError):
            raise CorpsInvalide("« delai_jours » : un entier, 0 ou plus.")
    if "etiquettes_crm" in corps:
        if not isinstance(corps["etiquettes_crm"], list):
            raise CorpsInvalide("« etiquettes_crm » est une liste de textes.")
        lettre.etiquettes_crm = [str(e).strip() for e in corps["etiquettes_crm"] if str(e).strip()]
    if "statut_crm" in corps:
        from jeiko.questionnaires_expert.models import Prospect

        statut = str(corps["statut_crm"] or "")
        if statut and statut not in Prospect.Statut.values:
            raise CorpsInvalide(f"« statut_crm » : {', '.join(Prospect.Statut.values)} ou vide.")
        lettre.statut_crm = statut
    lettre.save()
    if "listes" in corps:
        lettre.listes.set(Liste.objects.filter(pk__in=corps["listes"] or []))
    return lettre


class Newsletters(VueAgent):
    permission_requise = VOIR

    def get(self, request):
        lettres = Newsletter.objects.filter(sequence__isnull=True).prefetch_related("listes")[:100]
        return ok({"newsletters": [_lettre_en_dict(l) for l in lettres]})


class CreationNewsletter(VueAgent):
    """Un brouillon, avec sa page de corps vide (page_id) à composer avec les outils des pages."""

    permission_requise = MODIFIER

    def post(self, request):
        corps = self.corps(request, connues=CHAMPS_LETTRE | {"modele"})
        objet = str(corps.get("objet") or "").strip()
        if not objet:
            raise CorpsInvalide("« objet » est obligatoire.")
        lettre = moteur.creer(objet[:200], request.user, modele=str(corps.get("modele") or ""))
        corps.pop("modele", None)
        return ok({"newsletter": _lettre_en_dict(_ecrire_lettre(lettre, corps), detail=True)}, statut=201)


class DetailNewsletter(VueAgent):
    permission_requise = VOIR

    def get(self, request, newsletter_id):
        return ok({"newsletter": _lettre_en_dict(get_object_or_404(Newsletter, pk=newsletter_id), detail=True)})

    def patch(self, request, newsletter_id):
        if not request.user.has_perm(MODIFIER):
            return _refus()
        corps = self.corps(request, connues=CHAMPS_LETTRE)
        lettre = _ecrire_lettre(get_object_or_404(Newsletter, pk=newsletter_id), corps)
        return ok({"newsletter": _lettre_en_dict(lettre, detail=True)})

    def delete(self, request, newsletter_id):
        if not request.user.has_perm(MODIFIER):
            return _refus()
        lettre = get_object_or_404(Newsletter, pk=newsletter_id)
        if lettre.statut != Newsletter.Statut.BROUILLON:
            return erreur("Seul un brouillon se supprime.", statut=409)
        page = lettre.page
        lettre.delete()
        if page is not None:
            page.delete()
        return ok({"supprime": True})


class DuplicationNewsletter(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, newsletter_id):
        corps = self.corps(request, obligatoire=False, connues={"objet"})
        copie = moteur.dupliquer(get_object_or_404(Newsletter, pk=newsletter_id), request.user)
        if str(corps.get("objet") or "").strip():
            copie.objet = str(corps["objet"]).strip()[:200]
            copie.save(update_fields=["objet"])
        return ok({"newsletter": _lettre_en_dict(copie, detail=True)}, statut=201)


class ProgrammationNewsletter(VueAgent):
    """Envoie maintenant, ou à la date « quand » (ISO 8601). Refusé tant que quelque chose manque."""

    permission_requise = ENVOYER

    def post(self, request, newsletter_id):
        from django.utils import timezone
        from django.utils.dateparse import parse_datetime

        corps = self.corps(request, obligatoire=False, connues={"quand"})
        quand = None
        if corps.get("quand"):
            quand = parse_datetime(str(corps["quand"]))
            if quand is None:
                raise CorpsInvalide("« quand » : une date ISO 8601, par exemple 2026-11-02T09:00:00+01:00.")
            if timezone.is_naive(quand):
                quand = timezone.make_aware(quand)
        lettre = get_object_or_404(Newsletter, pk=newsletter_id)
        try:
            lettre = moteur.programmer(lettre, request.user, quand)
        except moteur.EnvoiImpossible as motif:
            return erreur(f"Envoi impossible : {motif}", statut=409)
        return ok({"newsletter": _lettre_en_dict(lettre, detail=True)})


class AnnulationNewsletter(VueAgent):
    """Une newsletter programmée revient au brouillon ; une en cours s'arrête (ceux qui l'ont reçue l'ont reçue)."""

    permission_requise = ENVOYER

    def post(self, request, newsletter_id):
        corps = self.corps(request, connues={"confirmer"})
        if corps.get("confirmer") is not True:
            raise CorpsInvalide("« confirmer »: true est obligatoire : annuler arrête un envoi.")
        lettre = moteur.annuler(get_object_or_404(Newsletter, pk=newsletter_id))
        return ok({"newsletter": _lettre_en_dict(lettre, detail=True)})


class EssaiNewsletter(VueAgent):
    """Envoie un exemplaire d'essai à une adresse (valeurs d'exemple) ; ne compte nulle part."""

    permission_requise = ENVOYER

    def post(self, request, newsletter_id):
        corps = self.corps(request, connues={"adresse"})
        from django.core.exceptions import ValidationError
        from django.core.validators import validate_email

        adresse = str(corps.get("adresse") or "").strip()
        try:
            validate_email(adresse)
        except ValidationError:
            raise CorpsInvalide("« adresse » n'est pas une adresse valide.")
        envoye, motif = moteur.envoyer_un_essai(get_object_or_404(Newsletter, pk=newsletter_id), adresse)
        if not envoye:
            return erreur(f"L'essai n'est pas parti : {motif}", statut=502)
        return ok({"envoye": True, "adresse": adresse})


class SuiviNewsletter(VueAgent):
    """Le suivi par destinataire d'une newsletter partie (200 au plus), filtrable par statut."""

    permission_requise = VOIR

    def get(self, request, newsletter_id):
        from jeiko.emailing.models import EnvoiNewsletter

        lettre = get_object_or_404(Newsletter, pk=newsletter_id)
        envois = lettre.envois.order_by("-clics", "email")
        statut = request.GET.get("statut")
        if statut:
            if statut not in EnvoiNewsletter.Statut.values:
                return erreur(f"« statut » : {', '.join(EnvoiNewsletter.Statut.values)}.")
            envois = envois.filter(statut=statut)
        return ok({"destinataires": [
            {"email": e.email, "statut": e.statut, "envoye_le": e.envoye_le.isoformat() if e.envoye_le else None,
             "clics": e.clics, "erreur": e.erreur, "desinscrit": bool(e.desinscrit_le)} for e in envois[:200]]})


CHAMPS_REGLAGES = {"envois_par_heure", "expediteur", "reponse_a", "texte_consentement",
                   "questionnaire_case_email", "questionnaire_case_telephone",
                   "rebonds_hote", "rebonds_port", "rebonds_utilisateur", "rebonds_dossier"}


class ReglagesNewsletterApi(VueAgent):
    """Les réglages d'envoi et de consentement, et l'état SPF / DKIM / DMARC du domaine d'envoi."""

    permission_requise = VOIR

    def _rendu(self):
        from jeiko.emailing.models import ReglagesNewsletter
        from jeiko.newsletter import delivrabilite

        r = ReglagesNewsletter.du_site()
        return {"reglages": {c: getattr(r, c) for c in sorted(CHAMPS_REGLAGES)},
                "rebonds": {"mot_de_passe_present": bool(r.rebonds_mot_de_passe),
                            "dernier_releve": r.rebonds_releve_le.isoformat() if r.rebonds_releve_le else None,
                            "derniere_erreur": r.rebonds_erreur},
                "domaine_d_envoi": delivrabilite.domaine_d_envoi(),
                "dns": [{"etat": e, "controle": l, "detail": d} for e, l, d in delivrabilite.verifier()]}

    def get(self, request):
        return ok(self._rendu())

    def patch(self, request):
        if not request.user.has_perm(ENVOYER):
            return erreur("Modification non autorisée.", statut=403, permission_manquante=ENVOYER)
        corps = self.corps(request, connues=CHAMPS_REGLAGES | {"rebonds_mot_de_passe"})
        from jeiko.emailing.models import ReglagesNewsletter

        r = ReglagesNewsletter.du_site()
        from jeiko.newsletter.rebonds import meme_boite

        # Une autre boîte sans nouveau mot de passe : l'ancien ne la suit pas (audit NL-02).
        if not corps.get("rebonds_mot_de_passe") and not meme_boite(
                r, corps.get("rebonds_hote", r.rebonds_hote), corps.get("rebonds_utilisateur", r.rebonds_utilisateur)):
            r.rebonds_mot_de_passe = ""
        if "envois_par_heure" in corps:
            try:
                valeur = int(corps["envois_par_heure"])
            except (TypeError, ValueError):
                raise CorpsInvalide("« envois_par_heure » : un entier.")
            if valeur < 1:
                raise CorpsInvalide("« envois_par_heure » : 1 au moins.")
            r.envois_par_heure = valeur
        for cle in ("expediteur", "reponse_a", "texte_consentement", "rebonds_hote", "rebonds_utilisateur",
                    "rebonds_dossier", "rebonds_mot_de_passe"):
            if cle in corps:
                setattr(r, cle, str(corps[cle] or ""))
        if "rebonds_port" in corps:
            try:
                r.rebonds_port = int(corps["rebonds_port"])
            except (TypeError, ValueError):
                raise CorpsInvalide("« rebonds_port » : un entier (993 le plus souvent).")
        for cle in ("questionnaire_case_email", "questionnaire_case_telephone"):
            if cle in corps:
                setattr(r, cle, bool(corps[cle]))
        r.save()
        return ok(self._rendu())



# --- Séquences automatiques ---

def _sequence_en_dict(sequence, detail=False):
    from jeiko.newsletter import sequences

    donnees = {"id": sequence.pk, "nom": sequence.nom, "liste": sequence.liste_id, "active": sequence.active,
               "active_depuis": sequence.active_depuis.isoformat() if sequence.active_depuis else None}
    if detail:
        donnees["etapes"] = [{**_lettre_en_dict(s["etape"]), "suivi": {k: v for k, v in s.items() if k != "etape"}}
                             for s in sequences.statistiques(sequence)]
        donnees["a_regler"] = sequences.problemes(sequence)
    return donnees


class Sequences(VueAgent):
    """Les séquences automatiques."""

    permission_requise = VOIR

    def get(self, request):
        from jeiko.emailing.models import Sequence

        return ok({"sequences": [_sequence_en_dict(s) for s in Sequence.objects.all()]})


class CreationSequence(VueAgent):
    permission_requise = MODIFIER

    def post(self, request):
        from jeiko.newsletter import sequences

        corps = self.corps(request, connues={"nom", "liste"})
        nom = str(corps.get("nom") or "").strip()
        liste = Liste.objects.filter(pk=corps.get("liste")).first() or Liste.par_defaut_du_site()
        if not nom:
            raise CorpsInvalide("« nom » est obligatoire.")
        return ok({"sequence": _sequence_en_dict(sequences.creer(nom, liste), detail=True)}, statut=201)


class DetailSequence(VueAgent):
    """Une séquence et ses étapes ; PATCH la renomme, change sa liste, l'active ou la met en pause."""

    permission_requise = VOIR

    def get(self, request, sequence_id):
        from jeiko.emailing.models import Sequence

        return ok({"sequence": _sequence_en_dict(get_object_or_404(Sequence, pk=sequence_id), detail=True)})

    def patch(self, request, sequence_id):
        from jeiko.emailing.models import Sequence
        from jeiko.newsletter import sequences

        if not request.user.has_perm(MODIFIER):
            return _refus()
        corps = self.corps(request, connues={"nom", "liste", "active"})
        sequence = get_object_or_404(Sequence, pk=sequence_id)
        # Activer, ou changer la liste d'une séquence active, fait partir des
        # e-mails : le droit d'envoi, vérifié AVANT de rien enregistrer (audit NL-01).
        if ("active" in corps or ("liste" in corps and sequence.active)) and not request.user.has_perm(ENVOYER):
            return erreur("Activer une séquence, ou changer la liste d'une séquence active, demande le droit sur "
                          "les e-mails du site.", statut=403, permission_manquante=ENVOYER)
        if "nom" in corps and str(corps["nom"] or "").strip():
            sequence.nom = str(corps["nom"]).strip()[:120]
        if "liste" in corps:
            liste = Liste.objects.filter(pk=corps["liste"]).first()
            if liste is None:
                raise CorpsInvalide("« liste » : une liste existante (lister_newsletter_listes).")
            if liste.pk != sequence.liste_id and sequences.a_deja_envoye(sequence):
                return erreur("Cette séquence a déjà écrit à des abonnés : sa liste ne change plus (les liens de "
                              "désinscription envoyés la visent). Créez une nouvelle séquence.", statut=409)
            sequence.liste = liste
        sequence.save()
        for etape in sequence.etapes.all():
            etape.listes.set([sequence.liste])
        if "active" in corps:
            if corps["active"] and sequences.problemes(sequence):
                return erreur("Séquence incomplète : " + " ".join(sequences.problemes(sequence)), statut=409)
            sequence = sequences.activer(sequence, bool(corps["active"]))
        return ok({"sequence": _sequence_en_dict(sequence, detail=True)})

    def delete(self, request, sequence_id):
        from jeiko.emailing.models import Sequence

        if not request.user.has_perm(MODIFIER):
            return _refus()
        sequence = get_object_or_404(Sequence, pk=sequence_id)
        for etape in sequence.etapes.all():
            page = etape.page
            etape.delete()
            if page is not None:
                page.delete()
        sequence.delete()
        return ok({"supprime": True})


class EtapesSequence(VueAgent):
    """Ajoute une étape : une newsletter rattachée, vide ou d'après un modèle, à composer comme les autres."""

    permission_requise = MODIFIER

    def post(self, request, sequence_id):
        from jeiko.emailing.models import Sequence
        from jeiko.newsletter import sequences

        corps = self.corps(request, connues={"objet", "delai_jours", "modele"})
        sequence = get_object_or_404(Sequence, pk=sequence_id)
        # Une étape ajoutée à une séquence active part toute seule (audit NL-01).
        if sequence.active and not request.user.has_perm(ENVOYER):
            return erreur("Ajouter une étape à une séquence active demande le droit sur les e-mails du site.",
                          statut=403, permission_manquante=ENVOYER)
        objet = str(corps.get("objet") or "").strip()
        if not objet:
            raise CorpsInvalide("« objet » est obligatoire.")
        try:
            delai = max(0, int(corps.get("delai_jours") or 0))
        except (TypeError, ValueError):
            raise CorpsInvalide("« delai_jours » : un entier, 0 ou plus.")
        etape = sequences.ajouter_une_etape(sequence, objet[:200], request.user, delai, str(corps.get("modele") or ""))
        return ok({"etape": _lettre_en_dict(etape, detail=True)}, statut=201)
