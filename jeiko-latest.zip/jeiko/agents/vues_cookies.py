"""
Les catégories de cookies, vues par un agent (L-16, 16/10/2026).

Mêmes règles que l'écran Cookies › Catégories (cookies/categories.py) : une
catégorie a une clé, que porte le consentement ; ses textes dans une langue
ajoutée se rangent dans `traductions`, sans seconde catégorie.
"""
from django.contrib.sites.shortcuts import get_current_site
from django.db.models import ProtectedError

from jeiko.cookies import categories as cats

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR, MODIFIER, SUPPRIMER = "cookies.view_cookiecategory", "cookies.change_cookiecategory", "cookies.delete_cookiecategory"
CHAMPS_API = {"libelle": "label", "description": "description", "essentielle": "is_essential",
              "active_par_defaut": "default_enabled", "ordre": "display_order", "active": "is_active"}


class CategoriesDeCookies(VueAgent):
    """GET : les catégories ; POST {cle, …, traductions} : créer ou modifier ; DELETE ?cle= : supprimer."""
    permission_requise = VOIR

    def get(self, request):
        return ok({"categories": [cats.en_donnees(c) for c in cats.d_origine(get_current_site(request))]})

    def post(self, request):
        if not request.user.has_perm(MODIFIER):
            return erreur("Opération non autorisée.", statut=403, permission_manquante=MODIFIER)
        corps = self.corps(request, connues={"cle", "traductions", *CHAMPS_API})
        traductions = corps.get("traductions") or {}
        if not isinstance(traductions, dict) or not all(isinstance(v, dict) for v in traductions.values()):
            raise CorpsInvalide("« traductions » : {code de langue: {libelle, description}}.")
        from jeiko.langues_du_site import langues_actives

        inconnues = set(traductions) - set(langues_actives())
        if inconnues:
            raise CorpsInvalide(f"Langue(s) non activée(s) sur le site : {sorted(inconnues)} (lister_langues).")
        site = get_current_site(request)
        champs = {CHAMPS_API[k]: v for k, v in corps.items() if k in CHAMPS_API}
        try:
            categorie = cats.enregistrer(site, corps.get("cle"), **champs)
        except cats.CategorieInvalide as refus:
            raise CorpsInvalide(str(refus))
        for code, textes in traductions.items():
            categorie = cats.traduire(categorie, code, textes.get("libelle", ""), textes.get("description", ""))
        return ok({"categorie": cats.en_donnees(categorie)})

    def delete(self, request):
        if not request.user.has_perm(SUPPRIMER):
            return erreur("Opération non autorisée.", statut=403, permission_manquante=SUPPRIMER)
        categorie = cats.trouver(get_current_site(request), request.GET.get("cle", ""))
        if categorie is None:
            return erreur("Catégorie inconnue (paramètre « cle »).", statut=404)
        try:
            categorie.delete()
        except ProtectedError:
            raise CorpsInvalide("Elle décrit encore des cookies : désactivez-la plutôt (« active »: false).")
        return ok({"supprimee": request.GET.get("cle")})
