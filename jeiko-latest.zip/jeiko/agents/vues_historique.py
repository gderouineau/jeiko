# jeiko/agents/vues_historique.py
"""
HIST-01 — le brouillon et l'historique d'une page, par l'API des agents.

Avant, un agent écrivait EN LIGNE : ce qu'il faisait se voyait aussitôt, et
seul l'historique permettait de défaire. Il peut maintenant préparer un
brouillon, le construire comme une page (son identifiant s'emploie partout où
une page est attendue pour la lire ou y ajouter des sections), le comparer à
la page en ligne, puis le publier — tout de suite ou à une date —, ou
l'abandonner ; et restaurer une version.

Mêmes fonctions que l'écran (`administration_pages/historique.py`) : une
version se prend avant chaque publication et chaque restauration.
"""
from django.db.models import Q
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from jeiko.administration_pages import comparaison, historique
from jeiko.administration_pages.models import Page

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

LIRE = "administration_pages.view_page"
MODIFIER = "administration_pages.change_page"
ACTIONS = ("preparer_brouillon", "publier_brouillon", "abandonner_brouillon", "programmer_brouillon", "restaurer")


def _etat_en_dict(request, cachee):
    return {"id": cachee.pk, "le": cachee.role_le.isoformat() if cachee.role_le else None,
            "motif": cachee.role_motif, "par": cachee.role_par.email if cachee.role_par_id else None,
            "apercu": request.build_absolute_uri(f"/jk-apercu/{cachee.pk}/")}


def _historique(request, page):
    brouillon = historique.brouillon_de(page)
    return {
        "page_id": page.pk,
        "brouillon": ({**_etat_en_dict(request, brouillon),
                       "publier_le": brouillon.publier_le.isoformat() if brouillon.publier_le else None}
                      if brouillon else None),
        "versions": [_etat_en_dict(request, v) for v in historique.versions_de(page)],
    }


class HistoriqueDeLaPage(VueAgent):
    """GET : brouillon et versions (?avant=&apres= : leur différence). POST : un geste."""

    permission_requise = LIRE

    def get(self, request, page_id):
        page = get_object_or_404(Page, pk=page_id)
        donnees = _historique(request, page)
        if request.GET.get("avant") or request.GET.get("apres"):
            lignee = Page.tous.filter(Q(pk=page.pk) | Q(rattachee_a=page))

            def etat(cle):
                valeur = request.GET.get(cle) or ""
                if not valeur:
                    return page
                if not valeur.isdigit():
                    raise CorpsInvalide(f"« {cle} » : l'identifiant de la page, de son brouillon ou d'une version.")
                return get_object_or_404(lignee, pk=valeur)

            donnees["differences"] = comparaison.differences(etat("avant"), etat("apres"))
        return ok(donnees)

    def post(self, request, page_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification de page non autorisée.", statut=403, permission_manquante=MODIFIER)
        page = get_object_or_404(Page, pk=page_id)
        corps = self.corps(request, connues={"action", "version", "quand"})
        action = corps.get("action")
        if action not in ACTIONS:
            raise CorpsInvalide(f"« action » : une valeur parmi {', '.join(ACTIONS)}.")
        if not historique.a_un_historique(page):
            return erreur("Cette page n'a ni brouillon ni historique (gabarit d'e-mail, PDF, atelier).", statut=409)
        brouillon = historique.brouillon_de(page)
        if action == "preparer_brouillon":
            brouillon = historique.creer_le_brouillon(page, auteur=request.user)
            return ok({**_historique(request, page), "brouillon_id": brouillon.pk}, statut=201)
        if action == "restaurer":
            version = Page.tous.filter(pk=corps.get("version") or 0, role=Page.Role.VERSION, rattachee_a=page).first()
            if version is None:
                raise CorpsInvalide("« version » : l'identifiant d'une version de cette page (GET historique).")
            historique.restaurer(version, auteur=request.user)
            return ok(_historique(request, page))
        if brouillon is None:
            return erreur("Cette page n'a pas de brouillon : « preparer_brouillon » d'abord.", statut=409)
        if action == "publier_brouillon":
            historique.publier_le_brouillon(brouillon, auteur=request.user)
        elif action == "abandonner_brouillon":
            historique.abandonner_le_brouillon(brouillon)
        else:
            quand = None
            if corps.get("quand"):
                quand = parse_datetime(str(corps["quand"]))
                if quand is None:
                    raise CorpsInvalide("« quand » : une date ISO 8601, par exemple 2026-11-02T09:00:00+01:00 ; "
                                        "null annule la programmation.")
                if timezone.is_naive(quand):
                    quand = timezone.make_aware(quand)
            try:
                historique.programmer_le_brouillon(brouillon, quand)
            except ValueError:
                raise CorpsInvalide("« quand » : une date à venir.")
        return ok(_historique(request, page))
