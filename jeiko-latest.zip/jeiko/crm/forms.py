from django import forms
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _

from jeiko.questionnaires_expert.models import Prospect


class ContactForm(forms.ModelForm):
    """La fiche d'un contact, telle que l'exploitant la tient."""

    tags = forms.CharField(
        label=_("Étiquettes"), required=False,
        help_text=_("Séparées par des virgules : « devis, salon 2026 »."),
    )

    class Meta:
        model = Prospect
        # La prochaine action ne se saisit plus ici : c'est la tâche ouverte la
        # plus proche, gérée sur la fiche (jeiko/crm/taches.py).
        fields = ["firstname", "lastname", "email", "phone", "entreprise", "company", "job_title",
                  "status", "owner", "tags", "task_reminders"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Un responsable est quelqu'un qui travaille sur le site, pas un client.
        self.fields["owner"].queryset = get_user_model().objects.filter(
            is_staff=True, is_active=True).order_by("first_name", "last_name", "username")
        self.initial["tags"] = ", ".join(self.instance.tags or [])
        self.fields["entreprise"].help_text = _("Choisie, elle remplace le texte « Société » par son nom.")

    def clean_tags(self):
        vues, propres = set(), []
        for brut in (self.cleaned_data.get("tags") or "").split(","):
            tag = brut.strip()[:50]
            if tag and tag.casefold() not in vues:
                vues.add(tag.casefold())
                propres.append(tag)
        return propres

    def clean(self):
        donnees = super().clean()
        if not any(donnees.get(c) for c in ("firstname", "lastname", "email", "company")):
            raise forms.ValidationError(_("Renseignez au moins un nom, une adresse e-mail ou une société."))
        return donnees


class RendezVousDuContactForm(forms.Form):
    """
    Un rendez-vous pris depuis la fiche d'un contact : sur un créneau libre
    de l'agenda, ou à une heure choisie librement (un appel, une réunion qui
    ne suit pas les disponibilités publiées). Dans le second cas, le temps
    est réservé quand même : les créneaux qu'il chevauche se ferment
    (`calendars.models.periodes_occupees`).
    """

    MODES = [("creneau", _("Sur un créneau libre")), ("libre", _("À une date et une heure libres"))]
    mode = forms.ChoiceField(label=_("Quand"), choices=MODES, initial="creneau", widget=forms.RadioSelect)
    slot = forms.ModelChoiceField(queryset=None, required=False, label=_("Créneau"),
                                  empty_label=_("Choisissez un créneau"))
    type = forms.ModelChoiceField(queryset=None, required=False, label=_("Type de rendez-vous"))
    date = forms.DateField(required=False, label=_("Date"), widget=forms.DateInput(attrs={"type": "date"}))
    heure = forms.TimeField(required=False, label=_("Heure"), widget=forms.TimeInput(attrs={"type": "time"}))
    visio = forms.BooleanField(
        required=False, label=_("Rendez-vous en visio"),
        help_text=_("Une séance est créée dans Conférence, à la date et pour la durée du rendez-vous ; "
                    "le contact y est invité avec son lien personnel."))
    message = forms.CharField(required=False, label=_("Objet ou note pour le rendez-vous"),
                              widget=forms.Textarea(attrs={"rows": 2}), max_length=2000)
    envoyer = forms.BooleanField(required=False, initial=True,
                                 label=_("Envoyer la confirmation au contact"))

    def __init__(self, *args, gestionnaire=None, superviseur=False, **kwargs):
        from django.utils import timezone

        from jeiko.calendars.forms import AppointmentClientCreateForm
        from jeiko.calendars.models import AppointmentType, Slot

        super().__init__(*args, **kwargs)
        creneaux = Slot.objects.filter(is_available=True, remaining_places__gt=0,
                                       start__gte=timezone.now()).select_related("type", "availability")
        types = AppointmentType.objects.all()
        if not superviseur:
            creneaux = creneaux.filter(availability__user=gestionnaire)
            types = types.filter(user=gestionnaire)
        self.fields["slot"].queryset = creneaux.order_by("start")
        self.fields["slot"].label_from_instance = AppointmentClientCreateForm._label
        self.fields["type"].queryset = types.order_by("name")

    def clean(self):
        donnees = super().clean()
        if donnees.get("mode") == "creneau":
            if not donnees.get("slot"):
                self.add_error("slot", _("Choisissez un créneau."))
        else:
            for champ in ("type", "date", "heure"):
                if not donnees.get(champ):
                    self.add_error(champ, _("Ce champ est obligatoire."))
        return donnees

    def enregistrer(self, *, email, user_id=None, client_name="", phone="", company="", job_title=""):
        """
        Crée le rendez-vous, confirmé ; None si un refus est posé sur le
        formulaire. Commun à la fiche d'un contact et à « Nouveau rendez-vous »
        (Rendez-vous › À venir) et à l'API des agents (`creer_rdv`) : créneau
        verrouillé, heure libre refusée si le praticien est déjà pris
        (`calendars.models.temps_pris`), sinon réservée ; séance de visio ;
        confirmation après COMMIT. Un refus de temps pris porte le code « pris ».
        """
        from datetime import datetime

        from django.db import transaction
        from django.utils import timezone

        from jeiko.calendars.models import Appointment, AppointmentType, Slot, recalculer_les_creneaux, temps_pris
        from jeiko.calendars.views import send_booking_emails_safe

        d = self.cleaned_data
        if d.get("visio") and not (email or user_id):
            self.add_error("visio", _("Ce contact n'a ni adresse e-mail ni compte : il ne pourrait pas recevoir son lien."))
            return None
        commun = dict(
            user_id=user_id, email=email or "", client_name=client_name or "", phone=(phone or "")[:30],
            company=company or "", job_title=job_title or "", message=d.get("message") or "",
            places=1, status=Appointment.Status.CONFIRMED,
        )
        with transaction.atomic():
            if d["mode"] == "creneau":
                slot = Slot.objects.select_for_update().select_related("type", "availability").get(pk=d["slot"].pk)
                if not slot.is_available or slot.remaining_places < 1:
                    self.add_error("slot", forms.ValidationError(
                        _("Ce créneau vient d'être pris : choisissez-en un autre."), code="pris"))
                    return None
                rdv = Appointment.objects.create(type=slot.type, slot=slot, start=slot.start, end=slot.end, **commun)
                slot.sync_remaining_places()
                slot.availability.update_slots_availability()
            else:
                debut = timezone.make_aware(datetime.combine(d["date"], d["heure"]))
                # Le type se verrouille : deux prises simultanées au même
                # moment ne passent pas toutes les deux le contrôle.
                AppointmentType.objects.select_for_update().filter(pk=d["type"].pk).first()
                if temps_pris(d["type"].user_id, debut, debut + d["type"].duration):
                    self.add_error("heure", forms.ValidationError(
                        _("Ce moment est déjà pris dans l'agenda du praticien (rendez-vous, séance de visio "
                          "ou agenda Google) : choisissez-en un autre."), code="pris"))
                    return None
                rdv = Appointment.objects.create(type=d["type"], start=debut,
                                                 end=debut + d["type"].duration, **commun)
                recalculer_les_creneaux(d["type"].user_id, rdv.start, rdv.end)
            if d.get("visio"):
                # La séance et l'invitation ; l'e-mail d'invitation part avec
                # la confirmation (`send_booking_emails`).
                from jeiko.visio.calendrier import mettre_en_visio
                mettre_en_visio(rdv)
            if d.get("envoyer"):
                transaction.on_commit(lambda pk=rdv.pk: send_booking_emails_safe(pk))
        return rdv


class NouveauRendezVousForm(RendezVousDuContactForm):
    """
    Un rendez-vous pris depuis Rendez-vous › À venir, pour quelqu'un qui n'a
    pas forcément de compte : un nom et une adresse suffisent. La fiche du
    CRM est retrouvée ou créée par l'adresse, comme à une réservation publique.
    """

    nom = forms.CharField(label=_("Nom"), max_length=200)
    email = forms.EmailField(label=_("Adresse e-mail"))
    field_order = ["nom", "email"]



class EntrepriseForm(forms.ModelForm):
    class Meta:
        from jeiko.questionnaires_expert.models import Company
        model = Company
        fields = ["name", "website", "email", "phone", "address", "postal_code", "city",
                  "country", "siret", "owner", "notes"]
        widgets = {"address": forms.Textarea(attrs={"rows": 2}), "notes": forms.Textarea(attrs={"rows": 4})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["owner"].queryset = get_user_model().objects.filter(
            is_staff=True, is_active=True).order_by("first_name", "last_name", "username")

    def clean_country(self):
        return (self.cleaned_data.get("country") or "").strip().upper()
