"""
Rapprocher deux fiches de la même personne — un geste HUMAIN.

Les doublons sont la règle, pas l'accident : une saisie publique n'est jamais
vérifiée, et deux noms différents à la même adresse font deux fiches
(`rattachement.py`). Seul l'exploitant sait qu'il s'agit de la même personne.

Rapprocher `doublon` dans `gardee` :
* ce que `gardee` n'a pas, elle le prend au doublon ; rien de ce qu'elle a
  n'est écrasé ;
* TOUT ce qui pointe vers le doublon la rejoint — passages de questionnaire,
  notes, tâches, pièces de vente, liens vers un compte. Les liens se lisent
  sur le modèle, pas dans une liste : un lien ajouté demain suit aussi. La
  liste écrite à la main oubliait les tâches (supprimées en cascade avec le
  doublon) et les pièces de vente (détachées du contact) — PK-01 F08 ;
* étiquettes réunies ; la date de création la plus ancienne l'emporte ;
* adresse vérifiée si l'une des deux l'était — même adresse, même preuve ;
* le doublon disparaît, et une note dit qui a rapproché quoi, quand.
"""
from django.db import transaction
from django.utils.translation import gettext as _

CHAMPS_COMPLETES = ("firstname", "lastname", "phone", "company", "job_title", "next_action", "owner_id")


@transaction.atomic
def rapprocher(gardee, doublon, acteur=None):
    from jeiko.users.models import Comments, ProspectLink

    if gardee.pk == doublon.pk:
        raise ValueError("Une fiche ne se rapproche pas d'elle-même.")

    for champ in CHAMPS_COMPLETES:
        if not getattr(gardee, champ) and getattr(doublon, champ):
            setattr(gardee, champ, getattr(doublon, champ))
    if not gardee.next_action_on and doublon.next_action_on:
        gardee.next_action_on = doublon.next_action_on
    gardee.tags = list(dict.fromkeys([*(gardee.tags or []), *(doublon.tags or [])]))
    gardee.email_verified = gardee.email_verified or doublon.email_verified
    if doublon.date_created and (not gardee.date_created or doublon.date_created < gardee.date_created):
        gardee.date_created = doublon.date_created

    # Un compte déjà relié aux deux fiches : le lien du doublon ferait doublon
    # (unique user + prospect) ; il part avec lui.
    deja = set(ProspectLink.objects.filter(prospect=gardee).values_list("user_id", flat=True))
    ProspectLink.objects.filter(prospect=doublon, user_id__in=deja).delete()
    for lien in type(doublon)._meta.related_objects:
        if not lien.one_to_many:
            raise NotImplementedError(f"Rapprochement : lien {lien} non pris en charge.")
        lien.related_model._base_manager.filter(**{lien.field.name: doublon}).update(**{lien.field.name: gardee})

    nom_du_doublon = doublon.nom_complet
    doublon.delete()
    gardee.save()
    Comments.objects.create(
        prospect=gardee, author=acteur, kind=Comments.Nature.NOTE,
        text=_("Fiche « %(nom)s » rapprochée de celle-ci.") % {"nom": nom_du_doublon},
    )
    return gardee
