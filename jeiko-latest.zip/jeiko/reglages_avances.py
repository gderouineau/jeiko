"""
Les réglages de fonctionnement qui se règlent À L'ÉCRAN (A-81, 09/10/2026).

Demande de Guillaume : « un serveur au point qu'on ne touche plus ». Les
durées de conservation, quelques délais et plafonds, une option de
référencement passent en base, modifiables dans Réglages › Général ›
Réglages avancés — sans éditer le .env ni redémarrer.

Ordre de lecture, pour ne rien casser :
1. la valeur réglée à l'écran (WebSite.reglages_avances), si elle existe ;
2. sinon ce que dit le settings / le .env du site, comme avant ;
3. sinon la valeur par défaut du code appelant, comme avant.
Une mise à jour ne change donc rien tant que personne ne règle rien.

Ce qui n'y est PAS, et n'y viendra pas : secrets (clé, base, sel), domaine,
HTTPS, confiance au proxy, nettoyage du HTML, protection contre les images
piégées, canal de mise à jour. Le site n'écrit jamais son .env : une faille
applicative lui donnerait ses propres secrets.
"""
from django.utils.translation import gettext_lazy as _

#: clé → (réglage historique du settings, groupe, libellé, aide, minimum, maximum).
#: Un maximum de None : pas de borne haute. Un booléen : minimum et maximum à None.
CATALOGUE = {
    "journal_securite_jours": ("JEIKO_SECURITY_EVENTS_RETENTION_DAYS", _("Conservation des données"),
                               _("Journal de sécurité (jours)"),
                               _("Connexions, échecs, changements de mot de passe. Les preuves d'effacement sont gardées."), 30, 3650),
    "sessions_jours": ("JEIKO_USER_SESSIONS_RETENTION_DAYS", _("Conservation des données"),
                       _("Sessions fermées (jours)"), _("Historique des appareils connectés à un compte."), 1, 365),
    "comptes_non_verifies_jours": ("JEIKO_UNVERIFIED_ACCOUNT_TTL_DAYS", _("Conservation des données"),
                                   _("Comptes jamais vérifiés (jours)"),
                                   _("Un compte dont l'adresse n'a jamais été confirmée est supprimé après ce délai."), 1, 365),
    "contacts_jours": ("JEIKO_CONTACTS_RETENTION_DAYS", _("Conservation des données"),
                       _("Contacts sans activité (jours)"),
                       _("Un contact sans compte, sans commande ni échange depuis ce délai est effacé (RGPD)."), 30, 3650),
    "paiement_rdv_minutes": ("JEIKO_CALENDARS_PAYMENT_HOLD_MINUTES", _("Rendez-vous"),
                             _("Créneau retenu pendant le paiement (minutes)"),
                             _("Au-delà, un rendez-vous payant non réglé libère son créneau."), 5, 1440),
    "liste_attente_minutes": ("JEIKO_CALENDARS_WAITLIST_CLAIM_MINUTES", _("Rendez-vous"),
                              _("Délai pour réclamer une place libérée (minutes)"),
                              _("La personne prévenue d'une place libre a ce temps pour la prendre ; ensuite, la suivante."), 5, 2880),
    "stock_bas": ("JEIKO_LOW_STOCK_THRESHOLD", _("Boutique"), _("Seuil de stock bas par défaut"),
                  _("Pour les produits sans seuil propre. Vide : pas d'alerte pour eux."), 0, None),
    "image_mo": ("JEIKO_MAX_IMAGE_UPLOAD_MB", _("Médias"), _("Taille maximale d'une image (Mo)"),
                 _("Le serveur refuse tout envoi de plus de 25 Mo : 24 au plus."), 1, 24),
    "pdf_mo": ("JEIKO_MAX_PDF_UPLOAD_MB", _("Médias"), _("Taille maximale d'un PDF (Mo)"),
               _("Le serveur refuse tout envoi de plus de 25 Mo : 24 au plus."), 1, 24),
    "videos_au_clic": (None, _("Médias"), _("Vidéos YouTube, Vimeo et Dailymotion chargées au clic"),
                       _("Rien n'est demandé au fournisseur avant que le visiteur clique : ni cookie, ni "
                         "adresse IP. Une vidéo en lecture automatique attend aussi le clic."), None, None),
    "agents_appels_heure": (None, _("Agents IA"), _("Appels par heure et par jeton"),
                            _("Plafond du site ; un agent peut avoir le sien (fiche de l'agent)."), 10, 100000),
    "agents_echecs_ip": (None, _("Agents IA"), _("Jetons invalides tolérés par adresse IP (15 min)"),
                         _("Arrête qui essaie des jetons au hasard. Le relever affaiblit cette garde."), 5, 100),
    "masquer_aux_moteurs": ("JEIKO_ROBOTS_DISALLOW_ALL", _("Référencement"), _("Masquer le site aux moteurs de recherche"),
                            _("Pendant la construction : robots.txt interdit tout le site. À décocher à l'ouverture."), None, None),
}


def _reglages_du_site():
    try:
        from jeiko.administration.website_cache import get_website_data

        site = get_website_data()
        return dict(getattr(site, "reglages_avances", None) or {})
    except Exception:  # base absente (migration, commande sans base) : comme avant
        return {}


def valeur(cle, defaut):
    """La valeur réglée à l'écran, sinon celle du settings, sinon `defaut`."""
    from django.conf import settings

    reglees = _reglages_du_site()
    if cle in reglees and reglees[cle] is not None:
        return reglees[cle]
    nom_settings = CATALOGUE[cle][0]
    return getattr(settings, nom_settings, defaut) if nom_settings else defaut


def valider(cle, brut):
    """Valeur propre pour `cle`, ou ValueError avec un message pour l'écran."""
    _settings, _groupe, libelle, _aide, minimum, maximum = CATALOGUE[cle]
    if minimum is None and maximum is None:
        return bool(brut)
    if brut in (None, ""):
        return None
    try:
        nombre = int(brut)
    except (TypeError, ValueError):
        raise ValueError(_("%(champ)s : un nombre entier est attendu.") % {"champ": libelle})
    if nombre < minimum or (maximum is not None and nombre > maximum):
        raise ValueError(_("%(champ)s : entre %(min)s et %(max)s.")
                         % {"champ": libelle, "min": minimum, "max": maximum if maximum is not None else "∞"})
    return nombre
