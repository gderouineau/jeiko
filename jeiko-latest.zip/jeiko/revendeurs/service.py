"""
Côté JEIKO.FR : qui est le revendeur, ce qu'il voit, ce qu'il crée, et ce
qu'il fait sur SES services (01/11/2026) — reprendre, réinstaller, résilier,
annuler une résiliation, lire le journal de l'installeur.

Chaque geste cherche la chose PARMI CELLES DU REVENDEUR (`_a_lui`) : celle
d'un autre, ou vendue en direct par jeiko.fr, est introuvable — la même
réponse que si elle n'existait pas. Les gestes sont ceux du menu Jeiko
(hebergement.etapes, hebergement.resiliation), signés de la licence du
revendeur au journal. Ce qui reste à jeiko.fr : confirmer une commande, et
reprendre une commande échouée — tout ce qui dépense.
"""
from django.conf import settings
from django.db import transaction
from django.db.models import Q
from django.utils.translation import gettext as _

from jeiko.administration.models import Licence, MiseEnLigne, Resiliation
from jeiko.hebergement import etapes, resiliation
from jeiko.hebergement.etapes import noter
from jeiko.hebergement.ovh import ErreurOVH
from jeiko.licences import cles
from jeiko.licences import service as licences


class Refus(Exception):
    """Une demande qui ne peut pas être servie : le message part au revendeur."""


class Introuvable(Refus):
    """Pas à lui — ou n'existe pas : il ne voit pas la différence."""


def revendeur_de_la_cle(cle):
    forme = cles.canonique(cle)
    licence = Licence.objects.filter(empreinte=cles.empreinte(forme), revendeur=True).first() if forme else None
    if licence is None:
        raise Refus(_("Clé revendeur inconnue."))
    if not licence.valide:
        raise Refus(_("Clé revendeur désactivée ou expirée."))
    return licence


def _mise_en_json(mise):
    # Ni la dernière erreur ni le journal : ils parlent du compte OVH de
    # jeiko.fr (dépense globale, bons). Les IP, pour que le client pose sa zone.
    return {
        "id": mise.pk, "domaine": mise.domaine, "etape": mise.etape, "etape_nom": mise.get_etape_display(),
        "statut": mise.statut, "statut_nom": mise.get_statut_display(), "produit": mise.produit,
        "prix_ht": str(mise.prix_ht) if mise.prix_ht is not None else None,
        "ipv4": mise.ipv4, "ipv6": mise.ipv6, "cree_le": mise.cree_le.isoformat(),
        "gestes": gestes_possibles(mise), "resiliations": [_resiliation_en_json(r) for r in mise.resiliations.all()],
    }


def _resiliation_en_json(r):
    programmee = r.etat == Resiliation.PROGRAMMEE
    return {
        "id": r.pk, "service_nom": r.get_service_display(), "choix_nom": r.get_choix_display(),
        "date_effet": r.date_effet.isoformat() if r.date_effet else None,
        "etat": "faite" if r.faite else r.etat, "annulable": programmee and not r.faite,
        "code_de_transfert": r.code_de_transfert if programmee and r.choix == Resiliation.TRANSFERT else "",
    }


def gestes_possibles(mise):
    """Ce que le revendeur peut faire sur ce service, maintenant ; la page n'offre que ceux-là."""
    M = MiseEnLigne
    possibles = {
        # Une commande échouée se reprend chez jeiko.fr : la reprendre peut envoyer le bon.
        "reprendre": mise.statut in (M.ECHEC, M.ATTENTE) and mise.etape not in (M.CONFIRMATION, M.COMMANDE),
        "reinstaller": mise.statut == M.TERMINEE,
        "envoyer-acces": mise.statut == M.TERMINEE and not mise.acces_envoyes_le,
        "abandonner": mise.statut not in (M.TERMINEE, M.ABANDONNEE),
        "resilier-vps": bool(mise.vps) and not resiliation.en_cours(Resiliation.VPS, mise),
        "resilier-domaine": (mise.mode_domaine != M.DOMAINE_AILLEURS and bool(mise.commande_id)
                             and not resiliation.en_cours(Resiliation.DOMAINE, mise)),
        "journal": bool(mise.ipv4) and mise.etape in (M.INSTALLATION, M.EN_LIGNE),
    }
    return [nom for nom, permis in possibles.items() if permis]


def _a_lui(revendeur, objet, pk):
    choses = {
        "services": MiseEnLigne.objects.filter(revendeur=revendeur),
        "licences": revendeur.clients.all(),
        "resiliations": Resiliation.objects.filter(Q(mise_en_ligne__revendeur=revendeur)
                                                   | Q(licence__vendue_par=revendeur)),
    }.get(objet)
    chose = choses.filter(pk=pk).first() if choses is not None else None
    if chose is None:
        raise Introuvable(_("Introuvable."))
    return chose


def journal(revendeur, pk):
    mise = _a_lui(revendeur, "services", pk)
    if "journal" not in gestes_possibles(mise):
        raise Refus(_("L'installeur n'a pas encore été lancé sur ce serveur."))
    return etapes.journal_d_installation(mise)


def geste(revendeur, objet, pk, nom, corps):
    """Un geste du menu Jeiko, sur une chose du revendeur ; signé de sa licence."""
    from jeiko.hebergement.forms import ResiliationForm

    chose = _a_lui(revendeur, objet, pk)
    if objet == "services" and nom not in gestes_possibles(chose):
        raise Refus(_("Ce geste n'est pas possible sur ce service maintenant."))
    try:
        if objet == "services" and nom in ("reprendre", "reinstaller"):
            (etapes.reprendre if nom == "reprendre" else etapes.reinstaller)(chose, revendeur)
            etapes.avancer(chose, par=revendeur)
        elif objet == "services" and nom == "abandonner":
            etapes.abandonner(chose, revendeur)
        elif objet == "services" and nom == "envoyer-acces":
            etapes.envoyer_les_acces(chose, revendeur)
        elif (objet == "services" and nom.startswith("resilier-")) or (objet, nom) == ("licences", "resilier"):
            service = nom.removeprefix("resilier-") if objet == "services" else Resiliation.LICENCE
            form = ResiliationForm(corps, service=service)
            if not form.is_valid():
                raise Refus(_erreurs(form))
            cible = {"licence": chose} if objet == "licences" else {"mise": chose}
            resiliation.resilier(service, revendeur, form.cleaned_data["choix"],
                                 date_effet=form.cleaned_data.get("date_effet"), **cible)
        elif (objet, nom) == ("resiliations", "annuler"):
            resiliation.annuler(chose, revendeur)
        else:
            raise Introuvable(_("Introuvable."))
    except (etapes.Echec, ErreurOVH) as souci:
        raise Refus(str(souci))


def clients(revendeur):
    mises = {}
    for mise in MiseEnLigne.objects.filter(revendeur=revendeur).order_by("cree_le"):
        mises.setdefault(mise.licence_id, []).append(_mise_en_json(mise))
    return [{
        "id": licence.pk, "titulaire": licence.titulaire, "email": licence.email, "domaine": licence.domaine,
        "cle": licence.cle_chiffree, "active": licence.valide,
        "expire_le": licence.expire_le.isoformat() if licence.expire_le else None,
        "mises_en_ligne": mises.get(licence.pk, []),
        "resiliations": [_resiliation_en_json(r) for r in licence.resiliations.all()],
        "resiliable": not resiliation.en_cours(Resiliation.LICENCE, licence=licence),
    } for licence in revendeur.clients.order_by("titulaire", "-cree_le")]


def nouveau_client(revendeur, corps):
    """
    Une licence pour le client (R5), et sa mise en ligne si `hebergement` est
    donné. Le corps est revalidé ici par les formulaires de l'écran : il vient
    d'un autre site.
    """
    from jeiko.hebergement.forms import MiseEnLigneForm

    from .forms import NouveauClientForm

    client = NouveauClientForm(corps)
    if not client.is_valid():
        raise Refus(_erreurs(client))
    d = client.cleaned_data
    hebergement = corps.get("hebergement")
    form = None
    if hebergement is not None:
        if not getattr(settings, "JEIKO_HEBERGEMENT_OVH", False):
            raise Refus(_("jeiko.fr ne propose pas l'hébergement pour l'instant."))
        if not isinstance(hebergement, dict):
            raise Refus(_("« hebergement » : un objet attendu."))
        form = MiseEnLigneForm({**hebergement, "client": d["titulaire"], "domaine": d["domaine"], "notes": ""})
        if not form.is_valid():
            raise Refus(_erreurs(form))
    with transaction.atomic():
        # La licence du client ne survit pas à celle du revendeur.
        licence, __ = licences.creer(titulaire=d["titulaire"], email=d["email"], domaine=d["domaine"],
                                     expire_le=revendeur.expire_le)
        licence.vendue_par = revendeur
        licence.save(update_fields=["vendue_par"])
        if form is None:
            noter(None, _("Licence créée par le revendeur %(revendeur)s pour %(client)s.")
                  % {"revendeur": revendeur.titulaire, "client": d["titulaire"]})
        else:
            mise = form.save(commit=False)
            mise.revendeur, mise.licence = revendeur, licence
            mise.save()
            # Le cron la mène au panier puis l'arrête à la confirmation : à Guillaume.
            noter(mise, _("Demandée par le revendeur %(revendeur)s.") % {"revendeur": revendeur.titulaire})
    return licence


def _erreurs(form):
    return " ".join(f"{nom} : {erreur}" for nom, erreurs in form.errors.items() for erreur in erreurs)
