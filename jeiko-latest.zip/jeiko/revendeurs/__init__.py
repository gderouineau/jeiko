"""
L'espace revendeur (OVH-01, R4–R6, 01/11/2026) : kojei.fr — ou tout autre
vitrine — vend des sites JEIKO, et c'est jeiko.fr qui exécute.

Deux moitiés, dans le même paquet :
* SUR JEIKO.FR (`JEIKO_SERVEUR_DE_LICENCES`) : l'API `/api/revendeurs/clients/`.
  Elle s'ouvre à une clé de licence que Guillaume a validée REVENDEUR sur sa
  fiche (`Licence.revendeur`) ; une clé de site ordinaire n'ouvre rien. Elle
  liste les clients du revendeur et en crée : une licence fabriquée pour le
  client (R5), et, si demandée, une mise en ligne chez OVH.
* SUR LE SITE REVENDEUR (`JEIKO_ESPACE_REVENDEUR`) : une page du menu Jeiko
  où l'on colle la clé revendeur, voit ses clients, en ajoute.

Ce qui tient :
* Le revendeur ne CONFIRME aucune commande : la mise en ligne s'arrête à
  l'étape « Confirmation », et c'est Guillaume qui la confirme sur jeiko.fr
  (R2, à la main pour l'instant). Le plafond du revendeur (R4) s'ajoute alors
  au plafond global : un dépassement de l'un ou l'autre refuse l'envoi du bon.
* Le revendeur ne voit que SES clients, jamais les réglages OVH, ni la
  dépense globale, ni le mot de passe d'un site (envoyé au client par
  jeiko.fr, D7).
* Retirer la validation, ou désactiver la clé : l'API répond 403 aussitôt.
* La page du site revendeur est gardée comme tout le menu Jeiko
  (jeiko/acces_jeiko.py) : compte du .env, super-administrateur, double
  authentification.

Ce que ça ne fait pas : facturer le revendeur (R3, ouvert — le revendeur reste
noté sur chaque licence et chaque mise en ligne, de quoi le faire), créer la
licence à la suite d'un paiement sur la boutique du revendeur (D8), résilier,
poser la licence dans le site mis en ligne.
"""
