# jeiko/secrets_d_adresse.py
"""
Les secrets que porte une adresse — et comment ne pas les garder.

Un lien PRIVÉ porte son secret dans l'adresse : devis à payer, résultat de
questionnaire, confirmation de newsletter, lien de visio, jeton du websocket
de la visio (`?access_token=…`). Gardé tel quel dans les statistiques ou un
journal d'accès, il devient lisible par qui lit ces données — et rejouable
(audit du paquet S06, audit de la visio V-19).

La règle, plutôt qu'une liste de routes (un futur lien privé est couvert sans
y penser) : est secret un segment de 16 caractères au moins qui est un UUID,
une valeur signée (« …:… »), une suite hexadécimale de 32 caractères ou plus,
ou un jeton aléatoire (capitales ET minuscules ET chiffres). Les adresses du
site — des slugs en minuscules — n'y ressemblent pas. Dans une requête, la
valeur d'un paramètre secret par son nom (jeton, token, code, key…) ou par
sa forme est masquée aussi.

Module SANS Django : gunicorn le charge avant l'application, pour son
journal d'accès (`jeiko/journal_gunicorn.py`).
"""
import logging
import re
from urllib.parse import parse_qsl, quote, urlsplit, urlunsplit

MASQUE = "…"
_UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I)
_HEXA = re.compile(r"[0-9a-f]{32,}")
NOMS_SECRETS = {"token", "access_token", "jeton", "code", "key", "cle", "signature", "sig", "secret"}


def segment_secret(segment):
    if not segment or len(segment) < 16:
        return False
    if ":" in segment or _UUID.fullmatch(segment) or _HEXA.fullmatch(segment):
        return True
    return (any(c.isupper() for c in segment) and any(c.islower() for c in segment)
            and any(c.isdigit() for c in segment))


def masquer_les_secrets(chemin):
    """Le chemin, ses segments secrets remplacés par « … »."""
    if not chemin:
        return chemin
    return "/".join(MASQUE if segment_secret(s) else s for s in chemin.split("/"))


def masquer_la_requete(requete):
    """La chaîne de requête, ses valeurs secrètes (par leur nom ou leur forme) masquées."""
    if not requete:
        return requete
    morceaux = []
    for nom, valeur in parse_qsl(requete, keep_blank_values=True):
        secret = nom.lower() in NOMS_SECRETS or segment_secret(valeur)
        morceaux.append(f"{quote(nom)}={MASQUE if secret else quote(valeur)}")
    return "&".join(morceaux)


def masquer_l_adresse(adresse):
    """Une adresse complète (un référent) : chemin et requête masqués."""
    if not adresse or adresse == "-":
        return adresse
    morceaux = urlsplit(adresse)
    return urlunsplit(morceaux._replace(path=masquer_les_secrets(morceaux.path),
                                        query=masquer_la_requete(morceaux.query)))


class FiltreDesSecrets(logging.Filter):
    """
    Filtre de journalisation (LOGGING du gabarit des réglages) : une adresse
    passée en argument d'un message (« Internal Server Error: %s ») y perd
    ses secrets. Ne refuse jamais une ligne.
    """

    def filter(self, record):
        if isinstance(record.args, tuple):
            record.args = tuple(masquer_les_secrets(a) if isinstance(a, str) and a.startswith("/") else a
                                for a in record.args)
        return True
