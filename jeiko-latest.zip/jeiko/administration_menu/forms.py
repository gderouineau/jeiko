# jeiko/administration_menu/forms.py

from django import forms
from jeiko.administration_menu.models import (
    Menu, MenuItem, MenuStyle,
    MenuPlace, MenuLayout, LAYOUTS_BY_PLACE
)
from jeiko.administration_pages.models import Page




class MenuForm(forms.ModelForm):
    # Radio pour le layout (les choix viennent du modèle)
    layout = forms.ChoiceField(
        choices=Menu._meta.get_field('layout').choices,
        widget=forms.RadioSelect(attrs={"class": "form-check-input"}),
        label="Disposition (layout)",
        required=True,
        help_text="Choisissez l’organisation du logo et des éléments du menu."
    )

    # Sélecteur de style (facultatif)
    menu_style = forms.ModelChoiceField(
        queryset=MenuStyle.objects.all().order_by("name"),
        required=False,
        empty_label="(Aucun style — utiliser les valeurs par défaut)",
        widget=forms.Select(attrs={"class": "form-select"}),
        label="Style visuel"
    )

    class Meta:
        model = Menu
        fields = ["name", "place", "layout", "menu_style"]
        labels = {
            "name": "Nom",
            "place": "Emplacement",
        }
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "place": forms.Select(attrs={"class": "form-select"}),
        }
        help_texts = {
            "place": "MAIN = menu principal, FOOTER = menu de pied de page.",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # place courant (POST > instance > NULL)
        place_val = (
            self.data.get(self.add_prefix("place"))
            or getattr(self.instance, "place", None)
            or MenuPlace.NULL
        )

        # Restreindre les layouts affichés selon place
        allowed = {c.value for c in LAYOUTS_BY_PLACE.get(place_val, set())}
        all_choices = list(MenuLayout.choices)
        filtered = [(k, v) for (k, v) in all_choices if k in allowed]

        if filtered:
            self.fields["layout"].choices = filtered
            self.fields["layout"].required = True
        else:
            self.fields["layout"].choices = []
            self.fields["layout"].required = False
            self.fields["layout"].widget = forms.HiddenInput()
            self.fields["layout"].help_text = "Aucun layout disponible pour cet emplacement."

    def clean(self):
        cleaned = super().clean()
        place = cleaned.get("place") or MenuPlace.NULL
        layout = cleaned.get("layout")

        allowed = {c.value for c in LAYOUTS_BY_PLACE.get(place, set())}
        if allowed:
            if not layout:
                self.add_error("layout", "Un layout est requis pour cet emplacement.")
            elif layout not in allowed:
                self.add_error("layout", "Ce layout n'est pas autorisé pour cet emplacement.")
        else:
            cleaned["layout"] = None

        return cleaned



class MenuItemForm(forms.ModelForm):
    # On ne montre QUE ce que l’utilisateur édite réellement.
    # 'menu' et 'main_menu' seront fixés par la view avant save().
    page = forms.ModelChoiceField(
        queryset=Page.objects.all(),
        required=False,
        label="Page (optionnel)",
    )

    class Meta:
        model = MenuItem
        fields = ["title", "active", "page"]
        widgets = {
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def clean(self):
        cleaned = super().clean()
        # Ici, pas de validation cross-field sur menu/main_menu,
        # c’est le modèle (clean()) + la view qui garantissent la cohérence.
        return cleaned



class MenuStyleForm(forms.ModelForm):
    class Meta:
        model = MenuStyle
        fields = [
            "background_color","text_color","hover_text_color","active_text_color",
            "submenu_background_color","submenu_border_color","submenu_hover_background_color",
            "font_family","font_weight","font_size_mobile","font_size_desktop","letter_spacing","uppercase",
            "menu_min_height","padding_y_mobile","padding_y_desktop","gap_desktop","gap_mobile",
            "logo_width_mobile","logo_width_desktop","logo_height_desktop",
            "border_bottom_width","border_bottom_color",
            "sticky","sticky_shadow","transitions_ms","rounded_submenu",
        ]
        widgets = {
            "background_color": forms.TextInput(attrs={"type":"color"}),
            "text_color": forms.TextInput(attrs={"type":"color"}),
            "hover_text_color": forms.TextInput(attrs={"type":"color"}),
            "active_text_color": forms.TextInput(attrs={"type":"color"}),
            "submenu_background_color": forms.TextInput(attrs={"type":"color"}),
            "submenu_border_color": forms.TextInput(attrs={"type":"color"}),
            "submenu_hover_background_color": forms.TextInput(attrs={"type":"color"}),
            "font_family": forms.TextInput(attrs={"placeholder": "ex: Inter, system-ui"}),
            "letter_spacing": forms.NumberInput(attrs={"step":"0.01"}),
        }
        labels = {"uppercase":"Majuscules"}
