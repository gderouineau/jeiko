# jeiko/administration_menu/forms.py

from django import forms
from jeiko.administration_menu.models import Menu, MenuItem
from jeiko.administration_pages.models import Page


class MenuForm(forms.ModelForm):
    class Meta:
        model = Menu
        fields = ["name", "place"]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "place": forms.Select(attrs={"class": "form-select"}),
        }


class MenuItemForm(forms.ModelForm):
    # On ne montre QUE ce que l’utilisateur édite réellement.
    # 'menu' et 'main_menu' seront fixés par la view avant save().
    page = forms.ModelChoiceField(
        queryset=Page.objects.all(),
        required=False,
        label="Page (optionnel)",
    )

    class Meta:
        model = MenuItem
        fields = ["title", "active", "page"]
        widgets = {
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def clean(self):
        cleaned = super().clean()
        # Ici, pas de validation cross-field sur menu/main_menu,
        # c’est le modèle (clean()) + la view qui garantissent la cohérence.
        return cleaned
