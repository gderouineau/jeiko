from django.urls import path
import jeiko.administration_menu.views

app_name = 'jeiko_administration_menu'
urlpatterns = [

    path(
        '',
        jeiko.administration_menu.views.Main.as_view(),
        name='main'
    ),

    path(
        '<str:place>/',
        jeiko.administration_menu.views.All.as_view(),
        name='view'
    ),

    path(
        '<str:place>/add',
        jeiko.administration_menu.views.Add.as_view(),
        name='add'
    ),

    path(
        '<str:place>/<int:id>/update',
        jeiko.administration_menu.views.Update.as_view(),
        name='update'
    ),

    path(
        'submenu/add/<int:parent_id>/',
        jeiko.administration_menu.views.AddSubMenu.as_view(),
        name='submenu_add'
    ),
    path(
        'submenu/update/<int:id>/',
        jeiko.administration_menu.views.UpdateSubMenu.as_view(),
        name='submenu_update'
    ),
    path(
        'submenu/delete/<int:id>/',
        jeiko.administration_menu.views.DeleteSubMenu.as_view(),
        name='submenu_delete'
    ),


]


