from django.contrib.auth.decorators import permission_required
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.core.cache import cache
from django.http import Http404
from django.shortcuts import render, redirect, get_object_or_404

from django.views import View
from django.views.generic.base import TemplateView

from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache


from django.core.cache import cache
from django.db import IntegrityError
from django.core.exceptions import ValidationError

from jeiko.administration_menu.forms import (
    MenuItemForm, MenuForm
)
from jeiko.administration_menu.models import (
    Menu, MenuItem
)


decorators = [never_cache]


@method_decorator(never_cache, name='dispatch')
class Main(View):

    template_name = 'administration_menu/main.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        menu_items_up = MenuItem.objects.filter(
            is_sub_menu=False,
            place="U",
        )
        menu_items_down = MenuItem.objects.filter(
            is_sub_menu=False,
            place="D",
        )

        context = {
            'menu_items_up': menu_items_up,
            'menu_items_down': menu_items_down,
        }

        return render(request, self.template_name, context)


@method_decorator(never_cache, name='dispatch')
class All(View):

    template_name = 'administration_menu/view.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        place = kwargs['place']

        menu_items = MenuItem.objects.filter(
            place=place,
            is_sub_menu=False,

        )

        context = {
            'place': place,
            'menu_items': menu_items,
        }

        return render(request, self.template_name, context)


@method_decorator(never_cache, name='dispatch')
class MenuList(View):
    template_name = 'administration_menu/menu/list.html'

    def get(self, request):
        menus = Menu.objects.all().order_by('name')
        ctx = {
            'menus': menus,
            'menus_main': Menu.objects.filter(place='MAIN'),
            'menus_footer': Menu.objects.filter(place='FOOTER'),
            'menus_neutral': Menu.objects.filter(place__isnull=True),
        }
        return render(request, self.template_name, ctx)


@method_decorator(never_cache, name='dispatch')
class MenuDetail(View):
    """
    Détail d’un menu : montre les items top-level + leurs sous-menus
    """
    template_name = 'administration_menu/menu/view.html'

    def get(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        items = (
            MenuItem.objects
            .filter(menu=menu, main_menu__isnull=True)
            .order_by('position', 'pk')
            .prefetch_related('submenus')
        )
        ctx = {
            'menu': menu,
            'items': items,
        }
        return render(request, self.template_name, ctx)


@method_decorator(never_cache, name='dispatch')
class MenuCreate(View):
    template_name = 'administration_menu/menu/form.html'
    form_class = MenuForm

    def get(self, request):
        form = self.form_class()
        return render(request, self.template_name, {'form': form, 'update': False, 'submit_text': 'Créer'})

    def post(self, request):
        form = self.form_class(request.POST)
        if form.is_valid():
            try:
                form.save()
                cache.clear()
                return redirect('jeiko_administration_menu:menu_list')
            except (IntegrityError, ValidationError) as e:
                # Contrainte unique conditionnelle sur place=U/D
                form.add_error('place', "Un menu est déjà assigné à cette position." )
        return render(request, self.template_name, {'form': form, 'update': False, 'submit_text': 'Créer'})


@method_decorator(never_cache, name='dispatch')
class MenuUpdate(View):
    template_name = 'administration_menu/menu/form.html'
    form_class = MenuForm

    def get(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        form = self.form_class(instance=menu)
        return render(request, self.template_name, {'form': form, 'update': True, 'menu': menu, 'submit_text': 'Modifier'})

    def post(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        form = self.form_class(request.POST, instance=menu)
        if form.is_valid():
            try:
                form.save()
                cache.clear()
                return redirect('jeiko_administration_menu:menu_list')
            except (IntegrityError, ValidationError):
                form.add_error('place', "Un menu est déjà assigné à cette position.")
        return render(request, self.template_name, {'form': form, 'update': True, 'menu': menu, 'submit_text': 'Modifier'})


@method_decorator(never_cache, name='dispatch')
class MenuDelete(View):
    template_name = 'administration_menu/menu_confirm_delete.html'

    def get(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        return render(request, self.template_name, {'menu': menu})

    def post(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        menu.delete()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_list')


# ========= CRÉATION / MÀJ / SUPPRESSION — ITEM TOP-LEVEL =========
@method_decorator(never_cache, name='dispatch')
class MenuItemCreate(View):
    template_name = 'administration_menu/menu_item/form.html'
    form_class = MenuItemForm

    def get(self, request, menu_id):
        menu = get_object_or_404(Menu, pk=menu_id)
        form = self.form_class(prefix='menu_item_')
        return render(request, self.template_name, {
            'menu': menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })

    def post(self, request, menu_id):
        menu = get_object_or_404(Menu, pk=menu_id)
        form = self.form_class(request.POST, prefix='menu_item_')
        if form.is_valid():
            item = form.save(commit=False)
            item.menu = menu
            item.main_menu = None
            item.save()
            cache.clear()
            return redirect('jeiko_administration_menu:menu_detail', pk=menu.pk)
        return render(request, self.template_name, {
            'menu': menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })


@method_decorator(never_cache, name='dispatch')
class MenuItemUpdate(View):
    template_name = 'administration_menu/menu_item/form.html'
    form_class = MenuItemForm

    def get(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        form = self.form_class(instance=item, prefix='menu_item_')
        return render(request, self.template_name, {
            'menu': item.menu,
            'item': item,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        form = self.form_class(request.POST, instance=item, prefix='menu_item_')
        if form.is_valid():
            # on NE modifie PAS menu/main_menu ici
            form.save()
            cache.clear()
            return redirect('jeiko_administration_menu:menu_detail', pk=item.menu.pk)
        return render(request, self.template_name, {
            'menu': item.menu,
            'item': item,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })


@method_decorator(never_cache, name='dispatch')
class MenuItemDelete(View):
    template_name = 'administration_menu/menu_item/confirm_delete.html'

    def get(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        return render(request, self.template_name, {'item': item, 'menu': item.menu})

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        item.delete()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=item.menu.pk)


@method_decorator(never_cache, name='dispatch')
class MenuItemMoveUp(View):

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        item.move_up()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=item.menu_id)

    def get(self, request, pk):
        # fallback pratique pour les liens <a>, uniquement en admin
        return self.post(request, pk)


@method_decorator(never_cache, name='dispatch')
class MenuItemMoveDown(View):

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        item.move_down()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=item.menu_id)

    def get(self, request, pk):
        return self.post(request, pk)


# ========= CRÉATION / MÀJ / SUPPRESSION — SOUS-MENU =========
@method_decorator(never_cache, name='dispatch')
class SubMenuCreate(View):
    template_name = 'administration_menu/menu_sub_item/form.html'
    form_class = MenuItemForm

    def get(self, request, parent_id):
        parent = get_object_or_404(MenuItem, pk=parent_id)
        form = self.form_class(prefix='menu_item_')
        return render(request, self.template_name, {
            'parent': parent,
            'menu': parent.menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })

    def post(self, request, parent_id):
        parent = get_object_or_404(MenuItem, pk=parent_id)
        form = self.form_class(request.POST, prefix='menu_item_')

        if form.is_valid():
            sub = form.save(commit=False)

            sub.menu_id = parent.menu_id
            sub.main_menu_id = parent.id
            sub._assign_position_if_needed()

            try:
                sub.full_clean()   # cohérence parent/menu
                sub.save()         # position auto (scope = frères du parent)
            except ValidationError as e:
                form.add_error(None, e.messages)
                return render(request, self.template_name, {
                    'parent': parent,
                    'menu': parent.menu,
                    'form': form,
                    'update': False,
                    'submit_text': 'Créer',
                })

            cache.clear()
            return redirect('jeiko_administration_menu:menu_detail', pk=parent.menu_id)

        return render(request, self.template_name, {
            'parent': parent,
            'menu': parent.menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })


@method_decorator(never_cache, name='dispatch')
class SubMenuUpdate(View):
    template_name = 'administration_menu/menu_sub_item/form.html'
    form_class = MenuItemForm

    def get(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        if not sub.main_menu_id:
            return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

        form = self.form_class(instance=sub, prefix='menu_item_')
        return render(request, self.template_name, {
            'parent': sub.main_menu,
            'menu': sub.menu,
            'sub': sub,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })

    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        if not sub.main_menu_id:
            return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

        form = self.form_class(request.POST, instance=sub, prefix='menu_item_')
        if form.is_valid():
            sub = form.save(commit=False)
            # ✅ On ne change PAS de parent/menu ici, on les verrouille
            sub.menu_id = sub.menu_id
            sub.main_menu_id = sub.main_menu_id
            try:
                sub.full_clean()
                sub.save()
            except ValidationError as e:
                form.add_error(None, e.messages)
                return render(request, self.template_name, {
                    'parent': sub.main_menu,
                    'menu': sub.menu,
                    'sub': sub,
                    'form': form,
                    'update': True,
                    'submit_text': 'Modifier',
                })

            cache.clear()
            return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

        return render(request, self.template_name, {
            'parent': sub.main_menu,
            'menu': sub.menu,
            'sub': sub,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })


@method_decorator(never_cache, name='dispatch')
class SubMenuDelete(View):
    template_name = 'administration_menu/menu_sub_item/confirm_delete.html'

    def get(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        return render(request, self.template_name, {
            'sub': sub,
            'menu': sub.menu,
            'parent': sub.main_menu
        })

    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        menu_id = sub.menu_id
        sub.delete()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=menu_id)


@method_decorator(never_cache, name='dispatch')
class SubMenuMoveUp(View):
    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        sub.move_up()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

    def get(self, request, pk):
        # fallback pratique pour les liens <a> en admin
        return self.post(request, pk)


@method_decorator(never_cache, name='dispatch')
class SubMenuMoveDown(View):
    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        sub.move_down()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

    def get(self, request, pk):
        return self.post(request, pk)

