import os


from django.db import models
from django.core.validators import RegexValidator


from jeiko.administration_pages.models import Page

alphanumeric = RegexValidator(r'^[A-Za-z_-]*$', 'Seules des lettres sont autorisées et les tirets')

MENU_PLACE = [

    ('U', 'Haut'),
    ('D', 'Bas'),

]

class MenuItem(models.Model):

    title = models.CharField(
        max_length=100,
        verbose_name="titre",
        default="",
    )

    position = models.IntegerField(
        default=0,
    )

    place = models.CharField(
        max_length=1,
        default="U",
        choices=MENU_PLACE,
    )

    active = models.BooleanField(
        default=False,
    )

    main_menu = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        related_name="submenus",
        blank=True,
        null=True,
    )

    is_sub_menu = models.BooleanField(
        default=False,
    )

    page = models.ForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name="menus",
        null=True,
        blank=True,
    )


    class Meta:
        ordering = ('position',)

    def __str__(self):
        return self.title


