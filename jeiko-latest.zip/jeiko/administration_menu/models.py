

from django.db import models, transaction
from django.db.models import Q, Max, Index
from django.core.exceptions import ValidationError
from django.core.cache import cache
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

from jeiko.administration_pages.models import Page


MENU_PLACE = [

    ("NULL", "Non assigné"),
    ('MAIN', 'Menu Principal'),
    ('FOOTER', 'Footer'),

]


class Menu(models.Model):

    name = models.CharField(
        max_length=200,
        verbose_name='nom',
        default=""
    )

    place = models.CharField(
        max_length=10,
        default="NULL",
        choices=MENU_PLACE,
    )

    class Meta:
        constraints = [
            # Au plus 1 Menu avec place='U'
            models.UniqueConstraint(
                fields=['place'],
                condition=Q(place='MAIN'),
                name='uq_single_menu_main',
            ),
            # Au plus 1 Menu avec place='D'
            models.UniqueConstraint(
                fields=['place'],
                condition=Q(place='FOOTER'),
                name='uq_single_menu_footer',
            ),
        ]


    def __str__(self):
        return self.name

class MenuItem(models.Model):

    title = models.CharField(
        max_length=100,
        verbose_name="titre",
        default="",
    )

    position = models.IntegerField(
        default=0,
    )

    menu = models.ForeignKey(
        Menu,
        related_name="menu_items",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )

    active = models.BooleanField(
        default=False,
    )

    main_menu = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        related_name="submenus",
        blank=True,
        null=True,
    )


    page = models.ForeignKey(
        Page,
        on_delete=models.SET_NULL,
        related_name="menus",
        null=True,
        blank=True,
    )


    class Meta:
        ordering = ('position',)
        # ---------- Contraintes d'unicité par scope (Point 1) ----------
        constraints = [
            # Unicité position pour les items top-level (main_menu IS NULL) dans un même menu
            models.UniqueConstraint(
                fields=['menu', 'position'],
                condition=Q(main_menu__isnull=True),
                name='uq_menuitem_top_position'
            ),
            # Unicité position pour les sous-menus sous un même parent
            models.UniqueConstraint(
                fields=['main_menu', 'position'],
                name='uq_menuitem_sub_position'
            ),
        ]
        # ---------- Index (Point 6) ----------
        indexes = [
            Index(fields=['menu', 'position']),
            Index(fields=['main_menu', 'position']),
        ]

    def __str__(self):
        return self.title

    @property
    def is_sub_menu(self) -> bool:
        return self.main_menu_id is not None

    def clean(self):
        # Pas de parent = top-level
        if self.main_menu_id:
            # Empêcher self-parent
            if self.main_menu_id == self.id:
                raise ValidationError("Un élément de menu ne peut pas être son propre parent.")
            # Le parent doit appartenir au même menu
            if self.main_menu and self.main_menu.menu_id != self.menu_id:
                raise ValidationError("Le parent doit appartenir au même menu.")
        super().clean()

    def _siblings_qs(self):
        """
        Retourne la QuerySet des 'frères' dans le même scope d’ordre :
          - Top-level: même 'menu' et main_menu IS NULL
          - Sous-menu: même 'main_menu'
        """
        if self.main_menu_id:
            return MenuItem.objects.filter(main_menu=self.main_menu)
        return MenuItem.objects.filter(menu=self.menu, main_menu__isnull=True)

    def _same_scope(self, other: 'MenuItem') -> bool:
        if not isinstance(other, MenuItem):
            return False
        # Tous deux sous le même parent
        if self.main_menu_id and other.main_menu_id:
            return self.main_menu_id == other.main_menu_id
        # Tous deux top-level du même menu
        if not self.main_menu_id and not other.main_menu_id:
            return self.menu_id == other.menu_id
        return False

    def _assign_position_if_needed(self):
        """
        Si l'instance est en création et que la position est nulle/<=0,
        attribue la prochaine position disponible dans le scope.
        """
        if not self._state.adding:
            return
        if self.position and self.position > 0:
            return

        qs = self._siblings_qs()
        max_pos = qs.aggregate(m=Max('position'))['m']
        if max_pos is None:
            self.position = 0
        else:
            self.position = max_pos + 1

    def save(self, *args, **kwargs):
        self._assign_position_if_needed()
        self.full_clean()
        super().save(*args, **kwargs)

    @transaction.atomic
    def move_up(self) -> bool:
        """
        Échange la position avec le voisin précédent dans le même scope.
        Retourne True si un swap a été effectué.
        """
        prev_qs = self._siblings_qs().filter(position__lt=self.position).order_by('-position')
        prev_item = prev_qs.first()
        if not prev_item:
            return False
        return self._swap_positions(prev_item)

    @transaction.atomic
    def move_down(self) -> bool:
        """
        Échange la position avec le voisin suivant dans le même scope.
        Retourne True si un swap a été effectué.
        """
        next_qs = self._siblings_qs().filter(position__gt=self.position).order_by('position')
        next_item = next_qs.first()
        if not next_item:
            return False
        return self._swap_positions(next_item)

    def _swap_positions(self, other: 'MenuItem') -> bool:
        """
        Swap robuste avec 'other' dans le même scope, en évitant les conflits d'unicité.
        """
        if not self._same_scope(other):
            return False
        if self.id == other.id:
            return False

        a_pos = self.position
        b_pos = other.position

        # Triple swap pour éviter collision de UniqueConstraint
        MenuItem.objects.filter(pk=self.pk).update(position=-1)
        MenuItem.objects.filter(pk=other.pk).update(position=a_pos)
        MenuItem.objects.filter(pk=self.pk).update(position=b_pos)

        # Rafraîchir les valeurs en mémoire
        self.position = b_pos
        other.position = a_pos
        return True


def _menu_cache_keys(instance: MenuItem):
    """
    Clés de cache à invalider pour un item donné.
    Tu pourras les réutiliser côté vues/templates si tu mets en place un cache par menu.
    """
    keys = [f"menu:{instance.menu_id}", f"menu:place:{instance.menu.place}"]
    # Pour les sous-menus, on peut invalider aussi la clé du parent
    if instance.main_menu_id:
        keys.append(f"menu:parent:{instance.main_menu_id}")
    return keys


@receiver(post_save, sender=MenuItem)
@receiver(post_delete, sender=MenuItem)
def invalidate_menuitem_cache(sender, instance: MenuItem, **kwargs):
    for key in _menu_cache_keys(instance):
        cache.delete(key)

@receiver(post_save, sender=Menu)
@receiver(post_delete, sender=Menu)
def invalidate_menu_cache(sender, instance: Menu, **kwargs):
    cache.delete(f"menu:place:{instance.place}")
    cache.delete(f"menu:{instance.pk}")

