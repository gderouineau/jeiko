# jeiko/administration_menu/utils.py
def get_menu_logo_urls(menu):
    """
    Retourne un dict d'URLs pour les variantes du logo :
    { 'full': ..., 'computer': ..., 'tablet': ..., 'mobile': ... }
    en privilégiant menu.logo, sinon WebSite.logo, sinon None.
    """
    if not menu:
        return None

    logo = None
    if getattr(menu, "logo_id", None):
        logo = menu.logo
    if logo is None:
        try:
            from jeiko.administration.models import WebSite
            site = WebSite.objects.select_related('logo').first()
            logo = getattr(site, 'logo', None)
        except Exception:
            logo = None

    if not logo:
        return None

    def _u(f):
        try:
            return f.url if f else None
        except Exception:
            return None

    return {
        "full": _u(getattr(logo, "full_size", None)),
        "computer": _u(getattr(logo, "computer_size", None)),
        "tablet": _u(getattr(logo, "tablet_size", None)),
        "mobile": _u(getattr(logo, "mobile_size", None)),
    }
