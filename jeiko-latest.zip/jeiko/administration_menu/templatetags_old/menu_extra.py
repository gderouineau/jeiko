# blog/templatetags/blog_extras.py

from django.template import Library, Node

from jeiko.administration_menu.models import MenuItem

register = Library()

class AllMenus(Node):
    def render(self, context):
        context['all_menus'] = MenuItem.objects.filter(
            active=True,
            place="U",
        ).order_by('position')
        return ''

@register.tag(name="get_all_menus")
def get_all_menus(parser, token):

    return AllMenus()

