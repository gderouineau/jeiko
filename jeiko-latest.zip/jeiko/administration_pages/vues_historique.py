"""
Brouillon et historique d'une page (administration_pages/historique.py) :
l'écran de l'historique, l'aperçu d'une version ou d'un brouillon, et les
gestes — préparer, publier ou abandonner un brouillon, restaurer une version.

Chaque geste qui écrit est un POST : un lien ouvert ailleurs ne doit ni
publier ni restaurer à l'insu de l'administrateur.
"""
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.decorators import method_decorator
from django.utils.formats import date_format
from django.utils.timezone import localtime
from django.utils.translation import gettext as _, gettext_lazy
from django.views import View
from django.views.decorators.cache import never_cache

from . import historique
from .models import Page
from .querysets import with_page_tree

MOTIFS = {
    historique.Motif.DEPART: gettext_lazy("Version de départ"),
    historique.Motif.MODIFICATIONS: gettext_lazy("Après modifications"),
    historique.Motif.AVANT_PUBLICATION: gettext_lazy("Avant la publication d'un brouillon"),
    historique.Motif.AVANT_RESTAURATION: gettext_lazy("Avant une restauration"),
    historique.Motif.AVANT_MODELE_LEGAL: gettext_lazy("Avant le modèle à jour (pages légales)"),
}


class _Droits(LoginRequiredMixin, PermissionRequiredMixin):
    permission_required = "administration_pages.change_page"
    raise_exception = True


def _quand(page_cachee):
    return date_format(localtime(page_cachee.role_le), "DATETIME_FORMAT")


@method_decorator(never_cache, name="dispatch")
class Historique(_Droits, View):
    def get(self, request, page_id):
        page = get_object_or_404(Page, pk=page_id)
        versions = [
            {"version": v, "motif": MOTIFS.get(v.role_motif, v.role_motif), "quand": _quand(v)}
            for v in historique.versions_de(page)
        ]
        return render(request, "administration_pages/historique.html", {
            "page": page,
            "possible": historique.a_un_historique(page),
            "brouillon": historique.brouillon_de(page),
            "versions": versions,
            "garder": historique.GARDER,
            "calme": int(historique.CALME.total_seconds() // 60),
        })


@method_decorator(never_cache, name="dispatch")
class Apercu(_Droits, View):
    """Une version ou un brouillon, rendus comme le site les rendrait."""

    def get(self, request, page_id):
        cachee = get_object_or_404(
            with_page_tree(Page.tous.exclude(role="")).select_related("rattachee_a"), pk=page_id)
        reponse = render(request, "administration_pages/apercu_cache.html", {
            "page": cachee,
            "page_du_site": cachee.rattachee_a,
            "quand": _quand(cachee),
            "breadcrumb": [],
        })
        reponse["X-Robots-Tag"] = "noindex, nofollow"
        return reponse


class CreerLeBrouillon(_Droits, View):
    def post(self, request, page_id):
        page = get_object_or_404(Page, pk=page_id)
        try:
            brouillon = historique.creer_le_brouillon(page, auteur=request.user)
        except ValueError:
            messages.error(request, _("Cette page ne se prépare pas en brouillon."))
            return redirect("jeiko_administration_pages:page_update", page.pk)
        return redirect("jeiko_administration_pages:page_editor", brouillon.pk)


def _brouillon(page_id):
    return get_object_or_404(Page.tous.select_related("rattachee_a"), pk=page_id, role=Page.Role.BROUILLON)


class PublierLeBrouillon(_Droits, View):
    def post(self, request, page_id):
        page = historique.publier_le_brouillon(_brouillon(page_id), auteur=request.user)
        messages.success(request, _(
            "Le brouillon est en ligne. La version qu'il remplace est gardée dans l'historique."))
        return redirect("jeiko_administration_pages:page_editor", page.pk)


class AbandonnerLeBrouillon(_Droits, View):
    def post(self, request, page_id):
        page = historique.abandonner_le_brouillon(_brouillon(page_id))
        messages.success(request, _("Le brouillon est abandonné. La page en ligne n'a pas changé."))
        return redirect("jeiko_administration_pages:page_historique", page.pk)


class ProgrammerLeBrouillon(_Droits, View):
    """HIST-01 : « Publier automatiquement le… » ; sans date, la programmation est annulée."""

    def post(self, request, page_id):
        from django.utils import timezone
        from django.utils.dateparse import parse_datetime

        brouillon = _brouillon(page_id)
        quand = parse_datetime(request.POST.get("quand") or "")
        if quand is not None and timezone.is_naive(quand):
            quand = timezone.make_aware(quand)
        try:
            historique.programmer_le_brouillon(brouillon, quand)
        except ValueError:
            messages.error(request, _("Choisissez une date à venir."))
        else:
            messages.success(request, _("Publication programmée le %(quand)s.") % {
                "quand": date_format(localtime(quand), "DATETIME_FORMAT")} if quand
                else _("Publication programmée annulée : le brouillon attend."))
        return redirect("jeiko_administration_pages:page_historique", brouillon.rattachee_a_id)


@method_decorator(never_cache, name="dispatch")
class Comparer(_Droits, View):
    """HIST-01 : deux états d'une page côte à côte — elle-même, son brouillon, ses versions."""

    def get(self, request, page_id):
        from django.db.models import Q

        from . import comparaison

        page = get_object_or_404(Page, pk=page_id)
        lignee = Page.tous.filter(Q(pk=page.pk) | Q(rattachee_a=page))

        def etat(cle):
            valeur = request.GET.get(cle)
            return get_object_or_404(lignee, pk=valeur) if (valeur or "").isdigit() else page

        avant, apres = etat("avant"), etat("apres")
        return render(request, "administration_pages/comparer.html", {
            "page": page, "avant": avant, "apres": apres,
            "libelle_avant": _libelle(avant), "libelle_apres": _libelle(apres),
            "tableau": comparaison.tableau(avant, apres, _libelle(avant), _libelle(apres)),
            "identiques": not comparaison.differences(avant, apres),
        })


def _libelle(etat):
    if etat.role == Page.Role.VERSION:
        return _("Version du %(quand)s") % {"quand": _quand(etat)}
    if etat.role == Page.Role.BROUILLON:
        return _("Brouillon")
    return _("Page en ligne")


class RestaurerLaVersion(_Droits, View):
    def post(self, request, page_id):
        version = get_object_or_404(Page.tous.select_related("rattachee_a"), pk=page_id,
                                    role=Page.Role.VERSION)
        quand = _quand(version)
        page = historique.restaurer(version, auteur=request.user)
        messages.success(request, _(
            "La version du %(quand)s est de nouveau en ligne. Ce qu'elle remplace est "
            "gardé dans l'historique.") % {"quand": quand})
        return redirect("jeiko_administration_pages:page_historique", page.pk)
