"""
Les pages 404, 403, 500 et 400 du site, écrites dans l'éditeur (A-10).

Le problème
-----------
« Cette page n'existe pas » et « Accès refusé » étaient deux gabarits figés
(`templates/404.html`, `403.html`) : même texte sur tous les sites, aucun lien
vers ce que le site propose, rien à traduire autrement qu'en publiant JEIKO.

Ce que fait ce module
---------------------
L'exploitant choisit une page ordinaire comme page 404, une autre comme page
403 (`WebSite.page_404`, `page_403` — Pages › Pages d'erreur, ou l'API). Elle
s'écrit dans l'éditeur comme les autres, se traduit comme les autres, et
s'affiche avec le BON code : 404, 403 — jamais 200, ce qui ferait d'une
adresse morte une page que Google indexe.

Elle peut — et devrait — être hors ligne : elle ne s'affiche alors qu'en cas
d'erreur, jamais à sa propre adresse. Sa version dans la langue du visiteur
est prise si elle existe, publiée ou non, pour la même raison.

Ce qu'il ne fait pas
--------------------
La 500 à part
-------------
Elle s'affiche quand quelque chose est tombé — la base, le plus souvent : on
ne peut pas y LIRE une page. On en écrit donc une copie statique, une par
langue, dans `MEDIA_ROOT/jeiko-erreurs/` (`ecrire_la_page_500`) : au choix de
la page, puis par le cron des 5 minutes dès que la page, ses traductions, les
menus ou les styles ont changé (`rafraichir_la_page_500`). `page_500` ne fait
que lire ce fichier, sans base ni gabarit ; sans fichier, `templates/500.html`.

Ce qu'il ne fait pas
--------------------
* La copie est rendue pour un visiteur anonyme : rien de personnel n'y entre,
  et un formulaire qu'elle porterait aurait un jeton CSRF périmé.
* nginx sert la même copie quand gunicorn lui-même est arrêté ou trop lent
  (502/504, `@jeiko_indisponible` dans 11_configure_nginx.sh), une fois le
  serveur mis à jour.
* Rien ne change sans réglage, ni sur un site dont le `urls.py` n'a pas été
  réaligné (les `handler404/403/500` y sont déclarés) : Django rend alors les
  gabarits figés, comme avant.
* Une erreur en rendant la page choisie ne doit pas en cacher une autre :
  elle est journalisée, et le gabarit figé prend le relais.
"""

import json
import logging
import os
from pathlib import Path

from django.conf import settings
from django.http import HttpResponseServerError
from django.shortcuts import render
from django.views import defaults

logger = logging.getLogger(__name__)

#: Les erreurs que Django laisse remplacer (handler400/403/404/500).
CODES = (404, 403, 500, 400)


def pages_possibles():
    """Les pages qu'on peut choisir : celles d'origine, publiées ou non, hors gabarits."""
    from .querysets import public_pages

    return (public_pages(include_unpublished=True)
            .filter(langue="").order_by("title"))


def page_choisie(code):
    """La page d'erreur `code` dans la langue du visiteur, ou `None`."""
    from jeiko.administration.models import WebSite
    from jeiko.langues_du_site import langue_du_site

    from .models import Page
    from .querysets import with_page_tree

    pk = WebSite.objects.values_list(f"page_{code}_id", flat=True).first()
    if not pk:
        return None
    pages = with_page_tree(Page.objects.all()).select_related(
        "metadata", "traduction_de", "category", "sub_category")
    langue = langue_du_site() or ""
    if langue:
        traduite = pages.filter(traduction_de_id=pk, langue=langue).first()
        if traduite:
            return traduite
    return pages.filter(pk=pk).first()


def _rendre(request, code, defaut, exception):
    try:
        page = page_choisie(code)
        if page is not None:
            from .views_client import build_breadcrumb_for_page

            contexte = {"page": page, "page_d_erreur": code,
                        "breadcrumb": build_breadcrumb_for_page(page)}
            if getattr(page, "metadata", None) is not None:
                contexte["metadata"] = page.metadata
            return render(request, "pages/main.html", contexte, status=code)
    except Exception:
        logger.exception("Page d'erreur %s impossible à rendre : gabarit par défaut.", code)
    return defaut(request, exception)


def page_404(request, exception=None):
    return _rendre(request, 404, defaults.page_not_found, exception)


def page_403(request, exception=None):
    # Un visiteur non connecté y trouve de quoi se connecter (connexion_requise.html).
    return _rendre(request, 403, defaults.permission_denied, exception)


def page_400(request, exception=None):
    return _rendre(request, 400, defaults.bad_request, exception)


# --------------------------------------------------------------------------
# La 500 : une copie statique
# --------------------------------------------------------------------------

def _dossier():
    return Path(settings.MEDIA_ROOT) / "jeiko-erreurs"


def _hote():
    """L'hôte de la requête fictive : le domaine du site parmi ALLOWED_HOSTS."""
    hotes = [h for h in settings.ALLOWED_HOSTS if h and h != "*" and not h.startswith(".")]
    locaux = {"localhost", "127.0.0.1", "testserver"}
    return next((h for h in hotes if h not in locaux), hotes[0] if hotes else "localhost")


def _versions_de_la_500():
    """{langue: page} — l'originale sous « », chaque traduction sous son code."""
    from jeiko.administration.models import WebSite
    from jeiko.langues_du_site import langues_actives

    from .models import Page

    pk = WebSite.objects.values_list("page_500_id", flat=True).first()
    if not pk:
        return {}
    versions = {"": Page.objects.filter(pk=pk).first()}
    for page in Page.objects.filter(traduction_de_id=pk, langue__in=langues_actives()):
        versions[page.langue] = page
    return {langue: page for langue, page in versions.items() if page is not None}


def _signature(versions):
    """Ce qui, en changeant, rend la copie périmée : la page, ses traductions, les liens, les styles."""
    from .page_cache import links_version, page_body_version, resources_version

    return {
        # Le titre et les métadonnées vivent hors du corps : pas dans sa version.
        "pages": {langue or "origine": [p.pk, page_body_version(p.pk), p.title,
                                        str(getattr(getattr(p, "metadata", None), "title", "")),
                                        str(getattr(getattr(p, "metadata", None), "description", ""))]
                  for langue, p in versions.items()},
        "liens": links_version(), "ressources": resources_version(),
    }


def _rendre_la_500(page, langue):
    from django.contrib.auth.models import AnonymousUser
    from django.contrib.sessions.backends.base import SessionBase
    from django.test import RequestFactory
    from django.utils import translation

    from jeiko import langues_du_site

    prefixe = f"/{langue}" if langue else ""
    requete = RequestFactory().get(f"{prefixe}/", HTTP_HOST=_hote(),
                                   secure=getattr(settings, "SECURE_SSL_REDIRECT", False))
    requete.user, requete.session = AnonymousUser(), SessionBase()
    requete.langue_du_prefixe = langue
    jeton = langues_du_site.fixer_la_langue(langue)
    try:
        with translation.override(langue or langues_du_site.langue_d_origine()):
            contexte = {"page": page, "page_d_erreur": 500}
            if getattr(page, "metadata", None) is not None:
                contexte["metadata"] = page.metadata
            return render(requete, "pages/main.html", contexte).content
    finally:
        langues_du_site.oublier_la_langue(jeton)


def ecrire_la_page_500():
    """
    (Ré)écrit la copie statique de la page 500, une par langue — ou l'efface
    sans page choisie. Chaque fichier est écrit à côté puis renommé : une
    erreur qui tombe pendant l'écriture lit l'ancien, jamais un demi-fichier.
    """
    dossier = _dossier()
    versions = _versions_de_la_500()
    voulus = {f"500.{l}.html" if l else "500.html" for l in versions} | ({"500.json"} if versions else set())
    if dossier.is_dir():
        for fichier in dossier.iterdir():
            if fichier.name not in voulus:
                fichier.unlink(missing_ok=True)
    if not versions:
        return 0
    # nginx sert ces fichiers quand gunicorn est arrêté (11_configure_nginx.sh,
    # @jeiko_indisponible) : mêmes modes qu'un média téléversé, lisibles par
    # le groupe www-data, quel que soit l'umask du processus qui écrit.
    dossier.mkdir(parents=True, exist_ok=True)
    os.chmod(dossier, getattr(settings, "FILE_UPLOAD_DIRECTORY_PERMISSIONS", None) or 0o2750)
    for langue, page in versions.items():
        contenu = _rendre_la_500(page, langue)
        cible = dossier / (f"500.{langue}.html" if langue else "500.html")
        provisoire = cible.with_suffix(".tmp")
        provisoire.write_bytes(contenu)
        os.chmod(provisoire, getattr(settings, "FILE_UPLOAD_PERMISSIONS", None) or 0o640)
        os.replace(provisoire, cible)
    (dossier / "500.json").write_text(json.dumps(_signature(versions)), encoding="utf-8")
    return len(versions)


def rafraichir_la_page_500():
    """Le cron : réécrit la copie si la page, ses traductions, les menus ou les styles ont changé."""
    versions = _versions_de_la_500()
    try:
        connue = json.loads((_dossier() / "500.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        connue = None
    if versions and connue == json.loads(json.dumps(_signature(versions))):
        return "à jour"
    if not versions and connue is None:
        return "aucune page choisie"
    return f"{ecrire_la_page_500()} copie(s) écrite(s)"


def page_500(request):
    """
    Sert la copie statique dans la langue du visiteur — sans base, sans
    gabarit : c'est peut-être eux qui sont tombés. Sans copie, le gabarit
    autonome de JEIKO.
    """
    try:
        from jeiko.langues_du_site import langue_du_site

        langue = langue_du_site() or ""
        dossier = _dossier()
        for nom in ([f"500.{langue}.html"] if langue else []) + ["500.html"]:
            if (dossier / nom).is_file():
                return HttpResponseServerError((dossier / nom).read_bytes())
    except Exception:
        logger.exception("Copie de la page 500 illisible : gabarit par défaut.")
    return defaults.server_error(request)


def ecrire_la_page_500_sans_lever():
    """Après un choix (écran, API) : la copie suit tout de suite ; un échec attend le cron."""
    try:
        ecrire_la_page_500()
    except Exception:
        logger.exception("Copie de la page 500 non écrite : le cron réessaiera.")
