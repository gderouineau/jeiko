# jeiko/administration_pages/utils.py
from django.forms import BaseInlineFormSet
from django.utils.datastructures import MultiValueDictKeyError
import datetime
from django.utils import timezone
from django.conf import settings
from django.views.decorators.http import require_GET
from django.http import Http404, JsonResponse, HttpResponse
from django.template.loader import render_to_string
from copy import deepcopy
from django.core.exceptions import ObjectDoesNotExist
from django.db import transaction
from urllib.parse import urljoin
from jeiko.administration_pages.forms import (

    SectionForm, LineForm, BlocSizeForm, BlocForm,
    StyleBoxForm, BackgroundImageForm, BackgroundImageParametersForm, SizeForm, CSSParametersForm,


)

from jeiko.administration.models import GoogleApi

from jeiko.administration_pages.models import (
    Section, Line, Bloc, Content,
    StyleBox, Size, ImageContent, BackgroundImageParameters,
    ContentText, ContentImage, ContentButton, ContentCalendar,
    ContentFormulaire, ContentChartQuestionnaire, ContentVideo,

    DynFAQItem, DynTabItem, DynCarouselSlide, DynProgressStep, DynTestimonialItem, DynLiveFilterItem,
    DynAccordionSection, DynAccordionChild, DynPricingPlan, DynPricingFeature, DynGalleryItem, DynStepperStep,
    DYNAMIC_DEFAULTS,

    PageInsights, Strategy
)

def _set(d, key, val):
    # d = QueryDict (mutable) ou dict
    try:
        d[key] = str(val) if val is not None else ''
    except MultiValueDictKeyError:
        d.appendlist(key, str(val) if val is not None else '')

def ensure_ids_and_orders_in_data(data, prefix, initial_count, total_count, start=1):
    """
    Remplit les champs cachés manquants pour un inline formset :
      - <prefix>-i-id       (pk pour lignes existantes, vide pour les nouvelles)-
      - <prefix>-i-ORDER    (1..n) si can_order ou si tu utilises ORDER
    Ne touche pas aux lignes marquées DELETE.
    """
    base = f"{prefix}-"
    # ids + ORDER pour formulaires existants
    for i in range(initial_count):
        del_flag = data.get(f"{base}{i}-DELETE")
        if del_flag:
            continue
        # si ORDER absent, on met i+start
        if not data.get(f"{base}{i}-ORDER"):
            _set(data, f"{base}{i}-ORDER", i + start)
        # si id absent (souvent la cause de 'id obligatoire'), on met un placeholder (il sera remplacé en 2e passe)
        if f"{base}{i}-id" not in data:
            _set(data, f"{base}{i}-id", "")  # sera backfill plus bas

    # lignes nouvelles (initial_count → total_count-1)
    cursor = start + initial_count
    for i in range(initial_count, total_count):
        del_flag = data.get(f"{base}{i}-DELETE")
        if del_flag:
            continue
        if not data.get(f"{base}{i}-ORDER"):
            _set(data, f"{base}{i}-ORDER", cursor)
        if f"{base}{i}-id" not in data:
            _set(data, f"{base}{i}-id", "")
        cursor += 1


def build_bound_inline_formset(data, files, formset_class, *, prefix, instance, start_order=1):
    """
    1) Instancie un formset *non bindé* pour lire initial_forms (et leurs PK),
    2) Backfill management form + id/ORDER manquants dans `data`,
    3) Retourne un formset *bindé* prêt à valider.
    """
    # 1) unbound pour connaître le nombre de formulaires initiaux et leurs pks
    fs0 = formset_class(prefix=prefix, instance=instance)
    initial_forms = fs0.initial_forms
    initial_count = len(initial_forms)

    # 2) compléter management_form si absent (ex: HTML partiel)
    data = data.copy()  # QueryDict -> mutable
    data[f"{prefix}-TOTAL_FORMS"]  = data.get(f"{prefix}-TOTAL_FORMS", str(initial_count))
    data[f"{prefix}-INITIAL_FORMS"] = data.get(f"{prefix}-INITIAL_FORMS", str(initial_count))
    data[f"{prefix}-MIN_NUM_FORMS"] = data.get(f"{prefix}-MIN_NUM_FORMS", "0")
    data[f"{prefix}-MAX_NUM_FORMS"] = data.get(f"{prefix}-MAX_NUM_FORMS", "1000")

    total = int(data.get(f"{prefix}-TOTAL_FORMS", initial_count) or initial_count)

    # 3) ids & ORDER manquants
    ensure_ids_and_orders_in_data(data, prefix, initial_count, total, start=start_order)

    # 4) backfill des PK manquantes pour les lignes existantes
    for i, f in enumerate(initial_forms):
        key = f"{prefix}-{i}-id"
        if not data.get(key):
            _set(data, key, f.instance.pk or "")

    # 5) formset bindé
    return formset_class(data=data, files=files, prefix=prefix, instance=instance)


def resequence_queryset(qs, field="order", start=1):
    """Sécurise l’ordre en base (1..n)."""
    i = start
    for obj in qs.order_by(field, "id"):
        if getattr(obj, field) != i:
            setattr(obj, field, i)
            obj.save(update_fields=[field])
        i += 1


def build_image_urls_4(img):
    """
    Retourne urls + srcset/sizes pour 4 paliers (mobile/tablet/computer/full).
    - Conserve la signature/clés historiques
    - Ajoute 'original'
    - Utilise laptop_size comme secours pour 'computer' si besoin
    """
    if not img:
        return {
            "original": None,
            "full": None, "computer": None, "tablet": None, "mobile": None,
            "best": None, "srcset": None, "sizes": None,
        }

    def _url(field):
        f = getattr(img, field, None)
        try:
            return f.url if f else None
        except Exception:
            return None

    # URLs par palier (on garde les clés historiques + original)
    urls = {
        "original": _url("original_image"),        # fichier source (non-WebP)
        "full":     _url("full_size"),             # 1920w WebP
        # computer: 992–1199. Si 'computer_size' manque, on retombe sur 'laptop_size' (1200w)
        "computer": _url("computer_size") or _url("laptop_size"),
        "tablet":   _url("tablet_size"),           # 991w WebP
        "mobile":   _url("mobile_size"),           # 767w WebP
    }

    # Best disponible : full > computer > tablet > mobile > original
    urls["best"] = (
        urls["full"] or urls["computer"] or urls["tablet"] or urls["mobile"] or urls["original"]
    )

    # srcset : on compose avec ce qu’on a (valeurs w cohérentes avec tes dérivés)
    parts = []
    if urls["mobile"]:
        parts.append(f"{urls['mobile']} 767w")
    if urls["tablet"]:
        parts.append(f"{urls['tablet']} 991w")

    # Si 'computer' vient de computer_size → 1199w ; s’il vient de laptop_size → 1200w
    comp_url = urls["computer"]
    if comp_url:
        comp_is_computer = bool(_url("computer_size")) and _url("computer_size") == comp_url
        comp_w = "1199w" if comp_is_computer else "1200w"
        parts.append(f"{comp_url} {comp_w}")

    if urls["full"]:
        parts.append(f"{urls['full']} 1920w")  # dérivée 1920w

    urls["srcset"] = ", ".join(parts) if parts else None

    # Sizes (4 paliers)
    urls["sizes"] = "(min-width: 1200px) 1200px, (min-width: 992px) 992px, (min-width: 768px) 768px, 100vw"

    return urls


def make_unique_url_tag(base_tag):
    """Génère un url_tag unique à partir du tag original."""
    timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
    return f"{base_tag}_copy_{timestamp}"


def duplicate_instance(obj, omit_fields=None, overrides=None):
    """Clone une instance Django, sans les relations FK, avec possibilité d’overrides."""
    omit_fields = omit_fields or []
    overrides = overrides or {}
    data = {}
    for field in obj._meta.fields:
        if field.name in omit_fields or field.auto_created:
            continue
        data[field.name] = getattr(obj, field.name)
    data.update(overrides)
    return obj.__class__.objects.create(**data)


def get_section_forms_context(page, data=None, files=None, instance=None):
    section_form = SectionForm(data=data, files=files, instance=instance)

    # StyleBox (marges / paddings) — ordre: phone, tablet, laptop, computer
    style_forms = [
        StyleBoxForm(data=data, prefix="margin_phone",   instance=getattr(instance, 'margin_phone',   None)),
        StyleBoxForm(data=data, prefix="margin_tablet",  instance=getattr(instance, 'margin_tablet',  None)),
        StyleBoxForm(data=data, prefix="margin_laptop",  instance=getattr(instance, 'margin_laptop',  None)),   # ✅
        StyleBoxForm(data=data, prefix="margin_computer",instance=getattr(instance, 'margin_computer',None)),

        StyleBoxForm(data=data, prefix="padding_phone",   instance=getattr(instance, 'padding_phone',   None)),
        StyleBoxForm(data=data, prefix="padding_tablet",  instance=getattr(instance, 'padding_tablet',  None)),
        StyleBoxForm(data=data, prefix="padding_laptop",  instance=getattr(instance, 'padding_laptop',  None)), # ✅
        StyleBoxForm(data=data, prefix="padding_computer",instance=getattr(instance, 'padding_computer',None)),
    ]

    # Sizes — ordre: phone, tablet, laptop, computer
    size_forms = [
        SizeForm(data=data, instance=getattr(instance, "size_phone",    None), prefix="size_phone_"),
        SizeForm(data=data, instance=getattr(instance, "size_tablet",   None), prefix="size_tablet_"),
        SizeForm(data=data, instance=getattr(instance, "size_laptop",   None), prefix="size_laptop_"),  # ✅
        SizeForm(data=data, instance=getattr(instance, "size_computer", None), prefix="size_computer_"),
    ]

    # Background image
    bgimg_instance = getattr(instance, 'background_image', None) if instance else None
    background_image_form = BackgroundImageForm(
        data=data, files=files, instance=bgimg_instance, prefix="background_image_"
    )
    bgimg_params_instance = getattr(instance, 'background_image_parameters', None) if instance else None
    background_image_parameters_form = BackgroundImageParametersForm(
        data=data, instance=bgimg_params_instance, prefix="bgimg_params_"
    )

    # Exposition à plat (pour tes templates qui accèdent directement à margin_*_form / size_*_form)
    return {
        "page": page,
        "section_form": section_form,
        "style_forms": style_forms,
        "size_forms": size_forms,
        "background_image_form": background_image_form,
        "background_image_parameters_form": background_image_parameters_form,

        # Margins
        "margin_phone_form":   style_forms[0],
        "margin_tablet_form":  style_forms[1],
        "margin_laptop_form":  style_forms[2],
        "margin_computer_form":style_forms[3],

        # Paddings
        "padding_phone_form":   style_forms[4],
        "padding_tablet_form":  style_forms[5],
        "padding_laptop_form":  style_forms[6],
        "padding_computer_form":style_forms[7],

        # Sizes
        "size_phone_form":    size_forms[0],
        "size_tablet_form":   size_forms[1],
        "size_laptop_form":   size_forms[2],
        "size_computer_form": size_forms[3],
    }


def get_line_forms_context(page, data=None, files=None, instance=None):
    line_form = LineForm(data=data, files=files, instance=instance)

    # StyleBox (marges / paddings) — ordre: phone, tablet, laptop, computer
    style_forms = [
        StyleBoxForm(data=data, prefix="margin_phone",   instance=getattr(instance, 'margin_phone',   None)),
        StyleBoxForm(data=data, prefix="margin_tablet",  instance=getattr(instance, 'margin_tablet',  None)),
        StyleBoxForm(data=data, prefix="margin_laptop",  instance=getattr(instance, 'margin_laptop',  None)),
        StyleBoxForm(data=data, prefix="margin_computer",instance=getattr(instance, 'margin_computer',None)),

        StyleBoxForm(data=data, prefix="padding_phone",   instance=getattr(instance, 'padding_phone',   None)),
        StyleBoxForm(data=data, prefix="padding_tablet",  instance=getattr(instance, 'padding_tablet',  None)),
        StyleBoxForm(data=data, prefix="padding_laptop",  instance=getattr(instance, 'padding_laptop',  None)),
        StyleBoxForm(data=data, prefix="padding_computer",instance=getattr(instance, 'padding_computer',None)),
    ]

    # Sizes — ordre: phone, tablet, laptop, computer
    size_forms = [
        SizeForm(data=data, instance=getattr(instance, "size_phone",    None), prefix="size_phone_"),
        SizeForm(data=data, instance=getattr(instance, "size_tablet",   None), prefix="size_tablet_"),
        SizeForm(data=data, instance=getattr(instance, "size_laptop",   None), prefix="size_laptop_"),
        SizeForm(data=data, instance=getattr(instance, "size_computer", None), prefix="size_computer_"),
    ]

    # Background image
    bgimg_instance = getattr(instance, 'background_image', None) if instance else None
    background_image_form = BackgroundImageForm(
        data=data, files=files, instance=bgimg_instance, prefix="background_image_"
    )
    bgimg_params_instance = getattr(instance, 'background_image_parameters', None) if instance else None
    background_image_parameters_form = BackgroundImageParametersForm(
        data=data, instance=bgimg_params_instance, prefix="bgimg_params_"
    )

    # Exposition à plat (pour tes templates qui accèdent directement à margin_*_form / size_*_form)
    return {
        "page": page,
        "line_form": line_form,
        "style_forms": style_forms,
        "size_forms": size_forms,
        "background_image_form": background_image_form,
        "background_image_parameters_form": background_image_parameters_form,

        # Margins
        "margin_phone_form":   style_forms[0],
        "margin_tablet_form":  style_forms[1],
        "margin_laptop_form":  style_forms[2],
        "margin_computer_form":style_forms[3],

        # Paddings
        "padding_phone_form":   style_forms[4],
        "padding_tablet_form":  style_forms[5],
        "padding_laptop_form":  style_forms[6],
        "padding_computer_form":style_forms[7],

        # Sizes
        "size_phone_form":    size_forms[0],
        "size_tablet_form":   size_forms[1],
        "size_laptop_form":   size_forms[2],
        "size_computer_form": size_forms[3],
    }


def get_bloc_forms_context(bloc, data=None):
    """Prépare les forms pour marges/paddings/tailles + CSS du bloc."""
    style_instances = [
        bloc.margin_phone, bloc.margin_tablet, bloc.margin_laptop, bloc.margin_computer,     # ✅ + laptop
        bloc.padding_phone, bloc.padding_tablet, bloc.padding_laptop, bloc.padding_computer, # ✅ + laptop
    ]
    size_instances = [bloc.size_phone, bloc.size_tablet, bloc.size_laptop, bloc.size_computer]  # ✅ + laptop

    style_forms = [
        # Margins
        StyleBoxForm(data=data, prefix="margin_phone", instance=getattr(bloc, 'margin_phone', None)),
        StyleBoxForm(data=data, prefix="margin_tablet", instance=getattr(bloc, 'margin_tablet', None)),
        StyleBoxForm(data=data, prefix="margin_laptop", instance=getattr(bloc, 'margin_laptop', None)),
        StyleBoxForm(data=data, prefix="margin_computer", instance=getattr(bloc, 'margin_computer', None)),

        # Paddings
        StyleBoxForm(data=data, prefix="padding_phone", instance=getattr(bloc, 'padding_phone', None)),
        StyleBoxForm(data=data, prefix="padding_tablet", instance=getattr(bloc, 'padding_tablet', None)),
        StyleBoxForm(data=data, prefix="padding_laptop", instance=getattr(bloc, 'padding_laptop', None)),
        StyleBoxForm(data=data, prefix="padding_computer", instance=getattr(bloc, 'padding_computer', None)),

    ]
    size_forms = [
        BlocSizeForm(data=data, instance=getattr(bloc, "size_phone", None), prefix="size_phone_"),
        BlocSizeForm(data=data, instance=getattr(bloc, "size_tablet", None), prefix="size_tablet_"),
        BlocSizeForm(data=data, instance=getattr(bloc, "size_laptop", None), prefix="size_laptop_"),
        BlocSizeForm(data=data, instance=getattr(bloc, "size_computer", None), prefix="size_computer_"),
    ]

    css_instance = (bloc.content.CSS_parameters.first()
                    if hasattr(bloc, "content") and bloc.content and bloc.content.CSS_parameters.exists()
                    else None)
    css_form = CSSParametersForm(data=data, instance=css_instance, prefix="css_")

    return {
        "style_forms": style_forms,
        "size_forms": size_forms,
        "css_form": css_form,

        # Margins (alias à plat)
        "margin_phone_form": style_forms[0],
        "margin_tablet_form": style_forms[1],
        "margin_laptop_form": style_forms[2],
        "margin_computer_form": style_forms[3],

        # Paddings (alias à plat)
        "padding_phone_form": style_forms[4],
        "padding_tablet_form": style_forms[5],
        "padding_laptop_form": style_forms[6],
        "padding_computer_form": style_forms[7],

        # Sizes (alias à plat)
        "size_phone_form": size_forms[0],
        "size_tablet_form": size_forms[1],
        "size_laptop_form": size_forms[2],
        "size_computer_form": size_forms[3],
    }


def image_sources(img):
    """
    Retourne un dict d'URLs par palier + alt.
    - Conserve les clés historiques: mobile/tablet/laptop/computer/full
    - Ajoute 'original' (URL du fichier original non webp)
    - Fallbacks élargis vers original_image quand une dérivée manque
    """
    if not img:
        return {}

    def url_or_none(f):
        try:
            return f.url if f else None
        except Exception:
            return None

    return {
        # Fallback chain élargie jusqu’à l’original
        "mobile":   url_or_none(img.mobile_size)
                    or url_or_none(img.tablet_size)
                    or url_or_none(img.laptop_size)
                    or url_or_none(img.computer_size)
                    or url_or_none(img.full_size)
                    or url_or_none(img.original_image),

        "tablet":   url_or_none(img.tablet_size),
        "laptop":   url_or_none(img.laptop_size),
        "computer": url_or_none(img.computer_size),

        # 1920w WEBP si présent (clé historique)
        "full":     url_or_none(img.full_size),

        # Nouveau: original (fichier source)
        "original": url_or_none(img.original_image),

        "alt":      (getattr(img, "alt", "") or ""),
    }


def _snapshot_for_content(content):
    """
    Sérialise un petit snapshot du contenu dyn pour faciliter le rendu client (optionnel côté front).
    Ne remplace pas les relations en base ; on stocke un résumé.
    """
    data = content.data or {}
    t = content.content_type

    if t == "DYN_FAQ":
        data["items"] = [
            {"title": it.title, "answer": it.answer, "open": it.open, "order": it.order}
            for it in content.faq_items.all().order_by("order", "id")
        ]

    elif t == "DYN_TABS":
        data["items"] = [
            {"label": it.label, "body": it.body, "order": it.order}
            for it in content.tab_items.all().order_by("order", "id")
        ]

    elif t == "DYN_CAROUSEL":
        data["items"] = [
            {
                "image_id": it.image_id,
                "external_src": it.external_src,
                "alt": it.alt,
                "caption": it.caption,
                "href": it.href,
                "open_in_new_tab": it.open_in_new_tab,
                "order": it.order,
            }
            for it in content.carousel_slides.all().order_by("order", "id")
        ]

    elif t == "DYN_PROGRESS":
        data["items"] = [{"label": it.label, "done": it.done, "order": it.order}
                         for it in content.progress_steps.all().order_by("order", "id")]

    elif t in ("DYN_TESTIMONIALS", "DYN_TESTIMONIALS_GRID"):
        data["items"] = [
            {"quote": it.quote, "author": it.author, "role": it.role, "avatar_id": it.avatar_id, "order": it.order}
            for it in content.testimonial_items.all().order_by("order", "id")
        ]

    elif t == "DYN_FILTER":
        data["items"] = [
            {"title": it.title, "category": it.category, "description": it.description, "order": it.order}
            for it in content.livefilter_items.all().order_by("order", "id")
        ]

    elif t == "DYN_ACCORDION_ADV":
        data["sections"] = [
            {
                "title": sec.title, "open": sec.open, "order": sec.order,
                "items": [{"title": ch.title, "body": ch.body, "open": ch.open, "order": ch.order}
                          for ch in sec.children.all().order_by("order", "id")]
            }
            for sec in content.accordion_sections.all().order_by("order", "id")
        ]

    elif t == "DYN_PRICING_TABLE":
        data["plans"] = [
            {
                "name": pl.name,
                "price_monthly": str(pl.price_monthly or ""),
                "price_yearly": str(pl.price_yearly or ""),
                "popular": pl.popular,
                "cta_label": pl.cta_label,
                "cta_href": pl.cta_href,
                "order": pl.order,
                "features": [f.label for f in pl.features.all().order_by("order", "id")],
            }
            for pl in content.pricing_plans.all().order_by("order", "id")
        ]


    elif t == "DYN_GALLERY_FILTER":
        items = []
        for it in content.gallery_items.all().order_by("order", "id"):
            items.append({
                "title": it.title,
                "category": it.category,
                "order": it.order,
                "image": image_sources(getattr(it, "image", None)),
            })
        existing = []
        try:
            if isinstance(content.data, dict):
                existing = list(content.data.get("categories", []))
        except Exception:
            existing = []
        if not existing:
            deduced = sorted(
                {(it.category or "").strip() for it in content.gallery_items.all() if (it.category or "").strip()})
            existing = (["all"] + deduced) if "all" not in [c.lower() for c in deduced] else deduced
        data["items"] = items
        data["categories"] = existing


    elif t == "DYN_STEPPER":
        data["items"] = [
            {
                "title": it.title,
                "body": it.body,
                "done": bool(getattr(it, "done", False)),
                "order": it.order,
            }
            for it in content.stepper_steps.all().order_by("order", "id")
        ]

    elif t == "DYN_RATING":
        # la vue a déjà mis rating/count/max/editable dans content.data
        # ici on passe simplement data tel quel
        data = {
            "rating": float(content.data.get("rating", 0.0)),
            "count": int(content.data.get("count", 0)),
            "max": int(content.data.get("max", 5)),
            "editable": bool(content.data.get("editable", False)),
        }
    return data


def _save_style_and_sizes(bloc, bloc_ctx_forms):
    """
    Sauve margins/paddings/sizes + CSS et réaffecte les Size au bloc.
    Supporte désormais : phone, tablet, laptop, computer.
    (Rétro-compatible si seulement 3 tailles sont présentes.)
    """
    # 1) Sauvegarder tous les forms (style + size + css)
    for f in [*bloc_ctx_forms.get("style_forms", []),
              *bloc_ctx_forms.get("size_forms", []),
              bloc_ctx_forms.get("css_form")]:
        if f is not None:
            f.save()

    # 2) Réaffecter les Size au bloc
    size_forms = bloc_ctx_forms.get("size_forms", [])
    size_instances = [getattr(f, "instance", None) for f in size_forms]

    if len(size_instances) >= 4:
        (bloc.size_phone,
         bloc.size_tablet,
         bloc.size_laptop,     # ✅ nouveau palier
         bloc.size_computer) = size_instances[:4]
    elif len(size_instances) == 3:
        # rétro-compat (anciens écrans sans laptop)
        bloc.size_phone, bloc.size_tablet, bloc.size_computer = size_instances

    bloc.save()



def _errors_dict(*forms_or_sets):
    out = {}
    for i, f in enumerate(forms_or_sets):
        if f is None:
            continue
        name = getattr(f, 'prefix', f.__class__.__name__) or f.__class__.__name__
        try:
            # FormSet ?
            forms = getattr(f, 'forms', None)
            non_form_errors = getattr(f, 'non_form_errors', None)
            if forms is not None:
                errs = {}
                for idx, sub in enumerate(forms):
                    if sub.errors:
                        errs[f"{name}[{idx}]"] = sub.errors
                if non_form_errors and non_form_errors():
                    errs[f"{name}.__all__"] = non_form_errors()
                if errs:
                    out[name] = errs
            else:
                if f.errors:
                    out[name] = f.errors
                nfe = getattr(f, 'non_field_errors', None)
                if nfe and nfe():
                    out[f"{name}.__all__"] = nfe()
        except Exception:
            pass
    return out


def ensure_sequential_orders(data, prefix: str, start: int = 1) -> None:
    """
    Remplit prefix-<i>-order pour les formulaires non vides et non supprimés, à partir de 'start' (par défaut 1).
    Ne touche pas aux extra vides.
    """
    if not hasattr(data, "keys"):
        return
    total = int(data.get(f"{prefix}-TOTAL_FORMS", 0) or 0)
    cursor = start
    base = f"{prefix}-"
    for i in range(total):
        # skip delete
        if data.get(f"{base}{i}-DELETE"):
            continue
        # détecter si le form i est “non vide” (hors champs de gestion/order/delete)
        non_empty = False
        prefix_i = f"{base}{i}-"
        for k in data.keys():
            if not k.startswith(prefix_i):
                continue
            if k.endswith("-DELETE") or k.endswith("-order") or k.endswith("-id"):
                continue
            if (val := data.get(k)) not in ("", None):
                non_empty = True
                break
        if not non_empty:
            continue
        # donner un ordre si manquant ou invalide
        key = f"{base}{i}-order"
        try:
            val = int(data.get(key))
            if val < start:
                raise ValueError
        except Exception:
            data[key] = str(cursor)
        cursor += 1


def resequence(qs, field: str = "order", start: int = 1) -> None:
    idx = start
    for obj in qs.order_by(field, "id"):
        if getattr(obj, field) != idx:
            setattr(obj, field, idx)
            obj.save(update_fields=[field])
        idx += 1


@require_GET
def editing_menu(request):
    """
    Retourne le fragment HTML du menu d'édition.
    """
    # Si besoin, vous pouvez passer un contexte ici.
    html = render_to_string('administration_pages/content/editing_menu.html', request=request)
    return HttpResponse(html)

def _dup_stylebox(sb, _cache):
    if not sb: return None
    if sb.pk in _cache['stylebox']: return _cache['stylebox'][sb.pk]
    copy = duplicate_instance(sb, omit_fields=['id', 'pk'])
    _cache['stylebox'][sb.pk] = copy
    return copy

def _dup_size(sz, _cache):
    if not sz: return None
    if sz.pk in _cache['size']: return _cache['size'][sz.pk]
    copy = duplicate_instance(sz, omit_fields=['id', 'pk'])
    _cache['size'][sz.pk] = copy
    return copy

def _dup_image(img, _cache):
    if not img: return None
    if img.pk in _cache['image']: return _cache['image'][img.pk]
    copy = duplicate_instance(img, omit_fields=['id', 'pk'])
    _cache['image'][img.pk] = copy
    return copy

def _dup_bgparams(p, _cache):
    if not p: return None
    if p.pk in _cache['bgparams']: return _cache['bgparams'][p.pk]
    copy = duplicate_instance(p, omit_fields=['id', 'pk'])
    _cache['bgparams'][p.pk] = copy
    return copy


def _duplicate_stylables_on(obj, overrides, _cache):
    """Renseigne toutes les FK stylables sur overrides à partir d'un obj source."""
    overrides.update({
        'margin_phone':   _dup_stylebox(getattr(obj, 'margin_phone'),   _cache),
        'margin_tablet':  _dup_stylebox(getattr(obj, 'margin_tablet'),  _cache),
        'margin_laptop':  _dup_stylebox(getattr(obj, 'margin_laptop'),  _cache),
        'margin_computer':_dup_stylebox(getattr(obj, 'margin_computer'),_cache),

        'padding_phone':   _dup_stylebox(getattr(obj, 'padding_phone'),   _cache),
        'padding_tablet':  _dup_stylebox(getattr(obj, 'padding_tablet'),  _cache),
        'padding_laptop':  _dup_stylebox(getattr(obj, 'padding_laptop'),  _cache),
        'padding_computer':_dup_stylebox(getattr(obj, 'padding_computer'),_cache),

        'size_phone':   _dup_size(getattr(obj, 'size_phone'),   _cache),
        'size_tablet':  _dup_size(getattr(obj, 'size_tablet'),  _cache),
        'size_laptop':  _dup_size(getattr(obj, 'size_laptop'),  _cache),
        'size_computer':_dup_size(getattr(obj, 'size_computer'),_cache),

        'background_image':             _dup_image(getattr(obj, 'background_image'), _cache),
        'background_image_parameters':  _dup_bgparams(getattr(obj, 'background_image_parameters'), _cache),
    })
    return overrides


def _duplicate_content_tree(content, content_copy, _cache):
    """
    Duplique entièrement un Content -> content_copy (déjà créé via duplicate_instance sans ses FKs).
    Gère types classiques + dyn. Copie profonde de .data et des CSS_parameters liés.
    """
    # -- classiques
    if content.content_type == "TEXT" and content.content_text_id:
        content_copy.content_text = duplicate_instance(content.content_text, omit_fields=['id', 'pk'])

    elif content.content_type == "IMAGE" and content.content_image_id:
        img_copy = _dup_image(content.content_image.image_content, _cache)
        ci_copy  = duplicate_instance(
            content.content_image, omit_fields=['id', 'pk', 'image_content'], overrides={'image_content': img_copy}
        )
        content_copy.content_image = ci_copy

    elif content.content_type == "BUTTON" and content.content_button_id:
        content_copy.content_button = duplicate_instance(content.content_button, omit_fields=['id', 'pk'])

    elif content.content_type == "CALENDAR" and content.content_calendar_id:
        content_copy.content_calendar = duplicate_instance(content.content_calendar, omit_fields=['id', 'pk'])

    elif content.content_type == "FORM" and content.content_formulaire_id:
        form_copy = duplicate_instance(content.content_formulaire, omit_fields=['id', 'pk'])
        for fld in content.content_formulaire.fields.all().order_by('order', 'id'):
            duplicate_instance(fld, omit_fields=['id', 'pk', 'formulaire'], overrides={'formulaire': form_copy})
        content_copy.content_formulaire = form_copy

    elif content.content_type == "CHART" and content.content_chart_id:
        content_copy.content_chart = duplicate_instance(content.content_chart, omit_fields=['id', 'pk'])

    elif content.content_type == "VIDEO" and content.content_video_id:
        poster_copy = _dup_image(content.content_video.poster, _cache) if content.content_video.poster_id else None
        vid_copy = duplicate_instance(
            content.content_video, omit_fields=['id', 'pk', 'poster'], overrides={'poster': poster_copy}
        )
        content_copy.content_video = vid_copy

    # -- dyn *
    t = content.content_type
    if t == "DYN_FAQ":
        for it in content.faq_items.all():
            duplicate_instance(it, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})

    elif t == "DYN_TABS":
        for tab in content.tab_items.all():
            duplicate_instance(tab, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})

    elif t == "DYN_CAROUSEL":
        for slide in content.carousel_slides.all():
            img_copy = _dup_image(slide.image, _cache) if slide.image_id else None
            duplicate_instance(slide, omit_fields=['id', 'pk', 'content', 'image'],
                               overrides={'content': content_copy, 'image': img_copy})

    elif t == "DYN_PROGRESS":
        for step in content.progress_steps.all():
            duplicate_instance(step, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})

    elif t in ("DYN_TESTIMONIALS", "DYN_TESTIMONIALS_GRID"):
        for it in content.testimonial_items.all():
            avatar_copy = _dup_image(it.avatar, _cache) if it.avatar_id else None
            duplicate_instance(it, omit_fields=['id', 'pk', 'content', 'avatar'],
                               overrides={'content': content_copy, 'avatar': avatar_copy})

    elif t == "DYN_FILTER":
        for it in content.livefilter_items.all():
            duplicate_instance(it, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})

    elif t == "DYN_ACCORDION_ADV":
        for sec in content.accordion_sections.all():
            sec_copy = duplicate_instance(sec, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})
            for ch in sec.children.all():
                duplicate_instance(ch, omit_fields=['id', 'pk', 'section'], overrides={'section': sec_copy})

    elif t == "DYN_PRICING_TABLE":
        for pl in content.pricing_plans.all():
            pl_copy = duplicate_instance(pl, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})
            for ft in pl.features.all():
                duplicate_instance(ft, omit_fields=['id', 'pk', 'plan'], overrides={'plan': pl_copy})

    elif t == "DYN_GALLERY_FILTER":
        for gi in content.gallery_items.all():
            img_copy = _dup_image(gi.image, _cache) if gi.image_id else None
            duplicate_instance(gi, omit_fields=['id', 'pk', 'content', 'image'],
                               overrides={'content': content_copy, 'image': img_copy})

    elif t == "DYN_STEPPER":
        for st in content.stepper_steps.all():
            duplicate_instance(st, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})

    # DYN_RATING / DYN_COUNTDOWN / DYN_COUNTDOWN_CTA : pas d’enfants relationnels

    # Data JSON + CSS params
    content_copy.data = deepcopy(content.data) if content.data else {}
    content_copy.save()
    for css in content.CSS_parameters.all():
        duplicate_instance(css, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})




@transaction.atomic
def bloc_duplicate(source_bloc: Bloc, *, target_line: Line = None, position: int = None,
                   as_model: bool = False, link_model: bool = False) -> Bloc:
    """
    Duplique un bloc complet (styles + background + content).
    NOTE:
      - Si position est None => conserve la position du bloc source.
      - Les flags as_model/link_model s'appliquent UNIQUEMENT à ce bloc,
        ne pas les propager implicitement depuis les parents.
    """
    cache = {'stylebox': {}, 'size': {}, 'image': {}, 'bgparams': {}}

    line = target_line or source_bloc.line
    if position is None:
        position = source_bloc.position if source_bloc.position is not None else 0

    overrides = {'line': line, 'position': position}
    _duplicate_stylables_on(source_bloc, overrides, cache)

    copy = duplicate_instance(
        source_bloc,
        omit_fields=[
            'id', 'pk', 'line', 'content',
            'background_image', 'background_image_parameters',
            'margin_phone','margin_tablet','margin_laptop','margin_computer',
            'padding_phone','padding_tablet','padding_laptop','padding_computer',
            'size_phone','size_tablet','size_laptop','size_computer',
        ],
        overrides=overrides
    )

    if as_model:
        copy.is_model = True
    if link_model:
        copy.model_source = source_bloc
    copy.save()

    # --- Content (reverse OneToOne)
    content_obj = None
    try:
        content_obj = source_bloc.content
    except ObjectDoesNotExist:
        content_obj = None

    if content_obj:
        content_copy = duplicate_instance(
            content_obj,
            omit_fields=[
                'id','pk','bloc',
                'content_text','content_image','content_text_questionnaire',
                'content_chart','content_button','content_calendar',
                'content_formulaire','content_video',
            ],
            overrides={'bloc': copy}
        )
        _duplicate_content_tree(content_obj, content_copy, cache)

        # Copier aussi les CSSParameters liés au content
        for css_param in content_obj.CSS_parameters.all():
            duplicate_instance(
                css_param,
                omit_fields=['id', 'pk', 'content'],
                overrides={'content': content_copy}
            )

    return copy


@transaction.atomic
def line_duplicate(source_line: Line, *, target_section: Section = None, position: int = None,
                   as_model: bool = False, link_model: bool = False) -> Line:
    """
    Duplique une ligne + tous ses blocs.
    NOTE:
      - Si position est None => conserve la position de la ligne source.
      - Les blocs enfants sont dupliqués SANS as_model / link_model par défaut
        (les enfants ne deviennent pas "model" et ne pointent pas vers un model_source).
    """
    cache = {'stylebox': {}, 'size': {}, 'image': {}, 'bgparams': {}}

    section = target_section or source_line.section
    if position is None:
        position = source_line.position if source_line.position is not None else 0

    overrides = {'section': section, 'position': position}
    _duplicate_stylables_on(source_line, overrides, cache)

    line_copy = duplicate_instance(
        source_line,
        omit_fields=[
            'id', 'pk', 'section', 'blocs',
            'background_image', 'background_image_parameters',
            'margin_phone','margin_tablet','margin_laptop','margin_computer',
            'padding_phone','padding_tablet','padding_laptop','padding_computer',
            'size_phone','size_tablet','size_laptop','size_computer',
        ],
        overrides=overrides
    )

    # Applique as_model / link_model uniquement sur la ligne, pas sur les blocs
    if as_model:
        line_copy.is_model = True
    if link_model:
        line_copy.model_source = source_line
    line_copy.save()

    # Blocs : DUPLIQUÉS en conservant leur position & SANS model/link
    for bloc in source_line.blocs.all().order_by('position', 'id'):
        bloc_duplicate(
            bloc,
            target_line=line_copy,
            position=bloc.position,      # conserve la position
            as_model=False,              # <- pas de model sur les enfants
            link_model=False             # <- pas de model_source sur les enfants
        )

    return line_copy


@transaction.atomic
def section_duplicate(source_section: Section, *, target_page=None, position: int = None,
                      as_model: bool = False, link_model: bool = False) -> Section:
    """
    Duplique une section + toutes ses lignes + blocs (contenus inclus).
    NOTE:
      - Si position est None => append à la fin de la page cible (comportement existant).
      - Les LIGNES et BLOCS enfants conservent leur position d'origine et ne sont pas marqués model,
        ni liés via model_source (pas de propagation).
    """
    cache = {'stylebox': {}, 'size': {}, 'image': {}, 'bgparams': {}}

    page = target_page or source_section.page
    if position is None:
        last = Section.objects.filter(page=page).order_by('-position').first()
        position = (last.position + 1) if last and last.position is not None else 0

    overrides = {'page': page, 'position': position}
    _duplicate_stylables_on(source_section, overrides, cache)

    section_copy = duplicate_instance(
        source_section,
        omit_fields=[
            'id','pk','page','lines',
            'background_image', 'background_image_parameters',
            'margin_phone','margin_tablet','margin_laptop','margin_computer',
            'padding_phone','padding_tablet','padding_laptop','padding_computer',
            'size_phone','size_tablet','size_laptop','size_computer',
        ],
        overrides=overrides
    )

    # Applique as_model / link_model uniquement sur la section
    if as_model:
        section_copy.is_model = True
    if link_model:
        section_copy.model_source = source_section
    section_copy.save()

    # Lignes : DUPLIQUÉES en conservant leur position & SANS model/link sur les enfants
    for line in source_section.lines.all().order_by('position', 'id'):
        line_duplicate(
            line,
            target_section=section_copy,
            position=line.position,     # conserve la position
            as_model=False,             # <- pas de model pour les enfants
            link_model=False            # <- pas de model_source pour les enfants
        )

    return section_copy




def get_latest_insight(page, strategy: str) -> PageInsights | None:
    """
    Récupère l'unique dernier insight pour (page, strategy).
    Avec le signal de purge, il ne devrait y en avoir qu'un.
    """
    return (
        PageInsights.objects
        .filter(page=page, strategy=strategy)
        .order_by("-fetched_at", "-pk")
        .first()
    )




def create_latest_insight(
    *,
    page,
    strategy: str,
    status: str,
    url_tested: str | None = None,
    scores: dict | None = None,        # {performance, accessibility, best_practices, seo, pwa}
    field_metrics: dict | None = None, # {crux_lcp_ms, crux_inp_ms, crux_cls}
    lab_metrics: dict | None = None,   # {lab_fcp_ms, lab_lcp_ms, lab_cls, lab_ttfb_ms, lab_speed_index_ms, lab_tbt_ms}
    error_message: str | None = None,
    raw_json: dict | None = None,
    **extras,  # <--- accepte les nouveaux champs (KPI/flags/failed_ids/http_status_code/top_issues, etc.)
) -> PageInsights:
    """
    Crée un nouveau run "dernier état" pour (page, strategy).
    Le signal post_save se charge de purger les anciens runs.
    Accepte en plus des kwargs supplémentaires et les applique s'ils existent sur le modèle.
    """

    # Normalise la stratégie vers la valeur 'mobile' / 'desktop'
    strat_val = getattr(strategy, "value", strategy)
    if strat_val not in (Strategy.MOBILE, Strategy.DESKTOP):
        if isinstance(strat_val, str) and "desktop" in strat_val.lower():
            strat_val = Strategy.DESKTOP
        elif isinstance(strat_val, str) and "mobile" in strat_val.lower():
            strat_val = Strategy.MOBILE

    obj = PageInsights(
        page=page,
        strategy=strat_val,
        status=status,
        url_tested=url_tested or "",
        error_message=error_message or "",
        raw_json=raw_json,
        fetched_at=timezone.now(),  # explicite (au cas où tu relies ça ailleurs)
    )

    # Scores (0–100)
    if scores:
        obj.score_performance = scores.get("performance")
        obj.score_accessibility = scores.get("accessibility")
        obj.score_best_practices = scores.get("best_practices")
        obj.score_seo = scores.get("seo")
        obj.score_pwa = scores.get("pwa")

    # Field (CrUX)
    if field_metrics:
        obj.crux_lcp_ms = field_metrics.get("crux_lcp_ms")
        obj.crux_inp_ms = field_metrics.get("crux_inp_ms")
        obj.crux_cls = field_metrics.get("crux_cls")

    # Lab (Lighthouse)
    if lab_metrics:
        obj.lab_fcp_ms = lab_metrics.get("lab_fcp_ms")
        obj.lab_lcp_ms = lab_metrics.get("lab_lcp_ms")
        obj.lab_cls = lab_metrics.get("lab_cls")
        obj.lab_ttfb_ms = lab_metrics.get("lab_ttfb_ms")
        obj.lab_speed_index_ms = lab_metrics.get("lab_speed_index_ms")
        obj.lab_tbt_ms = lab_metrics.get("lab_tbt_ms")

    # Nouveaux champs : KPI / flags / failed_ids / http_status_code / top_issues ...
    # On ne set que les attributs réellement présents sur le modèle (sécurisé).
    for key, val in (extras or {}).items():
        if hasattr(obj, key):
            setattr(obj, key, val)

    obj.save()  # <-- déclenche la purge via le signal (comme avant)
    return obj



def get_google_api_key() -> str | None:
    try:
        key_db = (GoogleApi.get_solo().psi_api_key or "").strip()
        if key_db:
            return key_db
    except Exception:
        pass
    key_env = (getattr(settings, "GOOGLE_PSI_API_KEY", "") or "").strip()
    return key_env or None


def page_public_url(page) -> str:
    """
    Construit l'URL publique absolue à donner à PageSpeed.
    - Domaine: env DOMAIN_NAME si défini, sinon ALLOWED_HOSTS[0], sinon localhost
    - Schéma: https par défaut (ou PUBLIC_SCHEME en settings)
    - Chemin: "/<url_tag>/"
    """
    scheme = getattr(settings, "PUBLIC_SCHEME", "https")
    domain = getattr(settings, "DOMAIN_NAME", None)
    if not domain:
        hosts = getattr(settings, "ALLOWED_HOSTS", [])
        domain = hosts[0] if hosts else "localhost:8000"

    slug = (getattr(page, "url_tag", "") or "").strip("/")
    path = f"/{slug}/" if slug else "/"
    base = f"{scheme}://{domain}"
    return urljoin(base, path)