
from django.shortcuts import render, get_object_or_404, redirect

from django.views import View

from django.utils.decorators import method_decorator
from django.views.decorators.csrf import ensure_csrf_cookie

from django.http import HttpResponsePermanentRedirect

from jeiko.administration_pages.models import Page, Category



def build_breadcrumb_for_page(page):
    items = [{'name': 'Accueil', 'url': '/'}]
    cat = getattr(page, 'category', None)
    sub = getattr(page, 'sub_category', None)

    if cat:
        items.append({'name': cat.name, 'url': f'/{cat.slug}/' if cat.slug else None})
    if sub and sub.main_category_id == getattr(cat, 'id', None):
        items.append({'name': sub.name, 'url': f'/{cat.slug}/{sub.slug}/' if (cat and cat.slug and sub.slug) else None})

    items.append({'name': page.title, 'url': None})

@method_decorator(ensure_csrf_cookie, name='get')
class RootPage(View):

    template_name = 'pages/main.html'

    def get(self, request, *args, **kwargs):

        page = get_object_or_404(
            Page,
            is_root=True,
        )

        context = {
            'page': page,
            'breadcrumb': build_breadcrumb_for_page(page),
        }

        metadata = getattr(page, "metadata", None)
        if metadata is not None:
            context["metadata"] = metadata


        return render(request, self.template_name, context)


@method_decorator(ensure_csrf_cookie, name='get')
class PageView(View):
    template_name = 'pages/main.html'

    def get(self, request, *args, **kwargs):
        category_slug = kwargs.get('category_slug')
        sub_category_slug = kwargs.get('sub_category_slug')
        url_tag = kwargs.get('url_tag')

        page = self._resolve_page(category_slug, sub_category_slug, url_tag)

        # Canonical check (toujours un slash final dans get_absolute_url())
        canonical_path = page.get_absolute_url()
        if request.path != canonical_path:
            return HttpResponsePermanentRedirect(canonical_path)

        context = {
                'page': page,
                'breadcrumb': build_breadcrumb_for_page(page),
            }


        metadata = getattr(page, "metadata", None)
        if metadata is not None:
            context["metadata"] = metadata


        return render(
            request,
            self.template_name,
            context
        )

    # ---------- Helpers ----------
    def _resolve_page(self, category_slug, sub_category_slug, url_tag):
        """
        Règles:
          - /cat/sub/page/  -> page avec (cat.slug, sub.slug, url_tag) si canonique, sinon on redirige
          - /cat/page/      -> page avec (cat.slug, url_tag) si cat visible; sinon on redirige
          - /page/          -> page 'global' (pas de cat OU cat masquée)
        On select_related() pour éviter N+1 lors du check canonique.
        """
        qs = Page.objects.select_related('category', 'sub_category', 'sub_category__main_category')

        if category_slug and sub_category_slug:
            # 1) Cas /cat/sub/page/
            cat = get_object_or_404(Category, slug=category_slug)
            sub = get_object_or_404(Category, slug=sub_category_slug, main_category=cat)

            # On cherche d'abord le match exact (cat + sub + url_tag)
            try:
                page = qs.get(category=cat, sub_category=sub, url_tag=url_tag)
                return page
            except Page.DoesNotExist:
                # fallback: si une page existe pour (cat, url_tag) avec sub différent/masqué, on la récupère,
                # la 301 se fera sur la canonique plus bas
                page = get_object_or_404(qs, category=cat, url_tag=url_tag)
                return page

        if category_slug and not sub_category_slug:
            # 2) Cas /cat/page/
            cat = get_object_or_404(Category, slug=category_slug)
            # On essaye d'abord sans sous-cat visible
            try:
                page = qs.get(category=cat, url_tag=url_tag, sub_category__isnull=True)
                return page
            except Page.DoesNotExist:
                # Peut-être une page avec sub définie mais non visible, ou une page 'cat_sub' -> on récupère et on 301
                page = get_object_or_404(qs, category=cat, url_tag=url_tag)
                return page

        # 3) Cas /page/
        # Unicité garantie par la contrainte + clean() pour pages globales
        try:
            page = qs.get(url_tag=url_tag, category__isnull=True)
            return page
        except Page.DoesNotExist:
            # Catégorie masquée (show_cat_in_url=False)
            page = get_object_or_404(qs, url_tag=url_tag, category__show_cat_in_url=False)
            return page

