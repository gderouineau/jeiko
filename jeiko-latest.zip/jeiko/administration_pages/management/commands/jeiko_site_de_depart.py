"""
Monter le site de départ d'une installation neuve (SITE-01, 09/10/2026).

Pourquoi une commande, et pas une migration
-------------------------------------------
La migration `0002_seed_demo_site` montait trois pages avec le schéma de
2025 : sans thème, sans police, sans menu rattaché. Le premier écran d'un site
neuf était laid, et une migration ne pouvait pas faire mieux — elle ne voit
que le schéma de SON époque. Cette commande passe APRÈS toutes les
migrations : elle dispose de tout ce que sait faire JEIKO aujourd'hui.

Elle pose aussi les pages légales qui manquent (LEG-01,
`administration/pages_legales.py`).

Ce qu'elle monte vient d'un KIT (`site_de_depart/kit.<langue>.json`, celui
de la langue du site — SITE-01 bis), écrit dans le
format de l'API des agents (`POST /pages/creer/`, `PATCH /identite/`,
`POST /menus/creer/`) et passé par les MÊMES fonctions : mêmes refus, même
assainissement. On relit et on retouche la présentation dans ce fichier ; un
assistant branché par le MCP écrirait la même chose.

Garde-fous
----------
- Elle ne s'exécute que sur un site SANS page publique (hors pages légales et
  gabarits) : sur un site en service, elle refuse. L'installeur la lance une
  fois, à la création du site.
- `--refaire` remplace les pages et le menu qu'un passage précédent du kit a
  posés (reconnus à leur adresse) — pour retoucher la présentation sur une
  base d'essai. Elle refuse toujours si d'autres pages publiques existent.
- Tout ou rien : une erreur dans le kit ne laisse rien en base.

Ce qu'elle ne fait pas : télécharger quoi que ce soit d'obligatoire. La
police (Inter) est rapatriée par `rebuild_fonts` si le réseau le permet ;
sinon le site s'affiche dans la police de secours, et la commande le dit.
"""
import json
from pathlib import Path

from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

KITS = Path(__file__).resolve().parents[2] / "site_de_depart"


def kit_de_la_langue(langue):
    """kit.<langue>.json — en français si la langue n'a pas de kit (SITE-01 bis)."""
    chemin = KITS / f"kit.{(langue or 'fr')[:2].lower()}.json"
    return chemin if chemin.is_file() else KITS / "kit.fr.json"


def _resoudre(valeur, pages):
    """Remplace « @cle » par l'identifiant de la page du kit qui porte cette clé."""
    if isinstance(valeur, dict):
        return {k: _resoudre(v, pages) for k, v in valeur.items()}
    if isinstance(valeur, list):
        return [_resoudre(v, pages) for v in valeur]
    if isinstance(valeur, str) and valeur.startswith("@"):
        if valeur[1:] not in pages:
            raise CommandError(f"Le kit renvoie à une page inconnue : {valeur}.")
        return pages[valeur[1:]].id
    return valeur


def _pages_publiques_hors_kit(adresses_du_kit):
    from jeiko.administration_pages.models import Page
    from jeiko.administration_pages.querysets import public_pages

    return (public_pages(Page.objects.all(), include_unpublished=True)
            .filter(category__isnull=True)  # les pages légales sont rangées
            .exclude(url_tag__in=adresses_du_kit))


class Command(BaseCommand):
    help = "Monte le site de départ (pages, menu, couleurs, police) sur un site neuf."

    def add_arguments(self, parser):
        parser.add_argument("--refaire", action="store_true",
                            help="Remplace ce qu'un passage précédent du kit a posé.")
        parser.add_argument("--si-neuf", action="store_true",
                            help="Sur un site qui a déjà ses pages, ne rien faire (et réussir) "
                                 "au lieu de refuser : c'est l'appel de l'installeur, relançable.")
        parser.add_argument("--langue", help="fr, en, es, de, it — par défaut la langue du site (LANGUAGE_CODE).")
        parser.add_argument("--kit", help="Chemin d'un kit (JSON) ; sinon celui de la langue.")

    def handle(self, *args, **options):
        from jeiko.administration_menu.models import Menu, MenuStyle
        from jeiko.administration_pages.models import Page

        from django.conf import settings

        chemin = Path(options["kit"]) if options.get("kit") else kit_de_la_langue(
            options.get("langue") or settings.LANGUAGE_CODE)
        kit = json.loads(chemin.read_text(encoding="utf-8"))
        adresses = [p["url_tag"] for p in kit["pages"]]

        autres = list(_pages_publiques_hors_kit(adresses).values_list("title", flat=True)[:5])
        deja = Page.objects.filter(url_tag__in=adresses, category__isnull=True)
        if options["si_neuf"] and (autres or deja.exists()):
            self.stdout.write("Le site a déjà ses pages : site de départ non posé.")
            return
        if autres:
            raise CommandError(
                "Ce site a déjà des pages (" + ", ".join(autres) + ") : le site de "
                "départ ne se pose que sur un site neuf.")
        if deja.exists() and not options["refaire"]:
            raise CommandError("Le site de départ est déjà en place (--refaire pour le remplacer).")

        with transaction.atomic():
            # LEG-01 : les pages légales, qui ne viennent plus des migrations.
            # Celles qui existent ne sont pas touchées.
            from jeiko.administration.pages_legales import poser_les_manquantes
            poser_les_manquantes()
            deja.delete()
            Menu.objects.filter(name=kit["menu"]["nom"]).delete()
            if kit["menu"].get("style"):
                MenuStyle.objects.filter(name=kit["menu"]["style"]["name"]).delete()
            self._identite(kit["identite"])
            self._modules_eteints()
            pages = self._pages(kit["pages"])
            self._menu(kit["menu"], pages)

        from jeiko.administration.website_cache import invalidate_website_data
        invalidate_website_data()
        try:
            call_command("rebuild_fonts", verbosity=0)
        except Exception as souci:  # réseau absent : la police de secours suffit
            self.stderr.write(f"Police non rapatriée ({souci}) : le site garde la police de secours.")
        self.stdout.write(self.style.SUCCESS(
            f"Site de départ monté : {len(pages)} pages, menu « {kit['menu']['nom']} »."))

    # ------------------------------------------------------------------ #
    def _modules_eteints(self):
        """
        MOD-01 : un site NEUF montre un menu d'administration court — Boutique,
        Rendez-vous, Formations et Questionnaires masqués, à rallumer dans
        Réglages › Général. Cette commande ne monte que des sites neufs : les
        sites en service gardent leurs modules allumés (la valeur par défaut).
        """
        from jeiko.administration.models import WebSite
        from jeiko.administration.modules import MODULES

        site = WebSite.objects.first()
        if site is not None:
            for champ, _libelle in MODULES.values():
                setattr(site, champ, False)
            site.save(update_fields=[champ for champ, _l in MODULES.values()])

    # ------------------------------------------------------------------ #
    def _identite(self, identite):
        from jeiko.agents.vues_api import CorpsInvalide
        from jeiko.agents.vues_identite import _ecrire_les_couleurs, _ecrire_les_polices, _site

        site = _site()
        try:
            if identite.get("couleurs"):
                _ecrire_les_couleurs(site, identite["couleurs"])
            if identite.get("polices"):
                _ecrire_les_polices(site, identite["polices"])
        except CorpsInvalide as souci:
            raise CommandError(f"identite : {souci}")

    def _pages(self, documents):
        from jeiko.administration_pages.models import Page
        from jeiko.agents.vues_api import CorpsInvalide
        from jeiko.agents.vues_pages import _appliquer_metadonnees, _Construction

        # Toutes les pages d'abord : un bouton peut viser une page du kit
        # écrite plus loin (« @contact »).
        pages = {}
        for doc in documents:
            if doc.get("racine"):
                Page.objects.filter(is_root=True).update(is_root=False)
            pages[doc["cle"]] = Page.objects.create(
                title=doc["titre"], url_tag=doc["url_tag"], active=True,
                is_root=bool(doc.get("racine")),
            )
        # Les pages sont connues : les signaux ne cherchent pas, boîte par
        # boîte, à qui appartient ce qu'on enregistre (construction_de_pages).
        from jeiko.administration_pages.signals import construction_de_pages

        with construction_de_pages([p.pk for p in pages.values()]):
            for doc in documents:
                page = pages[doc["cle"]]
                construction = _Construction()
                try:
                    if doc.get("metadonnees"):
                        _appliquer_metadonnees(page, doc["metadonnees"])
                    for n, section in enumerate(_resoudre(doc.get("sections") or [], pages)):
                        construction.section(page, section, f"{doc['cle']}.sections[{n}]")
                except CorpsInvalide as souci:
                    raise CommandError(str(souci))
                for rappel in construction.avertissements:
                    self.stderr.write(f"Avertissement : {rappel}")
        return pages

    def _menu(self, document, pages):
        from django.core.exceptions import ValidationError

        from jeiko.administration_menu.models import Menu, MenuLayout, MenuPlace, MenuStyle
        from jeiko.agents.vues_api import CorpsInvalide
        from jeiko.agents.vues_menus import _ecrire_les_elements

        # Le style de menu n'est pas ouvert à l'API (un style sert plusieurs
        # menus) : le kit le donne en champs du modèle, que le modèle valide.
        style = None
        if document.get("style"):
            style = MenuStyle(**document["style"])
            try:
                style.full_clean()
            except ValidationError as souci:
                raise CommandError(f"menu.style : {souci}")
            style.save()
        Menu.objects.filter(place=MenuPlace.MAIN, is_default=True).update(is_default=False)
        menu = Menu.objects.create(
            name=document["nom"], place=MenuPlace.MAIN,
            layout=MenuLayout.LOGO_LEFT_MENU_RIGHT, is_default=True, menu_style=style,
        )
        try:
            _ecrire_les_elements(menu, _resoudre(document["elements"], pages))
        except CorpsInvalide as souci:
            raise CommandError(f"menu : {souci}")
