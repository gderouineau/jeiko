# jeiko/administration_pages/publication.py
"""
Conséquences de la publication d'une page sur le reste du site.

Dépublier n'est pas un geste isolé : si la page figure dans un menu, l'entrée
de navigation devient un lien mort. L'administrateur n'a aucun moyen de le
savoir depuis l'écran de la page — d'où ces helpers, utilisés par les vues pour
l'avertir avant qu'il ne casse sa propre navigation.
"""


def menus_referencing(page):
    """
    Noms des menus qui pointent vers cette page, sans doublon et triés.

    On ne retient que les entrées actives : une entrée déjà désactivée ne
    s'affiche nulle part, la dépublication ne change donc rien pour elle.
    """
    if not getattr(page, "pk", None):
        return []

    from jeiko.administration_menu.models import MenuItem

    noms = (
        MenuItem.objects
        .filter(page=page, active=True)
        .select_related("menu")
        .values_list("menu__name", flat=True)
    )
    return sorted({nom for nom in noms if nom})


def unpublish_warning(page):
    """
    Phrase à afficher avant de dépublier, ou "" s'il n'y a rien à signaler.

    Formulée du point de vue de la conséquence — ce que le visiteur va vivre —
    plutôt que de l'état interne : « la page disparaîtra du menu » se comprend,
    « MenuItem.page_id orphelin » non.
    """
    accueil = ""
    if getattr(page, "is_root", False):
        from django.utils.translation import gettext

        accueil = gettext(
            "C'est la page d'accueil : tant qu'elle n'est pas publiée, les visiteurs "
            "arrivent sur « Site en préparation ». Publiez-la de nouveau, ou désignez "
            "une autre page d'accueil."
        )
    menus = menus_referencing(page)
    if not menus:
        return accueil
    if accueil:
        return f"{accueil} {unpublish_warning_menus(menus)}"
    return unpublish_warning_menus(menus)


def unpublish_warning_menus(menus):
    """La phrase des menus qui perdent leur entrée."""
    if len(menus) == 1:
        return (
            f"Cette page figure dans le menu « {menus[0]} ». En la dépubliant, "
            "l'entrée correspondante disparaîtra de la navigation."
        )
    liste = ", ".join(f"« {nom} »" for nom in menus)
    return (
        f"Cette page figure dans les menus {liste}. En la dépubliant, les "
        "entrées correspondantes disparaîtront de la navigation."
    )
