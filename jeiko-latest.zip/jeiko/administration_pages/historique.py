# jeiko/administration_pages/historique.py
"""
Brouillon d'une page en ligne, et historique de ses versions (IDEES-01, C01/C02).

Ce que ça résout
----------------
Toute modification d'une page publiée se voyait aussitôt, et rien ne se
défaisait : une section supprimée par erreur, un agent IA qui réécrit une page,
une mise en page ratée — il fallait tout refaire de mémoire.

Comment
-------
Un brouillon et une version sont des PAGES CACHÉES (`Page.role`), rattachées à
la page du site, qui portent une copie de son contenu (sections, lignes, blocs
et leurs styles). Ce choix plutôt qu'un instantané JSON :

* l'éditeur ouvre un brouillon comme n'importe quelle page, sans rien savoir
  des brouillons — tout ce qu'il sait faire marche dessus ;
* une version s'affiche par le rendu même du site : l'aperçu est exact ;
* la copie est celle qu'on utilise déjà pour dupliquer une page, éprouvée.

Le gestionnaire par défaut (`Page.objects`) ne les voit pas : ni le public, ni
les listes, ni les menus, ni l'API.

* **Brouillon** — « Préparer un brouillon » copie la page ; on le modifie en
  paix, le public voit toujours la page en ligne. « Publier le brouillon »
  met la version en ligne de côté dans l'historique, puis met le contenu du
  brouillon à sa place. Un seul brouillon par page.
* **Historique** — une version est prise :
  - après chaque séance de modification, d'où qu'elle vienne (éditeur, API,
    agent IA) : la tâche des cinq minutes (`historiser_les_pages_modifiees`)
    prend l'état d'une page modifiée puis laissée tranquille dix minutes ;
  - la première fois qu'elle passe sur une page (version de départ) ;
  - avant de publier un brouillon et avant de restaurer une version.
  On garde les `GARDER` plus récentes par page. Restaurer une version la
  recopie à la place du contenu en ligne — l'état remplacé est gardé d'abord :
  une restauration se défait.

Ce que ça ne couvre pas
-----------------------
* Les RÉGLAGES de la page (titre, adresse, référencement, menu, catégorie)
  s'appliquent tout de suite, comme avant : brouillon et historique portent
  le contenu fait dans l'éditeur.
* Une version est l'état APRÈS une séance de travail : deux modifications à
  moins de dix minutes d'écart ne font qu'une version.
* Les images ne sont pas recopiées : brouillon et versions désignent celles
  de la médiathèque (pas de doublon à chaque version). Un fichier remplacé
  depuis l'éditeur crée une nouvelle image quand l'ancienne sert ailleurs
  (`forms.NouvelleImageSiPartagee`) : le passé reste intact. Une image
  supprimée de la médiathèque n'y est plus — la médiathèque refuse de
  supprimer une image qu'une version utilise encore.
* Les messages reçus par un formulaire suivent la page : quand le contenu est
  remplacé, ils passent au formulaire de même lignée
  (`ContentFormulaire.lignee`). Un formulaire RETIRÉ dans le brouillon part
  avec ses messages, comme quand on supprime son bloc dans l'éditeur.
* Une version ne se modifie pas : l'éditeur ne l'ouvre pas, l'API ne la liste
  pas. Ses sections restent joignables par leur numéro pour qui le devinerait,
  avec le droit de modifier les pages — rien ne l'empêche au niveau d'un bloc.
* La comparaison (`comparaison.py`) porte sur le contenu décrit en texte —
  textes, réglages, images désignées —, pas sur le rendu : l'aperçu reste
  ce qui montre une version telle qu'elle était.
* Un brouillon programmé (`programmer_le_brouillon`) est publié par la tâche
  des cinq minutes, au nom de qui l'a préparé : à cinq minutes près.
"""

import logging
from datetime import timedelta
from uuid import uuid4

from django.db import transaction
from django.db.models import F, OuterRef, Q, Subquery
from django.utils import timezone

from .models import (
    BackgroundImageParameters, Bloc, Content, ContentFormSubmission, ContentFormulaire,
    Line, Page, Section, Size, StyleBox,
)

logger = logging.getLogger(__name__)

#: Versions gardées par page.
GARDER = 30
#: Une page modifiée puis laissée tranquille ce temps-là : la séance est finie.
CALME = timedelta(minutes=10)
#: Pages historisées par passage de la tâche des cinq minutes (une copie de
#: page coûte une à quelques secondes).
PAR_PASSAGE = 10


class Motif:
    DEPART = "depart"
    MODIFICATIONS = "modifications"
    AVANT_PUBLICATION = "avant_publication"
    AVANT_RESTAURATION = "avant_restauration"
    BROUILLON = "brouillon"
    #: Une page légale remplacée par le modèle à jour (administration/pages_legales.py, LEG-01).
    AVANT_MODELE_LEGAL = "avant_modele_legal"


def a_un_historique(page):
    """Une page du site faite dans l'éditeur ; pas un e-mail, un PDF ni un atelier de modèle."""
    return not (page.role or page.is_mail_template or page.is_pdf or page.is_model_workshop)


def pages_historisables():
    return Page.objects.filter(is_mail_template=False, is_pdf=False, is_model_workshop=False)


def brouillon_de(page):
    return Page.tous.filter(role=Page.Role.BROUILLON, rattachee_a=page).first()


def versions_de(page):
    return (Page.tous.filter(role=Page.Role.VERSION, rattachee_a=page)
            .select_related("role_par").order_by("-role_le", "-pk"))


# --------------------------------------------------------------------------- #
#  Copier, effacer
# --------------------------------------------------------------------------- #
def _page_cachee(page, role, *, auteur=None, motif=""):
    return Page.tous.create(
        title=page.title[:100],
        url_tag=f"jk-{role}-{uuid4().hex[:24]}",
        active=False, google_index=False, langue=page.langue,
        role=role, rattachee_a=page, role_le=timezone.now(),
        role_par=auteur if getattr(auteur, "is_authenticated", False) else None,
        role_motif=motif,
        # Ce qui change l'allure de la page dans l'éditeur et l'aperçu.
        menu_transparent=page.menu_transparent,
        show_default_main_menu=page.show_default_main_menu,
        show_default_footer=page.show_default_footer,
        main_menu=page.main_menu, footer_menu=page.footer_menu,
        is_custom_object_template=page.is_custom_object_template,
    )


def _copier_le_contenu(source, cible):
    """Copie les sections de `source` sur `cible`, images partagées."""
    from .signals import construction_de_pages
    from .utils import section_duplicate

    with construction_de_pages([cible.pk]):
        for section in source.sections.order_by("position", "id"):
            section_duplicate(section, target_page=cible, position=section.position,
                              partager_les_images=True)
    # Un modèle de la bibliothèque ne se dédouble pas : sa copie n'en est pas un.
    for modele, chemin in ((Section, "page"), (Line, "section__page"), (Bloc, "line__section__page")):
        modele.objects.filter(**{chemin: cible, "is_model": True}).update(is_model=False, model_name=None)


_BOITES = (
    (StyleBox, [f"{b}_{a}" for b in ("margin", "padding") for a in ("phone", "tablet", "laptop", "computer")]),
    (Size, [f"size_{a}" for a in ("phone", "tablet", "laptop", "computer")]),
    (BackgroundImageParameters, ["background_image_parameters"]),
)


def _effacer_les_sections(sections):
    """
    Supprime des sections, leurs lignes, blocs et contenus — et leurs boîtes
    de style, que la cascade ne prend pas (l'élément les désigne, pas
    l'inverse) : sans ça, chaque version élaguée laissait des centaines de
    lignes orphelines.
    """
    ids = [s.pk for s in sections]
    if not ids:
        return
    porteurs = (
        Section.objects.filter(pk__in=ids),
        Line.objects.filter(section_id__in=ids),
        Bloc.objects.filter(line__section_id__in=ids),
    )
    boites = {modele: set() for modele, __ in _BOITES}
    # Les satellites d'un contenu (texte, vidéo, bouton…) : le contenu les
    # désigne, la cascade ne les prend pas non plus.
    satellites = {}
    contenus = Content.objects.filter(bloc__line__section_id__in=ids)
    for champ in Content._meta.fields:
        if champ.one_to_one and champ.name != "bloc":
            satellites[champ.related_model] = set(
                contenus.exclude(**{f"{champ.name}_id": None}).values_list(f"{champ.name}_id", flat=True))
    for qs in porteurs:
        for modele, champs in _BOITES:
            for ligne in qs.values_list(*[f"{c}_id" for c in champs]):
                boites[modele].update(v for v in ligne if v)

    # Un modèle de la bibliothèque posé là (cas ancien) part dans son atelier
    # au lieu d'être supprimé avec la page.
    from .modeles import atelier

    for modele, racine in ((Section, "pk__in"), (Line, "section_id__in"),
                           (Bloc, "line__section_id__in")):
        for element in modele.objects.filter(**{racine: ids, "is_model": True}):
            atelier(element)

    Section.objects.filter(pk__in=ids, is_model=False).delete()
    for modele, pks in satellites.items():
        modele.objects.filter(pk__in=pks).delete()

    for modele, champs in _BOITES:
        candidates = boites[modele]
        if not candidates:
            continue
        encore = set()
        for porteur in (Section, Line, Bloc):
            for champ in champs:
                encore.update(porteur.objects.filter(**{f"{champ}_id__in": candidates})
                              .values_list(f"{champ}_id", flat=True))
        modele.objects.filter(pk__in=candidates - encore).delete()


def _supprimer_la_page_cachee(page_cachee):
    _effacer_les_sections(list(page_cachee.sections.all()))
    page_cachee.delete()


def _formulaires(page):
    return list(ContentFormulaire.objects.filter(content__bloc__line__section__page=page)
                .order_by("content__bloc__line__section__position",
                          "content__bloc__line__position", "content__bloc__position", "pk"))


def _transmettre_les_messages(sortants, entrants):
    """Les messages d'un formulaire qui s'en va passent à celui de même lignée qui arrive."""
    heritiers = {}
    for formulaire in entrants:
        heritiers.setdefault(formulaire.lignee, []).append(formulaire)
    for formulaire in sortants:
        file = heritiers.get(formulaire.lignee)
        if file:
            ContentFormSubmission.objects.filter(formulaire=formulaire).update(formulaire=file.pop(0))


def _remplacer_le_contenu(page, source, *, deplacer):
    """
    Met le contenu de `source` (brouillon ou version) à la place de celui de
    `page`. `deplacer` : les sections passent d'une page à l'autre (brouillon
    publié, qui disparaît) ; sinon elles sont recopiées (version restaurée,
    qui reste dans l'historique).
    """
    from .signals import _schedule_page_refresh

    sortantes = list(page.sections.all())
    formulaires_sortants = _formulaires(page)
    if deplacer:
        Section.objects.filter(page=source).update(page=page)
    else:
        _copier_le_contenu(source, page)
    arrivees = [s for s in page.sections.all() if s not in sortantes]
    _transmettre_les_messages(formulaires_sortants,
                              [f for f in _formulaires(page) if f not in formulaires_sortants])
    _effacer_les_sections(sortantes)
    # `update()` n'émet aucun signal : le héros, le cache du corps et la date
    # de modification sont planifiés ici.
    _schedule_page_refresh(page.pk)
    return arrivees


def _verrouiller(page):
    return Page.tous.select_for_update().get(pk=page.pk)


# --------------------------------------------------------------------------- #
#  Historique
# --------------------------------------------------------------------------- #
@transaction.atomic
def capturer(page, *, motif, auteur=None):
    """Une version de l'état actuel de `page`. Élague au-delà de GARDER."""
    if not a_un_historique(page):
        raise ValueError("Cette page n'a pas d'historique.")
    version = _page_cachee(page, Page.Role.VERSION, auteur=auteur, motif=motif)
    _copier_le_contenu(page, version)
    for ancienne in list(versions_de(page)[GARDER:]):
        _supprimer_la_page_cachee(ancienne)
    return version


def historiser_les_pages_modifiees(maintenant=None):
    """
    Tâche des cinq minutes : une version de chaque page modifiée depuis sa
    dernière version et laissée tranquille `CALME` — et une version de départ
    pour celles qui n'en ont aucune. `PAR_PASSAGE` au plus ; le reste au
    passage suivant. Rend le nombre de versions prises.
    """
    maintenant = maintenant or timezone.now()
    derniere = Subquery(
        Page.tous.filter(role=Page.Role.VERSION, rattachee_a=OuterRef("pk"))
        .order_by("-role_le").values("role_le")[:1]
    )
    candidates = (
        pages_historisables().annotate(derniere=derniere)
        .filter(Q(derniere__isnull=True) | Q(contenu_modifie_le__gt=F("derniere")))
        .filter(Q(contenu_modifie_le__isnull=True) | Q(contenu_modifie_le__lte=maintenant - CALME))
        .order_by(F("contenu_modifie_le").asc(nulls_first=True), "pk")[:PAR_PASSAGE]
    )
    prises = 0
    for page in candidates:
        try:
            capturer(page, motif=Motif.MODIFICATIONS if page.derniere else Motif.DEPART)
            prises += 1
        except Exception:
            # Une page qui échoue ne bloque pas les autres ; elle sera
            # retentée au passage suivant, et l'erreur se voit au journal.
            logger.exception("Historique : version impossible pour la page %s", page.pk)
    return prises


@transaction.atomic
def restaurer(version, *, auteur=None):
    """Remet `version` en ligne ; l'état remplacé entre d'abord dans l'historique."""
    if version.role != Page.Role.VERSION:
        raise ValueError("Ce n'est pas une version de l'historique.")
    page = _verrouiller(version.rattachee_a)
    capturer(page, motif=Motif.AVANT_RESTAURATION, auteur=auteur)
    _remplacer_le_contenu(page, version, deplacer=False)
    return page


# --------------------------------------------------------------------------- #
#  Brouillon
# --------------------------------------------------------------------------- #
@transaction.atomic
def creer_le_brouillon(page, *, auteur=None):
    """Le brouillon de `page`, créé au besoin (un seul par page)."""
    if not a_un_historique(page):
        raise ValueError("Cette page ne se prépare pas en brouillon.")
    page = _verrouiller(page)
    existant = brouillon_de(page)
    if existant:
        return existant
    brouillon = _page_cachee(page, Page.Role.BROUILLON, auteur=auteur, motif=Motif.BROUILLON)
    _copier_le_contenu(page, brouillon)
    return brouillon


@transaction.atomic
def publier_le_brouillon(brouillon, *, auteur=None):
    """Le contenu du brouillon passe en ligne ; l'ancien entre dans l'historique."""
    if brouillon.role != Page.Role.BROUILLON:
        raise ValueError("Ce n'est pas un brouillon.")
    page = _verrouiller(brouillon.rattachee_a)
    capturer(page, motif=Motif.AVANT_PUBLICATION, auteur=auteur)
    _remplacer_le_contenu(page, brouillon, deplacer=True)
    _supprimer_la_page_cachee(brouillon)
    return page


def programmer_le_brouillon(brouillon, quand):
    """Publie `brouillon` à `quand` (cron_5m) ; None annule la programmation. ValueError si passé."""
    if brouillon.role != Page.Role.BROUILLON:
        raise ValueError("Ce n'est pas un brouillon.")
    if quand is not None and quand <= timezone.now():
        raise ValueError("La date de publication est passée.")
    Page.tous.filter(pk=brouillon.pk).update(publier_le=quand)
    brouillon.publier_le = quand
    return brouillon


def publier_les_brouillons_dus(maintenant=None):
    """Tâche des cinq minutes : les brouillons dont l'heure est venue passent en ligne. Rend leur nombre."""
    dus = Page.tous.filter(role=Page.Role.BROUILLON, publier_le__lte=maintenant or timezone.now())
    publies = 0
    for brouillon in dus.select_related("rattachee_a", "role_par"):
        try:
            publier_le_brouillon(brouillon, auteur=brouillon.role_par)
            publies += 1
        except Exception:
            # Le brouillon reste programmé : il sera retenté au passage suivant.
            logger.exception("Historique : publication programmée impossible pour le brouillon %s", brouillon.pk)
    return publies


@transaction.atomic
def abandonner_le_brouillon(brouillon):
    if brouillon.role != Page.Role.BROUILLON:
        raise ValueError("Ce n'est pas un brouillon.")
    page = brouillon.rattachee_a
    _supprimer_la_page_cachee(brouillon)
    return page
