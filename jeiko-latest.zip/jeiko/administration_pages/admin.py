from django.contrib import admin

from .models import (
    Page, Section, Line, Margin, Padding, Bloc, Content, ImageContent, ContentImage, Category,
    StyleBox, ContentButton, ContentText, ContentFormulaire, ContentCalendar, ContentChartQuestionnaire, Size
)


admin.site.register(Page)
admin.site.register(Section)
admin.site.register(Line)
admin.site.register(Margin)
admin.site.register(Padding)
admin.site.register(Size)
admin.site.register(Bloc)
admin.site.register(Content)
admin.site.register(ImageContent)
admin.site.register(ContentImage)
admin.site.register(Category)
admin.site.register(StyleBox)
admin.site.register(ContentText)
admin.site.register(ContentButton)
admin.site.register(ContentFormulaire)
admin.site.register(ContentCalendar)
admin.site.register(ContentChartQuestionnaire)


