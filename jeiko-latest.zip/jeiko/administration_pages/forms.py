from django import forms
from django.core.validators import EmailValidator
from django.db.models import Q


from jeiko.administration_pages.models import Page
import jeiko.administration_pages.models

from jeiko.administration_pages.models import (
    Page, Section, Line, Bloc,
    ContentButton, ImageContent,
    BackgroundImageParameters
)
from jeiko.administration_pages.models import Category

class MainCategoryForm(forms.ModelForm):

    class Meta:
        model = jeiko.administration_pages.models.Category
        fields = [
            'name',
        ]

class SubCategoryForm(forms.ModelForm):

    class Meta:
        model = jeiko.administration_pages.models.Category
        fields = [
            'name',
            'main_category',
        ]

class MainCategoryFormPage(forms.Form):
    name = forms.ModelChoiceField(
        queryset=Category.objects.filter(main_category__isnull=True),
        required=False,
        label="Catégorie principale",
        widget=forms.Select(attrs={'id': 'id_main_category_-name'})
    )



class SubCategoryFormPage(forms.Form):
    name = forms.ModelChoiceField(
        queryset=Category.objects.filter(main_category__isnull=False),
        required=False,
        label="Sous-catégorie",
        widget=forms.Select(attrs={'id': 'id_sub_category_-name'})
    )

class PageForm(forms.ModelForm):

    class Meta:
        model = jeiko.administration_pages.models.Page
        fields = [
            'title',
            'active',
            'url_tag',
            'is_root',
        ]


class MetadataForm(forms.ModelForm):

    class Meta:

        model = jeiko.administration_pages.models.Metadata
        fields = [
            'title',
            'description',

        ]


class BackgroundImageParametersForm(forms.ModelForm):
    class Meta:
        model = BackgroundImageParameters
        fields = [
            'background_repeat',
            'background_size',
            'background_position',
            'background_attachment',
            'background_blur',
            'background_brightness',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for f in self.fields.values():
            f.required = False

class StyleBoxForm(forms.ModelForm):
    class Meta:
        model = jeiko.administration_pages.models.StyleBox
        fields = ['top', 'right', 'bottom', 'left']

class MarginForm(forms.ModelForm):

    class Meta:
        model = jeiko.administration_pages.models.Margin
        fields = [
            'top',
            'right',
            'bottom',
            'left',
        ]

    def __init__(self, *args, **kwargs):
        super(MarginForm, self).__init__(*args, **kwargs)
        self.fields['top'].widget.attrs['placeholder'] = "Haute"
        self.fields['right'].widget.attrs['placeholder'] = "Droite"
        self.fields['bottom'].widget.attrs['placeholder'] = "Basse"
        self.fields['left'].widget.attrs['placeholder'] = "Gauche"


class PaddingForm(forms.ModelForm):

    class Meta:
        model = jeiko.administration_pages.models.Padding
        fields = [
            'top',
            'right',
            'bottom',
            'left',
        ]

    def __init__(self, *args, **kwargs):
        super(PaddingForm, self).__init__(*args, **kwargs)
        self.fields['top'].widget.attrs['placeholder'] = "Haute"
        self.fields['right'].widget.attrs['placeholder'] = "Droite"
        self.fields['bottom'].widget.attrs['placeholder'] = "Basse"
        self.fields['left'].widget.attrs['placeholder'] = "Gauche"


class BlocSizeForm(forms.ModelForm):

    class Meta:
        model = jeiko.administration_pages.models.Size
        fields = [
            'width',
            'height',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # height n’est plus obligatoire
        self.fields['height'].required = False

class SizeForm(forms.ModelForm):

    class Meta:
        model = jeiko.administration_pages.models.Size
        fields = [
            'width',
            # 'height',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # height n’est plus obligatoire

class ContentForm(forms.ModelForm):
    class Meta:
        model = jeiko.administration_pages.models.Content
        fields = ['content_type']

class ImageForm(forms.ModelForm):

    class Meta:
        model = jeiko.administration_pages.models.ImageContent
        fields = [
            'full_size'
        ]

    def __init__(self, *args, **kwargs):
        super(ImageForm, self).__init__(*args, **kwargs)
        self.fields['full_size'].required = True


class ContentImageForm(forms.ModelForm):
    class Meta:
        model = jeiko.administration_pages.models.ContentImage
        fields = [
            'object_fit', 'object_position', 'filter', 'opacity',
            'transition', 'mix_blend_mode', 'alt', 'title'
        ]
        widgets = {
            'object_fit': forms.Select(choices=jeiko.administration_pages.models.ContentImage._meta.get_field('object_fit').choices),
            'mix_blend_mode': forms.Select(choices=jeiko.administration_pages.models.ContentImage._meta.get_field('mix_blend_mode').choices),
        }

class BackgroundImageForm(forms.ModelForm):
    class Meta:
        model = ImageContent
        fields = [
            'full_size',      # L'utilisateur upload seulement ce champ
            # Les champs computer/tablet/mobile sont remplis automatiquement en .save()
        ]
        widgets = {
            'full_size': forms.ClearableFileInput(attrs={'accept': 'image/*'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Optionnel : Renomme le label pour plus de clarté
        self.fields['full_size'].label = "Image principale (sera redimensionnée pour chaque format)"
        self.fields["full_size"].required = False


class ContentTextAdvancedForm(forms.ModelForm):
    class Meta:
        model = jeiko.administration_pages.models.ContentText
        fields = ['text']
        widgets = {
            'text': forms.Textarea(attrs={'placeholder': 'Utilisez [%prenom%], [%score%], etc.'}),
        }

class ContentChartQuestionnaireForm(forms.ModelForm):
    class Meta:
        model = jeiko.administration_pages.models.ContentChartQuestionnaire
        fields = ["title", "description", "chart_type", "options_json", "main_axis"]
        widgets = {
            "options_json": forms.Textarea(attrs={"rows":4, "cols":60}),
        }


class ButtonContentForm(forms.ModelForm):
    class Meta:
        model = ContentButton
        fields = [
            'label', 'page_target', 'test_slug', 'open_in_new_tab',
            # Couleurs / Design
            'background_color', 'text_color', 'border_color',
            'hover_background_color', 'hover_text_color', 'hover_border_color',
            'border_radius', 'border_width', 'padding', 'width', 'height',
            'font_size', 'font_weight', 'font_family', 'letter_spacing', 'text_transform',
            'box_shadow', 'hover_shadow', 'transition',
            # Icônes
            'icon_left', 'icon_right',
            # Animation
            'animation',
            # Accessibilité
            'aria_label', 'tabindex', 'disabled',
        ]
        widgets = {
            'text_transform': forms.Select(choices=ContentButton._meta.get_field('text_transform').choices),
            'animation': forms.Select(choices=ContentButton._meta.get_field('animation').choices),
        }


class ContentCalendarForm(forms.ModelForm):
    class Meta:
        model = jeiko.administration_pages.models.ContentCalendar
        fields = ['title', 'appointment_type']  # Ajoute d'autres champs si tu veux


class SectionForm(forms.ModelForm):

    class Meta:
        model = jeiko.administration_pages.models.Section
        fields = [

            'background_color',

        ]


class LineForm(forms.ModelForm):

    class Meta:
        model = jeiko.administration_pages.models.Line
        fields = [
            'background_color',
            'columns_type',          # Desktop
            'columns_type_tablet',   # Tablette
            'columns_type_phone',    # Mobile
        ]
        labels = {
            'background_color': 'Couleur de fond',
            'columns_type':       'Disposition (Ordinateur)',
            'columns_type_tablet':'Disposition (Tablette)',
            'columns_type_phone': 'Disposition (Téléphone)',
        }



class BlocForm(forms.ModelForm):
    class Meta:
        model = Bloc
        fields = [
            'background_color',         # Fond du bloc
            'horizontal_align',         # Alignement horizontal du contenu
            'vertical_align',           # Alignement vertical du contenu
        ]
        widgets = {
            'horizontal_align': forms.Select(choices=Bloc._meta.get_field('horizontal_align').choices),
            'vertical_align': forms.Select(choices=Bloc._meta.get_field('vertical_align').choices),
        }


class TextForm(forms.ModelForm):


    class Meta:
        model = jeiko.administration_pages.models.ContentText
        fields = [
            'text',
        ]

    def __init__(self, *args, **kwargs):
        # first call parent's constructor
        super(TextForm, self).__init__(*args, **kwargs)
        # there's a `fields` property now
        self.fields['text'].required = False

class CSSParametersForm(forms.ModelForm):

    class Meta:
        model = jeiko.administration_pages.models.CSSParameters
        fields = [
            'object_id',
            'object_classes',
            'before',
            'current',
            'after',
            'hover',
            'custom',
        ]