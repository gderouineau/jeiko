from django.db import models
from django.core.validators import RegexValidator
import os
from django.db.models import UniqueConstraint, Q
from PIL import Image, ImageOps
from io import BytesIO
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage

from jeiko.calendars.models import AppointmentType, Appointment, Availability
alphanumeric = RegexValidator(r'^[A-Za-z_-]*$', 'Seules des lettres sont autorisées et les tirets')


class Category(models.Model):

    name = models.CharField(
        max_length=100,

    )

    main_category = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name="sub_categories"
    )


    class Meta:
        constraints = [
            UniqueConstraint(fields=('name',), name='only_one_category_name'),
        ]

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        super(Category, self).save(*args, **kwargs)


class Page(models.Model):

    title = models.CharField(
        max_length=100,
        verbose_name="Titre",
    )

    active = models.BooleanField(
        default=False,
    )



    url_tag = models.CharField(
        max_length=100,
        verbose_name='Nom de l\'url',
        validators=[alphanumeric],
        db_index=True,
        unique=True,
    )

    date_created = models.DateTimeField(
        auto_now_add=True,
        blank=True,
    )

    is_root = models.BooleanField(
        default=False,
        db_index=True,
    )

    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='pages_main_category'
    )

    sub_category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='pages_sub_category',
    )

    class Meta:
        constraints = [
            UniqueConstraint(fields=('is_root',), condition=Q(is_root=True), name='only_one_is_root_page')
        ]

    def __str__(self):
        return self.title

class Metadata(models.Model):

    page = models.OneToOneField(
        Page,
        on_delete=models.CASCADE,
        related_name='metadata',
        null=True,
        blank=True,

    )

    title = models.CharField(

        max_length=100,
        verbose_name='Titre',
        default="",
        null=True,
        blank=True,
    )

    description = models.TextField(
        default="",
        verbose_name="Description",
        null=True,
        blank=True,
    )



class StyleBox(models.Model):

    top = models.CharField(
        max_length=10,
        default=0,
    )

    right = models.CharField(
        max_length=10,
        default=0,
    )

    bottom = models.CharField(
        max_length=10,
        default=0,
    )

    left = models.CharField(
        max_length=10,
        default=0,
    )

    def as_inline_css(self):
        return f"{self.top} {self.right} {self.bottom} {self.left};"



class Margin(models.Model):

    top = models.CharField(
        max_length=10,
        verbose_name="Marge haute",
        default=0,
    )

    right = models.CharField(
        max_length=10,
        verbose_name="Marge droite",
        default=0,
    )

    bottom = models.CharField(
        max_length=10,
        verbose_name="Marge basse",
        default=0,
    )

    left = models.CharField(
        max_length=10,
        verbose_name="Marge gauche",
        default=0,
    )


class Padding(models.Model):

    top = models.CharField(
        max_length=10,
        verbose_name="Padding haut",
        default=0,
    )

    right = models.CharField(
        max_length=10,
        verbose_name="Padding droit",
        default=0,
    )

    bottom = models.CharField(
        max_length=10,
        verbose_name="Padding bas",
        default=0,
    )

    left = models.CharField(
        max_length=10,
        verbose_name="Padding gauche",
        default=0,
    )


class Size(models.Model):

    width = models.CharField(
        max_length=50,
        default="100%",
        verbose_name="Largeur"
    )

    height = models.CharField(
        max_length=50,
        default="",
        verbose_name="Hauteur"
    )


class ImageContent(models.Model):

    full_size = models.ImageField(
        upload_to='images',
        null=True,
        blank=True,
        verbose_name='Image',
    )

    computer_size = models.ImageField(
        upload_to='images',
        null=True,
        blank=True,
        verbose_name='Image',
    )

    tablet_size = models.ImageField(
        upload_to='images',
        null=True,
        blank=True,
        verbose_name='Image',
    )

    mobile_size = models.ImageField(
        upload_to='images',
        null=True,
        blank=True,
        verbose_name='Image',
    )


    def resize_and_save(self, size, suffix):
        # 1) on recharge l’original
        img = Image.open(self.full_size.path)

        # 1b) on rectifie l’orientation EXIF si besoin
        img = ImageOps.exif_transpose(img)

        # 2) on crée le thumbnail en LANCZOS (remplace ANTIALIAS)
        resample = getattr(Image, 'Resampling', Image).LANCZOS
        img.thumbnail(size, resample)

        # 3) on enregistre dans un buffer
        buffer = BytesIO()
        img.save(buffer, format='WEBP')
        buffer.seek(0)

        # 4) on génère un nom unique
        base, _ = os.path.splitext(self.full_size.name)
        new_name = f"{base}-{suffix}.webp"

        # 5) on sauvegarde via Django
        saved_path = default_storage.save(new_name, ContentFile(buffer.read()))
        return saved_path

    def save(self, *args, **kwargs):
        # première passe pour avoir full_size
        super().save(*args, **kwargs)
        if self.full_size:
            # on génère les tailles dérivées
            self.computer_size = self.resize_and_save((1500, 1500), 'computer')
            self.tablet_size  = self.resize_and_save((991,  991),   'tablet')
            self.mobile_size  = self.resize_and_save((767,  767),   'mobile')
            # mise à jour des trois champs seulement
            super().save(update_fields=['computer_size', 'tablet_size', 'mobile_size'])

from django.db import models

class BackgroundImageParameters(models.Model):
    # Background repeat
    REPEAT_CHOICES = [
        ('no-repeat', 'Pas de répétition (no-repeat)'),
        ('repeat', 'Répéter (repeat)'),
        ('repeat-x', 'Répéter horizontalement (repeat-x)'),
        ('repeat-y', 'Répéter verticalement (repeat-y)'),
        ('space', 'Espacement (space)'),
        ('round', 'Adapter (round)'),
    ]
    background_repeat = models.CharField(
        max_length=20, choices=REPEAT_CHOICES, default='no-repeat', verbose_name="Répétition"
    )

    # Background size
    SIZE_CHOICES = [
        ('auto', 'Auto'),
        ('cover', 'Couvrir (cover)'),
        ('contain', 'Adapter (contain)'),
        # tu peux ajouter d'autres tailles CSS si besoin (100% 100%, etc.)
    ]
    background_size = models.CharField(
        max_length=20, choices=SIZE_CHOICES, default='cover', verbose_name="Taille"
    )

    # Background position (tous les classiques + custom possible)
    POSITION_CHOICES = [
        ('left top', 'Gauche Haut'),
        ('left center', 'Gauche Centre'),
        ('left bottom', 'Gauche Bas'),
        ('center top', 'Centre Haut'),
        ('center center', 'Centre'),
        ('center bottom', 'Centre Bas'),
        ('right top', 'Droite Haut'),
        ('right center', 'Droite Centre'),
        ('right bottom', 'Droite Bas'),
        # Pour plus d’options, prévoir une saisie custom (ex: '70% 20px')
    ]
    background_position = models.CharField(
        max_length=30, choices=POSITION_CHOICES, default='center center', verbose_name="Position"
    )

    # Background attachment (scroll/fixed/local)
    ATTACHMENT_CHOICES = [
        ('scroll', 'Défilement (scroll)'),
        ('fixed', 'Fixé (fixed)'),
        ('local', 'Local (local)'),
    ]
    background_attachment = models.CharField(
        max_length=10, choices=ATTACHMENT_CHOICES, default='scroll', verbose_name="Attachement"
    )

    # Blur (via filter: blur(xpx))
    background_blur = models.CharField(
        max_length=10, blank=True, default='', verbose_name="Flou (px)",
        help_text="Ex : 5px ou laisser vide pour aucun flou"
    )

    # Brightness (via filter: brightness(x))
    background_brightness = models.CharField(
        max_length=10, blank=True, default='', verbose_name="Luminosité",
        help_text="Ex : 0.7 (plus sombre), 1.2 (plus clair), laisser vide pour valeur par défaut (1)"
    )

    class Meta:
        verbose_name = "Paramètres d’image de fond"
        verbose_name_plural = "Paramètres d’images de fond"

    def get_filter_css(self):
        """Génère la chaîne filter CSS à partir du flou et de la luminosité"""
        filters = []
        if self.background_blur:
            filters.append(f'blur({self.background_blur})')
        if self.background_brightness:
            filters.append(f'brightness({self.background_brightness})')
        return ' '.join(filters) if filters else None

    def __str__(self):
        return f"BG params ({self.background_repeat}, {self.background_size}, {self.background_position})"

class StylableElement(models.Model):
    """
    Modèle abstrait pour éléments stylables (Section, Line, Bloc).
    Gère les marges, paddings, background et tailles par device.
    """


    # Margins
    margin_phone = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_margin_phone"
    )
    margin_tablet = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_margin_tablet"
    )
    margin_computer = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_margin_computer"
    )

    # Paddings
    padding_phone = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_padding_phone"
    )
    padding_tablet = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_padding_tablet"
    )
    padding_computer = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_padding_computer"
    )

    # Sizes
    size_phone = models.ForeignKey(
        Size,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_size_phone"
    )
    size_tablet = models.ForeignKey(
        Size,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_size_tablet"
    )
    size_computer = models.ForeignKey(
        Size,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_size_computer"
    )

    # Background
    background_image = models.OneToOneField(
        ImageContent,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_background_image"
    )
    background_image_parameters = models.OneToOneField(
        BackgroundImageParameters,
        on_delete=models.CASCADE,
        null=True,
        blank=True,

    )
    background_color = models.CharField(
        max_length=30,
        default="rgba(255,255,255,0)"
    )

    class Meta:
        abstract = True

    # --- Méthodes utiles (optionnel)
    def css_margin_inline(self, device='computer'):
        field = getattr(self, f"margin_{device}")
        return f"margin: {field.as_inline_css()};"

    def css_padding_inline(self, device='computer'):
        field = getattr(self, f"padding_{device}")
        return f"padding: {field.as_inline_css()};"

    def css_size_inline(self, device='computer'):
        size = getattr(self, f"size_{device}")
        if not size:
            return ""
        return f"width: {size.width}; height: {size.height};"

    def css_background(self):
        return f"background-color: {self.background_color};"

    def has_background_image(self):
        return bool(self.background_image and self.background_image.full_size)

    def get_background_image_url(self, device='computer'):
        """
        Retourne l’URL de l’image background selon le device.
        device = 'computer' | 'tablet' | 'phone'
        """
        if not self.background_image:
            return ""
        # On suppose que ImageContent a bien des champs : computer_size, tablet_size, mobile_size
        img = self.background_image
        if device == "computer" and hasattr(img, 'computer_size') and img.computer_size:
            return img.computer_size.url
        elif device == "tablet" and hasattr(img, 'tablet_size') and img.tablet_size:
            return img.tablet_size.url
        elif device == "phone" and hasattr(img, 'mobile_size') and img.mobile_size:
            return img.mobile_size.url
        # fallback : full_size si présent
        elif hasattr(img, 'full_size') and img.full_size:
            return img.full_size.url
        return ""

class Section(StylableElement):

    page = models.ForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name='sections',
    )

    position = models.IntegerField(
        default=0,
        db_index=True,
    )

    is_model = models.BooleanField(
        default=False,
    )


    class Meta:
        ordering = ('position',)


class Line(StylableElement):
    section = models.ForeignKey(
        Section,
        on_delete=models.CASCADE,
        related_name='lines'
    )

    position = models.IntegerField(
        default=0,
        db_index=True,
    )

    is_model = models.BooleanField(
        default=False,
    )

    COLUMNS_TYPE_CHOICES = [
        ("12",      "12"),
        ("6-6",     "6-6"),
        ("4-8",     "4-8"),
        ("8-4",     "8-4"),
        ("9-3",     "9-3"),
        ("3-9",     "3-9"),
        ("2-10",    "2-10"),
        ("10-2",    "10-2"),
        ("4-4-4",   "4-4-4"),
        ("3-6-3",   "3-6-3"),
        ("3-3-6",   "3-3-6"),
        ("6-3-3",   "6-3-3"),
        ("2-8-2",   "2-8-2"),
        ("2-2-8",   "2-2-8"),
        ("8-2-2",   "8-2-2"),
        ("3-3-3-3", "3-3-3-3"),
        ("2-2-2-6", "2-2-2-6"),
        ("6-2-2-2", "6-2-2-2"),
        ("2-2-2-2-2-2", "2-2-2-2-2-2"),
    ]

    COLUMNS_ROWS_TYPE_CHOICES = [
        ("12", "12"),
        ("6-6", "6-6"),
        ("4-8", "4-8"),
        ("8-4", "8-4"),
        ("9-3", "9-3"),
        ("3-9", "3-9"),
        ("2-10", "2-10"),
        ("10-2", "10-2"),
        ("12-12", "12-12"),
        ("4-4-4", "4-4-4"),
        ("3-6-3", "3-6-3"),
        ("3-3-6", "3-3-6"),
        ("6-3-3", "6-3-3"),
        ("2-8-2", "2-8-2"),
        ("2-2-8", "2-2-8"),
        ("8-2-2", "8-2-2"),
        ("12-12-12", "12-12-12"),
        ("6-6-12", "6-6-12"),
        ("12-6-6", "12-6-6"),
        ("3-3-3-3", "3-3-3-3"),
        ("2-2-2-6", "2-2-2-6"),
        ("6-2-2-2", "6-2-2-2"),
        ("6-6-6-6", "6-6-6-6"),
        ("12-12-12-12", "12-12-12-12"),
        ("6-6-12-12", "6-6-12-12"),
        ("12-12-6-6", "12-12-6-6"),
        ("12-4-4-4", "12-4-4-4"),
        ("4-4-4-12", "4-4-4-12"),
        ("2-2-2-2-2-2", "2-2-2-2-2-2"),
        ("12-12-12-12-12-12", "12-12-12-12-12-12"),
        ("6-6-6-6-6-6", "6-6-6-6-6-6"),
        ("4-4-4-4-4-4", "4-4-4-4-4-4"),
        ("3-3-3-3-3-3", "3-3-3-3-3-3"),
    ]

    columns_type = models.CharField(
        max_length=20,
        choices=COLUMNS_TYPE_CHOICES,
        default="12",
        verbose_name="Desktop layout",
    )

    columns_type_tablet = models.CharField(
        max_length=20,
        choices=COLUMNS_ROWS_TYPE_CHOICES,
        default="12",
        verbose_name="Tablet layout",
    )

    columns_type_phone = models.CharField(
        max_length=20,
        choices=COLUMNS_ROWS_TYPE_CHOICES,
        default="12",
        verbose_name="Mobile layout",
    )

    columns_number = models.IntegerField(
        default=1,
        verbose_name="Nombre de colonnes",
    )

    class Meta:
        ordering = ('position',)

    def get_grid_positions(self, device="computer"):
        """
        Renvoie une liste de dicts {start, end} pour chaque bloc,
        en fonction de columns_type (desktop/tablet/phone).
        """
        field = {
            "computer": "columns_type",
            "tablet": "columns_type_tablet",
            "phone": "columns_type_phone"
        }[device]
        ratios = [int(r) for r in getattr(self, field).split("-")]
        positions = []
        current = 1
        for span in ratios:
            positions.append({"start": current, "end": current + span})
            current += span
        return positions

    @property
    def desktop_layout(self):
        return [int(x) for x in self.columns_type.split('-')]

    @property
    def tablet_layout(self):
        return [int(x) for x in self.columns_type_tablet.split('-')]

    @property
    def mobile_layout(self):
        return [int(x) for x in self.columns_type_phone.split('-')]

    def save(self, *args, **kwargs):
        is_new = self.pk is None
        super().save(*args, **kwargs)

        if is_new:
            # Par défaut, tablet = même as desktop
            if self.columns_type_tablet == "12":
                self.columns_type_tablet = self.columns_type
            # Par défaut, mobile = autant de "12" que de blocs desktop
            if self.columns_type_phone == "12":
                self.columns_type_phone = "-".join(
                    ["12"] * len(self.columns_type.split("-"))
                )
            super().save(update_fields=["columns_type_tablet", "columns_type_phone"])


class Bloc(StylableElement):
    line = models.ForeignKey(
        Line,
        on_delete=models.CASCADE,
        related_name='blocs',
    )
    position = models.IntegerField(default=0, db_index=True)
    is_model = models.BooleanField(default=False)

    # Ajout alignement
    horizontal_align = models.CharField(
        max_length=16,
        choices=[
            ('', 'Automatique'),
            ('left', 'Gauche'),
            ('center', 'Centré'),
            ('right', 'Droite'),
            ('justify', 'Justifié'),
        ],
        default='', blank=True,
        verbose_name="Alignement horizontal"
    )
    vertical_align = models.CharField(
        max_length=16,
        choices=[
            ('', 'Automatique'),
            ('top', 'Haut'),
            ('middle', 'Milieu'),
            ('bottom', 'Bas'),
        ],
        default='', blank=True,
        verbose_name="Alignement vertical"
    )

    class Meta:
        ordering = ('position',)


class ContentText(models.Model):
    text = models.TextField(
        default='',
        verbose_name="Contenu"
    )


class ContentTextQuestionnaire(models.Model):
    raw_text = models.TextField(
        verbose_name="Texte avec balises dynamiques",
        help_text="Utilisez [%prenom%], [%score%], [%profil%], etc."
    )

    def render(self, context: dict):
        # Optionnel si tu veux un rendu simple dans l'admin ou autre
        rendered = self.raw_text
        for key, value in context.items():
            rendered = rendered.replace(f"[%{key}%]", str(value))
        return rendered


class ContentChartQuestionnaire(models.Model):
    CHART_TYPE_CHOICES = [
        ("bar", "Barres"),
        ("radar", "Radar"),
        ("doughnut", "Doughnut"),
        ("pie", "Camembert"),
        ("line", "Lignes"),
    ]

    title = models.CharField(
        max_length=200,
        blank=True,
        default="",
        verbose_name="Titre du graphique"
    )
    description = models.TextField(
        blank=True,
        default="",
        verbose_name="Description (optionnelle)"
    )

    chart_type = models.CharField(
        max_length=20,
        choices=CHART_TYPE_CHOICES,
        default="bar",
        verbose_name="Type de graphique"
    )

    # Options Chart.js globales (axes, legendes, couleurs par défaut, etc.)
    options_json = models.JSONField(
        verbose_name="Options JSON (Chart.js)",
        help_text="Personnalisation du graphique (axes, titres, etc.)",
        default=dict,
        blank=True
    )

    # Facultatif : pour lier à une structure de scores particulière
    main_axis = models.CharField(
        max_length=100,
        blank=True,
        default="",
        help_text="Nom du champ dans les scores à utiliser (laisser vide pour auto)"
    )


    def __str__(self):
        return self.title or f"Graphique {self.pk}"


class ContentImage(models.Model):
    image_content = models.OneToOneField(
        ImageContent,
        on_delete=models.CASCADE,
        related_name='content_image',
    )

    # Options d'affichage spécifiques à l'image
    object_fit = models.CharField(
        max_length=20,
        choices=[
            ('fill', 'fill'),
            ('contain', 'contain'),
            ('cover', 'cover'),
            ('none', 'none'),
            ('scale-down', 'scale-down'),
        ],
        default='cover',
        verbose_name='object-fit',
        help_text='Détermine comment l’image s’adapte à son conteneur.'
    )
    object_position = models.CharField(
        max_length=30,
        default='center center',
        verbose_name='object-position',
        help_text='Exemple : center center, top left, 50% 50%…'
    )
    filter = models.CharField(
        max_length=100,
        default='none',
        blank=True,
        verbose_name='CSS filter',
        help_text='Effet CSS : blur(2px), grayscale(100%), etc.'
    )
    opacity = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=1.0,
        verbose_name='Opacité',
        help_text='Entre 0.0 (transparent) et 1.0 (opaque).'
    )
    transition = models.CharField(
        max_length=100,
        default='',
        blank=True,
        verbose_name='Transition CSS',
        help_text='Exemple : all 0.3s ease-in-out'
    )
    mix_blend_mode = models.CharField(
        max_length=30,
        default='normal',
        choices=[
            ('normal', 'normal'),
            ('multiply', 'multiply'),
            ('screen', 'screen'),
            ('overlay', 'overlay'),
            ('darken', 'darken'),
            ('lighten', 'lighten'),
            ('color-dodge', 'color-dodge'),
            ('color-burn', 'color-burn'),
            ('hard-light', 'hard-light'),
            ('soft-light', 'soft-light'),
            ('difference', 'difference'),
            ('exclusion', 'exclusion'),
            ('hue', 'hue'),
            ('saturation', 'saturation'),
            ('color', 'color'),
            ('luminosity', 'luminosity'),
        ],
        verbose_name='Mix blend mode'
    )
    alt = models.CharField(
        max_length=150,
        default='Image',
        verbose_name='Texte alternatif (alt)',
        help_text='Description de l’image pour l’accessibilité et le SEO.'
    )
    title = models.CharField(
        max_length=150,
        default='',
        blank=True,
        verbose_name='Title (tooltip)',
        help_text='Texte affiché au survol.'
    )

    def __str__(self):
        return self.alt or "Image"


class ContentButton(models.Model):
    # ------- CONTENU -------
    label = models.CharField(max_length=100, verbose_name="Texte du bouton")
    open_in_new_tab = models.BooleanField(default=False, verbose_name="Ouvrir dans un nouvel onglet")
    page_target = models.ForeignKey(
        'Page', null=True, blank=True, on_delete=models.SET_NULL, verbose_name="Page cible",
        related_name="buttons_targeted"
    )
    test_slug = models.CharField(max_length=100, null=True, blank=True, verbose_name="Slug du test")

    # ------- DESIGN : COULEURS -------
    background_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Couleur de fond (CSS)")
    text_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Couleur du texte (CSS)")
    border_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Couleur de bordure (CSS)")
    hover_background_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Fond hover (CSS)")
    hover_text_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Texte hover (CSS)")
    hover_border_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Bordure hover (CSS)")

    # ------- DESIGN : DIMENSIONS/FORME -------
    border_radius = models.CharField(max_length=16, null=True, blank=True, verbose_name="Rayon des coins (ex: 6px, 50%)")
    border_width = models.CharField(max_length=16, null=True, blank=True, verbose_name="Largeur bordure (ex: 2px)")
    padding = models.CharField(max_length=32, null=True, blank=True, verbose_name="Padding (ex: 12px 24px)")
    width = models.CharField(max_length=16, null=True, blank=True, verbose_name="Largeur (ex: 100%)")
    height = models.CharField(max_length=16, null=True, blank=True, verbose_name="Hauteur (ex: 100px)")
    font_size = models.CharField(max_length=16, null=True, blank=True, verbose_name="Taille de police (ex: 1.2rem)")
    font_weight = models.CharField(max_length=16, null=True, blank=True, verbose_name="Graisse police (400, 700...)")
    font_family = models.CharField(max_length=64, null=True, blank=True, verbose_name="Famille de police (ex: Roboto)")
    letter_spacing = models.CharField(max_length=16, null=True, blank=True, verbose_name="Espacement lettres")
    text_transform = models.CharField(
        max_length=16,
        choices=[('none', 'Normal'), ('uppercase', 'Majuscules'), ('lowercase', 'Minuscules'), ('capitalize', 'Capitalize')],
        default='none', blank=True, verbose_name="Casse"
    )

    # ------- OMBRES/TRANSITIONS -------
    box_shadow = models.CharField(max_length=128, null=True, blank=True, verbose_name="Box-shadow (CSS)")
    hover_shadow = models.CharField(max_length=128, null=True, blank=True, verbose_name="Ombre au hover (CSS)")
    transition = models.CharField(max_length=64, null=True, blank=True, verbose_name="Transition (ex: all 0.2s)")

    # ------- ICONES -------
    icon_left = models.CharField(max_length=64, null=True, blank=True, verbose_name="Icône à gauche (classe FontAwesome)")
    icon_right = models.CharField(max_length=64, null=True, blank=True, verbose_name="Icône à droite (classe FontAwesome)")

    # ------- ANIMATIONS prédéfinies CSS -------
    animation = models.CharField(
        max_length=32, null=True, blank=True,
        choices=[
            ('', 'Aucune'),
            ('bounce', 'Bounce'),
            ('pulse', 'Pulse'),
            ('shake', 'Shake'),
            ('wiggle', 'Wiggle'),
        ],
        verbose_name="Animation CSS"
    )

    # ------- ACCESSIBILITE -------
    aria_label = models.CharField(max_length=200, null=True, blank=True, verbose_name="Aria label")
    tabindex = models.IntegerField(null=True, blank=True, verbose_name="Tabindex")
    disabled = models.BooleanField(default=False, verbose_name="Désactivé")

    def get_url(self):
        if self.page_target:
            return f"/{self.page_target.url_tag}/"
        elif self.test_slug:
            return f"/questionnaires/{self.test_slug}/question/0/?"
        return "#"

    def __str__(self):
        return self.label or "Bouton"


class ContentCalendar(models.Model):
    # Optionnel : on peut y lier un ou plusieurs types de rendez-vous, couleur, titre...
    title = models.CharField(max_length=150, default="Réserver un rendez-vous")
    appointment_type = models.ForeignKey(
        AppointmentType,# modèle de type de RDV
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Type de rendez-vous par défaut"
    )
    # Tu peux ajouter d'autres options ici (couleur, affichage...)

    def __str__(self):
        return self.title


class ContentFormulaire(models.Model):
    name = models.CharField(max_length=200, verbose_name="Nom du formulaire")
    description = models.TextField(blank=True, null=True)
    to_email = models.CharField(max_length=200, blank=True, null=True)
    from_email = models.CharField(max_length=200, blank=True, null=True)
    mail_subject = models.CharField(max_length=200, blank=True, null=True)
    success_message = models.TextField(blank=True, null=True)
    # Ajoute d’autres champs génériques si besoin (style, etc.)

    def __str__(self):
        return self.name or f"Formulaire #{self.pk}"


class ContentFormField(models.Model):
    TYPE_CHOICES = [
        ('text', 'Texte'),
        ('email', 'Email'),
        ('phone', 'Téléphone'),
        ('textarea', 'Zone de texte'),
        ('select', 'Liste déroulante'),
        ('checkbox', 'Case à cocher'),
        ('date', 'Date'),
        ('number', 'Numérique'),
        # Ajoute d’autres types si besoin
    ]
    formulaire = models.ForeignKey(
        ContentFormulaire,
        related_name='fields',
        on_delete=models.CASCADE
    )
    label = models.CharField(max_length=200)
    name = models.CharField(
        max_length=100,
        help_text="Nom technique (utilisé en HTML). Doit être unique dans le formulaire."
    )
    type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    required = models.BooleanField(default=False)
    options = models.JSONField(
        blank=True,
        null=True,
        help_text=(
            "Pour les selects/checkbox : liste de dicts ex : "
            "[{'value': 'opt1', 'label': 'Option 1'}, {'value': 'opt2', 'label': 'Option 2'}]"
        )
    )
    order = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = ('formulaire', 'name')
        ordering = ['order', 'id']

    def __str__(self):
        return f"{self.label} ({self.formulaire})"


class ContentFormSubmission(models.Model):
    formulaire = models.ForeignKey(
        ContentFormulaire,
        related_name='submissions',
        on_delete=models.CASCADE
    )
    submitted_at = models.DateTimeField(auto_now_add=True)
    data = models.JSONField()  # { field_name: value }
    ip_address = models.GenericIPAddressField(blank=True, null=True)
    user_agent = models.CharField(max_length=300, blank=True, null=True)
    # Optionnel : user = models.ForeignKey(settings.AUTH_USER_MODEL, ...)

    def __str__(self):
        return f"Soumission {self.pk} ({self.formulaire})"


class Content(models.Model):
    bloc = models.OneToOneField(
        'Bloc',
        on_delete=models.CASCADE,
        related_name='content',
    )

    CONTENT_TYPE_CHOICES = [
        ("NOT_SET", "Non défini"),
        ("TEXT", "Texte"),
        ("IMAGE", "Image"),
        ("TEXT_QUESTIONNAIRE", "Texte avec balises"),
        ("CHART", "Graphique"),
        ("BUTTON", "Bouton"),
        ("CALENDAR", "Calendrier"),
        ("FORM", "Formulaire"),
    ]

    content_type = models.CharField(
        default="NOT_SET",
        choices=CONTENT_TYPE_CHOICES
    )

    content_text = models.OneToOneField(
        'ContentText',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_image = models.OneToOneField(
        'ContentImage',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_text_questionnaire = models.OneToOneField(
        'ContentTextQuestionnaire',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_chart = models.OneToOneField(
        'ContentChartQuestionnaire',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_button = models.OneToOneField(
        'ContentButton',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_calendar = models.OneToOneField(
        'ContentCalendar',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_formulaire = models.OneToOneField(
        ContentFormulaire,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )

    def reset(self):
        if self.content_type == "TEXT" and self.content_text:
            self.content_text.delete()
            self.content_text = None
        elif self.content_type == "IMAGE" and self.content_image:
            self.content_image.image_content.delete()
            self.content_image.delete()
            self.content_image = None
        self.content_type = "NOT_SET"
        self.save()


class CSSParameters(models.Model):

    object_id = models.CharField(
        default="",
        null=True,
        blank=True,
        verbose_name="ID de l'objet",
        max_length=100,
    )

    object_classes = models.CharField(
        default="",
        null=True,
        blank=True,
        verbose_name="Classes de l'objet",
        max_length=200,
    )

    before = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name='CSS before',
    )

    current = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name='CSS',
    )

    after = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name='CSS after',
    )

    hover = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name='CSS hover',
    )
    custom = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name="CSS personnalisé"
    )

    content = models.ForeignKey(
        Content,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="CSS_parameters",

    )



