from django.db import models
from django.core.validators import RegexValidator
import os
from django.db.models import UniqueConstraint, Q
from PIL import Image, ImageOps
from io import BytesIO
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator

from jeiko.calendars.models import AppointmentType, Appointment, Availability


alphanumeric = RegexValidator(r'^[A-Za-z_-]*$', 'Seules des lettres sont autorisées et les tirets')


class Category(models.Model):
    name = models.CharField(
        max_length=100,

    )

    main_category = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name="sub_categories"
    )

    class Meta:
        constraints = [
            UniqueConstraint(fields=('name',), name='only_one_category_name'),
        ]

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        super(Category, self).save(*args, **kwargs)


class Page(models.Model):
    title = models.CharField(
        max_length=100,
        verbose_name="Titre",
    )

    active = models.BooleanField(
        default=False,
    )

    url_tag = models.CharField(
        max_length=100,
        verbose_name='Nom de l\'url',
        validators=[alphanumeric],
        db_index=True,
        unique=True,
    )

    date_created = models.DateTimeField(
        auto_now_add=True,
        blank=True,
    )

    is_root = models.BooleanField(
        default=False,
        db_index=True,
    )

    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='pages_main_category'
    )

    sub_category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name='pages_sub_category',
    )

    is_pdf = models.BooleanField(
        default=False,
    )

    is_mail_template = models.BooleanField(
        default=False
    )

    show_default_main_menu = models.BooleanField(
        default=True,
    )

    show_default_footer = models.BooleanField(
        default=True,
    )

    google_index = models.BooleanField(
        default=True,
    )



    class Meta:
        constraints = [
            UniqueConstraint(fields=('is_root',), condition=Q(is_root=True), name='only_one_is_root_page')
        ]

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        """
        URL publique de la page.
        Hypothèse simple:
          - la page racine -> "/"
          - sinon -> "/<url_tag>/"
        Adapte si tu as un routeur différent.
        """
        if self.is_root:
            return "/"
        return f"/{self.url_tag}/"


class Metadata(models.Model):
    page = models.OneToOneField(
        Page,
        on_delete=models.CASCADE,
        related_name='metadata',
        null=True,
        blank=True,

    )

    title = models.CharField(

        max_length=100,
        verbose_name='Titre',
        default="",
        null=True,
        blank=True,
    )

    description = models.TextField(
        default="",
        verbose_name="Description",
        null=True,
        blank=True,
    )

    updated_at = models.DateTimeField(
        auto_now=True
    )

class StyleBox(models.Model):
    top = models.CharField(
        max_length=10,
        default=0,
    )

    right = models.CharField(
        max_length=10,
        default=0,
    )

    bottom = models.CharField(
        max_length=10,
        default=0,
    )

    left = models.CharField(
        max_length=10,
        default=0,
    )

    def as_inline_css(self):
        return f"{self.top} {self.right} {self.bottom} {self.left};"


class Margin(models.Model):
    top = models.CharField(
        max_length=10,
        verbose_name="Marge haute",
        default=0,
    )

    right = models.CharField(
        max_length=10,
        verbose_name="Marge droite",
        default="auto",
    )

    bottom = models.CharField(
        max_length=10,
        verbose_name="Marge basse",
        default=0,
    )

    left = models.CharField(
        max_length=10,
        verbose_name="Marge gauche",
        default="auto",
    )


class Padding(models.Model):
    top = models.CharField(
        max_length=10,
        verbose_name="Padding haut",
        default=0,
    )

    right = models.CharField(
        max_length=10,
        verbose_name="Padding droit",
        default=0,
    )

    bottom = models.CharField(
        max_length=10,
        verbose_name="Padding bas",
        default=0,
    )

    left = models.CharField(
        max_length=10,
        verbose_name="Padding gauche",
        default=0,
    )


class Size(models.Model):
    width = models.CharField(
        max_length=50,
        default="100%",
        verbose_name="Largeur"
    )

    height = models.CharField(
        max_length=50,
        default="",
        verbose_name="Hauteur"
    )


class ImageContent(models.Model):
    # === Original (remplace "full_size") ===
    original_image = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        verbose_name="Image originale",
        max_length=255,
    )

    # === Variantes dérivées (WEBP) ===
    # 1920px (full / hero)
    full_size = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        verbose_name="Image 1920w (WEBP)",
        max_length=255,
    )
    # 1500px (desktop large)
    computer_size = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        verbose_name="Image 1500w (WEBP)",
        max_length=255,
    )
    # 1200px (992–1199)
    laptop_size = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        verbose_name="Image 1200w (WEBP)",
        max_length=255,
    )
    # 991px (768–991)
    tablet_size = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        verbose_name="Image 991w (WEBP)",
        max_length=255,
    )
    # 767px (≤767)
    mobile_size = models.ImageField(
        upload_to="images",
        null=True,
        blank=True,
        verbose_name="Image 767w (WEBP)",
        max_length=255,
    )

    alt = models.CharField(max_length=200, default="", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)

    # cibles : (field_name, width, suffix)
    TARGETS = (
        ("full_size", 1920, "full"),
        ("computer_size", 1500, "computer"),
        ("laptop_size", 1200, "laptop"),
        ("tablet_size", 991, "tablet"),
        ("mobile_size", 767, "mobile"),
    )

    # ---------- utils ----------
    def _delete_storage_file(self, f):
        """Supprime un fichier du storage s’il existe (sans casser si absent)."""
        try:
            if f and getattr(f, "name", None) and default_storage.exists(f.name):
                default_storage.delete(f.name)
        except Exception:
            pass  # on ne bloque pas une suppression pour un souci disque

    def _cleanup_derivatives(self, old_instance=None):
        """Supprime tous les dérivés existants (utile avant régénération)."""
        target = old_instance or self
        for field_name in ("full_size", "computer_size", "laptop_size", "tablet_size", "mobile_size"):
            self._delete_storage_file(getattr(target, field_name))

    def _open_original(self):
        """Ouvre l’original depuis le storage, compatible storages distants."""
        if not self.original_image:
            return None
        try:
            img = Image.open(self.original_image.path)
        except Exception:
            with default_storage.open(self.original_image.name, "rb") as f:
                img = Image.open(f)
        return ImageOps.exif_transpose(img)

    def _make_derivative_webp(self, max_width, suffix):
        """
        Crée une dérivée WEBP redimensionnée par largeur (pas de contrainte hauteur).
        - Si l’original est plus petit que max_width → pas d’upscale : on encode tel quel en WEBP.
        - Retourne le nom du fichier sauvé dans le storage.
        """
        src = self._open_original()
        if src is None:
            return None

        if src.mode not in ("RGB", "L"):
            src = src.convert("RGB")

        ow, oh = src.size
        if ow > max_width:
            ratio = max_width / float(ow)
            new_size = (max_width, int(oh * ratio))
            resample = getattr(Image, "Resampling", Image).LANCZOS
            img = src.resize(new_size, resample)
        else:
            img = src

        buffer = BytesIO()
        img.save(buffer, format="WEBP", quality=85, method=6)  # qualité haute, poids contenu
        buffer.seek(0)

        base, _ = os.path.splitext(self.original_image.name)
        new_name = f"{base}-{suffix}.webp"
        return default_storage.save(new_name, ContentFile(buffer.read()))

    # ---------- cycles de vie ----------
    def save(self, *args, **kwargs):
        """
        - Si l’original change : purge des dérivés anciens.
        - Génère systématiquement toutes les variantes (1920/1500/1200/991/767) en WEBP.
        """
        old = None
        if self.pk:
            try:
                old = type(self).objects.get(pk=self.pk)
            except type(self).DoesNotExist:
                old = None

        # Si on a explicitement vidé l’original → nettoyer dérivés + ancien original
        if old and not self.original_image and old.original_image:
            self._cleanup_derivatives(old)
            self._delete_storage_file(old.original_image)

        # 1er save pour disposer d’un PK + placer l’original dans le storage
        super().save(*args, **kwargs)

        if self.original_image:
            # Si l’original a changé → purge des dérivés précédents
            if old and old.original_image and old.original_image.name != self.original_image.name:
                self._cleanup_derivatives(old)

            # (Re)génère toutes les cibles
            to_update = []
            for field_name, width, suffix in self.TARGETS:
                saved_name = self._make_derivative_webp(width, suffix)
                if saved_name:
                    # On affecte le nom renvoyé par le storage (ImageField accepte un str)
                    setattr(self, field_name, saved_name)
                    to_update.append(field_name)

            if to_update:
                to_update.append("updated_at")
                super().save(update_fields=to_update)

    def delete(self, using=None, keep_parents=False):
        """Supprime les fichiers (dérivés + original) puis l'instance DB."""
        self._cleanup_derivatives(self)
        self._delete_storage_file(self.original_image)
        return super().delete(using=using, keep_parents=keep_parents)


class BackgroundImageParameters(models.Model):
    # Background repeat
    REPEAT_CHOICES = [
        ('no-repeat', 'Pas de répétition (no-repeat)'),
        ('repeat', 'Répéter (repeat)'),
        ('repeat-x', 'Répéter horizontalement (repeat-x)'),
        ('repeat-y', 'Répéter verticalement (repeat-y)'),
        ('space', 'Espacement (space)'),
        ('round', 'Adapter (round)'),
    ]
    background_repeat = models.CharField(
        max_length=20, choices=REPEAT_CHOICES, default='no-repeat', verbose_name="Répétition"
    )

    # Background size
    SIZE_CHOICES = [
        ('auto', 'Auto'),
        ('cover', 'Couvrir (cover)'),
        ('contain', 'Adapter (contain)'),
        # tu peux ajouter d'autres tailles CSS si besoin (100% 100%, etc.)
    ]
    background_size = models.CharField(
        max_length=20, choices=SIZE_CHOICES, default='cover', verbose_name="Taille"
    )

    # Background position (tous les classiques + custom possible)
    POSITION_CHOICES = [
        ('left top', 'Gauche Haut'),
        ('left center', 'Gauche Centre'),
        ('left bottom', 'Gauche Bas'),
        ('center top', 'Centre Haut'),
        ('center center', 'Centre'),
        ('center bottom', 'Centre Bas'),
        ('right top', 'Droite Haut'),
        ('right center', 'Droite Centre'),
        ('right bottom', 'Droite Bas'),
        # Pour plus d’options, prévoir une saisie custom (ex: '70% 20px')
    ]
    background_position = models.CharField(
        max_length=30, choices=POSITION_CHOICES, default='center center', verbose_name="Position"
    )

    # Background attachment (scroll/fixed/local)
    ATTACHMENT_CHOICES = [
        ('scroll', 'Défilement (scroll)'),
        ('fixed', 'Fixé (fixed)'),
        ('local', 'Local (local)'),
    ]
    background_attachment = models.CharField(
        max_length=10, choices=ATTACHMENT_CHOICES, default='scroll', verbose_name="Attachement"
    )

    # Blur (via filter: blur(xpx))
    background_blur = models.CharField(
        max_length=10, blank=True, default='', verbose_name="Flou (px)",
        help_text="Ex : 5px ou laisser vide pour aucun flou"
    )

    # Brightness (via filter: brightness(x))
    background_brightness = models.CharField(
        max_length=10, blank=True, default='', verbose_name="Luminosité",
        help_text="Ex : 0.7 (plus sombre), 1.2 (plus clair), laisser vide pour valeur par défaut (1)"
    )

    background_opacity = models.CharField(
        max_length=10, blank=True, default='',
        verbose_name="Opacité",
        help_text="0–1 ou % (ex. 0.5 ou 50%)"
    )

    class Meta:
        verbose_name = "Paramètres d’image de fond"
        verbose_name_plural = "Paramètres d’images de fond"

    def get_filter_css(self):
        """Génère la chaîne filter CSS à partir du flou et de la luminosité"""
        filters = []
        if self.background_blur:
            filters.append(f'blur({self.background_blur})')
        if self.background_brightness:
            filters.append(f'brightness({self.background_brightness})')
        if self.background_opacity:
            filters.append(f'opacity({self.background_opacity})')
        return ' '.join(filters) if filters else None

    def __str__(self):
        return f"BG params ({self.background_repeat}, {self.background_size}, {self.background_position})"


class StylableElement(models.Model):
    """
    Modèle abstrait pour éléments stylables (Section, Line, Bloc).
    Gère les marges, paddings, background et tailles par device.
    """

    # Margins
    margin_phone = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_margin_phone",
        null=True,
        blank=True,
    )
    margin_tablet = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_margin_tablet",
        null=True,
        blank=True,
    )
    margin_laptop = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_margin_laptop",
        null=True,
        blank=True,
    )

    margin_computer = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_margin_computer",
        null=True,
        blank=True,
    )

    # Paddings
    padding_phone = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_padding_phone",
        null=True,
        blank=True,
    )
    padding_tablet = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_padding_tablet",
        null=True,
        blank=True,
    )
    padding_laptop = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_padding_laptop",
        null=True,
        blank=True,
    )
    padding_computer = models.ForeignKey(
        StyleBox,
        on_delete=models.CASCADE,
        related_name="%(class)s_padding_computer",
        null=True,
        blank=True,
    )

    # Sizes
    size_phone = models.ForeignKey(
        Size,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_size_phone"
    )
    size_tablet = models.ForeignKey(
        Size,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_size_tablet"
    )
    size_laptop = models.ForeignKey(
        Size,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_size_laptop"
    )
    size_computer = models.ForeignKey(
        Size,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_size_computer"
    )

    # Background
    background_image = models.OneToOneField(
        ImageContent,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="%(class)s_background_image"
    )
    background_image_parameters = models.OneToOneField(
        BackgroundImageParameters,
        on_delete=models.CASCADE,
        null=True,
        blank=True,

    )
    background_color = models.CharField(
        max_length=30,
        default="rgba(255,255,255,0)",
        null=True,
        blank=True,
    )

    class Meta:
        abstract = True

    # --- Méthodes utiles (optionnel)
    def css_margin_inline(self, device='computer'):
        field = getattr(self, f"margin_{device}")
        return f"margin: {field.as_inline_css()};"

    def css_padding_inline(self, device='computer'):
        field = getattr(self, f"padding_{device}")
        return f"padding: {field.as_inline_css()};"

    def css_size_inline(self, device='computer'):
        size = getattr(self, f"size_{device}")
        if not size:
            return ""
        return f"width: {size.width}; height: {size.height};"

    def css_background(self):
        return f"background-color: {self.background_color};"

    def has_background_image(self):
        return bool(self.background_image and self.background_image.full_size)

    def get_background_image_url(self, device='computer'):
        """
        Retourne l’URL de l’image background selon le device.
        device = 'computer' | 'tablet' | 'phone'
        """
        if not self.background_image:
            return ""
        # On suppose que ImageContent a bien des champs : computer_size, tablet_size, mobile_size
        img = self.background_image
        if device == "computer" and hasattr(img, 'computer_size') and img.computer_size:
            return img.computer_size.url
        elif device == "tablet" and hasattr(img, 'tablet_size') and img.tablet_size:
            return img.tablet_size.url
        elif device == "phone" and hasattr(img, 'mobile_size') and img.mobile_size:
            return img.mobile_size.url
        # fallback : full_size si présent
        elif hasattr(img, 'full_size') and img.full_size:
            return img.full_size.url
        return ""


class Section(StylableElement):

    page = models.ForeignKey(
        Page,
        on_delete=models.CASCADE,
        related_name='sections',
        null=True,
        blank=True
    )

    position = models.IntegerField(
        default=0,
        db_index=True,
        null=True,
        blank=True
    )

    is_model = models.BooleanField(
        default=False,
        db_index=True
    )

    model_source = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        db_index=True,
        related_name="model_copies"
    )

    model_name = models.CharField(
        max_length=200,
        default="",
        null=True,
        blank=True,
        verbose_name="Nom du modèle"

    )


    class Meta:
        ordering = ('position',)


class Line(StylableElement):

    section = models.ForeignKey(
        Section,
        on_delete=models.CASCADE,
        related_name='lines',
        null=True,
        blank=True,
    )

    position = models.IntegerField(
        default=0,
        db_index=True,
        blank=True,
        null=True,
    )

    is_model = models.BooleanField(
        default=False,
        db_index=True
    )

    model_source = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        db_index=True,
        related_name="model_copies"
    )

    model_name = models.CharField(
        max_length=200,
        default="",
        null=True,
        blank=True,
        verbose_name="Nom du modèle"

    )

    COLUMNS_TYPE_CHOICES = [
        ("12", "12"),
        ("6-6", "6-6"),
        ("4-8", "4-8"),
        ("8-4", "8-4"),
        ("9-3", "9-3"),
        ("3-9", "3-9"),
        ("2-10", "2-10"),
        ("10-2", "10-2"),
        ("4-4-4", "4-4-4"),
        ("3-6-3", "3-6-3"),
        ("3-3-6", "3-3-6"),
        ("6-3-3", "6-3-3"),
        ("2-8-2", "2-8-2"),
        ("2-2-8", "2-2-8"),
        ("8-2-2", "8-2-2"),
        ("3-3-3-3", "3-3-3-3"),
        ("2-2-2-6", "2-2-2-6"),
        ("6-2-2-2", "6-2-2-2"),
        ("2-2-2-2-2-2", "2-2-2-2-2-2"),
    ]

    COLUMNS_ROWS_TYPE_CHOICES = [
        ("12", "12"),
        ("6-6", "6-6"),
        ("4-8", "4-8"),
        ("8-4", "8-4"),
        ("9-3", "9-3"),
        ("3-9", "3-9"),
        ("2-10", "2-10"),
        ("10-2", "10-2"),
        ("12-12", "12-12"),
        ("4-4-4", "4-4-4"),
        ("3-6-3", "3-6-3"),
        ("3-3-6", "3-3-6"),
        ("6-3-3", "6-3-3"),
        ("2-8-2", "2-8-2"),
        ("2-2-8", "2-2-8"),
        ("8-2-2", "8-2-2"),
        ("12-12-12", "12-12-12"),
        ("6-6-12", "6-6-12"),
        ("12-6-6", "12-6-6"),
        ("3-3-3-3", "3-3-3-3"),
        ("2-2-2-6", "2-2-2-6"),
        ("6-2-2-2", "6-2-2-2"),
        ("6-6-6-6", "6-6-6-6"),
        ("12-12-12-12", "12-12-12-12"),
        ("6-6-12-12", "6-6-12-12"),
        ("12-12-6-6", "12-12-6-6"),
        ("12-4-4-4", "12-4-4-4"),
        ("4-4-4-12", "4-4-4-12"),
        ("2-2-2-2-2-2", "2-2-2-2-2-2"),
        ("12-12-12-12-12-12", "12-12-12-12-12-12"),
        ("6-6-6-6-6-6", "6-6-6-6-6-6"),
        ("4-4-4-4-4-4", "4-4-4-4-4-4"),
        ("3-3-3-3-3-3", "3-3-3-3-3-3"),
    ]

    columns_type = models.CharField(
        max_length=20,
        choices=COLUMNS_TYPE_CHOICES,
        default="12",
        verbose_name="Desktop/Laptop layout",
    )

    columns_type_tablet = models.CharField(
        max_length=20,
        choices=COLUMNS_ROWS_TYPE_CHOICES,
        default="12",
        verbose_name="Tablet layout",
    )

    columns_type_phone = models.CharField(
        max_length=20,
        choices=COLUMNS_ROWS_TYPE_CHOICES,
        default="12",
        verbose_name="Mobile layout",
    )

    columns_number = models.IntegerField(
        default=1,
        verbose_name="Nombre de colonnes",
    )

    class Meta:
        ordering = ('position',)

    def get_grid_positions(self, device="computer"):
        """
        Renvoie une liste de dicts {start, end} pour chaque bloc,
        en fonction de columns_type (desktop/tablet/phone).
        """
        field = {
            "computer": "columns_type",
            "tablet": "columns_type_tablet",
            "phone": "columns_type_phone"
        }[device]
        ratios = [int(r) for r in getattr(self, field).split("-")]
        positions = []
        current = 1
        for span in ratios:
            positions.append({"start": current, "end": current + span})
            current += span
        return positions

    @property
    def desktop_layout(self):
        return [int(x) for x in self.columns_type.split('-')]

    @property
    def tablet_layout(self):
        return [int(x) for x in self.columns_type_tablet.split('-')]

    @property
    def mobile_layout(self):
        return [int(x) for x in self.columns_type_phone.split('-')]

    def save(self, *args, **kwargs):
        is_new = self.pk is None
        super().save(*args, **kwargs)

        if is_new:
            # Par défaut, tablet = même as desktop
            if self.columns_type_tablet == "12":
                self.columns_type_tablet = self.columns_type
            # Par défaut, mobile = autant de "12" que de blocs desktop
            if self.columns_type_phone == "12":
                self.columns_type_phone = "-".join(
                    ["12"] * len(self.columns_type.split("-"))
                )
            super().save(update_fields=["columns_type_tablet", "columns_type_phone"])


class Bloc(StylableElement):

    line = models.ForeignKey(
        Line,
        on_delete=models.CASCADE,
        related_name='blocs',
        blank=True,
        null=True,
    )

    position = models.IntegerField(
        default=0,
        db_index=True,
        blank=True,
        null=True,
    )

    is_model = models.BooleanField(
        default=False,
        db_index=True
    )

    model_source = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        db_index=True,
        related_name="model_copies"
    )

    model_name = models.CharField(
        max_length=200,
        default="",
        null=True,
        blank=True,
        verbose_name="Nom du modèle"

    )

    # Ajout alignement
    horizontal_align = models.CharField(
        max_length=16,
        choices=[
            ('', 'Automatique'),
            ('left', 'Gauche'),
            ('center', 'Centré'),
            ('right', 'Droite'),
            ('justify', 'Justifié'),
        ],
        default='', blank=True,
        verbose_name="Alignement horizontal"
    )
    vertical_align = models.CharField(
        max_length=16,
        choices=[
            ('', 'Automatique'),
            ('top', 'Haut'),
            ('middle', 'Milieu'),
            ('bottom', 'Bas'),
        ],
        default='', blank=True,
        verbose_name="Alignement vertical"
    )

    class Meta:
        ordering = ('position',)


class ContentText(models.Model):
    text = models.TextField(
        default='',
        verbose_name="Contenu"
    )


class ContentTextQuestionnaire(models.Model):
    raw_text = models.TextField(
        verbose_name="Texte avec balises dynamiques",
        help_text="Utilisez [%prenom%], [%score%], [%profil%], etc."
    )

    def render(self, context: dict):
        # Optionnel si tu veux un rendu simple dans l'admin ou autre
        rendered = self.raw_text
        for key, value in context.items():
            rendered = rendered.replace(f"[%{key}%]", str(value))
        return rendered


class ContentChartQuestionnaire(models.Model):
    CHART_TYPE_CHOICES = [
        ("bar", "Barres"),
        ("radar", "Radar"),
        ("doughnut", "Doughnut"),
        ("pie", "Camembert"),
        ("line", "Lignes"),
    ]

    title = models.CharField(
        max_length=200,
        blank=True,
        default="",
        verbose_name="Titre du graphique"
    )
    description = models.TextField(
        blank=True,
        default="",
        verbose_name="Description (optionnelle)"
    )

    chart_type = models.CharField(
        max_length=20,
        choices=CHART_TYPE_CHOICES,
        default="bar",
        verbose_name="Type de graphique"
    )

    # Options Chart.js globales (axes, legendes, couleurs par défaut, etc.)
    options_json = models.JSONField(
        verbose_name="Options JSON (Chart.js)",
        help_text="Personnalisation du graphique (axes, titres, etc.)",
        default=dict,
        blank=True
    )

    # Facultatif : pour lier à une structure de scores particulière
    main_axis = models.CharField(
        max_length=100,
        blank=True,
        default="",
        help_text="Nom du champ dans les scores à utiliser (laisser vide pour auto)"
    )

    def __str__(self):
        return self.title or f"Graphique {self.pk}"


class ContentImage(models.Model):
    image_content = models.OneToOneField(
        ImageContent,
        on_delete=models.CASCADE,
        related_name='content_image',
    )

    # Options d'affichage spécifiques à l'image
    object_fit = models.CharField(
        max_length=20,
        choices=[
            ('fill', 'fill'),
            ('contain', 'contain'),
            ('cover', 'cover'),
            ('none', 'none'),
            ('scale-down', 'scale-down'),
        ],
        default='cover',
        verbose_name='object-fit',
        help_text='Détermine comment l’image s’adapte à son conteneur.'
    )
    object_position = models.CharField(
        max_length=30,
        default='center center',
        verbose_name='object-position',
        help_text='Exemple : center center, top left, 50% 50%…'
    )
    filter = models.CharField(
        max_length=100,
        default='none',
        blank=True,
        verbose_name='CSS filter',
        help_text='Effet CSS : blur(2px), grayscale(100%), etc.'
    )
    opacity = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=1.0,
        verbose_name='Opacité',
        help_text='Entre 0.0 (transparent) et 1.0 (opaque).'
    )
    transition = models.CharField(
        max_length=100,
        default='',
        blank=True,
        verbose_name='Transition CSS',
        help_text='Exemple : all 0.3s ease-in-out'
    )
    mix_blend_mode = models.CharField(
        max_length=30,
        default='normal',
        choices=[
            ('normal', 'normal'),
            ('multiply', 'multiply'),
            ('screen', 'screen'),
            ('overlay', 'overlay'),
            ('darken', 'darken'),
            ('lighten', 'lighten'),
            ('color-dodge', 'color-dodge'),
            ('color-burn', 'color-burn'),
            ('hard-light', 'hard-light'),
            ('soft-light', 'soft-light'),
            ('difference', 'difference'),
            ('exclusion', 'exclusion'),
            ('hue', 'hue'),
            ('saturation', 'saturation'),
            ('color', 'color'),
            ('luminosity', 'luminosity'),
        ],
        verbose_name='Mix blend mode'
    )
    alt = models.CharField(
        max_length=150,
        default='Image',
        verbose_name='Texte alternatif (alt)',
        help_text='Description de l’image pour l’accessibilité et le SEO.'
    )
    title = models.CharField(
        max_length=150,
        default='',
        blank=True,
        verbose_name='Title (tooltip)',
        help_text='Texte affiché au survol.'
    )

    def __str__(self):
        return self.alt or "Image"


class ContentButton(models.Model):
    # ------- CONTENU -------
    label = models.CharField(max_length=100, verbose_name="Texte du bouton")
    open_in_new_tab = models.BooleanField(default=False, verbose_name="Ouvrir dans un nouvel onglet")
    page_target = models.ForeignKey(
        'Page', null=True, blank=True, on_delete=models.SET_NULL, verbose_name="Page cible",
        related_name="buttons_targeted"
    )
    test_slug = models.CharField(max_length=100, null=True, blank=True, verbose_name="Slug du test")

    # ------- DESIGN : COULEURS -------
    background_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Couleur de fond (CSS)")
    text_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Couleur du texte (CSS)")
    border_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Couleur de bordure (CSS)")
    hover_background_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Fond hover (CSS)")
    hover_text_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Texte hover (CSS)")
    hover_border_color = models.CharField(max_length=32, null=True, blank=True, verbose_name="Bordure hover (CSS)")

    # ------- DESIGN : DIMENSIONS/FORME -------
    border_radius = models.CharField(max_length=16, null=True, blank=True,
                                     verbose_name="Rayon des coins (ex: 6px, 50%)")
    border_width = models.CharField(max_length=16, null=True, blank=True, verbose_name="Largeur bordure (ex: 2px)")
    padding = models.CharField(max_length=32, null=True, blank=True, verbose_name="Padding (ex: 12px 24px)")
    width = models.CharField(max_length=16, null=True, blank=True, verbose_name="Largeur (ex: 100%)")
    height = models.CharField(max_length=16, null=True, blank=True, verbose_name="Hauteur (ex: 100px)")
    font_size = models.CharField(max_length=16, null=True, blank=True, verbose_name="Taille de police (ex: 1.2rem)")
    font_weight = models.CharField(max_length=16, null=True, blank=True, verbose_name="Graisse police (400, 700...)")
    font_family = models.CharField(max_length=64, null=True, blank=True, verbose_name="Famille de police (ex: Roboto)")
    letter_spacing = models.CharField(max_length=16, null=True, blank=True, verbose_name="Espacement lettres")
    text_transform = models.CharField(
        max_length=16,
        choices=[('none', 'Normal'), ('uppercase', 'Majuscules'), ('lowercase', 'Minuscules'),
                 ('capitalize', 'Capitalize')],
        default='none', blank=True, verbose_name="Casse"
    )

    # ------- OMBRES/TRANSITIONS -------
    box_shadow = models.CharField(max_length=128, null=True, blank=True, verbose_name="Box-shadow (CSS)")
    hover_shadow = models.CharField(max_length=128, null=True, blank=True, verbose_name="Ombre au hover (CSS)")
    transition = models.CharField(max_length=64, null=True, blank=True, verbose_name="Transition (ex: all 0.2s)")

    # ------- ICONES -------
    icon_left = models.CharField(max_length=64, null=True, blank=True,
                                 verbose_name="Icône à gauche (classe FontAwesome)")
    icon_right = models.CharField(max_length=64, null=True, blank=True,
                                  verbose_name="Icône à droite (classe FontAwesome)")

    # ------- ANIMATIONS prédéfinies CSS -------
    animation = models.CharField(
        max_length=32, null=True, blank=True,
        choices=[
            ('', 'Aucune'),
            ('bounce', 'Bounce'),
            ('pulse', 'Pulse'),
            ('shake', 'Shake'),
            ('wiggle', 'Wiggle'),
        ],
        verbose_name="Animation CSS"
    )

    # ------- ACCESSIBILITE -------
    aria_label = models.CharField(max_length=200, null=True, blank=True, verbose_name="Aria label")
    tabindex = models.IntegerField(null=True, blank=True, verbose_name="Tabindex")
    disabled = models.BooleanField(default=False, verbose_name="Désactivé")

    def get_url(self):
        if self.page_target:
            return f"/{self.page_target.url_tag}/"
        elif self.test_slug:
            return f"/questionnaires/{self.test_slug}/question/0/?"
        return "#"

    def __str__(self):
        return self.label or "Bouton"


class ContentCalendar(models.Model):
    # Optionnel : on peut y lier un ou plusieurs types de rendez-vous, couleur, titre...
    title = models.CharField(max_length=150, default="Réserver un rendez-vous")
    appointment_type = models.ForeignKey(
        AppointmentType,  # modèle de type de RDV
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Type de rendez-vous par défaut"
    )

    # Tu peux ajouter d'autres options ici (couleur, affichage...)

    def __str__(self):
        return self.title


class ContentFormulaire(models.Model):
    name = models.CharField(max_length=200, verbose_name="Nom du formulaire")
    description = models.TextField(blank=True, null=True)
    to_email = models.CharField(max_length=200, blank=True, null=True)
    from_email = models.CharField(max_length=200, blank=True, null=True)
    mail_subject = models.CharField(max_length=200, blank=True, null=True)
    success_message = models.TextField(blank=True, null=True)

    # Ajoute d’autres champs génériques si besoin (style, etc.)

    def __str__(self):
        return self.name or f"Formulaire #{self.pk}"


class ContentFormField(models.Model):
    TYPE_CHOICES = [
        ('text', 'Texte'),
        ('email', 'Email'),
        ('phone', 'Téléphone'),
        ('textarea', 'Zone de texte'),
        ('select', 'Liste déroulante'),
        ('checkbox', 'Case à cocher'),
        ('date', 'Date'),
        ('number', 'Numérique'),
        # Ajoute d’autres types si besoin
    ]
    formulaire = models.ForeignKey(
        ContentFormulaire,
        related_name='fields',
        on_delete=models.CASCADE
    )
    label = models.CharField(max_length=200)
    name = models.CharField(
        max_length=100,
        help_text="Nom technique (utilisé en HTML). Doit être unique dans le formulaire."
    )
    type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    required = models.BooleanField(default=False)
    options = models.JSONField(
        blank=True,
        null=True,
        help_text=(
            "Pour les selects/checkbox : liste de dicts ex : "
            "[{'value': 'opt1', 'label': 'Option 1'}, {'value': 'opt2', 'label': 'Option 2'}]"
        )
    )
    order = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = ('formulaire', 'name')
        ordering = ['order', 'id']

    def __str__(self):
        return f"{self.label} ({self.formulaire})"


class ContentFormSubmission(models.Model):
    formulaire = models.ForeignKey(
        ContentFormulaire,
        related_name='submissions',
        on_delete=models.CASCADE
    )
    submitted_at = models.DateTimeField(auto_now_add=True)
    data = models.JSONField()  # { field_name: value }
    ip_address = models.GenericIPAddressField(blank=True, null=True)
    user_agent = models.CharField(max_length=300, blank=True, null=True)

    # Optionnel : user = models.ForeignKey(settings.AUTH_USER_MODEL, ...)

    def __str__(self):
        return f"Soumission {self.pk} ({self.formulaire})"


class ContentVideo(models.Model):
    class Source(models.TextChoices):
        FILE = "file", "Fichier"
        EXTERNAL = "external", "URL (YouTube/Vimeo/MP4)"

    class Provider(models.TextChoices):
        HTML5 = "html5", "HTML5 (mp4/webm/ogg)"
        YOUTUBE = "youtube", "YouTube"
        VIMEO = "vimeo", "Vimeo"
        DAILYMOTION = "dailymotion", "Dailymotion"
        OTHER = "other", "Autre"

    # ----- Source / Provider -----
    source = models.CharField(
        max_length=16, choices=Source.choices, default=Source.FILE, db_index=True
    )
    provider = models.CharField(
        max_length=16, choices=Provider.choices, default=Provider.HTML5
    )

    # Fichier vidéo (local) OU URL externe
    file = models.FileField(
        upload_to="videos/%Y/%m/",
        blank=True, null=True,
        validators=[FileExtensionValidator(allowed_extensions=["mp4", "webm", "ogg", "mov"])],
        verbose_name="Fichier vidéo"
    )
    url = models.URLField(blank=True, null=True, verbose_name="URL vidéo (YouTube/Vimeo/MP4)")

    # Poster (vignette) — on réutilise ton ImageContent (déjà géré ailleurs)
    poster = models.OneToOneField(
        "ImageContent",
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="poster_for_video",
        verbose_name="Poster (image d’aperçu)"
    )

    # ----- Accessibilité / Dimensions -----
    title = models.CharField(max_length=150, blank=True, default="", verbose_name="Titre (accessible)")
    aria_label = models.CharField(max_length=200, blank=True, null=True, verbose_name="Aria label")
    width = models.CharField(max_length=16, blank=True, null=True, help_text="ex: 100% ou 640px")
    height = models.CharField(max_length=16, blank=True, null=True, help_text="ex: 360px")
    aspect_ratio = models.CharField(
        max_length=16, blank=True, null=True,
        help_text="ex: 16/9, 4/3 (utilisé en CSS si width/height non définis)"
    )

    # ----- Comportement -----
    controls = models.BooleanField(default=True)
    autoplay = models.BooleanField(default=False)
    muted = models.BooleanField(default=False)
    loop = models.BooleanField(default=False)
    playsinline = models.BooleanField(default=True)
    preload = models.CharField(
        max_length=10,
        choices=[("auto", "auto"), ("metadata", "metadata"), ("none", "none")],
        default="metadata"
    )

    # ----- Plage de lecture -----
    start_time = models.PositiveIntegerField(blank=True, null=True, help_text="en secondes")
    end_time = models.PositiveIntegerField(blank=True, null=True, help_text="en secondes")

    # ----- Sous-titres (WebVTT) -----
    track_file = models.FileField(
        upload_to="videos/captions/%Y/%m/",
        blank=True, null=True,
        validators=[FileExtensionValidator(allowed_extensions=["vtt"])],
        help_text="Fichier de sous-titres .vtt"
    )
    track_lang = models.CharField(max_length=8, blank=True, default="fr")
    track_label = models.CharField(max_length=64, blank=True, default="Français")

    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    # ----- Validation & utilitaires -----
    def clean(self):
        # Cohérence source/fichier/url
        if self.source == self.Source.FILE and not self.file:
            raise ValidationError("Veuillez ajouter un fichier vidéo.")
        if self.source == self.Source.EXTERNAL and not self.url:
            raise ValidationError("Veuillez renseigner l’URL de la vidéo.")

        # Externes ≠ fichier local (provider externe seulement si EXTERNAL)
        if self.source == self.Source.FILE and self.provider != self.Provider.HTML5:
            raise ValidationError("Les providers externes s’utilisent avec une URL (source=external).")

        # Plage de lecture
        if self.start_time and self.end_time and self.end_time <= self.start_time:
            raise ValidationError("`end_time` doit être > `start_time`.")

    def save(self, *args, **kwargs):
        # Déduction du provider depuis l’URL si EXTERNAL (pratique)
        if self.source == self.Source.EXTERNAL and self.url:
            u = self.url.lower()
            if "youtu.be" in u or "youtube.com" in u:
                self.provider = self.Provider.YOUTUBE
            elif "vimeo.com" in u:
                self.provider = self.Provider.VIMEO
            elif "dailymotion.com" in u:
                self.provider = self.Provider.DAILYMOTION
            elif any(u.endswith(ext) for ext in (".mp4", ".webm", ".ogg", ".m3u8")):
                self.provider = self.Provider.HTML5
            else:
                self.provider = self.Provider.OTHER
        super().save(*args, **kwargs)

    def get_src(self) -> str:
        """Retourne l’URL vidéo à utiliser (fichier local ou URL)."""
        if self.source == self.Source.FILE and self.file:
            try:
                return self.file.url
            except Exception:
                return ""
        return self.url or ""

    def delete(self, *args, **kwargs):
        """
        Supprime proprement les fichiers vidéo / sous-titres du stockage.
        (Le poster dépend d'ImageContent et sera géré ailleurs si tu le supprimes.)
        """
        file_storage = self.file.storage if self.file else None
        file_name = self.file.name if self.file else None
        track_storage = self.track_file.storage if self.track_file else None
        track_name = self.track_file.name if self.track_file else None

        super().delete(*args, **kwargs)

        try:
            if file_storage and file_name:
                file_storage.delete(file_name)
        except Exception:
            pass
        try:
            if track_storage and track_name:
                track_storage.delete(track_name)
        except Exception:
            pass

    def __str__(self):
        return self.title or (self.url or (self.file.name if self.file else f"Vidéo {self.pk}"))


# content_defaults.py (recommandé) ou en bas de models.py
DYNAMIC_DEFAULTS = {
    "DYN_FAQ": {"items": [], "multiple": False},
    "DYN_TABS": {"items": [], "active": 0},
    "DYN_CAROUSEL": {"items": [], "autoplay": True, "interval": 5000},
    "DYN_PROGRESS": {"items": [], "progress": None},
    "DYN_TESTIMONIALS": {"items": [], "autoplay": True, "interval": 7000},
    "DYN_TESTIMONIALS_GRID": {"items": [], "perRow": 3, "rotate": True, "interval": 6000},
    "DYN_FILTER": {"items": [], "keys": ["title", "category"]},
    "DYN_COUNTDOWN": {"deadline": ""},
    "DYN_COUNTDOWN_CTA": {"deadline": "", "ctaText": "Réserver", "ctaHref": "#"},
    "DYN_ACCORDION_ADV": {"sections": []},
    "DYN_PRICING_TABLE": {"plans": [], "yearly": False},
    "DYN_GALLERY_FILTER": {"items": [], "categories": ["all"]},
    "DYN_STEPPER": {"items": [], "start": 0},
    "DYN_RATING": {"rating": 4.0, "count": 0, "max": 5, "editable": False},
}

# ---------- DYN 1) FAQ ----------
class DynFAQItem(models.Model):
    content = models.ForeignKey('Content', related_name='faq_items', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    answer = models.TextField(blank=True, default="")
    open = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"FAQ #{self.pk}"


# ---------- DYN 2) Tabs ----------
class DynTabItem(models.Model):
    content = models.ForeignKey('Content', related_name='tab_items', on_delete=models.CASCADE)
    label = models.CharField(max_length=120)
    body = models.TextField(blank=True, default="")  # texte riche autorisé (HTML)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.label or f"Tab #{self.pk}"


# ---------- DYN 3) Carousel ----------
class DynCarouselSlide(models.Model):
    content = models.ForeignKey('Content', related_name='carousel_slides', on_delete=models.CASCADE)
    image = models.ForeignKey('ImageContent', on_delete=models.CASCADE, null=True, blank=True, related_name='carousel_slides')
    external_src = models.URLField(blank=True, null=True, help_text="Optionnel si image externe/CDN")
    alt = models.CharField(max_length=150, blank=True, default="")
    caption = models.CharField(max_length=200, blank=True, default="")
    href = models.URLField(blank=True, null=True, help_text="Lien au clic (optionnel)")
    open_in_new_tab = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.caption or self.alt or f"Slide #{self.pk}"

    def get_src(self):
        if self.image:
            # privilégie les versions optimisées si disponibles
            if getattr(self.image, 'computer_size', None):
                return self.image.computer_size.url
            if getattr(self.image, 'full_size', None):
                return self.image.full_size.url
        return self.external_src or ""


# ---------- DYN 4) Progress / Timeline ----------
class DynProgressStep(models.Model):
    content = models.ForeignKey('Content', related_name='progress_steps', on_delete=models.CASCADE)
    label = models.CharField(max_length=200)
    done = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.label or f"Step #{self.pk}"


# ---------- DYN 5 & 10) Testimonials (slider & grid) ----------
class DynTestimonialItem(models.Model):
    content = models.ForeignKey('Content', related_name='testimonial_items', on_delete=models.CASCADE)
    quote = models.TextField()
    author = models.CharField(max_length=120, blank=True, default="")
    role = models.CharField(max_length=120, blank=True, default="")
    avatar = models.ForeignKey('ImageContent', on_delete=models.CASCADE, null=True, blank=True, related_name='testimonial_avatars')
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return (self.author or "Témoignage") + f" #{self.pk}"


# ---------- DYN 6) Live Filter items ----------
class DynLiveFilterItem(models.Model):
    content = models.ForeignKey('Content', related_name='livefilter_items', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    category = models.CharField(max_length=120, blank=True, default="")
    description = models.TextField(blank=True, default="")
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"Item #{self.pk}"


# ---------- DYN 8) Accordion avancé (sections + enfants) ----------
class DynAccordionSection(models.Model):
    content = models.ForeignKey('Content', related_name='accordion_sections', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    open = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"Section #{self.pk}"


class DynAccordionChild(models.Model):
    section = models.ForeignKey('DynAccordionSection', related_name='children', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    body = models.TextField(blank=True, default="")
    open = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"Child #{self.pk}"


# ---------- DYN 9) Pricing table ----------
class DynPricingPlan(models.Model):
    content = models.ForeignKey('Content', related_name='pricing_plans', on_delete=models.CASCADE)
    name = models.CharField(max_length=120)
    price_monthly = models.DecimalField(max_digits=9, decimal_places=2, default=0)
    price_yearly = models.DecimalField(max_digits=9, decimal_places=2, null=True, blank=True, help_text="Si vide, calcule 10× mensuel côté rendu")
    popular = models.BooleanField(default=False)
    cta_label = models.CharField(max_length=80, blank=True, default="Choisir")
    cta_href = models.URLField(blank=True, null=True)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.name or f"Plan #{self.pk}"

class DynPricingFeature(models.Model):
    plan = models.ForeignKey('DynPricingPlan', related_name='features', on_delete=models.CASCADE)
    label = models.CharField(max_length=200)
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.label or f"Feature #{self.pk}"


# ---------- DYN 12) Galerie filtrable ----------
class DynGalleryItem(models.Model):
    content = models.ForeignKey('Content', related_name='gallery_items', on_delete=models.CASCADE)
    image = models.ForeignKey('ImageContent', on_delete=models.CASCADE, related_name='gallery_items')
    category = models.CharField(max_length=120, blank=True, default="")
    title = models.CharField(max_length=200, blank=True, default="")
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"Image #{self.pk}"


# ---------- DYN 13) Stepper ----------
class DynStepperStep(models.Model):
    content = models.ForeignKey('Content', related_name='stepper_steps', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    body = models.TextField(blank=True, default="")
    order = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.title or f"Étape #{self.pk}"


class Content(models.Model):
    bloc = models.OneToOneField(
        'Bloc',
        on_delete=models.CASCADE,
        related_name='content',
    )

    CONTENT_TYPE_CHOICES = [
        ("NOT_SET", "Non défini"),
        ("TEXT", "Texte"),
        ("IMAGE", "Image"),
        ("TEXT_QUESTIONNAIRE", "Texte avec balises"),
        ("CHART", "Graphique"),
        ("BUTTON", "Bouton"),
        ("CALENDAR", "Calendrier"),
        ("FORM", "Formulaire"),
        ("VIDEO", "Vidéo"),

        # Dynamiques
        ("DYN_FAQ", "FAQ (accordéon)"),
        ("DYN_TABS", "Onglets (tabs)"),
        ("DYN_CAROUSEL", "Carrousel / Slider"),
        ("DYN_PROGRESS", "Progression / Timeline"),
        ("DYN_TESTIMONIALS", "Témoignages (slider)"),
        ("DYN_FILTER", "Filtre / Recherche live"),
        ("DYN_COUNTDOWN", "Compteur régressif (countdown)"),
        ("DYN_ACCORDION_ADV", "Accordéon avancé (multi-niveaux)"),
        ("DYN_PRICING_TABLE", "Table de prix (comparatif)"),
        ("DYN_TESTIMONIALS_GRID", "Témoignages (grille + rotation)"),
        ("DYN_COUNTDOWN_CTA", "Countdown + CTA"),
        ("DYN_GALLERY_FILTER", "Galerie filtrable (portfolio)"),
        ("DYN_STEPPER", "Stepper (parcours / wizard)"),
        ("DYN_RATING", "Avis / Étoiles (rating)"),
    ]

    content_type = models.CharField(
        max_length=32,
        default="NOT_SET",
        choices=CONTENT_TYPE_CHOICES,
        db_index=True,
    )

    # Données génériques pour TOUS les blocs dynamiques (DYN_*)
    # Exemple pour DYN_FAQ: {"items":[{"title":"Q1","content":"R1","open":false}, ...]}
    data = models.JSONField(default=dict, blank=True)

    # Liens vers sous-modèles (types "classiques")
    content_text = models.OneToOneField(
        'ContentText',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_image = models.OneToOneField(
        'ContentImage',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_text_questionnaire = models.OneToOneField(
        'ContentTextQuestionnaire',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_chart = models.OneToOneField(
        'ContentChartQuestionnaire',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_button = models.OneToOneField(
        'ContentButton',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_calendar = models.OneToOneField(
        'ContentCalendar',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    content_formulaire = models.OneToOneField(
        'ContentFormulaire',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )

    content_video = models.OneToOneField(
        "ContentVideo",
        on_delete=models.CASCADE,
        null=True, blank=True,
        related_name="parent_content",
    )

    # Mapping pratique pour factoriser
    CHILD_BY_TYPE = {
        "TEXT": "content_text",
        "IMAGE": "content_image",
        "TEXT_QUESTIONNAIRE": "content_text_questionnaire",
        "CHART": "content_chart",
        "BUTTON": "content_button",
        "CALENDAR": "content_calendar",
        "FORM": "content_formulaire",
        "VIDEO": "content_video",
        # DYN_* => stockés dans `data`
    }

    @property
    def is_dynamic(self) -> bool:
        return self.content_type.startswith("DYN_")

    def reset(self):
        """
        Supprime proprement la sous-instance liée et/ou les fichiers,
        vide `data` pour les dynamiques, et repasse en NOT_SET.
        """
        # 1) Supprime la sous-instance si type "classique"
        attr = self.CHILD_BY_TYPE.get(self.content_type)
        if attr:
            child = getattr(self, attr, None)
            if child:
                # Si le child contient des FileField/ImageField, supprime-les proprement
                for field in child._meta.get_fields():
                    if hasattr(field, 'upload_to'):  # heuristique FileField/ImageField
                        f = getattr(child, field.name, None)
                        if f:
                            try:
                                f.delete(save=False)
                            except Exception:
                                pass
                child.delete()
                setattr(self, attr, None)

        # 2) Vide les données dynamiques si DYN_*
        if self.is_dynamic:
            self.data = {}

        # 3) Reset le type
        self.content_type = "NOT_SET"
        self.save()

    def clear_dynamic_related(self):
        """
        Supprime tous les items relationnels associés au contenu dynamique courant.
        À appeler avant de repasser en NOT_SET, ou quand on change de type DYN_*.
        """
        # FAQ
        self.faq_items.all().delete()
        # Tabs
        self.tab_items.all().delete()
        # Carousel
        self.carousel_slides.all().delete()
        # Progress steps
        self.progress_steps.all().delete()
        # Testimonials (slider + grid)
        self.testimonial_items.all().delete()
        # Live filter
        self.livefilter_items.all().delete()
        # Accordion avancé (+ enfants via cascade)
        self.accordion_sections.all().delete()
        # Pricing (features via cascade)
        self.pricing_plans.all().delete()
        # Gallery
        self.gallery_items.all().delete()
        # Stepper
        self.stepper_steps.all().delete()
        # Snapshot JSON
        self.data = {}
        self.save()

    def __str__(self):
        return f"Content #{self.pk} — {self.content_type}"


class CSSParameters(models.Model):
    object_id = models.CharField(
        default="",
        null=True,
        blank=True,
        verbose_name="ID de l'objet",
        max_length=100,
    )

    object_classes = models.CharField(
        default="",
        null=True,
        blank=True,
        verbose_name="Classes de l'objet",
        max_length=200,
    )

    before = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name='CSS before',
    )

    current = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name='CSS',
    )

    after = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name='CSS after',
    )

    hover = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name='CSS hover',
    )
    custom = models.TextField(
        null=True,
        default="",
        blank=True,
        verbose_name="CSS personnalisé"
    )

    content = models.ForeignKey(
        Content,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="CSS_parameters",

    )
