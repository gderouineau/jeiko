from django.contrib.auth.decorators import permission_required
from django.contrib.auth.mixins import PermissionRequiredMixin, LoginRequiredMixin
from django.core.cache import cache


import copy
import json
import datetime
from django.conf import settings
from django.http import Http404, JsonResponse, HttpResponse, HttpResponseBadRequest
from django.views.decorators.http import require_GET
from django.shortcuts import render, redirect, get_object_or_404, reverse
from django.template.loader import render_to_string
from django.views import View
from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages
from django.db import transaction
from django.db.models import OuterRef, Subquery, F, FloatField, ExpressionWrapper
from django.db.models.functions import Coalesce
from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache
from django.views.decorators.clickjacking import xframe_options_exempt
from copy import deepcopy

import logging

logger = logging.getLogger(__name__)

from jeiko.administration_pages.forms import (
    PageForm, MetadataForm, SectionForm, LineForm, MarginForm, PaddingForm,
    ImageForm, TextForm, CSSParametersForm, ContentImageForm, MainCategoryForm, SubCategoryForm, MainCategoryFormPage,
    SubCategoryFormPage, StyleBoxForm, SizeForm, BlocSizeForm, ButtonContentForm, ContentCalendarForm,
    BackgroundImageForm, BackgroundImageParametersForm, ContentVideoForm,

    # dyn générique
    DynamicContentForm,
    # dyn typés + options
    FAQItemFormSet, FAQOptionsForm,
    TabItemFormSet, TabsOptionsForm,
    CarouselSlideFormSet, CarouselBulkUploadForm, CarouselOptionsForm,
    ProgressStepFormSet, ProgressOptionsForm,
    TestimonialItemFormSet, TestimonialsSliderOptionsForm, TestimonialsGridOptionsForm,
    LiveFilterItemFormSet, LiveFilterOptionsForm,
    AccordionSectionFormSet, AccordionChildFormSetFactory,
    PricingPlanFormSet, PricingFeatureFormSetFactory, PricingOptionsForm,
    GalleryItemFormSet, GalleryOptionsForm,
    StepperStepFormSet, StepperOptionsForm,
    RatingOptionsForm, CountdownOptionsForm, CountdownCTAOptionsForm
    )
from jeiko.administration_pages.models import (
    Page, Metadata, Strategy, PageInsights, InsightAuditOutcome, InsightAuditCategory,
    Section, Line, Margin, Padding, Size, ImageContent, Bloc, CustomCSS, Animation,
    Content, ContentImage, ContentText, CSSParameters, Category, ContentButton, ContentCalendar, ContentFormulaire,
    ContentChartQuestionnaire, BackgroundImageParameters, ContentVideo,
    # DYN models
    DynFAQItem, DynTabItem, DynCarouselSlide, DynProgressStep,
    DynTestimonialItem, DynLiveFilterItem,
    DynAccordionSection, DynAccordionChild,
    DynPricingPlan, DynPricingFeature,
    DynGalleryItem, DynStepperStep,
)
from jeiko.administration_pages.utils import (
    make_unique_url_tag, duplicate_instance,
    get_section_forms_context, get_line_forms_context, get_bloc_forms_context,
    build_bound_inline_formset, resequence_queryset, _snapshot_for_content, _save_style_and_sizes,
    build_image_urls_4, _errors_dict, ensure_sequential_orders, resequence, editing_menu,
    section_duplicate, line_duplicate, bloc_duplicate,
    get_latest_insight, get_google_api_key
    )

from jeiko.administration.models import GoogleApi
from django.db.models import Count

from jeiko.administration_pages.models import StyleBox
decorators = [never_cache]

from .mixins import AsyncRequestMixin


class Main(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/main.html'
    permission_required = 'administration_pages.view_page'
    raise_exception = True



    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        pages = Page.objects.all()
        main_categories = Category.objects.filter(main_category__isnull=True)
        context = {
            'pages': pages,
            'main_categories': main_categories,
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        # même rendu (si tu ajoutes des filtres POST plus tard, tu pourras les appliquer ici)
        pages = Page.objects.all()
        main_categories = Category.objects.filter(main_category__isnull=True)
        context = {
            'pages': pages,
            'main_categories': main_categories,
        }
        return render(request, self.template_name, context)


class SeePage(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/view.html'

    permission_required = 'administration_pages.view_page'
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_id = kwargs['page_id']

        page = get_object_or_404(
            Page,
            id=page_id,

        )

        context = {
            'page': page,
        }

        return render(request, self.template_name, context)


class PageAdd(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/add_or_update.html'

    permission_required = 'administration_pages.add_page'
    raise_exception = True

    page_form = PageForm
    metadata_form = MetadataForm
    main_category_form = MainCategoryFormPage
    sub_category_form = SubCategoryFormPage

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_form = self.page_form(prefix='page_')
        metadata_form = self.metadata_form(prefix='metadata_')
        main_category_form = self.main_category_form(prefix='main_category_')
        sub_category_form = self.sub_category_form(prefix='sub_category_')
        main_category_id = main_category_form.initial.get('name') if main_category_form.initial else ''
        sub_category_id = sub_category_form.initial.get('name') if sub_category_form.initial else ''
        context = {
            'update': False,
            'submit_text': "Créer",
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id,
            'sub_category_id': sub_category_id,
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page_form = self.page_form(request.POST, prefix='page_')
        metadata_form = self.metadata_form(request.POST, prefix='metadata_')
        main_category_form = self.main_category_form(prefix='main_category_')
        sub_category_form = self.sub_category_form(prefix='sub_category_')

        # Récupère l’id des catégories via le POST
        main_category_id = request.POST.get("main_category") or None
        sub_category_id = request.POST.get("sub_category") or None

        main_category = Category.objects.filter(id=main_category_id).first() if main_category_id else None
        sub_category = Category.objects.filter(id=sub_category_id).first() if sub_category_id else None

        if page_form.is_valid() and metadata_form.is_valid():
            page = page_form.save(commit=False)
            page.category = main_category
            page.sub_category = sub_category
            page.save()

            metadata = metadata_form.save(commit=False)
            metadata.page = page
            metadata.save()

            cache.clear()
            return redirect('jeiko_administration_pages:main')

        # Les id sont renvoyés à Alpine pour conserver l’état du select si erreur
        context = {
            'update': False,
            'submit_text': "Créer",
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id or '',
            'sub_category_id': sub_category_id or '',
        }
        return render(request, self.template_name, context)


class PageUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/add_or_update.html'

    permission_required = 'administration_pages.change_page'
    raise_exception = True


    page_form = PageForm
    metadata_form = MetadataForm
    main_category_form = MainCategoryFormPage
    sub_category_form = SubCategoryFormPage

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_id = kwargs['page_id']
        page = get_object_or_404(Page, id=page_id)
        page_form = self.page_form(instance=page, prefix='page_')
        metadata, _ = Metadata.objects.get_or_create(page=page)
        metadata_form = self.metadata_form(instance=metadata, prefix='metadata_')
        main_category_form = self.main_category_form(
            initial={'name': page.category_id} if page.category_id else None,
            prefix='main_category_'
        )
        sub_category_form = self.sub_category_form(
            initial={'name': page.sub_category_id} if page.sub_category_id else None,
            prefix='sub_category_'
        )
        main_category_id = str(page.category_id) if page.category_id else ''
        sub_category_id = str(page.sub_category_id) if page.sub_category_id else ''
        context = {
            'update': True,
            'submit_text': "Modifier",
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id,
            'sub_category_id': sub_category_id,
            'page': page,
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page_id = kwargs['page_id']
        page = get_object_or_404(Page, id=page_id)
        page_form = self.page_form(request.POST, instance=page, prefix='page_')
        metadata = get_object_or_404(Metadata, page=page)
        metadata_form = self.metadata_form(request.POST, instance=metadata, prefix='metadata_')
        main_category_form = self.main_category_form(prefix='main_category_')
        sub_category_form = self.sub_category_form(prefix='sub_category_')

        # Récupère l’id des catégories via le POST
        main_category_id = request.POST.get("main_category") or None
        sub_category_id = request.POST.get("sub_category") or None

        main_category = Category.objects.filter(id=main_category_id).first() if main_category_id else None
        sub_category = Category.objects.filter(id=sub_category_id).first() if sub_category_id else None

        if page_form.is_valid() and metadata_form.is_valid():
            page = page_form.save(commit=False)
            page.category = main_category
            page.sub_category = sub_category
            page.save()

            metadata = metadata_form.save(commit=False)
            metadata.page = page
            metadata.save()

            cache.clear()
            return redirect('jeiko_administration_pages:main')

        context = {
            'update': True,
            'submit_text': "Modifier",
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id or '',
            'sub_category_id': sub_category_id or '',
            'page': page,
        }
        return render(request, self.template_name, context)


class DuplicatePageView(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = 'administration_pages.add_page'
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, page_id):
        with transaction.atomic():
            page = get_object_or_404(Page, id=page_id)

            new_title = f"{page.title} (copie)"
            new_url_tag = make_unique_url_tag(page.url_tag)

            page_copy = duplicate_instance(
                page,
                omit_fields=['id', 'pk'],
                overrides={'title': new_title, 'url_tag': new_url_tag, 'active': False, 'is_root': False}
            )

            if hasattr(page, 'metadata') and page.metadata:
                duplicate_instance(
                    page.metadata,
                    omit_fields=['id', 'pk', 'page'],
                    overrides={'page': page_copy}
                )

            stylebox_map, size_map, imagecontent_map, bgparams_map = {}, {}, {}, {}

            def duplicate_stylable(obj):
                if obj is None:
                    return None
                if isinstance(obj, StyleBox):
                    if obj.pk not in stylebox_map:
                        stylebox_map[obj.pk] = duplicate_instance(obj, omit_fields=['id', 'pk'])
                    return stylebox_map[obj.pk]
                if isinstance(obj, Size):
                    if obj.pk not in size_map:
                        size_map[obj.pk] = duplicate_instance(obj, omit_fields=['id', 'pk'])
                    return size_map[obj.pk]
                return obj

            def duplicate_imagecontent(obj):
                if obj is None:
                    return None
                if obj.pk not in imagecontent_map:
                    imagecontent_map[obj.pk] = duplicate_instance(obj, omit_fields=['id', 'pk'])
                return imagecontent_map[obj.pk]

            def duplicate_bgparams(obj):
                if obj is None:
                    return None
                if obj.pk not in bgparams_map:
                    bgparams_map[obj.pk] = duplicate_instance(obj, omit_fields=['id', 'pk'])
                return bgparams_map[obj.pk]

            def duplicate_content_tree(content, content_copy):
                if content.content_type == "TEXT" and content.content_text:
                    content_copy.content_text = duplicate_instance(content.content_text, omit_fields=['id', 'pk'])

                elif content.content_type == "IMAGE" and content.content_image:
                    ic_copy = duplicate_imagecontent(content.content_image.image_content)
                    ci_copy = duplicate_instance(
                        content.content_image,
                        omit_fields=['id', 'pk', 'image_content'],
                        overrides={'image_content': ic_copy}
                    )
                    content_copy.content_image = ci_copy

                elif content.content_type == "BUTTON" and content.content_button:
                    content_copy.content_button = duplicate_instance(content.content_button, omit_fields=['id', 'pk'])

                elif content.content_type == "CHART" and content.content_chart:
                    content_copy.content_chart = duplicate_instance(content.content_chart, omit_fields=['id', 'pk'])

                elif content.content_type == "TEXT_QUESTIONNAIRE" and content.content_text_questionnaire:
                    content_copy.content_text_questionnaire = duplicate_instance(
                        content.content_text_questionnaire, omit_fields=['id', 'pk']
                    )

                elif content.content_type == "CALENDAR" and content.content_calendar:
                    content_copy.content_calendar = duplicate_instance(content.content_calendar, omit_fields=['id', 'pk'])

                elif content.content_type == "FORM" and content.content_formulaire:
                    form_copy = duplicate_instance(content.content_formulaire, omit_fields=['id', 'pk'])
                    for fld in content.content_formulaire.fields.all().order_by('order', 'id'):
                        duplicate_instance(fld, omit_fields=['id', 'pk', 'formulaire'], overrides={'formulaire': form_copy})
                    content_copy.content_formulaire = form_copy

                elif content.content_type == "VIDEO" and content.content_video:
                    poster_copy = duplicate_imagecontent(content.content_video.poster) if content.content_video.poster else None
                    video_copy = duplicate_instance(
                        content.content_video, omit_fields=['id', 'pk', 'poster'], overrides={'poster': poster_copy}
                    )
                    content_copy.content_video = video_copy

                t = content.content_type
                if t == "DYN_FAQ":
                    for item in content.faq_items.all():
                        duplicate_instance(item, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})

                elif t == "DYN_TABS":
                    for tab in content.tab_items.all():
                        duplicate_instance(tab, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})

                elif t == "DYN_CAROUSEL":
                    for slide in content.carousel_slides.all():
                        img_copy = duplicate_imagecontent(slide.image) if slide.image else None
                        duplicate_instance(
                            slide,
                            omit_fields=['id', 'pk', 'content', 'image'],
                            overrides={'content': content_copy, 'image': img_copy}
                        )

                elif t == "DYN_PROGRESS":
                    for step in content.progress_steps.all():
                        duplicate_instance(step, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})

                elif t in ("DYN_TESTIMONIALS", "DYN_TESTIMONIALS_GRID"):
                    for it in content.testimonial_items.all():
                        avatar_copy = duplicate_imagecontent(it.avatar) if it.avatar else None
                        duplicate_instance(
                            it,
                            omit_fields=['id', 'pk', 'content', 'avatar'],
                            overrides={'content': content_copy, 'avatar': avatar_copy}
                        )

                elif t == "DYN_FILTER":
                    for it in content.livefilter_items.all():
                        duplicate_instance(it, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})

                elif t == "DYN_ACCORDION_ADV":
                    for sec in content.accordion_sections.all():
                        sec_copy = duplicate_instance(sec, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})
                        for ch in sec.children.all():
                            duplicate_instance(ch, omit_fields=['id', 'pk', 'section'], overrides={'section': sec_copy})

                elif t == "DYN_PRICING_TABLE":
                    for pl in content.pricing_plans.all():
                        pl_copy = duplicate_instance(pl, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})
                        for ft in pl.features.all():
                            duplicate_instance(ft, omit_fields=['id', 'pk', 'plan'], overrides={'plan': pl_copy})

                elif t == "DYN_GALLERY_FILTER":
                    for gi in content.gallery_items.all():
                        img_copy = duplicate_imagecontent(gi.image) if gi.image else None
                        duplicate_instance(
                            gi,
                            omit_fields=['id', 'pk', 'content', 'image'],
                            overrides={'content': content_copy, 'image': img_copy}
                        )

                elif t == "DYN_STEPPER":
                    for st in content.stepper_steps.all():
                        duplicate_instance(st, omit_fields=['id', 'pk', 'content'], overrides={'content': content_copy})

                content_copy.data = deepcopy(content.data) if content.data else {}
                content_copy.save()

            for section in page.sections.all():
                margin_phone   = duplicate_stylable(section.margin_phone)
                margin_tablet  = duplicate_stylable(section.margin_tablet)
                margin_laptop  = duplicate_stylable(section.margin_laptop)
                margin_computer= duplicate_stylable(section.margin_computer)

                padding_phone   = duplicate_stylable(section.padding_phone)
                padding_tablet  = duplicate_stylable(section.padding_tablet)
                padding_laptop  = duplicate_stylable(section.padding_laptop)
                padding_computer= duplicate_stylable(section.padding_computer)

                size_phone   = duplicate_stylable(section.size_phone)
                size_tablet  = duplicate_stylable(section.size_tablet)
                size_laptop  = duplicate_stylable(section.size_laptop)
                size_computer= duplicate_stylable(section.size_computer)

                background_image = duplicate_imagecontent(section.background_image)
                bg_params        = duplicate_bgparams(section.background_image_parameters)

                section_copy = duplicate_instance(
                    section,
                    omit_fields=[
                        'id','pk','page','lines',
                        'background_image','background_image_parameters',
                        'margin_phone','margin_tablet','margin_laptop','margin_computer',
                        'padding_phone','padding_tablet','padding_laptop','padding_computer',
                        'size_phone','size_tablet','size_laptop','size_computer',
                    ],
                    overrides={
                        'page': page_copy,
                        'margin_phone': margin_phone, 'margin_tablet': margin_tablet,
                        'margin_laptop': margin_laptop, 'margin_computer': margin_computer,
                        'padding_phone': padding_phone, 'padding_tablet': padding_tablet,
                        'padding_laptop': padding_laptop, 'padding_computer': padding_computer,
                        'size_phone': size_phone, 'size_tablet': size_tablet,
                        'size_laptop': size_laptop, 'size_computer': size_computer,
                        'background_image': background_image,
                        'background_image_parameters': bg_params,
                    }
                )

                try:
                    src_cc = section.custom_css
                except CustomCSS.DoesNotExist:
                    src_cc = None
                if src_cc:
                    duplicate_instance(
                        src_cc,
                        omit_fields=['id','pk','section','line','bloc'],
                        overrides={'section': section_copy, 'line': None, 'bloc': None}
                    )

                # NEW — Animation (Section)
                try:
                    src_anim = section.animation
                except (Animation.DoesNotExist, AttributeError):
                    src_anim = None
                if src_anim:
                    duplicate_instance(
                        src_anim,
                        omit_fields=['id','pk','section','line','bloc'],
                        overrides={'section': section_copy, 'line': None, 'bloc': None, 'params': deepcopy(src_anim.params or {})}
                    )

                for line in section.lines.all():
                    margin_phone   = duplicate_stylable(line.margin_phone)
                    margin_tablet  = duplicate_stylable(line.margin_tablet)
                    margin_laptop  = duplicate_stylable(line.margin_laptop)
                    margin_computer= duplicate_stylable(line.margin_computer)

                    padding_phone   = duplicate_stylable(line.padding_phone)
                    padding_tablet  = duplicate_stylable(line.padding_tablet)
                    padding_laptop  = duplicate_stylable(line.padding_laptop)
                    padding_computer= duplicate_stylable(line.padding_computer)

                    size_phone   = duplicate_stylable(line.size_phone)
                    size_tablet  = duplicate_stylable(line.size_tablet)
                    size_laptop  = duplicate_stylable(line.size_laptop)
                    size_computer= duplicate_stylable(line.size_computer)

                    background_image = duplicate_imagecontent(line.background_image)
                    bg_params        = duplicate_bgparams(line.background_image_parameters)

                    line_copy = duplicate_instance(
                        line,
                        omit_fields=[
                            'id','pk','section','blocs',
                            'background_image','background_image_parameters',
                            'margin_phone','margin_tablet','margin_laptop','margin_computer',
                            'padding_phone','padding_tablet','padding_laptop','padding_computer',
                            'size_phone','size_tablet','size_laptop','size_computer',
                        ],
                        overrides={
                            'section': section_copy,
                            'margin_phone': margin_phone, 'margin_tablet': margin_tablet,
                            'margin_laptop': margin_laptop, 'margin_computer': margin_computer,
                            'padding_phone': padding_phone, 'padding_tablet': padding_tablet,
                            'padding_laptop': padding_laptop, 'padding_computer': padding_computer,
                            'size_phone': size_phone, 'size_tablet': size_tablet,
                            'size_laptop': size_laptop, 'size_computer': size_computer,
                            'background_image': background_image,
                            'background_image_parameters': bg_params,
                        }
                    )

                    try:
                        src_cc = line.custom_css
                    except CustomCSS.DoesNotExist:
                        src_cc = None
                    if src_cc:
                        duplicate_instance(
                            src_cc,
                            omit_fields=['id','pk','section','line','bloc'],
                            overrides={'section': None, 'line': line_copy, 'bloc': None}
                        )

                    # NEW — Animation (Line)
                    try:
                        src_anim = line.animation
                    except (Animation.DoesNotExist, AttributeError):
                        src_anim = None
                    if src_anim:
                        duplicate_instance(
                            src_anim,
                            omit_fields=['id','pk','section','line','bloc'],
                            overrides={'section': None, 'line': line_copy, 'bloc': None, 'params': deepcopy(src_anim.params or {})}
                        )

                    for bloc in line.blocs.all():
                        margin_phone   = duplicate_stylable(bloc.margin_phone)
                        margin_tablet  = duplicate_stylable(bloc.margin_tablet)
                        margin_laptop  = duplicate_stylable(bloc.margin_laptop)
                        margin_computer= duplicate_stylable(bloc.margin_computer)

                        padding_phone   = duplicate_stylable(bloc.padding_phone)
                        padding_tablet  = duplicate_stylable(bloc.padding_tablet)
                        padding_laptop  = duplicate_stylable(bloc.padding_laptop)
                        padding_computer= duplicate_stylable(bloc.padding_computer)

                        size_phone   = duplicate_stylable(bloc.size_phone)
                        size_tablet  = duplicate_stylable(bloc.size_tablet)
                        size_laptop  = duplicate_stylable(bloc.size_laptop)
                        size_computer= duplicate_stylable(bloc.size_computer)

                        background_image = duplicate_imagecontent(bloc.background_image)
                        bg_params        = duplicate_bgparams(bloc.background_image_parameters)

                        bloc_copy = duplicate_instance(
                            bloc,
                            omit_fields=[
                                'id','pk','line','content',
                                'background_image','background_image_parameters',
                                'margin_phone','margin_tablet','margin_laptop','margin_computer',
                                'padding_phone','padding_tablet','padding_laptop','padding_computer',
                                'size_phone','size_tablet','size_laptop','size_computer',
                            ],
                            overrides={
                                'line': line_copy,
                                'margin_phone': margin_phone, 'margin_tablet': margin_tablet,
                                'margin_laptop': margin_laptop, 'margin_computer': margin_computer,
                                'padding_phone': padding_phone, 'padding_tablet': padding_tablet,
                                'padding_laptop': padding_laptop, 'padding_computer': padding_computer,
                                'size_phone': size_phone, 'size_tablet': size_tablet,
                                'size_laptop': size_laptop, 'size_computer': size_computer,
                                'background_image': background_image,
                                'background_image_parameters': bg_params,
                            }
                        )

                        try:
                            src_cc = bloc.custom_css
                        except CustomCSS.DoesNotExist:
                            src_cc = None
                        if src_cc:
                            duplicate_instance(
                                src_cc,
                                omit_fields=['id','pk','section','line','bloc'],
                                overrides={'section': None, 'line': None, 'bloc': bloc_copy}
                            )

                        # NEW — Animation (Bloc)
                        try:
                            src_anim = bloc.animation
                        except (Animation.DoesNotExist, AttributeError):
                            src_anim = None
                        if src_anim:
                            duplicate_instance(
                                src_anim,
                                omit_fields=['id','pk','section','line','bloc'],
                                overrides={'section': None, 'line': None, 'bloc': bloc_copy, 'params': deepcopy(src_anim.params or {})}
                            )

                        if hasattr(bloc, 'content') and bloc.content:
                            content = bloc.content
                            content_copy = duplicate_instance(
                                content,
                                omit_fields=[
                                    'id','pk','bloc',
                                    'content_text','content_image','content_text_questionnaire',
                                    'content_chart','content_button','content_calendar',
                                    'content_formulaire','content_video',
                                ],
                                overrides={'bloc': bloc_copy}
                            )
                            duplicate_content_tree(content, content_copy)

            messages.success(request, f"La page a été dupliquée : {page_copy.title}")
            return redirect('jeiko_administration_pages:main')


class Categories(LoginRequiredMixin, PermissionRequiredMixin, View):

    template_name = 'administration_pages/category/list.html'

    permission_required = "administration_pages.view_category"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        categories = Category.objects.filter(
            main_category=None,
        )

        return render(
            request,
            self.template_name,
            context={
                'categories': categories,
            }
        )

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        categories = Category.objects.all()

        return render(
            request,
            self.template_name,
            context={
                'categories': categories,
            }
        )


class CategoryAdd(LoginRequiredMixin, PermissionRequiredMixin, View):

    template_name = 'administration_pages/category/add_or_update.html'

    permission_required = "administration_pages.add_category"
    raise_exception = True

    main_category_form = MainCategoryForm
    sub_category_form = SubCategoryForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        if 'main_category_id' in kwargs:
            main_category = get_object_or_404(
                Category,
                id=kwargs['main_category_id']
            )
            category_form = self.sub_category_form(
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'category_form': category_form,
                    'submit_text': "Créer",
                }
            )
        else:
            category_form = self.main_category_form(
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'category_form': category_form,
                    'submit_text': "Créer",
                }
            )


    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        if 'main_category_id' in kwargs:
            main_category = get_object_or_404(
                Category,
                id=kwargs['main_category_id']
            )
            category_form = self.sub_category_form(
                request.POST,
                prefix='category_',
            )
            if category_form.is_valid():

                category = category_form.save(commit=False)
                category.main_category = main_category
                category.save()

                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'category_form': category_form,
                }
            )
        else:
            category_form = self.main_category_form(
                request.POST,
                prefix='category_',
            )
            if category_form.is_valid():
                category_form.save()
                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={

                    'category_form': category_form,
                    'submit_text': "Créer",
                }
            )


class CategoryUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/category/add_or_update.html'

    permission_required = "administration_pages.change_category"
    raise_exception = True

    main_category_form = MainCategoryForm
    sub_category_form = SubCategoryForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        main_category = get_object_or_404(
            Category,
            id=kwargs['main_category_id']
        )

        if 'sub_category_id' in kwargs:

            sub_category = get_object_or_404(
                Category,
                id=kwargs['sub_category_id']
            )
            category_form = self.sub_category_form(
                instance=sub_category,
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'sub_category': sub_category,
                    'category_form': category_form,
                    'update': True,
                    'submit_text': "Modifier",
                }
            )
        else:
            category_form = self.main_category_form(
                instance=main_category,
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'category_form': category_form,
                    'update': True,
                    'submit_text': "Modifier",
                }
            )

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        main_category = get_object_or_404(
            Category,
            id=kwargs['main_category_id']
        )

        if 'sub_category_id' in kwargs:

            sub_category = get_object_or_404(
                Category,
                id=kwargs['sub_category_id'],
            )
            category_form = self.sub_category_form(
                request.POST,
                instance=sub_category,
                prefix='category_',
            )
            if category_form.is_valid():
                category = category_form.save(commit=False)
                category.main_category = main_category
                category.save()

                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'sub_category': sub_category,
                    'category_form': category_form,
                    'update': True,
                }
            )
        else:
            main_category_form = self.main_category_form(
                request.POST,
                instance=main_category,
                prefix='category_',
            )
            if main_category_form.is_valid():
                main_category_form.save()
                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={
                    'category_form': main_category_form,
                    'main_category': main_category,
                    'update': True,
                }
            )


class PageEditor(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/editor.html'

    permission_required = 'administration_pages.change_page'
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_id = kwargs['page_id']

        page = get_object_or_404(
            Page,
            id=page_id
        )

        context = {
            'page': page,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page = get_object_or_404(
            Page,
            id=kwargs['page_id']
        )

        context = {
            'page': page,
        }
        cache.clear()
        return render(request, self.template_name, context)


class PageInsight(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Vue HTML d'inspection des résultats PSI pour une page (Mobile / Desktop).
    """
    permission_required = "pages.view_page"
    raise_exception = True  # renvoie 403 si non autorisé

    template_name = "administration_pages/insight.html"

    def get(self, request, page_id: int):
        page = get_object_or_404(Page, pk=page_id)

        # Derniers résultats (le signal garantit latest-only)
        insight_mobile = get_latest_insight(page, Strategy.MOBILE)
        insight_desktop = get_latest_insight(page, Strategy.DESKTOP)

        # Clé API dispo ?
        api_key_configured = bool(get_google_api_key())

        context = {
            "page": page,
            "insight_mobile": insight_mobile,
            "insight_desktop": insight_desktop,
            "api_key_configured": api_key_configured,
        }
        return render(request, self.template_name, context)


class PageDelete(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/delete.html'

    permission_required = 'administration_pages.delete_page'
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page = get_object_or_404(
            Page,
            id=kwargs['page_id']
        )


        context = {
            'page': page,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page = get_object_or_404(
            Page,
            id=kwargs['page_id']
        )


        if page.delete():
            cache.clear()
            return redirect('jeiko_administration_pages:main')

        context = {
            'page': page,
            'message': 'Un problème est survenu'
        }

        return render(request, self.template_name, context)


class ModelLibrary(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration_pages/models/main.html"
    permission_required = 'administration_pages.change_page'
    raise_exception = True

    def get(self, request):
        sections = Section.objects.filter(is_model=True).order_by("model_name", "id")
        lines = Line.objects.filter(is_model=True).order_by("model_name", "id")
        blocs = Bloc.objects.filter(is_model=True).order_by("model_name", "id")
        context = {"sections": sections, "lines": lines, "blocs": blocs}
        return render(request, self.template_name, context)


class ModelDelete(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = 'administration_pages/models/delete.html'
    raise_exception = True

    MODEL_MAP = {
        "section": (Section, "administration_pages.delete_section"),
        "line":    (Line,    "administration_pages.delete_line"),
        "bloc":    (Bloc,    "administration_pages.delete_bloc"),
    }

    def get_permission_required(self):
        model_type = (getattr(self, "kwargs", {}) or {}).get("model_type")
        perm = self.MODEL_MAP.get(model_type, (None, None))[1]
        return (perm or "administration_pages.delete_section",)

    @method_decorator(never_cache)
    def get(self, request, model_type, pk):
        Model, _ = self.MODEL_MAP.get(model_type, (None, None))
        if not Model:
            return redirect('jeiko_administration_pages:model_library')
        obj = get_object_or_404(Model, pk=pk, is_model=True)
        return render(request, self.template_name, {"object": obj, "model_type": model_type})

    @method_decorator(never_cache)
    def post(self, request, model_type, pk):
        Model, _ = self.MODEL_MAP.get(model_type, (None, None))
        if not Model:
            return redirect('jeiko_administration_pages:model_library')
        obj = get_object_or_404(Model, pk=pk, is_model=True)
        try:
            obj.delete()
            cache.clear()
            return redirect('jeiko_administration_pages:model_library')
        except Exception:
            ctx = {"object": obj, "model_type": model_type, "message": "Un problème est survenu"}
            return render(request, self.template_name, ctx)


def build_errors_summary_section(
    section_form,
    styles,
    size_forms,
    bg_form,
    bg_params_form,
    custom_css_form=None,
    animation_form=None,
):
    summary = {}

    if section_form.errors or section_form.non_field_errors():
        summary['section'] = section_form.errors.as_ul() or section_form.non_field_errors().as_ul()

    style_errs = []
    for idx, f in enumerate(styles):
        if f.errors or f.non_field_errors():
            style_errs.append(f"<li>Style #{idx+1}: {f.errors.as_text() or f.non_field_errors().as_text()}</li>")
    if style_errs:
        summary['styles'] = "<ul>" + "".join(style_errs) + "</ul>"

    size_errs = []
    for idx, f in enumerate(size_forms):
        if f.errors or f.non_field_errors():
            size_errs.append(f"<li>Taille #{idx+1}: {f.errors.as_text() or f.non_field_errors().as_text()}</li>")
    if size_errs:
        summary['sizes'] = "<ul>" + "".join(size_errs) + "</ul>"

    if bg_form.errors or bg_form.non_field_errors():
        summary['background_image'] = bg_form.errors.as_ul() or bg_form.non_field_errors().as_ul()

    if bg_params_form.errors or bg_params_form.non_field_errors():
        summary['background_params'] = bg_params_form.errors.as_ul() or bg_params_form.non_field_errors().as_ul()

    if custom_css_form and (custom_css_form.errors or custom_css_form.non_field_errors()):
        summary['custom_css'] = custom_css_form.errors.as_ul() or custom_css_form.non_field_errors().as_ul()

    if animation_form and (animation_form.errors or animation_form.non_field_errors()):
        summary['animation'] = animation_form.errors.as_ul() or animation_form.non_field_errors().as_ul()

    return summary


@method_decorator(never_cache, name='dispatch')
class SectionCreate(View):
    choose_template = 'administration_pages/section/choose_type.html'
    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    def get(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        section_models = Section.objects.filter(is_model=True).order_by('position', 'id')
        html = render_to_string(self.choose_template, {"page": page, "section_models": section_models}, request=request)
        if self._is_ajax(request):
            return JsonResponse({"status": "choose_type", "html": html}, status=200)
        return HttpResponse(html)

    @transaction.atomic
    def post(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        choice = (request.POST.get('section_choice') or request.POST.get('preset') or '').strip()
        if not choice:
            return HttpResponseBadRequest("Choix de section manquant")

        last = Section.objects.filter(page=page).order_by('-position').first()
        position = (last.position + 1) if last and last.position is not None else 0

        def _new_stylebox(top=None, right=None, bottom=None, left=None):
            return StyleBox.objects.create(
                top=(top if top is not None else ""),
                right=(right if right is not None else ""),
                bottom=(bottom if bottom is not None else ""),
                left=(left if left is not None else "")
            )

        def _new_size(width=None, height=None):
            return Size.objects.create(width=(width or ""), height=(height or ""))

        if choice == "FULL":
            s_phone = _new_size("100%"); s_tablet = _new_size("100%"); s_laptop = _new_size("100%"); s_computer = _new_size("100%")
            m_phone = _new_stylebox("0", None, "0", "auto"); m_tablet = _new_stylebox("0", None, "0", "auto")
            m_laptop = _new_stylebox("0", None, "0", "auto"); m_computer = _new_stylebox("0", None, "0", "auto")
            p_phone = _new_stylebox("0", "0", "0", "0"); p_tablet = _new_stylebox("0", "0", "0", "0")
            p_laptop = _new_stylebox("0", "0", "0", "0"); p_computer = _new_stylebox("0", "0", "0", "0")

            created_section = Section.objects.create(
                page=page, position=position,
                size_phone=s_phone, size_tablet=s_tablet, size_laptop=s_laptop, size_computer=s_computer,
                margin_phone=m_phone, margin_tablet=m_tablet, margin_laptop=m_laptop, margin_computer=m_computer,
                padding_phone=p_phone, padding_tablet=p_tablet, padding_laptop=p_laptop, padding_computer=p_computer,
                is_model=False
            )

        elif choice == "CLASSIC":
            s_phone = _new_size("92%"); s_tablet = _new_size("730px"); s_laptop = _new_size("950px"); s_computer = _new_size("1140px")
            m_phone = _new_stylebox("0", None, "0", "auto"); m_tablet = _new_stylebox("0", None, "0", "auto")
            m_laptop = _new_stylebox("0", None, "0", "auto"); m_computer = _new_stylebox("0", None, "0", "auto")
            p_phone = _new_stylebox("0", "0", "0", "0"); p_tablet = _new_stylebox("0", "0", "0", "0")
            p_laptop = _new_stylebox("0", "0", "0", "0"); p_computer = _new_stylebox("0", "0", "0", "0")

            created_section = Section.objects.create(
                page=page, position=position,
                size_phone=s_phone, size_tablet=s_tablet, size_laptop=s_laptop, size_computer=s_computer,
                margin_phone=m_phone, margin_tablet=m_tablet, margin_laptop=m_laptop, margin_computer=m_computer,
                padding_phone=p_phone, padding_tablet=p_tablet, padding_laptop=p_laptop, padding_computer=p_computer,
                is_model=False
            )

        elif choice.startswith("MODEL:"):
            try:
                model_id = int(choice.split(":", 1)[1])
            except Exception:
                return HttpResponseBadRequest("Identifiant de modèle invalide")

            model_section = get_object_or_404(Section, id=model_id, is_model=True)
            created_section = section_duplicate(model_section, target_page=page, position=position, as_model=False, link_model=True)

            if created_section.is_model:
                created_section.is_model = False
            if created_section.model_source_id != model_section.id:
                created_section.model_source = model_section
            created_section.save(update_fields=["is_model", "model_source"])

        else:
            return HttpResponseBadRequest("Choix non reconnu")

        html = render_to_string(self.section_partial, {"section": created_section}, request=request)
        if self._is_ajax(request):
            return JsonResponse({"status": "success", "html": html, "section_id": created_section.id}, status=200)
        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)


@method_decorator(never_cache, name='dispatch')
class SectionUpdate(View, AsyncRequestMixin):
    template_name = 'administration_pages/section/form.html'

    @method_decorator(never_cache)
    def get(self, request, page_id, section_id):
        page = get_object_or_404(Page, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        ctx = get_section_forms_context(page, instance=section)
        ctx.update({
            'form_action': reverse('jeiko_administration_pages:section_update', args=[page_id, section_id]),
            'submit_text': 'Mettre à jour la section',
            'section': section,
            'page': page,
        })
        return render(request, self.template_name, ctx)

    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        page = get_object_or_404(Page, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        ctx = get_section_forms_context(page, request.POST, request.FILES, instance=section)

        form = ctx['section_form']
        styles = ctx['style_forms']
        size_forms = ctx['size_forms']
        background_image_form = ctx['background_image_form']
        background_image_parameters_form = ctx['background_image_parameters_form']
        custom_css_form = ctx.get('custom_css_form')
        animation_form = ctx.get('animation_form')

        ctx.update({
            'form_action': reverse('jeiko_administration_pages:section_update', args=[page_id, section_id]),
            'submit_text': 'Mettre à jour la section',
        })

        if custom_css_form is not None:
            custom_css_form.instance.section = section
            custom_css_form.instance.line = None
            custom_css_form.instance.bloc = None

        if animation_form is not None:
            animation_form.instance.section = section
            animation_form.instance.line = None
            animation_form.instance.bloc = None

        if (
            form.is_valid()
            and all(f.is_valid() for f in styles)
            and all(f.is_valid() for f in size_forms)
            and background_image_form.is_valid()
            and background_image_parameters_form.is_valid()
            and (custom_css_form is None or custom_css_form.is_valid())
            and (animation_form is None or animation_form.is_valid())
        ):
            margins  = [f.save() for f in styles[:4]]
            paddings = [f.save() for f in styles[4:8]]
            sizes    = [f.save() for f in size_forms]
            bgimg    = background_image_form.save()
            bgparams = background_image_parameters_form.save()

            section = form.save(commit=False)
            (section.margin_phone, section.margin_tablet, section.margin_laptop, section.margin_computer) = margins
            (section.padding_phone, section.padding_tablet, section.padding_laptop, section.padding_computer) = paddings
            (section.size_phone,   section.size_tablet,   section.size_laptop,   section.size_computer)   = sizes
            section.background_image = bgimg
            section.background_image_parameters = bgparams
            section.save()

            if custom_css_form:
                cc = custom_css_form.save(commit=False)
                if cc.pk is None:
                    cc.section, cc.line, cc.bloc = section, None, None
                cc.save()

            if animation_form:
                anim = animation_form.save(commit=False)
                anim.section, anim.line, anim.bloc = section, None, None
                anim.save()

            if self.is_fetch(request):
                html = render_to_string('administration_pages/partials/section.html', {'section': section}, request=request)
                return self.render_json(content_html=html, status=200, section_id=section.id)

            return redirect('jeiko_administration_pages:page_editor', page_id)

        if self.is_fetch(request):
            ctx['errors_summary'] = build_errors_summary_section(
                form, styles, size_forms, background_image_form, background_image_parameters_form,
                custom_css_form=custom_css_form, animation_form=animation_form
            )
            html = render_to_string(self.template_name, ctx, request=request)
            return HttpResponse(html, status=200)
        return render(request, self.template_name, ctx)


@method_decorator(never_cache, name='dispatch')
class SectionDelete(View, AsyncRequestMixin):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        style_ids = [
            section.margin_phone_id,
            section.margin_tablet_id,
            section.margin_laptop_id,
            section.margin_computer_id,
            section.padding_phone_id,
            section.padding_tablet_id,
            section.padding_laptop_id,
            section.padding_computer_id,
        ]
        section.delete()
        StyleBox.objects.filter(id__in=[sid for sid in style_ids if sid]).delete()

        if self.is_fetch(request):
            return self.render_json(status=200, section_id=section_id)
        return redirect('jeiko_administration_pages:page_editor', page_id)


@method_decorator(never_cache, name='dispatch')
class SectionMoveUp(View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        prev_sec = (
            Section.objects
            .filter(page=section.page, position__lt=section.position)
            .order_by('-position')
            .first()
        )
        if prev_sec:
            # swap
            section.position, prev_sec.position = prev_sec.position, section.position
            section.save()
            prev_sec.save()
        cache.clear()
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"status": "success"})
        return redirect('jeiko_administration_pages:page_editor', page_id)


@method_decorator(never_cache, name='dispatch')
class SectionMoveDown(View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        next_sec = (
            Section.objects
            .filter(page=section.page, position__gt=section.position)
            .order_by('position')
            .first()
        )
        if next_sec:
            section.position, next_sec.position = next_sec.position, section.position
            section.save()
            next_sec.save()
        cache.clear()
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"status": "success"})
        return redirect('jeiko_administration_pages:page_editor', page_id)


def build_errors_summary_line(
    line_form,
    style_forms,
    size_forms,
    bg_form,
    bg_params_form,
    custom_css_form=None,
    animation_form=None,
):
    summary = {}

    if line_form.errors or line_form.non_field_errors():
        summary['line'] = line_form.errors.as_ul() or line_form.non_field_errors().as_ul()

    style_errs = []
    for idx, f in enumerate(style_forms):
        if f.errors or f.non_field_errors():
            style_errs.append(f"<li>Style #{idx+1}: {f.errors.as_text() or f.non_field_errors().as_text()}</li>")
    if style_errs:
        summary['styles'] = "<ul>" + "".join(style_errs) + "</ul>"

    size_errs = []
    for idx, f in enumerate(size_forms):
        if f.errors or f.non_field_errors():
            size_errs.append(f"<li>Taille #{idx+1}: {f.errors.as_text() or f.non_field_errors().as_text()}</li>")
    if size_errs:
        summary['sizes'] = "<ul>" + "".join(size_errs) + "</ul>"

    if bg_form.errors or bg_form.non_field_errors():
        summary['background_image'] = bg_form.errors.as_ul() or bg_form.non_field_errors().as_ul()
    if bg_params_form.errors or bg_params_form.non_field_errors():
        summary['background_params'] = bg_params_form.errors.as_ul() or bg_params_form.non_field_errors().as_ul()

    if custom_css_form and (custom_css_form.errors or custom_css_form.non_field_errors()):
        summary['custom_css'] = custom_css_form.errors.as_ul() or custom_css_form.non_field_errors().as_ul()

    if animation_form and (animation_form.errors or animation_form.non_field_errors()):
        summary['animation'] = animation_form.errors.as_ul() or animation_form.non_field_errors().as_ul()

    return summary


@method_decorator(never_cache, name='dispatch')
class LineCreate(View):
    choose_template = 'administration_pages/line/choose_type.html'
    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    def get(self, request, page_id, section_id):
        page = get_object_or_404(Page, id=page_id)
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        line_models     = Line.objects.filter(is_model=True).order_by('position', 'id')
        desktop_choices = Line.COLUMNS_TYPE_CHOICES
        html = render_to_string(
            self.choose_template,
            {'page': page, 'section': section, 'line_models': line_models, 'desktop_choices': desktop_choices},
            request=request
        )
        if self._is_ajax(request):
            return JsonResponse({"status": "choose_type", "html": html}, status=200)
        return HttpResponse(html)

    @transaction.atomic
    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        choice = (request.POST.get('line_choice') or '').strip()
        if not choice:
            return HttpResponseBadRequest("Choix de ligne manquant")

        last = section.lines.order_by('-position').first()
        position = (last.position + 1) if last and last.position is not None else 0

        if choice == 'LINE':
            columns_type = (request.POST.get('columns_type') or '12').strip()
            columns_type_tablet = (request.POST.get('columns_type_tablet') or columns_type).strip()
            columns_type_phone = (request.POST.get('columns_type_phone') or columns_type).strip()

            def _sb():
                return StyleBox.objects.create(top=0, right=0, bottom=0, left=0)
            def _size():
                return Size.objects.create(width="100%", height="")

            line = Line.objects.create(
                section=section, position=position,
                columns_type=columns_type,
                columns_type_tablet=columns_type_tablet,
                columns_type_phone=columns_type_phone,
                columns_number=len(columns_type.split('-')) if columns_type else 1,
                margin_phone=_sb(), margin_tablet=_sb(), margin_laptop=_sb(), margin_computer=_sb(),
                padding_phone=_sb(), padding_tablet=_sb(), padding_laptop=_sb(), padding_computer=_sb(),
                size_phone=_size(), size_tablet=_size(), size_laptop=_size(), size_computer=_size(),
            )

            for pos in range(1, line.columns_number + 1):
                Bloc.objects.create(
                    line=line, position=pos,
                    margin_phone=StyleBox.objects.create(),
                    margin_tablet=StyleBox.objects.create(),
                    margin_laptop=StyleBox.objects.create(),
                    margin_computer=StyleBox.objects.create(),
                    padding_phone=StyleBox.objects.create(),
                    padding_tablet=StyleBox.objects.create(),
                    padding_laptop=StyleBox.objects.create(),
                    padding_computer=StyleBox.objects.create(),
                )

            html = render_to_string(self.section_partial, {'section': section}, request=request)
            if self._is_ajax(request):
                return JsonResponse({'status': 'success', 'section_id': section.id, 'section_html': html}, status=200)
            return redirect('jeiko_administration_pages:page_editor', page_id=page_id)

        elif choice.startswith('MODEL:'):
            try:
                model_id = int(choice.split(':', 1)[1])
            except Exception:
                return HttpResponseBadRequest("Identifiant de modèle invalide")

            model_line = get_object_or_404(Line, id=model_id, is_model=True)
            line = line_duplicate(model_line, target_section=section, position=position, as_model=False, link_model=True)

            update_fields = []
            if line.is_model:
                line.is_model = False
                update_fields.append('is_model')
            if line.model_source_id != model_line.id:
                line.model_source = model_line
                update_fields.append('model_source')
            if update_fields:
                line.save(update_fields=update_fields)

            html = render_to_string(self.section_partial, {'section': line.section}, request=request)
            if self._is_ajax(request):
                return JsonResponse({'status': 'success', 'section_id': section.id, 'section_html': html}, status=200)
            return redirect('jeiko_administration_pages:page_editor', page_id=page_id)

        else:
            return HttpResponseBadRequest("Choix non reconnu")


@method_decorator(never_cache, name='dispatch')
class LineUpdate(View):
    def get(self, request, page_id, section_id, line_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        line = get_object_or_404(Line, id=line_id, section=section)
        context = get_line_forms_context(section, instance=line)
        context.update({
            "form_action": reverse("jeiko_administration_pages:line_update", args=[page_id, section_id, line_id]),
            "submit_text": "Modifier la ligne",
            "update": True,
            "line": line,
        })
        return render(request, "administration_pages/line/form.html", context)

    def post(self, request, page_id, section_id, line_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        line = get_object_or_404(Line, id=line_id, section=section)
        context = get_line_forms_context(section, data=request.POST, instance=line, files=request.FILES)

        line_form = context["line_form"]
        style_forms = context["style_forms"]
        size_forms = context["size_forms"]
        background_image_form = context["background_image_form"]
        background_image_parameters_form = context["background_image_parameters_form"]
        custom_css_form = context.get("custom_css_form")
        animation_form = context.get("animation_form")

        if custom_css_form is not None:
            custom_css_form.instance.section = None
            custom_css_form.instance.line = line
            custom_css_form.instance.bloc = None

        if animation_form is not None:
            animation_form.instance.section = None
            animation_form.instance.line = line
            animation_form.instance.bloc = None

        if (
            line_form.is_valid()
            and all(f.is_valid() for f in style_forms)
            and all(f.is_valid() for f in size_forms)
            and background_image_form.is_valid()
            and background_image_parameters_form.is_valid()
            and (custom_css_form is None or custom_css_form.is_valid())
            and (animation_form is None or animation_form.is_valid())
        ):
            line = line_form.save(commit=False)
            line.columns_number = len(line.columns_type.split('-')) if line.columns_type else 1

            style_instances = [f.save() for f in style_forms]
            (
                line.margin_phone, line.margin_tablet, line.margin_laptop, line.margin_computer,
                line.padding_phone, line.padding_tablet, line.padding_laptop, line.padding_computer
            ) = style_instances

            size_instances = [f.save() for f in size_forms]
            (line.size_phone, line.size_tablet, line.size_laptop, line.size_computer) = size_instances

            bgimg = background_image_form.save()
            bgimg_params = background_image_parameters_form.save()
            line.background_image = bgimg
            line.background_image_parameters = bgimg_params

            line.save()
            cache.clear()

            desired = line.columns_number
            root_blocks = list(line.blocs.filter(position_in_column=0).values_list('position', flat=True))
            missing_positions = [pos for pos in range(1, desired + 1) if pos not in root_blocks]
            for pos in missing_positions:
                Bloc.objects.create(
                    line=line, position=pos, position_in_column=0,
                    margin_phone=StyleBox.objects.create(),
                    margin_tablet=StyleBox.objects.create(),
                    margin_laptop=StyleBox.objects.create(),
                    margin_computer=StyleBox.objects.create(),
                    padding_phone=StyleBox.objects.create(),
                    padding_tablet=StyleBox.objects.create(),
                    padding_laptop=StyleBox.objects.create(),
                    padding_computer=StyleBox.objects.create(),
                )

            if custom_css_form:
                cc = custom_css_form.save(commit=False)
                if cc.pk is None:
                    cc.section, cc.line, cc.bloc = None, line, None
                cc.save()

            if animation_form:
                anim = animation_form.save(commit=False)
                anim.section, anim.line, anim.bloc = None, line, None
                anim.save()

            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                html = render_to_string("administration_pages/partials/section.html", {"section": section}, request=request)
                return JsonResponse({"status": "success", "section_id": section.id, "section_html": html})

            return redirect("jeiko_administration_pages:page_editor", page_id)

        context.update({
            "form_action": reverse("jeiko_administration_pages:line_update", args=[page_id, section_id, line_id]),
            "submit_text": "Modifier la ligne",
            "update": True,
            "line": line,
        })
        context["errors_summary"] = build_errors_summary_line(
            line_form, style_forms, size_forms, background_image_form, background_image_parameters_form,
            custom_css_form=custom_css_form, animation_form=animation_form
        )

        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string("administration_pages/line/form.html", context, request=request)
            return HttpResponse(html, status=200)
        return render(request, "administration_pages/line/form.html", context)


@method_decorator(never_cache, name='dispatch')
class LineDelete(View):
    """
    Suppression d'une ligne :
    - sur fetch AJAX : renvoie {"status":"success"}
    - sinon : redirect vers page_editor
    """
    def post(self, request, page_id, section_id, line_id):
        line = get_object_or_404(Line, id=line_id, section_id=section_id, section__page_id=page_id)
        line.delete()
        cache.clear()

        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            section = line.section
            html = render_to_string("administration_pages/partials/section.html", {"section": section}, request=request)
            return JsonResponse({"status": "success", "section_id": section.id, "section_html": html})
        return redirect("jeiko_administration_pages:page_editor", page_id)


class LineMoveUp(View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id):
        print("post")
        # Récupère la ligne courante, vérifie qu'elle appartient bien à la section/page
        line = get_object_or_404(
            Line,
            id=line_id,
            section_id=section_id,
            section__page_id=page_id
        )
        # Cherche la ligne précédente dans la même section
        prev_line = (
            Line.objects
            .filter(section=line.section, position__lt=line.position)
            .order_by('-position')
            .first()
        )
        if prev_line:
            # Échange des positions
            line.position, prev_line.position = prev_line.position, line.position
            line.save()
            prev_line.save()
        cache.clear()
        # Si AJAX, renvoie JSON succès, sinon redirect
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            section = line.section
            html = render_to_string("administration_pages/partials/section.html", {"section": section}, request=request)
            return JsonResponse({"status": "success", "section_id": section.id, "section_html": html})
        return redirect('jeiko_administration_pages:page_editor', page_id)


class LineMoveDown(View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id):

        line = get_object_or_404(
            Line,
            id=line_id,
            section_id=section_id,
            section__page_id=page_id
        )
        # Cherche la ligne suivante dans la même section
        next_line = (
            Line.objects
            .filter(section=line.section, position__gt=line.position)
            .order_by('position')
            .first()
        )
        if next_line:
            line.position, next_line.position = next_line.position, line.position
            line.save()
            next_line.save()
        cache.clear()
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            section = line.section
            html = render_to_string("administration_pages/partials/section.html", {"section": section}, request=request)
            return JsonResponse({"status": "success", "section_id": section.id, "section_html": html})
        return redirect('jeiko_administration_pages:page_editor', page_id)


# Defaults dynamiques (si disponible)
try:
    from .models import DYNAMIC_DEFAULTS
except Exception:
    DYNAMIC_DEFAULTS = {}


@require_GET
@never_cache
def editing_menu(request):
    """
    Retourne le fragment HTML du menu d'édition.
    """
    # Si besoin, vous pouvez passer un contexte ici.
    html = render_to_string('administration_pages/content/editing_menu.html', request=request)
    return HttpResponse(html)


@require_GET
@never_cache
def editing_menu_section_line(request):
    """
    Retourne le fragment HTML du menu d'édition.
    """
    # Si besoin, vous pouvez passer un contexte ici.
    html = render_to_string('administration_pages/includes/sections_lines_editing_menu.html', request=request)
    return HttpResponse(html)


@method_decorator(never_cache, name='dispatch')
class ContentTypeChoice(View):
    """
    GET  : si content_type == NOT_SET => status="choose_type", html=choose_type.html
           sinon                       => status="ok", html=edit_{type}.html
    POST : crée/initialise le Content (TEXT/IMAGE/BUTTON/CALENDAR/FORM/CHART/VIDEO/DYN_*) et renvoie l’éditeur.
    """

    def _get_objects(self, kwargs):
        page = get_object_or_404(Page, id=kwargs['page_id'])
        section = get_object_or_404(Section, id=kwargs['section_id'], page=page)
        line = get_object_or_404(Line, id=kwargs['line_id'], section=section)
        bloc = get_object_or_404(Bloc, id=kwargs['bloc_id'], line=line)
        return page, section, line, bloc

    @method_decorator(never_cache)
    def get(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content, _ = Content.objects.get_or_create(bloc=bloc)
        bloc_models = Bloc.objects.filter(is_model=True)

        if content.content_type == Content.CONTENT_TYPE_CHOICES[0][0]:  # NOT_SET
            html = render_to_string(
                "administration_pages/content/choose_type.html",
                {"page": page, "section": section, "line": line, "bloc": bloc, "bloc_models": bloc_models},
                request=request
            )
            return JsonResponse({"status": "choose_type", "html": html})

        return self._render_editor(request, page, section, line, bloc, content)

    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content, _ = Content.objects.get_or_create(bloc=bloc)
        ct = request.POST.get('content_type')

        if ct == "TEXT":
            content.content_text = ContentText.objects.create(text="")
            content.content_type = "TEXT"

        elif ct == "IMAGE":
            img = ImageContent.objects.create()
            ci = ContentImage.objects.create(image_content=img)
            content.content_image = ci
            content.content_type = "IMAGE"

        elif ct == "BUTTON":
            btn = ContentButton.objects.create(label="Cliquez ici")
            content.content_button = btn
            content.content_type = "BUTTON"

        elif ct == "CALENDAR":
            cc = ContentCalendar.objects.create(title="Réserver un rendez-vous")
            content.content_calendar = cc
            content.content_type = "CALENDAR"

        elif ct == "FORM":
            formulaire = ContentFormulaire.objects.create(
                name="Nouveau formulaire",
                mail_subject="Nouveau message reçu",
                success_message="Merci, votre message a bien été envoyé.",
            )
            content.content_formulaire = formulaire
            content.content_type = "FORM"

        elif ct == "CHART":
            chart = ContentChartQuestionnaire.objects.create(chart_type="bar", options_json={})
            content.content_chart = chart
            content.content_type = "CHART"

        elif ct == "VIDEO":
            cv = ContentVideo.objects.create(source=ContentVideo.Source.EXTERNAL)
            content.content_video = cv
            content.content_type = "VIDEO"

        elif ct and ct.startswith("DYN_"):
            content.content_type = ct
            content.data = copy.deepcopy(DYNAMIC_DEFAULTS.get(ct, {}))
            content.save()
            return self._render_editor(request, page, section, line, bloc, content)

        else:
            return JsonResponse({"status": "error", "message": "Type non reconnu"}, status=400)

        content.save()
        return self._render_editor(request, page, section, line, bloc, content)

    def _render_editor(self, request, page, section, line, bloc, content):
        ctx = {"page": page, "section": section, "line": line, "bloc": bloc}

        # --- classiques ---
        if content.content_type == "TEXT":
            ctx["text_form"] = TextForm(prefix="text_", instance=content.content_text)
            tpl = "administration_pages/content/edit_text.html"

        elif content.content_type == "IMAGE":
            ctx["image_form"] = ImageForm(prefix="image_", instance=content.content_image.image_content)
            ctx["content_image_form"] = ContentImageForm(prefix="content_", instance=content.content_image)
            tpl = "administration_pages/content/edit_image.html"

        elif content.content_type == "BUTTON":
            ctx["button_form"] = ButtonContentForm(prefix="button_", instance=content.content_button)
            tpl = "administration_pages/content/edit_button.html"

        elif content.content_type == "CALENDAR":
            ctx["calendar_form"] = ContentCalendarForm(prefix="calendar_", instance=content.content_calendar)
            tpl = "administration_pages/content/edit_calendar.html"

        elif content.content_type == "FORM":
            ctx["formulaire"] = content.content_formulaire
            ctx["fields"] = content.content_formulaire.fields.all().order_by("order", "id")
            tpl = "administration_pages/content/edit_formulaire.html"

        elif content.content_type == "CHART":
            ctx["chart"] = content.content_chart
            tpl = "administration_pages/content/edit_chart.html"

        elif content.content_type == "VIDEO":
            ctx["video_form"] = ContentVideoForm(prefix="video_", instance=content.content_video)
            tpl = "administration_pages/content/edit_video.html"

        # --- dyn typés ---
        elif content.content_type == "DYN_FAQ":
            ctx["faq_formset"] = FAQItemFormSet(instance=content, prefix="faq")
            ctx["faq_opts"] = FAQOptionsForm(
                initial={
                    "multiple": content.data.get("multiple", False),
                    "title_tag": content.data.get("title_tag", "H4"),
                    "main_title": content.data.get("main_title", ""),
                    "main_title_tag": content.data.get("main_title_tag", "H4"),
                },
                prefix="faqopt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_faq.html"

        elif content.content_type == "DYN_TABS":
            ctx["tab_formset"] = TabItemFormSet(instance=content, prefix="tabs")
            ctx["tabs_opts"] = TabsOptionsForm(initial={"active": content.data.get("active", 0)}, prefix="tabsopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_tabs.html"

        elif content.content_type == "DYN_CAROUSEL":
            ctx["car_formset"] = CarouselSlideFormSet(instance=content, prefix="car")
            ctx["car_opts"] = CarouselOptionsForm(
                initial={
                    "autoplay": content.data.get("autoplay", True),
                    "interval": content.data.get("interval", 5000),
                    "hide_label": content.data.get("hide_label", True)
                },
                prefix="caropt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_carousel.html"

        elif content.content_type == "DYN_PROGRESS":
            ctx["prog_formset"] = ProgressStepFormSet(instance=content, prefix="prog")
            ctx["prog_opts"] = ProgressOptionsForm(initial={"progress": content.data.get("progress", None)}, prefix="progopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_progress.html"

        elif content.content_type == "DYN_TESTIMONIALS":
            ctx["tst_formset"] = TestimonialItemFormSet(instance=content, prefix="tst")
            ctx["tst_opts"] = TestimonialsSliderOptionsForm(
                initial={"autoplay": content.data.get("autoplay", True), "interval": content.data.get("interval", 7000)},
                prefix="tstopt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_testimonials.html"

        elif content.content_type == "DYN_TESTIMONIALS_GRID":
            ctx["tst_formset"] = TestimonialItemFormSet(instance=content, prefix="tst")
            ctx["tst_opts"] = TestimonialsGridOptionsForm(
                initial={"perRow": content.data.get("perRow", 3), "rotate": content.data.get("rotate", True), "interval": content.data.get("interval", 6000)},
                prefix="tstopt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_testimonials_grid.html"

        elif content.content_type == "DYN_FILTER":
            ctx["lf_formset"] = LiveFilterItemFormSet(instance=content, prefix="lf")
            ctx["lf_opts"] = LiveFilterOptionsForm(initial={"keys": ",".join(content.data.get("keys", ["title", "category"]))}, prefix="lfopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_live_filter.html"

        elif content.content_type == "DYN_COUNTDOWN":
            ctx["cd_opts"] = CountdownOptionsForm(initial={"deadline": content.data.get("deadline", "")}, prefix="cdopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_countdown.html"

        elif content.content_type == "DYN_COUNTDOWN_CTA":
            ctx["cd_opts"] = CountdownCTAOptionsForm(
                initial={
                    "deadline": content.data.get("deadline", ""),
                    "ctaText": content.data.get("ctaText", "Réserver"),
                    "ctaHref": content.data.get("ctaHref", "#"),
                },
                prefix="cdopt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_countdown_cta.html"

        elif content.content_type == "DYN_ACCORDION_ADV":
            sections = content.accordion_sections.all()
            ctx["acc_sec_formset"] = AccordionSectionFormSet(instance=content, prefix="acc")
            ctx["acc_child_sets"] = {sec.pk: AccordionChildFormSetFactory(sec) for sec in sections}
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_accordion_adv.html"

        elif content.content_type == "DYN_PRICING_TABLE":
            ctx["pl_formset"] = PricingPlanFormSet(instance=content, prefix="pl")
            ctx["pl_feat_sets"] = {pl.pk: PricingFeatureFormSetFactory(pl) for pl in content.pricing_plans.all()}
            ctx["pl_opts"] = PricingOptionsForm(initial={"yearly": content.data.get("yearly", False)}, prefix="plopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_pricing.html"

        elif content.content_type == "DYN_GALLERY_FILTER":
            gal_formset = GalleryItemFormSet(instance=content, prefix="gal")
            gal_opts = GalleryOptionsForm(initial={"categories": ",".join(content.data.get("categories", ["all"]))}, prefix="galopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_gallery.html"
            ctx = {
                "page": page, "section": section, "line": line, "bloc": bloc,
                "gal_formset": gal_formset, "gal_opts": gal_opts, "content": content,
            }

        elif content.content_type == "DYN_STEPPER":
            ctx["stp_formset"] = StepperStepFormSet(instance=content, prefix="stp")
            ctx["stp_opts"] = StepperOptionsForm(initial={"start": content.data.get("start", 0)}, prefix="stpopt_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_stepper.html"

        elif content.content_type == "DYN_RATING":
            ctx["rt_opts"] = RatingOptionsForm(
                initial={
                    "rating": content.data.get("rating", 4.0),
                    "count": content.data.get("count", 0),
                    "max": content.data.get("max", 5),
                    "editable": content.data.get("editable", False),
                },
                prefix="rtopt_"
            )
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dyn/edit_dyn_rating.html"

        else:
            ctx["dyn_form"] = DynamicContentForm(initial_data=content.data, prefix="dyn_")
            ctx["content"] = content
            tpl = "administration_pages/content/edit_dynamic.html"

        # Forms style/size/css du bloc (GET => non bindés)
        bloc_ctx_forms = get_bloc_forms_context(bloc, data=None)
        ctx.update(bloc_ctx_forms)

        html = render_to_string(tpl, ctx, request=request)
        return JsonResponse({"status": "success", "html": html})


@method_decorator(never_cache, name='dispatch')
class ContentTypeChoiceFromModel(View):
    """
    POST : remplace le bloc courant par un bloc basé sur un modèle existant.
           Renvoie le fragment HTML du nouveau bloc.
    """
    bloc_partial = 'administration_pages/partials/bloc.html'
    section_partial = 'administration_pages/partials/section.html'

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        old_bloc = get_object_or_404(Bloc, id=bloc_id, line=line)

        choice = (request.POST.get("bloc_model_choice") or "").strip()
        if not choice.startswith("MODEL:"):
            return HttpResponseBadRequest("Choix de modèle de bloc invalide")

        try:
            model_id = int(choice.split(":", 1)[1])
        except Exception:
            return HttpResponseBadRequest("Identifiant de modèle de bloc invalide")

        model_bloc = get_object_or_404(Bloc, id=model_id, is_model=True)

        position = old_bloc.position or 0

        # supprimer bloc + contenu
        try:
            old_content = getattr(old_bloc, "content", None)
            if old_content:
                old_content.delete()
            old_bloc.delete()
        except Exception:
            pass

        new_bloc = bloc_duplicate(model_bloc, target_line=line, position=position, as_model=False, link_model=True)

        update_fields = []
        if new_bloc.is_model:
            new_bloc.is_model = False
            update_fields.append("is_model")
        if new_bloc.model_source_id != model_bloc.id:
            new_bloc.model_source = model_bloc
            update_fields.append("model_source")
        if update_fields:
            new_bloc.save(update_fields=update_fields)

        cache.clear()
        html = render_to_string(self.section_partial, {"section": section}, request=request)

        return JsonResponse({
            "status": "success",
            "section_html": html,
            "bloc_id": new_bloc.id,
            "section_id": section.id
        }, status=200)


@method_decorator(never_cache, name='dispatch')
class EditContent(View):
    """
    GET : rend le formulaire d’édition du contenu (texte/image/etc.) {status:"ok", html:…}
    POST: sauvegarde et renvoie {status:"success", html:…}
    """

    def _get_objects(self, kwargs):
        page    = get_object_or_404(Page, id=kwargs['page_id'])
        section = get_object_or_404(Section, id=kwargs['section_id'], page=page)
        line    = get_object_or_404(Line, id=kwargs['line_id'], section=section)
        bloc    = get_object_or_404(Bloc, id=kwargs['bloc_id'], line=line)
        return page, section, line, bloc

    @method_decorator(never_cache)
    def get(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content = getattr(bloc, "content", None)
        if not content or content.content_type == Content.CONTENT_TYPE_CHOICES[0][0]:
            return JsonResponse({"status": "choose_type", "html": ""})
        return ContentTypeChoice()._render_editor(request, page, section, line, bloc, content)

    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content = getattr(bloc, "content", None)
        if not content or content.content_type == Content.CONTENT_TYPE_CHOICES[0][0]:
            return JsonResponse({"status": "error", "message": "Contenu non initialisé"}, status=400)

        data = request.POST
        files = request.FILES

        # --- spécifiques par type ---
        if content.content_type == "IMAGE":
            image_form = ImageForm(data, files, prefix="image_", instance=content.content_image.image_content)
            content_image_form = ContentImageForm(data, prefix="content_", instance=content.content_image)
            tpl = "administration_pages/content/edit_image.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "image_form": image_form, "content_image_form": content_image_form}
            main_valid = image_form.is_valid() and content_image_form.is_valid()

        elif content.content_type == "TEXT":
            form = TextForm(data, prefix="text_", instance=content.content_text)
            tpl = "administration_pages/content/edit_text.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "text_form": form}
            main_valid = form.is_valid()

        elif content.content_type == "BUTTON":
            form = ButtonContentForm(data, prefix="button_", instance=content.content_button)
            tpl = "administration_pages/content/edit_button.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "button_form": form}
            main_valid = form.is_valid()

        elif content.content_type == "CALENDAR":
            form = ContentCalendarForm(data, prefix="calendar_", instance=content.content_calendar)
            tpl = "administration_pages/content/edit_calendar.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "calendar_form": form}
            main_valid = form.is_valid()

        elif content.content_type == "FORM":
            formulaire = content.content_formulaire
            formulaire.name = data.get("name", formulaire.name)
            formulaire.description = data.get("description", formulaire.description)
            formulaire.mail_subject = data.get("mail_subject", formulaire.mail_subject)
            formulaire.success_message = data.get("success_message", formulaire.success_message)
            formulaire.to_email = data.get("to_email", formulaire.to_email)
            formulaire.from_email = data.get("from_email", formulaire.from_email)
            formulaire.save()
            fields = formulaire.fields.all().order_by("order", "id")
            tpl = "administration_pages/content/edit_formulaire.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "formulaire": formulaire, "fields": fields}
            main_valid = True

        elif content.content_type == "CHART":
            chart = content.content_chart
            chart.chart_type = data.get("chart_type", chart.chart_type)
            chart.title = data.get("title", chart.title)
            chart.description = data.get("description", chart.description)
            try:
                options = data.get("options_json", "{}")
                chart.options_json = json.loads(options) if options else {}
            except Exception:
                pass
            chart.save()
            tpl = "administration_pages/content/edit_chart.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "chart": chart}
            main_valid = True

        elif content.content_type == "VIDEO":
            form = ContentVideoForm(data, files, prefix="video_", instance=content.content_video)
            tpl = "administration_pages/content/edit_video.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "video_form": form}
            main_valid = form.is_valid()

        # --- dyn typés ---
        elif content.content_type == "DYN_FAQ":
            faq_fs = build_bound_inline_formset(data, files, FAQItemFormSet, prefix="faq", instance=content,
                                                start_order=1)
            faq_opts = FAQOptionsForm(data, prefix="faqopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_faq.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "faq_formset": faq_fs, "faq_opts": faq_opts, "content": content}
            main_valid = faq_fs.is_valid() and faq_opts.is_valid()

        elif content.content_type == "DYN_TABS":
            tab_fs = build_bound_inline_formset(data, files, TabItemFormSet, prefix="tabs", instance=content,
                                                start_order=1)
            tabs_opts = TabsOptionsForm(data, prefix="tabsopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_tabs.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "tab_formset": tab_fs, "tabs_opts": tabs_opts, "content": content}
            main_valid = tab_fs.is_valid() and tabs_opts.is_valid()

        elif content.content_type == "DYN_CAROUSEL":
            car_fs = build_bound_inline_formset(data, files, CarouselSlideFormSet, prefix="car", instance=content,
                                                start_order=1)
            car_opts = CarouselOptionsForm(data, prefix="caropt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_carousel.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "car_formset": car_fs, "car_opts": car_opts, "content": content}
            main_valid = car_fs.is_valid() and car_opts.is_valid()

        elif content.content_type == "DYN_PROGRESS":
            prog_fs = build_bound_inline_formset(data, files, ProgressStepFormSet, prefix="prog", instance=content,
                                                 start_order=1)
            prog_opts = ProgressOptionsForm(data, prefix="progopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_progress.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "prog_formset": prog_fs, "prog_opts": prog_opts, "content": content}
            main_valid = prog_fs.is_valid() and prog_opts.is_valid()

        elif content.content_type == "DYN_TESTIMONIALS":
            tst_fs = build_bound_inline_formset(data, files, TestimonialItemFormSet, prefix="tst", instance=content,
                                                start_order=1)
            tst_opts = TestimonialsSliderOptionsForm(data, prefix="tstopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_testimonials.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "tst_formset": tst_fs, "tst_opts": tst_opts, "content": content}
            main_valid = tst_fs.is_valid() and tst_opts.is_valid()

        elif content.content_type == "DYN_TESTIMONIALS_GRID":
            tst_fs = build_bound_inline_formset(data, files, TestimonialItemFormSet, prefix="tst", instance=content,
                                                start_order=1)
            tst_opts = TestimonialsGridOptionsForm(data, prefix="tstopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_testimonials_grid.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "tst_formset": tst_fs, "tst_opts": tst_opts, "content": content}
            main_valid = tst_fs.is_valid() and tst_opts.is_valid()

        elif content.content_type == "DYN_FILTER":
            lf_fs = build_bound_inline_formset(data, files, LiveFilterItemFormSet, prefix="lf", instance=content,
                                               start_order=1)
            lf_opts = LiveFilterOptionsForm(data, prefix="lfopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_live_filter.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "lf_formset": lf_fs, "lf_opts": lf_opts, "content": content}
            main_valid = lf_fs.is_valid() and lf_opts.is_valid()

        elif content.content_type == "DYN_COUNTDOWN":
            cd_opts = CountdownOptionsForm(data, prefix="cdopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_countdown.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "cd_opts": cd_opts, "content": content}
            main_valid = cd_opts.is_valid()

        elif content.content_type == "DYN_COUNTDOWN_CTA":
            cd_opts = CountdownCTAOptionsForm(data, prefix="cdopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_countdown_cta.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "cd_opts": cd_opts, "content": content}
            main_valid = cd_opts.is_valid()

        elif content.content_type == "DYN_ACCORDION_ADV":
            acc_sec_fs = AccordionSectionFormSet(data, instance=content, prefix="acc")
            child_sets = {}
            for sec in content.accordion_sections.all():
                fs = AccordionChildFormSetFactory(sec)
                fs.data = data
                fs.is_bound = True
                child_sets[sec.pk] = fs
            tpl = "administration_pages/content/edit_dyn/edit_dyn_accordion_adv.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "acc_sec_formset": acc_sec_fs, "acc_child_sets": child_sets, "content": content}
            main_valid = acc_sec_fs.is_valid() and all(fs.is_valid() for fs in child_sets.values())

        elif content.content_type == "DYN_PRICING_TABLE":
            pl_fs = build_bound_inline_formset(data, files, PricingPlanFormSet, prefix="pl", instance=content,
                                               start_order=1)
            feat_sets = {}
            for pl in content.pricing_plans.all():
                fs = PricingFeatureFormSetFactory(pl)
                fs.data = data
                fs.is_bound = True
                feat_sets[pl.pk] = fs
            pl_opts = PricingOptionsForm(data, prefix="plopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_pricing.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "pl_formset": pl_fs, "pl_feat_sets": feat_sets, "pl_opts": pl_opts, "content": content}
            main_valid = pl_fs.is_valid() and pl_opts.is_valid() and all(fs.is_valid() for fs in feat_sets.values())

        elif content.content_type == "DYN_GALLERY_FILTER":
            gal_fs = build_bound_inline_formset(data, files, GalleryItemFormSet, prefix="gal", instance=content,
                                                start_order=1)
            gal_opts = GalleryOptionsForm(data, prefix="galopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_gallery.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "gal_formset": gal_fs, "gal_opts": gal_opts, "content": content}
            main_valid = gal_fs.is_valid() and gal_opts.is_valid()

        elif content.content_type == "DYN_STEPPER":
            stp_fs = build_bound_inline_formset(data, files, StepperStepFormSet, prefix="stp", instance=content,
                                                start_order=1)
            stp_opts = StepperOptionsForm(data, prefix="stpopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_stepper.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc,
                   "stp_formset": stp_fs, "stp_opts": stp_opts, "content": content}
            main_valid = stp_fs.is_valid() and stp_opts.is_valid()

        elif content.content_type == "DYN_RATING":
            rt_opts = RatingOptionsForm(data, prefix="rtopt_")
            tpl = "administration_pages/content/edit_dyn/edit_dyn_rating.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "rt_opts": rt_opts, "content": content}
            main_valid = rt_opts.is_valid()

        else:
            form = DynamicContentForm(data, prefix="dyn_")
            tpl = "administration_pages/content/edit_dynamic.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "dyn_form": form, "content": content}
            main_valid = form.is_valid()

        # --- forms style/size/css/animation du bloc (bindés)
        bloc_ctx_forms = get_bloc_forms_context(bloc, data=data)
        custom_css_form = bloc_ctx_forms.get("custom_css_form")
        animation_form = bloc_ctx_forms.get("animation_form")  # ✅ NEW

        if custom_css_form is not None:
            custom_css_form.instance.section = None
            custom_css_form.instance.line = None
            custom_css_form.instance.bloc = bloc

        if animation_form is not None:
            animation_form.instance.section = None
            animation_form.instance.line = None
            animation_form.instance.bloc = bloc

        # Regroupe pour validation globale (ajout animation_form)
        if content.content_type == "IMAGE":
            all_forms = [image_form, content_image_form] \
                        + bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] \
                        + ([custom_css_form] if custom_css_form else []) \
                        + ([animation_form] if animation_form else [])
        elif content.content_type in ("FORM", "CHART", "VIDEO"):
            base_forms = []
            if content.content_type == "VIDEO":
                base_forms = [form]
            all_forms = base_forms \
                        + bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] \
                        + ([custom_css_form] if custom_css_form else []) \
                        + ([animation_form] if animation_form else [])
        else:
            base_forms = []
            if 'form' in locals():
                base_forms = [form]
            elif 'faq_fs' in locals():
                base_forms = [faq_fs, faq_opts]
            elif 'tab_fs' in locals():
                base_forms = [tab_fs, tabs_opts]
            elif 'car_fs' in locals():
                base_forms = [car_fs, car_opts]
            elif 'prog_fs' in locals():
                base_forms = [prog_fs, prog_opts]
            elif 'tst_fs' in locals() and 'tst_opts' in locals():
                base_forms = [tst_fs, tst_opts]
            elif 'lf_fs' in locals():
                base_forms = [lf_fs, lf_opts]
            elif 'cd_opts' in locals():
                base_forms = [cd_opts]
            elif 'acc_sec_fs' in locals():
                base_forms = [acc_sec_fs] + list(child_sets.values())
            elif 'pl_fs' in locals():
                base_forms = [pl_fs, pl_opts] + list(feat_sets.values())
            elif 'gal_fs' in locals():
                base_forms = [gal_fs, gal_opts]
            elif 'stp_fs' in locals():
                base_forms = [stp_fs, stp_opts]
            elif 'rt_opts' in locals():
                base_forms = [rt_opts]
            all_forms = base_forms \
                        + bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] \
                        + ([custom_css_form] if custom_css_form else []) \
                        + ([animation_form] if animation_form else [])

        valid = main_valid and all((f is None) or f.is_valid() for f in all_forms)

        if not valid:
            html = render_to_string(tpl, {**ctx, **bloc_ctx_forms}, request=request)

            # Collecte d’erreurs (inclut animation_form)
            base_forms = []
            if 'form' in locals():
                base_forms = [form]
            elif 'faq_fs' in locals():
                base_forms = [faq_fs, faq_opts]
            elif 'tab_fs' in locals():
                base_forms = [tab_fs, tabs_opts]
            elif 'car_fs' in locals():
                base_forms = [car_fs, car_opts]
            elif 'prog_fs' in locals():
                base_forms = [prog_fs, prog_opts]
            elif 'tst_fs' in locals() and 'tst_opts' in locals():
                base_forms = [tst_fs, tst_opts]
            elif 'lf_fs' in locals():
                base_forms = [lf_fs, lf_opts]
            elif 'cd_opts' in locals():
                base_forms = [cd_opts]
            elif 'acc_sec_fs' in locals():
                base_forms = [acc_sec_fs] + list(child_sets.values())
            elif 'pl_fs' in locals():
                base_forms = [pl_fs, pl_opts] + list(feat_sets.values())
            elif 'gal_fs' in locals():
                base_forms = [gal_fs, gal_opts]
            elif 'stp_fs' in locals():
                base_forms = [stp_fs, stp_opts]
            elif 'rt_opts' in locals():
                base_forms = [rt_opts]

            all_for_err = []
            if content.content_type == "IMAGE":
                all_for_err = [image_form, content_image_form]
            elif content.content_type in ("FORM", "CHART", "VIDEO"):
                all_for_err = base_forms
            else:
                all_for_err = base_forms
            all_for_err += bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] \
                           + ([custom_css_form] if custom_css_form else []) \
                           + ([animation_form] if animation_form else [])

            errs = _errors_dict(*all_for_err)

            import logging
            logger = logging.getLogger(__name__)
            logger.warning("EditContent invalid (%s) - errors: %s", content.content_type, errs)

            return JsonResponse({"status": "error", "errors": errs, "html": html}, status=400)

        # --- SAUVEGARDE principale selon le type ---
        if content.content_type == "TEXT":
            form.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "IMAGE":
            image_instance = image_form.save()
            content_image = content_image_form.save(commit=False)
            content_image.image_content = image_instance
            content_image.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type in ("FORM", "CHART"):
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "VIDEO":
            form.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_FAQ":
            faq_fs.save()
            resequence_queryset(content.faq_items.all(), field="order", start=1)
            content.data["multiple"] = faq_opts.cleaned_data.get("multiple", False)
            content.data["title_tag"] = (faq_opts.cleaned_data.get("title_tag") or "h4").lower()
            content.data["main_title"] = (faq_opts.cleaned_data.get("main_title") or "")
            content.data["main_title_tag"] = (faq_opts.cleaned_data.get("main_title_tag") or "h3").lower()
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_TABS":
            tab_fs.save()
            resequence_queryset(content.tab_items.all(), field="order", start=1)
            content.data["active"] = tabs_opts.cleaned_data.get("active", 0) or 0
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_CAROUSEL":
            _ = car_fs.save(commit=False)
            for f in car_fs.forms:
                if f in car_fs.deleted_forms:
                    continue
                f.save(commit=True)
            for obj in car_fs.deleted_objects:
                obj.delete()
            resequence_queryset(content.carousel_slides.all(), field="order", start=1)
            content.data["autoplay"] = car_opts.cleaned_data.get("autoplay", True)
            content.data["interval"] = car_opts.cleaned_data.get("interval", 5000) or 5000
            content.data["hide_label"] = car_opts.cleaned_data.get("hide_label", True)
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_PROGRESS":
            prog_fs.save()
            resequence_queryset(content.progress_steps.all(), field="order", start=1)
            pval = prog_opts.cleaned_data.get("progress")
            if pval is not None:
                content.data["progress"] = float(pval)
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_TESTIMONIALS":
            tst_fs.save()
            resequence_queryset(content.testimonial_items.all(), field="order", start=1)
            content.data["autoplay"] = tst_opts.cleaned_data.get("autoplay", True)
            content.data["interval"] = tst_opts.cleaned_data.get("interval", 7000) or 7000
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_TESTIMONIALS_GRID":
            tst_fs.save()
            resequence_queryset(content.testimonial_items.all(), field="order", start=1)
            content.data["perRow"] = tst_opts.cleaned_data.get("perRow", 3) or 3
            content.data["rotate"] = tst_opts.cleaned_data.get("rotate", True)
            content.data["interval"] = tst_opts.cleaned_data.get("interval", 6000) or 6000
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_FILTER":
            lf_fs.save()
            resequence_queryset(content.livefilter_items.all(), field="order", start=1)
            keys_raw = lf_opts.cleaned_data.get("keys")
            if isinstance(keys_raw, str):
                keys = [k.strip() for k in keys_raw.split(",") if k.strip()]
            else:
                keys = keys_raw or ["title", "category"]
            content.data["keys"] = keys
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type in ("DYN_COUNTDOWN", "DYN_COUNTDOWN_CTA"):
            deadline = cd_opts.cleaned_data.get("deadline")
            if isinstance(deadline, (datetime.datetime, datetime.date)):
                if isinstance(deadline, datetime.date) and not isinstance(deadline, datetime.datetime):
                    deadline = datetime.datetime.combine(deadline, datetime.time(0, 0, 0))
                deadline_str = deadline.strftime("%Y-%m-%d %H:%M:%S")
            else:
                deadline_str = (str(deadline).strip()) if deadline else ""
            content.data["deadline"] = deadline_str
            if content.content_type == "DYN_COUNTDOWN_CTA":
                content.data["ctaText"] = cd_opts.cleaned_data.get("ctaText") or "Réserver"
                content.data["ctaHref"] = cd_opts.cleaned_data.get("ctaHref") or "#"
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_ACCORDION_ADV":
            acc_sec_fs.save()
            for sec in content.accordion_sections.all():
                fs = AccordionChildFormSetFactory(sec)
                fs.data = data
                fs.is_bound = True
                if fs.is_valid():
                    fs.save()
                resequence_queryset(sec.children.all(), field="order", start=1)
            resequence_queryset(content.accordion_sections.all(), field="order", start=1)
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_PRICING_TABLE":
            pl_fs.save()
            resequence_queryset(content.pricing_plans.all(), field="order", start=1)
            for pl in content.pricing_plans.all():
                fs = PricingFeatureFormSetFactory(pl)
                fs.data = data
                fs.is_bound = True
                if fs.is_valid():
                    fs.save()
                resequence_queryset(pl.features.all(), field="order", start=1)
            content.data["yearly"] = bool(pl_opts.cleaned_data.get("yearly", False))
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_GALLERY_FILTER":
            gal_fs.save()
            resequence_queryset(content.gallery_items.all(), field="order", start=1)
            cats = gal_opts.cleaned_data.get("categories") or []
            if not cats:
                deduced = sorted({
                    (gi.category or "").strip()
                    for gi in content.gallery_items.all()
                    if (gi.category or "").strip()
                })
                if "all" not in [c.lower() for c in deduced]:
                    cats = ["all"] + deduced
                else:
                    cats = deduced
            else:
                if "all" not in [c.lower() for c in cats]:
                    cats = ["all"] + cats

            snap = _snapshot_for_content(content)
            snap["categories"] = cats
            content.data = snap
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_STEPPER":
            stp_fs.save()
            resequence_queryset(content.stepper_steps.all(), field="order", start=1)
            content.data["start"] = stp_opts.cleaned_data.get("start", 0) or 0
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        elif content.content_type == "DYN_RATING":
            content.data["rating"] = float(rt_opts.cleaned_data.get("rating", 4.0) or 4.0)
            content.data["count"] = int(rt_opts.cleaned_data.get("count", 0) or 0)
            content.data["max"] = int(rt_opts.cleaned_data.get("max", 5) or 5)
            content.data["editable"] = bool(rt_opts.cleaned_data.get("editable", False))
            content.data = _snapshot_for_content(content)
            content.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        else:
            payload = (form.cleaned_data.get("data_json") or form.cleaned_data.get("data") or None)
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except Exception:
                    payload = {"_raw": payload}
            content.data = payload or {}
            content.save()
            form.save()
            _save_style_and_sizes(bloc, bloc_ctx_forms)

        # --- CustomCSS : sauvegarde “propre” (avec purge si vide)
        if custom_css_form:
            cd = custom_css_form.cleaned_data
            has_css = any(
                (cd.get(k) or "").strip() for k in ("before", "current", "after", "hover", "custom", "object_classes"))
            cc = custom_css_form.save(commit=False)
            if cc.pk is None:
                cc.section, cc.line, cc.bloc = None, None, bloc
            if has_css:
                cc.save()
            else:
                try:
                    if cc.pk:
                        cc.delete()
                except Exception:
                    pass

        # --- Animations : même logique que CustomCSS (sauver si enabled, sinon purge)
        if animation_form:
            anim = animation_form.save(commit=False)
            # forcer la cible XOR
            anim.section, anim.line, anim.bloc = None, None, bloc
            try:
                if getattr(anim, "enabled", False):
                    anim.save()
                else:
                    # si une animation existe et que l’on la désactive → delete
                    try:
                        existing = bloc.animation
                        existing.delete()
                    except Exception:
                        pass
            except Exception:
                # fallback: ne bloque pas tout l’enregistrement si l’animation pose souci
                pass

        section_html = render_to_string(
            "administration_pages/partials/section.html",
            {"section": bloc.line.section},
            request=request
        )
        return JsonResponse({"status": "success", "section_html": section_html, "section_id": section.id})


@method_decorator(never_cache, name='dispatch')
class ResetContent(View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id, bloc_id):
        bloc = get_object_or_404(
            Bloc,
            id=bloc_id,
            line_id=line_id,
            line__section_id=section_id,
            line__section__page_id=page_id
        )

        if not hasattr(bloc, 'content') or not bloc.content:
            return JsonResponse({'status': 'no_content'}, status=400)

        content = bloc.content
        content_type = content.content_type

        if content_type == 'TEXT' and content.content_text:
            content.content_text.delete()
            content.content_text = None

        elif content_type == 'IMAGE' and content.content_image:
            if content.content_image.image_content:
                content.content_image.image_content.delete()
            content.content_image.delete()
            content.content_image = None

        elif content_type == 'BUTTON' and content.content_button:
            content.content_button.delete()
            content.content_button = None

        elif content_type == 'CALENDAR' and content.content_calendar:
            content.content_calendar.delete()
            content.content_calendar = None

        elif content_type == 'CHART' and content.content_chart:
            content.content_chart.delete()
            content.content_chart = None

        elif content_type == 'TEXT_QUESTIONNAIRE' and content.content_text_questionnaire:
            content.content_text_questionnaire.delete()
            content.content_text_questionnaire = None

        elif content_type == 'FORM' and content.content_formulaire:
            content.content_formulaire.delete()
            content.content_formulaire = None

        elif content_type == 'VIDEO' and getattr(content, "content_video", None):
            content.content_video.delete()
            content.content_video = None

        # dyn: on garde les relations (delete cascade si besoin), et on reset data
        elif content_type.startswith("DYN_"):
            content.data = {}
            # selon le besoin : supprimer aussi les items en cascade ici si nécessaire

        content.content_type = 'NOT_SET'
        content.save()

        cache.clear()
        section_html = render_to_string("administration_pages/partials/section.html", {"section": bloc.line.section},
                                        request=request)
        return JsonResponse({"status": "reset", "section_html": section_html})


@method_decorator(never_cache, name='dispatch')
class BlocCreate(View):
    """
    Ajout d’un bloc sous un bloc existant, dans la même colonne.
    - Params: page_id, section_id, line_id, bloc_id
    - Renvoie {"status": "success", "section_id":.., "section_html":..}
    """

    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        ref_bloc = get_object_or_404(Bloc, id=bloc_id, line=line)

        # même colonne
        position = ref_bloc.position

        # dernier bloc de cette colonne
        last = line.blocs.filter(position=position).order_by('-position_in_column').first()
        pos_in_col = (last.position_in_column + 1) if last else 0

        # helpers
        def _sb():
            return StyleBox.objects.create(top=0, right=0, bottom=0, left=0)

        def _size():
            return Size.objects.create(width="100%", height="")

        new_bloc = Bloc.objects.create(
            line=line,
            position=position,
            position_in_column=pos_in_col,
            margin_phone=_sb(), margin_tablet=_sb(), margin_laptop=_sb(), margin_computer=_sb(),
            padding_phone=_sb(), padding_tablet=_sb(), padding_laptop=_sb(), padding_computer=_sb(),
            size_phone=_size(), size_tablet=_size(), size_laptop=_size(), size_computer=_size(),
        )

        # rendu HTML complet de la section
        html = render_to_string(self.section_partial, {"section": section}, request=request)

        if self._is_ajax(request):
            return JsonResponse({
                "status": "success",
                "section_id": section.id,
                "section_html": html,
                "new_bloc_id": new_bloc.id,
            }, status=200)

        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)

@method_decorator(never_cache, name='dispatch')
class BlocDelete(View):
    """
    Suppression d'un bloc :
    - sur fetch AJAX : renvoie {"status":"success", "section_id":..., "section_html":...}
    - sinon : redirect vers page_editor
    """

    def post(self, request, page_id, section_id, line_id, bloc_id):
        line = get_object_or_404(Line, id=line_id, section_id=section_id, section__page_id=page_id)
        bloc = get_object_or_404(Bloc, id=bloc_id, line=line)

        # Vérif sécurité : ne jamais supprimer le dernier bloc
        same_column_count = Bloc.objects.filter(line_id=line_id, position=bloc.position).count()
        if same_column_count <= 1:
            return JsonResponse({
                "status": "error",
                "message": "Impossible de supprimer le dernier bloc de cette colonne."
            }, status=400)

        bloc.delete()
        cache.clear()

        section = line.section

        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            html = render_to_string(
                "administration_pages/partials/section.html",
                {"section": section},
                request=request
            )
            return JsonResponse({"status": "success", "section_id": section.id, "section_html": html})

        return redirect("jeiko_administration_pages:page_editor", page_id)


@method_decorator(never_cache, name='dispatch')
class BlocMoveUp(View):
    """Déplacement d’un bloc vers le haut (swap avec le précédent dans la colonne)."""

    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        bloc    = get_object_or_404(Bloc, id=bloc_id, line=line)

        if bloc.position_in_column > 0:
            above = line.blocs.filter(position=bloc.position, position_in_column=bloc.position_in_column - 1).first()
            if above:
                # swap
                above.position_in_column, bloc.position_in_column = bloc.position_in_column, above.position_in_column
                above.save(update_fields=['position_in_column'])
                bloc.save(update_fields=['position_in_column'])

        html = render_to_string(self.section_partial, {"section": section}, request=request)
        if self._is_ajax(request):
            return JsonResponse({"status": "success", "section_id": section.id, "section_html": html})
        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)


@method_decorator(never_cache, name='dispatch')
class BlocMoveDown(View):
    """Déplacement d’un bloc vers le bas (swap avec le suivant dans la colonne)."""

    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        bloc    = get_object_or_404(Bloc, id=bloc_id, line=line)

        below = line.blocs.filter(position=bloc.position, position_in_column=bloc.position_in_column + 1).first()
        if below:
            # swap
            below.position_in_column, bloc.position_in_column = bloc.position_in_column, below.position_in_column
            below.save(update_fields=['position_in_column'])
            bloc.save(update_fields=['position_in_column'])

        html = render_to_string(self.section_partial, {"section": section}, request=request)
        if self._is_ajax(request):
            return JsonResponse({"status": "success", "section_id": section.id, "section_html": html})
        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)


@method_decorator(never_cache, name='dispatch')
class BlocMoveLeft(View):
    """Déplacement d’un bloc vers la colonne de gauche."""

    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    def _create_empty_bloc(self, line, position):
        """Créer un bloc vide par sécurité (comme dans BlocCreate)."""
        def _sb():
            return StyleBox.objects.create(top=0, right=0, bottom=0, left=0)

        def _size():
            return Size.objects.create(width="100%", height="")

        return Bloc.objects.create(
            line=line,
            position=position,
            position_in_column=0,
            margin_phone=_sb(), margin_tablet=_sb(), margin_laptop=_sb(), margin_computer=_sb(),
            padding_phone=_sb(), padding_tablet=_sb(), padding_laptop=_sb(), padding_computer=_sb(),
            size_phone=_size(), size_tablet=_size(), size_laptop=_size(), size_computer=_size(),
        )

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        bloc    = get_object_or_404(Bloc, id=bloc_id, line=line)

        if bloc.position > 1:
            old_position = bloc.position
            new_position = bloc.position - 1

            # nouvelle colonne -> bloc à la fin
            last = line.blocs.filter(position=new_position).order_by('-position_in_column').first()
            bloc.position = new_position
            bloc.position_in_column = (last.position_in_column + 1) if last else 0
            bloc.save()

            # colonne d'origine -> réordonner
            remaining = line.blocs.filter(position=old_position).order_by('position_in_column')
            if not remaining.exists():
                self._create_empty_bloc(line, old_position)
            else:
                for idx, b in enumerate(remaining):
                    if b.position_in_column != idx:
                        b.position_in_column = idx
                        b.save(update_fields=['position_in_column'])

        html = render_to_string(self.section_partial, {"section": section}, request=request)
        if self._is_ajax(request):
            return JsonResponse({"status": "success", "section_id": section.id, "section_html": html})
        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)


@method_decorator(never_cache, name='dispatch')
class BlocMoveRight(View):
    """Déplacement d’un bloc vers la colonne de droite."""

    section_partial = 'administration_pages/partials/section.html'

    def _is_ajax(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    def _create_empty_bloc(self, line, position):
        """Créer un bloc vide par sécurité (comme dans BlocCreate)."""
        def _sb():
            return StyleBox.objects.create(top=0, right=0, bottom=0, left=0)

        def _size():
            return Size.objects.create(width="100%", height="")

        return Bloc.objects.create(
            line=line,
            position=position,
            position_in_column=0,
            margin_phone=_sb(), margin_tablet=_sb(), margin_laptop=_sb(), margin_computer=_sb(),
            padding_phone=_sb(), padding_tablet=_sb(), padding_laptop=_sb(), padding_computer=_sb(),
            size_phone=_size(), size_tablet=_size(), size_laptop=_size(), size_computer=_size(),
        )

    @transaction.atomic
    def post(self, request, page_id, section_id, line_id, bloc_id):
        page    = get_object_or_404(Page, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        line    = get_object_or_404(Line, id=line_id, section=section)
        bloc    = get_object_or_404(Bloc, id=bloc_id, line=line)

        if bloc.position < line.columns_number :
            old_position = bloc.position
            new_position = bloc.position + 1

            # nouvelle colonne -> bloc à la fin
            last = line.blocs.filter(position=new_position).order_by('-position_in_column').first()
            bloc.position = new_position
            bloc.position_in_column = (last.position_in_column + 1) if last else 0
            bloc.save()

            # colonne d'origine -> réordonner
            remaining = line.blocs.filter(position=old_position).order_by('position_in_column')
            if not remaining.exists():
                self._create_empty_bloc(line, old_position)
            else:
                for idx, b in enumerate(remaining):
                    if b.position_in_column != idx:
                        b.position_in_column = idx
                        b.save(update_fields=['position_in_column'])

        html = render_to_string(self.section_partial, {"section": section}, request=request)
        if self._is_ajax(request):
            return JsonResponse({"status": "success", "section_id": section.id, "section_html": html})
        return redirect('jeiko_administration_pages:page_editor', page_id=page.id)
