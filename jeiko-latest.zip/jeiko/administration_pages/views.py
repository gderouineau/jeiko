from django.contrib.auth.decorators import permission_required
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.core.cache import cache
from django.http import Http404, JsonResponse, HttpResponse
from django.shortcuts import render, redirect, get_object_or_404, reverse

from django.views import View
from django.views.generic.base import TemplateView
from django.views.generic.edit import DeleteView
from django.template.loader import render_to_string
from django.views import View
from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages
from django.db import transaction
from django.utils.text import slugify
import datetime
from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache
from django.views.decorators.clickjacking import xframe_options_exempt
from django.views.decorators.http import require_GET
from jeiko.administration_pages.forms import (
    PageForm, MetadataForm, SectionForm, LineForm, MarginForm, PaddingForm,
    ImageForm, TextForm, CSSParametersForm, ContentImageForm, MainCategoryForm, SubCategoryForm, MainCategoryFormPage,
    SubCategoryFormPage, StyleBoxForm, SizeForm, BlocSizeForm, ButtonContentForm, ContentCalendarForm, BackgroundImageForm,
    BackgroundImageParametersForm
    )
from jeiko.administration_pages.models import (
    Page, Metadata,
    Section, Line, Margin, Padding, Size, ImageContent, Bloc,
    Content, ContentImage, ContentText, CSSParameters, Category, ContentButton, ContentCalendar, ContentFormulaire,
    ContentChartQuestionnaire, BackgroundImageParameters
)

from django.db.models import Count
from jeiko.administration_pages.models import StyleBox
decorators = [never_cache]

from .mixins import AsyncRequestMixin

class Main(View):
    template_name = 'administration_pages/main.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        pages = Page.objects.all()
        main_categories = Category.objects.filter(main_category__isnull=True)
        context = {
            'pages': pages,
            'main_categories': main_categories,
        }

        return render(request, self.template_name, context)


    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        pages = Page.objects.all()
        main_categories = Category.objects.filter(main_category__isnull=True)
        context = {
            'pages': pages,
            'main_categories': main_categories,
        }

        return render(request, self.template_name, context)


class SeePage(View):
    template_name = 'administration_pages/view.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_id = kwargs['page_id']

        page = get_object_or_404(
            Page,
            id=page_id,

        )

        context = {
            'page': page,
        }

        return render(request, self.template_name, context)


class PageAdd(View):
    template_name = 'administration_pages/add_or_update.html'

    page_form = PageForm
    metadata_form = MetadataForm
    main_category_form = MainCategoryFormPage
    sub_category_form = SubCategoryFormPage

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_form = self.page_form(prefix='page_')
        metadata_form = self.metadata_form(prefix='metadata_')
        main_category_form = self.main_category_form(prefix='main_category_')
        sub_category_form = self.sub_category_form(prefix='sub_category_')
        main_category_id = main_category_form.initial.get('name') if main_category_form.initial else ''
        sub_category_id = sub_category_form.initial.get('name') if sub_category_form.initial else ''
        context = {
            'update': False,
            'submit_text': "Créer",
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id,
            'sub_category_id': sub_category_id,
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page_form = self.page_form(request.POST, prefix='page_')
        metadata_form = self.metadata_form(request.POST, prefix='metadata_')
        main_category_form = self.main_category_form(prefix='main_category_')
        sub_category_form = self.sub_category_form(prefix='sub_category_')

        # Récupère l’id des catégories via le POST
        main_category_id = request.POST.get("main_category") or None
        sub_category_id = request.POST.get("sub_category") or None

        main_category = Category.objects.filter(id=main_category_id).first() if main_category_id else None
        sub_category = Category.objects.filter(id=sub_category_id).first() if sub_category_id else None

        if page_form.is_valid() and metadata_form.is_valid():
            page = page_form.save(commit=False)
            page.category = main_category
            page.sub_category = sub_category
            page.save()

            metadata = metadata_form.save(commit=False)
            metadata.page = page
            metadata.save()

            cache.clear()
            return redirect('jeiko_administration_pages:main')

        # Les id sont renvoyés à Alpine pour conserver l’état du select si erreur
        context = {
            'update': False,
            'submit_text': "Créer",
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id or '',
            'sub_category_id': sub_category_id or '',
        }
        return render(request, self.template_name, context)


class PageUpdate(View):
    template_name = 'administration_pages/add_or_update.html'
    page_form = PageForm
    metadata_form = MetadataForm
    main_category_form = MainCategoryFormPage
    sub_category_form = SubCategoryFormPage

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_id = kwargs['page_id']
        page = get_object_or_404(Page, id=page_id)
        page_form = self.page_form(instance=page, prefix='page_')
        metadata, _ = Metadata.objects.get_or_create(page=page)
        metadata_form = self.metadata_form(instance=metadata, prefix='metadata_')
        main_category_form = self.main_category_form(
            initial={'name': page.category_id} if page.category_id else None,
            prefix='main_category_'
        )
        sub_category_form = self.sub_category_form(
            initial={'name': page.sub_category_id} if page.sub_category_id else None,
            prefix='sub_category_'
        )
        main_category_id = str(page.category_id) if page.category_id else ''
        sub_category_id = str(page.sub_category_id) if page.sub_category_id else ''
        context = {
            'update': True,
            'submit_text': "Modifier",
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id,
            'sub_category_id': sub_category_id,
            'page': page,
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page_id = kwargs['page_id']
        page = get_object_or_404(Page, id=page_id)
        page_form = self.page_form(request.POST, instance=page, prefix='page_')
        metadata = get_object_or_404(Metadata, page=page)
        metadata_form = self.metadata_form(request.POST, instance=metadata, prefix='metadata_')
        main_category_form = self.main_category_form(prefix='main_category_')
        sub_category_form = self.sub_category_form(prefix='sub_category_')

        # Récupère l’id des catégories via le POST
        main_category_id = request.POST.get("main_category") or None
        sub_category_id = request.POST.get("sub_category") or None

        main_category = Category.objects.filter(id=main_category_id).first() if main_category_id else None
        sub_category = Category.objects.filter(id=sub_category_id).first() if sub_category_id else None

        if page_form.is_valid() and metadata_form.is_valid():
            page = page_form.save(commit=False)
            page.category = main_category
            page.sub_category = sub_category
            page.save()

            metadata = metadata_form.save(commit=False)
            metadata.page = page
            metadata.save()

            cache.clear()
            return redirect('jeiko_administration_pages:main')

        context = {
            'update': True,
            'submit_text': "Modifier",
            'page_form': page_form,
            'metadata_form': metadata_form,
            'main_category_form': main_category_form,
            'sub_category_form': sub_category_form,
            'main_category_id': main_category_id or '',
            'sub_category_id': sub_category_id or '',
            'page': page,
        }
        return render(request, self.template_name, context)


def make_unique_url_tag(base_tag):
    """Génère un url_tag unique à partir du tag original."""
    timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
    return f"{base_tag}_copy_{timestamp}"


def duplicate_instance(obj, omit_fields=None, overrides=None):
    """Clone une instance Django, sans les relations FK, avec possibilité d’overrides."""
    omit_fields = omit_fields or []
    overrides = overrides or {}
    data = {}
    for field in obj._meta.fields:
        if field.name in omit_fields or field.auto_created:
            continue
        data[field.name] = getattr(obj, field.name)
    data.update(overrides)
    return obj.__class__.objects.create(**data)


class DuplicatePageView(View):
    """
    POST : duplique une page complète, puis redirige vers la nouvelle page.
    """
    def get(self, request, page_id):
        if not request.user.is_staff:
            messages.error(request, "Non autorisé")
            return redirect('jeiko_administration_pages:main')

        with transaction.atomic():
            # 1. Page d'origine
            page = get_object_or_404(Page, id=page_id)

            # 2. Nouveau titre + url_tag unique
            new_title = f"{page.title} (copie)"
            new_url_tag = make_unique_url_tag(page.url_tag)

            # 3. Dupliquer la page
            page_copy = duplicate_instance(
                page,
                omit_fields=['id', 'pk'],
                overrides={
                    'title': new_title,
                    'url_tag': new_url_tag,
                    'active': False,
                    'is_root': False,
                }
            )

            # 4. Copier la metadata si présente
            if hasattr(page, 'metadata') and page.metadata:
                metadata = page.metadata
                duplicate_instance(
                    metadata,
                    omit_fields=['id', 'pk', 'page'],
                    overrides={'page': page_copy}
                )

            # --- (Suit la duplication complète comme dans le message précédent) ---
            # Mapping pour les FK
            section_map, line_map, bloc_map, content_map = {}, {}, {}, {}
            stylebox_map, size_map, imagecontent_map = {}, {}, {}

            def duplicate_stylable(obj):
                if obj is None:
                    return None
                if isinstance(obj, StyleBox):
                    if obj.pk in stylebox_map:
                        return stylebox_map[obj.pk]
                    copy = duplicate_instance(obj, omit_fields=['id', 'pk'])
                    stylebox_map[obj.pk] = copy
                    return copy
                elif isinstance(obj, Size):
                    if obj.pk in size_map:
                        return size_map[obj.pk]
                    copy = duplicate_instance(obj, omit_fields=['id', 'pk'])
                    size_map[obj.pk] = copy
                    return copy
                return obj

            def duplicate_imagecontent(obj):
                if obj is None:
                    return None
                if obj.pk in imagecontent_map:
                    return imagecontent_map[obj.pk]
                copy = duplicate_instance(obj, omit_fields=['id', 'pk'])
                imagecontent_map[obj.pk] = copy
                return copy

            # Duplique toutes les sections
            for section in page.sections.all():
                # Duplique marges/paddings/sizes/bg
                margin_phone = duplicate_stylable(section.margin_phone)
                margin_tablet = duplicate_stylable(section.margin_tablet)
                margin_computer = duplicate_stylable(section.margin_computer)
                padding_phone = duplicate_stylable(section.padding_phone)
                padding_tablet = duplicate_stylable(section.padding_tablet)
                padding_computer = duplicate_stylable(section.padding_computer)
                size_phone = duplicate_stylable(section.size_phone)
                size_tablet = duplicate_stylable(section.size_tablet)
                size_computer = duplicate_stylable(section.size_computer)
                background_image = duplicate_imagecontent(section.background_image)

                section_copy = duplicate_instance(
                    section,
                    omit_fields=[
                        'id', 'pk', 'page', 'lines', 'background_image',
                        'margin_phone', 'margin_tablet', 'margin_computer',
                        'padding_phone', 'padding_tablet', 'padding_computer',
                        'size_phone', 'size_tablet', 'size_computer'
                    ],
                    overrides={
                        'page': page_copy,
                        'margin_phone': margin_phone,
                        'margin_tablet': margin_tablet,
                        'margin_computer': margin_computer,
                        'padding_phone': padding_phone,
                        'padding_tablet': padding_tablet,
                        'padding_computer': padding_computer,
                        'size_phone': size_phone,
                        'size_tablet': size_tablet,
                        'size_computer': size_computer,
                        'background_image': background_image,
                    }
                )
                section_map[section.pk] = section_copy

                # Lignes
                for line in section.lines.all():
                    margin_phone = duplicate_stylable(line.margin_phone)
                    margin_tablet = duplicate_stylable(line.margin_tablet)
                    margin_computer = duplicate_stylable(line.margin_computer)
                    padding_phone = duplicate_stylable(line.padding_phone)
                    padding_tablet = duplicate_stylable(line.padding_tablet)
                    padding_computer = duplicate_stylable(line.padding_computer)
                    size_phone = duplicate_stylable(line.size_phone)
                    size_tablet = duplicate_stylable(line.size_tablet)
                    size_computer = duplicate_stylable(line.size_computer)
                    background_image = duplicate_imagecontent(line.background_image)

                    line_copy = duplicate_instance(
                        line,
                        omit_fields=[
                            'id', 'pk', 'section', 'blocs', 'background_image',
                            'margin_phone', 'margin_tablet', 'margin_computer',
                            'padding_phone', 'padding_tablet', 'padding_computer',
                            'size_phone', 'size_tablet', 'size_computer'
                        ],
                        overrides={
                            'section': section_copy,
                            'margin_phone': margin_phone,
                            'margin_tablet': margin_tablet,
                            'margin_computer': margin_computer,
                            'padding_phone': padding_phone,
                            'padding_tablet': padding_tablet,
                            'padding_computer': padding_computer,
                            'size_phone': size_phone,
                            'size_tablet': size_tablet,
                            'size_computer': size_computer,
                            'background_image': background_image,
                        }
                    )
                    line_map[line.pk] = line_copy

                    # Blocs
                    for bloc in line.blocs.all():
                        margin_phone = duplicate_stylable(bloc.margin_phone)
                        margin_tablet = duplicate_stylable(bloc.margin_tablet)
                        margin_computer = duplicate_stylable(bloc.margin_computer)
                        padding_phone = duplicate_stylable(bloc.padding_phone)
                        padding_tablet = duplicate_stylable(bloc.padding_tablet)
                        padding_computer = duplicate_stylable(bloc.padding_computer)
                        size_phone = duplicate_stylable(bloc.size_phone)
                        size_tablet = duplicate_stylable(bloc.size_tablet)
                        size_computer = duplicate_stylable(bloc.size_computer)
                        background_image = duplicate_imagecontent(bloc.background_image)

                        bloc_copy = duplicate_instance(
                            bloc,
                            omit_fields=[
                                'id', 'pk', 'line', 'content', 'background_image',
                                'margin_phone', 'margin_tablet', 'margin_computer',
                                'padding_phone', 'padding_tablet', 'padding_computer',
                                'size_phone', 'size_tablet', 'size_computer'
                            ],
                            overrides={
                                'line': line_copy,
                                'margin_phone': margin_phone,
                                'margin_tablet': margin_tablet,
                                'margin_computer': margin_computer,
                                'padding_phone': padding_phone,
                                'padding_tablet': padding_tablet,
                                'padding_computer': padding_computer,
                                'size_phone': size_phone,
                                'size_tablet': size_tablet,
                                'size_computer': size_computer,
                                'background_image': background_image,
                            }
                        )
                        bloc_map[bloc.pk] = bloc_copy

                        # Content
                        if hasattr(bloc, 'content') and bloc.content:
                            content = bloc.content
                            content_copy = duplicate_instance(
                                content,
                                omit_fields=[
                                    'id', 'pk', 'bloc',
                                    'content_text', 'content_image', 'content_text_questionnaire',
                                    'content_chart', 'content_button', 'content_calendar'
                                ],
                                overrides={'bloc': bloc_copy}
                            )
                            content_map[content.pk] = content_copy

                            # Spécifique selon le type
                            if content.content_type == "TEXT" and content.content_text:
                                text_copy = duplicate_instance(content.content_text, omit_fields=['id', 'pk'])
                                content_copy.content_text = text_copy
                            elif content.content_type == "IMAGE" and content.content_image:
                                image_content = content.content_image.image_content
                                image_content_copy = duplicate_imagecontent(image_content)
                                content_image_copy = duplicate_instance(
                                    content.content_image,
                                    omit_fields=['id', 'pk', 'image_content'],
                                    overrides={'image_content': image_content_copy}
                                )
                                content_copy.content_image = content_image_copy
                            elif content.content_type == "BUTTON" and content.content_button:
                                button_copy = duplicate_instance(content.content_button, omit_fields=['id', 'pk'])
                                content_copy.content_button = button_copy
                            elif content.content_type == "CHART" and content.content_chart:
                                chart_copy = duplicate_instance(content.content_chart, omit_fields=['id', 'pk'])
                                content_copy.content_chart = chart_copy
                            elif content.content_type == "TEXT_QUESTIONNAIRE" and content.content_text_questionnaire:
                                tq_copy = duplicate_instance(content.content_text_questionnaire, omit_fields=['id', 'pk'])
                                content_copy.content_text_questionnaire = tq_copy
                            elif content.content_type == "CALENDAR" and content.content_calendar:
                                cal_copy = duplicate_instance(content.content_calendar, omit_fields=['id', 'pk'])
                                content_copy.content_calendar = cal_copy
                            content_copy.save()

                            # CSSParameters
                            for css_param in content.CSS_parameters.all():
                                duplicate_instance(
                                    css_param,
                                    omit_fields=['id', 'pk', 'content'],
                                    overrides={'content': content_copy}
                                )

        messages.success(request, f"La page a été dupliquée : {page_copy.title}")
        # Redirige vers l’édition de la nouvelle page (ou ce que tu veux)
        return redirect('jeiko_administration_pages:main')


class Categories(View):

    template_name = 'administration_pages/category/list.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        categories = Category.objects.filter(
            main_category=None,
        )

        return render(
            request,
            self.template_name,
            context={
                'categories': categories,
            }
        )

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        categories = Category.objects.all()

        return render(
            request,
            self.template_name,
            context={
                'categories': categories,
            }
        )


class CategoryAdd(View):

    template_name = 'administration_pages/category/add_or_update.html'

    main_category_form = MainCategoryForm
    sub_category_form = SubCategoryForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        if 'main_category_id' in kwargs:
            main_category = get_object_or_404(
                Category,
                id=kwargs['main_category_id']
            )
            category_form = self.sub_category_form(
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'category_form': category_form,
                }
            )
        else:
            category_form = self.main_category_form(
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'category_form': category_form,
                }
            )


    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        if 'main_category_id' in kwargs:
            main_category = get_object_or_404(
                Category,
                id=kwargs['main_category_id']
            )
            category_form = self.sub_category_form(
                request.POST,
                prefix='category_',
            )
            if category_form.is_valid():

                category = category_form.save(commit=False)
                category.main_category = main_category
                category.save()

                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'category_form': category_form,
                }
            )
        else:
            category_form = self.main_category_form(
                request.POST,
                prefix='category_',
            )
            if category_form.is_valid():
                category_form.save()
                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={

                    'category_form': category_form,
                }
            )


class CategoryUpdate(View):
    template_name = 'administration_pages/category/add_or_update.html'

    main_category_form = MainCategoryForm
    sub_category_form = SubCategoryForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        main_category = get_object_or_404(
            Category,
            id=kwargs['main_category_id']
        )

        if 'sub_category_id' in kwargs:

            sub_category = get_object_or_404(
                Category,
                id=kwargs['sub_category_id']
            )
            category_form = self.sub_category_form(
                instance=sub_category,
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'sub_category': sub_category,
                    'category_form': category_form,
                    'update': True,
                }
            )
        else:
            category_form = self.main_category_form(
                instance=main_category,
                prefix='category_',
            )
            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'category_form': category_form,
                    'update': True,
                }
            )

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        main_category = get_object_or_404(
            Category,
            id=kwargs['main_category_id']
        )

        if 'sub_category_id' in kwargs:

            sub_category = get_object_or_404(
                Category,
                id=kwargs['sub_category_id'],
            )
            category_form = self.sub_category_form(
                request.POST,
                instance=sub_category,
                prefix='category_',
            )
            if category_form.is_valid():
                category = category_form.save(commit=False)
                category.main_category = main_category
                category.save()

                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={
                    'main_category': main_category,
                    'sub_category': sub_category,
                    'category_form': category_form,
                    'update': True,
                }
            )
        else:
            main_category_form = self.main_category_form(
                request.POST,
                instance=main_category,
                prefix='category_',
            )
            if main_category_form.is_valid():
                main_category_form.save()
                return redirect('jeiko_administration_pages:categories')

            return render(
                request,
                self.template_name,
                context={
                    'category_form': main_category_form,
                    'main_category': main_category,
                    'update': True,
                }
            )


class PageEditor(View):
    template_name = 'administration_pages/editor.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page_id = kwargs['page_id']

        page = get_object_or_404(
            Page,
            id=page_id
        )

        context = {
            'page': page,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page = get_object_or_404(
            Page,
            id=kwargs['page_id']
        )

        context = {
            'page': page,
        }
        cache.clear()
        return render(request, self.template_name, context)


class PageDelete(View):
    template_name = 'administration_pages/delete.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        page = get_object_or_404(
            Page,
            id=kwargs['page_id']
        )


        context = {
            'page': page,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        page = get_object_or_404(
            Page,
            id=kwargs['page_id']
        )


        if page.delete():
            cache.clear()
            return redirect('jeiko_administration_pages:main')

        context = {
            'page': page,
            'message': 'Un problème est survenu'
        }

        return render(request, self.template_name, context)


def get_section_forms_context(page, data=None, files=None, instance=None):
    section_form = SectionForm(data=data, files=files, instance=instance)
    style_forms = [
        StyleBoxForm(data=data, prefix="margin_phone", instance=getattr(instance, 'margin_phone', None)),
        StyleBoxForm(data=data, prefix="margin_tablet", instance=getattr(instance, 'margin_tablet', None)),
        StyleBoxForm(data=data, prefix="margin_computer", instance=getattr(instance, 'margin_computer', None)),
        StyleBoxForm(data=data, prefix="padding_phone", instance=getattr(instance, 'padding_phone', None)),
        StyleBoxForm(data=data, prefix="padding_tablet", instance=getattr(instance, 'padding_tablet', None)),
        StyleBoxForm(data=data, prefix="padding_computer", instance=getattr(instance, 'padding_computer', None)),
    ]
    # Gestion des tailles (Size)
    size_forms = [
        SizeForm(data=data, instance=getattr(instance, "size_phone", None), prefix="size_phone_"),
        SizeForm(data=data, instance=getattr(instance, "size_tablet", None), prefix="size_tablet_"),
        SizeForm(data=data, instance=getattr(instance, "size_computer", None), prefix="size_computer_"),
    ]
    # Gestion du background image
    bgimg_instance = getattr(instance, 'background_image', None) if instance else None
    background_image_form = BackgroundImageForm(
        data=data,
        files=files,
        instance=bgimg_instance,
        prefix="background_image_"
    )
    bgimg_params_instance = getattr(instance, 'background_image_parameters', None) if instance else None
    background_image_parameters_form = BackgroundImageParametersForm(
        data=data,
        instance=bgimg_params_instance,
        prefix="bgimg_params_"
    )
    return {
        "page": page,
        "section_form": section_form,
        "style_forms": style_forms,
        "size_forms": size_forms,
        "background_image_form": background_image_form,
        "background_image_parameters_form": background_image_parameters_form,
        "margin_phone_form": style_forms[0],
        "margin_tablet_form": style_forms[1],
        "margin_computer_form": style_forms[2],
        "padding_phone_form": style_forms[3],
        "padding_tablet_form": style_forms[4],
        "padding_computer_form": style_forms[5],
        "size_phone_form": size_forms[0],
        "size_tablet_form": size_forms[1],
        "size_computer_form": size_forms[2],
    }

@method_decorator(never_cache, name='dispatch')
class SectionCreate(View, AsyncRequestMixin):
    template_name = 'administration_pages/section/form.html'

    @method_decorator(never_cache)
    def get(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        ctx = get_section_forms_context(page)
        ctx.update({
            'form_action': reverse('jeiko_administration_pages:section_add', args=[page_id]),
            'submit_text': 'Créer la section',
        })
        return render(request, self.template_name, ctx)

    @method_decorator(never_cache)
    def post(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        ctx = get_section_forms_context(page, request.POST, request.FILES)
        form = ctx['section_form']
        styles = ctx['style_forms']
        size_forms = ctx['size_forms']
        background_image_form = ctx['background_image_form']
        background_image_parameters_form = ctx['background_image_parameters_form']

        ctx.update({
            'form_action': reverse('jeiko_administration_pages:section_add', args=[page_id]),
            'submit_text': 'Créer la section',
        })

        if (
            form.is_valid()
            and all(f.is_valid() for f in styles)
            and all(f.is_valid() for f in size_forms)
            and background_image_form.is_valid()
            and background_image_parameters_form.is_valid()
        ):
            # Sauvegarde des StyleBox et Size
            margins = [f.save() for f in styles[:3]]
            paddings = [f.save() for f in styles[3:]]
            sizes = [f.save() for f in size_forms]
            # Background image & paramètres
            bgimg = background_image_form.save()
            bgimg_params = background_image_parameters_form.save()

            # Création de la section
            section = form.save(commit=False)
            section.page = page
            (section.margin_phone, section.margin_tablet, section.margin_computer) = margins
            (section.padding_phone, section.padding_tablet, section.padding_computer) = paddings
            (section.size_phone, section.size_tablet, section.size_computer) = sizes
            section.background_image = bgimg
            section.background_image_parameters = bgimg_params
            last = Section.objects.filter(page=page).order_by('-position').first()
            section.position = (last.position + 1) if last else 0
            section.save()

            if self.is_fetch(request):
                html = render_to_string(
                    'administration_pages/partials/section.html',
                    {'section': section},
                    request=request
                )
                return self.render_json(content_html=html, status=200, section_id=section.id)

            return redirect('jeiko_administration_pages:page_editor', page_id)

        # Form invalide
        if self.is_fetch(request):
            html = render_to_string(self.template_name, ctx, request=request)
            return HttpResponse(html, status=400)
        return render(request, self.template_name, ctx)


@method_decorator(never_cache, name='dispatch')
class SectionUpdate(View, AsyncRequestMixin):
    template_name = 'administration_pages/section/form.html'

    @method_decorator(never_cache)
    def get(self, request, page_id, section_id):
        page    = get_object_or_404(Page, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        ctx = get_section_forms_context(page, instance=section)
        ctx.update({
            'form_action': reverse('jeiko_administration_pages:section_update', args=[page_id, section_id]),
            'submit_text': 'Mettre à jour la section',
        })
        return render(request, self.template_name, ctx)

    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        page    = get_object_or_404(Page, id=page_id)
        section = get_object_or_404(Section, id=section_id, page=page)
        ctx = get_section_forms_context(page, request.POST, request.FILES, instance=section)
        form = ctx['section_form']
        styles = ctx['style_forms']
        size_forms = ctx['size_forms']
        background_image_form = ctx['background_image_form']
        background_image_parameters_form = ctx['background_image_parameters_form']

        ctx.update({
            'form_action': reverse('jeiko_administration_pages:section_update', args=[page_id, section_id]),
            'submit_text': 'Mettre à jour la section',
        })

        if (
            form.is_valid()
            and all(f.is_valid() for f in styles)
            and all(f.is_valid() for f in size_forms)
            and background_image_form.is_valid()
            and background_image_parameters_form.is_valid()
        ):
            margins  = [f.save() for f in styles[:3]]
            paddings = [f.save() for f in styles[3:]]
            sizes    = [f.save() for f in size_forms]
            bgimg = background_image_form.save()
            bgimg_params = background_image_parameters_form.save()

            section = form.save(commit=False)
            (section.margin_phone, section.margin_tablet, section.margin_computer) = margins
            (section.padding_phone, section.padding_tablet, section.padding_computer) = paddings
            (section.size_phone, section.size_tablet, section.size_computer) = sizes
            section.background_image = bgimg
            section.background_image_parameters = bgimg_params
            section.save()

            if self.is_fetch(request):
                html = render_to_string(
                    'administration_pages/partials/section.html',
                    {'section': section},
                    request=request
                )
                return self.render_json(content_html=html, status=200, section_id=section.id)

            return redirect('jeiko_administration_pages:page_editor', page_id)

        if self.is_fetch(request):
            html = render_to_string(self.template_name, ctx, request=request)
            return HttpResponse(html, status=400)
        return render(request, self.template_name, ctx)


@method_decorator(never_cache, name='dispatch')
class SectionDelete(View, AsyncRequestMixin):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        style_ids = [
            section.margin_phone_id,
            section.margin_tablet_id,
            section.margin_computer_id,
            section.padding_phone_id,
            section.padding_tablet_id,
            section.padding_computer_id,
        ]
        section.delete()
        StyleBox.objects.filter(id__in=style_ids).delete()

        if self.is_fetch(request):
            return self.render_json(status=200, section_id=section_id)
        return redirect('jeiko_administration_pages:page_editor', page_id)


@method_decorator(never_cache, name='dispatch')
class SectionMoveUp(View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        prev_sec = (
            Section.objects
            .filter(page=section.page, position__lt=section.position)
            .order_by('-position')
            .first()
        )
        if prev_sec:
            # swap
            section.position, prev_sec.position = prev_sec.position, section.position
            section.save()
            prev_sec.save()
        cache.clear()
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"status": "success"})
        return redirect('jeiko_administration_pages:page_editor', page_id)


@method_decorator(never_cache, name='dispatch')
class SectionMoveDown(View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        next_sec = (
            Section.objects
            .filter(page=section.page, position__gt=section.position)
            .order_by('position')
            .first()
        )
        if next_sec:
            section.position, next_sec.position = next_sec.position, section.position
            section.save()
            next_sec.save()
        cache.clear()
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"status": "success"})
        return redirect('jeiko_administration_pages:page_editor', page_id)


def get_line_forms_context(section, data=None, instance=None, files=None):
    # Prépare les instances si on modifie une ligne existante
    if instance:
        style_instances = [
            instance.margin_phone, instance.margin_tablet, instance.margin_computer,
            instance.padding_phone, instance.padding_tablet, instance.padding_computer,
        ]
        size_instances = [
            instance.size_phone, instance.size_tablet, instance.size_computer,
        ]
        bgimg_instance = instance.background_image
        bgimg_params_instance = getattr(instance, 'background_image_parameters', None)
    else:
        style_instances = [None] * 6
        size_instances = [None] * 3
        bgimg_instance = None
        bgimg_params_instance = None

    return {
        "page": section.page,
        "section": section,
        "line_form": LineForm(data=data, instance=instance, prefix="line_"),
        "style_forms": [
            StyleBoxForm(data=data, instance=style_instances[0], prefix="margin_phone_"),
            StyleBoxForm(data=data, instance=style_instances[1], prefix="margin_tablet_"),
            StyleBoxForm(data=data, instance=style_instances[2], prefix="margin_computer_"),
            StyleBoxForm(data=data, instance=style_instances[3], prefix="padding_phone_"),
            StyleBoxForm(data=data, instance=style_instances[4], prefix="padding_tablet_"),
            StyleBoxForm(data=data, instance=style_instances[5], prefix="padding_computer_"),
        ],
        "size_forms": [
            SizeForm(data=data, instance=size_instances[0], prefix="size_phone_"),
            SizeForm(data=data, instance=size_instances[1], prefix="size_tablet_"),
            SizeForm(data=data, instance=size_instances[2], prefix="size_computer_"),
        ],
        "background_image_form": BackgroundImageForm(
            data=data, files=files, instance=bgimg_instance, prefix="background_image_"
        ),
        "background_image_parameters_form": BackgroundImageParametersForm(
            data=data, instance=bgimg_params_instance, prefix="bgimg_params_"
        ),
    }


@method_decorator(never_cache, name='dispatch')
class LineCreate(View):
    """
    Création d'une ligne :
    - sur fetch AJAX : renvoie {"status":"success","line_id":..,"line_html":..}
    - sinon : redirect vers page_editor
    """
    def get(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        context = get_line_forms_context(section)
        context.update({
            "form_action": reverse("jeiko_administration_pages:line_add", args=[page_id, section_id]),
            "submit_text": "Créer la ligne",
        })
        return render(request, "administration_pages/line/form.html", context)

    def post(self, request, page_id, section_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        context = get_line_forms_context(section, request.POST, files=request.FILES)
        line_form = context["line_form"]
        style_forms = context["style_forms"]
        size_forms = context["size_forms"]
        background_image_form = context["background_image_form"]
        background_image_parameters_form = context["background_image_parameters_form"]

        if (
            line_form.is_valid()
            and all(f.is_valid() for f in style_forms)
            and all(f.is_valid() for f in size_forms)
            and background_image_form.is_valid()
            and background_image_parameters_form.is_valid()
        ):
            # 1) Crée la ligne sans sauvegarder
            line = line_form.save(commit=False)
            line.section = section
            line.columns_number = len(line.columns_type.split('-')) if line.columns_type else 1

            # 2) Enregistre styles
            style_instances = [f.save() for f in style_forms]
            (
                line.margin_phone, line.margin_tablet, line.margin_computer,
                line.padding_phone, line.padding_tablet, line.padding_computer
            ) = style_instances

            # 3) Enregistre sizes
            size_instances = [f.save() for f in size_forms]
            (
                line.size_phone, line.size_tablet, line.size_computer
            ) = size_instances

            # 4) Enregistre image de fond et paramètres associés
            bgimg = background_image_form.save()
            bgimg_params = background_image_parameters_form.save()
            line.background_image = bgimg
            line.background_image_parameters = bgimg_params

            # 5) Position dans la section
            last = section.lines.order_by("-position").first()
            line.position = (last.position + 1) if last else 0
            line.save()

            # 6) Crée 6 blocs par défaut (ne pas supprimer/modifier)
            for pos in range(1, 7):
                Bloc.objects.create(
                    line=line,
                    position=pos,
                    margin_phone=StyleBox.objects.create(),
                    margin_tablet=StyleBox.objects.create(),
                    margin_computer=StyleBox.objects.create(),
                    padding_phone=StyleBox.objects.create(),
                    padding_tablet=StyleBox.objects.create(),
                    padding_computer=StyleBox.objects.create(),
                )

            cache.clear()

            # AJAX / fetch
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                html = render_to_string(
                    "administration_pages/partials/line.html",
                    {"line": line},
                    request=request
                )
                return JsonResponse({
                    "status": "success",
                    "line_id": line.id,
                    "line_html": html,
                })

            return redirect("jeiko_administration_pages:page_editor", page_id)

        # Formulaire invalide
        context.update({
            "form_action": reverse("jeiko_administration_pages:line_add", args=[page_id, section_id]),
            "submit_text": "Créer la ligne",
        })
        return render(request, "administration_pages/line/form.html", context)


@method_decorator(never_cache, name='dispatch')
class LineUpdate(View):
    """
    Mise à jour d'une ligne :
    - sur fetch AJAX : renvoie {"status":"success","line_id":..,"line_html":..}
    - sinon : redirect vers page_editor
    """
    def get(self, request, page_id, section_id, line_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        line = get_object_or_404(Line, id=line_id, section=section)
        context = get_line_forms_context(section, instance=line)
        context.update({
            "form_action": reverse("jeiko_administration_pages:line_update", args=[page_id, section_id, line_id]),
            "submit_text": "Modifier la ligne",
            "update": True,
            "line": line,
        })
        return render(request, "administration_pages/line/form.html", context)

    def post(self, request, page_id, section_id, line_id):
        section = get_object_or_404(Section, id=section_id, page_id=page_id)
        line = get_object_or_404(Line, id=line_id, section=section)
        context = get_line_forms_context(section, data=request.POST, instance=line, files=request.FILES)
        line_form = context["line_form"]
        style_forms = context["style_forms"]
        size_forms = context["size_forms"]
        background_image_form = context["background_image_form"]
        background_image_parameters_form = context["background_image_parameters_form"]

        if (
            line_form.is_valid()
            and all(f.is_valid() for f in style_forms)
            and all(f.is_valid() for f in size_forms)
            and background_image_form.is_valid()
            and background_image_parameters_form.is_valid()
        ):
            # update des champs
            line = line_form.save(commit=False)
            line.columns_number = len(line.columns_type.split('-')) if line.columns_type else 1

            # update des StyleBox
            style_instances = [f.save() for f in style_forms]
            (
                line.margin_phone, line.margin_tablet, line.margin_computer,
                line.padding_phone, line.padding_tablet, line.padding_computer
            ) = style_instances

            # update des tailles
            size_instances = [f.save() for f in size_forms]
            (
                line.size_phone, line.size_tablet, line.size_computer
            ) = size_instances

            # update image de fond et paramètres associés
            bgimg = background_image_form.save()
            bgimg_params = background_image_parameters_form.save()
            line.background_image = bgimg
            line.background_image_parameters = bgimg_params

            line.save()
            cache.clear()

            # AJAX / fetch
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                html = render_to_string(
                    "administration_pages/partials/line.html",
                    {"line": line},
                    request=request
                )
                return JsonResponse({
                    "status": "success",
                    "line_id": line.id,
                    "line_html": html,
                })

            return redirect("jeiko_administration_pages:page_editor", page_id)

        # form invalide
        context.update({
            "form_action": reverse("jeiko_administration_pages:line_update", args=[page_id, section_id, line_id]),
            "submit_text": "Modifier la ligne",
            "update": True,
            "line": line,
        })
        return render(request, "administration_pages/line/form.html", context)


@method_decorator(never_cache, name='dispatch')
class LineDelete(View):
    """
    Suppression d'une ligne :
    - sur fetch AJAX : renvoie {"status":"success"}
    - sinon : redirect vers page_editor
    """
    def post(self, request, page_id, section_id, line_id):
        line = get_object_or_404(Line, id=line_id, section_id=section_id, section__page_id=page_id)
        line.delete()
        cache.clear()

        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return JsonResponse({"status": "success"})
        return redirect("jeiko_administration_pages:page_editor", page_id)


class LineMoveUp(View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id):
        print("post")
        # Récupère la ligne courante, vérifie qu'elle appartient bien à la section/page
        line = get_object_or_404(
            Line,
            id=line_id,
            section_id=section_id,
            section__page_id=page_id
        )
        # Cherche la ligne précédente dans la même section
        prev_line = (
            Line.objects
            .filter(section=line.section, position__lt=line.position)
            .order_by('-position')
            .first()
        )
        if prev_line:
            # Échange des positions
            line.position, prev_line.position = prev_line.position, line.position
            line.save()
            prev_line.save()
        cache.clear()
        # Si AJAX, renvoie JSON succès, sinon redirect
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"status": "success"})
        return redirect('jeiko_administration_pages:page_editor', page_id)


class LineMoveDown(View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id):
        print("post")
        line = get_object_or_404(
            Line,
            id=line_id,
            section_id=section_id,
            section__page_id=page_id
        )
        # Cherche la ligne suivante dans la même section
        next_line = (
            Line.objects
            .filter(section=line.section, position__gt=line.position)
            .order_by('position')
            .first()
        )
        if next_line:
            line.position, next_line.position = next_line.position, line.position
            line.save()
            next_line.save()
        cache.clear()
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"status": "success"})
        return redirect('jeiko_administration_pages:page_editor', page_id)


def get_bloc_forms_context(bloc, data=None):
    """
    Prépare les forms pour les marges/paddings/tailles + CSS + JS du bloc.
    """
    # StyleBox & Size forms
    style_instances = [
        bloc.margin_phone, bloc.margin_tablet, bloc.margin_computer,
        bloc.padding_phone, bloc.padding_tablet, bloc.padding_computer,
    ]
    size_instances = [
        bloc.size_phone, bloc.size_tablet, bloc.size_computer,
    ]

    style_forms = [
        StyleBoxForm(data=data, instance=style_instances[0], prefix="margin_phone_"),
        StyleBoxForm(data=data, instance=style_instances[1], prefix="margin_tablet_"),
        StyleBoxForm(data=data, instance=style_instances[2], prefix="margin_computer_"),
        StyleBoxForm(data=data, instance=style_instances[3], prefix="padding_phone_"),
        StyleBoxForm(data=data, instance=style_instances[4], prefix="padding_tablet_"),
        StyleBoxForm(data=data, instance=style_instances[5], prefix="padding_computer_"),
    ]
    size_forms = [
        BlocSizeForm(data=data, instance=size_instances[0], prefix="size_phone_"),
        BlocSizeForm(data=data, instance=size_instances[1], prefix="size_tablet_"),
        BlocSizeForm(data=data, instance=size_instances[2], prefix="size_computer_"),
    ]

    # CSS et JS parameters
    css_instance = bloc.content.CSS_parameters.first() if bloc.content.CSS_parameters.exists() else None

    css_form = CSSParametersForm(data=data, instance=css_instance, prefix="css_")

    return {
        "style_forms": style_forms,
        "size_forms": size_forms,
        "css_form": css_form,
    }


@method_decorator(never_cache, name='dispatch')
class ContentTypeChoice(View):
    """
    GET  : si content_type == NOT_SET => status="choose_type", html=choose_type.html
           sinon         => status="ok",         html=edit_{type}.html
    POST : crée/initialise le Content en TEXT, IMAGE, BUTTON, CALENDAR, FORM, CHART, puis renvoie status="ok", html=edit_{type}.html
    """

    def _get_objects(self, kwargs):
        page = get_object_or_404(Page,    id=kwargs['page_id'])
        section = get_object_or_404(Section, id=kwargs['section_id'], page=page)
        line = get_object_or_404(Line,    id=kwargs['line_id'],    section=section)
        bloc = get_object_or_404(Bloc,    id=kwargs['bloc_id'],    line=line)
        return page, section, line, bloc

    def get(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content, _ = Content.objects.get_or_create(bloc=bloc)

        if content.content_type == Content.CONTENT_TYPE_CHOICES[0][0]:
            html = render_to_string(
                "administration_pages/content/choose_type.html",
                {"page": page, "section": section, "line": line, "bloc": bloc},
                request=request
            )
            return JsonResponse({"status": "choose_type", "html": html})

        return self._render_editor(request, page, section, line, bloc, content)

    def post(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content, _ = Content.objects.get_or_create(bloc=bloc)
        ct = request.POST.get('content_type')

        # Création selon le type choisi
        if ct == "TEXT":
            content.content_text = ContentText.objects.create(text="")
            content.content_type = "TEXT"
        elif ct == "IMAGE":
            img = ImageContent.objects.create()
            ci = ContentImage.objects.create(image_content=img)
            content.content_image = ci
            content.content_type = "IMAGE"
        elif ct == "BUTTON":
            btn = ContentButton.objects.create(label="Cliquez ici")
            content.content_button = btn
            content.content_type = "BUTTON"
        elif ct == "CALENDAR":
            cc = ContentCalendar.objects.create(title="Réserver un rendez-vous")
            content.content_calendar = cc
            content.content_type = "CALENDAR"
        elif ct == "FORM":
            formulaire = ContentFormulaire.objects.create(
                name="Nouveau formulaire",
                mail_subject="Nouveau message reçu",
                success_message="Merci, votre message a bien été envoyé.",
            )
            content.content_formulaire = formulaire
            content.content_type = "FORM"
        elif ct == "CHART":
            chart = ContentChartQuestionnaire.objects.create(
                chart_type="bar",
                options_json={},
            )
            content.content_chart = chart
            content.content_type = "CHART"
        else:
            return JsonResponse({"status": "error", "message": "Type non reconnu"}, status=400)

        content.save()
        return self._render_editor(request, page, section, line, bloc, content)

    def _render_editor(self, request, page, section, line, bloc, content):
        ctx = {"page": page, "section": section, "line": line, "bloc": bloc}
        # Sélection du template et du contexte en fonction du type de contenu
        if content.content_type == "TEXT":
            ctx["text_form"] = TextForm(prefix="text_", instance=content.content_text)
            tpl = "administration_pages/content/edit_text.html"
        elif content.content_type == "IMAGE":
            ctx["image_form"] = ImageForm(prefix="image_", instance=content.content_image.image_content)
            tpl = "administration_pages/content/edit_image.html"
        elif content.content_type == "BUTTON":
            ctx["button_form"] = ButtonContentForm(prefix="button_", instance=content.content_button)
            tpl = "administration_pages/content/edit_button.html"
        elif content.content_type == "CALENDAR":
            ctx["calendar_form"] = ContentCalendarForm(prefix="calendar_", instance=content.content_calendar)
            tpl = "administration_pages/content/edit_calendar.html"
        elif content.content_type == "FORM":
            ctx["formulaire"] = content.content_formulaire
            ctx["fields"] = content.content_formulaire.fields.all().order_by("order", "id")
            tpl = "administration_pages/content/edit_formulaire.html"
        elif content.content_type == "CHART":
            ctx["chart"] = content.content_chart
            tpl = "administration_pages/content/edit_chart.html"
        else:
            return JsonResponse({"status": "error", "message": "Type de contenu inconnu"}, status=400)

        html = render_to_string(tpl, ctx, request=request)
        return JsonResponse({"status": "success", "html": html})


@method_decorator(never_cache, name='dispatch')
class EditContent(View):
    """
    GET : rend le formulaire d’édition du contenu (texte/image/bouton/etc.) dans {status:"ok", html:…}
    POST : sauvegarde le contenu et renvoie {status:"success", html:…}
    """

    def _get_objects(self, kwargs):
        page    = get_object_or_404(Page,    id=kwargs['page_id'])
        section = get_object_or_404(Section, id=kwargs['section_id'], page=page)
        line    = get_object_or_404(Line,    id=kwargs['line_id'],    section=section)
        bloc    = get_object_or_404(Bloc,    id=kwargs['bloc_id'],    line=line)
        return page, section, line, bloc

    def get(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content = getattr(bloc, "content", None)
        if not content or content.content_type == Content.CONTENT_TYPE_CHOICES[0][0]:
            return JsonResponse({"status": "choose_type", "html": ""})

        # Rendu contextuel
        if content.content_type == "TEXT":
            form = TextForm(prefix="text_", instance=content.content_text)
            tpl  = "administration_pages/content/edit_text.html"
            ctx  = {"page": page, "section": section, "line": line, "bloc": bloc, "text_form": form}
        elif content.content_type == "IMAGE":
            image_form = ImageForm(prefix="image_", instance=content.content_image.image_content)
            content_image_form = ContentImageForm(prefix="content_", instance=content.content_image)
            tpl = "administration_pages/content/edit_image.html"
            ctx = {
                "page": page, "section": section, "line": line, "bloc": bloc,
                "image_form": image_form,
                "content_image_form": content_image_form
            }
        elif content.content_type == "BUTTON":
            form = ButtonContentForm(prefix="button_", instance=content.content_button)
            tpl  = "administration_pages/content/edit_button.html"
            ctx  = {"page": page, "section": section, "line": line, "bloc": bloc, "button_form": form}
        elif content.content_type == "CALENDAR":
            form = ContentCalendarForm(prefix="calendar_", instance=content.content_calendar)
            tpl = "administration_pages/content/edit_calendar.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "calendar_form": form}
        elif content.content_type == "FORM":
            formulaire = content.content_formulaire
            fields = formulaire.fields.all().order_by("order", "id")
            tpl = "administration_pages/content/edit_formulaire.html"
            ctx = {
                "page": page, "section": section, "line": line, "bloc": bloc,
                "formulaire": formulaire,
                "fields": fields,
            }
        elif content.content_type == "CHART":
            chart = content.content_chart
            tpl = "administration_pages/content/edit_chart.html"
            ctx = {
                "page": page, "section": section, "line": line, "bloc": bloc,
                "chart": chart,
            }
        else:
            return JsonResponse({"status": "error", "message": "Type de contenu inconnu"}, status=400)

        bloc_ctx = get_bloc_forms_context(bloc)
        ctx.update(bloc_ctx)
        html = render_to_string(tpl, ctx, request=request)
        return JsonResponse({"status": "success", "html": html})

    def post(self, request, page_id, section_id, line_id, bloc_id):
        page, section, line, bloc = self._get_objects(locals())
        content = getattr(bloc, "content", None)
        if not content or content.content_type == Content.CONTENT_TYPE_CHOICES[0][0]:
            return JsonResponse({"status": "error", "message": "Contenu non initialisé"}, status=400)

        data = request.POST
        files = request.FILES

        # Préparation des forms par type de contenu
        if content.content_type == "IMAGE":
            image_form = ImageForm(data, files, prefix="image_", instance=content.content_image.image_content)
            content_image_form = ContentImageForm(data, prefix="content_", instance=content.content_image)
            tpl = "administration_pages/content/edit_image.html"
            ctx = {
                "page": page, "section": section, "line": line, "bloc": bloc,
                "image_form": image_form,
                "content_image_form": content_image_form
            }
            main_valid = image_form.is_valid() and content_image_form.is_valid()
        elif content.content_type == "TEXT":
            form = TextForm(data, prefix="text_", instance=content.content_text)
            tpl = "administration_pages/content/edit_text.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "text_form": form}
            main_valid = form.is_valid()
        elif content.content_type == "BUTTON":
            form = ButtonContentForm(data, prefix="button_", instance=content.content_button)
            tpl = "administration_pages/content/edit_button.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "button_form": form}
            main_valid = form.is_valid()
        elif content.content_type == "CALENDAR":
            form = ContentCalendarForm(data, prefix="calendar_", instance=content.content_calendar)
            tpl = "administration_pages/content/edit_calendar.html"
            ctx = {"page": page, "section": section, "line": line, "bloc": bloc, "calendar_form": form}
            main_valid = form.is_valid()
        elif content.content_type == "FORM":
            formulaire = content.content_formulaire
            formulaire.name = data.get("name", formulaire.name)
            formulaire.description = data.get("description", formulaire.description)
            formulaire.mail_subject = data.get("mail_subject", formulaire.mail_subject)
            formulaire.success_message = data.get("success_message", formulaire.success_message)
            formulaire.to_email = data.get("to_email", formulaire.to_email)
            formulaire.from_email = data.get("from_email", formulaire.from_email)
            formulaire.save()
            fields = formulaire.fields.all().order_by("order", "id")
            tpl = "administration_pages/content/edit_formulaire.html"
            ctx = {
                "page": page, "section": section, "line": line, "bloc": bloc,
                "formulaire": formulaire,
                "fields": fields,
            }
            main_valid = True
        elif content.content_type == "CHART":
            chart = content.content_chart
            # Ici, tu ajoutes la logique pour maj le chart si tu as un formulaire de config graphique
            chart.chart_type = data.get("chart_type", chart.chart_type)
            chart.title = data.get("title", chart.title)
            chart.description = data.get("description", chart.description)
            import json
            try:
                options = data.get("options_json", "{}")
                chart.options_json = json.loads(options) if options else {}
            except Exception:
                pass
            chart.save()
            tpl = "administration_pages/content/edit_chart.html"
            ctx = {
                "page": page, "section": section, "line": line, "bloc": bloc,
                "chart": chart,
            }
            main_valid = True
        else:
            return JsonResponse({"status": "error", "message": "Type de contenu inconnu"}, status=400)

        # Ajout forms de style/size/css/js
        bloc_ctx_forms = get_bloc_forms_context(bloc, data=data)
        if content.content_type == "IMAGE":
            all_forms = [image_form, content_image_form] + bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] + [bloc_ctx_forms["css_form"]]
        elif content.content_type in ("FORM", "CHART"):
            all_forms = bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] + [bloc_ctx_forms["css_form"]]
        else:
            all_forms = [form] + bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] + [bloc_ctx_forms["css_form"]]

        valid = main_valid and all(f.is_valid() for f in all_forms if f is not None)

        if not valid:
            html = render_to_string(
                tpl, {**locals(), **bloc_ctx_forms}, request=request
            )
            return JsonResponse({"status": "error", "html": html}, status=400)

        # SAUVEGARDE
        if content.content_type == "IMAGE":
            image_instance = image_form.save()
            content_image = content_image_form.save(commit=False)
            content_image.image_content = image_instance
            content_image.save()
            for f in bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] + [bloc_ctx_forms["css_form"]]:
                if f is not None:
                    f.save()
            # Réaffecte les tailles au bloc
            size_instances = [f.instance for f in bloc_ctx_forms["size_forms"]]
            bloc.size_phone, bloc.size_tablet, bloc.size_computer = size_instances
            bloc.save()

        elif content.content_type in ("FORM", "CHART"):
            for f in bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] + [bloc_ctx_forms["css_form"]]:
                if f is not None:
                    f.save()
            # Réaffecte les tailles au bloc
            size_instances = [f.instance for f in bloc_ctx_forms["size_forms"]]
            bloc.size_phone, bloc.size_tablet, bloc.size_computer = size_instances
            bloc.save()

        else:
            form.save()
            for f in bloc_ctx_forms["style_forms"] + bloc_ctx_forms["size_forms"] + [bloc_ctx_forms["css_form"]]:
                if f is not None:
                    f.save()
            # Réaffecte les tailles au bloc
            size_instances = [f.instance for f in bloc_ctx_forms["size_forms"]]
            bloc.size_phone, bloc.size_tablet, bloc.size_computer = size_instances
            bloc.save()

        html = render_to_string(
            "administration_pages/partials/bloc.html",
            {"bloc": bloc},
            request=request
        )
        return JsonResponse({"status": "success", "html": html})


@method_decorator(never_cache, name='dispatch')
class ResetContent(View):
    @method_decorator(never_cache)
    def post(self, request, page_id, section_id, line_id, bloc_id):
        bloc = get_object_or_404(
            Bloc,
            id=bloc_id,
            line_id=line_id,
            line__section_id=section_id,
            line__section__page_id=page_id
        )

        if not hasattr(bloc, 'content') or not bloc.content:
            return JsonResponse({'status': 'no_content'}, status=400)

        content = bloc.content
        content_type = content.content_type

        # Reset TEXT
        if content_type == 'TEXT' and content.content_text:
            content.content_text.delete()
            content.content_text = None

        # Reset IMAGE
        elif content_type == 'IMAGE' and content.content_image:
            if content.content_image.image_content:
                content.content_image.image_content.delete()
            content.content_image.delete()
            content.content_image = None

        # Reset BUTTON
        elif content_type == 'BUTTON' and content.content_button:
            content.content_button.delete()
            content.content_button = None

        # Reset CALENDAR
        elif content_type == 'CALENDAR' and content.content_calendar:
            content.content_calendar.delete()
            content.content_calendar = None

        # Reset CHART
        elif content_type == 'CHART' and content.content_chart:
            content.content_chart.delete()
            content.content_chart = None

        # Reset TEXT_QUESTIONNAIRE
        elif content_type == 'TEXT_QUESTIONNAIRE' and content.content_text_questionnaire:
            content.content_text_questionnaire.delete()
            content.content_text_questionnaire = None

        # Reset FORM
        elif content_type == 'FORM' and content.content_formulaire:
            # Supprime d'abord tous les champs et soumissions associés (en cascade)
            content.content_formulaire.delete()
            content.content_formulaire = None

        # Ajoute ici d'autres types quand tu en ajoutes (ex: VIDEO, PDF, ...)
        # elif content_type == 'VIDEO' and content.content_video:
        #     content.content_video.delete()
        #     content.content_video = None

        content.content_type = 'NOT_SET'
        content.save()

        cache.clear()
        return JsonResponse({'status': 'reset'})


@require_GET
def editing_menu(request):
    """
    Retourne le fragment HTML du menu d'édition.
    """
    # Si besoin, vous pouvez passer un contexte ici.
    html = render_to_string('administration_pages/content/editing_menu.html', request=request)
    return HttpResponse(html)