# administration_pages/services/pagespeed.py

import logging
from typing import Dict, Any, List, Tuple, Optional

import requests
from django.conf import settings
from django.db import transaction

from jeiko.administration_pages.utils import (
    create_latest_insight,
    page_public_url,
    get_google_api_key,
)
from jeiko.administration_pages.models import (
    InsightStatus,
    PageInsights,
    PageInsightAudit,
    InsightAuditOutcome,
    InsightAuditCategory,
    Strategy,
)

logger = logging.getLogger("administration_pages")

PSI_ENDPOINT = "https://www.googleapis.com/pagespeedonline/v5/runPagespeed"

# --- Mapping audits -> flags de PageInsights (éditoriaux, côté contenu) ---
AUDIT_TO_FLAG = {
    # A11Y
    "image-alt": "a11y_alt_text_ok",
    "label": "a11y_form_labels_ok",
    "link-name": "a11y_link_names_ok",
    "color-contrast": "a11y_color_contrast_ok",
    "heading-order": "a11y_headings_ok",         # parfois uses-heading-elements
    "uses-heading-elements": "a11y_headings_ok",
    "html-has-lang": "a11y_lang_ok",
    "keyboard": "a11y_keyboard_ok",              # focus / traps
    "focus-traps": "a11y_keyboard_ok",
    "focus-visible": "a11y_keyboard_ok",

    # SEO
    "document-title": "seo_title_ok",
    "meta-description": "seo_meta_description_ok",
    "viewport": "seo_viewport_ok",
    "font-size": "seo_font_size_ok",
    "tap-targets": "seo_tap_targets_ok",
    "canonical": "seo_canonical_ok",
    "hreflang": "seo_hreflang_ok",
    "is-crawlable": "seo_is_crawlable",
    "structured-data": "seo_structured_data_ok",
    "robots-txt": "seo_robots_txt_ok",
}

# Ordre de priorité pour les “top issues”
TOP_CATEGORIES_ORDER = (
    InsightAuditCategory.ACCESSIBILITY,
    InsightAuditCategory.SEO,
    InsightAuditCategory.BEST_PRACTICES,
    InsightAuditCategory.PERFORMANCE,
    InsightAuditCategory.PWA,
    InsightAuditCategory.OTHER,
)


def _safe_float(v):
    try:
        return float(v)
    except Exception:
        return None


def _audit_outcome(audit: Dict[str, Any]) -> str:
    """Mappe un audit Lighthouse vers notre outcome: pass/fail/notApplicable/notAvailable."""
    sdm = (audit.get("scoreDisplayMode") or "").strip()
    score = audit.get("score", None)

    if sdm == "notApplicable":
        return InsightAuditOutcome.NA
    if score is None:
        # pas de score exploitable (informative/manual/error/etc.) => notAvailable
        return InsightAuditOutcome.NOT_AVAILABLE
    try:
        # Lighthouse score est sur 0..1
        score_f = float(score)
    except Exception:
        return InsightAuditOutcome.NOT_AVAILABLE

    # Heuristique simple : >=0.9 = pass (souvent binaire 0/1)
    return InsightAuditOutcome.PASS if score_f >= 0.9 else InsightAuditOutcome.FAIL


def _build_category_map(lhr: Dict[str, Any]) -> Dict[str, str]:
    """
    Construit une table audit_id -> category (accessibility/seo/...)
    Préférence: accessibility/seo > best-practices > performance > pwa > other
    """
    categories = (lhr.get("categories") or {})
    audit_refs_by_cat = {}
    for cat_key, cat_obj in categories.items():
        refs = (cat_obj or {}).get("auditRefs") or []
        for ref in refs:
            aid = ref.get("id")
            if not aid:
                continue
            audit_refs_by_cat.setdefault(aid, set()).add(cat_key)

    # Normalise en un seul label “principal”
    def pick(cat_set: set) -> str:
        order = [
            "accessibility",
            "seo",
            "best-practices",
            "performance",
            "pwa",
        ]
        for wanted in order:
            if wanted in cat_set:
                return wanted
        return "other"

    return {aid: pick(cset) for aid, cset in audit_refs_by_cat.items()}


def _wcag_tags(audit: Dict[str, Any]) -> List[str]:
    # Lighthouse met parfois des tags wcag2a, wcag2aa, wcag21a, wcag21aa...
    tags = audit.get("tags") or []
    # Certaines versions ne les remontent pas dans `tags`; on peut aussi scruter title/description si besoin.
    return [t for t in tags if isinstance(t, str) and t.startswith("wcag")]


def _tally_kpis_for_cat(
    audits_enriched: List[Tuple[str, str, Dict[str, Any], str]]
) -> Dict[str, int]:
    """
    Calcule total/pass/fail/na pour un sous-ensemble (même catégorie).
    audits_enriched: liste de tuples (audit_id, category, audit_obj, outcome)
    """
    total = passed = failed = na = 0
    for _, _, _, outcome in audits_enriched:
        total += 1
        if outcome == InsightAuditOutcome.PASS:
            passed += 1
        elif outcome == InsightAuditOutcome.FAIL:
            failed += 1
        elif outcome == InsightAuditOutcome.NA:
            na += 1
        else:
            # NOT_AVAILABLE: on ne le compte pas dans na; total inclut tout
            pass
    return {
        "total": total,
        "pass": passed,
        "fail": failed,
        "na": na,
    }


def _collect_failed_ids(audits_enriched, want_cat: str) -> List[str]:
    return [
        aid for (aid, cat, _a, outcome) in audits_enriched
        if cat == want_cat and outcome == InsightAuditOutcome.FAIL
    ]


def _pick_top_issues(audits_enriched: List[Tuple[str, str, Dict[str, Any], str]], limit=8):
    """
    Sélectionne quelques audits en échec, d’abord A11Y/SEO, puis le reste.
    Retourne une liste de dicts {category, id, title, outcome}.
    """
    fails = [
        (aid, cat, a) for (aid, cat, a, outcome) in audits_enriched
        if outcome == InsightAuditOutcome.FAIL
    ]

    # tri par priorité de catégorie puis par titre
    def cat_rank(c):
        try:
            return TOP_CATEGORIES_ORDER.index(c)
        except ValueError:
            return len(TOP_CATEGORIES_ORDER)

    fails.sort(key=lambda t: (cat_rank(t[1]), (t[2].get("title") or "").lower()))
    items = []
    for aid, cat, a in fails[:limit]:
        items.append({
            "category": cat,
            "id": aid,
            "title": a.get("title") or aid,
            "outcome": "fail",
        })
    return items


def run_pagespeed_refresh(page, strategy: str):
    """
    Appelle Google PageSpeed Insights et enregistre le 'dernier état'.
    - Crée/MAJ le dernier PageInsights
    - Purge/insère les PageInsightAudit
    - Renseigne KPI/flags/failed_ids/http_status_code/top_issues
    strategy: 'mobile' | 'desktop'
    """
    api_key = get_google_api_key()
    if not api_key:
        logger.error("PSI: aucune clé trouvée (DB/settings). Abandon.")
        raise RuntimeError("Aucune clé PSI configurée")

    tested_url = page_public_url(page)
    timeout = getattr(settings, "PSI_TIMEOUT_SECONDS", 60)

    strategy = getattr(strategy, "value", strategy)
    if strategy not in (Strategy.MOBILE, Strategy.DESKTOP):
        if isinstance(strategy, str) and "desktop" in strategy.lower():
            strategy_value = Strategy.DESKTOP
        elif isinstance(strategy, str) and "mobile" in strategy.lower():
            strategy_value = Strategy.MOBILE

    safe_params = {
        "url": tested_url,
        "strategy": strategy,
        "category": ["performance", "accessibility", "best-practices", "seo", "pwa"],
        "key": "***",
    }
    logger.debug("PSI call params: %s", safe_params)

    params = dict(safe_params)
    params["key"] = api_key  # vraie clé

    params["locale"] = "fr"

    try:
        r = requests.get(PSI_ENDPOINT, params=params, timeout=timeout)
    except Exception as e:
        logger.exception(
            "PSI network error for page_id=%s strategy=%s url=%s (timeout=%ss)",
            page.id, strategy, tested_url, timeout
        )
        return create_latest_insight(
            page=page,
            strategy=strategy,
            status=InsightStatus.ERROR,
            url_tested=tested_url,
            error_message=f"Network error: {e}",
        )

    if r.status_code != 200:
        logger.error(
            "PSI HTTP %s for page_id=%s strategy=%s url=%s :: %s",
            r.status_code, page.id, strategy, tested_url, r.text[:800]
        )
        msg = f"HTTP {r.status_code}: {r.text[:500]}"
        return create_latest_insight(
            page=page,
            strategy=strategy,
            status=InsightStatus.ERROR,
            url_tested=tested_url,
            error_message=msg,
        )

    try:
        data = r.json()
    except Exception as e:
        logger.error(
            "PSI JSON parse error for page_id=%s strategy=%s url=%s :: %s",
            page.id, strategy, tested_url, str(e)
        )
        return create_latest_insight(
            page=page,
            strategy=strategy,
            status=InsightStatus.ERROR,
            url_tested=tested_url,
            error_message=f"JSON parse error: {e}",
        )

    # --- Normalisation scores (0..1 => 0..100) ---
    lhr = (data.get("lighthouseResult") or {})
    cats = (lhr.get("categories") or {})

    def score100(cat_key):
        s = (cats.get(cat_key, {}) or {}).get("score", None)
        try:
            return int(round(float(s) * 100)) if s is not None else None
        except Exception:
            return None

    scores = {
        "performance": score100("performance"),
        "accessibility": score100("accessibility"),
        "best_practices": score100("best-practices"),
        "seo": score100("seo"),
        "pwa": score100("pwa"),
    }

    audits = (lhr.get("audits") or {})
    audit_category_map = _build_category_map(lhr)

    def audit_val(audit_key):
        v = (audits.get(audit_key, {}) or {}).get("numericValue", None)
        return _safe_float(v)

    lab_metrics = {
        "lab_fcp_ms": audit_val("first-contentful-paint"),
        "lab_lcp_ms": audit_val("largest-contentful-paint"),
        "lab_cls": _safe_float((audits.get("cumulative-layout-shift", {}) or {}).get("numericValue")),
        "lab_ttfb_ms": audit_val("server-response-time"),
        "lab_speed_index_ms": audit_val("speed-index"),
        "lab_tbt_ms": audit_val("total-blocking-time"),
    }

    # Field (CrUX) — souvent None si faible trafic
    field = (data.get("loadingExperience", {}) or {}).get("metrics", {}) or {}

    def crux_ms(metric_key):
        v = (field.get(metric_key, {}) or {}).get("percentile", None)
        return _safe_float(v)

    field_metrics = {
        "crux_lcp_ms": crux_ms("LARGEST_CONTENTFUL_PAINT_MS"),
        "crux_inp_ms": crux_ms("INTERACTION_TO_NEXT_PAINT"),
        "crux_cls": _safe_float((field.get("CUMULATIVE_LAYOUT_SHIFT_SCORE", {}) or {}).get("percentile")),
    }

    # --- Enrichissement audits (outcome + catégorie + tags wcag) ---
    audits_enriched: List[Tuple[str, str, Dict[str, Any], str]] = []
    for aid, a in audits.items():
        # Retire certains audits purement informatifs si besoin ? (ici on garde tout)
        outcome = _audit_outcome(a)
        category = audit_category_map.get(aid, "other")
        audits_enriched.append((aid, category, a, outcome))

    # --- KPI A11Y / SEO ---
    a11y_subset = [t for t in audits_enriched if t[1] == "accessibility"]
    seo_subset = [t for t in audits_enriched if t[1] == "seo"]

    a11y_kpi = _tally_kpis_for_cat(a11y_subset)
    seo_kpi = _tally_kpis_for_cat(seo_subset)

    # Comptes WCAG (fail uniquement)
    wcag_counts = {"wcag2a": 0, "wcag2aa": 0, "wcag21a": 0, "wcag21aa": 0}
    for aid, cat, a, outcome in a11y_subset:
        if outcome != InsightAuditOutcome.FAIL:
            continue
        for tag in _wcag_tags(a):
            if tag in wcag_counts:
                wcag_counts[tag] += 1

    # --- Flags éditoriaux ---
    flags: Dict[str, Optional[bool]] = {v: None for v in AUDIT_TO_FLAG.values()}
    for aid, cat, a, outcome in audits_enriched:
        if aid not in AUDIT_TO_FLAG:
            continue
        ok_field = AUDIT_TO_FLAG[aid]
        flags[ok_field] = (outcome == InsightAuditOutcome.PASS)

    # --- Failed ids (pour UI) ---
    a11y_failed_ids = _collect_failed_ids(audits_enriched, "accessibility")
    seo_failed_ids = _collect_failed_ids(audits_enriched, "seo")

    # --- HTTP status code (si dispo) ---
    http_status = None
    http_a = audits.get("http-status-code")
    if http_a:
        nv = http_a.get("numericValue")
        try:
            http_status = int(nv) if nv is not None else None
        except Exception:
            http_status = None

    # --- Top issues (quelques fails prioritaires) ---
    top_issues = _pick_top_issues(audits_enriched, limit=8)

    logger.info(
        "PSI OK page_id=%s strategy=%s perf=%s url=%s (field_lcp=%s, lab_lcp=%s)",
        page.id, strategy, scores.get("performance"), tested_url,
        field_metrics.get("crux_lcp_ms"), lab_metrics.get("lab_lcp_ms"),
    )

    # --- Persistance ---
    # 1) On crée/MAJ l'insight principal (historique) avec toutes les colonnes utiles
    insight: PageInsights = create_latest_insight(
        page=page,
        strategy=strategy,
        status=InsightStatus.OK,
        url_tested=tested_url,

        # scores
        scores=scores,

        # lab/field
        field_metrics=field_metrics,
        lab_metrics=lab_metrics,

        # KPI
        a11y_total=a11y_kpi["total"],
        a11y_pass=a11y_kpi["pass"],
        a11y_fail=a11y_kpi["fail"],
        a11y_na=a11y_kpi["na"],

        seo_total=seo_kpi["total"],
        seo_pass=seo_kpi["pass"],
        seo_fail=seo_kpi["fail"],
        seo_na=seo_kpi["na"],

        # WCAG counts
        a11y_wcag2a_fail=wcag_counts["wcag2a"],
        a11y_wcag2aa_fail=wcag_counts["wcag2aa"],
        a11y_wcag21a_fail=wcag_counts["wcag21a"],
        a11y_wcag21aa_fail=wcag_counts["wcag21aa"],

        # Flags éditoriaux
        **flags,

        # Failed IDs
        a11y_failed_ids=a11y_failed_ids,
        seo_failed_ids=seo_failed_ids,

        # Technique/Meta
        http_status_code=http_status,
        top_issues=top_issues,
        raw_json=data,
    )

    # 2) (Re)création des audits normalisés
    try:
        with transaction.atomic():
            insight.audits.all().delete()
            to_insert: List[PageInsightAudit] = []
            for aid, cat, a, outcome in audits_enriched:
                p = PageInsightAudit(
                    insight=insight,
                    category=cat if cat in dict(InsightAuditCategory.choices).keys() else InsightAuditCategory.OTHER,
                    audit_id=aid,
                    title=(a.get("title") or "")[:512],
                    description=a.get("description") or "",
                    outcome=outcome,
                    score=_safe_float(a.get("score")),
                    score_display_mode=(a.get("scoreDisplayMode") or "")[:64],
                    numeric_value=_safe_float(a.get("numericValue")),
                    numeric_unit=(a.get("numericUnit") or "")[:64],
                    tags=a.get("tags") or None,
                    details=a.get("details") or None,
                )
                to_insert.append(p)
            if to_insert:
                PageInsightAudit.objects.bulk_create(to_insert, batch_size=500)
    except Exception:
        # On log mais on ne met pas l’insight principal en erreur si les audits échouent
        logger.exception("Failed to persist PageInsightAudit for page_id=%s strategy=%s", page.id, strategy)

    return insight
