# administration_pages/scripts/refresh_imagecontent_derivatives.py

from django.db.models import Q
from django.apps import apps

def run(limit=None, ids=None, only_missing=False, delete_old=True, verbose=True, chunk_size=50):


    ImageContent = apps.get_model('administration_pages', 'ImageContent')

    qs = ImageContent.objects.all()
    if ids:
        qs = qs.filter(pk__in=list(ids))

    if only_missing:
        qs = qs.filter(
            Q(full_size__isnull=True)     | Q(full_size="")     |
            Q(computer_size__isnull=True) | Q(computer_size="") |
            Q(laptop_size__isnull=True)   | Q(laptop_size="")   |
            Q(tablet_size__isnull=True)   | Q(tablet_size="")   |
            Q(mobile_size__isnull=True)   | Q(mobile_size="")
        ).distinct()

    processed = 0
    for obj in qs.iterator(chunk_size=chunk_size):
        if limit and processed >= limit:
            break
        if not obj.original_image:
            if verbose:
                print(f"⏭️  skip {obj.pk}: original_image absent")
            continue

        if delete_old:
            # Supprime les anciens fichiers de dérivés avant de régénérer
            try:
                obj._cleanup_derivatives(obj)
            except Exception as e:
                if verbose:
                    print(f"⚠️  cleanup {obj.pk}: {e}")

            # Optionnel: remettre les champs à None (facilite la relecture)
            obj.full_size = None
            obj.computer_size = None
            obj.laptop_size = None
            obj.tablet_size = None
            obj.mobile_size = None

        if verbose:
            print(f"♻️  rebuild {obj.pk} …")

        # Déclenche la (re)génération via le save() du modèle
        obj.save()
        processed += 1

    if verbose:
        print(f"✅ Terminé. Objets traités: {processed}")
