# jeiko/administration_pages/comparaison.py
"""
Comparer deux états d'une page — la page en ligne, son brouillon, une version
de l'historique (HIST-01).

Ce que ça résout : l'historique gardait trente versions, mais pour savoir ce
qui avait changé il fallait ouvrir deux aperçus côte à côte et chercher.

Comment : chaque état est DÉCRIT en lignes de texte — section, ligne, bloc,
son type, ses textes (sans balises), puis ses réglages non vides — à partir
de la même lecture que l'API des agents (`_section_en_dict`), sans les
identifiants (une version a d'autres numéros que la page). La différence de
ces descriptions dit ce qui a bougé : un mot, une couleur, un bloc déplacé.

Ce que ça ne fait pas : comparer le RENDU (une règle CSS du thème, un menu) ;
dire qu'un bloc déplacé est le même bloc — il paraît retiré ici, ajouté là.
"""
import difflib
import json
from html import unescape

from django.utils.html import strip_tags

IGNORES = {"id", "image_id", "bloc_id", "ligne_id", "section_id"}


def _vide(valeur):
    return valeur in ("", None, False, [], {})


def _a_plat(prefixe, valeur, sortie):
    if isinstance(valeur, dict) and "enabled" in valeur and not valeur["enabled"]:
        return  # une animation éteinte : ses réglages par défaut ne disent rien
    if isinstance(valeur, dict):
        for cle in sorted(valeur):
            if cle not in IGNORES:
                _a_plat(f"{prefixe}.{cle}" if prefixe else cle, valeur[cle], sortie)
    elif isinstance(valeur, list) and valeur and all(isinstance(v, dict) for v in valeur):
        for n, element in enumerate(valeur):
            _a_plat(f"{prefixe}[{n}]", element, sortie)
    elif not _vide(valeur):
        texte = valeur if isinstance(valeur, str) else json.dumps(valeur, ensure_ascii=False)
        if isinstance(valeur, str) and "<" in valeur:
            texte = " ".join(unescape(strip_tags(valeur)).split())
        sortie.append(f"    {prefixe} : {texte}")


def description(page):
    """Les lignes qui décrivent le contenu de `page`, dans l'ordre de la page."""
    from jeiko.agents.vues_pages import _section_en_dict

    lignes = []
    for s, section in enumerate(page.sections.all().order_by("position", "id"), start=1):
        donnees = _section_en_dict(section)
        lignes.append(f"Section {s}")
        reglages = []
        _a_plat("", {k: v for k, v in donnees.items() if k not in ("lignes", "position")}, reglages)
        lignes += reglages
        for l, ligne in enumerate(donnees.get("lignes") or [], start=1):
            lignes.append(f"  Section {s} › ligne {l}")
            reglages = []
            _a_plat("", {k: v for k, v in ligne.items() if k not in ("blocs", "position")}, reglages)
            lignes += reglages
            for b, bloc in enumerate(ligne.get("blocs") or [], start=1):
                contenu = bloc.get("contenu") or {}
                lignes.append(f"  Section {s} › ligne {l} › bloc {b} ({contenu.get('type', '?')}, "
                              f"colonne {bloc.get('colonne', 0)})")
                details = []
                _a_plat("", {k: v for k, v in bloc.items() if k not in ("colonne", "rang")}, details)
                lignes += [d for d in details if not d.startswith("    contenu.type :")]
    return lignes


def differences(avant, apres):
    """La différence unifiée des deux descriptions (liste de lignes) ; vide si identiques."""
    return list(difflib.unified_diff(description(avant), description(apres), "avant", "après", lineterm="", n=2))


def tableau(avant, apres, libelle_avant, libelle_apres):
    """La même différence, côte à côte, en HTML (les textes sont échappés par difflib)."""
    return difflib.HtmlDiff(wrapcolumn=70).make_table(
        description(avant), description(apres), libelle_avant, libelle_apres, context=True, numlines=2)
