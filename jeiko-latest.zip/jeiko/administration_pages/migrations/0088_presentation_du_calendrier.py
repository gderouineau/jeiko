"""La présentation du bloc calendrier : « classique » (le rendu d'origine) ou « moderne »."""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('administration_pages', '0087_recalculer_les_heros_apres_le_brouillon_programme'),
    ]

    operations = [
        migrations.AddField(
            model_name='contentcalendar',
            name='presentation',
            field=models.CharField(choices=[('classique', 'Classique'), ('moderne', 'Moderne')], default='classique', help_text='Moderne : les jours en cartes, les créneaux en pastilles, une fenêtre de réservation aérée — aux couleurs du thème du site.', max_length=10, verbose_name='Présentation'),
        ),
    ]
