from django.db import migrations


def seed_demo_site(apps, schema_editor):
    """
    Ne crée plus rien (SITE-01, 09/10/2026).

    Cette migration montait trois pages de démonstration (Accueil,
    Fonctionnalités, Contact) et leur menu, avec le schéma de 2025 : sans
    police, sans thème, sans héros — le premier écran d'un site neuf était
    laid. Le site de départ est désormais monté par la commande
    `jeiko_site_de_depart`, que l'installeur lance une fois sur un site neuf,
    APRÈS toutes les migrations : elle dispose donc de tout le schéma
    d'aujourd'hui.

    Sans effet sur un site existant : Django ne rejoue jamais une migration
    déjà passée. Le contenu d'origine reste dans l'historique git.
    """


class Migration(migrations.Migration):

    dependencies = [
        ('administration_pages', '0001_initial'),
        ('administration_menu', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(seed_demo_site, migrations.RunPython.noop),
    ]
