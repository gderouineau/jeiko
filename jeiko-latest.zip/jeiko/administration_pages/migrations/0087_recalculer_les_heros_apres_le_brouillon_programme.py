"""
Vide depuis le 23/10/2026 : le recalcul des héros est passé en 0089, après
`0088_presentation_du_calendrier` (voir 0089 et `tests/test_migration_des_heros.py`).
Gardée pour la chaîne déjà jouée.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0086_brouillon_programme"),
    ]

    operations = []
