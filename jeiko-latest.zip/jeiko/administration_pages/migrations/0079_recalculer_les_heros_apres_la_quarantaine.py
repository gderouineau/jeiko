"""
Vide depuis le 12/10/2026 : le recalcul des héros est passé en 0082, après
`0081_menu_transparent` (voir 0082 et `tests/test_migration_des_heros.py`).
Gardée pour la chaîne déjà jouée.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0078_quarantaine_des_formulaires"),
    ]

    operations = []
