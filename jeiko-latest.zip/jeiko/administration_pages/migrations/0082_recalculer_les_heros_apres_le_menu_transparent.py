"""
Vide depuis le 13/10/2026 : le recalcul des héros est passé en 0085, après
`0084_brouillon_et_historique` (voir 0085 et `tests/test_migration_des_heros.py`).
Gardée pour la chaîne déjà jouée.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0081_menu_transparent"),
    ]

    operations = []
