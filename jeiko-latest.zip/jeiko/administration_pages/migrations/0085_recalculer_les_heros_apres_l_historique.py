"""
Vide depuis le 17/10/2026 : le recalcul des héros est passé en 0087, après
`0086_brouillon_programme` (voir 0087 et `tests/test_migration_des_heros.py`).
Gardée pour la chaîne déjà jouée.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0084_brouillon_et_historique"),
    ]

    operations = []
