"""
Recalcule le visuel « héros » de chaque page — en fin de chaîne (13/10/2026).

Même règle que 0063, 0068, 0070, 0073, 0075, 0077, 0079 et 0082 : le recalcul
appelle le code COURANT, il doit donc passer après toute migration de schéma
de ce module (`tests/test_migration_des_heros.py`). `0084` ajoute le brouillon
et l'historique (`Page.role`, que le gestionnaire par défaut lit à chaque
requête) : 0082 est vide, le recalcul vit ici. Une base qui avait joué 0082
recalcule une seconde fois — sans effet, le calcul est idempotent.
Voir 0070 pour le pourquoi du recalcul lui-même.
"""

import logging

from django.db import migrations
from django.db.utils import OperationalError, ProgrammingError

logger = logging.getLogger(__name__)


def recalculer(apps, schema_editor):
    from django.db import transaction

    from jeiko.administration_pages.models import Page
    from jeiko.administration_pages.signals import recompute_page_hero

    try:
        with transaction.atomic():
            pages = list(Page.objects.all().only("pk"))
    except (OperationalError, ProgrammingError):
        logger.warning("Recalcul des héros sauté : schéma en avance sur cette étape.")
        return

    for page in pages:
        try:
            with transaction.atomic():
                recompute_page_hero(page)
        except (OperationalError, ProgrammingError):
            logger.warning(
                "Recalcul des héros arrêté : le schéma n'est pas celui qu'attend le "
                "code (page %s). Les héros se recalculent à la modification des pages.",
                page.pk,
            )
            return
        except Exception:
            # Une page abîmée ne doit pas bloquer la mise à jour du site.
            logger.exception("Héros non recalculé pour la page %s", page.pk)


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0084_brouillon_et_historique"),
    ]

    operations = [
        migrations.RunPython(recalculer, migrations.RunPython.noop),
    ]
