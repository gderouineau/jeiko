"""Libellés seulement : le titre du bloc calendrier, et les quatre présentations (classique, moderne, épurée, agenda)."""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('administration_pages', '0089_recalculer_les_heros_apres_la_presentation_du_calendrier'),
    ]

    operations = [
        migrations.AlterField(
            model_name='contentcalendar',
            name='presentation',
            field=models.CharField(choices=[('classique', 'Classique'), ('moderne', 'Moderne — les jours en cartes'), ('epuree', 'Épurée — une ligne par jour'), ('agenda', "Agenda — on choisit le jour, puis l'heure")], default='classique', help_text="Classique : l'affichage d'origine. Les trois autres partagent une fenêtre de réservation aérée et les couleurs du thème du site.", max_length=10, verbose_name='Présentation'),
        ),
        migrations.AlterField(
            model_name='contentcalendar',
            name='title',
            field=models.CharField(default='Réserver un rendez-vous', max_length=150, verbose_name='Titre'),
        ),
    ]
