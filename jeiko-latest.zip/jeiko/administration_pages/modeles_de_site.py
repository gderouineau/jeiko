"""
Les modèles de site : un site complet, posé en un geste (TPL-01, 12/10/2026).

Le besoin (Guillaume) : vendre un site « tout prêt » par métier. Le client
choisit un modèle ; ses pages, son menu, son pied de page et ses types de
rendez-vous arrivent EN LIGNE, aux couleurs du métier — puis tout se modifie.

La règle, posée par Guillaume : « on ne supprime rien, on rajoute juste et on
active ce que l'on choisit ».

- Les pages du site qui étaient en ligne passent HORS LIGNE (dépubliées, pas
  supprimées), sauf les pages légales et les pages d'erreur, qui restent
  obligatoires et ne sont pas du contenu à remplacer. Leurs traductions
  suivent.
- Les nouvelles pages arrivent en ligne ; l'accueil du modèle devient la page
  d'accueil du site.
- Les menus du modèle (principal et pied de page) deviennent ceux par défaut ;
  les anciens restent, simplement plus par défaut.
- Les couleurs et polices du modèle ne s'appliquent que si on le demande. Le
  thème d'avant n'est pas modifié : le site en reçoit un nouveau, l'ancien
  reste en base.
- Les modules dont le modèle a besoin (rendez-vous) sont allumés.
- Ce qui a été changé est écrit dans un journal (`ModeleDeSiteApplique`) :
  pages dépubliées, ancien accueil, anciens menus, ancien thème, anciennes
  polices. C'est ce qui permet de revenir en arrière à la main — et, un jour,
  d'un clic.

Ce que le modèle ne fait PAS : poser des horaires de rendez-vous. Il crée les
types de séance (durée, prix), jamais de disponibilité inventée — un visiteur
pourrait réserver un créneau que personne n'a ouvert. Les horaires se règlent
dans Rendez-vous › Créneaux ; la réponse le rappelle.

Les modèles sont des fichiers JSON (`modeles_de_site/<cle>.<langue>.json`),
dans le format de l'API des agents, fabriqués par
`outils-site-de-depart/fabriquer_modeles.py`. Ils passent par les MÊMES
fonctions que l'API : mêmes refus, même assainissement.
"""
import json
from pathlib import Path

from django.core.serializers.json import DjangoJSONEncoder
from django.db import transaction

DOSSIER = Path(__file__).resolve().parent / "modeles_de_site"


class ModeleInvalide(Exception):
    """Un modèle inconnu, ou un fichier de modèle que les fonctions de l'API refusent."""


def _fichier(cle, langue):
    langue = (langue or "fr")[:2].lower()
    for candidat in (DOSSIER / f"{cle}.{langue}.json", DOSSIER / f"{cle}.fr.json"):
        if candidat.is_file():
            return candidat
    return None


def _cles():
    return sorted({p.name.split(".")[0] for p in DOSSIER.glob("*.json")})


def lire(cle, langue=None):
    if "/" in cle or "." in cle or cle not in _cles():
        raise ModeleInvalide(f"Modèle inconnu : {cle}. Connus : {', '.join(_cles())}.")
    return json.loads(_fichier(cle, langue).read_text(encoding="utf-8"))


def catalogue(langue=None):
    """Les modèles proposés, dans l'ordre, avec de quoi les présenter."""
    modeles = []
    for cle in _cles():
        kit = lire(cle, langue)
        fiche = kit.get("_modele", {})
        modeles.append({
            "cle": cle,
            "nom": fiche.get("nom", cle),
            "metier": fiche.get("metier", ""),
            "famille": fiche.get("famille", ""),
            "description": fiche.get("description", ""),
            "ordre": fiche.get("ordre", 99),
            "couleurs": {k: v for k, v in (kit.get("identite", {}).get("couleurs") or {}).items()
                         if k in ("accent", "secondaire", "tertiaire", "fond_attenue")},
            "polices": fiche.get("polices", ""),
            "pages": [p["titre"] for p in kit["pages"] if not p.get("gabarit_de_fiche")],
            "produits": len((kit.get("boutique") or {}).get("produits", [])),
            "modules": kit.get("modules", []),
            "rendez_vous": [t["nom"] for t in kit.get("rendez_vous", [])],
        })
    return sorted(modeles, key=lambda m: (m["ordre"], m["nom"]))


# --------------------------------------------------------------------------- #
def _pages_a_depublier():
    """Les pages en ligne, hors pages légales et pages d'erreur, traductions comprises."""
    from django.db.models import Q

    from jeiko.administration.models import Legals, WebSite
    from jeiko.administration_pages.models import Page
    from jeiko.administration_pages.querysets import public_pages

    gardees = set()
    for legales in Legals.objects.all():
        gardees |= {getattr(legales, f"{c}_page_id") for c in ("mentions", "privacy", "cgv", "cgu")}
    site = WebSite.objects.first()
    if site is not None:
        gardees |= {getattr(site, f"page_{c}_id") for c in (404, 403, 500, 400)}
    gardees.discard(None)
    return (public_pages(Page.objects.all())
            .exclude(Q(pk__in=gardees) | Q(traduction_de__in=gardees))
            .exclude(is_default_legal_template=True))


def _liberer(adresse, renommees):
    """« adresse » (sans suffixe), si sa détentrice est une page HORS LIGNE.

    Une page dépubliée cède son adresse au modèle — /contact/ reste /contact/,
    avec le nouveau contenu — et prend « …-ancienne » (noté au journal). Une
    page EN LIGNE (une page légale) garde la sienne : la nouvelle prend un
    suffixe.
    """
    from jeiko.administration_pages.models import Page

    detentrice = Page.objects.filter(url_tag=adresse, traduction_de__isnull=True).first()
    if detentrice is None:
        return adresse
    if detentrice.active:
        n = 2
        while Page.objects.filter(url_tag=f"{adresse}-{n}").exists():
            n += 1
        return f"{adresse}-{n}"
    nouvelle, n = f"{adresse}-ancienne", 2
    while Page.objects.filter(url_tag=nouvelle).exists():
        nouvelle, n = f"{adresse}-ancienne-{n}", n + 1
    detentrice.url_tag = nouvelle
    detentrice.save(update_fields=["url_tag"])  # save() : les caches de la page suivent
    renommees.append({"page": detentrice.pk, "avant": adresse, "apres": nouvelle})
    return adresse


def _resoudre(valeur, pages):
    if isinstance(valeur, dict):
        return {k: _resoudre(v, pages) for k, v in valeur.items()}
    if isinstance(valeur, list):
        return [_resoudre(v, pages) for v in valeur]
    if isinstance(valeur, str) and valeur.startswith("@"):
        if valeur[1:] not in pages:
            raise ModeleInvalide(f"Le modèle renvoie à une page inconnue : {valeur}.")
        return pages[valeur[1:]].id
    return valeur


def _poser_les_pages(documents, renommees):
    from jeiko.administration_pages.models import Page
    from jeiko.agents.vues_api import CorpsInvalide
    from jeiko.agents.vues_pages import _appliquer_metadonnees, _Construction

    pages, avertissements = {}, []
    for doc in documents:
        if doc.get("racine"):
            Page.objects.filter(is_root=True).update(is_root=False)
        pages[doc["cle"]] = Page.objects.create(
            title=doc["titre"], url_tag=_liberer(doc["url_tag"], renommees), active=True,
            is_root=bool(doc.get("racine")), menu_transparent=bool(doc.get("menu_transparent")),
            # La page gabarit des fiches produit d'un modèle de boutique.
            is_custom_object_template=bool(doc.get("gabarit_de_fiche")),
        )
    from jeiko.administration_pages.signals import construction_de_pages

    with construction_de_pages([p.id for p in pages.values()]):
        for doc in documents:
            page = pages[doc["cle"]]
            construction = _Construction()
            try:
                if doc.get("metadonnees"):
                    _appliquer_metadonnees(page, doc["metadonnees"])
                for n, section in enumerate(_resoudre(doc.get("sections") or [], pages)):
                    construction.section(page, section, f"{doc['cle']}.sections[{n}]")
            except CorpsInvalide as souci:
                raise ModeleInvalide(str(souci))
            avertissements += construction.avertissements
    return pages, avertissements


def _poser_le_menu(document, place, pages):
    from jeiko.administration_menu import styles_predefinis
    from jeiko.administration_menu.models import Menu, MenuPlace
    from jeiko.agents.vues_api import CorpsInvalide
    from jeiko.agents.vues_menus import _ecrire_les_elements

    anciens = list(Menu.objects.filter(place=place, is_default=True).values_list("pk", flat=True))
    Menu.objects.filter(pk__in=anciens).update(is_default=False)
    champs = {c: document[c] for c in ("barre_infos", "barre_texte", "pied_texte", "pied_appel",
                                       "pied_appel_detail") if c in document}
    disposition = document.get("disposition")
    if place == MenuPlace.MAIN and not disposition:
        # Le menu principal exige une disposition dès sa création (contrainte de base).
        style = styles_predefinis.STYLES.get(document.get("style_pret") or "")
        disposition = style[2] if style else "logo-left-menu-right"
    menu = Menu.objects.create(name=document["nom"][:150], place=place, is_default=True,
                               layout=disposition, **champs)
    try:
        _ecrire_les_elements(menu, _resoudre(document["elements"], pages))
    except CorpsInvalide as souci:
        raise ModeleInvalide(f"{place} : {souci}")
    if place == MenuPlace.MAIN and document.get("style_pret"):
        styles_predefinis.appliquer(menu, document["style_pret"])
    return menu, anciens


def _poser_les_rendez_vous(types):
    from datetime import timedelta

    from jeiko.agents.vues_api import CorpsInvalide
    from jeiko.agents.vues_calendrier import _ecrire_le_type
    from jeiko.calendars.models import AppointmentType

    crees = []
    for doc in types:
        type_rdv = AppointmentType(name=doc["nom"][:100], duration=timedelta(minutes=int(doc["duree_minutes"])))
        try:
            _ecrire_le_type(type_rdv, doc)
        except CorpsInvalide as souci:
            raise ModeleInvalide(f"rendez_vous : {souci}")
        type_rdv.save()
        crees.append(type_rdv)
    return crees


def par_famille(modeles):
    """[(famille, [modèles])], dans l'ordre des modèles — pour l'écran."""
    familles = {}
    for m in modeles:
        familles.setdefault(m["famille"] or "", []).append(m)
    return list(familles.items())


def _poser_la_boutique(doc, pages):
    """
    Une boutique d'exemple : le modèle de fiche et son gabarit, le type de
    produit, les produits en ligne, la boutique ouverte avec son icône de
    panier. Rien n'est retiré : un catalogue existant garde ses produits, les
    nouveaux s'y ajoutent. Rend (créés, réglages d'avant) pour le journal.
    """
    from decimal import Decimal

    from django.utils.text import slugify

    from jeiko.custom_objects.models import (
        CustomObject, CustomObjectField, CustomObjectMetadata, CustomObjectModel, CustomObjectValue,
    )
    from jeiko.shop.models import Product, ProductType, ShopSettings

    def unique(modele, champ, base):
        valeur, n = base, 2
        while modele.objects.filter(**{champ: valeur}).exists():
            valeur, n = f"{base}-{n}", n + 1
        return valeur

    gabarit = pages[doc["gabarit"].lstrip("@")]
    modele = CustomObjectModel.objects.create(
        name=doc["type"]["nom"][:150], slug=unique(CustomObjectModel, "slug", slugify(doc["type"]["code"])),
        page_template=gabarit, is_product=True,
    )
    champs = {}
    for rang, c in enumerate(doc["champs"]):
        champs[c["code"]] = CustomObjectField.objects.create(
            model=modele, code=c["code"], label=c["libelle"], field_type=c["type"], position=rang)
    type_produit = ProductType.objects.create(
        name=doc["type"]["nom"][:100],
        code=unique(ProductType, "code", slugify(doc["type"]["code"]).replace("-", "_")),
        content_model=modele, kind=doc["type"].get("nature", ProductType.KIND_PHYSICAL),
        default_tax_rate=Decimal(str(doc["type"].get("tva", "20.00"))),
    )
    crees = []
    for p in doc["produits"]:
        fiche = CustomObject.objects.create(model=modele, title=p["titre"][:200],
                                            slug=slugify(p["titre"])[:200], is_published=True)
        for code, valeur in p["valeurs"].items():
            CustomObjectValue.objects.create(obj=fiche, field=champs[code], value_text=valeur)
        # La carte d'une grille lit la description des métadonnées de la fiche.
        CustomObjectMetadata.objects.create(obj=fiche, title=p["titre"][:100], description=p.get("description", ""))
        # Le modèle donne le prix que le client PAIE (TTC) ; on range le HT.
        taux = type_produit.default_tax_rate
        produit = Product.objects.create(
            type=type_produit, content=fiche, sku=unique(Product, "sku", p["sku"]),
            price_ht=(Decimal(str(p["prix_ttc"])) * 100 / (100 + taux)).quantize(Decimal("0.01")), tax_rate=taux,
            currency="EUR", stock_quantity=int(p.get("stock", 10)), is_active=True,
        )
        crees.append(produit.pk)

    reglages = ShopSettings.get_solo()
    avant = {"is_online": reglages.is_online, "show_cart": reglages.show_cart, "homepage": reglages.homepage_id,
             "return_days": reglages.return_days}
    reglages.is_online = True
    reglages.show_cart = True
    # La page « Livraison et retours » annonce quatorze jours (le délai légal
    # de rétractation) ; Merchant Center exige une politique de retour.
    # Une durée déjà réglée est gardée.
    if not reglages.return_days:
        reglages.return_days = 14
    if doc.get("accueil_boutique"):
        reglages.homepage = pages[doc["accueil_boutique"].lstrip("@")]
    reglages.save()
    return {"type_de_produit": type_produit.pk, "modele_de_fiche": modele.pk, "produits": crees,
            "boutique_d_avant": avant}


def appliquer(cle, langue=None, avec_couleurs=True, par=None):
    """
    Pose le modèle `cle` sur le site. Tout ou rien : une erreur ne laisse rien.
    Rend le rapport de ce qui a été fait (aussi écrit au journal).
    """
    from jeiko.administration.models import ModeleDeSiteApplique, Theme
    from jeiko.administration.modules import MODULES
    from jeiko.administration_menu.models import MenuPlace
    from jeiko.agents.vues_api import CorpsInvalide
    from jeiko.agents.vues_identite import (
        _ecrire_les_couleurs, _ecrire_les_polices, _identite_en_dict, _site,
    )
    from jeiko.administration_pages.models import Page

    kit = lire(cle, langue)
    with transaction.atomic():
        site = _site()
        avant = _identite_en_dict(site)
        journal = {
            "accueil_d_avant": Page.objects.filter(is_root=True).values_list("pk", flat=True).first(),
            "theme_d_avant": site.theme_id,
            "couleurs_d_avant": avant["couleurs"],
            "polices_d_avant": avant["polices"],
        }

        depubliees = list(_pages_a_depublier().values_list("pk", flat=True))
        # Leurs traductions suivent : une version anglaise en ligne d'une page
        # hors ligne resterait servie seule, sous son adresse /en/….
        depubliees += list(Page.objects.filter(traduction_de__in=depubliees, active=True)
                           .exclude(pk__in=depubliees).values_list("pk", flat=True))
        Page.objects.filter(pk__in=depubliees).update(active=False)
        journal["pages_depubliees"] = depubliees

        if avec_couleurs and kit.get("identite"):
            # Un thème NEUF : celui d'avant reste en base, intact.
            if site.theme_id:
                nouveau = Theme.objects.get(pk=site.theme_id)
                nouveau.pk = None
                nouveau.save()
                site.theme = nouveau
                site.save(update_fields=["theme"])
            try:
                if kit["identite"].get("couleurs"):
                    _ecrire_les_couleurs(site, kit["identite"]["couleurs"])
                if kit["identite"].get("polices"):
                    _ecrire_les_polices(site, kit["identite"]["polices"])
            except CorpsInvalide as souci:
                raise ModeleInvalide(f"identite : {souci}")

        renommees = []
        pages, avertissements = _poser_les_pages(kit["pages"], renommees)
        journal["adresses_cedees"] = renommees
        menu, anciens_menus = _poser_le_menu(kit["menu"], MenuPlace.MAIN, pages)
        journal["menus_principaux_d_avant"] = anciens_menus
        pied = None
        if kit.get("pied"):
            pied, anciens_pieds = _poser_le_menu(kit["pied"], MenuPlace.FOOTER, pages)
            journal["pieds_d_avant"] = anciens_pieds
        types = _poser_les_rendez_vous(kit.get("rendez_vous", []))
        boutique = _poser_la_boutique(kit["boutique"], pages) if kit.get("boutique") else None
        if boutique:
            journal["boutique"] = boutique

        modules = [m for m in kit.get("modules", []) if m in MODULES]
        for code in modules:
            setattr(site, MODULES[code][0], True)
        if modules:
            site.save(update_fields=[MODULES[c][0] for c in modules])

        rapport = {
            "modele": cle,
            "nom": kit.get("_modele", {}).get("nom", cle),
            "pages_creees": [{"id": p.id, "titre": p.title, "url": p.get_absolute_url()}
                             for p in pages.values() if not p.is_custom_object_template],
            "accueil": next((p.id for p in pages.values() if p.is_root), None),
            "menu_principal": menu.id,
            "pied_de_page": pied.id if pied else None,
            "types_de_rendez_vous": [t.id for t in types],
            "produits_crees": boutique["produits"] if boutique else [],
            "pages_depubliees": len(depubliees),
            "couleurs_appliquees": bool(avec_couleurs and kit.get("identite")),
            "modules_allumes": modules,
            "a_faire": kit.get("_modele", {}).get("a_faire", []),
            "avertissements": avertissements,
        }
        ModeleDeSiteApplique.objects.create(
            cle=cle, par=par if getattr(par, "pk", None) else None,
            details=json.loads(json.dumps({**journal, "rapport": rapport}, cls=DjangoJSONEncoder)),
        )

    from jeiko.administration.website_cache import invalidate_website_data
    from jeiko.administration_menu.models import invalider_tous_les_menus

    invalidate_website_data()
    invalider_tous_les_menus()
    if rapport["couleurs_appliquees"] and kit["identite"].get("polices"):
        try:
            from django.core.management import call_command
            call_command("rebuild_fonts", verbosity=0)
        except Exception:  # réseau absent : la police de secours s'affiche
            rapport["avertissements"].append(
                "Polices non rapatriées (réseau ?) : le site s'affiche dans la police de secours "
                "jusqu'au prochain enregistrement des polices.")
    return rapport
