"""
Les nouveaux défauts des blocs (BLOCS-01, 09/10/2026).

Demande de Guillaume : qu'un bloc posé sans réglage soit présentable — FAQ,
onglets, tarifs, boutons, formulaires… — moderne par défaut, SANS changer ceux
qui sont déjà en ligne. Et sans option à cocher : une règle CSS globale aurait
repeint d'un coup tous les sites, un choix « moderne / classique » aurait
encombré l'écran.

D'où une marque invisible, `apparence: "moderne"` dans `Content.data`, posée
sur tout bloc qui prend son type (éditeur ou API) ; `partials/bloc.html` en
fait la classe `jk-moderne`, que le CSS de `main.css` (section BLOCS-01)
habille aux couleurs du thème. Un bloc d'avant n'a pas la marque : il reste
tel quel. Ni l'écran ni l'API ne l'exposent.

Ce que ça ne fait pas : convertir les blocs existants. C'est voulu.
"""
from .models import DYNAMIC_DEFAULTS

#: Les types qui ont de nouveaux défauts : les blocs dynamiques, les grilles
#: et carrousels de fiches (produits, articles…), le bouton et le formulaire.
TYPES = frozenset(DYNAMIC_DEFAULTS) | {"DYN_RESOURCE_GRID", "DYN_RESOURCE_CAROUSEL", "BUTTON", "FORM"}


def poser(content, *, nouveau):
    """Marque un bloc qui vient de prendre son type. Ne sauvegarde pas."""
    if nouveau and content.content_type in TYPES and "apparence" not in (content.data or {}):
        content.data = {**(content.data or {}), "apparence": "moderne"}
