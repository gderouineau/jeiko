"""
Pages › Modèles de site (TPL-01) : choisir un site tout prêt et le poser.

L'écran présente les modèles (métier, couleurs, polices, pages) et pose celui
qu'on choisit, par POST, avec ou sans ses couleurs et polices. La règle et ce
qui est fait sont dans administration_pages/modeles_de_site.py : rien n'est
supprimé, les pages en ligne passent hors ligne, l'état d'avant est journalisé.
"""
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import redirect, render
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _
from django.views import View
from django.views.decorators.cache import never_cache

from jeiko.administration_pages import modeles_de_site


@method_decorator(never_cache, name="dispatch")
class ModelesDeSite(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = "users.config_edit_site"
    raise_exception = True

    def get(self, request):
        from django.conf import settings

        from jeiko.administration.models import ModeleDeSiteApplique

        catalogue = modeles_de_site.catalogue(settings.LANGUAGE_CODE)
        dernier = ModeleDeSiteApplique.objects.first()
        return render(request, "administration_pages/modeles_de_site.html", {
            "familles": modeles_de_site.par_famille(catalogue),
            "dernier": dernier,
            # Son nom à l'écran, pas sa clé de fichier (« bijoux-createur »).
            "nom_du_dernier": next((m["nom"] for m in catalogue if dernier and m["cle"] == dernier.cle),
                                   dernier.cle if dernier else ""),
            "rapport": request.session.pop("jeiko_rapport_modele", None),
        })

    def post(self, request):
        from django.conf import settings

        cle = request.POST.get("modele", "")
        try:
            rapport = modeles_de_site.appliquer(
                cle, settings.LANGUAGE_CODE, avec_couleurs=request.POST.get("couleurs") == "on", par=request.user)
        except modeles_de_site.ModeleInvalide as souci:
            messages.error(request, _("Le modèle n'a pas pu être posé : %(raison)s") % {"raison": souci})
            return redirect("jeiko_administration_pages:modeles_de_site")
        request.session["jeiko_rapport_modele"] = rapport
        messages.success(request, _("Modèle « %(nom)s » posé : %(pages)d pages en ligne, menus et pied de page activés.")
                         % {"nom": rapport["nom"], "pages": len(rapport["pages_creees"])})
        return redirect("jeiko_administration_pages:modeles_de_site")
