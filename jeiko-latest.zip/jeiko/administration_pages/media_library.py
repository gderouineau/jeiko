"""Inventaire et suppression sûre des images de la médiathèque.

Ce module est volontairement indépendant des vues : l'administration et les
autres points d'entrée peuvent appliquer exactement la même règle métier.
Une image utilisée n'est jamais supprimée implicitement ; l'appelant reçoit la
liste des dépendances à retirer ou à remplacer avant de réessayer.
"""

from dataclasses import dataclass

from django.db import IntegrityError, transaction
from django.db.models import Count
from django.db.models.deletion import ProtectedError, RestrictedError

from .models import ImageContent
from django.utils.translation import gettext_lazy as _


LIBELLES_USAGES = {
    "administration.siteidentity.default_share_image": _("Images de partage par défaut"),
    "administration_pages.page.main_image": _("Images principales de pages"),
    "administration_pages.section.background_image": _("Fonds de sections"),
    "administration_pages.line.background_image": _("Fonds de lignes"),
    "administration_pages.bloc.background_image": _("Fonds de blocs"),
    "administration_pages.contentimage.image_content": "Blocs image",
    "administration_pages.contentvideo.poster": _("Vignettes de vidéos"),
    "administration_pages.dyncarouselslide.image": _("Diapositives de carrousel"),
    "administration_pages.dyntestimonialitem.avatar": _("Avatars de témoignages"),
    "administration_pages.dyngalleryitem.image": _("Éléments de galerie"),
    "custom_objects.customobject.main_image": _("Images principales de fiches"),
    "custom_objects.customobjectvalue.image": _("Champs image de fiches"),
    "questionnaires_expert.experttest.main_image": _("Images de questionnaires"),
    "shop.productimage.image": _("Images de produits"),
}


@dataclass(frozen=True)
class ImageUsage:
    label: str
    model_label: str
    field_name: str
    count: int
    items: tuple


@dataclass(frozen=True)
class ImageDeletionResult:
    deleted: bool
    message: str
    usages: tuple = ()


def _relations_images():
    """Toutes les relations inverses concrètes qui ciblent ImageContent."""
    return tuple(
        relation
        for relation in ImageContent._meta.related_objects
        if getattr(relation, "field", None) is not None
        and not relation.field.many_to_many
    )


#: Chemin de chaque usage jusqu'à sa page — pour reconnaître ceux de
#: l'historique (administration_pages/historique.py). "" : la page elle-même.
_VERS_LA_PAGE = {
    "administration_pages.page": "",
    "administration_pages.section": "page__",
    "administration_pages.line": "section__page__",
    "administration_pages.bloc": "line__section__page__",
    "administration_pages.contentimage": "content__bloc__line__section__page__",
    "administration_pages.contentvideo": "parent_content__bloc__line__section__page__",
    "administration_pages.dyncarouselslide": "content__bloc__line__section__page__",
    "administration_pages.dyntestimonialitem": "content__bloc__line__section__page__",
    "administration_pages.dyngalleryitem": "content__bloc__line__section__page__",
}


def _hors_historique(relation, queryset):
    chemin = _VERS_LA_PAGE.get(relation.related_model._meta.label_lower)
    return queryset if chemin is None else queryset.exclude(**{f"{chemin}role": "version"})


def versions_qui_l_utilisent(image):
    """Les versions de l'historique des pages qui montrent cette image."""
    from .models import Page

    ids = set()
    for relation in _relations_images():
        chemin = _VERS_LA_PAGE.get(relation.related_model._meta.label_lower)
        if chemin is None:
            continue
        cible = "pk" if not chemin else chemin.rstrip("_")
        ids.update(
            relation.related_model._base_manager
            .filter(**{f"{relation.field.name}_id": image.pk, f"{chemin}role": "version"})
            .values_list(cible, flat=True)
        )
    return Page.tous.filter(pk__in=ids)


def _relation_label(relation):
    model = relation.related_model
    cle = f"{model._meta.label_lower}.{relation.field.name}"
    return LIBELLES_USAGES.get(cle, str(model._meta.verbose_name_plural).capitalize())


def _item_label(item):
    texte = str(item).strip()
    valeur_par_defaut = f"{item.__class__.__name__} object ({item.pk})"
    if not texte or texte == valeur_par_defaut:
        return f"{item._meta.verbose_name} n°{item.pk}"
    return texte


def image_usage_count_map(images, avec_l_historique=True):
    """
    Compte tous les usages d'un lot d'images sans requête par image.

    `avec_l_historique=False` : sans les versions de l'historique des pages,
    ce que la médiathèque affiche — une image qui ne sert plus qu'au passé
    se supprime (ces versions partent avec elle).
    """
    image_ids = [image.pk for image in images if image.pk]
    comptes = {image_id: 0 for image_id in image_ids}
    if not image_ids:
        return comptes

    for relation in _relations_images():
        champ = relation.field.name
        cle = f"{champ}_id"
        base = relation.related_model._base_manager.filter(**{f"{cle}__in": image_ids})
        if not avec_l_historique:
            base = _hors_historique(relation, base)
        lignes = (
            base
            .values(cle)
            .annotate(total=Count("pk"))
        )
        for ligne in lignes:
            comptes[ligne[cle]] += ligne["total"]
    return comptes


def image_usages(image, item_limit=20):
    """
    Retourne les usages regroupés, assez détaillés pour agir avant suppression.
    Sans l'historique des pages : il ne retient pas une image
    (`versions_qui_l_utilisent`).
    """
    groupes = []
    for relation in _relations_images():
        champ = relation.field.name
        queryset = _hors_historique(relation, relation.related_model._base_manager.filter(
            **{f"{champ}_id": image.pk}
        )).order_by("pk")
        total = queryset.count()
        if not total:
            continue
        items = tuple(
            {"id": item.pk, "label": _item_label(item)}
            for item in queryset[:item_limit]
        )
        groupes.append(ImageUsage(
            label=_relation_label(relation),
            model_label=relation.related_model._meta.label_lower,
            field_name=champ,
            count=total,
            items=items,
        ))
    return tuple(groupes)


def image_preview_url(image):
    """URL de la variante la plus utile disponible, sans laisser `.url` lever."""
    for champ in (
        "mobile_size", "tablet_size", "laptop_size", "computer_size",
        "full_size", "original_image",
    ):
        fichier = getattr(image, champ, None)
        if not fichier:
            continue
        try:
            return fichier.url
        except (ValueError, OSError, NotImplementedError):
            continue
    return ""


def delete_image_safely(image):
    """Supprime une image libre, ou renvoie un refus métier détaillé.

    Le verrou et la seconde lecture des usages réduisent la fenêtre de course
    entre l'écran de confirmation et le POST. Les protections de schéma restent
    la dernière barrière si une référence apparaît malgré tout.
    """
    try:
        with transaction.atomic():
            courante = ImageContent.objects.select_for_update().get(pk=image.pk)
            usages = image_usages(courante)
            if usages:
                total = sum(groupe.count for groupe in usages)
                return ImageDeletionResult(
                    False,
                    f"Suppression refusée : cette image possède {total} usage(s).",
                    usages,
                )
            # Le passé ne retient pas une image : les versions de pages qui
            # la montrent partent avec elle (l'écran l'a annoncé).
            from .historique import _supprimer_la_page_cachee

            versions = list(versions_qui_l_utilisent(courante))
            for version in versions:
                _supprimer_la_page_cachee(version)
            courante.delete()
    except ImageContent.DoesNotExist:
        return ImageDeletionResult(False, _("Cette image n'existe plus."))
    except (ProtectedError, RestrictedError, IntegrityError):
        # Une référence concurrente peut apparaître après l'inventaire. On ne
        # diffuse pas l'exception SQL et on restitue l'état actuel si possible.
        courante = ImageContent.objects.filter(pk=image.pk).first()
        usages = image_usages(courante) if courante else ()
        return ImageDeletionResult(
            False,
            _("Suppression refusée : l'image est encore utilisée."),
            usages,
        )
    if versions:
        return ImageDeletionResult(True, _(
            "Image supprimée de la médiathèque, avec %(n)s ancienne(s) version(s) de pages "
            "qui la montraient.") % {"n": len(versions)})
    return ImageDeletionResult(True, _("Image supprimée de la médiathèque."))
