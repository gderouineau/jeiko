from django.urls import path
import jeiko.administration_pages.views_client as views

app_name = 'jeiko_pages'
urlpatterns = [
    path('', views.RootPage.as_view(), name='root_page'),

    # /cat/sub/page/
    path('<slug:category_slug>/<slug:sub_category_slug>/<slug:url_tag>/',
         views.PageView.as_view(), name='page_view_cat_sub'),

    # /cat/page/
    path('<slug:category_slug>/<slug:url_tag>/',
         views.PageView.as_view(), name='page_view_cat'),

    # /page/
    path('<slug:url_tag>/',
         views.PageView.as_view(), name='page_view'),
]


