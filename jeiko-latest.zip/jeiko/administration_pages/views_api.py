# jeiko/administration_pages/views_api.py

from django.http import JsonResponse, HttpResponseBadRequest
from django.views import View
from django.shortcuts import get_object_or_404
import json
from django.core.mail import EmailMultiAlternatives, get_connection
from django.core.cache import cache
from django.views.decorators.cache import never_cache
decorators = [never_cache]
from django.utils.decorators import method_decorator
from django.template.loader import render_to_string
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt

from jeiko.administration.models import WebSite
from jeiko.administration_pages.models import (
    Category, Page,
    ContentFormulaire, ContentFormField, ContentFormSubmission
)



# Liste des catégories principales (pas de parent)
class CategoryMainListAPI(View):
    def get(self, request):
        categories = Category.objects.filter(main_category__isnull=True)
        data = [
            {
                "id": c.id,
                "name": c.name,
            }
            for c in categories
        ]
        return JsonResponse({"categories": data})


# Liste des sous-catégories pour une catégorie principale donnée (paramètre : category_id)
class SubCategoryListAPI(View):
    def get(self, request, category_id):
        main_category = get_object_or_404(Category, id=category_id)
        subcategories = Category.objects.filter(main_category=main_category)
        data = [
            {
                "id": c.id,
                "name": c.name,
            }
            for c in subcategories
        ]
        return JsonResponse({"subcategories": data})


# Liste des pages filtrées par catégorie/sous-catégorie (optionnel)
class PageListAPI(View):

    @method_decorator(never_cache)
    def get(self, request):
        category_id = request.GET.get("category_id")
        sub_category_id = request.GET.get("sub_category_id")
        search = request.GET.get("search")

        qs = Page.objects.all()
        if sub_category_id:
            qs = qs.filter(sub_category_id=sub_category_id)
        elif category_id:
            qs = qs.filter(category_id=category_id)
        if search:
            qs = qs.filter(title__icontains=search)  # ou autre champ
        pages = [
            {
                "id": p.id,
                "title": p.title,
                "url_tag": p.url_tag,
                "category_id": p.category_id,
                "sub_category_id": p.sub_category_id,
            }
            for p in qs
        ]
        return JsonResponse({"pages": pages})


class PageGetAPI(View):
    def get(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        data = {
            "id": page.id,
            "title": page.title,
            "url_tag": page.url_tag,
            "category_id": page.category_id,
            "sub_category_id": page.sub_category_id,
            # Ajoute ici d'autres champs si besoin
        }
        return JsonResponse({"page": data})


class ContentFormulaireAPI(View):
    """
    GET : récupère la config complète du formulaire (métadonnées + champs)
    POST : met à jour les méta-infos (name, mail_subject, etc.)
    """
    def get(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        data = {
            "id": formulaire.id,
            "name": formulaire.name,
            "description": formulaire.description,
            "to_email": formulaire.to_email,
            "from_email": formulaire.from_email,
            "mail_subject": formulaire.mail_subject,
            "success_message": formulaire.success_message,
            "fields": [
                {
                    "id": f.id,
                    "label": f.label,
                    "name": f.name,
                    "type": f.type,
                    "required": f.required,
                    "options": f.options,
                    "order": f.order,
                }
                for f in formulaire.fields.all().order_by("order", "id")
            ]
        }
        return JsonResponse(data)

    def post(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        try:
            data = json.loads(request.body)
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        # MAJ méta-infos
        formulaire.name = data.get("name", formulaire.name)
        formulaire.description = data.get("description", formulaire.description)
        formulaire.to_email = data.get("to_email", formulaire.to_email)
        formulaire.from_email = data.get("from_email", formulaire.from_email)
        formulaire.mail_subject = data.get("mail_subject", formulaire.mail_subject)
        formulaire.success_message = data.get("success_message", formulaire.success_message)
        formulaire.save()
        return JsonResponse({"success": True, "message": "Formulaire mis à jour."})


class ContentFormFieldAPI(View):
    """
    POST : ajoute un champ (si pas id), sinon édite le champ existant
    DELETE : supprime un champ
    PATCH : réordonne les champs (tu envoies une liste [{id, order}])
    """

    def post(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        try:
            data = json.loads(request.body)
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        # ADD or EDIT
        field_id = data.get("id")
        if field_id:
            field = get_object_or_404(ContentFormField, pk=field_id, formulaire=formulaire)
        else:
            field = ContentFormField(formulaire=formulaire)

        field.label = data.get("label", field.label)
        field.name = data.get("name", field.name)
        field.type = data.get("type", field.type)
        field.required = data.get("required", field.required)
        field.options = data.get("options", field.options)
        field.order = data.get("order", field.order or formulaire.fields.count())
        field.save()

        return JsonResponse({
            "success": True,
            "field": {
                "id": field.id,
                "label": field.label,
                "name": field.name,
                "type": field.type,
                "required": field.required,
                "options": field.options,
                "order": field.order,
            }
        })

    def delete(self, request, formulaire_id, field_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        field = get_object_or_404(ContentFormField, pk=field_id, formulaire=formulaire)
        field.delete()
        return JsonResponse({"success": True})

    def patch(self, request, formulaire_id):
        """
        Permet de réordonner plusieurs champs d'un coup (tu envoies une liste [{id, order}])
        """
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        try:
            data = json.loads(request.body)
        except Exception:
            return HttpResponseBadRequest("JSON invalide")
        for item in data.get("fields", []):
            try:
                field = ContentFormField.objects.get(pk=item["id"], formulaire=formulaire)
                field.order = item["order"]
                field.save()
            except Exception:
                continue
        return JsonResponse({"success": True})


@method_decorator(csrf_exempt, name='dispatch')  # Si tu fais de l'AJAX pur. Sinon retire-le si tu utilises le CSRF standard.
class FormulaireSubmitView(View):
    """
    POST : soumet un formulaire personnalisé, enregistre la soumission et renvoie un JSON succès/erreurs
    """
    def post(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        data = request.POST.dict()

        # 1. Validation dynamique
        errors = {}
        values = {}
        label_values = {}
        for field in formulaire.fields.all().order_by("order", "id"):
            field_name = field.name
            value = data.get(field_name, '').strip()
            values[field_name] = value
            label_values[field.label] = value
            if field.required and not value:
                errors[field_name] = "Ce champ est requis"
            if field.type == "email" and value:
                from django.core.validators import validate_email
                from django.core.exceptions import ValidationError
                try:
                    validate_email(value)
                except ValidationError:
                    errors[field_name] = "Adresse email invalide"

        if errors:
            return JsonResponse({"success": False, "errors": errors}, status=400)

        # 2. Enregistrement de la soumission
        submission = ContentFormSubmission.objects.create(
            formulaire=formulaire,
            data=values,
            ip_address=request.META.get('REMOTE_ADDR'),
            user_agent=request.META.get('HTTP_USER_AGENT', '')
        )

        # 3. Envoi d’un mail stylé via la config SMTP du site
        # ———— récupère la config depuis le site
        website = WebSite.objects.first()  # Adapte à ton contexte si multi-site
        config = website.mail_settings if website and website.mail_settings else None

        if formulaire.to_email and config and config.active:
            subject = formulaire.mail_subject or "Nouvelle soumission de formulaire"
            # Génère le mail HTML et texte
            html_body = render_to_string("administration/mail/default_formulaire_email.html", {
                "subject": subject,
                "form_name": formulaire.name or "Formulaire de contact",
                "fields": label_values,
                "site_name": website.name if website else "",
                "now": timezone.now(),
            })
            text_body = render_to_string("administration/mail/default_formulaire_email.txt", {
                "subject": subject,
                "form_name": formulaire.name or "Formulaire de contact",
                "fields": label_values,
                "site_name": website.name if website else "",
                "now": timezone.now(),
            })
            # Utilise la connexion personnalisée
            connection = get_connection(
                host=config.host,
                port=config.port,
                username=config.host_user,
                password=config.host_password,
                use_tls=config.use_tls,
                use_ssl=config.use_ssl,
                fail_silently=False,
            )
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_body,
                from_email=formulaire.from_email or config.default_from_email or "no-reply@monsite.com",
                to=[formulaire.to_email],
                connection=connection,
            )
            email.attach_alternative(html_body, "text/html")
            email.send()
        elif formulaire.to_email:
            # Fallback Django si pas de config trouvée (optionnel)
            from django.core.mail import send_mail
            subject = formulaire.mail_subject or "Nouvelle soumission de formulaire"
            message_lines = [f"{f.label}: {values.get(f.name, '')}" for f in formulaire.fields.all()]
            message = "\n".join(message_lines)
            send_mail(
                subject=subject,
                message=message,
                from_email=formulaire.from_email or None,
                recipient_list=[formulaire.to_email],
                fail_silently=False
            )

        # 4. Succès
        return JsonResponse({
            "success": True,
            "message": formulaire.success_message or "Merci, votre message a bien été envoyé."
        })

