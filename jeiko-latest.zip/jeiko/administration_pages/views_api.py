# jeiko/administration_pages/views_api.py

from django.http import JsonResponse, HttpResponseBadRequest, HttpResponse
from django.views import View
from django.shortcuts import get_object_or_404
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.cache import never_cache, cache_control
from django.template.loader import render_to_string
from django.utils import timezone
import json
from django.db import transaction

from django.core.mail import EmailMultiAlternatives, get_connection

from jeiko.administration.models import WebSite
from jeiko.administration_pages.models import (
    Category, Page, Section, Line, Bloc, Strategy,
    ContentFormulaire, ContentFormField, ContentFormSubmission
)

from jeiko.administration_pages.utils import section_duplicate, line_duplicate, bloc_duplicate, get_latest_insight

# ---- Mixin pour forcer les bons headers anti-cache sur TOUTES les réponses ----
class NoStoreMixin:
    def dispatch(self, request, *args, **kwargs):
        resp = super().dispatch(request, *args, **kwargs)
        if isinstance(resp, HttpResponse):
            # no-store est la clé pour éviter tout cache navigateur/proxy
            resp['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
            resp['Pragma'] = 'no-cache'
            resp['Expires'] = '0'
            # Vary Cookie pour éviter une mise en cache partagée entre users
            resp['Vary'] = 'Cookie'
        return resp


# ========== APIs ==========

@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class CategoryMainListAPI(NoStoreMixin, View):
    @method_decorator(never_cache)
    def get(self, request):
        categories = Category.objects.filter(main_category__isnull=True)
        print(categories)
        data = [{"id": c.id, "name": c.name} for c in categories]
        return JsonResponse({"categories": data})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class SubCategoryListAPI(NoStoreMixin, View):
    @method_decorator(never_cache)
    def get(self, request, category_id):
        main_category = get_object_or_404(Category, id=category_id)
        subcategories = Category.objects.filter(main_category=main_category)
        print(subcategories)
        data = [{"id": c.id, "name": c.name} for c in subcategories]
        return JsonResponse({"subcategories": data})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class PageListAPI(NoStoreMixin, View):
    @method_decorator(never_cache)
    def get(self, request):
        category_id = request.GET.get("category_id")
        sub_category_id = request.GET.get("sub_category_id")
        search = request.GET.get("search")

        qs = Page.objects.all()
        if sub_category_id:
            qs = qs.filter(sub_category_id=sub_category_id)
        elif category_id:
            qs = qs.filter(category_id=category_id)
        if search:
            qs = qs.filter(title__icontains=search)

        pages = [{
            "id": p.id,
            "title": p.title,
            "url_tag": p.url_tag,
            "category_id": p.category_id,
            "sub_category_id": p.sub_category_id,
        } for p in qs]
        return JsonResponse({"pages": pages})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class PageGetAPI(NoStoreMixin, View):
    @method_decorator(never_cache)
    def get(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        data = {
            "id": page.id,
            "title": page.title,
            "url_tag": page.url_tag,
            "category_id": page.category_id,
            "sub_category_id": page.sub_category_id,
        }
        return JsonResponse({"page": data})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class ContentFormulaireAPI(NoStoreMixin, View):
    """
    GET : config complète du formulaire (métadonnées + champs)
    POST : MAJ des méta-infos
    """
    def get(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        data = {
            "id": formulaire.id,
            "name": formulaire.name,
            "description": formulaire.description,
            "to_email": formulaire.to_email,
            "from_email": formulaire.from_email,
            "mail_subject": formulaire.mail_subject,
            "success_message": formulaire.success_message,
            "fields": [{
                "id": f.id, "label": f.label, "name": f.name, "type": f.type,
                "required": f.required, "options": f.options, "order": f.order,
            } for f in formulaire.fields.all().order_by("order", "id")]
        }
        return JsonResponse(data)

    def post(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        try:
            data = json.loads(request.body)
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        formulaire.name = data.get("name", formulaire.name)
        formulaire.description = data.get("description", formulaire.description)
        formulaire.to_email = data.get("to_email", formulaire.to_email)
        formulaire.from_email = data.get("from_email", formulaire.from_email)
        formulaire.mail_subject = data.get("mail_subject", formulaire.mail_subject)
        formulaire.success_message = data.get("success_message", formulaire.success_message)
        formulaire.save()
        return JsonResponse({"success": True, "message": "Formulaire mis à jour."})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class ContentFormFieldAPI(NoStoreMixin, View):
    """
    POST : add/edit un champ
    DELETE : supprime un champ
    PATCH : réordonne en masse [{id, order}]
    """
    def post(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        try:
            data = json.loads(request.body)
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        field_id = data.get("id")
        if field_id:
            field = get_object_or_404(ContentFormField, pk=field_id, formulaire=formulaire)
        else:
            field = ContentFormField(formulaire=formulaire)

        field.label = data.get("label", field.label)
        field.name = data.get("name", field.name)
        field.type = data.get("type", field.type)
        field.required = data.get("required", field.required)
        field.options = data.get("options", field.options)
        field.order = data.get("order", field.order or formulaire.fields.count())
        field.save()

        return JsonResponse({
            "success": True,
            "field": {
                "id": field.id, "label": field.label, "name": field.name,
                "type": field.type, "required": field.required,
                "options": field.options, "order": field.order,
            }
        })

    def delete(self, request, formulaire_id, field_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        field = get_object_or_404(ContentFormField, pk=field_id, formulaire=formulaire)
        field.delete()
        return JsonResponse({"success": True})

    def patch(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        try:
            data = json.loads(request.body)
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        for item in data.get("fields", []):
            try:
                field = ContentFormField.objects.get(pk=item["id"], formulaire=formulaire)
                field.order = item["order"]
                field.save()
            except Exception:
                continue
        return JsonResponse({"success": True})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class FormulaireSubmitView(NoStoreMixin, View):
    """
    POST : soumet un formulaire, enregistre et envoie un mail
    """
    def post(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        data = request.POST.dict()

        errors, values, label_values = {}, {}, {}
        for field in formulaire.fields.all().order_by("order", "id"):
            field_name = field.name
            value = data.get(field_name, '').strip()
            values[field_name] = value
            label_values[field.label] = value
            if field.required and not value:
                errors[field_name] = "Ce champ est requis"
            if field.type == "email" and value:
                from django.core.validators import validate_email
                from django.core.exceptions import ValidationError
                try:
                    validate_email(value)
                except ValidationError:
                    errors[field_name] = "Adresse email invalide"

        if errors:
            return JsonResponse({"success": False, "errors": errors}, status=400)

        ContentFormSubmission.objects.create(
            formulaire=formulaire, data=values,
            ip_address=request.META.get('REMOTE_ADDR'),
            user_agent=request.META.get('HTTP_USER_AGENT', '')
        )

        website = WebSite.objects.first()
        config = website.mail_settings if website and website.mail_settings else None

        if formulaire.to_email and config and config.active:
            subject = formulaire.mail_subject or "Nouvelle soumission de formulaire"
            html_body = render_to_string("administration/mail/default_formulaire_email.html", {
                "subject": subject, "form_name": formulaire.name or "Formulaire de contact",
                "fields": label_values, "site_name": website.name if website else "", "now": timezone.now(),
            })
            text_body = render_to_string("administration/mail/default_formulaire_email.txt", {
                "subject": subject, "form_name": formulaire.name or "Formulaire de contact",
                "fields": label_values, "site_name": website.name if website else "", "now": timezone.now(),
            })
            connection = get_connection(
                host=config.host, port=config.port, username=config.host_user, password=config.host_password,
                use_tls=config.use_tls, use_ssl=config.use_ssl, fail_silently=False,
            )
            email = EmailMultiAlternatives(
                subject=subject, body=text_body,
                from_email=formulaire.from_email or config.default_from_email or "no-reply@monsite.com",
                to=[formulaire.to_email], connection=connection,
            )
            email.attach_alternative(html_body, "text/html")
            email.send()
        elif formulaire.to_email:
            from django.core.mail import send_mail
            subject = formulaire.mail_subject or "Nouvelle soumission de formulaire"
            message_lines = [f"{f.label}: {values.get(f.name, '')}" for f in formulaire.fields.all()]
            send_mail(subject, "\n".join(message_lines), formulaire.from_email or None, [formulaire.to_email], fail_silently=False)

        return JsonResponse({"success": True, "message": formulaire.success_message or "Merci, votre message a bien été envoyé."})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class SectionModelCreateAPI(NoStoreMixin, View):
    """
    POST JSON {"model_name": "..."} -> duplique la section en un modèle (is_model=True)
    """
    @transaction.atomic
    def post(self, request, section_id):
        section = get_object_or_404(Section, pk=section_id)
        try:
            payload = json.loads(request.body or "{}")
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        model_name = (payload.get("model_name") or "").strip()
        if not model_name:
            return HttpResponseBadRequest("Le nom du modèle est requis")

        # Crée une COPIE de la section en tant que modèle (page=None, is_model=True)
        model_copy = section_duplicate(
            section,
            target_page=None,
            position=0,
            as_model=True,     # => is_model=True + model_source=None
            link_model=False   # on ne veut pas lier la section courante au modèle ici
        )
        model_copy.model_name = model_name
        model_copy.page = None
        model_copy.save()
        section.model_source = model_copy
        section.save()
        return JsonResponse({
            "success": True,
            "message": "Modèle créé",
            "model": {"id": model_copy.id, "name": model_copy.model_name}
        }, status=200)


# --- LINES: créer un modèle depuis une ligne existante ---
@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class LineModelCreateAPI(NoStoreMixin, View):
    """
    POST JSON {"model_name": "..."} -> duplique la ligne en un modèle (is_model=True)
    """
    @transaction.atomic
    def post(self, request, line_id):
        from jeiko.administration_pages.models import Line  # si besoin
        try:
            payload = json.loads(request.body or "{}")
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        model_name = (payload.get("model_name") or "").strip()
        if not model_name:
            return HttpResponseBadRequest("Le nom du modèle est requis")

        source_line = get_object_or_404(Line, pk=line_id)

        # On crée une COPIE de la ligne en tant que modèle (section cible = None)
        model_copy = line_duplicate(
            source_line,
            target_section=None,   # => pas rattachée à une section
            position=0,
            as_model=True,         # is_model=True sur la copie
            link_model=False       # la copie n'est pas “liée” à la source ; c'est le modèle
        )
        model_copy.model_name = model_name
        model_copy.section = None
        model_copy.save(update_fields=["model_name", "section"])

        # Optionnel : rattacher la ligne source à son modèle (trace)
        source_line.model_source = model_copy
        source_line.save(update_fields=["model_source"])

        return JsonResponse({
            "success": True,
            "message": "Modèle de ligne créé",
            "model": {"id": model_copy.id, "name": model_copy.model_name}
        }, status=200)


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class BlocModelCreateAPI(NoStoreMixin, View):
    """
    POST JSON {"model_name": "..."} -> duplique le bloc en un modèle (is_model=True)
    """
    @transaction.atomic
    def post(self, request, bloc_id):
        try:
            payload = json.loads(request.body or "{}")
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        model_name = (payload.get("model_name") or "").strip()
        if not model_name:
            return HttpResponseBadRequest("Le nom du modèle est requis")

        source_bloc = get_object_or_404(Bloc, pk=bloc_id)

        # Crée une COPIE du bloc en tant que modèle (line=None, is_model=True)
        model_copy = bloc_duplicate(
            source_bloc,
            target_line=None,   # modèle non rattaché à une ligne
            position=0,
            as_model=True,      # => is_model=True
            link_model=False    # on ne veut pas lier la source au modèle automatiquement
        )
        model_copy.model_name = model_name
        model_copy.line = None
        model_copy.save(update_fields=["model_name", "line"])

        # Optionnel : rattacher le bloc source à son modèle
        source_bloc.model_source = model_copy
        source_bloc.save(update_fields=["model_source"])

        return JsonResponse({
            "success": True,
            "message": "Modèle de bloc créé",
            "model": {"id": model_copy.id, "name": model_copy.model_name}
        }, status=200)


# administration_pages/views_api.py
from datetime import timedelta

from django.conf import settings
from django.contrib.auth.decorators import login_required, permission_required
from django.http import JsonResponse, HttpResponseBadRequest, HttpResponseForbidden
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST



# TODO: implémenter cette fonction dans services/pagespeed.py (ou utils)
# Elle doit appeler l’API PSI pour (page, strategy), normaliser, et créer le run via create_latest_insight(...)
def run_pagespeed_refresh(page, strategy: str):
    """
    Placeholder: lance un refresh PSI pour (page, strategy) et retourne l'instance PageInsights créée/mise à jour.
    À implémenter par la suite (appel API + normalize + create_latest_insight).
    """
    raise NotImplementedError("Brancher services/pagespeed.run_pagespeed_refresh(page, strategy)")


def _check_perm_or_403(request):
    if not request.user.has_perm("pages.view_page"):
        return False
    return True


@require_GET
@login_required
@permission_required("pages.view_page", raise_exception=True)
def insights_latest(request, page_id: int):
    """
    Retourne les derniers scores Mobile & Desktop pour affichage rapide (liste admin).
    """
    page = get_object_or_404(Page, pk=page_id)

    def serialize(insight):
        if not insight:
            return None
        return {
            "status": insight.status,
            "fetched_at": insight.fetched_at.isoformat() if insight.fetched_at else None,
            "url_tested": insight.url_tested,
            "scores": {
                "performance": insight.score_performance,
                "accessibility": insight.score_accessibility,
                "best_practices": insight.score_best_practices,
                "seo": insight.score_seo,
                "pwa": insight.score_pwa,
            },
            "field": {
                "lcp_ms": insight.crux_lcp_ms,
                "inp_ms": insight.crux_inp_ms,
                "cls": insight.crux_cls,
            },
            "lab": {
                "fcp_ms": insight.lab_fcp_ms,
                "lcp_ms": insight.lab_lcp_ms,
                "cls": insight.lab_cls,
                "ttfb_ms": insight.lab_ttfb_ms,
                "speed_index_ms": insight.lab_speed_index_ms,
                "tbt_ms": insight.lab_tbt_ms,
            },
            "error_message": insight.error_message or "",
        }

    data = {
        "page_id": page.id,
        "mobile": serialize(get_latest_insight(page, Strategy.MOBILE)),
        "desktop": serialize(get_latest_insight(page, Strategy.DESKTOP)),
    }
    return JsonResponse(data, status=200)


@require_POST
@login_required
def insights_refresh(request, page_id: int):
    """
    Lance un refresh PSI.
    - Param `strategy` dans body/GET: 'mobile' | 'desktop' | 'both' (défaut: both)
    - Rate-limit simple: empêche si < 10 min depuis le dernier fetch par stratégie (sauf ?force=1)
    - Nécessite la clé API configurée (settings.GOOGLE_PSI_API_KEY ou autre mécanisme que tu ajouteras)
    """
    if not _check_perm_or_403(request):
        return HttpResponseForbidden("Forbidden")

    page = get_object_or_404(Page, pk=page_id)

    if not getattr(settings, "GOOGLE_PSI_API_KEY", None):
        return HttpResponseBadRequest("Missing GOOGLE_PSI_API_KEY")

    strategy = request.POST.get("strategy") or request.GET.get("strategy") or "both"
    force = (request.POST.get("force") or request.GET.get("force")) in ("1", "true", "True")

    now = timezone.now()
    cooldown = timedelta(minutes=10)

    def can_run(strat):
        latest = get_latest_insight(page, strat)
        if force or not latest or not latest.fetched_at:
            return True
        return (now - latest.fetched_at) >= cooldown

    to_run = []
    if strategy == "both":
        for s in (Strategy.MOBILE, Strategy.DESKTOP):
            if can_run(s):
                to_run.append(s)
    elif strategy in (Strategy.MOBILE, Strategy.DESKTOP):
        if can_run(strategy):
            to_run.append(strategy)
    else:
        return HttpResponseBadRequest("Invalid strategy. Use 'mobile', 'desktop', or 'both'.")

    results = []
    errors = []

    for s in to_run:
        try:
            insight = run_pagespeed_refresh(page, s)
            results.append({
                "strategy": s,
                "status": insight.status,
                "fetched_at": insight.fetched_at.isoformat() if insight.fetched_at else None,
            })
        except NotImplementedError as e:
            # Placeholder tant que le service n'est pas branché
            errors.append({"strategy": s, "error": str(e)})
        except Exception as e:
            errors.append({"strategy": s, "error": str(e)})

    # Si rien n’a été lancé à cause du rate-limit
    if not results and not errors:
        return JsonResponse({
            "ok": False,
            "message": "Rate limited: a recent run exists (< 10 min). Use force=1 to override."
        }, status=429)

    return JsonResponse({
        "ok": len(errors) == 0,
        "page_id": page.id,
        "ran": results,
        "errors": errors,
    }, status=200 if len(errors) == 0 else 207)  # 207 Multi-Status si mix succès/erreurs
