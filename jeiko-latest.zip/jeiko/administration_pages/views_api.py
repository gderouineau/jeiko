# jeiko/administration_pages/views_api.py

from django.http import JsonResponse, HttpResponseBadRequest, HttpResponse,HttpResponseForbidden
from django.views import View
from django.shortcuts import get_object_or_404
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.cache import never_cache, cache_control
from django.template.loader import render_to_string
from django.utils import timezone
from django.contrib.auth.decorators import login_required, permission_required
import json
from django.db import transaction
from django.core.exceptions import ValidationError
import logging

logger = logging.getLogger("administration_pages")
from django.core.mail import EmailMultiAlternatives, get_connection
from datetime import timedelta


from django.views.decorators.http import require_GET, require_POST
from jeiko.administration.models import WebSite
from jeiko.administration_pages.models import (
    Category, Page, Section, Line, Bloc, Strategy,
    ContentFormulaire, ContentFormField, ContentFormSubmission,
    PageInsights, InsightAuditOutcome, InsightAuditCategory,
    ContentFormulaire, ContentFormField, ContentFormSubmission,
    PageInsights, InsightAuditOutcome, InsightAuditCategory,
    DEFAULT_FORM_STYLE, validate_form_style
)

from jeiko.shop.models import ProductType
from jeiko.custom_objects.models import CustomObjectModel

from jeiko.administration_pages.utils import (
    section_duplicate, line_duplicate, bloc_duplicate, get_latest_insight, get_google_api_key
)

from jeiko.administration_pages.services.pagespeed import run_pagespeed_refresh

# ---- Mixin pour forcer les bons headers anti-cache sur TOUTES les réponses ----
class NoStoreMixin:
    def dispatch(self, request, *args, **kwargs):
        resp = super().dispatch(request, *args, **kwargs)
        if isinstance(resp, HttpResponse):
            # no-store est la clé pour éviter tout cache navigateur/proxy
            resp['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
            resp['Pragma'] = 'no-cache'
            resp['Expires'] = '0'
            # Vary Cookie pour éviter une mise en cache partagée entre users
            resp['Vary'] = 'Cookie'
        return resp


# ========== APIs ==========

@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class CategoryMainListAPI(NoStoreMixin, View):
    @method_decorator(never_cache)
    def get(self, request):
        categories = Category.objects.filter(main_category__isnull=True)
        print(categories)
        data = [{"id": c.id, "name": c.name} for c in categories]
        return JsonResponse({"categories": data})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class SubCategoryListAPI(NoStoreMixin, View):
    @method_decorator(never_cache)
    def get(self, request, category_id):
        main_category = get_object_or_404(Category, id=category_id)
        subcategories = Category.objects.filter(main_category=main_category)
        print(subcategories)
        data = [{"id": c.id, "name": c.name} for c in subcategories]
        return JsonResponse({"subcategories": data})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class ProductTypeListAPI(NoStoreMixin, View):
    @method_decorator(never_cache)
    def get(self, request):
        types = ProductType.objects.all()
        data = [{"id": t.id, "name": t.name} for t in types]
        return JsonResponse({"product_types": data})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class CustomObjectModelListAPI(NoStoreMixin, View):
    @method_decorator(never_cache)
    def get(self, request):
        models = CustomObjectModel.objects.all()
        data = [{"id": m.id, "name": m.name} for m in models]
        return JsonResponse({"models": data})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class PageListAPI(NoStoreMixin, View):
    @method_decorator(never_cache)
    def get(self, request):
        category_id = request.GET.get("category_id")
        sub_category_id = request.GET.get("sub_category_id")
        search = request.GET.get("search")

        qs = Page.objects.all()
        if sub_category_id:
            qs = qs.filter(sub_category_id=sub_category_id)
        elif category_id:
            qs = qs.filter(category_id=category_id)
        if search:
            qs = qs.filter(title__icontains=search)

        pages = [{
            "id": p.id,
            "title": p.title,
            "url_tag": p.url_tag,
            "category_id": p.category_id,
            "sub_category_id": p.sub_category_id,
            "is_protected": p.is_protected,
        } for p in qs]
        return JsonResponse({"pages": pages})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class PageGetAPI(NoStoreMixin, View):
    @method_decorator(never_cache)
    def get(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        data = {
            "id": page.id,
            "title": page.title,
            "url_tag": page.url_tag,
            "category_id": page.category_id,
            "sub_category_id": page.sub_category_id,
            "is_protected": page.is_protected,
        }
        return JsonResponse({"page": data})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class ContentFormulaireAPI(View):
    """
    GET : config complète du formulaire (métadonnées + champs + style)
    POST: MAJ des méta-infos + style partiel
    """
    def get(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        style = {**DEFAULT_FORM_STYLE, **(formulaire.style or {})}

        data = {
            "id": formulaire.id,
            "name": formulaire.name,
            "description": formulaire.description,
            "to_email": formulaire.to_email,
            "from_email": formulaire.from_email,
            "mail_subject": formulaire.mail_subject,
            "success_message": formulaire.success_message,
            "style": style,
            "fields": [{
                "id": f.id, "label": f.label, "name": f.name, "type": f.type,
                "required": f.required, "options": f.options, "order": f.order, "placeholder":f.placeholder,
            } for f in formulaire.fields.all().order_by("order", "id")]
        }
        return JsonResponse(data)

    def post(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)

        # Parse JSON body (tolère body vide)
        try:
            raw = (request.body or b"").decode("utf-8").strip()
            data = json.loads(raw) if raw else {}
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        # --- Meta classiques (partiel) ---
        for k in ("name", "description", "to_email", "from_email", "mail_subject", "success_message"):
            if k in data:
                setattr(formulaire, k, data[k])

        # --- Style (merge + validation) ---
        if "style" in data:
            if not isinstance(data["style"], dict):
                return HttpResponseBadRequest("Le champ 'style' doit être un objet JSON.")
            merged = {**(formulaire.style or {}), **data["style"]}
            try:
                validate_form_style(merged)
            except ValidationError as e:
                return HttpResponseBadRequest(f"Style invalide: {e}")
            formulaire.style = merged

        formulaire.save()

        return JsonResponse({
            "success": True,
            "message": "Formulaire mis à jour.",
            "style": {**DEFAULT_FORM_STYLE, **(formulaire.style or {})}
        })


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class ContentFormFieldAPI(NoStoreMixin, View):
    """
    GET:
      - /formulaires/<fid>/fields/              -> liste des champs (facultatif)
      - /formulaires/<fid>/fields/<field_id>/   -> détail d’un champ
    POST:
      - /formulaires/<fid>/fields/              -> création (ou update si 'id' fourni)
    PUT:
      - /formulaires/<fid>/fields/<field_id>/   -> update d’un champ
    PATCH:
      - /formulaires/<fid>/fields/              -> réordonnancement en masse [{id, order}]
    DELETE:
      - /formulaires/<fid>/fields/<field_id>/   -> suppression
    """

    # --- helpers ---
    def _normalize_options(self, opts):
        """
        Accepte:
          - liste de chaînes: ["A","B"] -> [{"value":"A","label":"A"}, ...]
          - liste de dicts: [{"value":"A","label":"Option A"}, ...] -> tel quel
          - dict map: {"A":"Option A"} -> [{"value":"A","label":"Option A"}]
          - string JSON ou "A, B, C"
        """
        if opts in (None, "", []):
            return None
        if isinstance(opts, list):
            if all(isinstance(x, str) for x in opts):
                return [{"value": x, "label": x} for x in opts]
            return opts
        if isinstance(opts, dict):
            return [{"value": k, "label": v} for k, v in opts.items()]
        if isinstance(opts, str):
            t = opts.strip()
            try:
                parsed = json.loads(t)
                return self._normalize_options(parsed)
            except Exception:
                arr = [s.strip() for s in t.split(",") if s.strip()]
                return [{"value": s, "label": s} for s in arr]
        return None

    # --- GET ---
    def get(self, request, formulaire_id, field_id=None):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)

        # détail d’un champ
        if field_id is not None:
            f = get_object_or_404(ContentFormField, pk=field_id, formulaire=formulaire)
            return JsonResponse({
                "id": f.id,
                "label": f.label,
                "name": f.name,
                "type": f.type,
                "required": f.required,
                "options": f.options,
                "order": f.order,
                "placeholder": f.placeholder,
            })

        # liste (optionnel — utile si tu veux recharger uniquement la liste)
        fields = [{
            "id": f.id, "label": f.label, "name": f.name, "type": f.type,
            "required": f.required, "options": f.options, "order": f.order, "placeholder": f.placeholder,
        } for f in formulaire.fields.all().order_by("order", "id")]
        return JsonResponse({"fields": fields})

    # --- POST create / update (compat) ---
    def post(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        try:
            data = json.loads(request.body or "{}")
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        field_id = data.get("id")
        if field_id:
            field = get_object_or_404(ContentFormField, pk=field_id, formulaire=formulaire)
        else:
            field = ContentFormField(formulaire=formulaire)

        # assign
        field.label = data.get("label", field.label)
        field.name = data.get("name", field.name)
        field.type = data.get("type", field.type)
        field.placeholder = data.get("placeholder", field.placeholder)
        field.required = data.get("required", field.required)

        opts = data.get("options", field.options)
        if field.type in ("select", "checkbox"):
            field.options = self._normalize_options(opts)
        else:
            field.options = None

        if field.pk is None:
            # nouvel item : order à la fin
            field.order = data.get("order", formulaire.fields.count())
        else:
            field.order = data.get("order", field.order)

        try:
            field.save()
        except Exception as e:
            return HttpResponseBadRequest(f"Impossible d’enregistrer le champ : {e}")

        return JsonResponse({
            "success": True,
            "field": {
                "id": field.id, "label": field.label, "name": field.name,
                "type": field.type, "required": field.required, "placeholder": field.placeholder,
                "options": field.options, "order": field.order,
            }
        })

    # --- PUT update ---
    def put(self, request, formulaire_id, field_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        field = get_object_or_404(ContentFormField, pk=field_id, formulaire=formulaire)

        try:
            data = json.loads(request.body or "{}")
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        field.label = data.get("label", field.label)
        field.name = data.get("name", field.name)
        field.type = data.get("type", field.type)
        field.placeholder = data.get("placeholder", field.placeholder)
        field.required = data.get("required", field.required)

        opts = data.get("options", field.options)
        if field.type in ("select", "checkbox"):
            field.options = self._normalize_options(opts)
        else:
            field.options = None

        field.order = data.get("order", field.order)

        try:
            field.save()
        except Exception as e:
            return HttpResponseBadRequest(f"Impossible de mettre à jour le champ : {e}")

        return JsonResponse({
            "success": True,
            "field": {
                "id": field.id, "label": field.label, "name": field.name,
                "type": field.type, "required": field.required,
                "options": field.options, "order": field.order, "placeholder": field.placeholder,
            }
        })

    # --- DELETE ---
    def delete(self, request, formulaire_id, field_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        field = get_object_or_404(ContentFormField, pk=field_id, formulaire=formulaire)
        field.delete()
        return JsonResponse({"success": True})

    # --- PATCH reorder ---
    def patch(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        try:
            data = json.loads(request.body or "{}")
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        for item in data.get("fields", []):
            try:
                f = ContentFormField.objects.get(pk=item["id"], formulaire=formulaire)
                f.order = int(item["order"])
                f.save()
            except Exception:
                continue
        return JsonResponse({"success": True})



@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class FormulaireSubmitView(NoStoreMixin, View):
    """
    POST : soumet un formulaire, enregistre et envoie un mail
    """
    def post(self, request, formulaire_id):
        formulaire = get_object_or_404(ContentFormulaire, pk=formulaire_id)
        data = request.POST.dict()

        errors, values, label_values = {}, {}, {}
        for field in formulaire.fields.all().order_by("order", "id"):
            field_name = field.name
            value = data.get(field_name, '').strip()
            values[field_name] = value
            label_values[field.label] = value
            if field.required and not value:
                errors[field_name] = "Ce champ est requis"
            if field.type == "email" and value:
                from django.core.validators import validate_email
                from django.core.exceptions import ValidationError
                try:
                    validate_email(value)
                except ValidationError:
                    errors[field_name] = "Adresse email invalide"

        if errors:
            return JsonResponse({"success": False, "errors": errors}, status=400)

        ContentFormSubmission.objects.create(
            formulaire=formulaire, data=values,
            ip_address=request.META.get('REMOTE_ADDR'),
            user_agent=request.META.get('HTTP_USER_AGENT', '')
        )

        website = WebSite.objects.first()
        config = website.mail_settings if website and website.mail_settings else None

        if formulaire.to_email and config and config.active:
            subject = formulaire.mail_subject or "Nouvelle soumission de formulaire"
            html_body = render_to_string("administration/mail/default_formulaire_email.html", {
                "subject": subject, "form_name": formulaire.name or "Formulaire de contact",
                "fields": label_values, "site_name": website.name if website else "", "now": timezone.now(),
            })
            text_body = render_to_string("administration/mail/default_formulaire_email.txt", {
                "subject": subject, "form_name": formulaire.name or "Formulaire de contact",
                "fields": label_values, "site_name": website.name if website else "", "now": timezone.now(),
            })
            connection = get_connection(
                host=config.host, port=config.port, username=config.host_user, password=config.host_password,
                use_tls=config.use_tls, use_ssl=config.use_ssl, fail_silently=False,
            )
            email = EmailMultiAlternatives(
                subject=subject, body=text_body,
                from_email=formulaire.from_email or config.default_from_email or "no-reply@monsite.com",
                to=[formulaire.to_email], connection=connection,
            )
            email.attach_alternative(html_body, "text/html")
            email.send()
        elif formulaire.to_email:
            from django.core.mail import send_mail
            subject = formulaire.mail_subject or "Nouvelle soumission de formulaire"
            message_lines = [f"{f.label}: {values.get(f.name, '')}" for f in formulaire.fields.all()]
            send_mail(subject, "\n".join(message_lines), formulaire.from_email or None, [formulaire.to_email], fail_silently=False)

        return JsonResponse({"success": True, "message": formulaire.success_message or "Merci, votre message a bien été envoyé."})


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class SectionModelCreateAPI(NoStoreMixin, View):
    """
    POST JSON {"model_name": "..."} -> duplique la section en un modèle (is_model=True)
    """
    @transaction.atomic
    def post(self, request, section_id):
        section = get_object_or_404(Section, pk=section_id)
        try:
            payload = json.loads(request.body or "{}")
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        model_name = (payload.get("model_name") or "").strip()
        if not model_name:
            return HttpResponseBadRequest("Le nom du modèle est requis")

        # Crée une COPIE de la section en tant que modèle (page=None, is_model=True)
        model_copy = section_duplicate(
            section,
            target_page=None,
            position=0,
            as_model=True,     # => is_model=True + model_source=None
            link_model=False   # on ne veut pas lier la section courante au modèle ici
        )
        model_copy.model_name = model_name
        model_copy.page = None
        model_copy.save()
        section.model_source = model_copy
        section.save()
        return JsonResponse({
            "success": True,
            "message": "Modèle créé",
            "model": {"id": model_copy.id, "name": model_copy.model_name}
        }, status=200)


# --- LINES: créer un modèle depuis une ligne existante ---
@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class LineModelCreateAPI(NoStoreMixin, View):
    """
    POST JSON {"model_name": "..."} -> duplique la ligne en un modèle (is_model=True)
    """
    @transaction.atomic
    def post(self, request, line_id):
        from jeiko.administration_pages.models import Line  # si besoin
        try:
            payload = json.loads(request.body or "{}")
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        model_name = (payload.get("model_name") or "").strip()
        if not model_name:
            return HttpResponseBadRequest("Le nom du modèle est requis")

        source_line = get_object_or_404(Line, pk=line_id)

        # On crée une COPIE de la ligne en tant que modèle (section cible = None)
        model_copy = line_duplicate(
            source_line,
            target_section=None,   # => pas rattachée à une section
            position=0,
            as_model=True,         # is_model=True sur la copie
            link_model=False       # la copie n'est pas “liée” à la source ; c'est le modèle
        )
        model_copy.model_name = model_name
        model_copy.section = None
        model_copy.save(update_fields=["model_name", "section"])

        # Optionnel : rattacher la ligne source à son modèle (trace)
        source_line.model_source = model_copy
        source_line.save(update_fields=["model_source"])

        return JsonResponse({
            "success": True,
            "message": "Modèle de ligne créé",
            "model": {"id": model_copy.id, "name": model_copy.model_name}
        }, status=200)


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(never_cache, name='dispatch')
@method_decorator(cache_control(no_store=True, no_cache=True, must_revalidate=True, max_age=0), name='dispatch')
class BlocModelCreateAPI(NoStoreMixin, View):
    """
    POST JSON {"model_name": "..."} -> duplique le bloc en un modèle (is_model=True)
    """
    @transaction.atomic
    def post(self, request, bloc_id):
        try:
            payload = json.loads(request.body or "{}")
        except Exception:
            return HttpResponseBadRequest("JSON invalide")

        model_name = (payload.get("model_name") or "").strip()
        if not model_name:
            return HttpResponseBadRequest("Le nom du modèle est requis")

        source_bloc = get_object_or_404(Bloc, pk=bloc_id)

        # Crée une COPIE du bloc en tant que modèle (line=None, is_model=True)
        model_copy = bloc_duplicate(
            source_bloc,
            target_line=None,   # modèle non rattaché à une ligne
            position=0,
            as_model=True,      # => is_model=True
            link_model=False    # on ne veut pas lier la source au modèle automatiquement
        )
        model_copy.model_name = model_name
        model_copy.line = None
        model_copy.save(update_fields=["model_name", "line"])

        # Optionnel : rattacher le bloc source à son modèle
        source_bloc.model_source = model_copy
        source_bloc.save(update_fields=["model_source"])

        return JsonResponse({
            "success": True,
            "message": "Modèle de bloc créé",
            "model": {"id": model_copy.id, "name": model_copy.model_name}
        }, status=200)






# TODO: implémenter cette fonction dans services/pagespeed.py (ou utils)
# Elle doit appeler l’API PSI pour (page, strategy), normaliser, et créer le run via create_latest_insight(...)



def _check_perm_or_403(request):
    if not request.user.has_perm("pages.view_page"):
        return False
    return True


logger = logging.getLogger(__name__)


# ---------- Lecture : derniers scores (simple) ----------

@require_GET
@login_required
@permission_required("pages.view_page", raise_exception=True)
def insights_latest(request, page_id: int):
    """
    Retourne les derniers scores Mobile & Desktop pour affichage rapide (liste admin).
    (Version simple — on sérialise ce qui existe déjà côté modèle)
    """
    page = get_object_or_404(Page, pk=page_id)

    def serialize(insight: PageInsights | None):
        if not insight:
            return None

        # Récupère les audits FAIL pour A11Y & SEO (titre + description)
        fails_qs = (
            insight.audits
            .filter(outcome=InsightAuditOutcome.FAIL,
                    category__in=[InsightAuditCategory.ACCESSIBILITY, InsightAuditCategory.SEO])
            .values("audit_id", "title", "description", "category")
        )

        a11y_issues = []
        seo_issues = []
        for row in fails_qs:
            item = {
                "id": row["audit_id"],
                "title": (row["title"] or "").strip() or row["audit_id"],
                "description": (row["description"] or "").strip(),
            }
            if row["category"] == InsightAuditCategory.ACCESSIBILITY:
                a11y_issues.append(item)
            else:
                seo_issues.append(item)

        return {
            "status": insight.status,
            "fetched_at": insight.fetched_at.isoformat() if insight.fetched_at else None,
            "url_tested": insight.url_tested,
            "scores": {
                "performance": insight.score_performance,
                "accessibility": insight.score_accessibility,
                "best_practices": insight.score_best_practices,
                "seo": insight.score_seo,
            },
            "field": {
                "lcp_ms": insight.crux_lcp_ms,
                "inp_ms": insight.crux_inp_ms,
                "cls": insight.crux_cls,
            },
            "lab": {
                "fcp_ms": insight.lab_fcp_ms,
                "lcp_ms": insight.lab_lcp_ms,
                "cls": insight.lab_cls,
                "ttfb_ms": insight.lab_ttfb_ms,
                "speed_index_ms": insight.lab_speed_index_ms,
                "tbt_ms": insight.lab_tbt_ms,
            },
            # listes d’issues lisibles par l’utilisateur
            "issues": {
                "a11y": a11y_issues,
                "seo": seo_issues,
            },
            # si tu enregistres déjà top_issues au run
            "top_issues": insight.top_issues or [],
            "error_message": insight.error_message or "",
        }

    data = {
        "page_id": page.id,
        "mobile": serialize(get_latest_insight(page, Strategy.MOBILE)),
        "desktop": serialize(get_latest_insight(page, Strategy.DESKTOP)),
    }
    return JsonResponse(data, status=200)


# ---------- Écriture : refresh PSI (simple) ----------

@require_POST
@login_required
@permission_required("pages.change_page", raise_exception=True)
def insights_refresh(request, page_id: int):
    """
    Lance un refresh PSI.
    Param `strategy`: 'mobile' | 'desktop' | 'both' (défaut: both)
    > Version minimale : pas de rate-limit ni lock. Tout le reste est géré par le service.
    """
    page = get_object_or_404(Page, pk=page_id)

    # Clé API obligatoire (vérif côté vue pour message clair)
    api_key = get_google_api_key()
    if not api_key:
        return HttpResponseBadRequest("Missing GOOGLE_PSI_API_KEY")

    # Récup des paramètres (POST/GET/JSON) de façon simple
    strategy = request.POST.get("strategy") or request.GET.get("strategy")
    if not strategy and request.content_type == "application/json":
        try:
            body = json.loads(request.body or "{}")
            strategy = body.get("strategy")
        except json.JSONDecodeError:
            pass
    strategy = (strategy or "both").lower()

    if strategy == "both":
        to_run = (Strategy.MOBILE, Strategy.DESKTOP)
    elif strategy in (Strategy.MOBILE, Strategy.DESKTOP):
        to_run = (strategy,)
    else:
        return HttpResponseBadRequest("Invalid strategy. Use 'mobile', 'desktop', or 'both'.")

    results, errors = [], []

    for s in to_run:
        try:
            insight = run_pagespeed_refresh(page, s)
            logger.info("insights_refresh OK page_id=%s strategy=%s status=%s",
                        page.id, s, insight.status)
            results.append({
                "strategy": s,
                "status": insight.status,
                "fetched_at": insight.fetched_at.isoformat() if insight.fetched_at else None,
            })
        except Exception as e:
            # On log et on renvoie l'erreur côté client sans casser les autres stratégies
            logger.exception("insights_refresh error page_id=%s strategy=%s", page.id, s)
            errors.append({"strategy": s, "error": str(e)})

    return JsonResponse({
        "ok": len(errors) == 0,
        "page_id": page.id,
        "ran": results,
        "errors": errors,
    }, status=200 if len(errors) == 0 else 207)  # 207 si partiellement OK
