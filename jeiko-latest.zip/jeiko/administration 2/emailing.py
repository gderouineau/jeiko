# jeiko/administration/emailing.py
import logging
from django.conf import settings
from django.core.mail import get_connection, EmailMultiAlternatives
from django.utils import timezone

from jeiko.administration.models import WebSite

logger = logging.getLogger(__name__)


def get_mail_connection():
    """
    Récupère la connexion SMTP d'après WebSite.mail_settings.
    Retourne (connection | None, from_email | None, reply_to | None).
    """
    site = WebSite.objects.select_related("mail_settings").first()
    ms = getattr(site, "mail_settings", None)
    
    if not ms or not ms.active:
        logger.info("Email non configuré ou inactif : aucun envoi.")
        return None, None, None

    try:
        conn = get_connection(
            backend="django.core.mail.backends.smtp.EmailBackend",
            host=ms.host,
            port=ms.port,
            username=(ms.host_user or None),
            password=(ms.host_password or None),
            use_tls=bool(ms.use_tls),
            use_ssl=bool(ms.use_ssl),
            timeout=10,
        )
    except Exception as e:
        logger.exception("Impossible d'initialiser la connexion SMTP : %s", e)
        return None, None, None

    from_email = ms.default_from_email or ms.host_user or getattr(settings, "DEFAULT_FROM_EMAIL", None)
    reply_to = [ms.reply_to_email] if ms.reply_to_email else None

    return conn, from_email, reply_to


def send_simple_email(subject, body, to_recipients, html_body=None, reply_to=None):
    print(subject)
    print(body)
    print(to_recipients)
    print(html_body)
    print(reply_to)
    """
    Envoie un email simple avec la connexion SMTP configurée.
    
    Args:
        subject: Sujet de l'email
        body: Corps de l'email en texte brut
        to_recipients: Liste des destinataires
        html_body: Version HTML de l'email (optionnel)
        reply_to: Liste d'adresses reply-to (optionnel, utilise la config par défaut si None)
    
    Returns:
        (success: bool, error_message: str or None)
    """
    conn, from_email, default_reply_to = get_mail_connection()
    
    if not conn or not from_email:
        return False, "Configuration email manquante ou inactive"
    
    if not to_recipients:
        return False, "Aucun destinataire spécifié"
    
    # Utiliser reply_to fourni ou celui par défaut
    reply_to_list = reply_to if reply_to is not None else default_reply_to
    
    try:
        print(subject)
        msg = EmailMultiAlternatives(
            subject=subject,
            body=body,
            from_email=from_email,
            to=to_recipients if isinstance(to_recipients, list) else [to_recipients],
            reply_to=reply_to_list,
            connection=conn,
        )
        
        if html_body:
            msg.attach_alternative(html_body, "text/html")
        
        msg.send()
        logger.info("Email envoyé avec succès à %s", ", ".join(to_recipients if isinstance(to_recipients, list) else [to_recipients]))
        return True, None
        
    except Exception as e:
        error_msg = str(e)
        logger.exception("Échec envoi email : %s", error_msg)
        return False, error_msg


def send_test_email():
    
    """
    Envoie un email de test pour vérifier la configuration.
    Retourne (success: bool, message: str, trace: str or None)
    """
    site = WebSite.objects.select_related("mail_settings").first()
    ms = getattr(site, "mail_settings", None)
    
    if not ms:
        return False, "Aucune configuration email trouvée", None
    
    if not ms.active:
        return False, "Configuration email inactive", None
    
    if not ms.default_from_email:
        return False, "Adresse d'expéditeur par défaut non configurée", None
    
    site_name = getattr(site.identity, "name", "Votre site") if site else "Votre site"
    subject = f"[{site_name}] Test de configuration du serveur SMTP"
    body_lines = [
        "Ceci est un email de test pour vérifier la configuration SMTP.",
        "",
        f"Site: {site_name}",
        f"Date: {timezone.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Utilisateur SMTP: {ms.host_user or 'Non configuré'}",
        f"Serveur SMTP: {ms.host or 'Non configuré'}:{ms.port or 'Non configuré'}",
        f"Adresse expéditeur: {ms.default_from_email}",
        "",
        "Si vous recevez cet email, votre configuration SMTP fonctionne correctement.",
    ]
    body = "\n".join(body_lines)
    
    # On envoie vers l'adresse par défaut et vers le user SMTP si différent
    recipients = [ms.default_from_email]
    if ms.host_user and ms.host_user not in recipients:
        recipients.append(ms.host_user)
    if ms.test_receiver and ms.test_receiver not in recipients:
        recipients.append(ms.test_receiver)
    recipients.append(ms.reply_to_email)
    try:
        success, error = send_simple_email(
            subject=subject,
            body=body,
            to_recipients=recipients
        )
        
        if success:
            return True, f"Email de test envoyé avec succès à {', '.join(recipients)}", None
        else:
            return False, f"Erreur lors de l'envoi: {error}", None
            
    except Exception as e:
        import traceback
        return False, f"Erreur lors de l'envoi de l'email: {str(e)}", traceback.format_exc()
