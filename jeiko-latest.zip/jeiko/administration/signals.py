# signals.py
from django.db.models import Q, F
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from .models import Font, Fonts, WebSite

def _bump_assets_for_websites_using_fonts(fonts_qs):
    if not fonts_qs.exists():
        return
    # Tous les sites qui pointent vers ces objets Fonts (phone/tablet/computer)
    sites_qs = WebSite.objects.filter(
        Q(fonts_phone__in=fonts_qs) |
        Q(fonts_tablet__in=fonts_qs) |
        Q(fonts_computer__in=fonts_qs)
    ).distinct()
    if sites_qs.exists():
        sites_qs.update(assets_version=F("assets_version") + 1)

def _fonts_set_from_font(font_obj: Font):
    """Retourne les objets Fonts qui référencent ce Font dans n'importe quel champ."""
    return Fonts.objects.filter(
        Q(links=font_obj) |
        Q(links_hover=font_obj) |
        Q(menu=font_obj) |
        Q(menu_hover=font_obj) |
        Q(sub_menu=font_obj) |
        Q(sub_menu_hover=font_obj) |
        Q(text=font_obj) |
        Q(h1=font_obj) | Q(h2=font_obj) | Q(h3=font_obj) |
        Q(h4=font_obj) | Q(h5=font_obj) | Q(h6=font_obj)
    )

@receiver(post_save, sender=Font)
def bump_assets_on_font_save(sender, instance, **kwargs):
    fonts_qs = _fonts_set_from_font(instance)
    _bump_assets_for_websites_using_fonts(fonts_qs)

@receiver(post_delete, sender=Font)
def bump_assets_on_font_delete(sender, instance, **kwargs):
    fonts_qs = _fonts_set_from_font(instance)
    _bump_assets_for_websites_using_fonts(fonts_qs)

@receiver(post_save, sender=Fonts)
def bump_assets_on_fonts_save(sender, instance, **kwargs):
    _bump_assets_for_websites_using_fonts(Fonts.objects.filter(pk=instance.pk))

@receiver(post_delete, sender=Fonts)
def bump_assets_on_fonts_delete(sender, instance, **kwargs):
    _bump_assets_for_websites_using_fonts(Fonts.objects.filter(pk=instance.pk))
