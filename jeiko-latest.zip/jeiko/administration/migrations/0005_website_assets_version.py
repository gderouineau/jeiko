# jeiko/administration/migrations/0005_website_assets_version.py
from django.db import migrations

def noop(*args, **kwargs):
    pass

class Migration(migrations.Migration):

    dependencies = [
        ('administration', '0004_logo_updated_at_alter_logo_full_size'),
    ]

    operations = [
        migrations.RunPython(noop, reverse_code=noop),
    ]
