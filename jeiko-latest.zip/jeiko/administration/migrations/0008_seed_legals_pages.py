from django.db import migrations


def create_legal_category(apps, schema_editor):
    Category = apps.get_model('administration_pages', 'Category')

    existing = Category.objects.filter(hidden_slug__iexact='legals').first()
    if existing:
        return
    Category.objects.create(name='Pages légales', main_category=None, hidden_slug="legals")


class Migration(migrations.Migration):

    dependencies = [
        ('administration', '0007_legals'),
        ('administration_pages', '0025_category_hidden_slug'),
        ('cookies', '0004_alter_cookiebannerconfig_style'),
    ]

    operations = [
        migrations.RunPython(create_legal_category, migrations.RunPython.noop),
    ]
