from django.urls import path
import jeiko.administration.views as views

app_name = "jeiko_administration"

urlpatterns = [

    path(
        '',
        views.Main.as_view(),
        name='main'
    ),

    path(
        'global/',
        views.GlobalView.as_view(),
        name='global_view'
    ),

    path(
        'fonts/',
        views.FontsView.as_view(),
        name="fonts_view"
    ),
    path(
        'fonts/<int:fonts_id>/titles/update',
        views.FontsTitleUpdate.as_view(),
        name="fonts_titles_update"
    ),
    path(
        'fonts/<int:fonts_id>/text/update',
        views.FontsTextUpdate.as_view(),
        name="fonts_text_update"
    ),
    path(
        'fonts/<int:fonts_id>/text/update',
        views.FontsTextUpdate.as_view(),
        name="fonts_text_update"
    ),
    path(
        'fonts/<int:fonts_id>/link/update',
        views.FontsLinkUpdate.as_view(),
        name="fonts_link_update"
    ),
    path(
        'global/logo/update',
        views.LogoUpdate.as_view(),
        name='logo_update'
    ),
    path(
        'cache/clear',
        views.ClearCache.as_view(),
        name='cache_clear',
    ),
    path(
        'email/',
        views.MailSettingsUpdateView.as_view(),
        name='mail_settings_edit'
    ),


    path(
        "update-jeiko/",
        views.UpdateJeikoView.as_view(),
        name="update_jeiko"
    ),

    path(
        "settings/google-api/",
        views.GoogleApiConfigView.as_view(),
        name="google_api_config"
    ),

    path(
        "legals/",
        views.LegalsOverviewView.as_view(),
        name="legals_view"
    ),
    path(
        "identity/",
        views.SiteIdentityView.as_view(),
        name="site_identity",
    )

]


