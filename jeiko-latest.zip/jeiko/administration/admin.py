from django.contrib import admin

from jeiko.administration.models import WebSite, Fonts, Font, Logo, GoogleApi, Legals
from .models import MailSettings


admin.site.register(WebSite)
admin.site.register(Fonts)
admin.site.register(Font)
admin.site.register(Logo)
admin.site.register(GoogleApi)
admin.site.register(Legals)

@admin.register(MailSettings)
class MailSettingsAdmin(admin.ModelAdmin):
    list_display = ("host", "port", "active")
    fieldsets = (
        (None, {
            "fields": (
                "host", "port", "host_user", "host_password",
                "use_tls", "use_ssl", "default_from_email", "reply_to_email",
                "test_receiver", "active"
            )
        }),
    )
