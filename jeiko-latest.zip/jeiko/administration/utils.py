from jeiko.administration.models import SiteIdentity, WebSite

def site_identity_jsonld(identity: SiteIdentity) -> dict:
    typ = "LocalBusiness" if identity.type == identity.TYPE_LOCAL else "Organization"
    data = {
        "@context": "https://schema.org",
        "@type": typ,
        "@id": f"{identity.url or identity.website.base_url}#org",
        "name": identity.name,
    }
    if identity.url:
        data["url"] = identity.url
    if identity.logo_url:
        data["logo"] = identity.logo_url
    if identity.telephone:
        data["telephone"] = identity.telephone
    if identity.same_as:
        data["sameAs"] = identity.same_as

    if typ == "LocalBusiness":
        # Adresse (obligatoire)
        data["address"] = {
            "@type": "PostalAddress",
            "streetAddress": identity.street_address,
            "addressLocality": identity.address_locality,
            "addressRegion": identity.address_region or "",
            "postalCode": identity.postal_code,
            "addressCountry": identity.address_country,
        }
        if identity.geo_lat and identity.geo_lng:
            data["geo"] = {"@type": "GeoCoordinates", "latitude": float(identity.geo_lat), "longitude": float(identity.geo_lng)}
        if identity.price_range:
            data["priceRange"] = identity.price_range
    return data


def get_current_website(request) -> WebSite:
    # Variante 1: un seul site
    return WebSite.objects.first()

