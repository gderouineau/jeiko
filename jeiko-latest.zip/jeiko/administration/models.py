from django.core.validators import MinValueValidator, MaxValueValidator

from io import BytesIO
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
import os
from PIL import Image
from django.db import models
from django.core.exceptions import ValidationError
from django.core.validators import URLValidator

from jeiko.administration_pages.models import Page


from django.utils import timezone
class Font(models.Model):
    size = models.CharField(
        default="20px",
        max_length=20,
        verbose_name="Taille de la police",
        help_text="Ex: 18px, 1.2em, etc."
    )
    family = models.CharField(
        default="Georgia",
        max_length=100,
        verbose_name="Famille de police",
        help_text="Ex: Roboto, Playfair Display, Arial, etc."
    )
    fallback = models.CharField(
        default="serif",
        max_length=100,
        verbose_name="Police de secours",
        help_text="Ex: serif, sans-serif, monospace, Arial… (sera utilisée si la police principale n’est pas chargée)"
    )
    stretch = models.CharField(
        default="100%",
        max_length=100,
        verbose_name="Étirement",
        help_text="Ex: 100%, condensed, expanded (optionnel)"
    )
    color = models.CharField(
        default="rgba(0,0,0,1)",
        max_length=30,
        verbose_name="Couleur de la police",
        help_text="Ex: #333, rgba(0,0,0,1)"
    )
    POLICE_STYLE_CHOICES = [
        ("normal", "normal"),
        ("italic", "italic"),
        ("oblique", "oblique"),
    ]
    style = models.CharField(
        default="normal",
        max_length=10,
        choices=POLICE_STYLE_CHOICES,
        verbose_name="Style"
    )
    variant = models.CharField(
        default="normal",
        max_length=20,
        verbose_name="Variante",
        help_text="Ex: small-caps, normal"
    )
    weight = models.CharField(
        default="normal",
        max_length=50,
        verbose_name="Épaisseur de la police",
        help_text="Ex: normal, bold, 700"
    )
    line_height = models.CharField(
        default="normal",
        max_length=50,
        verbose_name="Hauteur de ligne",
        help_text="Ex: 1.2, normal, 32px"
    )
    google_fonts_url = models.URLField(
        blank=True,
        null=True,
        verbose_name="URL Google Fonts",
        help_text="Optionnel : colle ici l’URL Google Fonts si besoin (sinon sera générée automatiquement)."
    )

    def __str__(self):
        return f"{self.family} ({self.size})"

    class Meta:
        verbose_name = "Police"
        verbose_name_plural = "Polices"


class Fonts(models.Model):

    links = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="links"
    )

    links_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="links_hover"
    )
    menu = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="menu"
    )

    menu_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="menu_hover"
    )

    sub_menu = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="sub_menu"
    )

    sub_menu_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="sub_menu_hover"
    )

    text = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="text"
    )

    h1 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h1"
    )

    h2 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h2"
    )

    h3 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h3"
    )

    h4 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h4"
    )

    h5 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h5"
    )

    h6 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h6"
    )


class Logo(models.Model):
    full_size = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name="Logo")
    computer_size = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name="Logo")
    tablet_size   = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name="Logo")
    mobile_size   = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name="Logo")

    updated_at = models.DateTimeField(auto_now=True)

    # ---------- helpers ----------
    def _variant_name(self, base_name: str, suffix: str) -> str:
        # base_name = self.full_size.name (chemin relatif au storage)
        name_no_ext, _ = os.path.splitext(base_name)  # ex: images/logo/monfichier
        return f"{name_no_ext}-{suffix}.webp"          # ex: images/logo/monfichier-computer.webp

    def _save_webp(self, img: Image.Image, size: tuple[int, int], target_name: str) -> str:
        # préserver l’alpha
        if img.mode not in ("RGBA", "LA"):
            img = img.convert("RGBA")
        # copier l’original avant thumbnail (pour éviter cascade de thumbnails)
        variant = img.copy()
        variant.thumbnail(size, Image.LANCZOS)

        buf = BytesIO()
        # WebP supporte la transparence ; ajuste quality/method si besoin
        variant.save(buf, format="WEBP", quality=85, method=6)
        buf.seek(0)

        # Écrire via le storage (portable: local, S3…)
        if default_storage.exists(target_name):
            default_storage.delete(target_name)
        default_storage.save(target_name, ContentFile(buf.read()))
        return target_name  # chemin relatif (à assigner à .name)

    # ---------- save ----------
    def save(self, *args, **kwargs):
        # 1) sauvegarder d’abord pour garantir full_size.path/.name
        super().save(*args, **kwargs)

        # 2) régénérer les variantes si on a un original
        if self.full_size and self.full_size.name:
            base_name = self.full_size.name   # chemin relatif, ex: images/logo/monfichier.png
            base_img  = Image.open(self.full_size.path)

            computer_name = self._variant_name(base_name, "computer")
            tablet_name   = self._variant_name(base_name, "tablet")
            mobile_name   = self._variant_name(base_name, "mobile")

            comp_rel = self._save_webp(base_img, (150, 150), computer_name)
            tab_rel  = self._save_webp(base_img, (100, 100), tablet_name)
            mob_rel  = self._save_webp(base_img, (75, 75),  mobile_name)

            # 3) assigner .name (PAS .url)
            self.computer_size.name = comp_rel
            self.tablet_size.name   = tab_rel
            self.mobile_size.name   = mob_rel

            # 4) sauver uniquement les champs modifiés (updated_at bouge aussi)
            super().save(update_fields=["computer_size", "tablet_size", "mobile_size", "updated_at"])


class MailSettings(models.Model):
    # Utilisation d’un singleton, une seule config par site
    host = models.CharField(max_length=200, verbose_name="Serveur SMTP")
    port = models.PositiveIntegerField(
        default=587, validators=[MinValueValidator(1), MaxValueValidator(65535)],
        verbose_name="Port SMTP"
    )
    use_tls = models.BooleanField(default=True, verbose_name="Utiliser TLS")
    use_ssl = models.BooleanField(default=False, verbose_name="Utiliser SSL")
    host_user = models.CharField(max_length=200, blank=True, verbose_name="Nom d’utilisateur SMTP")
    host_password = models.CharField(max_length=200, blank=True, verbose_name="Mot de passe SMTP")
    default_from_email = models.CharField(max_length=200, blank=True, verbose_name="Adresse expéditeur par défaut")
    reply_to_email = models.CharField(max_length=200, blank=True, verbose_name="Adresse reply-to (optionnelle)")
    active = models.BooleanField(default=True, verbose_name="Actif")
    test_receiver = models.CharField(max_length=200, blank=True, verbose_name="Email de test (pour bouton 'Tester')")

    class Meta:
        verbose_name = "Configuration Email"
        verbose_name_plural = "Configuration Email"

    def __str__(self):
        return f"Mail SMTP ({self.host}:{self.port}) pour {self.website.name}"


class WebSite(models.Model):

    name = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        default="Jeiko",
    )
    fonts_phone = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_phone',
        null=True
    )

    fonts_tablet = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_tablet',
        null=True
    )

    fonts_computer = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_computer',
        null=True
    )

    logo = models.OneToOneField(
        Logo,
        on_delete=models.CASCADE,
        related_name='site',
        null=True,
    )

    mail_settings = models.OneToOneField(
        "MailSettings",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name="website",
        verbose_name="Configuration Email"
    )

    assets_version = models.IntegerField(
        default=1
    )


class SiteIdentity(models.Model):
    TYPE_ORG = "organization"
    TYPE_LOCAL = "localbusiness"
    TYPE_CHOICES = [
        (TYPE_ORG, "Organization"),
        (TYPE_LOCAL, "LocalBusiness"),
    ]

    website = models.OneToOneField("administration.WebSite", on_delete=models.CASCADE, related_name="identity")
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, default=TYPE_ORG)

    # Commun (recommandé / utile)
    name = models.CharField(max_length=200)                 # Required si LocalBusiness, recommandé si Organization
    url = models.URLField(blank=True)                       # Recommandé
    telephone = models.CharField(max_length=50, blank=True) # Recommandé

    # Adresse (obligatoire si LocalBusiness)
    street_address = models.CharField(max_length=255, blank=True)
    address_locality = models.CharField(max_length=120, blank=True)
    address_region = models.CharField(max_length=120, blank=True)
    postal_code = models.CharField(max_length=20, blank=True)
    address_country = models.CharField(max_length=2, blank=True)  # ISO-3166-1 alpha-2 (FR, CH, etc.)

    # Extras utiles (facultatifs)
    geo_lat = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    geo_lng = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    price_range = models.CharField(max_length=10, blank=True)     # ex: €, €€, €€€

    created_at = models.DateTimeField(default=timezone.now, editable=False)
    updated_at = models.DateTimeField(auto_now=True)


    class Meta:
        verbose_name = "Identité du site"
        verbose_name_plural = "Identités du site"

    def clean(self):
        if self.type == self.TYPE_LOCAL:
            missing = [f for f in ["name","street_address","address_locality","postal_code","address_country"] if not getattr(self, f)]
            if missing:
                raise ValidationError(
                    "LocalBusiness nécessite name + adresse complète (street/locality/postal_code/country)."
                )

    def __str__(self):
        return f"{self.get_type_display()} — {self.name or 'sans nom'}"


class GoogleApi(models.Model):
    """
    Réglages globaux pour les APIs Google (clé PSI, Search Console...).
    On ne garde qu'une seule configuration.
    """
    name = models.CharField(
        max_length=100,
        default="Default"
    )
    psi_api_key = models.CharField(
        "PageSpeed Insights API key",
        max_length=300,
        blank=True,
        default="",
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Configuration Google API"
        verbose_name_plural = "Configuration Google API"

    def __str__(self):
        return self.name

    @classmethod
    def get_solo(cls):
        obj, _ = cls.objects.get_or_create(pk=1, defaults={"name": "Default"})
        return obj



class Legals(models.Model):
    """
    Un jeu de pages légales par site.
    Les FK sont PROTECT pour empêcher la suppression d'une Page liée.
    """
    site = models.OneToOneField(
        WebSite,
        on_delete=models.CASCADE,
        related_name="legals",
        verbose_name="Site",
    )

    privacy_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_privacy_page_for",
        verbose_name="Page RGPD/Privacy",

    )
    cgv_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_cgv_page_for",
        verbose_name="Page CGV",
    )
    cgu_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_cgu_page_for",
        verbose_name="Page CGU",
    )
    mentions_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_mentions_page_for",
        verbose_name="Page Mentions légales",
    )

    class Meta:
        verbose_name = "Pages légales"
        verbose_name_plural = "Pages légales"
        ordering = ["site__name"]

    def __str__(self):
        return f"Pages légales — {self.site.name}"


    @property
    def all_links(self):
        return {
            "privacy": getattr(self.privacy_page, "get_absolute_url", lambda: None)(),
            "cgv": getattr(self.cgv_page, "get_absolute_url", lambda: None)(),
            "cgu": getattr(self.cgu_page, "get_absolute_url", lambda: None)(),
            "mentions": getattr(self.mentions_page, "get_absolute_url", lambda: None)(),
        }


PLATFORM_CHOICES = [
    # Social “généraux”
    ("facebook", "Facebook"),
    ("instagram", "Instagram"),
    ("x", "X (Twitter)"),
    ("threads", "Threads"),
    ("bluesky", "Bluesky"),
    ("tiktok", "TikTok"),
    ("snapchat", "Snapchat"),
    ("pinterest", "Pinterest"),
    ("linkedin", "LinkedIn"),
    ("youtube", "YouTube"),
    ("vimeo", "Vimeo"),
    ("reddit", "Reddit"),
    ("tumblr", "Tumblr"),
    ("mastodon", "Mastodon"),
    # Messageries / communautés
    ("whatsapp", "WhatsApp"),
    ("telegram", "Telegram"),
    ("signal", "Signal"),
    ("messenger", "Facebook Messenger"),
    ("discord", "Discord"),
    ("slack", "Slack"),
    # Créateurs / portfolio
    ("dribbble", "Dribbble"),
    ("behance", "Behance"),
    ("medium", "Medium"),
    ("substack", "Substack"),
    # Dev / produit
    ("github", "GitHub"),
    ("gitlab", "GitLab"),
    ("bitbucket", "Bitbucket"),
    ("producthunt", "Product Hunt"),
    ("wellfound", "Wellfound (AngelList)"),
    # Musique / audio
    ("spotify", "Spotify"),
    ("applemusic", "Apple Music"),
    ("deezer", "Deezer"),
    ("soundcloud", "SoundCloud"),
    ("twitch", "Twitch"),
    # Avis / annuaires
    ("googlebusiness", "Google Business Profile"),
    ("tripadvisor", "Tripadvisor"),
    ("yelp", "Yelp"),
    ("trustpilot", "Trustpilot"),
    ("glassdoor", "Glassdoor"),
    ("indeed", "Indeed"),
    ("houzz", "Houzz"),
    # E-commerce / marketplaces
    ("etsy", "Etsy"),
    ("amazon", "Amazon Store"),
    # Réseaux FR / divers
    ("viadeo", "Viadeo"),
    ("vk", "VK"),
    # Liens utilitaires
    ("email", "E-mail"),
    ("phone", "Téléphone"),
    ("website", "Site (autre)"),
    # Personnalisé
    ("custom", "Personnalisé"),
]


class SocialLink(models.Model):
    """
    Un lien social associé à un site (WebSite).
    Icônes 100% locales :
      - par défaut : SVG livré en static (jeiko/icons/social/<platform>.svg)
      - override possible : upload raster -> génération WebP 48/32/24
      - override possible : upload SVG custom (utilisé tel quel)
    """
    website = models.ForeignKey("administration.WebSite", on_delete=models.CASCADE, related_name="social_links")
    platform = models.CharField(max_length=32, choices=PLATFORM_CHOICES, default="instagram")
    profile_url = models.URLField(validators=[URLValidator()], blank=True, default="")
    handle = models.CharField(max_length=120, blank=True, default="")  # @pseudo, si utile à l'affichage
    display_name = models.CharField(max_length=120, blank=True, default="")  # texte alternatif à montrer
    position = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    aria_label = models.CharField(max_length=140, blank=True, default="")  # pour accessibilité

    # --- Overrides d’icône (OPTIONNELS) ---
    # 1) SVG custom (recommandé pour teinter via CSS currentColor)
    icon_svg = models.FileField(upload_to="images/social/svg", null=True, blank=True)

    # 2) Raster custom → on génère 3 variantes WebP 48/32/24 (fond transparent conservé)
    icon_raster_source = models.ImageField(upload_to="images/social/src", null=True, blank=True)
    icon_48 = models.ImageField(upload_to="images/social/variants", null=True, blank=True, editable=False)
    icon_32 = models.ImageField(upload_to="images/social/variants", null=True, blank=True, editable=False)
    icon_24 = models.ImageField(upload_to="images/social/variants", null=True, blank=True, editable=False)

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["position", "id"]
        verbose_name = "Lien social"
        verbose_name_plural = "Liens sociaux"
        constraints = [
            models.UniqueConstraint(fields=["website", "platform", "profile_url"], name="uniq_social_per_site_and_url"),
        ]

    def __str__(self):
        base = self.get_platform_display()
        return f"{base} — {self.display_name or self.handle or self.profile_url or 'sans URL'}"

    # ---------- helpers generation ----------
    def _variant_name(self, base_name: str, suffix: str) -> str:
        name_no_ext, _ = os.path.splitext(base_name)   # ex: images/social/src/monfichier
        return f"{name_no_ext}-{suffix}.webp"          # ex: images/social/src/monfichier-48.webp

    def _save_webp(self, img: Image.Image, size: int, target_name: str) -> str:
        if img.mode not in ("RGBA", "LA"):
            img = img.convert("RGBA")
        variant = img.copy()
        variant.thumbnail((size, size), Image.LANCZOS)

        buf = BytesIO()
        variant.save(buf, format="WEBP", quality=85, method=6)
        buf.seek(0)

        if default_storage.exists(target_name):
            default_storage.delete(target_name)
        default_storage.save(target_name, ContentFile(buf.read()))
        return target_name

    def save(self, *args, **kwargs):
        # 1) sauvegarder d’abord pour garantir .path/.name
        super().save(*args, **kwargs)

        # 2) si on a une source raster, (re)générer les variantes
        if self.icon_raster_source and self.icon_raster_source.name:
            base_name = self.icon_raster_source.name
            try:
                base_img = Image.open(self.icon_raster_source.path)
            except Exception:
                return  # si format non supporté par PIL

            name_48 = self._variant_name(base_name, "48")
            name_32 = self._variant_name(base_name, "32")
            name_24 = self._variant_name(base_name, "24")

            rel_48 = self._save_webp(base_img, 48, name_48)
            rel_32 = self._save_webp(base_img, 32, name_32)
            rel_24 = self._save_webp(base_img, 24, name_24)

            # assigner .name (PAS .url)
            self.icon_48.name = rel_48
            self.icon_32.name = rel_32
            self.icon_24.name = rel_24

            super().save(update_fields=["icon_48", "icon_32", "icon_24", "updated_at"])

    # ---------- accès icône ----------
    def get_icon_static_path(self) -> str:
        """
        Fallback local → chemin static attendu pour l’icône SVG par défaut.
        À placer dans: static/jeiko/icons/social/<platform>.svg
        """
        return f"jeiko/icons/social/{self.platform}.svg"

    def has_svg(self) -> bool:
        return bool(self.icon_svg)

    def has_raster_variants(self) -> bool:
        return bool(self.icon_24 and self.icon_24.name and self.icon_32 and self.icon_48)

    def get_best_icon(self, size: int = 24):
        """
        Retourne un tuple (type, url) où type ∈ {'svg','img'}
          - 'svg' => chemin static (ou override SVG)
          - 'img' => URL d’une variante raster (webp)
        size ∈ {24, 32, 48}
        """
        # 1) SVG custom prioritaire
        if self.icon_svg and hasattr(self.icon_svg, "url"):
            return ("svg", self.icon_svg.url)

        # 2) Variantes raster custom
        if self.has_raster_variants():
            if size <= 24 and self.icon_24 and self.icon_24.url:
                return ("img", self.icon_24.url)
            if size <= 32 and self.icon_32 and self.icon_32.url:
                return ("img", self.icon_32.url)
            return ("img", self.icon_48.url)

        # 3) SVG par défaut en static
        # (la template utilisera {% static path %})
        return ("svg", self.get_icon_static_path())