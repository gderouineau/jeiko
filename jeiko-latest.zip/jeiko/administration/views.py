import os, sys
import subprocess
from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required

from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic.base import TemplateView
from django.views.generic.edit import UpdateView
from django.urls import reverse_lazy


from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache

from .models import WebSite, Fonts, Logo, MailSettings
from .forms import FontForm, LogoForm, MailSettingsForm

decorators = [never_cache]


class Main(TemplateView):
    template_name = 'administration/main.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        context = {

        }

        return render(request, self.template_name, context)

class GlobalView(TemplateView):

    template_name = "administration/global/main.html"

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        context = {

        }

        return render(request, self.template_name, context)


class FontsView(View):

    template_name = "administration/fonts/view.html"

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        web_site = WebSite.objects.all().first()

        context = {
            'web_site': web_site,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        pass


class FontsUpdate(View):
    template_name = "administration/fonts/update.html"

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        pass

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        cache.clear()
        pass


class FontsTitleUpdate(View):
    template_name = "administration/fonts/update_title.html"
    font_form = FontForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        h1_form = self.font_form(
            instance=fonts.h1,
            prefix='h1_',
        )
        h2_form = self.font_form(
            instance=fonts.h2,
            prefix='h2_',
        )
        h3_form = self.font_form(
            instance=fonts.h3,
            prefix='h3_',
        )
        h4_form = self.font_form(
            instance=fonts.h4,
            prefix='h4_',
        )
        h5_form = self.font_form(
            instance=fonts.h5,
            prefix='h5_',
        )
        h6_form = self.font_form(
            instance=fonts.h6,
            prefix='h6_',
        )

        context = {
            'fonts': fonts,
            'h1_form': h1_form,
            'h2_form': h2_form,
            'h3_form': h3_form,
            'h4_form': h4_form,
            'h5_form': h5_form,
            'h6_form': h6_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        h1_form = self.font_form(
            request.POST,
            instance=fonts.h1,
            prefix='h1_',
        )
        h2_form = self.font_form(
            request.POST,
            instance=fonts.h2,
            prefix='h2_',
        )
        h3_form = self.font_form(
            request.POST,
            instance=fonts.h3,
            prefix='h3_',
        )
        h4_form = self.font_form(
            request.POST,
            instance=fonts.h4,
            prefix='h4_',
        )
        h5_form = self.font_form(
            request.POST,
            instance=fonts.h5,
            prefix='h5_',
        )
        h6_form = self.font_form(
            request.POST,
            instance=fonts.h6,
            prefix='h6_',
        )

        if h1_form.is_valid() \
                and h2_form.is_valid() \
                and h3_form.is_valid() \
                and h4_form.is_valid() \
                and h5_form.is_valid() \
                and h6_form.is_valid:

            h1 = h1_form.save()
            h2 = h2_form.save()
            h3 = h3_form.save()
            h4 = h4_form.save()
            h5 = h5_form.save()
            h6 = h6_form.save()

            fonts.h1 = h1
            fonts.h2 = h2
            fonts.h3 = h3
            fonts.h4 = h4
            fonts.h5 = h5
            fonts.h6 = h6

            fonts.save()

            cache.clear()
            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'h1_form': h1_form,
            'h2_form': h2_form,
            'h3_form': h3_form,
            'h4_form': h4_form,
            'h5_form': h5_form,
            'h6_form': h6_form,
        }
        return render(request, self.template_name, context)


class FontsTextUpdate(View):
    template_name = "administration/fonts/update_text.html"
    text_form = FontForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        text_form = self.text_form(
            instance=fonts.text,
            prefix='text_',
        )


        context = {
            'fonts': fonts,
            'text_form': text_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        text_form = self.text_form(
            request.POST,
            instance=fonts.text,
            prefix='text_',
        )



        if text_form.is_valid():


            text = text_form.save()


            fonts.text = text


            fonts.save()

            cache.clear()
            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'text_form': text_form,

        }
        return render(request, self.template_name, context)


class FontsLinkUpdate(View):

    template_name = "administration/fonts/update_link.html"
    form = FontForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        link_form = self.form(
            instance=fonts.links,
            prefix='link_',
        )
        link_hover_form = self.form(
            instance=fonts.links_hover,
            prefix='link_hover_',

        )


        context = {
            'fonts': fonts,
            'link_form': link_form,
            'link_hover_form': link_hover_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        link_form = self.form(
            request.POST,
            instance=fonts.links,
            prefix='link_',
        )
        link_hover_form = self.form(
            request.POST,
            instance=fonts.links_hover,
            prefix='link_hover_',

        )



        if link_form.is_valid() and link_hover_form.is_valid():


            link = link_form.save()
            link_hover = link_hover_form.save()


            fonts.links = link
            fonts.links_hover = link_hover


            fonts.save()

            cache.clear()
            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'link_form': link_form,
            'link_hover_form': link_hover_form,

        }
        return render(request, self.template_name, context)


class LogoUpdate(View):

    template_name = 'administration/logo/update.html'
    logo_form = LogoForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        website = WebSite.objects.all().first()

        if not website.logo:
            logo = Logo()
            logo.save()
            website.logo = logo
            website.save()
        else:
            logo = website.logo

        logo_form = self.logo_form(
            instance=logo,
            prefix='logo_'
        )

        context = {
            'logo_form': logo_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        website = WebSite.objects.all().first()

        logo = website.logo

        logo_form = self.logo_form(
            request.POST,
            request.FILES,
            instance=logo,
            prefix='logo_',
        )

        if logo_form.is_valid():
            logo = logo_form.save(commit=False)
            website.logo = logo
            website.save()
            logo.save()
            return redirect('jeiko_administration:global_view')

        context = {
            'logo_form': logo_form,
        }

        return render(request, self.template_name, context)


class ClearCache(View):

    @method_decorator(never_cache)
    def get(self, request, *args, ** kwargs):
        next_url = request.GET.get('next', '/')

        cache.clear()

        return redirect(next_url)


@method_decorator(never_cache, name='dispatch')
class MailSettingsUpdateView(UpdateView):
    model = MailSettings
    form_class = MailSettingsForm
    template_name = "administration/mail/settings_form.html"

    def get_object(self, queryset=None):
        # Ici, tu récupères la config liée au site courant (à adapter si multisite)
        website = WebSite.objects.first()  # ou récupère selon l'utilisateur/site courant
        mail_settings, created = MailSettings.objects.get_or_create(pk=getattr(website, "mail_settings_id", None))
        if not website.mail_settings:
            website.mail_settings = mail_settings
            website.save()
        return mail_settings

    def get_success_url(self):
        return reverse_lazy("jeiko_administration:main")  # à adapter à ton url





@method_decorator(staff_member_required, name='dispatch')
class UpdateJeikoView(TemplateView):
    template_name = "administration/update/form.html"

    def post(self, request, *args, **kwargs):
        BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        script_path = os.path.join(BASE_DIR, 'scripts', 'update_jeiko.sh')

        if not os.path.isfile(script_path):
            return render(request, "administration/update/result.html", {
                "output": "",
                "error": f"Script introuvable à {script_path}",
                "success": False,
            })

        try:
            result = subprocess.run(
                ["/bin/bash", script_path],
                capture_output=True,
                text=True,
                check=True
            )
            return render(request, "administration/update/result.html", {
                "output": result.stdout,
                "error": result.stderr,
                "success": True,
            })

        except subprocess.CalledProcessError as e:
            return render(request, "administration/update/result.html", {
                "output": e.stdout,
                "error": e.stderr,
                "success": False,
            })
