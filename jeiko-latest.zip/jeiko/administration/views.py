import os, sys
import subprocess
from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic.base import TemplateView
from django.views.generic.edit import UpdateView
from django.urls import reverse_lazy, reverse, NoReverseMatch

from django.http import HttpResponse, JsonResponse
from django.views.decorators.http import require_GET

from django.db.models import Q

from django.contrib import messages

from xml.sax.saxutils import escape as xml_escape

from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache, cache_control

from .models import (
    WebSite,
    Fonts, Logo, Font,
    MailSettings, GoogleApi,
    Legals, SiteIdentity
)
from .forms import (
    FontForm, LogoForm,
    MailSettingsForm, FontFamilyUpdateAllForm,
    GoogleApiForm,
    LegalsAdminForm,
    SiteIdentityForm,
)

from .utils import get_current_website


decorators = [never_cache]

from jeiko.administration_pages.models import Page


class Main(LoginRequiredMixin, TemplateView):
    template_name = 'administration/main.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        context = {

        }

        return render(request, self.template_name, context)


class GlobalView(LoginRequiredMixin, TemplateView):

    template_name = "administration/global/main.html"

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        context = {

        }

        return render(request, self.template_name, context)


class FontsView(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration/fonts/view.html"

    permission_required = "users.admincfg_change_fonts"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        web_site = WebSite.objects.all().first()
        form = FontFamilyUpdateAllForm()

        context = {
            "web_site": web_site,
            "form": form,
            "fonts_count": Font.objects.count(),
            "families": Font.objects.values_list("family", flat=True).distinct().order_by("family"),
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        form = FontFamilyUpdateAllForm(request.POST)
        if not form.is_valid():
            web_site = WebSite.objects.all().first()
            context = {
                "web_site": web_site,
                "form": form,
                "fonts_count": Font.objects.count(),
                "families": Font.objects.values_list("family", flat=True).distinct().order_by("family"),
            }
            return render(request, self.template_name, context)

        family = form.cleaned_data["family"]
        updated = Font.objects.update(family=family)
        messages.success(request, f"Famille « {family} » appliquée à {updated} police(s).")
        return redirect(request.path)


class FontsUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration/fonts/update.html"

    permission_required = "users.admincfg_change_fonts"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        pass

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        cache.clear()
        pass


class FontsTitleUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration/fonts/update_title.html"
    font_form = FontForm

    permission_required = "users.admincfg_change_fonts"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        h1_form = self.font_form(
            instance=fonts.h1,
            prefix='h1_',
        )
        h2_form = self.font_form(
            instance=fonts.h2,
            prefix='h2_',
        )
        h3_form = self.font_form(
            instance=fonts.h3,
            prefix='h3_',
        )
        h4_form = self.font_form(
            instance=fonts.h4,
            prefix='h4_',
        )
        h5_form = self.font_form(
            instance=fonts.h5,
            prefix='h5_',
        )
        h6_form = self.font_form(
            instance=fonts.h6,
            prefix='h6_',
        )

        context = {
            'fonts': fonts,
            'h1_form': h1_form,
            'h2_form': h2_form,
            'h3_form': h3_form,
            'h4_form': h4_form,
            'h5_form': h5_form,
            'h6_form': h6_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        h1_form = self.font_form(
            request.POST,
            instance=fonts.h1,
            prefix='h1_',
        )
        h2_form = self.font_form(
            request.POST,
            instance=fonts.h2,
            prefix='h2_',
        )
        h3_form = self.font_form(
            request.POST,
            instance=fonts.h3,
            prefix='h3_',
        )
        h4_form = self.font_form(
            request.POST,
            instance=fonts.h4,
            prefix='h4_',
        )
        h5_form = self.font_form(
            request.POST,
            instance=fonts.h5,
            prefix='h5_',
        )
        h6_form = self.font_form(
            request.POST,
            instance=fonts.h6,
            prefix='h6_',
        )

        if h1_form.is_valid() \
                and h2_form.is_valid() \
                and h3_form.is_valid() \
                and h4_form.is_valid() \
                and h5_form.is_valid() \
                and h6_form.is_valid:

            h1 = h1_form.save()
            h2 = h2_form.save()
            h3 = h3_form.save()
            h4 = h4_form.save()
            h5 = h5_form.save()
            h6 = h6_form.save()

            fonts.h1 = h1
            fonts.h2 = h2
            fonts.h3 = h3
            fonts.h4 = h4
            fonts.h5 = h5
            fonts.h6 = h6

            fonts.save()

            cache.clear()
            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'h1_form': h1_form,
            'h2_form': h2_form,
            'h3_form': h3_form,
            'h4_form': h4_form,
            'h5_form': h5_form,
            'h6_form': h6_form,
        }
        return render(request, self.template_name, context)


class FontsTextUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration/fonts/update_text.html"
    text_form = FontForm

    permission_required = "users.admincfg_change_fonts"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        text_form = self.text_form(
            instance=fonts.text,
            prefix='text_',
        )


        context = {
            'fonts': fonts,
            'text_form': text_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        text_form = self.text_form(
            request.POST,
            instance=fonts.text,
            prefix='text_',
        )



        if text_form.is_valid():


            text = text_form.save()


            fonts.text = text


            fonts.save()

            cache.clear()
            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'text_form': text_form,

        }
        return render(request, self.template_name, context)


class FontsLinkUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):

    template_name = "administration/fonts/update_link.html"
    form = FontForm

    permission_required = "users.admincfg_change_fonts"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        link_form = self.form(
            instance=fonts.links,
            prefix='link_',
        )
        link_hover_form = self.form(
            instance=fonts.links_hover,
            prefix='link_hover_',

        )


        context = {
            'fonts': fonts,
            'link_form': link_form,
            'link_hover_form': link_hover_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        link_form = self.form(
            request.POST,
            instance=fonts.links,
            prefix='link_',
        )
        link_hover_form = self.form(
            request.POST,
            instance=fonts.links_hover,
            prefix='link_hover_',

        )



        if link_form.is_valid() and link_hover_form.is_valid():


            link = link_form.save()
            link_hover = link_hover_form.save()


            fonts.links = link
            fonts.links_hover = link_hover


            fonts.save()

            cache.clear()
            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'link_form': link_form,
            'link_hover_form': link_hover_form,

        }
        return render(request, self.template_name, context)


class LogoUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):

    template_name = 'administration/logo/update.html'
    logo_form = LogoForm

    permission_required = "users.admincfg_change_website"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        website = WebSite.objects.all().first()

        if not website.logo:
            logo = Logo()
            logo.save()
            website.logo = logo
            website.save()
        else:
            logo = website.logo

        logo_form = self.logo_form(
            instance=logo,
            prefix='logo_'
        )

        context = {
            'logo_form': logo_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        website = WebSite.objects.all().first()

        logo = website.logo

        logo_form = self.logo_form(
            request.POST,
            request.FILES,
            instance=logo,
            prefix='logo_',
        )

        if logo_form.is_valid():
            logo = logo_form.save(commit=False)
            website.logo = logo
            website.save()
            logo.save()
            return redirect('jeiko_administration:global_view')

        context = {
            'logo_form': logo_form,
        }

        return render(request, self.template_name, context)


class ClearCache(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = "users.admincfg_clear_cache"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, ** kwargs):
        next_url = request.GET.get('next', '/')

        cache.clear()

        return redirect(next_url)


def _page_path(page: Page) -> str:
    """Construit le chemin public d'une page.
    Hypothèse: racine = '/', sinon '/<url_tag>/'."""
    return "/" if page.is_root else f"/{page.url_tag.strip('/')}/"



def _canon_path_from_page(page):
    """
    Retourne un chemin canonique normalisé (leading & trailing slash).
    Utilise get_absolute_url() si disponible, sinon tente _page_path(page).
    """
    url = "/"
    if hasattr(page, "get_absolute_url"):
        url = page.get_absolute_url() or "/"
    else:
        try:
            # Compat rétro si _page_path existe dans le projet
            url = _page_path(page) or "/"
        except NameError:
            url = "/"

    if not url.startswith("/"):
        url = "/" + url
    if not url.endswith("/"):
        url = url + "/"
    return url


@require_GET
@cache_control(public=True, max_age=3600)  # 1h
def robots_txt(request):
    """
    Robots.txt minimaliste, sans Allow par page.
    Option globale : settings.JEIKO_ROBOTS_DISALLOW_ALL = True -> Disallow: /
    """
    if getattr(settings, "JEIKO_ROBOTS_DISALLOW_ALL", False):
        content = "User-agent: *\nDisallow: /\n"
        return HttpResponse(content, content_type="text/plain; charset=utf-8")

    lines = [
        "User-agent: *",
        "Disallow: /admin/",
        "Disallow: /administration/",
        "Disallow: /jeiko/administration/",
        "Disallow: /pass-test/",
    ]

    # Pages non indexables -> Disallow (hors racine)
    blocked_pages = Page.objects.filter(Q(active=False) | Q(google_index=False))
    disallow_paths = set()
    for p in blocked_pages:
        path = p.get_absolute_url()
        if path != "/":
            disallow_paths.add(path)

    for path in sorted(disallow_paths):
        lines.append(f"Disallow: {path}")

    # Sitemap si présent
    try:
        sm_url = request.build_absolute_uri(reverse("sitemap_xml"))
        lines.append(f"Sitemap: {sm_url}")
    except NoReverseMatch:
        pass

    content = "\n".join(lines) + "\n"
    return HttpResponse(content, content_type="text/plain; charset=utf-8")


@require_GET
@cache_control(public=True, max_age=3600)  # 1h
def sitemap_xml(request):
    """
    Sitemap des pages actives & indexables.
    Si besoin >50k URLs ou >50Mo, passer à un sitemap index.
    """
    pages = (
        Page.objects
        .filter(active=True, google_index=True)
        .select_related("category", "sub_category", "sub_category__main_category")
        .order_by("id")
    )

    base = request.build_absolute_uri("/")[:-1]  # https://domaine.tld (sans slash final)

    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
    ]

    for p in pages:
        loc_url = f"{base}{p.get_absolute_url()}"
        loc = xml_escape(loc_url)

        # lastmod : updated_at prioritaire si dispo, sinon date_created
        lastmod = None
        if hasattr(p, "updated_at") and getattr(p, "updated_at"):
            try:
                lastmod = p.updated_at.date().isoformat()
            except Exception:
                pass
        if not lastmod and hasattr(p, "date_created") and getattr(p, "date_created"):
            try:
                lastmod = p.date_created.date().isoformat()
            except Exception:
                pass

        lines.append("  <url>")
        lines.append(f"    <loc>{loc}</loc>")
        if lastmod:
            lines.append(f"    <lastmod>{lastmod}</lastmod>")
        # lines.append("    <changefreq>weekly</changefreq>")
        # lines.append("    <priority>0.5</priority>")
        lines.append("  </url>")

    lines.append("</urlset>")
    xml = "\n".join(lines)
    return HttpResponse(xml, content_type="application/xml; charset=utf-8")



@method_decorator(never_cache, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class MailSettingsUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = MailSettings
    form_class = MailSettingsForm
    template_name = "administration/mail/settings_form.html"

    permission_required = "users.admincfg_change_mailsettings"
    raise_exception = True

    def get_object(self, queryset=None):
        # Ici, tu récupères la config liée au site courant (à adapter si multisite)
        website = WebSite.objects.first()  # ou récupère selon l'utilisateur/site courant
        mail_settings, created = MailSettings.objects.get_or_create(pk=getattr(website, "mail_settings_id", None))
        if not website.mail_settings:
            website.mail_settings = mail_settings
            website.save()
        return mail_settings

    def get_success_url(self):
        return reverse_lazy("jeiko_administration:main")  # à adapter à ton url


@method_decorator(staff_member_required, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class UpdateJeikoView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    template_name = "administration/update/form.html"

    permission_required = "users.admincfg_change_website"
    raise_exception = True

    def post(self, request, *args, **kwargs):
        BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        script_path = os.path.join(BASE_DIR, 'scripts', 'update_jeiko.sh')

        if not os.path.isfile(script_path):
            return render(request, "administration/update/result.html", {
                "output": "",
                "error": f"Script introuvable à {script_path}",
                "success": False,
            })
        env = os.environ.copy()
        env["JEIKO_MANAGE_DIR"] = str(settings.BASE_DIR)
        env["JEIKO_FIX_VENV_OWNERSHIP"] = "1"

        try:
            result = subprocess.run(
                ["sudo", str(script_path)],
                capture_output=True,
                text=True,
                check=True,
                env=env,
            )
            return render(request, "administration/update/result.html", {
                "output": result.stdout,
                "error": result.stderr,
                "success": True,
            })

        except subprocess.CalledProcessError as e:
            return render(request, "administration/update/result.html", {
                "output": e.stdout,
                "error": e.stderr,
                "success": False,
            })


@method_decorator(staff_member_required, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class GoogleApiConfigView(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration/google_api/config.html"
    permission_required = "users.admincfg_change_website"
    raise_exception = True

    def get(self, request):
        obj = GoogleApi.get_solo()
        form = GoogleApiForm(instance=obj)
        return render(request, self.template_name, {"form": form})

    def post(self, request):
        obj = GoogleApi.get_solo()
        form = GoogleApiForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            return redirect("jeiko_administration:google_api_config")
        return render(request, self.template_name, {"form": form})



@method_decorator(staff_member_required, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class LegalsOverviewView(View):
    """
    Affiche les 4 pages légales (liens Voir / Éditer).
    Pas de formulaire de choix : les pages sont protégées et créées par migration.
    """

    template_name = 'administration/legals/main.html'

    def _get_site(self):
        return WebSite.objects.first()

    def _get_legals(self, site):
        legals, _ = Legals.objects.get_or_create(site=site)
        return legals

    def _ensure_links(self, legals):
        """
        Si les FK du modèle Legals ne sont pas encore renseignées,
        on les pointe automatiquement vers les pages créées par migration.
        """
        updated_fields = []

        def _get(url_tag):
            return Page.objects.filter(url_tag__iexact=url_tag).first()

        mapping = {
            'mentions_page': _get('mentionslegales'),
            'cgu_page': _get('cgu'),
            'cgv_page': _get('cgv'),
            'privacy_page': _get('privacy'),
        }

        for attr, page in mapping.items():
            if getattr(legals, attr) is None and page is not None:
                setattr(legals, attr, page)
                updated_fields.append(attr)

        if updated_fields:
            legals.save(update_fields=updated_fields)
            cache.clear()

        return legals

    def get(self, request):
        site = self._get_site()
        legals = self._ensure_links(self._get_legals(site))

        context = {
            'legals': legals,
            # pratique si tu préfères accéder directement à ces variables dans le template
            'mentions_page': legals.mentions_page,
            'cgu_page': legals.cgu_page,
            'cgv_page': legals.cgv_page,
            'privacy_page': legals.privacy_page,
        }
        return render(request, self.template_name, context)

    def post(self, request):
        # Pas d’édition ici. On revient simplement sur la page.
        return redirect(request.path)

@method_decorator(staff_member_required, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class SiteIdentityView(View):
    template_name = "administration/identity/form.html"

    def get(self, request):
        website = get_current_website(request)
        identity, _ = SiteIdentity.objects.get_or_create(
            website=website,
            defaults={"type": SiteIdentity.TYPE_ORG, "name": (getattr(website, "name", "") or "")},
        )
        form = SiteIdentityForm(instance=identity)
        return render(request, self.template_name, {"form": form, "identity": identity, "website": website})

    def post(self, request):
        website = get_current_website(request)
        identity, _ = SiteIdentity.objects.get_or_create(website=website)
        form = SiteIdentityForm(request.POST, instance=identity)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.website = website
            obj.save()
            messages.success(request, "Identité du site enregistrée.")
            if request.headers.get("X-Requested-With") == "fetch":
                return JsonResponse({"ok": True})
            return redirect("jeiko_administration:site_identity")
        if request.headers.get("X-Requested-With") == "fetch":
            return JsonResponse({"ok": False, "errors": form.errors}, status=400)
        return render(request, self.template_name, {"form": form, "identity": identity, "website": website})