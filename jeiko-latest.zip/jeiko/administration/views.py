import os, sys
import subprocess
from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required

from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic.base import TemplateView
from django.views.generic.edit import UpdateView
from django.urls import reverse_lazy, reverse, NoReverseMatch

from django.http import HttpResponse
from django.views.decorators.http import require_GET

from django.db.models import Q



from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache, cache_control

from .models import WebSite, Fonts, Logo, MailSettings
from .forms import FontForm, LogoForm, MailSettingsForm

decorators = [never_cache]

from jeiko.administration_pages.models import Page

class Main(TemplateView):
    template_name = 'administration/main.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        context = {

        }

        return render(request, self.template_name, context)

class GlobalView(TemplateView):

    template_name = "administration/global/main.html"

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        context = {

        }

        return render(request, self.template_name, context)


class FontsView(View):

    template_name = "administration/fonts/view.html"

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        web_site = WebSite.objects.all().first()

        context = {
            'web_site': web_site,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        pass


class FontsUpdate(View):
    template_name = "administration/fonts/update.html"

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        pass

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        cache.clear()
        pass


class FontsTitleUpdate(View):
    template_name = "administration/fonts/update_title.html"
    font_form = FontForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        h1_form = self.font_form(
            instance=fonts.h1,
            prefix='h1_',
        )
        h2_form = self.font_form(
            instance=fonts.h2,
            prefix='h2_',
        )
        h3_form = self.font_form(
            instance=fonts.h3,
            prefix='h3_',
        )
        h4_form = self.font_form(
            instance=fonts.h4,
            prefix='h4_',
        )
        h5_form = self.font_form(
            instance=fonts.h5,
            prefix='h5_',
        )
        h6_form = self.font_form(
            instance=fonts.h6,
            prefix='h6_',
        )

        context = {
            'fonts': fonts,
            'h1_form': h1_form,
            'h2_form': h2_form,
            'h3_form': h3_form,
            'h4_form': h4_form,
            'h5_form': h5_form,
            'h6_form': h6_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        h1_form = self.font_form(
            request.POST,
            instance=fonts.h1,
            prefix='h1_',
        )
        h2_form = self.font_form(
            request.POST,
            instance=fonts.h2,
            prefix='h2_',
        )
        h3_form = self.font_form(
            request.POST,
            instance=fonts.h3,
            prefix='h3_',
        )
        h4_form = self.font_form(
            request.POST,
            instance=fonts.h4,
            prefix='h4_',
        )
        h5_form = self.font_form(
            request.POST,
            instance=fonts.h5,
            prefix='h5_',
        )
        h6_form = self.font_form(
            request.POST,
            instance=fonts.h6,
            prefix='h6_',
        )

        if h1_form.is_valid() \
                and h2_form.is_valid() \
                and h3_form.is_valid() \
                and h4_form.is_valid() \
                and h5_form.is_valid() \
                and h6_form.is_valid:

            h1 = h1_form.save()
            h2 = h2_form.save()
            h3 = h3_form.save()
            h4 = h4_form.save()
            h5 = h5_form.save()
            h6 = h6_form.save()

            fonts.h1 = h1
            fonts.h2 = h2
            fonts.h3 = h3
            fonts.h4 = h4
            fonts.h5 = h5
            fonts.h6 = h6

            fonts.save()

            cache.clear()
            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'h1_form': h1_form,
            'h2_form': h2_form,
            'h3_form': h3_form,
            'h4_form': h4_form,
            'h5_form': h5_form,
            'h6_form': h6_form,
        }
        return render(request, self.template_name, context)


class FontsTextUpdate(View):
    template_name = "administration/fonts/update_text.html"
    text_form = FontForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        text_form = self.text_form(
            instance=fonts.text,
            prefix='text_',
        )


        context = {
            'fonts': fonts,
            'text_form': text_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        text_form = self.text_form(
            request.POST,
            instance=fonts.text,
            prefix='text_',
        )



        if text_form.is_valid():


            text = text_form.save()


            fonts.text = text


            fonts.save()

            cache.clear()
            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'text_form': text_form,

        }
        return render(request, self.template_name, context)


class FontsLinkUpdate(View):

    template_name = "administration/fonts/update_link.html"
    form = FontForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        link_form = self.form(
            instance=fonts.links,
            prefix='link_',
        )
        link_hover_form = self.form(
            instance=fonts.links_hover,
            prefix='link_hover_',

        )


        context = {
            'fonts': fonts,
            'link_form': link_form,
            'link_hover_form': link_hover_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        link_form = self.form(
            request.POST,
            instance=fonts.links,
            prefix='link_',
        )
        link_hover_form = self.form(
            request.POST,
            instance=fonts.links_hover,
            prefix='link_hover_',

        )



        if link_form.is_valid() and link_hover_form.is_valid():


            link = link_form.save()
            link_hover = link_hover_form.save()


            fonts.links = link
            fonts.links_hover = link_hover


            fonts.save()

            cache.clear()
            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'link_form': link_form,
            'link_hover_form': link_hover_form,

        }
        return render(request, self.template_name, context)


class LogoUpdate(View):

    template_name = 'administration/logo/update.html'
    logo_form = LogoForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        website = WebSite.objects.all().first()

        if not website.logo:
            logo = Logo()
            logo.save()
            website.logo = logo
            website.save()
        else:
            logo = website.logo

        logo_form = self.logo_form(
            instance=logo,
            prefix='logo_'
        )

        context = {
            'logo_form': logo_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        website = WebSite.objects.all().first()

        logo = website.logo

        logo_form = self.logo_form(
            request.POST,
            request.FILES,
            instance=logo,
            prefix='logo_',
        )

        if logo_form.is_valid():
            logo = logo_form.save(commit=False)
            website.logo = logo
            website.save()
            logo.save()
            return redirect('jeiko_administration:global_view')

        context = {
            'logo_form': logo_form,
        }

        return render(request, self.template_name, context)


class ClearCache(View):

    @method_decorator(never_cache)
    def get(self, request, *args, ** kwargs):
        next_url = request.GET.get('next', '/')

        cache.clear()

        return redirect(next_url)


def _page_path(page: Page) -> str:
    """Construit le chemin public d'une page.
    Hypothèse: racine = '/', sinon '/<url_tag>/'."""
    return "/" if page.is_root else f"/{page.url_tag.strip('/')}/"

@require_GET
def robots_txt(request):
    # --- Règles de base (toujours utiles)
    lines = [
        "User-agent: *",
        "Disallow: /admin/",
        "Disallow: /administration/",
        "Disallow: /jeiko/administration/",
    ]

    # --- Pages publiques (actives + indexables)
    public_pages = Page.objects.filter(active=True, google_index=True)
    # Facultatif: on "Allow" explicitement ces chemins (pas indispensable, mais explicite)
    allow_paths = []
    for p in public_pages:
        path = _page_path(p)
        # Évite les doublons
        if path not in allow_paths:
            allow_paths.append(path)

    for path in allow_paths:
        # Éviter "Allow: /" qui n'apporte rien et peut interagir avec d'autres règles
        if path != "/":
            lines.append(f"Allow: {path}")

    # --- Pages non indexables (on les met en Disallow, sauf racine)
    blocked_pages = Page.objects.filter(Q(active=False) | Q(google_index=False))
    disallow_paths = set()
    for p in blocked_pages:
        path = _page_path(p)
        if path != "/":
            disallow_paths.add(path)

    for path in sorted(disallow_paths):
        lines.append(f"Disallow: {path}")

    # --- Sitemap si présent
    try:
        sm_url = request.build_absolute_uri(reverse("sitemap_xml"))  # nom de ta vue sitemap si/qd elle existe
        lines.append(f"Sitemap: {sm_url}")
    except NoReverseMatch:
        # pas de sitemap pour l’instant -> rien
        pass

    content = "\n".join(lines) + "\n"
    return HttpResponse(content, content_type="text/plain; charset=utf-8")


@require_GET
@cache_control(public=True, max_age=3600)  # 1h de cache (ajuste si besoin)
def sitemap_xml(request):
    """
    Génère un sitemap.xml avec les pages actives & indexables.
    NB: si tu penses dépasser 50k URLs, passe sur un sitemap index.
    """
    pages = (
        Page.objects
            .filter(active=True, google_index=True)
            .order_by('id')
            # .only('id','url_tag','is_root','date_created')  # micro-optim si tu veux
    )

    base = request.build_absolute_uri('/')[:-1]  # https://domaine.tld (sans slash final)

    # Construction XML
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
    ]

    for p in pages:
        loc = f"{base}{p.get_absolute_url()}"
        # lastmod : faute de mieux, on prend date_created ; si tu ajoutes un date_updated, remplace ici
        lastmod = (p.date_created.date().isoformat() if p.date_created else None)

        lines.append("  <url>")
        lines.append(f"    <loc>{loc}</loc>")
        if lastmod:
            lines.append(f"    <lastmod>{lastmod}</lastmod>")
        # Optionnels : changefreq/priority (mets des valeurs neutres)
        # lines.append("    <changefreq>weekly</changefreq>")
        # lines.append("    <priority>0.5</priority>")
        lines.append("  </url>")

    lines.append('</urlset>')
    xml = "\n".join(lines)
    return HttpResponse(xml, content_type="application/xml")


@method_decorator(never_cache, name='dispatch')
class MailSettingsUpdateView(UpdateView):
    model = MailSettings
    form_class = MailSettingsForm
    template_name = "administration/mail/settings_form.html"

    def get_object(self, queryset=None):
        # Ici, tu récupères la config liée au site courant (à adapter si multisite)
        website = WebSite.objects.first()  # ou récupère selon l'utilisateur/site courant
        mail_settings, created = MailSettings.objects.get_or_create(pk=getattr(website, "mail_settings_id", None))
        if not website.mail_settings:
            website.mail_settings = mail_settings
            website.save()
        return mail_settings

    def get_success_url(self):
        return reverse_lazy("jeiko_administration:main")  # à adapter à ton url


@method_decorator(staff_member_required, name='dispatch')
class UpdateJeikoView(TemplateView):
    template_name = "administration/update/form.html"

    def post(self, request, *args, **kwargs):
        BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        script_path = os.path.join(BASE_DIR, 'scripts', 'update_jeiko.sh')

        if not os.path.isfile(script_path):
            return render(request, "administration/update/result.html", {
                "output": "",
                "error": f"Script introuvable à {script_path}",
                "success": False,
            })

        try:
            result = subprocess.run(
                ["/bin/bash", script_path],
                capture_output=True,
                text=True,
                check=True
            )
            return render(request, "administration/update/result.html", {
                "output": result.stdout,
                "error": result.stderr,
                "success": True,
            })

        except subprocess.CalledProcessError as e:
            return render(request, "administration/update/result.html", {
                "output": e.stdout,
                "error": e.stderr,
                "success": False,
            })
