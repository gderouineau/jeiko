from django import forms



from .models import Font, Logo, MailSettings, GoogleApi, Legals, SiteIdentity

from jeiko.administration_pages.models import Page



class FontForm(forms.ModelForm):

    class Meta:
        model = Font
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(FontForm, self).__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form'


class FontFamilyUpdateAllForm(forms.Form):

    family = forms.CharField(
        label="Nouvelle famille de police",
        max_length=100,
        help_text='Ex: Inter, Roboto, Playfair Display, Georgia…',
        widget=forms.TextInput(attrs={"placeholder": "Inter"})
    )

    def clean_family(self):
        v = (self.cleaned_data.get("family") or "").strip()
        if not v:
            raise forms.ValidationError("La famille de police ne peut pas être vide.")
        # normalisation soft: espaces internes réduits
        v = " ".join(v.split())
        return v


class LogoForm(forms.ModelForm):

    class Meta:
        model = Logo
        fields = [
            'full_size',
        ]


class MailSettingsForm(forms.ModelForm):
    host_password = forms.CharField(
        label="Mot de passe SMTP",
        widget=forms.PasswordInput(render_value=True),
        required=False,
        help_text="Mot de passe du serveur SMTP"
    )

    class Meta:
        model = MailSettings
        fields = [
            "host", "port", "use_tls", "use_ssl", "host_user", "host_password",
            "default_from_email", "reply_to_email", "active", "test_receiver"
        ]


class GoogleApiForm(forms.ModelForm):
    class Meta:
        model = GoogleApi
        fields = ["psi_api_key"]
        widgets = {
            "psi_api_key": forms.PasswordInput(render_value=False, attrs={"autocomplete": "new-password"}),
        }
        labels = {
            "psi_api_key": "Clé API PageSpeed Insights",
        }
        help_texts = {
            "psi_api_key": "Colle ici ta clé PSI. Laisse vide pour utiliser la variable d'environnement.",
        }


class LegalsAdminForm(forms.ModelForm):
    class Meta:
        model = Legals
        fields = ["privacy_page", "cgv_page", "cgu_page", "mentions_page"]  # pas de 'site' ici

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        qs = Page.objects.all()
        for fname in ("privacy_page", "cgv_page", "cgu_page", "mentions_page"):
            self.fields[fname].queryset = qs
            self.fields[fname].required = False

class SiteIdentityForm(forms.ModelForm):
    type = forms.ChoiceField(
        choices=SiteIdentity.TYPE_CHOICES,
        widget=forms.RadioSelect
    )

    class Meta:
        model = SiteIdentity
        fields = [
            "type", "name", "url", "telephone",
            "street_address", "address_locality", "address_region",
            "postal_code", "address_country",
            "geo_lat", "geo_lng", "price_range",
        ]
        widgets = {
            "same_as": forms.Textarea(attrs={"rows": 3, "placeholder": "Une URL par ligne (profils sociaux, etc.)"}),
        }
        help_texts = {
            "address_country": "Code pays ISO-3166-1 alpha-2 (ex: FR, CH, BE).",
            "logo_url": "Image carrée ≥112×112, crawlable.",
        }

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("type") == SiteIdentity.TYPE_LOCAL:
            required = ["name", "street_address", "address_locality", "postal_code", "address_country"]
            for f in required:
                if not cleaned.get(f):
                    self.add_error(f, "Champ requis pour LocalBusiness.")
        # Normalise same_as si fourni en liste de lignes
        same_as = cleaned.get("same_as")
        if isinstance(same_as, str):
            lines = [l.strip() for l in same_as.splitlines() if l.strip()]
            if lines:
                cleaned["same_as"] = lines
        return cleaned