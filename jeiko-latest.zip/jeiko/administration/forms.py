from django import forms



from .models import Font, Logo, MailSettings



class FontForm(forms.ModelForm):

    class Meta:
        model = Font
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(FontForm, self).__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form'


class LogoForm(forms.ModelForm):

    class Meta:
        model = Logo
        fields = [
            'full_size',
        ]


class MailSettingsForm(forms.ModelForm):
    host_password = forms.CharField(
        label="Mot de passe SMTP",
        widget=forms.PasswordInput(render_value=True),
        required=False,
        help_text="Mot de passe du serveur SMTP"
    )

    class Meta:
        model = MailSettings
        fields = [
            "host", "port", "use_tls", "use_ssl", "host_user", "host_password",
            "default_from_email", "reply_to_email", "active", "test_receiver"
        ]