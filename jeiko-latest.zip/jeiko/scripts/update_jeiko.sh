#!/usr/bin/env bash
set -euo pipefail

echo "🔄 Mise à jour du package JEIKO..."

# -----------------------------
# 0) Détections & paramètres
# -----------------------------
MANAGE_DIR="${JEIKO_MANAGE_DIR:-}"
if [[ -z "$MANAGE_DIR" ]]; then
  CUR="$PWD"; found=""
  for _ in {1..6}; do
    if [[ -f "$CUR/manage.py" ]]; then found="$CUR"; break; fi
    CUR="$(dirname "$CUR")"
  done
  if [[ -z "$found" ]]; then
    echo "❌ manage.py introuvable. Lance ce script depuis le projet ou exporte JEIKO_MANAGE_DIR=/chemin/vers/le/projet"
    exit 1
  fi
  MANAGE_DIR="$found"
fi
echo "🗂️  manage.py : $MANAGE_DIR/manage.py"

SITE_NAME="$(basename "$MANAGE_DIR")"
SITE_USER="${JEIKO_SITE_USER:-jeiko-$SITE_NAME}"

choose_python() {
  if [[ -n "${JEIKO_PYTHON:-}" && -x "${JEIKO_PYTHON}" ]]; then echo "$JEIKO_PYTHON"; return; fi
  if [[ -x "$MANAGE_DIR/venv/bin/python" ]]; then echo "$MANAGE_DIR/venv/bin/python"; return; fi
  if [[ -x "$MANAGE_DIR/.venv/bin/python" ]]; then echo "$MANAGE_DIR/.venv/bin/python"; return; fi
  if command -v python3 >/dev/null 2>&1; then echo "$(command -v python3)"; return; fi
  echo ""
}

PYTHON_BIN="$(choose_python)"
if [[ -z "$PYTHON_BIN" || ! -x "$PYTHON_BIN" ]]; then
  echo "❌ Python introuvable. Crée un venv :  cd \"$MANAGE_DIR\" && python3 -m venv venv && ./venv/bin/python -m pip install -U pip"
  exit 1
fi

# Racine du venv et utilitaires
VENV_DIR="$(dirname "$(dirname "$PYTHON_BIN")")"
as_site() {
    local cmd="$*"
    if [ "$(id -un)" = "$SITE_USER" ]; then
        bash -lc "$cmd"
    else
        sudo -u "$SITE_USER" -E bash -lc "$cmd"
    fi
}

# Vérifier que ce Python est bien un venv
IS_VENV="$(as_site "$PYTHON_BIN - <<'PY'
import sys; print(sys.prefix != getattr(sys, 'base_prefix', sys.prefix))
PY
")"
if [[ "$IS_VENV" != "True" ]]; then
  echo "❌ Le Python sélectionné n'est pas un virtualenv : $PYTHON_BIN"
  echo "   Crée un venv:  cd \"$MANAGE_DIR\" && python3 -m venv venv && ./venv/bin/python -m pip install -U pip"
  echo "   Puis relance (ou exporte JEIKO_PYTHON=\"$MANAGE_DIR/venv/bin/python\")."
  exit 1
fi

# [OWNERSHIP CHECK] : le venv doit appartenir au SITE_USER
get_owner() {
  local path="$1"
  if stat --version >/dev/null 2>&1; then stat -c %U "$path"; else stat -f %Su "$path"; fi
}
VENV_OWNER="$(get_owner "$VENV_DIR" || echo "")"
if [[ -n "$VENV_OWNER" && "$VENV_OWNER" != "$SITE_USER" ]]; then
  echo "⚠️  Le venv ($VENV_DIR) appartient à '$VENV_OWNER', attendu: '$SITE_USER'."
  if [[ "${JEIKO_FIX_VENV_OWNERSHIP:-0}" == "1" ]]; then
    echo "🔧 Correction des droits (sudo chown -R $SITE_USER:$SITE_USER \"$VENV_DIR\")..."
    sudo chown -R "$SITE_USER:$SITE_USER" "$VENV_DIR"
  else
    echo "ℹ️  Pour corriger automatiquement : JEIKO_FIX_VENV_OWNERSHIP=1 $0"
    echo "    Ou exécute : sudo chown -R $SITE_USER:$SITE_USER \"$VENV_DIR\""
  fi
fi

# Chemin site-packages (et test écriture en tant que SITE_USER)
SITE_PACKAGES="$(as_site "$PYTHON_BIN - <<'PY'
import sysconfig; print(sysconfig.get_paths()['purelib'])
PY
")"
if ! as_site "test -w \"$SITE_PACKAGES\""; then
  echo "❌ Le dossier site-packages n'est pas écrivable par $SITE_USER : $SITE_PACKAGES"
  echo "   Corrige les droits (owner = $SITE_USER) puis relance."
  exit 1
fi

PIP_CMD="$PYTHON_BIN -m pip"
PIP_OPTS="--no-cache-dir"
export PYTHONNOUSERSITE=1
echo "🐍 Python utilisé : $PYTHON_BIN (user: $SITE_USER)"

# Dossiers statiques/médias + fix des droits
STATIC_ROOT="$MANAGE_DIR/staticdir"
MEDIA_ROOT="$MANAGE_DIR/mediadir"
fix_perms() {
  sudo mkdir -p "$STATIC_ROOT" "$MEDIA_ROOT"
  sudo chown -R "$SITE_USER":www-data "$STATIC_ROOT" "$MEDIA_ROOT"
  sudo find "$STATIC_ROOT" "$MEDIA_ROOT" -type d -exec chmod 2775 {} \;
  sudo find "$STATIC_ROOT" "$MEDIA_ROOT" -type f -exec chmod 664 {} \;
}

TMP_ZIP="/tmp/jeiko_latest.zip"
TMP_EXTRACT="/tmp/jeiko_extracted"
ZIP_URL="${JEIKO_ZIP_URL:-https://github.com/gderouineau/jeiko/raw/refs/heads/main/jeiko-latest.zip}"

SERVICE_NAME="${JEIKO_GUNICORN_SERVICE:-gunicorn-$SITE_NAME}"

# -----------------------------
# 1) Télécharger le zip
# -----------------------------
echo "📥 Téléchargement..."
curl -fL "$ZIP_URL" -o "$TMP_ZIP"

# -----------------------------
# 2) Extraction
# -----------------------------
echo "📂 Extraction dans $TMP_EXTRACT..."
rm -rf "$TMP_EXTRACT"; mkdir -p "$TMP_EXTRACT"
unzip -oq "$TMP_ZIP" -d "$TMP_EXTRACT"

# -----------------------------
# 3) Localiser le package
# -----------------------------
PACKAGE_DIR="$(find "$TMP_EXTRACT" -name 'pyproject.toml' -exec dirname {} \; | head -n 1 || true)"
if [[ -z "$PACKAGE_DIR" ]]; then
  echo "❌ Fichier pyproject.toml introuvable dans l'archive."
  exit 1
fi
DIST_DIR="$PACKAGE_DIR/dist"

# -----------------------------
# 4) pip à jour (dans le venv) — en tant que SITE_USER
# -----------------------------
echo "⬆️  Mise à jour de pip/setuptools/wheel..."
as_site "$PIP_CMD install $PIP_OPTS --upgrade pip setuptools wheel"

# -----------------------------
# 5) Installer requirements (si présents) — en tant que SITE_USER
# -----------------------------
REQ_FILE="$(find "$TMP_EXTRACT" -name 'requirements.txt' | head -n 1 || true)"
if [[ -n "$REQ_FILE" ]]; then
  echo "📦 Installation des dépendances (requirements.txt)..."
  as_site "$PIP_CMD install $PIP_OPTS -r \"$REQ_FILE\""
fi

# -----------------------------
# 6) S’assurer de build installé — en tant que SITE_USER
# -----------------------------
if ! as_site "$PYTHON_BIN -m build --version" &>/dev/null; then
  echo "📚 Installation du module 'build'..."
  as_site "$PIP_CMD install $PIP_OPTS build"
fi

# -----------------------------
# 7) Build du package — en tant que SITE_USER
# -----------------------------
echo "🧹 Nettoyage de $DIST_DIR..."
rm -rf "$DIST_DIR"
echo "🔧 Build du package..."
pushd "$PACKAGE_DIR" >/dev/null
as_site "$PYTHON_BIN -m build >/dev/null"
popd >/dev/null

# -----------------------------
# 8) Installation du package — en tant que SITE_USER
# -----------------------------
echo "📦 Installation du package construit..."
if compgen -G "$DIST_DIR/*.whl" > /dev/null; then
  WHEEL_FILE="$(ls -1 "$DIST_DIR"/*.whl | head -n 1)"
  as_site "$PIP_CMD install $PIP_OPTS --force-reinstall \"$WHEEL_FILE\""
elif compgen -G "$DIST_DIR/*.tar.gz" > /dev/null; then
  TAR_FILE="$(ls -1 "$DIST_DIR"/*.tar.gz | head -n 1)"
  as_site "$PIP_CMD install $PIP_OPTS --force-reinstall \"$TAR_FILE\""
else
  echo "❌ Aucun artefact (.whl/.tar.gz) trouvé dans $DIST_DIR"
  exit 1
fi

# -----------------------------
# 9) collectstatic & migrate — en tant que SITE_USER
# -----------------------------
echo "🗂️  Collecte des fichiers statiques..."
fix_perms
pushd "$MANAGE_DIR" >/dev/null
as_site "umask 0002; $PYTHON_BIN manage.py collectstatic --noinput"
echo "🛠️  Application des migrations..."
as_site "umask 0002; $PYTHON_BIN manage.py migrate --noinput"
popd >/dev/null
fix_perms

# -----------------------------
# 10) Redémarrages (optionnels)
# -----------------------------
restart_service() {
  local svc="$1"
  if command -v systemctl >/dev/null 2>&1; then
    if systemctl list-unit-files | grep -q "^${svc}\.service"; then
      echo "🔁 Redémarrage de ${svc}..."
      sudo systemctl restart "$svc" || true
    else
      echo "ℹ️  Service ${svc} introuvable, on saute."
    fi
  else
    echo "ℹ️  systemctl non disponible, on saute."
  fi
}

restart_service "nginx"
restart_service "$SERVICE_NAME"

# -----------------------------
# 11) Nettoyage
# -----------------------------
echo "🧹 Nettoyage des fichiers temporaires..."
rm -rf "$TMP_ZIP" "$TMP_EXTRACT"

echo "✅ Mise à jour de JEIKO terminée avec succès."
