#!/usr/bin/env bash
set -euo pipefail

echo "🔄 Mise à jour du package JEIKO..."

# -----------------------------
# 0) Détections & paramètres
# -----------------------------
MANAGE_DIR="${JEIKO_MANAGE_DIR:-}"
if [[ -z "${MANAGE_DIR}" ]]; then
  CUR="$PWD"; found=""
  for _ in {1..6}; do
    if [[ -f "$CUR/manage.py" ]]; then found="$CUR"; break; fi
    CUR="$(dirname "$CUR")"
  done
  if [[ -z "$found" ]]; then
    echo "❌ manage.py introuvable. Lance ce script depuis le projet ou exporte JEIKO_MANAGE_DIR=/chemin/vers/le/projet"
    exit 1
  fi
  MANAGE_DIR="$found"
fi
echo "🗂️  manage.py : $MANAGE_DIR/manage.py"

choose_python() {
  if [[ -n "${JEIKO_PYTHON:-}" && -x "${JEIKO_PYTHON}" ]]; then echo "$JEIKO_PYTHON"; return; fi
  if [[ -x "$MANAGE_DIR/venv/bin/python" ]]; then echo "$MANAGE_DIR/venv/bin/python"; return; fi
  if [[ -x "$MANAGE_DIR/.venv/bin/python" ]]; then echo "$MANAGE_DIR/.venv/bin/python"; return; fi
  if command -v python3 >/dev/null 2>&1; then echo "$(command -v python3)"; return; fi
  echo ""
}

PYTHON_BIN="$(choose_python)"
if [[ -z "$PYTHON_BIN" || ! -x "$PYTHON_BIN" ]]; then
  echo "❌ Python introuvable. Crée un venv :  cd \"$MANAGE_DIR\" && python3 -m venv venv && ./venv/bin/python -m pip install -U pip"
  exit 1
fi

IS_VENV="$("$PYTHON_BIN" - <<'PY'
import sys; print(sys.prefix != getattr(sys, "base_prefix", sys.prefix))
PY
)"
if [[ "$IS_VENV" != "True" ]]; then
  echo "❌ Le Python sélectionné n'est pas un virtualenv : $PYTHON_BIN"
  echo "   Crée un venv:  cd \"$MANAGE_DIR\" && python3 -m venv venv && ./venv/bin/python -m pip install -U pip"
  echo "   Puis relance (ou exporte JEIKO_PYTHON=\"$MANAGE_DIR/venv/bin/python\")."
  exit 1
fi

PIP_CMD=( "$PYTHON_BIN" -m pip )
PIP_OPTS=( --no-cache-dir )
export PYTHONNOUSERSITE=1
echo "🐍 Python utilisé : $PYTHON_BIN"

# Chemin du venv (racine)
VENV_DIR="$(dirname "$(dirname "$PYTHON_BIN")")"

# [OWNERSHIP FIX] --------------------------------------------------------------
# Fonction portable pour récupérer l'owner d'un chemin
get_owner() {
  local path="$1"
  if stat --version >/dev/null 2>&1; then
    # GNU stat
    stat -c %U "$path"
  else
    # BSD/macOS stat
    stat -f %Su "$path"
  fi
}

CURRENT_USER="$(id -un)"
VENV_OWNER="$(get_owner "$VENV_DIR" || echo "")"

if [[ -n "$VENV_OWNER" && "$VENV_OWNER" != "$CURRENT_USER" ]]; then
  echo "⚠️  Le venv appartient à '$VENV_OWNER', utilisateur courant: '$CURRENT_USER'."
  if [[ "${JEIKO_FIX_VENV_OWNERSHIP:-0}" == "1" ]]; then
    echo "🔧 Correction des droits (sudo chown -R $CURRENT_USER:$CURRENT_USER \"$VENV_DIR\")..."
    sudo chown -R "$CURRENT_USER:$CURRENT_USER" "$VENV_DIR"
  else
    echo "ℹ️  Pour corriger automatiquement, relance avec : JEIKO_FIX_VENV_OWNERSHIP=1"
    echo "    Ou exécute manuellement : sudo chown -R $CURRENT_USER:$CURRENT_USER \"$VENV_DIR\""
  fi
fi
# -----------------------------------------------------------------------------

# Déterminer le site-packages et tester l’écriture
SITE_PACKAGES="$("$PYTHON_BIN" - <<'PY'
import sysconfig; print(sysconfig.get_paths()['purelib'])
PY
)"
if ! ( test -d "$SITE_PACKAGES" && test -w "$SITE_PACKAGES" ); then
  echo "❌ Le dossier site-packages n'est pas écrivable : $SITE_PACKAGES"
  echo "   Corrige les droits (owner = $CURRENT_USER) puis relance."
  exit 1
fi

TMP_ZIP="/tmp/jeiko_latest.zip"
TMP_EXTRACT="/tmp/jeiko_extracted"
ZIP_URL="https://github.com/gderouineau/jeiko/raw/refs/heads/main/jeiko-latest.zip"

SERVICE_NAME="${JEIKO_GUNICORN_SERVICE:-gunicorn-$(basename "$MANAGE_DIR")}"

# -----------------------------
# 1) Télécharger le zip
# -----------------------------
echo "📥 Téléchargement..."
curl -fL "$ZIP_URL" -o "$TMP_ZIP"

# -----------------------------
# 2) Extraction
# -----------------------------
echo "📂 Extraction dans $TMP_EXTRACT..."
rm -rf "$TMP_EXTRACT"; mkdir -p "$TMP_EXTRACT"
unzip -oq "$TMP_ZIP" -d "$TMP_EXTRACT"

# -----------------------------
# 3) Localiser le package
# -----------------------------
PACKAGE_DIR="$(find "$TMP_EXTRACT" -name 'pyproject.toml' -exec dirname {} \; | head -n 1 || true)"
if [[ -z "$PACKAGE_DIR" ]]; then
  echo "❌ Fichier pyproject.toml introuvable dans l'archive."
  exit 1
fi
DIST_DIR="$PACKAGE_DIR/dist"

# -----------------------------
# 4) pip à jour (dans le venv)
# -----------------------------
echo "⬆️  Mise à jour de pip..."
"${PIP_CMD[@]}" install "${PIP_OPTS[@]}" --upgrade pip

# -----------------------------
# 5) Installer requirements (si présents)
# -----------------------------
REQ_FILE="$(find "$TMP_EXTRACT" -name 'requirements.txt' | head -n 1 || true)"
if [[ -n "$REQ_FILE" ]]; then
  echo "📦 Installation des dépendances (requirements.txt)..."
  "${PIP_CMD[@]}" install "${PIP_OPTS[@]}" -r "$REQ_FILE"
fi

# -----------------------------
# 6) S’assurer de build/setuptools
# -----------------------------
if ! "$PYTHON_BIN" -m build --version &>/dev/null; then
  echo "📚 Installation du module 'build'..."
  "${PIP_CMD[@]}" install "${PIP_OPTS[@]}" build
fi
if ! "$PYTHON_BIN" - <<'PY' &>/dev/null
import setuptools
PY
then
  echo "📚 Installation de 'setuptools'..."
  "${PIP_CMD[@]}" install "${PIP_OPTS[@]}" setuptools
fi

# -----------------------------
# 7) Build du package
# -----------------------------
echo "🧹 Nettoyage de $DIST_DIR..."
rm -rf "$DIST_DIR"

echo "🔧 Build du package..."
pushd "$PACKAGE_DIR" >/dev/null
"$PYTHON_BIN" -m build >/dev/null
popd >/dev/null

# -----------------------------
# 8) Installation du package
# -----------------------------
echo "📦 Installation du package construit..."
if compgen -G "$DIST_DIR/*.whl" > /dev/null; then
  WHEEL_FILE="$(ls -1 "$DIST_DIR"/*.whl | head -n 1)"
  "${PIP_CMD[@]}" install "${PIP_OPTS[@]}" --force-reinstall "$WHEEL_FILE"
elif compgen -G "$DIST_DIR/*.tar.gz" > /dev/null; then
  TAR_FILE="$(ls -1 "$DIST_DIR"/*.tar.gz | head -n 1)"
  "${PIP_CMD[@]}" install "${PIP_OPTS[@]}" --force-reinstall "$TAR_FILE"
else
  echo "❌ Aucun artefact (.whl/.tar.gz) trouvé dans $DIST_DIR"
  exit 1
fi

# -----------------------------
# 9) collectstatic & migrate
# -----------------------------
echo "🗂️  Collecte des fichiers statiques..."
pushd "$MANAGE_DIR" >/dev/null
"$PYTHON_BIN" manage.py collectstatic --noinput

echo "🛠️  Application des migrations..."
"$PYTHON_BIN" manage.py migrate
popd >/dev/null

# -----------------------------
# 10) Redémarrages (optionnels)
# -----------------------------
restart_service() {
  local svc="$1"
  if command -v systemctl >/dev/null 2>&1; then
    if systemctl list-unit-files | grep -q "^${svc}\.service"; then
      echo "🔁 Redémarrage de ${svc}..."
      sudo systemctl restart "$svc" || true
    else
      echo "ℹ️  Service ${svc} introuvable, on saute."
    fi
  else
    echo "ℹ️  systemctl non disponible, on saute."
  fi
}

restart_service "nginx"
restart_service "$SERVICE_NAME"

# -----------------------------
# 11) Nettoyage
# -----------------------------
echo "🧹 Nettoyage des fichiers temporaires..."
rm -rf "$TMP_ZIP" "$TMP_EXTRACT"

echo "✅ Mise à jour de JEIKO terminée avec succès."
