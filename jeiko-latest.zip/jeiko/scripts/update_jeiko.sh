#!/usr/bin/env bash
set -euo pipefail

echo "🔄 Mise à jour du package JEIKO..."

# -----------------------------
# 0) Détections & paramètres
# -----------------------------
# Python/Pip du venv actuellement utilisé par ton process (fiable même sans 'source').
PYTHON_BIN="$(python3 -c 'import sys; print(sys.executable)')"
PY_BIN_DIR="$(dirname "$PYTHON_BIN")"
PIP_BIN="$PY_BIN_DIR/pip"

if [[ ! -x "$PYTHON_BIN" ]]; then
  echo "❌ Impossible de déterminer le python du projet. Assure-toi d'être dans le bon environnement."
  exit 1
fi

echo "🐍 Python utilisé : $PYTHON_BIN"
echo "📦 Pip utilisé    : $PIP_BIN"

# Dossier temporaire
TMP_ZIP="/tmp/jeiko_latest.zip"
TMP_EXTRACT="/tmp/jeiko_extracted"
ZIP_URL="https://github.com/gderouineau/jeiko/raw/refs/heads/main/jeiko-latest.zip"

# -----------------------------
# 1) Trouver le dossier manage.py
# -----------------------------
# Priorité : variable d'env JEIKO_MANAGE_DIR (à définir si besoin)
MANAGE_DIR="${JEIKO_MANAGE_DIR:-}"

if [[ -z "${MANAGE_DIR}" ]]; then
  # Si non fourni : on cherche en remontant depuis le répertoire courant
  CUR="$PWD"
  found=""
  for _ in {1..6}; do
    if [[ -f "$CUR/manage.py" ]]; then
      found="$CUR"
      break
    fi
    CUR="$(dirname "$CUR")"
  done
  if [[ -z "$found" ]]; then
    echo "❌ manage.py introuvable. Lance ce script depuis ton projet OU exporte JEIKO_MANAGE_DIR=/chemin/vers/le/projet"
    exit 1
  fi
  MANAGE_DIR="$found"
fi

echo "🗂️  manage.py : $MANAGE_DIR/manage.py"

# Nom du service Gunicorn (optionnel)
SERVICE_NAME="${JEIKO_GUNICORN_SERVICE:-gunicorn-$(basename "$MANAGE_DIR")}"

# -----------------------------
# 2) Télécharger le zip
# -----------------------------
echo "📥 Téléchargement..."
curl -fL "$ZIP_URL" -o "$TMP_ZIP"

# -----------------------------
# 3) Extraction
# -----------------------------
echo "📂 Extraction dans $TMP_EXTRACT..."
rm -rf "$TMP_EXTRACT"
mkdir -p "$TMP_EXTRACT"
unzip -oq "$TMP_ZIP" -d "$TMP_EXTRACT"

# -----------------------------
# 4) Localiser le package (pyproject.toml)
# -----------------------------
PACKAGE_DIR="$(find "$TMP_EXTRACT" -name 'pyproject.toml' -exec dirname {} \; | head -n 1 || true)"
if [[ -z "$PACKAGE_DIR" ]]; then
  echo "❌ Fichier pyproject.toml introuvable dans l'archive."
  exit 1
fi
DIST_DIR="$PACKAGE_DIR/dist"

# -----------------------------
# 5) Installer requirements (si présents)
# -----------------------------
REQ_FILE="$(find "$TMP_EXTRACT" -name 'requirements.txt' | head -n 1 || true)"
if [[ -n "$REQ_FILE" ]]; then
  echo "📦 Installation des dépendances (requirements.txt)..."
  "$PIP_BIN" install -r "$REQ_FILE"
fi

# -----------------------------
# 6) S’assurer de build/setuptools
# -----------------------------
if ! "$PYTHON_BIN" -m build --version &>/dev/null; then
  echo "📚 Installation du module 'build'..."
  "$PIP_BIN" install build
fi
if ! "$PYTHON_BIN" - <<'PY' &>/dev/null
import setuptools
PY
then
  echo "📚 Installation de 'setuptools'..."
  "$PIP_BIN" install setuptools
fi

# -----------------------------
# 7) Build du package
# -----------------------------
echo "🧹 Nettoyage de $DIST_DIR..."
rm -rf "$DIST_DIR"

echo "🔧 Build du package..."
pushd "$PACKAGE_DIR" >/dev/null
"$PYTHON_BIN" -m build >/dev/null
popd >/dev/null

# -----------------------------
# 8) Installation du package
# -----------------------------
echo "📦 Installation du package construit..."
if compgen -G "$DIST_DIR/*.whl" > /dev/null; then
  WHEEL_FILE="$(ls -1 "$DIST_DIR"/*.whl | head -n 1)"
  "$PIP_BIN" install --force-reinstall --no-cache-dir "$WHEEL_FILE"
elif compgen -G "$DIST_DIR/*.tar.gz" > /dev/null; then
  TAR_FILE="$(ls -1 "$DIST_DIR"/*.tar.gz | head -n 1)"
  "$PIP_BIN" install --force-reinstall --no-cache-dir "$TAR_FILE"
else
  echo "❌ Aucun artefact (.whl/.tar.gz) trouvé dans $DIST_DIR"
  exit 1
fi

# -----------------------------
# 9) collectstatic & migrate
# -----------------------------
echo "🗂️  Collecte des fichiers statiques..."
pushd "$MANAGE_DIR" >/dev/null
"$PYTHON_BIN" manage.py collectstatic --noinput

echo "🛠️  Application des migrations..."
"$PYTHON_BIN" manage.py migrate
popd >/dev/null

# -----------------------------
# 10) Redémarrages (optionnels)
# -----------------------------
restart_service() {
  local svc="$1"
  if command -v systemctl >/dev/null 2>&1; then
    if systemctl list-unit-files | grep -q "^${svc}\.service"; then
      echo "🔁 Redémarrage de ${svc}..."
      sudo systemctl restart "$svc" || true
    else
      echo "ℹ️  Service ${svc} introuvable, on saute."
    fi
  else
    echo "ℹ️  systemctl non disponible, on saute."
  fi
}

restart_service "nginx"
restart_service "$SERVICE_NAME"

# -----------------------------
# 11) Nettoyage
# -----------------------------
echo "🧹 Nettoyage des fichiers temporaires..."
rm -rf "$TMP_ZIP" "$TMP_EXTRACT"

echo "✅ Mise à jour de JEIKO terminée avec succès."
