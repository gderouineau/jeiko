#!/usr/bin/env bash

#############################################
# 0) SELF-FIX INITIAL (before doing anything)
#############################################

SCRIPT_PATH="$(realpath "$0")"

# Fix CRLF if present (otherwise script may not execute)
if grep -q $'\r' "$SCRIPT_PATH"; then
    sed -i 's/\r$//' "$SCRIPT_PATH"
fi

# Ensure executable bit
chmod 750 "$SCRIPT_PATH" 2>/dev/null || true

# Ensure correct owner
chown jeiko-ateliersderouineau:jeiko-ateliersderouineau "$SCRIPT_PATH" 2>/dev/null || true


#############################################
# 1) MAIN SCRIPT START
#############################################

set -euo pipefail

echo "🔄 Mise à jour du package JEIKO..."

# -----------------------------
# 0) Détections & paramètres
# -----------------------------
MANAGE_DIR="${JEIKO_MANAGE_DIR:-}"
if [[ -z "$MANAGE_DIR" ]]; then
    CUR="$PWD"; found=""
    for _ in {1..6}; do
        if [[ -f "$CUR/manage.py" ]]; then found="$CUR"; break; fi
        CUR="$(dirname "$CUR")"
    done
    if [[ -z "$found" ]]; then
        echo "❌ manage.py introuvable. Lance ce script depuis le projet ou exporte JEIKO_MANAGE_DIR=/chemin/vers/le/projet"
        exit 1
    fi
    MANAGE_DIR="$found"
fi
echo "🗂️  manage.py : $MANAGE_DIR/manage.py"

SITE_NAME="$(basename "$MANAGE_DIR")"
SITE_USER="${JEIKO_SITE_USER:-jeiko-$SITE_NAME}"

choose_python() {
    if [[ -n "${JEIKO_PYTHON:-}" && -x "${JEIKO_PYTHON}" ]]; then echo "$JEIKO_PYTHON"; return; fi
    if [[ -x "$MANAGE_DIR/venv/bin/python" ]]; then echo "$MANAGE_DIR/venv/bin/python"; return; fi
    if [[ -x "$MANAGE_DIR/.venv/bin/python" ]]; then echo "$MANAGE_DIR/.venv/bin/python"; return; fi
    if command -v python3 >/dev/null 2>&1; then echo "$(command -v python3)"; return; fi
    echo ""
}

PYTHON_BIN="$(choose_python)"
if [[ -z "$PYTHON_BIN" || ! -x "$PYTHON_BIN" ]]; then
    echo "❌ Python introuvable."
    exit 1
fi

# Racine du venv
VENV_DIR="$(dirname "$(dirname "$PYTHON_BIN")")"

#############################################
# EXECUTION HELPERS (NO MORE bash_profile ERRORS)
#############################################

# Exécuter une commande en tant que root si possible
have_sudo_nonint() {
    command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null
}

run_root() {
    local cmd="$*"
    if [[ "$(id -u)" -eq 0 ]]; then
        bash -s <<EOF
$cmd
EOF
        return $?
    fi
    if have_sudo_nonint; then
        sudo -n bash -s <<EOF
$cmd
EOF
        return $?
    fi
    echo "⏭️  Opération root ignorée : $cmd"
    return 1
}

# Exécuter une commande en tant que SITE_USER (sans charger bash_profile)
as_site() {
    local cmd="$*"
    sudo -u "$SITE_USER" -H bash -s <<EOF
$cmd
EOF
}

#############################################
# VERIFY VENV
#############################################

IS_VENV="$(as_site "$PYTHON_BIN - <<'PY'
import sys; print(sys.prefix != getattr(sys, 'base_prefix', sys.prefix))
PY
")"

if [[ "$IS_VENV" != "True" ]]; then
    echo "❌ Python n'est pas un virtualenv : $PYTHON_BIN"
    exit 1
fi

#############################################
# CHECK VENV OWNERSHIP
#############################################

get_owner() {
    local path="$1"
    if stat --version >/dev/null 2>&1; then stat -c %U "$path"; else stat -f %Su "$path"; fi
}

VENV_OWNER="$(get_owner "$VENV_DIR" || echo "")"
if [[ "$VENV_OWNER" != "$SITE_USER" ]]; then
    echo "⚠️  Le venv appartient à '$VENV_OWNER' au lieu de '$SITE_USER'."
fi

#############################################
# SITE-PACKAGES
#############################################

SITE_PACKAGES="$(as_site "$PYTHON_BIN - <<'PY'
import sysconfig; print(sysconfig.get_paths()['purelib'])
PY
")"

if ! as_site "test -w \"$SITE_PACKAGES\""; then
    echo "❌ site-packages non écrivable : $SITE_PACKAGES"
    exit 1
fi

#############################################
# PIP
#############################################

PIP_CMD="$PYTHON_BIN -m pip"
PIP_OPTS="--no-cache-dir"
export PYTHONNOUSERSITE=1

echo "🐍 Python utilisé : $PYTHON_BIN"

#############################################
# STATIC & MEDIA PERMISSIONS FIX
#############################################

STATIC_ROOT="$MANAGE_DIR/staticdir"
MEDIA_ROOT="$MANAGE_DIR/mediadir"

fix_perms() {
    run_root "mkdir -p '$STATIC_ROOT' '$MEDIA_ROOT'"
    run_root "chown -R '$SITE_USER':www-data '$STATIC_ROOT' '$MEDIA_ROOT'"
    run_root "find '$STATIC_ROOT' '$MEDIA_ROOT' -type d -exec chmod 2775 {} \;"
    run_root "find '$STATIC_ROOT' '$MEDIA_ROOT' -type f -exec chmod 664 {} \;"
}

#############################################
# CLEAN BAD DISTS
#############################################

clean_bad_dists() {
    echo "🧽 Nettoyage distributions invalides…"
    as_site "$PYTHON_BIN - <<'PY'
import os, shutil, sysconfig
sp = sysconfig.get_paths()['purelib']
for name in os.listdir(sp):
    p = os.path.join(sp, name)
    if name.startswith('~') or (name.endswith('.dist-info') and '~' in name):
        try:
            shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
            print('Supprimé:', p)
        except:
            pass
PY
"
}

#############################################
# DOWNLOAD PACKAGE
#############################################

TMP_ZIP="/tmp/jeiko_latest.zip"
TMP_EXTRACT="/tmp/jeiko_extracted"
ZIP_URL="${JEIKO_ZIP_URL:-https://github.com/gderouineau/jeiko/raw/refs/heads/main/jeiko-latest.zip}"

echo "📥 Téléchargement..."
curl -fL "$ZIP_URL" -o "$TMP_ZIP"

#############################################
# EXTRACT & FIX PERMISSIONS
#############################################

echo "📂 Extraction..."
rm -rf "$TMP_EXTRACT"; mkdir -p "$TMP_EXTRACT"
unzip -oq "$TMP_ZIP" -d "$TMP_EXTRACT"

# Fix permissions for extracted files
run_root "chown -R '$SITE_USER':'$SITE_USER' '$TMP_EXTRACT'"
run_root "find '$TMP_EXTRACT' -type d -exec chmod 755 {} \;"
run_root "find '$TMP_EXTRACT' -type f -exec chmod 644 {} \;"

#############################################
# FIND PACKAGE DIR
#############################################

PACKAGE_DIR="$(find "$TMP_EXTRACT" -name 'pyproject.toml' -exec dirname {} \; | head -n 1)"

if [[ -z "$PACKAGE_DIR" ]]; then
    echo "❌ pyproject.toml introuvable"
    exit 1
fi

DIST_DIR="$PACKAGE_DIR/dist"

#############################################
# UPDATE PIP
#############################################

echo "⬆️  Mise à jour pip/setuptools/wheel..."
as_site "$PIP_CMD install $PIP_OPTS --upgrade pip setuptools wheel"

clean_bad_dists

#############################################
# INSTALL REQUIREMENTS
#############################################

REQ_FILE="$(find "$TMP_EXTRACT" -name 'requirements.txt' | head -n 1)"

if [[ -n "$REQ_FILE" ]]; then
    echo "📦 Installation requirements.txt..."
    as_site "$PIP_CMD install $PIP_OPTS -r \"$REQ_FILE\""
fi

#############################################
# BUILD PACKAGE
#############################################

if ! as_site "$PYTHON_BIN -m build --version" &>/dev/null; then
    as_site "$PIP_CMD install $PIP_OPTS build"
fi

echo "🧹 Nettoyage dist..."
rm -rf "$DIST_DIR"

echo "🔧 Build package..."
pushd "$PACKAGE_DIR" >/dev/null
as_site "$PYTHON_BIN -m build"
popd >/dev/null

#############################################
# INSTALL BUILT PACKAGE
#############################################

echo "📦 Installation du package..."

ARTIFACT="$(ls "$DIST_DIR"/*.whl "$DIST_DIR"/*.tar.gz 2>/dev/null | head -n 1)"

if [[ -z "$ARTIFACT" ]]; then
    echo "❌ Aucun artefact trouvé"
    exit 1
fi

as_site "$PIP_CMD install $PIP_OPTS --force-reinstall \"$ARTIFACT\""

clean_bad_dists

#############################################
# COLLECTSTATIC & MIGRATE
#############################################

echo "🗂️  collectstatic..."
fix_perms
pushd "$MANAGE_DIR" >/dev/null
as_site "umask 0002; $PYTHON_BIN manage.py collectstatic --noinput"
echo "🛠️  migrate..."
as_site "umask 0002; $PYTHON_BIN manage.py migrate --noinput"
popd >/dev/null
fix_perms

#############################################
# RESTART SERVICES
#############################################

SERVICE_NAME="${JEIKO_GUNICORN_SERVICE:-gunicorn-$SITE_NAME}"

restart_service() {
    local svc="$1"
    if systemctl list-unit-files | grep -q "^${svc}\.service"; then
        echo "🔁 Redémarrage ${svc}..."
        run_root "systemctl restart '$svc'"
    fi
}

restart_service "nginx"
restart_service "$SERVICE_NAME"

#############################################
# CLEAN TMP
#############################################

echo "🧹 Nettoyage..."
rm -rf "$TMP_ZIP" "$TMP_EXTRACT"

#############################################
# SELF-FIX FINAL (after pip overwrite)
#############################################

NEW_SCRIPT_PATH="$(realpath "$0")"

# Fix CRLF again
if grep -q $'\r' "$NEW_SCRIPT_PATH"; then
    sed -i 's/\r$//' "$NEW_SCRIPT_PATH"
fi

chmod 750 "$NEW_SCRIPT_PATH" 2>/dev/null || true
chown jeiko-ateliersderouineau:jeiko-ateliersderouineau "$NEW_SCRIPT_PATH" 2>/dev/null || true

echo "✅ Mise à jour JEIKO terminée (script réparé)."
