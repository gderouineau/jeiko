#!/usr/bin/env bash

#############################################
# 0) SELF-FIX INITIAL (before doing anything)
#############################################

SCRIPT_PATH="$(realpath "$0")"

# Fix CRLF if present (otherwise script may not execute)
if grep -q $'\r' "$SCRIPT_PATH"; then
    sed -i 's/\r$//' "$SCRIPT_PATH"
fi

# Ensure executable bit
chmod 750 "$SCRIPT_PATH" 2>/dev/null || true

# Ensure correct owner
chown jeiko-ateliersderouineau:jeiko-ateliersderouineau "$SCRIPT_PATH" 2>/dev/null || true


#############################################
# 1) MAIN SCRIPT START
#############################################

set -euo pipefail

echo "🔄 Mise à jour du package JEIKO..."

# -----------------------------
# 0) Détections & paramètres
# -----------------------------
MANAGE_DIR="${JEIKO_MANAGE_DIR:-}"
if [[ -z "$MANAGE_DIR" ]]; then
    CUR="$PWD"; found=""
    for _ in {1..6}; do
        if [[ -f "$CUR/manage.py" ]]; then found="$CUR"; break; fi
        CUR="$(dirname "$CUR")"
    done
    if [[ -z "$found" ]]; then
        echo "❌ manage.py introuvable. Lance ce script depuis le projet ou exporte JEIKO_MANAGE_DIR=/chemin/vers/le/projet"
        exit 1
    fi
    MANAGE_DIR="$found"
fi
echo "🗂️  manage.py : $MANAGE_DIR/manage.py"

SITE_NAME="$(basename "$MANAGE_DIR")"
SITE_USER="${JEIKO_SITE_USER:-jeiko-$SITE_NAME}"

choose_python() {
    if [[ -n "${JEIKO_PYTHON:-}" && -x "${JEIKO_PYTHON}" ]]; then echo "$JEIKO_PYTHON"; return; fi
    if [[ -x "$MANAGE_DIR/venv/bin/python" ]]; then echo "$MANAGE_DIR/venv/bin/python"; return; fi
    if [[ -x "$MANAGE_DIR/.venv/bin/python" ]]; then echo "$MANAGE_DIR/.venv/bin/python"; return; fi
    if command -v python3 >/dev/null 2>&1; then echo "$(command -v python3)"; return; fi
    echo ""
}

PYTHON_BIN="$(choose_python)"
if [[ -z "$PYTHON_BIN" || ! -x "$PYTHON_BIN" ]]; then
    echo "❌ Python introuvable. Crée un venv :  cd \"$MANAGE_DIR\" && python3 -m venv venv && ./venv/bin/python -m pip install -U pip"
    exit 1
fi

# Racine du venv
VENV_DIR="$(dirname "$(dirname "$PYTHON_BIN")")"

# Helpers sudo/non-interactif
have_sudo_nonint() {
    command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null
}
run_root() {
    local cmd="$*"
    if [[ "$(id -u)" -eq 0 ]]; then
        bash -lc "$cmd"
        return $?
    fi
    if have_sudo_nonint; then
        sudo -n bash -lc "$cmd"
        return $?
    fi
    echo "⏭️  Opération root ignorée (pas de sudo non-interactif) : $cmd"
    return 1
}

# Exécuter en tant que $SITE_USER
as_site() {
    local cmd="$*"
    if [[ "$(id -un)" = "$SITE_USER" ]]; then
        bash -lc "$cmd"
    else
        sudo -u "$SITE_USER" -E bash -lc "$cmd"
    fi
}

# Vérifier que ce Python est bien un venv
IS_VENV="$(as_site "$PYTHON_BIN - <<'PY'
import sys; print(sys.prefix != getattr(sys, 'base_prefix', sys.prefix))
PY
")"
if [[ "$IS_VENV" != "True" ]]; then
    echo "❌ Le Python sélectionné n'est pas un virtualenv : $PYTHON_BIN"
    echo "   Crée un venv:  cd \"$MANAGE_DIR\" && python3 -m venv venv && ./venv/bin/python -m pip install -U pip"
    echo "   Puis relance (ou exporte JEIKO_PYTHON=\"$MANAGE_DIR/venv/bin/python\")."
    exit 1
fi

# [OWNERSHIP CHECK] : le venv doit appartenir au SITE_USER
get_owner() {
    local path="$1"
    if stat --version >/dev/null 2>&1; then stat -c %U "$path"; else stat -f %Su "$path"; fi
}
VENV_OWNER="$(get_owner "$VENV_DIR" || echo "")"
if [[ -n "$VENV_OWNER" && "$VENV_OWNER" != "$SITE_USER" ]]; then
    echo "⚠️  Le venv ($VENV_DIR) appartient à '$VENV_OWNER', attendu: '$SITE_USER'."
    if [[ "${JEIKO_FIX_VENV_OWNERSHIP:-0}" == "1" ]]; then
        echo "🔧 Correction des droits (chown -R $SITE_USER:$SITE_USER \"$VENV_DIR\")..."
        run_root "chown -R '$SITE_USER':'$SITE_USER' '$VENV_DIR'" || true
    else
        echo "ℹ️  Pour corriger automatiquement : JEIKO_FIX_VENV_OWNERSHIP=1 $0"
        echo "    Ou exécute : sudo chown -R $SITE_USER:$SITE_USER \"$VENV_DIR\""
    fi
fi

SITE_PACKAGES="$(as_site "$PYTHON_BIN - <<'PY'
import sysconfig; print(sysconfig.get_paths()['purelib'])
PY
")"
if ! as_site "test -w \"$SITE_PACKAGES\""; then
    echo "❌ Le dossier site-packages n'est pas écrivable par $SITE_USER : $SITE_PACKAGES"
    exit 1
fi

PIP_CMD="$PYTHON_BIN -m pip"
PIP_OPTS="--no-cache-dir"
export PYTHONNOUSERSITE=1
echo "🐍 Python utilisé : $PYTHON_BIN (user: $SITE_USER)"

STATIC_ROOT="$MANAGE_DIR/staticdir"
MEDIA_ROOT="$MANAGE_DIR/mediadir"

fix_perms() {
    run_root "mkdir -p '$STATIC_ROOT' '$MEDIA_ROOT'" || true
    run_root "chown -R '$SITE_USER':www-data '$STATIC_ROOT' '$MEDIA_ROOT'" || true
    run_root "find '$STATIC_ROOT' '$MEDIA_ROOT' -type d -exec chmod 2775 {} \;" || true
    run_root "find '$STATIC_ROOT' '$MEDIA_ROOT' -type f -exec chmod 664 {} \;" || true
}

clean_bad_dists() {
    echo "🧽 Nettoyage distributions invalides dans site-packages…"
    as_site "$PYTHON_BIN - <<'PY'
import os, shutil, sysconfig
sp = sysconfig.get_paths()['purelib']
bad = []
for name in os.listdir(sp):
    p = os.path.join(sp, name)
    if name.startswith('~') or (name.endswith('.dist-info') and '~' in name):
        bad.append(p)
removed=[]
for p in bad:
    try:
        shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
        removed.append(os.path.basename(p))
    except Exception:
        pass
if removed:
    print("   Supprimé:", ", ".join(removed))
else:
    print("   Rien à nettoyer.")
PY
"
}

TMP_ZIP="/tmp/jeiko_latest.zip"
TMP_EXTRACT="/tmp/jeiko_extracted"
ZIP_URL="${JEIKO_ZIP_URL:-https://github.com/gderouineau/jeiko/raw/refs/heads/main/jeiko-latest.zip}"

SERVICE_NAME="${JEIKO_GUNICORN_SERVICE:-gunicorn-$SITE_NAME}"

echo "📥 Téléchargement..."
curl -fL "$ZIP_URL" -o "$TMP_ZIP"

echo "📂 Extraction dans $TMP_EXTRACT..."
rm -rf "$TMP_EXTRACT"; mkdir -p "$TMP_EXTRACT"
unzip -oq "$TMP_ZIP" -d "$TMP_EXTRACT"

PACKAGE_DIR="$(find "$TMP_EXTRACT" -name 'pyproject.toml' -exec dirname {} \; | head -n 1 || true)"
if [[ -z "$PACKAGE_DIR" ]]; then
    echo "❌ Fichier pyproject.toml introuvable dans l'archive."
    exit 1
fi
DIST_DIR="$PACKAGE_DIR/dist"

echo "⬆️  Mise à jour pip/setuptools/wheel..."
as_site "$PIP_CMD install $PIP_OPTS --upgrade pip setuptools wheel"

clean_bad_dists

REQ_FILE="$(find "$TMP_EXTRACT" -name 'requirements.txt' | head -n 1 || true)"
if [[ -n "$REQ_FILE" ]]; then
    echo "📦 Installation requirements.txt..."
    as_site "$PIP_CMD install $PIP_OPTS -r \"$REQ_FILE\""
fi

if ! as_site "$PYTHON_BIN -m build --version" &>/dev/null; then
    echo "📚 Installation du module build..."
    as_site "$PIP_CMD install $PIP_OPTS build"
fi

echo "🧹 Nettoyage de $DIST_DIR..."
rm -rf "$DIST_DIR"
echo "🔧 Construction du package..."
pushd "$PACKAGE_DIR" >/dev/null
as_site "$PYTHON_BIN -m build >/dev/null"
popd >/dev/null

echo "📦 Installation du package..."
if compgen -G "$DIST_DIR/*.whl" > /dev/null; then
    as_site "$PIP_CMD install $PIP_OPTS --force-reinstall \"$(ls -1 "$DIST_DIR"/*.whl | head -n 1)\""
elif compgen -G "$DIST_DIR/*.tar.gz" > /dev/null; then
    as_site "$PIP_CMD install $PIP_OPTS --force-reinstall \"$(ls -1 "$DIST_DIR"/*.tar.gz | head -n 1)\""
else
    echo "❌ Aucun artefact trouvé dans $DIST_DIR"
    exit 1
fi

clean_bad_dists

echo "🗂️  Collecte statiques..."
fix_perms
pushd "$MANAGE_DIR" >/dev/null
as_site "umask 0002; $PYTHON_BIN manage.py collectstatic --noinput"
echo "🛠️  Migration..."
as_site "umask 0002; $PYTHON_BIN manage.py migrate --noinput"
popd >/dev/null
fix_perms

restart_service() {
    local svc="$1"
    if command -v systemctl >/dev/null 2>&1; then
        if systemctl list-unit-files | grep -q "^${svc}\.service"; then
            echo "🔁 Redémarrage ${svc}..."
            run_root "systemctl restart '$svc'" || echo "ℹ️  ${svc} non redémarré."
        fi
    fi
}

restart_service "nginx"
restart_service "$SERVICE_NAME"

echo "🧹 Suppression fichiers temporaires..."
rm -rf "$TMP_ZIP" "$TMP_EXTRACT"

#############################################
# 12) SELF-FIX FINAL (after pip reinstall)
#############################################

# Recalculate path (pip may have replaced this file)
NEW_SCRIPT_PATH="$(realpath "$0")"

# Fix CRLF again
if grep -q $'\r' "$NEW_SCRIPT_PATH"; then
    sed -i 's/\r$//' "$NEW_SCRIPT_PATH"
fi

chmod 750 "$NEW_SCRIPT_PATH" 2>/dev/null || true
chown jeiko-ateliersderouineau:jeiko-ateliersderouineau "$NEW_SCRIPT_PATH" 2>/dev/null || true

echo "✅ Mise à jour JEIKO terminée (script réparé)."

