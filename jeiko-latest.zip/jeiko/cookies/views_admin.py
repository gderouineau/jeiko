# cookies/views_admin.py
import csv
from io import StringIO
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.sites.shortcuts import get_current_site
from django.http import JsonResponse, HttpResponse, HttpResponseBadRequest
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views import View

from django.utils.translation import get_language

from django.shortcuts import render, redirect

from django.contrib import messages

from .forms_admin import BannerTextUpdateForm

from .models import (
    CookieBannerConfig,
    CookiePolicyVersion,
    CookieConsent,
    CookieAppSettings,
)


@method_decorator(staff_member_required, name="dispatch")
class ActivateBannerView(View):
    """
    POST /admin/cookies/activate-banner/<int:banner_id>/
    Body vide. Active la bannière et désactive les autres pour le site/locale.
    """
    def post(self, request, banner_id, *args, **kwargs):
        try:
            banner = CookieBannerConfig.objects.get(pk=banner_id)
        except CookieBannerConfig.DoesNotExist:
            return HttpResponseBadRequest("Bannière introuvable")
        banner.activate()
        return JsonResponse({"ok": True, "banner_id": banner_id})


@method_decorator(staff_member_required, name="dispatch")
class ActivatePolicyVersionView(View):
    """
    POST /admin/cookies/activate-policy/<int:policy_id>/
    Active la version de politique donnée et désactive les autres (site/locale).
    """
    def post(self, request, policy_id, *args, **kwargs):
        try:
            policy = CookiePolicyVersion.objects.get(pk=policy_id)
        except CookiePolicyVersion.DoesNotExist:
            return HttpResponseBadRequest("Version introuvable")
        policy.activate()
        return JsonResponse({"ok": True, "policy_id": policy_id, "version": policy.version})


@method_decorator(staff_member_required, name="dispatch")
class ExportConsentsCSVView(View):
    """
    GET /admin/cookies/consents/export/
    Exporte les consentements en CSV (simple).
    """
    def get(self, request, *args, **kwargs):
        site = get_current_site(request)
        qs = CookieConsent.objects.filter(site=site).order_by("-created_at")

        buffer = StringIO()
        writer = csv.writer(buffer)
        writer.writerow([
            "id", "created_at", "locale", "user_id", "session_key",
            "ip_truncated", "user_agent", "policy_version", "source",
            "is_latest", "choices", "consent_token",
        ])

        for c in qs.iterator():
            writer.writerow([
                str(c.id),
                c.created_at.isoformat(),
                c.locale,
                c.user_id or "",
                c.session_key,
                c.ip_truncated,
                (c.user_agent or "")[:200],  # tronqué pour lisibilité
                c.policy_version,
                c.source,
                "1" if c.is_latest else "0",
                c.choices,
                str(c.consent_token),
            ])

        resp = HttpResponse(buffer.getvalue(), content_type="text/csv; charset=utf-8")
        resp["Content-Disposition"] = 'attachment; filename="cookie_consents.csv"'
        return resp


@method_decorator(staff_member_required, name="dispatch")
class PurgeOldConsentsView(View):
    """
    POST /admin/cookies/consents/purge/
    Supprime les consentements plus vieux que retention_days (CookieAppSettings) ou 730j par défaut.
    """
    def post(self, request, *args, **kwargs):
        site = get_current_site(request)
        app_settings = getattr(site, "cookie_app_settings", None)
        retention_days = getattr(app_settings, "retention_days", 730)
        cutoff = timezone.now() - timezone.timedelta(days=retention_days)
        qs = CookieConsent.objects.filter(site=site, created_at__lt=cutoff)
        count = qs.count()
        qs.delete()
        return JsonResponse({"ok": True, "deleted": count, "cutoff": cutoff.isoformat()})




@method_decorator(staff_member_required, name="dispatch")
class EditBannerTextView(View):
    """
    GET/POST /admin/cookies/banner/edit/
    Édite message + labels de boutons de la bannière active (site/locale).
    Crée une bannière si aucune n'existe (et l’active).
    """
    template_name = "cookies/banner_edit.html"

    def get(self, request, *args, **kwargs):
        site = get_current_site(request)
        locale = (get_language() or "fr").lower()

        banner = CookieBannerConfig.objects.filter(site=site, locale=locale).order_by("-updated_at").first()
        if not banner:
            # On crée une bannière par défaut
            policy = CookiePolicyVersion.objects.filter(site=site, locale=locale, is_active=True)\
                                                .order_by("-published_at", "-created_at").first()
            banner = CookieBannerConfig.objects.create(
                site=site,
                locale=locale,
                policy=policy,
                message_text="Nous utilisons des cookies essentiels au fonctionnement du site.",
                accept_all_label="Tout accepter",
                refuse_all_label="Tout refuser",
                customize_label="Personnaliser",
                save_choices_label="Enregistrer",
                more_info_label="En savoir plus",
                more_info_url="",
                show_refuse_all=True,
                is_active=True,
                priority=100,
            )
        form = BannerTextUpdateForm(instance=banner)
        return render(request, self.template_name, {"form": form, "banner": banner})

    def post(self, request, *args, **kwargs):
        site = get_current_site(request)
        locale = (get_language() or "fr").lower()
        banner = CookieBannerConfig.objects.filter(site=site, locale=locale).order_by("-updated_at").first()
        if not banner:
            return HttpResponseBadRequest("Bannière introuvable (raffraîchir la page).")
        form = BannerTextUpdateForm(request.POST, instance=banner)
        if form.is_valid():
            form.save()
            messages.success(request, "Bannière mise à jour.")
            return redirect("jeiko_cookies_admin:edit_banner_text")
        return render(request, self.template_name, {"form": form, "banner": banner}, status=400)
