from django import forms

from jeiko.cookies.models import CookieBannerConfig
# jeiko_cookies/forms.py (ajout)


class BannerTextUpdateForm(forms.ModelForm):
    """
    Formulaire ultra-simple pour éditer les textes visibles côté client.
    """
    class Meta:
        model = CookieBannerConfig
        fields = [
            "message_text",
            "accept_all_label",
            "refuse_all_label",
            "customize_label",
            "save_choices_label",
            "more_info_label",
            "more_info_url",
            "show_refuse_all",
        ]
        widgets = {
            "message_text": forms.Textarea(attrs={"rows": 3, "placeholder": "Texte court de la bannière…"}),
            "more_info_url": forms.URLInput(attrs={"placeholder": "https://…/cookies/"}),
        }
