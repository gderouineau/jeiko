# cookies/urls_admin.py
from django.urls import path
from .views_admin import (
    ActivateBannerView,
    ActivatePolicyVersionView,
    ExportConsentsCSVView,
    PurgeOldConsentsView,
    EditBannerTextView,
)

app_name = "jeiko_cookies_admin"

urlpatterns = [
    # Actions d’activation
    path(
        "activate-banner/<int:banner_id>/",
        ActivateBannerView.as_view(),
        name="activate_banner"
    ),

    path(
        "activate-policy/<int:policy_id>/",
        ActivatePolicyVersionView.as_view(),
        name="activate_policy"
    ),

    # Outils consentements
    path(
        "consents/export/",
        ExportConsentsCSVView.as_view(),
        name="export_consents_csv"
    ),
    path(
        "consents/purge/",
        PurgeOldConsentsView.as_view(),
        name="purge_old_consents"
    ),

    path(
        "admin/cookies/banner/edit/",
        EditBannerTextView.as_view(),
        name="edit_banner_text"
        ),


]
