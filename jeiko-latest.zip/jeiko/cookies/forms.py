# cookies/forms.py
from __future__ import annotations

from typing import Optional, Iterable, Dict

from django import forms
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db.models import Q
from decimal import Decimal
from django.core.exceptions import ValidationError

from .models import (
    CookieCategory,
    CookieVendor,
    CookieDefinition,
    CookiePolicyVersion,
    CookieBannerConfig,
    CookieAppSettings,
    SameSite,
    DEFAULT_BANNER_STYLE,
)


# ---------- Helpers ----------

def _locale_choices() -> Iterable[tuple[str, str]]:
    # Essaie settings.LANGUAGES, sinon fallback à LANGUAGE_CODE
    langs = getattr(settings, "LANGUAGES", None)
    if langs:
        return [(code.lower(), label) for code, label in langs]
    code = (getattr(settings, "LANGUAGE_CODE", "fr") or "fr").lower()
    return [(code, code)]


def _validate_cookie_prefix_constraints(name: str, cleaned: Dict):
    """
    Contraintes standards des préfixes de cookies :
    - __Host- : Secure=True, Domain interdit (host-only), Path="/"
    - __Secure- : Secure=True
    """
    is_secure = cleaned.get("is_secure", True)
    host_only = cleaned.get("host_only", True)
    path = cleaned.get("path", "/") or "/"
    domain = (cleaned.get("domain") or "").strip()

    if name.startswith("__Host-"):
        if not is_secure:
            raise ValidationError("Un cookie '__Host-' doit avoir Secure=True.")
        if domain:
            raise ValidationError("Un cookie '__Host-' ne peut pas définir 'Domain' (host-only).")
        if path != "/":
            raise ValidationError("Un cookie '__Host-' doit avoir Path='/'.")
        if not host_only:
            raise ValidationError("Un cookie '__Host-' doit être host-only (pas de Domain).")

    if name.startswith("__Secure-") and not is_secure:
        raise ValidationError("Un cookie '__Secure-' doit avoir Secure=True.")


# ---------- Base mixins ----------

class SiteAwareFormMixin:
    """
    Permet de passer un site à l'init (site ou request.site via middleware si dispo)
    pour filtrer les QuerySets liés au Site.
    """
    def __init__(self, *args, site=None, request=None, **kwargs):
        super().__init__(*args, **kwargs)
        self._site = site or getattr(request, "site", None)
        # Si nécessaire, les sous-classes filtrent leurs QuerySets ici.


class LocaleFieldMixin:
    locale = forms.ChoiceField(choices=_locale_choices(), required=True)


# ---------- Forms: Catégories / Vendors / Definitions ----------

class CookieCategoryForm(SiteAwareFormMixin, LocaleFieldMixin, forms.ModelForm):
    class Meta:
        model = CookieCategory
        fields = [
            "site", "locale", "key", "label", "description",
            "is_essential", "is_active", "default_enabled", "display_order",
        ]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 3}),
        }

    def clean(self):
        cleaned = super().clean()
        # Règles métier pour 'essential'
        if cleaned.get("is_essential"):
            cleaned["is_active"] = True
            cleaned["default_enabled"] = True
        return cleaned


class CookieVendorForm(SiteAwareFormMixin, forms.ModelForm):
    class Meta:
        model = CookieVendor
        fields = [
            "site", "name", "website_url", "privacy_url",
            "description", "categories", "is_active",
        ]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Filtre les catégories par site si fourni
        if self._site is not None:
            self.fields["categories"].queryset = CookieCategory.objects.filter(site=self._site)


class CookieDefinitionForm(SiteAwareFormMixin, LocaleFieldMixin, forms.ModelForm):
    class Meta:
        model = CookieDefinition
        fields = [
            "site", "locale", "name", "category", "vendor",
            "purpose", "duration_days",
            "is_http_only", "is_secure", "same_site",
            "host_only", "path", "domain",
        ]
        widgets = {
            "purpose": forms.Textarea(attrs={"rows": 3}),
            "path": forms.TextInput(attrs={"placeholder": "/"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self._site is not None:
            self.fields["category"].queryset = CookieCategory.objects.filter(site=self._site, is_active=True)
            self.fields["vendor"].queryset = CookieVendor.objects.filter(site=self._site, is_active=True)

    def clean(self):
        cleaned = super().clean()
        name = cleaned.get("name") or ""
        same_site = cleaned.get("same_site")
        is_secure = cleaned.get("is_secure")
        host_only = cleaned.get("host_only")
        domain = (cleaned.get("domain") or "").strip()
        path = (cleaned.get("path") or "/").strip()

        if not path.startswith("/"):
            raise ValidationError("Le chemin (Path) doit commencer par '/'.")

        # SameSite=None => Secure obligatoire (règle navigateur)
        if same_site == SameSite.NONE and not is_secure:
            raise ValidationError("SameSite=None requiert Secure=True.")

        # host-only => domain doit être vide
        if host_only and domain:
            raise ValidationError("Si 'host_only' est coché, 'domain' doit rester vide.")

        _validate_cookie_prefix_constraints(name, cleaned)
        return cleaned


# ---------- Forms: Politique / Bannière ----------

class CookiePolicyVersionForm(SiteAwareFormMixin, LocaleFieldMixin, forms.ModelForm):
    activate_now = forms.BooleanField(
        required=False,
        help_text="Activer cette version à l'enregistrement (désactive les autres pour le même site/locale)."
    )

    class Meta:
        model = CookiePolicyVersion
        fields = [
            "site", "locale", "version", "changelog",
            "published_at", "is_active",
        ]
        widgets = {
            "changelog": forms.Textarea(attrs={"rows": 4}),
        }

    def clean(self):
        cleaned = super().clean()
        # Si is_active True, s'assurer qu'il n'existe pas déjà une autre active (feedback user-friendly)
        is_active = cleaned.get("is_active")
        site = cleaned.get("site")
        locale = cleaned.get("locale")
        if is_active and site and locale:
            qs = CookiePolicyVersion.objects.filter(site=site, locale=locale, is_active=True)
            if self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise ValidationError("Une version de politique est déjà active pour ce site/locale.")
        return cleaned

    def save(self, commit=True):
        obj = super().save(commit=commit)
        if self.cleaned_data.get("activate_now") and obj.pk:
            obj.activate()
        return obj


class ColorInput(forms.TextInput):
    input_type = "color"


FONT_CHOICES = [
    ("system-ui", "System UI"),
    ("Inter", "Inter"),
    ("Roboto", "Roboto"),
    ("Georgia", "Georgia"),
]


SHADOW_CHOICES = [
    ("none", "Aucune"),
    ("sm", "Petite"),
    ("md", "Moyenne"),
    ("lg", "Forte"),
]


class CookieBannerConfigForm(SiteAwareFormMixin, LocaleFieldMixin, forms.ModelForm):
    # === Champs STYLE (contrôlés) ===
    font_family = forms.ChoiceField(label="Police (famille)", choices=FONT_CHOICES, required=True)
    font_size_px = forms.IntegerField(label="Taille du texte (px)", min_value=10, max_value=24, required=True)
    line_height = forms.DecimalField(label="Interligne", min_value=Decimal("1.20"), max_value=Decimal("1.80"),
                                     decimal_places=2, required=True)

    banner_bg = forms.CharField(label="Fond bannière", widget=ColorInput(), required=True)
    banner_fg = forms.CharField(label="Texte bannière", widget=ColorInput(), required=True)
    link_color = forms.CharField(label="Couleur des liens", widget=ColorInput(), required=True)

    btn_radius_px = forms.IntegerField(label="Rayon des boutons (px)", min_value=0, max_value=24, required=True)
    btn_primary_bg = forms.CharField(label="Bouton primaire — fond", widget=ColorInput(), required=True)
    btn_primary_fg = forms.CharField(label="Bouton primaire — texte", widget=ColorInput(), required=True)
    btn_outline_fg = forms.CharField(label="Bouton outline — texte", widget=ColorInput(), required=True)
    btn_outline_border = forms.CharField(label="Bouton outline — bordure", widget=ColorInput(), required=True)
    btn_ghost_fg = forms.CharField(label="Bouton ghost — texte", widget=ColorInput(), required=True)

    modal_bg = forms.CharField(label="Modal — fond", widget=ColorInput(), required=True)
    modal_fg = forms.CharField(label="Modal — texte", widget=ColorInput(), required=True)
    modal_shadow = forms.ChoiceField(label="Ombre du modal", choices=SHADOW_CHOICES, required=True)

    class Meta:
        model = CookieBannerConfig
        fields = [
            "site", "locale", "policy",
            "message_text",
            "accept_all_label", "refuse_all_label", "customize_label",
            "save_choices_label", "more_info_label", "more_info_url",
            "show_refuse_all", "is_active", "priority",
            # ⚠️ NE PAS mettre "style" ici : on le reconstruit dans clean()
        ]
        widgets = {
            "message_text": forms.Textarea(attrs={"rows": 3}),
            "more_info_url": forms.URLInput(attrs={"placeholder": "https://…/politique-cookies/"}),
        }

    # --- util interne : clés de style que l'on gère ---
    _STYLE_KEYS = [
        "font_family","font_size_px","line_height",
        "banner_bg","banner_fg","link_color",
        "btn_radius_px","btn_primary_bg","btn_primary_fg",
        "btn_outline_fg","btn_outline_border","btn_ghost_fg",
        "modal_bg","modal_fg","modal_shadow",
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # 1) Filtrer la politique par site/locale (ton code existant)
        if self._site is not None:
            locale = (self.initial.get("locale") or self.fields["locale"].initial or "").lower()
            pv_qs = CookiePolicyVersion.objects.filter(site=self._site)
            if locale:
                pv_qs = pv_qs.filter(locale=locale)
            self.fields["policy"].queryset = pv_qs

        # 2) Initialiser les champs STYLE depuis instance.style ou defaults
        style = DEFAULT_BANNER_STYLE.copy()
        if self.instance and isinstance(getattr(self.instance, "style", None), dict):
            style.update(self.instance.style)

        # Pusher les initials dans les champs si présents
        for k in self._STYLE_KEYS:
            if k in self.fields:
                self.fields[k].initial = style.get(k, DEFAULT_BANNER_STYLE[k])

    def clean(self):
        cleaned = super().clean()
        site = cleaned.get("site")
        locale = cleaned.get("locale")
        is_active = cleaned.get("is_active")

        # Unicité bannière active (ton code existant)
        if is_active and site and locale:
            qs = CookieBannerConfig.objects.filter(site=site, locale=locale, is_active=True)
            if self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise ValidationError("Une bannière est déjà active pour ce site/locale.")

        # Reconstruire le JSON 'style' à partir des champs contrôlés
        new_style = {}
        for k in self._STYLE_KEYS:
            v = cleaned.get(k, DEFAULT_BANNER_STYLE[k])

            # Types propres
            if k in ("font_size_px", "btn_radius_px") and v is not None:
                v = int(v)
            if k == "line_height" and v is not None:
                # Decimal -> float
                v = float(v)

            new_style[k] = v

        # Injecter dans l'instance (pas dans cleaned_data : on veut stocker JSON)
        self.instance.style = new_style
        return cleaned


# ---------- Forms: Réglages applicatifs ----------

class CookieAppSettingsForm(SiteAwareFormMixin, LocaleFieldMixin, forms.ModelForm):
    class Meta:
        model = CookieAppSettings
        fields = [
            "site", "locale",
            "retention_days",
            "disable_tracking_for_staff", "disable_tracking_for_superusers",
            "default_same_site", "default_secure", "default_http_only",
        ]

    def clean(self):
        cleaned = super().clean()
        same_site = cleaned.get("default_same_site")
        default_secure = cleaned.get("default_secure", True)

        if same_site == SameSite.NONE and not default_secure:
            raise ValidationError("SameSite=None requiert Secure=True (réglage par défaut).")

        if (cleaned.get("retention_days") or 0) < 1:
            raise ValidationError("La rétention doit être d'au moins 1 jour.")
        return cleaned


# ---------- Formulaire de préférences de consentement (dynamique) ----------

class ConsentPreferencesForm(forms.Form):
    """
    Formulaire générique pour (dé)cocher les catégories.
    - Les catégories 'is_essential=True' sont forcées à True et désactivées.
    - Construire avec un queryset de catégories (idéalement filtré par site/locale).
    Utilisation :
        form = ConsentPreferencesForm.from_categories(categories_qs, data=request.POST or None)
    """
    def __init__(self, *args, categories: Optional[Iterable[CookieCategory]] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self._categories = list(categories or [])
        for cat in self._categories:
            field = forms.BooleanField(
                required=False,
                initial=(True if cat.is_essential else cat.default_enabled),
                disabled=cat.is_essential,
                label=cat.label,
                help_text=cat.description,
            )
            self.fields[f"cat__{cat.key}"] = field

    @classmethod
    def from_categories(cls, categories_qs, *args, **kwargs) -> "ConsentPreferencesForm":
        return cls(*args, categories=list(categories_qs), **kwargs)

    def choices_dict(self) -> Dict[str, bool]:
        """
        Retourne un dict {category_key: bool}
        """
        out: Dict[str, bool] = {}
        for cat in self._categories:
            key = f"cat__{cat.key}"
            val = self.cleaned_data.get(key)
            out[cat.key] = True if cat.is_essential else bool(val)
        return out
