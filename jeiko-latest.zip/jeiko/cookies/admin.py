# cookies/admin.py
from django.contrib import admin
from .models import (
    CookieCategory,
    CookieVendor,
    CookieDefinition,
    CookiePolicyVersion,
    CookieBannerConfig,
    CookieConsent,
    CookieAppSettings,
)

admin.site.register(CookieCategory)
admin.site.register(CookieVendor)
admin.site.register(CookieDefinition)
admin.site.register(CookiePolicyVersion)
admin.site.register(CookieBannerConfig)
admin.site.register(CookieConsent)
admin.site.register(CookieAppSettings)
