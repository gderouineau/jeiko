from django.http import HttpResponsePermanentRedirect
from django.shortcuts import render
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import ensure_csrf_cookie
from django.urls import reverse

from ..models import CustomObject, CustomObjectField


@method_decorator(ensure_csrf_cookie, name="get")
class CustomObjectView(View):
    """
    Vue client pour afficher un objet custom :
    URL canonique : /<model_slug>/<object_slug>/
    """

    template_name = "pages/main.html"  # même template que PageView

    def get(self, request, *args, **kwargs):
        model_slug = kwargs.get("model_slug")
        object_slug = kwargs.get("object_slug")

        # Récupération de l'objet + modèle + page template
        obj = (
            CustomObject.objects
            .select_related("model", "model__page_template")
            .prefetch_related(
                "values__field",
                "values__image",
                "values__button_page",  # pour les boutons
            )
            .get(model__slug=model_slug, slug=object_slug)
        )

        # Canonical check
        canonical_path = obj.get_absolute_url()
        if request.path != canonical_path:
            return HttpResponsePermanentRedirect(canonical_path)

        page = obj.model.page_template

        # Contexte de base
        context = {
            "page": page,
            "custom_object": obj,
            "object": obj,  # alias si besoin
        }

        # Metadata éventuelle
        metadata = getattr(obj, "metadata", None)
        if metadata is not None:
            context["metadata"] = metadata

        # Injection des valeurs des champs dans le contexte
        for value in obj.values.all():
            code = value.field.code
            if not code:
                continue

            field_type = value.field.field_type

            if field_type in (CustomObjectField.TEXT, CustomObjectField.RICH_TEXT):
                context[code] = value.value_text

            elif field_type == CustomObjectField.IMAGE:
                context[code] = value.image  # ImageContent

            elif field_type == CustomObjectField.VIDEO:
                context[code] = value.video_url

            elif field_type == CustomObjectField.BUTTON:
                # Construire l’URL comme pour ContentButton
                url = "#"

                if getattr(value, "button_page", None):
                    try:
                        url = value.button_page.get_absolute_url()
                    except Exception:
                        url = "#"

                elif getattr(value, "button_test_slug", None):
                    slug = (value.button_test_slug or "").strip()
                    if slug:
                        try:
                            url = reverse(
                                "questionnaires_expert:question",
                                kwargs={"slug": slug, "index": 0},
                            )
                        except Exception:
                            url = f"/pass-test/{slug}/question/0/"

                elif getattr(value, "button_external_url", None):
                    url = (value.button_external_url or "").strip() or "#"

                label = (value.button_label or "").strip()

                # On stocke un dict : les template tags s’en serviront
                context[code] = {
                    "url": url,
                    "label": label,
                }

        return render(request, self.template_name, context)
