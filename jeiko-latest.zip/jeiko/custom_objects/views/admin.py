from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.db import transaction
from django.forms import inlineformset_factory
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse, reverse_lazy
from django.views.generic import (
    ListView,
    CreateView,
    UpdateView,
    DeleteView,
)
from django.views import View

from ..models import (
    CustomObjectModel,
    CustomObjectField,
    CustomObject,
    CustomObjectValue,
    CustomObjectMetadata,
)
from ..forms import (
    CustomObjectModelForm,
    CustomObjectFieldForm,
    CustomObjectForm,
    CustomObjectValueForm,
    CustomObjectMetadataForm,
)


class StaffRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """
    Mixin simple pour limiter l'accès à l'admin
    (tu peux adapter selon ton middleware JEIKO).
    """

    def test_func(self):
        user = self.request.user
        return user.is_staff or user.is_superuser


# -------------------------------------------------------------------
#  Inline formsets
# -------------------------------------------------------------------

CustomObjectFieldFormSet = inlineformset_factory(
    CustomObjectModel,
    CustomObjectField,
    form=CustomObjectFieldForm,
    extra=0,
    can_delete=True,
)

CustomObjectValueFormSet = inlineformset_factory(
    CustomObject,
    CustomObjectValue,
    form=CustomObjectValueForm,
    extra=0,
    can_delete=False,
)


# -------------------------------------------------------------------
#  CustomObjectModel (parent : Article, Produit, Livre, etc.)
# -------------------------------------------------------------------

class CustomObjectModelListView(StaffRequiredMixin, ListView):
    model = CustomObjectModel
    template_name = "custom_objects/admin/model_list.html"
    context_object_name = "models"


class CustomObjectModelCreateView(StaffRequiredMixin, CreateView):
    model = CustomObjectModel
    form_class = CustomObjectModelForm
    template_name = "custom_objects/admin/model_form.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.method == "POST":
            context["field_formset"] = CustomObjectFieldFormSet(self.request.POST)
        else:
            context["field_formset"] = CustomObjectFieldFormSet()
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        field_formset = context["field_formset"]

        if form.is_valid() and field_formset.is_valid():
            with transaction.atomic():
                self.object = form.save()
                field_formset.instance = self.object
                field_formset.save()
            messages.success(self.request, "Modèle créé avec succès.")
            return redirect(self.get_success_url())

        return self.render_to_response(self.get_context_data(form=form))

    def get_success_url(self):
        return reverse("jeiko_administration_custom_objects:model_update", args=[self.object.pk])


class CustomObjectModelUpdateView(StaffRequiredMixin, UpdateView):
    model = CustomObjectModel
    form_class = CustomObjectModelForm
    template_name = "custom_objects/admin/model_form.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.method == "POST":
            context["field_formset"] = CustomObjectFieldFormSet(
                self.request.POST,
                instance=self.object,
            )
        else:
            context["field_formset"] = CustomObjectFieldFormSet(instance=self.object)
        return context

    def form_valid(self, form):
        context = self.get_context_data()
        field_formset = context["field_formset"]

        if field_formset.is_valid():
            self.object = form.save()
            field_formset.instance = self.object
            field_formset.save()
            messages.success(self.request, "Modèle et champs mis à jour.")
            return redirect(self.get_success_url())

        # Si le formset est invalide, on renvoie les erreurs
        return self.render_to_response(self.get_context_data(form=form))

    def get_success_url(self):
        return reverse("jeiko_administration_custom_objects:model_update", args=[self.object.pk])


class CustomObjectModelDeleteView(StaffRequiredMixin, DeleteView):
    model = CustomObjectModel
    template_name = "custom_objects/admin/model_confirm_delete.html"
    success_url = reverse_lazy("jeiko_administration_custom_objects:model_list")

    def delete(self, request, *args, **kwargs):
        messages.success(self.request, "Modèle supprimé.")
        return super().delete(request, *args, **kwargs)


# -------------------------------------------------------------------
#  CustomObject (enfant : un article concret, un produit concret, etc.)
#  NB : tout passe maintenant par l'URL /models/<model_pk>/objects/...
# -------------------------------------------------------------------

class CustomObjectListView(StaffRequiredMixin, ListView):
    model = CustomObject
    template_name = "custom_objects/admin/object_list.html"
    context_object_name = "objects"

    def get_queryset(self):
        """
        Liste uniquement les objets du modèle passé dans l'URL.
        """
        model_pk = self.kwargs["model_pk"]
        return (
            CustomObject.objects
            .filter(model_id=model_pk)
            .select_related("model")
            .order_by("title")
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        model_pk = self.kwargs["model_pk"]
        context["model"] = get_object_or_404(CustomObjectModel, pk=model_pk)
        return context


class CustomObjectCreateView(StaffRequiredMixin, CreateView):
    """
    V1 : création de l'objet sans les valeurs.
    Après création, on redirige vers l'édition,
    où l'on gère les valeurs + SEO.
    """

    model = CustomObject
    form_class = CustomObjectForm
    template_name = "custom_objects/admin/object_form.html"

    def dispatch(self, request, *args, **kwargs):
        self.model_obj = get_object_or_404(CustomObjectModel, pk=self.kwargs["model_pk"])
        return super().dispatch(request, *args, **kwargs)

    def get_initial(self):
        initial = super().get_initial()
        initial["model"] = self.model_obj
        return initial

    def form_valid(self, form):
        context = self.get_context_data()
        values_formset = context["values_formset"]

        # On force le modèle depuis l'URL
        form.instance.model = self.model_obj

        if form.is_valid() and values_formset.is_valid():
            with transaction.atomic():
                self.object = form.save()
                
                # Sauvegarde des valeurs
                values_formset.instance = self.object
                values_formset.save()
                
                # Création auto des metadata vides si besoin
                CustomObjectMetadata.objects.get_or_create(obj=self.object)

            messages.success(self.request, "Objet créé avec succès.")
            return redirect(self.get_success_url())

        return self.render_to_response(self.get_context_data(form=form))

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["model"] = self.model_obj
        
        if self.request.method == "POST":
            context["values_formset"] = CustomObjectValueFormSet(
                self.request.POST,
                self.request.FILES
            )
        else:
            # Pré-remplir le formset avec tous les champs du modèle
            initial_data = []
            for field in self.model_obj.fields.all():
                initial_data.append({'field': field})
            
            context["values_formset"] = CustomObjectValueFormSet(
                initial=initial_data
            )
            # Important : dire au formset d'afficher autant de forms que de champs
            context["values_formset"].extra = len(initial_data)
            
        return context

    def get_success_url(self):
        return reverse(
            "jeiko_administration_custom_objects:object_update",
            kwargs={"model_pk": self.model_obj.pk, "pk": self.object.pk},
        )


class CustomObjectUpdateView(StaffRequiredMixin, UpdateView):
    model = CustomObject
    form_class = CustomObjectForm
    template_name = "custom_objects/admin/object_form.html"

    def get_queryset(self):
        """
        Sécurise : on ne peut éditer que des objets appartenant
        au modèle donné dans l'URL.
        """
        model_pk = self.kwargs["model_pk"]
        return CustomObject.objects.filter(model_id=model_pk).select_related("model")

    def _ensure_all_values_exist(self, obj: CustomObject):
        """
        S'assure qu'il existe une CustomObjectValue pour
        chaque CustomObjectField du modèle.
        """
        existing = {v.field_id for v in obj.values.all()}
        # obj.model est une instance de CustomObjectModel,
        # et "fields" est le related_name de CustomObjectField
        for field in obj.model.fields.all():
            if field.id not in existing:
                CustomObjectValue.objects.create(obj=obj, field=field)

    def _get_metadata_instance(self):
        metadata, _created = CustomObjectMetadata.objects.get_or_create(obj=self.object)
        return metadata

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # modèle depuis l'objet courant
        context["model"] = self.object.model

        # S'assurer que toutes les valeurs existent
        self._ensure_all_values_exist(self.object)

        if self.request.method == "POST":
            context["values_formset"] = CustomObjectValueFormSet(
                self.request.POST,
                self.request.FILES,
                instance=self.object,
            )
            context["metadata_form"] = CustomObjectMetadataForm(
                self.request.POST,
                instance=self._get_metadata_instance(),
                prefix="meta",
            )
        else:
            context["values_formset"] = CustomObjectValueFormSet(instance=self.object)
            context["metadata_form"] = CustomObjectMetadataForm(
                instance=self._get_metadata_instance(),
                prefix="meta",
            )

        return context

    def form_valid(self, form):
        # IMPORTANT: Ne pas appeler get_context_data() ici car ça recrée les formsets
        # et perd les fichiers uploadés !
        # On recrée manuellement avec les mêmes données que lors de la validation
        values_formset = CustomObjectValueFormSet(
            self.request.POST,
            self.request.FILES,
            instance=self.object,
        )
        metadata_form = CustomObjectMetadataForm(
            self.request.POST,
            instance=self._get_metadata_instance(),
            prefix="meta",
        )

        print(f"DEBUG form_valid: values_formset.is_valid()={values_formset.is_valid()}")
        print(f"DEBUG form_valid: metadata_form.is_valid()={metadata_form.is_valid()}")
        if not values_formset.is_valid():
            print(f"DEBUG form_valid: values_formset.errors={values_formset.errors}")
        
        if values_formset.is_valid() and metadata_form.is_valid():
            print("DEBUG form_valid: ENTERING SAVE BLOCK")
            self.object = form.save()

            # Valeurs
            values_formset.instance = self.object
            values_formset.save()
            print("DEBUG form_valid: values_formset.save() DONE")

            # Metadata
            metadata = metadata_form.save(commit=False)
            metadata.obj = self.object
            metadata.save()

            messages.success(self.request, "Objet et contenus mis à jour.")
            return redirect(self.get_success_url())

        # Si formset ou metadata invalide -> afficher erreurs
        print("DEBUG form_valid: VALIDATION FAILED, returning to form")
        return self.render_to_response(self.get_context_data(form=form, values_formset=values_formset, metadata_form=metadata_form))

    def get_success_url(self):
        return reverse(
            "jeiko_administration_custom_objects:object_update",
            kwargs={"model_pk": self.object.model_id, "pk": self.object.pk},
        )


class CustomObjectDeleteView(StaffRequiredMixin, DeleteView):
    model = CustomObject
    template_name = "custom_objects/admin/object_confirm_delete.html"

    def get_queryset(self):
        """
        Même sécurité que pour Update : on ne supprime que
        des objets du modèle de l'URL.
        """
        model_pk = self.kwargs["model_pk"]
        return CustomObject.objects.filter(model_id=model_pk)

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        messages.success(self.request, "Objet supprimé.")
        return super().delete(request, *args, **kwargs)

    def get_success_url(self):
        return reverse(
            "jeiko_administration_custom_objects:object_list",
            kwargs={"model_pk": self.object.model_id},
        )


# -------------------------------------------------------------------
#  Duplication d'un CustomObject
# -------------------------------------------------------------------

class CustomObjectDuplicateView(StaffRequiredMixin, View):
    """
    Duplique un CustomObject existant :
    - même model, title, main_image
    - slug += suffixe aléatoire (6 caractères)
    - is_published = False
    - date_created / date_updated remis à zéro (auto par Django)
    - CustomObjectValue dupliquées
    - CustomObjectMetadata dupliquée
    """

    def get(self, request, model_pk, pk):
        import uuid

        original = get_object_or_404(
            CustomObject.objects.select_related("model"),
            pk=pk,
            model_id=model_pk,
        )

        # Slug unique : slug original + suffixe aléatoire de 6 caractères
        suffix = uuid.uuid4().hex[:6]
        new_slug = f"{original.slug}-{suffix}"

        with transaction.atomic():
            # Création du nouvel objet
            new_obj = CustomObject.objects.create(
                model=original.model,
                title=original.title,
                slug=new_slug,
                is_published=False,
                main_image=original.main_image,
            )

            # Duplication des CustomObjectValue
            original_values = list(original.values.select_related("field").all())
            for value in original_values:
                CustomObjectValue.objects.create(
                    obj=new_obj,
                    field=value.field,
                    value_text=value.value_text,
                    image=value.image,
                    video_url=value.video_url,
                    button_label=value.button_label,
                    button_page=value.button_page,
                    button_test_slug=value.button_test_slug,
                    button_external_url=value.button_external_url,
                )

            # Duplication des Metadata
            if hasattr(original, 'metadata') and original.metadata:
                original_meta = original.metadata
                CustomObjectMetadata.objects.create(
                    obj=new_obj,
                    title=original_meta.title,
                    description=original_meta.description,
                )
            else:
                CustomObjectMetadata.objects.create(obj=new_obj)

        messages.success(request, f"Objet « {original.title} » dupliqué avec succès.")
        return redirect(
            reverse(
                "jeiko_administration_custom_objects:object_list",
                kwargs={"model_pk": model_pk},
            )
        )

