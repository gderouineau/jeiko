from django.apps import AppConfig


class CustomObjectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko.custom_objects'
