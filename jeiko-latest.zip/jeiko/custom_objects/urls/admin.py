from django.urls import path
from jeiko.custom_objects.views import admin as admin_views

app_name = 'jeiko_administration_custom_objects'

urlpatterns = [
    # ----------------------------
    #  Modèles d'objets
    # ----------------------------
    path(
        "models/",
        admin_views.CustomObjectModelListView.as_view(),
        name="model_list",
    ),
    path(
        "models/add/",
        admin_views.CustomObjectModelCreateView.as_view(),
        name="model_create",
    ),
    path(
        "models/<int:pk>/edit/",
        admin_views.CustomObjectModelUpdateView.as_view(),
        name="model_update",
    ),
    path(
        "models/<int:pk>/delete/",
        admin_views.CustomObjectModelDeleteView.as_view(),
        name="model_delete",
    ),

    # ----------------------------
    #  Objets selon un modèle donné
    # ----------------------------
    path(
        "models/<int:model_pk>/objects/",
        admin_views.CustomObjectListView.as_view(),
        name="object_list",
    ),
    path(
        "models/<int:model_pk>/objects/add/",
        admin_views.CustomObjectCreateView.as_view(),
        name="object_create",
    ),
    path(
        "models/<int:model_pk>/objects/<int:pk>/edit/",
        admin_views.CustomObjectUpdateView.as_view(),
        name="object_update",
    ),
    path(
        "models/<int:model_pk>/objects/<int:pk>/delete/",
        admin_views.CustomObjectDeleteView.as_view(),
        name="object_delete",
    ),
    path(
        "models/<int:model_pk>/objects/<int:pk>/duplicate/",
        admin_views.CustomObjectDuplicateView.as_view(),
        name="object_duplicate",
    ),
]
