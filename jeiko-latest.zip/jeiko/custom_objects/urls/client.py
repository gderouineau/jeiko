from django.urls import path
from jeiko.custom_objects.views import client as client_views

app_name = "jeiko_client_custom_objects"

urlpatterns = [
    path(
        "<slug:model_slug>/<slug:object_slug>/",
        client_views.CustomObjectView.as_view(),
        name="detail",
    ),
]
