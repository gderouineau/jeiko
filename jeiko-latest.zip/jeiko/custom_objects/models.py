from django.db import models
from django.utils.text import slugify
from django.core.exceptions import ValidationError





class CustomObjectModel(models.Model):
    """
    Définit un "type" d’objet dynamique :
    - Article
    - Livre
    - Produit (côté shop)
    - Formation
    - Etc.

    Chaque modèle est associé à une Page template
    comportant des tokens [%code_champ%].
    """

    name = models.CharField(max_length=150)
    slug = models.SlugField(
        max_length=200,
        unique=True,
        help_text="Ex : article, produit, livre. Sert dans l’URL."
    )

    page_template = models.ForeignKey(
        'administration_pages.Page',
        on_delete=models.PROTECT,
        related_name="custom_object_models",
        limit_choices_to={"is_custom_object_template": True},
        help_text="Page servant de gabarit visuel pour ce type d'objet."
    )

    date_created = models.DateTimeField(auto_now_add=True)

    is_product = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Modèle d'objet personnalisé"
        verbose_name_plural = "Modèles d'objets personnalisés"
        ordering = ["name"]

    def __str__(self):
        return self.name

    def clean(self):
        self.slug = slugify(self.slug or "")
        if not self.slug:
            raise ValidationError({"slug": "Le slug du modèle est requis."})


class CustomObjectField(models.Model):
    """
    Les champs définis sur un modèle d'objet.
    Ex :
        - title (text)
        - description (rich_text)
        - cover_image (image)
        - video_url (video)
        - cta_principal (button)
    """

    TEXT = "text"
    RICH_TEXT = "rich_text"
    IMAGE = "image"
    VIDEO = "video"
    BUTTON = "button"

    FIELD_TYPES = [
        (TEXT, "Texte court"),
        (RICH_TEXT, "Texte riche (Quill)"),
        (IMAGE, "Image"),
        (VIDEO, "Vidéo (URL)"),
        (BUTTON, "Bouton / Lien"),
    ]

    model = models.ForeignKey(
        CustomObjectModel,
        on_delete=models.CASCADE,
        related_name="fields"
    )

    code = models.SlugField(
        max_length=100,
        help_text="Code utilisé dans les templates : [%code%]."
    )

    label = models.CharField(max_length=200)
    field_type = models.CharField(max_length=30, choices=FIELD_TYPES)

    required = models.BooleanField(default=False)
    help_text = models.CharField(max_length=255, blank=True)
    position = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = (("model", "code"),)
        ordering = ["position", "id"]
        verbose_name = "Champ de modèle custom"
        verbose_name_plural = "Champs de modèles custom"

    def __str__(self):
        return f"{self.model.name} > {self.label} ({self.code})"

    def clean(self):
        self.code = slugify(self.code or "")
        if not self.code:
            raise ValidationError({"code": "Le code est requis."})


class CustomObject(models.Model):
    """
    Une instance (enfant) d’un modèle.
    Ex :
        - Article : Les 5 erreurs à éviter
        - Produit : Gourde 500ml
        - Livre : Le guide complet du Flow
    """

    model = models.ForeignKey(
        CustomObjectModel,
        on_delete=models.PROTECT,
        related_name="custom_objects"
    )

    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200)

    is_published = models.BooleanField(default=False)

    main_image = models.ForeignKey(
        'administration_pages.ImageContent',
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name='related_custom_objects',
        verbose_name='Image Principale'
    )

    date_created = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = (("model", "slug"),)
        ordering = ["-date_created"]
        verbose_name = "Objet personnalisé"
        verbose_name_plural = "Objets personnalisés"

    def __str__(self):
        return f"{self.model.name} – {self.title}"

    @property
    def description(self):
        """
        Retrieves description from metadata if available.
        """
        if hasattr(self, 'metadata'):
             return self.metadata.description
        return ""

    @property
    def excerpt(self):
        return self.description

    def get_absolute_url(self):
        # /co/<slug_model>/<slug_obj>/
        return f"/co/{self.model.slug}/{self.slug}/"

    def clean(self):
        self.slug = slugify(self.slug or "")
        if not self.slug:
            raise ValidationError({"slug": "Le slug est requis pour cet objet."})


class CustomObjectValue(models.Model):
    """
    Valeur d'un champ pour une instance d'objet.
    Gère plusieurs types :
        - Texte / RichText → value_text
        - Image → image
        - Vidéo → video_url
        - Bouton → button_* (cible + label)
    """

    obj = models.ForeignKey(
        CustomObject,
        on_delete=models.CASCADE,
        related_name="values"
    )

    field = models.ForeignKey(
        CustomObjectField,
        on_delete=models.CASCADE,
        related_name="values"
    )

    value_text = models.TextField(blank=True)
    image = models.ForeignKey(
        'administration_pages.ImageContent',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    video_url = models.URLField(blank=True)

    button_label = models.CharField(
        max_length=200,
        blank=True,
        default="",
        verbose_name="Texte du bouton (optionnel)"
    )
    button_page = models.ForeignKey(
        'administration_pages.Page',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="customobject_button_values",
        verbose_name="Page cible (bouton)"
    )
    button_test_slug = models.CharField(
        max_length=100,
        blank=True,
        default="",
        verbose_name="Slug de test (bouton)"
    )
    button_external_url = models.URLField(
        blank=True,
        default="",
        verbose_name="URL externe (bouton)"
    )


    class Meta:
        unique_together = (("obj", "field"),)
        verbose_name = "Valeur d'objet"
        verbose_name_plural = "Valeurs d'objet"

    def __str__(self):
        return f"{self.obj} – {self.field.code}"

    def clean(self):
        # Validation simple : vérifier que le type correspond
        if self.field.field_type == CustomObjectField.TEXT and not self.value_text:
            if self.field.required:
                raise ValidationError("Ce champ texte est requis.")

        if self.field.field_type == CustomObjectField.RICH_TEXT and not self.value_text:
            if self.field.required:
                raise ValidationError("Ce champ riche est requis.")

        if self.field.field_type == CustomObjectField.IMAGE and not self.image:
            if self.field.required:
                raise ValidationError("Cette image est requise.")

        if self.field.field_type == CustomObjectField.VIDEO and not self.video_url:
            if self.field.required:
                raise ValidationError("L’URL vidéo est requise.")

        if self.field.field_type == CustomObjectField.BUTTON:
            filled = [
                bool(self.button_page),
                bool(self.button_test_slug.strip()),
                bool(self.button_external_url.strip()),
            ]
            if sum(filled) > 1:
                raise ValidationError(
                    "Le bouton doit pointer soit vers une page, soit vers un test, soit vers une URL externe, pas plusieurs.")
            if self.field.required and sum(filled) == 0:
                raise ValidationError("Ce bouton doit avoir une destination (page, test ou lien externe).")

class CustomObjectMetadata(models.Model):
    """
    SEO spécifique à chaque objet, indépendant du template.
    (contraire de Page.metadata qui est pour les pages classiques)
    """

    obj = models.OneToOneField(
        CustomObject,
        on_delete=models.CASCADE,
        related_name="metadata"
    )

    title = models.CharField(max_length=100, blank=True, default="")
    description = models.TextField(blank=True, default="")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Metadata (objet custom)"
        verbose_name_plural = "Metadata (objets custom)"

    def __str__(self):
        return f"Metadata – {self.obj}"
