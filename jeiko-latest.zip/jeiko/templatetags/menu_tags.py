# jeiko/administration_menu/templatetags/menu_tags.py
from django import template
from django.core.cache import cache
from django.template.loader import render_to_string
from django.db.models import Prefetch, Q

from jeiko.administration_menu.models import Menu, MenuItem, MenuPlace

register = template.Library()

MENU_RENDER_TTL = 60 * 60 * 24 * 30  # 30 jours


def _get_default_menu(place: str):
    return (
        Menu.objects
        .filter(place=place, is_default=True)
        .select_related('menu_style')
        .first()
    )


def _prefetch_menu_by_id(menu_id):
    """Charge le menu (avec ses items préfetchés) à partir de son id."""
    if not menu_id:
        return None
    # Une entrée dont la page est dépubliée est retirée du menu.
    #
    # Sans ce filtre, deux comportements également mauvais : l'entrée mène à une
    # page qui ne doit plus être servie (donc une 404 depuis la navigation du
    # site lui-même), ou — si la page a été supprimée, la clé étrangère passant
    # à NULL — le gabarit rend « # » et le clic ne fait rien.
    #
    # Q(page__isnull=True) garde les entrées SANS page : ce sont les libellés de
    # regroupement qui n'ont jamais eu vocation à être cliquables.
    items_qs = (
        MenuItem.objects
        .filter(active=True)
        .filter(Q(page__isnull=True) | Q(page__active=True))
        .select_related('page')
        .order_by('position', 'pk')
    )
    return (
        Menu.objects
        .filter(pk=menu_id)
        .select_related('menu_style')
        .prefetch_related(Prefetch('menu_items', queryset=items_qs))
        .first()
    )


def _prefetch_menu(menu: Menu):
    """Retourne le menu avec ses items préfetchés (pages incluses)."""
    if not menu:
        return None
    return _prefetch_menu_by_id(menu.pk)




def _resolve_menu_for_page(place: str, page):
    """
    Priorités:
      1) Sous-catégorie (menu de l’emplacement)
      2) Parent de la sous-catégorie (menu de l’emplacement)
      3) Catégorie (menu de l’emplacement)
      4) Menu par défaut pour l’emplacement (is_default=True)
      5) None
    """
    if page is not None:
        sub = getattr(page, 'sub_category', None)
        if place == 'MAIN':
            # 1) sub.main_menu ?
            if sub and getattr(sub, 'main_menu_id', None):
                m = sub.main_menu
                if m and m.place == 'MAIN':
                    return m
            # 2) parent.main_menu ?
            if sub and getattr(sub, 'main_category', None):
                parent = sub.main_category
                if getattr(parent, 'main_menu_id', None):
                    m = parent.main_menu
                    if m and m.place == 'MAIN':
                        return m
            # 3) cat.main_menu ?
            cat = getattr(page, 'category', None)
            if cat and getattr(cat, 'main_menu_id', None):
                m = cat.main_menu
                if m and m.place == 'MAIN':
                    return m
        else:
            # place == 'FOOTER' (au cas où tu veux l’unifier plus tard)
            if sub and getattr(sub, 'footer_menu_id', None):
                m = sub.footer_menu
                if m and m.place == 'FOOTER':
                    return m
            if sub and getattr(sub, 'main_category', None):
                parent = sub.main_category
                if getattr(parent, 'footer_menu_id', None):
                    m = parent.footer_menu
                    if m and m.place == 'FOOTER':
                        return m
            cat = getattr(page, 'category', None)
            if cat and getattr(cat, 'footer_menu_id', None):
                m = cat.footer_menu
                if m and m.place == 'FOOTER':
                    return m

    # 4) défaut
    return Menu.objects.filter(place=place, is_default=True).select_related('menu_style').first()



@register.simple_tag
def get_menu(place="MAIN"):
    """
    Version générique: renvoie simplement le 1er menu pour place (deprecated pour ton MAIN).
    Garde pour compatibilité si d'autres templates l'utilisent.
    """
    place = place or MenuPlace.MAIN
    cache_key = f"menu:place:{place}:generic"
    # On ne cache que l'id (pas l'instance ORM : pickler un objet Django et ses
    # relations préfetchées est fragile et casse au moindre changement de modèle).
    menu_id = cache.get(cache_key, -1)
    if menu_id == -1:
        menu = (
            Menu.objects
            .filter(place=place)
            .values_list('pk', flat=True)
            .first()
        )
        menu_id = menu or 0
        cache.set(cache_key, menu_id, 60 * 60)
    if not menu_id:
        return None
    return (
        Menu.objects
        .filter(pk=menu_id)
        .select_related('menu_style')
        .first()
    )


@register.simple_tag(takes_context=True)
def get_main_menu(context):
    """
    Résout le menu MAIN en fonction de la page courante (si présente dans le contexte).
    Usage inchangé dans le template : {% get_main_menu as menu %}
    """
    page = context.get('page')  # RootPage / PageView mettent bien 'page' dans le contexte
    place = MenuPlace.MAIN

    # Clé de cache dépendante de la page/cat/sub -> même rendu que le menu choisi
    page_id = getattr(page, 'id', None)
    cat_id = getattr(getattr(page, 'category', None), 'id', None)
    sub_id = getattr(getattr(page, 'sub_category', None), 'id', None)
    cache_key = f"menu:resolve:place:{place}:p:{page_id}:c:{cat_id}:s:{sub_id}"

    # On ne cache que la décision de résolution (l'id du menu retenu), pas
    # l'instance ORM. Le rendu HTML lui-même est mémorisé par render_main_menu.
    menu_id = cache.get(cache_key, -1)
    if menu_id == -1:
        chosen = _resolve_menu_for_page(place, page)
        menu_id = chosen.pk if chosen else 0
        # Cache court : la résolution dépend de l'affectation des menus aux
        # catégories/sous-catégories, qui peut changer hors save de Menu.
        cache.set(cache_key, menu_id, 60 * 15)  # 15 minutes

    return _prefetch_menu_by_id(menu_id) if menu_id else None


@register.simple_tag(takes_context=True)
def render_main_menu(context):
    """
    Rendu HTML du menu MAIN, dépendant de la page (cache par menu.id).
    Invalider cette clé quand Menu/MenuItem/MenuStyle changent.
    """
    menu = get_main_menu(context)
    if not menu:
        return ""

    # Par langue du visiteur : les titres et les adresses en dépendent.
    from jeiko.langues_du_site import langue_du_site
    langue = langue_du_site()
    render_key = f"menu:render:{menu.id}:{langue}" if langue else f"menu:render:{menu.id}"
    html = cache.get(render_key)
    if html is not None:
        from django.utils.html import mark_safe
        return mark_safe(html)

    html = render_to_string("menu/main.html", {"menu": menu})
    cache.set(render_key, html, MENU_RENDER_TTL)

    from django.utils.html import mark_safe
    return mark_safe(html)


# --------------------------------------------------------------------------- #
# MENU-01 (12/10/2026) — options ajoutées aux menus
#
# Un menu d'avant n'en a aucune : `classes` est vide, `enveloppe` est faux, et
# son HTML reste octet pour octet celui d'avant (tests/test_rendu_actuel_fige).
# --------------------------------------------------------------------------- #
@register.simple_tag
def options_du_menu(menu, page=None):
    style = getattr(menu, "menu_style", None)
    classes = []
    if style is not None and getattr(style, "survol", ""):
        classes.append(f"jk-survol-{style.survol}")
    if style is not None and getattr(style, "forme", ""):
        classes.append(f"jk-forme-{style.forme}")
    # La case « Menu collant » (`sticky`) existait sans effet ; branchée le
    # 12/10/2026. Décochée par défaut : un menu qui ne l'a pas ne change pas.
    collant = bool(style is not None and getattr(style, "sticky", False))
    if collant:
        classes.append("jk-menu-collant")
    # Une version traduite suit sa page d'origine : la case ne se coche qu'une fois.
    origine = getattr(page, "traduction_de", None) or page
    transparent = bool(getattr(origine, "menu_transparent", False))
    if transparent:
        classes.append("jk-menu-transparent")
    barre = bool(getattr(menu, "barre_infos", False))
    return {
        "classes": "".join(f" {c}" for c in classes),
        "transparent": transparent,
        "texte_bandeau": (getattr(style, "transparent_texte", "") or "#ffffff") if style else "#ffffff",
        "enveloppe": transparent or barre,
        "barre": barre,
        "collant": collant,
    }


#: Réseaux dont JEIKO dessine l'icône ; les autres prennent l'icône « lien ».
RESEAUX_DESSINES = {"instagram", "facebook", "linkedin", "youtube", "x", "tiktok", "pinterest", "whatsapp"}


@register.simple_tag
def coordonnees_du_site():
    """
    Ce que la barre d'infos, le panneau « burger » et les pieds de page
    affichent du site : nom, téléphone, adresse, réseaux actifs. Lu dans les
    coordonnées (Réglages ▸ Identité) et les liens sociaux ; rien n'est saisi
    deux fois.
    """
    from jeiko.administration.models import WebSite

    site = WebSite.objects.select_related("identity").prefetch_related("social_links").first()
    if site is None:
        return {"nom": "", "telephone": "", "adresse": "", "reseaux": []}
    identite = getattr(site, "identity", None)
    rue = getattr(identite, "street_address", "") if identite else ""
    ville = " ".join(x for x in (getattr(identite, "postal_code", "") if identite else "",
                                 getattr(identite, "address_locality", "") if identite else "") if x)
    reseaux = [
        {"plateforme": lien.platform if lien.platform in RESEAUX_DESSINES else "lien",
         "nom": lien.get_platform_display(), "url": lien.profile_url,
         "libelle": lien.aria_label or lien.get_platform_display()}
        for lien in site.social_links.all()
        if lien.is_active and (lien.profile_url or "").strip()
    ]
    return {
        "nom": site.name or "",
        "telephone": (getattr(identite, "telephone", "") if identite else "") or "",
        "adresse": ", ".join(x for x in (rue, ville) if x),
        "reseaux": reseaux,
    }


@register.filter
def texte_du_menu(menu, champ):
    """Un texte du menu (barre d'infos, pied de page) dans la langue du visiteur."""
    if menu is None or champ not in ("barre_texte", "pied_texte", "pied_appel", "pied_appel_detail"):
        return ""
    return menu.texte_du_site(champ)


@register.filter
def liens_sans_sous_menu(items):
    """Les entrées de premier niveau sans sous-liens ni bouton (colonne « Navigation »)."""
    return [i for i in items if not getattr(i, "active_submenus", None) and not getattr(i, "bouton", "")]
