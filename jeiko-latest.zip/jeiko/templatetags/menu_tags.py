# jeiko/administration_menu/templatetags/menu_tags.py
from django import template
from django.core.cache import cache
from django.template.loader import render_to_string
from django.db.models import Prefetch

from jeiko.administration_menu.models import Menu, MenuItem, MenuPlace

register = template.Library()

MENU_RENDER_TTL = 60 * 60 * 24 * 30  # 30 jours


def _get_default_menu(place: str):
    return (
        Menu.objects
        .filter(place=place, is_default=True)
        .select_related('menu_style')
        .first()
    )


def _prefetch_menu(menu: Menu):
    """Retourne le menu avec ses items préfetchés (pages incluses)."""
    if not menu:
        return None
    items_qs = (
        MenuItem.objects
        .filter(active=True)
        .select_related('page')
        .order_by('position', 'pk')
    )
    # On recharge le menu par id pour appliquer les prefetch/related
    return (
        Menu.objects
        .filter(pk=menu.pk)
        .select_related('menu_style')
        .prefetch_related(Prefetch('menu_items', queryset=items_qs))
        .first()
    )




def _resolve_menu_for_page(place: str, page):
    """
    Priorités:
      1) Sous-catégorie (menu de l’emplacement)
      2) Parent de la sous-catégorie (menu de l’emplacement)
      3) Catégorie (menu de l’emplacement)
      4) Menu par défaut pour l’emplacement (is_default=True)
      5) None
    """
    if page is not None:
        sub = getattr(page, 'sub_category', None)
        if place == 'MAIN':
            # 1) sub.main_menu ?
            if sub and getattr(sub, 'main_menu_id', None):
                m = sub.main_menu
                if m and m.place == 'MAIN':
                    return m
            # 2) parent.main_menu ?
            if sub and getattr(sub, 'main_category', None):
                parent = sub.main_category
                if getattr(parent, 'main_menu_id', None):
                    m = parent.main_menu
                    if m and m.place == 'MAIN':
                        return m
            # 3) cat.main_menu ?
            cat = getattr(page, 'category', None)
            if cat and getattr(cat, 'main_menu_id', None):
                m = cat.main_menu
                if m and m.place == 'MAIN':
                    return m
        else:
            # place == 'FOOTER' (au cas où tu veux l’unifier plus tard)
            if sub and getattr(sub, 'footer_menu_id', None):
                m = sub.footer_menu
                if m and m.place == 'FOOTER':
                    return m
            if sub and getattr(sub, 'main_category', None):
                parent = sub.main_category
                if getattr(parent, 'footer_menu_id', None):
                    m = parent.footer_menu
                    if m and m.place == 'FOOTER':
                        return m
            cat = getattr(page, 'category', None)
            if cat and getattr(cat, 'footer_menu_id', None):
                m = cat.footer_menu
                if m and m.place == 'FOOTER':
                    return m

    # 4) défaut
    return Menu.objects.filter(place=place, is_default=True).select_related('menu_style').first()



@register.simple_tag
def get_menu(place="MAIN"):
    """
    Version générique: renvoie simplement le 1er menu pour place (deprecated pour ton MAIN).
    Garde pour compatibilité si d'autres templates l'utilisent.
    """
    place = place or MenuPlace.MAIN
    cache_key = f"menu:place:{place}:generic"
    menu = cache.get(cache_key)
    if menu is not None:
        return menu

    menu = (
        Menu.objects
        .filter(place=place)
        .select_related('menu_style')
        .first()
    )
    cache.set(cache_key, menu, 60 * 60)
    return menu


@register.simple_tag(takes_context=True)
def get_main_menu(context):
    """
    Résout le menu MAIN en fonction de la page courante (si présente dans le contexte).
    Usage inchangé dans le template : {% get_main_menu as menu %}
    """
    page = context.get('page')  # RootPage / PageView mettent bien 'page' dans le contexte
    place = MenuPlace.MAIN

    # Clé de cache dépendante de la page/cat/sub -> même rendu que le menu choisi
    page_id = getattr(page, 'id', None)
    cat_id = getattr(getattr(page, 'category', None), 'id', None)
    sub_id = getattr(getattr(page, 'sub_category', None), 'id', None)
    cache_key = f"menu:resolve:place:{place}:p:{page_id}:c:{cat_id}:s:{sub_id}"

    menu = cache.get(cache_key)
    if menu is not None:
        return menu

    chosen = _resolve_menu_for_page(place, page)
    menu = _prefetch_menu(chosen) if chosen else None

    # Cache court pour la résolution (les items sont eux aussi cachés via render_main_menu)
    cache.set(cache_key, menu, 60 * 15)  # 15 minutes
    return menu


@register.simple_tag(takes_context=True)
def render_main_menu(context):
    """
    Rendu HTML du menu MAIN, dépendant de la page (cache par menu.id).
    Invalider cette clé quand Menu/MenuItem/MenuStyle changent.
    """
    menu = get_main_menu(context)
    if not menu:
        return ""

    render_key = f"menu:render:{menu.id}"
    html = cache.get(render_key)
    if html is not None:
        from django.utils.html import mark_safe
        return mark_safe(html)

    html = render_to_string("menu/main.html", {"menu": menu})
    cache.set(render_key, html, MENU_RENDER_TTL)

    from django.utils.html import mark_safe
    return mark_safe(html)
