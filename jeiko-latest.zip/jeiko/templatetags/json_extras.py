from django import template
from django.utils.safestring import mark_safe
import json

register = template.Library()

@register.filter
def tojson(value):
    # Sérialise en JSON valide (garde les accents)
    return mark_safe(json.dumps(value, ensure_ascii=False))
