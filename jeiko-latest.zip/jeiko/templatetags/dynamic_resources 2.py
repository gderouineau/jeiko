from django import template
from django.db.models import QuerySet

# Imports wrapped in try/except to avoid hard errors if apps are missing/changed
try:
    from jeiko.shop.models import Product
except ImportError:
    Product = None

try:
    from jeiko.custom_objects.models import CustomObject
except ImportError:
    CustomObject = None

try:
    from jeiko.administration_pages.models import Page
except ImportError:
    Page = None

try:
    from jeiko.questionnaires_expert.models import ExpertTest
except ImportError:
    ExpertTest = None

register = template.Library()

@register.simple_tag
def get_resources(config):
    """
    Fetches resources based on DynResourceConfig.
    Returns a QuerySet or list of objects.
    """
    if not config:
        return []

    qs = []

    if config.source_type == 'PRODUCT' and Product:
        # Assuming generic active filter, adapt to your Product model
        qs = Product.objects.all()
        # If Product has is_active or is_archive, filter here
        if hasattr(Product, 'is_active'):
             qs = qs.filter(is_active=True)
        if hasattr(Product, 'is_archive'):
             qs = qs.filter(is_archive=False)
             
        if config.product_type:
            qs = qs.filter(product_type=config.product_type)
            
    elif config.source_type == 'CUSTOM_OBJECT' and CustomObject:
        if config.custom_object_model:
            qs = CustomObject.objects.filter(model=config.custom_object_model)
            
    elif config.source_type == 'PAGE' and Page:
        qs = Page.objects.filter(active=True)
        if config.category:
            qs = qs.filter(category=config.category)
        if config.sub_category:
             qs = qs.filter(sub_category=config.sub_category)

    elif config.source_type == 'EXPERT_TEST' and ExpertTest:
         # Assuming ExpertTest has is_active or similar
         qs = ExpertTest.objects.all()
         if hasattr(ExpertTest, 'is_active'):
             qs = qs.filter(is_active=True)

    # Sorting
    if hasattr(qs, 'order_by'):
         qs = qs.order_by('-id')

    # Limiting
    if config.limit and isinstance(config.limit, int) and config.limit > 0:
        qs = qs[:config.limit]
        
    return qs
