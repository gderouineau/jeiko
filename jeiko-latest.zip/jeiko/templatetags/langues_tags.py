"""
Les langues du site dans les gabarits — voir jeiko/langues_du_site.py.
"""

from django import template

from jeiko import langues_du_site

register = template.Library()


def _fiche(context):
    """
    La fiche que sert cette page (`custom_object`), ou `None`. Vérifiée par
    son type, comme `_page_du_site` : un gabarit peut ranger autre chose sous
    ce nom.
    """
    from jeiko.custom_objects.models import CustomObject

    objet = context.get("custom_object")
    return objet if isinstance(objet, CustomObject) and objet.pk else None


def _page_du_site(objet):
    """
    `objet` si c'est une `Page` enregistrée, `None` sinon.

    Les gabarits de base lisent la variable `page` du contexte — mais d'autres
    écrans y rangent autre chose sous ce nom (la page d'un paginateur, par
    exemple). On vérifie le type plutôt que de supposer.
    """
    from jeiko.administration_pages.models import Page

    return objet if isinstance(objet, Page) and objet.pk else None


@register.simple_tag
def accueil_du_site():
    """L'adresse de l'accueil pour qui lit : « / », ou « /en/ »."""
    return langues_du_site.accueil()


@register.simple_tag
def versions_de_la_page(page):
    """Le sélecteur de langue d'une page, côté administration (liste d'états)."""
    from jeiko.administration_pages.versions import etat_des_versions

    page = _page_du_site(page)
    return etat_des_versions(page) if page else []


@register.simple_tag(takes_context=True)
def langue_de_travail(context):
    """
    La langue dans laquelle qui administre lit SES outils — la barre
    d'administration, posée sur le site public.

    Sur une page anglaise, la langue de la requête est l'anglais : c'est celle
    du visiteur. La barre, elle, n'est pas du contenu : elle reste dans la
    langue de l'administration, comme les écrans où elle mène.
    """
    from jeiko import i18n

    return i18n.langue_de_travail(getattr(context.get("request"), "user", None))


@register.simple_tag(takes_context=True)
def page_des_langues(context):
    """
    L'adresse de l'écran « Langues », avec de quoi en revenir ; "" sur un site
    monolingue — le pied de page n'affiche alors pas le lien.

    D'une page du site, l'écran reçoit cette page (`?p=`) et propose son
    adresse dans chaque langue ; d'une fiche ou d'un produit, cette fiche
    (`?f=`). D'ailleurs (panier, connexion, compte…), il reçoit le chemin d'où
    l'on vient (`?retour=`). Voir `administration_pages/vues_langues.py`.
    """
    from urllib.parse import urlencode

    from django.urls import reverse

    if not langues_du_site.langues_actives():
        return ""
    if context.get("adresse_de_l_ecran"):
        # Déjà sur l'écran : il sait d'où l'on vient, et l'a vérifié.
        return context["adresse_de_l_ecran"]
    request = context.get("request")
    # La page d'une fiche est un gabarit commun à toutes les fiches : pas une
    # page à laquelle revenir. C'est la FICHE qu'on retrouve dans l'autre
    # langue (`?f=`) — un produit compris, par sa fiche.
    fiche = _fiche(context)
    page = None if context.get("custom_object") else _page_du_site(context.get("page"))
    if fiche is not None:
        suite = {"f": fiche.origine.pk}
    elif page is not None:
        suite = {"p": page.pk}
    elif request is not None:
        suite = {"retour": request.get_full_path()}
    else:
        suite = {}
    return reverse("jeiko_pages:langues") + (f"?{urlencode(suite)}" if suite else "")


@register.simple_tag(takes_context=True)
def versions_pour_google(context):
    """
    Les balises `hreflang` de la page — ou de la fiche — servie : [{code,
    url}] en adresses absolues, « x-default » compris. Vide quand elle n'a
    qu'une version publiée, ou qu'elle est lue sous le préfixe d'une langue où
    elle n'est pas traduite — elle renvoie alors à l'originale par
    `canonical`, et n'annonce rien.
    """
    request = context.get("request")
    # Sur la page d'une fiche, `page` est son gabarit, commun à toutes les
    # fiches : ce sont les versions de la FICHE qu'on annonce.
    servie = _fiche(context) if context.get("custom_object") else _page_du_site(context.get("page"))
    if (
        request is None or servie is None
        or context.get("canonical_url")
        or not langues_du_site.langues_actives()
    ):
        return []
    origine = servie.origine
    versions = [origine] if origine.est_publiee else []
    versions += [v for v in origine.traductions.all() if v.est_publiee
                 and v.langue in langues_du_site.langues_actives()]
    if len(versions) < 2:
        return []
    liens = [
        {"code": v.langue or langues_du_site.langue_d_origine(),
         "url": request.build_absolute_uri(v.adresse_propre())}
        for v in versions
    ]
    liens.append({"code": "x-default", "url": liens[0]["url"]})
    return liens


@register.simple_tag(takes_context=True)
def langue_de_la_page(context, page=None):
    """
    Le code à écrire dans `<html lang>` : celui du contenu servi. Pour une
    fiche, SA langue — pas celle de son gabarit, qui peut ne pas être traduit
    alors qu'elle l'est.
    """
    servie = _fiche(context) or _page_du_site(page)
    langue = servie.langue if servie else langues_du_site.langue_du_site()
    return langue or langues_du_site.langue_d_origine()


# Le pays par défaut d'une langue nue, pour `og:locale` (Open Graph veut
# « fr_FR », pas « fr »). Un site JEIKO est européen : l'anglais est britannique.
_PAYS_PAR_DEFAUT = {"fr": "FR", "en": "GB", "es": "ES", "de": "DE", "it": "IT"}


@register.simple_tag(takes_context=True)
def locale_open_graph(context, page=None):
    """
    La langue de la page au format d'Open Graph (L-21) : sans elle, un réseau
    social présente la version anglaise d'une page comme française — la
    langue d'origine du site. Même source que `<html lang>`.
    """
    code = langue_de_la_page(context, page).replace("_", "-")
    langue, _, pays = code.partition("-")
    pays = pays or _PAYS_PAR_DEFAUT.get(langue, langue)
    return f"{langue.lower()}_{pays.upper()}"


@register.simple_tag
def textes_de_l_editeur():
    """Le dictionnaire des textes des scripts de l'éditeur, dans la langue active."""
    from jeiko.administration_pages.textes_editeur import dictionnaire

    return dictionnaire()


@register.simple_tag(takes_context=True)
def langue_du_contenu(context, bloc=None):
    """
    La langue dans laquelle rendre le CONTENU d'une page (L-17, 09/10/2026).

    Sur le site public, c'est celle de la requête — déjà la langue de la page
    servie : rien ne change. Dans l'éditeur, la requête parle la langue de
    l'ADMINISTRATEUR, et la version anglaise d'une page montrait « Envoyer »,
    « Aucun créneau », le menu et le pied de page en français. Le contenu
    (blocs, menu, pied de page) passe alors à la langue de la version
    modifiée ; les outils d'édition autour gardent celle de l'administrateur.

    La page vient du contexte (l'éditeur la fournit), sinon du bloc — ce qui
    couvre les sections re-rendues après une action.
    """
    from django.utils import translation

    from jeiko import i18n
    from jeiko.administration_pages.models import Page

    request = context.get("request")
    if request is None or not i18n.est_un_ecran_d_administration(request):
        return translation.get_language()
    page = context.get("page")
    if not isinstance(page, Page) and bloc is not None:
        page = getattr(getattr(getattr(bloc, "line", None), "section", None), "page", None)
    if not isinstance(page, Page):
        return translation.get_language()
    return page.langue or langues_du_site.langue_d_origine()


class _NoeudContenuDansLaLangue(template.Node):
    def __init__(self, code, contenu):
        self.code, self.contenu = code, contenu

    def render(self, context):
        from django.utils import translation

        code = self.code.resolve(context)
        if not code or code == translation.get_language():
            return self.contenu.render(context)
        # La langue du site aussi : les titres et adresses du menu, les liens
        # des boutons vers une page s'y lisent ("" = langue d'origine).
        jeton = langues_du_site.fixer_la_langue(
            "" if code == langues_du_site.langue_d_origine() else code)
        try:
            with translation.override(code):
                return self.contenu.render(context)
        finally:
            langues_du_site.oublier_la_langue(jeton)


@register.tag
def contenu_dans_la_langue(parser, token):
    """
    `{% contenu_dans_la_langue code %}…{% fin_contenu_dans_la_langue %}` : rend le
    contenu comme le site le servirait dans cette langue — textes fixes
    (`{% translate %}`) ET langue du site (titres de menu, adresses). Sans
    effet quand `code` est déjà la langue active : le site public n'y perd rien.
    """
    morceaux = token.split_contents()
    if len(morceaux) != 2:
        raise template.TemplateSyntaxError("contenu_dans_la_langue attend un code de langue.")
    contenu = parser.parse(("fin_contenu_dans_la_langue",))
    parser.delete_first_token()
    return _NoeudContenuDansLaLangue(parser.compile_filter(morceaux[1]), contenu)
