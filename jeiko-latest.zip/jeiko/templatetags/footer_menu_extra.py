# jeiko/administration_menu/templatetags/menu_tags_footer.py
from django import template
from django.db.models import Prefetch

from jeiko.administration_menu.models import Menu, MenuItem, MenuPlace

register = template.Library()


def _resolve_menu_for_page_footer(page):
    """
    Priorités FOOTER :
      1) page.sub_category.footer_menu si place=FOOTER
      2) parent de la sous-cat (main_category).footer_menu si place=FOOTER
      3) page.category.footer_menu si place=FOOTER
      4) menu par défaut (place=FOOTER, is_default=True)
      5) sinon None
    """
    place = MenuPlace.FOOTER if hasattr(MenuPlace, "FOOTER") else "FOOTER"

    if page is not None:
        # 1) sous-catégorie
        sub = getattr(page, "sub_category", None)
        if sub and getattr(sub, "menu_id", None):
            m = sub.footer_menu
            if m and m.place == place:
                return m

        # 2) parent de la sous-catégorie
        if sub and getattr(sub, "main_category", None):
            parent = sub.main_category
            if getattr(parent, "menu_id", None):
                m = parent.footer_menu
                if m and m.place == place:
                    return m

        # 3) catégorie
        cat = getattr(page, "category", None)
        if cat and getattr(cat, "menu_id", None):
            m = cat.footer_menu
            if m and m.place == place:
                return m

    # 4) défaut
    return (
        Menu.objects.filter(
            place=place,
            is_default=True,
        ).select_related("menu_style").first()
    )


class FooterMenusNode(template.Node):
    """
    Usage dans le template :
      {% load menu_tags_footer %}
      {% get_footer_menus %}

    Dans le contexte, tu récupères :
      - footer_menu  : le Menu résolu (ou None)
      - footer_menus : queryset des items de 1er niveau (avec submenus actifs préfetchés)
    """

    def render(self, context):
        page = context.get("page")  # fourni par RootPage/PageView
        menu = _resolve_menu_for_page_footer(page)

        if not menu:
            context["footer_menu"] = None
            context["footer_menus"] = []
            return ""

        # Prépare les sous-menus actifs
        sub_qs = (
            MenuItem.objects
            .filter(active=True)
            .select_related("page")
            .order_by("position", "pk")
        )

        # Items de 1er niveau actifs (main_menu__isnull=True)
        items = (
            MenuItem.objects
            .filter(menu=menu, main_menu__isnull=True, active=True)
            .select_related("page")
            .prefetch_related(Prefetch("submenus", queryset=sub_qs, to_attr="active_submenus"))
            .order_by("position", "pk")
        )

        context["footer_menu"] = menu
        context["footer_menus"] = items
        return ""


@register.tag(name="get_footer_menus")
def get_footer_menus(parser, token):
    """
    Place, par priorité, le bon menu FOOTER et ses items actifs dans le contexte :
      footer_menu, footer_menus
    """
    return FooterMenusNode()
