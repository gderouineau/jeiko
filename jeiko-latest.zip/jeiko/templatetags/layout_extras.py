from django import template
register = template.Library()
@register.filter
def at(seq, i):
    try:
        return seq[int(i)]
    except Exception:
        return ''
