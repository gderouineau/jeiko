from django import template
register = template.Library()

@register.filter
def dgetattr(obj, attr_name):
    return getattr(obj, attr_name, None)

@register.filter
def font_list(fonts):
    # Renvoie uniquement les champs Font, ignore les None et évite toute récursivité.
    result = []
    for attr in [
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'links', 'links_hover', 'text', 'menu', 'menu_hover'
    ]:
        font = getattr(fonts, attr, None)
        if font and getattr(font, "family", None):
            result.append(font)
    return result
