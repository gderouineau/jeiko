# apps/core/templatetags/site_identity_tags.py
import json
from django import template
from django.utils.safestring import mark_safe

register = template.Library()

def _abs_url(request, url, site_url=None):
    if not url:
        return None
    if url.startswith("http://") or url.startswith("https://"):
        return url
    # construit une URL absolue depuis la requête ; fallback sur site_url
    if request:
        return request.build_absolute_uri(url)
    if site_url:
        return f"{site_url.rstrip('/')}/{url.lstrip('/')}"
    return url  # dernier recours

@register.simple_tag(takes_context=True)
def site_identity_jsonld(context, website):
    """
    Rend le JSON-LD Organization/LocalBusiness à partir de website.identity.
    - Logo pris depuis website.logo (computer_size -> >=112px).
    """
    request = context.get("request")
    identity = getattr(website, "identity", None)
    if not identity:
        return ""

    # Détermine l'URL de base (home)
    site_url = getattr(identity, "url", None) or getattr(website, "base_url", None)
    if not site_url and request is not None:
        site_url = f"{request.scheme}://{request.get_host()}/"

    if not site_url:
        return ""

    typ = "LocalBusiness" if identity.type == "localbusiness" else "Organization"
    data = {
        "@context": "https://schema.org",
        "@type": typ,
        "@id": f"{site_url.rstrip('/')}/#org",
        "name": identity.name,
        "url": site_url,
    }

    if identity.telephone:
        data["telephone"] = identity.telephone
    if identity.price_range:
        data["priceRange"] = identity.price_range

    # --- LOGO depuis WebSite.logo ---
    logo_obj = getattr(website, "logo", None)
    logo_url = None
    if logo_obj:
        # priorité: computer_size (150x150), fallback full_size
        if getattr(logo_obj, "computer_size", None) and getattr(logo_obj.computer_size, "url", None):
            logo_url = logo_obj.computer_size.url
        elif getattr(logo_obj, "full_size", None) and getattr(logo_obj.full_size, "url", None):
            logo_url = logo_obj.full_size.url

    logo_abs = _abs_url(request, logo_url, site_url) if logo_url else None
    if logo_abs:
        data["logo"] = logo_abs

    # LocalBusiness: adresse & géo
    if typ == "LocalBusiness":
        data["address"] = {
            "@type": "PostalAddress",
            "streetAddress": identity.street_address or "",
            "addressLocality": identity.address_locality or "",
            "addressRegion": identity.address_region or "",
            "postalCode": identity.postal_code or "",
            "addressCountry": (identity.address_country or "").upper(),
        }
        if identity.geo_lat is not None and identity.geo_lng is not None:
            data["geo"] = {
                "@type": "GeoCoordinates",
                "latitude": float(identity.geo_lat),
                "longitude": float(identity.geo_lng),
            }

    json_str = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return mark_safe(json_str)
