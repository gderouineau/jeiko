"""
`{{ valeur|traduit }}` — traduire à l'AFFICHAGE un texte lu en base (I-06,
09/10/2026).

Les rôles livrés par JEIKO et les permissions propres à JEIKO sont écrits en
base en français, par les migrations : un écran anglais les montrait en
français. Le texte passe ici par les catalogues ; un texte qu'ils ne
connaissent pas — le nom d'un rôle créé par l'exploitant — s'affiche tel
quel. La base ne change pas.
"""
from django import template
from django.utils.translation import gettext

register = template.Library()


@register.filter
def traduit(valeur):
    texte = str(valeur or "")
    return gettext(texte) if texte else texte
