"""Expose la navigation de l'administration au gabarit du menu."""

import re

from django import template
from django.template.loader import render_to_string

from jeiko.administration.admin_nav import build_nav, ecran_du_menu, onglets_de_la_page

register = template.Library()


@register.simple_tag(takes_context=True)
def admin_nav(context):
    """Sections visibles par l'utilisateur courant, état actif résolu.

    Usage : ``{% admin_nav as sections %}`` puis une boucle. Toute la logique
    (permissions, résolution d'URL, surbrillance) vit dans `admin_nav.py` ; le
    gabarit ne fait que dessiner.
    """
    request = context.get("request")
    if request is None or not getattr(request, "user", None):
        return []
    match = getattr(request, "resolver_match", None)
    return build_nav(
        request.user,
        match.view_name if match else "",
        request.path,
    )


@register.simple_tag(takes_context=True)
def onglets_admin(context):
    """La barre d'onglets de l'écran courant (voir `onglets_de_la_page`), ou None."""
    request = context.get("request")
    if request is None or not getattr(request, "user", None):
        return None
    match = getattr(request, "resolver_match", None)
    return onglets_de_la_page(request.user, match.view_name if match else "", request.GET)


#: Le fil d'Ariane d'un écran : un `<ol>` sans `<div>` dans un `<div>` — vrai
#: pour les 166 écrans qui en ont un (vérifié le 14/10/2026).
_FIL_D_ARIANE = re.compile(r'<div class="admin-nav">.*?</div>', re.S)
_TITRE = re.compile(r'<h[12][^>]*class="[^"]*main-title[^"]*"[^>]*>.*?</h[12]>', re.S)


@register.tag
def onglets_du_groupe(parser, token):
    """
    L'en-tête commun des écrans (ADMIN-01, 14/10/2026) : titre → fil d'Ariane
    → onglets, comme sur la fiche produit.

    * Un écran DU MENU (`admin_nav.ecran_du_menu`) reçoit son titre et son fil
      d'Ariane du menu — ce qu'on a cliqué —, et la barre de son groupe ;
      ceux qu'il dessinait lui-même sont remplacés.
    * Une fiche d'un groupe (`also_active`) garde son titre, qui nomme
      l'objet ; la barre du groupe se pose sous son fil d'Ariane.
    * Tout autre écran est rendu tel quel.

    Les 200 écrans dessinent eux-mêmes titre et fil d'Ariane ; les reprendre un
    à un aurait laissé la prochaine divergence possible. Ici elle ne l'est plus.

    {% onglets_du_groupe %}…contenu de l'écran…{% fin_onglets_du_groupe %}
    """
    contenu = parser.parse(("fin_onglets_du_groupe",))
    parser.delete_first_token()
    return _OngletsDuGroupe(contenu)


class _OngletsDuGroupe(template.Node):
    def __init__(self, contenu):
        self.contenu = contenu

    def render(self, context):
        html = self.contenu.render(context)
        request = context.get("request")
        if request is None or not getattr(request, "user", None):
            return html
        match = getattr(request, "resolver_match", None)
        vue = match.view_name if match else ""
        ecran = ecran_du_menu(request.user, vue, request.GET)
        if ecran:
            entete = render_to_string("includes/entete_admin.html", {"ecran": ecran})
            titre = _TITRE.search(html)
            if titre:
                html = html[:titre.start()] + "\x00" + html[titre.end():]
                html = _FIL_D_ARIANE.sub("", html, count=1)
                return html.replace("\x00", entete, 1)
            fil = _FIL_D_ARIANE.search(html)
            if fil:
                return html[:fil.start()] + entete + html[fil.end():]
            return f'<div class="admin-content">{entete}</div>' + html
        groupe = onglets_de_la_page(request.user, vue, request.GET)
        if not groupe:
            return html
        barre = render_to_string("includes/onglets_du_groupe.html", {"groupe": groupe})
        for repere in (_FIL_D_ARIANE, _TITRE):
            trouve = repere.search(html)
            if trouve:
                return html[:trouve.end()] + barre + html[trouve.end():]
        return f'<div class="admin-content">{barre}</div>' + html
