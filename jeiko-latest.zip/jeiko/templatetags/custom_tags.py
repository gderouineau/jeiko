import re
from django import template
from django.utils.safestring import mark_safe

register = template.Library()

# 1) Pattern pour matcher [% key %]
TAG_PATTERN = re.compile(r'\[\%\s*(\w+)\s*\%\]')

# 2) Pattern pour matcher [[ ... ]]
# Ex: [[mi-o:phone|size=24|color=#e3e3e3|class=mr-2]]
ICON_PATTERN = re.compile(r'\[\[\s*([^\]\|]+)(?:\s*\|\s*([^\]]+))?\s*\]\]')


def _parse_icon_token(token: str):
    """
    Accepte:
      - 'material-outlined:phone'
      - 'material-icons-outlined:phone'
      - 'material-icons-round:phone'
      - 'material-icons-sharp:phone'
      - 'material-icons-two-tone:phone'
      - 'mi:phone'        -> .material-icons (remplie)
      - 'mi-o:phone'      -> .material-icons-outlined
      - 'mi-r:phone'      -> .material-icons-round
      - 'mi-s:phone'      -> .material-icons-sharp
      - 'mi-t:phone'      -> .material-icons-two-tone
      - 'ms-o:phone'      -> alias compat pour outlined
    Retourne (css_class, name) ou (None, None).
    """
    token = token.strip().lower()

    # alias courts
    if token.startswith("mi-o:") or token.startswith("ms-o:"):
        return "material-icons-outlined", token.split(":", 1)[1]
    if token.startswith("mi-r:"):
        return "material-icons-round", token.split(":", 1)[1]
    if token.startswith("mi-s:"):
        return "material-icons-sharp", token.split(":", 1)[1]
    if token.startswith("mi-t:"):
        return "material-icons-two-tone", token.split(":", 1)[1]
    if token.startswith("mi:"):
        return "material-icons", token.split(":", 1)[1]

    # formats longs
    if ":" in token:
        prefix, name = token.split(":", 1)
        prefix = prefix.strip()
        name = name.strip()

        if "outlined" in prefix:
            return "material-icons-outlined", name
        if "round" in prefix:
            return "material-icons-round", name
        if "sharp" in prefix:
            return "material-icons-sharp", name
        if "two-tone" in prefix or "twotone" in prefix or "two_tone" in prefix:
            return "material-icons-two-tone", name
        if "material" in prefix:
            # fallback: police pleine
            return "material-icons", name

    return None, None


def _parse_icon_attrs(attrs_str: str):
    """
    Parse les options après le premier '|':
      size=24|color=#e3e3e3|class=mr-2|title=Texte
    """
    out = {"size": 24, "color": "currentColor", "class": "", "title": ""}
    if not attrs_str:
        return out

    parts = [p.strip() for p in attrs_str.split("|") if p.strip()]
    for p in parts:
        if "=" not in p:
            continue
        k, v = p.split("=", 1)
        k, v = k.strip().lower(), v.strip()
        if k == "size":
            try:
                val = int(v)
                if 8 <= val <= 128:
                    out["size"] = val
            except ValueError:
                pass
        elif k == "color":
            # autoriser hex, currentColor, var(--x), noms simples
            if re.fullmatch(r'(?:#[0-9a-fA-F]{3,8}|currentColor|var\([^)]+\)|[a-zA-Z][\w-]*)', v):
                out["color"] = v
        elif k == "class":
            if re.fullmatch(r'[\w\-\s]+', v):
                out["class"] = v
        elif k in ("title", "label", "aria"):
            out["title"] = v[:80]
    return out


def _render_text_with_context(context, text):
    """
    Helper pour appliquer les remplacements [% key %] et [[ icon ]] sur un texte donné,
    en utilisant le contexte fourni.
    """
    if not text:
        return ""

    # 1) variables [% key %]
    def _replace_vars(m):
        key = m.group(1)
        # On utilise str() pour convertir les Decimal/int en string
        return str(context.get(key, m.group(0)))

    rendered = TAG_PATTERN.sub(_replace_vars, str(text))

    # 2) icônes [[ token | attr=val | ... ]]
    def _replace_icon(m):
        token = m.group(1)
        attrs = _parse_icon_attrs(m.group(2) or "")
        css_class, name = _parse_icon_token(token)
        if not (css_class and name):
            return m.group(0)

        classes = f"{css_class} {attrs['class']}".strip()
        title = attrs["title"]
        if title:
            title_attr = f' aria-label="{title}" role="img"'
        else:
            title_attr = ' aria-hidden="true" role="img"'

        return (
            f'<span class="{classes}" style="font-size:{attrs["size"]}px; '
            f'color:{attrs["color"]};"{title_attr}>{name}</span>'
        )

    rendered = ICON_PATTERN.sub(_replace_icon, rendered)
    return mark_safe(rendered)


@register.simple_tag(takes_context=True)
def render_custom_tags(context, text):
    """
    Tag template simple pour rendre le texte.
    """
    return _render_text_with_context(context, text)


@register.filter
def concat(value, arg):
    return str(value) + str(arg)


@register.simple_tag(takes_context=True)
def resolve_image(context, img, token_code):
    """
    Si `token_code` est renseigné et que le contexte contient une image
    sous cette clé (cas CustomObjectView : context[code] = ImageContent),
    on renvoie cette image. Sinon, on garde l'image d'origine.
    """
    if not token_code:
        return img

    key = str(token_code).strip()
    if not key:
        return img

    dyn = context.get(key)
    if dyn is None:
        return img

    # ici éventuellement : vérifier que dyn ressemble à un ImageContent
    # ex: hasattr(dyn, "original_image")
    return dyn

@register.simple_tag(takes_context=True)
def resolve_button_url(context, btn, token_code):
    """
    Retourne l'URL du bouton :
      - si token_code est fourni et que le contexte contient un champ BUTTON
        sous ce code (dict avec clé 'url'), on utilise cette URL,
      - sinon on utilise btn.get_url().
    """

    # Pas de token → URL "normale"
    if not token_code:
        return btn.get_url()

    key = str(token_code).strip()
    if not key:
        return btn.get_url()

    dyn = context.get(key)
    if isinstance(dyn, dict):
        url = (dyn.get("url") or "").strip()
        if url:
            return url

    return btn.get_url()


@register.simple_tag(takes_context=True)
def resolve_button_label(context, btn, token_code):
    """
    Retourne le label du bouton :
      - si le champ BUTTON dans le contexte a un label non vide → override,
      - sinon, on garde btn.label.
    
    APPLIQUE ENSUITE LE RENDU DES TAGS [%...%] et [[...]] sur le résultat.
    """
    base_label = btn.label or ""
    final_label = base_label

    if token_code:
        key = str(token_code).strip()
        if key:
            dyn = context.get(key)
            if isinstance(dyn, dict):
                label = (dyn.get("label") or "").strip()
                if label:
                    final_label = label

    # Appliquer le rendu des tags sur le label final
    return _render_text_with_context(context, final_label)
