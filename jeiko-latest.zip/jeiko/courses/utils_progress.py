from django.db.models import Count
from .models import Section, SectionProgress, CourseEnrollment

def update_course_progress(enrollment):
    """
    Recalculate and update the progress percentage for an enrollment.
    """
    # Count total published sections in the course
    total_sections = Section.objects.filter(
        chapter__part__course=enrollment.course,
        is_published=True
    ).count()
    
    if total_sections == 0:
        enrollment.progress_percentage = 100
    else:
        # Count completed sections for this enrollment
        completed_sections = SectionProgress.objects.filter(
            enrollment=enrollment,
            is_completed=True
        ).count()
        
        enrollment.progress_percentage = (completed_sections / total_sections) * 100
        
    # Cap at 100
    if enrollment.progress_percentage > 100:
        enrollment.progress_percentage = 100
        
    # Check if completed
    if enrollment.progress_percentage >= 100 and enrollment.status == CourseEnrollment.STATUS_ACTIVE:
        enrollment.status = CourseEnrollment.STATUS_COMPLETED
        
    enrollment.save()
    return enrollment.progress_percentage
