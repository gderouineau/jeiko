from django.apps import AppConfig


class CoursesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko.courses'
    
    def ready(self):
        # Import signals to register them
        import jeiko.courses.signals
