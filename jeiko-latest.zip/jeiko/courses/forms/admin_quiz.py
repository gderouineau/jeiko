"""
Admin forms for quiz management.
"""
from django import forms
from django.forms import inlineformset_factory
from ..models import QuizContent, QuizQuestion, QuizAnswer

class QuizContentForm(forms.ModelForm):
    """Form for creating/editing quiz content."""
    
    class Meta:
        model = QuizContent
        fields = ['section', 'title', 'passing_score', 'allow_skip']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Titre du quiz (optionnel)'}),
            'passing_score': forms.NumberInput(attrs={'class': 'form-control', 'min': 0, 'max': 100}),
            'allow_skip': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }


class QuizQuestionForm(forms.ModelForm):
    """Form for creating/editing quiz questions."""
    
    class Meta:
        model = QuizQuestion
        fields = ['quiz', 'question_text', 'question_type', 'points']
        widgets = {
            'question_text': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'question_type': forms.Select(attrs={'class': 'form-control'}),
            'points': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
        }


class QuizAnswerForm(forms.ModelForm):
    """Form for creating/editing quiz answers."""
    
    class Meta:
        model = QuizAnswer
        fields = ['answer_text', 'is_correct']
        widgets = {
            'answer_text': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Réponse possible'}),
            'is_correct': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

# Inline formset for answers within a question form
QuizAnswerFormSet = inlineformset_factory(
    QuizQuestion,
    QuizAnswer,
    form=QuizAnswerForm,
    extra=5,
    can_delete=True
)
