"""
Client forms for courses (user-facing).
"""
from django import forms


class QuizSubmissionForm(forms.Form):
    """
    Dynamic form for quiz submission.
    Fields are added dynamically based on quiz questions.
    """
    
    def __init__(self, quiz, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Add a field for each question
        for question in quiz.questions.all().order_by('position'):
            field_name = f'question_{question.id}'
            
            # Get answers
            answers = question.answers.all().order_by('position')
            choices = [(answer.id, answer.answer_text) for answer in answers]
            
            if question.question_type == question.QUESTION_TYPE_SINGLE:
                # Radio buttons
                self.fields[field_name] = forms.ChoiceField(
                    choices=choices,
                    widget=forms.RadioSelect(attrs={'class': 'quiz-radio'}),
                    label=question.question_text,
                    required=True
                )
            
            elif question.question_type == question.QUESTION_TYPE_MULTIPLE:
                # Checkboxes
                self.fields[field_name] = forms.MultipleChoiceField(
                    choices=choices,
                    widget=forms.CheckboxSelectMultiple(attrs={'class': 'quiz-checkbox'}),
                    label=question.question_text,
                    required=True
                )
            
            elif question.question_type == question.QUESTION_TYPE_TRUE_FALSE:
                # True/False radio
                self.fields[field_name] = forms.ChoiceField(
                    choices=choices,
                    widget=forms.RadioSelect(attrs={'class': 'quiz-radio'}),
                    label=question.question_text,
                    required=True
                )


class CommentForm(forms.Form):
    """Form for adding comments/questions on a section."""
    
    comment = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 4,
            'placeholder': 'Posez votre question ou laissez un commentaire...'
        }),
        label="Commentaire",
        required=True
    )
