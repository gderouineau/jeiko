"""
Utility functions for the courses app.
"""
from decimal import Decimal
from django.utils import timezone
from django.db.models import Count, Q
from .models import CourseEnrollment, SectionProgress, VideoProgress, Section


def grant_course_access(user, course, granted_by=None, has_payed=False, order=None, notes=''):
    """
    Accorde l'accès à une formation pour un utilisateur.
    
    Args:
        user: L'utilisateur
        course: La formation
        granted_by: L'admin qui accorde l'accès (None si achat automatique)
        has_payed: True si achat, False si accès gratuit/manuel
        order: La commande associée (si achat)
        notes: Notes administratives
    
    Returns:
        CourseEnrollment: L'inscription créée ou mise à jour
    """
    enrollment, created = CourseEnrollment.objects.get_or_create(
        user=user,
        course=course,
        defaults={
            'granted_by': granted_by,
            'has_payed': has_payed,
            'order': order,
            'notes': notes,
        }
    )
    
    if not created and enrollment.status == CourseEnrollment.STATUS_SUSPENDED:
        # Réactiver l'accès si suspendu
        enrollment.status = CourseEnrollment.STATUS_ACTIVE
        if granted_by:
            enrollment.granted_by = granted_by
        if has_payed:
            enrollment.has_payed = True
        if order:
            enrollment.order = order
        if notes:
            enrollment.notes += f"\n{notes}"
        enrollment.save()
    
    return enrollment


def check_section_access(user, section):
    """
    Vérifie si un utilisateur a accès à une section.
    
    Args:
        user: L'utilisateur
        section: La section
    
    Returns:
        tuple: (has_access: bool, reason: str)
    """
    course = section.chapter.part.course
    
    # Si la formation n'est pas active, seuls les admins peuvent y accéder
    if not course.is_active and not user.is_staff:
        return False, "Formation désactivée"
    
    # Si la section n'est pas publiée, seuls les admins peuvent y accéder
    if not section.is_published and not user.is_staff:
        return False, "Section non publiée"
    
    # Si la formation n'est pas restreinte, tout le monde y a accès
    if not course.is_restricted:
        return True, "Accès libre"
    
    # Pour les vidéos en preview, accès libre
    if section.section_type == Section.SECTION_TYPE_VIDEO:
        if hasattr(section, 'video_content') and section.video_content.is_preview:
            return True, "Vidéo de prévisualisation"
    
    # Vérifier l'inscription
    try:
        enrollment = CourseEnrollment.objects.get(user=user, course=course)
        if enrollment.is_access_valid():
            return True, "Accès via inscription"
        else:
            return False, "Accès expiré ou suspendu"
    except CourseEnrollment.DoesNotExist:
        return False, "Pas d'inscription"


def calculate_course_progress(enrollment):
    """
    Calcule la progression globale d'un utilisateur dans une formation.
    
    Args:
        enrollment: CourseEnrollment
    
    Returns:
        Decimal: Pourcentage de progression (0-100)
    """
    course = enrollment.course
    
    # Compter toutes les sections publiées de la formation
    total_sections = Section.objects.filter(
        chapter__part__course=course,
        chapter__part__is_published=True,
        chapter__is_published=True,
        is_published=True
    ).count()
    
    if total_sections == 0:
        return Decimal('0.00')
    
    # Compter les sections complétées ou passées
    completed_sections = SectionProgress.objects.filter(
        enrollment=enrollment,
        section__chapter__part__course=course
    ).filter(
        Q(is_completed=True) | Q(is_skipped=True)
    ).count()
    
    progress = (Decimal(completed_sections) / Decimal(total_sections)) * Decimal('100.00')
    
    # Mettre à jour l'enrollment
    enrollment.progress_percentage = progress
    if progress >= 100 and not enrollment.completed_at:
        enrollment.status = CourseEnrollment.STATUS_COMPLETED
        enrollment.completed_at = timezone.now()
    enrollment.save(update_fields=['progress_percentage', 'status', 'completed_at', 'updated_at'])
    
    return progress


def update_video_progress(user, section, position_seconds, duration_seconds):
    """
    Met à jour la progression de visionnage d'une vidéo.
    
    Args:
        user: L'utilisateur
        section: La section vidéo
        position_seconds: Position actuelle en secondes
        duration_seconds: Durée totale en secondes
    
    Returns:
        VideoProgress: La progression mise à jour
    """
    # Récupérer l'enrollment
    course = section.chapter.part.course
    try:
        enrollment = CourseEnrollment.objects.get(user=user, course=course)
    except CourseEnrollment.DoesNotExist:
        return None
    
    # Calculer le pourcentage
    if duration_seconds > 0:
        watched_percentage = (Decimal(position_seconds) / Decimal(duration_seconds)) * Decimal('100.00')
        watched_percentage = min(watched_percentage, Decimal('100.00'))
    else:
        watched_percentage = Decimal('0.00')
    
    # Créer ou mettre à jour la progression vidéo
    video_progress, created = VideoProgress.objects.update_or_create(
        enrollment=enrollment,
        section=section,
        defaults={
            'last_position_seconds': position_seconds,
            'watched_percentage': watched_percentage,
            'is_completed': watched_percentage >= Decimal('90.00'),  # Considéré complété à 90%
            'completed_at': timezone.now() if watched_percentage >= Decimal('90.00') else None,
        }
    )
    
    # Mettre à jour la progression de la section si vidéo complétée
    if video_progress.is_completed:
        section_progress, created = SectionProgress.objects.update_or_create(
            enrollment=enrollment,
            section=section,
            defaults={
                'is_completed': True,
                'completed_at': timezone.now(),
            }
        )
        
        # Recalculer la progression globale
        calculate_course_progress(enrollment)
    
    return video_progress


def get_video_url(video_content, user):
    """
    Génére l'URL d'accès à une vidéo selon son type de stockage.
    
    Args:
        video_content: VideoContent
        user: L'utilisateur demandant l'accès
    
    Returns:
        str: URL d'accès à la vidéo
    """
    from .storage import get_signed_url
    
    if video_content.storage_type == video_content.STORAGE_LOCAL:
        # Pour le stockage local, on passe par une view protégée
        from django.urls import reverse
        return reverse('jeiko_courses:jeiko_courses_client:serve_video', kwargs={'video_id': video_content.pk})
    
    elif video_content.storage_type == video_content.STORAGE_REMOTE:
        # Provider distant avec URL signée si activé
        if video_content.remote_provider and video_content.remote_provider.url_signing_enabled:
            return get_signed_url(video_content)
        else:
            # URL directe du provider
            return get_provider_video_url(video_content)
    
    elif video_content.storage_type == video_content.STORAGE_DIRECT_LINK:
        return video_content.direct_url
    
    elif video_content.storage_type == video_content.STORAGE_FTP:
        # FTP : on proxy via Django
        from django.urls import reverse
        return reverse('jeiko_courses:jeiko_courses_client:serve_video', kwargs={'video_id': video_content.pk})
    
    return ''


def get_provider_video_url(video_content):
    """
    Génère l'URL de la vidéo sur le provider distant.
    
    Args:
        video_content: VideoContent
    
    Returns:
        str: URL de la vidéo
    """
    provider = video_content.remote_provider
    if not provider:
        return ''
    
    provider_type = provider.provider_type
    config = provider.config
    video_id = video_content.remote_video_id
    
    if provider_type == provider.PROVIDER_VIMEO:
        return f"https://player.vimeo.com/video/{video_id}"
    
    elif provider_type == provider.PROVIDER_BUNNY:
        cdn_hostname = config.get('cdn_hostname', '')
        return f"https://{cdn_hostname}/{video_id}/playlist.m3u8"
    
    elif provider_type == provider.PROVIDER_S3:
        bucket = config.get('bucket', '')
        region = config.get('region', 'us-east-1')
        return f"https://{bucket}.s3.{region}.amazonaws.com/{video_id}"
    
    return ''


def test_provider_connection(provider):
    """
    Teste la connexion à un provider de stockage.
    
    Args:
        provider: VideoStorageProvider
    
    Returns:
        dict: {'success': bool, 'message': str}
    """
    # Cette fonction sera complétée avec les implémentations spécifiques
    # de chaque provider (API calls, etc.)
    
    if not provider.is_active:
        return {'success': False, 'message': 'Provider désactivé'}
    
    provider_type = provider.provider_type
    config = provider.config
    
    # Validation basique de la configuration
    if provider_type == provider.PROVIDER_VIMEO:
        if not config.get('access_token'):
            return {'success': False, 'message': 'access_token manquant dans la configuration'}
        return {'success': True, 'message': 'Configuration Vimeo valide'}
    
    elif provider_type == provider.PROVIDER_BUNNY:
        if not config.get('api_key') or not config.get('library_id'):
            return {'success': False, 'message': 'api_key ou library_id manquant'}
        return {'success': True, 'message': 'Configuration Bunny valide'}
    
    elif provider_type == provider.PROVIDER_S3:
        required_keys = ['bucket', 'access_key', 'secret_key']
        missing = [k for k in required_keys if not config.get(k)]
        if missing:
            return {'success': False, 'message': f'Clés manquantes: {", ".join(missing)}'}
        return {'success': True, 'message': 'Configuration S3 valide'}
    
    elif provider_type == provider.PROVIDER_FTP:
        required_keys = ['host', 'username', 'password']
        missing = [k for k in required_keys if not config.get(k)]
        if missing:
            return {'success': False, 'message': f'Clés manquantes: {", ".join(missing)}'}
        return {'success': True, 'message': 'Configuration FTP valide'}
    
    return {'success': True, 'message': 'Provider configuré'}


def migrate_video_storage(video_content, new_provider=None, new_storage_type=None):
    """
    Migre une vidéo d'un provider à un autre.
    
    Args:
        video_content: VideoContent
        new_provider: Nouveau VideoStorageProvider (si storage_type='remote')
        new_storage_type: Nouveau type de stockage
    
    Returns:
        dict: {'success': bool, 'message': str}
    """
    # Cette fonction sera complétée avec la logique de migration
    # Pour l'instant, on fait juste une validation basique
    
    if new_storage_type and new_storage_type not in dict(video_content.STORAGE_TYPE_CHOICES):
        return {'success': False, 'message': 'Type de stockage invalide'}
    
    if new_storage_type == video_content.STORAGE_REMOTE and not new_provider:
        return {'success': False, 'message': 'Provider requis pour le stockage distant'}
    
    # TODO: Implémenter la logique de migration réelle
    # - Upload vers le nouveau provider
    # - Vérification
    # - Mise à jour du VideoContent
    # - Nettoyage de l'ancien stockage
    
    return {
        'success': False,
        'message': 'Migration non implémentée (TODO)'
    }
