"""
Client-facing URLs for courses app.
Routes for users accessing their formations.
"""
from django.urls import path
from jeiko.courses.views import client

urlpatterns = [
    # My courses - Espace utilisateur
    path('my-courses/', client.my_courses, name='my_courses'),
    
    # Course detail - Page d'accueil d'une formation
    path('<slug:course_slug>/', client.course_detail, name='course_detail'),
    
    # Section view - Visualisation d'une section (vidéo, texte, PDF, quiz)
    path('<slug:course_slug>/section/<int:section_id>/', client.section_view, name='section_view'),
    path('<slug:course_slug>/section/<int:section_id>/complete/', client.mark_section_complete, name='mark_section_complete'),
    
    # Quiz submission
    path('<slug:course_slug>/quiz/<int:quiz_id>/submit/', client.quiz_submit, name='quiz_submit'),
    path('<slug:course_slug>/quiz/<int:quiz_id>/skip/', client.quiz_skip, name='quiz_skip'),
    
    # Certificate & Completion
    path('<slug:course_slug>/certificate/', client.course_certificate, name='course_certificate'),
    path('<slug:course_slug>/complete/', client.course_complete, name='course_complete'),
    
    # Protected file serving
    path('serve/video/<int:video_id>/', client.serve_video, name='serve_video'),
    path('serve/pdf/<int:pdf_id>/', client.serve_pdf, name='serve_pdf'),
]
