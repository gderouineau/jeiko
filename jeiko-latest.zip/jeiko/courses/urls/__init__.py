"""
Main URL configuration for courses app.
Combines client, admin, and API routes.
"""
from django.urls import path, include

app_name = 'jeiko_courses'

urlpatterns = [
    # Client routes (formations côté utilisateur)
    path('courses/', include(('jeiko.courses.urls.client', 'jeiko_courses_client'))),
    
    # Admin routes (gestion côté admin)
    path('administration/courses/', include(('jeiko.courses.urls.admin', 'jeiko_courses_admin'))),
    
    # API routes (endpoints AJAX/REST)
    path('api/courses/', include(('jeiko.courses.urls.api', 'jeiko_courses_api'))),
]
