"""
API URLs for courses app.
RESTful endpoints for AJAX interactions.
"""
from django.urls import path
from jeiko.courses.views import api

urlpatterns = [
    # Video progress tracking (AJAX)
    path('video-progress/update/', api.update_video_progress, name='update_video_progress'),
    path('video-progress/<int:section_id>/', api.get_video_progress, name='get_video_progress'),
    
    # Quiz endpoints
    path('quiz/<int:quiz_id>/start/', api.start_quiz, name='start_quiz'),
    path('quiz/<int:quiz_id>/submit/', api.submit_quiz, name='submit_quiz'),
    path('quiz/<int:quiz_id>/results/', api.quiz_results, name='quiz_results'),
    
    # Progress data
    path('enrollment/<int:enrollment_id>/progress/', api.enrollment_progress, name='enrollment_progress'),
]
