"""
Admin URLs for courses app.
Routes for course management by administrators.
"""
from django.urls import path
from jeiko.courses.views import admin as admin_views
from ..views import admin_ordering

urlpatterns = [
    # Courses management
    path('all/', admin_views.course_list, name='course_list'),
    path('course/create/', admin_views.course_create, name='course_create'),
    path('course/<int:course_id>/edit/', admin_views.course_edit, name='course_edit'),
    path('course/<int:course_id>/delete/', admin_views.course_delete, name='course_delete'),
    path('course/<int:course_id>/structure/', admin_views.course_structure, name='course_structure'),
    
    # Structure Management - Parts
    path('course/<int:course_id>/part/create/', admin_views.part_create, name='part_create'),
    path('part/<int:part_id>/edit/', admin_views.part_edit, name='part_edit'),
    path('part/<int:part_id>/delete/', admin_views.part_delete, name='part_delete'),
    
    # Structure Management - Chapters
    path('part/<int:part_id>/chapter/create/', admin_views.chapter_create, name='chapter_create'),
    path('chapter/<int:chapter_id>/edit/', admin_views.chapter_edit, name='chapter_edit'),
    path('chapter/<int:chapter_id>/delete/', admin_views.chapter_delete, name='chapter_delete'),
    
    # Structure Management - Sections
    path('chapter/<int:chapter_id>/section/create/', admin_views.section_create, name='section_create'),
    path('section/<int:section_id>/edit/', admin_views.section_edit, name='section_edit'),
    path('section/<int:section_id>/delete/', admin_views.section_delete, name='section_delete'),
    
    # Structure Management - Content
    path('section/<int:section_id>/content/video/create/', admin_views.video_content_create, name='video_content_create'),
    path('content/video/<int:content_id>/edit/', admin_views.video_content_edit, name='video_content_edit'),
    
    # Structure Management - Quiz
    path('section/<int:section_id>/content/quiz/create/', admin_views.quiz_content_create, name='quiz_content_create'),
    path('content/quiz/<int:content_id>/edit/', admin_views.quiz_content_edit, name='quiz_content_edit'),
    
    # Structure Management - Quiz Questions
    path('content/quiz/<int:quiz_id>/question/create/', admin_views.quiz_question_create, name='quiz_question_create'),
    path('question/<int:question_id>/edit/', admin_views.quiz_question_edit, name='quiz_question_edit'),
    path('question/<int:question_id>/delete/', admin_views.quiz_question_delete, name='quiz_question_delete'),
    
    # Ordering
    path('part/<int:part_id>/move/<str:direction>/', admin_ordering.move_part, name='move_part'),
    path('chapter/<int:chapter_id>/move/<str:direction>/', admin_ordering.move_chapter, name='move_chapter'),
    path('section/<int:section_id>/move/<str:direction>/', admin_ordering.move_section, name='move_section'),
    path('question/<int:question_id>/move/<str:direction>/', admin_ordering.move_quiz_question, name='move_quiz_question'),
    
    # Video storage providers
    path('providers/', admin_views.provider_list, name='provider_list'),
    path('providers/create/', admin_views.provider_create, name='provider_create'),
    path('providers/<int:provider_id>/edit/', admin_views.provider_edit, name='provider_edit'),
    path('providers/<int:provider_id>/test/', admin_views.provider_test, name='provider_test'),
    
    # Enrollments management
    path('enrollments/', admin_views.enrollment_list, name='enrollment_list'),
    path('enrollments/grant/', admin_views.enrollment_grant, name='enrollment_grant'),
    path('enrollments/<int:enrollment_id>/revoke/', admin_views.enrollment_revoke, name='enrollment_revoke'),
    path('enrollments/<int:enrollment_id>/grant/', admin_views.enrollment_cancel_revoke, name='enrollment_cancel_revoke'),

    # Progress tracking
    path('course/<int:course_id>/progress/', admin_views.course_progress, name='course_progress'),
    path('user/<int:user_id>/progress/', admin_views.user_progress, name='user_progress'),
]
