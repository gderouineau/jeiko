"""
Storage backends and URL signing for video content.
"""
import hashlib
import hmac
import time
from urllib.parse import urlencode
from django.conf import settings


def get_signed_url(video_content):
    """
    Génère une URL signée pour accéder à une vidéo distante.
    
    Args:
        video_content: VideoContent instance
    
    Returns:
        str: URL signée avec expiration
    """
    provider = video_content.remote_provider
    if not provider or not provider.url_signing_enabled:
        from .utils import get_provider_video_url
        return get_provider_video_url(video_content)
    
    provider_type = provider.provider_type
    config = provider.config
    expiry_seconds = provider.url_expiry_seconds
    
    if provider_type == 'vimeo':
        return _get_vimeo_signed_url(video_content, config, expiry_seconds)
    elif provider_type == 'bunny':
        return _get_bunny_signed_url(video_content, config, expiry_seconds)
    elif provider_type == 's3':
        return _get_s3_signed_url(video_content, config, expiry_seconds)
    elif provider_type == 'ftp':
        # FTP doesn't support signed URLs, return proxy URL
        from django.urls import reverse
        return reverse('jeiko_courses:jeiko_courses_client:serve_video', kwargs={'video_id': video_content.pk})
    
    return ''


def _get_vimeo_signed_url(video_content, config, expiry_seconds):
    """
    Génère une URL signée pour Vimeo.
    Note: Vimeo utilise des tokens d'accès plutôt que des URLs signées.
    """
    video_id = video_content.remote_video_id
    access_token = config.get('access_token', '')
    
    # URL avec token
    return f"https://player.vimeo.com/video/{video_id}?h={access_token}"


def _get_bunny_signed_url(video_content, config, expiry_seconds):
    """
    Génère une URL signée pour Bunny.net.
    """
    cdn_hostname = config.get('cdn_hostname', '')
    token_key = config.get('token_key', '')  # Security token key from Bunny
    video_path = video_content.remote_video_id
    
    if not token_key:
        # Pas de clé de signature, URL normale
        return f"https://{cdn_hostname}/{video_path}/playlist.m3u8"
    
    # Générer timestamp d'expiration
    expires = int(time.time()) + expiry_seconds
    
    # Construire la chaîne à signer
    # Format Bunny: token_key + path + expires
    path_to_sign = f"/{video_path}/playlist.m3u8"
    string_to_sign = f"{token_key}{path_to_sign}{expires}"
    
    # Générer le hash MD5
    token = hashlib.md5(string_to_sign.encode()).hexdigest()
    
    # URL finale
    params = urlencode({'token': token, 'expires': expires})
    return f"https://{cdn_hostname}{path_to_sign}?{params}"


def _get_s3_signed_url(video_content, config, expiry_seconds):
    """
    Génère une URL signée pour Amazon S3.
    """
    try:
        import boto3
        from botocore.client import Config
    except ImportError:
        # Si boto3 n'est pas installé, retourner URL non signée
        bucket = config.get('bucket', '')
        region = config.get('region', 'us-east-1')
        key = video_content.remote_video_id
        return f"https://{bucket}.s3.{region}.amazonaws.com/{key}"
    
    # Configuration S3
    bucket = config.get('bucket', '')
    region = config.get('region', 'us-east-1')
    access_key = config.get('access_key', '')
    secret_key = config.get('secret_key', '')
    endpoint_url = config.get('endpoint_url')  # Pour S3-compatible (Bunny, etc.)
    
    # Créer le client S3
    s3_client = boto3.client(
        's3',
        region_name=region,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        endpoint_url=endpoint_url,
        config=Config(signature_version='s3v4')
    )
    
    # Générer l'URL pré-signée
    try:
        url = s3_client.generate_presigned_url(
            'get_object',
            Params={
                'Bucket': bucket,
                'Key': video_content.remote_video_id
            },
            ExpiresIn=expiry_seconds
        )
        return url
    except Exception as e:
        print(f"Error generating S3 presigned URL: {e}")
        # Fallback sur URL non signée
        return f"https://{bucket}.s3.{region}.amazonaws.com/{video_content.remote_video_id}"


class LocalProtectedStorage:
    """
    Custom storage backend pour fichiers locaux protégés.
    Les fichiers ne sont pas accessibles directement via /media/
    mais via une view qui vérifie les permissions.
    """
    
    @staticmethod
    def get_protected_url(file_field, object_id, file_type='video'):
        """
        Génère une URL protégée pour un fichier local.
        
        Args:
            file_field: Le FileField/ImageField
            object_id: L'ID de l'objet (VideoContent, PDFContent, etc.)
            file_type: Type de fichier ('video', 'pdf', etc.)
        
        Returns:
            str: URL vers la view protégée
        """
        from django.urls import reverse
        
        if file_type == 'video':
            return reverse('jeiko_courses:jeiko_courses_client:serve_video', kwargs={'video_id': object_id})
        elif file_type == 'pdf':
            return reverse('jeiko_courses:jeiko_courses_client:serve_pdf', kwargs={'pdf_id': object_id})
        
        # Fallback: URL média directe (non protégée)
        if file_field:
            return file_field.url
        return ''


# Configuration des backends par provider
STORAGE_BACKENDS = {
    'vimeo': {
        'class': 'VimeoStorage',
        'supports_signing': True,
    },
    'bunny': {
        'class': 'BunnyStorage',
        'supports_signing': True,
    },
    's3': {
        'class': 'S3Storage',
        'supports_signing': True,
    },
    'ftp': {
        'class': 'FTPStorage',
        'supports_signing': False,
    },
    'local': {
        'class': 'LocalProtectedStorage',
        'supports_signing': False,
    },
}


def get_storage_backend(provider_type):
    """
    Retourne le backend de stockage approprié pour un type de provider.
    
    Args:
        provider_type: Type de provider ('vimeo', 'bunny', 's3', 'ftp', 'local')
    
    Returns:
        dict: Configuration du backend
    """
    return STORAGE_BACKENDS.get(provider_type, STORAGE_BACKENDS['local'])
