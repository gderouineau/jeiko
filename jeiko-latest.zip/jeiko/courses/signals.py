"""
Signals for the courses app.
Handles automatic progression updates and shop integration.
"""
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone

from .models import (
    VideoProgress, SectionProgress, QuizAttempt,
    CourseEnrollment, Section
)
from .utils import calculate_course_progress


@receiver(post_save, sender=VideoProgress)
def update_section_progress_on_video_complete(sender, instance, created, **kwargs):
    """
    Quand une vidéo est complétée, marquer la section comme complétée.
    """
    if instance.is_completed:
        section_progress, created = SectionProgress.objects.get_or_create(
            enrollment=instance.enrollment,
            section=instance.section,
            defaults={
                'is_completed': True,
                'completed_at': timezone.now()
            }
        )
        
        if not created and not section_progress.is_completed:
            section_progress.is_completed = True
            section_progress.completed_at = timezone.now()
            section_progress.save()


@receiver(post_save, sender=SectionProgress)
def recalculate_course_progress_on_section_update(sender, instance, **kwargs):
    """
    Recalculer la progression globale quand une section est marquée comme complétée/skippée.
    """
    if instance.is_completed or instance.is_skipped:
        calculate_course_progress(instance.enrollment)


@receiver(post_save, sender=QuizAttempt)
def update_section_progress_on_quiz_attempt(sender, instance, created, **kwargs):
    """
    Mettre à jour la progression de section après une tentative de quiz.
    """
    if instance.completed_at or instance.was_skipped:
        section = instance.quiz.section
        enrollment = instance.enrollment
        
        section_progress, created = SectionProgress.objects.get_or_create(
            enrollment=enrollment,
            section=section,
            defaults={
                'is_completed': instance.is_passed,
                'is_skipped': instance.was_skipped,
                'completed_at': timezone.now() if (instance.is_passed or instance.was_skipped) else None
            }
        )
        
        if not created:
            # Mettre à jour si nécessaire
            if instance.is_passed and not section_progress.is_completed:
                section_progress.is_completed = True
                section_progress.completed_at = timezone.now()
                section_progress.save()
            elif instance.was_skipped and not section_progress.is_skipped:
                section_progress.is_skipped = True
                section_progress.completed_at = timezone.now()
                section_progress.save()


# =============================================================================
# SHOP INTEGRATION
# =============================================================================

@receiver(post_save, sender='shop.Order')
def auto_grant_course_access_on_payment(sender, instance, created, **kwargs):
    """
    Accorder automatiquement l'accès aux formations après un paiement validé.
    
    Lorsqu'une commande passe à 'paid', on vérifie si elle contient des produits
    liés à des formations et on crée les CourseEnrollment automatiquement.
    """
    from jeiko.shop.models import Order
    from .utils import grant_course_access
    
    # Vérifier que le paiement est validé
    if instance.payment_status != Order.PAYMENT_STATUS_PAID:
        return
    
    # Parcourir les lignes de commande
    for line in instance.lines.all():
        product = line.product
        
        if not product:
            continue
        
        # Vérifier si le produit est lié à une formation
        if hasattr(product, 'linked_course') and product.linked_course:
            course = product.linked_course
            user = instance.user
            
            if not user:
                # Impossible d'accorder un accès sans utilisateur
                continue
            
            # Vérifier si l'utilisateur n'a pas déjà accès
            existing_enrollment = CourseEnrollment.objects.filter(
                user=user,
                course=course
            ).first()
            
            if existing_enrollment:
                # Mise à jour si nécessaire
                if not existing_enrollment.has_payed:
                    existing_enrollment.has_payed = True
                    existing_enrollment.order = instance
                    existing_enrollment.notes += f"\nAchat via commande #{instance.pk} le {timezone.now()}"
                    existing_enrollment.save()
            else:
                # Créer l'inscription
                grant_course_access(
                    user=user,
                    course=course,
                    granted_by=None,  # Automatique
                    has_payed=True,
                    order=instance,
                    notes=f"Accès automatique suite à l'achat de {product.sku} (commande #{instance.pk})"
                )
