"""
Views for managing the ordering of course content (Parts, Chapters, Sections, Questions).
"""
from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.views.decorators.cache import never_cache
from django.db import transaction
from django.db.models import F, Max
from django.contrib import messages

from ..models import Part, Chapter, Section, QuizQuestion

def _move_item(item, direction, sibling_filter):
    """
    Generic function to move an item up or down within its siblings.
    sibling_filter: dict to filter siblings (e.g. {'course': item.course})
    """
    model = item.__class__
    current_position = item.position
    
    if direction == 'up':
        # Find the item immediately above
        sibling = model.objects.filter(
            **sibling_filter,
            position__lt=current_position
        ).order_by('-position').first()
        
        if sibling:
            with transaction.atomic():
                # Swap positions
                sibling_position = sibling.position
                sibling.position = current_position
                sibling.save()
                
                item.position = sibling_position
                item.save()
                return True
                
    elif direction == 'down':
        # Find the item immediately below
        sibling = model.objects.filter(
            **sibling_filter,
            position__gt=current_position
        ).order_by('position').first()
        
        if sibling:
            with transaction.atomic():
                # Swap positions
                sibling_position = sibling.position
                sibling.position = current_position
                sibling.save()
                
                item.position = sibling_position
                item.save()
                return True
                
    return False


@staff_member_required
@never_cache
def move_part(request, part_id, direction):
    part = get_object_or_404(Part, id=part_id)
    if _move_item(part, direction, {'course': part.course}):
        messages.success(request, "Position mise à jour.")
    return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=part.course.id)


@staff_member_required
@never_cache
def move_chapter(request, chapter_id, direction):
    chapter = get_object_or_404(Chapter, id=chapter_id)
    if _move_item(chapter, direction, {'part': chapter.part}):
        messages.success(request, "Position mise à jour.")
    return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=chapter.part.course.id)


@staff_member_required
@never_cache
def move_section(request, section_id, direction):
    section = get_object_or_404(Section, id=section_id)
    if _move_item(section, direction, {'chapter': section.chapter}):
        messages.success(request, "Position mise à jour.")
    return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=section.chapter.part.course.id)


@staff_member_required
@never_cache
def move_quiz_question(request, question_id, direction):
    question = get_object_or_404(QuizQuestion, id=question_id)
    if _move_item(question, direction, {'quiz': question.quiz}):
        messages.success(request, "Position mise à jour.")
    return redirect('jeiko_courses:jeiko_courses_admin:quiz_content_edit', content_id=question.quiz.id)
