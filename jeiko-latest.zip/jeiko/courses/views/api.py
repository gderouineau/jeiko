"""
API views for courses app.
RESTful endpoints for AJAX interactions.
"""
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods
from django.shortcuts import get_object_or_404
from decimal import Decimal

from ..models import Section, QuizContent, CourseEnrollment, VideoProgress
from ..utils import update_video_progress as util_update_video_progress


@login_required
@never_cache
@require_http_methods(["POST"])
def update_video_progress(request):
    """
    Met à jour la progression vidéo (appelé via AJAX).
    
    POST params:
        - section_id: ID de la section vidéo
        - position: Position en secondes
        - duration: Durée totale en secondes
    """
    try:
        section_id = int(request.POST.get('section_id'))
        position = int(request.POST.get('position', 0))
        duration = int(request.POST.get('duration', 0))
    except (ValueError, TypeError):
        return JsonResponse({'error': 'Paramètres invalides'}, status=400)
    
    section = get_object_or_404(Section, id=section_id, section_type=Section.SECTION_TYPE_VIDEO)
    
    # Mettre à jour la progression
    progress = util_update_video_progress(request.user, section, position, duration)
    
    if progress:
        return JsonResponse({
            'success': True,
            'watched_percentage': float(progress.watched_percentage),
            'is_completed': progress.is_completed
        })
    else:
        return JsonResponse({'error': 'Pas d\'inscription'}, status=403)


@login_required
@never_cache
def get_video_progress(request, section_id):
    """
    Récupère la progression vidéo pour reprendre la lecture.
    """
    section = get_object_or_404(Section, id=section_id, section_type=Section.SECTION_TYPE_VIDEO)
    course = section.chapter.part.course
    
    try:
        enrollment = CourseEnrollment.objects.get(user=request.user, course=course)
        progress = VideoProgress.objects.filter(
            enrollment=enrollment,
            section=section
        ).first()
        
        if progress:
            return JsonResponse({
                'position': progress.last_position_seconds,
                'watched_percentage': float(progress.watched_percentage),
                'is_completed': progress.is_completed
            })
        else:
            return JsonResponse({'position': 0, 'watched_percentage': 0.0, 'is_completed': False})
    
    except CourseEnrollment.DoesNotExist:
        return JsonResponse({'error': 'Non inscrit'}, status=403)


@login_required
@never_cache
@require_http_methods(["POST"])
def start_quiz(request, quiz_id):
    """
    Démarrer un quiz (optionnel, peut être utilisé pour tracking).
    """
    quiz = get_object_or_404(QuizContent, id=quiz_id)
    
    # TODO: Potentiellement créer une tentative "started" si besoin de timer
    
    return JsonResponse({
        'success': True,
        'quiz_id': quiz.id,
        'passing_score': quiz.passing_score,
        'allow_skip': quiz.allow_skip
    })


@login_required
@never_cache
@require_http_methods(["POST"])
def submit_quiz(request):
    """
    Soumettre un quiz via AJAX (alternative à la vue client).
    """
    # Cette fonction peut dupliquer la logique de client.quiz_submit
    # ou rediriger vers elle
    from ..views.client import quiz_submit as client_quiz_submit
    return client_quiz_submit(request, request.POST.get('course_slug'), int(request.POST.get('quiz_id')))


@login_required
@never_cache
def quiz_results(request, quiz_id):
    """
    Récupérer les résultats des tentatives de quiz.
    """
    quiz = get_object_or_404(QuizContent, id=quiz_id)
    course = quiz.section.chapter.part.course
    
    try:
        enrollment = CourseEnrollment.objects.get(user=request.user, course=course)
        attempts = quiz.attempts.filter(user=request.user).order_by('-started_at')
        
        attempts_data = [{
            'id': attempt.id,
            'score': float(attempt.score_percentage),
            'passed': attempt.is_passed,
            'skipped': attempt.was_skipped,
            'date': attempt.started_at.isoformat()
        } for attempt in attempts[:5]]  # 5 dernières tentatives
        
        return JsonResponse({
            'attempts': attempts_data,
            'best_score': float(max([a.score_percentage for a in attempts], default=Decimal('0.0')))
        })
    
    except CourseEnrollment.DoesNotExist:
        return JsonResponse({'error': 'Non inscrit'}, status=403)


@login_required
@never_cache
def enrollment_progress(request, enrollment_id):
    """
    Récupérer les données de progression détaillées.
    """
    enrollment = get_object_or_404(
        CourseEnrollment.objects.select_related('course', 'user'),
        id=enrollment_id
    )
    
    # Vérifier que c'est bien l'utilisateur ou un admin
    if enrollment.user != request.user and not request.user.is_staff:
        return JsonResponse({'error': 'Accès refusé'}, status=403)
    
    # Récupérer les progressions de sections
    section_progresses = enrollment.section_progresses.all().select_related('section')
    
    sections_data = [{
        'section_id': sp.section.id,
        'section_title': sp.section.title,
        'is_completed': sp.is_completed,
        'is_skipped': sp.is_skipped,
        'completed_at': sp.completed_at.isoformat() if sp.completed_at else None
    } for sp in section_progresses]
    
    return JsonResponse({
        'enrollment_id': enrollment.id,
        'course_title': enrollment.course.title,
        'progress_percentage': float(enrollment.progress_percentage),
        'status': enrollment.status,
        'enrolled_at': enrollment.enrolled_at.isoformat(),
        'completed_at': enrollment.completed_at.isoformat() if enrollment.completed_at else None,
        'sections': sections_data
    })
