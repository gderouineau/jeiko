from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from .models import (
    Course, Part, Chapter, Section,
    VideoStorageProvider,
    VideoContent, TextContent, PDFContent, QuizContent,
    QuizQuestion, QuizAnswer,
    CourseEnrollment, SectionProgress, VideoProgress, QuizAttempt
)


# =============================================================================
# INLINE ADMINS
# =============================================================================

class PartInline(admin.TabularInline):
    model = Part
    extra = 0
    fields = ('position', 'title', 'is_published')
    ordering = ('position',)


class ChapterInline(admin.TabularInline):
    model = Chapter
    extra = 0
    fields = ('position', 'title', 'is_published')
    ordering = ('position',)


class SectionInline(admin.TabularInline):
    model = Section
    extra = 0
    fields = ('position', 'title', 'section_type', 'is_published')
    ordering = ('position',)


class QuizQuestionInline(admin.TabularInline):
    model = QuizQuestion
    extra = 0
    fields = ('position', 'question_text', 'question_type', 'points')
    ordering = ('position',)


class QuizAnswerInline(admin.TabularInline):
    model = QuizAnswer
    extra = 0
    fields = ('position', 'answer_text', 'is_correct')
    ordering = ('position',)


# =============================================================================
# MAIN MODEL ADMINS
# =============================================================================

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('title', 'level', 'is_restricted', 'is_active', 'enrollments_count', 'created_at')
    list_filter = ('level', 'is_restricted', 'is_active', 'created_at')
    search_fields = ('title', 'description', 'slug')
    prepopulated_fields = {'slug': ('title',)}
    readonly_fields = ('created_at', 'updated_at', 'created_by')
    inlines = [PartInline]
    
    fieldsets = (
        ('Informations principales', {
            'fields': ('title', 'slug', 'description', 'thumbnail')
        }),
        ('Configuration', {
            'fields': ('is_active', 'is_restricted', 'level', 'estimated_duration')
        }),
        ('Métadonnées', {
            'fields': ('created_by', 'created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def enrollments_count(self, obj):
        count = obj.enrollments.count()
        return format_html(
            '<a href="{}?course__id__exact={}">{} inscription(s)</a>',
            reverse('admin:courses_courseenrollment_changelist'),
            obj.pk,
            count
        )
    enrollments_count.short_description = "Inscriptions"
    
    def save_model(self, request, obj, form, change):
        if not change:  # Si création
            obj.created_by = request.user
        super().save_model(request, obj, form, change)


@admin.register(Part)
class PartAdmin(admin.ModelAdmin):
    list_display = ('title', 'course', 'position', 'is_published', 'chapters_count')
    list_filter = ('course', 'is_published')
    search_fields = ('title', 'description')
    inlines = [ChapterInline]
    
    fieldsets = (
        ('Informations', {
            'fields': ('course', 'title', 'position')
        }),
        ('Contenu', {
            'fields': ('description', 'content_details')
        }),
        ('Publication', {
            'fields': ('is_published',)
        }),
    )
    
    def chapters_count(self, obj):
        return obj.chapters.count()
    chapters_count.short_description = "Chapitres"


@admin.register(Chapter)
class ChapterAdmin(admin.ModelAdmin):
    list_display = ('title', 'part', 'position', 'is_published', 'sections_count')
    list_filter = ('part__course', 'is_published')
    search_fields = ('title', 'description')
    inlines = [SectionInline]
    
    fieldsets = (
        ('Informations', {
            'fields': ('part', 'title', 'position')
        }),
        ('Contenu', {
            'fields': ('description', 'content_details')
        }),
        ('Publication', {
            'fields': ('is_published',)
        }),
    )
    
    def sections_count(self, obj):
        return obj.sections.count()
    sections_count.short_description = "Sections"


@admin.register(Section)
class SectionAdmin(admin.ModelAdmin):
    list_display = ('title', 'chapter', 'section_type', 'position', 'is_published', 'has_content')
    list_filter = ('chapter__part__course', 'section_type', 'is_published')
    search_fields = ('title', 'description')
    
    fieldsets = (
        ('Informations', {
            'fields': ('chapter', 'title', 'position', 'section_type')
        }),
        ('Contenu', {
            'fields': ('description', 'content_details')
        }),
        ('Publication', {
            'fields': ('is_published',)
        }),
    )
    
    def has_content(self, obj):
        if obj.section_type == Section.SECTION_TYPE_VIDEO:
            has = hasattr(obj, 'video_content')
        elif obj.section_type == Section.SECTION_TYPE_TEXT:
            has = hasattr(obj, 'text_content')
        elif obj.section_type == Section.SECTION_TYPE_PDF:
            has = hasattr(obj, 'pdf_content')
        elif obj.section_type == Section.SECTION_TYPE_QUIZ:
            has = hasattr(obj, 'quiz_content')
        else:
            has = False
        
        return format_html(
            '<span style="color: {};">{}</span>',
            'green' if has else 'red',
            '✓' if has else '✗'
        )
    has_content.short_description = "Contenu"


# =============================================================================
# STORAGE PROVIDER ADMIN
# =============================================================================

@admin.register(VideoStorageProvider)
class VideoStorageProviderAdmin(admin.ModelAdmin):
    list_display = ('name', 'provider_type', 'is_active', 'url_signing_enabled', 'videos_count', 'updated_at')
    list_filter = ('provider_type', 'is_active', 'url_signing_enabled')
    search_fields = ('name', 'notes')
    readonly_fields = ('created_at', 'updated_at')
    
    fieldsets = (
        ('Informations', {
            'fields': ('name', 'provider_type', 'is_active')
        }),
        ('Configuration', {
            'fields': ('config', 'url_signing_enabled', 'url_expiry_seconds'),
            'description': 'Configuration JSON spécifique au provider. Voir le champ d\'aide pour les formats.'
        }),
        ('Notes', {
            'fields': ('notes',)
        }),
        ('Métadonnées', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def videos_count(self, obj):
        count = obj.videos.count()
        return f"{count} vidéo(s)"
    videos_count.short_description = "Vidéos"


# =============================================================================
# CONTENT ADMINS
# =============================================================================

@admin.register(VideoContent)
class VideoContentAdmin(admin.ModelAdmin):
    list_display = ('title_display', 'section', 'storage_type', 'duration_display', 'is_preview')
    list_filter = ('storage_type', 'is_preview', 'remote_provider')
    search_fields = ('title', 'description', 'section__title')
    readonly_fields = ('created_at', 'updated_at')
    
    fieldsets = (
        ('Section', {
            'fields': ('section',)
        }),
        ('Informations', {
            'fields': ('title', 'description', 'duration_seconds', 'thumbnail', 'is_preview')
        }),
        ('Stockage', {
            'fields': ('storage_type',)
        }),
        ('Stockage Local', {
            'fields': ('video_file',),
            'classes': ('collapse',)
        }),
        ('Stockage Distant (Provider)', {
            'fields': ('remote_provider', 'remote_video_id'),
            'classes': ('collapse',)
        }),
        ('Lien Direct', {
            'fields': ('direct_url',),
            'classes': ('collapse',)
        }),
        ('FTP', {
            'fields': ('ftp_path',),
            'classes': ('collapse',)
        }),
        ('Métadonnées', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def title_display(self, obj):
        return obj.title or obj.section.title
    title_display.short_description = "Titre"
    
    def duration_display(self, obj):
        minutes = obj.duration_seconds // 60
        seconds = obj.duration_seconds % 60
        return f"{minutes}:{seconds:02d}"
    duration_display.short_description = "Durée"


@admin.register(TextContent)
class TextContentAdmin(admin.ModelAdmin):
    list_display = ('section', 'content_preview', 'updated_at')
    search_fields = ('section__title', 'content')
    readonly_fields = ('created_at', 'updated_at')
    
    fieldsets = (
        ('Section', {
            'fields': ('section',)
        }),
        ('Contenu', {
            'fields': ('content',)
        }),
        ('Métadonnées', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def content_preview(self, obj):
        return obj.content[:100] + '...' if len(obj.content) > 100 else obj.content
    content_preview.short_description = "Aperçu"


@admin.register(PDFContent)
class PDFContentAdmin(admin.ModelAdmin):
    list_display = ('section', 'storage_type', 'has_file', 'updated_at')
    list_filter = ('storage_type',)
    search_fields = ('section__title',)
    readonly_fields = ('created_at', 'updated_at')
    
    fieldsets = (
        ('Section', {
            'fields': ('section',)
        }),
        ('Stockage', {
            'fields': ('storage_type',)
        }),
        ('Stockage Local', {
            'fields': ('file',),
            'classes': ('collapse',)
        }),
        ('URL Distante', {
            'fields': ('remote_url',),
            'classes': ('collapse',)
        }),
        ('FTP', {
            'fields': ('ftp_path',),
            'classes': ('collapse',)
        }),
        ('Métadonnées', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def has_file(self, obj):
        has = bool(obj.file) or bool(obj.remote_url) or bool(obj.ftp_path)
        return format_html(
            '<span style="color: {};">{}</span>',
            'green' if has else 'red',
            '✓' if has else '✗'
        )
    has_file.short_description = "Fichier"


@admin.register(QuizContent)
class QuizContentAdmin(admin.ModelAdmin):
    list_display = ('title_display', 'section', 'passing_score', 'allow_skip', 'questions_count', 'attempts_count')
    search_fields = ('title', 'section__title')
    readonly_fields = ('created_at', 'updated_at')
    inlines = [QuizQuestionInline]
    
    fieldsets = (
        ('Section', {
            'fields': ('section',)
        }),
        ('Configuration', {
            'fields': ('title', 'passing_score', 'allow_skip')
        }),
        ('Métadonnées', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def title_display(self, obj):
        return obj.title or obj.section.title
    title_display.short_description = "Titre"
    
    def questions_count(self, obj):
        return obj.questions.count()
    questions_count.short_description = "Questions"
    
    def attempts_count(self, obj):
        return obj.attempts.count()
    attempts_count.short_description = "Tentatives"


@admin.register(QuizQuestion)
class QuizQuestionAdmin(admin.ModelAdmin):
    list_display = ('question_preview', 'quiz', 'question_type', 'points', 'position')
    list_filter = ('question_type', 'quiz')
    search_fields = ('question_text',)
    inlines = [QuizAnswerInline]
    
    fieldsets = (
        ('Quiz', {
            'fields': ('quiz',)
        }),
        ('Question', {
            'fields': ('question_text', 'question_type', 'position', 'points')
        }),
    )
    
    def question_preview(self, obj):
        return obj.question_text[:80] + '...' if len(obj.question_text) > 80 else obj.question_text
    question_preview.short_description = "Question"


@admin.register(QuizAnswer)
class QuizAnswerAdmin(admin.ModelAdmin):
    list_display = ('answer_text_preview', 'question', 'is_correct', 'position')
    list_filter = ('is_correct', 'question__quiz')
    search_fields = ('answer_text',)
    
    def answer_text_preview(self, obj):
        marker = "✓" if obj.is_correct else "✗"
        text = obj.answer_text[:60] + '...' if len(obj.answer_text) > 60 else obj.answer_text
        return f"{marker} {text}"
    answer_text_preview.short_description = "Réponse"


# =============================================================================
# PROGRESSION ADMINS
# =============================================================================

@admin.register(CourseEnrollment)
class CourseEnrollmentAdmin(admin.ModelAdmin):
    list_display = ('user', 'course', 'status', 'progress_display', 'has_payed', 'enrolled_at', 'access_valid')
    list_filter = ('status', 'has_payed', 'course', 'enrolled_at')
    search_fields = ('user__email', 'user__first_name', 'user__last_name', 'course__title')
    readonly_fields = ('created_at', 'updated_at', 'enrolled_at', 'progress_percentage')
    date_hierarchy = 'enrolled_at'
    actions = ['activate_enrollments', 'suspend_enrollments', 'recalculate_progress']
    
    fieldsets = (
        ('Inscription', {
            'fields': ('user', 'course', 'status', 'enrolled_at')
        }),
        ('Progression', {
            'fields': ('progress_percentage', 'completed_at')
        }),
        ('Accès', {
            'fields': ('granted_by', 'has_payed', 'order', 'access_expires_at')
        }),
        ('Notes', {
            'fields': ('notes',)
        }),
        ('Métadonnées', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def progress_display(self, obj):
        # Convert to string first, then to float to handle SafeString
        progress_value = obj.progress_percentage
        if isinstance(progress_value, str):
            progress = float(progress_value.replace('%', '').strip())
        else:
            progress = float(progress_value)
        color = 'green' if progress >= 100 else ('orange' if progress >= 50 else 'gray')
        return format_html(
            '<span style="color: {}; font-weight: bold;">{}</span>',
            color,
            f'{progress:.1f}%'
        )
    progress_display.short_description = "Progression"
    
    def access_valid(self, obj):
        is_valid = obj.is_access_valid()
        return format_html(
            '<span style="color: {};">{}</span>',
            'green' if is_valid else 'red',
            '✓' if is_valid else '✗'
        )
    access_valid.short_description = "Accès valide"
    
    def activate_enrollments(self, request, queryset):
        updated = queryset.update(status=CourseEnrollment.STATUS_ACTIVE)
        self.message_user(request, f"{updated} inscription(s) activée(s).")
    activate_enrollments.short_description = "Activer les inscriptions sélectionnées"
    
    def suspend_enrollments(self, request, queryset):
        updated = queryset.update(status=CourseEnrollment.STATUS_SUSPENDED)
        self.message_user(request, f"{updated} inscription(s) suspendue(s).")
    suspend_enrollments.short_description = "Suspendre les inscriptions sélectionnées"
    
    def recalculate_progress(self, request, queryset):
        from jeiko.courses.utils_progress import update_course_progress
        count = 0
        for enrollment in queryset:
            update_course_progress(enrollment)
            count += 1
        self.message_user(request, f"Progression recalculée pour {count} inscription(s).")
    recalculate_progress.short_description = "Recalculer la progression"
    
    def save_model(self, request, obj, form, change):
        """Handle status changes and update progress when needed."""
        if change and 'status' in form.changed_data:
            # If status changed to ACTIVE from SUSPENDED, recalculate progress
            if obj.status == CourseEnrollment.STATUS_ACTIVE:
                from jeiko.courses.utils_progress import update_course_progress
                update_course_progress(obj)
        super().save_model(request, obj, form, change)


@admin.register(SectionProgress)
class SectionProgressAdmin(admin.ModelAdmin):
    list_display = ('user_display', 'section', 'is_completed', 'is_skipped', 'completed_at')
    list_filter = ('is_completed', 'is_skipped', 'enrollment__course')
    search_fields = ('enrollment__user__email', 'section__title')
    readonly_fields = ('created_at', 'updated_at')
    
    def user_display(self, obj):
        return obj.enrollment.user
    user_display.short_description = "Utilisateur"


@admin.register(VideoProgress)
class VideoProgressAdmin(admin.ModelAdmin):
    list_display = ('user_display', 'section', 'watched_display', 'is_completed', 'last_watched_at')
    list_filter = ('is_completed', 'enrollment__course')
    search_fields = ('enrollment__user__email', 'section__title')
    readonly_fields = ('created_at', 'updated_at', 'last_watched_at')
    
    def user_display(self, obj):
        return obj.enrollment.user
    user_display.short_description = "Utilisateur"
    
    def watched_display(self, obj):
        return f"{obj.watched_percentage:.1f}% ({obj.last_position_seconds}s)"
    watched_display.short_description = "Progression"


@admin.register(QuizAttempt)
class QuizAttemptAdmin(admin.ModelAdmin):
    list_display = ('user', 'quiz_display', 'score_display', 'is_passed', 'was_skipped', 'started_at')
    list_filter = ('is_passed', 'was_skipped', 'quiz__section__chapter__part__course')
    search_fields = ('user__email', 'quiz__title', 'quiz__section__title')
    readonly_fields = ('created_at', 'updated_at', 'started_at', 'answers_data')
    date_hierarchy = 'started_at'
    
    fieldsets = (
        ('Tentative', {
            'fields': ('user', 'quiz', 'enrollment', 'started_at', 'completed_at')
        }),
        ('Résultat', {
            'fields': ('score_percentage', 'is_passed', 'was_skipped')
        }),
        ('Détails', {
            'fields': ('answers_data',),
            'classes': ('collapse',)
        }),
        ('Métadonnées', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def quiz_display(self, obj):
        return obj.quiz.title or obj.quiz.section.title
    quiz_display.short_description = "Quiz"
    
    def score_display(self, obj):
        color = 'green' if obj.is_passed else ('orange' if obj.was_skipped else 'red')
        symbol = '✓' if obj.is_passed else ('⊘' if obj.was_skipped else '✗')
        return format_html(
            '<span style="color: {};">{} {:.1f}%</span>',
            color,
            symbol,
            obj.score_percentage
        )
    score_display.short_description = "Score"
