from django.urls import path
from ..views.client import (
    CheckoutView,
    CreatePaymentIntentView,
    StripeWebhookView,
    PaymentSuccessView,
    PaymentCancelView,
    PaymentCheckView
)

app_name = 'jeiko_payments_client'

urlpatterns = [
    path('checkout/', CheckoutView.as_view(), name='checkout'),
    path('create-payment-intent/', CreatePaymentIntentView.as_view(), name='create_payment_intent'),
    path('webhook/stripe/', StripeWebhookView.as_view(), name='stripe_webhook'),
    path('check/', PaymentCheckView.as_view(), name='check'),
    path('success/', PaymentSuccessView.as_view(), name='success'),
    path('cancel/', PaymentCancelView.as_view(), name='cancel'),
]
