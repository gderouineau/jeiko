from django.apps import AppConfig


class PaymentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko.payments'

    def ready(self):
        # STRIPE-02 : chaque appel à Stripe porte la version pour laquelle
        # le code est écrit, plus celle de la bibliothèque installée.
        import stripe

        from .branchement import VERSION_DE_L_API
        stripe.api_version = VERSION_DE_L_API
