import logging
from jeiko.shop.models import Order
from django.shortcuts import get_object_or_404

logger = logging.getLogger(__name__)

class StripeWebhookDispatcher:
    def dispatch(self, event):
        event_type = event['type']
        handler_name = 'handle_' + event_type.replace('.', '_')
        handler = getattr(self, handler_name, self.handle_unknown)
        
        logger.info(f"Dispatching Stripe event: {event_type}")
        return handler(event)

    def handle_unknown(self, event):
        logger.info(f"Unhandled Stripe event type: {event['type']}")

    # -------------------------------------------------------------------------
    # 1. Paiements (PaymentIntent)
    # -------------------------------------------------------------------------
    def handle_payment_intent_succeeded(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent succeeded: {payment_intent['id']}")
        
        order_id = payment_intent.get('metadata', {}).get('order_id')
        if order_id:
            try:
                order = Order.objects.get(pk=order_id)
                if order.payment_status != Order.PAYMENT_STATUS_PAID:
                    order.payment_status = Order.PAYMENT_STATUS_PAID
                    order.order_status = Order.ORDER_STATUS_CONFIRMED
                    order.save()
                    
                    if order.cart:
                        order.cart.is_locked = True
                        order.cart.save()
                    
                    logger.info(f"Order #{order.pk} marked as PAID via webhook.")
            except Order.DoesNotExist:
                logger.error(f"Order #{order_id} not found for PaymentIntent {payment_intent['id']}")

    def handle_payment_intent_payment_failed(self, event):
        payment_intent = event['data']['object']
        logger.warning(f"PaymentIntent failed: {payment_intent['id']} - {payment_intent.get('last_payment_error', {}).get('message')}")
        
        order_id = payment_intent.get('metadata', {}).get('order_id')
        if order_id:
            try:
                order = Order.objects.get(pk=order_id)
                order.payment_status = Order.PAYMENT_STATUS_FAILED
                order.save()
            except Order.DoesNotExist:
                pass

    def handle_payment_intent_processing(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent processing: {payment_intent['id']}")

    def handle_payment_intent_canceled(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent canceled: {payment_intent['id']}")
        
        order_id = payment_intent.get('metadata', {}).get('order_id')
        if order_id:
            try:
                order = Order.objects.get(pk=order_id)
                order.payment_status = Order.PAYMENT_STATUS_FAILED # Or cancelled?
                order.order_status = Order.ORDER_STATUS_CANCELLED
                order.save()
            except Order.DoesNotExist:
                pass

    def handle_payment_intent_requires_action(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent requires action: {payment_intent['id']}")

    # -------------------------------------------------------------------------
    # 2. Checkout (Sessions)
    # -------------------------------------------------------------------------
    def handle_checkout_session_completed(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session completed: {session['id']}")
        
        # Logic similar to payment_intent_succeeded if using checkout sessions for orders
        # For now, we are using PaymentIntents directly in the current flow, 
        # but if we switch to Checkout Sessions, this is where we'd handle fulfillment.
        if session.get('payment_status') == 'paid':
             # Fulfill order
             pass

    def handle_checkout_session_async_payment_succeeded(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session async payment succeeded: {session['id']}")

    def handle_checkout_session_async_payment_failed(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session async payment failed: {session['id']}")

    def handle_checkout_session_expired(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session expired: {session['id']}")

    # -------------------------------------------------------------------------
    # 3. Abonnements (Billing)
    # -------------------------------------------------------------------------
    def handle_customer_subscription_created(self, event):
        subscription = event['data']['object']
        logger.info(f"Subscription created: {subscription['id']}")

    def handle_customer_subscription_updated(self, event):
        subscription = event['data']['object']
        logger.info(f"Subscription updated: {subscription['id']}")

    def handle_customer_subscription_deleted(self, event):
        subscription = event['data']['object']
        logger.info(f"Subscription deleted: {subscription['id']}")

    def handle_customer_subscription_paused(self, event):
        subscription = event['data']['object']
        logger.info(f"Subscription paused: {subscription['id']}")

    def handle_customer_subscription_resumed(self, event):
        subscription = event['data']['object']
        logger.info(f"Subscription resumed: {subscription['id']}")

    def handle_customer_subscription_trial_will_end(self, event):
        subscription = event['data']['object']
        logger.info(f"Subscription trial will end: {subscription['id']}")

    # Invoices
    def handle_invoice_created(self, event):
        invoice = event['data']['object']
        logger.info(f"Invoice created: {invoice['id']}")

    def handle_invoice_finalized(self, event):
        invoice = event['data']['object']
        logger.info(f"Invoice finalized: {invoice['id']}")

    def handle_invoice_payment_succeeded(self, event):
        invoice = event['data']['object']
        logger.info(f"Invoice payment succeeded: {invoice['id']}")

    def handle_invoice_payment_failed(self, event):
        invoice = event['data']['object']
        logger.info(f"Invoice payment failed: {invoice['id']}")

    def handle_invoice_marked_uncollectible(self, event):
        invoice = event['data']['object']
        logger.info(f"Invoice marked uncollectible: {invoice['id']}")

    def handle_invoice_voided(self, event):
        invoice = event['data']['object']
        logger.info(f"Invoice voided: {invoice['id']}")

    # -------------------------------------------------------------------------
    # 4. Paiements à l’étranger / SCA (Mandats)
    # -------------------------------------------------------------------------
    def handle_mandate_updated(self, event):
        mandate = event['data']['object']
        logger.info(f"Mandate updated: {mandate['id']}")

    def handle_mandate_created(self, event):
        mandate = event['data']['object']
        logger.info(f"Mandate created: {mandate['id']}")

    # -------------------------------------------------------------------------
    # 5. Clients
    # -------------------------------------------------------------------------
    def handle_customer_created(self, event):
        customer = event['data']['object']
        logger.info(f"Customer created: {customer['id']}")

    def handle_customer_updated(self, event):
        customer = event['data']['object']
        logger.info(f"Customer updated: {customer['id']}")

    def handle_customer_deleted(self, event):
        customer = event['data']['object']
        logger.info(f"Customer deleted: {customer['id']}")

    # -------------------------------------------------------------------------
    # 6. Produits & Prix
    # -------------------------------------------------------------------------
    def handle_product_created(self, event):
        product = event['data']['object']
        logger.info(f"Product created: {product['id']}")

    def handle_product_updated(self, event):
        product = event['data']['object']
        logger.info(f"Product updated: {product['id']}")

    def handle_price_created(self, event):
        price = event['data']['object']
        logger.info(f"Price created: {price['id']}")

    def handle_price_updated(self, event):
        price = event['data']['object']
        logger.info(f"Price updated: {price['id']}")

    # -------------------------------------------------------------------------
    # Charges (Legacy but useful)
    # -------------------------------------------------------------------------
    def handle_charge_succeeded(self, event):
        charge = event['data']['object']
        logger.info(f"Charge succeeded: {charge['id']}")

    def handle_charge_failed(self, event):
        charge = event['data']['object']
        logger.info(f"Charge failed: {charge['id']}")

    def handle_charge_refunded(self, event):
        charge = event['data']['object']
        logger.info(f"Charge refunded: {charge['id']}")

    def handle_charge_dispute_created(self, event):
        dispute = event['data']['object']
        logger.warning(f"Dispute created: {dispute['id']}")

    def handle_charge_dispute_closed(self, event):
        dispute = event['data']['object']
        logger.info(f"Dispute closed: {dispute['id']}")
