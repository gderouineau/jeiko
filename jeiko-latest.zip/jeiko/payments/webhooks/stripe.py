import logging

from jeiko.shop.models import Order
from jeiko.shop.services import mark_order_paid

logger = logging.getLogger(__name__)


def _evenement_perime(order, payment_intent):
    """
    Un échec ou une annulation ne s'applique qu'à la commande qui attend
    ENCORE cette intention. Stripe livre les événements en double et dans le
    désordre : l'annulation d'une ancienne intention passait en échec une
    commande payée par une autre (audit du 11/10/2026, F01).
    """
    if order.payment_status in (Order.PAYMENT_STATUS_PAID, Order.PAYMENT_STATUS_REFUNDED,
                                Order.PAYMENT_STATUS_PARTIALLY_REFUNDED):
        return True
    courante = order.payment_intent_id or ""
    return bool(courante) and courante != payment_intent.get("id")


class StripeWebhookDispatcher:
    def dispatch(self, event):
        event_type = event['type']
        handler_name = 'handle_' + event_type.replace('.', '_')
        handler = getattr(self, handler_name, self.handle_unknown)
        
        logger.info(f"Dispatching Stripe event: {event_type}")
        return handler(event)

    def handle_unknown(self, event):
        """
        Événement Stripe qu'aucun gestionnaire ne traite.

        Journalisé en AVERTISSEMENT et non en information : c'est le signe qu'un
        flux a été activé côté Stripe sans contrepartie côté site, et personne
        ne l'apprendrait en le noyant dans le bruit.
        """
        logger.warning("Événement Stripe non traité : %s", event['type'])

    # -------------------------------------------------------------------------
    # 1. Paiements (PaymentIntent)
    # -------------------------------------------------------------------------
    def handle_payment_intent_succeeded(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent succeeded: {payment_intent['id']}")

        # Rendez-vous du module calendars : la logique reste dans calendars,
        # on ne fait que la déclencher ici.
        self._handle_appointment_payment(payment_intent)
        self._handle_piece_payment(payment_intent)

        order_id = payment_intent.get('metadata', {}).get('order_id')
        if order_id:
            try:
                order = Order.objects.get(pk=order_id)
            except Order.DoesNotExist:
                logger.error(f"Order #{order_id} not found for PaymentIntent {payment_intent['id']}")
                return

            from ..verification import ecart_de_paiement, signaler_paiement_non_conforme

            ecart = ecart_de_paiement(order, payment_intent)
            if ecart and order.payment_status != Order.PAYMENT_STATUS_PAID:
                # 200 à Stripe malgré tout : rejouer l'événement ne changerait
                # pas le montant. C'est à l'exploitant de trancher.
                signaler_paiement_non_conforme(order, payment_intent, ecart, "stripe:webhook")
                return

            # Le webhook accorde désormais les accès et décrémente le stock,
            # comme le retour navigateur : c'est le seul chemin fiable quand
            # le client ferme son onglet après paiement.
            if mark_order_paid(order, source="stripe:webhook"):
                logger.info(f"Order #{order.pk} marked as PAID via webhook.")

    def _handle_piece_payment(self, payment_intent):
        """Enregistre le paiement d'une facture faite à la main (FACT-01), s'il en désigne une."""
        if not (payment_intent.get('metadata') or {}).get('jeiko_piece_id'):
            return
        try:
            from jeiko.shop.pieces_paiement import confirmer

            confirmer(payment_intent)
        except Exception:
            # L'erreur REMONTE : Stripe reçoit une 500 et renvoie l'événement
            # plus tard (pendant trois jours, en espaçant). Répondre 200 ici
            # acquittait un paiement jamais enregistré (audit du 11/10, F02).
            # `confirmer` est idempotent : un renvoi ne compte rien deux fois.
            logger.exception("Paiement de facture %s non enregistré", payment_intent.get('id'))
            raise

    def _handle_appointment_payment(self, payment_intent):
        """Confirme un rendez-vous payé, si l'évènement en désigne un."""
        if not (payment_intent.get('metadata') or {}).get('jeiko_appointment_id'):
            return
        try:
            from jeiko.calendars import payments as calendar_payments
            from jeiko.calendars.views import send_booking_emails_safe

            appointment, confirmed = calendar_payments.confirm_from_webhook(payment_intent)
            if confirmed:
                logger.info("Rendez-vous #%s confirmé par webhook Stripe.", appointment.pk)
                send_booking_emails_safe(appointment.pk)
        except Exception:
            # Remonte, pour que Stripe renvoie l'événement (F02) ; mark_paid
            # est idempotent, sous verrou.
            logger.exception(
                "Confirmation de rendez-vous impossible pour le PaymentIntent %s",
                payment_intent.get('id'),
            )
            raise

    def handle_payment_intent_payment_failed(self, event):
        payment_intent = event['data']['object']
        logger.warning(f"PaymentIntent failed: {payment_intent['id']} - {payment_intent.get('last_payment_error', {}).get('message')}")
        
        order_id = payment_intent.get('metadata', {}).get('order_id')
        if order_id:
            try:
                order = Order.objects.get(pk=order_id)
            except Order.DoesNotExist:
                return
            if _evenement_perime(order, payment_intent):
                logger.info("Échec de %s ignoré : commande #%s déjà réglée ou sur une autre intention.",
                            payment_intent['id'], order.pk)
                return
            order.payment_status = Order.PAYMENT_STATUS_FAILED
            order.save(update_fields=["payment_status", "updated_at"])

            # Le client doit savoir que son paiement n'est pas passé, et
            # pouvoir le reprendre. Le motif vient de Stripe : il est plus
            # utile que « une erreur est survenue » (carte expirée, plafond…).
            from jeiko.shop.emailing import send_payment_failed_email

            motif = (payment_intent.get('last_payment_error') or {}).get('message') or ""
            try:
                send_payment_failed_email(order, motif=motif)
            except Exception:
                logger.exception(
                    "E-mail d'échec de paiement impossible (commande #%s)", order.pk
                )

    def handle_payment_intent_processing(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent processing: {payment_intent['id']}")

    def handle_payment_intent_canceled(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent canceled: {payment_intent['id']}")
        
        order_id = payment_intent.get('metadata', {}).get('order_id')
        if order_id:
            try:
                order = Order.objects.get(pk=order_id)
            except Order.DoesNotExist:
                return
            if _evenement_perime(order, payment_intent):
                logger.info("Annulation de %s ignorée : commande #%s déjà réglée ou sur une autre intention.",
                            payment_intent['id'], order.pk)
                return
            order.payment_status = Order.PAYMENT_STATUS_FAILED
            order.order_status = Order.ORDER_STATUS_CANCELLED
            order.save(update_fields=["payment_status", "order_status", "updated_at"])

    def handle_payment_intent_requires_action(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent requires action: {payment_intent['id']}")

    # -------------------------------------------------------------------------
    # 2. Checkout (Sessions)
    # -------------------------------------------------------------------------
    def handle_checkout_session_completed(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session completed: {session['id']}")
        # Seule la page de paiement d'un ABONNEMENT passe par Checkout
        # (shop/abonnements.py) ; les commandes ordinaires règlent une
        # intention de paiement, traitée plus haut.
        if session.get('mode') == 'subscription' and session.get('subscription'):
            self._abonnement(event, session.get('subscription'))

    def handle_checkout_session_async_payment_succeeded(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session async payment succeeded: {session['id']}")

    def handle_checkout_session_async_payment_failed(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session async payment failed: {session['id']}")

    def handle_checkout_session_expired(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session expired: {session['id']}")

    # -------------------------------------------------------------------------
    # 3. Abonnements (Billing) — voir jeiko/shop/abonnements.py
    # -------------------------------------------------------------------------
    def _abonnement(self, event, subscription):
        """
        Relit l'abonnement chez Stripe et recopie son état. L'erreur REMONTE :
        Stripe renvoie l'événement plus tard (F02) ; relire est idempotent.
        """
        from jeiko.shop.abonnements import _id, synchroniser

        try:
            synchroniser(_id(subscription))
        except Exception:
            logger.exception("Abonnement %s non synchronisé (%s)", _id(subscription), event.get('type'))
            raise

    def handle_customer_subscription_created(self, event):
        self._abonnement(event, event['data']['object'])

    def handle_customer_subscription_updated(self, event):
        self._abonnement(event, event['data']['object'])

    def handle_customer_subscription_deleted(self, event):
        self._abonnement(event, event['data']['object'])

    def handle_customer_subscription_paused(self, event):
        self._abonnement(event, event['data']['object'])

    def handle_customer_subscription_resumed(self, event):
        self._abonnement(event, event['data']['object'])

    def handle_customer_subscription_trial_will_end(self, event):
        # Stripe prévient lui-même le client (réglage « e-mails » du compte).
        logger.info("Fin d'essai proche : %s", event['data']['object'].get('id'))

    def handle_invoice_paid(self, event):
        """Un prélèvement réussi : une commande payée, des licences prolongées."""
        invoice = event['data']['object']
        try:
            from jeiko.shop.abonnements import enregistrer_le_paiement

            enregistrer_le_paiement(invoice)
        except Exception:
            logger.exception("Prélèvement %s non enregistré", invoice.get('id'))
            raise

    def handle_invoice_payment_failed(self, event):
        # Stripe relance et prévient le client ; on recopie le statut
        # (past_due), et les licences gardent leur date.
        invoice = event['data']['object']
        logger.warning("Prélèvement d'abonnement refusé : facture %s", invoice.get('id'))
        from jeiko.shop.abonnements import _abonnement_de_la_facture

        subscription = _abonnement_de_la_facture(invoice)
        if subscription:
            self._abonnement(event, subscription)

    # Étapes intermédiaires d'une facture : `invoice.paid` suffit.
    def handle_invoice_created(self, event):
        logger.info("Facture Stripe créée : %s", event['data']['object'].get('id'))

    def handle_invoice_finalized(self, event):
        logger.info("Facture Stripe finalisée : %s", event['data']['object'].get('id'))

    def handle_invoice_payment_succeeded(self, event):
        logger.info("Facture Stripe réglée : %s", event['data']['object'].get('id'))

    def handle_invoice_marked_uncollectible(self, event):
        logger.warning("Facture Stripe irrécouvrable : %s", event['data']['object'].get('id'))

    def handle_invoice_voided(self, event):
        logger.info("Facture Stripe annulée : %s", event['data']['object'].get('id'))

    # -------------------------------------------------------------------------
    # 4. Paiements à l’étranger / SCA (Mandats)
    # -------------------------------------------------------------------------
    def handle_mandate_updated(self, event):
        mandate = event['data']['object']
        logger.info(f"Mandate updated: {mandate['id']}")

    def handle_mandate_created(self, event):
        mandate = event['data']['object']
        logger.info(f"Mandate created: {mandate['id']}")

    # -------------------------------------------------------------------------
    # 5. Clients
    # -------------------------------------------------------------------------
    def handle_customer_created(self, event):
        customer = event['data']['object']
        logger.info(f"Customer created: {customer['id']}")

    def handle_customer_updated(self, event):
        customer = event['data']['object']
        logger.info(f"Customer updated: {customer['id']}")

    def handle_customer_deleted(self, event):
        customer = event['data']['object']
        logger.info(f"Customer deleted: {customer['id']}")

    # -------------------------------------------------------------------------
    # 6. Produits & Prix
    # -------------------------------------------------------------------------
    def handle_product_created(self, event):
        product = event['data']['object']
        logger.info(f"Product created: {product['id']}")

    def handle_product_updated(self, event):
        product = event['data']['object']
        logger.info(f"Product updated: {product['id']}")

    def handle_price_created(self, event):
        price = event['data']['object']
        logger.info(f"Price created: {price['id']}")

    def handle_price_updated(self, event):
        price = event['data']['object']
        logger.info(f"Price updated: {price['id']}")

    # -------------------------------------------------------------------------
    # Charges (Legacy but useful)
    # -------------------------------------------------------------------------
    def handle_charge_succeeded(self, event):
        charge = event['data']['object']
        logger.info(f"Charge succeeded: {charge['id']}")

    def handle_charge_failed(self, event):
        charge = event['data']['object']
        logger.info(f"Charge failed: {charge['id']}")

    def handle_charge_refunded(self, event):
        charge = event['data']['object']
        logger.info(f"Charge refunded: {charge['id']}")
        # Répercute sur le rendez-vous concerné (remboursement fait depuis le
        # tableau de bord Stripe, ou confirmation d'un remboursement déclenché
        # par le site). La logique reste dans calendars.
        try:
            from jeiko.calendars import payments as calendar_payments
            calendar_payments.mark_refunded_from_charge(charge)
        except Exception:
            logger.exception("Répercussion du remboursement impossible (charge=%s)",
                             charge.get('id'))
        # Et sur la commande de la boutique réglée par la même intention
        # (Fable 1, §3.6) : elle restait « payée » après un remboursement fait
        # depuis Stripe.
        try:
            from jeiko.shop.remboursement import rembourser_depuis_stripe
            rembourser_depuis_stripe(charge)
        except Exception:
            logger.exception("Remboursement de commande non répercuté (charge=%s)",
                             charge.get('id'))

    def handle_charge_dispute_created(self, event):
        dispute = event['data']['object']
        logger.warning(f"Dispute created: {dispute['id']}")

    def handle_charge_dispute_closed(self, event):
        dispute = event['data']['object']
        logger.info(f"Dispute closed: {dispute['id']}")
