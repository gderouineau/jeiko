from django.views.generic import ListView, UpdateView, CreateView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from ..models import PaymentGateway
from ..forms import PaymentGatewayForm

class PaymentGatewayListView(LoginRequiredMixin, ListView):
    model = PaymentGateway
    template_name = 'payments/admin/gateway_list.html'
    context_object_name = 'gateways'

class PaymentGatewayUpdateView(LoginRequiredMixin, UpdateView):
    model = PaymentGateway
    form_class = PaymentGatewayForm
    template_name = 'payments/admin/gateway_form.html'
    success_url = reverse_lazy('jeiko_payments_admin:gateway_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['update'] = True
        return context

class PaymentGatewayCreateView(LoginRequiredMixin, CreateView):
    model = PaymentGateway
    form_class = PaymentGatewayForm
    template_name = 'payments/admin/gateway_form.html'
    success_url = reverse_lazy('jeiko_payments_admin:gateway_list')
