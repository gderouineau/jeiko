from django.views.generic import TemplateView, View
from django.http import JsonResponse, HttpResponse, HttpResponseRedirect
from django.shortcuts import redirect, get_object_or_404
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from ..services.stripe import StripeService
from jeiko.shop.models import Cart, Order, OrderLine
from jeiko.shop.views.client import get_or_create_cart
import json
import stripe


class CheckoutView(TemplateView):
    template_name = 'payments/client/checkout.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Get cart and total
        cart = get_or_create_cart(self.request)
        items = cart.items.all()
        total_ttc = sum(item.total_ttc for item in items)

        context['cart'] = cart
        context['total_ttc'] = total_ttc
        
        stripe_service = StripeService()
        if stripe_service.gateway:
            context['stripe_public_key'] = stripe_service.gateway.api_key
        return context

class CreatePaymentIntentView(View):
    def post(self, request, *args, **kwargs):
        try:
            # Get cart and total
            cart = get_or_create_cart(request)
            items = cart.items.all()
            if not items:
                 return JsonResponse({'error': 'Cart is empty'}, status=400)

            total_ttc = sum(item.total_ttc for item in items)
            
            # Create or update Order
            order, created = Order.objects.get_or_create(
                cart=cart,
                defaults={
                    'user': request.user if request.user.is_authenticated else None,
                    'order_status': Order.ORDER_STATUS_DRAFT,
                    'payment_status': Order.PAYMENT_STATUS_PENDING,
                    'currency': 'EUR', # Should come from cart/settings
                    'total_ht': sum(item.total_ht for item in items),
                    'total_ttc': total_ttc,
                }
            )
            
            if not created:
                # Update totals if order already existed
                order.total_ht = sum(item.total_ht for item in items)
                order.total_ttc = total_ttc
                order.save()

            # Create OrderLines if needed (or sync them)
            # For simplicity, we wipe and recreate lines to ensure sync with cart
            order.lines.all().delete()
            for item in items:
                OrderLine.objects.create(
                    order=order,
                    product=item.product,
                    label=f"{item.product.sku} - {item.product.content.title}",
                    sku=item.product.sku,
                    quantity=item.quantity,
                    unit_price_ht=item.unit_price_ht,
                    tax_rate=item.tax_rate
                )

            stripe_service = StripeService()
            # Pass order_id in metadata
            intent = stripe_service.create_payment_intent(
                amount=total_ttc, 
                currency='eur',
                metadata={'order_id': order.pk}
            )
            
            return JsonResponse({
                'clientSecret': intent['client_secret']
            })
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)


@method_decorator(csrf_exempt, name='dispatch')
class StripeWebhookView(View):
    def post(self, request, *args, **kwargs):
        payload = request.body
        sig_header = request.META.get('HTTP_STRIPE_SIGNATURE')
        
        stripe_service = StripeService()
        
        try:
            event = stripe_service.construct_event(payload, sig_header)
        except Exception as e:
            return HttpResponse(status=400)

        # Handle the event using the Dispatcher
        from ..webhooks.stripe import StripeWebhookDispatcher
        dispatcher = StripeWebhookDispatcher()
        dispatcher.dispatch(event)
        
        return HttpResponse(status=200)


class PaymentCheckView(View):
    def get(self, request, *args, **kwargs):
        payment_intent_id = request.GET.get('payment_intent')
        payment_intent_client_secret = request.GET.get('payment_intent_client_secret')
        
        if not payment_intent_id:
             return redirect('jeiko_payments_client:checkout')

        stripe_service = StripeService()
        try:
            # Ensure secret key is set
            stripe.api_key = stripe_service.gateway.secret_key
            
            # Retrieve the PaymentIntent from Stripe
            intent = stripe.PaymentIntent.retrieve(payment_intent_id)

            if intent.status == 'succeeded':
                order_id = intent.metadata.get('order_id')
                if order_id:
                    order = get_object_or_404(Order, pk=order_id)
                    
                    # Update status
                    if order.payment_status != Order.PAYMENT_STATUS_PAID:
                        order.payment_status = Order.PAYMENT_STATUS_PAID
                        order.order_status = Order.ORDER_STATUS_CONFIRMED
                        order.save()
                        
                        # Grant access to linked ExpertTests and Courses
                        if order.user and order.user.is_authenticated:
                            from jeiko.questionnaires_expert.models import UserTestAccess
                            from jeiko.courses.models import CourseEnrollment
                            
                            for line in order.lines.all():
                                # Expert Tests
                                if hasattr(line.product, 'linked_expert_test') and line.product.linked_expert_test:
                                    UserTestAccess.objects.get_or_create(
                                        user=order.user,
                                        test=line.product.linked_expert_test,
                                        defaults={'source': 'PURCHASE'}
                                    )
                                
                                # Courses
                                if hasattr(line.product, 'linked_course') and line.product.linked_course:
                                    CourseEnrollment.objects.get_or_create(
                                        user=order.user,
                                        course=line.product.linked_course,
                                        defaults={
                                            'status': CourseEnrollment.STATUS_ACTIVE,
                                            'has_payed': True,
                                            'order': order,
                                            'granted_by': None # System granted via purchase
                                        }
                                    )

                                # Update stock if needed (optional, depending on product type)
                                # if line.product.product_type.kind == ...
                        
                        # Lock cart
                        if order.cart:
                            order.cart.is_locked = True
                            order.cart.save()
                            
                            # Clear session cart if it matches
                            if request.session.session_key == order.cart.session_key:
                                # We don't delete the session, but we might want to ensure a new cart is created next time
                                pass 

                    return redirect('jeiko_users_client:order_detail', pk=order.pk)
            
            # If not succeeded or other issue
            return redirect('jeiko_payments_client:checkout')

        except Exception as e:
            print(f"Error checking payment: {e}")
            return redirect('jeiko_payments_client:checkout')

class PaymentSuccessView(TemplateView):
    template_name = 'payments/client/success.html'

class PaymentCancelView(TemplateView):
    template_name = 'payments/client/cancel.html'
