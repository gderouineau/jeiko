from django.db import models
from django.core.exceptions import ValidationError
from jeiko.encrypted import EncryptedCharField
from django.utils.translation import gettext_lazy as _

class PaymentGateway(models.Model):
    GATEWAY_CHOICES = (
        ('stripe', _('Stripe')),
    )

    name = models.CharField(_("Nom"), max_length=100)
    code = models.SlugField(_("Code"), unique=True, choices=GATEWAY_CHOICES, default='stripe', help_text=_("Identifiant unique (ex: stripe)"))
    is_active = models.BooleanField(_("Actif"), default=False)
    
    # API Keys
    api_key = models.CharField(_("Clé API publique"), max_length=255, blank=True)
    # Chiffrés au repos : un dump de base volé ne doit pas livrer de quoi
    # émettre des remboursements ni forger des webhooks. La clé dérive de
    # SECRET_KEY, qui vit dans le .env (0600) et non dans la base.
    secret_key = EncryptedCharField(_("Clé secrète"), max_length=255, blank=True)
    webhook_secret = EncryptedCharField(_("Secret Webhook"), max_length=255, blank=True)
    
    test_mode = models.BooleanField(_("Mode Test"), default=True)

    # STRIPE-01 — ce que le webhook a vu passer, pour dire à l'exploitant si
    # le branchement marche : le dernier événement accepté, la dernière
    # signature refusée (secret du webhook qui ne correspond pas). Écrits
    # par `StripeWebhookView`, jamais par le formulaire.
    dernier_evenement_le = models.DateTimeField(_("Dernier événement reçu le"), null=True, blank=True, editable=False)
    dernier_evenement_type = models.CharField(_("Type du dernier événement"), max_length=100, blank=True, editable=False)
    dernier_refus_le = models.DateTimeField(_("Dernière signature refusée le"), null=True, blank=True, editable=False)
    # STRIPE-02 — la version d'API du dernier avis accepté (`api_version` de
    # l'événement), comparée à `branchement.VERSION_DE_L_API`.
    dernier_evenement_version = models.CharField(_("Version du dernier événement"), max_length=40,
                                                 blank=True, editable=False)

    class Meta:
        verbose_name = _("Moyen de paiement")
        verbose_name_plural = _("Moyens de paiement")

    def __str__(self):
        return self.name

    def clean(self):
        super().clean()
        if (
            self.code == "stripe"
            and self.is_active
            and not (self.webhook_secret or "").strip()
        ):
            raise ValidationError({
                "webhook_secret": _(
                    "Le secret de webhook Stripe est obligatoire pour activer "
                    "cette passerelle."
                )
            })

    def save(self, *args, **kwargs):
        # `save()` protège aussi les créations faites hors du formulaire
        # d'administration. On appelle volontairement `clean()` plutôt que
        # `full_clean()` pour ne pas modifier ici les autres contrats hérités
        # du modèle (unicité, choix historiques, etc.).
        self.clean()
        if self.is_active:
            # Ensure only this gateway is active
            PaymentGateway.objects.filter(is_active=True).exclude(pk=self.pk).update(is_active=False)
        super().save(*args, **kwargs)
