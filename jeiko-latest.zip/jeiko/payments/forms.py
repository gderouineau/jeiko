from django import forms
from .models import PaymentGateway

class PaymentGatewayForm(forms.ModelForm):
    class Meta:
        model = PaymentGateway
        fields = ['name', 'code', 'is_active', 'api_key', 'secret_key', 'webhook_secret', 'test_mode']
        widgets = {
            'secret_key': forms.PasswordInput(render_value=True),
            'webhook_secret': forms.PasswordInput(render_value=True),
        }
