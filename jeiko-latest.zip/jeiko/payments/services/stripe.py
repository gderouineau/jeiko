import logging

import stripe

from jeiko.shop.services import to_minor_units

from ..models import PaymentGateway

logger = logging.getLogger(__name__)


class StripeService:
    def __init__(self):
        self.gateway = PaymentGateway.objects.filter(code='stripe').first()
        if self.gateway:
            stripe.api_key = self.gateway.secret_key

    def create_payment_intent(self, amount, currency='eur', metadata=None, idempotency_key=None):
        """
        `idempotency_key` : deux ouvertures du même paiement (deux onglets, un
        rafraîchissement) rendent LA MÊME intention pendant 24 h au lieu d'en
        créer deux payables — deux encaissements pour une seule dette (audit
        du 11/10/2026, F03). La clé doit changer avec le montant.
        """
        if not self.gateway or not self.gateway.is_active:
            raise Exception("Stripe gateway is not active or configured")

        options = {"idempotency_key": idempotency_key} if idempotency_key else {}
        try:
            intent = stripe.PaymentIntent.create(
                # Arrondi au centime avant conversion : int() seul tronquait
                # (cf. jeiko.shop.services.to_minor_units).
                amount=to_minor_units(amount, currency),
                currency=currency,
                metadata=metadata or {},
                **options,
            )
            return intent
        except stripe.error.StripeError as e:
            # Handle error
            raise e

    @staticmethod
    def cle_d_idempotence(nature, pk, montant, devise):
        """
        Une clé par (site, objet, montant) : un compte Stripe peut servir
        plusieurs sites, dont les identifiants se recouvrent.
        """
        from django.conf import settings

        site = getattr(settings, "SITE_NAME", "") or "jeiko"
        return f"jeiko-{site}-{nature}-{pk}-{to_minor_units(montant, devise)}-{devise.lower()}"

    def cancel_payment_intent(self, intent_id):
        """
        Annule une intention encore ouverte. Ne lève jamais.

        Une intention déjà réussie, ou déjà annulée, refuse l'annulation :
        c'est normal, et le contrôle de montant couvre le cas réussi.
        """
        if not intent_id or not self.gateway:
            return False
        try:
            stripe.PaymentIntent.cancel(intent_id)
            return True
        except Exception:
            logger.info("Intention %s non annulée (déjà close ?)", intent_id)
            return False

    def construct_event(self, payload, sig_header):
        if not self.gateway:
            raise RuntimeError("La passerelle Stripe n'est pas configurée.")

        webhook_secret = (self.gateway.webhook_secret or "").strip()
        if not webhook_secret:
            # Une signature HMAC calculée avec une clé vide peut être valide
            # pour la bibliothèque Stripe : le refus doit donc avoir lieu
            # avant de lui transmettre le corps de la requête.
            logger.error(
                "Webhook Stripe refusé : aucun secret de webhook n'est configuré."
            )
            raise RuntimeError(
                "Le secret du webhook Stripe n'est pas configuré."
            )
        
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, webhook_secret
            )
            return event
        except ValueError as e:
            # Invalid payload
            raise e
        except stripe.error.SignatureVerificationError as e:
            # Invalid signature
            raise e
