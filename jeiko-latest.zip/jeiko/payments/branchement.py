# jeiko/payments/branchement.py
"""
STRIPE-01 — brancher Stripe sans quitter JEIKO.

Le problème : une passerelle « active » ne dit pas qu'elle marche. Le cas
courant est un webhook mal déclaré chez Stripe — adresse fausse, événement
pas coché, secret recopié d'un autre point de terminaison. Le paiement passe
chez Stripe, le site n'en sait rien, la commande reste « en attente ». Rien
ne le montrait avant qu'un client ne se plaigne.

Ce module dit, à l'écran de la passerelle :
* ce qu'il faut déclarer chez Stripe — l'adresse du webhook et les
  événements que le site TRAITE (`EVENEMENTS`, verrouillée par un test sur
  le répartiteur : un événement listé sans gestionnaire serait un mensonge) ;
* ce qui peut se vérifier sans appeler Stripe — clés présentes, de la bonne
  forme et du même mode (test / réel) que la case « Mode test », secret du
  webhook présent, dernier événement reçu, dernière signature refusée.

Ce qu'il ne fait pas : appeler l'API de Stripe pour lire la configuration du
compte (portail client, événements réellement cochés). Une clé restreinte
peut ne pas en avoir le droit, et un écran d'administration qui attend
Stripe pour s'afficher est un écran lent. Aucune valeur secrète n'est
jamais rendue : seulement « présente », « absente », ou son préfixe public.
"""
from django.urls import reverse
from django.utils.translation import gettext as _

#: Les événements que `StripeWebhookDispatcher` traite vraiment — à cocher
#: chez Stripe, et rien d'autre : un événement de plus n'est que du bruit
#: (journalisé « non traité »).
EVENEMENTS = (
    "payment_intent.succeeded",
    "payment_intent.payment_failed",
    "payment_intent.canceled",
    "charge.refunded",
    "checkout.session.completed",
    "customer.subscription.created",
    "customer.subscription.updated",
    "customer.subscription.deleted",
    "customer.subscription.paused",
    "customer.subscription.resumed",
    "invoice.paid",
    "invoice.payment_failed",
)

DOCUMENTATION = "https://jeiko.fr/documentation/stripe/"

#: STRIPE-02 — la version de l'API Stripe pour laquelle JEIKO est écrit,
#: posée sur chaque appel (`PaymentsConfig.ready`). Elle était implicite :
#: celle de la bibliothèque `stripe` installée, qu'un `pip install -U`
#: changeait sans que personne ne le décide. Un test refuse qu'elles
#: divergent : monter la bibliothèque oblige à relire ce que la nouvelle
#: version change, puis à monter cette constante.
#:
#: Ce qu'elle ne règle pas : les AVIS du webhook arrivent dans la version
#: choisie à la création du point de terminaison chez Stripe, pas dans
#: celle-ci. Le code les lit sous leurs deux formes là où Stripe a changé
#: la forme (shop/abonnements.py : `subscription` / `parent` d'une facture,
#: fin de période sur l'abonnement ou sur l'article) ; l'écran dit quelle
#: version le webhook envoie, pour qu'on l'aligne.
VERSION_DE_L_API = "2026-07-29.dahlia"


def adresse_du_webhook(request):
    return request.build_absolute_uri(reverse("jeiko_payments_client:stripe_webhook"))


def _mode_de_la_cle(cle, prefixes):
    """« test », « live », ou None si la clé n'a pas la forme attendue."""
    for prefixe in prefixes:
        for mode in ("test", "live"):
            if cle.startswith(f"{prefixe}_{mode}_"):
                return mode
    return None


def verifications(passerelle):
    """
    Liste de (etat, libelle, detail) : etat vaut "ok", "attention" ou "manque".
    Rien de secret dans le détail.
    """
    from django.utils import formats, timezone

    mode_attendu = "test" if passerelle.test_mode else "live"
    noms = {"test": _("test"), "live": _("réel")}
    nom_du_mode = noms[mode_attendu]
    lignes = []

    publique = (passerelle.api_key or "").strip()
    mode = _mode_de_la_cle(publique, ("pk",))
    if not publique:
        lignes.append(("manque", _("Clé publique"), _("Absente : copiez-la depuis Stripe › Développeurs › Clés API.")))
    elif mode is None:
        lignes.append(("manque", _("Clé publique"), _("Elle doit commencer par pk_test_ ou pk_live_.")))
    elif mode != mode_attendu:
        lignes.append(("attention", _("Clé publique"),
                       _("C'est une clé %(cle)s, alors que la passerelle est en mode %(mode)s.")
                       % {"cle": noms[mode], "mode": nom_du_mode}))
    else:
        lignes.append(("ok", _("Clé publique"), _("Présente, mode %(mode)s.") % {"mode": nom_du_mode}))

    secrete = (passerelle.secret_key or "").strip()
    mode = _mode_de_la_cle(secrete, ("sk", "rk"))
    if not secrete:
        lignes.append(("manque", _("Clé secrète"), _("Absente : copiez-la depuis Stripe › Développeurs › Clés API.")))
    elif mode is None:
        lignes.append(("manque", _("Clé secrète"), _("Elle doit commencer par sk_ ou rk_ (clé restreinte), suivi de test_ ou live_.")))
    elif mode != mode_attendu:
        lignes.append(("attention", _("Clé secrète"),
                       _("C'est une clé %(cle)s, alors que la passerelle est en mode %(mode)s.")
                       % {"cle": noms[mode], "mode": nom_du_mode}))
    else:
        lignes.append(("ok", _("Clé secrète"), _("Présente, mode %(mode)s.") % {"mode": nom_du_mode}))

    secret = (passerelle.webhook_secret or "").strip()
    if not secret:
        lignes.append(("manque", _("Secret du webhook"),
                       _("Absent : sans lui, le site refuse tous les avis de Stripe et aucune commande ne passe « payée ».")))
    elif not secret.startswith("whsec_"):
        lignes.append(("manque", _("Secret du webhook"), _("Il doit commencer par whsec_.")))
    else:
        lignes.append(("ok", _("Secret du webhook"), _("Présent.")))

    def quand(moment):
        return formats.date_format(timezone.localtime(moment), "DATETIME_FORMAT")

    recu, refuse = passerelle.dernier_evenement_le, passerelle.dernier_refus_le
    if refuse and (not recu or refuse > recu):
        lignes.append(("manque", _("Réception des avis de Stripe"),
                       _("Stripe appelle le site, mais la signature a été refusée le %(date)s : le secret du webhook "
                         "ne correspond pas à ce point de terminaison. Recopiez-le depuis sa page chez Stripe.")
                       % {"date": quand(refuse)}))
    elif recu:
        lignes.append(("ok", _("Réception des avis de Stripe"),
                       _("Dernier avis reçu le %(date)s (%(type)s).")
                       % {"date": quand(recu), "type": passerelle.dernier_evenement_type or "?"}))
    else:
        lignes.append(("attention", _("Réception des avis de Stripe"),
                       _("Aucun avis reçu pour l'instant. Après avoir déclaré le webhook, envoyez un événement "
                         "de test depuis sa page chez Stripe : il doit apparaître ici.")))

    version = passerelle.dernier_evenement_version
    if version and version != VERSION_DE_L_API:
        lignes.append(("attention", _("Version de l'API du webhook"),
                       _("Le webhook envoie ses avis en version %(recue)s ; JEIKO est écrit pour la %(attendue)s. "
                         "Ils sont lus quand même, mais créez chez Stripe un webhook en version %(attendue)s, "
                         "recopiez son secret ici, puis supprimez l'ancien.")
                       % {"recue": version, "attendue": VERSION_DE_L_API}))
    elif version:
        lignes.append(("ok", _("Version de l'API du webhook"), version))
    return lignes


def resume(passerelle):
    """Pour l'API : l'état, sans les libellés de l'écran."""
    etats = [etat for etat, _l, _d in verifications(passerelle)]
    return {
        "actif": passerelle.is_active,
        "mode_test": passerelle.test_mode,
        "branche": all(e == "ok" for e in etats),
        "dernier_evenement_le": passerelle.dernier_evenement_le,
        "dernier_evenement_type": passerelle.dernier_evenement_type,
        "dernier_refus_le": passerelle.dernier_refus_le,
        "evenements_a_cocher": list(EVENEMENTS),
        "version_api": VERSION_DE_L_API,
        "version_du_webhook": passerelle.dernier_evenement_version,
    }
