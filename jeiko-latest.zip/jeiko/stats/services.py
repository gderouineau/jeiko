# stats/services.py
from datetime import date, timedelta
from django.db.models import Count, Avg, Sum, Case, When, IntegerField
from .models import PageView

def _range(preset: str | None, start: date | None, end: date | None):
    if preset in {"1w", "1m", "3m"} and not (start and end):
        today = date.today()
        if preset == "1w":  start, end = today - timedelta(days=6), today
        if preset == "1m":  start, end = today - timedelta(days=29), today
        if preset == "3m":  start, end = today - timedelta(days=89), today
    if not (start and end):
        # défaut 1 mois
        today = date.today()
        start, end = today - timedelta(days=29), today
    return start, end

def qs_between(start: date, end: date):
    return PageView.objects.filter(day__gte=start, day__lte=end)

def summary(preset: str | None = None, start: date | None = None, end: date | None = None):
    start, end = _range(preset, start, end)
    qs = qs_between(start, end)
    totals = qs.aggregate(
        pageviews=Count("id"),
        visits=Sum(Case(When(is_entry=True, then=1), default=0, output_field=IntegerField())),
        avg_dwell_ms=Avg("dwell_ms"),
    )
    visits = totals["visits"] or 0
    pageviews = totals["pageviews"] or 0
    pages_per_visit = (pageviews / visits) if visits else None

    # Estimation “temps / visite” (approchée)
    avg_dwell_per_visit_ms = None
    if totals["avg_dwell_ms"] is not None and pages_per_visit:
        avg_dwell_per_visit_ms = float(totals["avg_dwell_ms"]) * pages_per_visit

    return {
        "start": start, "end": end,
        "pageviews": pageviews,
        "visits": visits,
        "pages_per_visit": pages_per_visit,
        "avg_dwell_ms": totals["avg_dwell_ms"],
        "avg_dwell_per_visit_ms": avg_dwell_per_visit_ms,
    }

def daily_series(start: date, end: date):
    qs = qs_between(start, end).values("day").annotate(
        pageviews=Count("id"),
        visits=Sum(Case(When(is_entry=True, then=1), default=0, output_field=IntegerField())),
        avg_dwell_ms=Avg("dwell_ms"),
    ).order_by("day")
    return list(qs)

def top_pages(start: date, end: date, limit: int = 20):
    qs = qs_between(start, end).values("path").annotate(
        pageviews=Count("id"),
        visits=Sum(Case(When(is_entry=True, then=1), default=0, output_field=IntegerField())),
        avg_dwell_ms=Avg("dwell_ms"),
    ).order_by("-pageviews")[:limit]
    return list(qs)

def referrers_for(path: str, start: date, end: date, limit: int = 20):
    qs = qs_between(start, end).filter(path=path).values("referrer_path").annotate(
        arrivals=Count("id"),
        avg_dwell_ms=Avg("dwell_ms"),
    ).order_by("-arrivals")[:limit]
    return list(qs)
