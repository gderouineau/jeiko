# stats/models.py
import uuid
from django.db import models

class PageView(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    path = models.CharField(max_length=512, db_index=True)
    referrer_path = models.CharField(max_length=512, blank=True, null=True, db_index=True)

    day = models.DateField(db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    status_code = models.PositiveSmallIntegerField(default=200, db_index=True)
    is_internal_referrer = models.BooleanField(default=False, db_index=True)
    # is_entry = pas de ref interne => probable début de visite (approx)
    is_entry = models.BooleanField(default=False, db_index=True)

    is_authenticated = models.BooleanField(default=False, db_index=True)
    is_bot = models.BooleanField(default=False, db_index=True)

    content_length = models.PositiveIntegerField(null=True, blank=True)
    dwell_ms = models.PositiveIntegerField(null=True, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["day", "path"]),
            models.Index(fields=["day", "referrer_path"]),
        ]

    def __str__(self):
        ref = self.referrer_path or "-"
        return f"{self.created_at:%Y-%m-%d %H:%M:%S} {self.path} ← {ref} [{self.status_code}]"
