# stats/urls/client.py
from django.urls import path
from ..views.client import track_exit

urlpatterns = [
    path("track-exit/", track_exit, name="stats_track_exit"),
]
