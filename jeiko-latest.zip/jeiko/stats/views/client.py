# stats/views.py
import json, uuid
from django.http import JsonResponse, HttpResponseNotAllowed
from django.views.decorators.csrf import csrf_exempt
from ..models import PageView

@csrf_exempt
def track_exit(request):
    if request.method != "POST":
        return HttpResponseNotAllowed(["POST"])
    try:
        data = json.loads(request.body.decode("utf-8") or "{}")
        pid = uuid.UUID(str(data.get("id", "")))
        dwell = int(data.get("d", 0))
        if dwell < 0: dwell = 0
        if dwell > 45 * 60 * 1000: dwell = 45 * 60 * 1000  # clamp 45 min
        ok = PageView.objects.filter(pk=pid, dwell_ms__isnull=True).update(dwell_ms=dwell)
        return JsonResponse({"ok": bool(ok)})
    except Exception:
        return JsonResponse({"ok": False}, status=400)
