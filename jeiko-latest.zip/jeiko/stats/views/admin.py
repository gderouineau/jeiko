# jeiko/stats/views/admin.py
from __future__ import annotations

import json
from datetime import datetime, date
from typing import Optional, Tuple, List, Dict, Any

from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Count, Avg, Sum, Case, When, IntegerField, QuerySet
from django.http import HttpRequest, HttpResponse, HttpResponseBadRequest
from django.shortcuts import render

from jeiko.stats.models import PageView
from jeiko.stats import services


# -----------------------
# Helpers
# -----------------------

def _parse_date(s: Optional[str]) -> Optional[date]:
    if not s:
        return None
    return datetime.strptime(s, "%Y-%m-%d").date()


def _range_from_request(request: HttpRequest) -> Tuple[date, date, str | None]:
    """
    Lit preset/start/end de la querystring et renvoie (start, end, preset_effectif).
    On s’appuie sur services.summary() pour obtenir les bornes retenues.
    """
    preset = request.GET.get("preset") or None  # "1w" | "1m" | "3m" | None
    start = _parse_date(request.GET.get("start"))
    end = _parse_date(request.GET.get("end"))

    k = services.summary(preset, start, end)
    return k["start"], k["end"], preset


def _series_json(items: List[Dict[str, Any]]) -> str:
    """
    Convertit la liste issue de services.daily_series (avec 'day' = date)
    en JSON sérialisable côté JS (day -> string ISO).
    """
    serializable = []
    for row in items:
        serializable.append({
            "day": row["day"].isoformat() if hasattr(row["day"], "isoformat") else row["day"],
            "pageviews": row.get("pageviews", 0),
            "visits": row.get("visits", 0),
            "avg_dwell_ms": float(row["avg_dwell_ms"]) if row.get("avg_dwell_ms") is not None else None,
        })
    return json.dumps(serializable)


# -----------------------
# Views (admin)
# -----------------------

@staff_member_required
def overview(request: HttpRequest) -> HttpResponse:
    """
    Dashboard principal : KPIs, série quotidienne, top pages.
    Template: templates/stats/admin/overview.html
    URL name: jeiko_administration_stats:stats_overview
    """
    start, end, preset = _range_from_request(request)

    kpis = services.summary(preset=None, start=start, end=end)
    series = services.daily_series(start, end)
    pages = services.top_pages(start, end, limit=20)

    ctx = {
        "preset": request.GET.get("preset") or "",
        "kpis": kpis,
        "series": _series_json(series),
        "pages": pages,
    }
    return render(request, "stats/admin/overview.html", ctx)


@staff_member_required
def pages(request: HttpRequest) -> HttpResponse:
    """
    Liste agrégée des pages (filtrable par période + recherche 'q').
    Template: templates/stats/admin/pages.html
    URL name: jeiko_administration_stats:stats_pages
    """
    start, end, preset = _range_from_request(request)
    q = (request.GET.get("q") or "").strip()

    qs: QuerySet[PageView] = services.qs_between(start, end)
    if q:
        qs = qs.filter(path__icontains=q)

    agg = (
        qs.values("path")
          .annotate(
              pageviews=Count("id"),
              visits=Sum(Case(When(is_entry=True, then=1), default=0, output_field=IntegerField())),
              avg_dwell_ms=Avg("dwell_ms"),
          )
          .order_by("-pageviews")
    )

    ctx = {
        "preset": preset or "",
        "start": start,
        "end": end,
        "q": q,
        "pages": list(agg),
    }
    return render(request, "stats/admin/pages.html", ctx)


@staff_member_required
def page_detail(request: HttpRequest) -> HttpResponse:
    """
    Détail d’une page : KPIs, série quotidienne, referrers internes.
    Template: templates/stats/admin/page_detail.html
    URL name: jeiko_administration_stats:stats_page_detail
    """
    path = request.GET.get("path")
    if not path:
        return HttpResponseBadRequest("Paramètre 'path' requis.")

    start, end, preset = _range_from_request(request)
    base_qs = services.qs_between(start, end).filter(path=path)

    # KPIs pour la page
    pageviews = base_qs.count()
    visits = base_qs.filter(is_entry=True).count()
    avg_dwell_ms = base_qs.aggregate(Avg("dwell_ms"))["dwell_ms__avg"]
    pages_per_visit = (pageviews / visits) if visits else None

    kpis = {
        "start": start,
        "end": end,
        "pageviews": pageviews,
        "visits": visits,
        "avg_dwell_ms": avg_dwell_ms,
        "pages_per_visit": pages_per_visit,
    }

    # Série quotidienne pour cette page
    series = (
        base_qs.values("day")
               .annotate(
                   pageviews=Count("id"),
                   visits=Sum(Case(When(is_entry=True, then=1), default=0, output_field=IntegerField())),
                   avg_dwell_ms=Avg("dwell_ms"),
               )
               .order_by("day")
    )

    # D’où viennent-ils ? (référents internes)
    referrers = services.referrers_for(path, start, end, limit=50)

    ctx = {
        "preset": preset or "",
        "path": path,
        "start": start,
        "end": end,
        "kpis": kpis,
        "series": _series_json(list(series)),
        "referrers": referrers,
    }
    return render(request, "stats/admin/page_detail.html", ctx)
