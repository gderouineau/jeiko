# stats/middleware.py
import re
from urllib.parse import urlparse
from django.conf import settings
from django.utils import timezone
from django.urls import reverse, NoReverseMatch
from .models import PageView

BOT_RE = re.compile(r"(bot|crawler|spider|slurp|uptime|monitor|pingdom|crawl)", re.I)

def _is_probably_bot(user_agent: str) -> bool:
    if not user_agent:
        return False
    return bool(BOT_RE.search(user_agent))

def _safe_int(v):
    try:
        return int(v)
    except Exception:
        return None

def _path_is_ignored(path: str) -> bool:
    prefixes = getattr(settings, "STATS_IGNORE_PATH_PREFIXES", [])
    if not prefixes:
        return False
    for p in prefixes:
        if path.startswith(p):
            return True
    return False

def _canon_host(h: str | None) -> str:
    if not h:
        return ""
    h = h.split(":")[0].strip().lower()
    if h.startswith("www."):
        h = h[4:]
    return h

def _is_internal_by_host(request, ref_netloc: str | None) -> bool:
    """
    True si le référent est considéré interne :
    - netloc vide (certains navigateurs) → interne
    - même host (normalisé, sans www)
    - présent dans STATS_INTERNAL_HOSTS
    """
    if not ref_netloc:
        return True
    cur = _canon_host(request.get_host())
    ref = _canon_host(ref_netloc)
    if cur and ref == cur:
        return True
    extra = getattr(settings, "STATS_INTERNAL_HOSTS", [])
    extra_norm = {_canon_host(x) for x in extra if x}
    return ref in extra_norm

def _beacon_url() -> str:
    """
    Essaie de résoudre l'URL par son nom; sinon utilise le paramètre
    STATS_TRACK_EXIT_URL; enfin fallback en dur.
    """
    try:
        return reverse("stats_track_exit")
    except NoReverseMatch:
        return getattr(settings, "STATS_TRACK_EXIT_URL", "/stats/track-exit/")

def _try_inject_beacon_script(response, pageview_id: str):
    try:
        if getattr(response, "streaming", False):
            return
        content = response.content
        if not isinstance(content, (bytes, bytearray)):
            return
        body_close = b"</body>"
        idx = content.lower().rfind(body_close)
        if idx == -1:
            return

        beacon = _beacon_url()
        snippet = f"""
<script>
(function(){{try{{
    var start = performance.now(), sent=false;
    function send(ms){{
        if(sent) return; sent=true;
        var data = JSON.stringify({{id:"{pageview_id}", d: Math.round(ms)}});
        navigator.sendBeacon("{beacon}", new Blob([data], {{type:"application/json"}}));
    }}
    function handler(){{ send(performance.now()-start); }}
    document.addEventListener("visibilitychange", function(){{ if(document.visibilityState==="hidden"){{ handler(); }} }});
    window.addEventListener("pagehide", handler);
}}catch(e){{}}}})();
</script>
""".encode("utf-8")
        response.content = content[:idx] + snippet + content[idx:]
        # Si tu définis strictement Content-Length côté serveur, recalculer :
        # response["Content-Length"] = str(len(response.content))
    except Exception:
        pass

class PageViewCounterMiddleware:
    """
    - Compte seulement GET 200 text/html
    - Ignore bots, superusers, staff
    - Ignore /admin/ (configurable) et une liste de préfixes via STATS_IGNORE_PATH_PREFIXES
    - Détermine correctement si la vue est une entrée (pas de référent interne)
    - Injecte un beacon 'dwell_ms' (désactivable)
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        try:
            # Uniquement pertinent pour des pages HTML complètes
            if request.method != "GET":
                return response

            user = getattr(request, "user", None)
            if user and getattr(user, "is_authenticated", False) and (user.is_staff or user.is_superuser):
                return response

            path = request.path or "/"

            admin_url = getattr(settings, "ADMIN_URL", "/admin/")
            if path.startswith(admin_url):
                return response

            if _path_is_ignored(path):
                return response

            status = getattr(response, "status_code", 0) or 0
            if status != 200:
                return response

            ct = response.get("Content-Type", "")
            if not ct.startswith("text/html"):
                return response

            ua = request.META.get("HTTP_USER_AGENT", "")
            if _is_probably_bot(ua):
                return response

            # Référent (interne uniquement, sans query/fragment)
            ref_raw = request.META.get("HTTP_REFERER", "")
            referrer_path = None
            is_internal_referrer = False
            if ref_raw:
                p = urlparse(ref_raw)
                if _is_internal_by_host(request, p.netloc):
                    is_internal_referrer = True
                    referrer_path = p.path or "/"

            pv = PageView.objects.create(
                path=path,
                referrer_path=referrer_path,
                day=timezone.localdate(),
                status_code=status,
                is_internal_referrer=is_internal_referrer,
                is_entry=(not is_internal_referrer),
                is_authenticated=bool(user and getattr(user, "is_authenticated", False)),
                is_bot=False,
                content_length=_safe_int(response.get("Content-Length")),
            )

            if getattr(settings, "STATS_ENABLE_DWELL", True):
                _try_inject_beacon_script(response, str(pv.id))

        except Exception:
            # Ne jamais bloquer la réponse pour des stats
            pass

        return response
