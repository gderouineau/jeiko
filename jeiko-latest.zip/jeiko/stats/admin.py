# en haut du fichier
import re, unicodedata
from datetime import datetime, date

MONTHS_FR = {
    "janvier": 1, "fevrier": 2, "février": 2, "mars": 3, "avril": 4, "mai": 5,
    "juin": 6, "juillet": 7, "aout": 8, "août": 8, "septembre": 9, "octobre": 10,
    "novembre": 11, "decembre": 12, "décembre": 12,
}

def _strip_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))

def _parse_date(s: str | None) -> date | None:
    if not s:
        return None
    s = s.strip()

    # 1) ISO direct
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass

    # 2) Français : "19 octobre 2025" (accents acceptés)
    m = re.match(r"^\s*(\d{1,2})\s+([A-Za-zéèêëàâîïôöûüç\-]+)\s+(\d{4})\s*$", s, re.I)
    if m:
        d = int(m.group(1))
        month_raw = _strip_accents(m.group(2).lower())
        y = int(m.group(3))
        month = MONTHS_FR.get(month_raw)
        if month:
            return date(y, month, d)

    # 3) Tout le reste = invalide
    raise ValueError(f"Unsupported date format: {s!r}")

def _parse_date_safe(s: str | None) -> date | None:
    try:
        return _parse_date(s)
    except Exception:
        return None

def _range_from_request(request):
    preset = request.GET.get("preset") or None  # "1w" | "1m" | "3m" | None
    start = _parse_date_safe(request.GET.get("start"))
    end = _parse_date_safe(request.GET.get("end"))
    k = services.summary(preset, start, end)  # services._range décidera au besoin
    return k["start"], k["end"], preset
