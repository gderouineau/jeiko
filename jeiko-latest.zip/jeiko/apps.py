from django.apps import AppConfig


class AdministrationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko'
    label = "jeiko"

    def ready(self):
        # Contrôle d'installation complète : JEIKO s'installe entier ou pas du
        # tout (cf. jeiko/checks.py et ARCHITECTURE.md).
        from . import checks  # noqa: F401

        # Plafond de Pillow abaissé à 25 Mpx (S-10). Posé ici, à un moment
        # connu : c'est une variable globale de la bibliothèque, la laisser
        # dépendre de l'ordre des imports reviendrait à ne pas savoir si elle
        # est en vigueur. Voir jeiko/uploads.py.
        from .uploads import appliquer_les_limites_pillow

        appliquer_les_limites_pillow()

        # L'admin Django (/admin/) avait SA page de connexion : mot de passe
        # seul, hors du parcours allauth — ni double authentification, ni
        # plafond de tentatives (audit du 11/10/2026, S02). Elle renvoie
        # désormais vers la connexion du site, qui applique tout. Posé ici et
        # non dans le gabarit urls.py : un site protégé dès la mise à jour du
        # paquet, même si son urls.py n'a pas encore été réaligné.
        from allauth.account.decorators import secure_admin_login
        from django.contrib import admin

        admin.site.login = secure_admin_login(admin.site.login)
