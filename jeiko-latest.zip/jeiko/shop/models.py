from __future__ import annotations

from decimal import Decimal

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone

User = get_user_model()


class ProductType(models.Model):
    """
    Type métier du produit (couche "conceptuelle") :
    - produit_physique
    - formation_en_ligne
    - seance_1to1
    - abonnement
    etc.

    Chaque ProductType pointe vers un CustomObjectModel qui gère la fiche
    (contenu + template) côté "administration_pages".
    """

    name = models.CharField(
        max_length=150,
        verbose_name="Nom du type de produit",
    )
    code = models.SlugField(
        max_length=100,
        unique=True,
        verbose_name="Code interne",
        help_text="Identifiant technique (ex : produit_physique, formation, seance…).",
    )

    content_model = models.ForeignKey(
        "custom_objects.CustomObjectModel",
        on_delete=models.PROTECT,
        related_name="product_types",
        verbose_name="Modèle de contenu",
        null=True,
        blank=True,
        help_text=(
            "Modèle de contenu (CustomObjectModel) utilisé pour les fiches "
            "de ce type de produit."
        ),
    )

    # Flags fonctionnels
    KIND_PHYSICAL = "physical"
    KIND_COURSE = "course"
    KIND_QUESTIONNAIRE = "questionnaire"
    KIND_APPOINTMENT = "appointment"
    KIND_SERVICE = "service"

    KIND_CHOICES = (
        (KIND_PHYSICAL, "Produit physique"),
        (KIND_COURSE, "Formation en ligne"),
        (KIND_QUESTIONNAIRE, "Questionnaire expert"),
        (KIND_APPOINTMENT, "Rendez-vous / Crédits"),
        (KIND_SERVICE, "Service"),
    )

    kind = models.CharField(
        max_length=20,
        choices=KIND_CHOICES,
        default=KIND_PHYSICAL,
        verbose_name="Nature du produit",
    )

    is_physical = models.BooleanField(
        default=True,
        verbose_name="Produit physique (legacy)",
        help_text="Si coché, le produit nécessite une gestion de stock et de livraison.",
    )
    requires_shipping = models.BooleanField(
        default=True,
        verbose_name="Nécessite une expédition",
        help_text="Ex : colis, lettre. Décoche pour les produits 100 % digitaux.",
    )
    is_subscription = models.BooleanField(
        default=False,
        verbose_name="Abonnement",
        help_text="Produit facturé de manière récurrente.",
    )

    # TVA par défaut (en %)
    default_tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("20.00"),
        verbose_name="TVA par défaut (%)",
    )

    default_currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name="Devise par défaut",
        help_text="Code ISO (ex : EUR, USD).",
    )

    date_created = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Date de création",
    )

    class Meta:
        verbose_name = "Type de produit"
        verbose_name_plural = "Types de produit"
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name


class Product(models.Model):
    """
    Produit vendable (couche e-commerce).
    Il est relié :
      - à un ProductType (logique métier),
      - à un CustomObject (contenu + template).
    """

    type = models.ForeignKey(
        ProductType,
        on_delete=models.PROTECT,
        related_name="products",
        verbose_name="Type de produit",
    )

    content = models.OneToOneField(
        "custom_objects.CustomObject",
        on_delete=models.PROTECT,
        related_name="product",
        verbose_name="Fiche contenu",
        help_text="Objet custom (CustomObject) qui porte la fiche produit et le template.",
    )

    sku = models.CharField(
        max_length=64,
        unique=True,
        verbose_name="Référence (SKU)",
        help_text="Identifiant unique du produit (SKU).",
    )

    is_active = models.BooleanField(
        default=True,
        verbose_name="Actif (vendable)",
    )

    # Prix
    price_ht = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Prix HT",
    )
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal("20.00"),
        verbose_name="TVA (%)",
        help_text="Laisse vide pour utiliser la TVA du type (si tu gères ce comportement plus tard).",
    )
    currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name="Devise",
        help_text="Code ISO (ex : EUR, USD).",
    )

    # Stock (simple)
    stock_quantity = models.IntegerField(
        default=0,
        verbose_name="Quantité en stock",
    )
    allow_negative_stock = models.BooleanField(
        default=False,
        verbose_name="Autoriser le stock négatif",
    )

    # Logistique
    weight_kg = models.DecimalField(
        max_digits=7,
        decimal_places=3,
        default=Decimal("0.000"),
        verbose_name="Poids (kg)",
    )

    # Liens spécifiques (selon le kind)
    linked_expert_test = models.ForeignKey(
        "questionnaires_expert.ExpertTest",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Questionnaire lié",
        help_text="Si ce produit vend l'accès à un questionnaire.",
    )
    linked_appointment_type = models.ForeignKey(
        "calendars.AppointmentType",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Type de RDV lié",
        help_text="Si ce produit vend des crédits pour un type de RDV.",
    )
    credits_amount = models.IntegerField(
        default=0,
        verbose_name="Crédits offerts",
        help_text="Nombre de crédits/RDV crédités à l'achat.",
    )
    linked_course = models.ForeignKey(
        "courses.Course",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="products",
        verbose_name="Formation liée",
        help_text="Si ce produit donne accès à une formation en ligne.",
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Créé le",
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Mis à jour le",
    )

    class Meta:
        verbose_name = "Produit"
        verbose_name_plural = "Produits"
        ordering = ["sku"]

    def __str__(self) -> str:
        # content.title vient du CustomObject
        return f"{self.sku} – {self.content.title}"

    def clean(self):
        """
        Sécurité : on impose que le CustomObject utilise bien le CustomObjectModel
        attendu par le ProductType.
        """
        if self.content_id and self.type_id:
            if self.content.model_id != self.type.content_model_id:
                raise ValidationError(
                    {
                        "content": (
                            "Cet objet n'utilise pas le modèle de contenu attendu "
                            "pour ce type de produit."
                        )
                    }
                )

    @property
    def price_ttc(self) -> Decimal:
        return self.price_ht * (Decimal("1.0") + self.tax_rate / Decimal("100.0"))


class ProductImage(models.Model):
    """
    Images liées à un produit.
    On réutilise ton ImageContent de l'app administration_pages.
    """

    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name="images",
        verbose_name="Produit",
    )
    image = models.ForeignKey(
        "administration_pages.ImageContent",
        on_delete=models.PROTECT,
        related_name="product_images",
        verbose_name="Image",
    )
    is_main = models.BooleanField(
        default=False,
        verbose_name="Image principale",
    )
    position = models.PositiveIntegerField(
        default=0,
        verbose_name="Ordre d'affichage",
    )

    class Meta:
        verbose_name = "Image de produit"
        verbose_name_plural = "Images de produit"
        ordering = ["product", "position", "id"]

    def __str__(self) -> str:
        return f"Image {self.product.sku} (pos={self.position})"


class ProductStockMovement(models.Model):
    """
    Historique des mouvements de stock (optionnel mais pratique).
    Ex :
      - commande -1
      - correction inventaire +10
      - retour client +1
    """

    IN = "IN"
    OUT = "OUT"
    MOVEMENT_TYPES = [
        (IN, "Entrée"),
        (OUT, "Sortie"),
    ]

    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name="stock_movements",
        verbose_name="Produit",
    )
    movement_type = models.CharField(
        max_length=3,
        choices=MOVEMENT_TYPES,
        verbose_name="Type de mouvement",
    )
    quantity = models.IntegerField(
        verbose_name="Quantité",
        help_text="Positive ou négative selon ton usage, mais le type IN/OUT est là pour clarifier.",
    )
    reason = models.CharField(
        max_length=255,
        blank=True,
        verbose_name="Raison",
        help_text="Ex : commande #123, ajustement, retour, etc.",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Date du mouvement",
    )
    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="stock_movements",
        verbose_name="Utilisateur",
    )

    class Meta:
        verbose_name = "Mouvement de stock"
        verbose_name_plural = "Mouvements de stock"
        ordering = ["-created_at", "-id"]

    def __str__(self) -> str:
        return f"{self.product.sku} – {self.movement_type} {self.quantity}"


# ----------------------------------------------------------------------
#  Panier (Cart) + Commandes (Order)
#  La partie paiement ira dans l'app "payments" (FK depuis Order).
# ----------------------------------------------------------------------


class Cart(models.Model):
    """
    Panier simple :
    - lié éventuellement à un user,
    - ou à une session (anonyme).
    """

    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="carts",
        verbose_name="Utilisateur",
    )
    session_key = models.CharField(
        max_length=40,
        blank=True,
        db_index=True,
        verbose_name="Session",
        help_text="Clé de session pour les paniers anonymes.",
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Créé le",
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Mis à jour le",
    )

    is_locked = models.BooleanField(
        default=False,
        verbose_name="Verrouillé",
        help_text="Un panier verrouillé ne peut plus être modifié (ex : transformé en commande).",
    )

    class Meta:
        verbose_name = "Panier"
        verbose_name_plural = "Paniers"
        ordering = ["-updated_at", "-id"]

    def __str__(self) -> str:
        if self.user:
            return f"Panier #{self.pk} – {self.user}"
        return f"Panier #{self.pk} (session={self.session_key})"


class CartItem(models.Model):
    """
    Ligne de panier.
    On snapshot le prix au moment où on ajoute l'article.
    """

    cart = models.ForeignKey(
        Cart,
        on_delete=models.CASCADE,
        related_name="items",
        verbose_name="Panier",
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name="cart_items",
        verbose_name="Produit",
    )
    quantity = models.PositiveIntegerField(
        default=1,
        verbose_name="Quantité",
    )

    unit_price_ht = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Prix unitaire HT (snapshot)",
    )
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        verbose_name="TVA (%)",
    )
    currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name="Devise",
    )

    class Meta:
        verbose_name = "Ligne de panier"
        verbose_name_plural = "Lignes de panier"

    def __str__(self) -> str:
        return f"{self.product.sku} x {self.quantity} (panier #{self.cart_id})"

    @property
    def total_ht(self) -> Decimal:
        return self.unit_price_ht * self.quantity

    @property
    def total_ttc(self) -> Decimal:
        return self.total_ht * (Decimal("1.0") + self.tax_rate / Decimal("100.0"))


class Order(models.Model):
    """
    Commande client.
    La relation avec les paiements (Stripe, etc.) se fera dans l'app payments.
    """

    ORDER_STATUS_DRAFT = "draft"
    ORDER_STATUS_CONFIRMED = "confirmed"
    ORDER_STATUS_PROCESSING = "processing"
    ORDER_STATUS_SHIPPED = "shipped"
    ORDER_STATUS_COMPLETED = "completed"
    ORDER_STATUS_CANCELLED = "cancelled"

    ORDER_STATUS_CHOICES = [
        (ORDER_STATUS_DRAFT, "Brouillon"),
        (ORDER_STATUS_CONFIRMED, "Confirmée"),
        (ORDER_STATUS_PROCESSING, "En cours de traitement"),
        (ORDER_STATUS_SHIPPED, "Expédiée"),
        (ORDER_STATUS_COMPLETED, "Terminée"),
        (ORDER_STATUS_CANCELLED, "Annulée"),
    ]

    PAYMENT_STATUS_PENDING = "pending"
    PAYMENT_STATUS_PAID = "paid"
    PAYMENT_STATUS_FAILED = "failed"
    PAYMENT_STATUS_REFUNDED = "refunded"

    PAYMENT_STATUS_CHOICES = [
        (PAYMENT_STATUS_PENDING, "En attente"),
        (PAYMENT_STATUS_PAID, "Payée"),
        (PAYMENT_STATUS_FAILED, "Échouée"),
        (PAYMENT_STATUS_REFUNDED, "Remboursée"),
    ]

    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="orders",
        verbose_name="Utilisateur",
    )

    cart = models.OneToOneField(
        Cart,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="order",
        verbose_name="Panier source",
        help_text="Panier dont est issue cette commande (pour debug / tracking).",
    )

    order_status = models.CharField(
        max_length=20,
        choices=ORDER_STATUS_CHOICES,
        default=ORDER_STATUS_DRAFT,
        verbose_name="Statut Commande",
    )
    
    payment_status = models.CharField(
        max_length=20,
        choices=PAYMENT_STATUS_CHOICES,
        default=PAYMENT_STATUS_PENDING,
        verbose_name="Statut Paiement",
    )

    # Totaux snapshot
    currency = models.CharField(
        max_length=3,
        default="EUR",
        verbose_name="Devise",
    )
    total_ht = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name="Total HT",
    )
    total_tva = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name="Total TVA",
    )
    total_ttc = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name="Total TTC",
    )

    # Coordonnées (V1 : inline, on factorisera plus tard si besoin)
    billing_name = models.CharField(max_length=200, blank=True)
    billing_address = models.TextField(blank=True)
    shipping_name = models.CharField(max_length=200, blank=True)
    shipping_address = models.TextField(blank=True)

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Créée le",
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Mise à jour le",
    )

    class Meta:
        verbose_name = "Commande"
        verbose_name_plural = "Commandes"
        ordering = ["-created_at", "-id"]

    def __str__(self) -> str:
        return f"Commande #{self.pk} – {self.order_status} / {self.payment_status}"


class OrderLine(models.Model):
    """
    Ligne de commande (snapshot du produit et du prix au moment de la commande).
    """

    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE,
        related_name="lines",
    )

    product = models.ForeignKey(
        Product,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="order_lines",
        help_text="Produit d'origine (peut être supprimé plus tard).",
    )

    label = models.CharField(
        max_length=255,
        verbose_name="Description",
        help_text="Texte affiché pour cette ligne (titre produit, options, etc.).",
    )
    sku = models.CharField(
        max_length=64,
        blank=True,
        verbose_name="SKU (snapshot)",
    )

    quantity = models.PositiveIntegerField(
        default=1,
        verbose_name="Quantité",
    )

    unit_price_ht = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        verbose_name="Prix unitaire HT",
    )
    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        verbose_name="TVA (%)",
    )

    class Meta:
        verbose_name = "Ligne de commande"
        verbose_name_plural = "Lignes de commande"

    def __str__(self) -> str:
        return f"Commande #{self.order_id} – {self.label} x {self.quantity}"

    @property
    def total_ht(self) -> Decimal:
        return self.unit_price_ht * self.quantity

    @property
    def total_ttc(self) -> Decimal:
        return self.total_ht * (Decimal("1.0") + self.tax_rate / Decimal("100.0"))
