# shop/utils.py

from django.utils import timezone

from .models import Cart


def get_or_create_cart(request):
    """
    Récupère ou crée un panier en fonction :
      - de l'utilisateur connecté, OU
      - de la session (anonyme).
    """
    user = request.user if request.user.is_authenticated else None

    # 1) Si user connecté : on associe au user
    if user:
        cart, created = Cart.objects.get_or_create(
            user=user,
            is_locked=False,
            defaults={"created_at": timezone.now()},
        )
        return cart

    # 2) Sinon : on utilise la session pour identifier le panier
    session_key = request.session.session_key
    if not session_key:
        request.session.save()
        session_key = request.session.session_key

    cart, created = Cart.objects.get_or_create(
        session_key=session_key,
        is_locked=False,
        defaults={"created_at": timezone.now()},
    )
    return cart
