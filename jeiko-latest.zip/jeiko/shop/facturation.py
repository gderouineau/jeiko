"""
Factures et avoirs : ventiler la TVA, numéroter, sans trou.

Pourquoi ici et pas dans la vue de la facture
---------------------------------------------
Une facture française porte un numéro unique, attribué dans un ordre
chronologique continu — un trou ou un doublon se remarque en contrôle fiscal.
Le numéro se prend donc au RÈGLEMENT, dans la transaction de
`mark_order_paid`, sous verrou de la ligne des réglages : deux paiements
simultanés ne peuvent pas recevoir le même. Une commande jamais payée n'en
consomme aucun.

Un remboursement après facture ne modifie pas la facture : il fait l'objet
d'un AVOIR, numéroté de la même façon (`numeroter_avoir`).

La ventilation de la TVA par taux est calculée à la préparation de la
commande (`ventiler`), quand on sait encore quelles lignes la remise concerne
et lesquelles sont expédiées.

La facture et l'avoir sont UN gabarit (`shop/invoice.html`), servi en page
imprimable, en PDF à télécharger, et joint en PDF à l'e-mail de règlement
(`piece_jointe_facture`, moteur `jeiko.pdf.moteur`). Le contexte se construit ici, une fois,
pour que les trois ne puissent pas diverger.
"""

from decimal import Decimal

from django.db import transaction
from django.utils import timezone
from django.utils.translation import gettext as _

from .models import ShopSettings, _montant

CENT = Decimal("0.01")


def ventiler(lignes, remise_par_ligne, port_ttc, expediees, taux_par_defaut):
    """
    `{taux: {"ht", "tva", "ttc"}}` en Decimal, dont les TTC somment exactement
    au total à payer.

    * `remise_par_ligne` : {id de ligne: TTC retiré} ;
    * le port se répartit sur les lignes expédiées au prorata de leur TTC —
      la règle de l'accessoire — ou sur le taux par défaut à défaut.
    """
    ttc_par_taux = {}

    def ajouter(taux, montant):
        cle = Decimal(taux).quantize(CENT)
        ttc_par_taux[cle] = ttc_par_taux.get(cle, Decimal("0")) + montant

    for l in lignes:
        ajouter(l.tax_rate, l.total_ttc - remise_par_ligne.get(l.pk, Decimal("0")))

    if port_ttc:
        base = sum((l.total_ttc for l in expediees), Decimal("0"))
        if base:
            for l in expediees:
                ajouter(l.tax_rate, port_ttc * l.total_ttc / base)
        else:
            ajouter(taux_par_defaut, port_ttc)

    total = _montant(sum(ttc_par_taux.values(), Decimal("0")))
    resultat = {taux: _montant(v) for taux, v in ttc_par_taux.items() if v}
    # Les arrondis par taux ne doivent pas déplacer le total d'un centime :
    # l'écart va au taux le plus lourd.
    if resultat:
        ecart = total - sum(resultat.values(), Decimal("0"))
        if ecart:
            lourd = max(resultat, key=resultat.get)
            resultat[lourd] += ecart
    return {
        taux: {"ttc": ttc, "ht": _montant(ttc / (1 + taux / 100)),
               "tva": ttc - _montant(ttc / (1 + taux / 100))}
        for taux, ttc in sorted(resultat.items())
    }


def en_json(ventilation):
    return {str(t): {k: str(v) for k, v in m.items()} for t, m in ventilation.items()}


def ventilation_de(order):
    """La ventilation d'une commande, en Decimal ; reconstituée pour une commande antérieure."""
    if order.vat_breakdown:
        return {
            Decimal(t): {k: Decimal(v) for k, v in m.items()}
            for t, m in order.vat_breakdown.items()
        }
    # Commande antérieure à la ventilation : ses lignes seules.
    lignes = list(order.lines.all())
    return ventiler(lignes, {}, order.shipping_ttc, [], ShopSettings.get_solo().default_tax_rate)


def ventilation_avoir(refund):
    """La TVA d'un avoir : celle de la facture, au prorata du montant remboursé."""
    order = refund.order
    if not order.total_ttc:
        return {}
    part = Decimal(refund.amount) / order.total_ttc
    lignes = {}
    for taux, m in ventilation_de(order).items():
        ttc = _montant(m["ttc"] * part)
        if ttc:
            ht = _montant(ttc / (1 + taux / 100))
            lignes[taux] = {"ttc": ttc, "ht": ht, "tva": ttc - ht}
    if lignes:
        ecart = _montant(refund.amount) - sum((m["ttc"] for m in lignes.values()), Decimal("0"))
        if ecart:
            lourd = max(lignes, key=lambda t: lignes[t]["ttc"])
            lignes[lourd]["ttc"] += ecart
            lignes[lourd]["tva"] = lignes[lourd]["ttc"] - lignes[lourd]["ht"]
    return lignes


def partie_date(reglages, jour):
    """Ce que le numéro dit de sa période : 2026, 202610 ou 2026T4."""
    if reglages.numbering_period == ShopSettings.PERIODE_MOIS:
        return f"{jour.year}{jour.month:02d}"
    if reglages.numbering_period == ShopSettings.PERIODE_TRIMESTRE:
        return f"{jour.year}T{(jour.month - 1) // 3 + 1}"
    return str(jour.year)


def formater(reglages, prefixe, periode, valeur):
    chiffres = min(max(int(reglages.counter_digits or 5), 3), 8)
    return f"{prefixe}{periode}{reglages.number_separator or ''}{valeur:0{chiffres}d}"


def _prochain(nature, prefixe):
    """
    Le numéro suivant de cette nature, sous verrou. À appeler dans une
    transaction : le verrou sur la ligne des réglages sérialise deux
    attributions simultanées, y compris à la création du compteur d'une
    période neuve.
    """
    from .models import CompteurDeNumeros

    ShopSettings.get_solo()
    reglages = ShopSettings.objects.select_for_update().get(pk=1)
    periode = partie_date(reglages, timezone.localdate())
    compteur, __ = CompteurDeNumeros.objects.get_or_create(nature=nature, periode=periode)
    compteur.valeur += 1
    compteur.save(update_fields=["valeur"])
    return formater(reglages, prefixe, periode, compteur.valeur)


def apercu(reglages, nature, prefixe):
    """Le prochain numéro de cette nature, sans le prendre : pour l'écran de réglages."""
    from .models import CompteurDeNumeros

    periode = partie_date(reglages, timezone.localdate())
    dernier = CompteurDeNumeros.objects.filter(nature=nature, periode=periode).first()
    return formater(reglages, prefixe, periode, (dernier.valeur if dernier else 0) + 1)


@transaction.atomic
def numeroter_facture(order):
    """Attribue le numéro de facture d'une commande réglée. Idempotent."""
    if order.invoice_number:
        return order.invoice_number
    order.invoice_number = _prochain("facture", ShopSettings.get_solo().invoice_prefix)
    order.invoiced_at = timezone.now()
    order.save(update_fields=["invoice_number", "invoiced_at"])
    return order.invoice_number


@transaction.atomic
def numeroter_avoir(refund):
    """Attribue son numéro à l'avoir d'un remboursement d'une commande facturée."""
    if refund.credit_note_number or not refund.order.invoice_number:
        return refund.credit_note_number
    refund.credit_note_number = _prochain("avoir", ShopSettings.get_solo().credit_note_prefix)
    refund.save(update_fields=["credit_note_number"])
    return refund.credit_note_number


# --------------------------------------------------------------------------
#  Le document : page, PDF, pièce jointe
# --------------------------------------------------------------------------

def _entete():
    from jeiko.administration.models import WebSite

    site = WebSite.objects.select_related("identity").first()
    return {
        "vendeur": getattr(site, "identity", None) if site else None,
        "reglages": ShopSettings.get_solo(),
    }


def accent_des_pieces(reglages):
    """La couleur des pièces : la leur, sinon l'accent du thème, sinon un gris sombre."""
    if reglages.doc_accent:
        return reglages.doc_accent
    from jeiko.administration.models import WebSite

    site = WebSite.objects.select_related("theme").first()
    return getattr(getattr(site, "theme", None), "accent", "") or "#111827"


def logo_des_pieces(reglages, en_pdf=False):
    """
    L'adresse du logo du site, ou "". Pour le PDF, l'image EMBARQUÉE en
    `data:` : le moteur ne va rien chercher ailleurs (voir jeiko.pdf.moteur).
    Au-delà de 1 Mo, pas de logo dans le PDF plutôt qu'un fichier énorme.
    """
    import base64
    import mimetypes

    from jeiko.administration.models import WebSite

    if not reglages.doc_show_logo:
        return ""
    site = WebSite.objects.select_related("logo").first()
    logo = getattr(site, "logo", None)
    image = logo.email_image() if logo else None
    if image is None:
        return ""
    if not en_pdf:
        return image.url
    try:
        if image.size > 1024 * 1024:
            return ""
        with image.open("rb") as fichier:
            donnees = fichier.read()
    except (OSError, ValueError):
        return ""
    type_mime = mimetypes.guess_type(image.name)[0] or "image/png"
    return f"data:{type_mime};base64,{base64.b64encode(donnees).decode()}"


def contexte_facture(order):
    return {
        **_entete(), "order": order, "lines": order.lines.all(),
        "ventilation": ventilation_de(order), "titre": _("Facture"),
        "numero": order.invoice_number, "date": order.invoiced_at,
    }


def contexte_avoir(refund):
    return {
        **_entete(), "order": refund.order, "refund": refund,
        "ventilation": ventilation_avoir(refund), "titre": _("Avoir"),
        "numero": refund.credit_note_number, "date": refund.created_at,
    }


def document_pdf(contexte):
    """Lève `jeiko.pdf.moteur.MoteurPDFAbsent` sur un serveur sans moteur."""
    from jeiko.pdf.moteur import gabarit_en_pdf

    return gabarit_en_pdf("shop/invoice.html", {**contexte, "en_pdf": True})


def nom_du_fichier(contexte):
    return f"{contexte['titre']}-{contexte['numero']}.pdf".replace(" ", "-")


def piece_jointe_facture(order):
    """`(nom, octets, type)` pour un e-mail ; None sans facture ou sans moteur."""
    from jeiko.pdf.moteur import MoteurPDFAbsent

    if not order.invoice_number:
        return None
    contexte = contexte_facture(order)
    try:
        return nom_du_fichier(contexte), document_pdf(contexte), "application/pdf"
    except MoteurPDFAbsent:
        return None
