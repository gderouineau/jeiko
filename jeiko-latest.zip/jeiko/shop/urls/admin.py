from django.urls import path
from jeiko.shop.views import admin as admin_views

app_name = "jeiko_administration_shop"

urlpatterns = [
    # Types de produit
    path("types/", admin_views.ProductTypeListView.as_view(), name="product_type_list"),
    path("types/add/", admin_views.ProductTypeCreateView.as_view(), name="product_type_create"),
    path("types/<int:pk>/edit/", admin_views.ProductTypeUpdateView.as_view(), name="product_type_update"),
    path("types/<int:pk>/delete/", admin_views.ProductTypeDeleteView.as_view(), name="product_type_delete"),

    # Produits d’un type
    path(
        "products/",
        admin_views.AllProductListView.as_view(),
        name="product_list_all",
    ),
    path(
        "types/<int:type_pk>/products/",
        admin_views.ProductListView.as_view(),
        name="product_list",
    ),
    path(
        "types/<int:type_pk>/products/add/",
        admin_views.ProductCreateView.as_view(),
        name="product_create",
    ),
    path(
        "types/<int:type_pk>/products/<int:pk>/edit/",
        admin_views.ProductUpdateView.as_view(),
        name="product_update",
    ),
    path(
        "types/<int:type_pk>/products/<int:pk>/delete/",
        admin_views.ProductDeleteView.as_view(),
        name="product_delete",
    ),
]
