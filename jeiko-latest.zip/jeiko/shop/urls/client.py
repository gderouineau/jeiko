from django.urls import path
from jeiko.shop.views import client as client_views

app_name = "jeiko_client_shop"

urlpatterns = [
    path("<slug:product_type_code>/<slug:product_sku>/", client_views.ProductView.as_view(), name="product_detail"),
    
    # Cart
    path("cart/", client_views.CartDetailView.as_view(), name="cart_detail"),
    path("cart/add/<int:product_id>/", client_views.AddToCartView.as_view(), name="cart_add"),
    path("cart/update/<int:item_id>/", client_views.UpdateCartItemView.as_view(), name="cart_update"),
    path("cart/remove/<int:item_id>/", client_views.RemoveCartItemView.as_view(), name="cart_remove"),
]
