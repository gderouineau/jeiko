from django.urls import path
from ..views.admin_orders import OrderListView, OrderUpdateView

app_name = 'jeiko_shop_admin_orders'

urlpatterns = [
    path('orders/', OrderListView.as_view(), name='order_list'),
    path('orders/<int:pk>/', OrderUpdateView.as_view(), name='order_update'),
]
