"""
L'export comptable, en CSV (FACT-01).

Toutes les pièces numérotées d'une période — factures et avoirs faits à la
main ET ceux de la boutique, qui partagent la même suite —, puis, à part, les
règlements reçus. Format lu par Excel en français : point-virgule, virgule
décimale, marque UTF-8 en tête (sans elle, les accents arrivent brisés).

Ce que ce n'est pas : le FEC (fichier des écritures comptables). Il viendra
s'il est demandé ; ce CSV est ce qu'un comptable reprend aujourd'hui.
"""
import csv
import io
from decimal import Decimal

from django.utils.translation import gettext as _

from .facturation import ventilation_avoir, ventilation_de
from .models import Order, OrderRefund, PieceDeVente, Reglement


#: Ce par quoi un tableur reconnaît une formule en tête de cellule.
DEBUTS_DE_FORMULE = ("=", "+", "-", "@", "\t", "\r")


def _texte(valeur):
    """
    Un champ texte, neutralisé pour le tableur (vérification du 11/10/2026,
    C-10). Le nom de facturation est SAISI PAR LE CLIENT : « =HYPERLINK(…) »
    s'exécutait à l'ouverture de l'export chez le comptable — les guillemets
    du CSV n'y changent rien. Une apostrophe en tête fait lire la cellule
    comme du texte, et le tableur ne l'affiche pas.

    Les montants n'y passent pas : un avoir est négatif (« -12,50 »), et
    l'apostrophe en ferait du texte, que le comptable ne pourrait plus sommer.
    """
    valeur = "" if valeur is None else str(valeur)
    return "'" + valeur if valeur.startswith(DEBUTS_DE_FORMULE) else valeur


def _nombre(valeur):
    return f"{Decimal(valeur or 0):.2f}".replace(".", ",")


def _totaux(ventilation):
    ht = sum((m["ht"] for m in ventilation.values()), Decimal("0"))
    tva = sum((m["tva"] for m in ventilation.values()), Decimal("0"))
    return ht, tva, ht + tva


def lignes_des_pieces(du, au):
    """[(date, ligne)] de toutes les pièces numérotées entre `du` et `au` inclus."""
    lignes = []
    for p in PieceDeVente.objects.filter(nature__in=(PieceDeVente.FACTURE, PieceDeVente.AVOIR),
                                         date_emission__range=(du, au)).exclude(numero="") \
            .prefetch_related("lignes", "reglements"):
        ht, tva, ttc = _totaux(p.ventilation())
        nature = p.get_type_facture_display() if p.nature == PieceDeVente.FACTURE else p.get_nature_display()
        lignes.append((p.date_emission, [
            nature, _texte(p.numero), p.date_emission.strftime("%d/%m/%Y"), _texte(p.client_nom), _("Manuelle"),
            _nombre(ht), _nombre(tva), _nombre(ttc), p.devise,
            p.date_echeance.strftime("%d/%m/%Y") if p.date_echeance else "",
            _nombre(p.deja_regle), _nombre(p.reste_a_payer) if p.nature == PieceDeVente.FACTURE else "",
            p.get_etat_display(),
        ]))
    for o in Order.objects.exclude(invoice_number="").filter(invoiced_at__date__range=(du, au)):
        ht, tva, ttc = _totaux(ventilation_de(o))
        jour = o.invoiced_at.date()
        lignes.append((jour, [_("Facture"), _texte(o.invoice_number), jour.strftime("%d/%m/%Y"), _texte(o.billing_name),
                              _("Boutique"), _nombre(ht), _nombre(tva), _nombre(ttc), o.currency, "",
                              _nombre(o.total_ttc), _nombre(0), _("Payée")]))
    for r in OrderRefund.objects.exclude(credit_note_number="").filter(created_at__date__range=(du, au)) \
            .select_related("order"):
        ht, tva, ttc = _totaux(ventilation_avoir(r))
        jour = r.created_at.date()
        lignes.append((jour, [_("Avoir"), _texte(r.credit_note_number), jour.strftime("%d/%m/%Y"), _texte(r.order.billing_name),
                              _("Boutique"), _nombre(ht), _nombre(tva), _nombre(ttc), r.order.currency, "",
                              "", "", ""]))
    return sorted(lignes, key=lambda x: (x[0], x[1][1]))


def csv_des_pieces(du, au):
    tampon = io.StringIO()
    tampon.write("﻿")
    ecrire = csv.writer(tampon, delimiter=";")
    ecrire.writerow([_("Type"), _("Numéro"), _("Date"), _("Client"), _("Origine"), _("Total HT"), _("TVA"),
                     _("Total TTC"), _("Devise"), _("Échéance"), _("Réglé"), _("Reste à payer"), _("État")])
    for __, ligne in lignes_des_pieces(du, au):
        ecrire.writerow(ligne)
    return tampon.getvalue()


def csv_des_reglements(du, au):
    tampon = io.StringIO()
    tampon.write("﻿")
    ecrire = csv.writer(tampon, delimiter=";")
    ecrire.writerow([_("Date"), _("Facture"), _("Client"), _("Moyen"), _("Référence"), _("Montant TTC")])
    for r in Reglement.objects.filter(date__range=(du, au)).select_related("piece").order_by("date", "id"):
        ecrire.writerow([r.date.strftime("%d/%m/%Y"), _texte(r.piece.numero), _texte(r.piece.client_nom),
                         r.get_moyen_display(), _texte(r.reference), _nombre(r.montant)])
    for o in Order.objects.exclude(invoice_number="").filter(invoiced_at__date__range=(du, au)):
        ecrire.writerow([o.invoiced_at.date().strftime("%d/%m/%Y"), _texte(o.invoice_number), _texte(o.billing_name),
                         _("Boutique en ligne"), "", _nombre(o.total_ttc)])
    return tampon.getvalue()
