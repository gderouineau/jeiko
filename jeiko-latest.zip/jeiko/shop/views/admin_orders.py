from django.views.generic import ListView, UpdateView, DetailView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Q
from ..models import Order

class OrderListView(LoginRequiredMixin, ListView):
    model = Order
    template_name = 'shop/admin/order_list.html'
    context_object_name = 'orders'
    paginate_by = 20

    def get_queryset(self):
        queryset = super().get_queryset()
        order_status = self.request.GET.get('order_status')
        payment_status = self.request.GET.get('payment_status')
        search = self.request.GET.get('search')

        if order_status:
            queryset = queryset.filter(order_status=order_status)
        
        if payment_status:
            queryset = queryset.filter(payment_status=payment_status)
        
        if search:
            queryset = queryset.filter(
                Q(pk__icontains=search) | 
                Q(user__email__icontains=search) |
                Q(billing_name__icontains=search)
            )
            
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['order_status_choices'] = Order.ORDER_STATUS_CHOICES
        context['payment_status_choices'] = Order.PAYMENT_STATUS_CHOICES
        return context

class OrderUpdateView(LoginRequiredMixin, UpdateView):
    model = Order
    fields = ['order_status', 'payment_status', 'billing_name', 'billing_address', 'shipping_name', 'shipping_address']
    template_name = 'shop/admin/order_form.html'
    success_url = reverse_lazy('jeiko_shop_admin_orders:order_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['lines'] = self.object.lines.all()
        return context
