"""
Les écrans des devis, factures et avoirs (FACT-01).

Toutes les transitions passent par `shop.pieces` : ces vues ne font que
recevoir, valider et rediriger. Une action se fait par POST et revient sur la
fiche, avec son message ; un refus métier (ValidationError) devient un
message d'erreur, jamais une page 500.
"""
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Q
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.translation import gettext as _
from django.views import View

from jeiko.listes import paginer
from jeiko.shop import pieces
from jeiko.shop.forms import AcompteForm, LignesFormSet, PieceForm, ReglementForm
from jeiko.shop.models import PieceDeVente, ShopSettings
from jeiko.shop.views.admin import ShopAdminMixin

#: L'adresse de liste → les natures qu'elle montre. Les avoirs vivent avec
#: les factures : ils en sont la correction.
LISTES = {"devis": (PieceDeVente.DEVIS,), "factures": (PieceDeVente.FACTURE, PieceDeVente.AVOIR)}


def _fiche(piece):
    return redirect("jeiko_administration_shop:piece", pk=piece.pk)


class ListeDesPieces(ShopAdminMixin, View):
    permission_required = "shop.view_piecedevente"

    def get(self, request, liste):
        if liste not in LISTES:
            raise Http404
        qs = PieceDeVente.objects.filter(nature__in=LISTES[liste]).prefetch_related("lignes")
        q = (request.GET.get("q") or "").strip()
        if q:
            qs = qs.filter(Q(numero__icontains=q) | Q(client_nom__icontains=q) | Q(objet__icontains=q))
        etat = request.GET.get("etat") or ""
        if etat == "en_retard":
            qs = qs.filter(nature=PieceDeVente.FACTURE, etat__in=(PieceDeVente.EMISE, PieceDeVente.PAYEE_EN_PARTIE),
                           date_echeance__lt=timezone.localdate())
        elif etat:
            qs = qs.filter(etat=etat)
        objets, pagination = paginer(request, qs)
        return render(request, "shop/admin/pieces_liste.html", {
            "liste": liste, "pieces": objets, "q": q, "etat": etat,
            "export_du": timezone.localdate().replace(day=1).isoformat(), "export_au": timezone.localdate().isoformat(),
            "etats": [(c, l) for c, l in PieceDeVente.ETATS if liste == "factures" or c not in (
                PieceDeVente.PAYEE_EN_PARTIE, PieceDeVente.PAYEE, PieceDeVente.ANNULEE)],
            **pagination,
        })


class NouvellePiece(ShopAdminMixin, View):
    permission_required = "shop.add_piecedevente"

    def post(self, request, nature):
        if nature not in (PieceDeVente.DEVIS, PieceDeVente.FACTURE):
            raise Http404
        piece = PieceDeVente.objects.create(nature=nature, devise=ShopSettings.get_solo().currency,
                                            cree_par=request.user)
        return redirect("jeiko_administration_shop:piece_modifier", pk=piece.pk)


class ModifierLaPiece(ShopAdminMixin, View):
    """L'en-tête et les lignes d'un BROUILLON — ou d'un devis émis, qui reste corrigeable."""

    permission_required = "shop.change_piecedevente"
    gabarit = "shop/admin/piece_formulaire.html"

    def _piece(self, pk):
        piece = get_object_or_404(PieceDeVente, pk=pk)
        if piece.est_figee or piece.etat not in (PieceDeVente.BROUILLON, PieceDeVente.EMISE):
            raise Http404
        return piece

    def get(self, request, pk):
        piece = self._piece(pk)
        return render(request, self.gabarit, {"piece": piece, "form": PieceForm(instance=piece),
                                              "lignes": LignesFormSet(instance=piece, prefix="lignes")})

    def post(self, request, pk):
        piece = self._piece(pk)
        form = PieceForm(request.POST, instance=piece)
        lignes = LignesFormSet(request.POST, instance=piece, prefix="lignes")
        if not (form.is_valid() and lignes.is_valid()):
            return render(request, self.gabarit, {"piece": piece, "form": form, "lignes": lignes})
        with transaction.atomic():
            form.save()
            for rang, ligne in enumerate(lignes.save(commit=False)):
                ligne.position = rang
                ligne.save()
            for ligne in lignes.deleted_objects:
                ligne.delete()
        messages.success(request, _("Enregistré."))
        if "emettre" in request.POST and piece.etat == PieceDeVente.BROUILLON:
            return Action().post(request, pk, "emettre")
        return _fiche(piece)


class FicheDeLaPiece(ShopAdminMixin, View):
    permission_required = "shop.view_piecedevente"

    def get(self, request, pk):
        piece = get_object_or_404(PieceDeVente.objects.select_related("origine", "contact", "entreprise"), pk=pk)
        return render(request, "shop/admin/piece_fiche.html", {
            "piece": piece, "acompte_form": AcompteForm(),
            "reglement_form": ReglementForm(initial={"montant": piece.reste_a_payer, "date": timezone.localdate()}),
            "lien_public": request.build_absolute_uri(
                reverse("jeiko_client_shop:piece_publique", args=[piece.jeton])) if piece.jeton else "",
        })


class Action(ShopAdminMixin, View):
    """Une transition, par POST. Revient sur la fiche — celle de la pièce née, s'il y en a une."""

    permission_required = "shop.change_piecedevente"

    def post(self, request, pk, action):
        piece = get_object_or_404(PieceDeVente, pk=pk)
        if action == "supprimer":
            if piece.numero:
                messages.error(request, _("Une pièce numérotée ne se supprime pas."))
                return _fiche(piece)
            liste = "devis" if piece.nature == PieceDeVente.DEVIS else "factures"
            piece.delete()
            messages.success(request, _("Brouillon supprimé."))
            return redirect(f"jeiko_administration_shop:pieces_{liste}")
        try:
            nee = self._faire(request, piece, action)
        except ValidationError as souci:
            messages.error(request, " ".join(souci.messages))
            return _fiche(piece)
        return _fiche(nee or piece)

    def _faire(self, request, piece, action):
        if action == "emettre":
            piece = pieces.emettre(piece)
            messages.success(request, _("Émise sous le numéro %(numero)s.") % {"numero": piece.numero})
        elif action == "facturer":
            facture = pieces.transformer_en_facture(piece)
            messages.success(request, _("Facture créée en brouillon : relisez-la, puis émettez-la."))
            return facture
        elif action == "acompte":
            form = AcompteForm(request.POST)
            if not form.is_valid():
                raise ValidationError(_("Indiquez un pourcentage entre 0 et 100."))
            messages.success(request, _("Facture d'acompte créée en brouillon."))
            return pieces.creer_acompte(piece, form.cleaned_data["pourcentage"])
        elif action == "reglement":
            form = ReglementForm(request.POST)
            if not form.is_valid():
                raise ValidationError(" ".join(
                    f"{form.fields[champ].label} : {' '.join(erreurs)}" for champ, erreurs in form.errors.items()))
            pieces.enregistrer_reglement(piece, **form.cleaned_data)
            messages.success(request, _("Règlement enregistré."))
        elif action == "avoir":
            messages.success(request, _("Avoir créé en brouillon : réduisez-le s'il est partiel, puis émettez-le."))
            return pieces.avoir_de(piece)
        elif action == "accepte":
            nee = pieces.accepter(piece, request.user.get_full_name() or request.user.get_username())
            messages.success(request, _("Devis marqué accepté."))
            return nee
        elif action == "refuse":
            pieces.refuser(piece)
            messages.success(request, _("Devis marqué refusé."))
        elif action == "envoyer":
            from jeiko.shop.pieces_envois import envoyer

            if not envoyer(piece):
                raise ValidationError(_("Rien n'est parti : la pièce doit être émise et le client avoir une adresse e-mail."))
            messages.success(request, _("Envoyé à %(email)s.") % {"email": piece.client_email})
        elif action == "relances":
            piece.relances_actives = not piece.relances_actives
            piece.save(update_fields=["relances_actives", "modifie_le"])
        else:
            raise Http404
        return None



def contexte_document(piece, en_pdf=False, public=False):
    from jeiko.calendars.payments import is_available
    from jeiko.shop.facturation import _entete, accent_des_pieces, logo_des_pieces
    from jeiko.shop.pieces_paiement import a_payer

    entete = _entete()
    reglages = entete["reglages"]
    return {**entete, "piece": piece, "lignes": piece.lignes.all(), "ventilation": piece.ventilation(),
            "accent": accent_des_pieces(reglages), "logo_url": logo_des_pieces(reglages, en_pdf),
            "pied_de_page": reglages.doc_footer, "public": public,
            "paiement_en_ligne": public and not en_pdf and is_available() and a_payer(piece) is not None}


def servir_le_document(request, piece, gabarit="shop/piece.html", public=False):
    """La page imprimable, ou son PDF avec `?format=pdf`."""
    from jeiko.pdf import moteur as pdf

    contexte = contexte_document(piece, public=public)
    if request.GET.get("format") == "pdf":
        try:
            octets = pdf.gabarit_en_pdf(gabarit, {**contexte_document(piece, en_pdf=True), "en_pdf": True})
        except pdf.MoteurPDFAbsent:
            pass
        else:
            reponse = HttpResponse(octets, content_type="application/pdf")
            nom = (piece.numero or _("brouillon")).replace(" ", "-")
            reponse["Content-Disposition"] = f'attachment; filename="{piece.get_nature_display()}-{nom}.pdf"'
            return reponse
    return render(request, gabarit, {**contexte, "pdf_disponible": pdf.disponible()})


class DocumentDeLaPiece(ShopAdminMixin, View):
    permission_required = "shop.view_piecedevente"

    def get(self, request, pk):
        return servir_le_document(request, get_object_or_404(PieceDeVente, pk=pk))


class PiecePublique(View):
    """
    Le devis ou la facture, pour le CLIENT, sans compte : un lien à jeton
    (`secrets.token_urlsafe(32)`, envoyé avec la pièce). Un brouillon n'en a
    pas ; un jeton inconnu donne 404, sans dire si la pièce existe.

    Sur un devis qui attend sa réponse, le client l'accepte : son nom, la date
    et son adresse IP sont gardés comme preuve (`pieces.accepter`).
    """

    gabarit = "shop/piece.html"

    def _piece(self, jeton):
        if len(jeton) < 30:
            raise Http404
        return get_object_or_404(PieceDeVente, jeton=jeton)

    def get(self, request, jeton):
        from jeiko.throttling import rate_limited

        piece = self._piece(jeton)
        # Un PDF coûte du calcul : au-delà de 30 par heure et par adresse, la
        # page imprimable reste, sans le fichier.
        if request.GET.get("format") == "pdf" and rate_limited(request, "shop:piece_pdf", 30, 3600):
            request = _sans_pdf(request)
        return servir_le_document(request, piece, self.gabarit, public=True)

    def post(self, request, jeton):
        from jeiko.throttling import ip_stockable, rate_limited

        piece = self._piece(jeton)
        if rate_limited(request, "shop:piece_accepter", 10, 3600):
            return HttpResponse(status=429)
        nom = (request.POST.get("nom") or "").strip()
        if not nom or request.POST.get("accord") != "1":
            messages.error(request, _("Indiquez votre nom et cochez la case pour accepter le devis."))
            return redirect(request.path)
        try:
            pieces.accepter(piece, nom, ip_stockable(request))
        except ValidationError as souci:
            messages.error(request, " ".join(souci.messages))
        else:
            messages.success(request, _("Merci : votre accord est enregistré."))
        return redirect(request.path)


def _sans_pdf(request):
    """La même requête, sans `?format=pdf` : au-delà du plafond, la page imprimable reste."""
    copie = request.GET.copy()
    copie.pop("format", None)
    request.GET = copie
    return request


class PayerLaPiece(PiecePublique):
    """La page de paiement par carte d'une facture, depuis le lien du client."""

    def get(self, request, jeton):
        from jeiko.shop import pieces_paiement

        piece = self._piece(jeton)
        facture = pieces_paiement.a_payer(piece)
        contexte = {"piece": piece, "facture": facture}
        if facture is None:
            contexte["indisponible"] = _("Il n'y a rien à payer en ligne sur cette pièce.")
        else:
            try:
                secret, cle = pieces_paiement.ouvrir(facture)
            except pieces_paiement.PaiementIndisponible:
                contexte["indisponible"] = _("Le paiement en ligne n'est pas disponible : réglez par virement.")
            except Exception:
                import logging

                logging.getLogger(__name__).exception("Paiement de la pièce %s impossible à ouvrir", piece.pk)
                contexte["indisponible"] = _("Impossible d'ouvrir le paiement pour le moment, merci de réessayer.")
            else:
                contexte.update({
                    "montant": pieces_paiement.montant_attendu(facture), "client_secret": secret,
                    "stripe_public_key": cle,
                    "return_url": request.build_absolute_uri(
                        reverse("jeiko_client_shop:piece_paiement_retour", args=[jeton])),
                })
        return render(request, "shop/piece_paiement.html", contexte)

    def post(self, request, jeton):
        raise Http404


class RetourDePaiement(PiecePublique):
    """Retour du client depuis Stripe : on relit le paiement, puis on rend la pièce."""

    def get(self, request, jeton):
        from jeiko.shop import pieces_paiement

        piece = self._piece(jeton)
        facture = pieces_paiement.confirmer_par_identifiant(request.GET.get("payment_intent") or "")
        if facture is not None:
            messages.success(request, _("Merci : votre paiement est enregistré."))
        else:
            messages.info(request, _("Votre paiement est en cours de vérification ; la facture se mettra à jour d'elle-même."))
        return redirect("jeiko_client_shop:piece_publique", jeton=piece.jeton)

    def post(self, request, jeton):
        raise Http404


class ExportComptable(ShopAdminMixin, View):
    """Le CSV des pièces, ou des règlements, d'une période (du … au, inclus)."""

    permission_required = "shop.view_piecedevente"

    def get(self, request):
        from datetime import date

        from jeiko.shop.facturation_export import csv_des_pieces, csv_des_reglements

        aujourd_hui = timezone.localdate()
        try:
            du = date.fromisoformat(request.GET.get("du") or aujourd_hui.replace(day=1).isoformat())
            au = date.fromisoformat(request.GET.get("au") or aujourd_hui.isoformat())
        except ValueError:
            messages.error(request, _("Des dates au format AAAA-MM-JJ, s'il vous plaît."))
            return redirect("jeiko_administration_shop:pieces_factures")
        if request.GET.get("quoi") == "reglements":
            contenu, nom = csv_des_reglements(du, au), "reglements"
        else:
            contenu, nom = csv_des_pieces(du, au), "factures"
        reponse = HttpResponse(contenu, content_type="text/csv; charset=utf-8")
        reponse["Content-Disposition"] = f'attachment; filename="{nom}-{du.isoformat()}-{au.isoformat()}.csv"'
        return reponse
