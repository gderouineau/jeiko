"""
L'écran « Facturation » de la boutique (FACT-01, 10/10/2026).

Identité de facturation, numérotation et taux de TVA. Les devis et les
factures faits à la main viendront s'y ranger, en onglets.
"""
from django.contrib import messages
from django.db import transaction
from django.shortcuts import redirect, render
from django.utils.translation import gettext as _
from django.views import View

from jeiko.shop import facturation
from jeiko.shop.forms import ReglagesFacturationForm, TauxDeTVAFormSet
from jeiko.shop.models import ShopSettings, TaxRate
from jeiko.shop.views.admin import ShopAdminMixin


class ReglagesFacturation(ShopAdminMixin, View):
    permission_required = "shop.change_producttype"
    gabarit = "shop/admin/facturation_reglages.html"

    def _rendre(self, request, form, taux):
        reglages = ShopSettings.get_solo()
        return render(request, self.gabarit, {
            "form": form, "taux": taux,
            "apercus": [
                (_("Facture"), facturation.apercu(reglages, "facture", reglages.invoice_prefix)),
                (_("Devis"), facturation.apercu(reglages, "devis", reglages.quote_prefix)),
                (_("Avoir"), facturation.apercu(reglages, "avoir", reglages.credit_note_prefix)),
            ],
        })

    def get(self, request):
        return self._rendre(request, ReglagesFacturationForm(instance=ShopSettings.get_solo()),
                            TauxDeTVAFormSet(queryset=TaxRate.objects.all(), prefix="taux"))

    def post(self, request):
        form = ReglagesFacturationForm(request.POST, instance=ShopSettings.get_solo())
        taux = TauxDeTVAFormSet(request.POST, queryset=TaxRate.objects.all(), prefix="taux")
        if not (form.is_valid() and taux.is_valid()):
            return self._rendre(request, form, taux)
        with transaction.atomic():
            form.save()
            taux.save()
        messages.success(request, _("Réglages de facturation enregistrés."))
        return redirect("jeiko_administration_shop:facturation_reglages")
