"""
Ce qui arrive aux devis, factures et avoirs faits à la main (FACT-01).

Les écrans, l'API et les automatismes passent tous par ici : une seule place
où un devis devient une facture, où une facture reçoit son numéro, où un
paiement la solde. Deux chemins écrits deux fois finiraient par ne plus
numéroter de la même façon.

Ce que ce module garantit
-------------------------
* Le numéro n'est pris qu'à l'ÉMISSION (`emettre`), sous verrou, dans la suite
  de sa nature — les factures dans celle de la boutique. Un brouillon
  abandonné ne laisse pas de trou.
* Le client est figé à l'émission : la pièce garde le nom et l'adresse du
  jour, quoi que devienne la fiche du CRM.
* Une facture émise ne se corrige que par un avoir (`avoir_de`).

Ce qu'il ne fait pas
--------------------
Il n'envoie rien : l'e-mail d'une pièce, ses relances et son PDF vivent dans
leurs propres modules, qui l'appellent.
"""

import secrets
from datetime import timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone
from django.utils.translation import gettext as _

from . import facturation
from .models import CENTIME, LigneDePiece, PieceDeVente, Reglement, ShopSettings, _montant

PREFIXES = {
    PieceDeVente.FACTURE: "invoice_prefix",
    PieceDeVente.DEVIS: "quote_prefix",
    PieceDeVente.AVOIR: "credit_note_prefix",
}


def figer_le_client(piece):
    """Recopie le client depuis le CRM, sans écraser ce qui a été saisi."""
    entreprise, contact = piece.entreprise, piece.contact
    if entreprise is None and contact is not None:
        entreprise = contact.entreprise
    if not piece.client_nom:
        if entreprise is not None:
            piece.client_nom = entreprise.name
        elif contact is not None:
            piece.client_nom = f"{contact.firstname} {contact.lastname}".strip() or contact.company or contact.email
    if not piece.client_adresse and entreprise is not None:
        lignes = [entreprise.address, f"{entreprise.postal_code} {entreprise.city}".strip(), entreprise.country]
        piece.client_adresse = "\n".join(l for l in lignes if l)
    if not piece.client_email:
        piece.client_email = (contact.email if contact is not None else "") or (entreprise.email if entreprise else "")


def _copier_les_lignes(source, cible, signe=Decimal("1"), libelle=None):
    for ligne in source.lignes.all():
        LigneDePiece.objects.create(
            piece=cible, position=ligne.position, libelle=libelle(ligne) if libelle else ligne.libelle,
            quantite=ligne.quantite, unite=ligne.unite, prix_unitaire_ht=ligne.prix_unitaire_ht * signe,
            taux_tva=ligne.taux_tva, produit=ligne.produit,
        )


def _nouvelle(nature, source, **champs):
    piece = PieceDeVente.objects.create(
        nature=nature, origine=source, contact=source.contact, entreprise=source.entreprise,
        client_nom=source.client_nom, client_adresse=source.client_adresse,
        client_email=source.client_email, client_tva=source.client_tva,
        objet=source.objet, devise=source.devise, **champs,
    )
    return piece


@transaction.atomic
def emettre(piece):
    """
    Numérote et date une pièce brouillon ; elle ne se modifie plus ensuite
    (sauf un devis, qui reste corrigeable jusqu'à sa transformation).
    """
    piece = PieceDeVente.objects.select_for_update().get(pk=piece.pk)
    if piece.etat != PieceDeVente.BROUILLON:
        raise ValidationError(_("Seul un brouillon s'émet."))
    figer_le_client(piece)
    if not piece.client_nom:
        raise ValidationError(_("Indiquez le client avant d'émettre."))
    if not piece.lignes.exists():
        raise ValidationError(_("Une pièce sans ligne ne s'émet pas."))
    reglages = ShopSettings.get_solo()
    aujourd_hui = timezone.localdate()
    piece.numero = facturation._prochain(piece.nature, getattr(reglages, PREFIXES[piece.nature]))
    piece.date_emission = aujourd_hui
    if piece.nature == PieceDeVente.FACTURE and piece.date_echeance is None:
        piece.date_echeance = aujourd_hui + timedelta(days=reglages.payment_days)
    if piece.nature == PieceDeVente.DEVIS and piece.date_validite is None:
        piece.date_validite = aujourd_hui + timedelta(days=reglages.quote_validity_days)
    if not piece.jeton:
        piece.jeton = secrets.token_urlsafe(32)
    piece.etat = PieceDeVente.EMISE
    piece.save()
    if piece.nature == PieceDeVente.AVOIR and piece.origine_id:
        _annuler_si_soldee_par_avoirs(piece.origine)
    return piece


def transformer_en_facture(devis):
    """Le devis devient une facture BROUILLON, modifiable avant émission."""
    if devis.nature != PieceDeVente.DEVIS or devis.etat in (PieceDeVente.BROUILLON, PieceDeVente.TRANSFORME):
        raise ValidationError(_("Seul un devis émis ou accepté se transforme en facture."))
    with transaction.atomic():
        facture = _nouvelle(PieceDeVente.FACTURE, devis, notes=devis.notes)
        _copier_les_lignes(devis, facture)
        _deduire_les_acomptes(devis, facture)
        devis.etat = PieceDeVente.TRANSFORME
        devis.save(update_fields=["etat", "modifie_le"])
    return facture


def creer_acompte(devis, pourcentage):
    """Une facture d'acompte brouillon : `pourcentage` du devis, taux par taux."""
    pourcentage = Decimal(str(pourcentage))
    if not Decimal("0") < pourcentage <= Decimal("100"):
        raise ValidationError(_("Un acompte se situe entre 0 et 100 % du devis."))
    if devis.nature != PieceDeVente.DEVIS or not devis.numero:
        raise ValidationError(_("Un acompte se demande sur un devis émis."))
    with transaction.atomic():
        facture = _nouvelle(PieceDeVente.FACTURE, devis, type_facture=PieceDeVente.ACOMPTE)
        for rang, (taux, montants) in enumerate(devis.ventilation().items()):
            LigneDePiece.objects.create(
                piece=facture, position=rang, taux_tva=taux,
                prix_unitaire_ht=(montants["ht"] * pourcentage / Decimal("100")).quantize(CENTIME),
                libelle=_("Acompte de %(pourcentage)s %% sur le devis %(devis)s") % {
                    "pourcentage": pourcentage.normalize(), "devis": devis.numero},
            )
    return facture


def _deduire_les_acomptes(devis, facture):
    """Les acomptes émis sur ce devis, déduits de la facture de solde."""
    acomptes = devis.suites.filter(nature=PieceDeVente.FACTURE, type_facture=PieceDeVente.ACOMPTE) \
        .exclude(numero="").exclude(etat=PieceDeVente.ANNULEE)
    if not acomptes.exists():
        return
    facture.type_facture = PieceDeVente.SOLDE
    facture.save(update_fields=["type_facture"])
    position = facture.lignes.count()
    for acompte in acomptes:
        for ligne in acompte.lignes.all():
            position += 1
            LigneDePiece.objects.create(
                piece=facture, position=position, taux_tva=ligne.taux_tva,
                prix_unitaire_ht=-ligne.prix_unitaire_ht, quantite=ligne.quantite,
                libelle=_("Acompte déjà facturé (%(numero)s)") % {"numero": acompte.numero},
            )


def avoir_de(facture):
    """Un avoir BROUILLON qui reprend la facture ; à réduire pour un avoir partiel."""
    if facture.nature != PieceDeVente.FACTURE or not facture.numero:
        raise ValidationError(_("Un avoir corrige une facture émise."))
    with transaction.atomic():
        avoir = _nouvelle(PieceDeVente.AVOIR, facture)
        _copier_les_lignes(facture, avoir)
    return avoir


def _annuler_si_soldee_par_avoirs(facture):
    avoirs = facture.suites.filter(nature=PieceDeVente.AVOIR).exclude(numero="")
    if sum((a.total_ttc for a in avoirs), Decimal("0")) >= facture.total_ttc:
        facture.etat = PieceDeVente.ANNULEE
        facture.save(update_fields=["etat", "modifie_le"])


def enregistrer_reglement(facture, montant, moyen=Reglement.VIREMENT, reference="", date=None):
    if facture.nature != PieceDeVente.FACTURE or facture.etat not in (PieceDeVente.EMISE, PieceDeVente.PAYEE_EN_PARTIE):
        raise ValidationError(_("Un règlement s'enregistre sur une facture émise et pas encore soldée."))
    montant = _montant(montant)
    if montant <= 0:
        raise ValidationError(_("Le montant d'un règlement est positif."))
    with transaction.atomic():
        Reglement.objects.create(piece=facture, montant=montant, moyen=moyen, reference=reference,
                                 date=date or timezone.localdate())
        facture.etat = PieceDeVente.PAYEE if facture.reste_a_payer <= 0 else PieceDeVente.PAYEE_EN_PARTIE
        facture.save(update_fields=["etat", "modifie_le"])
    return facture


def accepter(devis, nom, ip=None):
    """
    Le client accepte le devis (en ligne, ou noté par l'exploitant). Selon le
    réglage, la facture naît aussitôt en brouillon — rien n'est émis sans
    relecture.
    """
    if devis.nature != PieceDeVente.DEVIS or devis.etat != PieceDeVente.EMISE:
        raise ValidationError(_("Ce devis n'attend plus de réponse."))
    if devis.date_validite and devis.date_validite < timezone.localdate():
        raise ValidationError(_("Ce devis n'est plus valable."))
    devis.etat = PieceDeVente.ACCEPTE
    devis.accepte_le, devis.accepte_par, devis.accepte_ip = timezone.now(), (nom or "")[:200], ip
    devis.save(update_fields=["etat", "accepte_le", "accepte_par", "accepte_ip", "modifie_le"])
    if ShopSettings.get_solo().auto_invoice_on_accept:
        return transformer_en_facture(devis)
    return None


def refuser(devis):
    if devis.nature != PieceDeVente.DEVIS or devis.etat != PieceDeVente.EMISE:
        raise ValidationError(_("Ce devis n'attend plus de réponse."))
    devis.etat = PieceDeVente.REFUSE
    devis.save(update_fields=["etat", "modifie_le"])
