# jeiko/shop/emailing.py
"""
E-mails de la boutique.

Le système d'e-mails éditables était en place, le catalogue déclarait les huit
codes de la chaîne transactionnelle — et aucun n'était appelé. Un client payait
sans jamais rien recevoir, et l'exploitant n'était pas prévenu qu'une commande
était tombée.

Ce module traduit une Order en contexte et délègue à `jeiko.emailing`, où sujets
et mises en page restent éditables en back-office. Il ne compose pas de message,
et aucune fonction ne lève : un e-mail qui ne part pas ne doit jamais faire
échouer un règlement, un remboursement ni une expédition.

Codes utilisés — order_confirmation, payment_received, order_admin_new,
payment_failed, order_shipped, order_completed, order_cancelled, order_refunded.
"""

import logging

from django.urls import NoReverseMatch, reverse
from django.utils.html import escape

from jeiko.emailing.render import site_base_url
from jeiko.emailing.sending import admin_recipients
from jeiko.emailing.services import send_email

logger = logging.getLogger(__name__)


# =========================
#  Mise en forme
# =========================

def _absolute(path):
    base = site_base_url()
    return f"{base}{path}" if base else path


def _montant(valeur, devise="EUR"):
    """Montant lisible. La devise est celle figée sur la commande."""
    return f"{valeur:.2f} {devise}".strip()


def _numero(order):
    """
    Numéro présenté au client.

    Le modèle ne porte pas de référence dédiée : la clé primaire fait office de
    numéro de commande, préfixée pour qu'elle se lise comme telle.
    """
    return f"#{order.pk}"


def _destinataire(order):
    """
    Adresse du client.

    Le compte fait foi — le tunnel de commande exige désormais un compte, donc
    cette adresse existe toujours pour une commande passée normalement.
    """
    return getattr(order.user, "email", "") or ""


def _client_nom(order):
    if order.billing_name:
        return order.billing_name
    user = order.user
    if not user:
        return ""
    return (user.get_full_name() or user.get_username() or "").strip()


def _prenom(order):
    return (_client_nom(order) or "").split(" ")[0]


def _bloc_lignes(order):
    """
    Tableau HTML des articles, injecté tel quel dans le corps de l'e-mail.

    Les valeurs sont échappées une à une : un intitulé de produit vient de
    l'administration, et le rendu e-mail marque ce bloc sûr. Le style est en
    ligne, comme tout le reste du rendu e-mail (les clients de messagerie
    ignorent les feuilles externes).
    """
    # Les chiffres à droite et d'un seul tenant : sur téléphone, « 129.00 EUR »
    # passait sur deux lignes, et la colonne ne s'alignait ni sur son en-tête
    # ni d'une ligne à l'autre (26/10/2026).
    cellule = 'style="padding:8px 10px;border-bottom:1px solid #e5e7eb;text-align:left;"'
    chiffre = (
        'style="padding:8px 10px;border-bottom:1px solid #e5e7eb;'
        'text-align:right;white-space:nowrap;"'
    )
    entete = (
        'style="padding:8px 10px;border-bottom:2px solid #111;'
        'text-align:left;font-weight:700;"'
    )
    entete_chiffre = (
        'style="padding:8px 10px;border-bottom:2px solid #111;'
        'text-align:right;font-weight:700;white-space:nowrap;"'
    )

    lignes = [
        "<table role='presentation' cellpadding='0' cellspacing='0' "
        "style='width:100%;border-collapse:collapse;font-size:14px;'>",
        f"<tr><th {entete}>Article</th><th {entete_chiffre}>Qté</th>"
        f"<th {entete_chiffre}>Prix</th></tr>",
    ]
    # Montants TTC : la ligne « Total » l'est, et c'est ce que le client paie.
    # Le tableau montrait le HT des lignes sous un total TTC.
    for ligne in order.lines.all():
        lignes.append(
            f"<tr><td {cellule}>{escape(ligne.label or ligne.sku or '')}</td>"
            f"<td {chiffre}>{ligne.quantity}</td>"
            f"<td {chiffre}>{escape(_montant(ligne.total_ttc, order.currency))}</td></tr>"
        )
    if order.discount_ttc:
        lignes.append(
            f"<tr><td {cellule} colspan='2'>Code {escape(order.coupon_code)}</td>"
            f"<td {chiffre}>− {escape(_montant(order.discount_ttc, order.currency))}</td></tr>"
        )
    if order.shipping_method or order.shipping_ttc:
        lignes.append(
            f"<tr><td {cellule} colspan='2'>Livraison"
            f"{(' — ' + escape(order.shipping_method)) if order.shipping_method else ''}</td>"
            f"<td {chiffre}>{escape(_montant(order.shipping_ttc, order.currency))}</td></tr>"
        )
    lignes.append(
        f"<tr><td {cellule} colspan='2'><strong>Total</strong></td>"
        f"<td {chiffre}><strong>"
        f"{escape(_montant(order.total_ttc, order.currency))}</strong></td></tr>"
    )
    lignes.append("</table>")
    return "".join(lignes)


def _lien_commande(order):
    try:
        return _absolute(reverse("jeiko_users_client:order_detail", args=[order.pk]))
    except NoReverseMatch:
        return ""


def _lien_admin(order):
    try:
        return _absolute(
            reverse("jeiko_shop_admin_orders:order_update", args=[order.pk])
        )
    except NoReverseMatch:
        return ""


def _contexte(order):
    """Contexte commun à tous les e-mails de commande."""
    return {
        "prenom": _prenom(order),
        "commande_num": _numero(order),
        "commande_date": order.created_at.strftime("%d/%m/%Y"),
        "commande_total": _montant(order.total_ttc, order.currency),
        "montant": _montant(order.total_ttc, order.currency),
        "lien_action": _lien_commande(order),
    }


# =========================
#  Envois
# =========================

def send_order_paid_emails(order):
    """
    Confirmation + reçu au client, notification à l'exploitant.

    Appelé après COMMIT par `shop.services.mark_order_paid`, pour ne pas
    annoncer une commande qu'une transaction annulée effacerait.
    """
    contexte = _contexte(order)
    client = _destinataire(order)

    if client:
        confirmation = dict(contexte)
        confirmation["bloc_lignes"] = _bloc_lignes(order)
        confirmation["adresse_livraison"] = (
            order.shipping_block or order.billing_block or ""
        )
        send_email("order_confirmation", client, confirmation, user=order.user)

        recu = dict(contexte)
        recu["moyen_paiement"] = "Carte bancaire"
        recu["lien_facture"] = contexte["lien_action"]
        # La facture en PDF (D-10) ; sans moteur, l'e-mail part sans elle —
        # le lien vers la facture imprimable reste.
        from .facturation import piece_jointe_facture

        try:
            facture = piece_jointe_facture(order)
        except Exception:
            logger.exception("Facture PDF impossible pour la commande #%s", order.pk)
            facture = None
        send_email("payment_received", client, recu, user=order.user,
                   attachments=[facture] if facture else None)
    else:
        logger.warning(
            "Commande #%s réglée sans adresse client : aucun e-mail envoyé.",
            order.pk,
        )

    destinataires = admin_recipients()
    if destinataires:
        interne = dict(contexte)
        interne["client_nom"] = _client_nom(order)
        interne["client_email"] = client
        interne["bloc_lignes"] = _bloc_lignes(order)
        interne["lien_action"] = _lien_admin(order)
        send_email("order_admin_new", destinataires, interne)


def send_payment_failed_email(order, motif=""):
    """Échec de paiement : on rend au client le moyen de reprendre."""
    client = _destinataire(order)
    if not client:
        return

    contexte = _contexte(order)
    contexte["motif"] = motif or "Le paiement n'a pas abouti."
    try:
        contexte["lien_action"] = _absolute(
            reverse("jeiko_payments_client:checkout")
        )
    except NoReverseMatch:
        pass
    send_email("payment_failed", client, contexte, user=order.user)


def send_order_shipped_email(order):
    """
    Expédition, avec le transporteur et le suivi saisis sur la commande.

    La date de livraison estimée reste vide : rien ne la porte.
    """
    client = _destinataire(order)
    if not client:
        return

    contexte = _contexte(order)
    contexte.update({
        "transporteur": order.carrier,
        "numero_suivi": order.tracking_number,
        "lien_suivi": order.tracking_url,
        "date_livraison_estimee": "",
    })
    send_email("order_shipped", client, contexte, user=order.user)


def send_order_completed_email(order):
    client = _destinataire(order)
    if not client:
        return

    contexte = _contexte(order)
    contexte["bloc_lignes"] = _bloc_lignes(order)
    # « Lien vers le formulaire d'avis », promis par le catalogue : la fiche
    # du premier article, à l'ancre des avis, quand la boutique en recueille.
    from .models import ShopSettings

    premiere = order.lines.select_related("product").first()
    if ShopSettings.get_solo().reviews_enabled and premiere and premiere.product:
        contexte["lien_action"] = _absolute(premiere.product.get_absolute_url() + "#avis")
    send_email("order_completed", client, contexte, user=order.user)


def send_order_cancelled_email(order, motif=""):
    client = _destinataire(order)
    if not client:
        return

    contexte = _contexte(order)
    contexte["motif"] = motif or "Commande annulée."
    send_email("order_cancelled", client, contexte, user=order.user)


def send_order_refunded_email(order, montant=None):
    """`montant` : celui de CE remboursement, qui peut être partiel."""
    client = _destinataire(order)
    if not client:
        return

    contexte = _contexte(order)
    if montant is not None:
        contexte["montant"] = _montant(montant, order.currency)
    contexte["moyen_paiement"] = "Carte bancaire"
    contexte["delai"] = "sous 5 à 10 jours ouvrés"
    send_email("order_refunded", client, contexte, user=order.user)
