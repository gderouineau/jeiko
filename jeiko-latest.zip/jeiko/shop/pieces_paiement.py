"""
Payer une facture en ligne, par carte (FACT-01).

Sur le lien du client, une facture émise et pas soldée propose « Payer en
ligne » : une intention Stripe pour le RESTE à payer, Stripe Elements sur la
page — le même chemin que les rendez-vous payants (`calendars.payments`).

« Un paiement reçu émet la facture » (réglage, actif par défaut) : depuis un
devis accepté en ligne, le client paie la facture BROUILLON née du devis ; le
paiement l'émet, puis l'enregistre comme réglée.

Ce qui fait foi
---------------
Jamais le navigateur : le retour du client interroge Stripe, le webhook
confirme de son côté (`payments.webhooks.stripe`). Les deux passent par
`confirmer`, idempotent — un règlement porte l'identifiant de l'intention, et
la même intention n'est jamais comptée deux fois. Le montant et la devise
reçus doivent être ceux qu'on attendait ; sinon on n'enregistre rien et on
prévient l'exploitant.
"""

import logging

from django.db import transaction

from . import pieces
from .models import PieceDeVente, Reglement, ShopSettings

logger = logging.getLogger(__name__)

METADATA = "jeiko_piece_id"


class PaiementIndisponible(Exception):
    """Pas de passerelle active, ou rien à payer."""


def a_payer(piece):
    """
    La facture que ce lien permet de payer, ou None : la facture elle-même si
    elle attend un règlement ; pour un devis accepté, sa facture brouillon —
    si le réglage laisse le paiement l'émettre.
    """
    if piece.nature == PieceDeVente.FACTURE and piece.etat in (PieceDeVente.EMISE, PieceDeVente.PAYEE_EN_PARTIE) \
            and piece.reste_a_payer > 0:
        return piece
    if piece.nature == PieceDeVente.DEVIS and piece.etat == PieceDeVente.TRANSFORME \
            and ShopSettings.get_solo().auto_issue_on_payment:
        return piece.suites.filter(nature=PieceDeVente.FACTURE, etat=PieceDeVente.BROUILLON,
                                   type_facture__in=(PieceDeVente.NORMALE, PieceDeVente.SOLDE)).first()
    return None


def montant_attendu(facture):
    return facture.reste_a_payer if facture.numero else facture.total_ttc


def ouvrir(facture):
    """(client_secret, clé publique) d'une intention pour cette facture."""
    from jeiko.calendars.payments import get_gateway
    from jeiko.payments.services.stripe import StripeService

    gateway = get_gateway()
    if not gateway or not gateway.secret_key or not gateway.api_key:
        raise PaiementIndisponible("Aucune passerelle de paiement active.")
    montant = montant_attendu(facture)
    if montant <= 0:
        raise PaiementIndisponible("Rien à payer.")
    intention = StripeService().create_payment_intent(
        amount=montant, currency=facture.devise.lower(),
        metadata={METADATA: str(facture.pk), "jeiko_piece_numero": facture.numero or ""},
        # La même facture, le même reste dû : la même intention (F03).
        idempotency_key=StripeService.cle_d_idempotence("piece", facture.pk, montant, facture.devise),
    )
    secret = intention.get("client_secret") if isinstance(intention, dict) else getattr(intention, "client_secret", None)
    return secret, gateway.api_key


def confirmer(intention):
    """
    Enregistre le paiement d'une intention réussie. Rend la facture, ou None
    si l'intention ne désigne pas une pièce, n'a pas abouti, ou ne correspond
    pas au montant attendu.
    """
    from jeiko.shop.services import to_minor_units

    piece_id = (intention.get("metadata") or {}).get(METADATA)
    if not piece_id or intention.get("status") != "succeeded":
        return None
    identifiant = intention.get("id") or ""
    with transaction.atomic():
        facture = PieceDeVente.objects.select_for_update().filter(pk=piece_id, nature=PieceDeVente.FACTURE).first()
        if facture is None:
            logger.error("Paiement %s : pièce %s introuvable.", identifiant, piece_id)
            return None
        if Reglement.objects.filter(piece=facture, reference=identifiant).exists():
            return facture  # déjà compté : le webhook et le retour client se croisent
        recu = intention.get("amount_received") or intention.get("amount")
        attendu = to_minor_units(montant_attendu(facture), facture.devise)
        if recu != attendu or (intention.get("currency") or "").lower() != facture.devise.lower():
            _signaler(facture, intention, attendu)
            return None
        if not facture.numero:
            facture = pieces.emettre(facture)
        pieces.enregistrer_reglement(facture, montant_attendu(facture), Reglement.CARTE, reference=identifiant)
    return facture


def confirmer_par_identifiant(identifiant):
    """Le retour du client : on relit l'intention chez Stripe, jamais dans l'adresse."""
    import stripe

    from jeiko.calendars.payments import get_gateway

    gateway = get_gateway()
    if not gateway or not identifiant:
        return None
    stripe.api_key = gateway.secret_key
    try:
        intention = stripe.PaymentIntent.retrieve(identifiant)
    except Exception:
        logger.exception("Lecture du paiement %s impossible", identifiant)
        return None
    return confirmer(intention)


def _signaler(facture, intention, attendu):
    logger.error("Paiement %s non conforme pour la pièce %s : %s reçu, %s attendu.",
                 intention.get("id"), facture.pk, intention.get("amount_received"), attendu)
    try:
        from jeiko.emailing.admin_alerts import notifier_erreur

        notifier_erreur(
            "Paiement de facture non conforme",
            f"Le paiement {intention.get('id')} sur {facture} ne correspond pas au montant attendu "
            f"({attendu} centimes) : rien n'a été enregistré. À vérifier dans Stripe.",
        )
    except Exception:
        logger.exception("Alerte de paiement non conforme impossible")
