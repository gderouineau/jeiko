"""
Envoyer un devis ou une facture, et relancer les factures impayées (FACT-01).

L'e-mail porte le PDF en pièce jointe (s'il y a un moteur PDF sur le serveur)
et le lien du client, qui s'ouvre sans compte. Sans adresse e-mail, rien ne
part : l'appelant le dit à l'écran.

La relance passe chaque jour (`cron_24h`) : une facture émise, pas soldée,
relances actives — sur le site ET sur la facture —, dont l'échéance est
dépassée d'un des jours réglés (0,7,15 par défaut). Une relance envoyée est
comptée et datée : la même ne repart pas deux fois le même jour, et un jour
manqué (serveur arrêté) est rattrapé au passage suivant.
"""

import logging

from django.urls import reverse
from django.utils import timezone

from .models import PieceDeVente, ShopSettings

logger = logging.getLogger(__name__)


def _montant(valeur, devise):
    return f"{valeur:.2f} {devise}".replace(".", ",")


def lien_du_client(piece):
    from jeiko.emailing.render import site_base_url

    chemin = reverse("jeiko_client_shop:piece_publique", args=[piece.jeton])
    base = site_base_url()
    return f"{base}{chemin}" if base else chemin


def _piece_jointe(piece):
    from jeiko.pdf import moteur as pdf

    from .views.pieces import contexte_document

    try:
        octets = pdf.gabarit_en_pdf("shop/piece.html", {**contexte_document(piece, en_pdf=True), "en_pdf": True})
    except pdf.MoteurPDFAbsent:
        return None
    except Exception:
        logger.exception("PDF impossible pour la pièce %s", piece.pk)
        return None
    return (f"{piece.get_nature_display()}-{piece.numero}.pdf", octets, "application/pdf")


def envoyer(piece):
    """Envoie la pièce émise à son client. Rend True si l'e-mail est parti."""
    from jeiko.emailing.services import send_email

    if not piece.numero or not piece.client_email:
        return False
    code = "quote_sent" if piece.nature == PieceDeVente.DEVIS else "invoice_sent"
    contexte = {
        "client_nom": piece.client_nom, "piece_num": piece.numero, "piece_objet": piece.objet,
        "montant": _montant(piece.total_ttc, piece.devise),
        "validite": piece.date_validite.strftime("%d/%m/%Y") if piece.date_validite else "",
        "echeance": piece.date_echeance.strftime("%d/%m/%Y") if piece.date_echeance else "",
        "lien_action": lien_du_client(piece),
    }
    jointe = _piece_jointe(piece)
    send_email(code, piece.client_email, contexte, attachments=[jointe] if jointe else None)
    return True


def jours_de_relance(reglages):
    return sorted({int(j) for j in (reglages.reminder_days or "").split(",") if j.strip().isdigit()})


def relancer_les_factures(aujourd_hui=None):
    """La tournée quotidienne des relances. Rend le nombre d'e-mails partis."""
    from jeiko.emailing.services import send_email

    reglages = ShopSettings.get_solo()
    if not reglages.invoice_reminders:
        return 0
    aujourd_hui = aujourd_hui or timezone.localdate()
    jours = jours_de_relance(reglages)
    parties = 0
    factures = PieceDeVente.objects.filter(
        nature=PieceDeVente.FACTURE, etat__in=(PieceDeVente.EMISE, PieceDeVente.PAYEE_EN_PARTIE),
        relances_actives=True, date_echeance__isnull=False, date_echeance__lte=aujourd_hui,
    ).exclude(client_email="")
    for facture in factures:
        retard = (aujourd_hui - facture.date_echeance).days
        dues = sum(1 for j in jours if j <= retard)
        if facture.relances_envoyees >= dues or facture.derniere_relance == aujourd_hui:
            continue
        send_email("invoice_reminder", facture.client_email, {
            "client_nom": facture.client_nom, "piece_num": facture.numero,
            "montant": _montant(facture.reste_a_payer, facture.devise),
            "echeance": facture.date_echeance.strftime("%d/%m/%Y"),
            "lien_action": lien_du_client(facture),
        })
        facture.relances_envoyees = dues
        facture.derniere_relance = aujourd_hui
        facture.save(update_fields=["relances_envoyees", "derniere_relance"])
        parties += 1
    return parties
