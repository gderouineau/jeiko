from decimal import Decimal

from django import forms

from .models import (
    ProductType,
    Product,
    ProductImage,
)
from jeiko.custom_objects.models import CustomObject
from jeiko.administration_pages.models import Page

from jeiko.custom_objects.forms import CustomObjectForm as BaseCustomObjectForm


class ProductTypeForm(forms.ModelForm):
    # Champ "virtuel" : sert à créer / mettre à jour le CustomObjectModel
    page_template = forms.ModelChoiceField(
        queryset=Page.objects.filter(is_custom_object_template=True),
        required=True,
        label="Template de page produit",
        help_text="Page gabarit utilisée pour afficher les produits de ce type."
    )

    class Meta:
        model = ProductType
        fields = [
            "name",
            "code",
            "kind",
            "default_tax_rate",
            "default_currency",
            "is_physical",
            "requires_shipping",
            "is_subscription",
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Si on est en édition et qu'un CustomObjectModel existe déjà,
        # on pré-remplit page_template avec celui de ce modèle.
        instance = getattr(self, "instance", None)
        if instance and instance.pk and instance.content_model:
            self.fields["page_template"].initial = instance.content_model.page_template



class ProductForm(forms.ModelForm):
    """
    Formulaire produit relié à ProductType.
    Le CustomObject (contenu) est géré par ProductCustomObjectForm.
    """

    class Meta:
        model = Product
        fields = [
            "type",              # sera figé depuis l'URL (product_type)
            # "content",         # ⚠️ plus exposé ici, géré en coulisse
            "sku",
            "is_active",
            "price_ht",
            "tax_rate",
            "currency",
            "stock_quantity",
            "allow_negative_stock",
            "weight_kg",
            "linked_expert_test",
            "linked_appointment_type",
            "credits_amount",
        ]

    def __init__(self, *args, **kwargs):
        # On accepte un kwarg supplémentaire product_type pour simplifier
        self.product_type = kwargs.pop("product_type", None)
        super().__init__(*args, **kwargs)

        # --------- Type ---------
        if self.product_type is not None:
            self.fields["type"].initial = self.product_type
            self.fields["type"].widget = forms.HiddenInput()
            self.fields["type"].disabled = True

        # --------- Defaults basés sur le ProductType ---------
        instance = getattr(self, "instance", None)
        effective_type = self.product_type or getattr(instance, "type", None)

        if effective_type and not self.initial.get("tax_rate"):
            self.initial.setdefault("tax_rate", effective_type.default_tax_rate)
        if effective_type and not self.initial.get("currency"):
            self.initial.setdefault("currency", effective_type.default_currency)

        # --------- Masquage conditionnel des champs selon le kind ---------
        if effective_type:
            kind = effective_type.kind
            
            # Questionnaire
            if kind != ProductType.KIND_QUESTIONNAIRE:
                self.fields.pop("linked_expert_test", None)
            
            # Appointment / Credits
            if kind != ProductType.KIND_APPOINTMENT:
                self.fields.pop("linked_appointment_type", None)
                self.fields.pop("credits_amount", None)
            
            # Physical (weight)
            if kind != ProductType.KIND_PHYSICAL:
                # On peut garder weight_kg pour tous ou le masquer. 
                # Le user a dit "produit physique ok", mais pour un service ça sert à rien.
                # On le laisse pour l'instant ou on le masque si tu veux être strict.
                pass

    def clean(self):
        cleaned_data = super().clean()

        # Forcer le type depuis product_type si présent
        if self.product_type is not None:
            cleaned_data["type"] = self.product_type

        ptype = cleaned_data.get("type")
        if ptype:
            # Si tax_rate est vide, on reprend celui du type
            tax_rate = cleaned_data.get("tax_rate")
            if tax_rate in (None, ""):
                cleaned_data["tax_rate"] = ptype.default_tax_rate

            # Si currency est vide, on reprend la devise du type
            currency = cleaned_data.get("currency")
            if not currency:
                cleaned_data["currency"] = ptype.default_currency

        return cleaned_data

    def clean_tax_rate(self):
        value = self.cleaned_data.get("tax_rate")
        if value is None:
            # On laisse clean() gérer l’héritage depuis ProductType
            return value
        if value < 0 or value > 100:
            raise forms.ValidationError("La TVA doit être comprise entre 0 et 100%.")
        return value

    def clean_price_ht(self):
        value = self.cleaned_data.get("price_ht")
        if value is None:
            raise forms.ValidationError("Le prix HT est requis.")
        if value < 0:
            raise forms.ValidationError("Le prix HT ne peut pas être négatif.")
        return value

    def clean_stock_quantity(self):
        value = self.cleaned_data.get("stock_quantity")
        if value is None:
            return 0
        return value



class ProductCustomObjectForm(BaseCustomObjectForm):
    """
    Version simplifiée de CustomObjectForm pour l'écran Produit :
    - on ne montre pas le champ `model`, il sera imposé selon le ProductType
    """

    class Meta(BaseCustomObjectForm.Meta):
        model = BaseCustomObjectForm.Meta.model
        # On garde le trio de base ; on rajoutera d’autres champs plus tard si tu veux
        fields = ["title", "slug", "is_published", "main_image"]
        widgets = {
            "title": BaseCustomObjectForm.Meta.widgets["title"],
            "slug": BaseCustomObjectForm.Meta.widgets["slug"],
            "is_published": BaseCustomObjectForm.Meta.widgets["is_published"],
            "main_image": BaseCustomObjectForm.Meta.widgets["main_image"],
        }

    def __init__(self, *args, **kwargs):
        self.content_model = kwargs.pop("content_model", None)
        super().__init__(*args, **kwargs)
        # On s’assure que le champ `model` ne soit pas manipulable dans ce form
        if "model" in self.fields:
            self.fields.pop("model")

    def clean_slug(self):
        from django.utils.text import slugify
        slug = self.cleaned_data.get("slug") or self.cleaned_data.get("title")
        return slugify(slug or "")

    def save(self, commit=True):
        obj = super().save(commit=False)
        # À la création, on impose le bon CustomObjectModel
        if self.content_model and not obj.pk:
            obj.model = self.content_model
        if commit:
            obj.save()
        return obj


class ProductImageForm(forms.ModelForm):
    """
    Formulaire simple pour les images de produit.
    Utile pour un inline formset dans l’admin (quand on fera les views).
    """

    class Meta:
        model = ProductImage
        fields = [
            "image",
            "is_main",
            "position",
        ]
