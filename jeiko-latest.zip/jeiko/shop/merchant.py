# jeiko/shop/merchant.py
"""
GMC-01 — Google Merchant Center, expliqué et vérifié depuis JEIKO.

Le flux (`/shop/flux/google.xml`, `GoogleFeedView`) existait et se tenait à
jour seul, mais rien ne disait quoi en faire ni ce que Google en refuserait.
On l'apprenait des jours plus tard, dans les diagnostics de Merchant Center.

Ce module relit ce que le flux PUBLIE — mêmes produits (`produits_publics`),
mêmes données (`donnees_produit`), même règle pour le prix nul — et dit, par
produit, ce qui sera refusé ou à revoir. Il ne réimplémente pas le flux : un
écart entre les deux se verrait dans le test qui les compare.

Ce qu'il ne fait pas : interroger Merchant Center (il faudrait un compte de
service et l'API Content), ni juger une image (taille, filigrane) ou un
titre. Il voit ce que le site sait ; Google voit le reste.
"""
from django.urls import reverse
from django.utils.translation import gettext as _

DOCUMENTATION = "https://jeiko.fr/documentation/google-merchant-center/"

#: Ce que Merchant Center coupe : au-delà, le titre est tronqué.
TITRE_MAX = 150


def _url_admin(produit):
    return reverse("jeiko_administration_shop:product_update", args=[produit.type_id, produit.pk])


def examiner(produit, d, articles):
    """
    (statut, raisons) d'un produit : statut « exclu » (n'entre pas dans le
    flux), « refuse » (y entre, Google le refusera), « attention » ou « ok ».
    """
    exclu, refuse, attention = [], [], []
    if not any(a["prix"] for a in articles):
        exclu.append(_("Prix nul : un article gratuit n'entre pas dans le flux, Google refuse les prix nuls."))
    if not d["image"]:
        refuse.append(_("Pas d'image : Google refuse un article sans image."))
    if not d["description"].strip():
        attention.append(_("Pas de description : le titre en tient lieu, Google la juge alors trop pauvre."))
    if any(len(a["titre"]) > TITRE_MAX for a in articles):
        attention.append(_("Titre de plus de 150 caractères : Google le coupe."))
    if not (d["marque"] or "").strip():
        attention.append(_("Pas de marque : ni sur le produit, ni le nom du site dans Réglages › Identité."))
    if getattr(produit.type, "requires_shipping", False) and not d["livraison"]:
        attention.append(_("Expédié, mais aucune zone de livraison avec un pays n'est réglée (Boutique › Réglages) : "
                           "les frais déclarés dans Merchant Center ne pourront pas être comparés à ceux du site."))
    statut = "exclu" if exclu else "refuse" if refuse else "attention" if attention else "ok"
    return statut, exclu + refuse + attention


def etat(request):
    """Tout ce que l'écran et l'API disent : le flux, le site, chaque produit."""
    from .lisible import _retours, _vendeur, base_url, donnees_produit, produits_publics
    from .models import ShopSettings

    reglages = ShopSettings.get_solo()
    base = base_url(request)
    produits = []
    for produit in produits_publics():
        d = donnees_produit(produit, base + produit.get_absolute_url(), base)
        articles = ([{"titre": f"{d['titre']} — {v['libelle']}", "prix": v["prix_ttc"]} for v in d["declinaisons"]]
                    or [{"titre": d["titre"], "prix": d["prix_ttc"]}])
        statut, raisons = examiner(produit, d, articles)
        produits.append({"id": produit.pk, "sku": d["sku"], "titre": d["titre"], "statut": statut,
                         "raisons": raisons, "articles": len(articles), "adresse": d["url"],
                         "administration": _url_admin(produit)})
    _marque, identite = _vendeur()
    site = []
    if not reglages.is_online:
        site.append(_("La boutique est hors ligne (Boutique › Réglages) : le flux répond « introuvable » à Google."))
    if not _retours(reglages, identite):
        site.append(_("Aucune durée de retour n'est réglée (Boutique › Réglages) : Merchant Center exige une politique de retour."))
    if not produits:
        site.append(_("Aucun produit en vente avec une fiche publiée : le flux est vide."))
    compte = {s: sum(1 for p in produits if p["statut"] == s) for s in ("ok", "attention", "refuse", "exclu")}
    return {
        "flux": base + reverse("jeiko_client_shop:google_feed"),
        "en_ligne": reglages.is_online,
        "site": site,
        "compte": compte,
        "produits": produits,
        "documentation": DOCUMENTATION,
    }
