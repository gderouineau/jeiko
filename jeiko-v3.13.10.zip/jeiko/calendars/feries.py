"""
Les jours fériés ferment les créneaux du praticien (retour client du 17/11/2026).

Chaque praticien choisit, dans Réglages des rendez-vous, un pays — ou une
région, quand elle a ses propres fériés (Moselle et Alsace, DOM, Länder,
cantons…). Vide par défaut : un site en service ne voit pas ses créneaux se
fermer sans l'avoir demandé.

Les dates viennent de la bibliothèque `holidays`, calculées sur place : aucun
service tiers n'est interrogé. Un férié ferme la journée entière, de minuit à
minuit dans le fuseau du site — comme un événement « occupé » de l'agenda
Google, il passe par `periodes_occupees`. Ce qui n'est PAS fait : les ponts,
les fermetures propres au cabinet (une disponibilité, ou ses dates à exclure,
s'en charge), ni le refus d'un rendez-vous posé à la main par le praticien un
jour férié — c'est son choix.
"""
from datetime import datetime, time, timedelta
from functools import lru_cache

from django.utils import timezone


@lru_cache(maxsize=1)
def choix():
    """[(code, libellé)] : « FR », puis ses régions « FR/57 » (France — Moselle).

    Le nom du pays est posé par le navigateur (Intl.DisplayNames), dans la
    langue de l'écran ; celui de la région vient de la bibliothèque."""
    import holidays

    out = []
    for pays, regions in sorted(holidays.list_supported_countries().items()):
        if len(pays) != 2:  # la bibliothèque donne aussi les codes à trois lettres
            continue
        out.append((pays, pays))
        noms = {}
        try:
            for nom, code in holidays.country_holidays(pays).subdivisions_aliases.items():
                noms.setdefault(code, nom)
        except Exception:  # noqa: BLE001 — un pays sans alias garde ses codes
            pass
        out += [(f"{pays}/{r}", f"{pays} — {noms.get(r, r)}") for r in regions]
    return out


def jours_feries(reglage, du, au):
    """Les dates fériées entre `du` et `au` (dates incluses) pour « FR » ou « FR/57 »."""
    if not reglage:
        return set()
    import holidays

    pays, __, region = reglage.partition("/")
    try:
        calendrier = holidays.country_holidays(pays, subdiv=region or None, years=range(du.year, au.year + 1))
    except NotImplementedError:  # pays ou région retirés de la bibliothèque
        return set()
    return {j for j in calendrier if du <= j <= au}


def periodes_feriees(user_id, debut, fin):
    """[(début, fin)] des jours fériés du praticien qui touchent [début, fin]."""
    from .models import GoogleCalendarConfig

    reglage = (GoogleCalendarConfig.objects.filter(user_id=user_id)
               .values_list("feries", flat=True).first())
    if not reglage:
        return []
    fuseau = timezone.get_current_timezone()
    jours = jours_feries(reglage, timezone.localtime(debut, fuseau).date(),
                         timezone.localtime(fin, fuseau).date())
    return [(timezone.make_aware(datetime.combine(j, time.min), fuseau),
             timezone.make_aware(datetime.combine(j + timedelta(days=1), time.min), fuseau))
            for j in sorted(jours)]
