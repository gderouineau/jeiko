# jeiko/agents/migrations/0022_agent_menus_supprime.py
"""
Rôle « Agent menus » : la suppression d'un menu (Guillaume, 13/11/2026 —
« il faut vraiment pouvoir tout faire sur les menus »).

0009 l'avait refusée : un menu supprimé laissait sans navigation les
catégories qui le portaient. L'API ne supprime plus qu'un menu qui ne SERT
plus — ni menu par défaut, ni porté par une catégorie (`agents/vues_menus.py`) :
le danger qui justifiait le refus n'existe plus par cette route.

Ajoute `delete_menu` et `delete_menuitem` au rôle, et dit-le dans sa
description. Permissions forcées d'abord : le piège réparé par 0011.
"""
from django.db import migrations

SLUG = "agent-menus"
AJOUTS = ("delete_menu", "delete_menuitem")
DESCRIPTION = (
    "Permet à un agent de construire les menus, leur apparence, et de les affecter aux catégories, "
    "ce qui permet des sous-sites ; de supprimer un menu qui ne sert plus (ni par défaut, ni porté "
    "par une catégorie)."
)


def ajouter(apps, schema_editor):
    from django.apps import apps as registre_reel
    from django.contrib.auth.management import create_permissions

    create_permissions(registre_reel.get_app_config("administration_menu"), verbosity=0)
    role = apps.get_model("users", "Role").objects.filter(slug=SLUG).first()
    if role is None:
        return
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")
    for codename in AJOUTS:
        permission = Permission.objects.filter(
            codename=codename, content_type__app_label="administration_menu").first()
        if permission is not None:
            RolePermission.objects.get_or_create(role=role, permission=permission)
    role.description = DESCRIPTION
    role.save(update_fields=["description"])


def retirer(apps, schema_editor):
    role = apps.get_model("users", "Role").objects.filter(slug=SLUG).first()
    if role is not None:
        apps.get_model("users", "RolePermission").objects.filter(
            role=role, permission__codename__in=AJOUTS,
            permission__content_type__app_label="administration_menu").delete()


class Migration(migrations.Migration):
    dependencies = [
        ("jeiko_agents", "0021_role_agent_newsletter"),
        ("administration_menu", "0022_menus_modernes"),
        ("users", "0001_initial"),
    ]
    operations = [migrations.RunPython(ajouter, retirer)]
