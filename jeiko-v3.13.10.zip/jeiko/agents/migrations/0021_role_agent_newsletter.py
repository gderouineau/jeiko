# jeiko/agents/migrations/0021_role_agent_newsletter.py
"""
Rôle « Agent newsletter » — créer et modifier les listes de diffusion
(Guillaume, 04/11/2026).

Pourquoi un rôle à part
-----------------------
Un assistant à qui l'on demandait de créer la liste « Mon réseau » répondait
qu'il n'en avait pas le droit : les routes des listes exigeaient de pouvoir
modifier TOUTES les fiches du CRM, et aucun rôle livré n'était fait pour la
newsletter. Celui-ci ouvre les listes, et rien d'autre.

Ce qu'il porte : voir, créer et modifier une liste (`emailing.*_liste`), que
`agents/vues_newsletter.py` accepte à côté du droit CRM d'avant.

Ce qu'il ne porte pas : supprimer une liste, toucher aux abonnés ou aux
contacts, écrire ou ENVOYER une lettre — un envoi ne se reprend pas.

Peuplé dès sa création, permissions forcées d'abord : le piège réparé par 0011.
"""

from django.db import migrations

SLUG = "agent-newsletter"
NOM = "Agent newsletter"

PERMISSIONS = {
    "emailing": ("view_liste", "add_liste", "change_liste"),
}


def creer_le_role(apps, schema_editor):
    from django.apps import apps as registre_reel
    from django.contrib.auth.management import create_permissions

    for app_label in PERMISSIONS:
        create_permissions(registre_reel.get_app_config(app_label), verbosity=0)

    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role, _ = Role.objects.get_or_create(
        slug=SLUG,
        defaults={
            "name": NOM,
            "description": (
                "Permet à un agent de créer et modifier les listes de diffusion de la newsletter. "
                "N'autorise NI la suppression d'une liste, NI l'accès aux abonnés, NI l'envoi d'une lettre."
            ),
            "is_active": True,
        },
    )
    for app_label, codenames in PERMISSIONS.items():
        for codename in codenames:
            permission = Permission.objects.filter(
                codename=codename, content_type__app_label=app_label
            ).first()
            if permission is not None:
                RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer_le_role(apps, schema_editor):
    apps.get_model("users", "Role").objects.filter(slug=SLUG).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0020_application_mobile"),
        ("emailing", "0025_boite_de_reception"),
        ("users", "0001_initial"),
    ]

    operations = [migrations.RunPython(creer_le_role, retirer_le_role)]
