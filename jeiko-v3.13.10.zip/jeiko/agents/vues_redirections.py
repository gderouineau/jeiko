# jeiko/agents/vues_redirections.py
"""
Les anciennes adresses d'une page, par l'API (03/11/2026).

Pourquoi par l'API
------------------
Un site importé (WordPress, Shopify, Wix) arrive avec ses adresses, que
Google a indexées et que d'autres sites citent. Sans redirection, chacune
devient une 404 le jour de la bascule, et le référencement repart de zéro.
Le modèle `Redirection` et son middleware existaient (Q-20) ; il manquait le
moyen, pour l'outil de transfert, de les poser sans passer par l'écran.

Ce qu'on refuse, et pourquoi
----------------------------
On ne refuse que ce que le middleware ne servirait JAMAIS, pour qu'une
redirection acceptée soit une redirection qui marche :
  * une adresse sans « / » initial, ou avec un domaine : le middleware
    compare le CHEMIN de la requête ;
  * une adresse avec « ? » : il ignore la query string ;
  * une adresse sous /api/, /administration/… : il ne regarde pas là ;
  * l'adresse actuelle d'une page : une page qui existe l'emporte toujours.

Rejouer le même POST rend 200 sans doublon : un import interrompu se relance
du début sans qu'on trie ce qui était déjà passé.
"""

from urllib.parse import unquote

from django.db import transaction
from django.shortcuts import get_object_or_404

from jeiko.administration_pages import adresses
from jeiko.administration_pages.anciennes_adresses import PREFIXES_IGNORES
from jeiko.administration_pages.models import Page, Redirection

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

LIRE = "administration_pages.view_page"
MODIFIER = "administration_pages.change_page"


def _redirection_en_dict(redirection):
    return {
        "id": redirection.id,
        "adresse": redirection.adresse,
        "page_id": redirection.page_id,
        "creee_le": redirection.creee_le.isoformat() if redirection.creee_le else None,
        "utilisations": redirection.utilisations,
        "derniere_utilisation": (redirection.derniere_utilisation.isoformat()
                                 if redirection.derniere_utilisation else None),
    }


def adresse_d_ancienne_page(brute):
    """
    L'ancienne adresse telle que le middleware la comparera, ou un refus.

    Elle est DÉCODÉE (`%C3%A9` → `é`) : un export WordPress donne ses adresses
    encodées, alors que Django compare `request.path`, décodé. Stockée
    encodée, la redirection ne se déclencherait jamais.
    """
    if not isinstance(brute, str) or not brute.strip():
        raise CorpsInvalide("« adresse » est obligatoire : le chemin de l'ancienne page, « /ancien/chemin/ ».")
    adresse = brute.strip()
    if "://" in adresse or adresse.startswith("//"):
        raise CorpsInvalide(
            f"« adresse » : « {adresse} » porte un domaine. Donnez le chemin seul, "
            "« /ancien/chemin/ » : la redirection vaut pour le domaine du site.")
    if not adresse.startswith("/"):
        raise CorpsInvalide(f"« adresse » : « {adresse} » doit commencer par « / ».")
    if "?" in adresse or "#" in adresse:
        raise CorpsInvalide(
            f"« adresse » : « {adresse} » porte une query string (« ? ») ou une ancre (« # »). "
            "Les redirections comparent le chemin seul et ignorent la query string : "
            "« /article?id=12 » et « /article?id=13 » seraient une seule adresse. "
            "Donnez le chemin sans « ? ».")
    adresse = unquote(adresse)
    if any(c.isspace() for c in adresse):
        raise CorpsInvalide(f"« adresse » : « {adresse} » contient un espace.")
    longueur = Redirection._meta.get_field("adresse").max_length
    if len(adresse) > longueur:
        raise CorpsInvalide(f"« adresse » fait au plus {longueur} caractères.")
    if adresse.startswith(PREFIXES_IGNORES):
        raise CorpsInvalide(
            f"« adresse » : « {adresse} » est sous une adresse réservée au site "
            f"({', '.join(PREFIXES_IGNORES)}) : elle ne serait jamais redirigée.")
    return adresse


class RedirectionsDeLaPage(VueAgent):
    """Les anciennes adresses d'une page, redirigées vers elle en 301."""

    permission_requise = LIRE

    def get(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        return ok({"page_id": page.id, "url": page.adresse_propre(),
                   "redirections": [_redirection_en_dict(r) for r in page.redirections.all()]})

    @transaction.atomic
    def post(self, request, page_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification de page non autorisée.", statut=403,
                          permission_manquante=MODIFIER)
        page = get_object_or_404(Page, id=page_id)
        corps = self.corps(request, connues={"adresse"})
        adresse = adresse_d_ancienne_page(corps.get("adresse"))

        existante = Redirection.objects.select_related("page").filter(adresse=adresse).first()
        if existante is not None:
            if existante.page_id == page.id:
                # Rejouée : déjà là, rien à refaire.
                return ok({"redirection": _redirection_en_dict(existante), "creee": False})
            return erreur(
                f"« {adresse} » redirige déjà vers une autre page (nº {existante.page_id}, "
                f"« {existante.page.title} »). Une adresse ne mène qu'à une page : retirez "
                f"d'abord cette redirection-là (DELETE sur ses redirections).",
                statut=409, page_id=existante.page_id)

        occupante = adresses.page_a_cette_adresse(adresse)
        if occupante is not None:
            return erreur(
                f"« {adresse} » est l'adresse actuelle de la page nº {occupante.id} "
                f"(« {occupante.title} ») : la page l'emporterait, la redirection ne "
                f"servirait jamais.", statut=409, page_id=occupante.id)

        redirection = Redirection.objects.create(adresse=adresse, page=page)
        return ok({"redirection": _redirection_en_dict(redirection), "creee": True}, statut=201)

    @transaction.atomic
    def delete(self, request, page_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification de page non autorisée.", statut=403,
                          permission_manquante=MODIFIER)
        page = get_object_or_404(Page, id=page_id)
        corps = self.corps(request, connues={"adresse"})
        adresse = adresse_d_ancienne_page(corps.get("adresse"))
        retirees, _ = Redirection.objects.filter(page=page, adresse=adresse).delete()
        if not retirees:
            return erreur(f"La page nº {page.id} n'a pas de redirection depuis « {adresse} ».",
                          statut=404)
        return ok({"supprime": True, "adresse": adresse, "page_id": page.id})
