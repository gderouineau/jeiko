# jeiko/agents/push.py
"""
Réveiller l'application mobile quand il se passe quelque chose (APP-01) —
côté SITE. Le relais de jeiko.fr est dans `licences/relais_push.py`.

Ce qui part, et ce qui ne part pas
----------------------------------
La règle de Guillaume : aucun service tiers ne reçoit de données
personnelles. APNs (Apple) et FCM (Google) ne sont admis que parce que la
notification ne porte AUCUN contenu : un code d'événement (`commandes`,
`rendez_vous`…), le domaine du site et le nombre de la pastille. L'app
traduit le code (« Nouvelle commande sur exemple.fr »), puis lit le détail
par l'API, avec son jeton. Ni nom, ni montant, ni message ne quittent le site.

Les jetons push ne sont gardés QUE sur le site, sur le jeton de l'appareil
(`AgentToken.jeton_push`). Le relais les reçoit à chaque envoi et n'en garde
aucun.

Les événements
--------------
Cinq, branchés là où ils se produisent, chacun sur le code de notification
du menu qui le gouverne (`administration/notifications.py`) :

* commande payée — `shop.services.mark_order_paid` → `commandes` ;
* rendez-vous pris — `calendars.signals` (création) → `rendez_vous` ;
* rendez-vous annulé — `Appointment.cancel` → `rendez_vous_annule`, réglé
  par `rendez_vous` (c'est la même liste, et le même interrupteur) ;
* message de formulaire non indésirable — `administration_pages.views_api`
  → `messages` ;
* arrivée en salle d'attente — `visio.acces.entrer` → `visio_attente`.

On prévient les appareils des personnes qui VOIENT ce code
(`notifications.visibles` : droit de lecture, module allumé, notification
allumée dans Réglages › Général) et ne l'ont pas éteint dans l'app. Un
rendez-vous ne réveille que son gestionnaire, et qui supervise tous les
agendas — comme la pastille.

Sans ralentir la requête, et sans rien casser
---------------------------------------------
`prevenir` ne fait que s'inscrire après la transaction (`on_commit`) : une
transaction annulée n'annonce rien. L'envoi part ensuite dans un petit pool
de fond — le mécanisme des vues de page (`stats.middleware`), file bornée
comprise. Le relais lent, en panne ou injoignable : une ligne de journal, et
c'est tout. Rien ici ne lève.

Un jeton qu'Apple ou Google déclare désinscrit (application supprimée) revient
du relais : le site l'oublie.
"""

import logging
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlsplit

from django.conf import settings
from django.db import connections, transaction

logger = logging.getLogger(__name__)

#: Le code envoyé au téléphone → le code de notification qui le gouverne
#: (droit de le voir, interrupteur du site, réglage de l'app).
EVENEMENTS = {
    "commandes": "commandes",
    "rendez_vous": "rendez_vous",
    "rendez_vous_annule": "rendez_vous",
    "messages": "messages",
    "visio_attente": "visio_attente",
}

#: Un fil suffit : quelques envois par heure, chacun court.
_EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="jeiko-push")
#: File bornée, comme celle des vues de page : un relais bloqué ne doit pas
#: faire grossir la mémoire du worker sans fin. Au-delà, on renonce.
FILE_MAX = 200
_en_vol = 0
_dernier_avertissement = 0.0


def prevenir(code, *, gestionnaire_id=None):
    """
    À appeler DANS la transaction de l'événement. Ne lève jamais, ne bloque pas.

    `gestionnaire_id` : pour un rendez-vous, la personne dont c'est l'agenda.
    """
    if code not in EVENEMENTS:
        logger.error("Notification push inconnue : %s", code)
        return
    try:
        transaction.on_commit(lambda: _soumettre(code, gestionnaire_id))
    except Exception:
        logger.warning("Notification push « %s » non programmée", code, exc_info=True)


def _soumettre(code, gestionnaire_id):
    global _en_vol, _dernier_avertissement

    if _en_vol >= FILE_MAX:
        maintenant = time.monotonic()
        if maintenant - _dernier_avertissement > 60:
            _dernier_avertissement = maintenant
            logger.warning("File des notifications push saturée (%s) : envoi abandonné.", _en_vol)
        return
    _en_vol += 1
    try:
        _EXECUTOR.submit(_envoyer_en_fond, code, gestionnaire_id)
    except RuntimeError:
        # Pool arrêté (extinction du processus).
        _en_vol -= 1


def _envoyer_en_fond(code, gestionnaire_id):
    global _en_vol
    try:
        envoyer(code, gestionnaire_id)
    except Exception:
        logger.warning("Notification push « %s » non envoyée", code, exc_info=True)
    finally:
        _en_vol -= 1
        connections.close_all()


# --------------------------------------------------------------------------- #
#  Qui prévenir
# --------------------------------------------------------------------------- #
def destinataires(code, gestionnaire_id=None):
    """[(personne, [jetons d'appareil])] — ceux qui doivent être réveillés."""
    from jeiko.administration import notifications
    from jeiko.calendars.mixins import is_calendar_supervisor

    from . import app
    from .models import AgentToken

    reglage = EVENEMENTS[code]
    jetons = (AgentToken.objects
              .filter(agent__pour_l_app=True, agent__actif=True, revoque_le__isnull=True,
                      agent__proprietaire__is_active=True, plateforme__in=("ios", "android"))
              .exclude(jeton_push="")
              .select_related("agent__proprietaire").order_by("agent_id", "pk"))
    par_personne = {}
    for jeton in jetons:
        if jeton.agent.expire:
            continue
        par_personne.setdefault(jeton.agent.proprietaire, []).append(jeton)

    resultat = []
    for personne, siens in par_personne.items():
        if not app.peut_connecter(personne):
            continue
        if reglage not in set(notifications.visibles(personne)):
            continue
        if (siens[0].agent.reglages_push or {}).get(reglage) is False:
            continue
        if (reglage == "rendez_vous" and gestionnaire_id is not None
                and personne.pk != gestionnaire_id and not is_calendar_supervisor(personne)):
            continue
        resultat.append((personne, siens))
    return resultat


def domaine_du_site():
    """Le domaine que la licence connaît : celui de l'identité du site, sinon du .env."""
    from jeiko.licences.service import domaine_canonique

    try:
        from jeiko.administration.website_cache import get_website_data

        identite = getattr(get_website_data(), "identity", None)
        declaree = domaine_canonique(urlsplit((getattr(identite, "url", "") or "").strip()).hostname or "")
        if declaree:
            return declaree
    except Exception:
        logger.debug("Identité du site illisible", exc_info=True)
    for hote in getattr(settings, "ALLOWED_HOSTS", []):
        domaine = domaine_canonique(str(hote).lstrip("."))
        if domaine and domaine not in ("localhost", "127.0.0.1"):
            return domaine
    return ""


def charge(code, domaine, badge, jetons):
    """
    Ce que le site envoie au relais — et rien d'autre. Ni nom, ni montant, ni
    message : `tests/test_app.py` le vérifie champ par champ.
    """
    return {
        "domaine": domaine, "code": code, "badge": int(badge),
        "destinataires": [{"plateforme": j.plateforme, "jeton_push": j.jeton_push} for j in jetons],
    }


def envoyer(code, gestionnaire_id=None):
    """Prévient les destinataires de `code`, maintenant. Rend le nombre de personnes visées."""
    from jeiko.administration import notifications
    from jeiko.administration.models import WebSite
    from jeiko.reseaux.client import demander

    from .models import AgentToken

    cibles = destinataires(code, gestionnaire_id)
    if not cibles:
        return 0
    site = WebSite.objects.only("licence_cle").first()
    cle = getattr(site, "licence_cle", "") or ""
    domaine = domaine_du_site()
    if not cle or not domaine:
        logger.info("Notification push « %s » : pas de %s, rien n'est parti.", code,
                    "clé de licence" if not cle else "domaine connu")
        return 0
    for personne, jetons in cibles:
        badge = sum(notifications.compteurs(personne).values())
        reponse = demander("POST", "/api/relais-push/", cle, charge(code, domaine, badge, jetons))
        if reponse.get("erreur"):
            logger.warning("Relais push : %s", reponse["erreur"])
            continue
        desinscrits = [j for j in (reponse.get("desinscrits") or []) if isinstance(j, str) and j]
        if desinscrits:
            AgentToken.objects.filter(jeton_push__in=desinscrits).update(jeton_push="")
    return len(cibles)
