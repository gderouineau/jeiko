# jeiko/agents/vues_app.py
"""
Les routes propres à l'application mobile JEIKO (APP-01), sous
`/api/agent/v1/app/…`. Le reste — agenda, contacts, boutique, visio,
nouveautés — passe par les routes de l'API, avec les droits de la personne.

Réservées aux jetons de l'app
-----------------------------
Un agent IA qui les appelle reçoit un 403 qui le dit (`VueDeLApp`). Elles
n'ont pas de sens pour lui — son téléphone, ses notifications —, et l'une
d'elles franchit une règle de l'API à dessein :

**`app/contacts/` liste toutes les fiches.** L'API ne le fait pas pour un
agent (`vues_contacts.py`) : une liste paginée est un export en masse, et un
agent qui lit des textes saisis par des visiteurs ne doit trouver aucune route
par laquelle les faire sortir. L'app, elle, s'ouvre sur une liste, comme
l'écran du CRM — et c'est une personne qui la tient, avec les droits qu'elle a
déjà à l'écran. Ouvrir cette route à tout agent aurait défait la règle ; la
réserver à l'app la garde.

Ce qu'aucune de ces routes ne fait
----------------------------------
Rien n'est gardé sur le téléphone, et rien ici ne part ailleurs que dans la
réponse. Le jeton push enregistré n'est qu'une adresse : ce qui y part ne
porte aucun contenu (`push.py`).
"""

import re

from django.http import HttpResponse
from django.views import View

from . import app
from .vues_api import AUTHENTIFICATION_SEULE, CorpsInvalide, VueAgent, erreur, ok

PLATEFORMES = ("ios", "android")
#: Un jeton APNs fait 64 caractères hexadécimaux, un jeton FCM moins de 200 ;
#: la borne laisse de la marge sans accepter n'importe quoi.
JETON_PUSH = re.compile(r"[A-Za-z0-9_:\-.]{20,512}")
CONTACTS_PAR_PAGE = 50


class _ReserveeALApp(View):
    """
    Placée APRÈS `VueAgent` dans l'héritage : son `dispatch` s'exécute une
    fois le jeton vérifié (`request.agent` posé), avant la méthode HTTP.
    """

    def dispatch(self, request, *args, **kwargs):
        if not getattr(getattr(request, "agent", None), "pour_l_app", False):
            return erreur("Route réservée à l'application mobile JEIKO.", statut=403)
        return super().dispatch(request, *args, **kwargs)


class VueDeLApp(VueAgent, _ReserveeALApp):
    """Une route de l'application mobile : un jeton d'appareil, rien d'autre."""

    #: Chaque vue précise sa permission ; la plupart se contentent du jeton,
    #: puisque c'est la personne qui est derrière.
    permission_requise = AUTHENTIFICATION_SEULE


def _hexa(couleur):
    """« rgb(180, 83, 9) » ou « #b45309 » → « #b45309 » ; None si illisible."""
    texte = (couleur or "").strip().lower()
    if re.fullmatch(r"#[0-9a-f]{6}", texte):
        return texte
    if re.fullmatch(r"#[0-9a-f]{3}", texte):
        return "#" + "".join(c * 2 for c in texte[1:])
    m = re.fullmatch(r"rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,[^)]*)?\)", texte)
    if m and all(int(v) <= 255 for v in m.groups()):
        return "#%02x%02x%02x" % tuple(int(v) for v in m.groups())
    return None


def peut(user):
    """
    Ce que l'app peut ouvrir pour cette personne : faux si le module est
    éteint, ou si le droit de LECTURE manque. Les écritures gardent leurs
    propres permissions, route par route.
    """
    from jeiko.administration import notifications
    from jeiko.administration.modules import module_actif

    return {
        "rdv": module_actif("rendez_vous") and user.has_perm("calendars.view_appointment"),
        "contacts": user.has_perm("questionnaires_expert.view_prospect"),
        "boutique": module_actif("boutique") and user.has_perm("shop.view_order"),
        "visio": module_actif("visio") and user.has_perm("visio.view_salle"),
        "nouveautes": any(True for _code in notifications.visibles(user)),
    }


class Moi(VueDeLApp):
    """Le site et la personne connectés, et ce que l'app peut ouvrir."""

    def get(self, request):
        from jeiko.administration.website_cache import get_website_data

        site = get_website_data()
        icone = None
        favicon = getattr(site, "favicon", None)
        if favicon is not None and favicon.png_180:
            icone = request.build_absolute_uri(favicon.png_180.url)
        theme = getattr(site, "theme", None)
        personne = request.user
        # Le nom que le site donne de lui-même (identité, celui d'`og:site_name`),
        # pas `WebSite.name` qui vaut « Jeiko » par défaut : sur le téléphone,
        # tous les sites s'appelaient Jeiko.
        identite = getattr(site, "identity", None)
        nom = (getattr(identite, "name", "") or "").strip() or (getattr(site, "name", "") or "").strip()
        return ok({
            "site": {
                "nom": nom or request.get_host().split(":")[0],
                "domaine": request.get_host().split(":")[0],
                "icone": icone,
                "couleur": _hexa(getattr(theme, "accent", "")) if theme is not None else None,
            },
            "personne": {"id": personne.pk, "nom": personne.get_full_name() or personne.get_username(),
                         "email": personne.email},
            "peut": peut(personne),
        })


class Appareil(VueDeLApp):
    """POST : enregistre le jeton push de cet appareil (idempotent). DELETE : déconnecte cet appareil."""

    def post(self, request):
        from .models import AgentToken

        corps = self.corps(request, connues={"plateforme", "jeton_push", "nom"})
        plateforme = corps.get("plateforme")
        if plateforme not in PLATEFORMES:
            raise CorpsInvalide("« plateforme » : « ios » ou « android ».")
        jeton_push = corps.get("jeton_push")
        if not isinstance(jeton_push, str) or not JETON_PUSH.fullmatch(jeton_push):
            raise CorpsInvalide("« jeton_push » : le jeton de notification donné par le système.")
        nom = app.nom_d_appareil(corps.get("nom")) if corps.get("nom") is not None else None

        jeton = request.jeton_agent
        # Un téléphone réinstallé garde son jeton push sous un nouveau jeton
        # d'appareil : l'ancien ne doit pas recevoir la même notification en
        # double. Parmi les appareils de CETTE personne seulement : le jeton
        # d'une autre n'a aucun effet sur les siens.
        AgentToken.objects.filter(agent=request.agent, jeton_push=jeton_push).exclude(pk=jeton.pk).update(
            jeton_push="")
        champs = {"plateforme": plateforme, "jeton_push": jeton_push}
        if nom:
            champs["libelle"] = nom
        AgentToken.objects.filter(pk=jeton.pk).update(**champs)
        return ok({"appareil": {"nom": nom or jeton.libelle, "plateforme": plateforme,
                                "cree_le": jeton.cree_le.isoformat()}}, statut=201)

    def delete(self, request):
        # Révoqué et oublié : l'appel suivant de ce jeton reçoit un 401.
        app.revoquer(request.jeton_agent)
        return HttpResponse(status=204)


class ReglagesNotifications(VueDeLApp):
    """Les notifications de l'app, une par code de `notifications.visibles` : {code: bool}."""

    def _reglages(self, request):
        from jeiko.administration import notifications

        from .push import EVENEMENTS

        # Seulement les codes qui réveillent le téléphone (`push.EVENEMENTS`) :
        # un interrupteur « Stock bas » qui ne commande rien mentirait.
        envoyes = set(EVENEMENTS.values())
        eteintes = request.agent.reglages_push or {}
        return {code: eteintes.get(code, True) is not False
                for code in notifications.visibles(request.user) if code in envoyes}

    def get(self, request):
        return ok(self._reglages(request))

    def patch(self, request):
        from .models import Agent

        actuels = self._reglages(request)
        corps = self.corps(request, connues=set(actuels))
        for code, valeur in corps.items():
            if not isinstance(valeur, bool):
                raise CorpsInvalide(f"« {code} » : true ou false.")
        # On ne garde que les codes éteints : un code nouveau naît allumé.
        reglages = {**(request.agent.reglages_push or {}), **corps}
        reglages = {code: False for code, valeur in reglages.items() if valeur is False}
        Agent.objects.filter(pk=request.agent.pk).update(reglages_push=reglages)
        request.agent.reglages_push = reglages
        return ok(self._reglages(request))


class ContactsDeLApp(VueDeLApp):
    """Toutes les fiches du CRM, la plus récemment modifiée d'abord, 50 par page (application mobile)."""

    permission_requise = "questionnaires_expert.view_prospect"

    def get(self, request):
        from jeiko.questionnaires_expert.models import Prospect

        from .vues_contacts import _resume

        brut = request.GET.get("page") or "1"
        if not brut.isdigit() or int(brut) < 1:
            raise CorpsInvalide("« page » : un entier, 1 ou plus.")
        page = int(brut)
        debut = (page - 1) * CONTACTS_PAR_PAGE
        fiches = list(Prospect.objects.order_by("-updated_at", "-date_created", "-pk")
                      [debut:debut + CONTACTS_PAR_PAGE + 1])
        return ok({
            "contacts": [_resume(c) for c in fiches[:CONTACTS_PAR_PAGE]],
            "page": page,
            "suivante": len(fiches) > CONTACTS_PAR_PAGE,
        })


class EntrerEnVisio(VueDeLApp):
    """
    POST : l'adresse qui fait entrer la personne dans la séance, depuis le
    téléphone, SANS se reconnecter au site — son lien d'invitation, et pour un
    hôte un passe à usage unique (`visio.acces.passe`, qui dit ses gardes).
    Comme « Entrer dans la salle » de la fiche : le lien d'hôte de la personne
    est créé au besoin, s'il a le droit de modifier les séances.
    """

    permission_requise = "visio.view_salle"

    def post(self, request, seance_id):
        from urllib.parse import urlencode

        from django.shortcuts import get_object_or_404

        from jeiko.administration.modules import module_actif
        from jeiko.visio import acces
        from jeiko.visio.models import Invitation, Salle

        if not module_actif("visio"):
            return erreur("La visio n'est pas activée sur ce site.", statut=404)
        salle = get_object_or_404(Salle, pk=seance_id)
        invitation = salle.invitations_actives().filter(user=request.user).first()
        if invitation is None:
            if not request.user.has_perm("visio.change_salle"):
                return erreur("Vous n'êtes pas invité(e) à cette séance.", statut=403)
            try:
                invitation = acces.inviter(salle, user=request.user, role=Invitation.Role.HOTE)
            except acces.Refus as refus:
                return erreur(str(refus), statut=409)
        adresse = request.build_absolute_uri(invitation.get_absolute_url())
        if invitation.est_hote:
            adresse += "?" + urlencode({"passe": acces.passe(invitation)})
        return ok({"adresse": adresse, "hote": invitation.est_hote})


class EcrireAUnContact(VueDeLApp):
    """
    POST {"sujet", "message"} : un e-mail à ce contact, envoyé PAR LE SITE
    (`crm.boite.ecrire`) et rangé sur sa fiche — au lieu de la messagerie du
    téléphone. Réservé à l'app, comme toute route qui fait partir un e-mail sur
    le geste d'une personne : aucun agent IA n'envoie d'e-mail (`vues_contacts`).
    """

    permission_requise = "questionnaires_expert.view_prospect"

    def post(self, request, contact_id):
        from django.shortcuts import get_object_or_404

        from jeiko.crm import boite
        from jeiko.questionnaires_expert.models import Prospect

        if not request.user.has_perm("emailing.add_messageemail"):
            return erreur("Votre compte ne peut pas envoyer d'e-mail depuis le CRM.", statut=403)
        contact = get_object_or_404(Prospect, pk=contact_id)
        if not contact.email:
            return erreur("Ce contact n'a pas d'adresse e-mail.", statut=400)
        corps = self.corps(request, connues={"sujet", "message"})
        envoye, raison = boite.ecrire(contact.email, contact.nom_complet, corps.get("sujet"),
                                      corps.get("message"), request.user)
        if envoye is None:
            return erreur(f"L'e-mail n'est pas parti : {raison}.", statut=400)
        return ok({"envoye": {"a": contact.email, "sujet": envoye.sujet, "le": envoye.date.isoformat()}},
                  statut=201)
