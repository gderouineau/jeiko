from django.urls import path

from .vues_admin import (
    AppareilsConnectes, RevocationDAppareil,
    BasculeActivation, CreationAgent, DetailAgent, ListeDesAgents,
    ModificationAgent, ReinitialisationDuJeton, RevocationDuJeton, RolesDeLAgent,
    TelechargementSkill,
)

app_name = "jeiko_agents_admin"

urlpatterns = [
    path("", ListeDesAgents.as_view(), name="liste"),
    # L'application mobile (APP-01) : les appareils connectés, et leur révocation.
    path("appareils/", AppareilsConnectes.as_view(), name="appareils"),
    path("appareils/<int:jeton_pk>/revoquer/", RevocationDAppareil.as_view(), name="revoquer_appareil"),
    path("nouveau/", CreationAgent.as_view(), name="creer"),
    path("skill/", TelechargementSkill.as_view(), name="skill"),
    path("<int:pk>/", DetailAgent.as_view(), name="detail"),
    path("<int:pk>/modifier/", ModificationAgent.as_view(), name="modifier"),
    path("<int:pk>/roles/", RolesDeLAgent.as_view(), name="roles"),
    # POST : les deux ont un effet immédiat sur l'accès en cours.
    path("<int:pk>/jeton/", ReinitialisationDuJeton.as_view(), name="reinitialiser_jeton"),
    path("<int:pk>/activation/", BasculeActivation.as_view(), name="activation"),
    path("<int:pk>/jetons/<int:jeton_pk>/revoquer/", RevocationDuJeton.as_view(),
         name="revoquer_jeton"),
]
