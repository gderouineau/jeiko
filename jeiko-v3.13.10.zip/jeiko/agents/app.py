# jeiko/agents/app.py
"""
L'application mobile JEIKO (APP-01, 03/11/2026) : gérer ses sites depuis le
téléphone — nouveautés, agenda, contacts, boutique, visio —, tout sauf la mise
en page. Plusieurs sites à la fois ; on entre par le domaine, puis
l'identifiant et le mot de passe SUR LA PAGE DU SITE. Aucune clé à coller.

L'app ne garde aucune donnée : elle appelle l'API des agents
(`/api/agent/v1/…`) avec un jeton par appareil.

La connexion : l'OAuth du serveur MCP, avec un client connu d'avance
-------------------------------------------------------------------
`oauth.py` sait déjà délivrer un jeton d'agent ordinaire au bout d'un
parcours OAuth 2 + PKCE. L'app le suit, avec trois différences :

* **le client `jeiko-app` n'est pas enregistré** : il est connu d'avance, et
  une seule adresse de retour l'accompagne, `fr.jeiko.app:/oauth`. Son
  `ClientOAuth` naît à la première autorisation (le code en a besoin) ;
* **pas de choix d'agent** : le consentement dit « Connecter l'application
  JEIKO sur « <appareil> » », et c'est tout ;
* **le jeton agit avec les droits de LA PERSONNE, en direct.**

Un agent par personne, et pourquoi son compte porteur n'est pas la personne
---------------------------------------------------------------------------
Chaque personne qui connecte l'app reçoit UN agent (`pour_l_app`), dont
chaque jeton est un appareil. `proprietaire` = la personne : l'agenda suit
déjà cette règle (`vues_calendrier._agenda`).

La piste « le compte porteur EST la personne » a été écartée à la lecture du
code : `Agent.user` est un lien un-pour-un, et `user.agent` veut dire partout
« ce compte est une machine » — la page de consentement de Claude refuse un
tel compte (`oauth.autoriser`), le choix du propriétaire d'un agent et de
l'agenda l'écartent (`agent__isnull=True`), la purge et l'effacement RGPD le
traitent en compte technique. Connecter l'app aurait retiré la personne de
tout cela, sans un mot.

D'où : un compte porteur technique, comme pour tout agent (mot de passe
inutilisable, aucun rôle), et `authentification.exige_un_agent` qui pose
`request.user` = la personne pour un agent de l'app. Ses droits sont donc lus
à chaque appel : un rôle retiré, c'est un 403 aussitôt ; un compte désactivé,
un 401 (`authentification.identifier`). Le journal, les plafonds, les
permissions de chaque route : tout le reste est celui de l'API.

Supprimer un agent n'existe pas à l'écran (`vues_admin.py`) ; un agent de l'app
n'y est de toute façon pas listé. Rien, dans ce module, ne touche au compte
de la personne.

Qui peut connecter l'app
------------------------
Tout compte qui a accès à l'administration (`users.access_admin`, le
critère de l'écran d'accueil). Un simple membre, non. Le même critère est
vérifié à chaque appel : le perdre, c'est perdre l'app.
"""

from django.contrib.auth import get_user_model
from django.db import IntegrityError, transaction

from .models import Agent, ClientOAuth

#: Le client public de l'app. Connu d'avance : pas d'enregistrement dynamique.
CLIENT_APP = "jeiko-app"

#: SA SEULE adresse de retour. Une adresse à schéma propre ne s'ouvre que
#: dans l'app qui l'a déclarée au système ; toute autre est refusée.
RETOUR_APP = "fr.jeiko.app:/oauth"

#: Le critère d'accès à l'administration (`administration.views.Main`).
PERM_APP = "users.access_admin"

#: La longueur d'un nom d'appareil : il devient le libellé du jeton.
NOM_D_APPAREIL_MAX = 100


def peut_connecter(user) -> bool:
    """Un compte de l'équipe, actif, qui entre dans l'administration."""
    return bool(user and user.is_authenticated and user.is_active and user.has_perm(PERM_APP))


def nom_d_appareil(valeur) -> str:
    """Le nom affiché sur le consentement et dans « Appareils connectés »."""
    texte = " ".join(str(valeur or "").split())[:NOM_D_APPAREIL_MAX]
    return texte or "Appareil"


def client_de_l_app() -> ClientOAuth:
    """
    Le `ClientOAuth` de l'app, créé ou remis à sa seule adresse de retour.

    Le remettre à chaque fois coûte une écriture et garantit qu'aucune autre
    adresse n'y survit, quoi qu'on ait fait à la table entre-temps.
    """
    client, _cree = ClientOAuth.objects.update_or_create(
        client_id=CLIENT_APP,
        defaults={"nom": "Application JEIKO", "adresses_de_retour": [RETOUR_APP]},
    )
    return client


def agent_de(personne) -> Agent:
    """
    L'agent de l'app de cette personne, créé à sa première connexion.

    Son compte porteur est fabriqué comme celui de tout agent (`services`) :
    identifiant `agent-…`, mot de passe inutilisable, ni staff ni super-
    utilisateur. Deux connexions simultanées : la seconde retrouve le premier.
    """
    from .services import _identifiant_libre

    existant = Agent.objects.filter(pour_l_app=True, proprietaire=personne).first()
    if existant is not None:
        return existant
    nom = f"Application JEIKO — {personne.get_username()}"[:150]
    try:
        with transaction.atomic():
            compte = get_user_model().objects.create(
                username=_identifiant_libre(f"app-{personne.pk}"), email="",
                is_active=True, is_staff=False, is_superuser=False)
            compte.set_unusable_password()
            compte.save(update_fields=["password"])
            return Agent.objects.create(
                nom=nom, user=compte, proprietaire=personne, cree_par=personne, pour_l_app=True,
                description="Les appareils de cette personne connectés à l'application mobile.")
    except IntegrityError:
        return Agent.objects.get(pour_l_app=True, proprietaire=personne)


def appareils(par=None):
    """Les jetons vivants de l'app — tous, ou ceux d'une personne."""
    from .models import AgentToken

    jetons = (AgentToken.objects.filter(agent__pour_l_app=True, revoque_le__isnull=True)
              .select_related("agent__proprietaire").order_by("-cree_le"))
    return jetons if par is None else jetons.filter(agent__proprietaire=par)


def revoquer(jeton):
    """Révoque un appareil et oublie son jeton push : plus rien ne doit y partir."""
    from django.utils import timezone

    from .models import AgentToken

    AgentToken.objects.filter(pk=jeton.pk).update(
        revoque_le=jeton.revoque_le or timezone.now(), jeton_push="", plateforme=jeton.plateforme)
