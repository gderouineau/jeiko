"""
BOITE-01 — les écrans de la boîte de réception du CRM (logique : boite.py).

Une conversation s'ouvre par le numéro d'un de ses messages, jamais par
l'adresse : une adresse dans l'URL finirait dans les journaux du serveur web.

Droits : `emailing.view_messageemail` pour lire (et relever),
`emailing.add_messageemail` pour répondre, ceux de `CompteMessagerie` pour
les comptes. Aucun rôle par défaut ne les donne.
"""
from django.contrib import messages
from django.db.models import Count, Max, OuterRef, Q, Subquery
from django.db.models.functions import Lower
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.utils.http import content_disposition_header
from django.utils.safestring import mark_safe
from django.utils.translation import gettext as _
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from jeiko.emailing.models import CompteMessagerie, MessageEmail
from jeiko.listes import paginer
from jeiko.questionnaires_expert.models import Prospect

from . import boite
from .forms import CompteMessagerieForm, ReponseForm
from .views import _Acces

LIRE = "emailing.view_messageemail"
REPONDRE = "emailing.add_messageemail"


def fiches_par_adresse(adresses):
    """{adresse en minuscules: fiche} — la plus ancienne fiche d'une adresse en double."""
    fiches = {}
    for fiche in (Prospect.objects.annotate(l=Lower("email")).filter(l__in=list(adresses))
                  .order_by("-date_created")):
        fiches[fiche.l] = fiche
    return fiches


@method_decorator(never_cache, name="dispatch")
class BoiteDeReception(_Acces, View):
    """Une ligne par correspondant : son dernier message, ses non-lus."""
    permission_required = LIRE

    def get(self, request):
        recents = MessageEmail.objects.filter(adresse=OuterRef("adresse")).order_by("-date")
        qs = MessageEmail.objects.all()
        terme = (request.GET.get("q") or "").strip()
        if terme:
            qs = qs.filter(Q(adresse__icontains=terme) | Q(nom__icontains=terme) | Q(sujet__icontains=terme))
        conversations = (qs.values("adresse")
                         .annotate(derniere=Max("date"),
                                   non_lus=Count("pk", filter=Q(sens=MessageEmail.Sens.RECU, lu_le__isnull=True)),
                                   nombre=Count("pk"),
                                   dernier_id=Subquery(recents.values("pk")[:1]),
                                   sujet_=Subquery(recents.values("sujet")[:1]),
                                   nom_=Subquery(recents.exclude(nom="").values("nom")[:1]))
                         .order_by("-derniere"))
        if request.GET.get("non_lus"):
            conversations = conversations.filter(non_lus__gt=0)
        page, pagination = paginer(request, conversations)
        page = list(page)
        fiches = fiches_par_adresse(c["adresse"] for c in page)
        for c in page:
            c["fiche"] = fiches.get(c["adresse"])
        return render(request, "crm/admin/boite.html", {
            "conversations": page, **pagination, "recherche": terme,
            "comptes": CompteMessagerie.objects.all(),
        })


@method_decorator(never_cache, name="dispatch")
class Relever(_Acces, View):
    permission_required = LIRE

    def post(self, request):
        nombre = boite.relever_tout()
        erreurs = list(CompteMessagerie.objects.filter(actif=True).exclude(erreur="").values_list("nom", "erreur"))
        for nom, erreur in erreurs:
            messages.error(request, _("Relève de « %(nom)s » impossible : %(erreur)s") % {"nom": nom, "erreur": erreur})
        if not erreurs:
            messages.success(request, _("%(n)s nouveau(x) message(s).") % {"n": nombre})
        return redirect("jeiko_crm:boite")


def _fil(message):
    return list(MessageEmail.objects.filter(adresse__iexact=message.adresse).select_related("compte", "envoye_par")
                .order_by("date"))


@method_decorator(never_cache, name="dispatch")
class Conversation(_Acces, View):
    """Le fil d'une adresse ; l'ouvrir marque ses messages reçus comme lus."""
    permission_required = LIRE

    def contexte(self, message, form=None):
        fil = _fil(message)
        for m in fil:
            # Assaini à la relève ET au rendu : la règle peut avoir changé depuis.
            m.html_sur = mark_safe(boite.nettoyer_html(m.html)) if m.html else ""
        recus = [m for m in fil if m.sens == MessageEmail.Sens.RECU]
        repondre_a = recus[-1] if recus else None
        return {
            "fil": fil, "message": message, "repondre_a": repondre_a,
            "fiche": fiches_par_adresse([message.adresse.lower()]).get(message.adresse.lower()),
            "compte_de_reponse": boite.compte_pour_repondre(repondre_a) if repondre_a else None,
            "form": form or ReponseForm(),
        }

    def get(self, request, pk):
        message = get_object_or_404(MessageEmail, pk=pk)
        MessageEmail.objects.filter(adresse__iexact=message.adresse, sens=MessageEmail.Sens.RECU,
                                    lu_le__isnull=True).update(lu_le=timezone.now())
        return render(request, "crm/admin/conversation.html", self.contexte(message))


@method_decorator(never_cache, name="dispatch")
class Repondre(Conversation):
    permission_required = (LIRE, REPONDRE)

    def get(self, request, pk):
        return redirect("jeiko_crm:conversation", pk)

    def post(self, request, pk):
        message = get_object_or_404(MessageEmail, pk=pk, sens=MessageEmail.Sens.RECU)
        form = ReponseForm(request.POST)
        if form.is_valid():
            reponse, erreur = boite.repondre(message, form.cleaned_data["corps"], request.user)
            if reponse is not None:
                messages.success(request, _("Réponse envoyée à %(adresse)s.") % {"adresse": message.adresse})
                return redirect(reverse("jeiko_crm:conversation", args=[reponse.pk]) + "#dernier")
            messages.error(request, _("La réponse n'est pas partie : %(erreur)s") % {"erreur": erreur})
        return render(request, "crm/admin/conversation.html", self.contexte(message, form), status=400)


@method_decorator(never_cache, name="dispatch")
class PieceJointe(_Acces, View):
    """
    Relue dans la boîte, servie en TÉLÉCHARGEMENT : type générique et
    `nosniff`, pour qu'aucun navigateur ne l'ouvre dans l'origine du site
    (une page HTML jointe y lirait la session de l'administration).
    """
    permission_required = LIRE

    def get(self, request, pk, index):
        message = get_object_or_404(MessageEmail, pk=pk, sens=MessageEmail.Sens.RECU)
        try:
            trouvee = boite.piece_jointe(message, index)
        except Exception:  # noqa: BLE001 — serveur IMAP injoignable
            trouvee = None
        if trouvee is None:
            messages.error(request, _("Cette pièce jointe n'est plus dans la boîte de messagerie."))
            return redirect("jeiko_crm:conversation", pk)
        nom, octets = trouvee
        reponse = HttpResponse(octets, content_type="application/octet-stream")
        reponse["Content-Disposition"] = content_disposition_header(True, nom)
        reponse["X-Content-Type-Options"] = "nosniff"
        return reponse


# --- Les comptes -----------------------------------------------------------

@method_decorator(never_cache, name="dispatch")
class ComptesDeMessagerie(_Acces, ListView):
    permission_required = "emailing.view_comptemessagerie"
    model = CompteMessagerie
    template_name = "crm/admin/boite_comptes.html"
    context_object_name = "comptes"


class _EditionCompte(_Acces):
    model = CompteMessagerie
    form_class = CompteMessagerieForm
    template_name = "crm/admin/boite_compte_formulaire.html"
    context_object_name = "compte"
    success_url = reverse_lazy("jeiko_crm:boite_comptes")

    def form_valid(self, form):
        messages.success(self.request, _("Compte de messagerie enregistré."))
        return super().form_valid(form)


@method_decorator(never_cache, name="dispatch")
class NouveauCompte(_EditionCompte, CreateView):
    permission_required = "emailing.add_comptemessagerie"


@method_decorator(never_cache, name="dispatch")
class ModifierLeCompte(_EditionCompte, UpdateView):
    permission_required = "emailing.change_comptemessagerie"


@method_decorator(never_cache, name="dispatch")
class SupprimerLeCompte(_Acces, DeleteView):
    """Les messages restent (SET_NULL) : une réponse passera par le compte par défaut."""
    permission_required = "emailing.delete_comptemessagerie"
    model = CompteMessagerie
    success_url = reverse_lazy("jeiko_crm:boite_comptes")
    http_method_names = ["post"]

    def form_valid(self, form):
        messages.success(self.request, _("Compte de messagerie supprimé."))
        return super().form_valid(form)
