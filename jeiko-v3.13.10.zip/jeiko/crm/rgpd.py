"""
Droit d'accès et droit à l'effacement d'un CONTACT — une personne qui n'a pas
forcément de compte.

`users/rgpd.py` part toujours d'un compte (`build_user_export(user)`,
`erase_user_data(user)`). Une personne qui a réservé, rempli un formulaire ou
passé un questionnaire sans s'inscrire n'avait donc aucune porte d'entrée :
le site détenait ses données sans pouvoir ni les lui rendre ni les effacer.

Le périmètre est celui de l'historique (`historique.py`) : la fiche, et ce que
les modules gardent sous son ADRESSE. Un compte lié n'est pas touché — il a sa
propre voie, la fiche utilisateur, qui l'efface avec tout ce qui lui est
rattaché. L'écran le dit plutôt que de le faire en silence.

Ce qui reste après l'effacement : la trace qu'il a eu lieu (`SecurityEvent`,
sans donnée personnelle) — sans elle, rien ne prouverait que la demande a été
honorée.
"""
from django.db import transaction
from django.utils import timezone

from .historique import historique, envois_de_formulaire, comptes_lies


def exporter(contact):
    """Un dict JSON-sérialisable : la fiche et son historique."""
    fiche = {
        "prenom": contact.firstname, "nom": contact.lastname, "email": contact.email,
        "telephone": contact.phone, "societe": contact.company, "fonction": contact.job_title,
        "statut": contact.get_status_display(), "origine": contact.get_origin_display(),
        "cree_le": contact.date_created.isoformat() if contact.date_created else None,
    }
    from jeiko.users.models import Comments

    return {
        "genere_le": timezone.now().isoformat(),
        "contact": fiche,
        # Les notes à son sujet sont des données de la personne (droit d'accès).
        "notes": [
            {"date": n.date_created.isoformat() if n.date_created else None,
             "nature": n.get_kind_display(), "texte": n.text}
            for n in Comments.objects.filter(prospect=contact).order_by("date_created")
        ],
        "newsletter": _newsletter(contact.email),
        "boite_de_reception": _boite(contact.email),
        "visio": _visio(contact.email),
        "historique": [
            {"date": e.date.isoformat() if e.date else None, "genre": e.genre,
             "titre": e.titre, "detail": {str(k): str(v) for k, v in e.detail}}
            for e in historique(contact)
        ],
    }


def _boite(email):
    """Les e-mails échangés par la boîte de réception (BOITE-01), corps compris."""
    from jeiko.emailing.models import MessageEmail

    if not email:
        return []
    return [{"date": m.date.isoformat(), "sens": m.get_sens_display(), "sujet": m.sujet, "texte": m.texte,
             "pieces_jointes": [p.get("nom") for p in m.pieces_jointes]}
            for m in MessageEmail.objects.filter(adresse__iexact=email).order_by("date")]


def _visio(email):
    from jeiko.visio.rgpd import export_de

    return export_de(email=email)


def _newsletter(email):
    from jeiko.newsletter.abonnes import export_de_l_adresse

    return export_de_l_adresse(email)


@transaction.atomic
def effacer(contact, *, acteur=None, motif=""):
    """
    Efface la fiche et ce que les modules gardent sous son adresse. Tout ou
    rien. Rend un résumé ({élément: nombre}).
    """
    from jeiko.users.models import SecurityEvent, SecurityEventType
    from jeiko.users.rgpd import (
        CHAMPS_DE_LA_PERSONNE, CHAMPS_DU_RENDEZ_VOUS, _anonymiser_les_envois, _modele,
    )

    email = (contact.email or "").strip()
    resume = {"comptes_lies_non_touches": len(comptes_lies(contact))}

    if email:
        Appointment = _modele("calendars.Appointment")
        if Appointment is not None:
            # Anonymisés, pas supprimés : l'agenda du praticien garde le créneau.
            resume["rendez_vous_anonymises"] = Appointment.objects.filter(
                email__iexact=email).update(**CHAMPS_DU_RENDEZ_VOUS)
        WaitlistEntry = _modele("calendars.WaitlistEntry")
        if WaitlistEntry is not None:
            resume["listes_d_attente_anonymisees"] = WaitlistEntry.objects.filter(
                email__iexact=email).update(**CHAMPS_DE_LA_PERSONNE)
        resume["envois_de_formulaire_supprimes"] = envois_de_formulaire(email, avec_indesirables=True).delete()[0]
        resume["emails_anonymises"] = _anonymiser_les_envois(email=email)
        from jeiko.newsletter.abonnes import effacer_l_adresse

        resume["newsletter_supprimee"] = effacer_l_adresse(email)
        from jeiko.visio.rgpd import effacer_de

        resume["invitations_visio_anonymisees"] = effacer_de(email=email)
        # Sur le site seulement : la boîte IMAP d'où ils viennent est hors de sa portée.
        from jeiko.emailing.models import MessageEmail

        resume["emails_de_la_boite_supprimes"] = MessageEmail.objects.filter(adresse__iexact=email).delete()[0]

    # Toutes les fiches de l'adresse, pas seulement celle qu'on regarde : la
    # demande vient d'une PERSONNE, et ses doublons (règle de `resolve_prospect`)
    # portent les mêmes données. Chaque fiche emporte ses passages de
    # questionnaire, ses notes et ses liens vers des comptes.
    from jeiko.questionnaires_expert.models import Prospect

    fiches = Prospect.objects.filter(email__iexact=email) if email else Prospect.objects.filter(pk=contact.pk)
    fiches = fiches | Prospect.objects.filter(pk=contact.pk)
    resume["fiches_supprimees"] = fiches.count()
    resume["passages_supprimes"] = sum(f.test_datas.count() for f in fiches)
    for fiche in list(fiches):
        fiche.delete()

    SecurityEvent.objects.create(
        user=None,
        event_type=SecurityEventType.CONTACT_ERASED,
        extra={"reason": motif, "actor_id": getattr(acteur, "pk", None),
               "resume": resume},
    )
    return resume


#: Trois ans sans contact venu de la personne : la durée que la CNIL admet pour
#: un prospect (référentiel « gestion des activités commerciales »).
CONSERVATION_PAR_DEFAUT = 3 * 365


def purger_les_contacts_sans_suite(maintenant=None):
    """
    Efface les PROSPECTS sans activité depuis la durée de conservation
    (`JEIKO_CONTACTS_RETENTION_DAYS`, trois ans par défaut).

    Un client ou un ancien client n'est pas concerné : la relation commerciale
    a ses propres obligations (facturation, garanties), que l'exploitant
    connaît mieux que JEIKO. L'activité, c'est la fiche elle-même ET son
    historique : un rendez-vous pris l'an dernier garde la fiche.
    """
    from datetime import timedelta

    from django.conf import settings

    from jeiko.questionnaires_expert.models import Prospect

    try:
        from jeiko.reglages_avances import valeur  # A-81 : réglable à l'écran
        jours = max(1, int(valeur("contacts_jours", CONSERVATION_PAR_DEFAUT)))
    except (TypeError, ValueError):
        jours = CONSERVATION_PAR_DEFAUT
    limite = (maintenant or timezone.now()) - timedelta(days=jours)

    candidats = Prospect.objects.filter(status=Prospect.Statut.PROSPECT, date_created__lt=limite).exclude(
        updated_at__gte=limite)
    effaces = 0
    for contact in candidats:
        dates = [e.date for e in historique(contact) if e.date]
        if dates and max(dates) >= limite:
            continue
        if Prospect.objects.filter(pk=contact.pk).exists():  # un doublon effacé avec un autre
            effacer(contact, motif="conservation")
            effaces += 1
    return effaces

