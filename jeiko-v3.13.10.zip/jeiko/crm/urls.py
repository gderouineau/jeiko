from django.urls import path

from . import views, vues_boite

app_name = "jeiko_crm"

urlpatterns = [
    # BOITE-01 — la boîte de réception (vues_boite.py).
    path("boite/", vues_boite.BoiteDeReception.as_view(), name="boite"),
    path("boite/relever/", vues_boite.Relever.as_view(), name="boite_relever"),
    path("boite/<int:pk>/", vues_boite.Conversation.as_view(), name="conversation"),
    path("boite/<int:pk>/repondre/", vues_boite.Repondre.as_view(), name="repondre"),
    path("boite/<int:pk>/pieces/<int:index>/", vues_boite.PieceJointe.as_view(), name="piece_jointe"),
    path("boite/comptes/", vues_boite.ComptesDeMessagerie.as_view(), name="boite_comptes"),
    path("boite/comptes/nouveau/", vues_boite.NouveauCompte.as_view(), name="boite_compte_nouveau"),
    path("boite/comptes/<int:pk>/", vues_boite.ModifierLeCompte.as_view(), name="boite_compte"),
    path("boite/comptes/<int:pk>/supprimer/", vues_boite.SupprimerLeCompte.as_view(), name="boite_compte_supprimer"),
    path("contacts/", views.ListeDesContacts.as_view(), name="liste"),
    path("contacts/nouveau/", views.NouveauContact.as_view(), name="nouveau"),
    path("a-relancer/", views.ARelancer.as_view(), name="relances"),
    path("questionnaires/", views.ProspectsDesQuestionnaires.as_view(), name="prospects_questionnaires"),
    path("contacts/export.csv", views.ExportCsv.as_view(), name="export_csv"),
    path("contacts/import/", views.ImportCsv.as_view(), name="import_csv"),
    path("contacts/supprimer/", views.EffacerLaSelection.as_view(), name="effacer_selection"),
    path("entreprises/", views.ListeDesEntreprises.as_view(), name="entreprises"),
    path("entreprises/nouvelle/", views.NouvelleEntreprise.as_view(), name="entreprise_nouvelle"),
    path("entreprises/<int:pk>/", views.FicheEntreprise.as_view(), name="entreprise"),
    path("entreprises/<int:pk>/modifier/", views.ModifierLEntreprise.as_view(), name="entreprise_modifier"),
    path("entreprises/<int:pk>/supprimer/", views.SupprimerLEntreprise.as_view(), name="entreprise_supprimer"),
    path("entreprises/<int:pk>/contacts/", views.RattacherUnContact.as_view(), name="entreprise_contacts"),
    path("contacts/<int:pk>/rapprocher/<int:doublon_id>/", views.Rapprocher.as_view(), name="rapprocher"),
    path("contacts/<int:pk>/relance-faite/", views.RelanceFaite.as_view(), name="relance_faite"),
    path("contacts/<int:pk>/taches/", views.AjouterUneTache.as_view(), name="tache_ajouter"),
    path("contacts/<int:pk>/taches/<int:tache_id>/", views.ChangerUneTache.as_view(), name="tache_changer"),
    path("contacts/<int:pk>/rappels/", views.BasculerLesRappels.as_view(), name="rappels"),
    path("contacts/<int:pk>/rendez-vous/", views.RendezVousDuContact.as_view(), name="rendez_vous"),
    path("contacts/<int:pk>/", views.FicheDuContact.as_view(), name="fiche"),
    path("contacts/<int:pk>/modifier/", views.ModifierLeContact.as_view(), name="modifier"),
    path("contacts/<int:pk>/export/", views.ExportDuContact.as_view(), name="export"),
    path("contacts/<int:pk>/effacer/", views.EffacerLeContact.as_view(), name="effacer"),
    path("contacts/<int:pk>/notes/", views.AjouterUneNote.as_view(), name="note_ajouter"),
    path("contacts/<int:pk>/notes/<int:note_id>/supprimer/", views.SupprimerUneNote.as_view(), name="note_supprimer"),
    path("contacts/<int:pk>/notes/<int:note_id>/transmettre/", views.TransmettreLeCompteRendu.as_view(),
         name="note_transmettre"),
]
