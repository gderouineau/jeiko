"""
Le rapport d'activité par e-mail (D-13 à D-16) : chaque jour, chaque
semaine, chaque mois ou chaque année, à qui l'a demandé.

Le problème
-----------
Le récapitulatif quotidien (`admin_alerts.envoyer_le_recapitulatif_quotidien`)
liste les rendez-vous, commandes et comptes de la veille : une cadence, des
listes, aucun réglage. Sur un mois, une liste ne dit rien. L'exploitant veut
savoir si son site va mieux ou moins bien.

Ce que fait ce module
---------------------
* des COMPTEURS, chacun comparé à la période précédente (« 12 commandes,
  +20 % ») : les inscriptions (D-14 : comptes, newsletter, formations,
  séances) et l'activité (D-15 : visites, commandes et chiffre d'affaires,
  rendez-vous, questionnaires, contacts, formations terminées). Seuls les
  modules allumés sont comptés ;
* des cadences cumulables, par personne (D-13, `AbonnementRapport`), réglées
  dans E-mails › Rapports ou par l'API (D-16) ;
* une période CLOSE : hier, la semaine dernière (lundi-dimanche), le mois
  dernier, l'année dernière. La tâche quotidienne envoie la période close la
  plus récente, une seule fois (`derniere_periode`) ;
* l'e-mail est un modèle du catalogue (`admin_periodic_report`), modifiable
  comme les autres ;
* QUI a passé un questionnaire (`bloc_questionnaires`) : une ligne par
  passage de la période — le nom, le questionnaire, un lien vers la fiche,
  un lien vers le résultat dans l'administration, et l'accord de recontact
  (`Prospect.recontact_accepte_le`). Une section du même rapport plutôt
  qu'un e-mail à part : les cadences, l'écran, l'API et le « une fois par
  période » existaient déjà ; couper une cadence coupe donc aussi sa liste.

Vie privée
----------
La liste nomme des gens : elle n'est rendue qu'à qui peut ouvrir leurs
fiches (`questionnaires_expert.view_prospect`, la permission des deux
liens). Les autres abonnés reçoivent les compteurs, sans la section. Elle
est plafonnée (`PLAFOND_QUESTIONNAIRES`), le reste résumé en « et N
autres » avec un lien vers la liste du CRM : un mensuel de 2 000 passages
ne doit pas faire un e-mail de 2 Mo.

Ce qu'il ne fait pas
--------------------
* Il ne remplace pas le récapitulatif quotidien, qui reste tel quel.
* Une période sans aucune activité n'envoie rien : le rapport est marqué
  envoyé, en silence.
* Le rapport annuel ne compte pas les visites : les vues de page ne sont
  gardées que 180 jours, l'année serait fausse.
* Les montants sont additionnés dans leur devise d'enregistrement, sans
  conversion : un site vend dans une devise.
* La liste des questionnaires ne se règle pas à part des compteurs : qui
  veut l'une reçoit l'autre. Le lien « résultat » mène à l'administration,
  jamais au lien public du répondant.
* Un répondant connecté sans fiche CRM n'a pas d'accord de recontact
  enregistré : « — », et le lien mène à son compte.
"""

import logging
from datetime import date, datetime, time, timedelta

from django.utils import timezone
from django.utils.html import format_html, format_html_join

logger = logging.getLogger(__name__)

MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre",
        "octobre", "novembre", "décembre"]

#: Le nom de la cadence dans l'e-mail (en français, comme tout le contenu des e-mails, I-05).
ADJECTIFS = {"jour": "quotidien", "semaine": "hebdomadaire", "mois": "mensuel", "annee": "annuel"}


def periode(cadence, aujourd_hui):
    """(premier jour, lendemain du dernier jour) de la dernière période close."""
    if cadence == "jour":
        return aujourd_hui - timedelta(days=1), aujourd_hui
    if cadence == "semaine":
        lundi = aujourd_hui - timedelta(days=aujourd_hui.weekday())
        return lundi - timedelta(days=7), lundi
    if cadence == "mois":
        premier = aujourd_hui.replace(day=1)
        return (premier - timedelta(days=1)).replace(day=1), premier
    if cadence == "annee":
        return date(aujourd_hui.year - 1, 1, 1), date(aujourd_hui.year, 1, 1)
    raise ValueError(cadence)


def libelle(cadence, debut, fin):
    dernier = fin - timedelta(days=1)
    if cadence == "jour":
        return f"{debut:%d/%m/%Y}"
    if cadence == "semaine":
        return f"du {debut:%d/%m} au {dernier:%d/%m/%Y}"
    if cadence == "mois":
        return f"{MOIS[debut.month - 1]} {debut.year}"
    return str(debut.year)


def _bornes(debut, fin):
    tz = timezone.get_current_timezone()
    return timezone.make_aware(datetime.combine(debut, time.min), tz), timezone.make_aware(datetime.combine(fin, time.min), tz)


def _compter(debut, fin):
    """{clé: valeur} pour une période. Un compteur en erreur est omis, jamais fatal."""
    from django.contrib.auth import get_user_model
    from django.db.models import Sum

    from jeiko.administration.modules import module_actif

    de, a = _bornes(debut, fin)
    valeurs = {}

    def poser(cle, calcul):
        try:
            valeurs[cle] = calcul()
        except Exception:
            logger.exception("Rapport : compteur « %s » impossible", cle)

    poser("comptes", lambda: get_user_model().objects.filter(date_joined__gte=de, date_joined__lt=a).count())

    if module_actif("newsletter"):
        def newsletter():
            from jeiko.emailing.models import Inscription
            return Inscription.objects.filter(confirmee_le__gte=de, confirmee_le__lt=a).count()
        poser("newsletter", newsletter)

    def visites():
        from jeiko.stats.models import PageView
        return PageView.objects.filter(day__gte=debut, day__lt=fin, is_bot=False, is_entry=True).count()
    poser("visites", visites)

    def pages_vues():
        from jeiko.stats.models import PageView
        return PageView.objects.filter(day__gte=debut, day__lt=fin, is_bot=False).count()
    poser("pages_vues", pages_vues)

    if module_actif("boutique"):
        def payees():
            from jeiko.shop.models import Order
            return Order.objects.filter(created_at__gte=de, created_at__lt=a, payment_status=Order.PAYMENT_STATUS_PAID)
        poser("commandes", lambda: payees().count())
        poser("chiffre_affaires", lambda: payees().aggregate(t=Sum("total_ttc"))["t"] or 0)
    if module_actif("rendez_vous"):
        def rendez_vous():
            from jeiko.calendars.models import Appointment
            return Appointment.objects.filter(created__gte=de, created__lt=a).count()
        poser("rendez_vous", rendez_vous)
    if module_actif("questionnaires"):
        def questionnaires():
            from jeiko.questionnaires_expert.models import ExpertTestData
            return ExpertTestData.objects.filter(created_at__gte=de, created_at__lt=a).count()
        poser("questionnaires", questionnaires)

    def contacts():
        from jeiko.questionnaires_expert.models import Prospect
        return Prospect.objects.filter(date_created__gte=de, date_created__lt=a).count()
    poser("contacts", contacts)

    if module_actif("formations"):
        def inscriptions_formations():
            from jeiko.courses.models import CourseEnrollment
            return CourseEnrollment.objects.filter(enrolled_at__gte=de, enrolled_at__lt=a).count()
        poser("inscriptions_formations", inscriptions_formations)

        def formations_terminees():
            from jeiko.courses.models import CourseEnrollment
            return CourseEnrollment.objects.filter(completed_at__gte=de, completed_at__lt=a).count()
        poser("formations_terminees", formations_terminees)
    if module_actif("visio"):
        def seances():
            from jeiko.visio.models import Invitation
            return Invitation.objects.filter(inscrite=True, cree_le__gte=de, cree_le__lt=a).count()
        poser("inscriptions_seances", seances)
    return valeurs


#: (section, clé, libellé) — l'ordre de l'e-mail. Libellés en français (I-05).
LIGNES = [
    ("inscriptions", "comptes", "Nouveaux comptes"),
    ("inscriptions", "newsletter", "Inscriptions à la newsletter"),
    ("inscriptions", "inscriptions_formations", "Inscriptions aux formations"),
    ("inscriptions", "inscriptions_seances", "Inscriptions aux séances en visio"),
    ("activite", "visites", "Visites"),
    ("activite", "pages_vues", "Pages vues"),
    ("activite", "commandes", "Commandes payées"),
    ("activite", "chiffre_affaires", "Chiffre d'affaires TTC"),
    ("activite", "rendez_vous", "Rendez-vous pris"),
    ("activite", "questionnaires", "Questionnaires passés"),
    ("activite", "contacts", "Nouveaux contacts"),
    ("activite", "formations_terminees", "Formations terminées"),
]


def _evolution(valeur, avant):
    if not avant:
        return "nouveau" if valeur else "—"
    ecart = round((valeur - avant) * 100 / avant)
    return f"{ecart:+d} %"


def _montant(valeur, cle):
    if cle == "chiffre_affaires":
        return f"{valeur:.2f} €".replace(".", ",")
    return str(valeur)


def tableau(section, actuel, precedent):
    """
    Le tableau HTML d'une section (styles en ligne : un e-mail).

    Les chiffres ne passent jamais à la ligne : sur téléphone, « +100 % »
    et « 1325,80 € » se coupaient à leur espace (26/10/2026). Le libellé,
    lui, se replie. 14 px, comme le tableau des commandes : hérité du texte
    du site, il faisait 22 px sur certains sites et débordait à trois colonnes.
    """
    lignes = [(lib, _montant(actuel[cle], cle), _evolution(actuel[cle], precedent.get(cle, 0)))
              for sec, cle, lib in LIGNES if sec == section and cle in actuel]
    if not lignes:
        return ""
    return format_html(
        '<table role="presentation" style="width:100%;border-collapse:collapse;font-size:14px;">{}</table>',
        format_html_join("", '<tr><td style="padding:6px 0;border-bottom:1px solid #eeeeee;">{}</td>'
                             '<td style="padding:6px 0 6px 12px;border-bottom:1px solid #eeeeee;text-align:right;white-space:nowrap;"><strong>{}</strong></td>'
                             '<td style="padding:6px 0 6px 12px;border-bottom:1px solid #eeeeee;text-align:right;white-space:nowrap;color:#666666;">{}</td></tr>',
                         lignes))


PLAFOND_QUESTIONNAIRES = 50
PERMISSION_QUESTIONNAIRES = "questionnaires_expert.view_prospect"


def bloc_questionnaires(debut, fin):
    """
    La liste HTML des passages de la période, plafonnée ; "" s'il n'y en a pas
    ou si le module est éteint. À ne donner qu'à `PERMISSION_QUESTIONNAIRES`.
    """
    from jeiko.administration.modules import module_actif

    from .admin_alerts import _lien_absolu

    if not module_actif("questionnaires"):
        return ""
    from jeiko.questionnaires_expert.models import ExpertTestData

    de, a = _bornes(debut, fin)
    passages = (ExpertTestData.objects.filter(created_at__gte=de, created_at__lt=a)
                .select_related("test", "prospect", "user").order_by("created_at"))
    total = passages.count()
    if not total:
        return ""
    lignes = []
    for td in passages[:PLAFOND_QUESTIONNAIRES]:
        if td.prospect_id:
            fiche = _lien_absolu("jeiko_crm:fiche", td.prospect_id)
            accord = td.prospect.recontact_accepte_le
            recontact = f"oui, depuis le {timezone.localtime(accord):%d/%m/%Y}" if accord else "non"
        else:
            fiche = _lien_absolu("jeiko_administration_users:user_detail", td.user_id) if td.user_id else ""
            recontact = "—"
        lignes.append((
            f"{timezone.localtime(td.created_at):%d/%m %H:%M}",
            td.recipient_name or td.recipient_email or "Répondant anonyme",
            td.test.title, fiche,
            _lien_absolu("jeiko_administration_questionnaires_expert:test_data_detail", td.pk),
            recontact,
        ))
    cellule = 'style="padding:6px 8px 6px 0;border-bottom:1px solid #eeeeee;vertical-align:top;"'
    html = format_html(
        '<h3>Questionnaires passés</h3>'
        '<table role="presentation" style="width:100%;border-collapse:collapse;font-size:14px;">'
        '<tr><th align="left">Date</th><th align="left">Personne</th><th align="left">Questionnaire</th>'
        '<th align="left">Recontact</th></tr>{}</table>',
        format_html_join("", '<tr><td ' + cellule + ' nowrap>{}</td><td ' + cellule + '>{}<br>'
                             '<a href="{}">Fiche</a> · <a href="{}">Résultat</a></td>'
                             '<td ' + cellule + '>{}</td><td ' + cellule + '>{}</td></tr>',
                         lignes))
    if total > PLAFOND_QUESTIONNAIRES:
        html += format_html('<p>Et {} autres : <a href="{}">voir les contacts des questionnaires</a>.</p>',
                            total - PLAFOND_QUESTIONNAIRES, _lien_absolu("jeiko_crm:prospects_questionnaires"))
    return html


def contexte(cadence, aujourd_hui):
    """(premier jour de la période, contexte de l'e-mail, y a-t-il eu de l'activité)."""
    from .admin_alerts import _lien_absolu

    debut, fin = periode(cadence, aujourd_hui)
    avant_debut, avant_fin = periode(cadence, debut)
    actuel, precedent = _compter(debut, fin), _compter(avant_debut, avant_fin)
    if cadence == "annee":
        # Les vues de page ne sont gardées que 180 jours (`stats_purge`) : une
        # année de visites, et la précédente, seraient fausses — omises.
        for cle in ("visites", "pages_vues"):
            actuel.pop(cle, None)
    return debut, {
        "cadence": ADJECTIFS[cadence],
        "periode": libelle(cadence, debut, fin),
        "bloc_inscriptions": tableau("inscriptions", actuel, precedent),
        "bloc_activite": tableau("activite", actuel, precedent),
        "lien_tableau_de_bord": _lien_absolu("jeiko_administration:main"),
        "bloc_questionnaires": bloc_questionnaires(debut, fin),
    }, any(actuel.values())


def _envoyer(user, ctx):
    from .services import send_email

    if not user.has_perm(PERMISSION_QUESTIONNAIRES):
        ctx = {**ctx, "bloc_questionnaires": ""}
    ok, _raison = send_email("admin_periodic_report", user.email, ctx, user=user)
    return bool(ok)


def envoyer_les_rapports(aujourd_hui=None):
    """La tâche quotidienne : rend le nombre de rapports envoyés."""
    from .models import AbonnementRapport

    aujourd_hui = aujourd_hui or timezone.localdate()
    envoyes, calcules = 0, {}
    abonnements = AbonnementRapport.objects.select_related("user").filter(
        user__is_active=True, user__is_staff=True).exclude(user__email="")
    for abonnement in abonnements:
        debut, _fin = periode(abonnement.cadence, aujourd_hui)
        if abonnement.derniere_periode == debut:
            continue
        if abonnement.cadence not in calcules:
            calcules[abonnement.cadence] = contexte(abonnement.cadence, aujourd_hui)
        _debut, ctx, activite = calcules[abonnement.cadence]
        # Rien à dire : marqué envoyé, sans écrire « il ne s'est rien passé ».
        if not activite or _envoyer(abonnement.user, ctx):
            envoyes += int(activite)
            AbonnementRapport.objects.filter(pk=abonnement.pk).update(derniere_periode=debut)
    return envoyes


def apercu(user, cadence="semaine"):
    """Le rapport de la dernière période close, tout de suite, à `user` — sans rien marquer."""
    _debut, ctx, _activite = contexte(cadence, timezone.localdate())
    return _envoyer(user, ctx)
