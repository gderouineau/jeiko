# jeiko/emailing/models_boite.py
"""
BOITE-01 — la boîte de réception du CRM : des comptes de messagerie, et les
e-mails échangés avec les visiteurs.

Rangés dans `emailing` pour la même raison que la newsletter : une
application neuve obligerait à toucher le `settings.py` de chaque site. La
logique vit dans `jeiko/crm/boite.py`.

Le fil d'une conversation est celui d'une ADRESSE (`MessageEmail.adresse`),
comme l'historique du CRM : aucune clé vers la fiche, rien à resynchroniser
quand une fiche est créée, rapprochée ou effacée.

Ce que ces modèles ne gardent pas : le message brut, ni les pièces jointes —
celles-ci restent dans la boîte IMAP et y sont relues au clic.
"""
from django.conf import settings
from django.db import models
from django.db.models import Q
from django.utils.translation import gettext_lazy as _

from jeiko.encrypted import EncryptedCharField, EncryptedTextField


class CompteMessagerie(models.Model):
    """
    Une boîte aux lettres : IMAP pour lire, SMTP pour répondre.

    Les deux mots de passe sont chiffrés au repos, comme ceux de `MailSettings`
    et des rebonds (`jeiko/encrypted.py`) — avec les mêmes limites.

    SMTP vide : la réponse part par le SMTP du site (`MailSettings`), signée de
    l'adresse du compte. Le compte par défaut répond quand celui qui a reçu le
    message a été supprimé.
    """

    nom = models.CharField(_("Nom"), max_length=100, help_text=_("Pour vous : « Contact », « Boutique »…"))
    adresse = models.EmailField(_("Adresse d'envoi"), help_text=_("L'adresse qui signe vos réponses."))
    par_defaut = models.BooleanField(_("Compte par défaut"), default=False,
                                     help_text=_("Répond quand le compte d'un message n'existe plus."))
    actif = models.BooleanField(_("Relever ce compte"), default=True)

    imap_hote = models.CharField(_("Serveur IMAP"), max_length=200)
    imap_port = models.PositiveIntegerField(_("Port IMAP"), default=993)
    imap_utilisateur = models.CharField(_("Identifiant IMAP"), max_length=200)
    imap_mot_de_passe = EncryptedCharField(_("Mot de passe IMAP"), max_length=255, blank=True)
    imap_dossier = models.CharField(_("Dossier"), max_length=100, default="INBOX")

    smtp_hote = models.CharField(_("Serveur SMTP"), max_length=200, blank=True,
                                 help_text=_("Vide : les réponses partent par le serveur d'envoi du site."))
    smtp_port = models.PositiveIntegerField(_("Port SMTP"), default=587)
    smtp_tls = models.BooleanField(_("Utiliser TLS"), default=True)
    smtp_ssl = models.BooleanField(_("Utiliser SSL"), default=False)
    smtp_utilisateur = models.CharField(_("Identifiant SMTP"), max_length=200, blank=True)
    smtp_mot_de_passe = EncryptedCharField(_("Mot de passe SMTP"), max_length=255, blank=True)

    # Où la relève en est : les UID ne valent que pour un même UIDVALIDITY.
    uidvalidity = models.CharField(max_length=40, blank=True, editable=False)
    dernier_uid = models.PositiveBigIntegerField(default=0, editable=False)
    releve_le = models.DateTimeField(_("Dernier relevé"), null=True, blank=True, editable=False)
    erreur = models.CharField(_("Dernière erreur de relevé"), max_length=300, blank=True, editable=False)

    class Meta:
        verbose_name = _("Compte de messagerie")
        verbose_name_plural = _("Comptes de messagerie")
        ordering = ["-par_defaut", "nom"]

    def __str__(self):
        return f"{self.nom} <{self.adresse}>"

    def save(self, *args, **kwargs):
        # Un seul compte par défaut ; le premier l'est d'office.
        if not self.par_defaut and not CompteMessagerie.objects.exclude(pk=self.pk).filter(par_defaut=True).exists():
            self.par_defaut = True
        super().save(*args, **kwargs)
        if self.par_defaut:
            CompteMessagerie.objects.exclude(pk=self.pk).filter(par_defaut=True).update(par_defaut=False)


class MessageEmail(models.Model):
    """
    Un e-mail reçu d'un visiteur, ou une réponse envoyée depuis le site.

    `adresse` est toujours celle du VISITEUR — l'expéditeur d'un message reçu,
    le destinataire d'une réponse : le fil d'une personne est un simple filtre.

    Les corps sont chiffrés, comme les notes du CRM. `html` est déjà assaini à
    la relève (`crm/boite.py`) : le HTML d'un e-mail entrant n'est jamais
    gardé tel qu'il est arrivé.
    """

    class Sens(models.TextChoices):
        RECU = "recu", _("Reçu")
        ENVOYE = "envoye", _("Envoyé")

    compte = models.ForeignKey(CompteMessagerie, null=True, blank=True, on_delete=models.SET_NULL,
                               related_name="messages")
    sens = models.CharField(max_length=10, choices=Sens.choices)
    adresse = models.EmailField(db_index=True)
    nom = models.CharField(max_length=200, blank=True)
    sujet = models.CharField(max_length=300, blank=True)
    date = models.DateTimeField(db_index=True)
    message_id = models.CharField(max_length=300, blank=True, db_index=True)
    en_reponse_a = models.CharField(max_length=300, blank=True)
    references = models.TextField(blank=True)
    texte = EncryptedTextField(blank=True)
    html = EncryptedTextField(blank=True)
    # [{"index": n, "nom": …, "taille": …}] — l'index est le rang de la partie
    # dans `message.walk()`, pour la relire dans la boîte au clic.
    pieces_jointes = models.JSONField(default=list, blank=True)
    uid = models.PositiveBigIntegerField(null=True, blank=True)
    uidvalidity = models.CharField(max_length=40, blank=True)
    lu_le = models.DateTimeField(null=True, blank=True)
    envoye_par = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
                                   related_name="+")
    cree_le = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("E-mail de la boîte de réception")
        verbose_name_plural = _("E-mails de la boîte de réception")
        ordering = ["-date"]
        constraints = [
            # La relève du cron et celle du bouton peuvent se croiser : le
            # même message ne s'enregistre qu'une fois.
            models.UniqueConstraint(fields=["compte", "uidvalidity", "uid"], condition=Q(uid__isnull=False),
                                    name="boite_un_uid_par_compte"),
        ]

    def __str__(self):
        return f"{self.get_sens_display()} — {self.adresse} — {self.sujet}"
