from django.db import migrations

MARQUE = "[%bloc_questionnaires%]"


def ajouter(apps, schema_editor):
    """
    Pose la liste des questionnaires passés dans un rapport d'activité déjà là.

    `apply_seed` ne touche pas un e-mail existant, et le forcer écraserait un
    modèle retouché. On ajoute donc la marque derrière celle de l'activité,
    là où elle est : un modèle qui a déjà la marque, ou qui n'a plus celle de
    l'activité, est laissé tel quel.
    """
    EmailTemplate = apps.get_model("emailing", "EmailTemplate")
    ContentText = apps.get_model("administration_pages", "ContentText")
    modele = EmailTemplate.objects.filter(code="admin_periodic_report").exclude(page=None).first()
    if modele is None:
        return
    textes = ContentText.objects.filter(content__bloc__line__section__page=modele.page_id)
    if textes.filter(text__contains=MARQUE).exists():
        return
    texte = textes.filter(text__contains="[%bloc_activite%]").first()
    if texte is not None:
        texte.text = texte.text.replace("[%bloc_activite%]", "[%bloc_activite%]" + MARQUE, 1)
        texte.save(update_fields=["text"])


class Migration(migrations.Migration):

    dependencies = [
        ("emailing", "0023_fond_des_boutons"),
        ("administration_pages", "0091_variantes_transparentes"),
    ]

    operations = [
        migrations.RunPython(ajouter, migrations.RunPython.noop),
    ]
