"""
Vide depuis le 13/11/2026 : le recalcul des héros est passé en 0095, après
`0094_theme_par_categorie` (voir 0095 et `tests/test_migration_des_heros.py`).
Gardée pour la chaîne déjà jouée.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0092_types_du_bloc_calendrier"),
    ]

    operations = []
