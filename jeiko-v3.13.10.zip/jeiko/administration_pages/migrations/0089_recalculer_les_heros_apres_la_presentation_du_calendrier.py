"""
Vide depuis le 01/11/2026 : le recalcul des héros est passé en 0093, après
`0092_types_du_bloc_calendrier` (voir 0093 et `tests/test_migration_des_heros.py`).
Gardée pour la chaîne déjà jouée.
"""

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0088_presentation_du_calendrier"),
    ]

    operations = []
