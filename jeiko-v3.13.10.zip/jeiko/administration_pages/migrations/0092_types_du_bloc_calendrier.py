# Le bloc calendrier propose un, plusieurs ou tous les types (01/11/2026).
#
# Les blocs déjà en place gardent leur rendu exact (règle « ajouter sans
# remplacer ») : « Un seul type » pour ceux qui avaient un type, « Tous les
# types » pour les autres — ce qu'ils montraient —, et filtres éteints. Les
# blocs créés ensuite ont les filtres allumés (défaut du modèle).

import django.db.models.deletion
from django.db import migrations, models


def un_seul_type_pour_ceux_qui_en_avaient_un(apps, schema_editor):
    ContentCalendar = apps.get_model("administration_pages", "ContentCalendar")
    ContentCalendar.objects.filter(appointment_type__isnull=False).update(types_proposes="un")


class Migration(migrations.Migration):

    dependencies = [
        ('administration_pages', '0091_variantes_transparentes'),
        # 0007, pas la dernière de `calendars` : celle-ci déplaçait l'ordre du
        # plan, et `emailing/0002` — qui crée des pages avec le VRAI modèle
        # Page — passait avant `0081_menu_transparent` et échouait (vérifié).
        ('calendars', '0007_appointmenttype_user_availability_user_and_more'),
    ]

    operations = [
        migrations.AddField(
            model_name='contentcalendar',
            name='appointment_types',
            field=models.ManyToManyField(blank=True, help_text='Pour « Plusieurs types ».', related_name='+', to='calendars.appointmenttype', verbose_name='Types de rendez-vous'),
        ),
        migrations.AddField(
            model_name='contentcalendar',
            name='filtre_par_type',
            field=models.BooleanField(default=False, help_text="Des boutons « Tous · Massage 1h · … » au-dessus des créneaux, quand le bloc propose plus d'un type.", verbose_name='Le client filtre par type'),
        ),
        migrations.AddField(
            model_name='contentcalendar',
            name='types_proposes',
            field=models.CharField(choices=[('un', 'Un seul type'), ('plusieurs', 'Plusieurs types (à cocher)'), ('tous', 'Tous les types')], default='tous', help_text="Tous les types : ceux du prestataire choisi, ou ceux du site si aucun ne l'est.", max_length=10, verbose_name='Types proposés'),
        ),
        migrations.AlterField(
            model_name='contentcalendar',
            name='appointment_type',
            field=models.ForeignKey(blank=True, help_text='Pour « Un seul type ».', null=True, on_delete=django.db.models.deletion.SET_NULL, to='calendars.appointmenttype', verbose_name='Type de rendez-vous'),
        ),
        migrations.AlterField(
            model_name='contentcalendar',
            name='filtre_par_type',
            field=models.BooleanField(default=True, help_text="Des boutons « Tous · Massage 1h · … » au-dessus des créneaux, quand le bloc propose plus d'un type.", verbose_name='Le client filtre par type'),
        ),
        migrations.RunPython(un_seul_type_pour_ceux_qui_en_avaient_un, migrations.RunPython.noop),
    ]
