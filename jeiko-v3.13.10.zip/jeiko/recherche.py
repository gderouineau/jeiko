# jeiko/recherche.py
"""
La recherche du site public : `/recherche/?q=…`.

Le besoin : une documentation (jeiko.fr, kojei.fr) se lit en cherchant —
« comment activer les langues ? » — et un site sans recherche oblige à
deviner la page. On cherche donc dans tout ce que le site SERT au public :

* les pages : titre, titre et description SEO, texte de leurs blocs ;
* les fiches, produits compris (un produit EST une fiche) : titre,
  description SEO, valeurs texte ;
* les questionnaires et les formations actifs : titre, description.

Ce que la recherche voit est exactement ce que le visiteur peut ouvrir : les
mêmes filtres que le plan du site (`public_pages`, `fiches_publiques`). Une
page que l'exploitant a dit « non indexable » n'y est pas non plus : ce sont
les pages de remerciement, de confirmation — rien qu'on vient chercher.

Ce qu'elle ne fait PAS :

* pas de pertinence fine : un titre qui contient le terme passe devant, le
  reste suit dans l'ordre du site. `icontains` sur la base, sans index plein
  texte — # ponytail: balayage SQL à chaque recherche ; passer à la recherche
  plein texte de PostgreSQL (SearchVector + index GIN) si un site dépasse
  quelques milliers de pages ;
* pas de recherche dans les blocs « dynamiques » (FAQ, onglets, accordéons) :
  seulement les blocs de texte, où vit la documentation ;
* une langue à la fois : celle du visiteur. Le lecteur anglais trouve les
  versions anglaises, et les originales QUI N'EN ONT PAS — celles que le
  site lui sert faute de traduction. Sans elles, un site sans page anglaise
  répondait « aucun résultat » à tout lecteur anglais.
"""

import re
from html import unescape

from django.db.models import Q
from django.shortcuts import render
from django.urls import reverse
from django.utils.html import strip_tags
from django.utils.translation import gettext_lazy as _

TERME_MINIMUM = 2
RESULTATS_MAXIMUM = 50


def _extrait(texte, terme, largeur=160):
    """Le passage autour du terme, sans balises — ce que le lecteur reconnaît."""
    # Une balise de BLOC vaut une espace : « </h3><p> » collait le titre au
    # paragraphe. Pas une balise en ligne : « </strong>, » garde sa virgule.
    texte = re.sub(r"<(?:/?(?:p|div|h[1-6]|li|ul|ol|tr|td|th|blockquote|section)\b|br)",
                   r" \g<0>", texte or "", flags=re.I)
    texte = unescape(strip_tags(texte))
    texte = re.sub(r"\s+", " ", texte).strip()
    position = texte.lower().find(terme.lower())
    if position < 0:
        return texte[:largeur] + ("…" if len(texte) > largeur else "")
    debut = max(0, position - largeur // 3)
    if debut:  # commencer sur un mot entier, pas sur « …oduits »
        debut = texte.find(" ", debut, position) + 1 or debut
    fin = min(len(texte), debut + largeur)
    return ("…" if debut else "") + texte[debut:fin] + ("…" if fin < len(texte) else "")


def _dans_la_langue(queryset, langue):
    """Ce que lit un visiteur de `langue` : ses versions, et les originales sans version."""
    if not langue:
        return queryset.filter(langue="")
    traduites = queryset.model.versions_publiees(langue).values_list("traduction_de_id", flat=True)
    return queryset.filter(Q(langue=langue) | (Q(langue="") & ~Q(pk__in=list(traduites))))


def _pages(terme, langue):
    from jeiko.administration_pages.models import ContentText, Page
    from jeiko.administration_pages.querysets import public_pages

    pages = (
        _dans_la_langue(public_pages(Page.objects.filter(active=True, google_index=True)), langue)
        .filter(
            Q(title__icontains=terme)
            | Q(metadata__title__icontains=terme)
            | Q(metadata__description__icontains=terme)
            | Q(sections__lines__blocs__content__content_text__text__icontains=terme)
        )
        .select_related("metadata")
        .distinct()[:RESULTATS_MAXIMUM]
    )
    for page in pages:
        description = getattr(getattr(page, "metadata", None), "description", "") or ""
        texte = description
        if terme.lower() not in description.lower():
            bloc = (
                ContentText.objects
                .filter(content__bloc__line__section__page=page, text__icontains=terme)
                .values_list("text", flat=True).first()
            )
            texte = bloc or description
        yield {"genre": _("Page"), "titre": page.title, "adresse": page.get_absolute_url(),
               "extrait": _extrait(texte, terme)}


def _fiches(terme, langue):
    from jeiko.custom_objects.versions import fiches_publiques

    fiches = (
        _dans_la_langue(fiches_publiques(), langue)
        .filter(
            Q(title__icontains=terme)
            | Q(metadata__title__icontains=terme)
            | Q(metadata__description__icontains=terme)
            | Q(values__value_text__icontains=terme)
        )
        .distinct()[:RESULTATS_MAXIMUM]
    )
    for fiche in fiches:
        texte = fiche.description
        if terme.lower() not in (texte or "").lower():
            texte = fiche.values.filter(value_text__icontains=terme) \
                .values_list("value_text", flat=True).first() or texte
        # Le produit est porté par l'originale, pour toutes ses versions.
        produit = hasattr(fiche, "product") or hasattr(fiche.traduction_de or fiche, "product")
        yield {"genre": _("Produit") if produit else _("Fiche"),
               "titre": fiche.title, "adresse": fiche.get_absolute_url(),
               "extrait": _extrait(texte, terme)}


def _questionnaires(terme):
    from jeiko.questionnaires_expert.models import ExpertTest

    for test in ExpertTest.objects.filter(is_active=True).filter(
            Q(title__icontains=terme) | Q(description__icontains=terme))[:RESULTATS_MAXIMUM]:
        yield {"genre": _("Questionnaire"), "titre": test.title,
               "adresse": test.get_absolute_url(), "extrait": _extrait(test.description, terme)}


def _formations(terme):
    from jeiko.courses.models import Course

    for cours in Course.objects.filter(is_active=True).filter(
            Q(title__icontains=terme) | Q(description__icontains=terme))[:RESULTATS_MAXIMUM]:
        yield {"genre": _("Formation"), "titre": cours.title,
               "adresse": reverse("jeiko_courses:jeiko_courses_client:course_detail", args=[cours.slug]),
               "extrait": _extrait(cours.description, terme)}


def rechercher(terme, langue=""):
    """
    Les résultats pour `terme` dans `langue` ("" = langue d'origine) : une
    liste de {genre, titre, adresse, extrait}, les titres qui contiennent le
    terme d'abord. Vide sous deux lettres : « a » trouverait tout.
    """
    terme = (terme or "").strip()
    if len(terme) < TERME_MINIMUM:
        return []
    resultats = [*_pages(terme, langue), *_fiches(terme, langue),
                 *_questionnaires(terme), *_formations(terme)]
    # Tri stable : l'ordre de chaque famille est gardé à rang égal.
    resultats.sort(key=lambda r: terme.lower() not in str(r["titre"]).lower())
    return resultats[:RESULTATS_MAXIMUM]


def vue_recherche(request):
    from jeiko.langues_du_site import langue_du_site

    terme = (request.GET.get("q") or "").strip()[:200]
    return render(request, "recherche.html", {
        "terme": terme,
        "resultats": rechercher(terme, langue_du_site() or ""),
        "terme_trop_court": 0 < len(terme) < TERME_MINIMUM,
    })
