import json
import re

from django.conf import settings
from django.contrib import messages
from django.http import Http404, JsonResponse
from django.shortcuts import redirect, render
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt

from jeiko import throttling
from jeiko.acces_jeiko import AccesJeiko
from jeiko.administration.models import ReglagesRevendeur
from jeiko.reseaux.client import demander

from . import service
from .forms import CleRevendeurForm, HebergementForm, NouveauClientForm

API = "/api/revendeurs/"
CHEMIN = f"{API}clients/"
OBJETS = ("services", "licences", "resiliations")
GESTE = re.compile(r"[a-z-]{1,30}")


# --- Sur jeiko.fr : l'API ------------------------------------------------------


@method_decorator(csrf_exempt, name="dispatch")
class ApiClients(View):
    """`Authorization: Bearer <clé revendeur>`. GET : ses clients ; POST : un client de plus."""

    TAILLE_MAX = 16 * 1024

    def dispatch(self, request, *args, **kwargs):
        if not getattr(settings, "JEIKO_SERVEUR_DE_LICENCES", False):
            raise Http404
        if throttling.rate_limited(request, "revendeurs_api", 60, 60):
            return JsonResponse({"erreur": "trop de demandes"}, status=429)
        if len(request.body) > self.TAILLE_MAX:
            return JsonResponse({"erreur": "corps trop long"}, status=413)
        entete = request.headers.get("Authorization", "")
        try:
            self.revendeur = service.revendeur_de_la_cle(entete[7:] if entete.startswith("Bearer ") else "")
            self.corps = json.loads(request.body or b"{}") if request.method == "POST" else {}
            if not isinstance(self.corps, dict):
                raise ValueError
        except service.Refus as refus:
            return JsonResponse({"erreur": str(refus)}, status=403)
        except (ValueError, UnicodeDecodeError):
            return JsonResponse({"erreur": "objet JSON attendu"}, status=400)
        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        return JsonResponse({"revendeur": self.revendeur.titulaire, "droits": service.droits(self.revendeur),
                             "clients": service.clients(self.revendeur)})

    def post(self, request):
        try:
            licence = service.nouveau_client(self.revendeur, self.corps)
        except service.Refus as refus:
            return JsonResponse({"erreur": str(refus)}, status=400)
        return JsonResponse({"id": licence.pk, "cle": licence.cle_chiffree}, status=201)


class ApiGeste(ApiClients):
    """
    `/api/revendeurs/<services|licences|resiliations>/<pk>/<geste>/` : un geste
    sur une chose du revendeur (service.geste) ; GET `services/<pk>/journal/`,
    le journal de l'installeur. Celle d'un autre : 404.
    """

    def get(self, request, objet, pk, geste):
        try:
            if (objet, geste) != ("services", "journal"):
                raise service.Introuvable(_("Introuvable."))
            return JsonResponse({"journal": service.journal(self.revendeur, pk)})
        except service.Introuvable as refus:
            return JsonResponse({"erreur": str(refus)}, status=404)
        except service.Refus as refus:
            return JsonResponse({"erreur": str(refus)}, status=400)

    def post(self, request, objet, pk, geste):
        try:
            service.geste(self.revendeur, objet, pk, geste, self.corps)
        except service.Introuvable as refus:
            return JsonResponse({"erreur": str(refus)}, status=404)
        except service.Refus as refus:
            return JsonResponse({"erreur": str(refus)}, status=400)
        return JsonResponse({"fait": geste})


# --- Sur le site revendeur : la page du menu Jeiko -----------------------------


@method_decorator(never_cache, name="dispatch")
class Espace(AccesJeiko, View):
    reglage_jeiko = "JEIKO_ESPACE_REVENDEUR"

    def _rendre(self, request, form_cle=None, form_client=None, form_h=None, avec_hebergement=False):
        reglages = ReglagesRevendeur.get_solo()
        reponse = demander("GET", CHEMIN, reglages.cle) if reglages.cle else {}
        journal = None
        if reglages.cle and request.GET.get("journal", "").isdigit():
            lu = demander("GET", f"{API}services/{request.GET['journal']}/journal/", reglages.cle)
            journal = {"id": int(request.GET["journal"]), "texte": lu.get("journal") or lu.get("erreur", "")}
        return render(request, "revendeurs/admin/espace.html", {
            "indice": reglages.cle[-4:], "reponse": reponse, "clients": reponse.get("clients", []), "journal": journal,
            "form_cle": form_cle or CleRevendeurForm(),
            "form_client": form_client or NouveauClientForm(),
            "form_h": form_h or HebergementForm(prefix="h", initial={"datacenter": "GRA"}),
            "avec_hebergement": avec_hebergement,
        })

    def get(self, request):
        return self._rendre(request)

    def post(self, request):
        if request.POST.get("action") == "cle":
            return self._cle(request)
        if request.POST.get("action") == "geste":
            return self._geste(request)
        reglages = ReglagesRevendeur.get_solo()
        avec_hebergement = request.POST.get("avec_hebergement") == "oui"
        form_client = NouveauClientForm(request.POST)
        form_h = HebergementForm(request.POST, prefix="h")
        if not reglages.cle or not form_client.is_valid() or (avec_hebergement and not form_h.is_valid()):
            if not reglages.cle:
                messages.error(request, _("Collez d'abord la clé revendeur."))
            return self._rendre(request, form_client=form_client, form_h=form_h, avec_hebergement=avec_hebergement)
        corps = {**form_client.cleaned_data}
        if avec_hebergement:
            corps["hebergement"] = {nom: form_h.cleaned_data[nom] for nom in HebergementForm.Meta.fields}
        reponse = demander("POST", CHEMIN, reglages.cle, corps)
        if "erreur" in reponse:
            messages.error(request, reponse["erreur"])
            return self._rendre(request, form_client=form_client, form_h=form_h, avec_hebergement=avec_hebergement)
        messages.success(request, _("Client créé chez jeiko.fr : sa clé de licence est dans la liste.")
                         + (" " + _("La mise en ligne attend la confirmation de jeiko.fr.") if avec_hebergement else ""))
        return redirect("jeiko_revendeurs:espace")

    def _geste(self, request):
        """Relayé tel quel à jeiko.fr, qui vérifie que la chose est à ce revendeur : l'adresse seule est bornée ici."""
        objet, pk, geste = (request.POST.get(n, "") for n in ("objet", "pk", "geste"))
        reglages = ReglagesRevendeur.get_solo()
        if objet not in OBJETS or not pk.isdigit() or not GESTE.fullmatch(geste) or not reglages.cle:
            messages.error(request, _("Geste inconnu."))
            return redirect("jeiko_revendeurs:espace")
        corps = {n: request.POST[n] for n in ("choix", "j_ai_lu") if request.POST.get(n)}
        reponse = demander("POST", f"{API}{objet}/{pk}/{geste}/", reglages.cle, corps)
        if "erreur" in reponse:
            messages.error(request, reponse["erreur"])
        else:
            messages.success(request, _("Fait, chez jeiko.fr."))
        return redirect("jeiko_revendeurs:espace")

    def _cle(self, request):
        form = CleRevendeurForm(request.POST)
        if not form.is_valid():
            return self._rendre(request, form_cle=form)
        reglages = ReglagesRevendeur.get_solo()
        reglages.cle = form.cleaned_data["cle"]
        reglages.save()
        messages.success(request, _("Clé revendeur enregistrée."))
        return redirect("jeiko_revendeurs:espace")
