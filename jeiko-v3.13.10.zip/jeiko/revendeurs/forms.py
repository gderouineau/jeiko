from django import forms
from django.utils.translation import gettext_lazy as _

from jeiko.hebergement.forms import MiseEnLigneForm
from jeiko.licences import cles
from jeiko.licences.service import domaine_canonique


class NouveauClientForm(forms.Form):
    """Le client d'un revendeur : sur son site (l'écran) ET sur jeiko.fr (l'API revalide)."""

    titulaire = forms.CharField(label=_("Client"), max_length=200)
    email = forms.EmailField(label=_("E-mail du client"), required=False)
    domaine = forms.CharField(label=_("Domaine"), max_length=253)

    def clean_domaine(self):
        domaine = domaine_canonique(self.cleaned_data.get("domaine"))
        if not domaine:
            raise forms.ValidationError(_("Domaine invalide : écrivez-le sans https:// ni www, par exemple monsite.fr."))
        return domaine


class HebergementForm(MiseEnLigneForm):
    """La mise en ligne demandée à jeiko.fr : le client et le domaine viennent du formulaire du client."""

    class Meta(MiseEnLigneForm.Meta):
        fields = ["nom_du_site", "mode_domaine", "langue", "identifiant_admin", "email_admin", "offre",
                  "datacenter", "duree"]


class CleRevendeurForm(forms.Form):
    cle = forms.CharField(label=_("Clé revendeur"), max_length=80,
                          help_text=_("Donnée par jeiko.fr, une fois votre compte revendeur validé."))

    def clean_cle(self):
        cle = cles.canonique(self.cleaned_data.get("cle"))
        if not cle:
            raise forms.ValidationError(_("Une clé : 12 à 64 caractères, lettres, chiffres et tirets."))
        return cle
