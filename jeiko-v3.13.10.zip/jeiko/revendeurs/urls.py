from django.urls import path

from . import views

app_name = "jeiko_revendeurs"

urlpatterns = [
    path("", views.Espace.as_view(), name="espace"),
]
