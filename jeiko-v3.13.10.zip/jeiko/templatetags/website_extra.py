# blog/templatetags/blog_extras.py

from django.template import Library, Node

from jeiko.administration.website_cache import get_website_data

register = Library()

class GetWebSiteData(Node):
    def render(self, context):
        # Objet de site mis en cache (identity + logo joints), invalidé par
        # signal — cf. administration/website_cache.py. Évite ~3 requêtes par
        # page pour un objet qui change rarement.
        context['website_data'] = get_website_data()
        return ''

@register.tag(name="get_website_data")
def get_all_menus(parser, token):

    return GetWebSiteData()



MARQUES = {"jeiko.fr", "kojei.fr"}


@register.simple_tag
def propulse_par():
    """La marque du « Powered by » : jeiko.fr, ou kojei.fr ; rien d'autre."""
    from django.conf import settings
    marque = getattr(settings, "JEIKO_PROPULSE_PAR", "jeiko.fr")
    return marque if marque in MARQUES else "jeiko.fr"
