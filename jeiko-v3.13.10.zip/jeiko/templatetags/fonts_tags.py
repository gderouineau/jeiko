"""
Tags de chargement des polices self-hostées (pages publiques).

Le CSS `@font-face` local est généré par jeiko.fonts_selfhost au moment de
l'enregistrement des polices en admin (et par la commande `rebuild_fonts`).
"""

from django import template
from django.utils.safestring import mark_safe

from jeiko.fonts_selfhost import _BASE_WEIGHTS, _ITAL_WGHT_AXIS, collect_weights, site_css_relurl

register = template.Library()


@register.simple_tag
def local_fonts_link(website_data):
    """`<link>` vers le bundle de polices local du site, bustée par
    assets_version. Chaîne vide si aucun bundle n'a encore été généré (le
    rendu retombe alors sur les familles de secours) — lancer
    `manage.py rebuild_fonts` pour le créer."""
    if not website_data:
        return ""
    href = site_css_relurl(website_data)
    if not href:
        return ""
    version = getattr(website_data, "assets_version", None)
    if version:
        href = f"{href}?v={version}"
    # Non bloquant (PageSpeed, 28/09/2026) : le bundle ne contient que des
    # `@font-face` en `font-display: swap` — le texte s'affiche de toute façon
    # dans la police de secours le temps du chargement. Le bloquer ne faisait
    # que retarder le premier affichage. Même procédé que footer.css.
    return mark_safe(
        # Bascule par jk-actions.js (data-jk-media), pas par onload : S-03.
        f'<link rel="stylesheet" href="{href}" media="print" data-jk-media="all">'
        f'<noscript><link rel="stylesheet" href="{href}"></noscript>'
    )


@register.simple_tag
def cdn_fonts_link(website_data):
    """Polices via le CDN Google pour l'ÉDITEUR/admin (fluidité d'édition).

    Émet UN seul `<link>` par famille DISTINCTE réellement utilisée (au lieu
    des ~33 `<link>` de l'ancien includes/google_fonts.html, un par rôle ×
    breakpoint). Un lien par famille reste indépendant : si une famille ne
    supporte pas tous les axes, seule celle-là échoue (pas de cascade).
    Le préchargement (preconnect) est déjà posé dans base_editor.html.
    """
    if not website_data:
        return ""
    graisses = collect_weights(website_data)
    families = sorted(graisses)
    if not families:
        return ""
    links = []
    for fam in families:
        spec = fam.replace(" ", "+")
        # Le jeu de base dans un lien, chaque graisse de plus (300…) dans le
        # sien : si la famille n'a pas cette graisse, seul ce lien échoue.
        axes = [_ITAL_WGHT_AXIS] + [f"wght@{w}" for w in sorted(graisses[fam] - _BASE_WEIGHTS)]
        for axe in axes:
            href = f"https://fonts.googleapis.com/css2?family={spec}:{axe}&display=swap"
            links.append(f'<link rel="stylesheet" href="{href}">')
    return mark_safe("\n".join(links))
