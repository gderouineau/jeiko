"""
Le thème d'une page : celui de sa catégorie, sinon celui du site.

Un site à plusieurs métiers (Électricité, Plomberie…) a déjà ses menus par
catégorie ; la palette suit le même chemin, pour qu'un sous-site ait aussi ses
couleurs. L'ordre est celui des menus (`menu_tags._resolve_menu_for_page`) :
sous-catégorie, son parent, puis la catégorie de la page.

Ce que ce module ne fait pas : il ne remplace pas le thème du site. Celui-ci
reste posé sur `:root` pour toutes les pages ; le thème de catégorie est posé
JUSTE APRÈS et ne fait que redéfinir les mêmes variables. Une page hors de
toute catégorie — ou d'une catégorie sans thème — ne change donc pas d'un
pixel.
"""

from django import template

register = template.Library()


def theme_de_la_page(page):
    """Le thème choisi par la catégorie de la page, ou None."""
    if page is None:
        return None
    sous = getattr(page, "sub_category", None)
    candidates = [sous, getattr(sous, "main_category", None), getattr(page, "category", None)]
    for categorie in candidates:
        if categorie is not None and getattr(categorie, "theme_id", None):
            return categorie.theme
    return None


@register.simple_tag(takes_context=True)
def theme_de_categorie(context):
    """`{% theme_de_categorie as theme %}` — None quand le thème du site suffit."""
    theme = theme_de_la_page(context.get("page"))
    # L'identifiant, pas l'objet : `website_data` vient du cache, et son thème
    # peut avoir été supprimé depuis — `site.theme` lèverait alors une
    # exception au milieu du rendu de la page.
    defaut_id = getattr(context.get("website_data"), "theme_id", None)
    if theme is None or theme.pk == defaut_id:
        return None
    return theme
