"""
Qui entre dans le menu « Jeiko » (licences, hébergement OVH) — OVH-01, 01/11/2026.

Guillaume : « que personne ne puisse y avoir accès ». Ce menu commande des
serveurs payés et tient les clés de tous les clients : être super-administrateur
du site ne suffit pas. Il faut, ensemble :
* le module allumé dans le .env (`JEIKO_SERVEUR_DE_LICENCES`,
  `JEIKO_HEBERGEMENT_OVH`) ;
* l'adresse du compte dans `JEIKO_ACCES_JEIKO` (le .env : adresses séparées
  par des virgules ; vide = personne) ;
* cette adresse CONFIRMÉE et principale (allauth) — `user.email` seul ne
  suffit pas : tout super-administrateur peut le réécrire à l'écran, sans
  confirmation, et s'attribuer l'adresse du .env (audit à froid F1) ;
* un compte super-administrateur, actif ;
* la double authentification en place sur ce compte (le code par e-mail de
  users/twofactor.py, ou une méthode d'allauth.mfa).
Sinon : 404, pas 403 — on ne dit pas qu'il y a quelque chose ici.

Pourquoi le .env : un super-administrateur créé par erreur, ou par une faille
de l'application, n'y entre pas. Il faut la main sur le serveur.

Ce que ça ne fait pas : vérifier que LA session en cours est passée par le
second facteur. La connexion l'exige de tout compte qui en a un
(users/adapters.pre_login) ; une session ouverte AVANT qu'on l'active garde
donc l'accès jusqu'à sa fin — activer le second facteur, puis se reconnecter.
"""
from django.conf import settings
from django.http import Http404


def comptes_autorises():
    brut = getattr(settings, "JEIKO_ACCES_JEIKO", "") or ""
    if isinstance(brut, (list, tuple)):
        brut = ",".join(brut)
    return {adresse.strip().lower() for adresse in brut.split(",") if adresse.strip()}


def second_facteur(user):
    from jeiko.users import twofactor
    from jeiko.users.adapters import _mfa_allauth_active

    return twofactor.user_requires_2fa(user) or _mfa_allauth_active(user)


def adresse_confirmee(user):
    from allauth.account.models import EmailAddress

    return EmailAddress.objects.filter(user=user, email__iexact=(user.email or "").strip(),
                                       verified=True, primary=True).exists()


def autorise(user):
    return bool(
        user and user.is_authenticated and user.is_active and user.is_superuser
        and (user.email or "").strip().lower() in comptes_autorises()
        and adresse_confirmee(user)
        and second_facteur(user)
    )


class AccesJeiko:
    """Garde de CHAQUE vue du menu. `reglage_jeiko` : l'interrupteur du module."""

    reglage_jeiko = ""

    def dispatch(self, request, *args, **kwargs):
        if not getattr(settings, self.reglage_jeiko, False) or not autorise(request.user):
            raise Http404
        return super().dispatch(request, *args, **kwargs)
