"""
Les moyens de paiement de la boutique, et lesquels sont proposés.

Stripe était le seul : le tunnel l'appelait en dur. Cette couche dit, pour
chaque moyen, s'il est allumé et prêt, et la page de paiement les montre
dans cet ordre. Chaque moyen autre que Stripe est **éteint par défaut** :
il s'allume dans Paiements › Moyens de paiement (`ShopSettings`), et ses
clés, quand il en a, viennent du `.env` (`settings.template.py`).

Stripe garde son comportement exact : tant qu'aucun autre moyen n'est
allumé, la page de paiement montre son formulaire comme avant, même si sa
passerelle n'est pas encore active (le message d'erreur de Stripe Elements
le dit, comme avant).

Ajouter un moyen (« Pay by bank » par GoCardless ou Fintecture, voir
`PAIEMENTS_ETUDE.md`) : une classe de plus dans `MOYENS`, sa vue, son
webhook vérifié.

Un abonnement ne passe que par Stripe (Checkout) ; une commande à 0 € ne
passe par aucun : la page de paiement les traite avant de consulter ce
module.
"""

from django.conf import settings
from django.utils.translation import gettext_lazy as _


class Moyen:
    code = ""
    libelle = ""

    def disponible(self):
        raise NotImplementedError


class Stripe(Moyen):
    code = "stripe"
    libelle = _("Carte bancaire")

    def disponible(self):
        from .models import PaymentGateway

        return PaymentGateway.objects.filter(code="stripe", is_active=True).exists()


class Virement(Moyen):
    code = "virement"
    libelle = _("Virement bancaire")

    def disponible(self):
        from jeiko.shop.models import ShopSettings

        reglages = ShopSettings.get_solo()
        # Sans IBAN, le client ne saurait pas où virer.
        return bool(reglages.virement_actif and (reglages.iban or "").strip())


class PayPal(Moyen):
    code = "paypal"
    libelle = _("PayPal")

    def disponible(self):
        from jeiko.shop.models import ShopSettings

        return bool(ShopSettings.get_solo().paypal_actif and paypal_configure())


def paypal_configure():
    """Les trois clés du .env : sans l'identifiant du webhook, rien ne serait vérifié."""
    return all(
        (getattr(settings, nom, "") or "").strip()
        for nom in ("JEIKO_PAYPAL_CLIENT_ID", "JEIKO_PAYPAL_SECRET", "JEIKO_PAYPAL_WEBHOOK_ID")
    )


MOYENS = (Stripe(), Virement(), PayPal())


def moyens_proposes():
    """
    Les codes des moyens à montrer sur la page de paiement, dans l'ordre.

    Aucun autre moyen allumé : Stripe seul, qu'il soit actif ou non — c'est
    le comportement d'avant cette couche.
    """
    autres = [m.code for m in MOYENS if m.code != "stripe" and m.disponible()]
    if not autres:
        return ["stripe"]
    stripe = ["stripe"] if Stripe().disponible() else []
    return stripe + autres


def est_propose(code):
    return code in moyens_proposes()
