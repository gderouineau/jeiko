from django.urls import path
from ..views.admin import PaymentGatewayListView, PaymentGatewayUpdateView, PaymentGatewayCreateView, MoyensDePaiementView

app_name = 'jeiko_payments_admin'

urlpatterns = [
    path('gateways/', PaymentGatewayListView.as_view(), name='gateway_list'),
    path('gateways/add/', PaymentGatewayCreateView.as_view(), name='gateway_add'),
    path('moyens/', MoyensDePaiementView.as_view(), name='moyens'),
    path('gateways/<int:pk>/', PaymentGatewayUpdateView.as_view(), name='gateway_update'),
]
