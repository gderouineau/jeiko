from django.urls import path
from ..views.client import (
    CheckoutView,
    PaymentStepView,
    CreatePaymentIntentView,
    StripeWebhookView,
    PaymentSuccessView,
    PaymentCancelView,
    PaymentCheckView,
    AbonnementView,
    CommandeConfirmeeView,
    CommandeGratuiteView,
    AbonnementRetourView,
    PortailAbonnementView,
)

from ..views.moyens import PayPalRetourView, PayPalView, PayPalWebhookView, VirementView

app_name = 'jeiko_payments_client'

urlpatterns = [
    path('checkout/', CheckoutView.as_view(), name='checkout'),
    path('checkout/paiement/', PaymentStepView.as_view(), name='payment'),
    path('checkout/gratuit/', CommandeGratuiteView.as_view(), name='commande_gratuite'),
    path('create-payment-intent/', CreatePaymentIntentView.as_view(), name='create_payment_intent'),
    path('webhook/stripe/', StripeWebhookView.as_view(), name='stripe_webhook'),
    # Les autres moyens (payments/moyens.py), éteints par défaut.
    path('checkout/virement/', VirementView.as_view(), name='virement'),
    path('checkout/paypal/', PayPalView.as_view(), name='paypal'),
    path('paypal/retour/', PayPalRetourView.as_view(), name='paypal_retour'),
    path('webhook/paypal/', PayPalWebhookView.as_view(), name='paypal_webhook'),
    path('check/', PaymentCheckView.as_view(), name='check'),
    path('success/', PaymentSuccessView.as_view(), name='success'),
    path('cancel/', PaymentCancelView.as_view(), name='cancel'),
    path('abonnement/', AbonnementView.as_view(), name='abonnement'),
    path('abonnement/retour/', AbonnementRetourView.as_view(), name='abonnement_retour'),
    path('merci/<int:pk>/', CommandeConfirmeeView.as_view(), name='merci'),
    path('abonnement/gerer/', PortailAbonnementView.as_view(), name='abonnement_portail'),
]
