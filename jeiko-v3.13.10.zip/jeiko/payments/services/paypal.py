"""
PayPal Checkout, API REST v2 — sans script PayPal dans la page.

Le parcours :

1. `creer_la_commande` — le serveur crée une commande PayPal (intention
   CAPTURE) au montant que `preparer_commande` vient de calculer, et rend
   l'adresse où le client l'approuve ;
2. le client approuve chez PayPal et revient sur `paypal/retour/` ;
3. `capturer` — le serveur encaisse, puis `reglement_conforme` compare ce qui
   a été capturé à ce qui est dû avant de régler la commande.

Le webhook (`PAYMENT.CAPTURE.COMPLETED`) rattrape le client qui ferme
l'onglet entre l'encaissement et le retour. **Il n'est cru qu'après
vérification par PayPal** (`verifier_le_webhook`, avec l'identifiant du
webhook du .env) : un corps posté par n'importe qui ne règle rien.

Les clés vivent dans le `.env` (`JEIKO_PAYPAL_*`), jamais en base.
`JEIKO_PAYPAL_SANDBOX`, vrai par défaut, envoie tout au bac à sable.
"""

import logging
from decimal import Decimal

import requests
from django.conf import settings

logger = logging.getLogger(__name__)

BAC_A_SABLE = "https://api-m.sandbox.paypal.com"
PRODUCTION = "https://api-m.paypal.com"
DELAI = 20


class PayPalErreur(Exception):
    pass


def base():
    return BAC_A_SABLE if getattr(settings, "JEIKO_PAYPAL_SANDBOX", True) else PRODUCTION


def _jeton():
    try:
        reponse = requests.post(
            f"{base()}/v1/oauth2/token",
            auth=(settings.JEIKO_PAYPAL_CLIENT_ID, settings.JEIKO_PAYPAL_SECRET),
            data={"grant_type": "client_credentials"},
            timeout=DELAI,
        )
    except requests.RequestException as exc:
        raise PayPalErreur("PayPal injoignable") from exc
    if reponse.status_code != 200:
        raise PayPalErreur(f"Jeton PayPal refusé ({reponse.status_code})")
    return reponse.json()["access_token"]


def _appel(methode, chemin, json=None, cle=None):
    entetes = {"Authorization": f"Bearer {_jeton()}", "Content-Type": "application/json"}
    if cle:
        # Idempotence : un double clic ou un retour rejoué rend la même chose.
        entetes["PayPal-Request-Id"] = cle
    try:
        reponse = requests.request(methode, f"{base()}{chemin}", json=json, headers=entetes, timeout=DELAI)
    except requests.RequestException as exc:
        raise PayPalErreur("PayPal injoignable") from exc
    try:
        corps = reponse.json()
    except ValueError:
        corps = {}
    return reponse.status_code, corps


def montant(valeur):
    """« 12.30 » : PayPal veut une chaîne à deux décimales."""
    return f"{Decimal(valeur).quantize(Decimal('0.01'))}"


def _cle(nature, order):
    site = getattr(settings, "SITE_NAME", "") or "jeiko"
    return f"jeiko-{site}-paypal-{nature}-{order.pk}-{montant(order.total_ttc)}-{order.currency}"


def creer_la_commande(order, retour, annulation):
    """Rend (identifiant de la commande PayPal, adresse d'approbation)."""
    site = getattr(settings, "SITE_NAME", "") or "jeiko"
    corps = {
        "intent": "CAPTURE",
        "purchase_units": [{
            "reference_id": str(order.pk),
            # Ce qui rattache un avis de webhook à SA commande.
            "custom_id": str(order.pk),
            "description": f"Commande {order.pk}"[:127],
            "amount": {"currency_code": order.currency.upper(), "value": montant(order.total_ttc)},
        }],
        "payment_source": {"paypal": {"experience_context": {
            "return_url": retour, "cancel_url": annulation,
            "user_action": "PAY_NOW", "shipping_preference": "NO_SHIPPING",
            "brand_name": site[:127],
        }}},
    }
    statut, reponse = _appel("POST", "/v2/checkout/orders", corps, cle=_cle("creation", order))
    if statut not in (200, 201):
        raise PayPalErreur(f"Commande PayPal refusée ({statut}) : {reponse.get('name', '')}")
    lien = next((l["href"] for l in reponse.get("links", ())
                 if l.get("rel") in ("payer-action", "approve")), None)
    if not lien:
        raise PayPalErreur("PayPal n'a pas rendu d'adresse d'approbation")
    return reponse["id"], lien


def capturer(paypal_order_id):
    """Encaisse une commande approuvée ; déjà encaissée, la relit."""
    statut, reponse = _appel("POST", f"/v2/checkout/orders/{paypal_order_id}/capture", {},
                             cle=f"capture-{paypal_order_id}")
    if statut in (200, 201):
        return reponse
    details = reponse.get("details") or [{}]
    if statut == 422 and details[0].get("issue") == "ORDER_ALREADY_CAPTURED":
        statut, reponse = _appel("GET", f"/v2/checkout/orders/{paypal_order_id}")
        if statut == 200:
            return reponse
    raise PayPalErreur(f"Capture PayPal refusée ({statut}) : {reponse.get('name', '')}")


def capture_de(commande_paypal):
    """La capture d'une commande PayPal relue : (unité d'achat, capture) ou (None, None)."""
    for unite in commande_paypal.get("purchase_units") or ():
        for capture in (unite.get("payments") or {}).get("captures") or ():
            return unite, capture
    return None, None


def reglement_conforme(order, paypal_order_id, custom_id, capture):
    """`None` si la capture règle exactement la commande, sinon la raison."""
    if not order.paypal_order_id or paypal_order_id != order.paypal_order_id:
        return (f"commande PayPal {paypal_order_id} ≠ commande PayPal en cours "
                f"({order.paypal_order_id or 'aucune'}) : paiement d'une version périmée")
    if str(custom_id or "") != str(order.pk):
        return f"commande désignée {custom_id} ≠ commande {order.pk}"
    if (capture or {}).get("status") != "COMPLETED":
        return f"capture au statut {(capture or {}).get('status')}"
    somme = (capture or {}).get("amount") or {}
    if str(somme.get("currency_code") or "").upper() != order.currency.upper():
        return f"devise encaissée {somme.get('currency_code')} ≠ devise de la commande {order.currency}"
    if str(somme.get("value") or "") != montant(order.total_ttc):
        return f"encaissé {somme.get('value')} ≠ dû {montant(order.total_ttc)} {order.currency}"
    return None


#: Les en-têtes que PayPal pose sur chaque avis, et les champs où la
#: vérification les attend.
ENTETES_DU_WEBHOOK = {
    "auth_algo": "HTTP_PAYPAL_AUTH_ALGO",
    "cert_url": "HTTP_PAYPAL_CERT_URL",
    "transmission_id": "HTTP_PAYPAL_TRANSMISSION_ID",
    "transmission_sig": "HTTP_PAYPAL_TRANSMISSION_SIG",
    "transmission_time": "HTTP_PAYPAL_TRANSMISSION_TIME",
}


def verifier_le_webhook(meta, evenement):
    """
    Vrai seulement si PayPal confirme que l'avis vient de lui, pour CE webhook.

    Ne lève jamais : un avis invérifiable est un avis refusé.
    """
    webhook_id = (getattr(settings, "JEIKO_PAYPAL_WEBHOOK_ID", "") or "").strip()
    if not webhook_id:
        logger.error("Webhook PayPal refusé : JEIKO_PAYPAL_WEBHOOK_ID absent du .env.")
        return False
    corps = {cle: meta.get(entete, "") for cle, entete in ENTETES_DU_WEBHOOK.items()}
    if not all(corps.values()):
        return False
    corps.update(webhook_id=webhook_id, webhook_event=evenement)
    try:
        statut, reponse = _appel("POST", "/v1/notifications/verify-webhook-signature", corps)
    except PayPalErreur:
        logger.exception("Vérification du webhook PayPal impossible")
        return False
    return statut == 200 and reponse.get("verification_status") == "SUCCESS"
