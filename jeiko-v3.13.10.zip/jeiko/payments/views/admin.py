from django.views.generic import ListView, UpdateView, CreateView
from django.contrib import messages
from django.urls import reverse, reverse_lazy
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from ..models import PaymentGateway
from ..forms import MoyensDePaiementForm, PaymentGatewayForm


# Ces écrans exposent les clés Stripe du site. Ils ne portaient que
# LoginRequiredMixin : tout compte connecté — un simple client inscrit — y
# accédait. On revient à la convention du reste de l'administration
# (PermissionRequiredMixin + raise_exception), qui passe par les rôles.

class PaymentGatewayListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = PaymentGateway
    template_name = 'payments/admin/gateway_list.html'
    context_object_name = 'gateways'

    permission_required = 'payments.view_paymentgateway'
    raise_exception = True


class PaymentGatewayUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = PaymentGateway
    form_class = PaymentGatewayForm
    template_name = 'payments/admin/gateway_form.html'

    permission_required = 'payments.change_paymentgateway'

    def get_success_url(self):
        messages.success(self.request, _("Moyen de paiement enregistré."))
        return reverse('jeiko_payments_admin:gateway_list')
    raise_exception = True

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['update'] = True
        if self.object.code == 'stripe':
            from .. import branchement
            context['branchement'] = {
                'verifications': branchement.verifications(self.object),
                'adresse': branchement.adresse_du_webhook(self.request),
                'evenements': branchement.EVENEMENTS,
                'version': branchement.VERSION_DE_L_API,
                'documentation': branchement.DOCUMENTATION,
            }
        return context


class PaymentGatewayCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = PaymentGateway
    form_class = PaymentGatewayForm
    template_name = 'payments/admin/gateway_form.html'
    success_url = reverse_lazy('jeiko_payments_admin:gateway_list')

    permission_required = 'payments.add_paymentgateway'
    raise_exception = True


class MoyensDePaiementView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    """Virement et PayPal : les allumer, et ce qu'il faut déclarer chez PayPal."""

    form_class = MoyensDePaiementForm
    template_name = 'payments/admin/moyens.html'
    permission_required = 'payments.change_paymentgateway'
    raise_exception = True

    def get_object(self, queryset=None):
        from jeiko.shop.models import ShopSettings

        return ShopSettings.get_solo()

    def get_success_url(self):
        messages.success(self.request, _("Moyens de paiement enregistrés."))
        return reverse('jeiko_payments_admin:moyens')

    def get_context_data(self, **kwargs):
        from django.conf import settings

        from ..moyens import paypal_configure

        context = super().get_context_data(**kwargs)
        context['paypal'] = {
            'configure': paypal_configure(),
            'bac_a_sable': getattr(settings, 'JEIKO_PAYPAL_SANDBOX', True),
            'webhook': self.request.build_absolute_uri(reverse('jeiko_payments_client:paypal_webhook')),
        }
        return context
