"""
Les moyens de paiement autres que Stripe : virement manuel et PayPal.

Les gardes sont celles du tunnel Stripe (`views/client.py`) : un compte, des
coordonnées, une commande recalculée par `preparer_commande` — seul juge de
ce que coûte le panier —, ni abonnement (Stripe seul), ni total nul
(`CommandeGratuiteView`). Un moyen éteint dans les réglages renvoie à la
page de paiement.

Choisir un de ces moyens annule l'intention Stripe éventuellement ouverte
pour la commande : elle ne doit plus pouvoir être réglée deux fois.
"""

import json
import logging

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import transaction
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views import View
from django.views.decorators.csrf import csrf_exempt

from jeiko.shop.models import Order
from jeiko.shop.services import CommandeImpossible, mark_order_paid, preparer_commande
from jeiko.shop.views.client import BoutiqueEnLigneRequiredMixin, get_or_create_cart

from .. import moyens
from ..services import paypal

logger = logging.getLogger(__name__)


class _ChoixDuMoyen(BoutiqueEnLigneRequiredMixin, LoginRequiredMixin, View):
    """La commande prête à payer par `code`, ou une redirection."""

    code = ""

    def _commande(self, request):
        if not moyens.est_propose(self.code):
            return None, redirect("jeiko_payments_client:payment")
        cart = get_or_create_cart(request)
        if not Order.objects.filter(cart=cart, user=request.user).exclude(billing_name="").exists():
            return None, redirect("jeiko_payments_client:checkout")
        try:
            order = preparer_commande(request.user, cart)
        except CommandeImpossible as exc:
            messages.error(request, str(exc))
            return None, redirect("jeiko_client_shop:cart_detail")
        lignes = order.lines.select_related("product", "variant")
        if order.total_ttc <= 0 or any(l.product and l.product.intervalle(l.variant) for l in lignes):
            return None, redirect("jeiko_payments_client:payment")
        if order.payment_intent_id:
            from ..services.stripe import StripeService

            StripeService().cancel_payment_intent(order.payment_intent_id)
        return order, None


class VirementView(_ChoixDuMoyen):
    """
    Le client choisit de payer par virement : la commande est confirmée, en
    attente de paiement, et son panier fermé — un ajout ne la réécrit plus.
    Elle ne sera réglée (accès, stock, facture, e-mails) que quand
    l'exploitant la marquera payée, à réception du virement.
    """

    code = Order.MOYEN_VIREMENT

    @transaction.atomic
    def post(self, request):
        order, refus = self._commande(request)
        if refus:
            return refus
        order.payment_method = Order.MOYEN_VIREMENT
        order.order_status = Order.ORDER_STATUS_CONFIRMED
        order.save(update_fields=["payment_method", "order_status", "updated_at"])
        if order.cart_id and not order.cart.is_locked:
            order.cart.is_locked = True
            order.cart.save(update_fields=["is_locked", "updated_at"])
        logger.info("Commande #%s : paiement par virement attendu.", order.pk)
        return redirect("jeiko_payments_client:merci", pk=order.pk)


class PayPalView(_ChoixDuMoyen):
    """Part chez PayPal approuver la commande, au montant recalculé ici."""

    code = Order.MOYEN_PAYPAL

    @transaction.atomic
    def post(self, request):
        order, refus = self._commande(request)
        if refus:
            return refus
        try:
            identifiant, approbation = paypal.creer_la_commande(
                order,
                retour=request.build_absolute_uri(reverse("jeiko_payments_client:paypal_retour")),
                annulation=request.build_absolute_uri(reverse("jeiko_payments_client:payment")),
            )
        except paypal.PayPalErreur:
            logger.exception("Commande PayPal impossible (commande #%s)", order.pk)
            messages.error(request, _("Le paiement n'a pas pu être initialisé."))
            return redirect("jeiko_payments_client:payment")
        order.payment_method = Order.MOYEN_PAYPAL
        order.paypal_order_id = identifiant
        order.save(update_fields=["payment_method", "paypal_order_id", "updated_at"])
        return HttpResponseRedirect(approbation)


def regler_par_paypal(order, paypal_order_id, custom_id, capture, source):
    """Règle la commande si la capture lui est conforme ; sinon alerte. Rend vrai si réglée."""
    from ..verification import signaler_paiement_non_conforme

    ecart = paypal.reglement_conforme(order, paypal_order_id, custom_id, capture)
    if ecart:
        if order.payment_status != Order.PAYMENT_STATUS_PAID:
            signaler_paiement_non_conforme(order, {"id": paypal_order_id}, ecart, source)
        return False
    mark_order_paid(order, source=source)
    return True


class PayPalRetourView(LoginRequiredMixin, View):
    """
    Retour du client après approbation : on capture, et l'on ne croit que la
    réponse de PayPal, jamais l'adresse. La commande doit être celle du
    visiteur et porter cette commande PayPal.
    """

    def get(self, request):
        identifiant = (request.GET.get("token") or "").strip()
        order = (Order.objects.filter(paypal_order_id=identifiant, user=request.user).first()
                 if identifiant else None)
        if order is None:
            return redirect("jeiko_payments_client:checkout")
        if order.payment_status == Order.PAYMENT_STATUS_PAID:
            return redirect("jeiko_payments_client:merci", pk=order.pk)
        try:
            commande_paypal = paypal.capturer(identifiant)
        except paypal.PayPalErreur:
            logger.exception("Capture PayPal %s impossible (commande #%s)", identifiant, order.pk)
            messages.error(request, _("Le paiement n'a pas abouti."))
            return redirect("jeiko_payments_client:payment")
        unite, capture = paypal.capture_de(commande_paypal)
        with transaction.atomic():
            regle = regler_par_paypal(order, commande_paypal.get("id"), (unite or {}).get("custom_id"),
                                      capture, "paypal:return")
        if not regle and order.payment_status != Order.PAYMENT_STATUS_PAID:
            messages.error(request, _("Le paiement n'a pas abouti."))
            return redirect("jeiko_payments_client:payment")
        return redirect("jeiko_payments_client:merci", pk=order.pk)


@method_decorator(csrf_exempt, name="dispatch")
class PayPalWebhookView(View):
    """
    Les avis de PayPal. Un avis n'est cru qu'après vérification par PayPal
    lui-même (`paypal.verifier_le_webhook`) ; refusé, il reçoit un 400.
    Seul `PAYMENT.CAPTURE.COMPLETED` règle une commande, et seulement si la
    capture lui est conforme (montant, devise, commande PayPal en cours).
    """

    def post(self, request):
        try:
            evenement = json.loads(request.body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return HttpResponse(status=400)
        if not isinstance(evenement, dict) or not paypal.verifier_le_webhook(request.META, evenement):
            logger.warning("Avis PayPal refusé : signature non vérifiée.")
            return HttpResponse(status=400)
        if evenement.get("event_type") == "PAYMENT.CAPTURE.COMPLETED":
            capture = evenement.get("resource") or {}
            custom_id = str(capture.get("custom_id") or "")
            paypal_order_id = ((capture.get("supplementary_data") or {}).get("related_ids") or {}).get("order_id")
            order = Order.objects.filter(pk=custom_id).first() if custom_id.isdigit() else None
            if order is None:
                logger.info("Avis PayPal pour une commande inconnue (%s) : ignoré.", custom_id)
            else:
                with transaction.atomic():
                    regler_par_paypal(order, paypal_order_id, custom_id, capture, "paypal:webhook")
        return HttpResponse(status=200)
