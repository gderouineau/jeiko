# jeiko/agents/vues_menus.py
"""
La construction des menus — la structure et les liens, pas le design.

Ce que permet cette surface
---------------------------
Un site JEIKO peut porter **plusieurs menus**, et les affecter par catégorie :
`Category.main_menu` et `Category.footer_menu`. C'est ce qui permet des
**sous-sites** — sur ateliersderouineau.com, « Électricité » et « Plomberie »
ont des menus identiques à l'œil et des liens différents.

Construire cela à la main veut dire recréer un menu entier, entrée par entrée,
pour chaque branche. D'où `copie_de` à la création : le nouveau menu naît avec
la même disposition et la même arborescence que son modèle, et il ne reste
qu'à réaffecter les pages. C'est exactement le geste décrit — « les mêmes
visuellement, les liens ne sont pas les mêmes ».

Ce qui n'est PAS ouvert, et pourquoi
-------------------------------------
**Le design des menus** (`MenuStyle`) : couleurs, polices, tailles, survols.
L'exploitant l'a demandé explicitement — « pas des designs ». Un style de menu
se règle une fois et se partage entre menus ; le modifier depuis une clé
d'édition de structure changerait l'apparence de menus qu'on ne visait pas.
`disposition` fait exception : un menu ne peut pas exister sans elle, et un
menu dupliqué doit garder celle de son modèle.

**La suppression.** Un menu supprimé emporte ses entrées, et laisse sans menu
toutes les catégories et pages qui le désignaient — c'est-à-dire un site sans
navigation, sans qu'aucune page en particulier paraisse en cause.

La règle d'écriture des entrées
--------------------------------
Envoyer « elements » REMPLACE l'arborescence entière. Deux raisons, et la
seconde est technique : une liste ordonnée n'a pas de clé stable sur laquelle
fusionner ; et `MenuItem` porte deux contraintes d'unicité sur la position
(par menu pour le premier niveau, par parent pour les sous-entrées), qu'une
mise à jour partielle violerait dès qu'on insère au milieu.
"""

from django.db import transaction
from django.shortcuts import get_object_or_404

from jeiko.administration_menu.models import (
    LAYOUTS_BY_PLACE, Menu, MenuItem, MenuLayout, MenuPlace,
)
from jeiko.administration_pages.models import Category, Page

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR = "administration_menu.view_menu"
AJOUTER = "administration_menu.add_menu"
MODIFIER = "administration_menu.change_menu"

CLES_MENU = {
    "nom", "emplacement", "disposition", "par_defaut", "afficher_le_panier",
    "elements",
}
CLES_ELEMENT = {"titre", "page", "actif", "sous_elements"}

EMPLACEMENTS = [code for code, _ in MenuPlace.choices]
DISPOSITIONS = [code for code, _ in MenuLayout.choices]


# --------------------------------------------------------------------------- #
#  Sérialisation
# --------------------------------------------------------------------------- #
def _element_en_dict(element):
    return {
        "id": element.id,
        "titre": element.title,
        "page": element.page_id,
        "actif": element.active,
        "sous_elements": [
            _element_en_dict(sous)
            for sous in element.submenus.all().order_by("position", "id")
        ],
    }


def _menu_en_dict(menu, avec_elements=True):
    document = {
        "id": menu.id,
        "nom": menu.name,
        "emplacement": menu.place,
        "disposition": menu.layout,
        "par_defaut": menu.is_default,
        "afficher_le_panier": menu.show_cart,
        # Ce à quoi il est rattaché : c'est la question qu'on se pose en
        # arrivant sur un site à plusieurs menus, et y répondre demande
        # autrement de parcourir toutes les catégories.
        # Des objets, pas des slugs.
        #
        # Un slug de sous-catégorie n'est unique que sous SON parent : deux
        # univers peuvent légitimement avoir chacun leur « articles » et leur
        # « services ». La liste de slugs devenait alors indéchiffrable — on ne
        # savait pas quel « articles » ce menu servait, et il fallait deviner
        # par le parent. L'identifiant, lui, ne ment jamais.
        #
        # « categories » reste servie telle quelle : des appelants s'en
        # servent, et la retirer serait une rupture. Elle est simplement
        # doublée par une forme exploitable.
        "categories": sorted(
            c.slug or c.name
            for c in list(menu.categories_main_menu.all())
            + list(menu.categories_footer_menu.all())
        ),
        "categories_detail": [
            {
                "id": c.id,
                "slug": c.slug or "",
                "nom": c.name,
                "parent": getattr(c, "main_category_id", None),
                "rattachement": rattachement,
            }
            for rattachement, groupe in (
                ("principal", menu.categories_main_menu.all()),
                ("pied_de_page", menu.categories_footer_menu.all()),
            )
            for c in groupe
        ],
    }
    if avec_elements:
        document["elements"] = [
            _element_en_dict(e)
            for e in menu.menu_items.filter(main_menu__isnull=True)
                                    .prefetch_related("submenus")
                                    .order_by("position", "id")
        ]
    return document


# --------------------------------------------------------------------------- #
#  Aides
# --------------------------------------------------------------------------- #
def _verifier_la_disposition(emplacement, disposition):
    """
    Toutes les dispositions ne valent pas pour tous les emplacements.

    `LAYOUTS_BY_PLACE` le dit : le pied de page n'en a aucune pour l'instant.
    En poser une quand même produirait un menu qui ne se rend pas — encore une
    panne muette.
    """
    autorisees = LAYOUTS_BY_PLACE.get(emplacement, set())

    if not autorisees:
        # Cet emplacement n'accepte AUCUNE disposition — c'est le cas du pied
        # de page aujourd'hui. Une contrainte de base le fait respecter, mais
        # par une `CheckViolation`, c'est-à-dire une 500 : un défaut de l'API
        # rendu comme une panne de serveur. On refuse proprement avant.
        if disposition:
            raise CorpsInvalide(
                f"L'emplacement « {emplacement} » n'accepte pas de "
                f"disposition — ne pas envoyer « disposition »."
            )
        return

    if disposition not in autorisees:
        raise CorpsInvalide(
            f"La disposition « {disposition} » ne vaut pas pour l'emplacement "
            f"« {emplacement} ». Acceptées : {', '.join(sorted(autorisees))}."
        )


def _ecrire_les_elements(menu, elements, parent=None, deja_vues=None):
    """
    Recrée l'arborescence d'un menu, en profondeur.

    Tout est validé avant le premier effacement : un menu à moitié réécrit,
    c'est une navigation amputée sur toutes les pages à la fois.
    """
    if not isinstance(elements, list):
        raise CorpsInvalide("« elements » doit être une liste.")

    prepares = _preparer_les_elements(elements)

    if parent is None:
        menu.menu_items.all().delete()
    _creer_les_elements(menu, prepares, parent=None)


def _preparer_les_elements(elements, chemin="elements"):
    """Valide récursivement, sans rien écrire."""
    prepares = []
    for rang, brut in enumerate(elements, 1):
        ou = f"{chemin}[{rang}]"
        if not isinstance(brut, dict):
            raise CorpsInvalide(f"{ou} : un objet est attendu.")

        inconnues = sorted(set(brut) - CLES_ELEMENT)
        if inconnues:
            raise CorpsInvalide(
                f"{ou} : clé(s) inconnue(s) — {', '.join(inconnues)}. "
                f"Acceptées : {', '.join(sorted(CLES_ELEMENT))}."
            )

        titre = str(brut.get("titre") or "").strip()
        if not titre:
            raise CorpsInvalide(f"{ou} : « titre » est obligatoire.")

        page = None
        if brut.get("page"):
            page = Page.objects.filter(pk=brut["page"]).first()
            if page is None:
                raise CorpsInvalide(
                    f"{ou} : aucune page nº {brut['page']}. Une entrée qui "
                    f"pointe vers rien ne mène nulle part."
                )

        prepares.append({
            "title": titre[:100],
            "page": page,
            "active": bool(brut.get("actif", True)),
            "sous": _preparer_les_elements(
                brut.get("sous_elements") or [], f"{ou}.sous_elements"
            ),
        })
    return prepares


def _creer_les_elements(menu, prepares, parent):
    for position, valeurs in enumerate(prepares, 1):
        sous = valeurs.pop("sous")
        element = MenuItem.objects.create(
            menu=menu, main_menu=parent, position=position, **valeurs
        )
        valeurs["sous"] = sous  # on rend le dict intact à l'appelant
        if sous:
            _creer_les_elements(menu, sous, parent=element)


# --------------------------------------------------------------------------- #
#  Menus
# --------------------------------------------------------------------------- #
class ListeDesMenus(VueAgent):
    permission_requise = VOIR

    def get(self, request):
        menus = Menu.objects.prefetch_related(
            "menu_items__submenus", "categories_main_menu", "categories_footer_menu"
        ).order_by("place", "name")
        return ok({
            "menus": [_menu_en_dict(m) for m in menus],
            "emplacements": EMPLACEMENTS,
            "dispositions": DISPOSITIONS,
        })


class CreationMenu(VueAgent):
    """
    Crée un menu — éventuellement en COPIANT un existant.

    `copie_de` est le geste qui fait les sous-sites : le nouveau menu naît avec
    la disposition et l'arborescence de son modèle, et il ne reste qu'à
    réaffecter les pages. Sans lui, chaque branche d'un site se reconstruit
    entrée par entrée, et la moindre différence d'oubli se voit.
    """

    permission_requise = AJOUTER

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)
        inconnues = sorted(set(corps) - CLES_MENU - {"copie_de"})
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Acceptées : copie_de, {', '.join(sorted(CLES_MENU))}."
            )

        nom = str(corps.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide("« nom » est obligatoire.")

        modele = None
        if corps.get("copie_de"):
            modele = Menu.objects.filter(pk=corps["copie_de"]).first()
            if modele is None:
                raise CorpsInvalide(f"Aucun menu nº {corps['copie_de']} à copier.")

        emplacement = str(
            corps.get("emplacement") or (modele.place if modele else MenuPlace.MAIN)
        )
        if emplacement not in EMPLACEMENTS:
            raise CorpsInvalide(
                f"Emplacement « {emplacement} » inconnu. "
                f"Attendus : {', '.join(EMPLACEMENTS)}."
            )

        # Le défaut dépend de l'emplacement : le pied de page n'accepte
        # aucune disposition, imposer celle du menu principal le ferait
        # échouer sur une contrainte de base.
        # `None`, pas une chaîne vide : la contrainte
        # `menu_layout_required_for_main_only` exige `layout IS NULL` hors
        # menu principal, et `""` la viole aussi sûrement qu'une disposition.
        if LAYOUTS_BY_PLACE.get(emplacement):
            defaut = modele.layout if modele else MenuLayout.LOGO_LEFT_MENU_RIGHT
            disposition = corps.get("disposition") or defaut
        else:
            disposition = corps.get("disposition") or None
        _verifier_la_disposition(emplacement, disposition)

        menu = Menu.objects.create(
            name=nom[:150],
            place=emplacement,
            layout=disposition,
            # Jamais par défaut à la création : une contrainte n'autorise qu'un
            # seul menu par défaut et par emplacement, et le prendre d'office
            # débrancherait le menu en service sans qu'on l'ait demandé.
            is_default=False,
            show_cart=bool(
                corps.get("afficher_le_panier",
                          modele.show_cart if modele else False)
            ),
            menu_style=modele.menu_style if modele else None,
            logo=modele.logo if modele else None,
        )

        if "elements" in corps:
            _ecrire_les_elements(menu, corps["elements"])
        elif modele is not None:
            _copier_les_elements(modele, menu)

        return ok({"menu": _menu_en_dict(menu)}, statut=201)


def _copier_les_elements(source, destination):
    """Recopie l'arborescence d'un menu vers un autre, sous-entrées comprises."""
    def copier(elements, parent):
        for element in elements.order_by("position", "id"):
            clone = MenuItem.objects.create(
                menu=destination, main_menu=parent, position=element.position,
                title=element.title, page=element.page, active=element.active,
            )
            copier(element.submenus, clone)

    copier(source.menu_items.filter(main_menu__isnull=True), None)


class DetailMenu(VueAgent):
    permission_requise = VOIR

    def get(self, request, menu_id):
        menu = get_object_or_404(
            Menu.objects.prefetch_related("menu_items__submenus"), pk=menu_id
        )
        return ok({"menu": _menu_en_dict(menu)})

    @transaction.atomic
    def patch(self, request, menu_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification de menu non autorisée.", statut=403)

        menu = get_object_or_404(Menu, pk=menu_id)
        corps = self.corps(request)
        inconnues = sorted(set(corps) - CLES_MENU)
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Acceptées : {', '.join(sorted(CLES_MENU))}. "
                f"Le style visuel des menus n'est pas ouvert ici."
            )

        modifies = []
        if "nom" in corps:
            menu.name = str(corps["nom"]).strip()[:150]
            modifies.append("name")
        if "emplacement" in corps:
            if corps["emplacement"] not in EMPLACEMENTS:
                raise CorpsInvalide(
                    f"Emplacement inconnu. Attendus : {', '.join(EMPLACEMENTS)}."
                )
            menu.place = corps["emplacement"]
            modifies.append("place")
        if "disposition" in corps:
            # `None` et non `""` : voir la contrainte de base.
            menu.layout = corps["disposition"] or None
            modifies.append("layout")
        if "afficher_le_panier" in corps:
            menu.show_cart = bool(corps["afficher_le_panier"])
            modifies.append("show_cart")

        _verifier_la_disposition(menu.place, menu.layout)

        if "par_defaut" in corps and corps["par_defaut"]:
            # Une contrainte n'autorise qu'un défaut par emplacement : libérer
            # l'ancien plutôt que de lever une UniqueViolation, c'est-à-dire
            # une 500. Même raisonnement que la page racine.
            Menu.objects.filter(place=menu.place, is_default=True).exclude(
                pk=menu.pk
            ).update(is_default=False)
            menu.is_default = True
            modifies.append("is_default")

        if modifies:
            menu.save()

        if "elements" in corps:
            _ecrire_les_elements(menu, corps["elements"])
            modifies.append("elements")

        menu.refresh_from_db()
        return ok({"menu": _menu_en_dict(menu), "modifie": modifies})


# --------------------------------------------------------------------------- #
#  Affectation — c'est ici que se font les sous-sites
# --------------------------------------------------------------------------- #
class MenusDeLaCategorie(VueAgent):
    """
    Affecte un menu principal et un menu de pied de page à une catégorie.

    C'est LE point qui fait les sous-sites : toutes les pages d'une catégorie
    prennent ses menus. Un menu retiré (`null`) rend la catégorie au menu par
    défaut du site.
    """

    permission_requise = MODIFIER

    @transaction.atomic
    def patch(self, request, categorie_id):
        categorie = get_object_or_404(Category, pk=categorie_id)
        corps = self.corps(request)
        inconnues = sorted(set(corps) - {"menu_principal", "menu_pied_de_page"})
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Acceptées : menu_principal, menu_pied_de_page."
            )

        modifies = []
        for cle, champ, emplacement in (
            ("menu_principal", "main_menu", MenuPlace.MAIN),
            ("menu_pied_de_page", "footer_menu", MenuPlace.FOOTER),
        ):
            if cle not in corps:
                continue

            valeur = corps[cle]
            if valeur in (None, "", 0):
                setattr(categorie, champ, None)
                modifies.append(champ)
                continue

            menu = Menu.objects.filter(pk=valeur).first()
            if menu is None:
                raise CorpsInvalide(f"Aucun menu nº {valeur}. Voir /menus/.")
            # Un menu de pied de page posé en menu principal ne se rendrait
            # pas : les dispositions ne sont pas les mêmes.
            if menu.place != emplacement:
                raise CorpsInvalide(
                    f"Le menu « {menu.name} » est un menu « {menu.place} », "
                    f"pas « {emplacement} » : il ne se rendrait pas à cette place."
                )
            setattr(categorie, champ, menu)
            modifies.append(champ)

        if modifies:
            categorie.save(update_fields=modifies)

        return ok({
            "categorie": {
                "id": categorie.id,
                "nom": categorie.name,
                "slug": categorie.slug,
                "menu_principal": categorie.main_menu_id,
                "menu_pied_de_page": categorie.footer_menu_id,
            },
            "modifie": modifies,
        })
