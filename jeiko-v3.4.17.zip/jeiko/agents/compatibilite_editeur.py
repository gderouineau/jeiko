"""
Ce qu'un bloc TEXT peut contenir sans que l'éditeur ne le détruise.

Le problème
-----------
Le contenu d'un bloc TEXT est édité dans l'administration par **Quill**, qui
ne travaille pas sur du HTML mais sur son propre modèle de document. Ce qu'il
ne sait pas représenter, il ne l'abîme pas : il le fait disparaître.

Et il ne le fait pas au moment où on édite. `editor.js` pose le HTML stocké
dans l'éditeur, puis réinjecte aussitôt ce que Quill en a fait dans le champ
caché du formulaire. **Ouvrir un bloc et enregistrer sans rien toucher suffit
donc à le vider.**

Mesuré, pas supposé : un `<div class="carte"><h2>…</h2><p>…</p></div>` de
trois cents caractères ressort de Quill en `<p><br></p>`. Le bloc est vide.
Sur un site en service, treize blocs étaient dans cet état — dont neuf sur la
page d'accueil.

Ce que ce module empêche
------------------------
Qu'un agent écrive, par l'API, du HTML que l'exploitant ne pourra plus
modifier sans le perdre. Le site rendrait ce contenu parfaitement ; c'est le
retour vers l'éditeur qui est impossible, et rien ne le signalait.

Le refus porte donc sur une propriété qu'aucun test de rendu ne peut voir :
**l'aller-retour**. C'est aussi pourquoi il vit ici et non dans `sanitize.py`,
qui répond à une autre question — ce qui est sûr à servir.

Ce qu'il ne résout pas
----------------------
Les contenus écrits AVANT ce garde-fou restent en base tels quels. Les
réécrire à plat est un geste distinct, à faire en connaissance de cause.

Et l'éditeur lui-même n'est pas réparé : il détruira toujours ce qu'on lui
donne. On l'empêche seulement d'en recevoir.
"""

#: Les balises qui vident le bloc ENTIER, et par quoi les remplacer.
#:
#: Chacune a été éprouvée contre Quill 2.0.3, la version chargée par
#: l'administration : on a posé le HTML dans un éditeur neuf et relu ce que
#: Quill en avait fait. Les conclusions ne viennent pas de la documentation de
#: Quill mais de son comportement observé.
BALISES_QUI_VIDENT = {
    "div": (
        "Un <div> ne sert qu'à porter un fond, une bordure ou un espacement — "
        "et tout cela se règle dans les PARAMÈTRES du bloc (fond, bordure, "
        "paddings, tailles), où l'exploitant peut ensuite les modifier. "
        "Écrivez le contenu à plat : <h2 class=\"…\">, <p class=\"…\">, sans "
        "conteneur. Les classes sur ces éléments-là, elles, survivent."
    ),
    "figure": (
        "Écrivez l'image dans un <p> et sa légende dans un <p> suivant, avec "
        "des classes. L'encadré se règle par les paramètres du bloc."
    ),
    "pre": (
        "Le texte préformaté n'est pas représentable. Pour du code, utilisez "
        "un <p> par ligne, ou une classe et une règle « white-space: pre » "
        "dans css.custom."
    ),
    "details": (
        "Un repli écrit à la main ne survit pas à l'éditeur. Les blocs "
        "DYN_ACCORDION_ADV et DYN_FAQ font exactement cela, et restent "
        "modifiables élément par élément."
    ),
    "ul": (
        "Quill n'écrit pas les listes en <ul>. Le format qu'il relit — et que "
        "le site rend à l'identique, puces comprises — est : "
        "<ol><li data-list=\"bullet\">…</li></ol>. Pour une liste numérotée, "
        "data-list=\"ordered\"."
    ),
}

#: Ce qui traverse Quill sans dommage. Sert au message d'erreur : dire ce
#: qu'on refuse sans dire ce qui marche laisse l'appelant à sa perplexité.
CE_QUI_TRAVERSE = (
    '<p class="…"> et <h1>…<h6 class="…"> — la classe est conservée',
    "<strong> <em> <a href> <img> <table>",
    'style="color: …; background-color: …; text-align: …" en ligne',
    '<ol><li data-list="bullet"> pour les listes',
    "<blockquote>",
)


class ContenuNonEditable(Exception):
    """Le HTML serait détruit par l'éditeur. Porte le message rendu."""


def _balises_presentes(html):
    """Les noms de balises ouvrantes, en minuscules, sans analyser plus loin.

    Une expression régulière suffit et vaut mieux qu'un analyseur ici : on
    cherche la PRÉSENCE d'un nom, pas une structure. Un faux positif dans un
    commentaire ou une chaîne coûte un message d'erreur explicite ; un faux
    négatif coûte un bloc vidé chez le client.
    """
    import re

    return {nom.lower() for nom in re.findall(r"<\s*([a-zA-Z][\w-]*)", html or "")}


def verifier(html):
    """Lève `ContenuNonEditable` si l'éditeur détruirait ce contenu."""
    presentes = _balises_presentes(html)
    fautives = [b for b in BALISES_QUI_VIDENT if b in presentes]
    if not fautives:
        return

    details = "\n".join(
        f"  <{balise}> — {BALISES_QUI_VIDENT[balise]}" for balise in fautives
    )
    quoi = ", ".join(f"<{b}>" for b in fautives)
    raise ContenuNonEditable(
        f"Ce contenu serait DÉTRUIT par l'éditeur de l'administration : "
        f"{quoi}. Le site le rendrait correctement, mais l'exploitant ne "
        f"pourrait plus le modifier — ouvrir le bloc et enregistrer suffirait "
        f"à le vider entièrement.\n\n{details}\n\n"
        f"Ce qui traverse l'éditeur sans dommage :\n  "
        + "\n  ".join(CE_QUI_TRAVERSE)
        + "\n\nLa mise en page — fond, bordure, colonnes, espacements — ne "
        "s'écrit pas en HTML : elle se règle dans les paramètres du bloc, de "
        "la ligne et de la section."
    )
