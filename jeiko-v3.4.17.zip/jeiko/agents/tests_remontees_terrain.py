# jeiko/agents/tests_remontees_terrain.py
"""
Défauts remontés par un agent qui a monté un site entier sans rien savoir.

L'exercice
----------
Un assistant a reçu la clé d'un site en service et le seul mode d'emploi que
l'API sert d'elle-même — pas nos notes, pas notre mémoire des pièges. Il a
construit, et rapporté ce qui l'avait trompé. Ce qu'il a trouvé n'est pas ce
qu'on aurait cherché : ce sont les endroits où l'API répond « oui » et ne
fait rien, ou répond juste et mesure autre chose.

Ce fichier verrouille ceux qui étaient des défauts. Chaque classe nomme le
symptôme tel qu'il a été observé, parce que c'est sous cette forme qu'il
reviendra.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Bloc, Line, Page, Section

from .tests import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class CleInconnueDansLesParametresTests(SocleMixin, TestCase):
    """
    P2 — « PATCH {"couleur_de_fond": "#fff"} → 200, et rien ne change. »

    Le mode d'emploi PROMET l'inverse : « une clé inconnue est refusée, jamais
    ignorée ». La promesse était tenue pour les contenus de bloc — dont le
    message d'erreur est un modèle du genre — et pas pour les paramètres, qui
    lisaient les clés connues et laissaient tomber le reste.

    Pour un humain, c'est une minute perdue à comprendre pourquoi la couleur
    n'a pas pris. Pour un agent, c'est pire : il tient le 200 pour une
    confirmation et passe à la suite. Le défaut ne se découvre qu'en relisant
    le rendu, s'il y pense — et le rapport montre qu'on n'y pense pas toujours.
    """

    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent paramètres",
        )
        page = Page.objects.create(title="Essai", url_tag="essai-cles")
        self.section = Section.objects.create(page=page, position=0)
        self.ligne = Line.objects.create(
            section=self.section, position=0, columns_type="12", columns_number=1
        )
        self.bloc = Bloc.objects.create(
            line=self.ligne, position=0, position_in_column=0
        )

    def _patch(self, chemin, corps):
        return self.client.patch(
            f"/api/agent/v1/{chemin}", data=json.dumps(corps),
            content_type="application/json", **self.entetes(self.jeton),
        )

    def test_la_cle_inventee_est_refusee_sur_une_section(self):
        reponse = self._patch(f"sections/{self.section.id}/",
                              {"couleur_de_fond": "#ffffff"})
        self.assertEqual(reponse.status_code, 400)
        message = reponse.json()["erreur"]
        self.assertIn("couleur_de_fond", message, "Le message doit nommer la clé.")
        self.assertIn("fond", message, "Et indiquer où la couleur se règle.")

    def test_la_cle_inventee_est_refusee_sur_une_ligne_et_un_bloc(self):
        for chemin in (f"lignes/{self.ligne.id}/", f"blocs/{self.bloc.id}/"):
            with self.subTest(chemin=chemin):
                reponse = self._patch(chemin, {"nimportequoi": 1})
                self.assertEqual(reponse.status_code, 400)
                self.assertIn("nimportequoi", reponse.json()["erreur"])

    def test_le_message_nomme_les_cles_acceptees(self):
        """Se corriger sans relire la documentation : c'est tout l'objet."""
        message = self._patch(f"sections/{self.section.id}/",
                              {"xyz": 1}).json()["erreur"]
        for attendue in ("fond", "marges", "paddings", "tailles", "css"):
            self.assertIn(attendue, message)

    def test_une_cle_inconnue_sous_fond_est_refusee_aussi(self):
        reponse = self._patch(f"sections/{self.section.id}/",
                              {"fond": {"color": "#fff"}})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("color", reponse.json()["erreur"])

    def test_les_vraies_cles_passent_toujours(self):
        """Le garde ne doit pas fermer la porte à ce qui marchait."""
        reponse = self._patch(
            f"sections/{self.section.id}/",
            {"fond": {"couleur": "rgba(24,28,38,1)"},
             "paddings": {"phone": {"haut": "40px"}},
             "css": {"custom": ".content .x{color:red;}"}},
        )
        self.assertEqual(reponse.status_code, 200, reponse.content[:400])
        self.section.refresh_from_db()
        self.assertEqual(self.section.background_color, "rgba(24,28,38,1)")


class AdresseMesureeTests(TestCase):
    """
    P1 — trois pages mesurées à la même adresse, dont deux qui répondent 404.

    L'URL donnée à PageSpeed était bâtie sur `url_tag` seul. Une page rangée
    dans « électricité » et servie à `/electricite/accueil/` était mesurée sur
    `/accueil/` — l'accueil du site, qui existe. D'autres tombaient sur des
    adresses inexistantes et rapportaient « performance 100 » : Lighthouse
    note très bien une page d'erreur, qui est légère et sans images.

    Le relevé était donc plausible, daté, chiffré. Il mesurait autre chose.
    """

    def setUp(self):
        from jeiko.administration_pages.models import Category

        self.categorie = Category.objects.create(
            name="Électricité", slug="electricite", show_cat_in_url=True
        )

    def _adresse(self, page):
        from jeiko.administration_pages.utils import page_public_url

        return page_public_url(page)

    def test_la_categorie_est_dans_l_adresse_mesuree(self):
        page = Page.objects.create(
            title="Accueil Électricité", url_tag="accueil-elec",
            category=self.categorie,
        )
        self.assertTrue(
            self._adresse(page).endswith("/electricite/accueil-elec/"),
            f"Adresse mesurée : {self._adresse(page)}",
        )

    def test_la_racine_est_mesuree_a_la_racine(self):
        # L'installation en pose une, et la base n'en accepte qu'une seule.
        racine = Page.objects.filter(is_root=True).first() or Page.objects.create(
            title="Accueil", url_tag="accueil", is_root=True
        )
        self.assertTrue(
            self._adresse(racine).rstrip("/").count("/") == 2,   # https://hôte
            f"La racine doit être mesurée sur « / », pas « /accueil/ » : "
            f"{self._adresse(racine)}",
        )

    def test_deux_pages_de_categories_differentes_ont_deux_adresses(self):
        """Le symptôme exact du rapport : trois pages, une seule adresse."""
        from jeiko.administration_pages.models import Category

        autre = Category.objects.create(
            name="Plomberie", slug="plomberie", show_cat_in_url=True
        )
        a = Page.objects.create(title="A", url_tag="accueil-univers",
                                category=self.categorie)
        b = Page.objects.create(title="B", url_tag="accueil-univers-2",
                                category=autre)
        self.assertNotEqual(self._adresse(a), self._adresse(b))

    def test_une_page_en_brouillon_ne_se_mesure_pas(self):
        """
        Un brouillon répond 404 : la mesure porterait sur la page d'erreur.

        On refuse en amont plutôt que de rendre un score flatteur qui ne
        concerne pas la page.
        """
        from jeiko.administration_pages.services.pagespeed import run_pagespeed_refresh

        brouillon = Page.objects.create(
            title="Brouillon", url_tag="brouillon-mesure", active=False
        )
        with self.assertRaises(RuntimeError) as leve:
            run_pagespeed_refresh(brouillon, "mobile")
        self.assertIn("brouillon", str(leve.exception).lower())


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class ReponsesExploitablesTests(SocleMixin, TestCase):
    """
    P6, P7, P8 — trois réponses qu'un agent ne pouvait pas exploiter.

    Aucune n'est un défaut de fonctionnement : le site marchait. Ce sont des
    réponses qui obligent à deviner, et deviner est exactement ce qu'un agent
    fait mal. Trois ajouts de clé, aucune rupture.
    """

    def setUp(self):
        self.agent, self.jeton = self.creer()
        # `donner_le_role` ne couvre qu'une application à la fois : les pages
        # et les menus vivent dans deux applications distinctes.
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent lecture pages",
        )
        donner_le_role(
            self.agent.user, "view_menu", "change_menu",
            app="administration_menu", nom="Agent lecture menus",
        )

    def test_un_gabarit_de_fiche_est_annonce_comme_tel(self):
        """
        « publiee: true » sur une page qui répond 404 est contradictoire.

        Ça ne l'est qu'en apparence — un gabarit de fiche n'a pas d'existence
        propre, il sert à rendre les objets d'un modèle. Encore faut-il que
        la réponse le dise.
        """
        gabarit = Page.objects.create(
            title="Gabarit", url_tag="gabarit-fiche",
            is_custom_object_template=True,
        )
        ordinaire = Page.objects.create(title="Simple", url_tag="page-simple")

        reponse = self.client.get(
            f"/api/agent/v1/pages/{gabarit.id}/", **self.entetes(self.jeton)
        )
        self.assertTrue(reponse.json()["page"]["gabarit_de_fiche"])

        reponse = self.client.get(
            f"/api/agent/v1/pages/{ordinaire.id}/", **self.entetes(self.jeton)
        )
        self.assertFalse(reponse.json()["page"]["gabarit_de_fiche"])

    def test_une_image_sans_fichier_est_signalee(self):
        """
        Trente-huit entrées sur quatre-vingt-quatre n'avaient aucun fichier.

        Indiscernables des bonnes tant qu'on ne lit pas « url », et un
        « image_id » posé sur l'une d'elles produit un fond vide sans erreur.
        """
        from jeiko.administration_pages.models import ImageContent

        vide = ImageContent.objects.create(alt="orpheline")
        reponse = self.client.get(
            "/api/agent/v1/images/", **self.entetes(self.jeton)
        )
        trouvee = [i for i in reponse.json()["images"] if i["id"] == vide.id]
        self.assertEqual(len(trouvee), 1)
        self.assertTrue(
            trouvee[0]["fichier_absent"],
            "Une entrée sans fichier doit être filtrable sans heuristique.",
        )

    def test_les_categories_d_un_menu_sont_identifiables(self):
        """
        Deux sous-catégories peuvent légitimement partager un slug.

        « articles » sous « électricité » et « articles » sous « plomberie »
        sont deux catégories distinctes. La liste de slugs ne permettait pas
        de savoir laquelle un menu servait.
        """
        from jeiko.administration_menu.models import Menu
        from jeiko.administration_pages.models import Category

        parent_a = Category.objects.create(name="Électricité", slug="electricite")
        parent_b = Category.objects.create(name="Plomberie", slug="plomberie")
        a = Category.objects.create(
            name="Articles élec", slug="articles", main_category=parent_a
        )
        b = Category.objects.create(
            name="Articles plomberie", slug="articles", main_category=parent_b
        )

        menu = Menu.objects.create(name="Électricité principal")
        a.main_menu = menu
        a.save(update_fields=["main_menu"])

        reponse = self.client.get(
            "/api/agent/v1/menus/", **self.entetes(self.jeton)
        )
        document = [m for m in reponse.json()["menus"] if m["id"] == menu.id][0]
        identifiants = [c["id"] for c in document["categories_detail"]]
        self.assertIn(a.id, identifiants)
        self.assertNotIn(
            b.id, identifiants,
            "Les deux « articles » doivent être distinguables par identifiant.",
        )


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class MediathequeLisibleTests(SocleMixin, TestCase):
    """
    P7 — la moitié de la médiathèque était invisible, et les fichiers existaient.

    Premier diagnostic, erroné : « trente-huit entrées sur quatre-vingt-quatre
    n'ont aucun fichier ». Vérification faite sur le rendu, c'était l'inverse —
    les fichiers sont là, servis en production, déclinés en cinq variantes.
    C'est l'API qui ne les voyait pas : elle lisait `original_image` et rien
    d'autre, quand le rendu prend `laptop_size` en priorité et ne retombe sur
    l'original qu'en dernier recours.

    Une image dont l'original a disparu — effacé pour gagner de la place,
    jamais conservé par un import — sortait donc avec « url: "" » tout en
    s'affichant parfaitement sur le site. Un agent ne pouvait ni la décrire ni
    la choisir, et rien ne le lui disait : la réponse était bien formée,
    l'identifiant correct, le champ simplement vide.

    La leçon dépasse le cas : l'API doit répondre à la question posée — « puis-je
    m'en servir » — et non à celle du schéma de la base.
    """

    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(self.agent.user, "view_page", nom="Agent médiathèque")

    def _images(self):
        reponse = self.client.get(
            "/api/agent/v1/images/", **self.entetes(self.jeton)
        )
        return {i["id"]: i for i in reponse.json()["images"]}

    def test_une_image_sans_original_mais_avec_variantes_est_utilisable(self):
        from jeiko.administration_pages.models import ImageContent

        image = ImageContent.objects.create(alt="fond du hero")
        # On simule l'état réel : l'original manque, les dérivées sont là.
        ImageContent.objects.filter(pk=image.pk).update(
            laptop_size="images/hero-laptop.webp",
            mobile_size="images/hero-mobile.webp",
        )

        vue = self._images()[image.id]
        self.assertFalse(
            vue["fichier_absent"],
            "Cette image s'affiche sur le site : la dire absente est un mensonge.",
        )
        self.assertTrue(vue["url"], "Une URL utilisable doit être rendue.")
        self.assertIn("hero-laptop", vue["url"])
        self.assertIn("hero-mobile", vue["apercu"])
        self.assertIn("laptop_size", vue["variantes"])

    def test_l_url_suit_le_meme_ordre_que_le_rendu(self):
        """Ce que l'agent lit doit être ce que le visiteur verra."""
        from jeiko.administration_pages.models import ImageContent

        image = ImageContent.objects.create()
        ImageContent.objects.filter(pk=image.pk).update(
            original_image="images/o.jpg",
            full_size="images/f.webp",
            laptop_size="images/l.webp",
        )
        self.assertIn("l.webp", self._images()[image.id]["url"])

    def test_une_entree_vraiment_vide_reste_signalee(self):
        """Le drapeau garde son sens : aucun fichier, dans aucune variante."""
        from jeiko.administration_pages.models import ImageContent

        vide = ImageContent.objects.create(alt="orpheline")
        vue = self._images()[vide.id]
        self.assertTrue(vue["fichier_absent"])
        self.assertEqual(vue["url"], "")
        self.assertEqual(vue["variantes"], {})


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class AssainissementALEcritureTests(SocleMixin, TestCase):
    """
    P9 — la relecture ne montrait pas ce que le visiteur verrait.

    L'assainissement s'appliquait au rendu, pas à l'écriture. L'API rendait
    donc fidèlement ce qu'elle avait stocké — HTML intact, `<svg>` compris —
    et le visiteur voyait une page amputée.

    C'est le pire cas de figure, parce qu'il désarme la parade que le guide
    recommande lui-même : « relis ce que tu écris, une écriture peut réussir
    sans rien produire ». Ici la relecture confirmait tout, et mentait.

    Deux garanties désormais : ce qui est stocké est ce qui sera servi, et
    l'appel dit ce qu'il a retiré.
    """

    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent écriture",
        )
        page = Page.objects.create(title="Essai", url_tag="essai-assainissement")
        section = Section.objects.create(page=page, position=0)
        ligne = Line.objects.create(
            section=section, position=0, columns_type="12", columns_number=1
        )
        self.bloc = Bloc.objects.create(line=ligne, position=0, position_in_column=0)

    def _ecrire(self, html):
        return self.client.put(
            f"/api/agent/v1/blocs/{self.bloc.id}/contenu/",
            data=json.dumps({"type": "TEXT", "texte": html}),
            content_type="application/json", **self.entetes(self.jeton),
        )

    def _relire(self):
        reponse = self.client.get(
            f"/api/agent/v1/blocs/{self.bloc.id}/", **self.entetes(self.jeton)
        )
        return reponse.json()["bloc"]["contenu"]["texte"]

    def test_ce_qu_on_relit_est_ce_qui_sera_servi(self):
        """La garantie de fond, et le seul test qui compte vraiment."""
        self._ecrire('<p class="k"><svg viewBox="0 0 9 9"></svg></p><h2>T</h2>')
        relu = self._relire()
        self.assertNotIn("svg", relu, "Le <svg> ne survit pas au rendu : "
                                      "il ne doit pas survivre à la relecture.")
        self.assertIn("<h2>T</h2>", relu, "Le reste doit être intact.")

    def test_l_appel_dit_ce_qu_il_a_retire(self):
        reponse = self._ecrire('<p onclick="x()"><svg></svg>texte</p>')
        self.assertEqual(reponse.status_code, 200)
        avertissements = " ".join(reponse.json().get("avertissements", []))
        self.assertIn("svg", avertissements)
        self.assertIn("onclick", avertissements)

    def test_un_html_propre_ne_produit_aucun_avertissement(self):
        """Un avertissement systématique serait vite ignoré."""
        reponse = self._ecrire('<p class="ok">Rien à redire</p>')
        self.assertNotIn("avertissements", reponse.json())

    def test_le_style_reduit_est_signale_avec_les_proprietes_admises(self):
        reponse = self._ecrire('<p style="position:fixed;color:red">t</p>')
        avertissements = " ".join(reponse.json().get("avertissements", []))
        self.assertIn("position", avertissements)
        self.assertIn("color", avertissements, "Le message doit dire ce qui passe.")
        self.assertIn("color: red", self._relire())

    def test_un_repli_ecrit_a_la_main_est_refuse(self):
        """
        `<details>` traverse l'assainissement mais pas l'éditeur.

        Il a été ajouté aux balises autorisées — c'est un repli natif, sans
        script — et le SITE le rend donc correctement. Mais Quill le vide, et
        l'API refuse par conséquent qu'un agent en écrive : ce serait poser un
        contenu que l'exploitant ne pourrait plus modifier.

        Les deux règles ne se contredisent pas, elles répondent à deux
        questions : `sanitize` dit ce qui est sûr à servir,
        `compatibilite_editeur` ce qui survit à l'aller-retour.
        """
        reponse = self._ecrire("<details><summary>plus</summary>le corps</details>")
        self.assertEqual(reponse.status_code, 400)
        message = reponse.json()["erreur"]
        self.assertIn("DYN_ACCORDION_ADV", message,
                      "Le refus doit nommer le bloc qui fait la même chose.")

    def test_le_refus_dit_ce_qui_traverse(self):
        """Refuser sans dire ce qui marche laisse l'appelant à sa perplexité."""
        message = self._ecrire('<div><p>a</p></div>').json()["erreur"]
        self.assertIn("paramètres du bloc", message)
        self.assertIn("data-list", message, "Le format de liste attendu doit y être.")

    def test_une_liste_au_format_de_l_editeur_passe(self):
        reponse = self._ecrire(
            '<ol><li data-list="bullet">Odéon</li>'
            '<li data-list="bullet">Mabillon</li></ol>'
        )
        self.assertEqual(reponse.status_code, 200, reponse.content[:300])
        self.assertIn("data-list", self._relire())

    def test_une_liste_en_ul_est_refusee(self):
        """`<ul>` rend bien sur le site et vide le bloc dans l'éditeur."""
        reponse = self._ecrire("<ul><li>Odéon</li></ul>")
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("data-list", reponse.json()["erreur"])

    def test_le_contenu_a_plat_avec_ses_classes_passe(self):
        """
        La forme recommandée : une carte écrite sans conteneur.

        C'est exactement le contenu que l'agent avait enveloppé dans un
        `<div class="jk-trade">`. À plat, il traverse l'éditeur intact — les
        classes sur les éléments de bloc sont conservées par Quill — et la
        boîte se règle dans les paramètres du bloc.
        """
        reponse = self._ecrire(
            '<h2 class="jk-tt">Électricité</h2>'
            '<p class="jk-tp">Installation et dépannage.</p>'
            '<p class="jk-go"><a href="/electricite/">Voir</a></p>'
        )
        self.assertEqual(reponse.status_code, 200, reponse.content[:300])
        relu = self._relire()
        self.assertIn('class="jk-tt"', relu)
        self.assertIn('class="jk-go"', relu)
