# jeiko/administration_pages/tests_editeur_de_ligne.py
"""
Trois défauts de l'éditeur, rapportés par l'exploitant, tous invisibles aux tests.

Aucun ne lève. Aucun ne casse une page. Ils rendent simplement une partie de
l'interface inopérante — et il faut s'en servir pour s'en apercevoir.

1. Le panneau « CSS » d'une ligne était vide
   -----------------------------------------
   Le formulaire de ligne incluait `content/includes/css_parameters.html`, un
   gabarit de juin resté sur l'ancien nom de variable (`css_form`) que la vue
   ne fournit plus — elle passe `custom_css_form`. Django résout une variable
   inconnue en chaîne vide : les sept champs sortaient vides. Ce vieux gabarit
   n'avait pas non plus la `<div id="css-parameters">` que le système
   d'onglets montre et cache.

   Vingt-cinq autres formulaires utilisaient déjà la bonne version : seule la
   ligne était restée en arrière. Bascule commencée, jamais finie — la même
   famille que le passage de `CSSParameters` à `CustomCSS`.

2. La disposition choisie n'était jamais marquée comme telle
   ---------------------------------------------------------
   `class="layout-option { 'selected': desktopValue === opt.value }"` est une
   liaison Alpine écrite dans un attribut `class` ordinaire. Le navigateur y
   voit des noms de classes littéraux — « { », « 'selected': », « === » — et
   la classe `selected` n'apparaît jamais. Le `:` resté seul sur la ligne
   suivante était le préfixe de liaison, séparé de son attribut.

   Conséquence : on ne savait pas dans quelle disposition on se trouvait.

3. Les polices étaient échappées comme du HTML
   --------------------------------------------
   `base_style.html` interpole les familles de police dans un bloc `<style>`
   sans passer par `css_value`. Une pile contenant un nom entre apostrophes —
   « Georgia, 'Times New Roman', serif » — sortait avec des `&#x27;`, que le
   navigateur ne décode pas dans une feuille de style : la déclaration entière
   devenait invalide.

   Et les liens légaux du pied de page n'étaient couverts par aucune règle de
   police : ils rendaient en Times, à côté de crédits en Poppins.
"""

import pathlib
import re

from django.test import SimpleTestCase

GABARITS = pathlib.Path(__file__).resolve().parent.parent / "templates"


def _source(chemin):
    return (GABARITS / chemin).read_text()


class PanneauCssDeLaLigneTests(SimpleTestCase):
    def test_la_ligne_utilise_le_meme_panneau_que_la_section(self):
        ligne = _source("administration_pages/line/form.html")
        self.assertIn("administration_pages/includes/css_parameters.html", ligne)
        self.assertNotIn(
            "content/includes/css_parameters.html", ligne,
            "Le formulaire de ligne pointe à nouveau sur le gabarit de juin, "
            "qui lit « css_form » — une variable que la vue ne fournit plus. "
            "Les champs sortiraient vides.",
        )

    def test_aucun_formulaire_ne_pointe_sur_le_gabarit_perime(self):
        """
        Le verrou de fond : la version périmée ne doit servir à personne.

        Sans ce test, un formulaire écrit demain pourrait la reprendre — elle
        est toujours sur le disque, et son nom est plausible.
        """
        coupables = []
        for fichier in sorted(GABARITS.rglob("*.html")):
            if "content/includes/css_parameters.html" in fichier.read_text():
                coupables.append(str(fichier.relative_to(GABARITS)))
        self.assertEqual(
            coupables, [],
            "Gabarit(s) incluant la version périmée du panneau CSS : "
            + ", ".join(coupables)
            + ". Utiliser « administration_pages/includes/css_parameters.html ».",
        )

    def test_le_panneau_est_dans_l_enveloppe_des_onglets(self):
        """Sans `id="css-parameters"`, l'onglet n'a rien à montrer."""
        ligne = _source("administration_pages/line/form.html")
        self.assertIn('id="css-parameters"', ligne)


class DispositionSelectionneeTests(SimpleTestCase):
    #: Une liaison Alpine posée dans un `class` ordinaire. On reconnaît
    #: l'objet littéral — une accolade suivie d'un nom entre guillemets — ce
    #: qu'aucune balise Django ne produit : `{%` et `{{` n'ont pas de
    #: guillemet en seconde position. Sans cette précision, le test se
    #: déclenchait sur les `{% if %}` légitimes dans un `class`.
    _LIAISON_EGAREE = re.compile(r"""\sclass="[^"]*\{\s*['"]""")

    def test_les_trois_appareils_lient_bien_la_classe(self):
        ligne = _source("administration_pages/line/form.html")
        for variable in ("desktopValue", "tabletValue", "mobileValue"):
            with self.subTest(appareil=variable):
                self.assertIn(
                    f":class=\"{{ 'selected': {variable} === opt.value }}\"",
                    ligne,
                    "La classe « selected » doit être LIÉE (:class), sinon "
                    "elle n'est jamais posée et on ne sait pas dans quelle "
                    "disposition on se trouve.",
                )

    def test_aucune_liaison_alpine_n_est_egaree_dans_un_class(self):
        """Le garde général : la même faute ailleurs serait aussi silencieuse."""
        coupables = []
        for fichier in sorted(GABARITS.rglob("*.html")):
            for numero, ligne in enumerate(fichier.read_text().splitlines(), 1):
                if self._LIAISON_EGAREE.search(ligne):
                    coupables.append(
                        f"{fichier.relative_to(GABARITS)}:{numero} — {ligne.strip()[:90]}"
                    )
        self.assertEqual(
            coupables, [],
            "Liaison Alpine écrite dans un attribut « class » ordinaire :\n  "
            + "\n  ".join(coupables)
            + "\nLe navigateur y verra des noms de classes littéraux. "
              "Écrire « :class=\"{ … }\" ».",
        )


class PolicesDansLaFeuilleDeStyleTests(SimpleTestCase):
    FEUILLE = "includes/base_style.html"

    def test_toute_famille_interpolee_passe_par_css_value(self):
        source = _source(self.FEUILLE)
        nues = re.findall(r"\{\{\s*font\.(?:family|fallback)\s*\}\}", source)
        self.assertEqual(
            nues, [],
            f"{len(nues)} famille(s) de police interpolée(s) sans « |css_value ». "
            "Django les échappe pour du HTML, et « 'Times New Roman' » devient "
            "« &#x27;Times New Roman&#x27; » dans un bloc <style> — la "
            "déclaration entière est alors invalide.",
        )

    def test_le_filtre_est_charge(self):
        self.assertIn("{% load css_extras %}", _source(self.FEUILLE))

    def test_les_liens_legaux_heritent_de_la_police_du_site(self):
        """
        Ils rendaient en Times, à côté de crédits en Poppins.

        `footer.css` leur donne une taille et une couleur, aucune famille :
        rien dans la cascade ne leur en attribuait, d'où la police par défaut
        du navigateur sur toutes les pages du site.
        """
        source = _source(self.FEUILLE)
        self.assertEqual(
            source.count("footer nav.menu-legals a"), 3,
            "Les trois blocs d'appareil — ordinateur, tablette, téléphone — "
            "doivent couvrir le menu légal comme ils couvrent les crédits.",
        )
