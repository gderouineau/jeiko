"""
Assainissement du HTML saisi dans l'administration.

Le contenu des pages est du HTML : les rédacteurs doivent pouvoir mettre en
forme, insérer des liens, des images. On ne peut donc pas simplement tout
échapper. Mais on ne peut pas non plus le rendre tel quel — un `<script>`, un
attribut `onerror=` ou une URL `javascript:` s'exécuteraient chez tous les
visiteurs, y compris les administrateurs, ce qui permet le vol de session vers
un compte plus privilégié.

Stratégie, par ordre de préférence :

1. `nh3` — liaison Python d'`ammonia` (Rust), l'analyseur de référence. C'est la
   dépendance déclarée dans requirements.txt.
2. `bleach` — repli si le projet l'a déjà.
3. Aucun des deux — on **échappe intégralement**. Le rendu perd sa mise en
   forme, ce qui se voit immédiatement, plutôt que de laisser passer du script
   silencieusement. Un défaut visible vaut mieux qu'une faille invisible.

Le comportement est pilotable par `JEIKO_SANITIZE_HTML` (défaut : True). Le
passer à False rend le HTML brut : à ne faire que si les seuls rédacteurs sont
de confiance et qu'aucun rôle n'est délégué à un tiers.
"""

import logging
import re

from django.conf import settings
from django.utils.html import escape
from django.utils.safestring import mark_safe

logger = logging.getLogger("jeiko")

# Balises de mise en forme, de structure et de média. Volontairement sans
# <script>, <style>, <iframe>, <object>, <embed>, <form> ni <input>.
ALLOWED_TAGS = {
    "a", "abbr", "b", "blockquote", "br", "caption", "cite", "code", "col",
    "colgroup", "dd", "del", "div", "dl", "dt", "em", "figcaption", "figure",
    "h1", "h2", "h3", "h4", "h5", "h6", "hr", "i", "img", "ins", "li", "mark",
    "ol", "p", "picture", "pre", "q", "s", "small", "source", "span", "strong",
    "sub", "sup", "table", "tbody", "td", "tfoot", "th", "thead", "time", "tr",
    "u", "ul", "video", "audio",
    # `details`/`summary` : un accordéon natif, sans une ligne de script.
    # Leur retrait était le pire des trois cas possibles — les balises
    # tombaient mais leur texte restait, collé : « <details><summary>plus
    # </summary>corps</details> » sortait en « pluscorps ». Un repli écrit à
    # la main devenait de la bouillie, silencieusement. Ni l'un ni l'autre ne
    # peut exécuter quoi que ce soit.
    "details", "summary",
}

# Aucun attribut `on*` : c'est la voie d'exécution la plus courante.
ALLOWED_ATTRIBUTES = {
    # « style » est autorisé à TRAVERSER l'assainisseur, puis filtré
    # déclaration par déclaration par `_filtrer_les_styles()` juste après.
    # Voir le long commentaire de PROPRIETES_DE_STYLE, qui dit pourquoi il ne
    # peut pas être laissé libre — ni interdit.
    "*": {"class", "id", "title", "dir", "lang", "role", "aria-label",
          "aria-hidden", "style"},
    # « rel » est absent volontairement : nh3 le pose lui-même via link_rel et
    # refuse qu'on le déclare en plus. Le repli bleach l'ajoute de son côté.
    "a": {"href", "target"},
    "img": {"src", "alt", "width", "height", "loading", "srcset", "sizes"},
    "source": {"src", "srcset", "type", "media"},
    "video": {"src", "controls", "poster", "width", "height", "preload"},
    "audio": {"src", "controls", "preload"},
    "td": {"colspan", "rowspan"},
    "th": {"colspan", "rowspan", "scope"},
    "time": {"datetime"},
    "col": {"span"},
    "colgroup": {"span"},
    "details": {"open"},
    # `data-list` porte la puce des listes de l'éditeur : Quill écrit
    # « <ol><li data-list="bullet"> » et `main.css` rend la puce depuis cet
    # attribut (`li[data-list="bullet"]{list-style-type:disc}`). Le retirer
    # transformait toute liste à puces en liste numérotée, silencieusement —
    # et rendait impossible le seul format de liste que l'éditeur sache
    # relire. C'est une valeur d'affichage, sans effet exécutable.
    "li": {"data-list"},
}

# `javascript:` et `data:` exclus — `data:text/html` est un vecteur d'exécution.
ALLOWED_SCHEMES = {"http", "https", "mailto", "tel"}

_BACKEND = None


def _resolve_backend():
    """Choisit l'implémentation une fois pour toutes, et le dit dans le journal."""
    global _BACKEND
    if _BACKEND is not None:
        return _BACKEND

    try:
        import nh3  # noqa: F401
        _BACKEND = "nh3"
    except ImportError:
        try:
            import bleach  # noqa: F401
            _BACKEND = "bleach"
        except ImportError:
            _BACKEND = "escape"
            logger.warning(
                "Ni nh3 ni bleach ne sont installés : le HTML des contenus sera "
                "intégralement échappé et perdra sa mise en forme. "
                "Installer nh3 (déjà présent dans requirements.txt) pour "
                "rétablir le rendu."
            )
    return _BACKEND


def clean_html(value):
    """
    Retourne une chaîne sûre à insérer telle quelle dans un gabarit.

    La valeur de retour n'est PAS marquée sûre : c'est à l'appelant de le faire
    explicitement, pour que chaque `mark_safe` du code reste visible.
    """
    if not value:
        return ""

    text = str(value)

    if not getattr(settings, "JEIKO_SANITIZE_HTML", True):
        return text

    backend = _resolve_backend()

    if backend == "nh3":
        import nh3
        return _filtrer_les_styles(nh3.clean(
            text,
            tags=ALLOWED_TAGS,
            attributes={k: set(v) for k, v in ALLOWED_ATTRIBUTES.items()},
            url_schemes=ALLOWED_SCHEMES,
            link_rel="noopener noreferrer",
        ))

    if backend == "bleach":
        import bleach
        attributes = {k: list(v) for k, v in ALLOWED_ATTRIBUTES.items()}
        # bleach ne pose pas rel="noopener" tout seul : on autorise l'attribut
        # pour que celui déjà présent dans le contenu survive.
        attributes["a"] = attributes.get("a", []) + ["rel"]
        return _filtrer_les_styles(bleach.clean(
            text,
            tags=ALLOWED_TAGS,
            attributes=attributes,
            protocols=list(ALLOWED_SCHEMES),
            strip=True,
        ))

    # Le dernier repli échappe tout : il ne reste aucune balise, donc
    # aucun attribut à filtrer.
    return escape(text)


# ---------------------------------------------------------------------------
#  L'attribut `style`
# ---------------------------------------------------------------------------
#
# Le problème
# -----------
# L'éditeur de l'administration propose de colorer un mot. Il écrit alors
# `<span style="color: rgb(37, 99, 235)">`. Cet attribut ne figurait dans
# aucune liste blanche : il était retiré au rendu. Le texte restait bleu dans
# l'éditeur et sortait noir sur le site, sans que rien ne le signale — ni à
# l'exploitant, qui voit sa couleur à la saisie, ni à un agent, qui reçoit un
# 200. Des accroches sont en production, aujourd'hui, dans la mauvaise couleur.
#
# Le défaut n'était pas le retrait. C'était qu'un bouton de l'éditeur produise
# quelque chose que le rendu détruit.
#
# Pourquoi on ne peut pas simplement l'autoriser
# ----------------------------------------------
# Un `style` libre est une vraie porte, sans aucun script :
#
#   * `position: fixed; inset: 0` pose un calque invisible par-dessus toute la
#     page et détourne les clics — le visiteur croit cliquer sur un bouton,
#     il clique sur autre chose ;
#   * `background-image: url(https://ailleurs/...)` fait signer chaque
#     affichage de la page à un tiers, adresse IP comprise ;
#   * les anciens `expression()` d'Internet Explorer exécutaient du script.
#
# La parade
# ---------
# Une liste blanche de PROPRIÉTÉS, chacune avec ses valeurs admissibles. Ce
# qui n'y figure pas est retiré ; il n'y a pas de branche « au cas où ». Aucune
# des propriétés retenues ne positionne, n'anime, ni ne charge de ressource :
# elles décrivent la couleur et le poids du texte, rien d'autre.
#
# Le filtre s'applique APRÈS l'assainisseur, délibérément : à ce moment le HTML
# a été réanalysé et réécrit, les attributs sont correctement cités et
# échappés. Lire `style="…"` par expression régulière y est fiable, ce qui ne
# serait pas vrai sur la saisie brute.
#
# Ce que ça ne résout pas
# -----------------------
# Rien n'empêche l'éditeur de proposer, demain, un réglage qui produirait une
# propriété absente de cette liste : elle serait retirée, silencieusement,
# exactement comme `color` l'était. Le remède est le même qu'aujourd'hui —
# ajouter la propriété ici, avec ses valeurs.

#: Couleurs : notation hexadécimale, fonctionnelle, ou nom CSS.
#:
#: Le motif refuse `url(`, `expression(` et toute autre fonction : seules
#: `rgb`, `rgba`, `hsl` et `hsla` ouvrent une parenthèse, et un nom de couleur
#: ne contient que des lettres.
_VALEUR_COULEUR = re.compile(
    r"^(?:#[0-9a-f]{3,8}"
    r"|rgba?\([\d.,%\s/]+\)"
    r"|hsla?\([\d.,%\s/deg]+\)"
    r"|[a-z]{3,20})$",
    re.IGNORECASE,
)

#: Propriétés admises, et leurs valeurs. Une valeur peut être un ensemble
#: (liste fermée) ou une expression régulière.
PROPRIETES_DE_STYLE = {
    "color": _VALEUR_COULEUR,
    "background-color": _VALEUR_COULEUR,
    "text-align": {"left", "right", "center", "justify", "start", "end"},
    "text-decoration": {"none", "underline", "line-through", "overline"},
    "font-style": {"normal", "italic", "oblique"},
    "font-weight": {
        "normal", "bold", "lighter", "bolder",
        "100", "200", "300", "400", "500", "600", "700", "800", "900",
    },
}

#: `style="…"` dans du HTML déjà assaini : la valeur est entre guillemets
#: doubles et ne peut pas en contenir.
_ATTRIBUT_STYLE = re.compile(r'\sstyle="([^"]*)"', re.IGNORECASE)


def _declaration_admise(propriete, valeur):
    """Vrai si cette paire propriété/valeur figure dans la liste blanche."""
    admises = PROPRIETES_DE_STYLE.get(propriete)
    if admises is None:
        return False
    if isinstance(admises, set):
        return valeur.lower() in admises
    return bool(admises.match(valeur))


def _filtrer_une_declaration_de_style(brut):
    """Ne garde que les déclarations admises. Renvoie "" s'il n'en reste aucune."""
    gardees = []
    for morceau in brut.split(";"):
        if ":" not in morceau:
            continue
        propriete, _, valeur = morceau.partition(":")
        propriete = propriete.strip().lower()
        valeur = valeur.strip()
        # Un commentaire CSS peut masquer une propriété à un lecteur naïf.
        # Aucune valeur légitime n'en contient : on refuse sans chercher.
        if "/*" in morceau or "\\" in morceau:
            continue
        if _declaration_admise(propriete, valeur):
            gardees.append(f"{propriete}: {valeur}")
    return "; ".join(gardees)


def _filtrer_les_styles(html):
    """Réécrit chaque `style="…"` en ne gardant que ce qui est admis."""
    def remplacer(trouve):
        garde = _filtrer_une_declaration_de_style(trouve.group(1))
        return f' style="{garde}"' if garde else ""

    return _ATTRIBUT_STYLE.sub(remplacer, html)


def clean_html_safe(value):
    """`clean_html` suivi de `mark_safe` — pour un usage direct en gabarit."""
    return mark_safe(clean_html(value))


# ---------------------------------------------------------------------------
#  Dire ce qu'on a retiré
# ---------------------------------------------------------------------------
#
# Le problème
# -----------
# L'assainissement s'applique AU RENDU, pas à l'écriture. Ce qui est stocké
# n'est donc pas ce qui est servi, et rien ne le signale.
#
# Pour un agent, c'est le pire cas de figure. Le mode d'emploi lui conseille
# — à raison — de relire ce qu'il écrit, parce qu'une écriture peut réussir
# sans rien produire. Mais ici la relecture ne sert à rien : l'API rend
# fidèlement ce qu'elle a stocké, l'agent constate que tout est en place,
# publie, et le visiteur voit une page amputée. La seule parade recommandée
# était désarmée par la conception.
#
# Ce qu'on en fait
# ----------------
# `clean_html` reste la barrière, au rendu, et le restera : c'est elle qui
# protège les contenus déjà en base et ceux qui arrivent par d'autres voies.
# Mais l'API des agents assainit AUSSI à l'écriture, et dit ce qu'elle a
# retiré. Deux conséquences :
#
#   * ce qu'un agent relit est ce que le visiteur verra — la relecture
#     redevient la garantie que le guide promet ;
#   * il l'apprend au moment de l'appel, pas sur la page publiée.
#
# Ce que ça ne résout pas
# -----------------------
# Les contenus écrits depuis l'administration continuent d'être stockés bruts
# et assainis au rendu. C'est le même écart, et il reste — l'éditeur, lui,
# montre à son rédacteur ce qu'il vient de taper, pas ce qui sera servi.

#: Une balise ouvrante, quel qu'en soit le nom.
_NOM_DE_BALISE = re.compile(r"<\s*([a-zA-Z][\w:-]*)")

#: Un attribut nommé, avec sa valeur.
_NOM_D_ATTRIBUT = re.compile(r"\s([a-zA-Z_:][\w:.-]*)\s*=")

#: Une propriété CSS dans un attribut `style`.
_PROPRIETE_DE_STYLE = re.compile(r"([a-zA-Z-]+)\s*:")


def _proprietes_de_style(html):
    """Les propriétés CSS présentes dans tous les `style` d'un document."""
    trouvees = set()
    for declaration in _ATTRIBUT_STYLE.findall(html):
        trouvees.update(p.lower() for p in _PROPRIETE_DE_STYLE.findall(declaration))
    return trouvees


def rapport_de_menage(avant, apres):
    """
    Ce que l'assainissement a fait disparaître, en clair.

    On compare les deux documents plutôt que de consulter les listes
    blanches : c'est la seule méthode qui ne peut pas mentir quand les listes
    changeront. Une balise qui n'apparaît plus DU TOUT dans la sortie a été
    retirée ; une qui a survécu ailleurs ne mérite pas d'alarme.

    Renvoie une liste de phrases, vide quand rien n'a été touché.
    """
    avertissements = []

    balises_avant = {b.lower() for b in _NOM_DE_BALISE.findall(avant)}
    balises_apres = {b.lower() for b in _NOM_DE_BALISE.findall(apres)}
    for balise in sorted(balises_avant - balises_apres):
        avertissements.append(
            f"balise <{balise}> retirée — elle n'est pas dans les balises "
            f"autorisées, et son contenu textuel a pu rester collé au reste"
        )

    attributs_avant = {a.lower() for a in _NOM_D_ATTRIBUT.findall(avant)}
    attributs_apres = {a.lower() for a in _NOM_D_ATTRIBUT.findall(apres)}
    for attribut in sorted(attributs_avant - attributs_apres):
        avertissements.append(f"attribut « {attribut} » retiré")

    perdues = _proprietes_de_style(avant) - _proprietes_de_style(apres)
    if perdues:
        avertissements.append(
            "propriété(s) de style retirée(s) : " + ", ".join(sorted(perdues))
            + " — seules " + ", ".join(sorted(PROPRIETES_DE_STYLE)) + " traversent"
        )

    return avertissements


def nettoyer_en_rendant_compte(html):
    """`clean_html`, plus la liste de ce qui a disparu. Pour l'API des agents."""
    brut = str(html or "")
    propre = clean_html(brut)
    return propre, rapport_de_menage(brut, propre)


# ---------------------------------------------------------------------------
#  SVG
# ---------------------------------------------------------------------------
#
# Un SVG est un document XML, pas une image inerte : il peut porter un
# `<script>`, un attribut `on*` ou un lien `javascript:`. Servi depuis /media/,
# il s'exécute sur l'origine du site — donc avec la session du visiteur qui
# l'ouvre. `clean_html` ne convient pas ici : sa liste blanche est faite pour du
# HTML de contenu et retirerait tout le dessin.
#
# On procède donc par retrait ciblé des seules constructions exécutables. C'est
# suffisant pour un fichier d'icône, qui n'a besoin d'aucune d'entre elles.

#: Éléments qui peuvent exécuter, ou faire exécuter, quelque chose.
#:
#: `set`, `animate` et leurs variantes n'exécutent rien elles-mêmes : elles
#: écrivent un attribut pendant l'animation. `<set attributeName="onload"
#: to="alert(1)"/>` pose donc un gestionnaire d'événement APRÈS le nettoyage,
#: et `<animate attributeName="href" values="javascript:…"/>` réintroduit un
#: lien exécutable. Elles sont aussi dangereuses que `<script>`.
_ELEMENTS_DANGEREUX = (
    "script", "foreignObject", "iframe", "embed", "object", "handler",
    "set", "animate", "animateTransform", "animateMotion",
)

_NOMS = "|".join(_ELEMENTS_DANGEREUX)

# S-06 — La forme AUTO-FERMANTE portait une liste plus courte que la forme
# appariée : `handler`, `set` et `animate` n'y figuraient pas. `<set …>` fermé
# par une paire était retiré, `<set …/>` passait. Or c'est la forme naturelle
# de ces éléments, qui n'ont pas de contenu. Les deux branches lisent
# désormais la même liste, ce qui rend l'écart impossible.
_SVG_DANGEROUS_ELEMENTS = re.compile(
    rf"<\s*({_NOMS})\b[^>]*>.*?<\s*/\s*\1\s*>"
    rf"|<\s*(?:{_NOMS})\b[^>]*/?>",
    re.IGNORECASE | re.DOTALL,
)

# Attributs gestionnaires d'événement : onload, onclick, onmouseover…
# Pas de forme encodée à prévoir ici : les références de caractères ne sont
# décodées que dans les VALEURS d'attribut, jamais dans leur nom.
_SVG_EVENT_ATTRS = re.compile(r"\son[a-z]+\s*=\s*(\"[^\"]*\"|'[^']*'|[^\s>]+)",
                              re.IGNORECASE)


def _lettre_encodable(caractere):
    """
    Une lettre, ou l'une de ses écritures en référence de caractère XML.

    `&#106;`, `&#0000106;`, `&#x6A;`, `&#X6a`, avec ou sans point-virgule
    final : les navigateurs acceptent toutes ces formes dans une valeur
    d'attribut, et les décodent avant de lire le schéma de l'URL.
    """
    code = ord(caractere)
    return (
        f"(?:[{caractere.lower()}{caractere.upper()}]"
        rf"|&#0*{code};?"
        rf"|&#[xX]0*{code:x};?)"
    )


def _mot_encodable(mot):
    """
    Le mot, lettre par lettre, chacune éventuellement encodée.

    Les séparateurs autorisés entre deux lettres sont la tabulation, le saut
    de ligne, le retour chariot et le caractère nul : les navigateurs les
    retirent d'une URL avant de l'interpréter, si bien que `java\tscript:` et
    `java&#10;script:` valent `javascript:`. C'est un contournement classique,
    et il ne coûte rien de le fermer.
    """
    separateur = r"[\t\n\r\x00]*"
    return separateur.join(_lettre_encodable(lettre) for lettre in mot)


# S-06 — Liens exécutables. La version précédente cherchait le mot en clair :
# `href="&#106;avascript:alert(1)"` passait intact, alors que le navigateur y
# lit `javascript:`. On accepte donc les mêmes écritures que lui.
_SVG_JS_URLS = re.compile(
    r"(?:href|xlink:href|src)\s*=\s*(\"|')?\s*"
    rf"(?:{_mot_encodable('javascript')}|{_mot_encodable('data')})"
    r"\s*:[^\"'>]*(\"|')?",
    re.IGNORECASE,
)


def clean_svg(value):
    """
    Retire d'un SVG ce qui peut s'exécuter. Retourne le document nettoyé.

    Accepte des octets ou une chaîne. Ne valide pas que l'entrée est un SVG
    correct : ce n'est pas le sujet, un fichier illisible restera illisible.
    """
    if not value:
        return ""

    if isinstance(value, (bytes, bytearray)):
        text = value.decode("utf-8", errors="replace")
    else:
        text = str(value)

    text = _SVG_DANGEROUS_ELEMENTS.sub("", text)
    text = _SVG_EVENT_ATTRS.sub("", text)
    text = _SVG_JS_URLS.sub("", text)
    return text
