# jeiko/tests_style_en_ligne.py
"""
L'attribut `style` : autorisé, mais réduit à ce qui ne peut pas nuire.

Le défaut
---------
L'éditeur de l'administration propose de colorer un mot. Il écrit
`<span style="color: rgb(37, 99, 235)">`. L'attribut ne figurait dans aucune
liste blanche : il était retiré au rendu. Le texte restait bleu dans
l'éditeur et sortait noir sur le site.

Personne n'était prévenu. Pas l'exploitant, qui voit sa couleur à la saisie ;
pas l'agent, qui reçoit un 200. Des accroches sont parties en production dans
la mauvaise couleur, et n'ont été vues que par un lecteur extérieur comparant
la base au HTML servi.

Le défaut n'était pas le retrait — un `style` libre est une vraie porte. Le
défaut était qu'un bouton de l'éditeur produise quelque chose que le rendu
détruit, en silence.

Ce que ces tests gardent
------------------------
Les deux moitiés, qui ne valent rien l'une sans l'autre :

* ce qui doit passer passe — sinon on a juste déplacé le défaut ;
* ce qui doit tomber tombe — et on éprouve ici les usages hostiles réels d'un
  `style`, qui n'ont besoin d'aucun script pour faire du mal.
"""

from django.test import SimpleTestCase

from jeiko.sanitize import PROPRIETES_DE_STYLE, clean_html


class CeQuiDoitPasserTests(SimpleTestCase):
    """La mise en forme que l'éditeur propose doit arriver jusqu'au visiteur."""

    def test_la_couleur_du_texte_survit(self):
        """Le cas exact du rapport : une accroche colorée depuis l'admin."""
        rendu = clean_html(
            '<p><span style="color: rgb(37, 99, 235);">CAP, polyvalence</span></p>'
        )
        self.assertIn("color: rgb(37, 99, 235)", rendu)
        self.assertIn("CAP, polyvalence", rendu)

    def test_les_notations_de_couleur_usuelles(self):
        for valeur in ("#fff", "#2563EB", "#2563ebff", "rgb(1,2,3)",
                       "rgba(1,2,3,.5)", "hsl(210, 90%, 50%)", "red"):
            with self.subTest(valeur=valeur):
                self.assertIn(
                    "color:", clean_html(f'<p style="color: {valeur}">x</p>'),
                    f"« {valeur} » est une couleur légitime et doit passer.",
                )

    def test_les_autres_proprietes_admises(self):
        rendu = clean_html(
            '<p style="background-color:#eee;text-align:center;'
            'font-weight:600;font-style:italic;text-decoration:underline">x</p>'
        )
        for attendue in ("background-color", "text-align", "font-weight",
                         "font-style", "text-decoration"):
            self.assertIn(attendue, rendu)

    def test_une_declaration_valide_survit_a_une_voisine_refusee(self):
        """
        On filtre déclaration par déclaration, pas attribut par attribut.

        Jeter tout le `style` parce qu'une de ses déclarations est refusée
        ferait perdre une couleur légitime à cause d'un réglage sans rapport.
        """
        rendu = clean_html('<p style="position: fixed; color: red">x</p>')
        self.assertIn("color: red", rendu)
        self.assertNotIn("position", rendu)


class CeQuiDoitTomberTests(SimpleTestCase):
    """
    Les usages hostiles d'un `style`. Aucun n'a besoin de script.

    C'est ce qui rend la liste blanche nécessaire : interdire `<script>` ne
    protège de rien ici.
    """

    def _sans(self, html, interdit):
        rendu = clean_html(html)
        self.assertNotIn(interdit, rendu.lower(), f"Rendu : {rendu}")
        return rendu

    def test_le_calque_qui_detourne_les_clics(self):
        """
        `position: fixed; inset: 0` recouvre la page d'une zone invisible.

        Le visiteur croit cliquer sur un bouton ; il clique sur autre chose.
        Aucun script, aucune balise interdite — et pourtant.
        """
        self._sans('<p style="position:fixed;inset:0;z-index:9999">x</p>', "position")

    def test_la_ressource_externe_qui_piste(self):
        """
        `url()` fait signer chaque affichage de la page à un tiers.

        Adresse IP du visiteur, page consultée, horaire. Sur une page
        d'administration, cela révèle aussi qu'un administrateur travaillait.
        """
        self._sans(
            '<p style="background-image:url(https://ailleurs/pixel.png)">x</p>',
            "url(",
        )

    def test_l_expression_internet_explorer(self):
        """Historique, mais gratuit à refuser — et c'était de l'exécution."""
        self._sans('<p style="width:expression(alert(1))">x</p>', "expression")

    def test_le_commentaire_css_ne_masque_rien(self):
        """
        `/* … */` sert à tromper un lecteur, pas le navigateur.

        On refuse toute déclaration qui en contient plutôt que de chercher à
        l'interpréter : aucune valeur légitime n'en a besoin.
        """
        rendu = clean_html(
            '<p style="background-color:#fff;/*x*/color:url(javascript:alert(1))">x</p>'
        )
        self.assertIn("background-color: #fff", rendu)
        self.assertNotIn("javascript", rendu.lower())

    def test_une_propriete_hors_liste_tombe_meme_si_sa_valeur_est_anodine(self):
        """La liste est fermée : on ne juge pas au cas par cas."""
        for propriete in ("animation", "transform", "content", "behavior",
                          "-moz-binding", "filter", "clip-path"):
            with self.subTest(propriete=propriete):
                self._sans(f'<p style="{propriete}: none">x</p>', propriete)

    def test_l_attribut_disparait_quand_il_ne_reste_rien(self):
        """Un `style=""` vide est du bruit ; on retire l'attribut entier."""
        self.assertNotIn("style", clean_html('<p style="position:fixed">x</p>'))

    def test_les_gestionnaires_d_evenement_restent_interdits(self):
        """Le garde nouveau ne doit pas avoir desserré l'ancien."""
        rendu = clean_html('<p style="color:red" onclick="alert(1)">x</p>')
        self.assertIn("color: red", rendu)
        self.assertNotIn("onclick", rendu)


class LaListeResteFermeeTests(SimpleTestCase):
    """
    Le garde du garde.

    La sûreté de tout le dispositif tient à ce que la liste ne contienne que
    des propriétés incapables de positionner, d'animer ou de charger quoi que
    ce soit. Une propriété ajoutée à la légère la percerait sans qu'aucun test
    ci-dessus n'échoue — ils n'éprouvent que ce qu'ils nomment.
    """

    #: Ce que la liste a le droit de contenir, et rien d'autre. Y ajouter une
    #: entrée est une décision, pas un ajustement : relire le commentaire de
    #: `PROPRIETES_DE_STYLE` avant.
    ATTENDUES = {
        "color", "background-color", "text-align",
        "text-decoration", "font-style", "font-weight",
    }

    def test_aucune_propriete_ne_s_est_ajoutee_sans_examen(self):
        self.assertEqual(
            set(PROPRIETES_DE_STYLE), self.ATTENDUES,
            "La liste des propriétés de style a changé. Vérifier que la "
            "nouvelle ne peut ni positionner, ni animer, ni charger une "
            "ressource externe — puis l'inscrire ici.",
        )

    def test_aucune_valeur_admise_ne_peut_ouvrir_de_fonction(self):
        """
        Le vrai danger d'une valeur est la fonction qu'elle ouvre.

        Seules `rgb`, `rgba`, `hsl` et `hsla` en ouvrent une. On vérifie que
        rien d'autre ne passe, quelle que soit la propriété.
        """
        for fonction in ("url", "expression", "image-set", "attr", "var",
                         "element", "-moz-element"):
            for propriete in PROPRIETES_DE_STYLE:
                with self.subTest(propriete=propriete, fonction=fonction):
                    rendu = clean_html(
                        f'<p style="{propriete}: {fonction}(https://x/y)">z</p>'
                    )
                    self.assertNotIn(fonction, rendu.lower())
