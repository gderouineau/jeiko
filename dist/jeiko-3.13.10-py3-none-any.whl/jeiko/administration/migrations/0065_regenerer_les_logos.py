"""
Refait les variantes WebP des logos déjà téléversés, aux nouvelles tailles
(LOGO_BOITES) : sans cela, un site gardait son logo flou jusqu'à ce que
quelqu'un le téléverse de nouveau.

Le modèle réel, pas celui de l'historique : la génération vit dans Logo.save().
Un logo dont le fichier manque ou ne se lit plus est laissé tel quel — une
mise à jour ne doit jamais échouer pour une image.
"""
from django.db import migrations


def regenerer(apps, schema_editor):
    from jeiko.administration.models import Logo

    for logo in Logo.objects.exclude(full_size=""):
        try:
            logo.save()
        except Exception:  # noqa: BLE001 — fichier absent ou illisible
            continue


class Migration(migrations.Migration):
    dependencies = [("administration", "0064_alter_font_weight")]
    operations = [migrations.RunPython(regenerer, migrations.RunPython.noop)]
