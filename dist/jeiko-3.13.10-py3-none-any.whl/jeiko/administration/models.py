from django.core.validators import MinValueValidator, MaxValueValidator

import logging
from io import BytesIO
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
import os
from PIL import Image
from django.conf import settings
from django.db import models
from jeiko.horodatage import HorodatageFiable
from jeiko.encrypted import EncryptedCharField, EncryptedTextField
from jeiko.uploads import valider_l_image
from django.core.exceptions import ValidationError
from django.core.validators import URLValidator

from jeiko.administration_pages.models import Page


from django.utils import timezone
from django.utils.translation import gettext_lazy as _

logger = logging.getLogger(__name__)


class Font(models.Model):
    size = models.CharField(
        default="20px",
        max_length=20,
        verbose_name=_("Taille de la police"),
        help_text=_("Ex: 18px, 1.2em, etc.")
    )
    family = models.CharField(
        default="Georgia",
        max_length=100,
        verbose_name=_("Famille de police"),
        help_text=_("Ex: Roboto, Playfair Display, Arial, etc.")
    )
    fallback = models.CharField(
        default="serif",
        max_length=100,
        verbose_name=_("Police de secours"),
        help_text=_("Ex: serif, sans-serif, monospace, Arial… (sera utilisée si la police principale n’est pas chargée)")
    )
    stretch = models.CharField(
        default="100%",
        max_length=100,
        verbose_name=_("Étirement"),
        help_text=_("Ex: 100%, condensed, expanded (optionnel)")
    )
    color = models.CharField(
        default="rgba(0,0,0,1)",
        max_length=30,
        verbose_name=_("Couleur de la police"),
        help_text=_("Ex: #333, rgba(0,0,0,1)")
    )
    POLICE_STYLE_CHOICES = [
        ("normal", "normal"),
        ("italic", "italic"),
        ("oblique", "oblique"),
    ]
    style = models.CharField(
        default="normal",
        max_length=10,
        choices=POLICE_STYLE_CHOICES,
        verbose_name=_("Style")
    )
    variant = models.CharField(
        default="normal",
        max_length=20,
        verbose_name=_("Variante"),
        help_text=_("Ex: small-caps, normal")
    )
    weight = models.CharField(
        default="normal",
        max_length=50,
        verbose_name=_("Épaisseur de la police"),
        help_text=_("De 100 (très fin) à 900 (très gras) : 300, normal, 500, bold… Seules les graisses que la police propose sont servies.")
    )
    line_height = models.CharField(
        default="normal",
        max_length=50,
        verbose_name=_("Hauteur de ligne"),
        help_text=_("Ex: 1.2, normal, 32px")
    )
    google_fonts_url = models.URLField(
        blank=True,
        null=True,
        verbose_name=_("URL Google Fonts"),
        help_text=_("Optionnel : colle ici l’URL Google Fonts si besoin (sinon sera générée automatiquement).")
    )

    def __str__(self):
        return f"{self.family} ({self.size})"

    class Meta:
        verbose_name = _("Police")
        verbose_name_plural = _("Polices")


class Fonts(models.Model):

    links = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="links"
    )

    links_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="links_hover"
    )
    menu = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="menu"
    )

    menu_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="menu_hover"
    )

    sub_menu = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="sub_menu"
    )

    sub_menu_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="sub_menu_hover"
    )

    text = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="text"
    )

    h1 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h1"
    )

    h2 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h2"
    )

    h3 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h3"
    )

    h4 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h4"
    )

    h5 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h5"
    )

    h6 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h6"
    )


# `updated_at` sert de clé de cache (cache du bloc d'identité dans le <head>) : il doit bouger
# même sur une sauvegarde partielle. Voir jeiko/horodatage.py.
class Logo(HorodatageFiable):
    # S-10 — seul `full_size` est téléversé ; les trois variantes ci-dessous
    # sont fabriquées par `save()` en redimensionnant celle-ci.
    full_size = models.ImageField(upload_to="images/logo", null=True, blank=True,
                                  validators=[valider_l_image], verbose_name=_("Logo"))
    computer_size = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name=_("Logo"))
    tablet_size   = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name=_("Logo"))
    mobile_size   = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name=_("Logo"))

    #: Logo réservé aux e-mails. Facultatif : sa PRÉSENCE vaut activation.
    #:
    #: Deux raisons de le vouloir distinct du logo du site.
    #:
    #: *Technique.* Les variantes générées pour le site sont en WebP, format
    #: que plusieurs clients de messagerie — Outlook pour Windows au premier
    #: rang — ne savent pas afficher. Un logo destiné aux e-mails doit être en
    #: PNG ou JPEG pour arriver chez tout le monde.
    #:
    #: *Éditoriale.* Un logo lisible sur un site à fond clair peut disparaître
    #: dans un e-mail, dont le fond varie avec le client et le thème sombre.
    #:
    #: Pas de case « activer » associée : un booléen coché sans image, ou une
    #: image sans le booléen, sont deux états incohérents qu'il faudrait
    #: expliquer. Ici, déposer une image l'active, la retirer revient au logo
    #: du site.
    mail_logo = models.ImageField(
        upload_to="images/logo/mail", null=True, blank=True,
        validators=[valider_l_image],
        verbose_name=_("Logo pour les e-mails"),
        help_text=(
            _("Facultatif. S'il est renseigné, il remplace le logo du site dans "
            "tous les e-mails. À fournir en PNG ou JPEG : le format WebP n'est "
            "pas affiché par plusieurs messageries, dont Outlook. Largeur "
            "conseillée : 300 à 600 pixels.")
        ),
    )

    updated_at = models.DateTimeField(auto_now=True)

    def email_image(self):
        """
        L'image à utiliser dans un e-mail, ou None.

        Ordre délibéré : le logo dédié d'abord, puis l'original téléversé, et
        seulement en dernier recours les variantes générées — celles-ci sont en
        WebP, que toutes les messageries ne rendent pas.

        `_logo_url` prenait auparavant `computer_size` en premier : tous les
        e-mails partaient donc avec un logo WebP, invisible chez une partie des
        destinataires.
        """
        for champ in ("mail_logo", "full_size", "computer_size",
                      "tablet_size", "mobile_size"):
            image = getattr(self, champ, None)
            if image and getattr(image, "name", ""):
                return image
        return None

    # ---------- helpers ----------
    def _variant_name(self, base_name: str, suffix: str) -> str:
        # base_name = self.full_size.name (chemin relatif au storage)
        name_no_ext, __ = os.path.splitext(base_name)  # ex: images/logo/monfichier
        return f"{name_no_ext}-{suffix}.webp"          # ex: images/logo/monfichier-computer.webp

    def _save_webp(self, img: Image.Image, size: tuple[int, int], target_name: str) -> str:
        # préserver l’alpha
        if img.mode not in ("RGBA", "LA"):
            img = img.convert("RGBA")
        # copier l’original avant thumbnail (pour éviter cascade de thumbnails)
        variant = img.copy()
        variant.thumbnail(size, Image.LANCZOS)

        buf = BytesIO()
        # WebP supporte la transparence. Qualité 92 : un logo est fait de
        # bords nets et d'aplats, où la compression se voit d'abord.
        variant.save(buf, format="WEBP", quality=92, method=6)
        buf.seek(0)

        # Écrire via le storage (portable: local, S3…)
        if default_storage.exists(target_name):
            default_storage.delete(target_name)
        default_storage.save(target_name, ContentFile(buf.read()))
        return target_name  # chemin relatif (à assigner à .name)

    # ---------- save ----------
    def save(self, *args, **kwargs):
        # 1) sauvegarder d’abord pour garantir full_size.path/.name
        super().save(*args, **kwargs)

        # 2) régénérer les variantes si on a un original
        if self.full_size and self.full_size.name:
            base_name = self.full_size.name   # chemin relatif, ex: images/logo/monfichier.png
            base_img  = Image.open(self.full_size.path)

            computer_name = self._variant_name(base_name, "computer")
            tablet_name   = self._variant_name(base_name, "tablet")
            mobile_name   = self._variant_name(base_name, "mobile")

            # Boîtes larges (retour client du 17/11/2026) : en 150/100/75 px, un
            # logo affiché à sa largeur réglée (100 px par défaut, souvent plus
            # dans le pied) était agrandi par le navigateur, et flou sur tout
            # écran Retina, qui compte deux pixels par point. Ces boîtes
            # couvrent le double de largeurs d'affichage courantes ;
            # thumbnail() n'agrandit jamais un original plus petit.
            comp_rel = self._save_webp(base_img, LOGO_BOITES["computer"], computer_name)
            tab_rel  = self._save_webp(base_img, LOGO_BOITES["tablet"], tablet_name)
            mob_rel  = self._save_webp(base_img, LOGO_BOITES["mobile"], mobile_name)

            # 3) assigner .name (PAS .url)
            self.computer_size.name = comp_rel
            self.tablet_size.name   = tab_rel
            self.mobile_size.name   = mob_rel

            # 4) sauver uniquement les champs modifiés (updated_at bouge aussi)
            super().save(update_fields=["computer_size", "tablet_size", "mobile_size", "updated_at"])


#: Taille maximale (largeur, hauteur) des variantes WebP d'un logo.
LOGO_BOITES = {"computer": (800, 400), "tablet": (600, 300), "mobile": (480, 240)}


class Favicon(models.Model):
    """Favicon du site : une image carrée uploadée, déclinée en PNG 32×32
    (onglet) et 180×180 (apple-touch-icon). PNG et non WebP : compat maximale
    des onglets/navigateurs et d'iOS. Même logique de génération que Logo."""
    source = models.ImageField(
        upload_to="images/favicon", null=True, blank=True,
        validators=[valider_l_image],
        verbose_name=_("Favicon (image carrée, PNG conseillé)"),
        help_text=_("Idéalement une image carrée d'au moins 180×180 px."),
    )
    png_32 = models.ImageField(upload_to="images/favicon", null=True, blank=True, editable=False)
    png_180 = models.ImageField(upload_to="images/favicon", null=True, blank=True, editable=False)

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Favicon")
        verbose_name_plural = _("Favicons")

    def _variant_name(self, base_name: str, suffix: str) -> str:
        name_no_ext, __ = os.path.splitext(base_name)
        return f"{name_no_ext}-{suffix}.png"

    def _save_png(self, img: Image.Image, size: int, target_name: str) -> str:
        if img.mode not in ("RGBA", "LA"):
            img = img.convert("RGBA")
        variant = img.copy()
        variant.thumbnail((size, size), Image.LANCZOS)
        buf = BytesIO()
        variant.save(buf, format="PNG")
        buf.seek(0)
        if default_storage.exists(target_name):
            default_storage.delete(target_name)
        default_storage.save(target_name, ContentFile(buf.read()))
        return target_name

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if self.source and self.source.name:
            base_name = self.source.name
            base_img = Image.open(self.source.path)
            self.png_32.name = self._save_png(base_img, 32, self._variant_name(base_name, "32"))
            self.png_180.name = self._save_png(base_img, 180, self._variant_name(base_name, "180"))
            super().save(update_fields=["png_32", "png_180", "updated_at"])


class MailSettings(models.Model):
    # Utilisation d’un singleton, une seule config par site
    host = models.CharField(max_length=200, verbose_name=_("Serveur SMTP"))
    port = models.PositiveIntegerField(
        default=587, validators=[MinValueValidator(1), MaxValueValidator(65535)],
        verbose_name=_("Port SMTP")
    )
    use_tls = models.BooleanField(default=True, verbose_name=_("Utiliser TLS"))
    use_ssl = models.BooleanField(default=False, verbose_name=_("Utiliser SSL"))
    host_user = models.CharField(max_length=200, blank=True, verbose_name=_("Nom d’utilisateur SMTP"))
    # Chiffré au repos : ce mot de passe permet d'envoyer du courrier signé
    # du domaine du site.
    host_password = EncryptedCharField(max_length=200, blank=True, verbose_name=_("Mot de passe SMTP"))
    default_from_email = models.CharField(max_length=200, blank=True, verbose_name=_("Adresse expéditeur par défaut"))
    reply_to_email = models.CharField(max_length=200, blank=True, verbose_name=_("Adresse reply-to (optionnelle)"))
    active = models.BooleanField(default=True, verbose_name=_("Actif"))
    test_receiver = models.CharField(max_length=200, blank=True, verbose_name=_("Email de test (pour bouton 'Tester')"))

    class Meta:
        verbose_name = _("Configuration Email")
        verbose_name_plural = _("Configuration Email")

    def __str__(self):
        return f"Mail SMTP ({self.host}:{self.port}) pour {self.website.name}"


class Theme(models.Model):
    """
    La palette du site — une seule source pour toutes les couleurs.

    Pourquoi ce modèle
    ------------------
    Avant lui, une couleur d'accent se retapait à la main partout où on la
    voulait : dans le CSS d'un bloc, dans le style d'un bouton, dans une classe
    d'un gabarit. Changer d'avis demandait de retrouver chaque occurrence — et
    d'en oublier. Les onze palettes concurrentes d'`admin_ui.css` racontent
    exactement cette histoire, côté administration.

    Ici, on règle une fois. Les couleurs sortent en variables CSS
    (`--jk-accent`, `--jk-secondaire`…) dans le `<head>` de chaque page, et
    tout ce qui veut la couleur du site la lit par `var(--jk-accent)`.

    Ce que ce modèle ne fait pas
    ---------------------------
    Il ne remplace pas les couleurs choisies bloc par bloc dans l'éditeur :
    celles-là restent des décisions locales, et c'est très bien. Il donne un
    défaut cohérent et un point de bascule — pas une contrainte.

    Les valeurs par défaut forment une palette chaude autour de l'ocre
    `rgb(180, 83, 9)` : un bleu-ardoise profond en secondaire, qui contraste
    sans crier, et un sable clair en tertiaire pour les fonds de section. Elles
    ont été choisies ensemble ; changer l'accent seul reste possible, mais le
    reste ne s'ajustera pas tout seul.
    """

    #: Un site peut porter plusieurs palettes : celle du site (`WebSite.theme`,
    #: le thème par défaut) et d'autres, qu'une catégorie choisit pour ses
    #: pages (`Category.theme`) — l'équivalent des menus par catégorie, pour
    #: les couleurs. Le nom ne sert qu'à les distinguer dans les listes.
    nom = models.CharField(_("Nom"), max_length=80, blank=True, default="")

    #: L'accent : boutons, liens, éléments actifs. Le seul vraiment obligatoire.
    accent = models.CharField(
        _("Couleur d'accent"), max_length=30, default="rgb(180, 83, 9)",
        help_text=_("Boutons, liens, éléments actifs."),
    )
    accent_survol = models.CharField(
        _("Accent au survol"), max_length=30, default="rgb(146, 64, 14)",
        help_text=_("Une version plus foncée de l'accent."),
    )
    sur_accent = models.CharField(
        _("Texte sur l'accent"), max_length=30, default="rgb(255, 255, 255)",
        help_text=_("La couleur du texte posé SUR un fond d'accent. "
                  "À garder très contrastée."),
    )

    secondaire = models.CharField(
        _("Couleur secondaire"), max_length=30, default="rgb(30, 58, 68)",
        help_text=_("Bandeaux, pieds de page, fonds sombres."),
    )
    tertiaire = models.CharField(
        _("Couleur tertiaire"), max_length=30, default="rgb(217, 175, 122)",
        help_text=_("Touches discrètes, séparateurs, fonds de mise en avant."),
    )

    texte = models.CharField(
        _("Texte"), max_length=30, default="rgb(28, 25, 23)",
    )
    texte_attenue = models.CharField(
        _("Texte secondaire"), max_length=30, default="rgb(87, 83, 78)",
        help_text=_("Légendes, mentions, texte d'appoint."),
    )
    fond = models.CharField(
        _("Fond"), max_length=30, default="rgb(255, 255, 255)",
    )
    fond_attenue = models.CharField(
        _("Fond alterné"), max_length=30, default="rgb(250, 247, 243)",
        help_text=_("Pour alterner une section sur deux."),
    )
    bordure = models.CharField(
        _("Bordures"), max_length=30, default="rgb(231, 226, 219)",
    )

    updated_at = models.DateTimeField(_("Modifié le"), auto_now=True)

    class Meta:
        verbose_name = _("Thème du site")
        verbose_name_plural = _("Thèmes du site")

    def __str__(self):
        return self.nom or f"Thème ({self.accent})"

    #: Nom de la variable CSS pour chaque champ de couleur. L'ordre est celui
    #: de l'écran de réglage.
    VARIABLES = (
        ("accent", "--jk-accent"),
        ("accent_survol", "--jk-accent-survol"),
        ("sur_accent", "--jk-sur-accent"),
        ("secondaire", "--jk-secondaire"),
        ("tertiaire", "--jk-tertiaire"),
        ("texte", "--jk-texte"),
        ("texte_attenue", "--jk-texte-attenue"),
        ("fond", "--jk-fond"),
        ("fond_attenue", "--jk-fond-attenue"),
        ("bordure", "--jk-bordure"),
    )

    def as_css_variables(self):
        """
        Les déclarations à poser sur `:root`.

        Les valeurs sont assainies avant d'être rendues : elles finissent dans
        une feuille de style, et un `;` ou une accolade y ouvrirait la porte à
        n'importe quelle règle. Même raisonnement que `css_vars` pour S-18.
        """
        # `css_extras.clean_css_value` existe déjà et fait exactement cela :
        # il retire les caractères qui ont une STRUCTURE en CSS — accolades,
        # point-virgule, « at », commentaires — sans casser les valeurs
        # légitimes. En écrire un second aurait créé deux réponses à la même
        # question, dont l'une aurait fini par diverger.
        from jeiko.templatetags.css_extras import clean_css_value

        return "\n".join(
            f"  {variable}: {clean_css_value(getattr(self, champ))};"
            for champ, variable in self.VARIABLES
        )

    def couleurs(self):
        """La palette en dictionnaire, pour l'API et les gabarits."""
        return {champ: getattr(self, champ) for champ, __ in self.VARIABLES}


class WebSite(models.Model):

    css_global = models.TextField(blank=True, default='', verbose_name=_('CSS global du contenu'))

    @property
    def css_global_scoped(self):
        # Même un import direct ne doit pas pouvoir injecter un <style> ou
        # charger une feuille externe. Le formulaire signale l'erreur avant
        # sauvegarde ; cette garde protège aussi les écritures hors formulaire.
        from django.core.exceptions import ValidationError
        from .css_site import compiler_css_site
        try:
            return compiler_css_site(self.css_global)
        except ValidationError:
            import logging
            logging.getLogger(__name__).warning('CSS global invalide ignoré pour le site %s', self.pk)
            return ''

    name = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        default="Jeiko",
    )
    fonts_phone = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_phone',
        null=True
    )

    fonts_tablet = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_tablet',
        null=True
    )

    fonts_computer = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_computer',
        null=True
    )

    theme = models.OneToOneField(
        Theme,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="website",
        verbose_name=_("Thème"),
    )

    logo = models.OneToOneField(
        Logo,
        on_delete=models.CASCADE,
        related_name='site',
        null=True,
    )

    favicon = models.OneToOneField(
        Favicon,
        on_delete=models.SET_NULL,
        related_name='site_favicon',
        null=True,
        blank=True,
    )

    mail_settings = models.OneToOneField(
        "MailSettings",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name="website",
        verbose_name=_("Configuration Email")
    )

    assets_version = models.IntegerField(
        default=1
    )

    #: Langue dans laquelle l'ADMINISTRATION s'affiche pour tout le monde,
    #: sauf pour qui a choisi la sienne sur son profil (`Profile.langue_admin`).
    #:
    #: Elle ne touche pas au site public : les visiteurs lisent le contenu dans
    #: la langue où il a été écrit, et ce qui l'entoure reste dans la langue du
    #: site (`LANGUAGE_CODE`). Voir `jeiko/i18n.py`.
    #:
    #: Pas de `choices` : la liste proposée vient des réglages (`LANGUAGES`), et
    #: une langue retirée de la configuration ne doit ni casser l'enregistrement
    #: du site ni demander une migration — elle est simplement ignorée.
    langue_admin = models.CharField(
        max_length=10,
        default="fr",
        verbose_name=_("Langue de l'administration"),
    )

    #: Le site PUBLIC en plusieurs langues (jeiko/langues_du_site.py). Éteint,
    #: rien ne change : pas de préfixe, pas de sélecteur, pas de cookie.
    multilingue = models.BooleanField(
        default=False,
        verbose_name=_("Site en plusieurs langues"),
    )
    #: Les codes des langues AJOUTÉES (« en », « es »…). La langue d'origine
    #: n'y figure pas : c'est celle du site, `LANGUAGE_CODE`, sans préfixe.
    langues_du_site = models.JSONField(default=list, blank=True)

    # ------------------------------------------------------------------ #
    # Disponibilité d'une mise à jour de JEIKO.
    #
    # Renseigné une fois par jour par le job `cron_24h` (cf.
    # `administration/update_check.py`), qui lit le `version.json` du canal de
    # publication et le compare à la version installée.
    #
    # Ces trois champs vivent sur `WebSite` — et non dans le cache — pour deux
    # raisons : le résultat doit survivre à un redémarrage (un badge qui
    # disparaît au hasard est pire que pas de badge), et `WebSite` est déjà
    # chargé et mis en cache à chaque rendu (`website_cache.get_website_data`),
    # donc afficher le badge ne coûte aucune requête supplémentaire.
    # ------------------------------------------------------------------ #
    update_available_version = models.CharField(
        max_length=32,
        blank=True,
        default="",
        help_text=_("Version publiée sur le canal, si elle est plus récente que celle installée."),
    )
    update_last_checked_at = models.DateTimeField(
        null=True,
        blank=True,
        help_text=_("Dernière interrogation réussie ou non du canal de publication."),
    )
    # La mise à jour automatique (INSTALLER/updater/jeiko-maj) : chaque
    # semaine, le serveur d'abord, puis le paquet de ce site. Décochée par
    # défaut (A-82) : un site ne change pas de version sans qu'on l'ait voulu.
    mise_a_jour_auto = models.BooleanField(
        default=False,
        verbose_name=_("Mise à jour automatique chaque semaine"),
        help_text=_("Dans la nuit de dimanche à lundi : le serveur d'abord, puis ce site, "
                    "si une version plus récente est publiée. En cas d'échec, le site revient "
                    "à son état d'avant et vous êtes prévenu par e-mail."),
    )
    #: Version publiée de l'INSTALLEUR (outillage serveur), lue chaque jour
    #: (administration/mise_a_jour.py). Instantané, comme
    #: update_available_version : la comparaison se refait à la lecture.
    installeur_disponible = models.CharField(max_length=32, blank=True, default="")
    #: Horodatage du dernier échec de mise à jour déjà signalé par e-mail — un
    #: échec n'est signalé qu'une fois.
    echec_maj_site_signale = models.CharField(max_length=40, blank=True, default="")
    echec_maj_serveur_signale = models.CharField(max_length=40, blank=True, default="")
    #: « paquet/installeur » de la dernière mise à jour disponible déjà
    #: annoncée par e-mail — une version n'est annoncée qu'une fois.
    mise_a_jour_signalee = models.CharField(max_length=80, blank=True, default="")
    # L'apparence de l'ADMINISTRATION (A-11, A-13, 09/10/2026) — jamais celle du
    # site, qui a son thème. Voir css/admin/couleurs.css. Par défaut, ce qu'elle
    # était : le corail, en clair. Réglée pour tout le site, pas par personne :
    # ponytail — par utilisateur le jour où plusieurs administrateurs le demandent.
    ACCENTS_ADMIN = [
        ("corail", _("Corail")), ("orange", _("Orange")), ("bleu", _("Bleu")), ("vert", _("Vert")),
        ("violet", _("Violet")), ("framboise", _("Framboise")), ("ardoise", _("Ardoise")),
    ]
    APPARENCES_ADMIN = [
        ("clair", _("Claire")), ("sombre", _("Sombre")), ("auto", _("Comme l'appareil")),
    ]
    admin_accent = models.CharField(
        max_length=12, choices=ACCENTS_ADMIN, default="corail",
        verbose_name=_("Couleur d'accent de l'administration"),
    )
    # Réglages de fonctionnement modifiables à l'écran (A-81) — voir
    # jeiko/reglages_avances.py. Une clé absente : le .env, sinon le défaut.
    reglages_avances = models.JSONField(default=dict, blank=True,
                                        verbose_name=_("Réglages avancés"))
    admin_apparence = models.CharField(
        max_length=8, choices=APPARENCES_ADMIN, default="clair",
        verbose_name=_("Apparence de l'administration"),
        help_text=_("« Comme l'appareil » suit le réglage clair ou sombre de chaque ordinateur ou téléphone."),
    )
    # Décoché par défaut (P4-a) : un site — surtout celui d'un client — ne doit
    # pas se mettre à envoyer ses traces d'erreur à un tiers sans qu'on l'ait
    # choisi. L'aide dit la vérité : les clés et mots de passe reconnus sont
    # masqués, mais une trace technique peut porter d'autres données.
    partager_les_erreurs = models.BooleanField(
        default=False,
        verbose_name=_("Partager les rapports d'erreur avec les développeurs"),
        help_text=_("Une fois par jour, s'il y en a eu, les erreurs 500 du site partent "
                    "aux développeurs de JEIKO (contact@jeiko.fr) : le type d'erreur, "
                    "l'adresse de la page et la trace technique. Les clés et mots de passe "
                    "reconnus sont masqués, mais une trace peut contenir d'autres données "
                    "(une adresse e-mail citée dans un message d'erreur, par exemple)."),
    )
    # MOD-01 (12/10/2026) : les modules qu'on VOIT dans le menu de
    # l'administration. Les éteindre ne fait que les masquer là : applications,
    # données, écrans (par leur adresse), site public et API restent tels quels.
    # Allumés par défaut, pour que rien ne change sur les sites en service ; un
    # site NEUF les reçoit éteints du site de départ (jeiko_site_de_depart).
    # Voir administration/modules.py.
    module_boutique = models.BooleanField(
        default=True, verbose_name=_("Boutique"),
        help_text=_("Produits, commandes, facturation, moyens de paiement."))
    module_formations = models.BooleanField(
        default=True, verbose_name=_("Formations"),
        help_text=_("Cours en ligne, accès des élèves, hébergement vidéo."))
    module_questionnaires = models.BooleanField(
        default=True, verbose_name=_("Questionnaires"),
        help_text=_("Tests et questionnaires, et les prospects qu'ils amènent."))
    module_rendez_vous = models.BooleanField(
        default=True, verbose_name=_("Rendez-vous et calendriers"),
        help_text=_("Prise de rendez-vous, créneaux, calendriers Google."))
    module_newsletter = models.BooleanField(
        default=True, verbose_name=_("Newsletter"),
        help_text=_("Listes de diffusion, abonnés, lettres et séquences automatiques."))
    # VISIO-01 : éteint par défaut, à l'inverse des autres — la visio demande
    # LiveKit sur le serveur, que seule l'installation pose.
    module_visio = models.BooleanField(
        default=False, verbose_name=_("Conférence"),
        help_text=_("Réunions, conférences et rendez-vous en visio."))
    # NOTIF-01 — les pastilles du menu, une à une : {code: bool}. Une clé
    # absente vaut « allumée » (administration/notifications.py).
    notifications = models.JSONField(_("Notifications du menu"), default=dict, blank=True)
    # Les étapes facultatives de la mise en route (D-01) écartées : « pas pour
    # ce site ». Une liste de codes (administration/mise_en_route.py).
    mise_en_route_ignorees = models.JSONField(default=list, blank=True)
    # La clé de licence de CE site (LIC-01) : envoyée par jeiko-client-update au
    # serveur de licences avant chaque mise à jour. En clair, ici : le site
    # doit pouvoir la présenter. Le serveur, lui, n'en garde que l'empreinte.
    licence_cle = models.CharField(
        max_length=64, blank=True, default="",
        verbose_name=_("Clé de licence"),
        help_text=_("Fournie par JEIKO. Elle autorise les mises à jour de ce site."),
    )
    # Les pages d'erreur écrites dans l'éditeur (A-10). Vides : les pages
    # « Cette page n'existe pas » et « Accès refusé » de JEIKO. Une page hors
    # ligne convient — et vaut mieux : elle ne s'affiche qu'en cas d'erreur
    # (administration_pages/pages_erreur.py).
    page_404 = models.ForeignKey(
        Page, null=True, blank=True, on_delete=models.SET_NULL, related_name="+",
        verbose_name=_("Page « introuvable » (404)"),
    )
    page_403 = models.ForeignKey(
        Page, null=True, blank=True, on_delete=models.SET_NULL, related_name="+",
        verbose_name=_("Page « accès refusé » (403)"),
    )
    # La 500 ne se rend pas à la demande — la base est souvent ce qui est
    # tombé : on en sert une copie statique, réécrite à chaque changement.
    page_500 = models.ForeignKey(
        Page, null=True, blank=True, on_delete=models.SET_NULL, related_name="+",
        verbose_name=_("Page « erreur du serveur » (500)"),
    )
    page_400 = models.ForeignKey(
        Page, null=True, blank=True, on_delete=models.SET_NULL, related_name="+",
        verbose_name=_("Page « requête invalide » (400)"),
    )
    update_check_error = models.CharField(
        max_length=255,
        blank=True,
        default="",
        help_text=_("Raison du dernier échec de vérification. Vide si la dernière a abouti."),
    )

    @property
    def mise_a_jour_disponible(self):
        """La version publiée, si elle est ENCORE plus récente que l'installée.

        Q-13 — le badge restait allumé après la mise à jour.

        `update_available_version` est un instantané pris par le cron : « le
        canal publiait 3.4.6 la dernière fois qu'on a regardé ». Ce n'est pas
        la réponse à « une mise à jour est-elle disponible ? », parce que la
        seconde moitié de la comparaison — la version installée — change
        précisément au moment où l'administrateur agit. Après un
        `jeiko-client-update` réussi, le champ dit toujours 3.4.6 alors que
        3.4.6 est désormais installée : la pastille restait donc allumée
        jusqu'au prochain passage du cron, jusqu'à vingt-quatre heures plus
        tard, sur une action déjà faite.

        On refait donc la comparaison à la lecture. Elle ne coûte rien —
        `importlib.metadata` sert la version depuis un cache de processus, et
        `WebSite` est déjà chargé.

        Ce champ ne doit plus être lu directement nulle part pour décider d'un
        affichage : `test_page_mise_a_jour.py` le vérifie.
        """
        from jeiko.administration.update_check import installed_version, is_newer

        publiee = self.update_available_version or ""
        if not publiee:
            return ""
        return publiee if is_newer(publiee, installed_version()) else ""

    def oublier_la_mise_a_jour_appliquee(self):
        """Efface l'instantané devenu caduc, une fois, sans attendre le cron.

        La propriété ci-dessus suffit à éteindre la pastille. Mais laisser en
        base une valeur qu'on sait fausse est une invitation à ce que le
        prochain lecteur la croie — c'est exactement de cette façon que le
        défaut est né. On la nettoie donc dès qu'on constate qu'elle est
        périmée, depuis l'écran de mise à jour : une seule écriture, sur une
        page que personne ne martèle.

        Seulement si la version installée est LISIBLE. Illisible, la propriété
        ci-dessus répond « rien » par prudence — ce qui ne prouve pas que la
        version publiée est installée. Effacer sur ce doute détruisait un
        relevé juste : l'écran ne l'annonçait plus, et le cron seul le
        rétablissait le lendemain (constaté le 28/09 en revérifiant A-30).
        """
        from jeiko.administration.update_check import installed_version

        if installed_version() is None:
            return False
        if self.update_available_version and not self.mise_a_jour_disponible:
            self.update_available_version = ""
            self.save(update_fields=["update_available_version"])
            return True
        return False


# `updated_at` sert de clé de cache (cache du bloc d'identité dans le <head>) : il doit bouger
# même sur une sauvegarde partielle. Voir jeiko/horodatage.py.
class SiteIdentity(HorodatageFiable):
    TYPE_ORG = "organization"
    TYPE_LOCAL = "localbusiness"
    TYPE_CHOICES = [
        (TYPE_ORG, _("Organization")),
        (TYPE_LOCAL, _("LocalBusiness")),
    ]

    website = models.OneToOneField("administration.WebSite", on_delete=models.CASCADE, related_name="identity")
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, default=TYPE_ORG)

    # Commun (recommandé / utile)
    name = models.CharField(max_length=200)                 # Required si LocalBusiness, recommandé si Organization
    # Le pied de page : le copyright (vide = « © année nom du site ») et le
    # crédit de l'auteur, que le propriétaire peut retirer. Le « Powered by »,
    # lui, reste : voir JEIKO_PROPULSE_PAR.
    pied_copyright = models.CharField(
        _("Copyright du pied de page"), max_length=200, blank=True,
        help_text=_("Vide : « © année nom du site »."))
    pied_realise_par = models.BooleanField(
        _("Afficher « Réalisé par Guillaume Derouineau »"), default=True)
    url = models.URLField(blank=True)                       # Recommandé
    telephone = models.CharField(max_length=50, blank=True) # Recommandé

    # Adresse (obligatoire si LocalBusiness)
    street_address = models.CharField(max_length=255, blank=True)
    address_locality = models.CharField(max_length=120, blank=True)
    address_region = models.CharField(max_length=120, blank=True)
    postal_code = models.CharField(max_length=20, blank=True)
    address_country = models.CharField(max_length=2, blank=True)  # ISO-3166-1 alpha-2 (FR, CH, etc.)

    # Extras utiles (facultatifs)
    geo_lat = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    geo_lng = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    price_range = models.CharField(max_length=10, blank=True)     # ex: €, €€, €€€
    default_share_image = models.ForeignKey(
        "administration_pages.ImageContent",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="default_share_for_identities",
        verbose_name=_("Image de partage par défaut"),
    )

    created_at = models.DateTimeField(default=timezone.now, editable=False)
    updated_at = models.DateTimeField(auto_now=True)


    class Meta:
        verbose_name = _("Identité du site")
        verbose_name_plural = _("Identités du site")

    def clean(self):
        if self.type == self.TYPE_LOCAL:
            missing = [f for f in ["name","street_address","address_locality","postal_code","address_country"] if not getattr(self, f)]
            if missing:
                raise ValidationError(
                    _("LocalBusiness nécessite name + adresse complète (street/locality/postal_code/country).")
                )

    def __str__(self):
        return f"{self.get_type_display()} — {self.name or 'sans nom'}"


class GoogleApi(models.Model):
    """
    Réglages globaux pour les APIs Google (clé PSI, Search Console...).
    On ne garde qu'une seule configuration.
    """
    name = models.CharField(
        max_length=100,
        default="Default"
    )
    # Chiffrée au repos (Fable 1 §1.5) : une clé d'API Google facturable.
    psi_api_key = EncryptedCharField(
        "PageSpeed Insights API key",
        max_length=300,
        blank=True,
        default="",
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Configuration Google API")
        verbose_name_plural = _("Configuration Google API")

    def __str__(self):
        return self.name

    @classmethod
    def get_solo(cls):
        obj, __ = cls.objects.get_or_create(pk=1, defaults={"name": "Default"})
        return obj



class Legals(models.Model):
    """
    Un jeu de pages légales par site.
    Les FK sont PROTECT pour empêcher la suppression d'une Page liée.
    """
    site = models.OneToOneField(
        WebSite,
        on_delete=models.CASCADE,
        related_name="legals",
        verbose_name=_("Site"),
    )

    privacy_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_privacy_page_for",
        verbose_name=_("Page RGPD/Privacy"),

    )
    cgv_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_cgv_page_for",
        verbose_name=_("Page CGV"),
    )
    cgu_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_cgu_page_for",
        verbose_name=_("Page CGU"),
    )
    mentions_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_mentions_page_for",
        verbose_name=_("Page Mentions légales"),
    )

    class Meta:
        verbose_name = _("Pages légales")
        verbose_name_plural = _("Pages légales")
        ordering = ["site__name"]

    def __str__(self):
        return f"Pages légales — {self.site.name}"


    @property
    def all_links(self):
        return {
            "privacy": getattr(self.privacy_page, "get_absolute_url", lambda: None)(),
            "cgv": getattr(self.cgv_page, "get_absolute_url", lambda: None)(),
            "cgu": getattr(self.cgu_page, "get_absolute_url", lambda: None)(),
            "mentions": getattr(self.mentions_page, "get_absolute_url", lambda: None)(),
        }


PLATFORM_CHOICES = [
    # Social “généraux”
    ("facebook", _("Facebook")),
    ("instagram", _("Instagram")),
    ("x", _("X (Twitter)")),
    ("threads", _("Threads")),
    ("bluesky", _("Bluesky")),
    ("tiktok", _("TikTok")),
    ("snapchat", _("Snapchat")),
    ("pinterest", _("Pinterest")),
    ("linkedin", _("LinkedIn")),
    ("youtube", _("YouTube")),
    ("vimeo", _("Vimeo")),
    ("reddit", _("Reddit")),
    ("tumblr", _("Tumblr")),
    ("mastodon", _("Mastodon")),
    # Messageries / communautés
    ("whatsapp", _("WhatsApp")),
    ("telegram", _("Telegram")),
    ("signal", _("Signal")),
    ("messenger", _("Facebook Messenger")),
    ("discord", _("Discord")),
    ("slack", _("Slack")),
    # Créateurs / portfolio
    ("dribbble", _("Dribbble")),
    ("behance", _("Behance")),
    ("medium", _("Medium")),
    ("substack", _("Substack")),
    # Dev / produit
    ("github", _("GitHub")),
    ("gitlab", _("GitLab")),
    ("bitbucket", _("Bitbucket")),
    ("producthunt", _("Product Hunt")),
    ("wellfound", _("Wellfound (AngelList)")),
    # Musique / audio
    ("spotify", _("Spotify")),
    ("applemusic", _("Apple Music")),
    ("deezer", _("Deezer")),
    ("soundcloud", _("SoundCloud")),
    ("twitch", _("Twitch")),
    # Avis / annuaires
    ("googlebusiness", _("Google Business Profile")),
    ("tripadvisor", _("Tripadvisor")),
    ("yelp", _("Yelp")),
    ("trustpilot", _("Trustpilot")),
    ("glassdoor", _("Glassdoor")),
    ("indeed", _("Indeed")),
    ("houzz", _("Houzz")),
    # E-commerce / marketplaces
    ("etsy", _("Etsy")),
    ("amazon", _("Amazon Store")),
    # Réseaux FR / divers
    ("viadeo", _("Viadeo")),
    ("vk", "VK"),
    # Liens utilitaires
    ("email", _("E-mail")),
    ("phone", _("Téléphone")),
    ("website", _("Site (autre)")),
    # Personnalisé
    ("custom", _("Personnalisé")),
]


class SocialLink(models.Model):
    """
    Un lien social associé à un site (WebSite).
    Icônes 100% locales :
      - par défaut : SVG livré en static (jeiko/icons/social/<platform>.svg)
      - override possible : upload raster -> génération WebP 48/32/24
      - override possible : upload SVG custom (utilisé tel quel)
    """
    website = models.ForeignKey("administration.WebSite", on_delete=models.CASCADE, related_name="social_links")
    platform = models.CharField(max_length=32, choices=PLATFORM_CHOICES, default="instagram")
    profile_url = models.URLField(validators=[URLValidator()], blank=True, default="")
    handle = models.CharField(max_length=120, blank=True, default="")  # @pseudo, si utile à l'affichage
    display_name = models.CharField(max_length=120, blank=True, default="")  # texte alternatif à montrer
    position = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    aria_label = models.CharField(max_length=140, blank=True, default="")  # pour accessibilité

    # --- Overrides d’icône (OPTIONNELS) ---
    # 1) SVG custom (recommandé pour teinter via CSS currentColor)
    icon_svg = models.FileField(upload_to="images/social/svg", null=True, blank=True)

    # 2) Raster custom → on génère 3 variantes WebP 48/32/24 (fond transparent conservé)
    icon_raster_source = models.ImageField(upload_to="images/social/src", null=True, blank=True,
                                           validators=[valider_l_image])
    icon_48 = models.ImageField(upload_to="images/social/variants", null=True, blank=True, editable=False)
    icon_32 = models.ImageField(upload_to="images/social/variants", null=True, blank=True, editable=False)
    icon_24 = models.ImageField(upload_to="images/social/variants", null=True, blank=True, editable=False)

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["position", "id"]
        verbose_name = _("Lien social")
        verbose_name_plural = _("Liens sociaux")
        constraints = [
            models.UniqueConstraint(fields=["website", "platform", "profile_url"], name="uniq_social_per_site_and_url"),
        ]

    def __str__(self):
        base = self.get_platform_display()
        return f"{base} — {self.display_name or self.handle or self.profile_url or 'sans URL'}"

    # ---------- helpers generation ----------
    def _variant_name(self, base_name: str, suffix: str) -> str:
        name_no_ext, __ = os.path.splitext(base_name)   # ex: images/social/src/monfichier
        return f"{name_no_ext}-{suffix}.webp"          # ex: images/social/src/monfichier-48.webp

    def _save_webp(self, img: Image.Image, size: int, target_name: str) -> str:
        if img.mode not in ("RGBA", "LA"):
            img = img.convert("RGBA")
        variant = img.copy()
        variant.thumbnail((size, size), Image.LANCZOS)

        buf = BytesIO()
        variant.save(buf, format="WEBP", quality=85, method=6)
        buf.seek(0)

        if default_storage.exists(target_name):
            default_storage.delete(target_name)
        default_storage.save(target_name, ContentFile(buf.read()))
        return target_name

    def save(self, *args, **kwargs):
        # 1) sauvegarder d’abord pour garantir .path/.name
        super().save(*args, **kwargs)

        # 1 bis) assainir le SVG déposé.
        #
        # Un SVG est un document XML : il peut porter un script, un attribut
        # `on*` ou un lien `javascript:`, et il est servi depuis /media/ — donc
        # sur l'origine du site. Aucun écran n'alimente ce champ aujourd'hui
        # (SocialLink n'a ni formulaire ni entrée d'administration), mais le
        # jour où l'un existera, le nettoyage sera déjà en place.
        self._sanitize_svg()

        # 2) si on a une source raster, (re)générer les variantes
        if self.icon_raster_source and self.icon_raster_source.name:
            base_name = self.icon_raster_source.name
            try:
                base_img = Image.open(self.icon_raster_source.path)
            except Exception:
                return  # si format non supporté par PIL

            name_48 = self._variant_name(base_name, "48")
            name_32 = self._variant_name(base_name, "32")
            name_24 = self._variant_name(base_name, "24")

            rel_48 = self._save_webp(base_img, 48, name_48)
            rel_32 = self._save_webp(base_img, 32, name_32)
            rel_24 = self._save_webp(base_img, 24, name_24)

            # assigner .name (PAS .url)
            self.icon_48.name = rel_48
            self.icon_32.name = rel_32
            self.icon_24.name = rel_24

            super().save(update_fields=["icon_48", "icon_32", "icon_24", "updated_at"])

    # ---------- accès icône ----------
    def _sanitize_svg(self):
        """
        Réécrit le SVG déposé, débarrassé de ce qui peut s'exécuter.

        Best-effort : un fichier illisible est laissé tel quel plutôt que de
        faire échouer l'enregistrement du lien.
        """
        if not (self.icon_svg and self.icon_svg.name):
            return

        from jeiko.sanitize import clean_svg

        try:
            self.icon_svg.open("rb")
            brut = self.icon_svg.read()
        except Exception:
            return
        finally:
            try:
                self.icon_svg.close()
            except Exception:
                logger.debug("Fermeture du fichier d'icône impossible", exc_info=True)

        propre = clean_svg(brut).encode("utf-8")
        if propre == brut:
            return

        try:
            self.icon_svg.storage.delete(self.icon_svg.name)
            self.icon_svg.storage.save(self.icon_svg.name, ContentFile(propre))
        except Exception:
            logger.exception(
                "Assainissement du SVG impossible pour le lien social #%s", self.pk
            )

    def get_icon_static_path(self) -> str:
        """
        Fallback local → chemin static attendu pour l’icône SVG par défaut.
        À placer dans: static/jeiko/icons/social/<platform>.svg
        """
        return f"jeiko/icons/social/{self.platform}.svg"

    def has_svg(self) -> bool:
        return bool(self.icon_svg)

    def has_raster_variants(self) -> bool:
        return bool(self.icon_24 and self.icon_24.name and self.icon_32 and self.icon_48)

    def get_best_icon(self, size: int = 24):
        """
        Retourne un tuple (type, url) où type ∈ {'svg','img'}
          - 'svg' => chemin static (ou override SVG)
          - 'img' => URL d’une variante raster (webp)
        size ∈ {24, 32, 48}
        """
        # 1) SVG custom prioritaire
        if self.icon_svg and hasattr(self.icon_svg, "url"):
            return ("svg", self.icon_svg.url)

        # 2) Variantes raster custom
        if self.has_raster_variants():
            if size <= 24 and self.icon_24 and self.icon_24.url:
                return ("img", self.icon_24.url)
            if size <= 32 and self.icon_32 and self.icon_32.url:
                return ("img", self.icon_32.url)
            return ("img", self.icon_48.url)

        # 3) SVG par défaut en static
        # (la template utilisera {% static path %})
        return ("svg", self.get_icon_static_path())


class SocialProvider(models.Model):
    """
    Configuration back-office d'un fournisseur de connexion sociale (allauth).

    Source de vérité unique : les clés sont saisies ici depuis `admin/`,
    puis synchronisées vers le `SocialApp` d'allauth (`sync_to_allauth`).

    Activation / désactivation = rattachement / détachement du `SocialApp`
    au `Site` courant. allauth (`SocialApp.objects.on_site`) n'affiche les
    boutons que pour les apps rattachées au site, donc un provider désactivé
    (ou sans identifiants) disparaît automatiquement de la page de connexion.

    Correspondance des champs allauth (SocialApp) :
        - Google / Facebook : client_id = Client ID, secret = Client Secret
        - Apple             : client_id = Services ID, secret = Key ID,
                              key = Team ID, settings["certificate_key"] = .p8
    """

    PROVIDER_GOOGLE = "google"
    PROVIDER_APPLE = "apple"
    PROVIDER_FACEBOOK = "facebook"
    PROVIDER_CHOICES = [
        (PROVIDER_GOOGLE, _("Google")),
        (PROVIDER_APPLE, _("Apple")),
        (PROVIDER_FACEBOOK, _("Facebook")),
    ]

    provider = models.CharField(
        max_length=32,
        choices=PROVIDER_CHOICES,
        unique=True,
        verbose_name=_("Fournisseur"),
    )
    enabled = models.BooleanField(
        default=False,
        verbose_name=_("Activé"),
        help_text=_("Affiche (ou masque) le bouton de connexion correspondant."),
    )

    client_id = models.CharField(
        max_length=300,
        blank=True,
        default="",
        verbose_name=_("Client ID"),
        help_text=_("Google/Facebook : Client ID. Apple : Services ID."),
    )
    # Chiffrés au repos (Fable 1 §1.5), comme les clés Stripe et Google
    # Agenda : avec eux, n'importe qui se fait passer pour le site auprès de
    # Google, Apple ou Facebook. Le Team ID (`key`) n'est pas un secret.
    secret = EncryptedCharField(
        max_length=500,
        blank=True,
        default="",
        verbose_name=_("Client Secret"),
        help_text=_("Google/Facebook : Client Secret. Apple : Key ID."),
    )
    key = models.CharField(
        max_length=191,
        blank=True,
        default="",
        verbose_name=_("Clé / Team ID"),
        help_text=_("Inutile pour Google/Facebook. Apple : Team ID."),
    )
    certificate_key = EncryptedTextField(
        blank=True,
        default="",
        verbose_name=_("Clé privée (.p8)"),
        help_text=_("Apple uniquement : contenu du fichier .p8 (clé privée)."),
    )

    position = models.PositiveIntegerField(default=0)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["position", "provider"]
        verbose_name = _("Connexion sociale")
        verbose_name_plural = _("Connexions sociales")

    def __str__(self):
        return f"{self.get_provider_display()} ({'activé' if self.enabled else 'désactivé'})"

    # ------------------------------------------------------------------ #
    # Validité des identifiants
    # ------------------------------------------------------------------ #
    @property
    def has_credentials(self) -> bool:
        """Identifiants minimum requis selon le fournisseur."""
        if not self.client_id:
            return False
        if self.provider == self.PROVIDER_APPLE:
            return bool(self.secret and self.key and self.certificate_key)
        return bool(self.secret)

    @property
    def is_live(self) -> bool:
        """Réellement exposé sur la page de connexion."""
        return self.enabled and self.has_credentials

    # ------------------------------------------------------------------ #
    # Synchronisation vers allauth
    # ------------------------------------------------------------------ #
    def sync_to_allauth(self):
        """
        Crée / met à jour le SocialApp allauth et gère le rattachement au
        Site courant (= activation/désactivation effective).
        """
        from django.conf import settings as dj_settings
        from django.contrib.sites.models import Site
        from allauth.socialaccount.models import SocialApp

        app = (
            SocialApp.objects.filter(provider=self.provider).first()
            or SocialApp(provider=self.provider)
        )
        app.name = self.get_provider_display()
        app.client_id = self.client_id
        app.key = self.key
        # Les secrets ne sont PAS recopiés : la table d'allauth les garderait
        # en clair, à côté de notre copie chiffrée — le chiffrement ne
        # servirait à rien. `JeikoSocialAccountAdapter.list_apps` les fournit
        # en mémoire, déchiffrés, au moment où allauth en a besoin.
        app.secret = ""
        app_settings = dict(app.settings or {})
        app_settings.pop("certificate_key", None)
        app.settings = app_settings
        app.save()

        site = Site.objects.filter(pk=dj_settings.SITE_ID).first()
        if site is not None:
            if self.is_live:
                app.sites.add(site)
            else:
                app.sites.remove(site)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        self.sync_to_allauth()

    @classmethod
    def all_providers(cls):
        """Retourne les 3 configs (créées si besoin), dans l'ordre d'affichage."""
        order = {p: i for i, (p, __) in enumerate(cls.PROVIDER_CHOICES)}
        for i, (code, __) in enumerate(cls.PROVIDER_CHOICES):
            cls.objects.get_or_create(provider=code, defaults={"position": i})
        return sorted(cls.objects.all(), key=lambda o: order.get(o.provider, 99))


class ErreurServeur(models.Model):
    """Une erreur 500, regroupée par signature. Voir `administration/erreurs.py`."""

    signature = models.CharField(max_length=64, unique=True)
    exception = models.CharField(max_length=200, verbose_name=_("Exception"))
    methode = models.CharField(max_length=10, blank=True, verbose_name=_("Méthode"))
    chemin = models.CharField(max_length=500, blank=True, verbose_name=_("Adresse"))
    trace = models.TextField(blank=True, verbose_name=_("Trace"))
    occurrences = models.PositiveIntegerField(default=1, verbose_name=_("Occurrences"))
    premiere = models.DateTimeField(auto_now_add=True, verbose_name=_("Première fois"))
    derniere = models.DateTimeField(default=timezone.now, verbose_name=_("Dernière fois"))
    occurrences_signalees = models.PositiveIntegerField(default=0)
    signalee_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-derniere"]
        verbose_name = _("Erreur serveur")
        verbose_name_plural = _("Erreurs serveur")

    def __str__(self):
        return f"{self.exception} — {self.methode} {self.chemin}"


class SignalementCsp(models.Model):
    """
    Ce que la protection des scripts (CSP) aurait bloqué, AGRÉGÉ (S-03,
    09/10/2026).

    L'en-tête est en mode « Report-Only » : il ne bloque rien, il signale.
    Sans adresse de signalement, ces violations ne s'affichaient que dans la
    console de chaque visiteur — personne ne les lisait, et on ne pouvait pas
    décider de passer en mode bloquant. Une ligne par (directive, origine
    bloquée, page), avec un compteur : mille visites d'une même page font
    une ligne, pas mille. Ni adresse IP, ni paramètres d'adresse, ni
    navigateur : ce qu'il faut pour corriger, rien de plus.
    """

    directive = models.CharField(max_length=64)
    origine_bloquee = models.CharField(max_length=200)
    page = models.CharField(max_length=200)
    compte = models.PositiveIntegerField(default=1)
    premier_le = models.DateTimeField(auto_now_add=True)
    dernier_le = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Signalement CSP")
        verbose_name_plural = _("Signalements CSP")
        constraints = [models.UniqueConstraint(fields=["directive", "origine_bloquee", "page"],
                                               name="signalement_csp_unique")]


# --------------------------------------------------------------------------- #
# Serveur de licences (LIC-01, 11/10/2026)
#
# Les tables existent sur tous les sites — une application de plus aurait dû
# entrer dans le gabarit de settings — mais ne servent que là où le .env pose
# JEIKO_SERVEUR_DE_LICENCES=True (jeiko.fr) : ailleurs, ni écran ni API, et
# les tables restent vides. La logique vit dans jeiko/licences/.
# --------------------------------------------------------------------------- #
class Licence(models.Model):
    """
    La clé d'un client. Elle autorise les mises à jour d'UN domaine — celui
    qui s'en sert le premier, ou celui qu'on lui donne —, jusqu'à sa date de
    fin, ou à vie.

    La recherche se fait par EMPREINTE (SHA-256 de la forme normalisée) :
    c'est elle qui fait foi. La clé est AUSSI gardée chiffrée (LIC-02,
    décision de Guillaume, 11/10) pour que le client la retrouve dans son
    compte et Guillaume dans la fiche : une base lue sans le .env ne la livre
    pas (voir jeiko/encrypted.py). `indice` (ses 4 derniers caractères)
    suffit à la reconnaître dans une liste.
    """

    titulaire = models.CharField(_("Titulaire"), max_length=200)
    email = models.EmailField(_("E-mail"), blank=True, default="")
    notes = models.TextField(_("Notes"), blank=True, default="")
    empreinte = models.CharField(max_length=64, unique=True)
    cle_chiffree = EncryptedCharField(max_length=64, blank=True, default="")
    indice = models.CharField(max_length=8, blank=True, default="")
    # Le compte qui l'a achetée (boutique de jeiko.fr, LIC-02) : il la voit et
    # la prolonge depuis son espace. Vide pour une clé créée à la main.
    compte = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="licences", verbose_name=_("Compte"),
    )
    commande = models.ForeignKey(
        "shop.Order", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="licences", verbose_name=_("Commande"),
    )
    # L'abonnement qui la paie (prélèvement Stripe) : chaque paiement repousse
    # sa fin à celle de la période payée. Vide : achat unique ou clé à la main.
    abonnement = models.ForeignKey(
        "shop.Abonnement", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="licences", verbose_name=_("Abonnement"),
    )
    domaine = models.CharField(
        _("Domaine"), max_length=253, blank=True, default="",
        help_text=_("Vide : la clé se lie au premier domaine qui s'en sert."),
    )
    expire_le = models.DateField(
        _("Fin de validité"), null=True, blank=True,
        help_text=_("Vide : accès à vie."),
    )
    active = models.BooleanField(_("Active"), default=True)
    cree_le = models.DateTimeField(_("Créée le"), auto_now_add=True)
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name="+", verbose_name=_("Créée par"),
    )
    derniere_verification_le = models.DateTimeField(_("Dernière vérification"), null=True, blank=True)
    derniere_version = models.CharField(_("Version installée"), max_length=32, blank=True, default="")
    # L'espace revendeur (OVH-01, R4–R6) : une clé que Guillaume a validée
    # REVENDEUR ouvre l'API des revendeurs (jeiko/revendeurs/) — créer des
    # licences pour ses clients, demander leur mise en ligne. Son plafond
    # s'ajoute au plafond global de l'hébergement. Une clé de site ordinaire
    # n'ouvre rien là.
    revendeur = models.BooleanField(
        _("Revendeur validé"), default=False,
        help_text=_("Cette clé ouvre l'espace revendeur : licences et mises en ligne pour ses clients."),
    )
    plafond_revendeur_ht = models.DecimalField(
        _("Plafond du revendeur sur 30 jours (€ HT)"), max_digits=8, decimal_places=2, default=0,
        null=True, blank=True, validators=[MinValueValidator(0)],
        help_text=_("0 : aucune commande ne peut partir pour lui. Vide : sans plafond."),
    )
    # La clé REVENDEUR, à part de la clé du site (03/11/2026, demandé par
    # Guillaume) : c'est elle que le revendeur colle dans son espace. La
    # renouveler ou la retirer ne touche pas aux mises à jour de son site, et
    # la clé du site, qui voyage à chaque mise à jour, n'ouvre plus l'API.
    cle_revendeur_empreinte = models.CharField(max_length=64, blank=True, default="", db_index=True)
    cle_revendeur_chiffree = EncryptedCharField(max_length=64, blank=True, default="")
    # Ce que Guillaume lui permet, droit par droit. Tout éteint au départ :
    # valider un revendeur ne lui donne rien qu'on n'ait coché.
    revendeur_peut_creer = models.BooleanField(_("Créer des clients et leurs licences"), default=False)
    revendeur_peut_commander = models.BooleanField(
        _("Commander un serveur ou un domaine"), default=False,
        help_text=_("Chaque commande attend encore votre confirmation."))
    revendeur_peut_reinstaller = models.BooleanField(_("Réinstaller JEIKO sur un serveur"), default=False)
    revendeur_peut_resilier = models.BooleanField(_("Résilier un serveur, un domaine ou une licence"), default=False)
    # Le revendeur par qui elle a été vendue (R3 : de quoi le facturer un
    # jour). PROTECT : un revendeur qui a des clients ne s'efface pas.
    vendue_par = models.ForeignKey(
        "self", on_delete=models.PROTECT, null=True, blank=True,
        related_name="clients", verbose_name=_("Vendue par"),
    )

    class Meta:
        verbose_name = _("Licence")
        verbose_name_plural = _("Licences")
        ordering = ("titulaire", "-cree_le")

    def __str__(self):
        return f"{self.titulaire} — …{self.indice}"

    @property
    def a_vie(self):
        return self.expire_le is None

    def expiree(self, aujourd_hui=None):
        return self.expire_le is not None and self.expire_le < (aujourd_hui or timezone.localdate())

    @property
    def valide(self):
        return self.active and not self.expiree()

    @property
    def domaine_modifiable(self):
        """
        Le client peut-il (re)choisir le site de sa clé depuis son compte ?
        Oui tant qu'elle n'a autorisé aucune mise à jour sur ce domaine ;
        ensuite, la délier revient à l'exploitant (licences.views).
        """
        return not (self.domaine and self.verifications.filter(
            decision=VerificationDeLicence.AUTORISEE, domaine=self.domaine).exists())


class VerificationDeLicence(models.Model):
    """
    Chaque demande d'un site : qui, quelle version, et ce qui a été répondu.
    En mode observation, c'est ce journal qui dit quels sites ont encore à
    recevoir leur clé avant d'activer le blocage. Purgé après 180 jours.
    """

    AUTORISEE = "autorisee"
    REFUSEE = "refusee"
    OBSERVATION = "observation"
    DECISIONS = [
        (AUTORISEE, _("Autorisée")),
        (REFUSEE, _("Refusée")),
        (OBSERVATION, _("Laissée passer (observation)")),
    ]

    licence = models.ForeignKey(Licence, on_delete=models.SET_NULL, null=True, blank=True,
                                related_name="verifications")
    indice = models.CharField(max_length=8, blank=True, default="")
    domaine = models.CharField(max_length=253, blank=True, default="")
    version_actuelle = models.CharField(max_length=32, blank=True, default="")
    version_visee = models.CharField(max_length=32, blank=True, default="")
    ip = models.GenericIPAddressField(null=True, blank=True)
    decision = models.CharField(max_length=12, choices=DECISIONS)
    motif = models.CharField(max_length=200, blank=True, default="")
    le = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        verbose_name = _("Vérification de licence")
        verbose_name_plural = _("Vérifications de licence")
        ordering = ("-le",)


class ReglagesDesLicences(models.Model):
    """
    L'interrupteur. Tant que `blocage_actif` est faux, toute mise à jour est
    autorisée et seulement notée (mode observation) : on distribue les clés
    d'abord, on bloque ensuite — sans rien republier.
    """

    blocage_actif = models.BooleanField(
        _("Bloquer les mises à jour sans clé valide"), default=False,
        help_text=_("Décoché : toute mise à jour passe, et la demande est seulement notée."),
    )
    duree_essai_jours = models.PositiveSmallIntegerField(
        _("Durée de l'essai (jours)"), default=30,
        validators=[MinValueValidator(1), MaxValueValidator(366)],
    )

    class Meta:
        verbose_name = _("Réglages des licences")
        verbose_name_plural = _("Réglages des licences")

    @classmethod
    def get_solo(cls):
        obj, __ = cls.objects.get_or_create(pk=1)
        return obj


class CompteReseau(models.Model):
    """
    Une page Facebook ou un compte Instagram professionnel relié à une licence
    par le relais des réseaux (RES-01, jeiko/reseaux/). Vit ici, comme les
    licences, pour ne pas ajouter d'application au gabarit de settings.

    `jeton` est le jeton de PAGE (Instagram se publie avec celui de sa page) :
    sans expiration tant que la personne garde son rôle sur la page et
    l'autorisation de l'application. `jeton_utilisateur` (60 jours) ne sert
    qu'à retirer l'autorisation chez Meta quand on délie le dernier compte de
    cette personne. Les deux chiffrés (jeiko/encrypted.py).
    """

    FACEBOOK = "facebook"
    INSTAGRAM = "instagram"
    RESEAUX = [(FACEBOOK, "Facebook"), (INSTAGRAM, "Instagram")]

    ACTIF = "actif"
    A_RECONNECTER = "a_reconnecter"
    ETATS = [(ACTIF, _("Relié")), (A_RECONNECTER, _("À reconnecter"))]

    licence = models.ForeignKey(Licence, on_delete=models.CASCADE, related_name="comptes_reseaux")
    reseau = models.CharField(_("Réseau"), max_length=12, choices=RESEAUX)
    id_externe = models.CharField(max_length=64)
    nom = models.CharField(_("Nom"), max_length=200, blank=True, default="")
    page_id = models.CharField(max_length=64, blank=True, default="")
    utilisateur_meta = models.CharField(max_length=64, blank=True, default="")
    jeton = EncryptedTextField(blank=True, default="")
    jeton_utilisateur = EncryptedTextField(blank=True, default="")
    etat = models.CharField(_("État"), max_length=16, choices=ETATS, default=ACTIF)
    derniere_erreur = models.CharField(max_length=300, blank=True, default="")
    relie_le = models.DateTimeField(_("Relié le"), auto_now_add=True)
    verifie_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = _("Compte de réseau relié")
        verbose_name_plural = _("Comptes de réseaux reliés")
        ordering = ("licence", "reseau", "nom")
        constraints = [models.UniqueConstraint(fields=["licence", "reseau", "id_externe"],
                                               name="un_compte_reseau_par_licence")]

    def __str__(self):
        return f"{self.get_reseau_display()} — {self.nom}"


class PublicationReseau(models.Model):
    """
    Une publication demandée par un site au relais, et ce qu'elle est
    devenue : le journal que le site relit (quoi, où, quand, lien ou erreur).
    Une ligne par compte visé. `compte` peut disparaître (délié) : `reseau` et
    `nom_du_compte` gardent la trace.
    """

    PROGRAMMEE = "programmee"
    EN_COURS = "en_cours"
    PUBLIEE = "publiee"
    ECHOUEE = "echouee"
    ANNULEE = "annulee"
    ETATS = [
        (PROGRAMMEE, _("Programmée")),
        (EN_COURS, _("En cours")),
        (PUBLIEE, _("Publiée")),
        (ECHOUEE, _("Échouée")),
        (ANNULEE, _("Annulée")),
    ]

    licence = models.ForeignKey(Licence, on_delete=models.CASCADE, related_name="publications_reseaux")
    compte = models.ForeignKey(CompteReseau, on_delete=models.SET_NULL, null=True, blank=True,
                               related_name="publications")
    reseau = models.CharField(_("Réseau"), max_length=12, choices=CompteReseau.RESEAUX)
    nom_du_compte = models.CharField(_("Compte"), max_length=200, blank=True, default="")
    texte = models.TextField(_("Texte"), blank=True, default="")
    images = models.JSONField(default=list, blank=True)
    lien = models.URLField(max_length=1000, blank=True, default="")
    programmee_pour = models.DateTimeField(_("Programmée pour"), db_index=True)
    etat = models.CharField(_("État"), max_length=12, choices=ETATS, default=PROGRAMMEE, db_index=True)
    # Instagram : le conteneur créé, en attente que Meta ait fini de lire l'image.
    conteneur = models.CharField(max_length=64, blank=True, default="")
    id_externe = models.CharField(max_length=128, blank=True, default="")
    permalien = models.URLField(max_length=1000, blank=True, default="")
    erreur = models.CharField(_("Erreur"), max_length=500, blank=True, default="")
    cree_le = models.DateTimeField(auto_now_add=True)
    publiee_le = models.DateTimeField(_("Publiée le"), null=True, blank=True)

    class Meta:
        verbose_name = _("Publication sur un réseau")
        verbose_name_plural = _("Publications sur les réseaux")
        ordering = ("-programmee_pour", "-pk")


# --------------------------------------------------------------------------- #
# Hébergement OVH (OVH-01, 29/10/2026)
#
# Comme les licences : les tables existent partout, ne servent que là où le
# .env pose JEIKO_HEBERGEMENT_OVH=True (jeiko.fr). La logique vit dans
# jeiko/hebergement/.
# --------------------------------------------------------------------------- #
class ReglagesRevendeur(models.Model):
    """
    Côté SITE REVENDEUR (kojei.fr…) : la clé revendeur que jeiko.fr lui a
    donnée, collée dans le menu Jeiko. Chiffrée : une base lue sans le .env
    ne la livre pas. L'espace ne s'allume que par JEIKO_ESPACE_REVENDEUR.
    """

    cle = EncryptedCharField(_("Clé revendeur"), max_length=80, blank=True, default="")

    class Meta:
        verbose_name = _("Réglages de l'espace revendeur")
        verbose_name_plural = _("Réglages de l'espace revendeur")
        default_permissions = ()

    @classmethod
    def get_solo(cls):
        obj, __ = cls.objects.get_or_create(pk=1)
        return obj


class ReglagesHebergement(models.Model):
    """
    Ce qui se règle à l'écran, DANS les bornes du .env : le mode de paiement,
    le plafond, le délai annoncé, le centre de données. Les clés d'API OVH et
    la clé SSH ne sont pas ici : elles ne viennent que du .env (01/11/2026,
    « que personne ne puisse y avoir accès »).
    """

    paiement_automatique = models.BooleanField(
        _("Payer automatiquement les bons de commande"), default=False,
        help_text=_("Décoché : le bon part non payé, à régler dans l'espace client OVH. "
                    "Coché : le moyen de paiement par défaut du compte OVH est débité à l'envoi."),
    )
    plafond_30_jours_ht = models.DecimalField(
        _("Plafond des commandes sur 30 jours (€ HT)"), max_digits=8, decimal_places=2, default=0,
        null=True, blank=True, validators=[MinValueValidator(0)],
        help_text=_("0 : aucune commande ne peut partir. Vide : sans plafond, si le .env le permet."),
    )
    delai_annonce_heures = models.PositiveSmallIntegerField(
        _("Délai de livraison annoncé (heures)"), default=24, validators=[MinValueValidator(1)])
    datacenter_defaut = models.CharField(_("Centre de données par défaut"), max_length=8, default="GRA")

    class Meta:
        verbose_name = _("Réglages de l'hébergement OVH")
        verbose_name_plural = _("Réglages de l'hébergement OVH")

    @classmethod
    def get_solo(cls):
        obj, __ = cls.objects.get_or_create(pk=1)
        return obj



class MiseEnLigne(models.Model):
    """
    Un site posé sur un VPS commandé chez OVH : une fiche qui avance par
    étapes (jeiko/hebergement/etapes.py), chacune notée au journal, chacune
    rejouable — sauf l'envoi du bon, qui ne part qu'une fois et seulement
    après la confirmation d'une personne qui a le droit de commander.
    """

    PANIER, CONFIRMATION, COMMANDE, LIVRAISON, MACHINE, DNS, INSTALLATION, EN_LIGNE = (
        "panier", "confirmation", "commande", "livraison", "machine", "dns", "installation", "en_ligne")
    ETAPES = [
        (PANIER, _("Panier")),
        (CONFIRMATION, _("Confirmation")),
        (COMMANDE, _("Commande")),
        (LIVRAISON, _("Livraison")),
        (MACHINE, _("Machine")),
        (DNS, _("DNS")),
        (INSTALLATION, _("Installation")),
        (EN_LIGNE, _("En ligne")),
    ]
    EN_COURS, ATTENTE, ECHEC, A_VERIFIER, TERMINEE, ABANDONNEE = (
        "en_cours", "attente", "echec", "a_verifier", "terminee", "abandonnee")
    STATUTS = [
        (EN_COURS, _("En cours")),
        (ATTENTE, _("En attente")),
        (ECHEC, _("Échec")),
        (A_VERIFIER, _("À vérifier")),
        (TERMINEE, _("Terminée")),
        (ABANDONNEE, _("Abandonnée")),
    ]
    DOMAINE_OVH, DOMAINE_A_ACHETER, DOMAINE_AILLEURS = "ovh", "acheter", "ailleurs"
    MODES_DE_DOMAINE = [
        (DOMAINE_OVH, _("Déjà dans le compte OVH")),
        (DOMAINE_A_ACHETER, _("À acheter chez OVH, dans la même commande")),
        (DOMAINE_AILLEURS, _("Chez un autre registraire (DNS posés à la main)")),
    ]

    client = models.CharField(_("Client"), max_length=200)
    nom_du_site = models.CharField(_("Nom du site"), max_length=26)
    domaine = models.CharField(_("Domaine"), max_length=253)
    mode_domaine = models.CharField(_("Nom de domaine"), max_length=10, choices=MODES_DE_DOMAINE)
    langue = models.CharField(_("Langue du site"), max_length=2, default="fr")
    email_admin = models.EmailField(_("E-mail du compte d'administration"))
    identifiant_admin = models.CharField(_("Identifiant du compte d'administration"), max_length=150)
    mot_de_passe_admin = EncryptedCharField(max_length=128, blank=True, default="")
    offre = models.CharField(_("Offre VPS (code OVH)"), max_length=64)
    datacenter = models.CharField(_("Centre de données"), max_length=8, default="GRA")
    duree = models.CharField(_("Durée"), max_length=8, default="P1M")
    notes = models.TextField(_("Notes"), blank=True, default="")

    etape = models.CharField(_("Étape"), max_length=14, choices=ETAPES, default=PANIER)
    statut = models.CharField(_("Statut"), max_length=12, choices=STATUTS, default=EN_COURS, db_index=True)
    derniere_erreur = models.TextField(_("Dernière erreur"), blank=True, default="")
    # Ce que chaque étape a obtenu : rien n'est redemandé à la reprise.
    panier_id = models.CharField(max_length=64, blank=True, default="")
    produit = models.CharField(_("Produit"), max_length=300, blank=True, default="")
    prix_ht = models.DecimalField(_("Prix HT"), max_digits=8, decimal_places=2, null=True, blank=True)
    prix_ttc = models.DecimalField(_("Prix TTC"), max_digits=8, decimal_places=2, null=True, blank=True)
    confirmee_par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
                                      blank=True, related_name="+")
    confirmee_le = models.DateTimeField(null=True, blank=True)
    commande_tentee_le = models.DateTimeField(null=True, blank=True)
    commande_id = models.CharField(_("Bon de commande OVH"), max_length=32, blank=True, default="")
    commande_le = models.DateTimeField(null=True, blank=True, db_index=True)
    lien_de_paiement = models.URLField(max_length=500, blank=True, default="")
    vps = models.CharField(_("VPS"), max_length=100, blank=True, default="")
    ipv4 = models.GenericIPAddressField(_("IPv4"), null=True, blank=True)
    ipv6 = models.GenericIPAddressField(_("IPv6"), null=True, blank=True)
    reinstallation_lancee_le = models.DateTimeField(null=True, blank=True)
    hote_connu = models.TextField(blank=True, default="")
    dns_pose_le = models.DateTimeField(null=True, blank=True)
    installation_lancee_le = models.DateTimeField(null=True, blank=True)
    # Un seul travailleur à la fois (tâche des 5 minutes ou bouton).
    travail_depuis = models.DateTimeField(null=True, blank=True)
    # Demandée par un revendeur (jeiko/revendeurs/) : son plafond s'applique,
    # et il la voit dans son espace. La licence du site, fabriquée avec la
    # demande (R5).
    revendeur = models.ForeignKey("Licence", on_delete=models.PROTECT, null=True, blank=True,
                                  related_name="mises_en_ligne", verbose_name=_("Revendeur"))
    licence = models.ForeignKey("Licence", on_delete=models.SET_NULL, null=True, blank=True,
                                related_name="+", verbose_name=_("Licence"))

    cree_le = models.DateTimeField(auto_now_add=True)
    cree_par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
                                 blank=True, related_name="+")
    terminee_le = models.DateTimeField(null=True, blank=True)
    acces_envoyes_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = _("Mise en ligne")
        verbose_name_plural = _("Mises en ligne")
        ordering = ("-cree_le",)
        # Aucun droit délégable : le menu Jeiko n'ouvre qu'aux comptes du .env
        # (jeiko/acces_jeiko.py), jamais par un rôle.
        default_permissions = ()

    def __str__(self):
        return f"{self.client} — {self.domaine}"

    @property
    def machine_payee_sans_site(self):
        return bool(self.commande_id) and self.statut != self.TERMINEE


class EvenementDeMiseEnLigne(models.Model):
    """
    Le journal du menu Jeiko : chaque étape d'une mise en ligne, et chaque
    geste — confirmation, résiliation, changement de plafond ou de paiement —
    avec qui et quand. Sans mise en ligne : un geste sur les réglages ou sur
    une licence.
    """

    INFO, ERREUR = "info", "erreur"
    mise_en_ligne = models.ForeignKey(MiseEnLigne, on_delete=models.CASCADE, related_name="evenements",
                                      null=True, blank=True)
    le = models.DateTimeField(auto_now_add=True)
    etape = models.CharField(max_length=14, choices=MiseEnLigne.ETAPES, blank=True, default="")
    niveau = models.CharField(max_length=6, default=INFO)
    message = models.TextField()
    par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
                            blank=True, related_name="+")
    #: Un geste venu de l'espace d'un revendeur, par son API (01/11/2026) : il
    #: n'a pas de compte sur jeiko.fr, c'est sa licence qui signe.
    par_revendeur = models.ForeignKey(Licence, on_delete=models.SET_NULL, null=True, blank=True, related_name="+")

    class Meta:
        ordering = ("-le", "-pk")


class Resiliation(models.Model):
    """
    La fin d'un service vendu (01/11/2026) : un VPS ou un domaine (fin à
    l'échéance chez OVH, ou transfert du domaine au client), une licence
    (coupée à une date, ou gardée). Programmée, elle s'annule jusqu'à sa date ;
    passée la date, elle est faite. jeiko/hebergement/resiliation.py.
    """

    VPS, DOMAINE, LICENCE = "vps", "domaine", "licence"
    SERVICES = [(VPS, _("Serveur")), (DOMAINE, _("Domaine")), (LICENCE, _("Licence"))]
    ECHEANCE, TRANSFERT, COUPEE, GARDEE = "echeance", "transfert", "coupee", "gardee"
    CHOIX = [
        (ECHEANCE, _("Fin à l'échéance")),
        (TRANSFERT, _("Transfert au client")),
        (COUPEE, _("Coupée à la fin du contrat")),
        (GARDEE, _("Gardée")),
    ]
    PROGRAMMEE, ANNULEE = "programmee", "annulee"
    ETATS = [(PROGRAMMEE, _("Programmée")), (ANNULEE, _("Annulée"))]

    service = models.CharField(_("Service"), max_length=8, choices=SERVICES)
    mise_en_ligne = models.ForeignKey(MiseEnLigne, on_delete=models.CASCADE, null=True, blank=True,
                                      related_name="resiliations")
    licence = models.ForeignKey(Licence, on_delete=models.CASCADE, null=True, blank=True,
                                related_name="resiliations")
    choix = models.CharField(_("Choix"), max_length=10, choices=CHOIX)
    date_effet = models.DateField(_("Date d'effet"), null=True, blank=True)
    etat = models.CharField(_("État"), max_length=10, choices=ETATS, default=PROGRAMMEE)
    code_de_transfert = EncryptedCharField(max_length=128, blank=True, default="")
    ancienne_fin = models.DateField(null=True, blank=True)
    par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
                            related_name="+")
    par_revendeur = models.ForeignKey(Licence, on_delete=models.SET_NULL, null=True, blank=True, related_name="+")
    le = models.DateTimeField(auto_now_add=True)
    annulee_par = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
                                    blank=True, related_name="+")
    annulee_le = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = _("Résiliation")
        verbose_name_plural = _("Résiliations")
        ordering = ("-le",)
        default_permissions = ()

    @property
    def faite(self):
        return self.etat == self.PROGRAMMEE and self.date_effet is not None and self.date_effet <= timezone.localdate()


class ModeleDeSiteApplique(models.Model):
    """
    Le journal des modèles de site posés (TPL-01) : ce qui a été changé, pour
    pouvoir revenir en arrière — pages dépubliées, ancien accueil, anciens
    menus par défaut, ancien thème, anciennes polices. Rien n'a été supprimé
    par le modèle : tout ce que ce journal désigne existe encore.
    Voir administration_pages/modeles_de_site.py.
    """

    cle = models.CharField(_("Modèle"), max_length=60)
    applique_le = models.DateTimeField(_("Appliqué le"), auto_now_add=True)
    par = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                            on_delete=models.SET_NULL, related_name="+")
    details = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ("-applique_le",)
        verbose_name = _("Modèle de site appliqué")
        verbose_name_plural = _("Modèles de site appliqués")

    def __str__(self):
        return f"{self.cle} ({self.applique_le:%d/%m/%Y})"



class NotificationVue(models.Model):
    """
    NOTIF-01 — quand une personne a ouvert pour la dernière fois la liste
    d'une notification « du nouveau » (rendez-vous, résultats, membres,
    messages) : ce qui est arrivé APRÈS compte dans sa pastille.
    """

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="+")
    code = models.CharField(max_length=40)
    vu_le = models.DateTimeField()

    class Meta:
        constraints = [models.UniqueConstraint(fields=["user", "code"], name="une_vue_par_notification")]
