# jeiko/agents/urls_api.py
"""
Routes de l'API des agents.

Aucune route de suppression de page : voir l'en-tête de `vues_pages.py`. Ce
n'est pas un oubli, c'est la règle — et son absence ici est la première des
deux barrières.
"""

from django.urls import path

from .vues_api import Guide, QuiSuisJe
from .vues_objets import (
    CreationObjet, CreationProduit, DetailObjet, DetailProduit, ListeDesModeles,
    ListeDesObjets, ListeDesProduits,
)
from .vues_pages import (
    BlocsDeLaLigne, Deplacement, ListeDesImages, ContenuDuBloc, CreationDePage, DetailBloc, DetailLigne,
    DetailPage, DetailSection, LignesDeLaSection, ListeDesPages,
    SectionsDeLaPage,
)

app_name = "jeiko_agents_api"

urlpatterns = [
    # Le mode d'emploi, à la racine ET nommé : c'est le premier appel qu'un
    # agent doit faire, et il ne doit pas avoir à le chercher.
    path("", Guide.as_view(), name="guide"),
    path("guide/", Guide.as_view(), name="guide_explicite"),

    # Vérifier son jeton et découvrir ses droits.
    path("qui-suis-je/", QuiSuisJe.as_view(), name="whoami"),

    # Pages — lecture, création, modification. Jamais de suppression.
    path("pages/", ListeDesPages.as_view(), name="pages"),
    path("pages/creer/", CreationDePage.as_view(), name="page_creer"),
    path("pages/<int:page_id>/", DetailPage.as_view(), name="page"),
    path("pages/<int:page_id>/sections/", SectionsDeLaPage.as_view(), name="page_sections"),

    # Sections
    path("sections/<int:section_id>/", DetailSection.as_view(), name="section"),
    path("sections/<int:section_id>/lignes/", LignesDeLaSection.as_view(), name="section_lignes"),

    # Lignes
    path("lignes/<int:ligne_id>/", DetailLigne.as_view(), name="ligne"),
    path("lignes/<int:ligne_id>/blocs/", BlocsDeLaLigne.as_view(), name="ligne_blocs"),

    # Blocs
    path("blocs/<int:bloc_id>/", DetailBloc.as_view(), name="bloc"),
    path("blocs/<int:bloc_id>/contenu/", ContenuDuBloc.as_view(), name="bloc_contenu"),

    # Déplacer un élément — un seul point d'entrée pour les trois niveaux.
    # `position` n'est volontairement pas modifiable par PATCH : l'écrire à la
    # main produirait deux éléments au même rang.
    path("deplacer/<str:niveau>/<int:element_id>/", Deplacement.as_view(), name="deplacer"),

    # Médiathèque — lecture seule. Le téléversement reste dans
    # l'administration, où s'appliquent les validateurs de S-10.
    path("images/", ListeDesImages.as_view(), name="images"),

    # Modèles de fiche — le contrat à lire avant de créer quoi que ce soit :
    # quels types existent, et quels champs les composent.
    path("modeles/", ListeDesModeles.as_view(), name="modeles"),

    # Fiches (objets personnalisés). Pas de suppression, comme pour les pages.
    path("objets/", ListeDesObjets.as_view(), name="objets"),
    path("objets/creer/", CreationObjet.as_view(), name="objet_creer"),
    path("objets/<int:objet_id>/", DetailObjet.as_view(), name="objet"),

    # Produits — le commerce d'une fiche : référence, prix, TVA, stock.
    path("produits/", ListeDesProduits.as_view(), name="produits"),
    path("produits/creer/", CreationProduit.as_view(), name="produit_creer"),
    path("produits/<int:produit_id>/", DetailProduit.as_view(), name="produit"),
]
