# jeiko/agents/vues_pages.py
"""
L'API des pages : lire un arbre complet, le construire, le modifier.

La forme retenue
----------------
**Une lecture d'un seul tenant, des écritures granulaires.**

`GET /pages/<id>/` rend la page entière — sections, lignes, blocs, contenus et
tous les paramètres — en un seul document. Un agent qui doit modifier une page
a besoin de la voir en entier pour décider ; le faire en quarante appels
coûterait cher et lui donnerait une vue par morceaux.

Les écritures, elles, restent unitaires. Un `PUT` de l'arbre complet aurait été
séduisant, mais il suppose un moteur de comparaison : c'est lui qui déciderait
seul de supprimer ce qui manque dans le document reçu. Un agent qui oublie une
branche effacerait alors du contenu sans l'avoir demandé, et personne ne
saurait dire si c'était voulu. Les écritures unitaires disent ce qu'elles font,
se journalisent une par une, et une erreur n'emporte que son propre appel.

Ce qui est délibérément absent
------------------------------
**La suppression de page.** Aucun point d'entrée, à aucune permission. Un agent
peut tout construire et tout défaire à l'intérieur d'une page, mais la page
elle-même ne disparaît que par la main d'un humain, dans l'écran qui dit les
conséquences. C'est la règle posée avec l'exploitant, et elle est appliquée
deux fois : ici par l'absence de route, et par un rôle qui ne porte pas
`delete_page`.

Le vocabulaire du modèle, à connaître
-------------------------------------
`Bloc.position` n'est **pas** un rang vertical : c'est un numéro de COLONNE.
Le rang dans la colonne est `position_in_column`. L'API expose donc `colonne`
et `rang`, qui disent ce qu'ils sont.
"""

from django.db import transaction
from django.shortcuts import get_object_or_404
from django.utils.text import slugify

from jeiko.administration_pages import fabrique
from jeiko.administration_pages.models import (
    Bloc, Content, ContentButton, ContentFormField, ContentFormulaire,
    ContentImage, ContentText, ContentVideo, ImageContent, Line, Page,
    Section,
)

from . import contenus_dynamiques, parametres
from .contenus_dynamiques import ElementInvalide
from .parametres import ParametreInvalide
from .vues_api import CorpsInvalide, VueAgent, erreur, ok

LIRE = "administration_pages.view_page"
MODIFIER = "administration_pages.change_page"
CREER = "administration_pages.add_page"


# --------------------------------------------------------------------------- #
#  Sérialisation
# --------------------------------------------------------------------------- #
def _contenu_en_dict(content):
    """
    Le contenu d'un bloc, réduit à ce qu'un agent peut lire et écrire.

    Les types non encore couverts sont rendus avec leur seul `type` : mieux
    vaut dire « ce bloc est un carrousel, je ne sais pas te le détailler » que
    de laisser croire qu'il est vide.
    """
    if content is None:
        return {"type": "NOT_SET"}

    donnees = {"type": content.content_type}

    if content.content_type == "TEXT" and content.content_text:
        donnees["texte"] = content.content_text.text
    elif content.content_type == "BUTTON" and content.content_button:
        bouton = content.content_button
        donnees["bouton"] = {
            cle: getattr(bouton, champ) for cle, champ in CHAMPS_BOUTON.items()
        }
        donnees["bouton"]["page_id"] = bouton.page_target_id
        donnees["bouton"]["style"] = {
            cle: getattr(bouton, champ) for cle, champ in STYLE_BOUTON.items()
        }
    elif content.content_type == "IMAGE" and content.content_image:
        image = content.content_image.image_content
        donnees["image"] = {
            "id": image.id if image else None,
            "alt": getattr(image, "alt", "") if image else "",
        }
    elif content.content_type == "FORM" and content.content_formulaire:
        donnees["formulaire"] = _formulaire_en_dict(content.content_formulaire)
    elif content.content_type == "VIDEO" and content.content_video:
        donnees["video"] = {
            cle: getattr(content.content_video, champ)
            for cle, champ in CHAMPS_VIDEO.items()
        }
    elif content.content_type in CONTENUS_SIMPLES:
        donnees[content.content_type.lower()] = _lire_contenu_simple(content)
    elif contenus_dynamiques.est_dynamique(content.content_type):
        donnees.update(contenus_dynamiques.lire(content))
    elif content.content_type != "NOT_SET":
        donnees["modifiable_par_l_api"] = False

    return donnees


def _bloc_en_dict(bloc):
    return {
        "id": bloc.id,
        "colonne": bloc.position,
        "rang": bloc.position_in_column,
        "contenu": _contenu_en_dict(getattr(bloc, "content", None)),
        "parametres": parametres.lire(bloc),
    }


def _ligne_en_dict(ligne):
    return {
        "id": ligne.id,
        "position": ligne.position,
        "blocs": [
            _bloc_en_dict(b)
            for b in ligne.blocs.all().order_by("position", "position_in_column", "id")
        ],
        "parametres": parametres.lire(ligne),
    }


def _section_en_dict(section):
    return {
        "id": section.id,
        "position": section.position,
        "lignes": [
            _ligne_en_dict(l) for l in section.lines.all().order_by("position", "id")
        ],
        "parametres": parametres.lire(section),
    }


def _metadonnees_de(page):
    """Le titre et la description qui partent dans les résultats de recherche."""
    meta = getattr(page, "metadata", None)
    return {
        "titre": meta.title if meta else "",
        "description": meta.description if meta else "",
    }


def _page_en_resume(page):
    return {
        "id": page.id,
        "titre": page.title,
        "metadonnees": _metadonnees_de(page),
        "url_tag": page.url_tag,
        "publiee": page.active,
        "racine": page.is_root,
        "protegee": page.is_protected,
        "url": page.get_absolute_url() if hasattr(page, "get_absolute_url") else "",
    }


#: Champs de page qu'un agent peut écrire.
#:
#: `is_root`, `is_protected`, `is_pdf`, `is_mail_template` et les autres
#: drapeaux de nature en sont exclus : ils changent ce QU'EST une page, pas ce
#: qu'elle raconte. Les basculer par erreur transformerait la page d'accueil en
#: gabarit d'e-mail, ce qu'aucun message d'erreur ne rattraperait.
CHAMPS_PAGE_MODIFIABLES = {
    "titre": "title",
    "url_tag": "url_tag",
    "publiee": "active",
    "afficher_le_menu": "show_default_main_menu",
    "afficher_le_pied_de_page": "show_default_footer",
    "indexable_par_google": "google_index",
}


# --------------------------------------------------------------------------- #
#  Médiathèque — lecture seule
# --------------------------------------------------------------------------- #
class ListeDesImages(VueAgent):
    """
    Les images disponibles, avec leur identifiant.

    Sans ce point d'entrée, un agent pouvait poser un bloc image ou une image
    de fond sans jamais savoir QUELLE image choisir : les champs attendent un
    identifiant, et rien ne le lui donnait. Il devait deviner un nombre, ou
    renoncer.

    **Lecture seule, et c'est définitif.** Le téléversement passe par
    l'administration, où s'appliquent les validateurs de S-10 : plafond de
    poids et garde contre les bombes de décompression. Un agent qui pousserait
    des octets contournerait les deux.
    """

    permission_requise = LIRE

    #: Au-delà, on pagine. Une médiathèque de plusieurs milliers d'images ne
    #: doit pas produire une réponse que personne ne peut lire.
    PAR_PAGE = 100

    def get(self, request):
        images = ImageContent.objects.order_by("-id")

        try:
            depuis = int(request.GET.get("apres") or 0)
        except (TypeError, ValueError):
            raise CorpsInvalide("« apres » doit être un identifiant.")
        if depuis:
            images = images.filter(id__lt=depuis)

        lot = list(images[:self.PAR_PAGE])
        return ok({
            "images": [
                {
                    "id": i.id,
                    "alt": i.alt or "",
                    "url": i.original_image.url if i.original_image else "",
                    "apercu": i.mobile_size.url if i.mobile_size else "",
                    "ajoutee_le": i.created_at.isoformat() if i.created_at else None,
                }
                for i in lot
            ],
            "suite": lot[-1].id if len(lot) == self.PAR_PAGE else None,
        })


# --------------------------------------------------------------------------- #
#  Pages
# --------------------------------------------------------------------------- #
class ListeDesPages(VueAgent):
    permission_requise = LIRE

    def get(self, request):
        pages = Page.objects.all().order_by("title")
        return ok({"pages": [_page_en_resume(p) for p in pages]})


class CreationDePage(VueAgent):
    permission_requise = CREER

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)

        titre = str(corps.get("titre") or "").strip()
        if not titre:
            raise CorpsInvalide("Un « titre » est obligatoire.")

        url_tag = str(corps.get("url_tag") or "").strip() or slugify(titre)
        if Page.objects.filter(url_tag=url_tag).exists():
            return erreur(
                f"Une page utilise déjà l'adresse « {url_tag} ».",
                statut=409,
                url_tag=url_tag,
            )

        page = Page.objects.create(
            title=titre[:200],
            url_tag=url_tag[:200],
            # Une page créée par un agent naît en BROUILLON, toujours.
            # La mise en ligne est une décision éditoriale : elle reste un geste
            # humain, ou un appel explicite et séparé.
            active=False,
        )
        return ok({"page": _page_en_resume(page)}, statut=201)


class DetailPage(VueAgent):
    permission_requise = LIRE

    def get(self, request, page_id):
        page = get_object_or_404(
            Page.objects.prefetch_related("sections__lines__blocs"), id=page_id
        )
        return ok({
            "page": _page_en_resume(page),
            "sections": [
                _section_en_dict(s)
                for s in page.sections.all().order_by("position", "id")
            ],
        })

    def patch(self, request, page_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification de page non autorisée.", statut=403)

        page = get_object_or_404(Page, id=page_id)
        corps = self.corps(request)

        modifies = []
        for cle_api, champ in CHAMPS_PAGE_MODIFIABLES.items():
            if cle_api not in corps:
                continue
            valeur = corps[cle_api]
            if champ in ("title", "url_tag"):
                valeur = str(valeur).strip()[:200]
                if not valeur:
                    raise CorpsInvalide(f"« {cle_api} » ne peut pas être vide.")
            if champ == "url_tag" and Page.objects.filter(
                url_tag=valeur
            ).exclude(id=page.id).exists():
                return erreur(
                    f"Une autre page utilise déjà l'adresse « {valeur} ».", statut=409
                )
            setattr(page, champ, valeur)
            modifies.append(champ)

        if modifies:
            page.save(update_fields=modifies)

        if "metadonnees" in corps:
            modifies += _appliquer_metadonnees(page, corps["metadonnees"])

        return ok({"page": _page_en_resume(page), "modifies": modifies})


def _appliquer_metadonnees(page, donnees):
    """
    Le titre et la description des résultats de recherche.

    Ils vivent dans un modèle à part (`Metadata`), lié en un-à-un et absent
    tant qu'on ne l'a pas créé. Sans ce point d'entrée, une page construite par
    un agent sortait sans description : Google reprend alors un morceau du
    corps, souvent mal choisi.
    """
    from jeiko.administration_pages.models import Metadata

    if not isinstance(donnees, dict):
        raise CorpsInvalide("« metadonnees » doit être un objet.")

    meta, _ = Metadata.objects.get_or_create(page=page)
    modifies = []
    if "titre" in donnees:
        meta.title = str(donnees["titre"])[:200]
        modifies.append("title")
    if "description" in donnees:
        meta.description = str(donnees["description"])
        modifies.append("description")
    if modifies:
        meta.save(update_fields=modifies)
    return [f"metadonnees.{c}" for c in modifies]


# --------------------------------------------------------------------------- #
#  Sections, lignes, blocs
# --------------------------------------------------------------------------- #
class SectionsDeLaPage(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, page_id):
        page = get_object_or_404(Page, id=page_id)
        corps = self.corps(request, obligatoire=False)
        gabarit = str(corps.get("gabarit") or "CLASSIC").upper()

        try:
            section = fabrique.creer_section(page, gabarit=gabarit)
        except ValueError as souci:
            raise CorpsInvalide(str(souci))

        return ok({"section": _section_en_dict(section)}, statut=201)


class DetailSection(VueAgent):
    permission_requise = MODIFIER

    def _section(self, section_id):
        return get_object_or_404(Section, id=section_id)

    def get(self, request, section_id):
        return ok({"section": _section_en_dict(self._section(section_id))})

    def patch(self, request, section_id):
        section = self._section(section_id)
        try:
            touches = parametres.appliquer(section, self.corps(request))
        except ParametreInvalide as souci:
            raise CorpsInvalide(str(souci))
        return ok({"section": _section_en_dict(section), "modifies": touches})

    def delete(self, request, section_id):
        section = self._section(section_id)
        section.delete()
        return ok({"supprime": True, "section_id": int(section_id)})


class LignesDeLaSection(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, section_id):
        section = get_object_or_404(Section, id=section_id)
        corps = self.corps(request, obligatoire=False)
        colonnes = corps.get("colonnes", 1)

        try:
            colonnes = int(colonnes)
        except (TypeError, ValueError):
            raise CorpsInvalide("« colonnes » doit être un nombre entier.")

        ligne = fabrique.creer_ligne(section, colonnes=colonnes)
        return ok({"ligne": _ligne_en_dict(ligne)}, statut=201)


class DetailLigne(VueAgent):
    permission_requise = MODIFIER

    def _ligne(self, ligne_id):
        return get_object_or_404(Line, id=ligne_id)

    def get(self, request, ligne_id):
        return ok({"ligne": _ligne_en_dict(self._ligne(ligne_id))})

    def patch(self, request, ligne_id):
        ligne = self._ligne(ligne_id)
        try:
            touches = parametres.appliquer(ligne, self.corps(request))
        except ParametreInvalide as souci:
            raise CorpsInvalide(str(souci))
        return ok({"ligne": _ligne_en_dict(ligne), "modifies": touches})

    def delete(self, request, ligne_id):
        self._ligne(ligne_id).delete()
        return ok({"supprime": True, "ligne_id": int(ligne_id)})


class BlocsDeLaLigne(VueAgent):
    permission_requise = MODIFIER

    def post(self, request, ligne_id):
        ligne = get_object_or_404(Line, id=ligne_id)
        corps = self.corps(request, obligatoire=False)

        try:
            colonne = int(corps.get("colonne", 0))
        except (TypeError, ValueError):
            raise CorpsInvalide("« colonne » doit être un nombre entier.")

        if colonne < 0 or colonne >= max(1, ligne.columns_number or 1):
            raise CorpsInvalide(
                f"Cette ligne a {ligne.columns_number} colonne(s) : "
                f"« colonne » doit être entre 0 et {max(0, (ligne.columns_number or 1) - 1)}."
            )

        bloc = fabrique.creer_bloc(ligne, colonne=colonne)
        return ok({"bloc": _bloc_en_dict(bloc)}, statut=201)


class DetailBloc(VueAgent):
    permission_requise = MODIFIER

    def _bloc(self, bloc_id):
        return get_object_or_404(Bloc, id=bloc_id)

    def get(self, request, bloc_id):
        return ok({"bloc": _bloc_en_dict(self._bloc(bloc_id))})

    def patch(self, request, bloc_id):
        bloc = self._bloc(bloc_id)
        try:
            touches = parametres.appliquer(bloc, self.corps(request))
        except ParametreInvalide as souci:
            raise CorpsInvalide(str(souci))
        return ok({"bloc": _bloc_en_dict(bloc), "modifies": touches})

    def delete(self, request, bloc_id):
        self._bloc(bloc_id).delete()
        return ok({"supprime": True, "bloc_id": int(bloc_id)})


# --------------------------------------------------------------------------- #
#  Déplacement
# --------------------------------------------------------------------------- #
#: Comment retrouver les voisins d'un élément, par niveau.
#:
#: Un bloc se déplace dans SA colonne : deux blocs de colonnes différentes sont
#: côte à côte, pas l'un au-dessus de l'autre. C'est pourquoi il a son propre
#: champ d'ordre — `position` désigne la colonne, `position_in_column` le rang.
FRATRIES = {
    "section": (Section, lambda e: {"page_id": e.page_id}, "position"),
    "ligne": (Line, lambda e: {"section_id": e.section_id}, "position"),
    "bloc": (Bloc, lambda e: {"line_id": e.line_id, "position": e.position},
             "position_in_column"),
}


def _deplacer(element, niveau, sens):
    """
    Échange l'élément avec son voisin. Retourne `True` si quelque chose a bougé.

    On échange plutôt qu'on ne renumérote : c'est ce que fait l'éditeur, et
    cela laisse les positions des autres intactes — donc aucune surprise pour
    quelqu'un qui regarde la page pendant qu'un agent la réorganise.
    """
    modele, fratrie, champ = FRATRIES[niveau]
    actuelle = getattr(element, champ)
    if actuelle is None:
        actuelle = 0

    comparaison = "lt" if sens == "haut" else "gt"
    ordre = f"-{champ}" if sens == "haut" else champ

    voisin = (
        modele.objects.filter(**fratrie(element), **{f"{champ}__{comparaison}": actuelle})
        .order_by(ordre)
        .first()
    )
    if voisin is None:
        return False

    setattr(element, champ, getattr(voisin, champ))
    setattr(voisin, champ, actuelle)
    element.save(update_fields=[champ])
    voisin.save(update_fields=[champ])
    return True


class Deplacement(VueAgent):
    """
    Monter ou descendre une section, une ligne ou un bloc.

    Sans ce point d'entrée, un agent ne pouvait qu'**ajouter à la fin** : pour
    insérer une section en deuxième position, il fallait tout reconstruire.
    Les vues de l'éditeur le faisaient déjà ; la logique est reprise ici sur
    les trois niveaux d'un seul tenant, plutôt que recopiée six fois.

    `position` n'est pas modifiable par `PATCH` — et c'est délibéré : l'écrire
    à la main produirait deux éléments au même rang, donc un ordre d'affichage
    arbitraire. On passe par ici, qui renumérote les deux côtés.
    """

    permission_requise = MODIFIER

    def post(self, request, niveau, element_id):
        if niveau not in FRATRIES:
            raise CorpsInvalide(
                f"Niveau « {niveau} » inconnu. Attendus : {', '.join(FRATRIES)}."
            )

        sens = str(self.corps(request, obligatoire=False).get("sens") or "").lower()
        if sens not in ("haut", "bas"):
            raise CorpsInvalide("« sens » doit valoir « haut » ou « bas ».")

        modele = FRATRIES[niveau][0]
        element = get_object_or_404(modele, id=element_id)
        bouge = _deplacer(element, niveau, sens)

        return ok({
            "deplace": bouge,
            "niveau": niveau,
            "id": element.id,
            # Faux n'est pas une erreur : c'est « il est déjà en bout de
            # course ». Le dire explicitement évite qu'un agent réessaie.
            "raison": "" if bouge else f"déjà en {'première' if sens == 'haut' else 'dernière'} position",
        })


# --------------------------------------------------------------------------- #
#  Contenu d'un bloc
# --------------------------------------------------------------------------- #
#: Les cinq types restants, chacun une poignée de champs sur un objet lié.
#: Décrits en données comme le reste : ajouter un champ ne demande pas
#: d'écrire du code, et l'oublier dans le guide devient impossible puisque
#: celui-ci lit cette table.
CONTENUS_SIMPLES = {
    "TEXT_QUESTIONNAIRE": ("content_text_questionnaire", "ContentTextQuestionnaire", {
        "texte": "raw_text",
    }),
    "CHART": ("content_chart", "ContentChartQuestionnaire", {
        "titre": "title", "description": "description", "type_de_graphique": "chart_type",
        "axe_principal": "main_axis", "options": "options_json",
    }),
    "CALENDAR": ("content_calendar", "ContentCalendar", {
        "titre": "title",
    }),
    "DYN_RESOURCE_CAROUSEL": ("content_resource_config", "DynResourceConfig", {
        "source": "source_type", "limite": "limit", "intervalle": "interval",
        "colonnes_ordinateur": "columns_computer", "colonnes_portable": "columns_laptop",
        "colonnes_tablette": "columns_tablet", "colonnes_telephone": "columns_phone",
        "libelle_bouton": "button_label", "libelle_voir_plus": "load_more_label",
    }),
    "DYN_RESOURCE_GRID": ("content_resource_config", "DynResourceConfig", {
        "source": "source_type", "limite": "limit",
        "colonnes_ordinateur": "columns_computer", "colonnes_portable": "columns_laptop",
        "colonnes_tablette": "columns_tablet", "colonnes_telephone": "columns_phone",
        "libelle_bouton": "button_label", "libelle_voir_plus": "load_more_label",
    }),
}


def _modele_simple(nom):
    from jeiko.administration_pages import models as M
    return getattr(M, nom)


def _lire_contenu_simple(content):
    lien, _, correspondances = CONTENUS_SIMPLES[content.content_type]
    objet = getattr(content, lien, None)
    if objet is None:
        return {}
    return {cle: getattr(objet, champ) for cle, champ in correspondances.items()}


def _appliquer_contenu_simple(content, type_demande, donnees):
    lien, nom_modele, correspondances = CONTENUS_SIMPLES[type_demande]
    objet = getattr(content, lien, None)
    if objet is None:
        objet = _modele_simple(nom_modele).objects.create()
        setattr(content, lien, objet)

    if not isinstance(donnees, dict):
        raise CorpsInvalide(f"« {type_demande.lower()} » doit être un objet.")

    inconnus = sorted(set(donnees) - set(correspondances))
    if inconnus:
        raise CorpsInvalide(
            f"Clé(s) inconnue(s) : {', '.join(inconnus)}. "
            f"Acceptées pour {type_demande} : {', '.join(sorted(correspondances))}."
        )

    modifies = []
    for cle, valeur in donnees.items():
        setattr(objet, correspondances[cle], valeur)
        modifies.append(correspondances[cle])
    if modifies:
        objet.save(update_fields=modifies)
    return modifies


#: La vidéo. `source` dit d'où elle vient : un fichier hébergé, une URL
#: externe (YouTube, Vimeo…). L'API ne pose pas de fichier — elle renseigne
#: une URL ou réutilise ce qui est déjà là.
CHAMPS_VIDEO = {
    "source": "source", "fournisseur": "provider", "url": "url",
    "titre": "title", "ratio": "aspect_ratio", "controles": "controls",
    "lecture_auto": "autoplay", "muet": "muted", "boucle": "loop",
    "debut": "start_time", "fin": "end_time", "aria_label": "aria_label",
}


#: Types de champ d'un formulaire, tels que le modèle les accepte.
TYPES_DE_CHAMP = ("text", "email", "phone", "textarea", "select",
                  "checkbox", "date", "number")

#: Réglages du formulaire lui-même.
CHAMPS_FORMULAIRE = {
    "nom": "name",
    "description": "description",
    "destinataire": "to_email",
    "expediteur": "from_email",
    "sujet": "mail_subject",
    "message_de_succes": "success_message",
}


def _formulaire_en_dict(formulaire):
    return {
        "nom": formulaire.name,
        "destinataire": formulaire.to_email or "",
        "sujet": formulaire.mail_subject or "",
        "message_de_succes": formulaire.success_message or "",
        "champs": [
            {
                "nom": c.name, "libelle": c.label, "type": c.type,
                "obligatoire": c.required, "indication": c.placeholder or "",
                "options": c.options or [],
            }
            for c in formulaire.fields.all().order_by("order", "id")
        ],
    }


def _appliquer_formulaire(formulaire, donnees):
    """
    Écrit un formulaire et ses champs.

    Les champs sont REMPLACÉS quand la clé « champs » est présente : un
    formulaire est un tout, et fusionner deux listes par position produirait
    des mélanges silencieux — un libellé sur le mauvais champ, un « email »
    devenu « texte ». Ne pas envoyer « champs » laisse les existants intacts.
    """
    if not isinstance(donnees, dict):
        raise CorpsInvalide("« formulaire » doit être un objet.")

    modifies = []
    for cle, champ in CHAMPS_FORMULAIRE.items():
        if cle in donnees:
            setattr(formulaire, champ, str(donnees[cle] or "")[:500])
            modifies.append(champ)
    if modifies:
        formulaire.save(update_fields=modifies)

    if "champs" not in donnees:
        return modifies

    champs = donnees["champs"]
    if not isinstance(champs, list):
        raise CorpsInvalide("« formulaire.champs » doit être une liste.")

    for rang, brut in enumerate(champs):
        if not isinstance(brut, dict):
            raise CorpsInvalide("Chaque champ doit être un objet.")
        type_champ = str(brut.get("type") or "text")
        if type_champ not in TYPES_DE_CHAMP:
            raise CorpsInvalide(
                f"Type de champ « {type_champ} » inconnu. "
                f"Acceptés : {', '.join(TYPES_DE_CHAMP)}."
            )
        nom = str(brut.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide(
                "Chaque champ a besoin d'un « nom » : c'est lui qui sert de "
                "clé dans le message reçu."
            )

    formulaire.fields.all().delete()
    for rang, brut in enumerate(champs):
        ContentFormField.objects.create(
            formulaire=formulaire,
            name=str(brut["nom"])[:100],
            label=str(brut.get("libelle") or brut["nom"])[:200],
            type=str(brut.get("type") or "text"),
            placeholder=str(brut.get("indication") or "")[:200],
            required=bool(brut.get("obligatoire", False)),
            options=brut.get("options") or [],
            order=rang,
        )
    return modifies + ["champs"]


#: Correspondance entre le vocabulaire de l'API et les champs de
#: `ContentButton`. Le modèle n'a **pas** de champ `url` : il a une destination
#: par nature (page interne, URL externe, questionnaire, objet, produit).
#:
#: L'API écrivait auparavant `bouton.url` derrière un `hasattr` : le champ
#: n'existant pas, l'URL était **perdue en silence** — le bouton s'affichait,
#: ne menait nulle part, et rien ne le signalait. C'est le pire cas d'erreur :
#: celui qu'on ne voit qu'en cliquant.
CHAMPS_BOUTON = {
    "libelle": "label",
    "url_externe": "external_url",
    "questionnaire": "test_slug",
    "nouvel_onglet": "open_in_new_tab",
    "ajouter_au_panier": "is_add_to_cart",
    "cle_dynamique": "dynamic_key",
    "aria_label": "aria_label",
}

#: La palette du bouton. Elle existe dans le modèle et n'était pas exposée :
#: un agent ne pouvait donc pas donner à un bouton la couleur du site.
STYLE_BOUTON = {
    "fond": "background_color",
    "couleur_texte": "text_color",
    "couleur_bordure": "border_color",
    "fond_survol": "hover_background_color",
    "couleur_texte_survol": "hover_text_color",
    "couleur_bordure_survol": "hover_border_color",
    "rayon": "border_radius",
    "epaisseur_bordure": "border_width",
    "padding": "padding",
    "largeur": "width",
    "hauteur": "height",
    "taille_police": "font_size",
    "graisse": "font_weight",
    "ombre": "box_shadow",
}


def _appliquer_bouton(bouton, donnees):
    """Écrit un bouton : destination, libellé, apparence."""
    if not isinstance(donnees, dict):
        raise CorpsInvalide("« bouton » doit être un objet.")

    modifies = []

    for cle, champ in CHAMPS_BOUTON.items():
        if cle not in donnees:
            continue
        valeur = donnees[cle]
        if champ in ("open_in_new_tab", "is_add_to_cart"):
            valeur = bool(valeur)
        else:
            valeur = str(valeur or "")[:500]
        setattr(bouton, champ, valeur)
        modifies.append(champ)

    if "page_id" in donnees:
        identifiant = donnees["page_id"]
        if identifiant in (None, "", 0):
            bouton.page_target = None
        else:
            page = Page.objects.filter(pk=identifiant).first()
            if page is None:
                raise CorpsInvalide(f"Bouton : page nº {identifiant} inconnue.")
            bouton.page_target = page
        modifies.append("page_target")

    style = donnees.get("style")
    if style is not None:
        if not isinstance(style, dict):
            raise CorpsInvalide("« bouton.style » doit être un objet.")
        inconnus = sorted(set(style) - set(STYLE_BOUTON))
        if inconnus:
            raise CorpsInvalide(
                f"Style de bouton inconnu : {', '.join(inconnus)}. "
                f"Acceptés : {', '.join(sorted(STYLE_BOUTON))}."
            )
        for cle, valeur in style.items():
            setattr(bouton, STYLE_BOUTON[cle], str(valeur)[:100])
            modifies.append(STYLE_BOUTON[cle])

    if modifies:
        bouton.save(update_fields=sorted(set(modifies)))
    return modifies


#: Types qu'un agent peut poser et remplir par l'API.
#:
#: Les vingt autres existent et se voient en lecture, mais chacun a sa propre
#: forme et ses propres objets liés : les ouvrir tous d'un coup, sans les
#: éprouver un par un, produirait une API qui prétend savoir faire ce qu'elle
#: ne sait pas. On ouvre au fil des besoins réels.
TYPES_OUVERTS = tuple(sorted(set(
    ["TEXT", "BUTTON", "IMAGE", "FORM", "VIDEO"]
    + list(contenus_dynamiques.TYPES)
    + list(contenus_dynamiques.TYPES_SANS_ELEMENTS)
    + list(CONTENUS_SIMPLES)
)))


class ContenuDuBloc(VueAgent):
    permission_requise = MODIFIER

    @transaction.atomic
    def put(self, request, bloc_id):
        bloc = get_object_or_404(Bloc, id=bloc_id)
        corps = self.corps(request)

        type_demande = str(corps.get("type") or "").upper()
        if type_demande not in TYPES_OUVERTS:
            raise CorpsInvalide(
                f"Type « {type_demande or 'absent'} » non modifiable par l'API. "
                f"Ouverts : {', '.join(TYPES_OUVERTS)}."
            )

        content, _ = Content.objects.get_or_create(bloc=bloc)

        if type_demande == "TEXT":
            if content.content_text is None:
                content.content_text = ContentText.objects.create(text="")
            if "texte" in corps:
                content.content_text.text = str(corps["texte"])
                content.content_text.save(update_fields=["text"])

        elif type_demande == "BUTTON":
            if content.content_button is None:
                content.content_button = ContentButton.objects.create(
                    label="Cliquez ici"
                )
            _appliquer_bouton(content.content_button, corps.get("bouton") or {})

        elif type_demande == "FORM":
            if content.content_formulaire is None:
                content.content_formulaire = ContentFormulaire.objects.create(
                    name="Formulaire",
                    mail_subject="Nouveau message reçu",
                    success_message="Merci, votre message a bien été envoyé.",
                )
            _appliquer_formulaire(content.content_formulaire, corps.get("formulaire") or {})

        elif type_demande == "VIDEO":
            if content.content_video is None:
                content.content_video = ContentVideo.objects.create(
                    source=ContentVideo.Source.EXTERNAL
                )
            video = corps.get("video") or {}
            if not isinstance(video, dict):
                raise CorpsInvalide("« video » doit être un objet.")
            inconnus = sorted(set(video) - set(CHAMPS_VIDEO))
            if inconnus:
                raise CorpsInvalide(
                    f"Clé(s) de vidéo inconnue(s) : {', '.join(inconnus)}. "
                    f"Acceptées : {', '.join(sorted(CHAMPS_VIDEO))}."
                )
            modifies = []
            for cle, valeur in video.items():
                setattr(content.content_video, CHAMPS_VIDEO[cle], valeur)
                modifies.append(CHAMPS_VIDEO[cle])
            if modifies:
                content.content_video.save(update_fields=modifies)

        elif type_demande in CONTENUS_SIMPLES:
            _appliquer_contenu_simple(
                content, type_demande, corps.get(type_demande.lower()) or {}
            )
            # Ces deux-là sont AUSSI des blocs dynamiques : leur configuration
            # vit dans un objet lié, mais leurs options restent dans `data`.
            if contenus_dynamiques.est_dynamique(type_demande):
                content.content_type = type_demande
                content.save(update_fields=["content_type"])
                try:
                    contenus_dynamiques.appliquer(content, corps)
                except ElementInvalide as souci:
                    raise CorpsInvalide(str(souci))

        elif contenus_dynamiques.est_dynamique(type_demande):
            # Le type doit être posé AVANT d'écrire : `contenus_dynamiques`
            # choisit le modèle d'élément d'après `content.content_type`.
            content.content_type = type_demande
            content.save(update_fields=["content_type"])
            try:
                contenus_dynamiques.appliquer(content, corps)
            except ElementInvalide as souci:
                raise CorpsInvalide(str(souci))

        elif type_demande == "IMAGE":
            # On ne crée que le réceptacle : le téléversement du fichier passe
            # par l'écran d'administration, où les validateurs de S-10
            # s'appliquent. Un agent qui pousserait des octets contournerait
            # le plafond de taille et le garde anti-bombe de décompression.
            if content.content_image is None:
                content.content_image = ContentImage.objects.create(
                    image_content=ImageContent.objects.create()
                )

        content.content_type = type_demande
        content.save()

        return ok({"bloc": _bloc_en_dict(bloc)})
