# jeiko/agents/contenus_dynamiques.py
"""
Les blocs dynamiques — FAQ, onglets, carrousel, tarifs… — en un seul mécanisme.

Ce qu'ils ont tous en commun
----------------------------
Un bloc dynamique, c'est **une liste ordonnée d'éléments** rattachés au
`Content`, plus des options rangées dans `Content.data`. Une FAQ a des
questions, un carrousel a des diapositives, une table de prix a des offres :
même forme, noms différents.

Les ouvrir un par un aurait produit vingt fonctions se ressemblant à 90 %, et
la vingt-et-unième aurait divergé. On décrit donc chaque type en **données** —
son modèle d'élément, ses champs, son vocabulaire français — et un seul couple
lire/écrire les sert tous.

La règle d'écriture, la même partout
------------------------------------
Envoyer « elements » **remplace** la liste entière. C'est le choix fait pour le
formulaire, et pour la même raison : une liste ordonnée n'a pas de clé stable
sur laquelle fusionner. Rapprocher deux listes par position mélangerait les
contenus — une réponse sous la mauvaise question — sans rien signaler.

Ne pas envoyer « elements » laisse les existants intacts : on peut donc changer
les seules options.

Ce que ce module ne fait pas
----------------------------
Il ne valide pas la cohérence métier d'un bloc : une table de prix sans offre
est acceptée, un carrousel sans image aussi. Ce sont des états transitoires
légitimes quand on construit une page en plusieurs appels.
"""

from django.db import transaction

from jeiko.administration_pages import models as M


class ElementInvalide(Exception):
    """Le document d'un bloc dynamique n'est pas exploitable."""


#: Description d'un type dynamique :
#:   (modèle de l'élément, related_name sur Content, {clé API: champ modèle})
#:
#: Le vocabulaire est en français côté API, comme partout ailleurs : c'est
#: l'exploitant qui lira ces documents quand une page n'aura pas l'air de ce
#: qu'il attendait.
TYPES = {
    "DYN_FAQ": (M.DynFAQItem, "faq_items", {
        "question": "title", "reponse": "answer", "ouvert": "open",
    }),
    "DYN_TABS": (M.DynTabItem, "tab_items", {
        "libelle": "label", "contenu": "body",
    }),
    "DYN_CAROUSEL": (M.DynCarouselSlide, "carousel_slides", {
        "image_id": "image", "source_externe": "external_src", "alt": "alt",
        "legende": "caption", "lien": "href", "nouvel_onglet": "open_in_new_tab",
        "cadrage": "object_position",
    }),
    "DYN_PROGRESS": (M.DynProgressStep, "progress_steps", {
        "libelle": "label", "fait": "done",
    }),
    "DYN_TESTIMONIALS": (M.DynTestimonialItem, "testimonial_items", {
        "citation": "quote", "auteur": "author", "role": "role", "avatar_id": "avatar",
    }),
    "DYN_TESTIMONIALS_GRID": (M.DynTestimonialItem, "testimonial_items", {
        "citation": "quote", "auteur": "author", "role": "role", "avatar_id": "avatar",
    }),
    "DYN_FILTER": (M.DynLiveFilterItem, "live_filter_items", {
        "titre": "title", "categorie": "category", "description": "description",
    }),
    "DYN_ACCORDION_ADV": (M.DynAccordionSection, "accordion_sections", {
        "titre": "title", "ouvert": "open",
    }),
    "DYN_PRICING_TABLE": (M.DynPricingPlan, "pricing_plans", {
        "nom": "name", "prix_mensuel": "price_monthly", "prix_annuel": "price_yearly",
        "mis_en_avant": "popular", "libelle_bouton": "cta_label", "lien_bouton": "cta_href",
    }),
    "DYN_GALLERY_FILTER": (M.DynGalleryItem, "gallery_items", {
        "image_id": "image", "categorie": "category", "titre": "title",
    }),
    "DYN_STEPPER": (M.DynStepperStep, "stepper_steps", {
        "titre": "title", "contenu": "body",
    }),
}

#: Types dynamiques SANS liste d'éléments : tout tient dans les options.
TYPES_SANS_ELEMENTS = ("DYN_COUNTDOWN", "DYN_COUNTDOWN_CTA", "DYN_RATING")

#: Les champs qui désignent une image : leur valeur d'API est un identifiant.
CHAMPS_IMAGE = {"image", "avatar"}


def est_dynamique(type_contenu):
    return type_contenu in TYPES or type_contenu in TYPES_SANS_ELEMENTS


def _elements_de(content, type_contenu):
    _, lien, _ = TYPES[type_contenu]
    return getattr(content, lien).all().order_by("order", "id")


def lire(content):
    """Les options et les éléments d'un bloc dynamique."""
    donnees = {"options": content.data or {}}

    if content.content_type in TYPES_SANS_ELEMENTS:
        return donnees

    _, _, correspondances = TYPES[content.content_type]
    donnees["elements"] = []
    for element in _elements_de(content, content.content_type):
        rendu = {}
        for cle, champ in correspondances.items():
            valeur = getattr(element, champ)
            if champ in CHAMPS_IMAGE:
                valeur = getattr(element, f"{champ}_id")
            rendu[cle] = valeur
        donnees["elements"].append(rendu)
    return donnees


@transaction.atomic
def appliquer(content, donnees):
    """
    Écrit les options, et remplace la liste d'éléments si elle est fournie.

    Renvoie la liste de ce qui a changé.
    """
    if not isinstance(donnees, dict):
        raise ElementInvalide("Le contenu dynamique doit être un objet.")

    touches = []

    options = donnees.get("options")
    if options is not None:
        if not isinstance(options, dict):
            raise ElementInvalide("« options » doit être un objet.")
        content.data = options
        content.save(update_fields=["data"])
        touches.append("options")

    if content.content_type in TYPES_SANS_ELEMENTS:
        if "elements" in donnees:
            raise ElementInvalide(
                f"« {content.content_type} » n'a pas d'éléments : tout se règle "
                f"dans « options »."
            )
        return touches

    if "elements" not in donnees:
        return touches

    elements = donnees["elements"]
    if not isinstance(elements, list):
        raise ElementInvalide("« elements » doit être une liste.")

    modele, lien, correspondances = TYPES[content.content_type]

    # On valide TOUT avant d'effacer quoi que ce soit : une liste à moitié
    # écrite parce que le troisième élément était mal formé serait pire que
    # le refus complet.
    prepares = []
    for rang, brut in enumerate(elements):
        if not isinstance(brut, dict):
            raise ElementInvalide(f"Élément nº {rang + 1} : un objet est attendu.")
        inconnus = sorted(set(brut) - set(correspondances))
        if inconnus:
            raise ElementInvalide(
                f"Élément nº {rang + 1} — clé(s) inconnue(s) : {', '.join(inconnus)}. "
                f"Acceptées pour {content.content_type} : "
                f"{', '.join(sorted(correspondances))}."
            )
        valeurs = {"content": content, "order": rang}
        for cle, valeur in brut.items():
            champ = correspondances[cle]
            if champ in CHAMPS_IMAGE:
                if valeur in (None, "", 0):
                    valeurs[champ] = None
                else:
                    image = M.ImageContent.objects.filter(pk=valeur).first()
                    if image is None:
                        raise ElementInvalide(
                            f"Élément nº {rang + 1} : aucune image nº {valeur} "
                            f"dans la médiathèque. Voir /images/."
                        )
                    valeurs[champ] = image
            else:
                valeurs[champ] = valeur
        prepares.append(valeurs)

    getattr(content, lien).all().delete()
    for valeurs in prepares:
        modele.objects.create(**valeurs)

    touches.append("elements")
    return touches
