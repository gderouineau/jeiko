# jeiko/administration_menu/forms.py

from django import forms
from jeiko.administration_menu.models import (
    Menu, MenuItem, MenuStyle,
    MenuPlace, MenuLayout, LAYOUTS_BY_PLACE
)
from jeiko.administration_pages.models import Page
from django.utils.translation import gettext_lazy as _
from jeiko.formulaires_par_langue import ChampsParLangueMixin




class MenuForm(ChampsParLangueMixin, forms.ModelForm):
    # MENU-01 : les textes de la barre d'infos et du pied de page, traduits
    # dans `Menu.traductions` ({"en": {"barre_texte": "…"}}).
    champ_json = "traductions"
    valeurs_traduites = (
        ("barre_texte", _("Texte de la barre d'infos")),
        ("pied_texte", _("Texte du pied de page")),
        ("pied_appel", _("Titre de l'appel à l'action")),
        ("pied_appel_detail", _("Sous-titre de l'appel à l'action")),
    )
    cles_d_adresse = ()
    longueur_max = 300

    # Layout (radio)
    layout = forms.ChoiceField(
        choices=Menu._meta.get_field('layout').choices,
        widget=forms.RadioSelect(attrs={"class": "form-check-input"}),
        label=_("Disposition (layout)"),
        required=True,
        help_text=_("Choisissez l’organisation du logo et des éléments du menu.")
    )

    # Style (facultatif)
    menu_style = forms.ModelChoiceField(
        queryset=MenuStyle.objects.all().order_by("name"),
        required=False,
        empty_label=_("(Aucun style — utiliser les valeurs par défaut)"),
        widget=forms.Select(attrs={"class": "form-select"}),
        label=_("Style visuel")
    )

    # ➕ Upload d’un NOUVEAU logo (optionnel)
    new_logo_full_size = forms.ImageField(
        required=False,
        label=_("Ajouter un nouveau logo (image source)"),
        help_text=_("Optionnel. Si fourni, un nouveau Logo sera créé et rattaché au menu (prioritaire sur le logo sélectionné).")
    )

    class Meta:
        model = Menu
        fields = ["name", "place", "layout", "menu_style", "logo", "is_default",
                  "new_logo_full_size",
                  "barre_infos", "barre_texte", "pied_texte", "pied_appel", "pied_appel_detail"]
        labels = {
            "name": _("Nom"),
            "place": _("Emplacement"),
            "logo": _("Logo (sélection d’un existant — optionnel)"),
            "is_default": _("Menu par défaut pour cet emplacement"),
        }
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "place": forms.Select(attrs={"class": "form-select"}),
            "logo": forms.Select(attrs={"class": "form-select"}),
            "barre_texte": forms.TextInput(attrs={"class": "form-control"}),
            "pied_texte": forms.TextInput(attrs={"class": "form-control"}),
            "pied_appel": forms.TextInput(attrs={"class": "form-control"}),
            "pied_appel_detail": forms.TextInput(attrs={"class": "form-control"}),
        }
        help_texts = {
            "place": _("MAIN = menu principal, FOOTER = menu de pied de page."),
            "logo": _("Laisser vide pour utiliser le logo du site (WebSite.logo), ou uploadez un nouveau logo ci-dessous."),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Restreindre les layouts selon l’emplacement choisi
        place_val = (
            self.data.get(self.add_prefix("place"))
            or getattr(self.instance, "place", None)
            or MenuPlace.NULL
        )
        allowed = {c.value for c in LAYOUTS_BY_PLACE.get(place_val, set())}
        all_choices = list(MenuLayout.choices)
        filtered = [(k, v) for (k, v) in all_choices if k in allowed]

        if filtered and place_val == MenuPlace.FOOTER:
            # Facultative : sans disposition, le pied de page d'avant (MENU-01).
            self.fields["layout"].choices = [("", _("Pied de page d'origine"))] + filtered
            self.fields["layout"].required = False
        elif filtered:
            self.fields["layout"].choices = filtered
            self.fields["layout"].required = True
        else:
            self.fields["layout"].choices = []
            self.fields["layout"].required = False
            self.fields["layout"].widget = forms.HiddenInput()
            self.fields["layout"].help_text = _("Aucun layout disponible pour cet emplacement.")

        # Ordonner la liste des logos existants (si le champ est présent)
        if "logo" in self.fields:
            try:
                from jeiko.administration.models import Logo  # import local pour éviter tout cycle
                self.fields["logo"].queryset = Logo.objects.all().order_by("-updated_at", "id")
            except Exception:
                # Si le modèle Logo n’est pas dispo (migration…), ne plante pas le form
                pass

    def clean(self):
        cleaned = super().clean()
        place = cleaned.get("place") or MenuPlace.NULL
        layout = cleaned.get("layout")

        allowed = {c.value for c in LAYOUTS_BY_PLACE.get(place, set())}
        if allowed:
            if not layout and place == MenuPlace.MAIN:
                self.add_error("layout", _("Un layout est requis pour cet emplacement."))
            elif not layout:
                cleaned["layout"] = None
            elif layout not in allowed:
                self.add_error("layout", _("Ce layout n'est pas autorisé pour cet emplacement."))
        else:
            cleaned["layout"] = None

        # Rien à interdire si logo sélectionné + nouveau upload en même temps :
        # on documente que l’upload est prioritaire, et on applique ça en save().
        return cleaned

    def save(self, commit=True):
        """
        - Sauvegarde le Menu.
        - Si `new_logo_full_size` est fourni, crée un Logo, le sauvegarde (variants auto),
          et l’associe au menu (prioritaire sur le champ `logo`).
        """
        instance: Menu = super().save(commit=False)

        uploaded = self.cleaned_data.get("new_logo_full_size")
        if uploaded:
            # Création et assignation d’un NOUVEAU logo
            from jeiko.administration.models import Logo  # import local anti-cycle
            new_logo = Logo(full_size=uploaded)
            # 1er save => a un pk + déclenchera la génération des variantes lors du 2e save dans Logo.save()
            new_logo.save()
            instance.logo = new_logo

        if commit:
            instance.save()

        return instance




class MenuItemForm(ChampsParLangueMixin, forms.ModelForm):
    champ_json = "titres"
    valeurs_traduites = (("", _("Titre")),)

    # Les pages d'origine seulement : une entrée désigne LA page, et son lien
    # mène à la version que lit le visiteur (jeiko/langues_du_site.py).
    page = forms.ModelChoiceField(
        queryset=Page.objects.filter(traduction_de__isnull=True),
        required=False,
        label=_("Page (optionnel)"),
    )

    class Meta:
        model = MenuItem
        fields = ["title", "active", "page", "lien", "bouton"]
        labels = {
            "lien": _("Ou une adresse"),
            "bouton": _("Afficher en bouton"),
        }
        help_texts = {
            "lien": _("Si aucune page n'est choisie : /contact/, https://…, tel:…, mailto:…"),
            "bouton": _("Un bouton d'action (« Réserver ») : à droite du menu, et dans les pieds de page qui en ont un."),
        }
        widgets = {
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "lien": forms.TextInput(attrs={"class": "form-control", "placeholder": "https://"}),
            "active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def clean(self):
        cleaned = super().clean()
        # Ici, pas de validation cross-field sur menu/main_menu,
        # c’est le modèle (clean()) + la view qui garantissent la cohérence.
        return cleaned



class MenuStyleForm(forms.ModelForm):
    class Meta:
        model = MenuStyle
        fields = [
            "background_color","text_color","hover_text_color","active_text_color",
            "submenu_background_color","submenu_border_color","submenu_hover_background_color",
            "font_family","font_weight","font_size_mobile","font_size_desktop","letter_spacing","uppercase",
            "menu_min_height","padding_y_mobile","padding_y_desktop","gap_desktop","gap_mobile",
            "logo_width_mobile","logo_width_desktop","logo_height_desktop",
            "border_bottom_width","border_bottom_color",
            "sticky","sticky_shadow","transitions_ms","rounded_submenu",
            "survol","forme","transparent_texte",
        ]
        widgets = {
            "background_color": forms.TextInput(attrs={"type":"color"}),
            "text_color": forms.TextInput(attrs={"type":"color"}),
            "hover_text_color": forms.TextInput(attrs={"type":"color"}),
            "active_text_color": forms.TextInput(attrs={"type":"color"}),
            "submenu_background_color": forms.TextInput(attrs={"type":"color"}),
            "submenu_border_color": forms.TextInput(attrs={"type":"color"}),
            "submenu_hover_background_color": forms.TextInput(attrs={"type":"color"}),
            "transparent_texte": forms.TextInput(attrs={"type":"color"}),
            "font_family": forms.TextInput(attrs={"placeholder": "ex: Inter, system-ui"}),
            "letter_spacing": forms.NumberInput(attrs={"step":"0.01"}),
        }
        labels = {"uppercase":_("Majuscules")}

    #: Montrés à part, dans « Options » ; le reste sous « Réglages fins ».
    CHAMPS_D_OPTIONS = ("survol", "forme", "transparent_texte")

    @property
    def champs_d_options(self):
        return [self[n] for n in self.CHAMPS_D_OPTIONS]

    @property
    def champs_fins(self):
        return [f for f in self if f.name not in self.CHAMPS_D_OPTIONS]
