# jeiko/administration_menu/styles_predefinis.py
"""
Les styles prêts du menu principal (MENU-01, 12/10/2026).

Le problème : un menu « pro » demandait de régler une trentaine de champs
(couleurs, tailles, espacements) et de deviner les bonnes combinaisons. Un style
prêt pose en un geste une disposition et un jeu de réglages cohérent, PRIS DANS
LES COULEURS DU THÈME (Réglages ▸ Thème) : le menu s'accorde au site au lieu de
lui imposer une palette. Les réglages fins restent modifiables ensuite.

Ce qu'il ne fait pas :
- il ne suit pas le thème après coup — les couleurs sont recopiées au moment
  de l'application (les champs de couleur sont des sélecteurs `#rrggbb`, une
  `var(--jk-…)` y serait effacée au premier enregistrement). Changer de thème,
  c'est réappliquer le style ;
- il ne touche ni aux pages (« Menu transparent sur cette page » se coche page
  par page), ni à la taille du logo, réglée pour CE logo ;
- il ne modifie jamais un style partagé : si d'autres menus utilisent le même
  `MenuStyle`, ce menu reçoit sa propre copie — sinon appliquer un style à un
  menu changerait l'apparence de menus qu'on ne visait pas.
"""
import re

from django.utils.translation import gettext_lazy as _

from .models import Menu, MenuLayout, MenuPlace, MenuStyle

#: Champs que le style prêt ne remet pas aux valeurs par défaut.
_INTOUCHABLES = {"id", "name", "updated_at", "logo_width_mobile", "logo_width_desktop", "logo_height_desktop"}

_DEFAUT_THEME = {
    "accent": "#b45309", "secondaire": "#1e3a44", "tertiaire": "#d9af7a",
    "texte": "#1c1917", "fond": "#ffffff", "bordure": "#e7e2db",
}


def _en_hexa(valeur, repli):
    """`rgb(180, 83, 9)` ou `#b45309` → `#b45309` ; sinon le repli."""
    valeur = (valeur or "").strip().lower()
    if re.fullmatch(r"#[0-9a-f]{6}", valeur):
        return valeur
    if re.fullmatch(r"#[0-9a-f]{3}", valeur):
        return "#" + "".join(c * 2 for c in valeur[1:])
    m = re.fullmatch(r"rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*[\d.]+\s*)?\)", valeur)
    if m and all(int(x) <= 255 for x in m.groups()):
        return "#" + "".join(f"{int(x):02x}" for x in m.groups())
    return repli


def couleurs_du_theme():
    from jeiko.administration.models import WebSite

    site = WebSite.objects.select_related("theme").first()
    theme = getattr(site, "theme", None)
    return {cle: _en_hexa(getattr(theme, cle, ""), repli) for cle, repli in _DEFAUT_THEME.items()}


def _reglages(cle, c):
    """Les valeurs d'un style, à partir des couleurs `c` du thème."""
    clair = {
        "background_color": c["fond"], "text_color": c["texte"],
        "hover_text_color": c["accent"], "active_text_color": c["accent"],
        "submenu_background_color": c["fond"], "submenu_border_color": c["bordure"],
        "border_bottom_color": c["bordure"], "font_weight": "500",
        "font_size_desktop": 15, "menu_min_height": 72, "gap_desktop": 28,
        "rounded_submenu": 12,
    }
    styles = {
        "epure": {**clair, "survol": MenuStyle.SURVOL_SOULIGNE, "border_bottom_width": 1},
        "flottant": {**clair, "survol": MenuStyle.SURVOL_PASTILLE, "forme": MenuStyle.FORME_FLOTTANTE,
                     "menu_min_height": 64, "gap_desktop": 6},
        "transparent": {**clair, "survol": MenuStyle.SURVOL_SOULIGNE, "transparent_texte": "#ffffff"},
        "sombre": {**clair, "background_color": c["secondaire"], "text_color": "#ffffff",
                   "hover_text_color": c["tertiaire"], "active_text_color": c["tertiaire"],
                   "submenu_background_color": c["secondaire"], "submenu_border_color": c["secondaire"],
                   "submenu_hover_background_color": c["secondaire"], "survol": MenuStyle.SURVOL_SOULIGNE},
        "centre": {**clair, "survol": MenuStyle.SURVOL_SOULIGNE, "uppercase": True, "letter_spacing": "0.12",
                   "font_size_desktop": 13, "gap_desktop": 36, "border_bottom_width": 1},
        "burger": {**clair, "menu_min_height": 76},
    }
    return styles[cle]


#: clé → (libellé, description, disposition). L'ordre est celui de l'écran.
STYLES = {
    "epure": (_("Épuré"), _("Fond clair, liens au centre, soulignement au survol."),
              MenuLayout.LOGO_LEFT_MENU_CENTER),
    "flottant": (_("Flottant"), _("Une capsule arrondie posée sur la page, qui reste en haut."),
                 MenuLayout.LOGO_LEFT_MENU_CENTER),
    "transparent": (_("Transparent"), _("Posé sur l'image de la première section, sur les pages où « Menu transparent » est coché."),
                    MenuLayout.LOGO_LEFT_MENU_CENTER),
    "sombre": (_("Sombre"), _("Fond de la couleur secondaire du thème, texte blanc."),
               MenuLayout.LOGO_LEFT_MENU_CENTER),
    "centre": (_("Centré élégant"), _("Logo centré, liens en petites capitales espacées."),
               MenuLayout.LOGO_CENTER_BELOW),
    "burger": (_("Burger"), _("Logo, bouton d'action et un menu plein écran, même sur ordinateur."),
               MenuLayout.LOGO_LEFT_BURGER),
}


def liste():
    return [{"cle": cle, "libelle": str(lib), "description": str(desc), "disposition": disp}
            for cle, (lib, desc, disp) in STYLES.items()]


def style_propre(menu: Menu, nom="") -> MenuStyle:
    """
    Le `MenuStyle` de ce menu SEUL, à modifier sans toucher aux autres menus.

    S'il est partagé (ou absent), une copie est créée — non enregistrée : à
    l'appelant de la modifier puis de l'enregistrer.
    """
    style = menu.menu_style
    if style is not None and not Menu.objects.filter(menu_style=style).exclude(pk=menu.pk).exists():
        return style
    copie = MenuStyle()
    if style is not None:
        for champ in MenuStyle._meta.concrete_fields:
            if champ.name not in ("id", "updated_at"):
                setattr(copie, champ.name, getattr(style, champ.name))
    copie.name = (nom or f"{menu.name} — {_('style propre')}")[:120]
    return copie


def appliquer(menu: Menu, cle: str) -> MenuStyle:
    """Pose la disposition et le style `cle` sur `menu` (menu principal seulement)."""
    if cle not in STYLES:
        raise ValueError(f"Style prêt inconnu : {cle}. Connus : {', '.join(STYLES)}.")
    if menu.place != MenuPlace.MAIN:
        raise ValueError("Les styles prêts valent pour le menu principal.")

    style = style_propre(menu, nom=f"{menu.name} — {STYLES[cle][0]}")
    for champ in MenuStyle._meta.concrete_fields:
        if champ.name not in _INTOUCHABLES:
            setattr(style, champ.name, champ.get_default())
    for champ, valeur in _reglages(cle, couleurs_du_theme()).items():
        setattr(style, champ, valeur)
    style.save()

    menu.menu_style = style
    menu.layout = STYLES[cle][2]
    menu.save()
    return style
