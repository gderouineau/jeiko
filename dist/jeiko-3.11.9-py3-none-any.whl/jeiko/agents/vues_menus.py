# jeiko/agents/vues_menus.py
"""
La construction des menus — la structure et les liens, pas le design.

Ce que permet cette surface
---------------------------
Un site JEIKO peut porter **plusieurs menus**, et les affecter par catégorie :
`Category.main_menu` et `Category.footer_menu`. C'est ce qui permet des
**sous-sites** — sur ateliersderouineau.com, « Électricité » et « Plomberie »
ont des menus identiques à l'œil et des liens différents.

Construire cela à la main veut dire recréer un menu entier, entrée par entrée,
pour chaque branche. D'où `copie_de` à la création : le nouveau menu naît avec
la même disposition et la même arborescence que son modèle, et il ne reste
qu'à réaffecter les pages. C'est exactement le geste décrit — « les mêmes
visuellement, les liens ne sont pas les mêmes ».

L'apparence (MENU-01, 12/10/2026)
---------------------------------
Longtemps fermée (« pas des designs »), elle s'ouvre à la demande de
l'exploitant — « tout cela doit être modifiable par l'API et le MCP » — mais
par des CHOIX, pas par trente champs de couleur :
- `disposition` (6 pour le menu principal, 8 pour le pied de page, facultative
  pour ce dernier) ;
- `style_pret` : un style complet pris dans les couleurs du thème
  (administration_menu/styles_predefinis.py) ;
- `apparence` : l'effet au survol, la forme, la couleur du texte sur le bandeau ;
- la barre d'infos et les textes du pied de page, et leurs traductions ;
- sur une entrée : `bouton` (plein, contour) et `lien` (une adresse au lieu
  d'une page).

Les réglages fins (27/10/2026) — « tout ce qui concerne les réglages du menu
et du logo, taille etc. : c'est un réglage essentiel » (Guillaume) :
- `style` : TOUS les champs de l'écran « Style du menu » (couleurs, police,
  tailles, espacements, LARGEUR ET HAUTEUR DU LOGO, bordure, sous-menus),
  sous leur nom d'écran et validés par son formulaire (`MenuStyleForm`) ;
- `logo` : un logo propre à ce menu (une image de la médiathèque), ou `null`
  pour reprendre celui du site.

Un style PARTAGÉ entre menus n'est jamais modifié : le menu visé en reçoit sa
propre copie (`styles_predefinis.style_propre`), sans quoi changer un menu
changerait l'apparence de menus qu'on ne visait pas. Même règle pour le logo :
un logo posé ici est toujours un logo NEUF, jamais celui qu'un autre menu (ou
le site) partage.

Ce qui n'est PAS ouvert, et pourquoi
-------------------------------------

**La suppression.** Un menu supprimé emporte ses entrées, et laisse sans menu
toutes les catégories et pages qui le désignaient — c'est-à-dire un site sans
navigation, sans qu'aucune page en particulier paraisse en cause.

La règle d'écriture des entrées
--------------------------------
Envoyer « elements » REMPLACE l'arborescence entière. Deux raisons, et la
seconde est technique : une liste ordonnée n'a pas de clé stable sur laquelle
fusionner ; et `MenuItem` porte deux contraintes d'unicité sur la position
(par menu pour le premier niveau, par parent pour les sous-entrées), qu'une
mise à jour partielle violerait dès qu'on insère au milieu.
"""

import re

from django.db import transaction
from django.shortcuts import get_object_or_404

from jeiko import langues_du_site

from jeiko.administration_menu import styles_predefinis
from jeiko.administration_menu.forms import MenuStyleForm
from jeiko.administration_menu.utils import get_menu_logo_urls
from jeiko.administration_menu.models import (
    LAYOUTS_BY_PLACE, Menu, MenuItem, MenuLayout, MenuPlace, MenuStyle, adresse_acceptee,
)
from jeiko.administration_pages.models import Category, Page

from .vues_api import CorpsInvalide, VueAgent, ecrire_par_formulaire, erreur, ok, valeurs_du_formulaire

VOIR = "administration_menu.view_menu"
AJOUTER = "administration_menu.add_menu"
MODIFIER = "administration_menu.change_menu"

#: Les textes d'un menu (barre d'infos, pied de page) : clé d'API → champ.
TEXTES_MENU = {
    "barre_texte": "barre_texte",
    "pied_texte": "pied_texte",
    "pied_appel": "pied_appel",
    "pied_appel_detail": "pied_appel_detail",
}
CLES_APPARENCE = {"survol", "forme", "texte_sur_bandeau", "collant"}

CLES_MENU = {
    "nom", "emplacement", "disposition", "par_defaut", "afficher_le_panier",
    "elements", "barre_infos", "traductions", "style_pret", "apparence",
    "style", "logo",
} | set(TEXTES_MENU)
CLES_ELEMENT = {"titre", "titres", "page", "lien", "bouton", "actif", "sous_elements"}
BOUTONS = [code for code, _ in MenuItem._meta.get_field("bouton").choices]

EMPLACEMENTS = [code for code, _ in MenuPlace.choices]
DISPOSITIONS = [code for code, _ in MenuLayout.choices]


# --------------------------------------------------------------------------- #
#  L'icône du panier
# --------------------------------------------------------------------------- #
#
# « afficher_le_panier » se lit et s'écrit ICI, sur un menu — c'est là qu'un
# agent le cherche —, mais c'est un réglage de la BOUTIQUE, le même pour tous
# les menus du site (`ShopSettings.show_cart`). Il vivait sur chaque menu ; un
# site à plusieurs menus devait le cocher partout. Le régler demande donc le
# droit sur les réglages de la boutique, pas seulement sur les menus — le même
# que l'écran Boutique › Réglages (`shop.views.admin.ShopSettingsUpdateView`),
# pour que l'API et l'administration disent la même chose.
REGLER_LA_BOUTIQUE = "shop.change_producttype"


def _le_panier_est_affiche():
    from jeiko.shop.models import ShopSettings

    return bool(ShopSettings.objects.filter(pk=1).values_list("show_cart", flat=True).first())


def _regler_le_panier(request, valeur):
    from jeiko.shop.models import ShopSettings

    if bool(valeur) == _le_panier_est_affiche():
        return False
    if not request.user.has_perm(REGLER_LA_BOUTIQUE):
        raise CorpsInvalide(
            "« afficher_le_panier » est un réglage de la boutique, commun à tous "
            "les menus : cet agent n'a pas le droit de le modifier "
            "(Boutique › Réglages, dans l'administration)."
        )
    reglages = ShopSettings.get_solo()
    reglages.show_cart = bool(valeur)
    reglages.save(update_fields=["show_cart"])
    return True


# --------------------------------------------------------------------------- #
#  Sérialisation
# --------------------------------------------------------------------------- #
def _element_en_dict(element):
    return {
        "id": element.id,
        "titre": element.title,
        # Le titre dans les autres langues du site : {"en": "Pricing"}. Une
        # langue absente affiche « titre ».
        "titres": element.titres or {},
        "page": element.page_id,
        # Sans page : l'adresse visée (/shop/, https://…, tel:…).
        "lien": element.lien,
        # "" (lien), "plein" ou "contour" : un bouton d'action.
        "bouton": element.bouton,
        "actif": element.active,
        "sous_elements": [
            _element_en_dict(sous)
            for sous in element.submenus.all().order_by("position", "id")
        ],
    }


def _menu_en_dict(menu, avec_elements=True):
    document = {
        "id": menu.id,
        "nom": menu.name,
        "emplacement": menu.place,
        "disposition": menu.layout,
        "par_defaut": menu.is_default,
        "afficher_le_panier": _le_panier_est_affiche(),
        "barre_infos": menu.barre_infos,
        **{cle: getattr(menu, champ) for cle, champ in TEXTES_MENU.items()},
        # Ces textes dans les autres langues : {"en": {"barre_texte": "…"}}.
        "traductions": menu.traductions or {},
        "apparence": _apparence(menu),
        "style": _style(menu),
        # `propre` : ce menu a son logo ; sinon il montre celui du site.
        "logo": {"propre": bool(menu.logo_id), "url": (get_menu_logo_urls(menu) or {}).get("full")},
        # Ce à quoi il est rattaché : c'est la question qu'on se pose en
        # arrivant sur un site à plusieurs menus, et y répondre demande
        # autrement de parcourir toutes les catégories.
        # Des objets, pas des slugs.
        #
        # Un slug de sous-catégorie n'est unique que sous SON parent : deux
        # univers peuvent légitimement avoir chacun leur « articles » et leur
        # « services ». La liste de slugs devenait alors indéchiffrable — on ne
        # savait pas quel « articles » ce menu servait, et il fallait deviner
        # par le parent. L'identifiant, lui, ne ment jamais.
        #
        # « categories » reste servie telle quelle : des appelants s'en
        # servent, et la retirer serait une rupture. Elle est simplement
        # doublée par une forme exploitable.
        "categories": sorted(
            c.slug or c.name
            for c in list(menu.categories_main_menu.all())
            + list(menu.categories_footer_menu.all())
        ),
        "categories_detail": [
            {
                "id": c.id,
                "slug": c.slug or "",
                "nom": c.name,
                "parent": getattr(c, "main_category_id", None),
                "rattachement": rattachement,
            }
            for rattachement, groupe in (
                ("principal", menu.categories_main_menu.all()),
                ("pied_de_page", menu.categories_footer_menu.all()),
            )
            for c in groupe
        ],
    }
    if avec_elements:
        document["elements"] = [
            _element_en_dict(e)
            for e in menu.menu_items.filter(main_menu__isnull=True)
                                    .prefetch_related("submenus")
                                    .order_by("position", "id")
        ]
    return document


def _apparence(menu):
    style = menu.menu_style
    return {
        "survol": getattr(style, "survol", ""),
        "forme": getattr(style, "forme", ""),
        "texte_sur_bandeau": getattr(style, "transparent_texte", "#ffffff"),
        "collant": bool(getattr(style, "sticky", False)),
    }


def _style(menu):
    """Les réglages fins, sous leurs noms d'écran ; ceux par défaut sans style."""
    return valeurs_du_formulaire(MenuStyleForm, menu.menu_style or MenuStyle())


# --------------------------------------------------------------------------- #
#  Aides
# --------------------------------------------------------------------------- #
def _verifier_la_disposition(emplacement, disposition):
    """
    Toutes les dispositions ne valent pas pour tous les emplacements.

    `LAYOUTS_BY_PLACE` le dit : le menu principal en exige une, le pied de page
    en accepte une (sans elle, le pied de page d'origine), un menu sans
    emplacement aucune. En poser une qui ne vaut pas produirait un menu qui ne
    se rend pas — encore une panne muette.
    """
    autorisees = LAYOUTS_BY_PLACE.get(emplacement, set())

    if not autorisees:
        # Cet emplacement n'accepte AUCUNE disposition — c'est le cas d'un
        # menu sans emplacement. Une contrainte de base le fait respecter, mais
        # par une `CheckViolation`, c'est-à-dire une 500 : un défaut de l'API
        # rendu comme une panne de serveur. On refuse proprement avant.
        if disposition:
            raise CorpsInvalide(
                f"L'emplacement « {emplacement} » n'accepte pas de "
                f"disposition — ne pas envoyer « disposition »."
            )
        return

    if not disposition and emplacement == MenuPlace.FOOTER:
        return  # le pied de page d'origine
    if disposition not in autorisees:
        raise CorpsInvalide(
            f"La disposition « {disposition} » ne vaut pas pour l'emplacement "
            f"« {emplacement} ». Acceptées : {', '.join(sorted(autorisees))}."
        )


def _ecrire_les_elements(menu, elements, parent=None, deja_vues=None):
    """
    Recrée l'arborescence d'un menu, en profondeur.

    Tout est validé avant le premier effacement : un menu à moitié réécrit,
    c'est une navigation amputée sur toutes les pages à la fois.
    """
    if not isinstance(elements, list):
        raise CorpsInvalide("« elements » doit être une liste.")

    prepares = _preparer_les_elements(elements)

    if parent is None:
        menu.menu_items.all().delete()
    _creer_les_elements(menu, prepares, parent=None)


def _preparer_les_elements(elements, chemin="elements"):
    """Valide récursivement, sans rien écrire."""
    prepares = []
    for rang, brut in enumerate(elements, 1):
        ou = f"{chemin}[{rang}]"
        if not isinstance(brut, dict):
            raise CorpsInvalide(f"{ou} : un objet est attendu.")

        inconnues = sorted(set(brut) - CLES_ELEMENT)
        if inconnues:
            raise CorpsInvalide(
                f"{ou} : clé(s) inconnue(s) — {', '.join(inconnues)}. "
                f"Acceptées : {', '.join(sorted(CLES_ELEMENT))}."
            )

        titre = str(brut.get("titre") or "").strip()
        if not titre:
            raise CorpsInvalide(f"{ou} : « titre » est obligatoire.")

        titres = brut.get("titres") or {}
        if not isinstance(titres, dict) or set(titres) - set(langues_du_site.codes_proposes()):
            raise CorpsInvalide(
                f"{ou} : « titres » est un objet par langue — "
                f"{{\"en\": \"Pricing\"}} — parmi "
                f"{', '.join(langues_du_site.codes_proposes())}."
            )
        titres = {c: str(t).strip()[:100] for c, t in titres.items() if str(t or "").strip()}

        page = None
        if brut.get("page"):
            page = Page.objects.filter(pk=brut["page"]).first()
            if page is None:
                raise CorpsInvalide(
                    f"{ou} : aucune page nº {brut['page']}. Une entrée qui "
                    f"pointe vers rien ne mène nulle part."
                )
            if page.traduction_de_id:
                raise CorpsInvalide(
                    f"{ou} : la page nº {page.id} est une version traduite. "
                    f"Une entrée désigne la page d'origine (nº "
                    f"{page.traduction_de_id}) : son lien mène de lui-même à "
                    f"la version que lit le visiteur."
                )

        lien = str(brut.get("lien") or "").strip()
        if page is not None and lien:
            raise CorpsInvalide(f"{ou} : « page » OU « lien », pas les deux.")
        if not adresse_acceptee(lien) or len(lien) > 500:
            raise CorpsInvalide(
                f"{ou} : « lien » commence par « / », « https:// », « tel: » ou "
                f"« mailto: » (500 caractères au plus)."
            )
        bouton = brut.get("bouton") or ""
        if bouton not in BOUTONS:
            raise CorpsInvalide(f"{ou} : « bouton » vaut {', '.join(repr(b) for b in BOUTONS)}.")

        prepares.append({
            "title": titre[:100],
            "titres": titres,
            "page": page,
            "lien": lien,
            "bouton": bouton,
            "active": bool(brut.get("actif", True)),
            "sous": _preparer_les_elements(
                brut.get("sous_elements") or [], f"{ou}.sous_elements"
            ),
        })
    return prepares


def _creer_les_elements(menu, prepares, parent):
    for position, valeurs in enumerate(prepares, 1):
        sous = valeurs.pop("sous")
        element = MenuItem.objects.create(
            menu=menu, main_menu=parent, position=position, **valeurs
        )
        valeurs["sous"] = sous  # on rend le dict intact à l'appelant
        if sous:
            _creer_les_elements(menu, sous, parent=element)


# --------------------------------------------------------------------------- #
#  Menus
# --------------------------------------------------------------------------- #
class ListeDesMenus(VueAgent):
    permission_requise = VOIR

    def get(self, request):
        menus = Menu.objects.prefetch_related(
            "menu_items__submenus", "categories_main_menu", "categories_footer_menu"
        ).order_by("place", "name")
        return ok({
            "menus": [_menu_en_dict(m) for m in menus],
            "emplacements": EMPLACEMENTS,
            "dispositions": DISPOSITIONS,
            "dispositions_par_emplacement": {
                place: sorted(LAYOUTS_BY_PLACE.get(place, ())) for place in EMPLACEMENTS
            },
            "styles_prets": styles_predefinis.liste(),
            "apparence_valeurs": {
                "survol": [c for c, _ in MenuStyle._meta.get_field("survol").choices],
                "forme": [c for c, _ in MenuStyle._meta.get_field("forme").choices],
            },
            "boutons": BOUTONS,
        })


class CreationMenu(VueAgent):
    """
    Crée un menu — éventuellement en COPIANT un existant.

    `copie_de` est le geste qui fait les sous-sites : le nouveau menu naît avec
    la disposition et l'arborescence de son modèle, et il ne reste qu'à
    réaffecter les pages. Sans lui, chaque branche d'un site se reconstruit
    entrée par entrée, et la moindre différence d'oubli se voit.
    """

    permission_requise = AJOUTER

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)
        inconnues = sorted(set(corps) - CLES_MENU - {"copie_de"})
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Acceptées : copie_de, {', '.join(sorted(CLES_MENU))}."
            )

        nom = str(corps.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide("« nom » est obligatoire.")

        modele = None
        if corps.get("copie_de"):
            modele = Menu.objects.filter(pk=corps["copie_de"]).first()
            if modele is None:
                raise CorpsInvalide(f"Aucun menu nº {corps['copie_de']} à copier.")

        emplacement = str(
            corps.get("emplacement") or (modele.place if modele else MenuPlace.MAIN)
        )
        if emplacement not in EMPLACEMENTS:
            raise CorpsInvalide(
                f"Emplacement « {emplacement} » inconnu. "
                f"Attendus : {', '.join(EMPLACEMENTS)}."
            )

        # Le défaut dépend de l'emplacement : le pied de page n'accepte
        # aucune disposition, imposer celle du menu principal le ferait
        # échouer sur une contrainte de base.
        # `None`, pas une chaîne vide : la contrainte
        # `menu_layout_required_for_main_only` exige `layout IS NULL` hors
        # menu principal, et `""` la viole aussi sûrement qu'une disposition.
        if emplacement == MenuPlace.MAIN:
            defaut = modele.layout if modele else MenuLayout.LOGO_LEFT_MENU_RIGHT
            disposition = corps.get("disposition") or defaut
        elif emplacement == MenuPlace.FOOTER:
            disposition = corps.get("disposition") or (modele.layout if modele else None)
        else:
            disposition = corps.get("disposition") or None
        _verifier_la_disposition(emplacement, disposition)

        menu = Menu.objects.create(
            name=nom[:150],
            place=emplacement,
            layout=disposition,
            # Jamais par défaut à la création : une contrainte n'autorise qu'un
            # seul menu par défaut et par emplacement, et le prendre d'office
            # débrancherait le menu en service sans qu'on l'ait demandé.
            is_default=False,
            menu_style=modele.menu_style if modele else None,
            logo=modele.logo if modele else None,
        )
        if "afficher_le_panier" in corps:
            _regler_le_panier(request, corps["afficher_le_panier"])
        if modele is not None:
            for champ in ("barre_infos", "traductions", *TEXTES_MENU.values()):
                setattr(menu, champ, getattr(modele, champ))
        _ecrire_l_apparence(menu, corps)
        menu.save()

        if "elements" in corps:
            _ecrire_les_elements(menu, corps["elements"])
        elif modele is not None:
            _copier_les_elements(modele, menu)

        return ok({"menu": _menu_en_dict(menu)}, statut=201)


def _ecrire_l_apparence(menu, corps):
    """
    Les textes, la barre d'infos, le style prêt et l'apparence d'un menu.
    Valide tout avant d'écrire ; rend la liste des champs touchés.
    """
    modifies = []
    for cle, champ in TEXTES_MENU.items():
        if cle in corps:
            limite = Menu._meta.get_field(champ).max_length
            setattr(menu, champ, str(corps[cle] or "").strip()[:limite])
            modifies.append(champ)
    if "barre_infos" in corps:
        menu.barre_infos = bool(corps["barre_infos"])
        modifies.append("barre_infos")
    if "traductions" in corps:
        menu.traductions = _traductions_valides(corps["traductions"])
        modifies.append("traductions")

    cle_style = corps.get("style_pret")
    if cle_style:
        if menu.place != MenuPlace.MAIN:
            raise CorpsInvalide("« style_pret » vaut pour un menu principal (emplacement MAIN).")
        if cle_style not in styles_predefinis.STYLES:
            raise CorpsInvalide(
                f"Style prêt « {cle_style} » inconnu. Connus : {', '.join(styles_predefinis.STYLES)}."
            )

    apparence = corps.get("apparence")
    if apparence is not None:
        if not isinstance(apparence, dict) or set(apparence) - CLES_APPARENCE:
            raise CorpsInvalide(
                f"« apparence » est un objet aux clés {', '.join(sorted(CLES_APPARENCE))}."
            )
        for cle, champ in (("survol", "survol"), ("forme", "forme")):
            permis = [c for c, _ in MenuStyle._meta.get_field(champ).choices]
            if cle in apparence and apparence[cle] not in permis:
                raise CorpsInvalide(f"« apparence.{cle} » vaut {', '.join(repr(c) for c in permis)}.")
        couleur = apparence.get("texte_sur_bandeau")
        if couleur is not None and not re.fullmatch(r"#[0-9a-fA-F]{6}", str(couleur)):
            raise CorpsInvalide("« apparence.texte_sur_bandeau » est une couleur #rrggbb.")
        if "collant" in apparence and not isinstance(apparence["collant"], bool):
            raise CorpsInvalide("« apparence.collant » vaut true ou false.")

    if menu.pk is None:
        menu.save()
    if cle_style:
        styles_predefinis.appliquer(menu, cle_style)
        modifies += ["style_pret", "layout"]
    if apparence:
        style = styles_predefinis.style_propre(menu)
        if "survol" in apparence:
            style.survol = apparence["survol"]
        if "forme" in apparence:
            style.forme = apparence["forme"]
        if "texte_sur_bandeau" in apparence:
            style.transparent_texte = apparence["texte_sur_bandeau"].lower()
        if "collant" in apparence:
            style.sticky = apparence["collant"]
        style.save()
        menu.menu_style = style
        modifies.append("apparence")
    if "style" in corps:
        # Après « style_pret » et « apparence » : le détail l'emporte sur l'ensemble.
        style = ecrire_par_formulaire(MenuStyleForm, styles_predefinis.style_propre(menu), corps["style"], "style")
        menu.menu_style = style
        modifies.append("style")
    if "logo" in corps:
        menu.logo = _logo_neuf(corps["logo"])
        modifies.append("logo")
    return modifies


def _logo_neuf(image_id):
    """Un logo NEUF fait d'une image de la médiathèque — ou None : celui du site."""
    from django.core.files.base import ContentFile

    from jeiko.administration.models import Logo

    from .vues_reglages import _image

    if image_id is None:
        return None
    nom, octets = _image(image_id, "logo")
    logo = Logo()
    logo.full_size.save(nom, ContentFile(octets), save=False)
    logo.save()  # fabrique les variantes (ordinateur, tablette, téléphone)
    return logo


def _traductions_valides(valeur):
    """{"en": {"barre_texte": "…"}} — langues proposées, clés de TEXTES_MENU."""
    codes = set(langues_du_site.codes_proposes())
    if not isinstance(valeur, dict) or set(valeur) - codes:
        raise CorpsInvalide(
            f"« traductions » est un objet par langue ({', '.join(sorted(codes))}) : "
            f"{{\"en\": {{\"barre_texte\": \"…\"}}}}."
        )
    propre = {}
    for code, textes in valeur.items():
        if not isinstance(textes, dict) or set(textes) - set(TEXTES_MENU):
            raise CorpsInvalide(
                f"« traductions.{code} » : clés acceptées — {', '.join(sorted(TEXTES_MENU))}."
            )
        textes = {
            c: str(v).strip()[:Menu._meta.get_field(TEXTES_MENU[c]).max_length]
            for c, v in textes.items() if str(v or "").strip()
        }
        if textes:
            propre[code] = textes
    return propre


def _copier_les_elements(source, destination):
    """Recopie l'arborescence d'un menu vers un autre, sous-entrées comprises."""
    def copier(elements, parent):
        for element in elements.order_by("position", "id"):
            clone = MenuItem.objects.create(
                menu=destination, main_menu=parent, position=element.position,
                title=element.title, titres=element.titres, page=element.page, active=element.active,
                lien=element.lien, bouton=element.bouton,
            )
            copier(element.submenus, clone)

    copier(source.menu_items.filter(main_menu__isnull=True), None)


class DetailMenu(VueAgent):
    permission_requise = VOIR

    def get(self, request, menu_id):
        menu = get_object_or_404(
            Menu.objects.prefetch_related("menu_items__submenus"), pk=menu_id
        )
        return ok({"menu": _menu_en_dict(menu)})

    @transaction.atomic
    def patch(self, request, menu_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification de menu non autorisée.", statut=403)

        menu = get_object_or_404(Menu, pk=menu_id)
        corps = self.corps(request)
        inconnues = sorted(set(corps) - CLES_MENU)
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Acceptées : {', '.join(sorted(CLES_MENU))}."
            )

        modifies = []
        if "nom" in corps:
            menu.name = str(corps["nom"]).strip()[:150]
            modifies.append("name")
        if "emplacement" in corps:
            if corps["emplacement"] not in EMPLACEMENTS:
                raise CorpsInvalide(
                    f"Emplacement inconnu. Attendus : {', '.join(EMPLACEMENTS)}."
                )
            menu.place = corps["emplacement"]
            modifies.append("place")
        if "disposition" in corps:
            # `None` et non `""` : voir la contrainte de base.
            menu.layout = corps["disposition"] or None
            modifies.append("layout")
        panier_regle = (
            "afficher_le_panier" in corps
            and _regler_le_panier(request, corps["afficher_le_panier"])
        )

        _verifier_la_disposition(menu.place, menu.layout)

        if "par_defaut" in corps and corps["par_defaut"]:
            # Une contrainte n'autorise qu'un défaut par emplacement : libérer
            # l'ancien plutôt que de lever une UniqueViolation, c'est-à-dire
            # une 500. Même raisonnement que la page racine.
            Menu.objects.filter(place=menu.place, is_default=True).exclude(
                pk=menu.pk
            ).update(is_default=False)
            menu.is_default = True
            modifies.append("is_default")

        modifies += _ecrire_l_apparence(menu, corps)

        if modifies:
            menu.save()

        if panier_regle:
            modifies.append("afficher_le_panier")

        if "elements" in corps:
            _ecrire_les_elements(menu, corps["elements"])
            modifies.append("elements")

        menu.refresh_from_db()
        return ok({"menu": _menu_en_dict(menu), "modifie": modifies})


# --------------------------------------------------------------------------- #
#  Affectation — c'est ici que se font les sous-sites
# --------------------------------------------------------------------------- #
class MenusDeLaCategorie(VueAgent):
    """
    Affecte un menu principal et un menu de pied de page à une catégorie.

    C'est LE point qui fait les sous-sites : toutes les pages d'une catégorie
    prennent ses menus. Un menu retiré (`null`) rend la catégorie au menu par
    défaut du site.
    """

    permission_requise = MODIFIER

    @transaction.atomic
    def patch(self, request, categorie_id):
        categorie = get_object_or_404(Category, pk=categorie_id)
        corps = self.corps(request)
        inconnues = sorted(set(corps) - {"menu_principal", "menu_pied_de_page"})
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Acceptées : menu_principal, menu_pied_de_page."
            )

        modifies = []
        for cle, champ, emplacement in (
            ("menu_principal", "main_menu", MenuPlace.MAIN),
            ("menu_pied_de_page", "footer_menu", MenuPlace.FOOTER),
        ):
            if cle not in corps:
                continue

            valeur = corps[cle]
            if valeur in (None, "", 0):
                setattr(categorie, champ, None)
                modifies.append(champ)
                continue

            menu = Menu.objects.filter(pk=valeur).first()
            if menu is None:
                raise CorpsInvalide(f"Aucun menu nº {valeur}. Voir /menus/.")
            # Un menu de pied de page posé en menu principal ne se rendrait
            # pas : les dispositions ne sont pas les mêmes.
            if menu.place != emplacement:
                raise CorpsInvalide(
                    f"Le menu « {menu.name} » est un menu « {menu.place} », "
                    f"pas « {emplacement} » : il ne se rendrait pas à cette place."
                )
            setattr(categorie, champ, menu)
            modifies.append(champ)

        if modifies:
            categorie.save(update_fields=modifies)

        return ok({
            "categorie": {
                "id": categorie.id,
                "nom": categorie.name,
                "slug": categorie.slug,
                "menu_principal": categorie.main_menu_id,
                "menu_pied_de_page": categorie.footer_menu_id,
            },
            "modifie": modifies,
        })
