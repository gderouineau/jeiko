"""
Les réglages de base du site, vus par une IA qui le monte de zéro (07/10/2026).

Le besoin (Guillaume) : « quand on fabrique un site du commencement, l'IA va
voir ce qu'il y a à faire dans les réglages de base — cela permettra d'avoir
un site qui fonctionne ». Une seule lecture lui dit donc :

* `a_faire` — la liste « À finir de configurer » du tableau de bord, la
  même, calculée comme pour un administrateur qui aurait TOUS les droits :
  l'IA doit voir ce qui manque même quand elle ne peut pas le faire — elle le
  dit alors à la personne ;
* `reglages` — l'état de chaque réglage de base ;
* pour chacun, OÙ le régler : la route de l'API, ou l'écran quand il est
  sensible.

Ce qu'une IA peut modifier ici (`PATCH`) : le logo et le favicon (une image de
la médiathèque), les textes du bandeau cookies de la langue du site, et les
MODULES montrés dans le menu de l'administration (MOD-01 — boutique,
rendez-vous, formations, questionnaires : les masquer ne supprime rien). Le reste
a déjà sa route (identité, langues, pages, menus, pages d'erreur).

Ouverts le 27/10/2026 (« si tu vois d'autres réglages qui ne sont pas
ouverts, ouvre-les » — Guillaume), par le formulaire de leur écran, sous la
permission de leur écran :
* `boutique` — Boutique › Réglages (en ligne, panier, TVA, devise, livraison
  offerte, avis…) ;
* `facturation` — Boutique › Facturation, SAUF l'IBAN et le BIC : ils disent
  où les clients paient, et une IA trompée par un texte qu'elle a lu pourrait
  les détourner. Ils restent à l'écran ;
* `avances` — Réglages › Réglages avancés, SAUF le groupe « Agents IA » : un
  agent ne relève pas lui-même la garde qui le limite.

Ce qui reste à l'ÉCRAN, à dessein : tout ce qui porte un secret ou engage le
site au-delà de son contenu — serveur d'e-mails (mot de passe), moyens de
paiement (clés), API Google et connexions sociales (clés), mise à jour
automatique, partage des rapports d'erreur (des données qui sortent du site).
La lecture dit seulement s'ils sont faits, jamais leur valeur.
"""

from django.core.files.base import ContentFile
from django.db import transaction

from jeiko.administration.models import Favicon, Logo, WebSite
from jeiko.administration.modules import MODULES, etat_des_modules

from jeiko import reglages_avances

from .vues_api import CorpsInvalide, VueAgent, ecrire_par_formulaire, erreur, ok, valeurs_du_formulaire

VOIR = "administration.view_website"
MODIFIER = "administration.change_website"

#: Où se règle chaque entrée de la liste « À finir de configurer ».
API_POUR = {
    "jeiko_administration:logo_update": "PATCH /reglages/ {\"logo\": id d'image}",
    "jeiko_administration:favicon_update": "PATCH /reglages/ {\"favicon\": id d'image}",
    "jeiko_administration:site_identity": "PATCH /identite/ {\"nom_du_site\", \"coordonnees\"}",
    "jeiko_administration_pages:main": "POST /pages/creer/, puis PATCH /pages/<id>/ {\"publiee\": true}",
    "jeiko_administration_pages:pages_erreur": "PATCH /pages/erreurs/",
    "accueil": "PATCH /pages/<id>/ {\"racine\": true, \"publiee\": true}",
}

#: Les permissions des écrans de la boutique et des réglages avancés.
REGLER_LA_BOUTIQUE = "shop.change_producttype"
REGLER_LE_FONCTIONNEMENT = "users.config_edit_site"

#: Ce que la facturation garde à l'écran : où les clients paient.
BANQUE = ("iban", "bic")

#: Les réglages avancés qu'une IA peut lire et écrire. Par la clé, pas par le
#: libellé du groupe : traduit, il ne vaudrait plus « Agents IA » en anglais.
AVANCES = [cle for cle in reglages_avances.CATALOGUE if not cle.startswith("agents_")]


def _formulaires_de_la_boutique():
    from jeiko.shop.forms import ReglagesFacturationForm, ShopSettingsForm

    class Facturation(ReglagesFacturationForm):
        class Meta(ReglagesFacturationForm.Meta):
            fields = tuple(f for f in ReglagesFacturationForm.Meta.fields if f not in BANQUE)

    return ShopSettingsForm, Facturation


def _avances(site):
    reglees = site.reglages_avances or {}
    return {
        cle: {"valeur": reglages_avances.valeur(cle, None), "reglee_ici": cle in reglees,
              "libelle": str(libelle), "aide": str(aide), "min": minimum, "max": maximum}
        for cle, (_s, _g, libelle, aide, minimum, maximum) in reglages_avances.CATALOGUE.items()
        if cle in AVANCES
    }


#: Les textes du bandeau cookies qu'on peut écrire.
TEXTES_DU_BANDEAU = ("message_text", "accept_all_label", "refuse_all_label", "customize_label",
                     "save_choices_label", "more_info_label")


class _TousLesDroits:
    """Un administrateur imaginaire qui a tous les droits : voir TOUT ce qui manque."""
    is_staff = is_superuser = True

    def has_perm(self, perm):
        return True


def _bandeau():
    from django.contrib.sites.models import Site

    from jeiko.cookies.models import CookieBannerConfig, default_locale

    return (CookieBannerConfig.objects.filter(site=Site.objects.get_current(), locale=default_locale())
            .order_by("-is_active", "priority").first())


def _etat(site):
    from jeiko.administration.dashboard import setup_checklist
    from jeiko.administration.models import Legals, MailSettings
    from jeiko.administration_pages.models import Page
    from jeiko.payments.models import PaymentGateway

    from jeiko.shop.models import ShopSettings

    boutique, facturation = _formulaires_de_la_boutique()
    reglages_boutique = ShopSettings.get_solo()
    legales = Legals.objects.filter(site=site).first()
    mail = MailSettings.objects.first()
    bandeau = _bandeau()
    a_faire = [
        {"a_faire": i["label"], "pourquoi": i["hint"], "ecran": i["url"],
         "api": API_POUR.get(i.get("code"), "à l'écran seulement (réglage sensible) : le demander à la personne")}
        for i in setup_checklist(_TousLesDroits(), site)
    ]
    return {
        "a_faire": [{k: str(v) for k, v in item.items()} for item in a_faire],
        "reglages": {
            "nom_du_site": {"valeur": site.name, "api": "PATCH /identite/"},
            "logo": {"fait": bool(site.logo_id and site.logo.full_size), "api": "PATCH /reglages/"},
            "favicon": {"fait": bool(site.favicon_id and site.favicon.png_32), "api": "PATCH /reglages/"},
            "identite": {"fait": bool(getattr(getattr(site, "identity", None), "name", "")),
                         "api": "GET/PATCH /identite/"},
            "langues": {"multilingue": site.multilingue, "langues": site.langues_du_site or [],
                        "api": "GET/PATCH /langues/"},
            "accueil": {"page": Page.objects.filter(is_root=True).values_list("pk", flat=True).first(),
                        "api": "GET/PATCH /pages/<id>/"},
            "pages_publiees": Page.objects.filter(active=True, langue="").count(),
            "pages_d_erreur": {"choisies": {str(c): getattr(site, f"page_{c}_id") for c in (404, 403, 500, 400)},
                               "api": "GET/PATCH /pages/erreurs/"},
            "pages_legales": {
                "pages": {cle: getattr(legales, f"{cle}_page_id", None) if legales else None
                          for cle in ("mentions", "privacy", "cgv", "cgu")},
                "api": "le contenu : routes des pages (/pages/<id>/sections/…) — pages protégées, jamais supprimées",
            },
            "bandeau_cookies": {
                "textes": {cle: getattr(bandeau, cle) for cle in TEXTES_DU_BANDEAU} if bandeau else None,
                "api": "PATCH /reglages/ {\"bandeau_cookies\": {…}}",
            },
            "serveur_email": {"fait": bool(mail and (mail.host or "").strip()),
                              "api": "à l'écran seulement : il porte un mot de passe"},
            "paiement": {"fait": PaymentGateway.objects.filter(is_active=True).exists(),
                         # STRIPE-01 : actif ne veut pas dire branché (webhook).
                         "stripe": _branchement_stripe(),
                         "api": "à l'écran seulement : il porte des clés (Paiements › Stripe, qui dit aussi quoi déclarer chez Stripe)"},
            "notifications": {"valeurs": _notifications(site),
                              "api": "PATCH /reglages/ {\"notifications\": {\"stock_bas\": false}} — les pastilles du menu de l'administration, une à une"},
            "modules": {"valeurs": etat_des_modules(site),
                        "api": "PATCH /reglages/ {\"modules\": {\"boutique\": true}} — masque ou montre la section dans le menu de l'administration, rien d'autre"},
            "boutique": {"valeurs": valeurs_du_formulaire(boutique, reglages_boutique),
                         "api": "PATCH /reglages/ {\"boutique\": {\"currency\": \"EUR\"}} — Boutique › Réglages"},
            "facturation": {"valeurs": valeurs_du_formulaire(facturation, reglages_boutique),
                            "iban_renseigne": bool(reglages_boutique.iban),
                            "api": "PATCH /reglages/ {\"facturation\": {\"siret\": \"…\"}} — Boutique › Facturation ; l'IBAN et le BIC à l'écran seulement"},
            "avances": {"valeurs": _avances(site),
                        "api": "PATCH /reglages/ {\"avances\": {\"contacts_jours\": 730}} — null rend la main au .env ; « Agents IA » à l'écran seulement"},
            "mise_a_jour_auto": {"valeur": site.mise_a_jour_auto, "api": "à l'écran seulement"},
            "partage_des_erreurs": {"valeur": site.partager_les_erreurs, "api": "à l'écran seulement"},
        },
    }


def _notifications(site):
    from jeiko.administration.notifications import actives

    return actives(site)


def _branchement_stripe():
    from jeiko.payments.branchement import resume
    from jeiko.payments.models import PaymentGateway

    passerelle = PaymentGateway.objects.filter(code="stripe").first()
    return resume(passerelle) if passerelle else None


def _image(identifiant, cle):
    """Le fichier d'une image de la médiathèque, pour en faire un logo ou un favicon."""
    from jeiko.administration_pages.models import ImageContent

    if not isinstance(identifiant, int) or isinstance(identifiant, bool):
        raise CorpsInvalide(f"« {cle} » attend l'identifiant d'une image de la médiathèque (GET /images/).")
    image = ImageContent.objects.filter(pk=identifiant).first()
    fichier = image and (image.original_image or image.full_size)
    if not fichier:
        raise CorpsInvalide(f"« {cle} » : aucune image ne porte l'identifiant {identifiant}.")
    with fichier.open("rb") as source:
        return fichier.name.rsplit("/", 1)[-1], source.read()


class ReglagesDeBase(VueAgent):
    """
    `GET` : ce qui reste à faire, l'état des réglages de base, où régler chacun.
    `PATCH {"logo": 12, "favicon": 13, "bandeau_cookies": {"message_text": "…"}}` :
    partiel ; une clé absente ne change pas.
    """

    permission_requise = VOIR

    def get(self, request):
        return ok(_etat(WebSite.objects.first()))

    @transaction.atomic
    def patch(self, request):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification des réglages non autorisée.", statut=403, permission_manquante=MODIFIER)
        corps = self.corps(request, connues={"logo", "favicon", "bandeau_cookies", "modules", "notifications",
                                           "boutique", "facturation", "avances"})
        # Toutes les permissions AVANT la première écriture : un refus au milieu
        # rendrait un 403 sur un PATCH à moitié appliqué.
        for cles, permission in ((("boutique", "facturation"), REGLER_LA_BOUTIQUE),
                                 (("avances",), REGLER_LE_FONCTIONNEMENT)):
            if set(cles) & set(corps) and not request.user.has_perm(permission):
                return erreur(f"Modification de « {', '.join(sorted(set(cles) & set(corps)))} » non autorisée.",
                              statut=403, permission_manquante=permission)
        site = WebSite.objects.select_for_update().first()

        if "logo" in corps:
            nom, octets = _image(corps["logo"], "logo")
            logo = site.logo or Logo.objects.create()
            logo.full_size.save(nom, ContentFile(octets), save=False)
            logo.save()  # fabrique les variantes (ordinateur, tablette, téléphone)
            site.logo = logo
        if "favicon" in corps:
            nom, octets = _image(corps["favicon"], "favicon")
            favicon = site.favicon or Favicon.objects.create()
            favicon.source.save(nom, ContentFile(octets), save=False)
            favicon.save()  # fabrique les PNG 32 et 180
            site.favicon = favicon
        if "logo" in corps or "favicon" in corps:
            site.save(update_fields=["logo", "favicon"])

        if "modules" in corps:
            modules = corps["modules"]
            if (not isinstance(modules, dict) or set(modules) - set(MODULES)
                    or not all(isinstance(v, bool) for v in modules.values())):
                raise CorpsInvalide(f"« modules » : un objet {{code: true|false}}, codes parmi {', '.join(MODULES)}.")
            for code, actif in modules.items():
                setattr(site, MODULES[code][0], actif)
            site.save(update_fields=[MODULES[code][0] for code in modules])

        if "notifications" in corps:
            from jeiko.administration.notifications import NOTIFICATIONS, actives

            notes = corps["notifications"]
            if (not isinstance(notes, dict) or set(notes) - set(NOTIFICATIONS)
                    or not all(isinstance(v, bool) for v in notes.values())):
                raise CorpsInvalide(f"« notifications » : un objet {{code: true|false}}, codes parmi {', '.join(NOTIFICATIONS)}.")
            site.notifications = {**actives(site), **notes}
            site.save(update_fields=["notifications"])

        if "bandeau_cookies" in corps:
            textes = corps["bandeau_cookies"]
            if not isinstance(textes, dict) or set(textes) - set(TEXTES_DU_BANDEAU):
                raise CorpsInvalide(f"« bandeau_cookies » : un objet dont les clés sont parmi {', '.join(TEXTES_DU_BANDEAU)}.")
            bandeau = _bandeau()
            if bandeau is None:
                raise CorpsInvalide("Aucun bandeau cookies : ouvrez une fois Réglages › Cookies pour le créer.")
            for cle, valeur in textes.items():
                if not isinstance(valeur, str) or (cle != "message_text" and len(valeur) > 80):
                    raise CorpsInvalide(f"« {cle} » : un texte (80 caractères au plus, sauf le message).")
                setattr(bandeau, cle, valeur.strip())
            bandeau.save(update_fields=list(textes))

        if "boutique" in corps or "facturation" in corps:
            from jeiko.shop.models import ShopSettings

            boutique, facturation = _formulaires_de_la_boutique()
            for cle, formulaire in (("boutique", boutique), ("facturation", facturation)):
                if cle in corps:
                    ecrire_par_formulaire(formulaire, ShopSettings.get_solo(), corps[cle], cle)

        if "avances" in corps:
            site.reglages_avances = {**(site.reglages_avances or {}), **_avances_valides(corps["avances"])}
            site.reglages_avances = {k: v for k, v in site.reglages_avances.items() if v is not None}
            site.save(update_fields=["reglages_avances"])
            from jeiko.administration.website_cache import invalidate_website_data

            invalidate_website_data()
        return ok(_etat(site))


def _avances_valides(valeurs):
    """{clé: valeur} validé comme à l'écran ; None retire le réglage (le .env reprend la main)."""
    if not isinstance(valeurs, dict) or set(valeurs) - set(AVANCES):
        raise CorpsInvalide(f"« avances » : un objet dont les clés sont parmi {', '.join(AVANCES)}.")
    propres = {}
    for cle, valeur in valeurs.items():
        booleen = reglages_avances.CATALOGUE[cle][4] is None and reglages_avances.CATALOGUE[cle][5] is None
        if valeur is not None and booleen != isinstance(valeur, bool):
            raise CorpsInvalide(f"« avances.{cle} » : " + ("true ou false." if booleen else "un nombre entier."))
        try:
            propres[cle] = None if valeur is None else reglages_avances.valider(cle, valeur)
        except ValueError as souci:
            raise CorpsInvalide(str(souci)) from None
    return propres


class PagesLegales(VueAgent):
    """
    LEG-01 — les pages légales : leur état et les informations du site
    qu'elles reprennent (GET) ; un geste (POST) :

    * `{"action": "poser"}` crée celles qui manquent ;
    * `{"action": "informations"}` refait celles JAMAIS retouchées, avec le
      texte et les informations du moment ;
    * `{"action": "appliquer", "page": "cgv"}` remplace une page, même
      retouchée, par le modèle à jour — l'état remplacé entre dans
      l'historique de la page. Seulement à la demande de l'exploitant.
    """
    permission_requise = VOIR

    @staticmethod
    def _etat():
        from jeiko.administration import pages_legales

        return {
            "pages": [{"cle": d["cle"], "titre": d["titre"], "page_id": page.pk if page else None,
                       "retouchee": retouchee} for d, page, retouchee in pages_legales.etat()],
            "informations": pages_legales.informations_du_site(),
        }

    def get(self, request):
        return ok(self._etat())

    def post(self, request):
        from jeiko.administration import pages_legales

        if not request.user.has_perm(MODIFIER):
            return erreur("Modification des pages légales non autorisée.", statut=403)
        corps = self.corps(request, connues={"action", "page"})
        action = corps.get("action")
        if action == "poser":
            fait = {"creees": pages_legales.poser_les_manquantes()}
        elif action == "informations":
            fait = {"mises_a_jour": pages_legales.mettre_a_jour_les_informations()}
        elif action == "appliquer":
            try:
                fait = {"appliquee": pages_legales.appliquer_le_modele(str(corps.get("page") or ""),
                                                                       auteur=request.user).pk}
            except KeyError:
                raise CorpsInvalide("« page » : mentions, cgu, cgv ou confidentialite.")
        else:
            raise CorpsInvalide("« action » : poser, informations ou appliquer.")
        return ok({**fait, **self._etat()})
