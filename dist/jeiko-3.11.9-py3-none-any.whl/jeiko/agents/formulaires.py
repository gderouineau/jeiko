# jeiko/agents/formulaires.py
"""Saisie d'un agent. Le jeton, lui, ne se saisit jamais : il se tire au sort."""

from django import forms

from .models import Agent


def personnes_possibles(par, agent=None):
    """
    À qui un agent peut appartenir — donc dans quel agenda il écrira.

    Qui supervise les agendas (superuser, rôle Administrateur) choisit parmi
    les personnes de l'équipe ; les autres ne donnent un agent qu'à
    eux-mêmes : sinon, créer un agent serait un moyen d'écrire dans l'agenda
    d'un collègue. Jamais le compte porteur d'un agent. L'actuel reste
    proposé, pour qu'un enregistrement ne le retire pas en silence.
    """
    from django.contrib.auth import get_user_model
    from django.db.models import Q

    from jeiko.calendars.mixins import is_calendar_supervisor

    User = get_user_model()
    if par is not None and is_calendar_supervisor(par):
        equipe = Q(is_active=True, agent__isnull=True) & (
            Q(is_superuser=True) | Q(is_staff=True) | Q(role_assignments__isnull=False))
    else:
        equipe = Q(pk=getattr(par, "pk", None))
    if agent is not None and agent.proprietaire_id:
        equipe |= Q(pk=agent.proprietaire_id)
    return User.objects.filter(equipe).distinct().order_by("first_name", "last_name", "username")


class AgentForm(forms.ModelForm):
    class Meta:
        model = Agent
        fields = ("nom", "proprietaire", "description", "expire_le", "plafond_horaire",
                  "ips_autorisees", "actif")
        widgets = {
            "nom": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "ex. Rédaction assistée",
            }),
            "proprietaire": forms.Select(attrs={"class": "form-select"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "expire_le": forms.DateTimeInput(
                attrs={"class": "form-control", "type": "datetime-local"},
                format="%Y-%m-%dT%H:%M",
            ),
            "plafond_horaire": forms.NumberInput(attrs={
                "class": "form-control",
                "min": 1,
                "placeholder": "vide = plafond du site",
            }),
            "ips_autorisees": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3,
                "placeholder": "une adresse par ligne",
            }),
        }

    def __init__(self, *args, par=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["proprietaire"].queryset = personnes_possibles(par, self.instance)
        # À la création, vide veut dire « moi » (`creer_agent`) ; ensuite, le
        # retirer fermerait l'agenda à l'agent sans qu'on l'ait voulu.
        self.fields["proprietaire"].required = bool(self.instance.pk)
        # Le navigateur n'accepte que ce format pour `datetime-local`, et sans
        # lui le champ se vide à chaque réaffichage du formulaire.
        self.fields["expire_le"].input_formats = ["%Y-%m-%dT%H:%M"]
