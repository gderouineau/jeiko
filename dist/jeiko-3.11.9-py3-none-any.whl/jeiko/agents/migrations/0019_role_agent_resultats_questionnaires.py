# jeiko/agents/migrations/0019_role_agent_resultats_questionnaires.py
"""
Rôle « Agent résultats de questionnaires » — voir qui a passé un questionnaire
et ce qu'il a répondu (28/10/2026).

Pourquoi un rôle à part
-----------------------
« Agent questionnaires » CONSTRUIT un test et, exprès, ne voit pas ses
passages (0006) : ils portent les réponses de personnes identifiables. Guillaume
veut pouvoir les lire depuis le MCP. Ce rôle est donc le seul à porter
`view_experttestdata` : une clé de construction ne gagne pas d'accès aux
données de visiteurs, et inversement.

Ce qu'il porte : voir les passages, voir les contacts (pour nommer qui a
répondu), voir les questionnaires et leurs profils (pour lire un résultat).
Ce qu'il ne porte pas : aucune écriture, aucune suppression, pas les notes
des contacts. Et l'API ne liste jamais tous les passages : vingt au plus.

Peuplé dès sa création, permissions forcées d'abord : le piège réparé par 0011.
"""

from django.db import migrations

SLUG = "agent-resultats-questionnaires"
NOM = "Agent résultats de questionnaires"

PERMISSIONS = {
    "questionnaires_expert": ("view_experttestdata", "view_prospect", "view_experttest", "view_expertprofiletype"),
}


def creer_le_role(apps, schema_editor):
    from django.apps import apps as registre_reel
    from django.contrib.auth.management import create_permissions

    for app_label in PERMISSIONS:
        create_permissions(registre_reel.get_app_config(app_label), verbosity=0)

    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role, _ = Role.objects.get_or_create(
        slug=SLUG,
        defaults={
            "name": NOM,
            "description": (
                "Permet à un agent de LIRE les passages d'un questionnaire (profil obtenu, scores, réponses "
                "données) et les contacts qui l'ont passé. Données personnelles. N'autorise NI l'écriture, "
                "NI la suppression, NI la construction d'un questionnaire (rôle « Agent questionnaires »)."
            ),
            "is_active": True,
        },
    )
    for app_label, codenames in PERMISSIONS.items():
        for codename in codenames:
            permission = Permission.objects.filter(
                codename=codename, content_type__app_label=app_label
            ).first()
            if permission is not None:
                RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer_le_role(apps, schema_editor):
    apps.get_model("users", "Role").objects.filter(slug=SLUG).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0018_proprietaire"),
        ("questionnaires_expert", "0027_libelles_des_champs"),
        ("users", "0001_initial"),
    ]

    operations = [migrations.RunPython(creer_le_role, retirer_le_role)]
