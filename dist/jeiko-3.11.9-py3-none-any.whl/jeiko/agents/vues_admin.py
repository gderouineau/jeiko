# jeiko/agents/vues_admin.py
"""
Écrans d'administration des agents.

Le jeton ne s'affiche qu'une fois
---------------------------------
À la création et à la réinitialisation, et nulle part ailleurs : la base ne
contient que son empreinte (voir `jetons.py`). L'écran le montre donc en clair
une seule fois, en disant que c'est la seule.

C'est un inconfort assumé. L'alternative — un jeton relisable — ferait d'une
base lue, d'une sauvegarde égarée ou d'une capture d'écran de cet écran un
accès permanent au site.

Ce que ces écrans ne font pas
-----------------------------
Ils n'attribuent pas de droits. Un agent tout neuf ne peut RIEN : ses
permissions passent par les rôles, sur l'écran des rôles, comme pour une
personne. C'est délibéré — une seule vérité sur « qui a le droit de quoi ».
"""

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.generic import DetailView, ListView

from .formulaires import AgentForm
from .models import Agent, AppelAgent
from .services import creer_agent, reinitialiser_le_jeton
from django.utils.translation import gettext_lazy as _

#: Un agent est un porteur de droits : le créer, c'est ouvrir un accès. On le
#: garde derrière la permission qui gouverne déjà les comptes.
PERM = "auth.change_user"

#: Le jeton en clair transite par la session, pas par l'URL ni par la base.
#: Une URL part dans les journaux et l'historique ; la session, elle, est
#: purgée dès la première lecture (voir `_reprendre_le_jeton`).
CLE_SESSION_JETON = "jeiko_agent_jeton_en_clair"


def _deposer_le_jeton(request, jeton):
    request.session[CLE_SESSION_JETON] = jeton


def _reprendre_le_jeton(request):
    """Rend le jeton et l'efface : il ne survit pas à un rafraîchissement."""
    return request.session.pop(CLE_SESSION_JETON, "")


@method_decorator(never_cache, name="dispatch")
class ListeDesAgents(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Agent
    template_name = "agents/admin/liste.html"
    context_object_name = "agents"
    permission_required = PERM
    raise_exception = True

    def get_queryset(self):
        return Agent.objects.select_related("user").prefetch_related("jetons")


@method_decorator(never_cache, name="dispatch")
class CreationAgent(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "agents/admin/formulaire.html"
    permission_required = PERM
    raise_exception = True

    def get(self, request):
        from django.shortcuts import render

        return render(request, self.template_name,
                      {"form": AgentForm(par=request.user, initial={"proprietaire": request.user.pk})})

    def post(self, request):
        from django.shortcuts import render

        form = AgentForm(request.POST, par=request.user)
        if not form.is_valid():
            return render(request, self.template_name, {"form": form})

        agent, jeton = creer_agent(
            nom=form.cleaned_data["nom"],
            description=form.cleaned_data["description"],
            expire_le=form.cleaned_data["expire_le"],
            ips_autorisees=form.cleaned_data["ips_autorisees"],
            plafond_horaire=form.cleaned_data.get("plafond_horaire"),
            cree_par=request.user,
            proprietaire=form.cleaned_data["proprietaire"],
        )
        agent.actif = form.cleaned_data["actif"]
        agent.save(update_fields=["actif"])

        _deposer_le_jeton(request, jeton)
        messages.success(
            request,
            _("Agent « %(nom)s » créé. Donnez-lui un rôle pour qu'il puisse faire quelque chose : sans rôle, il ne peut rien.") % {"nom": agent.nom},
        )
        return redirect("jeiko_agents_admin:detail", pk=agent.pk)


@method_decorator(never_cache, name="dispatch")
class DetailAgent(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = Agent
    template_name = "agents/admin/detail.html"
    context_object_name = "agent"
    permission_required = PERM
    raise_exception = True

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["jeton_en_clair"] = _reprendre_le_jeton(self.request)
        ctx["jetons"] = self.object.jetons.all()
        ctx["appels"] = AppelAgent.objects.filter(agent=self.object)[:50]
        ctx["roles"] = self.object.user.role_assignments.select_related("role")
        if self.request.user.has_perm("users.assign_role"):
            from jeiko.users.delegation import roles_delegables
            from jeiko.users.models import Role

            ctx["roles_a_cocher"] = roles_delegables(
                self.request.user, Role.objects.filter(is_active=True))
            ctx["roles_coches"] = {ra.role_id for ra in ctx["roles"]}
        ctx["url_api"] = self.request.build_absolute_uri("/api/agent/v1/")
        ctx.update(_connexion_mcp(self.request))
        return ctx


def _connexion_mcp(request):
    """Ce qu'il faut pour brancher un assistant sur CE site (MCP + skill)."""
    from jeiko.administration.models import WebSite

    from .skill import nom_de_la_skill

    site = WebSite.objects.only("name").first()
    domaine = request.get_host()
    return {
        "url_mcp": request.build_absolute_uri(reverse("agents_mcp")),
        # Un seul identifiant pour le serveur MCP et la skill.
        "nom_serveur_mcp": nom_de_la_skill(domaine),
        "nom_skill": nom_de_la_skill(domaine),
        "nom_du_site": (site.name if site and site.name else domaine),
    }


@method_decorator(never_cache, name="dispatch")
class TelechargementSkill(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    La skill de ce site, à ajouter dans Claude (Paramètres → Capacités).

    Même méthode de travail pour tous les sites, mais nommée et décrite pour
    CELUI-CI, avec l'adresse de son serveur MCP : voir `agents/skill.py`.
    Aucun jeton dedans — il se déclare dans le connecteur MCP.
    """

    permission_required = PERM
    raise_exception = True

    def get(self, request):
        from django.http import HttpResponse

        from .skill import archive_skill

        connexion = _connexion_mcp(request)
        nom, octets = archive_skill(
            request.get_host(), connexion["nom_du_site"], connexion["url_mcp"]
        )
        reponse = HttpResponse(octets, content_type="application/zip")
        reponse["Content-Disposition"] = f'attachment; filename="{nom}.zip"'
        return reponse


def _agent_gere(request, pk):
    """
    L'agent, s'il n'a pas plus de droits que la personne qui agit : modifier,
    réémettre le jeton ou réactiver un agent plus puissant, c'était s'en
    approprier les droits (audit du 11/10/2026, S05).
    """
    from jeiko.users.delegation import verifier_la_cible

    agent = get_object_or_404(Agent, pk=pk)
    verifier_la_cible(request.user, agent.user)
    return agent


@method_decorator(never_cache, name="dispatch")
class ModificationAgent(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "agents/admin/formulaire.html"
    permission_required = PERM
    raise_exception = True

    def get(self, request, pk):
        from django.shortcuts import render

        agent = _agent_gere(request, pk)
        return render(
            request, self.template_name, {"form": AgentForm(instance=agent, par=request.user), "agent": agent}
        )

    def post(self, request, pk):
        from django.shortcuts import render

        agent = _agent_gere(request, pk)
        form = AgentForm(request.POST, instance=agent, par=request.user)
        if not form.is_valid():
            return render(request, self.template_name, {"form": form, "agent": agent})
        form.save()
        messages.success(request, _("Agent enregistré."))
        return redirect("jeiko_agents_admin:detail", pk=agent.pk)


class RolesDeLAgent(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Les rôles de l'agent, cochés en une fois sur sa fiche (27/10/2026).

    Un rôle à la fois, sur l'écran des rôles qui renvoyait ensuite à la liste
    des rôles : avec huit rôles par agent, « on ne s'en sort jamais »
    (Guillaume). Les règles restent celles de cet écran-là : on ne donne ni ne
    retire que les rôles qu'on pourrait déléguer (S04) — les autres ne sont ni
    affichés ni touchés —, chaque changement est journalisé, et le dernier
    super-rôle actif du site n'est jamais retiré.

    Ce que la case ne règle pas : une date d'expiration. Elle se pose sur
    l'écran des rôles, qui revient ici.
    """
    permission_required = (PERM, "users.assign_role")
    raise_exception = True

    def post(self, request, pk):
        from jeiko.users.delegation import roles_delegables
        from jeiko.users.models import Role, RoleAssignment
        from jeiko.users.views.admin import _log_security_event

        agent = _agent_gere(request, pk)
        permis = roles_delegables(request.user, Role.objects.filter(is_active=True))
        voulus = {r.pk for r in permis if str(r.pk) in request.POST.getlist("roles")}
        actuels = {ra.role_id: ra for ra in agent.user.role_assignments.filter(role__in=permis)}

        for role in permis:
            if role.pk in voulus and role.pk not in actuels:
                RoleAssignment.objects.create(user=agent.user, role=role, assigned_by=request.user)
                _log_security_event(request, agent.user, "role_changed",
                                    {"action": "assign", "role": role.slug})
            elif role.pk not in voulus and role.pk in actuels:
                if role.is_superrole and not RoleAssignment.objects.filter(
                        role__is_superrole=True, role__is_active=True,
                ).exclude(pk=actuels[role.pk].pk).exists():
                    messages.error(request, _("« %(role)s » est le dernier rôle d'administrateur "
                                              "du site : il est gardé.") % {"role": role.name})
                    continue
                actuels[role.pk].delete()
                _log_security_event(request, agent.user, "role_changed",
                                    {"action": "revoke", "role": role.slug})
        messages.success(request, _("Rôles enregistrés."))
        return redirect("jeiko_agents_admin:detail", pk=agent.pk)


@method_decorator(never_cache, name="dispatch")
class ReinitialisationDuJeton(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Fabrique un jeton neuf et révoque les précédents.

    POST uniquement : c'est une action, et elle coupe l'accès en cours.
    """

    permission_required = PERM
    raise_exception = True

    def post(self, request, pk):
        agent = _agent_gere(request, pk)
        jeton = reinitialiser_le_jeton(
            agent, libelle=request.POST.get("libelle", "")[:150], par=request.user
        )
        _deposer_le_jeton(request, jeton)
        messages.success(
            request,
            _("Nouveau jeton créé, les précédents sont révoqués. "
            "Notez-le maintenant : il ne sera plus affiché."),
        )
        return redirect("jeiko_agents_admin:detail", pk=agent.pk)


@method_decorator(never_cache, name="dispatch")
class BasculeActivation(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = PERM
    raise_exception = True

    def post(self, request, pk):
        agent = _agent_gere(request, pk)
        agent.actif = not agent.actif
        agent.save(update_fields=["actif", "maj_le"])
        messages.success(
            request,
            (_("Agent « %(nom)s » réactivé.") if agent.actif
             else _("Agent « %(nom)s » désactivé.")) % {"nom": agent.nom},
        )
        return redirect("jeiko_agents_admin:detail", pk=agent.pk)


@method_decorator(never_cache, name="dispatch")
class RevocationDuJeton(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Révoque UN jeton, sans toucher aux autres (P-04).

    « Réinitialiser » coupe tout : l'accès de claude.ai et celui de Claude
    Code tombaient ensemble. Retirer l'accès d'un seul assistant — un
    téléphone perdu, une connexion qu'on ne reconnaît pas — doit laisser les
    autres travailler.
    """

    permission_required = PERM
    raise_exception = True

    def post(self, request, pk, jeton_pk):
        from .models import AgentToken

        _agent_gere(request, pk)
        jeton = get_object_or_404(AgentToken, pk=jeton_pk, agent_id=pk)
        jeton.revoquer()
        messages.success(
            request,
            _("Jeton « %(prefixe)s » révoqué. L’assistant qui s’en servait devra se reconnecter.") % {"prefixe": jeton.libelle or jeton.prefixe},
        )
        return redirect("jeiko_agents_admin:detail", pk=pk)
