# jeiko/agents/models.py
"""
Agents : des comptes machine, avec les mêmes droits que les comptes humains.

Le principe
-----------
Un agent **possède un `User`**. Ce n'est pas un détail d'implémentation, c'est
la décision structurante : tout ce qui existe déjà — le système de rôles
(`users/auth_backends.py`), les permissions Django, le journal de sécurité,
l'auteur d'une modification — continue de fonctionner sans une ligne de plus.
Inventer un système de droits parallèle aurait produit deux vérités sur « qui a
le droit de quoi », et l'une des deux aurait fini par mentir.

Ce compte ne peut pas se connecter par le formulaire : son mot de passe est
inutilisable (`set_unusable_password`) et il n'a pas d'adresse confirmée. Il
n'existe que pour porter des rôles et signer des modifications.

Les gardes, et ce que chacune couvre
------------------------------------
Aucune ne suffit seule ; c'est leur empilement qui fait la sécurité.

* **Le jeton haché** (`jetons.py`) — une base lue ne livre pas de quoi entrer.
* **`actif`** — la coupure immédiate, sans supprimer l'historique.
* **`expire_le`** — la coupure qu'on n'a pas besoin de penser à faire. Un agent
  créé pour un chantier de trois semaines devrait toujours en porter une.
* **`ips_autorisees`** — réduit l'usage d'un jeton divulgué à un réseau connu.
  Facultatif : un agent qui tourne chez un hébergeur à IP changeante ne peut
  pas s'en servir, et une garde qu'on désactive « en attendant » ne protège
  personne.
* **Les rôles** — ce que l'agent peut faire une fois entré. C'est là que se
  décide « modifier des pages oui, en supprimer non ».
* **`AppelAgent`** — ce qu'il a fait. Une action d'agent sans trace est une
  action que personne ne peut expliquer trois semaines plus tard.

Ce que cela ne protège pas
--------------------------
Un jeton divulgué reste utilisable jusqu'à sa révocation, depuis une IP
autorisée. Et un agent à qui l'on donne un rôle trop large fera exactement ce
que ce rôle permet : la vraie limite est le rôle, pas le jeton.
"""

from django.conf import settings
from django.db import models
from django.utils import timezone

from . import jetons
from django.utils.translation import gettext_lazy as _


class Agent(models.Model):
    """Un consommateur machine de l'API, et le compte qui porte ses droits."""

    nom = models.CharField(
        _("Nom"),
        max_length=150,
        unique=True,
        help_text=_("Ce à quoi sert cet agent. Il apparaîtra dans le journal."),
    )
    description = models.TextField(_("Description"), blank=True, default="")

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="agent",
        verbose_name=_("Compte porteur des droits"),
        help_text=_("Créé automatiquement. C'est à lui qu'on assigne des rôles."),
    )

    # Multi-agenda (Guillaume, 27/10/2026) : « un agent devrait appartenir à
    # quelqu'un, donc il écrirait en son nom et n'aurait accès qu'à son
    # agenda ». Le compte porteur ci-dessus porte les DROITS ; cette personne
    # dit AU NOM DE QUI il agit — l'agenda où il crée types et disponibilités,
    # et le seul qu'il voit. Le rôle Administrateur (super-rôle) lui ouvre
    # tous les agendas, comme à une personne (calendars.mixins).
    proprietaire = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="agents_a_moi",
        verbose_name=_("Appartient à"),
        help_text=_("La personne au nom de qui l'agent agit : il écrit dans SON agenda et ne voit "
                    "que le sien. Avec le rôle Administrateur, il voit tous les agendas."),
    )

    actif = models.BooleanField(
        _("Actif"),
        default=True,
        db_index=True,
        help_text=_("Décoché, l'agent est refusé immédiatement, jetons compris."),
    )

    expire_le = models.DateTimeField(
        _("Expire le"),
        null=True,
        blank=True,
        help_text=(
            _("Facultatif mais recommandé. Passée cette date, l'agent est refusé "
            "sans qu'on ait à y penser.")
        ),
    )

    plafond_horaire = models.PositiveIntegerField(
        _("Appels par heure"),
        null=True,
        blank=True,
        help_text=(
            _("Nombre d'appels autorisés par heure pour cet agent. Laisser vide "
            "pour le plafond du site. Un agent qui CONSTRUIT un site en "
            "consomme plusieurs centaines en une session — chaque bloc coûte "
            "deux ou trois appels ; un agent qui l'entretient en demande bien "
            "moins.")
        ),
    )

    ips_autorisees = models.TextField(
        _("Adresses IP autorisées"),
        blank=True,
        default="",
        help_text=(
            _("Facultatif. Une adresse par ligne. Laissé vide, l'agent est "
            "accepté depuis n'importe où.")
        ),
    )

    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="agents_crees",
        verbose_name=_("Créé par"),
    )
    cree_le = models.DateTimeField(_("Créé le"), auto_now_add=True)
    maj_le = models.DateTimeField(_("Modifié le"), auto_now=True)

    derniere_utilisation_le = models.DateTimeField(
        _("Dernier appel"), null=True, blank=True
    )
    derniere_ip = models.GenericIPAddressField(
        _("Dernière adresse IP"), null=True, blank=True
    )

    class Meta:
        verbose_name = _("Agent")
        verbose_name_plural = _("Agents")
        ordering = ("nom",)

    def __str__(self):
        return self.nom

    # ------------------------------------------------------------------ #
    #  État
    # ------------------------------------------------------------------ #
    @property
    def expire(self):
        return bool(self.expire_le and self.expire_le <= timezone.now())

    @property
    def utilisable(self):
        """Actif, non expiré, et son compte porteur n'est pas désactivé."""
        return bool(self.actif and not self.expire and self.user and self.user.is_active)

    @property
    def raison_de_refus(self):
        """
        Pourquoi cet agent serait refusé, en clair, pour l'écran d'administration.

        Ce texte ne sort JAMAIS par l'API : dire à un appelant *pourquoi* son
        jeton ne passe pas lui apprend l'état du système.
        """
        if not self.actif:
            return _("désactivé")
        if self.expire:
            return _("expiré")
        if self.user and not self.user.is_active:
            return _("compte porteur désactivé")
        return ""

    def liste_ips(self):
        return [
            ligne.strip()
            for ligne in (self.ips_autorisees or "").splitlines()
            if ligne.strip()
        ]

    def ip_autorisee(self, ip):
        autorisees = self.liste_ips()
        return True if not autorisees else ip in autorisees

    def jetons_actifs(self):
        return self.jetons.filter(revoque_le__isnull=True)


class AgentToken(models.Model):
    """
    Un jeton d'accès. Plusieurs par agent, pour permettre une rotation sans
    coupure : on crée le nouveau, on bascule l'appelant, on révoque l'ancien.
    """

    agent = models.ForeignKey(
        Agent, on_delete=models.CASCADE, related_name="jetons", verbose_name=_("Agent")
    )

    #: Partie publique, celle qui permet de retrouver la ligne sans balayer la
    #: table — et sans comparer une empreinte contre chaque enregistrement.
    prefixe = models.CharField(_("Préfixe"), max_length=32, unique=True, db_index=True)

    #: SHA-256 du secret. Le secret lui-même n'existe qu'une fois, à l'écran.
    empreinte = models.CharField(_("Empreinte"), max_length=64)

    libelle = models.CharField(
        _("Libellé"),
        max_length=150,
        blank=True,
        default="",
        help_text=_("À quoi sert ce jeton — « poste de Guillaume », « CI »…"),
    )

    cree_le = models.DateTimeField(_("Créé le"), auto_now_add=True)
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="jetons_agents_crees",
        verbose_name=_("Créé par"),
    )

    revoque_le = models.DateTimeField(_("Révoqué le"), null=True, blank=True)
    derniere_utilisation_le = models.DateTimeField(
        _("Dernier appel"), null=True, blank=True
    )

    class Meta:
        verbose_name = _("Jeton d'agent")
        verbose_name_plural = _("Jetons d'agent")
        ordering = ("-cree_le",)

    def __str__(self):
        return f"{self.agent.nom} — {self.prefixe}"

    @property
    def revoque(self):
        return self.revoque_le is not None

    def revoquer(self):
        if not self.revoque:
            self.revoque_le = timezone.now()
            self.save(update_fields=["revoque_le"])

    @classmethod
    def creer(cls, agent, *, libelle="", cree_par=None):
        """
        Fabrique un jeton et renvoie `(objet, jeton_en_clair)`.

        Le jeton en clair est la SEULE occasion de le lire. L'appelant doit le
        montrer à l'exploitant et ne pas l'enregistrer.

        La boucle sur la collision de préfixe est théorique — 48 bits — mais
        une contrainte d'unicité qui lève en production sur un tirage au sort
        est exactement le genre de panne qu'on ne sait pas reproduire.
        """
        from django.db import IntegrityError

        for __ in range(5):
            prefixe, secret, en_clair = jetons.fabriquer()
            try:
                objet = cls.objects.create(
                    agent=agent,
                    prefixe=prefixe,
                    empreinte=jetons.empreinte(secret),
                    libelle=libelle,
                    cree_par=cree_par,
                )
            except IntegrityError:
                continue
            return objet, en_clair

        raise RuntimeError("Impossible de tirer un préfixe de jeton libre.")


class AppelAgent(models.Model):
    """
    Journal des appels. Un agent qui modifie un site sans laisser de trace est
    un agent dont on ne peut pas expliquer le travail après coup.

    On enregistre ce qui a été demandé et ce qui a été répondu — jamais le
    corps de la requête, qui peut être volumineux et contenir n'importe quoi.
    """

    agent = models.ForeignKey(
        Agent,
        on_delete=models.CASCADE,
        related_name="appels",
        null=True,
        blank=True,
        verbose_name=_("Agent"),
    )
    prefixe_jeton = models.CharField(
        _("Préfixe du jeton"), max_length=32, blank=True, default=""
    )

    methode = models.CharField(_("Méthode"), max_length=10)
    chemin = models.CharField(_("Chemin"), max_length=300)
    statut = models.PositiveSmallIntegerField(_("Code de réponse"))

    #: Renseigné quand l'appel est refusé. Codé, pas rédigé : il sert à
    #: l'exploitant, jamais à l'appelant.
    motif_refus = models.CharField(
        _("Motif de refus"), max_length=60, blank=True, default=""
    )

    ip = models.GenericIPAddressField(_("Adresse IP"), null=True, blank=True)
    horodatage = models.DateTimeField(_("Le"), default=timezone.now, db_index=True)

    class Meta:
        verbose_name = _("Appel d'agent")
        verbose_name_plural = _("Appels d'agents")
        ordering = ("-horodatage",)
        indexes = [models.Index(fields=["agent", "-horodatage"])]

    def __str__(self):
        return f"{self.methode} {self.chemin} → {self.statut}"


# --------------------------------------------------------------------------- #
#  OAuth — brancher un agent sur claude.ai et l'app mobile (P-04)
# --------------------------------------------------------------------------- #
class ClientOAuth(models.Model):
    """
    Un client qui s'est déclaré par l'enregistrement dynamique (RFC 7591) :
    claude.ai, l'app Claude, Claude Code. Client PUBLIC — il ne reçoit aucun
    secret, c'est le PKCE qui protège l'échange. Voir `oauth.py`.
    """

    client_id = models.CharField(_("Identifiant"), max_length=64, unique=True)
    nom = models.CharField(_("Nom annoncé"), max_length=120, blank=True, default="")
    #: Les adresses où un code peut être renvoyé, déjà filtrées par
    #: `oauth.retour_admis` : jamais une adresse libre.
    adresses_de_retour = models.JSONField(_("Adresses de retour"), default=list)
    cree_le = models.DateTimeField(_("Enregistré le"), auto_now_add=True, db_index=True)

    class Meta:
        verbose_name = _("Client OAuth")
        verbose_name_plural = _("Clients OAuth")
        ordering = ("-cree_le",)

    def __str__(self):
        return self.nom or self.client_id


class CodeOAuth(models.Model):
    """
    Un code d'autorisation, et la trace du consentement : qui a autorisé quel
    client à agir comme quel agent, et quand.

    Le code lui-même n'est jamais stocké, seulement son empreinte — comme les
    jetons. Il ne sert qu'une fois (`utilise_le`) et vit dix minutes.
    """

    empreinte_code = models.CharField(_("Empreinte du code"), max_length=64, unique=True)
    client = models.ForeignKey(
        ClientOAuth, on_delete=models.CASCADE, related_name="codes", verbose_name=_("Client"),
    )
    agent = models.ForeignKey(
        Agent, on_delete=models.CASCADE, related_name="codes_oauth", verbose_name=_("Agent"),
    )
    autorise_par = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="autorisations_oauth", verbose_name=_("Autorisé par"),
    )
    adresse_de_retour = models.CharField(_("Adresse de retour"), max_length=500)
    defi_pkce = models.CharField(_("Défi PKCE"), max_length=128)
    ressource = models.CharField(_("Ressource demandée"), max_length=300, blank=True, default="")
    cree_le = models.DateTimeField(_("Créé le"), auto_now_add=True)
    utilise_le = models.DateTimeField(_("Échangé le"), null=True, blank=True)
    #: Le jeton délivré contre ce code. Un code présenté deux fois est un code
    #: volé : on révoque alors ce jeton (voir `oauth.jeton`).
    jeton = models.ForeignKey(
        AgentToken, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="codes_oauth", verbose_name=_("Jeton délivré"),
    )

    class Meta:
        verbose_name = _("Autorisation OAuth")
        verbose_name_plural = _("Autorisations OAuth")
        ordering = ("-cree_le",)

    def __str__(self):
        return f"{self.client} → {self.agent}"
