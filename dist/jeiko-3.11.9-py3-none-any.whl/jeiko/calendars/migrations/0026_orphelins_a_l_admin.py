"""
Les types de rendez-vous et les disponibilités SANS propriétaire — créés par
l'API des agents avant le multi-agenda (27/10/2026), ou par un modèle de site
— n'apparaissent dans l'agenda de personne : les écrans ne montrent à chacun
que les siens. Décision de Guillaume : « au seul admin du site ».

L'admin, c'est le plus ancien superuser actif. Sans superuser, rien ne bouge :
mieux vaut un orphelin visible des superviseurs qu'un agenda attribué au
hasard. Ne touche à rien qui a déjà un propriétaire.
"""
from django.conf import settings
from django.db import migrations


def a_l_admin(apps, schema_editor):
    User = apps.get_model(*settings.AUTH_USER_MODEL.split("."))
    admin = User.objects.filter(is_superuser=True, is_active=True).order_by("date_joined", "pk").first()
    if admin is None:
        return
    for modele in ("AppointmentType", "Availability"):
        apps.get_model("calendars", modele).objects.filter(user__isnull=True).update(user=admin)


class Migration(migrations.Migration):

    dependencies = [
        ("calendars", "0025_duree_bloquee"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.RunPython(a_l_admin, migrations.RunPython.noop),
    ]
