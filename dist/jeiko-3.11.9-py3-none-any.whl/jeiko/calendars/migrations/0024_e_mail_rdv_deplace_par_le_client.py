"""
`appointment_rescheduled_admin` : le praticien apprend que le client a
déplacé son rendez-vous depuis le lien de son e-mail (26/10/2026). Pose son
contenu par défaut s'il manque, sans rien écraser.
"""
from django.db import migrations


def poser(apps, schema_editor):
    from jeiko.emailing.builder import apply_seed

    apply_seed("appointment_rescheduled_admin", force=False)


class Migration(migrations.Migration):
    dependencies = [
        ("calendars", "0023_type_en_visio"),
        ("emailing", "0023_fond_des_boutons"),
    ]
    operations = [migrations.RunPython(poser, migrations.RunPython.noop)]
