"""
Réglages › Réglages avancés (A-81) : durées de conservation, délais,
plafonds, référencement. Chaque champ montre la valeur qui S'APPLIQUE
aujourd'hui ; vide, il la laisse (le .env, sinon le défaut). Voir
jeiko/reglages_avances.py.
"""
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import redirect, render
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _
from django.views import View
from django.views.decorators.cache import never_cache

from jeiko import reglages_avances as ra

from .models import WebSite
from .website_cache import invalidate_website_data

#: Défauts du code, pour montrer « ce qui s'applique » quand rien n'est réglé.
_DEFAUTS = {"journal_securite_jours": 365, "sessions_jours": 30, "comptes_non_verifies_jours": 30,
            "contacts_jours": 1095, "paiement_rdv_minutes": 20, "liste_attente_minutes": 30,
            "stock_bas": None, "image_mo": 10, "pdf_mo": 25, "masquer_aux_moteurs": False}


def _en_vigueur(cle):
    if cle in ("agents_appels_heure", "agents_echecs_ip"):
        from jeiko.agents.authentification import plafonds
        return plafonds()["jeton" if cle == "agents_appels_heure" else "echecs_ip"][0]
    return ra.valeur(cle, _DEFAUTS.get(cle))


def _champs(site, erreurs=None, saisies=None):
    reglees = site.reglages_avances or {}
    groupes = {}
    for cle, (_s, groupe, libelle, aide, minimum, maximum) in ra.CATALOGUE.items():
        groupes.setdefault(str(groupe), []).append({
            "cle": cle, "libelle": libelle, "aide": aide, "booleen": minimum is None and maximum is None,
            "minimum": minimum, "maximum": maximum,
            "valeur": (saisies or {}).get(cle, reglees.get(cle, "")),
            "en_vigueur": _en_vigueur(cle), "reglee": cle in reglees,
        })
    return groupes


@method_decorator(never_cache, name="dispatch")
class ReglagesAvances(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = "users.config_edit_site"
    raise_exception = True
    template_name = "administration/reglages_avances.html"

    def get(self, request):
        site = WebSite.objects.first()
        if site is None:
            return redirect("jeiko_administration:main")
        return render(request, self.template_name, {"groupes": _champs(site)})

    def post(self, request):
        site = WebSite.objects.first()
        if site is None:
            return redirect("jeiko_administration:main")
        nouveaux, erreurs, saisies = {}, [], {}
        for cle, (_s, _g, _l, _a, minimum, maximum) in ra.CATALOGUE.items():
            if minimum is None and maximum is None:
                # Une case : « réglée » seulement si on l'a touchée — sinon le .env garde la main.
                if request.POST.get(f"{cle}__regle") == "1":
                    nouveaux[cle] = request.POST.get(cle) == "on"
                continue
            brut = (request.POST.get(cle) or "").strip()
            saisies[cle] = brut
            try:
                propre = ra.valider(cle, brut)
            except ValueError as souci:
                erreurs.append(str(souci))
                continue
            if propre is not None:
                nouveaux[cle] = propre
        if erreurs:
            for e in erreurs:
                messages.error(request, e)
            return render(request, self.template_name, {"groupes": _champs(site, saisies=saisies)}, status=400)
        site.reglages_avances = nouveaux
        site.save(update_fields=["reglages_avances"])
        invalidate_website_data()
        messages.success(request, _("Réglages avancés enregistrés."))
        return redirect("jeiko_administration:reglages_avances")
