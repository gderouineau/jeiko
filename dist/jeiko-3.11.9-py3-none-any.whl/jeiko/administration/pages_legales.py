"""
Les pages légales — mentions légales, CGU, CGV, confidentialité (LEG-01).

Le problème
-----------
Leurs textes étaient posés par dix MIGRATIONS de données (`administration`
0008 à 0016, 0025 : 3 500 lignes). Changer une phrase obligeait à écrire une
migration de plus, qui fouillait les pages pour retrouver son paragraphe — et
ne pouvait rien pour une page retouchée. Ces migrations ne font plus rien.

Ce que fait ce module
---------------------
* Les textes sont des DONNÉES (`textes_legaux/pages_legales.fr.json`), au
  format de l'API des agents, construits par les mêmes fonctions (mêmes
  refus, même assainissement) — comme le kit du site de départ.
* Les clés `[%cle%]` du texte prennent l'information du site
  (`informations_du_site` : raison sociale, adresse, SIRET, TVA, contact —
  l'identité de facturation d'abord, puis l'identité du site) ; une
  information absente laisse la mention à compléter, « [Nom de la société] ».
* `poser_les_manquantes` : un site neuf reçoit ses quatre pages (appelé par
  le site de départ). Une page qui existe n'est jamais touchée.
* `mettre_a_jour_les_informations` : refait les pages JAMAIS retouchées
  (`is_default_legal_template`, qui passe à faux à la première
  modification), avec le texte à jour et les informations du moment. Rien de
  ce que l'exploitant a écrit ne peut s'y perdre.
* `appliquer_le_modele` : remplace UNE page, même retouchée, par le modèle à
  jour — à la demande expresse de l'exploitant ; l'état remplacé entre
  d'abord dans l'historique de la page (HIST-01), d'où on le restaure.

Ce qu'il ne fait pas
--------------------
* Rien d'automatique sur un site en service : sans geste de l'exploitant, ses
  pages légales restent exactement ce qu'elles sont.
* Pas de traduction : les pages légales restent en français (L-14).
* L'hébergeur, le médiateur, l'assureur ne sont connus nulle part : leurs
  mentions restent à compléter.
"""

import json
import logging
from pathlib import Path

from django.db import transaction
from django.utils import timezone

logger = logging.getLogger(__name__)

FICHIER = Path(__file__).resolve().parent / "textes_legaux" / "pages_legales.fr.json"


class TexteLegalIntrouvable(Exception):
    """Le fichier des textes manque (paquet publié sans lui)."""


def textes():
    try:
        return json.loads(FICHIER.read_text(encoding="utf-8"))
    except FileNotFoundError as souci:
        raise TexteLegalIntrouvable(str(FICHIER)) from souci


def _une_ligne(adresse):
    return ", ".join(p.strip() for p in (adresse or "").splitlines() if p.strip())


def informations_du_site():
    """{clé: valeur} de ce que le site sait de lui-même ; une clé vide n'est pas connue."""
    from jeiko.administration.models import WebSite
    from jeiko.shop.models import ShopSettings

    site = WebSite.objects.select_related("identity", "mail_settings").first()
    identite = getattr(site, "identity", None)
    boutique = ShopSettings.get_solo()
    adresse_du_site = ", ".join(x for x in (
        getattr(identite, "street_address", ""),
        " ".join(y for y in (getattr(identite, "postal_code", ""), getattr(identite, "address_locality", "")) if y),
    ) if x)
    courrier = getattr(site, "mail_settings", None)
    return {
        "raison_sociale": boutique.billing_name or getattr(identite, "name", "") or getattr(site, "name", "") or "",
        "forme_juridique": boutique.billing_legal,
        "adresse": _une_ligne(boutique.billing_address) or adresse_du_site,
        "siret": boutique.siret,
        "tva": boutique.vat_number,
        # L'adresse de RÉPONSE avant l'expéditeur : celui-ci est souvent un
        # no-reply, et les mentions légales publiaient « no-reply@… » comme
        # contact (vu sur kojei.fr le 21/10/2026). C'est aussi la boîte où
        # arrivent les messages des formulaires.
        "email": (boutique.billing_email or getattr(courrier, "reply_to_email", "")
                  or getattr(courrier, "default_from_email", "") or ""),
        "telephone": boutique.billing_phone or getattr(identite, "telephone", "") or "",
    }


def _adresse_absolue(page):
    from jeiko.emailing.render import site_base_url

    return f"{site_base_url()}{page.get_absolute_url()}" if page else ""


def _remplir(valeur, valeurs, defauts):
    """Les clés [%cle%] de chaque texte de `valeur` (dict, liste, chaîne), remplacées
    par l'information échappée, ou par la mention à compléter."""
    from django.utils.html import escape

    if isinstance(valeur, dict):
        return {k: _remplir(v, valeurs, defauts) for k, v in valeur.items()}
    if isinstance(valeur, list):
        return [_remplir(v, valeurs, defauts) for v in valeur]
    if isinstance(valeur, str):
        for cle, defaut in defauts.items():
            valeur = valeur.replace(f"[%{cle}%]", escape(valeurs.get(cle) or defaut))
    return valeur


def _valeurs(legals):
    valeurs = informations_du_site()
    valeurs["url_cgv"] = _adresse_absolue(legals.cgv_page)
    valeurs["url_confidentialite"] = _adresse_absolue(legals.privacy_page)
    valeurs["date"] = timezone.localdate().strftime("%d/%m/%Y")
    return valeurs


def _legals():
    from jeiko.administration.models import Legals, WebSite

    site = WebSite.objects.first()
    if site is None:
        site = WebSite.objects.create()
    return Legals.objects.get_or_create(site=site)[0]


def _categorie(declaration):
    from jeiko.administration_pages.models import Category

    categorie = Category.objects.filter(hidden_slug=declaration["hidden_slug"], main_category=None).first()
    if categorie is None:
        categorie = Category.objects.create(name=declaration["nom"], main_category=None,
                                            hidden_slug=declaration["hidden_slug"], is_protected=True)
    return categorie


def _construire(page, document, valeurs, defauts):
    """Le contenu de `page` refait depuis sa déclaration (ses sections d'avant sont effacées)."""
    from jeiko.administration_pages.signals import construction_de_pages
    from jeiko.agents.vues_api import CorpsInvalide
    from jeiko.agents.vues_pages import _appliquer_metadonnees, _Construction

    sections = _remplir(document["sections"], valeurs, defauts)
    # Les signaux des pages cherchent, à chaque boîte de style enregistrée, la
    # page qui la porte : 2 300 recherches pour quatre pages, une vingtaine de
    # secondes. On SAIT quelle page on construit (signals.construction_de_pages).
    with construction_de_pages([page.pk]):
        page.sections.all().delete()
        construction = _Construction()
        try:
            if document.get("metadonnees"):
                _appliquer_metadonnees(page, document["metadonnees"])
            for n, section in enumerate(sections):
                construction.section(page, section, f"{document['cle']}.sections[{n}]")
        except CorpsInvalide as souci:
            raise ValueError(f"Texte légal « {document['cle']} » : {souci}") from souci
    # La sortie du bloc a planifié, au commit, le marquage « retouchée » que
    # subit toute page modifiée. Elle est le modèle : on le redit APRÈS lui.
    transaction.on_commit(lambda: type(page).tous.filter(pk=page.pk).update(is_default_legal_template=True))


def poser_les_manquantes():
    """Crée les pages légales qui manquent (site neuf). Rend le nombre de pages créées."""
    from jeiko.administration_pages.models import Page

    kit = textes()
    with transaction.atomic():
        legals = _legals()
        categorie = _categorie(kit["categorie"])
        crees = []
        for document in kit["pages"]:
            if getattr(legals, document["lien"]) is not None:
                continue
            page = Page.objects.filter(url_tag=document["url_tag"], traduction_de__isnull=True).first()
            if page is None:
                page = Page.objects.create(title=document["titre"], url_tag=document["url_tag"], active=True,
                                           category=categorie, is_protected=True, is_default_legal_template=True)
                crees.append((page, document))
            setattr(legals, document["lien"], page)
        legals.save()
        # Après les liens : une page cite l'adresse des CGV et de la confidentialité.
        valeurs = _valeurs(legals)
        for page, document in crees:
            _construire(page, document, valeurs, kit["infos"])
    return len(crees)


def etat():
    """[(document, page, retouchee)] pour l'écran : chaque page légale et son état."""
    legals = _legals()
    return [(document, getattr(legals, document["lien"]),
             bool(getattr(legals, document["lien"]) and not getattr(legals, document["lien"]).is_default_legal_template))
            for document in textes()["pages"]]


def mettre_a_jour_les_informations():
    """Refait les pages jamais retouchées avec le texte et les informations du moment. Rend leur nombre."""
    kit = textes()
    with transaction.atomic():
        legals = _legals()
        valeurs = _valeurs(legals)
        faites = 0
        for document in kit["pages"]:
            page = getattr(legals, document["lien"])
            if page is None or not page.is_default_legal_template:
                continue
            _construire(page, document, valeurs, kit["infos"])
            faites += 1
    return faites


def appliquer_le_modele(cle, *, auteur=None):
    """Remplace la page `cle` par le modèle à jour ; l'état remplacé entre dans l'historique."""
    from jeiko.administration_pages import historique

    kit = textes()
    document = next((d for d in kit["pages"] if d["cle"] == cle), None)
    if document is None:
        raise KeyError(cle)
    with transaction.atomic():
        legals = _legals()
        page = getattr(legals, document["lien"])
        if page is None:
            poser_les_manquantes()
            return getattr(_legals(), document["lien"])
        if historique.a_un_historique(page):
            historique.capturer(page, motif=historique.Motif.AVANT_MODELE_LEGAL, auteur=auteur)
        _construire(page, document, _valeurs(legals), kit["infos"])
    return page
