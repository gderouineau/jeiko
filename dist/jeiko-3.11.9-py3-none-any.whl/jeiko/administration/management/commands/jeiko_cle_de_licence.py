"""
La clé de licence du site (LIC-01), sur une ligne — lue par
/usr/local/sbin/jeiko-client-update avant chaque mise à jour, sous le compte
du site : le serveur demande au site plutôt que de lire sa base. Une ligne
vide s'il n'en a pas. jeiko-client-update ne fait pas confiance à cette
sortie : il la borne à la forme d'une clé avant de l'envoyer.
"""

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Clé de licence du site, sur une ligne (lue par jeiko-client-update)."
    requires_system_checks = []

    def handle(self, *args, **options):
        from jeiko.administration.models import WebSite

        site = WebSite.objects.first()
        self.stdout.write(site.licence_cle if site is not None else "")
