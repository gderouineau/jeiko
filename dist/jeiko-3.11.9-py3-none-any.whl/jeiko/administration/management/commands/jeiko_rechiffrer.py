"""
Rechiffrer tous les secrets avec la clé actuelle (F07).

Après un changement de `SECRET_KEY` (l'ancienne dans `SECRET_KEY_FALLBACKS`,
site redémarré), chaque secret est relu — par l'ancienne clé — puis
réenregistré par la nouvelle. Ensuite seulement, l'ancienne clé peut quitter
le `.env`.

Ce qu'elle ne fait JAMAIS : réenregistrer une valeur qu'aucune clé ne
déchiffre. La bibliothèque rend alors le texte chiffré tel quel ;
l'enregistrer le chiffrerait une seconde fois, et le secret serait perdu pour
de bon. Ces valeurs sont comptées et nommées : retrouver l'ancienne clé, ou
ressaisir le secret à l'écran.
"""
from django.core.management.base import BaseCommand
from django.db import transaction


class Command(BaseCommand):
    help = "Rechiffre tous les secrets avec la SECRET_KEY actuelle (après une rotation)."

    def add_arguments(self, parser):
        parser.add_argument("--simulation", action="store_true", help="Compter sans rien écrire.")

    def handle(self, *args, **options):
        from jeiko.encrypted import champs_chiffres, illisible

        total, illisibles = 0, []
        for modele, champ in champs_chiffres():
            # Le gestionnaire de base : les pages cachées, brouillons… comprises.
            lignes = modele._base_manager.only(modele._meta.pk.name, champ.attname)
            for ligne in lignes.iterator():
                valeur = getattr(ligne, champ.attname)
                if valeur in (None, "", {}, []):
                    continue
                if illisible(champ, valeur):
                    illisibles.append(f"{modele._meta.label}.{champ.name} #{ligne.pk}")
                    continue
                if not options["simulation"]:
                    with transaction.atomic():
                        modele._base_manager.filter(pk=ligne.pk).update(**{champ.attname: valeur})
                total += 1
        verbe = "à rechiffrer" if options["simulation"] else "rechiffré(s)"
        self.stdout.write(self.style.SUCCESS(f"{total} secret(s) {verbe}."))
        if illisibles:
            self.stderr.write(f"{len(illisibles)} secret(s) illisible(s), laissé(s) tel(s) quel(s) — retrouver "
                              "l'ancienne clé (SECRET_KEY_FALLBACKS) ou les ressaisir à l'écran :")
            for nom in illisibles:
                self.stderr.write(f"  {nom}")
