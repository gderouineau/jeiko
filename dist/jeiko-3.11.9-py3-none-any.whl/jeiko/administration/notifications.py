"""
Les pastilles de notification du menu de l'administration (NOTIF-01).

Le besoin (Guillaume, 12/10/2026) : « si stock bas, une petite notification
sur le menu Boutique, qui amène au produit » ; pareil pour les nouvelles
personnes qui ont passé un questionnaire, les nouvelles commandes, les
nouveaux rendez-vous ; les notifications regroupées dans « Général » ; et
pouvoir les activer et les désactiver.

Deux natures de compteur :
* un ÉTAT à traiter — stock bas, commandes payées à préparer. Il dure tant
  que la chose n'est pas faite, quelle que soit la personne qui regarde ;
* du NOUVEAU depuis la dernière visite de CETTE personne sur la liste —
  rendez-vous pris, résultats de questionnaire, membres inscrits, messages
  reçus. Ouvrir la liste le remet à zéro (`NotificationVue`, posée par
  `admin_nav.build_nav`). Jamais venue : les sept derniers jours.

Chaque compteur respecte le droit de voir sa liste et le module qui la
porte (MOD-01) ; un compteur éteint dans Réglages › Général ne coûte aucune
requête. Les nombres d'une personne sont gardés une minute en cache : le
menu se rend à chaque page.

Les agents lisent les mêmes compteurs, et leur détail, par l'API
(`agents/vues_nouveautes.py`) — sans rien marquer « vu ».

Ce que ça ne fait pas : prévenir hors de l'administration (e-mail, push).
Les e-mails d'alerte existent à part (stock bas, nouvelle commande…).
"""
import logging
from datetime import timedelta

from django.core.cache import cache
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

logger = logging.getLogger(__name__)

ETAT, NOUVEAU = "etat", "nouveau"

#: code → (libellé, nature, permission, module, vue de la liste).
NOTIFICATIONS = {
    "stock_bas": (_("Stock bas"), ETAT, "shop.view_product", "boutique",
                  "jeiko_administration_shop:product_list_all"),
    "commandes": (_("Commandes à préparer"), ETAT, "shop.view_order", "boutique",
                  "jeiko_shop_admin_orders:order_list"),
    "rendez_vous": (_("Nouveaux rendez-vous"), NOUVEAU, "calendars.view_appointment", "rendez_vous",
                    "jeiko_administration_calendars:appointment_list_upcoming"),
    "questionnaires": (_("Nouveaux résultats de questionnaire"), NOUVEAU, "questionnaires_expert.view_prospect",
                       "questionnaires", "jeiko_administration_questionnaires_expert:prospect_list"),
    "membres": (_("Nouveaux membres"), NOUVEAU, "auth.view_user", None,
                "jeiko_administration_users:user_list"),
    "messages": (_("Nouveaux messages"), NOUVEAU, "administration_pages.view_contentformsubmission", None,
                 "jeiko_administration_pages:form_submissions"),
    # VISIO-01 : quelqu'un attend en salle d'attente d'une séance.
    "visio_attente": (_("Personnes en salle d'attente (visio)"), ETAT, "visio.view_salle", "visio",
                      "jeiko_visio_admin:seances"),
}

#: Jamais venue sur la liste : ce qui est arrivé ces derniers jours compte.
FENETRE_INITIALE = timedelta(days=7)
CACHE_SECONDES = 60


def actives(site=None):
    """{code: bool} — une notification absente des réglages est allumée."""
    if site is None:
        try:
            from jeiko.administration.website_cache import get_website_data
            site = get_website_data()
        except Exception:
            site = None
    reglees = (getattr(site, "notifications", None) or {}) if site is not None else {}
    return {code: bool(reglees.get(code, True)) for code in NOTIFICATIONS}


def _cle(user):
    # La génération change à chaque commande enregistrée (`oublier_les_compteurs`) :
    # une commande passée « En traitement » ou « Terminée » éteint sa pastille
    # tout de suite, pour tout le monde, sans attendre la fin du cache.
    return f"jeiko:notifications:{cache.get(GENERATION, 0)}:{user.pk}"


GENERATION = "jeiko:notifications:generation"


def oublier_les_compteurs():
    try:
        cache.incr(GENERATION)
    except ValueError:
        cache.set(GENERATION, 1, None)


def produits_en_stock_bas():
    """
    Les produits sous leur seuil — pour la pastille ET l'alerte par e-mail
    (emailing/admin_alerts.py), qui comptent ainsi les mêmes.

    Un produit qui ne s'épuise pas n'a pas de rupture possible. Deux
    conditions, et la seconde manquait autrefois : le dépassement autorisé
    (`allow_negative_stock`) est un réglage, mais c'est la NATURE du produit
    qui décide vraiment — un abonnement à stock zéro déclenchait une alerte
    « rupture » à chaque passage. Même critère que le panier et le JSON-LD :
    `type__requires_shipping`. Seuil saisi sur le produit (NULL : il n'en veut
    pas), sinon le repli global des Réglages avancés, s'il y en a un.
    """
    from django.db.models import F, Q

    from jeiko.emailing.admin_alerts import _seuil_stock_par_defaut
    from jeiko.shop.models import Product

    condition = Q(stock_alert_threshold__isnull=False, stock_quantity__lte=F("stock_alert_threshold"))
    defaut = _seuil_stock_par_defaut()
    if defaut is not None:
        condition |= Q(stock_alert_threshold__isnull=True, stock_quantity__lte=defaut)
    return (Product.objects.filter(is_active=True, allow_negative_stock=False, type__requires_shipping=True)
            .filter(condition).select_related("content", "type").order_by("stock_quantity"))


def _depuis(user, code):
    from .models import NotificationVue

    vue = NotificationVue.objects.filter(user=user, code=code).values_list("vu_le", flat=True).first()
    return vue or (timezone.now() - FENETRE_INITIALE)


def objets(code, user, depuis=None):
    """
    Ce que compte la notification `code` pour `user`, en requête : la pastille
    en prend le nombre, l'API des agents (`lister_nouveautes`) le détail — les
    deux disent donc la même chose. `depuis` remplace la dernière visite pour
    le NOUVEAU ; un ÉTAT l'ignore. Ne vérifie ni droit ni module : `visibles`.
    """
    from django.contrib.auth import get_user_model

    if code == "stock_bas":
        return produits_en_stock_bas()
    if code == "visio_attente":
        from jeiko.visio.acces import ATTENTE_VIVANTE
        from jeiko.visio.models import Invitation

        return Invitation.objects.filter(revoquee_le__isnull=True, admise=False, salle__terminee_le__isnull=True,
                                         attente_vue_le__gte=timezone.now() - ATTENTE_VIVANTE
                                         ).select_related("salle").order_by("attente_vue_le")
    if code == "commandes":
        from jeiko.shop.models import Order

        # « À préparer » : payée et pas encore prise en main. Passée « En
        # traitement », quelqu'un s'en occupe : elle ne compte plus (Guillaume).
        return Order.objects.filter(payment_status=Order.PAYMENT_STATUS_PAID,
                                    order_status=Order.ORDER_STATUS_CONFIRMED).select_related("user").order_by("created_at")
    depuis = depuis or _depuis(user, code)
    if code == "rendez_vous":
        from jeiko.calendars.mixins import is_calendar_supervisor
        from jeiko.calendars.models import Appointment

        rdv = Appointment.objects.active().filter(created__gt=depuis)
        if not is_calendar_supervisor(user):
            rdv = rdv.filter(type__user=user)
        return rdv.select_related("type").order_by("-created")
    if code == "questionnaires":
        from jeiko.questionnaires_expert.models import ExpertTestData

        return (ExpertTestData.objects.filter(created_at__gt=depuis)
                .select_related("test", "prospect", "result_profile").order_by("-created_at"))
    if code == "membres":
        return get_user_model().objects.filter(date_joined__gt=depuis).exclude(pk=user.pk).order_by("-date_joined")
    if code == "messages":
        from jeiko.administration_pages.models import ContentFormSubmission

        return (ContentFormSubmission.objects.filter(submitted_at__gt=depuis, is_spam=False)
                .select_related("formulaire").order_by("-submitted_at"))
    raise KeyError(code)


def visibles(user):
    """Les codes des notifications allumées que `user` a le droit de voir, modules compris."""
    from jeiko.administration.modules import module_actif

    for code, allumee in actives().items():
        _libelle, _nature, perm, module, _vue = NOTIFICATIONS[code]
        if allumee and user.has_perm(perm) and not (module and not module_actif(module)):
            yield code


def compteurs(user):
    """{code: nombre} des notifications allumées que `user` a le droit de voir. Ne lève jamais."""
    if not getattr(user, "is_authenticated", False):
        return {}
    en_cache = cache.get(_cle(user))
    if en_cache is not None:
        return en_cache
    resultat = {}
    for code in visibles(user):
        try:
            resultat[code] = objets(code, user).count()
        except Exception:
            # Un compteur en panne ne doit pas empêcher le menu de s'afficher.
            logger.warning("Notification « %s » non comptée", code, exc_info=True)
    cache.set(_cle(user), resultat, CACHE_SECONDES)
    return resultat


def marquer_vue(user, code):
    """La personne vient d'ouvrir la liste : ce qui était nouveau ne l'est plus."""
    from .models import NotificationVue

    if code not in NOTIFICATIONS or NOTIFICATIONS[code][1] != NOUVEAU or not getattr(user, "is_authenticated", False):
        return
    NotificationVue.objects.update_or_create(user=user, code=code, defaults={"vu_le": timezone.now()})
    cache.delete(_cle(user))
