"""
Pages légales — ne fait plus rien (LEG-01, 14/10/2026).

Cette migration posait ou retouchait le texte d'une page légale. Les textes
sont désormais des données (`administration/textes_legaux/`), posées par
`administration/pages_legales.py` : à la création d'un site (site de départ)
et, sur un site en service, quand l'exploitant le choisit (Pages légales). La
migration reste pour l'historique des migrations des sites ; vide, elle ne
touche à rien sur un site neuf, une base de test ou un site en service.
"""
from django.db import migrations


def create_mentions_legales(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ('administration_pages', '0025_category_hidden_slug'),
        ('administration', '0008_seed_legals_pages'),
    ]

    operations = [
        migrations.RunPython(create_mentions_legales, migrations.RunPython.noop),
    ]
