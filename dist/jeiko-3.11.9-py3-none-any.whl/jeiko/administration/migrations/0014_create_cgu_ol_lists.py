"""
Pages légales — ne fait plus rien (LEG-01, 14/10/2026).

Cette migration posait ou retouchait le texte d'une page légale. Les textes
sont désormais des données (`administration/textes_legaux/`), posées par
`administration/pages_legales.py` : à la création d'un site (site de départ)
et, sur un site en service, quand l'exploitant le choisit (Pages légales). La
migration reste pour l'historique des migrations des sites ; vide, elle ne
touche à rien sur un site neuf, une base de test ou un site en service.
"""
from django.db import migrations


def create_cgu(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        # le champ Page.is_protected
        ('administration_pages', '0028_page_is_protected'),
        # dépend de la migration que tu viens de relancer pour Mentions légales
        ('administration', '0013_update_mentions_legales_ol_lists'),
    ]

    operations = [
        migrations.RunPython(create_cgu, migrations.RunPython.noop),
    ]
