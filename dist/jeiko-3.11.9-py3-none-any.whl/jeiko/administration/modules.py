"""
Les modules du site : ce qu'on VOIT dans le menu de l'administration (MOD-01).

Le besoin (Guillaume, 12/10/2026) : un site qui ne vend rien ne doit pas
traîner une section « Boutique » de douze entrées — ni « Formations »,
« Questionnaires » ou « Rendez-vous » s'il ne s'en sert pas. « En gros ça
cache juste dans le menu. »

Ce que fait un module éteint : sa section disparaît du menu de
l'administration (admin_nav.py), et les entrées qui en dépendent ailleurs
(CRM › Prospects des questionnaires).

Ce qu'il ne fait PAS, à dessein : désinstaller, interdire ou effacer. Les
applications restent dans INSTALLED_APPS, les écrans répondent à leur adresse,
le site public (fiches produit, réservation, formations) et l'API des agents
restent tels quels. Masquer n'est pas interdire : rallumer un module rend le
menu à l'identique, sans rien avoir perdu.
"""
from django.utils.translation import gettext_lazy as _

#: code → (champ de WebSite, libellé). L'ordre est celui de l'écran.
MODULES = {
    "boutique": ("module_boutique", _("Boutique")),
    "rendez_vous": ("module_rendez_vous", _("Rendez-vous et calendriers")),
    "formations": ("module_formations", _("Formations")),
    "questionnaires": ("module_questionnaires", _("Questionnaires")),
    "visio": ("module_visio", _("Conférence")),
}


def module_actif(code, site=None):
    """Vrai si le module est allumé — et par défaut, faute de site ou de code connu."""
    if code not in MODULES:
        return True
    if site is None:
        try:
            from jeiko.administration.website_cache import get_website_data
            site = get_website_data()
        except Exception:
            return True
    return bool(getattr(site, MODULES[code][0], True)) if site is not None else True


def etat_des_modules(site):
    return {code: bool(getattr(site, champ, True)) for code, (champ, _l) in MODULES.items()}
