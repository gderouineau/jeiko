"""
Recevoir et lire les signalements de la protection des scripts (S-03, 09/10/2026).

Le navigateur de chaque visiteur poste ici, sans compte, ce que la CSP
(« Report-Only ») aurait bloqué. Un point d'entrée PUBLIC qui écrit en base :
- corps de 16 Ko au plus ; au-delà, ignoré ;
- 60 signalements par minute et par adresse IP (jeiko.throttling) ;
- agrégé : une ligne par (directive, origine bloquée, page), un compteur ;
- 1 000 lignes au plus : au-delà, les signalements NOUVEAUX sont ignorés
  (les connus continuent de compter). Un robot ne remplit pas la base.
On ne garde que l'ORIGINE de ce qui est bloqué et le CHEMIN de la page —
ni paramètres d'adresse, ni adresse IP, ni navigateur.

Ce qu'il ne fait pas : décider. Il donne de quoi lire, sur l'écran
Tableau de bord › Signalements CSP, avant de passer l'en-tête en mode bloquant.
"""
import json
from urllib.parse import urlsplit

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.db import IntegrityError, transaction
from django.db.models import F
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt

TAILLE_MAX = 16 * 1024
LIGNES_MAX = 1000
PAR_MINUTE = 60


def _origine(adresse):
    """« https://exemple.fr/x.js?a=1 » → « https://exemple.fr » ; « inline », « eval » tels quels."""
    adresse = str(adresse or "").strip()
    if not adresse:
        return "?"
    morceaux = urlsplit(adresse)
    if morceaux.scheme and morceaux.netloc:
        return f"{morceaux.scheme}://{morceaux.netloc}"[:200]
    return (morceaux.scheme or adresse)[:200]


def _chemin(adresse):
    return (urlsplit(str(adresse or "")).path or "/")[:200]


def lire_les_rapports(corps):
    """
    Les rapports d'un envoi, sous les deux formes : l'ancienne (report-uri,
    {"csp-report": {…}}) et l'API Reporting ([{"type": "csp-violation",
    "body": {…}}]). Rend [(directive, origine, page)].
    """
    donnees = json.loads(corps)
    elements = donnees if isinstance(donnees, list) else [donnees]
    lus = []
    for e in elements[:20]:
        if not isinstance(e, dict):
            continue
        r = e.get("csp-report") or e.get("body") or {}
        if not isinstance(r, dict):
            continue
        directive = (r.get("effective-directive") or r.get("effectiveDirective")
                     or r.get("violated-directive") or "?")
        bloque = r.get("blocked-uri") or r.get("blockedURL") or ""
        page = r.get("document-uri") or r.get("documentURL") or e.get("url") or ""
        lus.append((str(directive).split(" ")[0][:64], _origine(bloque), _chemin(page)))
    return lus


@csrf_exempt
def recevoir(request):
    from jeiko.throttling import rate_limited

    from .models import SignalementCsp

    if request.method != "POST":
        return HttpResponse(status=405)
    if rate_limited(request, "csp", PAR_MINUTE, 60, quiet=True):
        return HttpResponse(status=204)
    corps = request.body
    if len(corps) > TAILLE_MAX:
        return HttpResponse(status=204)
    try:
        rapports = lire_les_rapports(corps)
    except (ValueError, TypeError):
        return HttpResponse(status=204)
    for directive, origine, page in rapports:
        mis_a_jour = SignalementCsp.objects.filter(
            directive=directive, origine_bloquee=origine, page=page).update(compte=F("compte") + 1)
        if mis_a_jour or SignalementCsp.objects.count() >= LIGNES_MAX:
            continue
        try:
            with transaction.atomic():
                SignalementCsp.objects.create(directive=directive, origine_bloquee=origine, page=page)
        except IntegrityError:  # créée entre-temps par un autre envoi
            SignalementCsp.objects.filter(directive=directive, origine_bloquee=origine,
                                          page=page).update(compte=F("compte") + 1)
    return HttpResponse(status=204)


@method_decorator(never_cache, name="dispatch")
class SignalementsCsp(LoginRequiredMixin, UserPassesTestMixin, View):
    """Tableau de bord › Signalements CSP — réservé aux superutilisateurs."""

    template_name = "administration/signalements_csp.html"
    raise_exception = True

    def test_func(self):
        return self.request.user.is_superuser

    def get(self, request):
        from .models import SignalementCsp

        signalements = SignalementCsp.objects.order_by("-compte", "-dernier_le")[:200]
        return render(request, self.template_name, {
            "signalements": signalements, "total": SignalementCsp.objects.count(), "maximum": LIGNES_MAX,
        })

    def post(self, request):
        from .models import SignalementCsp

        SignalementCsp.objects.all().delete()
        messages.success(request, _("Signalements effacés : la liste repart de zéro."))
        return redirect("jeiko_administration:signalements_csp")
