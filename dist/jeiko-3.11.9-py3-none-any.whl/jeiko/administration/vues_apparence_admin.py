"""
L'apparence de l'administration : couleur d'accent (A-13) et mode clair,
sombre ou comme l'appareil (A-11). Jamais celle du site — elle a son thème.
Les couleurs elles-mêmes : static/jeiko/css/admin/couleurs.css.
"""
from django import forms
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import redirect, render
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views import View
from django.views.decorators.cache import never_cache

from .models import WebSite
from .website_cache import invalidate_website_data


class ApparenceAdminForm(forms.ModelForm):
    class Meta:
        model = WebSite
        fields = ["admin_accent", "admin_apparence"]
        widgets = {"admin_accent": forms.RadioSelect, "admin_apparence": forms.RadioSelect}


@method_decorator(never_cache, name="dispatch")
class ApparenceAdminView(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = "users.config_edit_site"
    raise_exception = True
    template_name = "administration/apparence_admin.html"

    def get(self, request):
        site = WebSite.objects.first()
        if site is None:
            return redirect("jeiko_administration:main")
        return render(request, self.template_name, {"form": ApparenceAdminForm(instance=site)})

    def post(self, request):
        site = WebSite.objects.first()
        if site is None:
            return redirect("jeiko_administration:main")
        form = ApparenceAdminForm(request.POST, instance=site)
        if not form.is_valid():
            return render(request, self.template_name, {"form": form}, status=400)
        form.save()
        invalidate_website_data()
        messages.success(request, _("Apparence de l'administration enregistrée."))
        return redirect("jeiko_administration:apparence_admin")
