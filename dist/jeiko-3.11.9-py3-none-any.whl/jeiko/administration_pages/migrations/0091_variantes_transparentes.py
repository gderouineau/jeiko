"""
Refait les variantes WebP des images transparentes, que la conversion passait
en RGB : un logo détouré s'affichait sur fond noir (27/10/2026).

Réécrites SOUS LE MÊME NOM : les pages en cache et les fiches qui citent ces
fichiers n'ont rien à changer. Ce que la migration ne fait pas : vider le
cache des navigateurs qui ont déjà la version noire — elle partira avec lui.

Le code est ici, pas emprunté au modèle : une migration doit survivre aux
refontes de `models.py`. Une image illisible est laissée telle quelle.
"""
from io import BytesIO

from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.db import migrations

CIBLES = (
    ("full_size", 1920), ("computer_size", 1500), ("laptop_size", 1200),
    ("tablet_size", 991), ("mobile_size", 767),
)


def refaire_les_variantes_transparentes(apps, schema_editor):
    from PIL import Image, ImageOps

    ImageContent = apps.get_model("administration_pages", "ImageContent")
    for image in ImageContent.objects.exclude(original_image="").iterator():
        try:
            with default_storage.open(image.original_image.name, "rb") as f:
                src = Image.open(f)
                transparente = src.mode in ("RGBA", "LA", "PA") or (
                    src.mode == "P" and "transparency" in src.info)
                if not transparente:
                    continue
                src.load()
        except Exception:
            continue
        src = ImageOps.exif_transpose(src).convert("RGBA")
        for champ, largeur in CIBLES:
            nom = getattr(image, champ).name if getattr(image, champ) else ""
            if not nom or not default_storage.exists(nom):
                continue
            if src.width > largeur:
                img = src.resize((largeur, int(src.height * largeur / src.width)),
                                 Image.Resampling.LANCZOS)
            else:
                img = src
            tampon = BytesIO()
            img.save(tampon, format="WEBP", quality=85, method=6)
            default_storage.delete(nom)
            default_storage.save(nom, ContentFile(tampon.getvalue()))


class Migration(migrations.Migration):

    dependencies = [
        ("administration_pages", "0090_libelle_du_titre_du_calendrier"),
    ]

    operations = [
        migrations.RunPython(refaire_les_variantes_transparentes, migrations.RunPython.noop),
    ]
