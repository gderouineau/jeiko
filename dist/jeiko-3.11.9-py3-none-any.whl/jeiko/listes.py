# jeiko/listes.py
"""
Listes de l'administration : recherche, puis pagination (D-03, 28/09/2026).

L'ordre compte : on FILTRE d'abord, on DÉCOUPE ensuite. Une recherche porte
donc sur toute la liste, pas sur la page affichée. Les liens de page gardent
la recherche et les autres paramètres (`parametres_sans_page`) : sans cela,
passer à la page 2 perdait la recherche — ou, comme sur la liste des
utilisateurs, répétait `page` dans l'adresse et bloquait la navigation.
"""

from functools import reduce
from operator import or_

from django.db.models import Q


class ListeRechercheeEtPaginee:
    """
    À mêler à une `ListView`. Déclarer `champs_de_recherche`.

    Une vue qui écrit son propre `get_queryset` doit passer son résultat par
    `self.rechercher(...)` : le sien passe devant celui-ci.
    """

    paginate_by = 50
    champs_de_recherche = ()

    def recherche(self):
        return (self.request.GET.get("q") or "").strip()

    def rechercher(self, queryset):
        terme = self.recherche()
        if not terme or not self.champs_de_recherche:
            return queryset
        return queryset.filter(
            reduce(or_, (Q(**{f"{champ}__icontains": terme}) for champ in self.champs_de_recherche))
        )

    def get_queryset(self):
        return self.rechercher(super().get_queryset())

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        parametres = self.request.GET.copy()
        parametres.pop("page", None)
        context["recherche"] = self.recherche()
        context["parametres_sans_page"] = parametres.urlencode()
        return context


def paginer(request, queryset, par_page=50):
    """
    La même règle pour une vue qui n'est pas une `ListView` : filtrer AVANT
    d'appeler, puis passer le résultat au gabarit avec
    `{% include "includes/pagination.html" %}`. Rend (objets de la page,
    contexte de pagination).
    """
    from django.core.paginator import Paginator

    page_obj = Paginator(queryset, par_page).get_page(request.GET.get("page"))
    parametres = request.GET.copy()
    parametres.pop("page", None)
    return page_obj.object_list, {
        "page_obj": page_obj, "is_paginated": page_obj.has_other_pages(),
        "parametres_sans_page": parametres.urlencode(),
    }
