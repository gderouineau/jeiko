"""
Les catégories de cookies du site, et leurs textes par langue (L-16).

Jusqu'ici, elles ne se réglaient que dans l'admin de Django, et dans la seule
langue du site : un visiteur anglais lisait « Mesure d'audience » si le libellé
était l'un de ceux que JEIKO connaît (catalogues), sinon le texte de
l'exploitant, en français. Ce module sert l'écran Cookies › Catégories et
l'API des agents :

* une catégorie a UNE clé (`analytics`…) : c'est elle que porte le
  consentement, dans toutes les langues ;
* ses textes dans une langue ajoutée se rangent sur elle
  (`CookieCategory.traductions`), sans créer de seconde catégorie ;
* une langue sans traduction retombe sur le texte d'origine (passé par les
  catalogues).

Ce que ce module ne fait pas : décider des catégories qu'un site doit
proposer. C'est à l'exploitant — selon les outils qu'il ajoute (mesure
d'audience, vidéos externes…) ; JEIKO, lui, ne pose que des cookies
essentiels.
"""
from django.utils.text import slugify
from django.utils.translation import gettext as _
from django.utils.translation import gettext_noop

from .models import CookieCategory, default_locale
from .views import _au_plus_pres_de

CHAMPS = ("label", "description", "is_essential", "default_enabled", "display_order", "is_active")

#: Les libellés habituels : présents dans les catalogues, ils sortent traduits
#: dans chaque langue sans que l'exploitant ait rien à saisir
#: (`CookieCategory.label_pour`). Jamais affichés tels quels ici.
LIBELLES_HABITUELS = (
    gettext_noop("Cookies essentiels"), gettext_noop("Essentiels"), gettext_noop("Fonctionnels"),
    gettext_noop("Préférences"), gettext_noop("Mesure d'audience"), gettext_noop("Statistiques"),
    gettext_noop("Marketing"), gettext_noop("Publicité"), gettext_noop("Contenus externes"),
    gettext_noop("Réseaux sociaux"),
)


class CategorieInvalide(Exception):
    """Le message est destiné à l'exploitant."""


def d_origine(site):
    """Les catégories dans la langue du site — celles qu'on règle."""
    qs = CookieCategory.objects.filter(site=site).order_by("display_order", "key")
    return _au_plus_pres_de(qs, default_locale())


def trouver(site, cle):
    return d_origine(site).filter(key=cle).first()


def enregistrer(site, cle, **champs):
    """Crée ou modifie la catégorie `cle` (langue du site). Rend la catégorie."""
    cle = slugify(cle or "")[:50]
    if not cle:
        raise CategorieInvalide(_("Une catégorie a besoin d'une clé (lettres, chiffres, tirets)."))
    inconnus = set(champs) - set(CHAMPS)
    if inconnus:
        raise CategorieInvalide(_("Champs inconnus : %(champs)s.") % {"champs": ", ".join(sorted(inconnus))})
    categorie = trouver(site, cle)
    libelle = champs.get("label", categorie.label if categorie else "")
    if not str(libelle or "").strip():
        raise CategorieInvalide(_("Une catégorie a besoin d'un libellé."))
    if categorie is None:
        categorie = CookieCategory(site=site, key=cle, locale=default_locale())
    for nom, valeur in champs.items():
        if nom in ("is_essential", "default_enabled", "is_active"):
            valeur = bool(valeur)
        elif nom == "display_order":
            try:
                valeur = max(0, int(valeur))
            except (TypeError, ValueError):
                raise CategorieInvalide(_("L'ordre est un nombre entier."))
        else:
            valeur = str(valeur or "").strip()
        setattr(categorie, nom, valeur)
    categorie.label = categorie.label[:120]
    categorie.save()
    return categorie


def traduire(categorie, langue, label="", description=""):
    """Les textes de `categorie` dans `langue` ; vides, la langue retombe sur l'origine."""
    traductions = dict(categorie.traductions or {})
    textes = {k: v for k, v in (("label", str(label or "").strip()[:120]),
                                ("description", str(description or "").strip())) if v}
    if textes:
        traductions[langue] = textes
    else:
        traductions.pop(langue, None)
    categorie.traductions = traductions
    categorie.save(update_fields=["traductions", "updated_at"])
    return categorie


def en_donnees(categorie):
    return {"cle": categorie.key, "libelle": categorie.label, "description": categorie.description,
            "essentielle": categorie.is_essential, "active_par_defaut": categorie.default_enabled,
            "ordre": categorie.display_order, "active": categorie.is_active,
            "traductions": {code: {"libelle": t.get("label", ""), "description": t.get("description", "")}
                            for code, t in (categorie.traductions or {}).items()}}
