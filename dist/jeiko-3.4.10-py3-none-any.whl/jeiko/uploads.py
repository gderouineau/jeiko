"""
Gardes sur les fichiers téléversés — images (S-10) et PDF (S-11).

Ce que cela protège
-------------------
**La bombe de décompression.** Un PNG de 40 Ko peut déclarer 60 000 × 60 000
pixels. Pillow ne lit pas l'image au moment d'ouvrir le fichier, mais dès qu'on
la redimensionne — ce que `ImageContent.save()` fait cinq fois, pour produire
ses variantes — il alloue quatre octets par pixel : quatorze gigaoctets pour
l'exemple ci-dessus. Le processus est tué, ou la machine part en `swap`. Il
suffit d'un formulaire d'import d'image et d'un compte.

Pillow porte bien un garde-fou, mais à 89 mégapixels : au-delà il *avertit*, et
il ne lève qu'au double. C'est très au-dessus de ce dont un site a besoin —
une image de 1920 × 1080 fait 2 Mpx — et très au-dessus de ce qu'une machine de
VPS encaisse. On descend à 25 Mpx, soit une photo de 6000 × 4000, ce qui laisse
passer un appareil photo récent et arrête tout le reste.

**Le poids.** Le plafond en pixels ne dit rien du poids du fichier : un JPEG de
200 Mo tient dans 25 Mpx. Dix mégaoctets suffisent largement pour une image de
site, et c'est autant de disque et de bande passante qu'on ne consomme pas.

**Le faux PDF.** Le champ du PDF de formation n'avait AUCUN validateur : ni
extension, ni poids, ni contenu. `courses.views.client.serve_pdf` renvoie
ensuite le fichier avec `Content-Type: application/pdf`, depuis le domaine du
site. Un fichier HTML déposé sous le nom `cours.pdf` s'exécuterait donc dans
l'origine du site si le navigateur se mettait à renifler le contenu.
`SECURE_CONTENT_TYPE_NOSNIFF` l'en empêche — mais c'est un réglage, dans un
autre fichier, qu'un site peut perdre. On vérifie donc aussi la signature du
fichier, qui, elle, ne dépend d'aucun réglage.

Ce que cela ne protège pas
--------------------------
Rien ici ne remplace la limite du serveur web (`client_max_body_size` chez
Nginx) : ces validateurs s'exécutent APRÈS que le fichier soit monté, donc
après l'avoir reçu et écrit sur disque. Ils protègent le traitement, pas la
réception.

Et une signature `%PDF-` ne dit pas qu'un PDF est inoffensif : un vrai PDF peut
porter du JavaScript. Elle dit seulement que ce n'est pas un fichier d'un autre
type déguisé.

Réglable par site
-----------------
`JEIKO_MAX_IMAGE_PIXELS`, `JEIKO_MAX_IMAGE_UPLOAD_MB`, `JEIKO_MAX_PDF_UPLOAD_MB`
dans les settings, pour un site qui héberge des plans ou des scans.
"""

import logging

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator
from PIL import Image

logger = logging.getLogger(__name__)

#: 25 Mpx — une photo de 6000 × 4000. Au-delà, un site web n'a rien à en faire.
LIMITE_PIXELS_PAR_DEFAUT = 25_000_000
LIMITE_IMAGE_MO_PAR_DEFAUT = 10
LIMITE_PDF_MO_PAR_DEFAUT = 25

#: Signature d'un fichier PDF. La norme autorise jusqu'à 1024 octets d'entête
#: avant elle ; en pratique elle est en tête, et un fichier qui la place plus
#: loin n'est de toute façon pas ce qu'on attend d'un import.
SIGNATURE_PDF = b"%PDF-"

valider_extension_pdf = FileExtensionValidator(allowed_extensions=["pdf"])


def limite_pixels():
    return getattr(settings, "JEIKO_MAX_IMAGE_PIXELS", LIMITE_PIXELS_PAR_DEFAUT)


def appliquer_les_limites_pillow():
    """
    Abaisse le garde-fou de Pillow, une fois, au démarrage.

    Appelée depuis `jeiko.apps.AdministrationConfig.ready()` plutôt que depuis
    un module de modèles : c'est une variable globale de Pillow, elle doit être
    posée à un moment connu et pas au gré des imports.
    """
    Image.MAX_IMAGE_PIXELS = limite_pixels()


def _poids_en_mo(fichier):
    taille = getattr(fichier, "size", None)
    return None if taille is None else taille / (1024 * 1024)


def valider_le_poids_de_l_image(fichier):
    plafond = getattr(settings, "JEIKO_MAX_IMAGE_UPLOAD_MB", LIMITE_IMAGE_MO_PAR_DEFAUT)
    poids = _poids_en_mo(fichier)
    if poids is not None and poids > plafond:
        raise ValidationError(
            "Image trop lourde : %(poids).1f Mo, maximum %(max)s Mo.",
            params={"poids": poids, "max": plafond},
        )


def valider_les_dimensions_de_l_image(fichier):
    """
    Refuse une image dont le nombre de pixels dépasse la limite.

    On ouvre sans décoder : `Image.open` ne lit que l'entête, `.size` en
    découle. C'est justement ce qui permet de refuser une bombe avant de
    l'avoir dépliée.
    """
    if not fichier:
        return

    plafond = limite_pixels()
    try:
        position = fichier.tell() if hasattr(fichier, "tell") else None
        if hasattr(fichier, "seek"):
            fichier.seek(0)
        with Image.open(fichier) as image:
            largeur, hauteur = image.size
        if position is not None and hasattr(fichier, "seek"):
            fichier.seek(position)
    except ValidationError:
        raise
    except Image.DecompressionBombError:
        # Pillow a tranché avant nous : le fichier annonce plus du double de la
        # limite. Le message doit rester celui de l'utilisateur, pas la trace.
        raise ValidationError(
            "Image trop grande pour être traitée (maximum %(max)s mégapixels).",
            params={"max": plafond // 1_000_000},
        )
    except Exception:
        # Fichier illisible : `ImageField` le dira mieux que nous, avec le
        # message d'erreur que l'utilisateur attend. On ne masque pas, on
        # laisse passer — et on garde une trace, parce qu'une image que Pillow
        # n'ouvre pas alors que Django l'a acceptée mérite d'être regardée.
        logger.warning("Image illisible à la validation des dimensions.", exc_info=True)
        return

    if largeur * hauteur > plafond:
        raise ValidationError(
            "Image trop grande : %(l)s × %(h)s pixels, maximum "
            "%(max)s mégapixels (soit environ 6000 × 4000).",
            params={"l": largeur, "h": hauteur, "max": plafond // 1_000_000},
        )


def valider_l_image(fichier):
    """Les deux gardes d'un seul tenant, pour n'en poser qu'un sur un champ."""
    valider_le_poids_de_l_image(fichier)
    valider_les_dimensions_de_l_image(fichier)


def valider_le_pdf(fichier):
    """Poids, puis signature — l'extension est vérifiée par un validateur à part."""
    if not fichier:
        return

    plafond = getattr(settings, "JEIKO_MAX_PDF_UPLOAD_MB", LIMITE_PDF_MO_PAR_DEFAUT)
    poids = _poids_en_mo(fichier)
    if poids is not None and poids > plafond:
        raise ValidationError(
            "PDF trop lourd : %(poids).1f Mo, maximum %(max)s Mo.",
            params={"poids": poids, "max": plafond},
        )

    try:
        position = fichier.tell() if hasattr(fichier, "tell") else None
        fichier.seek(0)
        entete = fichier.read(len(SIGNATURE_PDF))
        fichier.seek(position if position is not None else 0)
    except Exception:
        logger.warning("PDF illisible à la validation.", exc_info=True)
        return

    if not entete.startswith(SIGNATURE_PDF):
        raise ValidationError(
            "Ce fichier ne semble pas être un PDF : il porte l'extension .pdf "
            "mais son contenu dit autre chose."
        )
