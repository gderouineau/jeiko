from jeiko.administration.models import WebSite


def get_current_website(request) -> WebSite:
    # Variante 1: un seul site
    return WebSite.objects.first()
