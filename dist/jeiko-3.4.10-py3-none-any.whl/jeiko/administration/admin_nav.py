"""
Navigation de l'espace d'administration, déclarée en données.

Pourquoi ce module existe
-------------------------
Le menu vivait dans `templates/includes/admin_menu.html` : 400 lignes de HTML
répétitif où chaque entrée recopiait à la main son libellé, son `{% url %}`,
sa garde de permission et son test d'état actif. Quatre familles de défauts en
découlaient, toutes constatées à l'audit :

*Des liens morts.* L'entrée « Shop » pointait sur `#`.

*Des états actifs qui ne s'allument jamais.* « Menus » comparait le nom de vue
`jeiko_administration_menu:main` alors que son lien visait `menu_list` ; une
autre entrée testait `url_name == ''`, jamais vrai.

*Des gardes de permission croisées.* La section Boutique était conditionnée par
`view_product / view_order / view_paymentgateway` mais contenait un item régi
par `view_producttype` : un rôle qui n'a que ce dernier ne voyait jamais son
écran. « Les calendriers » était conditionné par `view_googlecalendarconfig`,
sans rapport avec ce qu'il ouvre.

*Des écrans absents.* Sept écrans réels (e-mails, cookies, pages légales,
identité, serveur mail, API Google, mise à jour) n'apparaissaient nulle part :
on n'y accédait que par la pile de liens de l'accueil.

Déclarer la navigation en données rend ces quatre défauts structurellement
impossibles : l'URL est résolue par `reverse()` (un nom faux lève à la
construction au lieu de produire un lien mort), l'état actif se déduit du nom
de vue courant, et la garde de permission est portée par l'item lui-même — donc
une section est visible exactement quand au moins un de ses items l'est.

Ajouter un écran au menu = ajouter une ligne ici.
"""

from dataclasses import dataclass, field as dc_field
from typing import Tuple

from django.urls import NoReverseMatch, reverse
from django.utils.translation import gettext_lazy as _


@dataclass(frozen=True)
class NavItem:
    """Une entrée de menu.

    `perms` : l'item est visible si l'utilisateur détient **au moins une** de
    ces permissions (OU logique). Vide = visible par quiconque atteint l'admin.

    `staff_only` : réservé aux comptes `is_staff`. Sert aux écrans encore gardés
    par `staff_member_required` plutôt que par le backend de rôles (cookies,
    pages légales, identité du site) — le menu doit refléter la garde réelle,
    sinon il propose un écran qui renverra l'utilisateur vers une page de
    connexion.

    `also_active` : autres noms de vue qui allument cette entrée, pour qu'une
    sous-page (formulaire, détail) garde son parent en surbrillance.
    """

    label: str
    url_name: str
    perms: Tuple[str, ...] = ()
    staff_only: bool = False
    superuser_only: bool = False
    also_active: Tuple[str, ...] = ()
    #: Nom d'un compteur calculé par `_badges()`. Non nul, il s'affiche sur
    #: l'entrée ET se cumule sur sa section — sans quoi une notification posée
    #: dans une section repliée resterait invisible.
    badge: str = ""

    def is_visible(self, user) -> bool:
        if self.superuser_only and not user.is_superuser:
            return False
        if self.staff_only and not (user.is_staff or user.is_superuser):
            return False
        if not self.perms:
            return True
        return any(user.has_perm(p) for p in self.perms)

    def matches(self, view_name: str) -> bool:
        return view_name == self.url_name or view_name in self.also_active


@dataclass(frozen=True)
class NavSection:
    label: str
    items: Tuple[NavItem, ...] = dc_field(default_factory=tuple)


# ---------------------------------------------------------------------------
# La navigation.
#
# Les libellés sont des noms de choses, pas des ordres : « Pages », pas « Voir
# les pages ». L'ancien menu mélangeait trois grammaires (« Voir les pages »,
# « Les modèles », « Gestion des créneaux ») et portait des fautes visibles
# (« Moyens de payment », « Gestion de accès », « Les roles »). Le menu fait
# 180 px de large : les libellés courts évitent le retour à la ligne.
# ---------------------------------------------------------------------------

NAVIGATION: Tuple[NavSection, ...] = (
    # L'ancienne entrée « Shop » de cette section pointait sur `#`. Elle n'est
    # pas remplacée : la boutique n'a pas de page d'index côté client (les URLs
    # publiques de `shop` ne couvrent que la fiche produit et le panier), donc
    # aucune cible honnête n'existe. Le jour où une page « boutique » est créée
    # dans les pages, ajouter ici son `url_name`.
    NavSection(_("Le site"), (
        NavItem(_("Voir le site"), "jeiko_pages:root_page"),
    )),

    NavSection(_("Pilotage"), (
        NavItem(_("Tableau de bord"), "jeiko_administration:global_view",
                perms=("users.config_edit_site",)),
        NavItem(_("Statistiques"), "jeiko_administration_stats:stats_overview",
                perms=("users.config_edit_site",),
                # L'aperçu porte déjà un bouton « Voir toutes les pages » vers
                # le détail par page. Deux entrées de menu pour la même idée se
                # ressemblaient trop pour être distinguées d'un coup d'œil.
                also_active=("jeiko_administration_stats:stats_pages",
                             "jeiko_administration_stats:stats_page_detail")),
    )),

    NavSection(_("Réglages"), (
        NavItem(_("Général"), "jeiko_administration:main",
                perms=("users.access_admin",)),
        NavItem(_("Identité du site"), "jeiko_administration:site_identity", staff_only=True),
        NavItem(_("Polices"), "jeiko_administration:fonts_view",
                perms=("users.config_edit_fonts",)),
        # Juste après les polices : c'est le même geste — régler l'aspect du
        # site à un seul endroit plutôt qu'écran par écran.
        NavItem(_("Thème"), "jeiko_administration:theme_view",
                perms=("users.config_edit_fonts",)),
        NavItem(_("Connexions sociales"), "jeiko_administration:social_login_config",
                perms=("users.config_edit_site",)),
        NavItem(_("API Google"), "jeiko_administration:google_api_config",
                perms=("users.config_edit_site",)),
        NavItem(_("Serveur e-mail"), "jeiko_administration:mail_settings_edit",
                perms=("users.config_edit_mail",)),
        NavItem(_("E-mails envoyés"), "jeiko_administration_emailing:template_list",
                perms=("users.config_edit_mail",),
                also_active=("jeiko_administration_emailing:template_edit",)),
        NavItem(_("Cookies"), "jeiko_cookies_admin:edit_banner_text", staff_only=True),
        NavItem(_("Pages légales"), "jeiko_administration:legals_view", staff_only=True),
        # Les agents portent des droits comme un compte : ils se règlent là où
        # l'on règle le site, pas dans un coin à part.
        NavItem(_("Agents IA"), "jeiko_agents_admin:liste",
                perms=("auth.change_user",),
                also_active=("jeiko_agents_admin:detail",
                             "jeiko_agents_admin:creer",
                             "jeiko_agents_admin:modifier")),
        # Une section « Maintenance » pour une seule entrée coûtait un repli de
        # plus sans rien apporter : la mise à jour vit ici, en dernier.
        NavItem(_("Mettre à jour JEIKO"), "jeiko_administration:update_jeiko",
                perms=("users.config_edit_site",), badge="update"),
    )),

    NavSection(_("Pages"), (
        NavItem(_("Toutes les pages"), "jeiko_administration_pages:main",
                perms=("administration_pages.view_page",),
                also_active=("jeiko_administration_pages:page_update",
                             "jeiko_administration_pages:page_insights")),
        NavItem(_("Ajouter une page"), "jeiko_administration_pages:page_add",
                perms=("administration_pages.add_page",)),
        NavItem(_("Catégories"), "jeiko_administration_pages:categories",
                perms=("administration_pages.view_page",)),
        NavItem(_("Modèles de page"), "jeiko_administration_pages:model_library",
                perms=("administration_pages.view_page",)),
        NavItem(_("Menus"), "jeiko_administration_menu:menu_list",
                perms=("users.config_edit_site",),
                also_active=("jeiko_administration_menu:menu_detail",
                             "jeiko_administration_menu:menu_add",
                             "jeiko_administration_menu:menu_update")),
    )),

    NavSection(_("Objets personnalisés"), (
        NavItem(_("Modèles d'objet"), "jeiko_administration_custom_objects:model_list",
                perms=("custom_objects.view_customobjectmodel",)),
    )),

    NavSection(_("Boutique"), (
        NavItem(_("Produits"), "jeiko_administration_shop:product_list_all",
                perms=("shop.view_product",)),
        NavItem(_("Types de produits"), "jeiko_administration_shop:product_type_list",
                perms=("shop.view_producttype",)),
        NavItem(_("Commandes"), "jeiko_shop_admin_orders:order_list",
                perms=("shop.view_order",)),
        NavItem(_("Moyens de paiement"), "jeiko_payments_admin:gateway_list",
                perms=("payments.view_paymentgateway",)),
        # Ce qui vaut pour toute la boutique — TVA, devise, livraison — par
        # opposition à ce qui se règle produit par produit.
        NavItem(_("Réglages"), "jeiko_administration_shop:settings",
                perms=("shop.change_producttype",)),
    )),

    NavSection(_("Formations"), (
        NavItem(_("Toutes les formations"), "jeiko_courses:jeiko_courses_admin:course_list",
                perms=("courses.view_course",),
                also_active=("jeiko_courses:jeiko_courses_admin:course_edit",
                             "jeiko_courses:jeiko_courses_admin:course_structure")),
        NavItem(_("Ajouter une formation"), "jeiko_courses:jeiko_courses_admin:course_create",
                perms=("courses.add_course",)),
        NavItem(_("Accès aux formations"), "jeiko_courses:jeiko_courses_admin:enrollment_list",
                perms=("courses.view_courseenrollment",)),
        NavItem(_("Hébergement vidéo"), "jeiko_courses:jeiko_courses_admin:provider_list",
                perms=("courses.change_course",)),
    )),

    NavSection(_("Rendez-vous"), (
        NavItem(_("Rendez-vous à venir"), "jeiko_administration_calendars:appointment_list_upcoming",
                perms=("calendars.view_appointment",)),
        NavItem(_("Rendez-vous passés"), "jeiko_administration_calendars:appointment_list_past",
                perms=("calendars.view_appointment",)),
        NavItem(_("Types de rendez-vous"), "jeiko_administration_calendars:appointmenttype_list",
                perms=("calendars.view_appointmenttype",)),
        NavItem(_("Créneaux"), "jeiko_administration_calendars:availability_list",
                perms=("calendars.view_availability",)),
        NavItem(_("Calendriers"), "jeiko_administration_calendars:calendar_list",
                perms=("calendars.view_googlecalendarconfig",)),
        NavItem(_("Connexion Google"), "jeiko_administration_calendars:google_config",
                perms=("calendars.view_googlecalendarconfig",)),
        NavItem(_("Supervision"), "jeiko_administration_calendars:google_configs_all",
                superuser_only=True),
    )),

    NavSection(_("Questionnaires"), (
        NavItem(_("Tous les tests"), "jeiko_administration_questionnaires_expert:test_list",
                perms=("questionnaires_expert.view_questionnaire",)),
        NavItem(_("Ajouter un test"), "jeiko_administration_questionnaires_expert:test_add",
                perms=("questionnaires_expert.add_questionnaire",)),
        NavItem(_("Prospects"), "jeiko_administration_questionnaires_expert:prospect_list",
                perms=("questionnaires_expert.view_prospect",)),
    )),

    NavSection(_("Utilisateurs"), (
        NavItem(_("Tous les utilisateurs"), "jeiko_administration_users:user_list",
                perms=("auth.view_user",),
                also_active=("jeiko_administration_users:user_detail",)),
        NavItem(_("Rôles"), "jeiko_administration_users:role_list",
                perms=("users.view_role",)),
        NavItem(_("Journal de sécurité"), "jeiko_administration_users:security_event_list",
                perms=("users.view_securityevent",)),
        NavItem(_("Double auth. (2FA)"), "jeiko_administration_users:twofa_list",
                perms=("users.view_twofactordevice",)),
        # PAS d'entrée « Connexions OAuth » (users.ProviderConfig) : c'est un
        # doublon INERTE de « Réglages → Connexions sociales ». Les deux
        # modèles servent à saisir des identifiants OAuth, mais seul
        # `administration.SocialProvider` possède un `sync_to_allauth()` qui
        # écrit réellement le `SocialApp` d'allauth. Côté `users/`, aucune
        # référence à `SocialApp` n'existe : les docstrings annoncent la
        # synchronisation au futur (« écrira », « déclenchera ») et elle n'a
        # jamais été écrite. Exposer cet écran revenait à inviter un
        # administrateur à saisir des clés Google qui ne partent nulle part.
        NavItem(_("Notifications"), "jeiko_administration_users:notif_compose",
                perms=("users.add_notification",)),
    )),

    # Les sept écrans ci-dessous n'étaient atteignables que depuis la pile de
    # liens de l'accueil : aucun n'apparaissait dans le menu.
)


def _badges():
    """Compteurs à afficher dans le menu, par nom de badge.

    Lit `WebSite` depuis le cache (`website_cache`), déjà chargé à chaque rendu :
    afficher le badge ne coûte donc aucune requête supplémentaire. Ne lève
    jamais — un compteur indisponible ne doit pas empêcher le menu de s'afficher.
    """
    try:
        from jeiko.administration.website_cache import get_website_data
        site = get_website_data()
    except Exception:
        return {}
    if site is None:
        return {}
    counts = {}
    if getattr(site, "update_available_version", ""):
        counts["update"] = 1
    return counts


def build_nav(user, view_name: str, path: str = ""):
    """Sections visibles par `user`, avec URL résolue et état actif.

    Une entrée dont le nom de vue n'existe pas est **écartée** plutôt que rendue
    en lien mort : c'est la garantie qu'un renommage d'URL se voit (l'entrée
    disparaît) au lieu de produire un 404 silencieux.

    Une section sans aucun item visible n'est pas rendue : plus besoin de tenir
    à jour, à la main, une condition de section qui répète celles des items.

    L'état actif se décide en deux temps. D'abord par **nom de vue** — exact,
    et c'est ce qui fait autorité. À défaut, par **préfixe d'URL le plus long** :
    sans cela, un administrateur en train de modifier un rendez-vous ou une
    formation ne voit plus aucune entrée en surbrillance et perd le fil de
    l'endroit où il se trouve. On ne prend que le préfixe le plus spécifique,
    pour que « /administration/users/… » allume « Utilisateurs » et non
    « Général » (dont l'URL, « /administration/ », préfixe tout l'espace).
    """
    resolved = []
    for section in NAVIGATION:
        for item in section.items:
            if not item.is_visible(user):
                continue
            try:
                url = reverse(item.url_name)
            except NoReverseMatch:
                continue
            resolved.append((section, item, url))

    active_by_name = any(item.matches(view_name) for _, item, _ in resolved)

    fallback_url = None
    if not active_by_name and path:
        # « Général » vit à la racine de l'espace (/administration/), donc son
        # URL préfixe TOUT l'admin. Sans cette garde, un sous-formulaire sans
        # entrée propre (révoquer une session, lier un prospect…) allumerait
        # « Général » — une indication fausse, pire que pas d'indication. On ne
        # retient un préfixe que s'il est plus spécifique que cette racine, sauf
        # à être exactement sur l'écran Général.
        candidates = [
            url for _, _, url in resolved
            if url != "/" and path.startswith(url) and (len(url) > len("/administration/") or path == url)
        ]
        if candidates:
            fallback_url = max(candidates, key=len)

    badges = _badges()
    sections, current = [], None
    for section, item, url in resolved:
        is_active = item.matches(view_name) if active_by_name else url == fallback_url
        count = badges.get(item.badge, 0) if item.badge else 0
        if current is None or current["label"] != section.label:
            current = {"label": section.label, "items": [], "is_open": False, "badge": 0}
            sections.append(current)
        current["items"].append({
            "label": item.label,
            "url": url,
            "is_active": is_active,
            "badge": count,
        })
        # Le compte remonte sur la section : repliée par défaut, elle serait
        # sinon le seul endroit visible et n'afficherait rien.
        current["badge"] += count
        if is_active:
            current["is_open"] = True
    return sections
