# jeiko/administration/emailing.py
"""
Test de la configuration mail du site.

L'envoi lui-même vit désormais dans `jeiko.emailing` : ce module ne garde que le
point d'entrée du bouton « Tester la configuration », qui passe par le modèle
éditable `smtp_test`.
"""
import logging

from django.utils import timezone

from jeiko.administration.models import WebSite

logger = logging.getLogger(__name__)


def send_test_email():
    """
    Envoie un e-mail de test pour vérifier la configuration.

    Passe par le modèle éditable `smtp_test` : le bouton de test envoie donc
    exactement la mise en page que verra l'utilisateur, pas un message à part.
    Retourne (success: bool, message: str, trace: str or None).
    """
    from jeiko.emailing.services import send_email

    site = WebSite.objects.select_related("mail_settings").first()
    ms = getattr(site, "mail_settings", None)

    if not ms:
        return False, "Aucune configuration email trouvée", None
    if not ms.active:
        return False, "Configuration email inactive", None
    if not ms.default_from_email:
        return False, "Adresse d'expéditeur par défaut non configurée", None

    # Destinataires : expéditeur par défaut, utilisateur SMTP, adresse de test et
    # reply-to, dédupliqués et débarrassés des valeurs vides.
    recipients = list(dict.fromkeys(
        address for address in (
            ms.default_from_email, ms.host_user, ms.test_receiver, ms.reply_to_email,
        ) if address
    ))

    context = {
        "serveur_smtp": f"{ms.host or 'Non configuré'}:{ms.port or 'Non configuré'}",
        "utilisateur_smtp": ms.host_user or "Non configuré",
        "date_heure": timezone.localtime().strftime("%d/%m/%Y %H:%M:%S"),
    }

    try:
        success, error = send_email("smtp_test", recipients, context)
        if success:
            return True, f"E-mail de test envoyé avec succès à {', '.join(recipients)}", None
        return False, f"Erreur lors de l'envoi : {error}", None
    except Exception as exc:
        import traceback
        return False, f"Erreur lors de l'envoi de l'e-mail : {exc}", traceback.format_exc()
