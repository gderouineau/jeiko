# -*- coding: utf-8 -*-
"""
Met à jour les MODÈLES par défaut des pages légales pour couvrir les traitements
réellement gérés par la plateforme mais absents des textes seedés (orientés
e-commerce pur) :

  1) Politique de confidentialité (url_tag='privacy') :
     - « Données collectées »        → + RDV, questionnaires/tests, formations
     - « Finalités des traitements » → + gestion RDV, questionnaires, formations
     - « Bases légales »             → + contrat (RDV/formations) / consentement
     - « Durées de conservation »    → + RDV (24 mois, cf. purge), questionnaires,
                                        formations
     - « Destinataires & sous-traitants » → + agenda (si synchro), hébergeur vidéo

  2) Conditions Générales de Vente (url_tag='cgv') :
     - Nouvelle section « Produits numériques & prestations de services »
       (formations, rendez-vous) : pas de livraison, rétractation spécifique
       aux contenus numériques (L221-28) et aux prestations de services.

Garde-fous :
  - On ne touche QUE les pages encore `is_default_legal_template=True` : une page
    éditée à la main (le drapeau passe à False au premier changement) n'est jamais
    réécrite.
  - Idempotent : chaque insertion est protégée par un marqueur ; ré-exécuter ne
    duplique rien.
"""

from django.db import migrations


# ---------------------------------------------------------------------------
# Helpers de navigation dans l'arbre Page → Section → Line → Bloc → Content →
# ContentText, en modèles historiques (apps.get_model).
# ---------------------------------------------------------------------------

def _line_body_ct_by_heading(apps, line, heading_needle):
    """
    Renvoie le ContentText du bloc « corps » d'une Line dont le bloc « titre »
    contient `heading_needle`. None si la ligne ne porte pas ce titre.
    """
    Content = apps.get_model('administration_pages', 'Content')
    blocs = list(line.blocs.all())
    contents = list(
        Content.objects.filter(bloc__in=blocs).select_related('content_text')
    )
    cts = [c.content_text for c in contents if c.content_text_id]
    if not any(heading_needle in (ct.text or '') for ct in cts):
        return None
    for ct in cts:
        if heading_needle not in (ct.text or ''):
            return ct
    return None


def _find_body_ct_by_heading(apps, page, heading_needle):
    """Cherche dans toute la page la Line portant `heading_needle` et renvoie son corps."""
    for section in page.sections.all():
        for line in section.lines.all().order_by('position'):
            ct = _line_body_ct_by_heading(apps, line, heading_needle)
            if ct is not None:
                return ct
    return None


def _find_line_by_heading(apps, page, heading_needle):
    """Renvoie (section, line) de la Line dont le titre contient `heading_needle`."""
    Content = apps.get_model('administration_pages', 'Content')
    for section in page.sections.all():
        for line in section.lines.all().order_by('position'):
            blocs = list(line.blocs.all())
            contents = Content.objects.filter(bloc__in=blocs).select_related('content_text')
            for c in contents:
                ct = c.content_text
                if ct and heading_needle in (ct.text or ''):
                    return section, line
    return None, None


def _page_contains(apps, page, needle):
    """True si un ContentText quelconque de la page contient `needle`."""
    Content = apps.get_model('administration_pages', 'Content')
    for section in page.sections.all():
        for line in section.lines.all():
            blocs = list(line.blocs.all())
            for c in Content.objects.filter(bloc__in=blocs).select_related('content_text'):
                ct = c.content_text
                if ct and needle in (ct.text or ''):
                    return True
    return False


def _insert_li_before_last_ul(html, extra_items_html):
    """
    Insère `extra_items_html` juste avant la dernière fermeture de liste du corps.
    Le seed par défaut utilise <ul> ; on tolère <ol> par prudence (l'éditeur Quill
    convertit les puces en <ol data-list="bullet">).
    """
    html = html or ''
    idx = max(html.rfind('</ul>'), html.rfind('</ol>'))
    if idx == -1:
        return html  # pas de liste : on ne touche pas
    return html[:idx] + extra_items_html + html[idx:]


def _append_li(apps, page, heading, marker, extra_items_html):
    """
    Ajoute des <li> à la liste de la section `heading`, sauf si `marker` y est
    déjà présent (idempotence).
    """
    ct = _find_body_ct_by_heading(apps, page, heading)
    if ct is None or marker in (ct.text or ''):
        return
    ct.text = _insert_li_before_last_ul(ct.text, extra_items_html)
    ct.save(update_fields=['text'])


def _build_line(apps, section, position, title_html, body_html):
    """Crée une Line 12/12/12 (bloc titre + bloc corps) à `position` explicite."""
    Line = apps.get_model('administration_pages', 'Line')
    Bloc = apps.get_model('administration_pages', 'Bloc')
    Content = apps.get_model('administration_pages', 'Content')
    ContentText = apps.get_model('administration_pages', 'ContentText')
    Size = apps.get_model('administration_pages', 'Size')
    StyleBox = apps.get_model('administration_pages', 'StyleBox')

    def _sb0():
        return StyleBox.objects.create(top="0", right="0", bottom="0", left="0")

    def _sb_line(top, right, bottom, left):
        return StyleBox.objects.create(top=top, right=right, bottom=bottom, left=left)

    def _size100():
        return Size.objects.create(width="100%", height="")

    line = Line.objects.create(
        section=section,
        position=position,
        columns_type="12",
        columns_type_tablet="12",
        columns_type_phone="12",
        columns_number=1,
        margin_phone=_sb_line("40px", 0, 0, 0),
        margin_tablet=_sb_line("70px", 0, 0, 0),
        margin_laptop=_sb_line("100px", 0, 0, 0),
        margin_computer=_sb_line("100px", 0, 0, 0),
        padding_phone=_sb0(), padding_tablet=_sb0(), padding_laptop=_sb0(), padding_computer=_sb0(),
        size_phone=_size100(), size_tablet=_size100(), size_laptop=_size100(), size_computer=_size100(),
        is_model=False, is_hero=False,
    )

    bloc1 = Bloc.objects.create(
        line=line, position=1, position_in_column=0,
        margin_phone=_sb0(), margin_tablet=_sb0(), margin_laptop=_sb0(), margin_computer=_sb0(),
        padding_phone=_sb0(), padding_tablet=_sb0(), padding_laptop=_sb0(), padding_computer=_sb0(),
        size_phone=_size100(), size_tablet=_size100(), size_laptop=_size100(), size_computer=_size100(),
        is_model=False,
    )
    ct1 = ContentText.objects.create(text=title_html or "")
    Content.objects.create(bloc=bloc1, content_type="TEXT", content_text=ct1, data={})

    if body_html:
        bloc2 = Bloc.objects.create(
            line=line, position=1, position_in_column=1,
            margin_phone=_sb0(), margin_tablet=_sb0(), margin_laptop=_sb0(), margin_computer=_sb0(),
            padding_phone=_sb0(), padding_tablet=_sb0(), padding_laptop=_sb0(), padding_computer=_sb0(),
            size_phone=_size100(), size_tablet=_size100(), size_laptop=_size100(), size_computer=_size100(),
            is_model=False,
        )
        ct2 = ContentText.objects.create(text=body_html)
        Content.objects.create(bloc=bloc2, content_type="TEXT", content_text=ct2, data={})

    return line


def _bump_cache(page_id):
    """Invalide le cache de corps de page (sans casser si indisponible)."""
    try:
        from jeiko.administration_pages.page_cache import bump_page_body_version
        bump_page_body_version(page_id)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Contenus ajoutés
# ---------------------------------------------------------------------------

COLLECTE_LI = """
        <li><strong>Prise de rendez-vous :</strong> nom, adresse email, créneau réservé, nombre de places, statut et, le cas échéant, état du paiement. Si la synchronisation d'agenda est activée, le rendez-vous est transmis à l'agenda du prestataire (ex.&nbsp;Google Calendar).</li>
        <li><strong>Questionnaires &amp; tests :</strong> réponses fournies, résultats et scores calculés, ainsi que les coordonnées saisies (nom, prénom, email, téléphone) lorsque vous choisissez de les communiquer.</li>
        <li><strong>Formations en ligne :</strong> inscription, progression de visionnage et d'avancement, accès aux contenus vidéo/PDF. L'hébergement des vidéos peut être assuré par un prestataire tiers ([Nom de l'hébergeur vidéo]).</li>
"""

FINALITE_LI = """
        <li><strong>Gestion des rendez-vous</strong> (réservation, confirmation, rappels, annulation/report).</li>
        <li><strong>Réalisation des questionnaires/tests</strong> (calcul et restitution des résultats).</li>
        <li><strong>Accès aux formations en ligne</strong> (inscription, suivi de progression, mise à disposition des contenus).</li>
"""

BASE_LEGALE_LI = """
        <li><strong>Rendez-vous et formations</strong> : exécution du contrat. <strong>Questionnaires/tests</strong> : consentement (démarche volontaire).</li>
"""

CONSERVATION_LI = """
        <li><strong>Rendez-vous</strong> : coordonnées conservées jusqu'à 24 mois après le rendez-vous, puis anonymisation automatique.</li>
        <li><strong>Questionnaires &amp; résultats</strong> : [durée de la relation, puis archivage/anonymisation].</li>
        <li><strong>Formations</strong> : durée de l'accès accordé ; les achats suivent la conservation comptable (10&nbsp;ans).</li>
"""

DESTINATAIRE_LI = """
        <li><strong>Agenda</strong> (si synchronisation activée) : Google — [Pays/UE] ;</li>
        <li><strong>Hébergement vidéo</strong> (formations) : [Prestataire] — [Pays/UE].</li>
"""

CGV_DIGITAL_TITLE = "<h2>Produits numériques &amp; prestations de services (formations, rendez-vous)</h2>"

CGV_DIGITAL_BODY = """
        <p>Outre d'éventuels produits physiques, [Nom de la société] propose des <strong>contenus numériques</strong> (formations et cours en ligne) et des <strong>prestations de services</strong> (rendez-vous, consultations). Pour ces offres, les clauses relatives à la livraison et au transport ne s'appliquent pas et sont remplacées par les dispositions suivantes.</p>
        <ul>
          <li><strong>Nature :</strong> l'achat d'une formation ouvre l'accès à un contenu numérique en ligne ; l'achat d'un rendez-vous correspond à la réservation d'une prestation à une date convenue. Aucune livraison physique n'a lieu.</li>
          <li><strong>Mise à disposition :</strong> l'accès aux formations est ouvert [immédiatement après paiement / à la date indiquée] et reste disponible [durée d'accès]. Le rendez-vous est confirmé pour le créneau réservé.</li>
          <li><strong>Rétractation — contenus numériques :</strong> conformément à l'article L221-28 du Code de la consommation, si vous demandez un accès immédiat au contenu, vous <strong>renoncez expressément</strong> à votre droit de rétractation ; à défaut, le délai de 14&nbsp;jours s'applique tant que l'accès n'est pas ouvert.</li>
          <li><strong>Rétractation — prestations (rendez-vous) :</strong> pour un service dont l'exécution commence, à votre demande, avant la fin du délai de 14&nbsp;jours, le droit de rétractation ne peut plus être exercé une fois la prestation pleinement exécutée. Les conditions d'annulation/report figurent [sur la page de réservation].</li>
          <li><strong>Prérequis techniques :</strong> l'accès aux formations nécessite [connexion internet, navigateur à jour].</li>
        </ul>
"""


# ---------------------------------------------------------------------------
# Migration
# ---------------------------------------------------------------------------

def apply(apps, schema_editor):
    Page = apps.get_model('administration_pages', 'Page')

    # 1) Politique de confidentialité
    privacy = Page.objects.filter(
        url_tag__iexact='privacy', is_default_legal_template=True
    ).first()
    if privacy is not None:
        _append_li(apps, privacy, "Données collectées",
                   "Prise de rendez-vous", COLLECTE_LI)
        _append_li(apps, privacy, "Finalités des traitements",
                   "Gestion des rendez-vous", FINALITE_LI)
        _append_li(apps, privacy, "Bases légales",
                   "Rendez-vous et formations", BASE_LEGALE_LI)
        _append_li(apps, privacy, "Durées de conservation",
                   "24 mois après le rendez-vous", CONSERVATION_LI)
        _append_li(apps, privacy, "Destinataires",
                   "Hébergement vidéo", DESTINATAIRE_LI)
        _bump_cache(privacy.id)

    # 2) CGV — nouvelle section numérique/services après « Produits — … — Disponibilité »
    cgv = Page.objects.filter(
        url_tag__iexact='cgv', is_default_legal_template=True
    ).first()
    if cgv is not None and not _page_contains(apps, cgv, "Produits numériques"):
        section, anchor_line = _find_line_by_heading(apps, cgv, "Disponibilité</h2>")
        if section is not None and anchor_line is not None:
            insert_pos = (anchor_line.position or 0) + 1
            # décale les lignes suivantes pour insérer au bon endroit
            for ln in section.lines.filter(position__gte=insert_pos).order_by('-position'):
                ln.position = (ln.position or 0) + 1
                ln.save(update_fields=['position'])
            _build_line(apps, section, insert_pos, CGV_DIGITAL_TITLE, CGV_DIGITAL_BODY)
            _bump_cache(cgv.id)


class Migration(migrations.Migration):

    dependencies = [
        ('administration', '0024_favicon_website_favicon'),
        ('administration_pages', '0056_alter_bloc_options_alter_line_options_and_more'),
    ]

    operations = [
        migrations.RunPython(apply, migrations.RunPython.noop),
    ]
