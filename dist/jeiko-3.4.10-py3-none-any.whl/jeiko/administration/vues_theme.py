# jeiko/administration/vues_theme.py
"""Écran de réglage du thème."""

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import redirect, render
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.cache import never_cache

from .forms_theme import ThemeForm
from .models import Theme, WebSite
from .website_cache import invalidate_website_data


@method_decorator(never_cache, name="dispatch")
class ThemeView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Les couleurs du site, en un seul endroit.

    Gardée par la permission qui gouverne déjà l'identité et les polices :
    changer la palette change l'aspect de toutes les pages d'un coup.
    """

    template_name = "administration/theme/update.html"
    permission_required = "users.config_edit_fonts"
    raise_exception = True

    def _theme(self):
        """
        Le thème du site, créé s'il manque.

        La migration en pose un sur les sites existants, mais un site créé
        après elle — ou une base restaurée d'ailleurs — pourrait ne pas en
        avoir. Un écran qui plante dans ce cas serait un mauvais accueil.
        """
        site = WebSite.objects.first()
        if site is None:
            return None, None
        if site.theme is None:
            site.theme = Theme.objects.create()
            site.save(update_fields=["theme"])
        return site, site.theme

    def get(self, request):
        site, theme = self._theme()
        if theme is None:
            messages.error(request, "Aucun site n'est encore configuré.")
            return redirect("jeiko_administration:main")
        return render(request, self.template_name, {
            "form": ThemeForm(instance=theme), "theme": theme,
        })

    def post(self, request):
        site, theme = self._theme()
        if theme is None:
            return redirect("jeiko_administration:main")

        form = ThemeForm(request.POST, instance=theme)
        if not form.is_valid():
            return render(request, self.template_name,
                          {"form": form, "theme": theme})
        form.save()

        # Le thème voyage dans `website_data`, qui est en cache : sans cette
        # purge, l'exploitant enregistre et ne voit rien changer pendant 24 h.
        invalidate_website_data()

        messages.success(
            request,
            "Thème enregistré. Les couleurs s'appliquent sur tout le site.",
        )
        return redirect("jeiko_administration:theme_view")
