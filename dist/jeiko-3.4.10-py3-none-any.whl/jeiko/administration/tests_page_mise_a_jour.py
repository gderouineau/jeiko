# jeiko/administration/tests_page_mise_a_jour.py
"""
La page de mise à jour doit dire QUELLE version est disponible.

Ce qui manquait
---------------
Le job `cron_24h` relève la version publiée sur le canal et l'enregistre dans
`WebSite.update_available_version`. La donnée était donc là — et la page de
mise à jour ne l'affichait nulle part. On lisait « Version installée : 3.4.9 »
et un bouton, sans savoir ce qu'on allait installer, ni même s'il y avait
quelque chose à installer.

Trois états, et pas deux
------------------------
La distinction qui compte n'est pas « à jour / pas à jour » mais :

* une version est disponible — on dit laquelle ;
* la vérification a ÉCHOUÉ — on le dit, parce qu'un site coupé de son canal
  de publication avait exactement la même apparence qu'un site à jour, et
  restait donc à l'écart des correctifs sans que rien ne le signale ;
* la vérification a abouti et il n'y a rien — on rassure.

Confondre les deux derniers est le défaut qu'on ferme ici.
"""

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from jeiko.administration.models import WebSite


class PageDeMiseAJourTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.admin = User.objects.create_superuser(
            "chef", "chef@exemple.fr", "Un-Mot-De-Passe-42"
        )
        self.client.force_login(self.admin)
        self.url = reverse("jeiko_administration:update_jeiko")
        self.site = WebSite.objects.first()

    def _regler(self, **champs):
        WebSite.objects.filter(pk=self.site.pk).update(**champs)

    def test_une_version_disponible_est_annoncee(self):
        self._regler(
            update_available_version="3.5.0",
            update_last_checked_at=timezone.now(),
            update_check_error="",
        )
        reponse = self.client.get(self.url)
        self.assertContains(reponse, "3.5.0")
        self.assertContains(reponse, "est")
        self.assertContains(reponse, "disponible")

    def test_un_echec_de_verification_ne_passe_pas_pour_un_site_a_jour(self):
        """
        Le défaut central : les deux cas donnaient la même page muette, et un
        site coupé de son canal avait l'air à jour.
        """
        self._regler(
            update_available_version="",
            update_last_checked_at=timezone.now(),
            update_check_error="Canal injoignable (timeout)",
        )
        reponse = self.client.get(self.url)
        self.assertContains(reponse, "Canal injoignable")
        self.assertNotContains(reponse, "Vous êtes à jour")

    def test_un_site_a_jour_le_dit(self):
        self._regler(
            update_available_version="",
            update_last_checked_at=timezone.now(),
            update_check_error="",
        )
        self.assertContains(self.client.get(self.url), "à jour")

    def test_sans_verification_aucune_annonce_n_est_faite(self):
        """
        Tant que le cron n'est pas passé, on ne sait rien — et affirmer « à
        jour » serait une affirmation sans fondement.
        """
        self._regler(
            update_available_version="",
            update_last_checked_at=None,
            update_check_error="",
        )
        reponse = self.client.get(self.url)
        self.assertNotContains(reponse, "Vous êtes à jour")
