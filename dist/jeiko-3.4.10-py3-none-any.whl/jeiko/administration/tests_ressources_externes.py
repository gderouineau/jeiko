# jeiko/administration/tests_ressources_externes.py
"""
Aucune page ne charge une police ou une icône depuis un tiers (R-06).

Pourquoi cela compte
--------------------
Un `<link>` vers `fonts.googleapis.com` ou un script depuis
`kit.fontawesome.com` fait partir l'adresse IP de la personne — visiteur ou
exploitant — chez un tiers, à chaque page, avant tout consentement et sans
qu'aucun écran ne le mentionne. C'est le genre de dépendance qu'on ne voit pas
parce qu'elle marche : rien ne casse, rien n'avertit.

Ce qui a été trouvé en le faisant
---------------------------------
Le kit FontAwesome était chargé sur les deux pages **publiques** de
questionnaire, qui n'utilisent aucune icône — zéro occurrence de `fa-`. Et les
gabarits qui en utilisent vraiment étendent des bases où le kit était commenté :
leurs icônes ne s'affichaient pas. Chargé là où il ne sert pas, absent là où il
sert.

Ce que ce test NE couvre pas
----------------------------
Les polices du SITE, choisies par l'exploitant : elles sont auto-hébergées à
l'enregistrement par `jeiko/fonts_selfhost.py`, mais l'ÉDITEUR les sert encore
par le CDN pour que l'aperçu suive un changement immédiatement. C'est un
arbitrage assumé, et il ne concerne qu'un écran d'administration — pas les
visiteurs. Le CDN Quill de l'éditeur est dans le même cas (S-02 au plan).
"""

import pathlib
import re

from django.test import SimpleTestCase

GABARITS = pathlib.Path(__file__).resolve().parent.parent / "templates"

#: Hôtes tiers qui reçoivent une adresse IP dès qu'une page les référence.
TIERS = ("fonts.googleapis.com", "fonts.gstatic.com", "kit.fontawesome.com",
         "use.fontawesome.com", "cdnjs.cloudflare.com")

#: Gabarits autorisés à y recourir, avec la raison. Toute autre entrée est un
#: retour en arrière — et la liste doit rester courte, sinon elle cesse d'être
#: une exception pour devenir la règle.
TOLERES = {
    # L'éditeur sert les polices DU SITE par le CDN : l'aperçu doit refléter
    # un changement de police immédiatement, avant tout enregistrement.
    "base_editor.html": ("fonts.googleapis.com", "fonts.gstatic.com"),
    # Quill, l'éditeur de texte riche — S-02 au plan : à servir en local avec
    # une empreinte d'intégrité.
    "includes/quill.html": ("cdnjs.cloudflare.com",),
    "administration_pages/content/edit_text.html": ("cdnjs.cloudflare.com",),
}

#: Les quatre écrans de CHOIX de police interrogent le CDN pour prévisualiser
#: une famille avant qu'elle soit retenue. On ne peut pas auto-héberger ce
#: qu'on n'a pas encore choisi : l'exception est inhérente à la fonction, pas
#: un raccourci. Une fois la police enregistrée, `fonts_selfhost.py` la
#: rapatrie et le site public ne touche plus au CDN.
for _ecran in ("update_link", "update_menu", "update_text", "update_title"):
    TOLERES[f"administration/fonts/{_ecran}.html"] = (
        "fonts.googleapis.com", "fonts.gstatic.com",
    )


def _sans_commentaires(html):
    """Retire les commentaires Django et HTML : ils EXPLIQUENT le défaut."""
    html = re.sub(r"{%\s*comment\s*%}.*?{%\s*endcomment\s*%}", "", html, flags=re.DOTALL)
    return re.sub(r"<!--.*?-->", "", html, flags=re.DOTALL)


class RessourcesTiercesTests(SimpleTestCase):
    def test_aucun_gabarit_ne_charge_une_police_tierce(self):
        coupables = []

        for fichier in sorted(GABARITS.rglob("*.html")):
            relatif = str(fichier.relative_to(GABARITS))
            contenu = _sans_commentaires(fichier.read_text())
            autorises = TOLERES.get(relatif, ())

            for hote in TIERS:
                if hote in contenu and hote not in autorises:
                    coupables.append(f"{relatif} → {hote}")

        self.assertEqual(
            coupables, [],
            "Ressource tierce chargée par un gabarit :\n  "
            + "\n  ".join(coupables)
            + "\nL'adresse IP de la personne part chez ce tiers à chaque page. "
              "Auto-héberger, ou justifier l'exception dans TOLERES.",
        )

    def test_inter_est_bien_livree_avec_le_paquet(self):
        """
        Basculer les gabarits sur une feuille locale ne sert à rien si les
        fichiers ne sont pas dans le paquet : l'administration s'afficherait
        dans la police système sans que rien ne le signale.
        """
        css = GABARITS.parent / "static" / "jeiko" / "css" / "admin" / "inter.css"
        self.assertTrue(css.exists(), "css/admin/inter.css manque")

        polices = sorted(
            (GABARITS.parent / "static" / "jeiko" / "fonts" / "inter").glob("*.woff2")
        )
        self.assertGreaterEqual(
            len(polices), 4,
            "les fichiers woff2 d'Inter manquent : les écrans retomberaient "
            "sur la police système.",
        )

        declare = css.read_text()
        for police in polices:
            with self.subTest(police=police.name):
                self.assertIn(police.name, declare)
