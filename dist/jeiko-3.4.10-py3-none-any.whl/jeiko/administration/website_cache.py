"""
Cache de l'objet ``WebSite`` (les « données de site » injectées dans chaque page).

``{% get_website_data %}`` (templatetags/website_extra.py) est évalué en tête de
CHAQUE ``base.html``. Sans cache, cela coûtait :
  - une requête ``WebSite.objects.first()`` ;
  - une requête ``website_data.identity`` (son ``updated_at`` sert de clé au
    fragment ``site_identity_block`` du head, lu à chaque requête) ;
  - une requête ``website_data.logo`` (idem pour ``site_assets_block``).

Soit ~3 requêtes par page pour un objet qui change très rarement. On met donc en
cache l'instance avec ``identity`` et ``logo`` déjà joints : sur un hit, les
gabarits y accèdent sans requête. Les polices (``fonts_computer.h1``…) ne sont
PAS préchargées : elles ne sont lues que sur un rare défaut du fragment
``site_assets_block`` (caché 30 j), et le chargement paresseux fonctionne sur
l'instance dépicklée.

Il n'y a qu'un seul ``WebSite`` : une clé unique suffit, invalidée par signal
(administration/signals.py) sur tout changement de WebSite, SiteIdentity, Logo,
Font ou Fonts.
"""

from django.core.cache import cache

from .models import WebSite

WEBSITE_DATA_KEY = "jeiko:website_data"
# TTL de garde : l'invalidation par signal fait foi ; ce délai ne couvre que
# l'éviction ou un signal manqué.
WEBSITE_DATA_TTL = 60 * 60 * 24  # 24 h

# cache.get() renvoie None aussi bien pour un défaut que pour une valeur None
# mise en cache. On distingue les deux avec une sentinelle, pour ne pas
# re-interroger la base à chaque page quand aucun WebSite n'existe encore.
_MISS = object()
_NONE_SENTINEL = "__jeiko_website_none__"


def get_website_data():
    """Renvoie l'unique ``WebSite`` (avec identity + logo joints), depuis le cache."""
    cached = cache.get(WEBSITE_DATA_KEY, _MISS)
    if cached is not _MISS:
        return None if cached == _NONE_SENTINEL else cached

    site = WebSite.objects.select_related("identity", "logo", "favicon").first()
    cache.set(
        WEBSITE_DATA_KEY,
        site if site is not None else _NONE_SENTINEL,
        WEBSITE_DATA_TTL,
    )
    return site


def invalidate_website_data(*args, **kwargs):
    """
    Purge le cache du site. Signature tolérante (``*args, **kwargs``) pour être
    branchée directement comme récepteur de signal.
    """
    cache.delete(WEBSITE_DATA_KEY)
