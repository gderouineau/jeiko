# jeiko/administration/tests_menu_mobile.py
"""
L'administration reste utilisable au doigt — menu latéral et barre rapide.

Elle est consultée quotidiennement depuis un téléphone. Deux défauts la
rendaient inutilisable à cette taille, tous deux invisibles sur un écran
d'ordinateur.

A-18 — le menu latéral ne se refermait pas
------------------------------------------
Le menu est `position: fixed; left: 0; width: 180px` à toutes les largeurs :
déployé par défaut. Ce qui le repliait sous 992 px vivait dans une AUTRE
feuille, chargée après. Il suffit que celle-ci manque — cache de navigateur
périmé sur un téléphone, requête qui n'aboutit pas — pour que le menu
s'affiche ouvert dès le chargement, en travers de l'écran, et qu'aucun bouton
ne sache le refermer : leur style vient de la même feuille absente.

Et même feuille présente, il n'existait qu'une seule sortie — le bouton
flottant — plus la touche Échap, qu'un téléphone n'a pas. Tout reposait donc
sur un unique élément `position: fixed` : dès que quelque chose le recouvre ou
le déplace, le menu est bloqué ouvert.

La barre rapide débordait de l'écran
------------------------------------
Six entrées sur une ligne `flex` sans retour à la ligne : elles sortaient de
la largeur du téléphone. Les faire passer à la ligne rend la hauteur variable,
ce qui condamnait le `body { margin-top: 30px }` qui lui réservait sa place.

Ce que ces tests attrapent
--------------------------
Rien de tout cela ne lève d'erreur : les gabarits compilent, les vues
répondent 200. Seul un contrôle sur ce qui part au navigateur peut le voir.
"""

import pathlib
import re

from django.contrib.auth import get_user_model
from django.template.loader import render_to_string
from django.test import RequestFactory, SimpleTestCase, TestCase

CSS = pathlib.Path(__file__).resolve().parent.parent / "static" / "jeiko" / "css"
ADMIN_MENU_CSS = CSS / "admin" / "admin_menu.css"
QUICK_CSS = CSS / "admin" / "quick_admin_menu.css"

#: La borne au-delà de laquelle le menu est permanent. Écrite dans les deux
#: feuilles ; si l'une change, l'autre doit suivre.
BORNE = "991.98px"

_COMMENTAIRE = re.compile(r"/\*.*?\*/", re.DOTALL)


def _sans_commentaires(css):
    """
    Retire les commentaires avant analyse.

    Sans cela, le commentaire qui *raconte* le défaut se fait prendre pour le
    défaut : ces feuilles expliquent en toutes lettres ce qu'elles ont cessé
    de faire, `100vw` et `margin-top: 30px` compris.
    """
    return _COMMENTAIRE.sub("", css)


class SortiesDuMenuLateralTests(TestCase):
    """Le menu doit offrir plusieurs façons de se refermer, pas une seule."""

    @classmethod
    def setUpTestData(cls):
        cls.utilisateur = get_user_model().objects.create_superuser(
            "chef", "chef@example.test", "pw"
        )

    def _rendre(self):
        requete = RequestFactory().get("/administration/")
        requete.user = self.utilisateur
        return render_to_string(
            "includes/admin_menu.html", {"request": requete}, request=requete
        )

    def test_le_menu_offre_trois_sorties(self):
        """
        Le bouton flottant, le voile, la croix — plus Échap au clavier.

        Aucune ne doit dépendre des autres : c'est tout l'intérêt. Le bouton
        seul avait suffi à bloquer un iPhone menu ouvert.
        """
        html = self._rendre()
        for classe, role in (
            ("jk-menu-toggle", "le bouton flottant"),
            ("jk-menu-backdrop", "le voile, qui ferme au toucher"),
            ("jk-menu-close", "la croix, à l'intérieur du panneau"),
        ):
            with self.subTest(sortie=classe):
                self.assertIn(
                    classe, html,
                    f"{role} a disparu du menu : il ne reste plus assez de "
                    f"façons de le refermer sur un téléphone.",
                )

    def test_la_croix_est_dans_le_panneau(self):
        """
        Ce qui la rend indépendante de ce qui recouvrirait le bouton flottant.

        Placée hors du `<nav>`, elle retomberait dans le même piège.
        """
        html = self._rendre()
        nav = html[html.index("<nav"):html.index("</nav>")]
        self.assertIn("jk-menu-close", nav)

    def test_le_voile_est_masque_au_chargement(self):
        """
        `hidden` à la pose : sinon le voile figure dans l'arbre
        d'accessibilité et sur le trajet de tabulation alors qu'il n'est qu'un
        décor cliquable — et il couvrirait la page avant tout clic.
        """
        html = self._rendre()
        voile = re.search(r"<div[^>]*jk-menu-backdrop[^>]*>", html).group()
        self.assertIn("hidden", voile)


class EtatReplieParDefautTests(SimpleTestCase):
    def test_le_menu_est_replie_dans_sa_propre_feuille(self):
        """
        La redite avec `admin_ui.css` est délibérée — voir l'en-tête.

        Un menu replié par défaut est un menu qu'on ouvre ; un menu déployé par
        défaut, sur un téléphone, est une page qu'on ne peut plus utiliser. La
        règle doit donc vivre dans la feuille qui définit le menu, pas
        seulement dans celle qui l'habille.
        """
        css = ADMIN_MENU_CSS.read_text()
        self.assertIn(BORNE, css, "la borne mobile a disparu d'admin_menu.css")
        self.assertRegex(
            css,
            r"nav\.admin-menu\s*\{\s*transform:\s*translateX\(-100%\)",
            "admin_menu.css ne replie plus le menu : s'il devient le seul "
            "fichier chargé, l'administration s'ouvre menu déployé et bloqué.",
        )


class BarreRapideTests(SimpleTestCase):
    def test_les_entrees_passent_a_la_ligne(self):
        css = QUICK_CSS.read_text()
        self.assertIn(
            "flex-wrap: wrap", css,
            "sans retour à la ligne, les six entrées débordent de la largeur "
            "d'un téléphone.",
        )

    def test_la_barre_occupe_sa_place_dans_le_flux(self):
        """
        `sticky`, pas `fixed`.

        En `fixed`, la barre sort du flux et sa place doit être réservée à la
        main — ce qui était fait par un `body { margin-top: 30px }`, la hauteur
        d'UNE ligne. Dès qu'elle en fait deux ou trois, cette marge est fausse
        et la barre recouvre le haut du site. `sticky` occupe exactement sa
        propre hauteur, sans rien à tenir à jour.
        """
        css = _sans_commentaires(QUICK_CSS.read_text())
        self.assertIn("position: sticky", css)
        self.assertNotRegex(
            css, r"body\s*\{[^}]*margin[^}]*\d+px",
            "la marge de compensation est revenue : elle ne peut pas suivre "
            "une barre dont la hauteur varie.",
        )

    def test_pas_de_largeur_en_100vw(self):
        """`100vw` compte la barre de défilement et déborde à lui seul."""
        self.assertNotIn("100vw", _sans_commentaires(QUICK_CSS.read_text()))
