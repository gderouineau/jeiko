from django.test import TestCase

from jeiko.administration.management.commands._cron import (
    CronCommand, default_on_calendar, default_randomized_delay,
)
from jeiko.administration.management.commands.jeiko_cron_units import (
    discover_cron_commands,
)


class OnCalendarTests(TestCase):
    """La cadence déclarée dans le code doit suffire à programmer le timer."""

    def test_minute_cadences(self):
        self.assertEqual(default_on_calendar("5m"), "*:0/5")
        self.assertEqual(default_on_calendar("30m"), "*:0/30")

    def test_hour_cadences(self):
        self.assertEqual(default_on_calendar("1h"), "*-*-* *:00:00")
        self.assertEqual(default_on_calendar("6h"), "*-*-* 0/6:00:00")

    def test_daily_and_beyond_run_once_a_day(self):
        self.assertEqual(default_on_calendar("24h"), "*-*-* 03:30:00")
        self.assertEqual(default_on_calendar("7d"), "*-*-* 03:30:00")

    def test_sixty_minutes_is_an_hour(self):
        self.assertEqual(default_on_calendar("60m"), "*-*-* *:00:00")

    def test_invalid_cadence_is_not_schedulable(self):
        for cadence in ("", None, "toto", "0m", "-5m", "5s"):
            self.assertIsNone(default_on_calendar(cadence), cadence)

    def test_randomized_delay_is_capped(self):
        self.assertEqual(default_randomized_delay("5m"), 30)
        self.assertEqual(default_randomized_delay("30m"), 180)
        self.assertEqual(default_randomized_delay("24h"), 300)  # plafond
        self.assertEqual(default_randomized_delay("nimporte quoi"), 0)


class DiscoveryTests(TestCase):
    """L'installeur découvre les cadences sans les connaître à l'avance."""

    def test_ships_the_expected_cadences(self):
        cadences = {spec["cadence"] for spec in discover_cron_commands()}
        self.assertEqual(cadences, {"5m", "30m", "1h", "24h"})

    def test_every_spec_is_schedulable(self):
        for spec in discover_cron_commands():
            self.assertTrue(spec["on_calendar"], spec)
            self.assertEqual(spec["command"], f"cron_{spec['cadence']}")
            self.assertIsInstance(spec["randomized_delay_sec"], int)
            self.assertIn("description", spec)

    def test_base_class_is_not_reported_as_a_cadence(self):
        commands = {spec["command"] for spec in discover_cron_commands()}
        self.assertNotIn("cron_", commands)


class ScheduleSpecTests(TestCase):

    def test_subclass_can_override_the_schedule(self):
        class Command(CronCommand):
            cadence = "15m"
            on_calendar = "*-*-* 02:00:00"
            randomized_delay_sec = 0
            persistent = False

            def get_jobs(self):
                return []

        spec = Command.schedule_spec()
        self.assertEqual(spec["on_calendar"], "*-*-* 02:00:00")
        self.assertEqual(spec["randomized_delay_sec"], 0)
        self.assertFalse(spec["persistent"])

    def test_disabled_cadence_is_not_discovered(self):
        class Command(CronCommand):
            cadence = "15m"
            enabled = False

            def get_jobs(self):
                return []

        self.assertFalse(Command.enabled)


class JobIsolationTests(TestCase):
    """L'échec d'un job ne doit pas empêcher les suivants de tourner."""

    def test_failure_does_not_stop_the_others(self):
        ran = []

        class Command(CronCommand):
            cadence = "5m"

            def get_jobs(self):
                return [
                    ("ok", lambda: ran.append("a")),
                    ("casse", lambda: (_ for _ in ()).throw(RuntimeError("boum"))),
                    ("apres", lambda: ran.append("b")),
                ]

        with self.assertRaises(SystemExit):
            Command().handle()

        self.assertEqual(ran, ["a", "b"])
