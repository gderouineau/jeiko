# jeiko/administration/tests_theme.py
"""
Le thème du site — une palette, un écran, des variables CSS.

Pourquoi ce modèle existe
-------------------------
Avant lui, une couleur d'accent se retapait à la main partout où on la voulait :
dans le CSS d'un bloc, dans le style d'un bouton, dans une classe de gabarit.
Changer d'avis demandait de retrouver chaque occurrence — et d'en oublier une.

Ce que ces tests protègent
--------------------------
**Que les variables sortent.** Sans elles, `var(--jk-accent)` ne vaut rien et
tout ce qui s'appuie dessus retombe silencieusement sur la valeur par défaut du
navigateur — souvent noir. Rien ne casse : c'est simplement laid, et personne
ne sait pourquoi.

**Qu'une valeur ne puisse pas sortir de sa déclaration.** Ces couleurs
finissent dans un bloc `<style>`. Un `;` y termine la déclaration et en ouvre
une autre ; une accolade sort du bloc. C'est le constat S-18, appliqué ici.

**Que le cache soit purgé à l'enregistrement.** `website_data` est en cache
24 h : sans purge, l'exploitant enregistre, ne voit rien changer, et recommence.
"""

from django.contrib.auth.models import Permission
from django.test import TestCase
from django.urls import reverse

from jeiko.administration.models import Theme, WebSite
from jeiko.administration.website_cache import get_website_data
from jeiko.users.testing import creer_compte_verifie


class PaletteTests(TestCase):
    def test_les_dix_couleurs_sortent_en_variables(self):
        theme = Theme.objects.create()
        css = theme.as_css_variables()

        for champ, variable in Theme.VARIABLES:
            with self.subTest(variable=variable):
                self.assertIn(f"{variable}:", css)

        self.assertIn("rgb(180, 83, 9)", css)

    def test_une_couleur_ne_peut_pas_sortir_de_sa_declaration(self):
        """
        Le constat S-18, appliqué au thème : la valeur vient de la base, et
        rien ne garantit qu'elle soit passée par le formulaire — un import,
        une duplication ou un accès direct suffisent.
        """
        # Courte à dessein : le champ fait 30 caractères, ce qui est déjà une
        # défense — une injection élaborée n'y tient pas. On éprouve donc ce
        # qui PEUT entrer.
        theme = Theme.objects.create(accent="red;}a{color:red")
        ligne = theme.as_css_variables().split("--jk-accent:")[1].split("\n")[0]

        for structure in (";", "{", "}"):
            with self.subTest(caractere=structure):
                self.assertNotIn(structure.strip(), ligne.replace(";", "", 1))

    def test_la_palette_se_lit_en_dictionnaire(self):
        """Pour l'API et les gabarits, sans repasser par le CSS."""
        couleurs = Theme.objects.create().couleurs()
        self.assertEqual(len(couleurs), len(Theme.VARIABLES))
        self.assertEqual(couleurs["accent"], "rgb(180, 83, 9)")


class EcranDuThemeTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.chef = creer_compte_verifie(
            "chef", "chef@example.test", "pw", is_staff=True, is_superuser=True
        )

    def setUp(self):
        self.client.force_login(self.chef)
        self.url = reverse("jeiko_administration:theme_view")
        WebSite.objects.get_or_create(defaults={"name": "Essai"})

    def test_l_ecran_s_affiche_avec_les_dix_couleurs(self):
        reponse = self.client.get(self.url)
        self.assertEqual(reponse.status_code, 200)
        corps = reponse.content.decode()
        for champ, _ in Theme.VARIABLES:
            with self.subTest(champ=champ):
                self.assertIn(f'data-couleur="{champ}"', corps)

    def test_un_site_sans_theme_en_recoit_un(self):
        """
        La migration en pose un partout, mais une base restaurée d'ailleurs
        pourrait ne pas en avoir. Un écran qui plante là serait un mauvais
        accueil.
        """
        site = WebSite.objects.first()
        site.theme = None
        site.save(update_fields=["theme"])

        self.assertEqual(self.client.get(self.url).status_code, 200)
        site.refresh_from_db()
        self.assertIsNotNone(site.theme)

    def test_enregistrer_change_la_palette_et_purge_le_cache(self):
        site = WebSite.objects.first()
        if site.theme is None:
            site.theme = Theme.objects.create()
            site.save(update_fields=["theme"])

        get_website_data()  # met en cache l'état d'avant

        donnees = {champ: getattr(site.theme, champ) for champ, _ in Theme.VARIABLES}
        donnees["accent"] = "rgb(1, 2, 3)"
        reponse = self.client.post(self.url, donnees)
        self.assertEqual(reponse.status_code, 302)

        site.theme.refresh_from_db()
        self.assertEqual(site.theme.accent, "rgb(1, 2, 3)")

        # Sans purge, l'exploitant enregistrerait sans rien voir changer.
        self.assertEqual(get_website_data().theme.accent, "rgb(1, 2, 3)")

    def test_une_valeur_dangereuse_est_refusee_a_la_saisie(self):
        """
        Le modèle l'assainirait de toute façon — mais silencieusement. Dire
        « ceci ne fera pas ce que vous croyez » vaut mieux que l'accepter et
        rendre autre chose.
        """
        site = WebSite.objects.first()
        donnees = {champ: getattr(site.theme, champ) for champ, _ in Theme.VARIABLES}
        donnees["accent"] = "red; } body{display:none}"

        reponse = self.client.post(self.url, donnees)
        self.assertEqual(reponse.status_code, 200)
        self.assertIn("accent", reponse.context["form"].errors)

    def test_un_compte_sans_droit_est_refuse(self):
        simple = creer_compte_verifie("simple", "s@example.test", "pw")
        self.client.force_login(simple)
        self.assertEqual(self.client.get(self.url).status_code, 403)


class VariablesDansLesPagesTests(TestCase):
    def test_le_theme_sort_dans_le_style_de_base(self):
        from django.template.loader import render_to_string
        from django.test import RequestFactory

        site, _ = WebSite.objects.get_or_create(defaults={"name": "Essai"})
        if site.theme is None:
            site.theme = Theme.objects.create()
            site.save(update_fields=["theme"])

        requete = RequestFactory().get("/")
        html = render_to_string(
            "includes/base_style.html",
            {"website_data": site, "request": requete}, request=requete,
        )
        self.assertIn("--jk-accent:", html)
        self.assertIn("rgb(180, 83, 9)", html)
