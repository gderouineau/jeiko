from django.urls import path
import jeiko.administration.views as views
import jeiko.administration.vues_theme as vues_theme

app_name = "jeiko_administration"

urlpatterns = [

    path(
        '',
        views.Main.as_view(),
        name='main'
    ),

    path(
        'global/',
        views.GlobalView.as_view(),
        name='global_view'
    ),

    path(
        'fonts/',
        views.FontsView.as_view(),
        name="fonts_view"
    ),
    path(
        'global/theme',
        vues_theme.ThemeView.as_view(),
        name="theme_view"
    ),
    path(
        'fonts/<int:fonts_id>/titles/update',
        views.FontsTitleUpdate.as_view(),
        name="fonts_titles_update"
    ),
    path(
        'fonts/<int:fonts_id>/text/update',
        views.FontsTextUpdate.as_view(),
        name="fonts_text_update"
    ),
    path(
        'fonts/<int:fonts_id>/link/update',
        views.FontsLinkUpdate.as_view(),
        name="fonts_link_update"
    ),
    path(
        'fonts/<int:fonts_id>/menu/update',
        views.FontsMenuUpdate.as_view(),
        name="fonts_menu_update"
    ),
    path(
        'global/logo/update',
        views.LogoUpdate.as_view(),
        name='logo_update'
    ),
    path(
        'global/favicon/update',
        views.FaviconUpdate.as_view(),
        name='favicon_update'
    ),
    path(
        'cache/clear',
        views.ClearCache.as_view(),
        name='cache_clear',
    ),
    path(
        'email/',
        views.MailSettingsUpdateView.as_view(),
        name='mail_settings_edit'
    ),
    path(
        'email/test/',
        views.TestMailSettingsView.as_view(),
        name='mail_settings_test'
    ),



    path(
        "update-jeiko/",
        views.UpdateJeikoView.as_view(),
        name="update_jeiko"
    ),

    # Interrogé en boucle par la page de mise à jour : la mise à jour tourne
    # sous systemd, la page se contente d'en suivre l'avancement.
    path(
        "update-jeiko/status/",
        views.UpdateJeikoStatusView.as_view(),
        name="update_jeiko_status"
    ),

    path(
        "settings/google-api/",
        views.GoogleApiConfigView.as_view(),
        name="google_api_config"
    ),

    path(
        "settings/social-login/",
        views.SocialLoginConfigView.as_view(),
        name="social_login_config"
    ),

    path(
        "legals/",
        views.LegalsOverviewView.as_view(),
        name="legals_view"
    ),
    path(
        "identity/",
        views.SiteIdentityView.as_view(),
        name="site_identity",
    )

]


