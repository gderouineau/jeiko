# jeiko/administration/tests_tableaux.py
"""
Aucun tableau d'administration ne fait défiler la page (A-20).

Le défaut
---------
Douze colonnes posées directement dans `.admin-content-container` poussaient la
page entière vers la droite — **y compris sur un écran d'ordinateur**. Les
premières colonnes sortaient de l'écran, le titre se décalait, et il fallait
faire défiler tout le document pour lire une ligne.

`admin_ui.css` déclarait pourtant `.admin-table-scroll { overflow-x: auto }`,
un conteneur fait exactement pour cela. **Aucun des 28 tableaux ne l'employait.**
La classe avait été écrite et jamais posée : un outil correct que rien ne
reliait à son usage, la même famille de défaut qu'A-17.

Ce que ce test attrape
----------------------
Le vingt-neuvième tableau. Envelopper les vingt-huit était mécanique ; ce qui
ne l'est pas, c'est de s'en souvenir dans six mois, sur un écran neuf, un
vendredi. Le contrôle porte sur le gabarit livré, pas sur un rendu : c'est ce
qui part chez le client qui compte, et un gabarit peut n'être rendu par aucun
test.
"""

import pathlib
import re

from django.test import SimpleTestCase

GABARITS = pathlib.Path(__file__).resolve().parent.parent / "templates"

#: Ce qui compte comme conteneur de défilement. `overflow-x-auto` est la forme
#: utilitaire employée par les écrans les plus récents ; les deux sont
#: acceptées, l'important est que le débordement soit contenu quelque part.
CONTENEURS = (
    "admin-table-scroll",
    "overflow-x-auto",
    "overflow-x:auto",
    "overflow: auto",
    "overflow:auto",
)

#: Nombre de lignes remontées pour chercher le conteneur. Quatre suffisent :
#: au-delà, ce n'est plus une enveloppe, c'est une coïncidence.
PORTEE = 4


def _est_un_gabarit_d_administration(contenu):
    return "admin-content" in contenu or "base_admin" in contenu


class TableauxContenusTests(SimpleTestCase):
    def test_aucun_tableau_ne_deborde_de_la_page(self):
        coupables = []

        for fichier in sorted(GABARITS.rglob("*.html")):
            contenu = fichier.read_text()
            if not _est_un_gabarit_d_administration(contenu):
                continue

            lignes = contenu.splitlines()
            for numero, ligne in enumerate(lignes):
                if "<table" not in ligne:
                    continue
                amont = "\n".join(lignes[max(0, numero - PORTEE):numero])
                if not any(conteneur in amont for conteneur in CONTENEURS):
                    coupables.append(
                        f"{fichier.relative_to(GABARITS)}:{numero + 1}"
                    )

        self.assertEqual(
            coupables, [],
            "Tableau(x) sans conteneur de défilement :\n  "
            + "\n  ".join(coupables)
            + "\nEnvelopper dans <div class=\"admin-table-scroll\">…</div>, "
              "sinon c'est la page entière qui défile — même sur ordinateur.",
        )

    def test_la_classe_de_defilement_existe_toujours(self):
        """
        Envelopper 28 tableaux dans une classe qui n'existe plus ne ferait
        rien, et ne se verrait pas.
        """
        css = (
            GABARITS.parent / "static" / "jeiko" / "css" / "admin" / "admin_ui.css"
        ).read_text()
        sans_commentaires = re.sub(r"/\*.*?\*/", "", css, flags=re.DOTALL)

        self.assertRegex(sans_commentaires, r"\.admin-table-scroll\s*\{[^}]*overflow-x:\s*auto")
        self.assertRegex(
            sans_commentaires,
            r"\.admin-table-scroll\s*>\s*table\s*\{[^}]*min-width",
            "Sans plancher de largeur, une table en `width:100%` se comprime "
            "au lieu de déborder : le conteneur ne défile jamais et l'on "
            "obtient des colonnes illisibles.",
        )


class CiblesTactilesTests(SimpleTestCase):
    """
    A-16 — sous 992 px, on vise avec un doigt, pas avec un curseur.

    Les recommandations situent la cible minimale autour de 44 px. En dessous,
    on vise à côté — et sur un écran d'administration, viser à côté veut dire
    ouvrir la mauvaise fiche ou déclencher la mauvaise action. Les liens
    « Voir | Modifier | Supprimer » d'un tableau étaient trois cibles de 18 px
    côte à côte, dont une destructrice.

    Ce test ne mesure pas un rendu : il vérifie que la règle est écrite, et
    qu'elle reste **bornée au tactile**. Agrandir les boutons au-delà de 992 px
    abîmerait des écrans denses qui fonctionnent très bien à la souris — c'est
    la moitié de la décision, et c'est celle qu'on oublie.
    """

    CSS = GABARITS.parent / "static" / "jeiko" / "css" / "admin" / "admin_ui.css"

    def _bloc_tactile(self):
        """Le contenu de la media query qui porte les cibles tactiles."""
        css = re.sub(r"/\*.*?\*/", "", self.CSS.read_text(), flags=re.DOTALL)
        blocs = re.findall(
            r"@media\s*\(max-width:\s*991\.98px\)\s*\{(.*?)\n\}", css, re.DOTALL
        )
        return "\n".join(blocs)

    def test_les_cibles_sont_portees_a_44px(self):
        bloc = self._bloc_tactile()
        self.assertIn("min-height: 44px", bloc)
        self.assertIn(".btn", bloc)

    def test_les_liens_d_action_des_tableaux_sont_des_cibles(self):
        """Du texte nu de 18 px n'est pas une cible, surtout « Supprimer »."""
        self.assertIn(".admin-table td a", self._bloc_tactile())

    def test_rien_n_est_agrandi_a_la_souris(self):
        """
        La règle doit vivre SOUS 992 px et nulle part ailleurs. Hors media
        query, elle gonflerait des écrans denses qui n'en ont pas besoin.
        """
        css = re.sub(r"/\*.*?\*/", "", self.CSS.read_text(), flags=re.DOTALL)
        # On retire les blocs @media, puis on cherche la règle dans ce qui reste.
        hors_media = re.sub(r"@media[^{]*\{.*?\n\}", "", css, flags=re.DOTALL)
        self.assertNotIn(
            "min-height: 44px", hors_media,
            "Les cibles tactiles s'appliquent en dehors du tactile : à la "
            "souris, ces tailles sont justes et les gonfler abîme les écrans "
            "denses.",
        )
