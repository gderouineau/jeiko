"""
Vérification quotidienne de la disponibilité d'une mise à jour de JEIKO.

Ce que ce module fait
---------------------
Il lit le `version.json` du canal de publication (le même fichier que
`jeiko-client-update` télécharge au moment de mettre à jour), compare la
version qui s'y trouve à celle du paquet installé, et range le résultat sur
`WebSite`. Le badge du menu et celui de la barre d'administration s'en
servent ; l'écran « Mettre à jour JEIKO » aussi.

Pourquoi ici plutôt que côté serveur
------------------------------------
Le serveur ne doit pas avoir à être remis à jour pour qu'une tâche planifiée
apparaisse : c'est tout le principe de `jeiko_cron_units`, qui déclare les
cadences depuis le paquet. Une vérification écrite en Python voyage donc avec
le paquet et s'active à la prochaine mise à jour du client, sans toucher au
serveur. Le prix à payer est un appel HTTPS sortant par jour et par site, vers
un fichier public de quelques centaines d'octets.

Ce module ne met JAMAIS à jour quoi que ce soit : il se contente de regarder.
L'exécution reste déclenchée à la main depuis l'écran d'administration, elle
passe par `sudo jeiko-client-update`, et l'intégrité du wheel est vérifiée par
le sha256 côté installeur. Un canal compromis ne peut donc, au pire, que
faire clignoter un badge à tort.
"""

import json
import logging
import urllib.error
import urllib.request

from django.conf import settings
from django.utils import timezone

logger = logging.getLogger(__name__)

#: Canal par défaut — identique à `JEIKO_DEFAULT_CHANNEL_URL` de
#: `INSTALLER/lib/jeiko-common.sh`. Surchargeable par `JEIKO_CHANNEL_URL` dans
#: les settings du site, comme la variable d'environnement du même nom côté
#: serveur.
DEFAULT_CHANNEL_URL = "https://raw.githubusercontent.com/gderouineau/jeiko/main"

TIMEOUT_SECONDS = 10
#: Le manifeste fait quelques centaines d'octets. On borne la lecture pour
#: qu'une URL détournée ne puisse pas saturer la mémoire du site.
MAX_MANIFEST_BYTES = 64 * 1024


def channel_url() -> str:
    return getattr(settings, "JEIKO_CHANNEL_URL", DEFAULT_CHANNEL_URL).rstrip("/")


def installed_version():
    """Version du paquet `jeiko` installé, ou None si indéterminable."""
    try:
        from importlib.metadata import version
        return version("jeiko")
    except Exception:
        return None


def _parse(raw):
    """Découpe une version en tuple d'entiers comparable.

    `packaging` n'est pas une dépendance déclarée : on s'en tient à une
    comparaison numérique par segments, suffisante pour le schéma
    `MAJEUR.MINEUR.CORRECTIF` utilisé par `release.sh`. Tout segment non
    numérique (suffixe `rc1`, `dev0`…) arrête la lecture, ce qui fait qu'une
    préversion n'est jamais considérée comme supérieure à la version finale.
    """
    segments = []
    for part in str(raw or "").strip().split("."):
        digits = ""
        for char in part:
            if not char.isdigit():
                break
            digits += char
        if not digits:
            break
        segments.append(int(digits))
    return tuple(segments)


def is_newer(published, installed) -> bool:
    """Vrai si `published` est strictement postérieure à `installed`.

    Renvoie False dès qu'une des deux est illisible : dans le doute, on
    n'annonce pas de mise à jour. Un badge affiché à tort use la confiance
    plus vite qu'un badge manquant.
    """
    left, right = _parse(published), _parse(installed)
    if not left or not right:
        return False
    return left > right


def fetch_published_version(url=None):
    """Lit `version.json` sur le canal et renvoie la version publiée.

    Lève `RuntimeError` avec un message lisible en cas d'échec — c'est ce
    message qui sera montré à l'administrateur.
    """
    manifest_url = f"{url or channel_url()}/version.json"
    request = urllib.request.Request(
        manifest_url,
        headers={"User-Agent": "jeiko-update-check"},
    )
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
            payload = response.read(MAX_MANIFEST_BYTES + 1)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"Canal injoignable (HTTP {exc.code}).") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Canal injoignable ({exc.reason}).") from exc
    except OSError as exc:
        raise RuntimeError(f"Canal injoignable ({exc}).") from exc

    if len(payload) > MAX_MANIFEST_BYTES:
        raise RuntimeError("Manifeste anormalement volumineux — ignoré.")

    try:
        manifest = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("Manifeste illisible (JSON invalide).") from exc

    published = (manifest or {}).get("version")
    if not published:
        raise RuntimeError("Manifeste sans champ « version ».")
    return str(published).strip()


def check_for_update():
    """Interroge le canal et enregistre le résultat sur `WebSite`.

    Ne lève jamais : une vérification est une commodité, elle ne doit pas
    faire échouer la cadence qui la porte ni les jobs voisins.

    Renvoie la version disponible (str) si une mise à jour existe, sinon None.
    """
    from jeiko.administration.models import WebSite

    site = WebSite.objects.first()
    if site is None:
        return None

    current = installed_version()
    try:
        published = fetch_published_version()
    except RuntimeError as exc:
        # On garde la dernière disponibilité connue : un canal momentanément
        # injoignable ne doit pas faire disparaître un badge légitime.
        site.update_check_error = str(exc)[:255]
        site.update_last_checked_at = timezone.now()
        site.save(update_fields=["update_check_error", "update_last_checked_at"])
        logger.warning("Vérification de mise à jour JEIKO échouée : %s", exc)
        return None

    available = published if is_newer(published, current) else ""
    site.update_available_version = available
    site.update_check_error = ""
    site.update_last_checked_at = timezone.now()
    site.save(update_fields=[
        "update_available_version",
        "update_check_error",
        "update_last_checked_at",
    ])
    return available or None
