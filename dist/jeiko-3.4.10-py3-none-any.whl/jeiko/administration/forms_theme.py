# jeiko/administration/forms_theme.py
"""
Saisie du thème — dix couleurs, et un aperçu qui les montre.

Le champ `color` du navigateur ne comprend que `#rrggbb` : il refuse
silencieusement `rgb(180, 83, 9)` et retombe sur du noir. Or le modèle accepte
n'importe quelle notation CSS, et les valeurs livrées sont en `rgb()`.

On expose donc **deux champs par couleur** : le sélecteur natif, pratique, et
la valeur en toutes lettres, qui fait foi. Ils se synchronisent dans l'écran.
C'est un peu plus de balisage, mais cela évite le piège classique — un
exploitant qui ouvre l'écran, ne touche à rien, enregistre, et repart avec dix
couleurs devenues noires.
"""

from django import forms

from .models import Theme


class ThemeForm(forms.ModelForm):
    class Meta:
        model = Theme
        fields = [champ for champ, _ in Theme.VARIABLES]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for nom, champ in self.fields.items():
            champ.widget.attrs.update({
                "class": "form-control jk-theme-valeur",
                "data-couleur": nom,
                "autocomplete": "off",
                "spellcheck": "false",
            })

    def clean(self):
        """
        Refuse une valeur qui ne survivrait pas à l'assainissement.

        `clean_css_value` retire les caractères de structure ; si la valeur en
        ressort vide ou amputée, elle n'aurait pas produit ce que l'exploitant
        croit avoir saisi. Mieux vaut le lui dire ici que de le laisser
        chercher pourquoi sa couleur ne s'applique pas.
        """
        from jeiko.templatetags.css_extras import clean_css_value

        donnees = super().clean()
        for nom in self.fields:
            valeur = (donnees.get(nom) or "").strip()
            if not valeur:
                continue
            propre = clean_css_value(valeur)
            if propre != valeur:
                self.add_error(
                    nom,
                    "Cette valeur contient des caractères qui n'ont pas leur "
                    "place dans une couleur (accolade, point-virgule, « @ »…). "
                    f"Elle deviendrait « {propre} ».",
                )
        return donnees
