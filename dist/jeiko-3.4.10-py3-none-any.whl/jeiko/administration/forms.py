from django import forms



from .models import Font, Logo, Favicon, MailSettings, GoogleApi, Legals, SiteIdentity, SocialProvider

from jeiko.administration_pages.models import Page



class FontForm(forms.ModelForm):

    class Meta:
        model = Font
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(FontForm, self).__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form'


class FontFamilyUpdateAllForm(forms.Form):

    family = forms.CharField(
        label="Nouvelle famille de police",
        max_length=100,
        help_text='Ex: Inter, Roboto, Playfair Display, Georgia…',
        widget=forms.TextInput(attrs={"placeholder": "Inter"})
    )

    def clean_family(self):
        v = (self.cleaned_data.get("family") or "").strip()
        if not v:
            raise forms.ValidationError("La famille de police ne peut pas être vide.")
        # normalisation soft: espaces internes réduits
        v = " ".join(v.split())
        return v


class LogoForm(forms.ModelForm):
    """
    Le logo du site, et son remplaçant facultatif pour les e-mails.

    `mail_logo` n'a pas de case « activer » : le renseigner l'active, le vider
    revient au logo du site. Voir `Logo.mail_logo` pour le pourquoi.
    """

    class Meta:
        model = Logo
        fields = [
            'full_size',
            'mail_logo',
        ]


class FaviconForm(forms.ModelForm):

    class Meta:
        model = Favicon
        fields = [
            'source',
        ]


class MailSettingsForm(forms.ModelForm):
    host_password = forms.CharField(
        label="Mot de passe SMTP",
        widget=forms.PasswordInput(render_value=True),
        required=False,
        help_text="Mot de passe du serveur SMTP"
    )

    class Meta:
        model = MailSettings
        fields = [
            "host", "port", "use_tls", "use_ssl", "host_user", "host_password",
            "default_from_email", "reply_to_email", "active", "test_receiver"
        ]


class GoogleApiForm(forms.ModelForm):
    class Meta:
        model = GoogleApi
        fields = ["psi_api_key"]
        widgets = {
            "psi_api_key": forms.PasswordInput(render_value=False, attrs={"autocomplete": "new-password"}),
        }
        labels = {
            "psi_api_key": "Clé API PageSpeed Insights",
        }
        help_texts = {
            "psi_api_key": "Colle ici ta clé PSI. Laisse vide pour utiliser la variable d'environnement.",
        }


class LegalsAdminForm(forms.ModelForm):
    class Meta:
        model = Legals
        fields = ["privacy_page", "cgv_page", "cgu_page", "mentions_page"]  # pas de 'site' ici

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        qs = Page.objects.all()
        for fname in ("privacy_page", "cgv_page", "cgu_page", "mentions_page"):
            self.fields[fname].queryset = qs
            self.fields[fname].required = False

class SiteIdentityForm(forms.ModelForm):
    type = forms.ChoiceField(
        choices=SiteIdentity.TYPE_CHOICES,
        widget=forms.RadioSelect
    )

    class Meta:
        model = SiteIdentity
        fields = [
            "type", "name", "url", "telephone",
            "street_address", "address_locality", "address_region",
            "postal_code", "address_country",
            "geo_lat", "geo_lng", "price_range",
        ]
        help_texts = {
            "address_country": "Code pays ISO-3166-1 alpha-2 (ex: FR, CH, BE).",
        }

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("type") == SiteIdentity.TYPE_LOCAL:
            required = ["name", "street_address", "address_locality", "postal_code", "address_country"]
            for f in required:
                if not cleaned.get(f):
                    self.add_error(f, "Champ requis pour LocalBusiness.")
        return cleaned

class SocialProviderForm(forms.ModelForm):
    """
    Un formulaire par fournisseur. Les libellés/champs sensibles s'adaptent
    au provider (Apple a des champs supplémentaires : Team ID + clé .p8).
    """

    class Meta:
        model = SocialProvider
        fields = ["enabled", "client_id", "secret", "key", "certificate_key"]
        widgets = {
            "secret": forms.PasswordInput(render_value=True, attrs={"autocomplete": "new-password"}),
            "certificate_key": forms.Textarea(attrs={"rows": 5, "autocomplete": "off"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        provider = getattr(self.instance, "provider", None)

        for name, field in self.fields.items():
            css = "form"
            if name == "enabled":
                css = "form-check"
            field.widget.attrs.setdefault("class", css)

        # Apple : garder Team ID + certificat ; sinon les retirer du formulaire.
        if provider != SocialProvider.PROVIDER_APPLE:
            self.fields.pop("key", None)
            self.fields.pop("certificate_key", None)
        else:
            self.fields["client_id"].label = "Services ID"
            self.fields["secret"].label = "Key ID"
            self.fields["key"].label = "Team ID"

    def clean(self):
        cleaned = super().clean()
        # On empêche d'activer un provider sans identifiants complets.
        if cleaned.get("enabled"):
            provider = getattr(self.instance, "provider", None)
            missing = not cleaned.get("client_id") or not cleaned.get("secret")
            if provider == SocialProvider.PROVIDER_APPLE:
                missing = missing or not cleaned.get("key") or not cleaned.get("certificate_key")
            if missing:
                raise forms.ValidationError(
                    "Renseigne tous les identifiants avant d'activer ce fournisseur."
                )
        return cleaned
