"""
Tâches planifiées — toutes les 5 minutes.

Lancé par le timer systemd jeiko-cron-5m@<site>.timer.

Jobs :
  - rappels de rendez-vous (24 h et 2 h avant), idempotents ;
  - vidage de la file d'attente des e-mails différés ;
  - libération des créneaux payants non réglés.
"""
from jeiko.administration.management.commands._cron import CronCommand


def job_appointment_reminders():
    from jeiko.calendars.emailing import send_due_reminders
    sent_24h, sent_2h, sent_pro = send_due_reminders()
    return (f"{sent_24h} rappel(s) client 24 h, {sent_2h} à 2 h, "
            f"{sent_pro} rappel(s) praticien 1 h")


def job_flush_email_queue():
    from jeiko.emailing.services import flush_queue
    sent, failed = flush_queue()
    return f"{sent} envoyé(s), {failed} échec(s)"


def job_expire_holds():
    from jeiko.calendars import payments
    released = payments.expire_holds()
    return f"{released} créneau(x) libéré(s)"


class Command(CronCommand):
    help = "Tâches planifiées à exécuter toutes les 5 minutes."
    cadence = "5m"

    def get_jobs(self):
        return [
            ("rappels de rendez-vous", job_appointment_reminders),
            ("file d'attente e-mails", job_flush_email_queue),
            ("libération des créneaux non réglés", job_expire_holds),
        ]
