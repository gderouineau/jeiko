"""
Socle commun des tâches planifiées.

Le serveur ne connaît que des cadences (timers systemd : 5 min, 30 min, 1 h,
24 h), chacune lançant `manage.py cron_<cadence>`. Le contenu de chaque cadence
vit ici, dans le package : ajouter ou retirer un job est une modification de
code, livrée par la mise à jour normale — jamais une intervention serveur.

`run_jobs` isole les jobs les uns des autres : l'échec de l'un ne doit pas
empêcher les suivants de s'exécuter, ni faire échouer le passage du timer.
"""
import logging
import re
import traceback

from django.core.management.base import BaseCommand

logger = logging.getLogger("jeiko.cron")

# Heure des cadences quotidiennes : la nuit, hors des fenêtres de sauvegarde.
DAILY_TIME = "03:30:00"

_CADENCE_RE = re.compile(r"^(\d+)([mhd])$")


def default_on_calendar(cadence):
    """
    Traduit une cadence ("5m", "30m", "1h", "24h", "7d") en expression
    OnCalendar systemd.

    C'est ce qui permet à l'installeur de créer le timer d'une nouvelle cadence
    sans rien savoir d'elle : il suffit de déposer un `cron_<cadence>.py` dans
    le package. Une sous-classe peut toujours forcer `on_calendar` si le
    résultat ne convient pas.
    """
    match = _CADENCE_RE.match(cadence or "")
    if not match:
        return None

    value, unit = int(match.group(1)), match.group(2)
    if value <= 0:
        return None

    if unit == "m":
        if value < 60:
            # Toutes les N minutes, alignées sur l'heure ronde.
            return f"*:0/{value}"
        value, unit = value // 60, "h"

    if unit == "h":
        if value == 1:
            return "*-*-* *:00:00"
        if value < 24:
            return f"*-*-* 0/{value}:00:00"
        # 24 h et plus : une seule fois par jour, à heure fixe.
        return f"*-*-* {DAILY_TIME}"
    # Jours : systemd ne sait pas exprimer « tous les N jours » simplement ;
    # on planifie quotidiennement, au job de décider s'il a quelque chose à faire.
    return f"*-*-* {DAILY_TIME}"


def default_randomized_delay(cadence):
    """
    Étalement aléatoire du déclenchement.

    Plusieurs sites cohabitent sur une même machine : sans décalage, leurs
    timers partent à la même seconde et se disputent le CPU et la base.
    Plafonné à un dixième de la période pour ne pas dériver.
    """
    match = _CADENCE_RE.match(cadence or "")
    if not match:
        return 0
    value, unit = int(match.group(1)), match.group(2)
    seconds = value * {"m": 60, "h": 3600, "d": 86400}[unit]
    return min(seconds // 10, 300)


class CronCommand(BaseCommand):
    """
    Base des commandes cron_*. Les sous-classes ne définissent que `cadence`
    (pour les messages) et `get_jobs()`, qui retourne une liste de (nom, appel).

    Les attributs de planification ci-dessous sont lus par la commande
    `jeiko_cron_units`, qui les expose à l'installeur : la cadence est déclarée
    ici, dans le code, et le serveur s'y conforme.
    """

    cadence = ""

    # Expression OnCalendar systemd. None => dérivée de la cadence.
    on_calendar = None
    # Rejouer un déclenchement manqué (serveur éteint, redémarrage).
    persistent = True
    # Décalage aléatoire en secondes. None => dérivé de la cadence.
    randomized_delay_sec = None
    # Passer à False pour livrer une cadence sans l'activer sur les serveurs.
    enabled = True

    @classmethod
    def schedule_spec(cls):
        """Description de la planification, consommée par `jeiko_cron_units`."""
        cadence = cls.cadence
        delay = cls.randomized_delay_sec
        return {
            "cadence": cadence,
            "command": f"cron_{cadence}",
            "on_calendar": cls.on_calendar or default_on_calendar(cadence),
            "persistent": bool(cls.persistent),
            "randomized_delay_sec": (
                default_randomized_delay(cadence) if delay is None else int(delay)
            ),
            "description": (cls.help or f"Tâches planifiées ({cadence})").strip(),
        }

    def get_jobs(self):
        raise NotImplementedError

    def handle(self, *args, **options):
        jobs = self.get_jobs()
        if not jobs:
            self.stdout.write(f"[{self.cadence}] Aucun job configuré.")
            return

        failures = 0
        for name, func in jobs:
            try:
                summary = func()
                self.stdout.write(self.style.SUCCESS(
                    f"[{self.cadence}] {name} : {summary or 'ok'}"
                ))
            except Exception as exc:
                failures += 1
                logger.exception("Job cron '%s' en échec", name)
                self.stderr.write(self.style.ERROR(
                    f"[{self.cadence}] {name} : ÉCHEC — {exc}"
                ))
                self.stderr.write(traceback.format_exc())

        if failures:
            # Sortie non nulle : le timer systemd marque l'unité en échec, ce qui
            # remonte dans `systemctl status` et le journal.
            raise SystemExit(1)
