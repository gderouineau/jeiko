"""
Tâches planifiées — toutes les heures.

Lancé par le timer systemd jeiko-cron-1h@<site>.timer.

Jobs :
  - récapitulatif quotidien du praticien : balayé chaque heure, ne part qu'à
    l'heure d'envoi (DAILY_DIGEST_HOUR dans calendars.emailing).

Autres candidats : relance des formations en pause, alerte de stock bas,
réactivation des inactifs.
"""
from jeiko.administration.management.commands._cron import CronCommand


def job_daily_provider_digests():
    from jeiko.calendars.emailing import send_daily_provider_digests
    sent = send_daily_provider_digests()
    return f"{sent} récapitulatif(s) envoyé(s)"


class Command(CronCommand):
    help = "Tâches planifiées à exécuter toutes les heures."
    cadence = "1h"

    def get_jobs(self):
        return [
            ("récapitulatif quotidien praticien", job_daily_provider_digests),
        ]
