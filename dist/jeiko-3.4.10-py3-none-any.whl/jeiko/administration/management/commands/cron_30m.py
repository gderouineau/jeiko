"""
Tâches planifiées — toutes les 30 minutes.

Lancé par le timer systemd jeiko-cron-30m@<site>.timer.

Aucun job pour l'instant. Pour en ajouter un : écrire une fonction
`job_xxx()` qui retourne un court résumé, puis l'inscrire dans `get_jobs()`.
Candidats : relance des tests commencés non terminés, relance de panier abandonné.
"""
from jeiko.administration.management.commands._cron import CronCommand


class Command(CronCommand):
    help = "Tâches planifiées à exécuter toutes les 30 minutes."
    cadence = "30m"

    def get_jobs(self):
        return []
