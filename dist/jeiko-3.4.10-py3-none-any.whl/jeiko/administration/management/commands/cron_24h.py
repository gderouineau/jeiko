"""
Tâches planifiées — une fois par jour.

Lancé par le timer systemd jeiko-cron-24h@<site>.timer.

Les campagnes déclenchées par le temps — anniversaire, panier abandonné,
formation en sommeil, purge du journal — vivent dans `jeiko.emailing.campaigns`
et sont appelées ici. Elles sont idempotentes : un timer qui repasse ne renvoie
rien.

Candidat non encore posé : récapitulatif quotidien à l'administrateur.
"""
from jeiko.administration.management.commands._cron import CronCommand
from jeiko.administration.update_check import check_for_update


def job_check_jeiko_update():
    """Regarde si une version plus récente de JEIKO est publiée.

    Ne met rien à jour : renseigne seulement `WebSite.update_available_version`,
    d'où le badge du menu et de la barre d'administration tire son compte.
    L'exécution reste un geste manuel, depuis « Réglages → Mettre à jour JEIKO ».
    """
    check_for_update()


def job_refresh_page_insights():
    """Remesure les pages dont le score PageSpeed date de plus d'une semaine.

    Plafonné par passage et interrompu au premier refus pour quota : les pages
    non traitées restent périmées et repasseront le lendemain. Voir
    `administration_pages/insights_cron.py`.
    """
    from jeiko.administration_pages.insights_cron import refresh_stale_insights
    refresh_stale_insights()


def job_anniversaires():
    """Souhaite l'anniversaire aux comptes dont c'est le jour.

    Marketing : `send_email` n'expédie qu'aux comptes ayant donné leur opt-in,
    et l'e-mail reste désactivable depuis l'administration.
    """
    from jeiko.emailing.campaigns import souhaiter_les_anniversaires
    souhaiter_les_anniversaires()


def job_paniers_abandonnes():
    """Relance les paniers laissés en plan depuis plus d'un jour."""
    from jeiko.emailing.campaigns import relancer_les_paniers_abandonnes
    relancer_les_paniers_abandonnes()


def job_formations_en_sommeil():
    """Rappelle une formation commencée puis délaissée depuis deux semaines."""
    from jeiko.emailing.campaigns import relancer_les_formations_en_sommeil
    relancer_les_formations_en_sommeil()


def job_purge_journal_emails():
    """Retire du journal d'envoi les lignes de plus d'un an.

    Sans elle, cette table grossit d'une ligne par e-mail expédié et finit par
    être la plus volumineuse du site.
    """
    from jeiko.emailing.campaigns import purger_le_journal_des_envois
    purger_le_journal_des_envois()


def job_purge_audience():
    """Retire les vues de page au-delà du délai de conservation.

    La commande `stats_purge` existait depuis longtemps et n'était appelée
    NULLE PART : les données d'audience s'accumulaient sans limite, ce qui est
    à la fois une table qui enfle et une conservation que rien ne justifie.
    Délai réglable par `--days` (défaut : 180 jours).
    """
    from django.core.management import call_command
    call_command("stats_purge", verbosity=0)
    return "vues de page au-delà de 180 jours supprimées"


def job_purge_comptes_non_confirmes():
    """Supprime les inscriptions jamais confirmées, au-delà de 30 jours.

    Depuis que la confirmation d'adresse est obligatoire, une inscription non
    suivie laisse un compte inutilisable — le plus souvent automatisé. Les
    comptes du personnel, et ceux rattachés à une commande, une formation ou un
    rendez-vous, sont protégés quoi qu'il arrive : voir users/purge.py.
    """
    from jeiko.users.purge import purger_les_comptes_non_confirmes
    nombre = purger_les_comptes_non_confirmes()
    return f"{nombre} compte(s) non confirmé(s) supprimé(s)"


def job_purge_rendez_vous():
    """Anonymise et purge les rendez-vous au-delà des délais de conservation.

    Même constat que ci-dessus : `jeiko_calendars_purge` était écrite, testée,
    et jamais déclenchée. Les délais viennent des réglages du site
    (`JEIKO_CALENDARS_ANONYMIZE_AFTER_MONTHS` et voisins), pas d'ici : chaque
    exploitant a ses obligations de conservation.
    """
    from django.core.management import call_command
    call_command("jeiko_calendars_purge", verbosity=0)
    return "rendez-vous anonymisés et purgés selon les délais configurés"


def job_stocks_bas():
    """Signale les produits passés sous le seuil d'alerte.

    Un seul message pour tous les produits concernés : dix e-mails parce que dix
    références sont basses feraient fermer la boîte, pas réapprovisionner.
    """
    from jeiko.emailing.admin_alerts import alerter_sur_les_stocks_bas
    alerter_sur_les_stocks_bas()


def job_recapitulatif_quotidien():
    """Synthèse de la veille : rendez-vous, commandes, nouveaux comptes.

    Rien n'est envoyé si la journée a été vide : on n'écrit pas pour dire qu'il
    ne s'est rien passé.
    """
    from jeiko.emailing.admin_alerts import envoyer_le_recapitulatif_quotidien
    envoyer_le_recapitulatif_quotidien()


class Command(CronCommand):
    help = "Tâches planifiées à exécuter une fois par jour."
    cadence = "24h"

    def get_jobs(self):
        return [
            ("vérification des mises à jour JEIKO", job_check_jeiko_update),
            ("rafraîchissement des scores PageSpeed", job_refresh_page_insights),
            ("souhaits d'anniversaire", job_anniversaires),
            ("relance des paniers abandonnés", job_paniers_abandonnes),
            ("relance des formations en sommeil", job_formations_en_sommeil),
            ("purge du journal d'envoi", job_purge_journal_emails),
            ("purge des vues de page", job_purge_audience),
            ("purge des rendez-vous", job_purge_rendez_vous),
            ("purge des comptes non confirmés", job_purge_comptes_non_confirmes),
            ("alerte stock bas", job_stocks_bas),
            ("récapitulatif quotidien", job_recapitulatif_quotidien),
        ]
