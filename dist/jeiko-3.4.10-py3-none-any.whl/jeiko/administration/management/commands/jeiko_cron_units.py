"""
Inventaire des tâches planifiées, à destination de l'installeur serveur.

Le serveur ne doit pas avoir à connaître la liste des cadences : il la demande
au package. Déposer un `cron_<cadence>.py` quelque part dans jeiko suffit donc
à faire apparaître le timer correspondant à la prochaine mise à jour serveur —
et en retirer un fait disparaître le timer.

    manage.py jeiko_cron_units --json      # consommé par jeiko-server-update
    manage.py jeiko_cron_units             # lisible, pour vérifier en SSH
"""
import json

from django.core.management import get_commands, load_command_class
from django.core.management.base import BaseCommand

from ._cron import CronCommand


def discover_cron_commands():
    """
    Retourne les specs de planification de toutes les commandes `cron_*`.

    On interroge le registre Django plutôt que le système de fichiers : les
    cadences peuvent vivre dans n'importe quelle app installée, et une app
    absente du site ne doit pas produire de timer.
    """
    specs = []
    for name, app_name in sorted(get_commands().items()):
        if not name.startswith("cron_"):
            continue
        try:
            command = load_command_class(app_name, name)
        except Exception:
            # Une commande cassée ne doit pas empêcher les autres d'être planifiées.
            continue

        command_class = type(command)
        if not issubclass(command_class, CronCommand) or command_class is CronCommand:
            continue
        if not getattr(command_class, "enabled", True):
            continue

        spec = command_class.schedule_spec()
        # Sans expression OnCalendar exploitable, on ne sait pas planifier.
        if not spec.get("on_calendar"):
            continue
        spec["app"] = app_name
        spec["job_count"] = _safe_job_count(command)
        specs.append(spec)
    return specs


def _safe_job_count(command):
    try:
        return len(command.get_jobs())
    except Exception:
        return None


class Command(BaseCommand):
    help = "Liste les cadences de tâches planifiées et leur programmation systemd."

    def add_arguments(self, parser):
        parser.add_argument(
            "--json",
            action="store_true",
            help="Sortie JSON, destinée aux scripts d'installation et de mise à jour.",
        )

    def handle(self, *args, **options):
        specs = discover_cron_commands()

        if options["json"]:
            # Sortie brute : aucun autre écrit sur stdout, le script la parse.
            self.stdout.write(json.dumps(specs, ensure_ascii=False))
            return

        if not specs:
            self.stdout.write("Aucune cadence déclarée.")
            return

        self.stdout.write(f"{len(specs)} cadence(s) déclarée(s) :\n")
        for spec in specs:
            jobs = spec["job_count"]
            jobs_label = "?" if jobs is None else f"{jobs} job(s)"
            self.stdout.write(
                f"  {spec['cadence']:>5}  {spec['on_calendar']:<22} "
                f"délai {spec['randomized_delay_sec']:>3}s  "
                f"persistant={'oui' if spec['persistent'] else 'non':<3} "
                f"{jobs_label:<10} ({spec['app']})"
            )
