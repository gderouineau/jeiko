"""
(Re)génère les bundles de polices self-hostées (woff2 + CSS local) pour tous
les sites, ou pour un site donné.

Utile pour :
- le backfill initial après déploiement du self-hosting,
- un dépannage si un bundle est manquant/corrompu,
- rafraîchir après une modif faite hors des vues admin habituelles.

    python manage.py rebuild_fonts
    python manage.py rebuild_fonts --site 1
"""

from django.core.management.base import BaseCommand

from jeiko.administration.models import WebSite
from jeiko.fonts_selfhost import rebuild_site_fonts, gc_orphan_families


class Command(BaseCommand):
    help = "Reconstruit les bundles de Google Fonts self-hostées (public)."

    def add_arguments(self, parser):
        parser.add_argument(
            "--site", type=int, default=None,
            help="ID d'un WebSite précis (sinon : tous les sites).",
        )

    def handle(self, *args, **options):
        qs = WebSite.objects.all()
        if options["site"] is not None:
            qs = qs.filter(pk=options["site"])

        if not qs.exists():
            self.stderr.write(self.style.WARNING("Aucun site à traiter."))
            return

        for site in qs:
            self.stdout.write(f"Site {site.id} : reconstruction…")
            report = rebuild_site_fonts(site)
            ok = ", ".join(report["ok"]) or "—"
            failed = ", ".join(report["failed"]) or "—"
            self.stdout.write(self.style.SUCCESS(
                f"  {len(report['ok'])} OK ({ok}) | {len(report['failed'])} échec(s) ({failed})"
            ))
            self.stdout.write(f"  CSS : {report['css_path']}")

        # Purge des dossiers de familles woff2 qui ne sont plus référencés.
        # On ne purge pas quand un seul site est ciblé (--site) : le calcul des
        # familles à garder est global, mais on évite de surprendre l'opérateur
        # qui répare un site précis.
        if options["site"] is None:
            gc_orphan_families()
            self.stdout.write("Purge des familles woff2 orphelines : terminée.")
