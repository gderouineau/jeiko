# jeiko/calendars/tests_refund.py
"""
Remboursement d'un rendez-vous payant annulé.

Politique testée :
- annulation PAR LE CLIENT, dans le délai (`cancellation_deadline_hours`) →
  remboursement intégral automatique ;
- annulation client tardive → aucun remboursement automatique ;
- annulation PAR LE GESTIONNAIRE → jamais automatique (bouton manuel).

Stripe est simulé : `stripe.Refund.create` est mocké, aucun appel réseau.
"""
from datetime import timedelta
from decimal import Decimal
from unittest import mock

from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from . import payments
from .models import Appointment, AppointmentType, Availability, Slot
from .tests import grant_calendar_perms

User = get_user_model()


class RefundFixture(TestCase):
    PRICE = Decimal("50.00")
    DEADLINE_HOURS = 24

    def setUp(self):
        self.manager = grant_calendar_perms(
            User.objects.create_user(username="manager", password="pwd12345")
        )
        self.type = AppointmentType.objects.create(
            name="Consultation", user=self.manager, duration=timedelta(hours=1),
            capacity=1, is_paid=True, price=self.PRICE,
            cancellation_deadline_hours=self.DEADLINE_HOURS,
        )
        # Rendez-vous dans 3 jours (donc bien avant le délai de 24h).
        start = (timezone.now() + timedelta(days=3)).replace(
            minute=0, second=0, microsecond=0
        )
        self.availability = Availability.objects.create(
            user=self.manager, start=start, end=start + timedelta(hours=1)
        )
        self.availability.appointment_types.add(self.type)
        self.slot = Slot.objects.get(availability=self.availability, type=self.type)

        # Passerelle Stripe active (clés factices).
        gw = mock.patch.object(
            payments, "get_gateway",
            return_value=mock.Mock(secret_key="sk_test", api_key="pk_test",
                                   webhook_secret="wh", is_active=True),
        )
        gw.start(); self.addCleanup(gw.stop)

        # stripe.Refund.create -> objet factice
        self.refund_create = mock.patch(
            "stripe.Refund.create", return_value={"id": "re_test_123"}
        )
        self.mock_refund = self.refund_create.start()
        self.addCleanup(self.refund_create.stop)

        # e-mail de remboursement neutralisé.
        mail = mock.patch("jeiko.calendars.emailing.send_refund_email")
        self.mock_mail = mail.start(); self.addCleanup(mail.stop)

    def make_paid_appt(self, start=None):
        appt = Appointment.objects.create(
            type=self.type, slot=self.slot,
            start=start or self.slot.start, end=(start or self.slot.start) + timedelta(hours=1),
            email="client@example.com", client_name="Marie Martin", places=1,
            status=Appointment.Status.CONFIRMED, is_paid=True,
            amount_due=self.PRICE, paid_at=timezone.now(),
            payment_intent_id="pi_test_abc",
        )
        self.slot.sync_remaining_places()
        return appt


class AutoRefundOnClientCancelTests(RefundFixture):

    def test_client_cancel_in_time_triggers_full_refund(self):
        appt = self.make_paid_appt()
        with self.captureOnCommitCallbacks(execute=True):
            appt.cancel(by=Appointment.CancelledBy.CLIENT)

        self.mock_refund.assert_called_once()
        _, kwargs = self.mock_refund.call_args
        self.assertEqual(kwargs["payment_intent"], "pi_test_abc")
        self.assertNotIn("amount", kwargs)  # remboursement TOTAL, pas de montant partiel

        appt.refresh_from_db()
        self.assertTrue(appt.is_refunded)
        self.assertEqual(appt.refund_amount, self.PRICE)
        self.assertEqual(appt.refund_id, "re_test_123")

    def test_client_cancel_too_late_does_not_refund(self):
        # RDV dans 2h, délai de 24h → hors fenêtre.
        soon = timezone.now() + timedelta(hours=2)
        appt = self.make_paid_appt(start=soon)
        with self.captureOnCommitCallbacks(execute=True):
            appt.cancel(by=Appointment.CancelledBy.CLIENT)

        self.mock_refund.assert_not_called()
        appt.refresh_from_db()
        self.assertFalse(appt.is_refunded)

    def test_manager_cancel_never_auto_refunds(self):
        appt = self.make_paid_appt()
        with self.captureOnCommitCallbacks(execute=True):
            appt.cancel(by=Appointment.CancelledBy.MANAGER)
        self.mock_refund.assert_not_called()
        appt.refresh_from_db()
        self.assertFalse(appt.is_refunded)

    def test_refund_email_is_sent(self):
        appt = self.make_paid_appt()
        with self.captureOnCommitCallbacks(execute=True):
            appt.cancel(by=Appointment.CancelledBy.CLIENT)
        self.mock_mail.assert_called_once()

    def test_unpaid_hold_expiry_does_not_refund(self):
        pending = Appointment.objects.create(
            type=self.type, slot=self.slot, start=self.slot.start, end=self.slot.end,
            email="x@example.com", places=1,
            status=Appointment.Status.PENDING_PAYMENT,
            amount_due=self.PRICE,
            hold_expires_at=timezone.now() - timedelta(minutes=1),
        )
        with self.captureOnCommitCallbacks(execute=True):
            pending.release_expired_hold()
        self.mock_refund.assert_not_called()

    def test_free_appointment_cancel_does_not_refund(self):
        free = AppointmentType.objects.create(
            name="Gratuit", user=self.manager, duration=timedelta(hours=1), capacity=1
        )
        self.availability.appointment_types.add(free)
        free_slot = Slot.objects.get(availability=self.availability, type=free)
        appt = Appointment.objects.create(
            type=free, slot=free_slot, start=free_slot.start, end=free_slot.end,
            email="g@example.com", status=Appointment.Status.CONFIRMED,
        )
        with self.captureOnCommitCallbacks(execute=True):
            appt.cancel(by=Appointment.CancelledBy.CLIENT)
        self.mock_refund.assert_not_called()

    def test_refund_is_idempotent(self):
        appt = self.make_paid_appt()
        payments.refund_appointment(appt, by_system=False)
        self.mock_refund.reset_mock()
        # Deuxième appel : déjà remboursé, aucun nouvel appel Stripe.
        payments.refund_appointment(appt, by_system=False)
        self.mock_refund.assert_not_called()


@override_settings(DEBUG=True)  # évite le template 404 du projet en test
class ManualRefundViewTests(RefundFixture):

    def _refund_url(self, appt):
        return reverse("jeiko_administration_calendars:appointment_refund",
                       kwargs={"pk": appt.pk})

    def test_manager_can_refund_manually(self):
        appt = self.make_paid_appt()
        appt.cancel(by=Appointment.CancelledBy.MANAGER)  # pas de refund auto
        self.mock_refund.reset_mock()

        self.client.force_login(self.manager)
        with self.captureOnCommitCallbacks(execute=True):
            resp = self.client.post(self._refund_url(appt))
        self.assertEqual(resp.status_code, 302)
        self.mock_refund.assert_called_once()
        appt.refresh_from_db()
        self.assertTrue(appt.is_refunded)

    def test_other_manager_cannot_refund(self):
        appt = self.make_paid_appt()
        other = grant_calendar_perms(
            User.objects.create_user(username="autre", password="pwd12345")
        )
        self.client.force_login(other)
        resp = self.client.post(self._refund_url(appt))
        self.assertEqual(resp.status_code, 404)
        self.mock_refund.assert_not_called()

    def test_refund_button_absent_when_not_refundable(self):
        # Rendez-vous non payé : pas de bouton de remboursement au détail.
        appt = Appointment.objects.create(
            type=self.type, slot=self.slot, start=self.slot.start, end=self.slot.end,
            email="np@example.com", status=Appointment.Status.CONFIRMED,
        )
        self.client.force_login(self.manager)
        resp = self.client.get(
            reverse("jeiko_administration_calendars:appointment_detail", kwargs={"pk": appt.pk})
        )
        self.assertNotContains(resp, "appointment_refund")


class WebhookRefundTests(RefundFixture):

    def test_charge_refunded_marks_appointment(self):
        appt = self.make_paid_appt()
        payments.mark_refunded_from_charge({
            "id": "ch_1",
            "payment_intent": "pi_test_abc",
            "amount_refunded": 5000,  # 50,00 €
        })
        appt.refresh_from_db()
        self.assertTrue(appt.is_refunded)
        self.assertEqual(appt.refund_amount, Decimal("50.00"))

    def test_charge_for_unknown_intent_is_harmless(self):
        result = payments.mark_refunded_from_charge({
            "id": "ch_2", "payment_intent": "pi_unknown", "amount_refunded": 100,
        })
        self.assertIsNone(result)


@override_settings(DEBUG=True)
class RefundNoticeTests(RefundFixture):

    def test_cancel_page_announces_refund_in_time(self):
        appt = self.make_paid_appt()
        resp = self.client.get(appt.get_public_cancel_url())
        self.assertContains(resp, "remboursé de")

    def test_cancel_page_warns_when_too_late(self):
        soon = timezone.now() + timedelta(hours=2)
        appt = self.make_paid_appt(start=soon)
        resp = self.client.get(appt.get_public_cancel_url())
        self.assertContains(resp, "trop tardive")
