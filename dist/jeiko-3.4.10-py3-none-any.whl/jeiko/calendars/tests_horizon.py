# jeiko/calendars/tests_horizon.py
"""
Horizon glissant des réservations.

Les créneaux ne sont matérialisés que sur une profondeur donnée, figée au
moment où la disponibilité est enregistrée. Sans repasse quotidienne, une
disponibilité récurrente cesse d'ouvrir des créneaux — sans erreur, sans
alerte. `jeiko_calendars_regenerate` fait glisser cette fenêtre.
"""
from datetime import timedelta
from io import StringIO

from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import TestCase, override_settings
from django.utils import timezone

from .models import Appointment, AppointmentType, Availability, Slot
from .recurrence import build_rrulestr

User = get_user_model()


class HorizonFixture(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="prov", password="pwd12345")
        self.type = AppointmentType.objects.create(
            name="Séance", user=self.user, duration=timedelta(hours=1), capacity=1
        )
        self.start = (timezone.now() + timedelta(days=1)).replace(
            hour=9, minute=0, second=0, microsecond=0
        )

    def make_weekly(self, horizon_days=None):
        """Disponibilité hebdomadaire sans date de fin."""
        availability = Availability.objects.create(
            user=self.user, start=self.start, end=self.start + timedelta(hours=1),
            recurring_rule=build_rrulestr(
                start=self.start, freq="WEEKLY", byday=["MO", "TU", "WE", "TH", "FR"]
            ),
        )
        availability.appointment_types.add(self.type)
        if horizon_days:
            availability.generate_slots(horizon_days=horizon_days)
        return availability

    def run_command(self, **kwargs):
        out = StringIO()
        err = StringIO()
        call_command("jeiko_calendars_regenerate", stdout=out, stderr=err, **kwargs)
        return out.getvalue(), err.getvalue()


class HorizonSlidingTests(HorizonFixture):

    def test_short_horizon_then_regeneration_opens_more(self):
        availability = self.make_weekly(horizon_days=7)
        narrow = availability.slots.count()
        self.assertGreater(narrow, 0)

        self.run_command(horizon_days=60)

        wide = availability.slots.count()
        self.assertGreater(wide, narrow)

    def test_regeneration_reaches_the_requested_horizon(self):
        availability = self.make_weekly(horizon_days=7)
        self.run_command(horizon_days=45)

        furthest = availability.slots.order_by("-start").first()
        self.assertGreater(furthest.start, timezone.now() + timedelta(days=30))

    def test_running_twice_creates_nothing_new(self):
        self.make_weekly(horizon_days=30)
        self.run_command(horizon_days=30)
        after_first = Slot.objects.count()
        self.run_command(horizon_days=30)
        self.assertEqual(Slot.objects.count(), after_first)

    @override_settings(JEIKO_CALENDARS_HORIZON_DAYS=15)
    def test_horizon_comes_from_settings(self):
        availability = self.make_weekly()          # utilise le réglage du site
        furthest = availability.slots.order_by("-start").first()
        self.assertLess(furthest.start, timezone.now() + timedelta(days=16))

    def test_availability_without_type_is_skipped_not_crashed(self):
        Availability.objects.create(
            user=self.user, start=self.start, end=self.start + timedelta(hours=1)
        )
        out, err = self.run_command()
        self.assertIn("ignorée", out)
        self.assertEqual(err, "")

    def test_unknown_user_is_reported(self):
        with self.assertRaises(CommandError):
            self.run_command(username="fantome")

    def test_filtering_by_user_leaves_others_alone(self):
        other = User.objects.create_user(username="autre", password="pwd12345")
        other_type = AppointmentType.objects.create(
            name="Autre", user=other, duration=timedelta(hours=1), capacity=1
        )
        other_availability = Availability.objects.create(
            user=other, start=self.start, end=self.start + timedelta(hours=2)
        )
        other_availability.appointment_types.add(other_type)
        other_availability.slots.all().delete()

        self.make_weekly(horizon_days=7)
        self.run_command(username="prov", horizon_days=30)

        self.assertEqual(other_availability.slots.count(), 0)

    def test_dry_run_changes_nothing(self):
        self.make_weekly(horizon_days=7)
        before = Slot.objects.count()
        out, _ = self.run_command(dry_run=True, horizon_days=60)
        self.assertEqual(Slot.objects.count(), before)
        self.assertIn("simulation", out.lower())

    def test_reports_availabilities_that_open_nothing(self):
        """
        Cas silencieux typique : la plage est plus courte que la durée du type
        (ici 30 min pour une séance d'1 h). Aucun créneau ne peut être découpé,
        aucune erreur n'est levée — le gestionnaire croit avoir ouvert des
        disponibilités et personne ne peut réserver.
        """
        dead = Availability.objects.create(
            user=self.user, start=self.start, end=self.start + timedelta(minutes=30)
        )
        dead.appointment_types.add(self.type)   # type d'une heure
        self.assertEqual(dead.slots.count(), 0)

        out, _ = self.run_command()
        self.assertIn("n'ouvrent aucun créneau", out)
        self.assertIn(f"#{dead.pk}", out)

    def test_inverted_dates_are_reported_not_crashed(self):
        broken = Availability.objects.create(
            user=self.user, start=self.start, end=self.start - timedelta(hours=1)
        )
        broken.appointment_types.add(self.type)

        out, err = self.run_command()
        self.assertEqual(err, "")
        self.assertIn("n'ouvrent aucun créneau", out)


class RegenerationPreservesHistoryTests(HorizonFixture):
    """
    Le nettoyage supprime des créneaux, et `Appointment.slot` est en CASCADE :
    un créneau porteur du moindre rendez-vous doit survivre, même annulé.
    """

    def _availability_with_out_of_window_appointment(self, status):
        """
        Une plage active, plus un créneau HORS de cette plage qui porte un
        rendez-vous. C'est le seul cas où le nettoyage envisage la suppression :
        un créneau hors fenêtre et « complet en places » (donc, une fois le
        rendez-vous annulé, candidat au delete → CASCADE sur l'historique).
        """
        availability = Availability.objects.create(
            user=self.user, start=self.start, end=self.start + timedelta(hours=1)
        )
        availability.appointment_types.add(self.type)

        past = self.start - timedelta(days=400)   # hors de la fenêtre de la plage
        slot = Slot.objects.create(
            availability=availability, type=self.type,
            start=past, end=past + timedelta(hours=1),
            capacity=1, remaining_places=1, is_available=True,
        )
        appt = Appointment.objects.create(
            type=self.type, slot=slot, start=slot.start, end=slot.end,
            email="client@example.com", status=status,
        )
        slot.sync_remaining_places()
        return availability, slot, appt

    def test_cancelled_appointment_survives_regeneration(self):
        availability, slot, appt = self._availability_with_out_of_window_appointment(
            Appointment.Status.CANCELLED
        )
        # Annulé → le créneau est de nouveau « complet en places », et il est
        # hors fenêtre : c'est exactement le cas qui le rendait supprimable.
        slot.refresh_from_db()
        self.assertEqual(slot.remaining_places, slot.capacity)

        self.run_command()

        self.assertTrue(
            Appointment.objects.filter(pk=appt.pk).exists(),
            "l'historique d'annulation a été effacé par la régénération",
        )
        self.assertTrue(Slot.objects.filter(pk=slot.pk).exists())

    def test_confirmed_appointment_survives_regeneration(self):
        availability, slot, appt = self._availability_with_out_of_window_appointment(
            Appointment.Status.CONFIRMED
        )
        self.run_command()
        self.assertTrue(Appointment.objects.filter(pk=appt.pk).exists())

    def test_no_show_survives_regeneration(self):
        availability, slot, appt = self._availability_with_out_of_window_appointment(
            Appointment.Status.NO_SHOW
        )
        self.run_command()
        self.assertTrue(Appointment.objects.filter(pk=appt.pk).exists())

    def test_empty_past_slots_are_cleaned_up(self):
        """Sans rendez-vous, un créneau hors plage n'a pas à rester en base."""
        availability = self.make_weekly(horizon_days=7)
        orphan = Slot.objects.create(
            availability=availability, type=self.type,
            start=self.start - timedelta(days=400),
            end=self.start - timedelta(days=400) + timedelta(hours=1),
            capacity=1, remaining_places=1, is_available=True,
        )
        self.run_command(horizon_days=7)
        self.assertFalse(Slot.objects.filter(pk=orphan.pk).exists())
