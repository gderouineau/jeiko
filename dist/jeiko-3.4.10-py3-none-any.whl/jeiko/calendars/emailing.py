# jeiko/calendars/emailing.py
"""
E-mails du module calendars.

Ce fichier ne compose plus de messages : il traduit un Appointment en contexte
et délègue à `jeiko.emailing`, où sujets et mises en page sont éditables en
back-office. Aucune fonction ne lève : un e-mail qui ne part pas ne doit jamais
faire échouer une réservation ni une annulation.

Codes utilisés — appointment_confirmed, appointment_admin_new,
appointment_cancelled_client, appointment_cancelled_pro, appointment_no_show,
appointment_payment_pending.
"""

import logging

from django.utils.timezone import localtime

from jeiko.emailing.render import site_base_url
from jeiko.emailing.sending import admin_recipients
from jeiko.emailing.services import send_email

logger = logging.getLogger(__name__)


# =========================
#  Mise en forme
# =========================

def _fmt_date(dt):
    d = localtime(dt)
    return f"{d.day:02d}/{d.month:02d}/{d.year}"


def _fmt_time(dt):
    d = localtime(dt)
    return f"{d.hour:02d}h{d.minute:02d}"


def _fmt_duration(start, end):
    minutes = int((end - start).total_seconds() // 60)
    if minutes < 60:
        return f"{minutes} min"
    hours, rest = divmod(minutes, 60)
    return f"{hours}h{rest:02d}" if rest else f"{hours}h"


def _absolute(path):
    base = site_base_url()
    return f"{base}{path}" if base else path


def _provider(appt):
    return appt.type.user if appt.type_id else None


def _provider_name(appt):
    provider = _provider(appt)
    if not provider:
        return ""
    return (provider.get_full_name() or provider.get_username() or "").strip()


def _recipients_pro(appt):
    """
    Destinataires internes : administrateurs configurés + praticien du type.

    Le praticien est ajouté explicitement — la configuration mail du site ne le
    connaît pas, et c'est pourtant lui qui tient l'agenda.
    """
    recipients = list(admin_recipients())
    provider = _provider(appt)
    email = getattr(provider, "email", None)
    if email and email not in recipients:
        recipients.append(email)
    return recipients


def _site_address():
    """
    Adresse du cabinet, d'après l'identité du site.

    Le modèle Appointment ne porte pas de lieu : les rendez-vous se tiennent à
    l'adresse du site. Renvoyer une chaîne vide plutôt que rien — une clé absente
    du contexte laisse [%lieu%] visible dans l'e-mail envoyé.
    """
    from jeiko.administration.models import WebSite

    site = WebSite.objects.select_related("identity").first()
    identity = getattr(site, "identity", None)
    if not identity:
        return ""

    parts = [
        identity.street_address,
        f"{identity.postal_code} {identity.address_locality}".strip(),
    ]
    return ", ".join(part for part in parts if part and part.strip())


def _context(appt):
    """Contexte commun à tous les e-mails de rendez-vous."""
    return {
        "rdv_date": _fmt_date(appt.start),
        "rdv_heure": _fmt_time(appt.start),
        "rdv_duree": _fmt_duration(appt.start, appt.end),
        "rdv_type": appt.type.name if appt.type_id else "Rendez-vous",
        "pro_nom": _provider_name(appt),
        "lieu": _site_address(),
        "lien_visio": "",
        "lien_annulation": _absolute(appt.get_public_cancel_url()),
    }


# =========================
#  Envois
# =========================

def send_booking_emails(appt):
    """
    Confirmation au client et notification au praticien.

    Point d'entrée historique, appelé après COMMIT par les vues de réservation
    et de retour de paiement. Signature inchangée.
    """
    context = _context(appt)

    if appt.email:
        client_context = dict(context)
        client_context["prenom"] = (appt.client_name or "").split(" ")[0]
        send_email("appointment_confirmed", appt.email, client_context,
                   user=appt.user)

    recipients = _recipients_pro(appt)
    if recipients:
        admin_context = dict(context)
        admin_context.update({
            "client_nom": appt.client_name or "—",
            "client_email": appt.email or "—",
            "client_tel": "—",
            "rdv_id": appt.pk,
        })
        send_email("appointment_admin_new", recipients, admin_context)


def send_cancellation_emails(appt):
    """
    Prévient des suites d'une annulation.

    Le modèle envoyé au client dépend de QUI a annulé : accusé de réception s'il
    en est l'auteur, excuses et invitation à replanifier si c'est le praticien.
    """
    from jeiko.calendars.models import Appointment

    context = _context(appt)
    by_client = appt.cancelled_by == Appointment.CancelledBy.CLIENT

    if appt.email:
        client_context = dict(context)
        client_context["prenom"] = (appt.client_name or "").split(" ")[0]
        client_context["lien_action"] = _absolute("/")

        if by_client:
            send_email("appointment_cancelled_client", appt.email,
                       client_context, user=appt.user)
        else:
            client_context["motif"] = appt.cancel_reason or "Indisponibilité"
            send_email("appointment_cancelled_pro", appt.email,
                       client_context, user=appt.user)

    # Le praticien n'est prévenu que si l'annulation ne vient pas de lui.
    if by_client:
        recipients = _recipients_pro(appt)
        if recipients:
            admin_context = dict(context)
            admin_context["lien_action"] = _absolute("/")
            send_email("appointment_cancelled_client", recipients, admin_context)


def send_no_show_email(appt):
    """Signale au client qu'il ne s'est pas présenté."""
    if not appt.email:
        return

    context = _context(appt)
    context["prenom"] = (appt.client_name or "").split(" ")[0]
    context["lien_action"] = _absolute("/")

    send_email("appointment_no_show", appt.email, context, user=appt.user)


def send_reschedule_email(appt, old_start):
    """Prévient le client que son rendez-vous a été déplacé.

    Appelé par la fiche d'administration quand le créneau (donc l'horaire) d'un
    rendez-vous change. `old_start` est l'ancien datetime, capturé avant save.
    """
    if not appt.email or old_start is None:
        return

    context = _context(appt)  # rdv_date/heure = nouvelles valeurs
    context.update({
        "prenom": (appt.client_name or "").split(" ")[0],
        "ancienne_date": _fmt_date(old_start),
        "ancienne_heure": _fmt_time(old_start),
    })
    send_email("appointment_rescheduled", appt.email, context, user=appt.user)


def send_payment_pending_email(appt):
    """Rappelle qu'un créneau est réservé mais pas encore réglé."""
    if not appt.email:
        return

    context = _context(appt)
    context.update({
        "prenom": (appt.client_name or "").split(" ")[0],
        "montant": f"{appt.amount_due} €",
        "lien_action": _absolute(appt.get_payment_url()),
        "expiration": _fmt_time(appt.hold_expires_at) if appt.hold_expires_at else "quelques minutes",
    })

    send_email("appointment_payment_pending", appt.email, context, user=appt.user)


# =========================
#  Liste d'attente
# =========================

def send_waitlist_available_email(entry):
    """
    Prévient une personne inscrite en liste d'attente qu'une place s'est
    libérée, avec le lien de réservation en 1 clic (place tenue le temps du
    délai). `entry` est un WaitlistEntry.
    """
    if not entry.email:
        return

    slot = entry.slot
    provider = slot.type.user if slot.type_id else None
    context = {
        "prenom": (entry.client_name or "").split(" ")[0],
        "rdv_date": _fmt_date(slot.start),
        "rdv_heure": _fmt_time(slot.start),
        "rdv_duree": _fmt_duration(slot.start, slot.end),
        "rdv_type": slot.type.name if slot.type_id else "Rendez-vous",
        "pro_nom": (provider.get_full_name() or provider.get_username()).strip() if provider else "",
        "places": entry.places,
        "lien_action": _absolute(entry.get_claim_url()),
        "lien_desinscription": _absolute(entry.get_leave_url()),
        "expiration": _fmt_time(entry.claim_expires_at) if entry.claim_expires_at else "quelques minutes",
    }
    send_email("appointment_waitlist_available", entry.email, context, user=entry.user)


# =========================
#  Rappels planifiés
# =========================
# Générés par la tâche `run_email_jobs`, exécutée toutes les 5 minutes par un
# timer systemd (hors Django). L'idempotence repose sur reminder_24h_sent_at /
# reminder_2h_sent_at : un rappel déjà envoyé n'est jamais renvoyé.

from datetime import timedelta

from django.utils import timezone


def _send_reminder(appt, code):
    context = _context(appt)
    context["prenom"] = (appt.client_name or "").split(" ")[0]
    return send_email(code, appt.email, context, user=appt.user)


def send_due_reminders():
    """
    Envoie les rappels de rendez-vous arrivés à échéance.

    Deux fenêtres, sans recouvrement :
      - rappel 24 h : entre 24 h et 2 h avant le rendez-vous ;
      - rappel 2 h  : dans les 2 h qui précèdent.
    Un rendez-vous pris à la dernière minute n'entre que dans la fenêtre 2 h et
    ne reçoit donc pas un rappel « 24 h » absurde.

    Ne concerne que les rendez-vous fermes (ni annulés, ni en attente de
    paiement) et dotés d'une adresse e-mail.

    Retourne (nb_24h, nb_2h).
    """
    from jeiko.calendars.models import Appointment

    now = timezone.now()
    base = (
        Appointment.objects.firm()
        .filter(start__gt=now, email__gt="")
        .select_related("type", "type__user")
    )

    sent_24h = 0
    for appt in base.filter(
        reminder_24h_sent_at__isnull=True,
        start__lte=now + timedelta(hours=24),
        start__gt=now + timedelta(hours=2),
    ):
        success, _ = _send_reminder(appt, "appointment_reminder_24h")
        # Marqué quel que soit le résultat : un e-mail refusé (modèle inactif)
        # ne doit pas être retenté indéfiniment à chaque passage du timer.
        appt.reminder_24h_sent_at = now
        appt.save(update_fields=["reminder_24h_sent_at"])
        if success:
            sent_24h += 1

    sent_2h = 0
    for appt in base.filter(
        reminder_2h_sent_at__isnull=True,
        start__lte=now + timedelta(hours=2),
    ):
        success, _ = _send_reminder(appt, "appointment_reminder_2h")
        appt.reminder_2h_sent_at = now
        appt.save(update_fields=["reminder_2h_sent_at"])
        if success:
            sent_2h += 1

    # Rappel au praticien, 1 h avant. Destinataire = propriétaire du type de RDV.
    sent_pro = 0
    for appt in base.filter(
        reminder_pro_1h_sent_at__isnull=True,
        start__lte=now + timedelta(hours=1),
    ):
        provider = _provider(appt)
        provider_email = getattr(provider, "email", None)
        if provider_email:
            context = _context(appt)
            context.update({
                "client_nom": appt.client_name or "—",
                "client_email": appt.email or "—",
            })
            success, _ = send_email(
                "appointment_reminder_pro_1h", provider_email, context,
                user=provider,
            )
            if success:
                sent_pro += 1
        appt.reminder_pro_1h_sent_at = now
        appt.save(update_fields=["reminder_pro_1h_sent_at"])

    return sent_24h, sent_2h, sent_pro


# Heure d'envoi par défaut du récapitulatif quotidien (heure locale). Elle ne
# sert plus que de valeur initiale au champ `GoogleCalendarConfig.
# daily_digest_hour` : l'heure se choisit désormais calendrier par calendrier
# depuis l'administration. Le job reste balayé toutes les heures et ne retient
# que les calendriers dont c'est l'heure — la planification systemd est donc
# indépendante du réglage.
DEFAULT_DAILY_DIGEST_HOUR = 20


def _digest_table(appointments):
    """Tableau HTML des rendez-vous d'une journée, pour [%bloc_rdv%]."""
    from django.utils.html import escape

    rows = []
    for appt in appointments:
        client = escape(appt.client_name or appt.email or "—")
        rows.append(
            '<tr>'
            f'<td style="padding:6px 8px;border-bottom:1px solid #eeeeee;'
            f'font-weight:700;white-space:nowrap;">{_fmt_time(appt.start)}</td>'
            f'<td style="padding:6px 8px;border-bottom:1px solid #eeeeee;">'
            f'{escape(appt.type.name if appt.type_id else "Rendez-vous")}</td>'
            f'<td style="padding:6px 8px;border-bottom:1px solid #eeeeee;">{client}</td>'
            '</tr>'
        )

    if not rows:
        return "<p>Aucun rendez-vous.</p>"

    return (
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" '
        'border="0" style="width:100%;border-collapse:collapse;">'
        + "".join(rows) +
        '</table>'
    )


def send_daily_provider_digests():
    """
    Envoie à chaque praticien ayant activé l'option le récapitulatif de ses
    rendez-vous du LENDEMAIN.

    Balayée toutes les heures ; ne fait rien tant qu'on n'est pas à l'heure
    d'envoi. Une garde par calendrier (last_digest_sent_on) évite tout doublon.

    Retourne le nombre de récapitulatifs envoyés.
    """
    from jeiko.calendars.models import Appointment, GoogleCalendarConfig

    now = timezone.localtime()
    today = now.date()
    tomorrow = today + timedelta(days=1)
    start_of = timezone.make_aware(
        timezone.datetime.combine(tomorrow, timezone.datetime.min.time())
    )
    end_of = start_of + timedelta(days=1)

    sent = 0
    # Le filtre horaire est désormais PAR calendrier : la tâche passe toutes
    # les heures et ne retient que ceux dont c'est l'heure d'envoi. Auparavant
    # une constante `DAILY_DIGEST_HOUR` coupait le job pour tout le monde, donc
    # changer l'heure imposait une mise à jour du paquet.
    configs = (
        GoogleCalendarConfig.objects
        .filter(
            daily_digest_enabled=True,
            user__isnull=False,
            daily_digest_hour=now.hour,
        )
        .exclude(last_digest_sent_on=today)
        .select_related("user")
    )

    for config in configs:
        provider = config.user
        if not provider.email:
            continue

        appointments = list(
            Appointment.objects.firm()
            .filter(type__user=provider, start__gte=start_of, start__lt=end_of)
            .select_related("type")
            .order_by("start")
        )

        context = {
            "date_cible": tomorrow.strftime("%d/%m/%Y"),
            "nombre_rdv": len(appointments),
            "bloc_rdv": _digest_table(appointments),
            "prenom": (provider.get_full_name() or provider.get_username() or "").split(" ")[0],
        }
        success, _ = send_email(
            "appointment_daily_digest_pro", provider.email, context, user=provider,
        )

        # Marqué même si l'envoi échoue : on ne réessaie pas en boucle chaque
        # heure. Le lendemain, la garde par date libère un nouvel envoi.
        config.last_digest_sent_on = today
        config.save(update_fields=["last_digest_sent_on"])
        if success:
            sent += 1

    return sent


def send_refund_email(appt):
    """Confirme au client le remboursement de son rendez-vous."""
    if not appt.email:
        return
    context = _context(appt)
    context.update({
        "prenom": (appt.client_name or "").split(" ")[0],
        "montant": f"{appt.refund_amount} €",
    })
    send_email("appointment_refunded", appt.email, context, user=appt.user)
