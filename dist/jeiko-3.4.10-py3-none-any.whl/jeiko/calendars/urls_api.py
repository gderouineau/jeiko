from jeiko.calendars.views import (
    APIAvailabilitiesView,
    APIBookAppointmentView,
    APIJoinWaitlistView,
                                   )
from django.urls import path

app_name = "api_calendars"

urlpatterns = [
    path("availabilities/", APIAvailabilitiesView.as_view(), name="api_availabilities"),
    path("book/", APIBookAppointmentView.as_view(), name="api_book_appointment"),
    path("waitlist/join/", APIJoinWaitlistView.as_view(), name="api_join_waitlist"),
    ]
