# jeiko/calendars/tests_places.py
"""
Nom du client et réservation de plusieurs places.

Le plafond est décidé par le gestionnaire, type de rendez-vous par type de
rendez-vous (`AppointmentType.max_places_per_booking`), et ne peut jamais
dépasser ce qu'il reste réellement sur le créneau.
"""
import json
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.cache import cache

from .throttling import reset_counters
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .forms import AppointmentTypeForm
from .models import Appointment, AppointmentType, Availability, Slot

User = get_user_model()


class PlacesFixture(TestCase):
    CAPACITY = 6
    MAX_PER_BOOKING = 3

    def setUp(self):
        cache.clear()
        reset_counters()
        self.user = User.objects.create_user(username="prov", password="pwd12345")
        self.type = AppointmentType.objects.create(
            name="Atelier", user=self.user, duration=timedelta(hours=1),
            capacity=self.CAPACITY, max_places_per_booking=self.MAX_PER_BOOKING,
        )
        start = (timezone.now() + timedelta(days=3)).replace(
            minute=0, second=0, microsecond=0
        )
        self.availability = Availability.objects.create(
            user=self.user, start=start, end=start + timedelta(hours=1)
        )
        self.availability.appointment_types.add(self.type)
        self.slot = Slot.objects.get(availability=self.availability, type=self.type)

    def book(self, email, places=None, name="Jean Dupont", slot=None):
        payload = {
            "slot_id": (slot or self.slot).id,
            "email": email,
            "name": name,
        }
        if places is not None:
            payload["places"] = places
        return self.client.post(
            reverse("api_calendars:api_book_appointment"),
            data=json.dumps(payload),
            content_type="application/json",
        )


class ClientNameTests(PlacesFixture):

    def test_name_is_stored(self):
        self.book("c@example.com", name="Amélie Durand")
        appt = Appointment.objects.get(email="c@example.com")
        self.assertEqual(appt.client_name, "Amélie Durand")

    def test_name_is_trimmed_and_truncated(self):
        self.book("c@example.com", name="  " + "x" * 200 + "  ")
        appt = Appointment.objects.get(email="c@example.com")
        self.assertEqual(len(appt.client_name), 150)

    def test_booking_without_name_still_works(self):
        """Le nom est demandé côté formulaire, pas imposé par l'API."""
        resp = self.book("c@example.com", name="")
        self.assertEqual(resp.status_code, 200, resp.content)
        self.assertEqual(Appointment.objects.get(email="c@example.com").client_name, "")


class MultiPlaceBookingTests(PlacesFixture):

    def test_default_is_one_place(self):
        self.book("c@example.com")
        self.assertEqual(Appointment.objects.get(email="c@example.com").places, 1)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY - 1)

    def test_booking_three_places_takes_three(self):
        resp = self.book("famille@example.com", places=3)
        self.assertEqual(resp.status_code, 200, resp.content)
        self.assertEqual(Appointment.objects.get(email="famille@example.com").places, 3)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY - 3)

    def test_cannot_exceed_the_maximum_set_by_the_manager(self):
        resp = self.book("gourmand@example.com", places=self.MAX_PER_BOOKING + 1)
        self.assertEqual(resp.status_code, 400)
        self.assertIn("au maximum", resp.json()["message"])
        self.assertEqual(Appointment.objects.count(), 0)

    def test_cannot_exceed_what_remains_on_the_slot(self):
        self.book("a@example.com", places=3)
        self.book("b@example.com", places=2)      # il reste 1 place
        resp = self.book("c@example.com", places=3)
        self.assertEqual(resp.status_code, 400)
        self.assertIn("il ne reste que 1 place", resp.json()["message"].lower())

    def test_zero_or_negative_places_refused(self):
        for bad in (0, -2):
            resp = self.book("c@example.com", places=bad)
            self.assertEqual(resp.status_code, 400, bad)
        self.assertEqual(Appointment.objects.count(), 0)

    def test_non_numeric_places_refused(self):
        resp = self.book("c@example.com", places="beaucoup")
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(Appointment.objects.count(), 0)

    def test_slot_closes_when_places_are_exhausted(self):
        self.book("a@example.com", places=3)
        self.book("b@example.com", places=3)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 0)
        self.assertFalse(self.slot.is_available)

    def test_cancelling_gives_back_every_place(self):
        self.book("famille@example.com", places=3)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY - 3)

        Appointment.objects.get(email="famille@example.com").cancel()

        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY)

    def test_deleting_gives_back_every_place(self):
        self.book("famille@example.com", places=3)
        Appointment.objects.get(email="famille@example.com").delete()
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY)

    def test_capacity_change_accounts_for_places_taken(self):
        self.book("famille@example.com", places=3)
        self.type.capacity = 10
        self.type.save()
        self.availability.save()          # régénère les créneaux

        self.slot.refresh_from_db()
        self.assertEqual(self.slot.capacity, 10)
        self.assertEqual(self.slot.remaining_places, 7)   # 10 - 3 places prises


class MaxPlacesExposedTests(PlacesFixture):

    def test_api_exposes_the_cap(self):
        resp = self.client.get(reverse("api_calendars:api_availabilities"))
        row = next(r for r in resp.json() if r["id"] == self.slot.id)
        self.assertEqual(row["max_places"], self.MAX_PER_BOOKING)

    def test_cap_is_bounded_by_what_remains(self):
        self.book("a@example.com", places=3)
        self.book("b@example.com", places=2)      # il reste 1 place
        resp = self.client.get(reverse("api_calendars:api_availabilities"))
        row = next(r for r in resp.json() if r["id"] == self.slot.id)
        self.assertEqual(row["max_places"], 1)

    def test_single_place_type_reports_one(self):
        solo = AppointmentType.objects.create(
            name="Entretien", user=self.user, duration=timedelta(hours=1),
            capacity=1, max_places_per_booking=1,
        )
        self.availability.appointment_types.add(solo)
        resp = self.client.get(reverse("api_calendars:api_availabilities"))
        row = next(r for r in resp.json() if r["type"] == "Entretien")
        self.assertEqual(row["max_places"], 1)


class AppointmentTypeFormTests(TestCase):
    """Le plafond ne doit pas pouvoir dépasser la capacité du créneau."""

    BASE = {
        "name": "Atelier", "duration": "01:00:00", "color": "#2ecc40",
        "font": "Inter", "description": "",
    }

    def test_max_places_above_capacity_is_refused(self):
        form = AppointmentTypeForm({**self.BASE, "capacity": 4, "max_places_per_booking": 6})
        self.assertFalse(form.is_valid())
        self.assertIn("max_places_per_booking", form.errors)

    def test_max_places_equal_to_capacity_is_accepted(self):
        form = AppointmentTypeForm({**self.BASE, "capacity": 4, "max_places_per_booking": 4})
        self.assertTrue(form.is_valid(), form.errors)

    def test_default_is_one(self):
        form = AppointmentTypeForm({**self.BASE, "capacity": 4, "max_places_per_booking": 1})
        self.assertTrue(form.is_valid(), form.errors)
        self.assertFalse(form.save(commit=False).allows_multiple_places)
