# jeiko/calendars/tests_contact_consent.py
"""
Consentement FACULTATIF de recontact recueilli à la réservation publique :
- stocké sur l'Appointment (flag + horodatage) ;
- tracé comme preuve dans users.Consent (type CONTACT, source rdv:<id>) ;
- absent par défaut (case décochée).
"""
import json
import types
from datetime import timedelta

from django.test import TestCase
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser
from django.core.cache import cache

from .throttling import reset_counters
from django.test import RequestFactory
from django.urls import reverse
from django.utils import timezone

from .models import Appointment, AppointmentType, Availability, Slot
from jeiko.users.models import Consent, ConsentType

User = get_user_model()


class BookingConsentFixture(TestCase):
    def setUp(self):
        cache.clear()
        reset_counters()
        self.user = User.objects.create_user(username="prov", password="pwd12345")
        self.conf = AppointmentType.objects.create(
            name="Conférence", user=self.user,
            duration=timedelta(hours=1), capacity=3,
        )
        self.start = (timezone.now() + timedelta(days=3)).replace(
            minute=0, second=0, microsecond=0
        )
        self.availability = Availability.objects.create(
            user=self.user, start=self.start, end=self.start + timedelta(hours=2)
        )
        self.availability.appointment_types.add(self.conf)
        self.slot = Slot.objects.filter(
            availability=self.availability, type=self.conf
        ).order_by("start").first()

    def book(self, email, contact_consent=None):
        payload = {"slot_id": self.slot.id, "email": email}
        if contact_consent is not None:
            payload["contact_consent"] = contact_consent
        return self.client.post(
            reverse("api_calendars:api_book_appointment"),
            data=json.dumps(payload),
            content_type="application/json",
        )


class BookingContactConsentTests(BookingConsentFixture):

    def test_consent_true_is_stored_and_traced(self):
        resp = self.book("yes@example.com", contact_consent=True)
        self.assertEqual(resp.status_code, 200, resp.content)
        appt = Appointment.objects.get(email="yes@example.com")
        self.assertTrue(appt.contact_consent)
        self.assertIsNotNone(appt.contact_consent_at)
        proof = Consent.objects.filter(
            consent_type=ConsentType.CONTACT, source=f"rdv:{appt.id}"
        )
        self.assertEqual(proof.count(), 1)
        self.assertTrue(proof.first().granted)

    def test_consent_absent_by_default(self):
        resp = self.book("no@example.com")  # aucune case envoyée
        self.assertEqual(resp.status_code, 200, resp.content)
        appt = Appointment.objects.get(email="no@example.com")
        self.assertFalse(appt.contact_consent)
        self.assertIsNone(appt.contact_consent_at)
        self.assertEqual(
            Consent.objects.filter(consent_type=ConsentType.CONTACT).count(), 0
        )

    def test_consent_false_records_nothing(self):
        resp = self.book("false@example.com", contact_consent=False)
        self.assertEqual(resp.status_code, 200, resp.content)
        appt = Appointment.objects.get(email="false@example.com")
        self.assertFalse(appt.contact_consent)
        self.assertEqual(
            Consent.objects.filter(consent_type=ConsentType.CONTACT).count(), 0
        )


class QuestionnaireContactConsentTests(TestCase):
    """record_consent du questionnaire trace bien le recontact, séparément."""

    def _run(self, cleaned):
        from jeiko.questionnaires_expert.views.client import record_consent
        rf = RequestFactory()
        request = rf.post("/")
        request.user = AnonymousUser()
        request.session = types.SimpleNamespace(session_key="sesskey")
        form = types.SimpleNamespace(cleaned_data=cleaned)
        test = types.SimpleNamespace(slug="mon-test")
        record_consent(form, request, test)

    def test_contact_optin_traces_contact_consent(self):
        self._run({"marketing_optin": False, "contact_optin": True})
        self.assertEqual(
            Consent.objects.filter(consent_type=ConsentType.CONTACT,
                                   source="questionnaire:mon-test").count(),
            1,
        )
        # Toujours la preuve de traitement (PRIVACY), jamais MARKETING ici.
        self.assertEqual(Consent.objects.filter(consent_type=ConsentType.PRIVACY).count(), 1)
        self.assertEqual(Consent.objects.filter(consent_type=ConsentType.MARKETING).count(), 0)

    def test_no_contact_optin_no_contact_consent(self):
        self._run({"marketing_optin": False, "contact_optin": False})
        self.assertEqual(Consent.objects.filter(consent_type=ConsentType.CONTACT).count(), 0)
