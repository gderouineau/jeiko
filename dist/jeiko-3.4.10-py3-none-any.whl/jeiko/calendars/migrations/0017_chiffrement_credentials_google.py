"""
S-01 — chiffrement des clés de compte de service Google déjà enregistrées.

Le champ passe de `JSONField` à `EncryptedJSONField`. La colonne, elle, ne
change pas : `EncryptedJSONField.get_internal_type()` renvoie `JSONField`, on
reste en `jsonb`. Tout le travail est donc dans la reprise des données — sans
elle, les clés existantes resteraient **en clair** jusqu'au jour où quelqu'un
rouvrirait l'écran pour les ressaisir, c'est-à-dire jamais.

Réversible dans les deux sens, mais la marche arrière passe par du SQL brut :
au moment où `dechiffrer` s'exécute, le champ est encore le champ chiffré, et
lui réécrire du clair par l'ORM le rechiffrerait aussitôt.
"""

import json

import jeiko.encrypted
from django.db import migrations


def chiffrer(apps, schema_editor):
    Config = apps.get_model('calendars', 'GoogleCalendarConfig')
    for config in Config.objects.all():
        valeur = config.credentials_json
        if isinstance(valeur, str):
            # Ligne en clair : la lecture n'a pas su déchiffrer et rend le
            # texte JSON brut.
            try:
                valeur = json.loads(valeur)
            except ValueError:
                continue
        if not isinstance(valeur, dict) or not valeur:
            continue
        config.credentials_json = valeur
        # `update_fields` volontaire : `updated_at` est en `auto_now` et sert à
        # l'écran à dater la dernière saisie de clé. Une migration technique
        # n'a pas à faire croire que l'exploitant a retouché sa configuration.
        config.save(update_fields=['credentials_json'])


def dechiffrer(apps, schema_editor):
    Config = apps.get_model('calendars', 'GoogleCalendarConfig')
    table = Config._meta.db_table
    with schema_editor.connection.cursor() as curseur:
        for config in Config.objects.all():
            valeur = config.credentials_json  # déchiffré à la lecture
            if not isinstance(valeur, dict):
                continue
            curseur.execute(
                f'UPDATE {table} SET credentials_json = %s WHERE id = %s',
                [json.dumps(valeur), config.pk],
            )


class Migration(migrations.Migration):

    dependencies = [
        ('calendars', '0016_googlecalendarconfig_daily_digest_hour'),
    ]

    operations = [
        migrations.AlterField(
            model_name='googlecalendarconfig',
            name='credentials_json',
            field=jeiko.encrypted.EncryptedJSONField(blank=True, default=dict, help_text='Copier-coller ici le JSON de credentials Google'),
        ),
        migrations.RunPython(chiffrer, dechiffrer),
    ]
