# jeiko/calendars/management/commands/jeiko_calendars_regenerate.py
"""
Fait glisser l'horizon de réservation.

Les créneaux ne sont matérialisés que sur une profondeur donnée (90 jours par
défaut), figée au moment où une disponibilité est enregistrée. Sans repasse,
une disponibilité hebdomadaire créée en janvier cesse d'ouvrir des créneaux en
avril — silencieusement : aucune erreur, simplement plus rien à réserver.

À faire tourner une fois par jour :
    manage.py jeiko_calendars_regenerate

La commande est idempotente : elle crée les créneaux manquants, réaligne
capacité et places restantes, et nettoie ceux qui sont sortis des plages.
Elle ne touche jamais à un créneau porteur d'un rendez-vous, même annulé.
"""
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.db.models import Count

from jeiko.calendars.models import Availability, Slot, default_horizon_days


class Command(BaseCommand):
    help = "Régénère les créneaux de réservation jusqu'à l'horizon configuré."

    def add_arguments(self, parser):
        parser.add_argument(
            "--horizon-days", type=int, default=None,
            help="Profondeur d'ouverture en jours (défaut : réglage du site).",
        )
        parser.add_argument(
            "--user", dest="username", default=None,
            help="Ne traiter que le calendrier de ce gestionnaire.",
        )
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Affiche l'état sans rien régénérer.",
        )

    def handle(self, *args, **options):
        horizon = options["horizon_days"] or default_horizon_days()
        dry = options["dry_run"]

        availabilities = (
            Availability.objects
            .prefetch_related("appointment_types")
            .select_related("user")
            .order_by("user__username", "start")
        )

        if options["username"]:
            User = get_user_model()
            owner = User.objects.filter(username=options["username"]).first()
            if owner is None:
                raise CommandError(f"Utilisateur inconnu : {options['username']}")
            availabilities = availabilities.filter(user=owner)

        if dry:
            self.stdout.write(self.style.WARNING(
                f"Mode simulation — horizon {horizon} jours, aucune écriture."
            ))

        total_before = Slot.objects.count()
        processed = skipped = 0

        for availability in availabilities:
            # Une plage sans type ne peut rien produire : `generate_slots`
            # sortirait immédiatement, autant le dire.
            if not availability.appointment_types.exists():
                skipped += 1
                self.stdout.write(
                    f"  ignorée #{availability.pk} — aucun type de rendez-vous associé"
                )
                continue

            if dry:
                current = availability.slots.count()
                future = availability.slots.filter(
                    start__gte=availability.start
                ).count()
                self.stdout.write(
                    f"  #{availability.pk} ({availability.user or 'sans propriétaire'}) "
                    f"— {current} créneau(x), dont {future} à partir du début de plage"
                )
                processed += 1
                continue

            try:
                availability.generate_slots(horizon_days=horizon)
                processed += 1
            except Exception as exc:
                # Une plage bancale (règle de récurrence invalide, dates
                # inversées) ne doit pas empêcher les autres de s'ouvrir.
                self.stderr.write(self.style.ERROR(
                    f"  échec sur la disponibilité #{availability.pk} : {exc}"
                ))

        if dry:
            self.stdout.write(self.style.WARNING(
                f"{processed} disponibilité(s) seraient traitées "
                f"({skipped} ignorée(s)) — relancer sans --dry-run pour appliquer."
            ))
            return

        total_after = Slot.objects.count()
        delta = total_after - total_before
        self.stdout.write(self.style.SUCCESS(
            f"{processed} disponibilité(s) régénérée(s) sur {horizon} jours "
            f"({skipped} ignorée(s)). "
            f"Créneaux : {total_before} → {total_after} ({delta:+d})."
        ))

        # Signale les gestionnaires qui n'ouvrent plus rien : c'est le symptôme
        # que la commande est censée empêcher.
        empty = (
            Availability.objects
            .annotate(n=Count("slots"))
            .filter(n=0, appointment_types__isnull=False)
            .distinct()
        )
        if empty.exists():
            self.stdout.write(self.style.WARNING(
                f"⚠️  {empty.count()} disponibilité(s) n'ouvrent aucun créneau "
                "(plage passée, récurrence terminée ou dates incohérentes) :"
            ))
            for availability in empty[:20]:
                self.stdout.write(
                    f"     #{availability.pk} — {availability.user or 'sans propriétaire'} "
                    f"— {availability.start:%d/%m/%Y %H:%M} → {availability.end:%d/%m/%Y %H:%M}"
                )
