# jeiko/calendars/management/commands/jeiko_calendars_expire_holds.py
"""
Libère les places des rendez-vous payants jamais réglés.

Une réservation payante tient sa place le temps du règlement. Si le client
abandonne, la place doit revenir à la vente. La libération est déjà tentée à
chaque réservation sur le créneau concerné ; cette commande couvre les créneaux
que personne ne consulte, et permet de purger d'un coup.

À faire tourner toutes les 5 à 10 minutes :
    manage.py jeiko_calendars_expire_holds
"""
from django.core.management.base import BaseCommand

from jeiko.calendars import payments
from jeiko.calendars.models import Appointment


class Command(BaseCommand):
    help = "Libère les places des réservations payantes non réglées dans le délai."

    def add_arguments(self, parser):
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Liste les réservations concernées sans rien libérer.",
        )

    def handle(self, *args, **options):
        expired = Appointment.objects.expired_holds().select_related("type", "slot")

        if options["dry_run"]:
            total = 0
            for appt in expired:
                total += 1
                self.stdout.write(
                    f"#{appt.pk} — {appt.type.name} du {appt.start:%d/%m/%Y %H:%M} "
                    f"— {appt.places} place(s) — {appt.email or 'sans e-mail'} "
                    f"— échéance {appt.hold_expires_at:%d/%m/%Y %H:%M}"
                )
            self.stdout.write(self.style.WARNING(
                f"{total} réservation(s) à libérer — relancer sans --dry-run pour appliquer."
            ))
            return

        released = payments.expire_holds()
        if released:
            self.stdout.write(self.style.SUCCESS(
                f"{released} réservation(s) non réglée(s) libérée(s)."
            ))
        else:
            self.stdout.write("Aucune réservation à libérer.")
