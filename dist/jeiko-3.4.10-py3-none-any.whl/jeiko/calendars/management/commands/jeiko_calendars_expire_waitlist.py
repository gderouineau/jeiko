# jeiko/calendars/management/commands/jeiko_calendars_expire_waitlist.py
"""
Fait tourner la liste d'attente.

Une place se libère → la personne en tête de liste est prévenue et la place lui
est tenue quelques minutes. Si elle ne réserve pas, cette commande libère la
place et prévient la suivante. La notification est aussi tentée en direct à
chaque libération ; cette commande couvre les délais qui expirent sans qu'aucun
autre évènement ne survienne.

À faire tourner toutes les 2 à 5 minutes :
    manage.py jeiko_calendars_expire_waitlist
"""
from django.core.management.base import BaseCommand

from jeiko.calendars import waitlist
from jeiko.calendars.models import WaitlistEntry


class Command(BaseCommand):
    help = "Libère les places tenues pour la liste d'attente et prévient la personne suivante."

    def add_arguments(self, parser):
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Liste les places tenues expirées sans rien libérer.",
        )

    def handle(self, *args, **options):
        if options["dry_run"]:
            from django.utils import timezone
            stale = WaitlistEntry.objects.filter(
                status=WaitlistEntry.Status.NOTIFIED,
                claim_expires_at__lt=timezone.now(),
            ).select_related("slot", "slot__type")
            total = 0
            for entry in stale:
                total += 1
                self.stdout.write(
                    f"#{entry.pk} — {entry.email} — créneau {entry.slot_id} "
                    f"— échéance {entry.claim_expires_at:%d/%m/%Y %H:%M}"
                )
            self.stdout.write(self.style.WARNING(
                f"{total} place(s) tenue(s) expirée(s) — relancer sans --dry-run pour libérer."
            ))
            return

        released = waitlist.expire_claims()
        if released:
            self.stdout.write(self.style.SUCCESS(
                f"{released} place(s) tenue(s) libérée(s), personne suivante prévenue."
            ))
        else:
            self.stdout.write("Aucune place tenue à libérer.")
