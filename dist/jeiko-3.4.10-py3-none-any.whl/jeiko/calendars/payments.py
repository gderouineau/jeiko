# jeiko/calendars/payments.py
"""
Encaissement des rendez-vous payants.

Se branche sur le module `jeiko.payments` existant (modèle `PaymentGateway` +
`StripeService`) plutôt que de redéfinir une configuration Stripe : une seule
passerelle, une seule paire de clés, un seul webhook pour tout le site.

Le rendez-vous est créé AVANT le paiement, au statut « en attente de paiement » :
il tient la place pendant que le client règle, et la relâche si le règlement
n'aboutit pas (cf. `expire_holds`).
"""
import logging
from datetime import timedelta

from django.conf import settings
from django.utils import timezone

logger = logging.getLogger(__name__)

# Durée pendant laquelle la place est tenue le temps du règlement.
DEFAULT_HOLD_MINUTES = 20

METADATA_KEY = "jeiko_appointment_id"


class PaymentNotConfigured(Exception):
    """La passerelle de paiement est absente ou inactive."""


def hold_duration():
    minutes = getattr(settings, "JEIKO_CALENDARS_PAYMENT_HOLD_MINUTES", DEFAULT_HOLD_MINUTES)
    try:
        minutes = int(minutes)
    except (TypeError, ValueError):
        minutes = DEFAULT_HOLD_MINUTES
    return timedelta(minutes=max(1, minutes))


def hold_deadline():
    return timezone.now() + hold_duration()


def get_gateway():
    """Passerelle active, ou None. Import tardif : le module payments est optionnel."""
    try:
        from jeiko.payments.models import PaymentGateway
    except Exception:  # pragma: no cover - app absente d'un déploiement
        return None
    return PaymentGateway.objects.filter(code="stripe", is_active=True).first()


def is_available():
    """Vrai si un encaissement est possible en l'état de la configuration."""
    gateway = get_gateway()
    return bool(gateway and gateway.secret_key and gateway.api_key)


def create_payment_intent(appointment):
    """
    Ouvre un paiement pour ce rendez-vous et retourne
    (client_secret, public_key).

    Le montant transmis à Stripe est `amount_due`, figé sur le rendez-vous :
    on ne recalcule pas depuis le tarif courant, qui a pu bouger entre-temps.
    """
    from jeiko.payments.services.stripe import StripeService

    gateway = get_gateway()
    if not gateway:
        raise PaymentNotConfigured(
            "Aucune passerelle de paiement active : impossible d'encaisser ce rendez-vous."
        )

    service = StripeService()
    intent = service.create_payment_intent(
        amount=appointment.amount_due,
        currency="eur",
        metadata={
            METADATA_KEY: str(appointment.pk),
            "jeiko_appointment_token": str(appointment.public_token),
            "jeiko_appointment_type": appointment.type.name if appointment.type_id else "",
        },
    )

    intent_id = intent.get("id") if isinstance(intent, dict) else getattr(intent, "id", "")
    if intent_id and intent_id != appointment.payment_intent_id:
        type(appointment).objects.filter(pk=appointment.pk).update(payment_intent_id=intent_id)
        appointment.payment_intent_id = intent_id

    client_secret = (
        intent.get("client_secret") if isinstance(intent, dict)
        else getattr(intent, "client_secret", None)
    )
    return client_secret, gateway.api_key


def confirm_from_intent_id(intent_id):
    """
    Interroge Stripe et confirme le rendez-vous si le paiement a abouti.

    Utilisé au retour du client sur le site. Ne fait jamais confiance au
    navigateur : le statut est relu auprès de Stripe.
    Retourne (appointment | None, confirmé_maintenant: bool).
    """
    import stripe
    from .models import Appointment

    gateway = get_gateway()
    if not gateway or not intent_id:
        return None, False

    stripe.api_key = gateway.secret_key
    try:
        intent = stripe.PaymentIntent.retrieve(intent_id)
    except Exception as exc:
        logger.exception("Lecture du PaymentIntent %s impossible : %s", intent_id, exc)
        return None, False

    appt_id = (intent.get("metadata") or {}).get(METADATA_KEY)
    if not appt_id:
        return None, False

    appointment = Appointment.objects.select_related("type").filter(pk=appt_id).first()
    if appointment is None:
        logger.error("PaymentIntent %s référence un rendez-vous inconnu (%s)", intent_id, appt_id)
        return None, False

    if intent.get("status") != "succeeded":
        logger.info(
            "PaymentIntent %s au statut %s : rendez-vous %s laissé en attente.",
            intent_id, intent.get("status"), appointment.pk,
        )
        return appointment, False

    if _amount_mismatch(intent, appointment):
        return appointment, False

    return appointment, appointment.mark_paid(payment_intent_id=intent_id)


def confirm_from_webhook(payment_intent):
    """
    Confirme depuis un évènement Stripe déjà authentifié (signature vérifiée
    par le module payments). Retourne (appointment | None, confirmé: bool).
    """
    from .models import Appointment

    appt_id = (payment_intent.get("metadata") or {}).get(METADATA_KEY)
    if not appt_id:
        return None, False

    appointment = Appointment.objects.select_related("type").filter(pk=appt_id).first()
    if appointment is None:
        logger.error(
            "Webhook : PaymentIntent %s référence un rendez-vous inconnu (%s)",
            payment_intent.get("id"), appt_id,
        )
        return None, False

    if _amount_mismatch(payment_intent, appointment):
        return appointment, False

    return appointment, appointment.mark_paid(
        payment_intent_id=payment_intent.get("id") or ""
    )


def _amount_mismatch(intent, appointment):
    """
    Refuse de confirmer si le montant encaissé est inférieur à ce qui est dû.

    Garde-fou : le montant vient de Stripe, mais `amount_due` vient de notre
    base — un écart signale une manipulation ou une incohérence de tarif.
    """
    received = intent.get("amount_received") or intent.get("amount") or 0
    expected = int(round(float(appointment.amount_due) * 100))
    if received < expected:
        logger.error(
            "Montant insuffisant pour le rendez-vous %s : %s centimes reçus, %s attendus.",
            appointment.pk, received, expected,
        )
        return True
    return False


def expire_holds(queryset=None):
    """
    Libère les places des réservations non réglées dans le délai.

    Retourne le nombre de places rendues. Appelé par la commande
    `jeiko_calendars_expire_holds`, et juste avant chaque réservation sur le
    créneau visé — sinon une place abandonnée resterait bloquée jusqu'au
    prochain passage du cron.
    """
    from .models import Appointment

    qs = queryset if queryset is not None else Appointment.objects.all()
    released = 0
    for appointment in qs.expired_holds().select_related("slot", "type"):
        if appointment.release_expired_hold():
            released += 1
            logger.info(
                "Place libérée : rendez-vous %s non réglé dans le délai.", appointment.pk
            )
    return released


class RefundError(Exception):
    """Message destiné à l'interface (remboursement impossible)."""


def refund_appointment(appointment_or_pk, amount=None, by_system=False):
    """
    Rembourse (tout ou partie) le paiement d'un rendez-vous via Stripe.

    - `amount` en euros ; None => remboursement intégral de `amount_due`.
    - `by_system` : True pour un remboursement automatique (annulation client
      dans le délai), False pour une action manuelle du gestionnaire.

    Idempotent : un rendez-vous déjà remboursé n'est pas remboursé deux fois.
    Retourne l'objet Appointment à jour. Lève RefundError en cas d'échec.
    """
    import stripe
    from .models import Appointment

    if isinstance(appointment_or_pk, Appointment):
        appt = Appointment.objects.get(pk=appointment_or_pk.pk)
    else:
        appt = Appointment.objects.select_related("type").filter(pk=appointment_or_pk).first()
    if appt is None:
        raise RefundError("Rendez-vous introuvable.")

    if appt.is_refunded:
        return appt  # déjà fait : rien à refaire

    if not appt.is_refundable:
        raise RefundError("Ce rendez-vous n'a pas de paiement encaissé à rembourser.")

    gateway = get_gateway()
    if not gateway or not gateway.secret_key:
        raise RefundError("Le remboursement en ligne est indisponible (passerelle non configurée).")

    full_amount = appt.amount_due
    refund_amount = full_amount if amount is None else min(amount, full_amount)
    if refund_amount <= 0:
        raise RefundError("Le montant à rembourser doit être supérieur à 0.")

    stripe.api_key = gateway.secret_key
    try:
        params = {
            "payment_intent": appt.payment_intent_id,
            "metadata": {
                "jeiko_appointment_id": str(appt.pk),
                "jeiko_refund_origin": "system" if by_system else "manager",
            },
        }
        # Remboursement partiel : montant en centimes. Total : on laisse Stripe
        # rembourser l'intégralité de la charge.
        if refund_amount < full_amount:
            params["amount"] = int(round(float(refund_amount) * 100))
        refund = stripe.Refund.create(**params)
    except Exception as exc:
        logger.exception("Échec du remboursement Stripe (appt=%s) : %s", appt.pk, exc)
        raise RefundError("Le remboursement a échoué côté Stripe, merci de réessayer.")

    refund_id = refund.get("id") if isinstance(refund, dict) else getattr(refund, "id", "")
    appt.mark_refunded(refund_amount, refund_id=refund_id or "")
    logger.info("Remboursement effectué (appt=%s, montant=%s, refund=%s)",
                appt.pk, refund_amount, refund_id)

    # Notifie le client (contenu géré par le module emailing).
    def _notify(appt_id):
        from .models import Appointment as A
        from .emailing import send_refund_email
        try:
            send_refund_email(A.objects.select_related("type").get(pk=appt_id))
        except Exception:
            logger.exception("E-mail de remboursement impossible (appt=%s)", appt_id)

    from django.db import transaction
    try:
        transaction.on_commit(lambda appt_id=appt.pk: _notify(appt_id))
    except transaction.TransactionManagementError:
        _notify(appt.pk)

    return appt


def mark_refunded_from_charge(charge):
    """
    Met à jour un rendez-vous à partir d'un évènement Stripe `charge.refunded`
    (remboursement déclenché depuis le tableau de bord Stripe, par exemple).
    """
    from .models import Appointment

    intent_id = charge.get("payment_intent")
    if not intent_id:
        return None
    appt = Appointment.objects.filter(payment_intent_id=intent_id).first()
    if appt is None or appt.is_refunded:
        return appt
    refunded_cents = charge.get("amount_refunded") or 0
    appt.mark_refunded(refunded_cents / 100, refund_id=charge.get("id") or "")
    logger.info("Remboursement enregistré via webhook (appt=%s)", appt.pk)
    return appt
