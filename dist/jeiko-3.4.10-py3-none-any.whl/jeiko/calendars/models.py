# jeiko/calendars/models.py

import uuid

from django.db import models, transaction
from django.contrib.auth import get_user_model
from django.urls import reverse
from django.utils import timezone
from datetime import timedelta, datetime, time
from dateutil.rrule import rrulestr

from jeiko.encrypted import EncryptedJSONField

import logging
logger = logging.getLogger(__name__)

WEEKDAY_TOKENS = ["MO","TU","WE","TH","FR","SA","SU"]

# Profondeur d'ouverture des réservations. Les créneaux ne sont matérialisés
# que jusque-là : au-delà, il faut que `jeiko_calendars_regenerate` soit passé.
DEFAULT_HORIZON_DAYS = 90


def default_horizon_days():
    from django.conf import settings
    try:
        return max(1, int(getattr(settings, "JEIKO_CALENDARS_HORIZON_DAYS", DEFAULT_HORIZON_DAYS)))
    except (TypeError, ValueError):
        return DEFAULT_HORIZON_DAYS


def _refund_after_commit(appt_pk):
    """Rembourse un rendez-vous après COMMIT (annulation client dans le délai)."""
    from . import payments
    try:
        payments.refund_appointment(appt_pk, by_system=True)
    except Exception:
        logger.exception("Remboursement automatique impossible (appt=%s)", appt_pk)


class GoogleCalendarConfig(models.Model):
    name = models.CharField(
        max_length=100,
        default="Primary"
    )
    user = models.OneToOneField(
        get_user_model(),
        on_delete=models.CASCADE,
        related_name='google_calendar_config',
        null=True,  # Temporary for migration
        blank=True
    )
    # Chiffré au repos (S-01) : ce JSON porte la CLÉ PRIVÉE RSA du compte de
    # service Google. En clair, une sauvegarde égarée suffisait à donner accès
    # aux agendas — et une clé qui a fuité ne se rattrape pas, il faut la
    # révoquer chez Google et reconfigurer chaque site.
    # Le formulaire ne la réaffiche jamais (`GoogleCalendarConfigForm`) ; le
    # chiffrement couvre l'autre moitié du problème, la lecture de la base.
    credentials_json = EncryptedJSONField(
        help_text="Copier-coller ici le JSON de credentials Google",
        default=dict,
        blank=True,
    )
    updated_at = models.DateTimeField(
        auto_now=True
    )

    calendar_id = models.CharField(

        max_length=300,
        default="",
        null=True,
        blank=True,
    )

    # Récapitulatif quotidien des rendez-vous du lendemain, envoyé le soir au
    # propriétaire du calendrier. Désactivé par défaut : c'est une sollicitation
    # supplémentaire, chaque praticien l'active pour son propre calendrier.
    daily_digest_enabled = models.BooleanField(
        "Recevoir le récapitulatif quotidien des rendez-vous",
        default=False,
    )
    # Heure d'envoi, choisie par calendrier : chaque praticien a ses horaires,
    # et une constante en dur dans le code n'était modifiable que par une mise
    # à jour du paquet. La tâche planifiée passe toutes les heures et ne
    # retient que les calendriers dont c'est l'heure — la planification systemd
    # reste donc inchangée quel que soit le réglage.
    daily_digest_hour = models.PositiveSmallIntegerField(
        "Heure d'envoi du récapitulatif",
        default=20,
        choices=[(h, f"{h:02d}h00") for h in range(24)],
        help_text="Heure locale à laquelle partira le récapitulatif des rendez-vous du lendemain.",
    )
    # Jour du dernier récap envoyé : garde d'idempotence, pour n'en envoyer
    # qu'un par jour même si la tâche planifiée repasse.
    last_digest_sent_on = models.DateField(
        "Dernier récapitulatif envoyé le", null=True, blank=True,
    )

    def __str__(self):
        return f"{self.user} -> {self.name}"


class AppointmentType(models.Model):
    name = models.CharField(
        "Nom du type",
        max_length=50
    )
    user = models.ForeignKey(
        get_user_model(),
        on_delete=models.CASCADE,
        related_name='appointment_types',
        null=True,  # Temporary for migration
        blank=True
    )
    duration = models.DurationField(
        "Durée",
    )
    is_paid = models.BooleanField(
        "Payant",
        default=False
    )
    price = models.DecimalField(
        "Prix par place",
        max_digits=8,
        decimal_places=2,
        default=0,
        blank=True,  # un type gratuit n'a pas à saisir « 0 »
        help_text="Montant à régler pour UNE place, en euros. Ignoré si le type n'est pas payant.",
    )
    is_registration_required = models.BooleanField(
        "Réservation uniquement pour inscrits",
        default=False,
    )
    color = models.CharField(
        "Couleur",
        max_length=7,
        default="#2ecc40",
    )
    font = models.CharField(
        "Police",
        max_length=50,
        default="Inter"
    )
    description = models.TextField(
        "Description",
        blank=True
    )
    capacity = models.PositiveIntegerField(
        default=1,
        verbose_name="Nombre de places par créneau"
    )
    max_places_per_booking = models.PositiveIntegerField(
        default=1,
        verbose_name="Places maximum par réservation",
        help_text=(
            "Nombre de places qu'un même client peut réserver d'un coup "
            "(1 = une place par réservation). Ne peut pas dépasser le nombre "
            "de places du créneau."
        ),
    )
    allow_waitlist = models.BooleanField(
        "Liste d'attente",
        default=False,
        help_text="Autoriser les clients à s'inscrire en attente sur un créneau complet.",
    )
    cancellation_deadline_hours = models.PositiveIntegerField(
        "Délai d'annulation remboursable (heures)",
        default=24,
        help_text=(
            "Un client qui annule au moins ce nombre d'heures avant un rendez-vous "
            "PAYANT est remboursé automatiquement. Passé ce délai, aucun remboursement "
            "automatique (le gestionnaire garde la main)."
        ),
    )

    def clean(self):
        super().clean()
        from django.core.exceptions import ValidationError
        errors = {}
        if self.max_places_per_booking and self.capacity and \
                self.max_places_per_booking > self.capacity:
            errors["max_places_per_booking"] = (
                "Un client ne peut pas réserver plus de places que n'en "
                f"compte le créneau ({self.capacity})."
            )
        if self.is_paid and (self.price or 0) <= 0:
            errors["price"] = "Un type de rendez-vous payant doit avoir un prix supérieur à 0."
        if errors:
            raise ValidationError(errors)

    @property
    def allows_multiple_places(self):
        return self.max_places_per_booking > 1

    @property
    def requires_payment(self):
        """Vrai si une réservation doit être réglée avant d'être confirmée."""
        return bool(self.is_paid and (self.price or 0) > 0)

    def amount_for(self, places=1):
        """Montant dû pour `places` places, en euros."""
        return (self.price or 0) * max(1, int(places or 1))

    def __str__(self):
        return self.name


class Availability(models.Model):
    appointment_types = models.ManyToManyField(
        AppointmentType,
        related_name='availabilities',
        verbose_name="Types de rendez-vous possibles"
    )
    user = models.ForeignKey(
        get_user_model(),
        on_delete=models.CASCADE,
        related_name='availabilities',
        null=True,  # Temporary for migration
        blank=True
    )
    start = models.DateTimeField(
        "Début de disponibilité",
    )
    end = models.DateTimeField(
        "Fin de disponibilité",
    )
    recurring_rule = models.TextField(
        "Règle de récurrence iCal (optionnel)",
        blank=True,
        help_text="Inclut éventuellement DTSTART, RRULE, EXDATE (une par ligne)."
    )
    is_available = models.BooleanField(
        "Disponible",
        default=True,
    )
    recurrence_exdates = models.JSONField(
        default=list, blank=True,
        help_text="Liste de dates à exclure, au format YYYY-MM-DD."
    )

    google_event_id = models.CharField(
        max_length=128,
        null=True,
        blank=True,
        db_index=True
    )

    def __str__(self):
        types = ", ".join([str(t) for t in self.appointment_types.all()])
        return f"{types}: {self.start} - {self.end}"


    def update_slots_availability(self):
        """
        Recalcule la disponibilité des créneaux du gestionnaire sur cette fenêtre.

        Règle : dès qu'UNE place est prise sur un créneau, le gestionnaire est
        occupé sur cette tranche horaire — tous les créneaux qui la chevauchent
        se ferment. Le créneau entamé, lui, reste ouvert tant qu'il lui reste
        des places (cas des rendez-vous collectifs / conférences).

        Le calcul porte sur TOUS les créneaux du même gestionnaire sur la
        fenêtre, pas seulement ceux de cette disponibilité : deux plages qui se
        chevauchent ne doivent pas se réserver l'une l'autre.
        """
        own_slots = list(self.slots.all())
        if not own_slots:
            return

        window_start = min(s.start for s in own_slots)
        window_end = max(s.end for s in own_slots)

        if self.user_id:
            slots = list(
                Slot.objects.filter(
                    availability__user_id=self.user_id,
                    start__lt=window_end,
                    end__gt=window_start,
                )
            )
        else:
            # Disponibilité orpheline (antérieure à l'attribution des
            # calendriers) : on ne la compare qu'à elle-même.
            slots = own_slots

        booked = [s for s in slots if s.remaining_places < s.capacity]

        to_update = []
        for slot in slots:
            busy_elsewhere = any(
                b.pk != slot.pk and b.start < slot.end and b.end > slot.start
                for b in booked
            )
            available = (not busy_elsewhere) and slot.remaining_places > 0
            if slot.is_available != available:
                slot.is_available = available
                to_update.append(slot)

        if to_update:
            # bulk_update : ne repasse pas par Slot.save(), donc pas de récursion.
            Slot.objects.bulk_update(to_update, ["is_available"])

    def _duration(self):
        return self.end - self.start

    def _as_rruleset(self):
        """
        Construit un rruleset (ou rrule) à partir de recurring_rule + DTSTART.
        Supporte RRULE/EXDATE multiples (forceset=True).
        """
        rule_str = (self.recurring_rule or "").strip()
        if not rule_str:
            return None
        # IMPORTANT: on fournit dtstart=self.start pour aligner la 1re occurrence
        return rrulestr(rule_str, forceset=True, dtstart=self.start)

    def iter_occurrences(self, start_from=None, until=None):
        """
        Génère les fenêtres (start,end) d’Availability pour chaque occurrence.
        - Si pas de récurrence: une seule fenêtre self.start/self.end.
        - Sinon: on expanse via rruleset().between().
        """
        dur = self._duration()
        if not (self.recurring_rule or "").strip():
            yield (self.start, self.end)
            return

        rs = self._as_rruleset()
        if not rs:
            yield (self.start, self.end)
            return

        if start_from is None:
            start_from = self.start

        if until is None:
            until = timezone.now() + timedelta(days=default_horizon_days())

        for occ_start in rs.between(start_from, until, inc=True):
            occ_end = occ_start + dur
            # Si tu as JSONField recurrence_exdates ET que tu préfères un double filet de sécurité:
            exdates = getattr(self, 'recurrence_exdates', []) or []
            if exdates:
                # compare la date uniquement
                if occ_start.date().isoformat() in exdates:
                    continue
            yield (occ_start, occ_end)


    def _slots_with_history(self):
        """Créneaux de cette plage, avec le nombre de rendez-vous rattachés
        TOUS statuts confondus (annulés compris)."""
        from django.db.models import Count
        return self.slots.annotate(_appointments_total=Count("appointments"))

    @staticmethod
    def _slot_is_disposable(slot):
        """
        Vrai si le créneau peut être supprimé sans rien perdre.

        Un créneau porteur du moindre rendez-vous est conservé, même annulé :
        `Appointment.slot` est en CASCADE, le supprimer effacerait l'historique
        d'annulation — que seule la purge RGPD a vocation à effacer.
        `remaining_places == capacity` ne suffit donc pas : c'est aussi l'état
        d'un créneau dont tous les rendez-vous ont été annulés.
        """
        if getattr(slot, "_appointments_total", None):
            return False
        return slot.remaining_places == slot.capacity

    def generate_slots(self, horizon_days=None):
        """
        Génère tous les slots pour CHAQUE occurrence (quotidienne/hebdomadaire),
        pour TOUS les types associés (durées différentes OK),
        puis met à jour les conflits et nettoie les slots hors plage.
        """
        types = list(self.appointment_types.all())
        if not types:
            return

        if horizon_days is None:
            horizon_days = default_horizon_days()

        type_ids = {t.id for t in types}
        horizon_end = timezone.now() + timedelta(days=horizon_days)
        windows = list(self.iter_occurrences(until=horizon_end))

        # Si aucune occurrence dans l'horizon -> on nettoie simplement
        if not windows:
            to_delete = []
            to_update = []
            for slot in self._slots_with_history():
                if self._slot_is_disposable(slot):
                    to_delete.append(slot.id)
                elif slot.is_available:
                    slot.is_available = False
                    to_update.append(slot)
            if to_delete:
                self.slots.filter(id__in=to_delete).delete()
            if to_update:
                Slot.objects.bulk_update(to_update, ["is_available"])
            return

        # Index des slots existants, avec le nombre de places réellement prises
        from django.db.models import Q as _Q, Sum
        existing_qs = self.slots.select_related("type").annotate(
            _booked=Sum(
                "appointments__places",
                filter=~_Q(appointments__status=Appointment.Status.CANCELLED),
            )
        )
        existing = {(s.start, s.end, s.type_id): s for s in existing_qs}

        to_create = []
        to_update = []

        def in_any_window(s, e):
            for ws, we in windows:
                if ws <= s and e <= we and e > s:
                    return True
            return False

        # Tessellation des fenêtres en pas = duration de chaque type
        for appt_type in types:
            step = appt_type.duration
            capacity = appt_type.capacity
            for ws, we in windows:
                cur = ws
                while cur + step <= we:
                    se = cur + step
                    key = (cur, se, appt_type.id)
                    slot = existing.get(key)
                    if slot is None:
                        to_create.append(Slot(
                            availability=self,
                            type=appt_type,
                            start=cur,
                            end=se,
                            capacity=capacity,
                            remaining_places=capacity,
                            is_available=True,
                        ))
                    else:
                        changed = False
                        # Capacité modifiée sur le type : on réaligne les places
                        # restantes sur les réservations réelles, sinon augmenter
                        # la capacité n'ouvrirait aucune place supplémentaire.
                        if slot.capacity != capacity:
                            booked = getattr(slot, "_booked", 0) or 0
                            slot.capacity = capacity
                            slot.remaining_places = max(0, capacity - booked)
                            changed = True
                        # Si non complet et désactivé → réactive
                        # (update_slots_availability refermera si conflit)
                        if slot.remaining_places > 0 and not slot.is_available:
                            slot.is_available = True
                            changed = True
                        if changed:
                            to_update.append(slot)
                    cur = se

        if to_create:
            Slot.objects.bulk_create(to_create)
        if to_update:
            Slot.objects.bulk_update(to_update, ["capacity", "remaining_places", "is_available"])

        # 1) Mise à jour de la dispo vs RDV pris (chevauchements avec slots complets)
        self.update_slots_availability()

        # 2) Nettoyage: tout slot qui ne tombe plus dans une fenêtre active ou dont le type a été retiré
        type_ids_set = type_ids  # alias lisible
        to_delete = []
        to_deactivate = []
        for slot in self._slots_with_history():
            if not in_any_window(slot.start, slot.end) or (slot.type_id not in type_ids_set):
                if self._slot_is_disposable(slot):
                    to_delete.append(slot.id)
                else:
                    if slot.is_available:
                        slot.is_available = False
                        to_deactivate.append(slot)

        if to_delete:
            self.slots.filter(id__in=to_delete).delete()
        if to_deactivate:
            Slot.objects.bulk_update(to_deactivate, ["is_available"])


    def save(self, *args, **kwargs):
        with transaction.atomic():

            super().save(*args, **kwargs)

            self.generate_slots()

        def _push(av_id):
            try:
                from .google_api import upsert_availability_event
                a = Availability.objects.get(pk=av_id)
                eid = upsert_availability_event(a)
                if eid and eid != a.google_event_id:
                    Availability.objects.filter(pk=av_id).update(google_event_id=eid)
            except Exception:
                logger.exception("Failed pushing availability to Google (id=%s)", av_id)

        transaction.on_commit(lambda av_id=self.id: _push(av_id))



class Slot(models.Model):
    availability = models.ForeignKey(
        'Availability',
        on_delete=models.CASCADE,
        related_name='slots',
        verbose_name="Plage de disponibilité"
    )
    type = models.ForeignKey(
        AppointmentType,
        on_delete=models.CASCADE,
        related_name="slots"
    )

    start = models.DateTimeField(
        verbose_name="Début du créneau"
    )
    end = models.DateTimeField(
        verbose_name="Fin du créneau"
    )
    is_available = models.BooleanField(
        default=False,
        verbose_name="Est disponible"
    )
    capacity = models.PositiveIntegerField(
        default=1
    )
    remaining_places = models.PositiveIntegerField(
        default=1
    )


    class Meta:
        ordering = ["start"]
        unique_together = (('availability', 'start', 'end', 'type'),)
        indexes = [
            models.Index(fields=["availability", "start"]),
            models.Index(fields=["start"]),
            models.Index(fields=["type", "start"]),
        ]

    def pending_claim_places(self):
        """
        Places tenues pour une personne prévenue sur la liste d'attente.

        Une entrée « prévenue » (NOTIFIED) dont la fenêtre de réservation court
        encore occupe la place : personne d'autre ne doit pouvoir la prendre. Un
        claim dont l'échéance est passée ne compte plus, même si le cron ne l'a
        pas encore marqué expiré — la place redevient libre aussitôt.
        """
        from django.db.models import Sum
        return self.waitlist_entries.filter(
            status=WaitlistEntry.Status.NOTIFIED,
            claim_expires_at__gt=timezone.now(),
        ).aggregate(n=Sum("places"))["n"] or 0

    def sync_remaining_places(self):
        """
        Réaligne les places restantes sur l'occupation réelle du créneau :
        rendez-vous actifs + places tenues pour la liste d'attente.

        Recalculer plutôt qu'incrémenter/décrémenter rend l'opération idempotente :
        une annulation rejouée, ou une suppression passée hors de `cancel()`, ne
        peut plus faire dériver le compteur.
        Retourne True si la valeur a changé.
        """
        from django.db.models import Sum
        taken = self.appointments.active().aggregate(n=Sum("places"))["n"] or 0
        taken += self.pending_claim_places()
        remaining = max(0, self.capacity - taken)
        if remaining == self.remaining_places:
            return False
        self.remaining_places = remaining
        Slot.objects.filter(pk=self.pk).update(remaining_places=remaining)
        return True

    def __str__(self):
        return f"{self.type.name}: {self.start} - {self.end} ({self.remaining_places}/{self.capacity})"


class AppointmentQuerySet(models.QuerySet):
    """Un rendez-vous annulé occupe une ligne, jamais une place."""

    def active(self):
        """
        Rendez-vous qui OCCUPENT une place.

        Inclut les attentes de paiement : la place est tenue le temps du
        règlement, sinon deux clients pourraient payer le même créneau.
        """
        return self.exclude(status=Appointment.Status.CANCELLED)

    def firm(self):
        """Rendez-vous fermes : ni annulés, ni en attente de paiement."""
        return self.exclude(status__in=[
            Appointment.Status.CANCELLED, Appointment.Status.PENDING_PAYMENT,
        ])

    def awaiting_payment(self):
        return self.filter(status=Appointment.Status.PENDING_PAYMENT)

    def expired_holds(self):
        """Attentes de paiement dont le délai est dépassé."""
        return self.awaiting_payment().filter(hold_expires_at__lt=timezone.now())

    def cancelled(self):
        return self.filter(status=Appointment.Status.CANCELLED)

    def upcoming(self):
        return self.active().filter(start__gte=timezone.now())

    def to_review(self):
        """Rendez-vous passés dont la présence n'a pas encore été tranchée."""
        return self.filter(
            status=Appointment.Status.CONFIRMED, end__lt=timezone.now()
        )

    def upcoming_firm(self):
        return self.firm().filter(start__gte=timezone.now())


class Appointment(models.Model):

    class Status(models.TextChoices):
        # La place est tenue le temps du règlement, puis libérée si le paiement
        # n'aboutit pas (cf. `hold_expires_at` et `expire_unpaid_holds`).
        PENDING_PAYMENT = "pending_payment", "En attente de paiement"
        CONFIRMED = "confirmed", "Confirmé"
        HONOURED = "honoured", "Honoré"
        NO_SHOW = "no_show", "Absent"
        CANCELLED = "cancelled", "Annulé"

    class CancelledBy(models.TextChoices):
        CLIENT = "client", "Le client"
        MANAGER = "manager", "Le gestionnaire"
        SYSTEM = "system", "Le système"

    objects = AppointmentQuerySet.as_manager()

    type = models.ForeignKey(
        AppointmentType,
        on_delete=models.PROTECT,
    )
    slot = models.ForeignKey(
        Slot,
        on_delete=models.CASCADE,
        related_name="appointments",
        null=True,
        blank=True
    )
    user = models.ForeignKey(
        get_user_model(),
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )
    start = models.DateTimeField(
        "Début"
    )
    end = models.DateTimeField(
        "Fin",
    )
    created = models.DateTimeField(
        auto_now_add=True
    )
    is_paid = models.BooleanField(
        default=False,
    )  # utile si tu veux vérifier le paiement
    client_name = models.CharField(
        "Nom du client",
        max_length=150,
        blank=True,
    )
    email = models.EmailField(
        "Email du client",
        blank=True,
    )
    places = models.PositiveIntegerField(
        "Nombre de places",
        default=1,
        help_text="Places occupées par cette réservation (accompagnants inclus).",
    )

    # Consentement, distinct de la relation liée au rendez-vous lui-même
    # (celui-ci relève de l'exécution du contrat) : autorisation FACULTATIVE
    # d'être recontacté au-delà de ce rendez-vous. La preuve horodatée est
    # aussi tracée dans users.Consent (type CONTACT).
    contact_consent = models.BooleanField(
        "Autorise le recontact",
        default=False,
        help_text="Le client autorise à être recontacté au-delà de ce rendez-vous.",
    )
    contact_consent_at = models.DateTimeField(
        "Consentement de recontact le",
        null=True,
        blank=True,
    )

    google_event_id = models.CharField(
        max_length=128, blank=True, null=True, db_index=True
    )

    public_token = models.UUIDField(
        "Jeton public",
        default=uuid.uuid4,
        editable=False,
        unique=True,
        help_text="Identifiant non devinable utilisé dans les liens envoyés au client.",
    )

    status = models.CharField(
        "Statut",
        max_length=16,
        choices=Status.choices,
        default=Status.CONFIRMED,
        db_index=True,
    )
    cancelled_at = models.DateTimeField(
        "Annulé le", null=True, blank=True
    )
    cancelled_by = models.CharField(
        "Annulé par", max_length=16, choices=CancelledBy.choices, blank=True
    )
    cancel_reason = models.TextField(
        "Motif d'annulation", blank=True
    )

    amount_due = models.DecimalField(
        "Montant dû",
        max_digits=8, decimal_places=2, default=0,
        help_text="Figé à la réservation : un changement de tarif ne réécrit pas l'historique.",
    )
    payment_intent_id = models.CharField(
        "Référence de paiement", max_length=255, blank=True, db_index=True
    )
    paid_at = models.DateTimeField(
        "Payé le", null=True, blank=True
    )
    hold_expires_at = models.DateTimeField(
        "Place tenue jusqu'à", null=True, blank=True,
        help_text="Au-delà, une réservation non réglée libère sa place.",
    )
    refunded_at = models.DateTimeField(
        "Remboursé le", null=True, blank=True
    )
    refund_amount = models.DecimalField(
        "Montant remboursé", max_digits=8, decimal_places=2, default=0,
    )
    refund_id = models.CharField(
        "Référence du remboursement", max_length=255, blank=True, db_index=True
    )

    # Horodatage d'envoi des rappels : garde d'idempotence pour la tâche
    # planifiée. Non nul = rappel déjà envoyé, on ne le renvoie pas au passage
    # suivant du timer (qui tourne toutes les 5 minutes).
    reminder_24h_sent_at = models.DateTimeField(
        "Rappel 24 h envoyé le", null=True, blank=True,
    )
    reminder_2h_sent_at = models.DateTimeField(
        "Rappel 2 h envoyé le", null=True, blank=True,
    )
    # Rappel envoyé au praticien 1 h avant (distinct des rappels client).
    reminder_pro_1h_sent_at = models.DateTimeField(
        "Rappel praticien 1 h envoyé le", null=True, blank=True,
    )

    def __str__(self):
        return f"{self.type.name} - {self.start:%Y-%m-%d %H:%M}"

    # ------------------------------------------------------------------
    # Accès client (liens envoyés par e-mail)
    # ------------------------------------------------------------------
    def get_public_cancel_url(self):
        """URL relative d'annulation, à insérer dans les e-mails au client."""
        return reverse(
            "jeiko_calendars_public:appointment_cancel",
            kwargs={"token": str(self.public_token)},
        )

    def get_payment_url(self):
        """URL relative de la page de règlement."""
        return reverse(
            "jeiko_calendars_public:appointment_pay",
            kwargs={"token": str(self.public_token)},
        )

    def get_payment_return_url(self):
        """URL de retour après passage sur Stripe."""
        return reverse(
            "jeiko_calendars_public:appointment_pay_return",
            kwargs={"token": str(self.public_token)},
        )

    @property
    def is_past(self):
        return self.start <= timezone.now()

    @property
    def is_cancelled(self):
        return self.status == self.Status.CANCELLED

    @property
    def is_awaiting_payment(self):
        return self.status == self.Status.PENDING_PAYMENT

    @property
    def hold_has_expired(self):
        return bool(
            self.is_awaiting_payment
            and self.hold_expires_at
            and self.hold_expires_at < timezone.now()
        )

    def mark_paid(self, payment_intent_id=""):
        """
        Confirme le rendez-vous après encaissement.

        Idempotent : appelé à la fois au retour du client depuis la page de
        paiement ET par le webhook Stripe, qui arrivent dans un ordre non
        garanti (et parfois deux fois).
        Retourne True seulement au premier passage — c'est ce booléen qui
        décide de l'envoi des e-mails.
        """
        if self.status != self.Status.PENDING_PAYMENT:
            return False
        self.status = self.Status.CONFIRMED
        self.is_paid = True
        self.paid_at = timezone.now()
        self.hold_expires_at = None
        if payment_intent_id:
            self.payment_intent_id = payment_intent_id
        self.save(update_fields=[
            "status", "is_paid", "paid_at", "hold_expires_at", "payment_intent_id",
        ])
        return True

    def release_expired_hold(self):
        """Libère la place d'une réservation non réglée dans le délai."""
        if not self.hold_has_expired:
            return False
        return self.cancel(
            by=self.CancelledBy.SYSTEM,
            reason="Paiement non finalisé dans le délai imparti.",
        )

    # ------------------------------------------------------------------
    # Remboursement
    # ------------------------------------------------------------------
    @property
    def is_refunded(self):
        return self.refunded_at is not None

    @property
    def is_refundable(self):
        """Un règlement encaissé, pas encore remboursé, peut l'être."""
        return bool(self.is_paid and self.paid_at and self.payment_intent_id
                    and not self.is_refunded)

    def cancellation_refund_deadline(self):
        """Instant limite pour une annulation client remboursable."""
        hours = self.type.cancellation_deadline_hours if self.type_id else 0
        return self.start - timedelta(hours=hours)

    def is_within_refund_window(self):
        """Vrai si l'on est encore avant le délai d'annulation remboursable."""
        return timezone.now() <= self.cancellation_refund_deadline()

    def _qualifies_for_auto_refund(self, by):
        """
        Politique : seule une annulation PAR LE CLIENT, sur un RDV payé et dans
        le délai, déclenche un remboursement automatique. L'annulation par le
        gestionnaire est laissée à sa main (bouton manuel).
        """
        if not self.is_refundable:
            return False
        if by != self.CancelledBy.CLIENT:
            return False
        return self.is_within_refund_window()

    def mark_refunded(self, amount, refund_id=""):
        """
        Enregistre un remboursement. Idempotent : ne fait rien si déjà remboursé.
        Retourne True seulement au premier passage.
        """
        if self.is_refunded:
            return False
        self.refunded_at = timezone.now()
        self.refund_amount = amount
        if refund_id:
            self.refund_id = refund_id
        self.save(update_fields=["refunded_at", "refund_amount", "refund_id"])
        return True

    def is_cancellable_by_client(self):
        """
        Un client ne peut annuler qu'un rendez-vous à venir et non déjà annulé.
        (Un délai de prévenance pourra être ajouté ici plus tard.)
        """
        return not self.is_past and not self.is_cancelled

    @property
    def owner(self):
        """Gestionnaire du calendrier auquel appartient ce rendez-vous."""
        return self.type.user if self.type_id else None

    def cancel(self, by=CancelledBy.CLIENT, reason=""):
        """
        Annule ce rendez-vous :
        - Passe le statut à « annulé ». La ligne est CONSERVÉE : historique,
          suivi des no-shows, déclenchement de la liste d'attente.
        - Libère la place et rouvre les créneaux qui étaient bloqués.
        - L'évènement Google est retiré par le signal post_save.

        Idempotent : retourne False si le rendez-vous était déjà annulé.
        """
        if self.pk is None or self.is_cancelled:
            # Déjà annulé (double clic, rejeu) : rien à faire.
            return False

        auto_refund = self._qualifies_for_auto_refund(by)
        with transaction.atomic():
            self.status = self.Status.CANCELLED
            self.cancelled_at = timezone.now()
            self.cancelled_by = by
            self.cancel_reason = reason or ""
            self.save(update_fields=[
                "status", "cancelled_at", "cancelled_by", "cancel_reason"
            ])
            self.release_slot()
            if auto_refund:
                # Le remboursement appelle Stripe : après COMMIT, hors transaction.
                appt_pk = self.pk
                transaction.on_commit(lambda pk=appt_pk: _refund_after_commit(pk))
        return True

    def release_slot(self):
        """Rend la place au créneau, recalcule les chevauchements, et prévient
        la liste d'attente si une place s'est libérée."""
        slot = (
            Slot.objects
            .filter(pk=self.slot_id)
            .select_related("availability", "type")
            .first()
        )
        if slot is None:
            return
        slot.sync_remaining_places()
        slot.availability.update_slots_availability()
        from . import waitlist
        waitlist.maybe_notify(slot)

    def mark_attendance(self, honoured: bool):
        """Tranche la présence après coup (suivi des no-shows)."""
        if self.is_cancelled:
            return False
        self.status = self.Status.HONOURED if honoured else self.Status.NO_SHOW
        self.save(update_fields=["status"])
        return True

class WaitlistEntry(models.Model):
    """
    Inscription en attente sur un créneau complet.

    Cible un créneau PRÉCIS (pas un type) : le client veut cette date-là. Quand
    une place se libère, la personne en tête de liste est prévenue et la place
    lui est tenue le temps qu'elle réserve (cf. `jeiko.calendars.waitlist`).
    """

    class Status(models.TextChoices):
        WAITING = "waiting", "En attente"
        NOTIFIED = "notified", "Prévenue (place tenue)"
        CONVERTED = "converted", "Convertie en rendez-vous"
        CANCELLED = "cancelled", "Désinscrite"
        EXPIRED = "expired", "Délai dépassé"

    slot = models.ForeignKey(
        "Slot",
        on_delete=models.CASCADE,
        related_name="waitlist_entries",
        verbose_name="Créneau visé",
    )
    user = models.ForeignKey(
        get_user_model(),
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="waitlist_entries",
    )
    client_name = models.CharField("Nom du client", max_length=150, blank=True)
    email = models.EmailField("Email du client")
    places = models.PositiveIntegerField("Places souhaitées", default=1)

    status = models.CharField(
        max_length=16, choices=Status.choices,
        default=Status.WAITING, db_index=True,
    )
    public_token = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)

    created = models.DateTimeField(auto_now_add=True)
    notified_at = models.DateTimeField("Prévenue le", null=True, blank=True)
    claim_expires_at = models.DateTimeField(
        "Place tenue jusqu'à", null=True, blank=True,
        help_text="Au-delà, la place est proposée à la personne suivante.",
    )

    class Meta:
        ordering = ["created"]  # premier inscrit, premier prévenu
        # Une même adresse ne s'inscrit qu'une fois par créneau.
        unique_together = (("slot", "email"),)
        indexes = [
            models.Index(fields=["slot", "status"]),
            models.Index(fields=["status", "claim_expires_at"]),
        ]
        verbose_name = "Inscription en liste d'attente"
        verbose_name_plural = "Inscriptions en liste d'attente"

    def __str__(self):
        return f"{self.email} @ {self.slot_id} ({self.get_status_display()})"

    @property
    def is_active(self):
        """En jeu : attend son tour ou a été prévenue."""
        return self.status in (self.Status.WAITING, self.Status.NOTIFIED)

    @property
    def claim_has_expired(self):
        return bool(
            self.status == self.Status.NOTIFIED
            and self.claim_expires_at
            and self.claim_expires_at < timezone.now()
        )

    def get_claim_url(self):
        from django.urls import reverse
        return reverse(
            "jeiko_calendars_public:waitlist_claim",
            kwargs={"token": str(self.public_token)},
        )

    def get_leave_url(self):
        from django.urls import reverse
        return reverse(
            "jeiko_calendars_public:waitlist_leave",
            kwargs={"token": str(self.public_token)},
        )
