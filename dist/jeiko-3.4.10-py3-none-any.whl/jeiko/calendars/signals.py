
# jeiko/calendars/signals.py
from django.db.models.signals import post_save, m2m_changed, post_delete
from django.dispatch import receiver
from django.db import transaction
import logging
logger = logging.getLogger(__name__)
from .google_api import upsert_event, delete_event, delete_availability_event

from .models import Availability, Appointment

@receiver(post_save, sender=Availability)
def availability_post_save(sender, instance, created, **kwargs):
    # Si nouvel objet : on tentera quand même (au cas où il y a des defaults)
    # Mais la vraie génération se fera surtout après save_m2m (voir m2m_changed)
    if created:
        instance.generate_slots()

@receiver(m2m_changed, sender=Availability.appointment_types.through)
def availability_types_changed(sender, instance, action, **kwargs):
    if action in {"post_add", "post_remove", "post_clear"}:
        instance.generate_slots()






@receiver(post_save, sender=Appointment, dispatch_uid="calendars.sync_appointment_google")
def appointment_synced_to_google(sender, instance: Appointment, created, **kwargs):
    # Évite les appels pendant la transaction : exécute après COMMIT.
    # `dispatch_uid` garantit un seul branchement même si le module est
    # importé deux fois.
    logger.info("post_save Appointment pk=%s created=%s -> schedule sync", instance.pk, created)
    transaction.on_commit(lambda: _sync_after_commit(instance.pk))

def _sync_after_commit(appt_pk: int):
    from .models import Appointment  # import tardif pour éviter cycles
    appt = Appointment.objects.select_related("type").filter(pk=appt_pk).first()
    if not appt:
        return

    # En attente de paiement : la place est tenue chez nous, mais on ne
    # pollue pas l'agenda du gestionnaire avec des paniers abandonnés.
    if appt.is_awaiting_payment:
        return

    # Rendez-vous annulé : la ligne reste en base, mais l'agenda du
    # gestionnaire doit se libérer.
    if appt.is_cancelled:
        if appt.google_event_id and delete_event(appt):
            Appointment.objects.filter(pk=appt.pk).update(google_event_id=None)
        return

    event_id = upsert_event(appt)
    if event_id and appt.google_event_id != event_id:
        # Update direct par QuerySet pour éviter de re-déclencher post_save
        Appointment.objects.filter(pk=appt.pk).update(google_event_id=event_id)

@receiver(post_delete, sender=Appointment)
def appointment_deleted_from_google(sender, instance: Appointment, **kwargs):
    transaction.on_commit(lambda: delete_event(instance))


@receiver(post_delete, sender=Appointment, dispatch_uid="calendars.release_slot")
def appointment_release_slot(sender, instance: Appointment, **kwargs):
    """
    Rend la place au créneau, quelle que soit la voie de suppression :
    `Appointment.cancel()`, admin Django, suppression en masse, script.

    Volontairement synchrone (et non `on_commit`) : ce sont deux requêtes SQL
    dans la même transaction, et une place doit être libre immédiatement pour
    la réservation suivante.
    """
    from .models import Slot
    from . import waitlist

    if not instance.slot_id:
        return
    slot = (
        Slot.objects
        .filter(pk=instance.slot_id)
        .select_related("availability", "type")
        .first()
    )
    if slot is None:
        # Créneau supprimé en cascade (suppression d'une disponibilité) :
        # il n'y a plus rien à libérer.
        return
    slot.sync_remaining_places()
    slot.availability.update_slots_availability()
    waitlist.maybe_notify(slot)


@receiver(post_delete, sender=Availability)
def availability_deleted_from_google(sender, instance: Availability, **kwargs):
    transaction.on_commit(lambda: delete_availability_event(instance))