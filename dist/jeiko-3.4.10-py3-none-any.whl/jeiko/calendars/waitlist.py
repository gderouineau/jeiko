# jeiko/calendars/waitlist.py
"""
Liste d'attente : inscription sur un créneau complet, puis notification en
cascade quand une place se libère.

Politique retenue :
- on prévient la personne en tête de liste et on lui TIENT la place le temps
  qu'elle réserve (`claim_expires_at`) — comme le « hold » des paiements ;
- sans action dans le délai, on passe à la suivante ;
- la place tenue est comptée dans l'occupation du créneau
  (`Slot.pending_claim_places`), donc personne d'autre ne peut la prendre.
"""
import logging
from datetime import timedelta

from django.conf import settings
from django.db import transaction
from django.utils import timezone

logger = logging.getLogger(__name__)

DEFAULT_CLAIM_MINUTES = 30


class WaitlistError(Exception):
    """Message destiné au client (inscription refusée, etc.)."""


def claim_duration():
    minutes = getattr(settings, "JEIKO_CALENDARS_WAITLIST_CLAIM_MINUTES", DEFAULT_CLAIM_MINUTES)
    try:
        minutes = int(minutes)
    except (TypeError, ValueError):
        minutes = DEFAULT_CLAIM_MINUTES
    return timedelta(minutes=max(1, minutes))


def join(slot, email, client_name="", places=1, user=None):
    """
    Inscrit une adresse en attente sur un créneau complet.

    Retourne (entry, created). Une adresse déjà inscrite et active retrouve son
    entrée (pas de doublon, pas d'erreur : le client peut recliquer).
    """
    from .models import Appointment, WaitlistEntry

    if not slot.type.allow_waitlist:
        raise WaitlistError("La liste d'attente n'est pas proposée pour ce rendez-vous.")

    if slot.start <= timezone.now():
        raise WaitlistError("Ce créneau est passé.")

    # On ne s'inscrit en attente que si le créneau est RÉELLEMENT complet
    # (remaining_places == 0) — même définition que l'API `waitlist_open`.
    # S'il reste de la place, autant réserver directement.
    if slot.remaining_places > 0:
        raise WaitlistError("Ce créneau a encore de la place : vous pouvez réserver directement.")

    try:
        places = int(places)
    except (TypeError, ValueError):
        places = 1
    places = max(1, min(places, max(1, slot.type.max_places_per_booking)))

    existing = WaitlistEntry.objects.filter(slot=slot, email=email).first()
    if existing is not None:
        if existing.is_active:
            return existing, False
        # Réinscription après un désistement ou une expiration : on repart à zéro.
        existing.status = WaitlistEntry.Status.WAITING
        existing.places = places
        existing.client_name = client_name or existing.client_name
        existing.user = user or existing.user
        existing.notified_at = None
        existing.claim_expires_at = None
        existing.save(update_fields=[
            "status", "places", "client_name", "user", "notified_at", "claim_expires_at",
        ])
        return existing, False

    entry = WaitlistEntry.objects.create(
        slot=slot, email=email, client_name=client_name,
        places=places, user=user,
    )
    return entry, True


def position_of(entry):
    """Rang (1 = prochain prévenu) parmi les inscrits encore en attente."""
    from .models import WaitlistEntry
    return WaitlistEntry.objects.filter(
        slot_id=entry.slot_id,
        status=WaitlistEntry.Status.WAITING,
        created__lt=entry.created,
    ).count() + 1


@transaction.atomic
def notify_next(slot_id):
    """
    Prévient la prochaine personne en attente si le créneau a de la place libre.

    Verrouille le créneau, tient la place pour la personne prévenue, et
    programme l'e-mail après COMMIT. Retourne l'entrée prévenue, ou None.
    Idempotent : ne prévient personne s'il n'y a pas de place réellement libre
    ou si une notification est déjà en cours.
    """
    from .models import Slot, WaitlistEntry

    slot = Slot.objects.select_for_update().select_related("type").filter(pk=slot_id).first()
    if slot is None:
        return None

    # Une notification déjà en cours tient déjà la place : on ne double pas.
    pending = WaitlistEntry.objects.filter(
        slot=slot, status=WaitlistEntry.Status.NOTIFIED,
        claim_expires_at__gt=timezone.now(),
    ).exists()
    if pending:
        return None

    slot.sync_remaining_places()
    if slot.remaining_places <= 0:
        return None

    entry = (
        WaitlistEntry.objects
        .filter(slot=slot, status=WaitlistEntry.Status.WAITING)
        .order_by("created")
        .first()
    )
    if entry is None:
        return None

    # Une entrée qui demande plus que la place disponible est laissée en
    # attente : on tente la suivante qui tient dans la place libre.
    if entry.places > slot.remaining_places:
        entry = (
            WaitlistEntry.objects
            .filter(slot=slot, status=WaitlistEntry.Status.WAITING,
                    places__lte=slot.remaining_places)
            .order_by("created")
            .first()
        )
        if entry is None:
            return None

    entry.status = WaitlistEntry.Status.NOTIFIED
    entry.notified_at = timezone.now()
    entry.claim_expires_at = timezone.now() + claim_duration()
    entry.save(update_fields=["status", "notified_at", "claim_expires_at"])

    # La place tenue réoccupe le créneau : personne d'autre ne peut la prendre.
    slot.sync_remaining_places()
    slot.availability.update_slots_availability()

    def _send(entry_id):
        from .models import WaitlistEntry as WE
        from .emailing import send_waitlist_available_email
        try:
            fresh = WE.objects.select_related("slot", "slot__type").get(pk=entry_id)
            send_waitlist_available_email(fresh)
        except Exception:
            logger.exception("Notification liste d'attente impossible (entry=%s)", entry_id)

    transaction.on_commit(lambda entry_id=entry.pk: _send(entry_id))
    logger.info("Liste d'attente : %s prévenue pour le créneau %s", entry.email, slot.pk)
    return entry


def maybe_notify(slot):
    """
    À appeler après chaque libération de place sur un créneau.

    Programmé après COMMIT : la libération doit être visible en base avant qu'on
    décide de prévenir quelqu'un. Sans transaction en cours, on exécute
    directement (cas des scripts et commandes).
    """
    if slot is None:
        return
    slot_id = slot.pk
    if not slot.type.allow_waitlist:
        return
    try:
        transaction.on_commit(lambda: notify_next(slot_id))
    except transaction.TransactionManagementError:
        notify_next(slot_id)


def expire_claims():
    """
    Libère les places tenues pour des personnes prévenues qui n'ont pas réservé.

    Retourne le nombre d'entrées expirées. Pour chaque place rendue, tente
    aussitôt de prévenir la personne suivante.
    """
    from .models import WaitlistEntry

    expired = 0
    stale = WaitlistEntry.objects.filter(
        status=WaitlistEntry.Status.NOTIFIED,
        claim_expires_at__lt=timezone.now(),
    ).select_related("slot", "slot__type", "slot__availability")

    for entry in stale:
        with transaction.atomic():
            entry.status = WaitlistEntry.Status.EXPIRED
            entry.save(update_fields=["status"])
            slot = entry.slot
            slot.sync_remaining_places()
            slot.availability.update_slots_availability()
        expired += 1
        logger.info("Liste d'attente : délai dépassé pour %s (créneau %s)",
                    entry.email, entry.slot_id)
        notify_next(entry.slot_id)

    return expired


def leave(entry, by_client=True):
    """Désinscrit une entrée et relance la personne suivante si une place se libère."""
    from .models import WaitlistEntry

    if not entry.is_active:
        return False
    was_holding = entry.status == WaitlistEntry.Status.NOTIFIED
    with transaction.atomic():
        entry.status = WaitlistEntry.Status.CANCELLED
        entry.save(update_fields=["status"])
        if was_holding:
            slot = entry.slot
            slot.sync_remaining_places()
            slot.availability.update_slots_availability()
    if was_holding:
        notify_next(entry.slot_id)
    return True
