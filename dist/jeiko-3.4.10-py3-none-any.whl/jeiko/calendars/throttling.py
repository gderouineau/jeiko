# jeiko/calendars/throttling.py
"""
Garde-fous anti-abus du point d'entrée public de réservation.

Les primitives (cache, compteurs, IP, leurre) vivent désormais dans
`jeiko.throttling`, partagées avec les autres points d'entrée publics. Ne reste
ici que la *politique* propre à la réservation : plafonds distincts pour les
tentatives, les réservations effectives par IP et par adresse e-mail.

L'API publique de ce module est inchangée — `check_booking_request`,
`record_booking`, `clean_booking_email`, `reset_counters`, `get_client_ip`,
`HONEYPOT_FIELD` — les vues et les tests continuent de l'importer d'ici.
"""

import logging

from django.core.exceptions import ValidationError
from django.core.validators import validate_email

from jeiko.throttling import (  # noqa: F401  (ré-export)
    HONEYPOT_FIELD,
    get_client_ip,
    get_limits,
    hit,
    honeypot_filled,
    peek,
    reset_counters,
)

logger = logging.getLogger(__name__)

# (nombre maximum, fenêtre en secondes)
DEFAULT_LIMITS = {
    "ip_attempts": (30, 3600),        # toute requête, même refusée
    "ip_bookings": (5, 3600),         # réservations effectives
    "ip_bookings_day": (10, 86400),
    "email_bookings_day": (3, 86400),
}

GENERIC_REFUSAL = (
    "Trop de réservations depuis cet appareil. Merci de réessayer plus tard "
    "ou de nous contacter directement."
)

#: Portée des compteurs de ce module, pour ne pas se mélanger avec les autres
#: points d'entrée qui partagent le même cache.
SCOPE = "cal"


def get_booking_limits():
    return get_limits("JEIKO_CALENDARS_BOOKING_LIMITS", DEFAULT_LIMITS)


def clean_booking_email(raw):
    """Retourne l'e-mail normalisé, ou None s'il est invalide."""
    email = (raw or "").strip()
    if not email or len(email) > 254:
        return None
    try:
        validate_email(email)
    except ValidationError:
        return None
    return email.lower()


def check_booking_request(request, payload, email):
    """
    Contrôles anti-abus AVANT réservation.

    Retourne `None` si la requête peut poursuivre, sinon un message destiné au
    client (volontairement vague : ne pas renseigner un robot sur la règle
    qui l'a arrêté).
    """
    limits = get_booking_limits()
    ip = get_client_ip(request)

    # 1. Leurre : un humain ne remplit jamais ce champ (masqué en CSS).
    if honeypot_filled(payload):
        logger.warning("Réservation rejetée (honeypot rempli) ip=%s", ip)
        return GENERIC_REFUSAL

    # 2. Volumétrie brute, pour couper le martèlement même en échec.
    if hit(f"{SCOPE}:attempts", ip, *limits["ip_attempts"]):
        logger.warning("Réservation rejetée (trop de tentatives) ip=%s", ip)
        return GENERIC_REFUSAL

    # 3. Réservations effectives par IP, à l'heure et au jour.
    if peek(f"{SCOPE}:book_h", ip, limits["ip_bookings"][0]) or \
       peek(f"{SCOPE}:book_d", ip, limits["ip_bookings_day"][0]):
        logger.warning("Réservation rejetée (plafond IP atteint) ip=%s", ip)
        return GENERIC_REFUSAL

    # 4. Réservations par adresse e-mail.
    if email and peek(f"{SCOPE}:book_mail", email, limits["email_bookings_day"][0]):
        logger.warning("Réservation rejetée (plafond e-mail atteint) email=%s", email)
        return (
            "Plusieurs rendez-vous ont déjà été réservés avec cette adresse "
            "aujourd'hui. Contactez-nous si vous en avez besoin d'un autre."
        )

    return None


def record_booking(request, email):
    """Comptabilise une réservation réussie (appelé après création du RDV)."""
    limits = get_booking_limits()
    ip = get_client_ip(request)
    hit(f"{SCOPE}:book_h", ip, *limits["ip_bookings"])
    hit(f"{SCOPE}:book_d", ip, *limits["ip_bookings_day"])
    if email:
        hit(f"{SCOPE}:book_mail", email, *limits["email_bookings_day"])
