# jeiko/calendars/tests_admin_create.py
"""
Création d'un rendez-vous par un gestionnaire POUR un client inscrit,
depuis la fiche de l'utilisateur.
"""
from datetime import timedelta
from decimal import Decimal
from unittest import mock

from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .models import Appointment, AppointmentType, Availability, Slot
from .tests import grant_calendar_perms

User = get_user_model()

CREATE_URL = "jeiko_administration_calendars:appointment_create_for_user"


@override_settings(DEBUG=True)  # évite le template 404 du projet en test
class AdminCreateAppointmentTests(TestCase):

    def setUp(self):
        self.manager = grant_calendar_perms(
            User.objects.create_user(username="manager", password="pwd12345")
        )
        self.client_user = User.objects.create_user(
            username="cliente", password="pwd12345",
            email="cliente@example.com", first_name="Marie", last_name="Martin",
        )
        self.type = AppointmentType.objects.create(
            name="Consultation", user=self.manager,
            duration=timedelta(hours=1), capacity=2, max_places_per_booking=2,
        )
        start = (timezone.now() + timedelta(days=2)).replace(
            minute=0, second=0, microsecond=0
        )
        self.availability = Availability.objects.create(
            user=self.manager, start=start, end=start + timedelta(hours=1)
        )
        self.availability.appointment_types.add(self.type)
        self.slot = Slot.objects.get(availability=self.availability, type=self.type)
        self.client.force_login(self.manager)

    def _url(self):
        return reverse(CREATE_URL, kwargs={"user_id": self.client_user.pk})

    def _post(self, **overrides):
        data = {"slot": self.slot.pk, "places": 1}
        data.update(overrides)
        return self.client.post(self._url(), data)

    def test_form_page_loads(self):
        resp = self.client.get(self._url())
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Marie Martin")

    def test_creates_a_confirmed_appointment_for_the_client(self):
        with self.captureOnCommitCallbacks(execute=True), \
             mock.patch("jeiko.calendars.views.send_booking_emails_safe"):
            resp = self._post()
        self.assertEqual(resp.status_code, 302)

        appt = Appointment.objects.get(user=self.client_user)
        self.assertEqual(appt.status, Appointment.Status.CONFIRMED)
        self.assertEqual(appt.type, self.type)
        self.assertEqual(appt.email, "cliente@example.com")
        self.assertEqual(appt.client_name, "Marie Martin")
        self.assertEqual(appt.start, self.slot.start)

    def test_place_is_taken_on_the_slot(self):
        with mock.patch("jeiko.calendars.views.send_booking_emails_safe"):
            self._post(places=2)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 0)
        self.assertFalse(self.slot.is_available)

    def test_confirmation_email_is_sent(self):
        # Le mock doit rester actif quand captureOnCommitCallbacks exécute les
        # callbacks (à SA sortie) : on le place donc en contexte extérieur.
        with mock.patch("jeiko.calendars.views.send_booking_emails_safe") as mailer, \
             self.captureOnCommitCallbacks(execute=True):
            self._post()
        mailer.assert_called_once()

    def test_places_beyond_remaining_refused(self):
        # Sature une place au préalable.
        Appointment.objects.create(
            type=self.type, slot=self.slot, start=self.slot.start, end=self.slot.end,
            email="autre@example.com", places=1,
        )
        self.slot.sync_remaining_places()
        with mock.patch("jeiko.calendars.views.send_booking_emails_safe"):
            resp = self._post(places=2)
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "reste")
        self.assertFalse(Appointment.objects.filter(user=self.client_user).exists())

    def test_paid_flag_marks_appointment_paid_without_online_payment(self):
        with mock.patch("jeiko.calendars.views.send_booking_emails_safe"):
            self._post(is_paid="on")
        appt = Appointment.objects.get(user=self.client_user)
        self.assertTrue(appt.is_paid)
        self.assertEqual(appt.status, Appointment.Status.CONFIRMED)

    def test_manager_cannot_use_another_managers_slot(self):
        other = grant_calendar_perms(
            User.objects.create_user(username="autre_mgr", password="pwd12345")
        )
        other_type = AppointmentType.objects.create(
            name="Autre", user=other, duration=timedelta(hours=1), capacity=1
        )
        other_av = Availability.objects.create(
            user=other, start=self.slot.start, end=self.slot.start + timedelta(hours=1)
        )
        other_av.appointment_types.add(other_type)
        other_slot = Slot.objects.get(availability=other_av, type=other_type)

        with mock.patch("jeiko.calendars.views.send_booking_emails_safe"):
            resp = self._post(slot=other_slot.pk)
        # Le créneau d'un autre n'est pas dans le queryset : erreur de formulaire.
        self.assertEqual(resp.status_code, 200)
        self.assertFalse(Appointment.objects.filter(user=self.client_user).exists())

    def test_requires_add_permission(self):
        nobody = User.objects.create_user(username="nobody", password="pwd12345")
        self.client.force_login(nobody)
        self.assertEqual(self.client.get(self._url()).status_code, 403)

    def test_appointments_show_on_user_detail(self):
        with mock.patch("jeiko.calendars.views.send_booking_emails_safe"):
            self._post()
        # Un superuser (qui a toutes les permissions) ouvre la fiche du client :
        # la section « Rendez-vous » doit lister le RDV créé.
        root = User.objects.create_superuser(username="root", password="pwd12345")
        self.client.force_login(root)
        resp = self.client.get(
            reverse("jeiko_administration_users:user_detail", kwargs={"pk": self.client_user.pk})
        )
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Consultation")
        self.assertContains(resp, "Créer un rendez-vous")
