# jeiko/calendars/urls_public.py
"""
Routes accessibles au CLIENT, sans compte, via un jeton non devinable
transmis par e-mail ou après réservation. Aucun identifiant séquentiel
n'est exposé ici.
"""
from django.urls import path

from jeiko.calendars.views import (
    AppointmentPaymentReturnView,
    AppointmentPaymentView,
    AppointmentPublicCancelView,
    WaitlistClaimView,
    WaitlistLeaveView,
)

app_name = "jeiko_calendars_public"

urlpatterns = [
    path(
        "annulation/<uuid:token>/",
        AppointmentPublicCancelView.as_view(),
        name="appointment_cancel",
    ),
    path(
        "paiement/<uuid:token>/",
        AppointmentPaymentView.as_view(),
        name="appointment_pay",
    ),
    path(
        "paiement/<uuid:token>/retour/",
        AppointmentPaymentReturnView.as_view(),
        name="appointment_pay_return",
    ),
    path(
        "liste-attente/<uuid:token>/",
        WaitlistClaimView.as_view(),
        name="waitlist_claim",
    ),
    path(
        "liste-attente/<uuid:token>/quitter/",
        WaitlistLeaveView.as_view(),
        name="waitlist_leave",
    ),
]
