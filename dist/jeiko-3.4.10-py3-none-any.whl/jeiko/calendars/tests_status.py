# jeiko/calendars/tests_status.py
"""
Cycle de vie d'un rendez-vous : annulation conservée, suivi de présence
(no-show) et purge RGPD.
"""
from datetime import timedelta
from io import StringIO

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.core.cache import cache

from .throttling import reset_counters
from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Appointment, AppointmentType, Availability, Slot
from .tests import grant_calendar_perms

User = get_user_model()


class StatusFixture(TestCase):
    CAPACITY = 2

    def setUp(self):
        cache.clear()
        reset_counters()
        self.user = grant_calendar_perms(
            User.objects.create_user(username="prov", password="pwd12345")
        )
        self.type = AppointmentType.objects.create(
            name="Bilan", user=self.user,
            duration=timedelta(hours=1), capacity=self.CAPACITY,
        )
        start = (timezone.now() + timedelta(days=2)).replace(
            minute=0, second=0, microsecond=0
        )
        self.availability = Availability.objects.create(
            user=self.user, start=start, end=start + timedelta(hours=1)
        )
        self.availability.appointment_types.add(self.type)
        self.slot = Slot.objects.get(availability=self.availability, type=self.type)
        self.appt = Appointment.objects.create(
            type=self.type, slot=self.slot,
            start=self.slot.start, end=self.slot.end,
            email="client@example.com",
        )
        self.slot.sync_remaining_places()

    def make_past(self, appt, days=2):
        past = timezone.now() - timedelta(days=days)
        Appointment.objects.filter(pk=appt.pk).update(
            start=past, end=past + timedelta(hours=1)
        )
        appt.refresh_from_db()
        return appt


class CancellationKeepsRowTests(StatusFixture):

    def test_new_appointment_is_confirmed(self):
        self.assertEqual(self.appt.status, Appointment.Status.CONFIRMED)
        self.assertFalse(self.appt.is_cancelled)

    def test_cancel_keeps_the_row_and_frees_the_place(self):
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY - 1)

        self.assertTrue(self.appt.cancel(by=Appointment.CancelledBy.CLIENT))

        self.appt.refresh_from_db()
        self.assertEqual(self.appt.status, Appointment.Status.CANCELLED)
        self.assertEqual(self.appt.cancelled_by, Appointment.CancelledBy.CLIENT)
        self.assertIsNotNone(self.appt.cancelled_at)

        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY)
        self.assertTrue(self.slot.is_available)

    def test_cancel_is_idempotent(self):
        self.appt.cancel()
        first = self.appt.cancelled_at
        self.assertFalse(self.appt.cancel())      # second appel : sans effet
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.cancelled_at, first)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY)

    def test_cancelled_appointment_does_not_occupy_a_place(self):
        self.appt.cancel()
        Appointment.objects.create(
            type=self.type, slot=self.slot,
            start=self.slot.start, end=self.slot.end, email="autre@example.com",
        )
        self.slot.sync_remaining_places()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY - 1)

    def test_active_and_cancelled_querysets(self):
        self.appt.cancel()
        self.assertEqual(Appointment.objects.active().count(), 0)
        self.assertEqual(Appointment.objects.cancelled().count(), 1)
        self.assertEqual(Appointment.objects.count(), 1)  # la ligne est là

    def test_cancelled_appointment_leaves_the_upcoming_list(self):
        self.client.force_login(self.user)
        url = reverse("jeiko_administration_calendars:appointment_list_upcoming")
        self.assertEqual(len(self.client.get(url).context["appointments"]), 1)
        self.appt.cancel()
        self.assertEqual(len(self.client.get(url).context["appointments"]), 0)

    def test_client_cancellation_is_attributed_to_the_client(self):
        self.client.post(self.appt.get_public_cancel_url())
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.cancelled_by, Appointment.CancelledBy.CLIENT)

    def test_manager_cancellation_is_attributed_to_the_manager(self):
        self.client.force_login(self.user)
        self.client.post(
            reverse("jeiko_administration_calendars:appointment_cancel",
                    kwargs={"pk": self.appt.pk}),
            {"reason": "Empêchement praticien"},
        )
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.cancelled_by, Appointment.CancelledBy.MANAGER)
        self.assertEqual(self.appt.cancel_reason, "Empêchement praticien")

    def test_cancelling_twice_via_public_link_is_harmless(self):
        url = self.appt.get_public_cancel_url()
        self.client.post(url)
        resp = self.client.post(url)          # le client rafraîchit / re-clique
        self.assertEqual(resp.status_code, 200)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, self.CAPACITY)


class NoShowTests(StatusFixture):

    def setUp(self):
        super().setUp()
        self.make_past(self.appt)
        self.client.force_login(self.user)

    def test_mark_no_show(self):
        resp = self.client.post(
            reverse("jeiko_administration_calendars:appointment_attendance",
                    kwargs={"pk": self.appt.pk}),
            {"attendance": "no_show"},
        )
        self.assertEqual(resp.status_code, 302)
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.status, Appointment.Status.NO_SHOW)

    def test_mark_honoured(self):
        self.client.post(
            reverse("jeiko_administration_calendars:appointment_attendance",
                    kwargs={"pk": self.appt.pk}),
            {"attendance": "honoured"},
        )
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.status, Appointment.Status.HONOURED)

    def test_cancelled_appointment_cannot_be_marked(self):
        self.appt.cancel()
        self.client.post(
            reverse("jeiko_administration_calendars:appointment_attendance",
                    kwargs={"pk": self.appt.pk}),
            {"attendance": "no_show"},
        )
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.status, Appointment.Status.CANCELLED)

    def test_another_manager_cannot_mark_attendance(self):
        other = grant_calendar_perms(
            User.objects.create_user(username="autre", password="pwd12345")
        )
        self.client.force_login(other)
        resp = self.client.post(
            reverse("jeiko_administration_calendars:appointment_attendance",
                    kwargs={"pk": self.appt.pk}),
            {"attendance": "no_show"},
        )
        self.assertEqual(resp.status_code, 404)
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.status, Appointment.Status.CONFIRMED)

    def test_to_review_lists_past_undecided_appointments(self):
        self.assertIn(self.appt, Appointment.objects.to_review())
        self.appt.mark_attendance(honoured=True)
        self.assertNotIn(self.appt, Appointment.objects.to_review())


class RgpdPurgeTests(StatusFixture):

    def run_purge(self, **kwargs):
        out = StringIO()
        call_command("jeiko_calendars_purge", stdout=out, **kwargs)
        return out.getvalue()

    def test_recent_appointments_are_untouched(self):
        self.run_purge()
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.email, "client@example.com")

    def test_old_appointment_email_is_anonymised(self):
        self.make_past(self.appt, days=800)      # ~26 mois
        self.run_purge()
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.email, "")
        # la ligne reste : statistiques et historique préservés
        self.assertTrue(Appointment.objects.filter(pk=self.appt.pk).exists())

    def test_old_cancelled_appointment_is_deleted(self):
        self.appt.cancel()
        self.make_past(self.appt, days=500)      # ~16 mois
        self.run_purge()
        self.assertFalse(Appointment.objects.filter(pk=self.appt.pk).exists())

    def test_dry_run_changes_nothing(self):
        self.make_past(self.appt, days=800)
        output = self.run_purge(dry_run=True)
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.email, "client@example.com")
        self.assertIn("simulation", output.lower())

    def test_thresholds_are_configurable(self):
        self.make_past(self.appt, days=200)      # ~6,5 mois
        self.run_purge()
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.email, "client@example.com")

        self.run_purge(anonymize_after=3)
        self.appt.refresh_from_db()
        self.assertEqual(self.appt.email, "")
