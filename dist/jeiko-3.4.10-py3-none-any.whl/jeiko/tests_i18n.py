# jeiko/tests_i18n.py
"""
La langue de l'INTERFACE d'administration.

Le besoin, tel qu'il a été posé
--------------------------------
« 95 % des sites sont dans une seule langue mais peuvent être dans d'autres
langues que le français. » Ce n'est donc pas d'abord un problème de traduction
de CONTENU — c'est un problème de langue de l'OUTIL. Un exploitant hispanophone
qui tient un site en espagnol se heurtait à une administration entièrement
française.

Traduire l'outil sert tout le monde ; un moteur multilingue de contenu ne
servirait que les 5 % restants, et coûte bien plus cher. D'où cet ordre.

Ce que ces tests éprouvent
--------------------------
**La chaîne, pas le vocabulaire.** Réglages, middleware, préférence de compte,
compilation, rendu : chacun de ces maillons est invisible seul, et l'ensemble
ne se vérifie qu'en bout de course. Un `.po` complet posé sur une chaîne
cassée ne traduirait rien, et rien ne le dirait.

La traduction anglaise fournie ne couvre que le menu d'administration. C'est
délibéré : elle existe pour prouver la mécanique, et se complétera écran par
écran. Une chaîne non traduite retombe sur le français — mieux vaut un mot
français au milieu de l'anglais qu'une interface à moitié cassée.
"""

from django.conf import settings
from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.utils import translation

from jeiko import i18n
from jeiko.administration.admin_nav import NAVIGATION


class MecaniqueTests(TestCase):
    """Les maillons, un par un — chacun est invisible seul."""

    def test_le_projet_declare_ses_langues(self):
        codes = [code for code, _ in settings.LANGUAGES]
        self.assertIn("fr", codes)
        self.assertIn(
            "en", codes,
            "Sans une seconde langue déclarée, rien ne permet de vérifier que "
            "la traduction fonctionne.",
        )

    def test_le_middleware_de_langue_est_monte(self):
        self.assertIn("django.middleware.locale.LocaleMiddleware", settings.MIDDLEWARE)
        self.assertIn(
            "jeiko.i18n.LangueDeLAdministrationMiddleware", settings.MIDDLEWARE
        )

    def test_notre_middleware_vient_apres_l_authentification(self):
        """
        Avant, `request.user` n'existe pas : la préférence de compte serait
        invisible et le middleware ne ferait rien — sans erreur.
        """
        ordre = settings.MIDDLEWARE
        self.assertLess(
            ordre.index("django.contrib.auth.middleware.AuthenticationMiddleware"),
            ordre.index("jeiko.i18n.LangueDeLAdministrationMiddleware"),
        )

    def test_les_traductions_sont_cherchees_dans_le_projet(self):
        self.assertTrue(
            settings.LOCALE_PATHS,
            "Sans LOCALE_PATHS, un exploitant ne peut pas corriger un libellé "
            "sans modifier JEIKO.",
        )


class TraductionEffectiveTests(TestCase):
    """Le bout de la chaîne : une chaîne française sort en anglais."""

    def test_le_menu_se_traduit(self):
        with translation.override("fr"):
            francais = [str(section.label) for section in NAVIGATION]
        with translation.override("en"):
            anglais = [str(section.label) for section in NAVIGATION]

        self.assertIn("Réglages", francais)
        self.assertIn("Settings", anglais)
        self.assertNotEqual(
            francais, anglais,
            "Le menu sort identique dans les deux langues : la chaîne de "
            "traduction est rompue quelque part.",
        )

    def test_une_chaine_non_traduite_retombe_sur_le_francais(self):
        """
        Le comportement voulu tant que la traduction est partielle : un mot
        français au milieu de l'anglais vaut mieux qu'un libellé vide.
        """
        with translation.override("en"):
            libelles = [str(item.label)
                        for section in NAVIGATION for item in section.items]
        self.assertTrue(all(libelles), "Aucun libellé ne doit être vide.")


class PreferenceDeCompteTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.user = User.objects.create_user(
            "ana", "ana@exemple.fr", "Un-Mot-De-Passe-42"
        )

    def _regler(self, code):
        profil = self.user.profile
        profil.langue_admin = code
        profil.save(update_fields=["langue_admin"])
        self.user.refresh_from_db()

    def test_sans_choix_on_suit_le_site(self):
        """
        `None` et non « français » : un site passé à l'espagnol doit emmener
        avec lui tous ceux qui n'ont rien choisi.
        """
        self.assertIsNone(i18n.langue_de_l_utilisateur(self.user))

    def test_un_choix_valide_est_retenu(self):
        self._regler("en")
        self.assertEqual(i18n.langue_de_l_utilisateur(self.user), "en")

    def test_une_langue_non_proposee_est_ignoree(self):
        """
        Une valeur restée en base après un changement de configuration
        activerait une langue sans traduction : l'interface retomberait sur
        l'anglais de Django, ce qui ressemble à une panne plutôt qu'à un choix.
        """
        self._regler("ja")
        self.assertIsNone(i18n.langue_de_l_utilisateur(self.user))

    def test_la_preference_s_applique_a_une_vraie_requete(self):
        """Le test qui compte : la page servie change réellement de langue."""
        self._regler("en")
        self.client.force_login(self.user)
        reponse = self.client.get("/jeiko/administration/")
        if reponse.status_code == 200:
            self.assertContains(reponse, "Settings")
            self.assertNotContains(reponse, ">Réglages<")

    def test_le_formulaire_de_profil_propose_les_langues_du_site(self):
        from jeiko.users.forms import ProfileForm

        choix = dict(ProfileForm().fields["langue_admin"].choices)
        self.assertIn("en", choix)
        self.assertIn("", choix, "« Langue du site » doit rester proposé.")
