# jeiko/tests_staticfiles.py
"""
La minification du CSS à `collectstatic` — et ses garde-fous.

Ce que ces tests protègent
--------------------------
Le paquet livrait deux exemplaires de chaque feuille : la source et une version
minifiée écrite à la main. Rien ne les tenait synchronisées, et au constat du
17/08/2026 `main.min.css` avait neuf mois de retard, `menu.min.css` onze —
d'où les écarts entre le rendu de l'éditeur et celui du site public.

`jeiko/staticfiles.py` supprime la classe de défaut : il n'y a plus qu'un
fichier écrit à la main, et la version compacte est produite au déploiement.

Ces tests portent moins sur la compression elle-même — c'est l'affaire de
`csscompressor` — que sur les **garde-fous**. Une feuille de style est ce qui
tient l'apparence du site : mieux vaut la servir non minifiée que corrompue,
et un déploiement ne doit jamais échouer pour une question de poids.
"""

import os
import tempfile

from django.test import SimpleTestCase, override_settings

from jeiko.staticfiles import MinifyingManifestStaticFilesStorage

CSS = """
/* un commentaire */
.bloc {
    color : #ffffff ;
    margin : 0 ;
}
@media (min-width: 768px) and (max-width: 991.98px) {
    .bloc { color: #000000; }
}
"""


class ChoixDesFichiersTests(SimpleTestCase):
    """Ce qui est minifié, et ce qui ne l'est pas."""

    def setUp(self):
        self.storage = MinifyingManifestStaticFilesStorage()

    def test_le_css_est_retenu(self):
        self.assertTrue(self.storage._a_minifier("jeiko/css/main/main.css"))
        self.assertTrue(self.storage._a_minifier("MAIN.CSS"))

    def test_le_css_deja_compacte_est_laisse_tel_quel(self):
        """Les dépendances tierces arrivent minifiées ; y repasser ne sert à rien."""
        self.assertFalse(self.storage._a_minifier("vendor/lib.min.css"))

    def test_le_css_compacte_ET_EMPREINT_est_reconnu(self):
        """
        Le cas vu en production, et que le contrôle par suffixe laissait passer.

        `ManifestStaticFilesStorage` insère l'empreinte AVANT l'extension :
        `main.min.css` devient `main.min.ee0803ada193.css`, qui ne se termine
        pas par « .min.css ». D'anciens fichiers minifiés restés dans
        STATIC_ROOT étaient donc repris à chaque déploiement, et l'un d'eux
        faisait échouer le compacteur — dix traces d'erreur par mise à jour.
        """
        for nom in ("jeiko/css/main/main.min.ee0803ada193.css",
                    "jeiko/css/footer/footer.min.5c75b27d855e.css",
                    "vendor/lib.MIN.a1b2c3d4.css"):
            with self.subTest(fichier=nom):
                self.assertFalse(self.storage._a_minifier(nom))

    def test_un_css_ordinaire_empreint_reste_traite(self):
        """La garde ne doit pas devenir si large qu'elle exclut le cas normal."""
        self.assertTrue(
            self.storage._a_minifier("jeiko/css/main/main.a1b2c3d4e5f6.css")
        )

    def test_les_autres_types_sont_ignores(self):
        """
        Le JavaScript demanderait un minifieur de plus, pour un gain sans
        commune mesure — et il n'a pas montré la dérive qui a motivé ce module.
        """
        for nom in ("app.js", "logo.svg", "police.woff2", "page.html"):
            with self.subTest(fichier=nom):
                self.assertFalse(self.storage._a_minifier(nom))


class MinificationTests(SimpleTestCase):
    """Le travail lui-même, et son comportement en cas d'ennui."""

    def setUp(self):
        self.storage = MinifyingManifestStaticFilesStorage()
        self.dossier = tempfile.TemporaryDirectory()
        self.addCleanup(self.dossier.cleanup)
        self.fichier = os.path.join(self.dossier.name, "feuille.css")
        with open(self.fichier, "w", encoding="utf-8") as f:
            f.write(CSS)

    def _contenu(self):
        with open(self.fichier, encoding="utf-8") as f:
            return f.read()

    def _minifier(self, compress):
        with override_settings(STATIC_ROOT=self.dossier.name):
            return self.storage._minifier_un(self.fichier, compress)

    def test_le_fichier_est_reduit_et_reste_valide(self):
        from csscompressor import compress

        gain = self._minifier(compress)
        apres = self._contenu()
        self.assertIsNotNone(gain)
        self.assertGreater(gain, 0)
        # Le fond est conservé : sélecteurs, valeurs, media query.
        self.assertIn(".bloc", apres)
        self.assertIn("#fff", apres)
        self.assertIn("@media", apres)
        self.assertIn("991.98px", apres)
        # La forme, non : commentaires et espaces superflus disparaissent.
        self.assertNotIn("un commentaire", apres)

    def test_un_minifieur_qui_leve_laisse_loriginal_intact(self):
        """
        Une feuille non minifiée reste une feuille valide. Un déploiement ne
        doit pas s'arrêter — ni pire, écrire un fichier tronqué — parce que la
        compression a échoué sur un fichier.
        """
        def casse(_):
            raise ValueError("syntaxe inattendue")

        with self.assertLogs("jeiko", level="ERROR"):
            gain = self._minifier(casse)
        self.assertIsNone(gain)
        self.assertEqual(self._contenu(), CSS)

    def test_un_resultat_vide_est_refuse(self):
        """
        Le cas le plus dangereux : un minifieur qui renvoie une chaîne vide
        sans lever. L'écrire effacerait la mise en forme du site entier, et
        rien ne le signalerait.
        """
        with self.assertLogs("jeiko", level="ERROR"):
            gain = self._minifier(lambda _: "")
        self.assertIsNone(gain)
        self.assertEqual(self._contenu(), CSS)

    def test_minifier_deux_fois_ne_degrade_pas(self):
        """`collectstatic` est rejoué à chaque déploiement."""
        from csscompressor import compress

        self._minifier(compress)
        premier = self._contenu()
        self._minifier(compress)
        self.assertEqual(self._contenu(), premier)


class MinifieurAbsentTests(SimpleTestCase):
    """`csscompressor` manquant : on prévient, on sert les sources, on continue."""

    def test_labsence_du_minifieur_ne_casse_pas_le_deploiement(self):
        storage = MinifyingManifestStaticFilesStorage()
        import builtins

        vrai_import = builtins.__import__

        def sans_csscompressor(nom, *args, **kwargs):
            if nom == "csscompressor":
                raise ImportError("absent pour le test")
            return vrai_import(nom, *args, **kwargs)

        builtins.__import__ = sans_csscompressor
        try:
            with self.assertLogs("jeiko", level="WARNING"):
                self.assertIsNone(storage._charger_minifieur())
        finally:
            builtins.__import__ = vrai_import
