# jeiko/tests_redirections.py
"""
Aucune vue ne suit un `next` venu d'ailleurs (S-12).

Six écrans acceptaient un paramètre `next` et le passaient tel quel à
`redirect()`. Le lien part de votre domaine, porte votre certificat, et dépose
l'utilisateur où l'attaquant veut :

    /administration/cache/clear?next=https://site-piege.example/connexion

Rien ne casse, rien ne lève : la redirection ouverte n'existe que dans le lien
envoyé par courriel. Elle ne se voit donc ni à l'usage, ni dans les journaux.

Le septième écran, lui, vérifiait — mal. Le test correspondant ci-dessous est
le plus utile du lot : il documente pourquoi on ne réécrit pas ce contrôle à la
main.

Le dernier test est le garde-fou : il relit le paquet et refuse qu'un `next`
reparte vers `redirect()` sans passer par `destination_sure`. C'est ce qui
empêche le septième cas d'apparaître dans six mois.
"""

import pathlib
import re

from django.contrib.auth import get_user_model
from django.test import RequestFactory, SimpleTestCase, TestCase
from django.urls import reverse

from jeiko.redirections import destination_sure

PAQUET = pathlib.Path(__file__).resolve().parent

#: Destinations qu'aucune vue ne doit suivre.
HOSTILES = [
    "https://site-piege.example/connexion",
    "//site-piege.example/connexion",
    "http://site-piege.example",
    # Le cas que le contrôle maison laissait passer : commence par UNE barre
    # oblique, donc « interne » pour lui. Le navigateur, lui, traite la barre
    # inverse comme une barre à cet endroit et part sur le domaine externe.
    "/\\site-piege.example",
    "/\\/site-piege.example",
    "javascript:alert(document.domain)",
]

#: Destinations légitimes : le repli ne doit pas se déclencher.
LEGITIMES = [
    "/administration/",
    "/administration/pages/12/?onglet=contenu",
    "/",
]


class DestinationSureTests(SimpleTestCase):
    def setUp(self):
        self.requete = RequestFactory().get("/administration/")

    def test_les_destinations_externes_sont_remplacees_par_le_repli(self):
        for cible in HOSTILES:
            with self.subTest(cible=cible):
                self.assertEqual(
                    destination_sure(self.requete, cible, "/repli/"), "/repli/",
                    f"« {cible} » a été suivie : c'est une redirection ouverte.",
                )

    def test_le_contournement_par_barre_inverse_est_couvert(self):
        """
        Le contrôle qui vivait dans `administration_pages/views.py` :

            back.startswith('/') and not back.startswith('//')

        Il paraît suffisant. Il ne l'est pas — d'où le passage par la fonction
        de Django plutôt qu'un test réécrit à la main.
        """
        piege = "/\\site-piege.example"
        self.assertTrue(piege.startswith("/"))
        self.assertFalse(piege.startswith("//"))  # l'ancien contrôle disait « interne »
        self.assertEqual(destination_sure(self.requete, piege, "/repli/"), "/repli/")

    def test_les_destinations_internes_passent(self):
        for cible in LEGITIMES:
            with self.subTest(cible=cible):
                self.assertEqual(
                    destination_sure(self.requete, cible, "/repli/"), cible
                )

    def test_une_destination_vide_prend_le_repli(self):
        for vide in ("", None):
            with self.subTest(cible=vide):
                self.assertEqual(destination_sure(self.requete, vide, "/repli/"), "/repli/")

    def test_le_repli_peut_etre_un_nom_de_route(self):
        """
        Les vues repliaient déjà sur un nom de route, que `redirect()` accepte.
        La fonction doit donc le rendre tel quel, sans chercher à le valider.
        """
        self.assertEqual(
            destination_sure(self.requete, "https://ailleurs.example", "jeiko_x:y"),
            "jeiko_x:y",
        )


class VideCacheTests(TestCase):
    """Le trajet complet sur l'écran le plus exposé : son `next` vient d'un lien."""

    @classmethod
    def setUpTestData(cls):
        cls.chef = get_user_model().objects.create_superuser(
            "chef", "chef@example.test", "pw"
        )

    def setUp(self):
        self.client.force_login(self.chef)
        self.url = reverse("jeiko_administration:cache_clear")

    def test_un_next_externe_ne_sort_pas_du_site(self):
        reponse = self.client.get(self.url, {"next": "https://site-piege.example/"})
        self.assertEqual(reponse.status_code, 302)
        self.assertEqual(reponse["Location"], "/")

    def test_un_next_interne_est_suivi(self):
        reponse = self.client.get(self.url, {"next": "/administration/"})
        self.assertEqual(reponse.status_code, 302)
        self.assertEqual(reponse["Location"], "/administration/")


class AucunNextNonValideTests(SimpleTestCase):
    """
    Relecture du paquet : un `next` ne repart jamais brut vers `redirect()`.

    On lit le source plutôt que d'éprouver les six vues une à une : monter le
    décor de chacune coûterait cent lignes, et ne dirait rien de la septième
    qu'on écrira un jour. Ici, toute nouvelle vue qui oublie le garde tombe.
    """

    def _appels_redirect(self, source):
        """Rend le texte de chaque appel `redirect(...)`, parenthèses équilibrées."""
        for debut in (m.end() for m in re.finditer(r"\bredirect\(", source)):
            profondeur, i = 1, debut
            while i < len(source) and profondeur:
                if source[i] == "(":
                    profondeur += 1
                elif source[i] == ")":
                    profondeur -= 1
                i += 1
            yield source[debut:i - 1]

    def test_aucun_redirect_ne_prend_un_next_brut(self):
        coupables = []
        for fichier in sorted(PAQUET.rglob("*.py")):
            if "__pycache__" in fichier.parts or fichier.name.startswith("tests"):
                continue
            source = fichier.read_text()
            for appel in self._appels_redirect(source):
                if "next" in appel and "destination_sure" not in appel:
                    coupables.append(
                        f"{fichier.relative_to(PAQUET)} — redirect({appel.strip()[:70]}…)"
                    )

        self.assertEqual(
            coupables, [],
            "Redirection vers un « next » non validé :\n  "
            + "\n  ".join(coupables)
            + "\nPasser par jeiko.redirections.destination_sure.",
        )
