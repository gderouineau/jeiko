# jeiko/questionnaires_expert/signals.py
import logging

from django.db import transaction
from django.db.models.signals import post_delete, post_save
from django.dispatch import receiver
from django.urls import NoReverseMatch, reverse

from .models import ExpertTestData, Prospect, UserTestAccess, refresh_prospect_last_test_date

logger = logging.getLogger(__name__)


@receiver(post_save, sender=ExpertTestData, dispatch_uid="questionnaires_expert.last_test_date_save")
def update_last_test_date_on_save(sender, instance, **kwargs):
    refresh_prospect_last_test_date(instance.prospect_id)


@receiver(post_delete, sender=ExpertTestData, dispatch_uid="questionnaires_expert.last_test_date_delete")
def update_last_test_date_on_delete(sender, instance, **kwargs):
    # post_delete est aussi émis pour les suppressions en cascade et pour
    # queryset.delete(), contrairement à un override de Model.delete().
    refresh_prospect_last_test_date(instance.prospect_id)


# =========================
#  Emails
# =========================
# Envoyés après COMMIT : on ne notifie pas d'un accès qu'une transaction annulée
# aurait fait disparaître, et l'utilisateur n'attend pas le serveur SMTP.

def _absolute(path):
    from jeiko.emailing.render import site_base_url
    base = site_base_url()
    return f"{base}{path}" if base else path


@receiver(post_save, sender=UserTestAccess, dispatch_uid="questionnaires_expert.access_granted_email")
def send_access_granted_email(sender, instance, created, **kwargs):
    """Prévient l'utilisateur que l'accès à un test vient de lui être ouvert."""
    if not created:
        return

    user = instance.user
    if not getattr(user, "email", None):
        return

    try:
        link = _absolute(reverse(
            "jeiko_client_questionnaires_expert:test_question",
            kwargs={"slug": instance.test.slug, "position": 0},
        ))
    except NoReverseMatch:
        link = _absolute(f"/pass-test/{instance.test.slug}/question/0/")

    context = {
        "test_nom": instance.test.title,
        "lien_action": link,
        "origine_acces": instance.get_source_display(),
    }

    def deliver():
        from jeiko.emailing.services import send_email
        send_email("test_access_granted", user.email, context, user=user)

    transaction.on_commit(deliver)


@receiver(post_save, sender=Prospect, dispatch_uid="questionnaires_expert.prospect_captured_email")
def send_prospect_captured_email(sender, instance, created, **kwargs):
    """Signale aux administrateurs qu'un nouveau prospect a été enregistré."""
    if not created:
        return

    try:
        link = _absolute(reverse(
            "jeiko_administration_questionnaires_expert:prospect_detail",
            kwargs={"pk": instance.pk},
        ))
    except NoReverseMatch:
        link = _absolute("/")

    context = {
        "client_nom": f"{instance.firstname} {instance.lastname}".strip(),
        "client_email": instance.email or "—",
        "client_tel": instance.phone or "—",
        "origine": "Questionnaire",
        "lien_action": link,
    }

    def deliver():
        from jeiko.emailing.sending import admin_recipients
        from jeiko.emailing.services import send_email

        recipients = admin_recipients()
        if recipients:
            send_email("prospect_captured_admin", recipients, context)

    transaction.on_commit(deliver)
