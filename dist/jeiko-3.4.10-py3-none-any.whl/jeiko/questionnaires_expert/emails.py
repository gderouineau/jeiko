"""
Emails du module questionnaires_expert.

Ce fichier ne compose plus de messages : il traduit un ExpertTestData en contexte
et délègue à `jeiko.emailing`, où le sujet et la mise en page sont éditables en
back-office (codes `test_completed_results` et `test_results_admin`).

Les vues n'appellent que `send_test_result_email()` et
`send_admin_test_notification()` : leurs signatures et leur contrat sont
inchangés — retour `(success, error)`, jamais d'exception, un échec d'envoi ne
doit pas coûter son résultat au visiteur.
"""

import logging

from django.utils.html import escape

from jeiko.emailing.services import send_email

logger = logging.getLogger(__name__)


def _admin_recipients():
    """Destinataires internes, d'après la configuration mail du site."""
    from jeiko.emailing.sending import admin_recipients
    return admin_recipients()


def _admin_url(name, **kwargs):
    """URL absolue d'une vue d'administration (pour les liens dans les e-mails)."""
    from django.urls import NoReverseMatch, reverse
    from jeiko.emailing.render import site_base_url

    try:
        path = reverse(name, kwargs=kwargs)
    except NoReverseMatch:
        return ""
    base = site_base_url()
    return f"{base}{path}" if base else path


def _scores_table(test_data):
    """
    Tableau HTML des scores par profil, injecté via [%bloc_resultats%].

    Construit ici plutôt que dans le modèle éditable : une boucle sur des données
    n'est pas exprimable avec de simples balises [%cle%]. Le rendu est en <table>
    à styles inline, seule forme fiable en messagerie.
    """
    scores = (test_data.data or {}).get("scores") or []
    if not scores:
        return ""

    rows = []
    for entry in scores:
        name = escape(str(entry.get("name") or ""))
        value = escape(str(entry.get("score", "")))
        color = str(entry.get("color") or "#cccccc")
        if not color.startswith("#"):
            color = "#cccccc"

        rows.append(
            '<tr>'
            '<td style="padding:6px 8px;border-bottom:1px solid #eeeeee;">'
            f'<span style="display:inline-block;width:10px;height:10px;'
            f'background-color:{color};margin-right:8px;"></span>{name}</td>'
            '<td style="padding:6px 8px;border-bottom:1px solid #eeeeee;'
            f'text-align:right;font-weight:700;">{value}</td>'
            '</tr>'
        )

    return (
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" '
        'border="0" style="width:100%;border-collapse:collapse;">'
        + "".join(rows) +
        '</table>'
    )


def _base_context(test_data):
    profile = test_data.result_profile

    return {
        "test_nom": test_data.test.title,
        "score": (test_data.data or {}).get("total_score", ""),
        "profil": profile.name if profile else "",
        "profil_description": profile.description if profile else "",
        "bloc_resultats": _scores_table(test_data),
    }


def send_test_result_email(test_data, request=None):
    """
    Envoie à la personne ayant passé le test le lien vers sa page de résultat.

    Retourne (success: bool, error: str|None).
    """
    recipient = test_data.recipient_email
    if not recipient:
        return False, "Aucune adresse email pour ce résultat"

    context = _base_context(test_data)
    # confirm=True : ce lien porte la signature qui vaut vérification de
    # l'adresse. Il ne doit figurer que dans le message au titulaire — la
    # notification interne reçoit la version non signée.
    context["lien_resultats"] = test_data.get_result_absolute_url(request, confirm=True)

    parts = (test_data.recipient_name or "").split()
    if parts:
        context["prenom"] = parts[0]
        context["nom"] = " ".join(parts[1:])

    try:
        return send_email(
            "test_completed_results",
            recipient,
            context,
            user=test_data.user,
        )
    except Exception as exc:
        logger.exception("Échec de l'envoi du résultat #%s à %s", test_data.pk, recipient)
        return False, str(exc)


def send_admin_test_notification(test_data, request=None):
    """
    Notifie l'équipe qu'un test vient d'être passé, avec le lien vers le résultat.

    Retourne (success: bool, error: str|None).
    """
    recipients = _admin_recipients()
    if not recipients:
        return False, "Aucun destinataire administrateur configuré"

    context = _base_context(test_data)
    # Version non signée : ce lien ne doit pas valider l'adresse du répondant.
    context["lien_resultats"] = test_data.get_result_absolute_url(request)
    context["client_nom"] = test_data.recipient_name or "Répondant anonyme"
    context["client_email"] = test_data.recipient_email or "—"

    # Liens vers l'administration : détail du test, et fiche du prospect
    # lorsque le répondant n'a pas de compte.
    context["lien_testdata"] = _admin_url(
        "jeiko_administration_questionnaires_expert:test_data_detail",
        pk=test_data.pk,
    )
    if test_data.prospect_id:
        context["lien_prospect"] = _admin_url(
            "jeiko_administration_questionnaires_expert:prospect_detail",
            pk=test_data.prospect_id,
        )
    else:
        # Répondant connecté : pas de fiche prospect, on renvoie vers le test.
        context["lien_prospect"] = context["lien_testdata"]

    try:
        return send_email("test_results_admin", recipients, context)
    except Exception as exc:
        logger.exception("Échec de la notification admin pour le résultat #%s", test_data.pk)
        return False, str(exc)
