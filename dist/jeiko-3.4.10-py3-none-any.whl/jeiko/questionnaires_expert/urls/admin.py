from django.urls import path
from jeiko.questionnaires_expert.views import admin as views

app_name = "jeiko_administration_questionnaires_expert"

urlpatterns = [
    path("tests/", views.ExpertTestListView.as_view(), name="test_list"),
    path("tests/create/", views.ExpertTestCreateView.as_view(), name="test_add"),
    path("tests/<int:test_id>/", views.ExpertTestDetailView.as_view(), name="test_detail"),
    path("tests/<int:test_id>/edit/", views.ExpertTestUpdateView.as_view(), name="test_edit"),
    path("tests/<int:test_id>/delete/", views.ExpertTestDeleteView.as_view(), name="test_delete"),
    path("tests/<int:test_id>/style/", views.ExpertTestStyleUpdateView.as_view(), name="test_style"),

    path("tests/<int:test_id>/questions/create/", views.ExpertQuestionCreateView.as_view(), name="question_add"),
    path("questions/<int:question_id>/edit/", views.ExpertQuestionUpdateView.as_view(), name="question_edit"),
    path("questions/<int:question_id>/delete/", views.ExpertQuestionDeleteView.as_view(), name="question_delete"),
    path('questions/<int:question_id>/up/', views.ExpertQuestionMoveUp.as_view(), name='question_up'),
    path('questions/<int:question_id>/down/', views.ExpertQuestionMoveDown.as_view(), name='question_down'),
    path('questions/<int:question_id>/duplicate/', views.ExpertQuestionDuplicate.as_view(), name='question_duplicate'),
    path('questions/<int:question_id>/toggle-active/', views.ExpertQuestionToggleActive.as_view(), name='question_toggle_active'),
    path('tests/<int:test_id>/questions/dedupe/', views.ExpertQuestionDedupeView.as_view(), name='question_dedupe'),

    path("questions/<int:question_id>/answers/create/", views.ExpertAnswerCreateView.as_view(), name="answer_add"),
    path("answers/<int:answer_id>/edit/", views.ExpertAnswerUpdateView.as_view(), name="answer_edit"),
    path("answers/<int:answer_id>/delete/", views.ExpertAnswerDeleteView.as_view(), name="answer_delete"),
    path('answers/<int:answer_id>/up/', views.ExpertAnswerMoveUp.as_view(), name='answer_up'),
    path('answers/<int:answer_id>/down/', views.ExpertAnswerMoveDown.as_view(), name='answer_down'),

    path("tests/<int:test_id>/profiles/", views.ExpertProfileTreeView.as_view(), name="profile_tree"),
    path("tests/<int:test_id>/profiles/create/", views.ExpertProfileTypeCreateView.as_view(), name="profile_add"),
    path("profiles/<int:pk>/edit/", views.ExpertProfileTypeUpdateView.as_view(), name="profile_edit"),
    path("profiles/<int:profile_id>/delete/", views.ExpertProfileTypeDeleteView.as_view(), name="profile_delete"),

    path("tests/<int:test_id>/combinations/create/", views.ExpertProfileCombinationCreateView.as_view(), name="combination_add"),
    path("combinations/<int:pk>/edit/", views.ExpertProfileCombinationUpdateView.as_view(), name="combination_edit"),
    path("combinations/<int:pk>/delete/", views.ExpertProfileCombinationDeleteView.as_view(), name="combination_delete"),

    path("combinations/<int:combination_id>/criteria/add/", views.ExpertProfileCriterionCreateView.as_view(), name="criterion_add"),
    path("criteria/<int:criterion_id>/edit/", views.ExpertProfileCriterionUpdateView.as_view(), name="criterion_edit"),
    path("criteria/<int:criterion_id>/delete/", views.ExpertProfileCriterionDeleteView.as_view(), name="criterion_delete"),

    path('tests/<int:test_id>/results/', views.ExpertTestResultsListView.as_view(), name="test_results"),
    path('testdata/<int:pk>/', views.ExpertTestDataDetailView.as_view(), name="test_data_detail"),
    path('prospects/', views.ProspectListView.as_view(), name="prospect_list"),
    path('prospects/test/<int:test_id>/', views.prospects_for_test, name="prospects_for_test"),
    path('prospect/<int:pk>/', views.prospect_detail, name="prospect_detail"),


]
