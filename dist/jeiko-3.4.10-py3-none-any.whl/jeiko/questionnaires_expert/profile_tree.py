# jeiko/questionnaires_expert/profile_tree.py
"""
Construction de l'arborescence des profils d'un test.

Pourquoi ce module existe
-------------------------
Les profils d'un test se hiérarchisent par `parent_profiles`, et l'écran de
détail du test les affichait à plat : une liste où rien ne dit qu'un profil
en précise un autre. Avec une quinzaine de profils, la structure devient
illisible — et c'est précisément la structure qui porte le sens.

Deux gabarits avaient été commencés pour y remédier
(`profile_branch_interactive.html`, `profile_tree_interactive.htm`). Ils
construisaient l'arbre **dans le gabarit**, au moyen de filtres inventés
(`dictfilter`, `dictfiltervalue`) qui n'ont jamais existé : le fichier ne
compilait pas, et il visait de surcroît un champ `parent_profile_id` absent du
modèle — la relation réelle est un ManyToMany. Ils ont été supprimés au profit
de ce module, qui fait le travail en Python, où il est testable.

Ce que la relation impose
-------------------------
`parent_profiles` est un ManyToMany réflexif : un profil peut avoir **plusieurs
parents**. La structure n'est donc pas un arbre mais un graphe orienté, ce qui
a deux conséquences dont le rendu doit tenir compte.

*Un profil peut apparaître à plusieurs endroits.* C'est voulu : sous chacun de
ses parents. Ce n'est pas une duplication à corriger.

*Un cycle est possible.* Rien dans le modèle n'empêche A d'être parent de B et
B parent de A. Une descente naïve boucle alors jusqu'à l'épuisement de la pile
— l'écran ne s'afficherait plus, et la cause serait difficile à voir depuis la
trace. On coupe donc la branche au deuxième passage sur un même profil, en le
signalant : mieux vaut un écran qui montre le cycle qu'un écran qui tombe.

*Un profil peut n'être atteignable par aucune racine* s'il n'existe que dans un
cycle. On le rattache alors à la racine, faute de quoi il disparaîtrait de
l'écran censé tout montrer.
"""


class Noeud:
    """
    Un profil et sa descendance, tels que le gabarit les consomme.

    Le gabarit lit `node.profile` et `node.children` ; `cycle` lui sert à
    signaler une branche coupée.
    """

    __slots__ = ("profile", "children", "cycle")

    def __init__(self, profile, children=None, cycle=False):
        self.profile = profile
        self.children = children if children is not None else []
        self.cycle = cycle

    def __repr__(self):  # pragma: no cover - confort de débogage
        return f"<Noeud {self.profile} enfants={len(self.children)} cycle={self.cycle}>"


def construire_foret(profiles):
    """
    Retourne la liste des nœuds racines pour un itérable de profils.

    `profiles` doit être matérialisé avec `prefetch_related('parent_profiles')` :
    sans lui, chaque profil coûte une requête, et l'écran en produit autant que
    de profils.
    """
    profiles = list(profiles)
    if not profiles:
        return []

    connus = {p.pk for p in profiles}

    # Enfants directs, indexés par parent. On lit `parent_profiles` (préchargé)
    # plutôt que la relation inverse, pour ne pas déclencher une requête par
    # profil.
    enfants = {p.pk: [] for p in profiles}
    parents_de = {}
    for profil in profiles:
        # On ignore les parents hors du test courant : un profil d'un autre
        # test n'a rien à faire dans cette arborescence.
        pere_pks = [q.pk for q in profil.parent_profiles.all() if q.pk in connus]
        parents_de[profil.pk] = pere_pks
        for pk in pere_pks:
            enfants[pk].append(profil)

    racines = [p for p in profiles if not parents_de[p.pk]]

    # Un profil pris dans un cycle n'a aucun chemin depuis une racine : il ne
    # serait rendu nulle part. On le remonte à la racine pour qu'il reste
    # visible et corrigeable.
    atteignables = _atteignables_depuis(racines, enfants)
    orphelins = [p for p in profiles
                 if p.pk not in atteignables and parents_de[p.pk]]
    racines.extend(orphelins)

    return [_descendre(p, enfants, vus=frozenset()) for p in racines]


def _descendre(profil, enfants, vus):
    """Construit le nœud d'un profil, en coupant les branches déjà parcourues."""
    if profil.pk in vus:
        # Cycle : on montre le profil, on ne redescend pas.
        return Noeud(profil, cycle=True)

    vus = vus | {profil.pk}
    return Noeud(profil, [
        _descendre(enfant, enfants, vus)
        for enfant in enfants.get(profil.pk, ())
    ])


def _atteignables_depuis(racines, enfants):
    """Clés primaires accessibles en descendant depuis les racines."""
    atteints = set()
    a_voir = [p.pk for p in racines]
    while a_voir:
        pk = a_voir.pop()
        if pk in atteints:
            continue
        atteints.add(pk)
        a_voir.extend(e.pk for e in enfants.get(pk, ()))
    return atteints
