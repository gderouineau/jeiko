# jeiko/questionnaires_expert/tests_profile_tree.py
"""
L'arborescence des profils : structure, cas limites, et accès.

Ce que ces tests couvrent
-------------------------
`parent_profiles` est un ManyToMany réflexif. La structure n'est donc pas un
arbre mais un graphe orienté, et deux situations parfaitement légales du point
de vue du modèle mettraient en défaut une descente naïve :

- un profil ayant **plusieurs parents**, qui doit apparaître sous chacun ;
- un **cycle**, qui ferait boucler la récursion jusqu'à épuisement de la pile.

Rien dans le modèle n'interdit le second. Les gabarits abandonnés qui ont
précédé ce module n'en tenaient pas compte — ils ne compilaient de toute façon
pas, et visaient un champ `parent_profile_id` qui n'existe pas sur ce modèle.
"""

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from jeiko.questionnaires_expert.models import ExpertProfileType, ExpertTest
from jeiko.questionnaires_expert.profile_tree import construire_foret


def _parcourir(noeuds):
    """Tous les nœuds de la forêt, à toute profondeur."""
    for noeud in noeuds:
        yield noeud
        yield from _parcourir(noeud.children)


def _noeuds_en_boucle(noeuds):
    """Les nœuds où la descente a été coupée. La coupure n'est pas forcément
    à la profondeur 1 : sur un cycle A→B→A, elle survient au troisième cran."""
    return [n for n in _parcourir(noeuds) if n.cycle]


class ConstructionDeLarbreTests(TestCase):
    """Le constructeur seul, sans passer par une vue."""

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="Test", description="", slug="t-principal")

    def _profil(self, nom, *parents):
        profil = ExpertProfileType.objects.create(test=self.test, name=nom)
        if parents:
            profil.parent_profiles.set(parents)
        return profil

    def _charger(self):
        return (ExpertProfileType.objects
                .filter(test=self.test)
                .prefetch_related("parent_profiles")
                .order_by("name"))

    def _noms(self, noeuds):
        return [n.profile.name for n in noeuds]

    def test_sans_profil_la_foret_est_vide(self):
        self.assertEqual(construire_foret(self._charger()), [])

    def test_des_profils_sans_parent_sont_tous_racines(self):
        self._profil("A")
        self._profil("B")
        racines = construire_foret(self._charger())
        self.assertEqual(sorted(self._noms(racines)), ["A", "B"])
        self.assertEqual([len(r.children) for r in racines], [0, 0])

    def test_un_enfant_est_range_sous_son_parent(self):
        a = self._profil("A")
        self._profil("B", a)
        racines = construire_foret(self._charger())
        self.assertEqual(self._noms(racines), ["A"])
        self.assertEqual(self._noms(racines[0].children), ["B"])

    def test_la_profondeur_est_respectee(self):
        a = self._profil("A")
        b = self._profil("B", a)
        self._profil("C", b)
        racines = construire_foret(self._charger())
        self.assertEqual(self._noms(racines[0].children[0].children), ["C"])

    def test_un_profil_a_deux_parents_apparait_sous_chacun(self):
        """
        Ce n'est pas une duplication à corriger : c'est ce que dit le modèle.
        Un ManyToMany autorise plusieurs parents, et l'écran doit le montrer.
        """
        a = self._profil("A")
        b = self._profil("B")
        self._profil("C", a, b)
        racines = construire_foret(self._charger())
        self.assertEqual(sorted(self._noms(racines)), ["A", "B"])
        for racine in racines:
            self.assertEqual(self._noms(racine.children), ["C"])

    def test_un_parent_hors_du_test_est_ignore(self):
        """Un profil d'un autre questionnaire n'a rien à faire dans cet arbre."""
        autre_test = ExpertTest.objects.create(title="Autre", description="", slug="t-autre")
        etranger = ExpertProfileType.objects.create(test=autre_test, name="Z")
        a = self._profil("A")
        a.parent_profiles.set([etranger])
        racines = construire_foret(self._charger())
        self.assertEqual(self._noms(racines), ["A"])


class CyclesTests(TestCase):
    """Le cas que rien n'empêche en base, et qui ferait tomber l'écran."""

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="Test", description="", slug="t-principal")

    def _profil(self, nom):
        return ExpertProfileType.objects.create(test=self.test, name=nom)

    def _charger(self):
        return (ExpertProfileType.objects
                .filter(test=self.test)
                .prefetch_related("parent_profiles")
                .order_by("name"))

    def test_un_cycle_ne_fait_pas_boucler_la_construction(self):
        """A parent de B, B parent de A. Sans garde, la pile explose."""
        a, b = self._profil("A"), self._profil("B")
        a.parent_profiles.set([b])
        b.parent_profiles.set([a])

        racines = construire_foret(self._charger())  # ne doit pas lever

        self.assertTrue(racines, "Les profils d'un cycle doivent rester visibles.")
        noms = {n.profile.name for n in racines}
        self.assertEqual(noms, {"A", "B"})

    def test_le_cycle_est_signale_sur_le_noeud_coupe(self):
        """L'exploitant doit voir la boucle, pas la subir."""
        a, b = self._profil("A"), self._profil("B")
        a.parent_profiles.set([b])
        b.parent_profiles.set([a])

        racines = construire_foret(self._charger())
        self.assertTrue(
            _noeuds_en_boucle(racines),
            "Aucun nœud n'est marqué comme boucle : la coupure n'est pas signalée.",
        )

    def test_un_profil_pris_dans_un_cycle_reste_affiche(self):
        """
        Sans remontée à la racine, un profil qui n'existe que dans une boucle
        n'aurait aucun chemin depuis une racine et disparaîtrait de l'écran
        censé tout montrer.
        """
        racine = self._profil("Racine")
        a, b = self._profil("A"), self._profil("B")
        a.parent_profiles.set([b])
        b.parent_profiles.set([a])

        noms_racines = {n.profile.name for n in construire_foret(self._charger())}
        self.assertIn("Racine", noms_racines)
        self.assertTrue({"A", "B"} & noms_racines)

    def test_un_profil_son_propre_parent(self):
        """Cas dégénéré du cycle, à une seule arête."""
        a = self._profil("A")
        a.parent_profiles.set([a])
        racines = construire_foret(self._charger())
        self.assertEqual([n.profile.name for n in racines], ["A"])


class EcranArborescenceTests(TestCase):
    """La vue : accès, rendu, et coût en requêtes."""

    @classmethod
    def setUpTestData(cls):
        cls.test = ExpertTest.objects.create(title="Mon test", description="", slug="t-vue")
        racine = ExpertProfileType.objects.create(test=cls.test, name="Racine")
        enfant = ExpertProfileType.objects.create(test=cls.test, name="Enfant")
        enfant.parent_profiles.set([racine])
        cls.url = reverse(
            "jeiko_administration_questionnaires_expert:profile_tree",
            args=[cls.test.id],
        )

    def _utilisateur(self, **kwargs):
        User = get_user_model()
        return User.objects.create_user(username="u", password="mdp", **kwargs)

    def test_lanonyme_est_refuse(self):
        self.assertIn(self.client.get(self.url).status_code, (302, 403))

    def test_un_compte_sans_permission_est_refuse(self):
        self._utilisateur()
        self.client.login(username="u", password="mdp")
        self.assertEqual(self.client.get(self.url).status_code, 403)

    def test_un_administrateur_voit_larborescence(self):
        self._utilisateur(is_superuser=True, is_staff=True)
        self.client.login(username="u", password="mdp")
        reponse = self.client.get(self.url)
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "Racine")
        self.assertContains(reponse, "Enfant")
        self.assertEqual(len(reponse.context["racines"]), 1)

    def test_un_test_sans_profil_affiche_un_etat_vide(self):
        vide = ExpertTest.objects.create(title="Vide", description="", slug="t-vide")
        self._utilisateur(is_superuser=True, is_staff=True)
        self.client.login(username="u", password="mdp")
        reponse = self.client.get(reverse(
            "jeiko_administration_questionnaires_expert:profile_tree",
            args=[vide.id],
        ))
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "Aucun profil")

    def test_le_cout_en_requetes_ne_depend_pas_du_nombre_de_profils(self):
        """
        Le préchargement doit tenir : sans lui, l'écran fait deux requêtes par
        profil et devient inutilisable sur un questionnaire fourni.
        """
        self._utilisateur(is_superuser=True, is_staff=True)
        self.client.login(username="u", password="mdp")

        with self.assertNumQueries(as_num := self._compter()):
            self.client.get(self.url)

        for i in range(15):
            ExpertProfileType.objects.create(test=self.test, name=f"P{i}")

        with self.assertNumQueries(as_num):
            self.client.get(self.url)

    def _compter(self):
        from django.db import connection
        from django.test.utils import CaptureQueriesContext

        with CaptureQueriesContext(connection) as ctx:
            self.client.get(self.url)
        return len(ctx)
