"""
Tests de jeiko.shop : visibilité publique des fiches, listes dynamiques et
règlement des commandes.

Le décor est celui de custom_objects — un produit n'existe pas sans sa fiche.
"""

from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase

from jeiko.administration_pages.models import DynResourceConfig
from jeiko.custom_objects.models import CustomObject
from jeiko.custom_objects.tests import CustomObjectFixture
from jeiko.shop.models import (
    Cart,
    CartItem,
    Order,
    OrderLine,
    Product,
    ProductStockMovement,
    ProductType,
)
from jeiko.shop.services import (
    compute_order_totals,
    mark_order_paid,
    to_minor_units,
)
from jeiko.templatetags.dynamic_resources import get_resources

User = get_user_model()


class ProductVisibilityTests(CustomObjectFixture):
    def test_produit_inactif_invisible(self):
        Product.objects.filter(pk=self.product.pk).update(is_active=False)
        self.assertEqual(self.client.get("/shop/formation/form-42/").status_code, 404)

    def test_fiche_brouillon_invisible(self):
        CustomObject.objects.filter(pk=self.obj.pk).update(is_published=False)
        self.assertEqual(self.client.get("/shop/formation/form-42/").status_code, 404)

    def test_mauvais_code_de_type_invisible(self):
        self.assertEqual(
            self.client.get("/shop/nimporte-quoi/form-42/").status_code, 404
        )

    def test_ajout_panier_refuse_produit_inactif(self):
        Product.objects.filter(pk=self.product.pk).update(is_active=False)
        response = self.client.post(
            f"/shop/cart/add/{self.product.pk}/", {"quantity": 1}
        )
        self.assertEqual(response.status_code, 404)
        self.assertEqual(CartItem.objects.count(), 0)


class DynamicResourcesTests(CustomObjectFixture):
    def test_source_produit_avec_type(self):
        config = DynResourceConfig(
            source_type="PRODUCT", product_type=self.ptype, limit=0
        )
        # Levait FieldError : le champ de Product s'appelle `type`.
        self.assertEqual(list(get_resources(config)), [self.product])

    def test_source_produit_exclut_brouillon(self):
        CustomObject.objects.filter(pk=self.obj.pk).update(is_published=False)
        config = DynResourceConfig(
            source_type="PRODUCT", product_type=self.ptype, limit=0
        )
        self.assertEqual(list(get_resources(config)), [])

    def test_source_objet_custom(self):
        config = DynResourceConfig(
            source_type="CUSTOM_OBJECT", custom_object_model=self.com, limit=0
        )
        self.assertEqual(list(get_resources(config)), [self.obj])


class MoneyTests(TestCase):
    def test_arrondi_au_centime_superieur(self):
        # 8.33 HT a 20% donne 9.996 : int() tronquait a 999 centimes.
        ttc = Decimal("8.33") * Decimal("1.20")
        self.assertEqual(to_minor_units(ttc), 1000)

    def test_totaux_coherents(self):
        class Ligne:
            total_ht = Decimal("16.66")
            total_ttc = Decimal("19.992")

        total_ht, total_tva, total_ttc = compute_order_totals([Ligne()])
        self.assertEqual(total_ht + total_tva, total_ttc)


class OrderFulfillmentTests(CustomObjectFixture):
    def setUp(self):
        super().setUp()
        self.user = User.objects.create_user("client", "c@example.test", "pw")

        self.physique = ProductType.objects.create(
            name="Objet",
            code="objet",
            content_model=self.com,
            kind=ProductType.KIND_PHYSICAL,
            requires_shipping=True,
        )
        contenu_mug = CustomObject.objects.create(
            model=self.com, title="Mug", slug="mug", is_published=True
        )
        self.mug = Product.objects.create(
            type=self.physique,
            content=contenu_mug,
            sku="mug-1",
            price_ht=Decimal("10.00"),
            tax_rate=Decimal("20.00"),
            stock_quantity=7,
            is_active=True,
        )

        cart = Cart.objects.create(user=self.user)
        self.order = Order.objects.create(user=self.user, cart=cart)
        OrderLine.objects.create(
            order=self.order,
            product=self.mug,
            label="Mug",
            sku="mug-1",
            quantity=2,
            unit_price_ht=Decimal("10.00"),
            tax_rate=Decimal("20.00"),
        )
        OrderLine.objects.create(
            order=self.order,
            product=self.product,
            label="Formation",
            sku="form-42",
            quantity=1,
            unit_price_ht=Decimal("100.00"),
            tax_rate=Decimal("20.00"),
        )

    def test_decremente_le_stock_des_seuls_produits_expedies(self):
        self.assertTrue(mark_order_paid(self.order, source="test"))
        self.mug.refresh_from_db()
        self.product.refresh_from_db()
        self.assertEqual(self.mug.stock_quantity, 5)  # 7 - 2
        self.assertEqual(self.product.stock_quantity, 5)  # formation : inchange
        self.assertEqual(ProductStockMovement.objects.count(), 1)

    def test_reglement_idempotent(self):
        # Le webhook et le retour navigateur arrivent tous les deux.
        self.assertTrue(mark_order_paid(self.order, source="webhook"))
        self.assertFalse(mark_order_paid(self.order, source="retour"))
        self.mug.refresh_from_db()
        self.assertEqual(self.mug.stock_quantity, 5)
        self.assertEqual(ProductStockMovement.objects.count(), 1)

    def test_confirme_la_commande_et_verrouille_le_panier(self):
        mark_order_paid(self.order, source="test")
        self.order.refresh_from_db()
        self.assertEqual(self.order.payment_status, Order.PAYMENT_STATUS_PAID)
        self.assertEqual(self.order.order_status, Order.ORDER_STATUS_CONFIRMED)
        self.assertTrue(self.order.cart.is_locked)

    def test_accorde_l_acces_a_la_formation_liee(self):
        from jeiko.courses.models import Course, CourseEnrollment

        cours = Course.objects.create(title="Cours", slug="cours")
        Product.objects.filter(pk=self.product.pk).update(linked_course=cours)

        mark_order_paid(self.order, source="test")
        self.assertTrue(
            CourseEnrollment.objects.filter(
                user=self.user, course=cours, has_payed=True, order=self.order
            ).exists()
        )
