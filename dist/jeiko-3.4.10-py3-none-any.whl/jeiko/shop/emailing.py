# jeiko/shop/emailing.py
"""
E-mails de la boutique.

Le système d'e-mails éditables était en place, le catalogue déclarait les huit
codes de la chaîne transactionnelle — et aucun n'était appelé. Un client payait
sans jamais rien recevoir, et l'exploitant n'était pas prévenu qu'une commande
était tombée.

Ce module traduit une Order en contexte et délègue à `jeiko.emailing`, où sujets
et mises en page restent éditables en back-office. Il ne compose pas de message,
et aucune fonction ne lève : un e-mail qui ne part pas ne doit jamais faire
échouer un règlement, un remboursement ni une expédition.

Codes utilisés — order_confirmation, payment_received, order_admin_new,
payment_failed, order_shipped, order_completed, order_cancelled, order_refunded.
"""

import logging

from django.urls import NoReverseMatch, reverse
from django.utils.html import escape

from jeiko.emailing.render import site_base_url
from jeiko.emailing.sending import admin_recipients
from jeiko.emailing.services import send_email

logger = logging.getLogger(__name__)


# =========================
#  Mise en forme
# =========================

def _absolute(path):
    base = site_base_url()
    return f"{base}{path}" if base else path


def _montant(valeur, devise="EUR"):
    """Montant lisible. La devise est celle figée sur la commande."""
    return f"{valeur:.2f} {devise}".strip()


def _numero(order):
    """
    Numéro présenté au client.

    Le modèle ne porte pas de référence dédiée : la clé primaire fait office de
    numéro de commande, préfixée pour qu'elle se lise comme telle.
    """
    return f"#{order.pk}"


def _destinataire(order):
    """
    Adresse du client.

    Le compte fait foi — le tunnel de commande exige désormais un compte, donc
    cette adresse existe toujours pour une commande passée normalement.
    """
    return getattr(order.user, "email", "") or ""


def _client_nom(order):
    if order.billing_name:
        return order.billing_name
    user = order.user
    if not user:
        return ""
    return (user.get_full_name() or user.get_username() or "").strip()


def _prenom(order):
    return (_client_nom(order) or "").split(" ")[0]


def _bloc_lignes(order):
    """
    Tableau HTML des articles, injecté tel quel dans le corps de l'e-mail.

    Les valeurs sont échappées une à une : un intitulé de produit vient de
    l'administration, et le rendu e-mail marque ce bloc sûr. Le style est en
    ligne, comme tout le reste du rendu e-mail (les clients de messagerie
    ignorent les feuilles externes).
    """
    cellule = 'style="padding:8px 10px;border-bottom:1px solid #e5e7eb;"'
    entete = (
        'style="padding:8px 10px;border-bottom:2px solid #111;'
        'text-align:left;font-weight:700;"'
    )

    lignes = [
        "<table role='presentation' cellpadding='0' cellspacing='0' "
        "style='width:100%;border-collapse:collapse;font-size:14px;'>",
        f"<tr><th {entete}>Article</th><th {entete}>Qté</th>"
        f"<th {entete}>Prix</th></tr>",
    ]
    for ligne in order.lines.all():
        total = ligne.quantity * ligne.unit_price_ht
        lignes.append(
            f"<tr><td {cellule}>{escape(ligne.label or ligne.sku or '')}</td>"
            f"<td {cellule}>{ligne.quantity}</td>"
            f"<td {cellule}>{escape(_montant(total, order.currency))}</td></tr>"
        )
    lignes.append(
        f"<tr><td {cellule} colspan='2'><strong>Total</strong></td>"
        f"<td {cellule}><strong>"
        f"{escape(_montant(order.total_ttc, order.currency))}</strong></td></tr>"
    )
    lignes.append("</table>")
    return "".join(lignes)


def _lien_commande(order):
    try:
        return _absolute(reverse("jeiko_users_client:order_detail", args=[order.pk]))
    except NoReverseMatch:
        return ""


def _lien_admin(order):
    try:
        return _absolute(
            reverse("jeiko_shop_admin_orders:order_update", args=[order.pk])
        )
    except NoReverseMatch:
        return ""


def _contexte(order):
    """Contexte commun à tous les e-mails de commande."""
    return {
        "prenom": _prenom(order),
        "commande_num": _numero(order),
        "commande_date": order.created_at.strftime("%d/%m/%Y"),
        "commande_total": _montant(order.total_ttc, order.currency),
        "montant": _montant(order.total_ttc, order.currency),
        "lien_action": _lien_commande(order),
    }


# =========================
#  Envois
# =========================

def send_order_paid_emails(order):
    """
    Confirmation + reçu au client, notification à l'exploitant.

    Appelé après COMMIT par `shop.services.mark_order_paid`, pour ne pas
    annoncer une commande qu'une transaction annulée effacerait.
    """
    contexte = _contexte(order)
    client = _destinataire(order)

    if client:
        confirmation = dict(contexte)
        confirmation["bloc_lignes"] = _bloc_lignes(order)
        confirmation["adresse_livraison"] = (
            order.shipping_address or order.billing_address or ""
        )
        send_email("order_confirmation", client, confirmation, user=order.user)

        recu = dict(contexte)
        recu["moyen_paiement"] = "Carte bancaire"
        recu["lien_facture"] = contexte["lien_action"]
        send_email("payment_received", client, recu, user=order.user)
    else:
        logger.warning(
            "Commande #%s réglée sans adresse client : aucun e-mail envoyé.",
            order.pk,
        )

    destinataires = admin_recipients()
    if destinataires:
        interne = dict(contexte)
        interne["client_nom"] = _client_nom(order)
        interne["client_email"] = client
        interne["bloc_lignes"] = _bloc_lignes(order)
        interne["lien_action"] = _lien_admin(order)
        send_email("order_admin_new", destinataires, interne)


def send_payment_failed_email(order, motif=""):
    """Échec de paiement : on rend au client le moyen de reprendre."""
    client = _destinataire(order)
    if not client:
        return

    contexte = _contexte(order)
    contexte["motif"] = motif or "Le paiement n'a pas abouti."
    try:
        contexte["lien_action"] = _absolute(
            reverse("jeiko_payments_client:checkout")
        )
    except NoReverseMatch:
        pass
    send_email("payment_failed", client, contexte, user=order.user)


def send_order_shipped_email(order):
    """
    Expédition.

    Le modèle Order ne porte ni transporteur ni numéro de suivi : ces variables
    sont déclarées au catalogue mais renseignées à vide, faute de données. Elles
    se rempliront d'elles-mêmes le jour où ces champs existeront.
    """
    client = _destinataire(order)
    if not client:
        return

    contexte = _contexte(order)
    contexte.update({
        "transporteur": "",
        "numero_suivi": "",
        "lien_suivi": "",
        "date_livraison_estimee": "",
    })
    send_email("order_shipped", client, contexte, user=order.user)


def send_order_completed_email(order):
    client = _destinataire(order)
    if not client:
        return

    contexte = _contexte(order)
    contexte["bloc_lignes"] = _bloc_lignes(order)
    send_email("order_completed", client, contexte, user=order.user)


def send_order_cancelled_email(order, motif=""):
    client = _destinataire(order)
    if not client:
        return

    contexte = _contexte(order)
    contexte["motif"] = motif or "Commande annulée."
    send_email("order_cancelled", client, contexte, user=order.user)


def send_order_refunded_email(order):
    client = _destinataire(order)
    if not client:
        return

    contexte = _contexte(order)
    contexte["moyen_paiement"] = "Carte bancaire"
    contexte["delai"] = "sous 5 à 10 jours ouvrés"
    send_email("order_refunded", client, contexte, user=order.user)
