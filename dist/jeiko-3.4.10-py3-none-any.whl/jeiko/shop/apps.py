from django.apps import AppConfig


class ShopConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko.shop'

    def ready(self):
        # Reprise du panier anonyme à la connexion (cf. shop/signals.py).
        from . import signals  # noqa: F401
