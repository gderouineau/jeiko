"""
Panier courant, et sa reprise à la connexion.

Le tunnel de commande exige désormais un compte. Sans reprise du panier, cette
exigence se retournerait contre l'acheteur : il remplit son panier en anonyme,
clique sur « Commander », se connecte — et retrouve un panier vide, exactement
au moment où on vient de lui imposer un détour. La fusion n'est donc pas un
agrément, c'est la condition pour que la connexion obligatoire soit tenable.

Pourquoi l'identifiant du panier passe par la session
-----------------------------------------------------
Un panier anonyme était retrouvé par `session_key`. Or `django.contrib.auth.login`
appelle `cycle_key()` : au moment où le signal `user_logged_in` part, la clé de
session a déjà changé, et le panier anonyme est devenu introuvable. `cycle_key`
conserve en revanche les **données** de session — on y range donc l'identifiant
du panier, qui survit à la connexion.

La recherche par `session_key` est gardée en repli, pour les paniers créés
avant cette bascule.
"""

import logging

from django.db import transaction

from .models import Cart, CartItem

logger = logging.getLogger(__name__)

#: Identifiant du panier courant, conservé dans les données de session.
SESSION_CART_KEY = "jeiko_cart_id"


def _remember(request, cart):
    if request.session.get(SESSION_CART_KEY) != cart.pk:
        request.session[SESSION_CART_KEY] = cart.pk
    return cart


def get_or_create_cart(request):
    """Panier modifiable du visiteur, créé au besoin."""
    user = getattr(request, "user", None)

    if user is not None and user.is_authenticated:
        cart = Cart.objects.filter(user=user, is_locked=False).first()
        if cart is None:
            cart = Cart.objects.create(user=user)
        return _remember(request, cart)

    if not request.session.session_key:
        request.session.create()

    cart_id = request.session.get(SESSION_CART_KEY)
    cart = None
    if cart_id:
        cart = Cart.objects.filter(
            pk=cart_id, user__isnull=True, is_locked=False
        ).first()
    if cart is None:
        cart = Cart.objects.filter(
            session_key=request.session.session_key, is_locked=False
        ).first()
    if cart is None:
        cart = Cart.objects.create(session_key=request.session.session_key)

    return _remember(request, cart)


@transaction.atomic
def merge_session_cart(request, user):
    """
    Reprend le panier anonyme dans celui du compte, à la connexion.

    Les quantités s'additionnent produit par produit, et le prix unitaire est
    rafraîchi au tarif courant — même règle que l'ajout au panier, qui ne fige
    pas le prix tant que la commande n'est pas passée.

    Ne lève jamais : rater une fusion doit coûter un panier, jamais une
    connexion.
    """
    cart_id = request.session.get(SESSION_CART_KEY)
    if not cart_id:
        return None

    anonyme = (
        Cart.objects.filter(pk=cart_id, user__isnull=True, is_locked=False)
        .prefetch_related("items__product")
        .first()
    )
    if anonyme is None:
        request.session.pop(SESSION_CART_KEY, None)
        return None

    cible = Cart.objects.filter(user=user, is_locked=False).first()
    if cible is None:
        # Aucun panier de compte : on s'approprie l'anonyme tel quel, ce qui
        # évite de recopier les lignes pour rien.
        anonyme.user = user
        anonyme.session_key = ""
        anonyme.save(update_fields=["user", "session_key", "updated_at"])
        request.session[SESSION_CART_KEY] = anonyme.pk
        return anonyme

    existantes = {item.product_id: item for item in cible.items.all()}
    for item in anonyme.items.all():
        cible_item = existantes.get(item.product_id)
        if cible_item is None:
            item.cart = cible
            item.save(update_fields=["cart"])
            existantes[item.product_id] = item
            continue

        cible_item.quantity += item.quantity
        if item.product is not None:
            cible_item.unit_price_ht = item.product.price_ht
            cible_item.tax_rate = item.product.tax_rate
        cible_item.save(update_fields=["quantity", "unit_price_ht", "tax_rate"])
        item.delete()

    anonyme.delete()
    request.session[SESSION_CART_KEY] = cible.pk
    return cible


def merge_session_cart_safe(request, user):
    """`merge_session_cart` sans jamais lever — pour le signal de connexion."""
    try:
        return merge_session_cart(request, user)
    except Exception:
        logger.exception("Reprise du panier anonyme impossible (user=%s)",
                         getattr(user, "pk", None))
        return None


__all__ = [
    "SESSION_CART_KEY",
    "get_or_create_cart",
    "merge_session_cart",
    "merge_session_cart_safe",
    "CartItem",
]
