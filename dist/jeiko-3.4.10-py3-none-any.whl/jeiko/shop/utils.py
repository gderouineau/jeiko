# shop/utils.py
#
# `get_or_create_cart` vivait ici en double, dans une version jamais importée
# et divergente : elle passait `created_at` en `defaults` alors que le champ
# est un auto_now_add, et cherchait le panier par (user, is_locked) sans
# jamais retomber sur la session. L'implémentation de référence est celle de
# jeiko.shop.views.client — la seule utilisée, y compris par payments.
#
# On réexporte plutôt que de supprimer : un projet en production peut encore
# importer ce chemin.

from jeiko.shop.views.client import get_or_create_cart  # noqa: F401

__all__ = ["get_or_create_cart"]
