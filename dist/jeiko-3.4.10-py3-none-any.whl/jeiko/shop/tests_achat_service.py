# jeiko/shop/tests_achat_service.py
"""
Simulation d'achat : un abonnement doit pouvoir être acheté.

Pourquoi ce fichier existe
--------------------------
Les trois formules JEIKO — 19, 39, 99 € par mois — étaient **invendables**.
Pas « mal affichées » : invendables. Le panier refusait l'ajout, la mise à
jour supprimait la ligne, et Google recevait `OutOfStock`.

La cause était une divergence, pas un oubli. Trois notions coexistaient pour
répondre à « ce produit s'épuise-t-il ? » :

* `ProductType.requires_shipping` — ce que consultait le décrément de stock
  **à la commande**, et qui était juste ;
* `ProductType.is_physical` — le même champ en plus ancien, intitulé
  « legacy » ;
* `Product.allow_negative_stock` — un réglage de dépassement, que le panier
  prenait pour une nature.

Le panier refusait donc ce que la commande aurait servi sans toucher au stock.
Deux chemins, deux critères, et personne pour les confronter — jusqu'à ce
qu'on essaie de vendre un abonnement.

Ce test parcourt le chemin complet, du panier à la commande, sur un produit à
stock zéro qui ne s'épuise pas. C'est le seul contrôle qui aurait attrapé le
défaut : chaque étape prise isolément avait l'air correcte.
"""

from decimal import Decimal

from django.test import TestCase
from django.urls import reverse

from jeiko.administration_pages.models import Page
from jeiko.custom_objects.models import CustomObject, CustomObjectModel
from jeiko.shop.models import CartItem, Product, ProductType


class AchatDUnAbonnementTests(TestCase):
    def setUp(self):
        gabarit = Page.objects.create(
            title="Gabarit", url_tag="gab-achat", is_custom_object_template=True
        )
        modele = CustomObjectModel.objects.create(
            name="Formule", slug="formule-achat", page_template=gabarit,
            is_product=True,
        )
        self.type = ProductType.objects.create(
            name="Abonnement", code="abonnement-achat",
            kind=ProductType.KIND_SERVICE,
            is_physical=False, requires_shipping=False,
            content_model=modele,
        )
        fiche = CustomObject.objects.create(
            model=modele, title="Équipe", slug="equipe-achat", is_published=True
        )
        # Stock zéro, et c'est NORMAL : personne ne saisit un stock
        # d'abonnements.
        self.produit = Product.objects.create(
            type=self.type, content=fiche, sku="JEIKO-EQUIPE-T",
            price_ht=Decimal("39.00"), stock_quantity=0, is_active=True,
        )

    def test_l_abonnement_s_ajoute_au_panier(self):
        reponse = self.client.post(
            f"/shop/cart/add/{self.produit.pk}/", {"quantity": 1}
        )
        self.assertEqual(reponse.status_code, 302)
        self.assertEqual(
            CartItem.objects.count(), 1,
            "Le panier a refusé un abonnement à stock zéro : il est "
            "invendable, et rien ne le dit au visiteur sinon « plus "
            "disponible en quantité suffisante ».",
        )

    def test_la_quantite_se_modifie_sans_etre_ramenee_a_zero(self):
        self.client.post(f"/shop/cart/add/{self.produit.pk}/", {"quantity": 1})
        ligne = CartItem.objects.get()

        self.client.post(
            reverse("jeiko_client_shop:cart_update", args=[ligne.pk]),
            {"action": "update", "quantity": 3},
        )
        ligne.refresh_from_db()
        self.assertEqual(
            ligne.quantity, 3,
            "La mise à jour a plafonné sur un stock qui n'existe pas.",
        )

    def test_la_page_produit_l_annonce_disponible(self):
        self.assertTrue(self.produit.est_disponible)

    def test_le_stock_n_est_pas_decremente_a_la_commande(self):
        """
        Un abonnement n'a pas de stock à consommer. Le décrément l'ignorait
        déjà — c'est le seul des trois chemins qui était juste, et c'est
        pourquoi « ça fonctionnait avant » côté commande.
        """
        self.assertFalse(self.produit.suit_le_stock)

    def test_un_produit_expediable_garde_ses_gardes(self):
        """
        Le correctif ne doit pas ouvrir la vente de ce qui s'épuise vraiment.
        """
        self.type.requires_shipping = True
        self.type.save(update_fields=["requires_shipping"])
        self.produit.refresh_from_db()

        self.assertFalse(self.produit.est_disponible)
        reponse = self.client.post(
            f"/shop/cart/add/{self.produit.pk}/", {"quantity": 1}
        )
        self.assertEqual(reponse.status_code, 302)
        self.assertEqual(
            CartItem.objects.count(), 0,
            "Un produit physique épuisé doit rester refusé.",
        )
