"""
Contrôle d'accès de l'administration boutique et objets personnalisés.

Ces vues étaient gardées par un simple `is_staff or is_superuser`, alors que le
menu les gardait par les permissions des modèles. L'écart jouait dans les deux
sens, et ce fichier fige les deux : un compte « équipe » sans droit boutique ne
doit plus entrer par l'URL, et un porteur des droits sans le drapeau `is_staff`
ne doit plus être refusé.

Les deux applications sont testées ensemble : elles portaient le même défaut et
partagent le formulaire produit.
"""

from django.contrib.auth.models import Permission, User
from django.test import TestCase
from django.urls import reverse


def permission(chemin):
    app_label, codename = chemin.split(".")
    return Permission.objects.get(content_type__app_label=app_label, codename=codename)


class AccesAdministrationTests(TestCase):
    """
    Une seule URL par application suffit : toutes les vues passent par le même
    mixin, et chacune déclare sa permission — c'est le branchement du mixin qui
    est vérifié ici, pas la table des permissions vue par vue.
    """

    URLS = {
        "shop": ("jeiko_administration_shop:product_type_list", "shop.view_producttype"),
        "custom_objects": ("jeiko_administration_custom_objects:model_list",
                           "custom_objects.view_customobjectmodel"),
    }

    def setUp(self):
        # Marqué « équipe », mais sans aucune permission métier : c'est le profil
        # du rédacteur ou du formateur, qui obtenait l'écriture complète.
        self.equipe_sans_droit = User.objects.create_user(
            "redacteur", "redacteur@exemple.test", "mdp", is_staff=True
        )
        # L'inverse : les droits par rôle, sans le drapeau `is_staff`.
        self.droit_sans_equipe = User.objects.create_user(
            "gestionnaire", "gestionnaire@exemple.test", "mdp", is_staff=False
        )

    def test_compte_equipe_sans_permission_est_refuse(self):
        self.client.force_login(self.equipe_sans_droit)
        for app, (nom_url, _perm) in self.URLS.items():
            with self.subTest(app=app):
                self.assertEqual(self.client.get(reverse(nom_url)).status_code, 403)

    def test_permission_sans_drapeau_equipe_est_acceptee(self):
        for app, (nom_url, perm) in self.URLS.items():
            with self.subTest(app=app):
                self.droit_sans_equipe.user_permissions.set([permission(perm)])
                # Le cache de permissions est porté par l'instance de requête ;
                # on repart d'une session propre pour chaque cas.
                self.client.force_login(User.objects.get(pk=self.droit_sans_equipe.pk))
                self.assertEqual(self.client.get(reverse(nom_url)).status_code, 200)

    def test_visiteur_anonyme_est_redirige_vers_la_connexion(self):
        for app, (nom_url, _perm) in self.URLS.items():
            with self.subTest(app=app):
                reponse = self.client.get(reverse(nom_url))
                self.assertEqual(reponse.status_code, 302)
                self.assertNotEqual(reponse.status_code, 403)

    def test_le_superutilisateur_passe(self):
        admin = User.objects.create_superuser("root", "root@exemple.test", "mdp")
        self.client.force_login(admin)
        for app, (nom_url, _perm) in self.URLS.items():
            with self.subTest(app=app):
                self.assertEqual(self.client.get(reverse(nom_url)).status_code, 200)

    def test_une_permission_de_lecture_n_ouvre_pas_l_ecriture(self):
        """Les verbes sont distincts : voir n'est pas ajouter."""
        self.droit_sans_equipe.user_permissions.set([permission("shop.view_producttype")])
        self.client.force_login(User.objects.get(pk=self.droit_sans_equipe.pk))
        creation = reverse("jeiko_administration_shop:product_type_create")
        self.assertEqual(self.client.get(creation).status_code, 403)
