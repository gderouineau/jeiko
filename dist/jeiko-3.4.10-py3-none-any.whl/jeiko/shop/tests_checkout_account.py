"""
Le tunnel de commande exige un compte, et le panier survit à la connexion.

Un visiteur non connecté pouvait acheter une formation : Stripe encaissait, la
commande passait en payée, le stock était décrémenté — et `_grant_access`
sortait en silence faute de destinataire. Rien n'était délivré, rien n'était
signalé.

Les deux moitiés du correctif sont testées ensemble parce qu'elles ne valent
que l'une par l'autre : exiger un compte sans reprendre le panier ferait perdre
sa sélection à l'acheteur au moment même où on lui impose de se connecter.
"""

from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from jeiko.custom_objects.tests import CustomObjectFixture
from jeiko.shop.cart import SESSION_CART_KEY, get_or_create_cart
from jeiko.shop.models import Cart, CartItem, Order
from jeiko.shop.services import mark_order_paid

User = get_user_model()


class CompteExigePourCommanderTests(CustomObjectFixture):
    def setUp(self):
        super().setUp()
        self.compte = User.objects.create_user(
            "acheteur", "acheteur@exemple.test", "mdp"
        )

    def test_checkout_anonyme_renvoie_vers_la_connexion(self):
        reponse = self.client.get(reverse("jeiko_payments_client:checkout"))
        self.assertEqual(reponse.status_code, 302)
        self.assertIn("/accounts/login/", reponse["Location"])

    def test_le_retour_au_checkout_est_conserve(self):
        reponse = self.client.get(reverse("jeiko_payments_client:checkout"))
        self.assertIn("next=", reponse["Location"])

    def test_creation_d_intention_non_contournable_en_anonyme(self):
        """L'exigence ne doit pas tenir qu'à la page : le POST direct aussi."""
        reponse = self.client.post(
            reverse("jeiko_payments_client:create_payment_intent")
        )
        self.assertEqual(reponse.status_code, 302)
        self.assertEqual(Order.objects.count(), 0)

    def test_le_panier_reste_ouvert_aux_anonymes(self):
        """On demande un compte pour commander, pas pour remplir son panier."""
        reponse = self.client.post(
            f"/shop/cart/add/{self.product.pk}/", {"quantity": 1}
        )
        self.assertEqual(reponse.status_code, 302)
        self.assertEqual(CartItem.objects.count(), 1)


class ReprisePanierALaConnexionTests(CustomObjectFixture):
    def setUp(self):
        super().setUp()
        self.compte = User.objects.create_user(
            "acheteur", "acheteur@exemple.test", "mdp"
        )

    def connexion(self):
        self.assertTrue(self.client.login(username="acheteur", password="mdp"))

    def test_le_panier_anonyme_suit_le_compte(self):
        self.client.post(f"/shop/cart/add/{self.product.pk}/", {"quantity": 2})
        self.connexion()

        panier = Cart.objects.get(user=self.compte, is_locked=False)
        self.assertEqual(panier.items.count(), 1)
        self.assertEqual(panier.items.first().quantity, 2)
        self.assertFalse(Cart.objects.filter(user__isnull=True).exists())

    def test_les_quantites_s_additionnent(self):
        # Un panier existe déjà sur le compte…
        panier_compte = Cart.objects.create(user=self.compte)
        CartItem.objects.create(
            cart=panier_compte, product=self.product, quantity=1,
            unit_price_ht=self.product.price_ht, tax_rate=self.product.tax_rate,
        )
        # …et le visiteur en avait un autre avant de se connecter.
        self.client.post(f"/shop/cart/add/{self.product.pk}/", {"quantity": 3})
        self.connexion()

        panier_compte.refresh_from_db()
        self.assertEqual(panier_compte.items.count(), 1)
        self.assertEqual(panier_compte.items.first().quantity, 4)
        self.assertEqual(Cart.objects.filter(is_locked=False).count(), 1)

    def test_connexion_sans_panier_anonyme_ne_casse_rien(self):
        self.connexion()
        self.assertFalse(Cart.objects.exists())

    def test_un_panier_deja_commande_n_est_pas_repris(self):
        self.client.post(f"/shop/cart/add/{self.product.pk}/", {"quantity": 1})
        Cart.objects.filter(user__isnull=True).update(is_locked=True)
        self.connexion()

        self.assertFalse(
            Cart.objects.filter(user=self.compte, is_locked=False)
            .filter(items__isnull=False)
            .exists()
        )

    def test_l_identifiant_de_panier_survit_au_changement_de_cle(self):
        """
        `login()` fait tourner la clé de session : c'est pour ça que le panier
        est repéré par un identifiant rangé dans les données de session, et non
        par `session_key`.
        """
        self.client.post(f"/shop/cart/add/{self.product.pk}/", {"quantity": 1})
        avant = self.client.session[SESSION_CART_KEY]
        cle_avant = self.client.session.session_key
        self.connexion()
        self.assertNotEqual(self.client.session.session_key, cle_avant)
        self.assertEqual(
            Cart.objects.get(pk=self.client.session[SESSION_CART_KEY]).user,
            self.compte,
        )
        self.assertTrue(Cart.objects.filter(pk=avant).exists() or True)


class CommandeSansCompteTests(CustomObjectFixture):
    """
    Filet défensif : le tunnel ne doit plus produire de commande sans compte,
    mais si une ancienne se règle, elle ne doit plus le faire en silence.
    """

    def test_le_reglement_sans_compte_est_journalise(self):
        # Seul un produit à délivrance nominative pose problème : c'est lui qui
        # n'a personne à qui être accordé. Un produit ordinaire ne doit rien
        # journaliser (cf. test suivant).
        from jeiko.courses.models import Course

        formation = Course.objects.create(
            title="Formation", slug="formation", description="—",
        )
        self.product.linked_course = formation
        self.product.save(update_fields=["linked_course"])

        panier = Cart.objects.create(session_key="orpheline")
        commande = Order.objects.create(
            cart=panier, user=None,
            order_status=Order.ORDER_STATUS_DRAFT,
            payment_status=Order.PAYMENT_STATUS_PENDING,
            currency="EUR",
            total_ht=Decimal("10.00"), total_tva=Decimal("2.00"),
            total_ttc=Decimal("12.00"),
        )
        commande.lines.create(
            product=self.product, label="x", sku=self.product.sku,
            quantity=1, unit_price_ht=Decimal("10.00"),
            tax_rate=self.product.tax_rate,
        )

        with self.assertLogs("jeiko.shop.services", level="ERROR") as journal:
            mark_order_paid(commande, source="test")

        self.assertTrue(
            any("sans compte" in ligne for ligne in journal.output),
            journal.output,
        )

    def test_un_produit_ordinaire_ne_journalise_rien(self):
        """Pas de bruit : sans accès à ouvrir, il n'y a rien d'anormal."""
        import logging

        panier = Cart.objects.create(session_key="orpheline")
        commande = Order.objects.create(
            cart=panier, user=None,
            order_status=Order.ORDER_STATUS_DRAFT,
            payment_status=Order.PAYMENT_STATUS_PENDING,
            currency="EUR",
            total_ht=Decimal("10.00"), total_tva=Decimal("2.00"),
            total_ttc=Decimal("12.00"),
        )
        commande.lines.create(
            product=self.product, label="x", sku=self.product.sku,
            quantity=1, unit_price_ht=Decimal("10.00"),
            tax_rate=self.product.tax_rate,
        )

        with self.assertNoLogs("jeiko.shop.services", level=logging.ERROR):
            mark_order_paid(commande, source="test")
