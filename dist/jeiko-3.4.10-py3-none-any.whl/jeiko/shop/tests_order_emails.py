"""
Chaîne transactionnelle e-mail de la boutique.

Les huit codes existaient au catalogue depuis le début et aucun n'était appelé :
le client payait sans rien recevoir, l'exploitant n'était pas prévenu. Ces tests
vérifient l'envoi réel (backend locmem), pas seulement que la fonction est
appelée — le rendu traverse `emailing.render`, où un modèle absent ou une clé
inconnue ferait échouer l'envoi en silence.
"""

from decimal import Decimal

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.core import mail
from django.test import TestCase, override_settings
from django.urls import reverse

from jeiko.custom_objects.tests import CustomObjectFixture
from jeiko.shop.models import Cart, Order
from jeiko.shop.services import mark_order_paid

User = get_user_model()

LOCMEM = "django.core.mail.backends.locmem.EmailBackend"


class CommandeFixture(CustomObjectFixture):
    def setUp(self):
        super().setUp()
        # `emailing.sending` refuse tout envoi tant qu'aucune MailSettings
        # active n'est rattachée au site — c'est le premier contrôle, avant même
        # que le backend locmem entre en jeu. Sans ce décor, les tests
        # passeraient en ne prouvant rien.
        from jeiko.administration.models import MailSettings, WebSite

        site = WebSite.objects.first()
        self.assertIsNotNone(site, "La migration doit créer un WebSite.")
        site.mail_settings = MailSettings.objects.create(
            host="localhost", port=587, active=True,
            default_from_email="boutique@exemple.test",
            test_receiver="admin@exemple.test",
        )
        site.save(update_fields=["mail_settings"])

        self.acheteur = User.objects.create_user(
            "acheteur", "acheteur@exemple.test", "mdp", first_name="Camille"
        )
        self.panier = Cart.objects.create(user=self.acheteur)
        self.commande = Order.objects.create(
            cart=self.panier, user=self.acheteur,
            order_status=Order.ORDER_STATUS_DRAFT,
            payment_status=Order.PAYMENT_STATUS_PENDING,
            currency="EUR",
            total_ht=Decimal("100.00"), total_tva=Decimal("20.00"),
            total_ttc=Decimal("120.00"),
            billing_name="Camille Durand",
            billing_address="1 rue de la Paix, 75002 Paris",
        )
        self.commande.lines.create(
            product=self.product, label="Formation Django", sku=self.product.sku,
            quantity=2, unit_price_ht=Decimal("50.00"),
            tax_rate=self.product.tax_rate,
        )
        mail.outbox = []


@override_settings(EMAIL_BACKEND=LOCMEM)
class ReglementTests(CommandeFixture):
    def regler(self, source="test"):
        """`mark_order_paid` poste ses envois en on_commit : il faut les jouer."""
        with self.captureOnCommitCallbacks(execute=True):
            return mark_order_paid(self.commande, source=source)

    def test_le_reglement_envoie_les_e_mails(self):
        self.regler(source="test")
        self.assertGreater(
            len(mail.outbox), 0,
            "Aucun e-mail : le client paie et ne reçoit rien.",
        )

    def test_le_client_est_destinataire(self):
        self.regler(source="test")
        destinataires = {adresse for m in mail.outbox for adresse in m.to}
        self.assertIn("acheteur@exemple.test", destinataires)

    def test_le_corps_porte_le_numero_et_le_total(self):
        self.regler(source="test")
        corps = "\n".join(
            m.body + "".join(c for c, _ in getattr(m, "alternatives", []))
            for m in mail.outbox
        )
        self.assertIn(f"#{self.commande.pk}", corps)
        self.assertIn("120.00", corps)

    def test_le_tableau_des_articles_est_present(self):
        self.regler(source="test")
        corps = "\n".join(
            "".join(c for c, _ in getattr(m, "alternatives", [])) for m in mail.outbox
        )
        self.assertIn("Formation Django", corps)

    def test_pas_de_doublon_si_le_reglement_est_rejoue(self):
        """Webhook et retour navigateur arrivent tous les deux."""
        self.regler(source="webhook")
        premier = len(mail.outbox)
        self.regler(source="retour")
        self.assertEqual(len(mail.outbox), premier)

    def test_un_echec_d_envoi_ne_casse_pas_le_reglement(self):
        from unittest import mock

        with mock.patch("jeiko.shop.emailing.send_email",
                        side_effect=RuntimeError("SMTP mort")):
            with self.captureOnCommitCallbacks(execute=True):
                self.assertTrue(mark_order_paid(self.commande, source="test"))
        self.commande.refresh_from_db()
        self.assertEqual(self.commande.payment_status, Order.PAYMENT_STATUS_PAID)


@override_settings(EMAIL_BACKEND=LOCMEM)
class ChangementDeStatutTests(CommandeFixture):
    def setUp(self):
        super().setUp()
        self.gestionnaire = User.objects.create_user(
            "gestion", "gestion@exemple.test", "mdp"
        )
        self.gestionnaire.user_permissions.set(
            Permission.objects.filter(
                content_type__app_label="shop", codename__in=["view_order", "change_order"]
            )
        )
        self.client.force_login(self.gestionnaire)
        self.url = reverse("jeiko_shop_admin_orders:order_update",
                           args=[self.commande.pk])

    def champs(self, **surcharge):
        donnees = {
            "order_status": self.commande.order_status,
            "payment_status": self.commande.payment_status,
            "billing_name": self.commande.billing_name,
            "billing_address": self.commande.billing_address,
            "shipping_name": "",
            "shipping_address": "",
        }
        donnees.update(surcharge)
        return donnees

    def test_expedition_previent_le_client(self):
        mail.outbox = []
        with self.captureOnCommitCallbacks(execute=True):
            self.client.post(self.url, self.champs(order_status=Order.ORDER_STATUS_SHIPPED))
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("acheteur@exemple.test", mail.outbox[0].to)

    def test_annulation_previent_le_client(self):
        mail.outbox = []
        with self.captureOnCommitCallbacks(execute=True):
            self.client.post(self.url, self.champs(order_status=Order.ORDER_STATUS_CANCELLED))
        self.assertEqual(len(mail.outbox), 1)

    def test_remboursement_previent_le_client(self):
        mail.outbox = []
        with self.captureOnCommitCallbacks(execute=True):
            self.client.post(
                self.url, self.champs(payment_status=Order.PAYMENT_STATUS_REFUNDED)
            )
        self.assertEqual(len(mail.outbox), 1)

    def test_corriger_une_adresse_n_envoie_rien(self):
        """Le déclencheur est la transition, pas l'enregistrement."""
        mail.outbox = []
        with self.captureOnCommitCallbacks(execute=True):
            self.client.post(self.url, self.champs(billing_name="Camille Durand-Martin"))
        self.assertEqual(len(mail.outbox), 0)

    def test_un_client_ordinaire_ne_peut_pas_modifier_une_commande(self):
        self.client.force_login(self.acheteur)
        reponse = self.client.get(self.url)
        self.assertEqual(reponse.status_code, 403)

    def test_un_client_ordinaire_ne_peut_pas_lister_les_commandes(self):
        self.client.force_login(self.acheteur)
        reponse = self.client.get(reverse("jeiko_shop_admin_orders:order_list"))
        self.assertEqual(reponse.status_code, 403)


@override_settings(EMAIL_BACKEND=LOCMEM)
class EchecDePaiementTests(CommandeFixture):
    def test_l_echec_previent_le_client_avec_le_motif(self):
        from jeiko.shop.emailing import send_payment_failed_email

        mail.outbox = []
        send_payment_failed_email(self.commande, motif="Carte expirée")
        self.assertEqual(len(mail.outbox), 1)
        corps = mail.outbox[0].body + "".join(
            c for c, _ in getattr(mail.outbox[0], "alternatives", [])
        )
        self.assertIn("Carte expirée", corps)
