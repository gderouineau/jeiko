# jeiko/shop/tests_reglages.py
"""
Les réglages de la boutique — ce qui vaut pour le site, pas pour un produit.

Ce qui manquait
---------------
La TVA se réglait produit par produit, avec un défaut par type. Cela suffit
tant qu'on a trois produits ; passé la dizaine, changer un taux — parce que la
loi bouge, ou parce qu'on s'était trompé — demande de reprendre chaque fiche,
et le premier oubli passe inaperçu jusqu'à la facture.

Il manquait l'étage au-dessus. Il porte aujourd'hui la TVA, la devise et un
seuil de livraison offerte ; la page est faite pour se remplir.

La garantie qui compte
----------------------
**Changer le défaut ne réécrit RIEN.** C'est la question que se pose quiconque
touche à un taux de TVA — « est-ce que ça va modifier mes commandes ? » — et
la réponse doit être non, vérifiée plutôt que promise. Une commande dont le
montant changerait après coup serait un problème comptable, pas un réglage.
"""

from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from jeiko.administration_pages.models import Page
from jeiko.custom_objects.models import CustomObject, CustomObjectModel
from jeiko.shop.models import Product, ProductType, ShopSettings


class SingletonTests(TestCase):
    def test_les_reglages_se_creent_au_premier_acces(self):
        self.assertEqual(ShopSettings.objects.count(), 0)
        reglages = ShopSettings.get_solo()
        self.assertEqual(ShopSettings.objects.count(), 1)
        self.assertEqual(reglages.default_tax_rate, Decimal("20.00"))

    def test_deux_acces_ne_creent_pas_deux_lignes(self):
        """
        Deux requêtes concurrentes sur une page fraîchement ouverte créeraient
        sinon deux lignes, et la seconde deviendrait invisible.
        """
        ShopSettings.get_solo()
        ShopSettings.get_solo()
        self.assertEqual(ShopSettings.objects.count(), 1)


class PageDeReglagesTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.admin = User.objects.create_superuser(
            "chef", "chef@exemple.fr", "Un-Mot-De-Passe-42"
        )
        self.client.force_login(self.admin)
        self.url = reverse("jeiko_administration_shop:settings")

    def test_la_page_s_affiche(self):
        reponse = self.client.get(self.url)
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "Réglages de la boutique")
        self.assertContains(reponse, "TVA")

    def test_l_enregistrement_fonctionne(self):
        reponse = self.client.post(self.url, {
            "default_tax_rate": "5.50", "currency": "eur",
            "free_shipping_from": "",
        })
        self.assertEqual(reponse.status_code, 302)
        reglages = ShopSettings.get_solo()
        self.assertEqual(reglages.default_tax_rate, Decimal("5.50"))
        self.assertEqual(reglages.currency, "EUR", "La devise est normalisée.")

    def test_un_taux_hors_bornes_est_refuse(self):
        """
        `DecimalField` ne borne rien : la base accepterait 250 %, et le prix
        TTC deviendrait absurde sans qu'aucune page ait l'air fautive.
        """
        reponse = self.client.post(self.url, {
            "default_tax_rate": "250", "currency": "EUR", "free_shipping_from": "",
        })
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "entre 0 et 100")

    def test_une_devise_invalide_est_refusee(self):
        reponse = self.client.post(self.url, {
            "default_tax_rate": "20", "currency": "euros", "free_shipping_from": "",
        })
        self.assertContains(reponse, "trois lettres")

    def test_l_acces_demande_le_droit_de_modifier_les_types(self):
        User = get_user_model()
        simple = User.objects.create_user("simple", "s@exemple.fr", "Mot-De-Passe-42")
        self.client.force_login(simple)
        self.assertIn(self.client.get(self.url).status_code, (302, 403))


class LesReglagesNeReecriventRienTests(TestCase):
    """La garantie centrale, vérifiée plutôt que promise."""

    def setUp(self):
        gabarit = Page.objects.create(
            title="Gabarit", url_tag="gab-reglages", is_custom_object_template=True
        )
        modele = CustomObjectModel.objects.create(
            name="Offre", slug="offre-reglages", page_template=gabarit, is_product=True
        )
        self.type = ProductType.objects.create(
            name="Objet", code="objet-reglages", default_tax_rate=Decimal("20.00"),
            content_model=modele,
        )
        fiche = CustomObject.objects.create(
            model=modele, title="Pot de cornichons", slug="cornichons-reglages",
            is_published=True,
        )
        self.produit = Product.objects.create(
            type=self.type, content=fiche, sku="CORNICHONS-1",
            price_ht=Decimal("10.00"), tax_rate=Decimal("20.00"), is_active=True,
        )

    def test_changer_le_defaut_ne_touche_ni_les_types_ni_les_produits(self):
        reglages = ShopSettings.get_solo()
        reglages.default_tax_rate = Decimal("5.50")
        reglages.save()

        self.type.refresh_from_db()
        self.produit.refresh_from_db()
        self.assertEqual(
            self.type.default_tax_rate, Decimal("20.00"),
            "Un type existant garde son taux : le réglage est un DÉFAUT.",
        )
        self.assertEqual(
            self.produit.tax_rate, Decimal("20.00"),
            "Un produit déjà vendu à 20 % ne doit pas changer de prix "
            "rétroactivement.",
        )
