import logging

from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db import transaction
from django.db.models import Q
from django.urls import reverse_lazy
from django.views.generic import ListView, UpdateView

from ..models import Order

logger = logging.getLogger(__name__)


class OrderListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    # Ces deux vues n'avaient qu'un contrôle de connexion : tout compte
    # authentifié — un simple client — pouvait lister les commandes du site et
    # modifier leurs statuts et adresses par l'URL. Le menu, lui, les gardait
    # déjà par `shop.view_order`.
    permission_required = "shop.view_order"

    model = Order
    template_name = 'shop/admin/order_list.html'
    context_object_name = 'orders'
    paginate_by = 20

    def get_queryset(self):
        queryset = super().get_queryset()
        order_status = self.request.GET.get('order_status')
        payment_status = self.request.GET.get('payment_status')
        search = self.request.GET.get('search')

        if order_status:
            queryset = queryset.filter(order_status=order_status)

        if payment_status:
            queryset = queryset.filter(payment_status=payment_status)

        if search:
            queryset = queryset.filter(
                Q(pk__icontains=search) |
                Q(user__email__icontains=search) |
                Q(billing_name__icontains=search)
            )

        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['order_status_choices'] = Order.ORDER_STATUS_CHOICES
        context['payment_status_choices'] = Order.PAYMENT_STATUS_CHOICES
        return context


class OrderUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    permission_required = "shop.change_order"

    model = Order
    fields = ['order_status', 'payment_status', 'billing_name', 'billing_address', 'shipping_name', 'shipping_address']
    template_name = 'shop/admin/order_form.html'
    success_url = reverse_lazy('jeiko_shop_admin_orders:order_list')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['lines'] = self.object.lines.all()
        return context

    def form_valid(self, form):
        """
        Prévient le client quand le statut change réellement.

        On compare aux valeurs d'avant enregistrement : sans cela, corriger une
        adresse de facturation renverrait un avis d'expédition. L'envoi part
        après COMMIT, pour ne rien annoncer qu'un échec effacerait.
        """
        precedent = Order.objects.get(pk=self.object.pk)
        avant = (precedent.order_status, precedent.payment_status)

        reponse = super().form_valid(form)

        apres = (self.object.order_status, self.object.payment_status)
        if avant != apres:
            transaction.on_commit(
                lambda pk=self.object.pk, a=avant: _notifier_changement(pk, a)
            )
        return reponse


def _notifier_changement(order_id, avant):
    """
    Traduit une transition de statut en e-mail. Ne lève jamais.

    Un seul message par enregistrement, même si les deux statuts bougent :
    le remboursement prime sur le reste, c'est l'information qui compte pour le
    client.
    """
    from ..emailing import (
        send_order_cancelled_email,
        send_order_completed_email,
        send_order_refunded_email,
        send_order_shipped_email,
    )

    try:
        order = (
            Order.objects.select_related("user").prefetch_related("lines").get(pk=order_id)
        )
    except Order.DoesNotExist:
        return

    statut_avant, paiement_avant = avant

    try:
        if (order.payment_status == Order.PAYMENT_STATUS_REFUNDED
                and paiement_avant != Order.PAYMENT_STATUS_REFUNDED):
            send_order_refunded_email(order)
            return

        if order.order_status == statut_avant:
            return

        if order.order_status == Order.ORDER_STATUS_SHIPPED:
            send_order_shipped_email(order)
        elif order.order_status == Order.ORDER_STATUS_COMPLETED:
            send_order_completed_email(order)
        elif order.order_status == Order.ORDER_STATUS_CANCELLED:
            send_order_cancelled_email(order)
    except Exception:
        logger.exception(
            "E-mail de changement de statut impossible (commande #%s)", order_id
        )
