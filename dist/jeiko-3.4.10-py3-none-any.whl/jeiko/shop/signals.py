"""
Signaux de la boutique.

Un seul pour l'instant : la reprise du panier anonyme à la connexion. Elle est
branchée sur `user_logged_in` plutôt que dans la vue de connexion, parce que
les entrées sont multiples — formulaire allauth, connexion sociale, connexion
programmée après inscription — et qu'un panier perdu selon le chemin emprunté
serait impossible à diagnostiquer.
"""

from django.contrib.auth.signals import user_logged_in
from django.dispatch import receiver

from .cart import merge_session_cart_safe


@receiver(user_logged_in, dispatch_uid="jeiko_shop_merge_session_cart")
def reprendre_le_panier_anonyme(sender, request, user, **kwargs):
    if request is None:
        return
    merge_session_cart_safe(request, user)
