"""
Finitions du panier et verrou de commande.

Trois défauts voisins, tous dans la mise à jour d'une ligne : `int()` sans
garde (500 sur une saisie non numérique), aucun plafond de quantité, et un
contrôle de stock présent à l'ajout mais absent à la mise à jour.
"""

from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from jeiko.custom_objects.tests import CustomObjectFixture
from jeiko.shop.models import CartItem, Product
from jeiko.shop.views.client import MAX_CART_QUANTITY

User = get_user_model()


class MiseAJourPanierTests(CustomObjectFixture):
    def setUp(self):
        super().setUp()
        self.client.post(f"/shop/cart/add/{self.product.pk}/", {"quantity": 1})
        self.ligne = CartItem.objects.get()
        self.url = reverse("jeiko_client_shop:cart_update", args=[self.ligne.pk])

    def maj(self, quantite):
        return self.client.post(self.url, {"action": "update", "quantity": quantite})

    def test_une_quantite_non_numerique_ne_provoque_pas_de_500(self):
        reponse = self.maj("beaucoup")
        self.assertEqual(reponse.status_code, 302)
        self.ligne.refresh_from_db()
        self.assertEqual(self.ligne.quantity, 1)

    def test_une_quantite_vide_ne_provoque_pas_de_500(self):
        self.assertEqual(self.maj("").status_code, 302)

    def test_une_quantite_normale_est_appliquee(self):
        Product.objects.filter(pk=self.product.pk).update(
            allow_negative_stock=True
        )
        self.maj(3)
        self.ligne.refresh_from_db()
        self.assertEqual(self.ligne.quantity, 3)

    def test_zero_supprime_la_ligne(self):
        self.maj(0)
        self.assertFalse(CartItem.objects.filter(pk=self.ligne.pk).exists())

    def test_une_quantite_negative_supprime_la_ligne(self):
        self.maj(-5)
        self.assertFalse(CartItem.objects.filter(pk=self.ligne.pk).exists())

    def test_la_quantite_est_plafonnee(self):
        Product.objects.filter(pk=self.product.pk).update(
            allow_negative_stock=True
        )
        self.maj(10**9)
        self.ligne.refresh_from_db()
        self.assertLessEqual(self.ligne.quantity, MAX_CART_QUANTITY)

    def _rendre_expediable(self):
        """
        Le produit du socle est une FORMATION (`requires_shipping=False`).

        Ces deux tests portent sur le plafonnement par le stock : il faut donc
        un produit qui en ait un. Les écrire sur une formation revenait à
        vérifier que le panier refuse de vendre ce qui ne s'épuise pas — et
        c'est exactement le défaut qu'on vient de corriger : aucun service
        n'était vendable.
        """
        self.product.type.requires_shipping = True
        self.product.type.save(update_fields=["requires_shipping"])
        self.product.refresh_from_db()

    def test_le_stock_est_verifie_a_la_mise_a_jour(self):
        """Le contrôle existait à l'ajout, pas ici."""
        self._rendre_expediable()
        Product.objects.filter(pk=self.product.pk).update(
            allow_negative_stock=False, stock_quantity=2
        )
        self.maj(50)
        self.ligne.refresh_from_db()
        self.assertEqual(self.ligne.quantity, 2)

    def test_stock_epuise_retire_la_ligne(self):
        self._rendre_expediable()
        Product.objects.filter(pk=self.product.pk).update(
            allow_negative_stock=False, stock_quantity=0
        )
        self.maj(3)
        self.assertFalse(CartItem.objects.filter(pk=self.ligne.pk).exists())

    def test_un_produit_sans_expedition_n_est_pas_plafonne(self):
        """
        Le socle est une formation à stock zéro. Avant correctif, la mise à
        jour ramenait la quantité à zéro et supprimait la ligne : la formation
        était invendable, et rien ne le disait.
        """
        Product.objects.filter(pk=self.product.pk).update(
            allow_negative_stock=False, stock_quantity=0
        )
        self.maj(3)
        self.ligne.refresh_from_db()
        self.assertEqual(self.ligne.quantity, 3)
