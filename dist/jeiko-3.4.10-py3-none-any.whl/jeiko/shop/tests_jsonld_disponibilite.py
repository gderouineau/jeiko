# jeiko/shop/tests_jsonld_disponibilite.py
"""
Un produit sans stock n'est pas forcément épuisé.

Le défaut
---------
Le JSON-LD annonçait `availability: OutOfStock` dès que `stock_quantity` valait
zéro. C'est juste pour un pot de cornichons. Ça ne l'est pas pour une séance de
coaching, un abonnement ou une formation en ligne : ces produits n'ont pas de
stock, personne n'en saisit, et ils étaient donc **tous** déclarés épuisés à
Google.

Conséquence : retirés des résultats enrichis et du Shopping. Aucune page n'a
l'air fautive, rien n'apparaît dans les journaux, et le seul symptôme est une
absence — celle des produits dans les résultats de recherche.

`ProductType.is_physical` distingue exactement les deux cas. Un produit non
physique est disponible tant qu'il est en vente ; le stock ne tranche que pour
ce qui s'épuise vraiment.
"""

from decimal import Decimal

from django.test import RequestFactory, TestCase

from jeiko.administration_pages.models import Page
from jeiko.custom_objects.models import CustomObject, CustomObjectModel
from jeiko.shop.models import Product, ProductType
from jeiko.shop.templatetags.shop_jsonld import product_jsonld

import json


class DisponibiliteJsonLdTests(TestCase):
    def setUp(self):
        gabarit = Page.objects.create(
            title="Gabarit", url_tag="gab-jsonld", is_custom_object_template=True
        )
        self.modele = CustomObjectModel.objects.create(
            name="Offre", slug="offre-jsonld", page_template=gabarit, is_product=True
        )
        self.requete = RequestFactory().get("/")

    def _produit(self, *, physique, stock=0, sku="REF-1"):
        type_produit = ProductType.objects.create(
            name="Physique" if physique else "Service",
            code=f"type-{sku.lower()}",
            kind=ProductType.KIND_PHYSICAL if physique else ProductType.KIND_SERVICE,
            is_physical=physique,
            requires_shipping=physique,
            content_model=self.modele,
        )
        fiche = CustomObject.objects.create(
            model=self.modele, title="Séance de coaching 1 h",
            slug=f"fiche-{sku.lower()}", is_published=True,
        )
        return Product.objects.create(
            type=type_produit, content=fiche, sku=sku,
            price_ht=Decimal("39.00"), stock_quantity=stock, is_active=True,
        )

    def _disponibilite(self, produit):
        rendu = product_jsonld({"request": self.requete}, produit)
        return json.loads(rendu)["offers"]["availability"]

    def test_un_service_sans_stock_reste_disponible(self):
        produit = self._produit(physique=False, stock=0, sku="SERVICE-1")
        self.assertEqual(
            self._disponibilite(produit), "https://schema.org/InStock",
            "Un abonnement annoncé épuisé disparaît des résultats enrichis, "
            "sans qu'aucune page ait l'air fautive.",
        )

    def test_un_produit_physique_sans_stock_est_epuise(self):
        produit = self._produit(physique=True, stock=0, sku="PHYSIQUE-1")
        self.assertEqual(
            self._disponibilite(produit), "https://schema.org/OutOfStock"
        )

    def test_un_produit_physique_en_stock_est_disponible(self):
        produit = self._produit(physique=True, stock=5, sku="PHYSIQUE-2")
        self.assertEqual(
            self._disponibilite(produit), "https://schema.org/InStock"
        )

    def test_le_nom_annonce_est_celui_de_la_fiche(self):
        """
        `Product` n'a pas de nom : « séance de coaching 1 h » vit dans le titre
        de la fiche, et c'est lui que Google doit lire.
        """
        produit = self._produit(physique=False, sku="NOM-1")
        rendu = json.loads(product_jsonld({"request": self.requete}, produit))
        self.assertEqual(rendu["name"], "Séance de coaching 1 h")


class VenteDUnServiceTests(TestCase):
    """
    Un service à stock zéro doit pouvoir être ACHETÉ, pas seulement affiché.

    Le défaut allait plus loin que le JSON-LD. `stock_quantity` valant zéro sur
    tout produit non physique, trois chemins le traitaient comme épuisé :

    * `AddToCartView` **refusait l'ajout au panier** ;
    * la mise à jour du panier ramenait la quantité à zéro et **supprimait la
      ligne** ;
    * le JSON-LD annonçait `OutOfStock`.

    Autrement dit, aucun abonnement ni aucune séance n'était vendable tant que
    personne n'avait pensé à cocher « stock négatif autorisé » — un réglage
    dont le nom ne suggère rien de tel, et qu'on ne trouve qu'en cherchant
    pourquoi le panier refuse.

    La règle vit désormais dans `Product.suit_le_stock`, en un seul endroit :
    quatre copies auraient divergé au premier correctif.
    """

    def setUp(self):
        gabarit = Page.objects.create(
            title="Gabarit", url_tag="gab-vente", is_custom_object_template=True
        )
        self.modele = CustomObjectModel.objects.create(
            name="Offre", slug="offre-vente", page_template=gabarit, is_product=True
        )

    def _produit(self, *, physique, stock, sku):
        type_produit = ProductType.objects.create(
            name="T" + sku, code=f"t-{sku.lower()}",
            kind=ProductType.KIND_PHYSICAL if physique else ProductType.KIND_SERVICE,
            is_physical=physique, requires_shipping=physique,
            content_model=self.modele,
        )
        fiche = CustomObject.objects.create(
            model=self.modele, title="Abonnement", slug=f"f-{sku.lower()}",
            is_published=True,
        )
        return Product.objects.create(
            type=type_produit, content=fiche, sku=sku,
            price_ht=Decimal("39.00"), stock_quantity=stock, is_active=True,
        )

    def test_un_service_a_stock_zero_est_servable(self):
        produit = self._produit(physique=False, stock=0, sku="SRV-A")
        self.assertTrue(produit.est_disponible)
        self.assertTrue(
            produit.peut_servir(3),
            "Un abonnement ne s'épuise pas : refuser l'ajout au panier le "
            "rendait tout simplement invendable.",
        )

    def test_un_produit_physique_a_stock_zero_ne_l_est_pas(self):
        produit = self._produit(physique=True, stock=0, sku="PHY-A")
        self.assertFalse(produit.est_disponible)
        self.assertFalse(produit.peut_servir(1))

    def test_un_produit_physique_respecte_sa_quantite(self):
        produit = self._produit(physique=True, stock=2, sku="PHY-B")
        self.assertTrue(produit.peut_servir(2))
        self.assertFalse(produit.peut_servir(3))

    def test_le_depassement_autorise_reste_prioritaire(self):
        produit = self._produit(physique=True, stock=0, sku="PHY-C")
        produit.allow_negative_stock = True
        produit.save(update_fields=["allow_negative_stock"])
        self.assertTrue(produit.peut_servir(10))

    def test_le_json_ld_et_le_panier_disent_la_meme_chose(self):
        """
        Le JSON-LD lit `est_disponible`, comme le panier. Deux règles
        parallèles auraient divergé au premier correctif — et Google aurait
        annoncé disponible ce que le panier refuse, ou l'inverse.
        """
        requete = RequestFactory().get("/")
        for physique, stock, sku in ((False, 0, "COH-A"), (True, 0, "COH-B"),
                                     (True, 5, "COH-C")):
            with self.subTest(sku=sku):
                produit = self._produit(physique=physique, stock=stock, sku=sku)
                rendu = json.loads(product_jsonld({"request": requete}, produit))
                annonce = rendu["offers"]["availability"].endswith("InStock")
                self.assertEqual(annonce, produit.est_disponible)
