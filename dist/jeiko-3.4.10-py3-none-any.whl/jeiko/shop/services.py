"""
Règlement d'une commande : ce qui se passe une fois le paiement encaissé.

Cette logique existait en double — dans `PaymentCheckView` (retour navigateur)
et dans le dispatcher webhook — et les deux versions divergeaient : seul le
retour navigateur accordait les accès. Comme le webhook était par ailleurs
injoignable (route masquée par la fiche produit), une commande dont le client
fermait l'onglet n'était jamais honorée.

Les deux chemins appellent désormais `mark_order_paid`, qui est idempotent :
peu importe lequel arrive en premier, ou que les deux arrivent.
"""

import logging
from decimal import ROUND_HALF_UP, Decimal

from django.db import transaction

from .models import Order, ProductStockMovement

logger = logging.getLogger(__name__)

CENTS = Decimal("0.01")


def to_money(value):
    """Arrondit un montant au centime (ROUND_HALF_UP, comme une facture)."""
    return Decimal(value or 0).quantize(CENTS, rounding=ROUND_HALF_UP)


def to_minor_units(amount):
    """
    Convertit un montant en plus petite unité monétaire, pour Stripe.

    `int(amount * 100)` tronquait : un prix TTC calculé par multiplication
    (prix HT × taux) tombe régulièrement sur 19.9999… et partait à 1999 au
    lieu de 2000. On arrondit d'abord au centime.
    """
    return int(to_money(amount) * 100)


def compute_order_totals(items):
    """
    Totaux HT / TVA / TTC pour un itérable de lignes (panier ou commande).

    `total_tva` n'était jamais renseigné sur Order : la commande partait avec
    une TVA à 0, ce qui fausse toute reprise comptable.
    """
    total_ht = to_money(sum((item.total_ht for item in items), Decimal("0")))
    total_ttc = to_money(sum((item.total_ttc for item in items), Decimal("0")))
    return total_ht, to_money(total_ttc - total_ht), total_ttc


@transaction.atomic
def mark_order_paid(order, *, source="unknown"):
    """
    Passe la commande en payée et honore son contenu. Idempotent.

    Retourne True si c'est cet appel qui a réglé la commande, False si elle
    l'était déjà (webhook et retour navigateur arrivent tous les deux).
    """
    # verrou de ligne : le webhook et le retour navigateur peuvent tomber en
    # même temps, et tous deux accordent des accès.
    order = Order.objects.select_for_update().get(pk=order.pk)

    if order.payment_status == Order.PAYMENT_STATUS_PAID:
        return False

    order.payment_status = Order.PAYMENT_STATUS_PAID
    order.order_status = Order.ORDER_STATUS_CONFIRMED
    order.save(update_fields=["payment_status", "order_status", "updated_at"])

    lines = list(order.lines.select_related("product", "product__type").all())

    _grant_access(order, lines)
    _consume_stock(order, lines)

    if order.cart and not order.cart.is_locked:
        order.cart.is_locked = True
        order.cart.save(update_fields=["is_locked", "updated_at"])

    # Confirmation + reçu au client, notification à l'exploitant. Après COMMIT :
    # une transaction annulée ne doit pas laisser derrière elle l'annonce d'une
    # commande qui n'existe pas. `mark_order_paid` étant idempotent, l'envoi
    # n'a lieu qu'une fois, quel que soit celui du webhook ou du retour
    # navigateur qui arrive en premier.
    transaction.on_commit(lambda pk=order.pk: _notify_order_paid(pk))

    logger.info("Commande #%s réglée (source=%s).", order.pk, source)
    return True


def _notify_order_paid(order_id):
    """Envoi des e-mails de règlement. Ne lève jamais."""
    try:
        from .emailing import send_order_paid_emails

        send_order_paid_emails(
            Order.objects.select_related("user").prefetch_related("lines").get(
                pk=order_id
            )
        )
    except Exception:
        logger.exception(
            "E-mails de règlement impossibles pour la commande #%s", order_id
        )


def _grant_access(order, lines):
    """Ouvre les accès achetés : questionnaires et formations."""
    if not order.user_id:
        # Ne devrait plus arriver : le tunnel de commande exige un compte
        # (`CheckoutView` / `CreatePaymentIntentView`). Ce cas correspondait à
        # un achat invité, où Stripe encaissait, la commande passait en payée,
        # le stock était décrémenté — et rien n'était délivré, sans la moindre
        # trace. On journalise donc en erreur plutôt que de sortir en silence :
        # une commande réglée sans destinataire doit se voir.
        rattachables = [
            l.sku for l in lines
            if l.product and (l.product.linked_course_id
                              or l.product.linked_expert_test_id)
        ]
        if rattachables:
            logger.error(
                "Commande #%s réglée sans compte : les accès %s n'ont pas pu "
                "être accordés. À rattacher à la main.",
                order.pk, ", ".join(rattachables),
            )
        return

    from jeiko.courses.models import CourseEnrollment
    from jeiko.questionnaires_expert.models import UserTestAccess

    for line in lines:
        product = line.product
        if product is None:
            continue

        if product.linked_expert_test_id:
            UserTestAccess.objects.get_or_create(
                user=order.user,
                test_id=product.linked_expert_test_id,
                defaults={"source": "PURCHASE"},
            )

        if product.linked_course_id:
            CourseEnrollment.objects.get_or_create(
                user=order.user,
                course_id=product.linked_course_id,
                defaults={
                    "status": CourseEnrollment.STATUS_ACTIVE,
                    "has_payed": True,
                    "order": order,
                    "granted_by": None,  # accordé par l'achat, pas par un admin
                },
            )


def _consume_stock(order, lines):
    """
    Décrémente le stock des produits qui en tiennent un.

    Le stock n'était jamais décrémenté et ProductStockMovement n'était écrit
    nulle part : le compteur affiché sur la fiche ne bougeait pas après un
    achat.
    """
    for line in lines:
        product = line.product
        if product is None:
            continue

        # Seuls les produits à expédier consomment du stock ; une formation ou
        # un questionnaire est reproductible à l'infini.
        #
        # `suit_le_stock` porte cette règle pour tout le monde — panier,
        # JSON-LD, alertes. On l'appelle plutôt que de relire `requires_shipping`
        # ici : c'est la divergence entre ce test et celui du panier qui avait
        # rendu tout service invendable.
        if not product.suit_le_stock:
            continue

        product.stock_quantity -= line.quantity
        product.save(update_fields=["stock_quantity", "updated_at"])

        ProductStockMovement.objects.create(
            product=product,
            movement_type=ProductStockMovement.OUT,
            quantity=line.quantity,
            reason=f"Commande #{order.pk}",
            user=order.user,
        )
