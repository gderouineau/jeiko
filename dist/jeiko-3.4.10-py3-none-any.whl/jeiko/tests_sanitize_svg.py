# jeiko/tests_sanitize_svg.py
"""
`clean_svg` — ce qui doit disparaître d'un SVG déposé (S-06).

Pourquoi c'est sérieux
----------------------
Un SVG est un document XML, pas une image inerte. Servi depuis `/media/`, il
s'exécute dans l'origine du site, avec la session du visiteur qui l'ouvre. Le
fichier est déposé par un administrateur — l'icône d'un lien social — mais un
compte d'administration compromis ou un fichier récupéré ailleurs suffit.

Les deux trous que ces tests ferment
------------------------------------
**La forme auto-fermante.** L'expression retirait `<set …>…</set>` mais pas
`<set …/>` : la liste d'éléments de la branche appariée comptait `handler`,
`set` et `animate`, celle de la branche auto-fermante ne les avait pas. Or
c'est la forme naturelle de ces éléments, qui n'ont pas de contenu.

Et ces éléments-là sont retors : ils n'exécutent rien eux-mêmes, ils écrivent
un attribut pendant l'animation. `<set attributeName="onload" to="alert(1)"/>`
repose un gestionnaire d'événement **après** le passage du nettoyage.

**Les références de caractères.** `href="&#106;avascript:alert(1)"` ne
contenait pas le mot `javascript`, donc rien ne le retirait — mais le
navigateur décode la valeur avant de lire le schéma, et y voit `javascript:`.

Ce que `clean_svg` ne prétend pas faire
---------------------------------------
Ce n'est pas un analyseur XML : c'est un retrait ciblé, adapté à un fichier
d'icône qui n'a besoin d'aucune de ces constructions. Un SVG applicatif
complet mériterait un vrai analyseur.
"""

from django.test import SimpleTestCase

from jeiko.sanitize import clean_svg

#: Ce qui ne doit jamais survivre au nettoyage, quelle que soit l'écriture.
TEMOINS = ("alert", "javascript", "onload", "<script", "<set", "<animate")


class ElementsExecutablesTests(SimpleTestCase):
    def _nettoyer(self, fragment):
        return clean_svg(
            f'<svg xmlns="http://www.w3.org/2000/svg">{fragment}</svg>'
        )

    def test_script_apparie(self):
        propre = self._nettoyer("<script>alert(1)</script>")
        self.assertNotIn("alert", propre)

    def test_script_auto_ferme(self):
        propre = self._nettoyer('<script src="//ailleurs.example/x.js"/>')
        self.assertNotIn("script", propre.lower())

    def test_set_auto_ferme_repose_un_gestionnaire(self):
        """
        Le cœur de S-06 : `<set/>` passait, et remettait un `onload` en place
        une fois le nettoyage terminé.
        """
        propre = self._nettoyer(
            '<set attributeName="onload" to="alert(document.domain)"/>'
        )
        self.assertNotIn("alert", propre)
        self.assertNotIn("onload", propre)

    def test_animate_auto_ferme_repose_un_lien(self):
        propre = self._nettoyer(
            '<animate attributeName="href" values="javascript:alert(1)"/>'
        )
        self.assertNotIn("javascript", propre)

    def test_les_variantes_danimation_sont_couvertes(self):
        for element in ("animateTransform", "animateMotion", "handler"):
            with self.subTest(element=element):
                propre = self._nettoyer(
                    f'<{element} attributeName="onload" to="alert(1)"/>'
                )
                self.assertNotIn("alert", propre)

    def test_la_casse_ne_protege_pas(self):
        propre = self._nettoyer('<SeT attributeName="onload" to="alert(1)"/>')
        self.assertNotIn("alert", propre)

    def test_foreign_object_et_iframe(self):
        for fragment in (
            "<foreignObject><iframe src=\"//ailleurs.example\"></iframe></foreignObject>",
            '<iframe src="//ailleurs.example"/>',
            '<embed src="//ailleurs.example"/>',
        ):
            with self.subTest(fragment=fragment):
                propre = self._nettoyer(fragment)
                self.assertNotIn("ailleurs.example", propre)


class LiensExecutablesTests(SimpleTestCase):
    def _lien(self, valeur):
        return clean_svg(
            f'<svg xmlns="http://www.w3.org/2000/svg">'
            f'<a href="{valeur}"><rect width="10" height="10"/></a></svg>'
        )

    def test_javascript_en_clair(self):
        self.assertNotIn("alert", self._lien("javascript:alert(1)"))

    def test_javascript_en_reference_decimale(self):
        """`&#106;` est un `j`. Le navigateur le décode, l'ancienne regex non."""
        self.assertNotIn("alert", self._lien("&#106;avascript:alert(1)"))

    def test_javascript_en_reference_hexadecimale(self):
        self.assertNotIn("alert", self._lien("&#x6A;avascript:alert(1)"))

    def test_reference_sans_point_virgule(self):
        """Les navigateurs l'acceptent ; on ne peut donc pas s'y fier."""
        self.assertNotIn("alert", self._lien("&#106avascript:alert(1)"))

    def test_reference_avec_zeros_de_tete(self):
        self.assertNotIn("alert", self._lien("&#0000106;avascript:alert(1)"))

    def test_lettres_separees_par_des_blancs_de_controle(self):
        """`java\\tscript:` vaut `javascript:` : l'URL est nettoyée avant lecture."""
        self.assertNotIn("alert", self._lien("java\tscript:alert(1)"))
        self.assertNotIn("alert", self._lien("java\nscript:alert(1)"))

    def test_plusieurs_lettres_encodees(self):
        self.assertNotIn("alert", self._lien("&#106;&#97;vascri&#112;t:alert(1)"))

    def test_xlink_href(self):
        propre = clean_svg(
            '<svg xmlns="http://www.w3.org/2000/svg">'
            '<a xlink:href="&#106;avascript:alert(1)"><rect/></a></svg>'
        )
        self.assertNotIn("alert", propre)


class CeQuiDoitSurvivreTests(SimpleTestCase):
    """Un nettoyage qui casse les icônes légitimes ne sera pas gardé."""

    ICONE = (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">'
        '<title>Facebook</title>'
        '<path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2z" '
        'fill="#1877F2"/>'
        '<a href="https://exemple.test/page"><circle cx="12" cy="12" r="4"/></a>'
        '</svg>'
    )

    def test_une_icone_ordinaire_traverse_intacte(self):
        self.assertEqual(clean_svg(self.ICONE), self.ICONE)

    def test_un_lien_https_est_conserve(self):
        self.assertIn("https://exemple.test/page", clean_svg(self.ICONE))

    def test_une_entree_vide_rend_une_chaine_vide(self):
        for vide in ("", None, b""):
            with self.subTest(valeur=vide):
                self.assertEqual(clean_svg(vide), "")

    def test_les_octets_sont_acceptes(self):
        self.assertEqual(clean_svg(self.ICONE.encode("utf-8")), self.ICONE)
