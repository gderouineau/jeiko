import {
    getCookie,
    fetchHtml,
    showModal,
    showToast,
    showConfirmModal,
    closeModal,
    escapeHtml,
} from "./utils.js";

const csrftoken = getCookie("csrftoken");

/* =========================
 *  Unification re-init UI
 * ========================= */
function reinitAlpine(root = document) {
    try {
        if (window.Alpine && typeof Alpine.initTree === "function") {
            Alpine.initTree(root);
        }
    } catch (e) {
        console.warn("[reinitAlpine] Alpine.initTree a échoué:", e);
    }
}
window.executeInlineScripts = function (root) {
    if (!root) return;
    const scripts = root.querySelectorAll("script");
    scripts.forEach((old) => {
        const s = document.createElement("script");
        // copy attributes (type/module etc.)
        for (const attr of old.attributes) s.setAttribute(attr.name, attr.value);
        s.textContent = old.textContent;
        old.replaceWith(s);
    });
};

window.initAlpineOn = function (root) {
    if (!window.Alpine || !root) return;
    // Alpine v3
    if (Alpine.initTree) Alpine.initTree(root);
};
function attachAjaxFormHandler(formId, updateDOMCallback, successMsg = "Opération réussie") {
    const form = document.getElementById(formId);
    if (!form || form._handlerAttached) return;

    form._handlerAttached = true;

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        // Garde anti double-soumission : un double-clic créait deux objets.
        if (form._submitting) return;
        form._submitting = true;
        const submitButtons = form.querySelectorAll('[type="submit"]');
        submitButtons.forEach((btn) => {
            btn.disabled = true;
        });

        const release = () => {
            form._submitting = false;
            submitButtons.forEach((btn) => {
                btn.disabled = false;
            });
        };

        const target = form.action || form.dataset.url;

        let res;
        try {
            res = await fetch(target, {
                method: "POST",
                headers: {
                    "X-CSRFToken": csrftoken,
                    "X-Requested-With": "XMLHttpRequest",
                },
                credentials: "same-origin",
                body: new FormData(form),
            });
        } catch {
            // Coupure réseau : la promesse était rejetée sans que rien ne le signale.
            showToast("Erreur réseau");
            release();
            return;
        }

        let data,
            isJson = false;
        try {
            data = await res.clone().json();
            isJson = true;
        } catch {
            data = await res.text();
        }

        const succeeded =
            isJson && (data.ok === true || data.status === "success" || data.status === "ok");

        if (res.ok && succeeded) {
            closeModal();
            // Le callback fait le remplacement ciblé ET réinitialise son sous-arbre
            // (applyEditorResponse / insertSectionFragment). Plus de reinitUI(document) ici :
            // il relançait Alpine sur toute la page et pouvait réinitialiser l'état de blocs
            // qui n'avaient pas bougé (onglet actif, slide courant d'un carousel).
            updateDOMCallback(data);
            showToast(successMsg);
            release();
        } else if (!isJson) {
            // Formulaire renvoyé avec ses erreurs : on le réinjecte dans le modal.
            const container =
                document.querySelector(".modal-body") || document.querySelector(".modal-content");
            if (container) container.innerHTML = data;
            release();
            attachAjaxFormHandler(formId, updateDOMCallback, successMsg);
            reinitUI(container || document);
        } else {
            showToast(data.message || "Erreur serveur");
            release();
        }
    });
}

/*
 * NOTE — les overlays d'édition n'ont plus de JavaScript.
 *
 * 174 lignes vivaient ici : elles branchaient mouseenter/mouseleave sur chaque section,
 * chaque ligne et chaque bloc, avec des tests croisés de `:hover` sur les frères et les
 * parents, et une tolérance en pixels pour décaler les barres qui se chevauchaient.
 * Tout est passé en CSS (`editor.css`, section « Affichage des overlays »).
 *
 * Trois défauts disparaissent par construction :
 *  - D1 : après un remplacement de section, aucun mouseenter n'était émis puisque le curseur
 *    n'avait franchi aucune frontière ; les contrôles restaient invisibles jusqu'à ce qu'on
 *    sorte de l'élément et y revienne. `:hover` est réévalué à chaque frame ;
 *  - D2 : `.overlay-block-controls` étant en `pointer-events:none`, ni `:hover` ni
 *    `mouseenter` ne s'y appliquaient — trois lignes de la logique ne s'exécutaient jamais ;
 *  - C4 : un listener `resize` était ajouté par ligne et jamais retiré ; après quelques
 *    dizaines d'opérations, des centaines de handlers morts référençaient des éléments
 *    détachés du DOM.
 *
 * D3 : les trois barres sont ancrées à des coins distincts (section haut gauche, ligne haut
 * droit, bloc centre), ce qui rend impossible la collision que --line-x compensait.
 */

/**
 * Remplace un nœud par un fragment serveur, puis réinitialise le sous-arbre.
 * outerHTML n'exécute jamais les <script> (spec HTML) : d'où executeInlineScripts.
 */
function replaceNode(targetId, html) {
    if (!targetId || !html) return null;
    const old = document.getElementById(targetId);
    if (!old) return null;

    old.outerHTML = html;
    const fresh = document.getElementById(targetId);
    if (!fresh) return null;

    executeInlineScripts(fresh);
    initAlpineOn(fresh);
    reinitUI(fresh);
    return fresh;
}

/** Extrait le fragment HTML d'une réponse. SEULE chaîne de repli du client. */
export function responseHtml(data) {
    if (!data) return "";
    return data.html || data.section_html || data.line_html || data.content_html || "";
}

/**
 * Point d'entrée UNIQUE pour appliquer une réponse de l'éditeur.
 *
 * C'est le seul endroit du client qui connaît la forme du JSON serveur. Avant, chaque
 * fonction refaisait `data.section_html || data.line_html || data.html` et son propre test
 * de statut — douze copies, dont plusieurs oubliaient d'exécuter les scripts inline.
 *
 * Contrat canonique (administration_pages/responses.py) :
 *   { ok, action: "replace"|"insert"|"modal"|"none", target, html, message }
 * Les clés historiques (status / section_id / section_html) restent tolérées.
 *
 * @returns {Element|null} le nœud fraîchement injecté, ou null.
 */
export function applyEditorResponse(data, { successMessage = "" } = {}) {
    if (!data) return null;

    const failed = data.ok === false || data.status === "error" || data.success === false;
    if (failed) {
        showToast(data.message || "Erreur serveur");
        return null;
    }

    const html = responseHtml(data);
    const target = data.target || (data.section_id != null ? `section-${data.section_id}` : null);
    const action = data.action || (html && target ? "replace" : "none");

    let node = null;
    if (action === "replace") {
        node = replaceNode(target, html);
    }

    if (successMessage) showToast(successMessage);
    return node;
}

/* =========================
 *  Primitives d'action
 * ========================= */

const EDITOR_BASE = "/jeiko/administration/pages";

/** Constructeurs d'URL — un seul endroit qui connaît la forme des routes. */
const endpoint = {
    section: (page, section, verb) => `${EDITOR_BASE}/${page}/sections/${section}/${verb}/`,
    line: (page, section, line, verb) =>
        `${EDITOR_BASE}/${page}/sections/${section}/lines/${line}/${verb}/`,
    bloc: (page, section, line, bloc, verb) =>
        `${EDITOR_BASE}/${page}/sections/${section}/lines/${line}/blocs/${bloc}/${verb}/`,
    model: (kind, id) => `/api/pages/${kind}/${id}/make_model/`,
};

/**
 * Requête d'édition : CSRF, en-tête AJAX, parsing et gestion d'erreur au même endroit.
 * Renvoie les données, ou null si quoi que ce soit a échoué (le toast est déjà affiché).
 *
 * Auparavant chaque fonction refaisait ce bloc, et la moitié en `.then()` sans `.catch()` :
 * une coupure réseau ou un 500 passaient totalement inaperçus.
 */
async function editorRequest(target, { method = "POST", body = null, json = false } = {}) {
    const headers = {
        "X-CSRFToken": csrftoken,
        "X-Requested-With": "XMLHttpRequest",
    };
    if (json) headers["Content-Type"] = "application/json";

    let res;
    try {
        res = await fetch(target, { method, headers, credentials: "same-origin", body });
    } catch {
        showToast("Erreur réseau");
        return null;
    }

    let data = null;
    try {
        data = await res.json();
    } catch {
        data = null;
    }

    if (!res.ok) {
        showToast((data && data.message) || "Erreur serveur");
        return null;
    }
    return data;
}

/** Requête + application de la réponse. Le cas courant de toutes les actions d'édition. */
async function editorAction(target, { successMessage = "", ...opts } = {}) {
    const data = await editorRequest(target, opts);
    if (!data) return null;
    return applyEditorResponse(data, { successMessage });
}

/**
 * Création d'un modèle depuis une section / ligne / bloc / contenu.
 * Les quatre variantes ne différaient que par l'URL, les ids du formulaire et le libellé.
 */
async function makeModel({ kind, id, inputId, feedbackId, successMessage, missingIdMessage }) {
    const input = document.getElementById(inputId);
    const feedback = document.getElementById(feedbackId);
    const name = (input?.value || "").trim();

    const paint = (msg, ok) => {
        if (!feedback) return;
        feedback.textContent = msg;
        feedback.style.color = ok ? "#0a7d32" : "#b00020";
    };

    if (!id) return paint(missingIdMessage, false);
    if (!name) return paint("Merci de saisir un nom de modèle.", false);

    const data = await editorRequest(endpoint.model(kind, id), {
        json: true,
        body: JSON.stringify({ model_name: name }),
    });
    if (!data) return paint("Erreur lors de la création du modèle.", false);

    if (data.success || data.ok) {
        paint(`${successMessage}${data.model?.name ? " : " + data.model.name : ""}`, true);
        showToast(successMessage);
    } else {
        paint(data.message || "Erreur lors de la création du modèle.", false);
        showToast(data.message || "Erreur");
    }
}

/** Réordonne visuellement une section parmi ses sœurs (le serveur ne renvoie pas de HTML). */
function moveSectionNode(sectionId, direction) {
    const container = document.getElementById("content");
    if (!container) return false;
    const sections = Array.from(container.querySelectorAll(".section"));
    const idx = sections.findIndex((el) => el.id === `section-${sectionId}`);
    if (idx < 0) return false;

    const swapWith = idx + direction;
    if (swapWith < 0 || swapWith >= sections.length) return false;

    if (direction < 0) container.insertBefore(sections[idx], sections[swapWith]);
    else container.insertBefore(sections[swapWith], sections[idx]);
    return true;
}

export function reinitUI(root = document) {
    reinitAlpine(root);

    // Les overlays d'édition ne demandent plus rien ici : ils sont pilotés par :hover.

    try {
        if (window.ResponsiveImg && typeof window.ResponsiveImg.refresh === "function") {
            window.ResponsiveImg.refresh(root);
        }
    } catch (e) {
        console.warn("[reinitUI] ResponsiveImg.refresh a échoué:", e);
    }

    try {
        if (window.Formsets && Formsets.Countdown) {
            Formsets.Countdown.boot(root);
        }
    } catch (e) {
        console.warn("[reinitUI] Countdown.boot a échoué:", e);
    }

    return root;
}

// === Helpers QUILL (ajout de pickers natifs + utilitaires) ====================

// === Helpers QUILL (color utils + pickers natifs) ============================

// rgb/rgba/#abc → #rrggbb
function toHex(color, current = "#000000") {
    if (!color) return current;
    if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(color)) {
        if (color.length === 4) {
            return (
                "#" +
                color[1] +
                color[1] +
                color[2] +
                color[2] +
                color[3] +
                color[3]
            ).toLowerCase();
        }
        return color.toLowerCase();
    }
    const m = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (m) {
        const r = Math.max(0, Math.min(255, parseInt(m[1], 10)));
        const g = Math.max(0, Math.min(255, parseInt(m[2], 10)));
        const b = Math.max(0, Math.min(255, parseInt(m[3], 10)));
        return (
            "#" +
            r.toString(16).padStart(2, "0") +
            g.toString(16).padStart(2, "0") +
            b.toString(16).padStart(2, "0")
        ).toLowerCase();
    }
    return current;
}

// Ajoute deux <input type="color"> (Texte + Fond) dans la toolbar Quill

function addQuillColorPickers(quill) {
    try {
        const toolbar = quill.getModule("toolbar");
        const bar = toolbar && toolbar.container;
        if (!bar) return;
        if (bar.querySelector(".ql-color-pickers")) return; // déjà injecté

        const group = document.createElement("span");
        group.className = "ql-formats ql-color-pickers";

        // --- Picker couleur de TEXTE
        const colorWrap = document.createElement("label");
        colorWrap.className = "ql-color-picker";
        colorWrap.title = "Couleur du texte";
        colorWrap.style.display = "inline-flex";
        colorWrap.style.alignItems = "center";

        const colorIcon = document.createElement("span");
        colorIcon.className = "ql-picker-label";
        colorIcon.textContent = "A";
        colorIcon.style.cssText = "display:inline-block;font-weight:700;margin-right:6px;";

        const colorInput = document.createElement("input");
        colorInput.type = "color";
        colorInput.value = "#333333";
        colorInput.style.cssText =
            "width:28px;height:28px;padding:0;border:none;background:transparent;cursor:pointer;";
        colorInput.addEventListener("input", () => {
            // → couleur du TEXTE
            quill.format("color", colorInput.value || null);
        });

        colorWrap.appendChild(colorIcon);
        colorWrap.appendChild(colorInput);
        group.appendChild(colorWrap);

        // --- Picker couleur de FOND
        const bgWrap = document.createElement("label");
        bgWrap.className = "ql-bg-picker";
        bgWrap.title = "Couleur de fond";
        bgWrap.style.display = "inline-flex";
        bgWrap.style.alignItems = "center";

        const bgIcon = document.createElement("span");
        bgIcon.className = "ql-picker-label";
        bgIcon.textContent = "▧";
        bgIcon.style.cssText = "display:inline-block;margin:0 6px 0 12px;";

        const bgInput = document.createElement("input");
        bgInput.type = "color";
        bgInput.value = "#ffffff";
        bgInput.style.cssText =
            "width:28px;height:28px;padding:0;border:none;background:transparent;cursor:pointer;";
        bgInput.addEventListener("input", () => {
            // → couleur de FOND
            quill.format("background", bgInput.value || null);
        });

        bgWrap.appendChild(bgIcon);
        bgWrap.appendChild(bgInput);
        group.appendChild(bgWrap);

        // Pas de palette Quill → on append à la fin du toolbar
        bar.appendChild(group);

        // synchro inverse (formats Quill -> inputs)
        const sync = () => {
            try {
                const range = quill.getSelection();
                if (!range) return;
                const fmt = quill.getFormat(range);
                if (fmt.color) colorInput.value = toHex(fmt.color, colorInput.value);
                if (fmt.background) bgInput.value = toHex(fmt.background, bgInput.value);
            } catch {}
        };
        quill.on("selection-change", sync);
        quill.on("text-change", sync);
    } catch (e) {
        console.warn("[addQuillColorPickers] échec:", e);
    }
}

function unwrapQuoted(s) {
    if (typeof s !== "string") return s;
    const t = s.trim();
    if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) {
        return t.slice(1, -1);
    }
    return s;
}
// === Initialisation QUILL dans le modal ======================================

export function initQuillInModal(body, blocId) {
    // Sélection par classe : un id est unique par définition, l'utiliser avec
    // querySelectorAll rendait le comportement indéfini dès qu'un second éditeur
    // de texte cohabiterait dans le modal.
    body.querySelectorAll(".js-quill-editor").forEach((editorEl) => {
        if (!window.Quill) return;

        // éviter double init
        if (editorEl.classList.contains("ql-container") || editorEl.querySelector(".ql-editor"))
            return;

        // 1) CAPTURER le contenu initial AVANT d'instancier Quill
        const initialHtmlRaw = unwrapQuoted(editorEl.innerHTML?.trim() || "");

        // 2) Instancier Quill
        const toolbarOptions = [
            [
                {
                    header: [1, 2, 3, 4, 5, 6, false],
                },
            ],
            ["bold", "italic", "underline", "strike"],
            ["link", "blockquote", "code-block"],
            [
                {
                    list: "ordered",
                },
                {
                    list: "bullet",
                },
                {
                    list: "check",
                },
            ],
            [
                {
                    script: "sub",
                },
                {
                    script: "super",
                },
            ],
            [
                {
                    align: [],
                },
            ],
            [
                {
                    size: ["small", false, "large", "huge"],
                },
            ],
        ];
        const quill = new Quill(editorEl, {
            theme: "snow",
            modules: {
                toolbar: toolbarOptions,
            },
        });

        // 3) Récup de l'input caché (avec suffixe -text)
        const input =
            editorEl.parentNode.querySelector('input[type="hidden"][name$="-text"]') ||
            body.querySelector('input[type="hidden"][name$="-text"]');

        // util: détecter "vide" (p, br, espaces)
        const isEmptyHtml = (html) => {
            if (!html) return true;
            const clean = html.replace(/\s+/g, " ").trim().toLowerCase();
            return clean === "" || clean === "<p><br></p>" || clean === "<p></p>";
        };

        // 4) Déterminer la valeur initiale à injecter
        let inputContent = (input?.value || "").trim();
        inputContent = unwrapQuoted(inputContent);
        const hasInitialDom = !isEmptyHtml(initialHtmlRaw);
        const hasInputValue = !isEmptyHtml(inputContent);

        if (hasInitialDom) {
            quill.root.innerHTML = initialHtmlRaw;
            if (input) input.value = quill.root.innerHTML;
        } else if (hasInputValue) {
            quill.root.innerHTML = inputContent;
        } // sinon, on garde l’état vide de Quill

        // 5) Sync en permanence vers l’input hidden
        if (input) {
            quill.on("text-change", () => {
                input.value = quill.root.innerHTML;
            });
        }

        // 6) Ajout des pickers couleur
        addQuillColorPickers(quill);

        // 7) Coller en texte brut (Alt = garder la mise en forme)
        quill.root.addEventListener(
            "paste",
            (e) => {
                if (e.altKey) return;
                e.preventDefault();
                e.stopPropagation();
                const text = (e.clipboardData || window.clipboardData)?.getData("text/plain") || "";
                if (!text) return;
                const sel = quill.getSelection(true);
                quill.deleteText(sel.index, sel.length, "user");
                quill.insertText(sel.index, text, "user");
                quill.setSelection(sel.index + text.length, 0, "silent");
            },
            true,
        );
    });

    reinitUI(body);
}

// ===================== Menu section et lignes ======================

// ---- Menu header pour SECTIONS/LIGNES ----
async function fetchEditingMenuStructure() {
    // À adapter côté serveur : renvoie le fragment <nav class="editing-menu">…</nav>
    // ex: templates/administration_pages/structure/editing_menu.html
    const url = "/jeiko/administration/pages/editing-menu-section-line/";
    try {
        const res = await fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest" } });
        if (res.ok) return await res.text();
    } catch (e) {
        console.warn("Impossible de charger le menu d’édition (structure) :", e);
    }
    return "";
}

// ===================== CRUD Sections ======================

// ——— helper optionnel pour insérer le fragment section dans le DOM

function insertSectionFragment(fragHtml, parentSelector) {
    if (!fragHtml) return;
    const parent = document.querySelector(parentSelector);
    if (!parent) return;

    // L'état vide porte data-empty-state dans le template : plus de comparaison
    // de texte, qui cassait au premier changement de libellé.
    parent.querySelector("[data-empty-state]")?.remove();

    // Insertion avant bouton .add si trouvé, sinon à la fin
    const addBtn = parent.querySelector(".section-add, .line-add, .bloc-add");
    let inserted = null;
    if (addBtn) {
        addBtn.insertAdjacentHTML("beforebegin", fragHtml);
        inserted = addBtn.previousElementSibling;
    } else {
        parent.insertAdjacentHTML("beforeend", fragHtml);
        inserted = parent.lastElementChild;
    }

    reinitUI(inserted || parent);
}

export async function createSection(pageId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/add/`;

    const res = await fetch(url, {
        method: "GET",
        headers: {
            "X-Requested-With": "XMLHttpRequest",
            "X-CSRFToken": csrftoken,
        },
    });

    if (!res.ok) {
        showToast("Erreur serveur");
        return;
    }

    let data;
    try {
        data = await res.json();
    } catch {
        data = {};
    }

    if (data.status === "choose_type" && data.html) {
        showModal(data.html, "Créer une section");
        attachAjaxFormHandler("choose-section-form", (postData) => {
            insertSectionFragment(responseHtml(postData), "#content");
            showToast("Section créée");
        });
    } else if (data.status === "success") {
        insertSectionFragment(responseHtml(data), "#content");
    }
}

export async function editSection(pageId, sectionId) {
    const html = await fetchHtml(endpoint.section(pageId, sectionId, "update"));

    const headerMenu = await fetchEditingMenuStructure();
    showModal(html, headerMenu || "Modifier la section");

    const body = document.querySelector("#editor-modal .modal-body");
    // Si le template serveur contient encore un <nav.editing-menu> dans le body, on le retire.
    body?.querySelector(".editing-menu")?.remove();

    try {
        showEditingParameters("global-parameters");
    } catch {}

    attachAjaxFormHandler("section-form", (data) => applyEditorResponse(data));
    reinitUI(body);
}

/**
 * Décrit ce qu'un élément emporte avec lui, pour le dire dans la confirmation.
 * « Es-tu sûr ? » ne dit ni ce qu'on supprime, ni ce qu'on perd.
 */
function describeContents(root, selectors) {
    if (!root) return "";
    const parts = selectors
        .map(({ selector, one, many }) => {
            const n = root.querySelectorAll(selector).length;
            return n ? `${n} ${n > 1 ? many : one}` : null;
        })
        .filter(Boolean);
    if (!parts.length) return "Cette action est définitive.";
    return `${parts.join(" et ")} seront perdus. Cette action est définitive.`;
}

export function removeSection(pageId, sectionId) {
    const el = document.getElementById(`section-${sectionId}`);
    const detail = describeContents(el, [
        { selector: ".line", one: "ligne", many: "lignes" },
        { selector: ".bloc", one: "bloc", many: "blocs" },
    ]);
    showConfirmModal("Supprimer cette section ?", async () => {
        const data = await editorRequest(endpoint.section(pageId, sectionId, "delete"));
        if (!data || data.ok === false) return;

        document.getElementById(`section-${sectionId}`)?.remove();
        showToast("Section supprimée");

        const content = document.getElementById("content");
        if (content && !content.querySelector(".section")) {
            const msg = document.createElement("h4");
            msg.textContent = "Aucune section créée pour l'instant";
            content.querySelector(".section-add")?.insertAdjacentElement("beforebegin", msg);
        }
    }, { detail, label: "Supprimer" });
}

// Les sections sont réordonnées côté client : SectionMoveUp/Down ne renvoient pas de HTML
// (déplacer une section change l'ordre des sœurs, pas le contenu de l'une d'elles).
async function moveSection(pageId, sectionId, direction, verb, message) {
    const data = await editorRequest(endpoint.section(pageId, sectionId, verb));
    if (!data || data.ok === false) return;
    if (moveSectionNode(sectionId, direction)) showToast(message);
}

export const moveSectionUp = (pageId, sectionId) =>
    moveSection(pageId, sectionId, -1, "move_up", "Section déplacée vers le haut");

export const moveSectionDown = (pageId, sectionId) =>
    moveSection(pageId, sectionId, +1, "move_down", "Section déplacée vers le bas");

export const makeSectionModel = (sectionId) =>
    makeModel({
        kind: "sections",
        id: sectionId,
        inputId: "model-name-input",
        feedbackId: "model-feedback",
        successMessage: "Modèle créé",
        missingIdMessage: "ID de section manquant.",
    });

// ===================== CRUD Lines ======================

export async function createLine(pageId, sectionId) {
    const target = `${EDITOR_BASE}/${pageId}/sections/${sectionId}/lines/add/`;

    let res;
    try {
        res = await fetch(target, {
            method: "GET",
            headers: { "X-Requested-With": "XMLHttpRequest", "X-CSRFToken": csrftoken },
            credentials: "same-origin",
        });
    } catch {
        showToast("Erreur réseau");
        return;
    }
    if (!res.ok) {
        showToast("Erreur serveur");
        return;
    }

    // Le serveur peut répondre en JSON {status:"choose_type", html} ou en HTML brut.
    let markup;
    try {
        const payload = await res.clone().json();
        markup = payload.html || "";
    } catch {
        markup = await res.text();
    }

    showModal(markup, "Créer une ligne");
    attachAjaxFormHandler("choose-line-form", (data) => {
        insertSectionFragment(responseHtml(data), `#section-${sectionId}`);
        showToast("Ligne créée");
    });
}

export async function editLine(pageId, sectionId, lineId) {
    const html = await fetchHtml(endpoint.line(pageId, sectionId, lineId, "update"));

    const headerMenu = await fetchEditingMenuStructure();
    showModal(html, headerMenu || "Modifier la ligne");

    const body = document.querySelector("#editor-modal .modal-body");
    body?.querySelector(".editing-menu")?.remove();

    try {
        showEditingParameters("global-parameters");
    } catch {}

    attachAjaxFormHandler("line-form", (data) => applyEditorResponse(data));
    reinitUI(body);
}

export function removeLine(pageId, sectionId, lineId) {
    const el = document.getElementById(`line-${lineId}`);
    const detail = describeContents(el, [
        { selector: ".bloc", one: "bloc", many: "blocs" },
    ]);
    showConfirmModal(
        "Supprimer cette ligne ?",
        () =>
            // La section renvoyée affiche déjà « Aucune ligne » quand elle est vide.
            editorAction(endpoint.line(pageId, sectionId, lineId, "delete"), {
                successMessage: "Ligne supprimée",
            }),
        { detail, label: "Supprimer" },
    );
}

const moveLine = (verb, message) => (pageId, sectionId, lineId) =>
    editorAction(endpoint.line(pageId, sectionId, lineId, verb), { successMessage: message });

export const moveLineUp = moveLine("move_up", "Ligne déplacée vers le haut");
export const moveLineDown = moveLine("move_down", "Ligne déplacée vers le bas");

export const makeLineModel = (lineId) =>
    makeModel({
        kind: "lines",
        id: lineId,
        inputId: "line-model-name-input",
        feedbackId: "line-model-feedback",
        successMessage: "Modèle de ligne créé",
        missingIdMessage: "ID de ligne manquant.",
    });

// ===================== CRUD Content (Blocs) ======================

export async function chooseContentType(pageId, sectionId, lineId, blocId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/add/`;
    const res = await fetch(url, {
        method: "GET",
        headers: {
            "X-CSRFToken": csrftoken,
            "X-Requested-With": "XMLHttpRequest",
        },
    });
    if (!res.ok) {
        showToast("Erreur serveur");
        return;
    }
    const data = await res.json();

    if (data.status === "choose_type") {
        showModal(data.html, "<h1>Choisir le type de contenu</h1>");
        setTimeout(() => {
            attachAjaxFormHandler("choose-content-form", (chooseData) => {
                if (chooseData.status === "success") {
                    editContent(pageId, sectionId, lineId, blocId);
                } else {
                    showToast(chooseData.message || "Erreur inattendue");
                }
            });
            attachBlocModelHandler("choose-bloc-model-form", pageId, sectionId, lineId, blocId);

            reinitUI(document.querySelector(".modal-body") || document);
        }, 0);
    } else if (data.status === "success") {
        editContent(pageId, sectionId, lineId, blocId);
    } else {
        showToast(data.message || "Erreur inattendue");
    }
}

export async function showEditingParameters(id) {
    // toggle panneaux
    document.querySelectorAll(".editing-parameters").forEach((section) => {
        section.style.display = section.id === id ? "" : "none";
    });

    // toggle actif sur les boutons du menu du modal
    const modal = document.getElementById("editor-modal");
    if (!modal) return;

    modal.querySelectorAll(".editing-menu button").forEach((btn) => {
        const target =
            btn.getAttribute("data-target") ||
            ((btn.getAttribute("onclick") || "").match(/showEditingParameters\('([^']+)'\)/) ||
                [])[1];

        const isActive = target === id;
        btn.classList.toggle("active", isActive);
        btn.setAttribute("aria-selected", isActive ? "true" : "false");
    });
}

async function fetchEditingMenu() {
    try {
        const response = await fetch("/jeiko/administration/pages/editing-menu/", {
            headers: {
                "X-Requested-With": "XMLHttpRequest",
            },
        });
        if (response.ok) {
            return await response.text();
        }
    } catch (e) {
        console.warn("Impossible de charger le menu d’édition :", e);
    }
    return "";
}

export async function editContent(pageId, sectionId, lineId, blocId) {
    const target = endpoint.bloc(pageId, sectionId, lineId, blocId, "content/edit");
    const data = await editorRequest(target, { method: "GET" });
    if (!data) return;

    // Le GET renvoie le formulaire d'édition à injecter dans le modal.
    const isOk = data.ok === true || data.status === "ok" || data.status === "success";
    if (!isOk || !responseHtml(data)) {
        showToast(data.message || "Erreur inattendue");
        return;
    }

    const menuHtml = await fetchEditingMenu();
    showModal(responseHtml(data), menuHtml || "Édition du contenu");

    const body = document.querySelector(".modal-body");
    const modalEl =
        body?.closest("#editor-modal") || document.getElementById("editor-modal") || document;

    initQuillInModal(body, blocId);
    showEditingParameters("content-parameters");

    // Aperçu + sauvegarde du style de formulaire
    if (window.InitFormulaireStyle) {
        window.InitFormulaireStyle(modalEl);
    } else if (window.jeikoInitFormulaireStyle) {
        window.jeikoInitFormulaireStyle(modalEl); // compat ancien nom
    }

    reinitUI(body);
    attachAjaxFormHandler("content-edit-form", (editData) => applyEditorResponse(editData));
}

export function resetContent(pageId, sectionId, lineId, blocId) {
    showConfirmModal("Remettre ce contenu à zéro ?", async () => {
        const target = endpoint.bloc(pageId, sectionId, lineId, blocId, "content/reset");
        const data = await editorRequest(target);
        if (!data || data.ok === false) return;

        applyEditorResponse(data, { successMessage: "Contenu réinitialisé" });
        // Puis on enchaîne directement sur le choix du type de contenu.
        chooseContentType(pageId, sectionId, lineId, blocId);
    }, {
        detail: "Le contenu actuel sera effacé et vous choisirez un nouveau type.",
        label: "Remettre à zéro",
    });
}

export async function addBloc(pageId, sectionId, lineId, blocId) {
    const data = await editorRequest(endpoint.bloc(pageId, sectionId, lineId, blocId, "add"));
    if (!data || data.ok === false) return;

    applyEditorResponse(data);
    // On ouvre directement le choix de contenu pour le bloc fraîchement créé.
    chooseContentType(pageId, sectionId, lineId, data.new_bloc_id);
}

export function removeBloc(pageId, sectionId, lineId, blocId) {
    showConfirmModal(
        "Supprimer ce bloc ?",
        () => editorAction(endpoint.bloc(pageId, sectionId, lineId, blocId, "delete")),
        { detail: "Son contenu sera perdu. Cette action est définitive.", label: "Supprimer" },
    );
}

// Les quatre déplacements de bloc ne différaient que par le verbe de l'URL :
// 4 x 27 lignes strictement identiques, sans aucune gestion d'erreur.
const moveBloc = (verb) => (pageId, sectionId, lineId, blocId) =>
    editorAction(endpoint.bloc(pageId, sectionId, lineId, blocId, verb));

export const moveBlocUp = moveBloc("move_up");
export const moveBlocDown = moveBloc("move_down");
export const moveBlocLeft = moveBloc("move_left");
export const moveBlocRight = moveBloc("move_right");

// ---- Content -> modèle ----
export const makeContentModel = (contentId) =>
    makeModel({
        kind: "contents",
        id: contentId,
        inputId: "content-model-name-input",
        feedbackId: "content-model-feedback",
        successMessage: "Modèle de contenu créé",
        missingIdMessage: "ID de contenu manquant.",
    });

// ---- Bloc -> modèle ----

export const makeBlocModel = (blocId) =>
    makeModel({
        kind: "blocs",
        id: blocId,
        inputId: "bloc-model-name-input",
        feedbackId: "bloc-model-feedback",
        successMessage: "Modèle de bloc créé",
        missingIdMessage: "ID de bloc manquant.",
    });

// ---- Remplacement par un bloc modèle ----
export function attachBlocModelHandler(formId, pageId, sectionId, lineId, blocId) {
    const form = document.getElementById(formId);
    // Même garde que attachAjaxFormHandler : sans elle, rouvrir le modal empilait
    // les écouteurs et le formulaire partait 2 fois, puis 3...
    if (!form || form._handlerAttached) return;
    form._handlerAttached = true;

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/add_from_model/`;
        const formData = new FormData(form);

        try {
            const res = await fetch(url, {
                method: "POST",
                headers: {
                    "X-CSRFToken": csrftoken,
                    "X-Requested-With": "XMLHttpRequest",
                },
                body: formData,
            });
            if (!res.ok) {
                showToast("Erreur lors de l’insertion du modèle");
                return;
            }
            const data = await res.json();

            if (data.ok !== false && responseHtml(data)) {
                applyEditorResponse(data);
                closeModal();
                showToast("Bloc inséré depuis modèle");
            } else {
                showToast(data.message || "Erreur lors de l’insertion du modèle");
            }
        } catch (err) {
            console.error(err);
            showToast("Erreur réseau");
        }
    });
}

// ===================== CRUD Formulaire (inline, sans nested <form>) ======================

function getFormulaireId() {
    const holder = document.querySelector("[data-formulaire-id]");
    if (holder?.dataset.formulaireId) return holder.dataset.formulaireId;
    const ul = document.getElementById("fields-list");
    if (ul?.dataset.formulaireId) return ul.dataset.formulaireId;
    return null;
}
function csrfHeaders(json = false) {
    const h = { "X-Requested-With": "XMLHttpRequest", "X-CSRFToken": getCookie("csrftoken") };
    if (json) h["Content-Type"] = "application/json";
    return h;
}

// L'éditeur de champ est monté DANS #content-edit-form (edit_formulaire.html:155).
// Ses contrôles portent des noms (label, name, placeholder, type, required, options) qui
// entrent en collision avec ceux du formulaire lui-même — notamment `name`, qui est le
// « Titre du formulaire ». On les rattache donc à un <form> inexistant via l'attribut
// form= : ils restent éditables mais n'appartiennent à aucun formulaire, ne sont jamais
// soumis, et leur validation native ne peut plus bloquer l'enregistrement du bloc.
const DETACHED = 'form="jeiko-detached-field-editor"';

function fieldEditorHtml(initial = {}, mode = "add") {
    const types = ["text", "email", "phone", "textarea", "select", "checkbox", "date", "number"];
    const optsStr = Array.isArray(initial.options)
        ? initial.options.join(", ")
        : typeof initial.options === "object"
          ? JSON.stringify(initial.options)
          : initial.options || "";
    return `
        <div class="field-inline-editor" data-mode="${mode}" style="border:1px dashed #bbb; padding:1em; margin-top:1em; border-radius:6px;">
            <h5 style="margin:0 0 .75em;">${mode === "add" ? "Ajouter un champ" : "Éditer le champ"}</h5>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem;">
                <label>Label
                    <input type="text" name="label" ${DETACHED} value="${escapeHtml(initial.label)}">
                </label>
                <label>Nom technique
                    <input type="text" name="name" ${DETACHED} value="${escapeHtml(initial.name)}">
                </label>
                <label>Placeholder <span style="color:#888;">(facultatif)</span>
                    <input type="text" name="placeholder" ${DETACHED} value="${escapeHtml(initial.placeholder)}">
                </label>
                <label>Type
                    <select name="type" ${DETACHED}>
                        ${types.map((t) => `<option value="${t}" ${t === (initial.type || "") ? "selected" : ""}>${t}</option>`).join("")}
                    </select>
                </label>
                <label>Obligatoire
                    <input type="checkbox" name="required" ${DETACHED} ${initial.required ? "checked" : ""}>
                </label>
            </div>
            <div style="margin-top:.75rem;">
                <label>Options (JSON ou valeurs séparées par virgule pour select/checkbox)
                    <input type="text" name="options" ${DETACHED} placeholder='["Option A","Option B"] ou A, B' value="${escapeHtml(optsStr)}">
                </label>
            </div>
            <div class="field-editor-error" style="color:#b00020; margin-top:.5rem; min-height:1.2em;"></div>
            <div style="display:flex; gap:.5rem; margin-top:1rem;">
                <button type="button" class="btn btn-primary" data-action="save">${mode === "add" ? "Ajouter" : "Enregistrer"}</button>
                <button type="button" class="btn" data-action="cancel">Annuler</button>
            </div>
        </div>
    `;
}
function mountEditor(container, html, onSave) {
    container.innerHTML = html;
    container.style.display = "";
    const $ = (sel) => container.querySelector(sel);
    const getPayload = () => {
        const p = {
            label: $('input[name="label"]').value.trim(),
            name: $('input[name="name"]').value.trim(),
            placeholder: $('input[name="placeholder"]').value.trim(),
            type: $('select[name="type"]').value,
            required: $('input[name="required"]').checked,
            options: $('input[name="options"]').value,
        };
        if (p.options && (p.type === "select" || p.type === "checkbox")) {
            const txt = String(p.options).trim();
            if (txt.startsWith("[") || txt.startsWith("{")) {
                try {
                    p.options = JSON.parse(txt);
                } catch {}
            }
            if (typeof p.options === "string")
                p.options = txt
                    .split(",")
                    .map((s) => s.trim())
                    .filter(Boolean);
        } else {
            delete p.options;
        }
        return p;
    };
    // Validation en JS : les contrôles étant détachés du formulaire, la validation
    // native (required) ne s'applique plus.
    $('button[data-action="save"]').onclick = async () => {
        const payload = getPayload();
        const err = $(".field-editor-error");
        if (!payload.label) {
            if (err) err.textContent = "Le label est obligatoire.";
            return;
        }
        if (!payload.name) {
            if (err) err.textContent = "Le nom technique est obligatoire.";
            return;
        }
        if (err) err.textContent = "";
        await onSave(payload);
        container.innerHTML = "";
        container.style.display = "none";
    };
    $('button[data-action="cancel"]').onclick = () => {
        container.innerHTML = "";
        container.style.display = "none";
    };
    container.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && e.target.tagName !== "TEXTAREA") {
            e.preventDefault();
            $('button[data-action="save"]').click();
        }
    });
}

/* ---- ADD (inline) ---- */
function showAddFieldInline(formulaireId) {
    const container = document.getElementById("field-inline-editor");
    if (!container) return alert("Zone d'édition introuvable (#field-inline-editor).");
    mountEditor(container, fieldEditorHtml({}, "add"), async (payload) => {
        const res = await fetch(`/api/pages/formulaires/${formulaireId}/fields/`, {
            method: "POST",
            headers: csrfHeaders(true),
            credentials: "same-origin",
            body: JSON.stringify(payload),
        });
        if (!res.ok) {
            alert("Échec de l'ajout du champ.");
            return;
        }
        await reloadFieldsList(formulaireId);
    });
}
/* compat : conserve le nom attendu par le bouton */
function showAddFieldForm(formulaireId) {
    showAddFieldInline(formulaireId);
}

/* ---- EDIT ---- */
async function editField(fieldId) {
    const formulaireId = getFormulaireId();
    if (!formulaireId) return alert("Formulaire introuvable.");
    const res = await fetch(`/api/pages/formulaires/${formulaireId}/fields/${fieldId}/`, {
        headers: csrfHeaders(),
        credentials: "same-origin",
    });
    if (!res.ok) return alert("Impossible de charger le champ.");
    const field = await res.json();

    const container = document.getElementById("field-inline-editor");
    if (!container) return alert("Zone d'édition introuvable (#field-inline-editor).");

    mountEditor(container, fieldEditorHtml(field, "edit"), async (payload) => {
        const res2 = await fetch(`/api/pages/formulaires/${formulaireId}/fields/${fieldId}/`, {
            method: "PUT",
            headers: csrfHeaders(true),
            credentials: "same-origin",
            body: JSON.stringify(payload),
        });
        if (!res2.ok) {
            alert("Échec de la mise à jour du champ.");
            return;
        }
        await reloadFieldsList(formulaireId);
    });
}

/* ---- DELETE ---- */
async function deleteField(fieldId) {
    // Dernier `confirm()` natif de l'éditeur : il ne pouvait ni nommer le
    // champ, ni afficher la conséquence, et son apparence changeait d'un
    // navigateur à l'autre — deux styles de confirmation dans le même produit.
    const label = document.querySelector(`[data-field-id="${fieldId}"] .field-label`)?.textContent?.trim();
    showConfirmModal(
        label ? `Supprimer le champ « ${label} » ?` : "Supprimer ce champ ?",
        () => performFieldDeletion(fieldId),
        { detail: "Les réponses déjà reçues ne sont pas supprimées.", label: "Supprimer" },
    );
}

async function performFieldDeletion(fieldId) {
    const formulaireId = getFormulaireId();
    if (!formulaireId) return alert("Formulaire introuvable.");
    const res = await fetch(`/api/pages/formulaires/${formulaireId}/fields/${fieldId}/`, {
        method: "DELETE",
        headers: csrfHeaders(),
        credentials: "same-origin",
    });
    if (!res.ok) return alert("Suppression impossible.");
    await reloadFieldsList(formulaireId);
}

/* ---- MOVE ---- */
async function moveFieldUp(id) {
    return moveField(id, -1);
}
async function moveFieldDown(id) {
    return moveField(id, 1);
}
async function moveField(fieldId, direction) {
    const fieldsList = Array.from(document.querySelectorAll("#fields-list li"));
    const idx = fieldsList.findIndex((li) => li.dataset.fieldId == fieldId);
    if (idx === -1) return;
    const newIdx = idx + direction;
    if (newIdx < 0 || newIdx >= fieldsList.length) return;
    // Permutation dans le tableau local : sert uniquement à calculer le nouvel ordre
    // envoyé au serveur. Le DOM, lui, est reconstruit par reloadFieldsList().
    [fieldsList[idx], fieldsList[newIdx]] = [fieldsList[newIdx], fieldsList[idx]];

    const formulaireId = getFormulaireId();
    if (!formulaireId) return alert("Formulaire introuvable.");
    const newOrder = fieldsList.map((li, i) => ({ id: li.dataset.fieldId, order: i }));

    const res = await fetch(`/api/pages/formulaires/${formulaireId}/fields/`, {
        method: "PATCH",
        headers: csrfHeaders(true),
        credentials: "same-origin",
        body: JSON.stringify({ fields: newOrder }),
    });
    if (!res.ok) return alert("Réordonnancement impossible.");
    await reloadFieldsList(formulaireId);
}

/* ---- RELOAD LIST ---- */
async function reloadFieldsList(formulaireId) {
    const res = await fetch(`/api/pages/formulaires/${formulaireId}/`, {
        headers: { "X-Requested-With": "XMLHttpRequest" },
        credentials: "same-origin",
    });
    if (!res.ok) return;
    const data = await res.json();
    const ul = document.getElementById("fields-list");
    if (!ul) return;
    ul.innerHTML = "";
    for (const field of data.fields || []) {
        const id = Number(field.id);
        if (!Number.isInteger(id)) continue;
        ul.insertAdjacentHTML(
            "beforeend",
            `
            <li data-field-id="${id}" style="margin:0 0 .5em 0; display:flex; align-items:center; gap:.5em; flex-wrap:wrap;">
                <span>
                    <strong>${escapeHtml(field.label)}</strong> <em>(${escapeHtml(field.type)})</em>${field.required ? ' <span style="color:red;">*</span>' : ""}
                    ${field.name ? `<span style="color:#888;"> — nom : ${escapeHtml(field.name)}</span>` : ""}
                </span>
                <span style="flex:1 1 auto;"></span>
                <button type="button" class="btn btn-xs" title="Éditer" aria-label="Éditer" onclick="editField(${id})"><i class="fa-solid fa-pen-to-square"></i></button>
                <button type="button" class="btn btn-xs" title="Monter" aria-label="Monter" onclick="moveFieldUp(${id})"><i class="fa-solid fa-arrow-up"></i></button>
                <button type="button" class="btn btn-xs" title="Descendre" aria-label="Descendre" onclick="moveFieldDown(${id})"><i class="fa-solid fa-arrow-down"></i></button>
                <button type="button" class="btn btn-xs btn-danger" title="Supprimer" aria-label="Supprimer" onclick="deleteField(${id})"><i class="fa-solid fa-trash"></i></button>
            </li>
        `,
        );
    }
}

function closeFieldForm() {
    // cache l’éditeur inline s’il existe
    const inline = document.getElementById("field-inline-editor");
    if (inline) {
        inline.innerHTML = "";
        inline.style.display = "none";
    }
    // cache l’ancien conteneur modal s’il traîne encore
    const legacy = document.getElementById("add-edit-field-modal");
    if (legacy) {
        legacy.innerHTML = "";
        legacy.style.display = "none";
    }
}
window.closeFieldForm = closeFieldForm;

// Initialisation du preview + sauvegarde du style
window.InitFormulaireStyle = function (scopeRoot) {
    const root = scopeRoot || document;
    const wrap = root.querySelector("#form-style-preview");
    if (!wrap) return;

    const API_URL = wrap.dataset.apiUrl;
    const $fs = wrap.querySelector("#style_title_font_size_px");
    const $tc = wrap.querySelector("#style_title_color");
    const $bfg = wrap.querySelector("#style_btn_bg");
    const $bfgH = wrap.querySelector("#style_btn_bg_hover");
    const $btx = wrap.querySelector("#style_btn_text_color");
    const $br = wrap.querySelector("#style_btn_radius_px");

    const $btnPreview = wrap.querySelector(".btn-preview");
    const $styleTag = wrap.querySelector("#btn-preview-style");
    const $feedback = wrap.querySelector("#style-save-feedback");

    const readVal = (el, fallback = null) => {
        if (!el) return fallback;
        const v = (el.value ?? "").trim();
        return v === "" ? fallback : v;
    };

    const paintPreview = () => {
        if ($btnPreview) {
            $btnPreview.style.backgroundColor = readVal($bfg, "#ff4e0f");
            $btnPreview.style.color = readVal($btx, "#ffffff");
            const rad = parseInt(readVal($br, 20), 10);
            $btnPreview.style.borderRadius = (isNaN(rad) ? 20 : rad) + "px";
            $btnPreview.style.borderColor = "transparent";
            $btnPreview.style.borderWidth = "1px";
            $btnPreview.style.borderStyle = "solid";
        }
        const hov = readVal($bfgH, "#e3450e");
        if ($styleTag) {
            $styleTag.textContent =
                "#form-style-preview .btn-preview:hover{background:" + hov + " !important;}";
        }
    };

    const debounce = (fn, ms = 400) => {
        let t;
        return (...args) => {
            clearTimeout(t);
            t = setTimeout(() => fn.apply(null, args), ms);
        };
    };

    const saveStyle = async () => {
        if (!API_URL) return;
        const payload = {
            style: {
                title_font_size_px: parseInt(readVal($fs, 24), 10),
                title_color: readVal($tc, "#111111"),
                btn_text_color: readVal($btx, "#ffffff"),
                btn_bg: readVal($bfg, "#ff4e0f"),
                btn_bg_hover: readVal($bfgH, "#e3450e"),
                btn_radius_px: parseInt(readVal($br, 20), 10),
            },
        };
        try {
            const res = await fetch(API_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Requested-With": "XMLHttpRequest",
                    "X-CSRFToken": getCookie("csrftoken"),
                },
                credentials: "same-origin",
                body: JSON.stringify(payload),
            });
            if (!res.ok) {
                const txt = await res.text().catch(() => "");
                if ($feedback)
                    $feedback.textContent = "Erreur d'enregistrement" + (txt ? ` : ${txt}` : "");
                return;
            }
            if ($feedback) {
                $feedback.textContent = "Style enregistré ✔︎";
                setTimeout(() => {
                    $feedback.textContent = "";
                }, 1200);
            }
        } catch {
            if ($feedback) $feedback.textContent = "Erreur réseau";
        }
    };
    const saveStyleDebounced = debounce(saveStyle, 400);

    const bindInputs = () => {
        [$fs, $tc, $bfg, $bfgH, $btx, $br].forEach((el) => {
            if (!el) return;
            el.addEventListener("input", () => {
                paintPreview();
                saveStyleDebounced();
            });
            el.addEventListener("change", () => {
                paintPreview();
                saveStyleDebounced();
            });
        });
    };

    const initFromAPI = async () => {
        if (!API_URL) {
            paintPreview();
            bindInputs();
            return;
        }
        try {
            const res = await fetch(API_URL, { headers: { "X-Requested-With": "XMLHttpRequest" } });
            if (res.ok) {
                const data = await res.json();
                const st = data.style || {};
                if ($fs && st.title_font_size_px != null) $fs.value = st.title_font_size_px;
                if ($tc && st.title_color) $tc.value = st.title_color;
                if ($btx && st.btn_text_color) $btx.value = st.btn_text_color;
                if ($bfg && st.btn_bg) $bfg.value = st.btn_bg;
                if ($bfgH && st.btn_bg_hover) $bfgH.value = st.btn_bg_hover;
                if ($br && st.btn_radius_px != null) $br.value = st.btn_radius_px;
            }
        } catch {}
        paintPreview();
        bindInputs();
    };

    initFromAPI();
};

/* ——— Exposer pour les onclick du template ——— */
window.showAddFieldForm = showAddFieldForm; // alias inline
window.editField = editField;
window.deleteField = deleteField;
window.moveFieldUp = moveFieldUp;
window.moveFieldDown = moveFieldDown;
window.reloadFieldsList = reloadFieldsList;

// ===================== Exports globaux ======================

window.createSection = createSection;
window.editSection = editSection;
window.removeSection = removeSection;
window.moveSectionUp = moveSectionUp;
window.moveSectionDown = moveSectionDown;
window.makeSectionModel = makeSectionModel;

window.createLine = createLine;
window.editLine = editLine;
window.removeLine = removeLine;
window.moveLineUp = moveLineUp;
window.moveLineDown = moveLineDown;
window.makeLineModel = makeLineModel;

window.chooseContentType = chooseContentType;
window.editContent = editContent;
window.resetContent = resetContent;
window.showEditingParameters = showEditingParameters;
window.makeBlocModel = makeBlocModel;
window.addBloc = addBloc;
window.removeBloc = removeBloc;
window.moveBlocUp = moveBlocUp;
window.moveBlocDown = moveBlocDown;
window.moveBlocLeft = moveBlocLeft;
window.moveBlocRight = moveBlocRight;

window.showAddFieldForm = showAddFieldForm;
window.closeFieldForm = closeFieldForm;
window.deleteField = deleteField;
window.moveFieldUp = moveFieldUp;
window.moveFieldDown = moveFieldDown;
window.reloadFieldsList = reloadFieldsList;

// utile pour debug
window.reinitUI = reinitUI;

document.addEventListener("DOMContentLoaded", () => {
    reinitUI(document);
});
