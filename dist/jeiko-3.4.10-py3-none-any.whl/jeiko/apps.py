from django.apps import AppConfig


class AdministrationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko'
    label = "jeiko"

    def ready(self):
        # Contrôle d'installation complète : JEIKO s'installe entier ou pas du
        # tout (cf. jeiko/checks.py et ARCHITECTURE.md).
        from . import checks  # noqa: F401

        # Plafond de Pillow abaissé à 25 Mpx (S-10). Posé ici, à un moment
        # connu : c'est une variable globale de la bibliothèque, la laisser
        # dépendre de l'ordre des imports reviendrait à ne pas savoir si elle
        # est en vigueur. Voir jeiko/uploads.py.
        from .uploads import appliquer_les_limites_pillow

        appliquer_les_limites_pillow()
