from django.core.management.base import BaseCommand

from jeiko.emailing.builder import apply_all_seeds, apply_seed
from jeiko.emailing.seeds import seeded_codes

LABELS = {
    "created": "créé",
    "reset": "réinitialisé",
    "skipped": "inchangé (contenu déjà présent)",
    "no_seed": "aucun contenu par défaut déclaré",
}


class Command(BaseCommand):
    help = (
        "Pose les contenus par défaut des e-mails. "
        "Idempotente : sans --force, les e-mails ayant déjà un contenu sont laissés tels quels."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--code",
            help="Ne traiter qu'un seul e-mail (ex : password_reset_request).",
        )
        parser.add_argument(
            "--force",
            action="store_true",
            help="Remplacer le contenu existant. L'ancienne page est archivée, pas supprimée.",
        )
        parser.add_argument(
            "--list",
            action="store_true",
            help="Lister les codes disposant d'un contenu par défaut.",
        )

    def handle(self, *args, **options):
        if options["list"]:
            for code in seeded_codes():
                self.stdout.write(f"  {code}")
            self.stdout.write(f"\n{len(seeded_codes())} contenu(s) par défaut déclaré(s).")
            return

        if options["code"]:
            outcome = apply_seed(options["code"], force=options["force"])
            message = f"{options['code']} : {LABELS.get(outcome, outcome)}"

            if outcome == "no_seed":
                self.stdout.write(self.style.WARNING(message))
            elif outcome == "skipped":
                self.stdout.write(message)
                self.stdout.write("Utilisez --force pour écraser le contenu existant.")
            else:
                self.stdout.write(self.style.SUCCESS(message))
            return

        results = apply_all_seeds(force=options["force"])

        for outcome in ("created", "reset", "skipped", "no_seed"):
            codes = results.get(outcome)
            if not codes:
                continue

            line = f"{len(codes)} {LABELS[outcome]}"
            if outcome in ("created", "reset"):
                self.stdout.write(self.style.SUCCESS(line))
            else:
                self.stdout.write(line)

            for code in codes:
                self.stdout.write(f"    {code}")
