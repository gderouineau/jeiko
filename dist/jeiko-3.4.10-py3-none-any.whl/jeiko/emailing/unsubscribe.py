# jeiko/emailing/unsubscribe.py
"""
Désinscription des e-mails marketing.

Le catalogue déclarait déjà la variable `lien_desabonnement` — « obligatoire sur
le marketing » — et le gabarit d'e-mail affichait le lien. Mais **rien ne
renseignait jamais cette variable, et aucune vue de désinscription n'existait** :
le lien partait avec une adresse vide, ramenant le lecteur sur la page d'accueil.

Le jeton plutôt que la connexion
--------------------------------
Se désinscrire ne doit **jamais** exiger de se connecter : la personne qui veut
partir n'a pas à retrouver un mot de passe pour y arriver, et beaucoup de
destinataires n'ont pas de compte. On signe donc un jeton, porté par l'URL.

`django.core.signing` convient exactement : le jeton est infalsifiable sans la
`SECRET_KEY`, il porte lui-même l'identité du destinataire, et il expire. Rien
à stocker.

⚠️ Un jeton nominatif dans une URL se retrouve dans les journaux de serveur et
dans le `Referer`. C'est pourquoi il ne donne **qu'un seul pouvoir** : couper
les envois marketing. Il n'authentifie pas, n'ouvre aucune session, et ne permet
ni de lire ni de modifier quoi que ce soit d'autre.
"""

import logging

from django.core import signing

logger = logging.getLogger(__name__)

#: Espace de signature : un jeton de désinscription ne peut pas être réutilisé
#: comme jeton d'autre chose.
SEL = "jeiko.emailing.unsubscribe"

#: Durée de validité. Large à dessein — un e-mail se lit parfois des mois plus
#: tard, et refuser une désinscription pour péremption serait absurde.
DUREE_VALIDITE = 60 * 60 * 24 * 365


def build_token(email, user=None):
    """Jeton signé identifiant le destinataire."""
    charge = {"email": (email or "").strip().lower()}
    if getattr(user, "pk", None):
        charge["uid"] = user.pk
    return signing.dumps(charge, salt=SEL)


def read_token(token):
    """
    Retourne la charge du jeton, ou None s'il est invalide ou périmé.

    Ne lève jamais : un jeton tordu doit donner une page « lien invalide », pas
    une erreur serveur.
    """
    try:
        return signing.loads(token, salt=SEL, max_age=DUREE_VALIDITE)
    except signing.BadSignature:
        return None
    except Exception:
        logger.exception("Jeton de désinscription illisible")
        return None


def build_url(email, user=None, request=None):
    """URL absolue de désinscription, à injecter dans `lien_desabonnement`."""
    from django.urls import NoReverseMatch, reverse

    from .render import site_base_url

    if not email:
        return ""
    try:
        chemin = reverse("jeiko_client_emailing:unsubscribe",
                         kwargs={"token": build_token(email, user)})
    except NoReverseMatch:
        logger.error("Route de désinscription introuvable : lien vide dans les e-mails.")
        return ""

    base = site_base_url()
    return f"{base}{chemin}" if base else chemin


def unsubscribe(email, user=None):
    """
    Coupe les envois marketing. Retourne True si quelque chose a changé.

    Deux cas, traités ensemble : le destinataire a un compte (on éteint sa
    préférence) ou non (on ne peut agir que sur les prospects portant cette
    adresse).
    """
    from jeiko.users.models import MarketingPreference

    email = (email or "").strip().lower()
    modifie = False

    comptes = []
    if getattr(user, "pk", None):
        comptes.append(user)
    else:
        from django.contrib.auth import get_user_model

        comptes = list(get_user_model().objects.filter(email__iexact=email))

    # Note sur les destinataires SANS compte : il n'y en a pas.
    # `services._marketing_allowed` refuse tout envoi marketing dès lors que
    # `user is None`. Un prospect anonyme ne reçoit donc jamais de marketing, et
    # il n'y a rien à couper pour lui. C'est heureux, car son consentement est
    # enregistré sur une clé de session (`Consent.anonymous_key`) et non sur son
    # adresse : il serait introuvable depuis un lien d'e-mail.
    from jeiko.users.models import Consent, ConsentType

    for compte in comptes:
        preference, _ = MarketingPreference.objects.get_or_create(user=compte)
        if preference.email_optin:
            preference.email_optin = False
            preference.save(update_fields=["email_optin", "updated_at"])
            modifie = True

        # Trace du retrait : le consentement se prouve dans les deux sens, et
        # c'est cette ligne qui atteste qu'on a cessé d'écrire à quelqu'un.
        Consent.objects.create(
            user=compte,
            consent_type=ConsentType.MARKETING,
            granted=False,
            source="email:unsubscribe",
        )

    return modifie
