# jeiko/emailing/seeds.py
"""
Contenus par défaut des e-mails.

Source unique du contenu initial ET du « retour à la version par défaut » : la
commande `seed_email_templates` et le bouton de réinitialisation lisent ce même
fichier. Une déclaration améliorée ici profite donc aux installations existantes,
ce qu'une migration de données — jouée une seule fois — ne permettrait pas.

Format d'une déclaration :

    "code_evenement": {
        "title":   titre de la page de contenu, visible en administration,
        "subject": sujet de l'e-mail (accepte les [%cle%]),
        "lines": [
            {"cols": "12", "blocs": [{"type": "TEXT", "text": "<p>…</p>"}]},
            {"cols": "12", "blocs": [{"type": "BUTTON", "label": "…", "url": "[%lien_action%]",
                                      "align": "center"}]},
            {"cols": "6-6", "blocs": [{…}, {…}]},
        ],
    }

Seules les clés déclarées par l'événement dans registry.py sont utilisables ;
les variables globales ([%prenom%], [%site_nom%]…) le sont partout.
"""

# Style récurrent : mention légère en bas de message.
NOTE = 'font-size:13px;color:#888888;'

EMAIL_SEEDS = {

    # =========================
    #  Compte & sécurité
    # =========================

    "account_welcome": {
        "title": "Mail — Bienvenue",
        "subject": "Bienvenue sur [%site_nom%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bienvenue [%prenom%],</h1>"
                        "<p>Votre compte est créé. Vous pouvez dès maintenant accéder "
                        "à votre espace personnel.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Accéder à mon espace", "url": "[%lien_action%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Une question ? Répondez simplement à ce message.</p>',
            }]},
        ],
    },

    "account_email_verify": {
        "title": "Mail — Vérification de l'adresse e-mail",
        "subject": "[%site_nom%] — Confirmez votre adresse e-mail",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Confirmez votre adresse e-mail pour activer votre compte.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Confirmer mon adresse", "url": "[%lien_action%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Ce lien est valable [%expiration%]. '
                        "Si vous n'êtes pas à l'origine de cette demande, ignorez ce message.</p>",
            }]},
        ],
    },

    "password_reset_request": {
        "title": "Mail — Réinitialisation du mot de passe",
        "subject": "[%site_nom%] — Réinitialisez votre mot de passe",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Vous avez demandé la réinitialisation de votre mot de passe. "
                        "Cliquez sur le bouton ci-dessous pour en choisir un nouveau.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Choisir un nouveau mot de passe", "url": "[%lien_action%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Ce lien expire dans [%expiration%]. '
                        "Si vous n'êtes pas à l'origine de cette demande, ignorez ce message : "
                        "votre mot de passe reste inchangé.</p>",
            }]},
        ],
    },

    "password_changed": {
        "title": "Mail — Mot de passe modifié",
        "subject": "[%site_nom%] — Votre mot de passe a été modifié",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 16px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre mot de passe a été modifié le [%date_heure%].</p>"
                        "<p>Connexion depuis <strong>[%appareil%]</strong> ([%ip%]).</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Si vous n\'êtes pas à l\'origine de ce changement, '
                        "contactez-nous immédiatement.</p>",
            }]},
        ],
    },

    "account_created_by_admin": {
        "title": "Mail — Compte créé par l'administrateur",
        "subject": "[%site_nom%] — Votre compte a été créé",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Un compte vient d'être créé pour vous sur [%site_nom%]. "
                        "Définissez votre mot de passe pour y accéder.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Définir mon mot de passe", "url": "[%lien_action%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Ce lien est valable [%expiration%].</p>',
            }]},
        ],
    },

    "email_change_confirm": {
        "title": "Mail — Confirmation de la nouvelle adresse",
        "subject": "[%site_nom%] — Confirmez votre nouvelle adresse e-mail",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Vous avez demandé à utiliser <strong>[%nouvel_email%]</strong> "
                        "comme nouvelle adresse de connexion. Confirmez-la pour rendre "
                        "le changement effectif.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Confirmer cette adresse", "url": "[%lien_action%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Ce lien est valable [%expiration%]. Sans '
                        "confirmation, votre adresse actuelle reste inchangée.</p>",
            }]},
        ],
    },

    "email_changed_alert": {
        "title": "Mail — Alerte de changement d'adresse",
        "subject": "[%site_nom%] — L'adresse de votre compte a été modifiée",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 16px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>L'adresse e-mail de votre compte a été remplacée par "
                        "<strong>[%nouvel_email%]</strong> le [%date_heure%].</p>"
                        "<p>Ce message est envoyé à votre ancienne adresse, à titre "
                        "d'information.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Si vous n\'êtes pas à l\'origine de ce '
                        "changement, contactez-nous immédiatement : votre compte est "
                        "peut-être compromis.</p>",
            }]},
        ],
    },

    "twofa_code": {
        "title": "Mail — Code de double authentification",
        "subject": "[%site_nom%] — Votre code de connexion",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Votre code de connexion</h1>"
                        "<p>Saisissez ce code pour terminer votre connexion.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "16px 24px 16px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": '<p style="font-size:32px;letter-spacing:6px;font-weight:700;'
                        'text-align:center;margin:0;">[%code%]</p>',
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Ce code expire dans [%expiration%]. '
                        "Ne le communiquez à personne : aucun membre de notre équipe "
                        "ne vous le demandera.</p>",
            }]},
        ],
    },

    "twofa_enabled": {
        "title": "Mail — Double authentification activée",
        "subject": "[%site_nom%] — Double authentification activée",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 16px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>La double authentification a été activée sur votre compte "
                        "le [%date_heure%], via <strong>[%methode%]</strong>.</p>"
                        "<p>Vos prochaines connexions demanderont un code en plus de "
                        "votre mot de passe.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Si vous n\'êtes pas à l\'origine de cette '
                        "activation, contactez-nous.</p>",
            }]},
        ],
    },

    "twofa_disabled": {
        "title": "Mail — Double authentification désactivée",
        "subject": "[%site_nom%] — Double authentification désactivée",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 16px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>La double authentification a été désactivée sur votre compte "
                        "le [%date_heure%]. Votre compte n'est plus protégé par un "
                        "second facteur.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Si vous n\'êtes pas à l\'origine de cette '
                        "désactivation, changez votre mot de passe sans attendre et "
                        "contactez-nous.</p>",
            }]},
        ],
    },

    "login_new_device": {
        "title": "Mail — Connexion depuis un nouvel appareil",
        "subject": "[%site_nom%] — Nouvelle connexion à votre compte",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Une connexion à votre compte vient d'avoir lieu depuis un "
                        "appareil que nous ne connaissions pas.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 16px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Date :</strong> [%date_heure%]<br>"
                        "<strong>Appareil :</strong> [%appareil%]<br>"
                        "<strong>Adresse IP :</strong> [%ip%]<br>"
                        "<strong>Localisation :</strong> [%localisation%]</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Si c\'est bien vous, il n\'y a rien à faire. '
                        "Sinon, changez votre mot de passe immédiatement.</p>",
            }]},
        ],
    },

    "account_locked": {
        "title": "Mail — Compte temporairement bloqué",
        "subject": "[%site_nom%] — Accès à votre compte temporairement bloqué",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Après plusieurs tentatives de connexion infructueuses, "
                        "l'accès à votre compte est suspendu pendant "
                        "<strong>[%duree_blocage%]</strong>.</p>"
                        "<p>Si vous avez oublié votre mot de passe, vous pouvez en "
                        "définir un nouveau dès maintenant.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Réinitialiser mon mot de passe", "url": "[%lien_action%]",
            }]},
        ],
    },

    "account_deactivated": {
        "title": "Mail — Compte désactivé",
        "subject": "[%site_nom%] — Votre compte a été désactivé",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 16px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre compte a été désactivé le [%date_heure%]. Vos accès "
                        "sont désormais clos.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Une question sur cette décision ? '
                        "Répondez simplement à ce message.</p>",
            }]},
        ],
    },

    "rgpd_data_export_ready": {
        "title": "Mail — Export de données prêt",
        "subject": "[%site_nom%] — Votre export de données est disponible",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>L'export des données personnelles que vous avez demandé "
                        "est prêt.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Télécharger mes données", "url": "[%lien_action%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Ce lien est valable [%expiration%]. '
                        "Passé ce délai, il faudra renouveler la demande.</p>",
            }]},
        ],
    },

    # =========================
    #  Rendez-vous
    # =========================

    "appointment_confirmed": {
        "title": "Mail — Confirmation de rendez-vous",
        "subject": "[%site_nom%] — Votre rendez-vous du [%rdv_date%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre rendez-vous est confirmé.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 8px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Date :</strong> [%rdv_date%] à [%rdv_heure%]<br>"
                        "<strong>Durée :</strong> [%rdv_duree%]<br>"
                        "<strong>Type :</strong> [%rdv_type%]<br>"
                        "<strong>Avec :</strong> [%pro_nom%]<br>"
                        "<strong>Lieu :</strong> [%lieu%]</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": "<p>Un empêchement ? Vous pouvez annuler ou déplacer votre "
                        "rendez-vous depuis le lien ci-dessous.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Modifier ou annuler", "url": "[%lien_annulation%]",
                "background_color": "#666666",
            }]},
        ],
    },

    "appointment_admin_new": {
        "title": "Mail — Nouvelle réservation (praticien)",
        "subject": "[%site_nom%] — Nouvelle réservation le [%rdv_date%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Nouvelle réservation</h1>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 24px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Date :</strong> [%rdv_date%] à [%rdv_heure%]<br>"
                        "<strong>Durée :</strong> [%rdv_duree%]<br>"
                        "<strong>Type :</strong> [%rdv_type%]</p>"
                        "<p><strong>Client :</strong> [%client_nom%]<br>"
                        "<strong>E-mail :</strong> [%client_email%]<br>"
                        "<strong>Téléphone :</strong> [%client_tel%]</p>"
                        "<p><strong>Référence interne :</strong> [%rdv_id%]</p>",
            }]},
        ],
    },

    "appointment_reminder_24h": {
        "title": "Mail — Rappel de rendez-vous (24 h)",
        "subject": "[%site_nom%] — Rappel : rendez-vous demain à [%rdv_heure%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Petit rappel : votre rendez-vous a lieu demain.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 8px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>[%rdv_date%] à [%rdv_heure%]</strong><br>"
                        "[%rdv_type%] — [%rdv_duree%]<br>"
                        "Avec [%pro_nom%]<br>"
                        "[%lieu%]</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Modifier ou annuler", "url": "[%lien_annulation%]",
                "background_color": "#666666",
            }]},
        ],
    },

    "appointment_cancelled_client": {
        "title": "Mail — Annulation par le client",
        "subject": "[%site_nom%] — Votre rendez-vous du [%rdv_date%] est annulé",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre rendez-vous du <strong>[%rdv_date%] à [%rdv_heure%]</strong> "
                        "([%rdv_type%]) a bien été annulé.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Prendre un nouveau rendez-vous", "url": "[%lien_action%]",
            }]},
        ],
    },

    "appointment_cancelled_pro": {
        "title": "Mail — Annulation par le praticien",
        "subject": "[%site_nom%] — Votre rendez-vous du [%rdv_date%] est annulé",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Nous sommes contraints d'annuler votre rendez-vous du "
                        "<strong>[%rdv_date%] à [%rdv_heure%]</strong> ([%rdv_type%]).</p>"
                        "<p>Motif : [%motif%]</p>"
                        "<p>Toutes nos excuses pour ce contretemps. Vous pouvez choisir "
                        "un nouveau créneau dès maintenant.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Choisir un nouveau créneau", "url": "[%lien_action%]",
            }]},
        ],
    },

    "appointment_reminder_2h": {
        "title": "Mail — Rappel de rendez-vous (2 h)",
        "subject": "[%site_nom%] — Votre rendez-vous à [%rdv_heure%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>C'est bientôt</h1>"
                        "<p>Votre [%rdv_type%] commence à <strong>[%rdv_heure%]</strong>.</p>"
                        "<p>[%lieu%]</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Rejoindre en visioconférence", "url": "[%lien_visio%]",
            }]},
        ],
    },

    "appointment_rescheduled": {
        "title": "Mail — Rendez-vous déplacé",
        "subject": "[%site_nom%] — Votre rendez-vous a été déplacé",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre rendez-vous [%rdv_type%] avec [%pro_nom%] a été "
                        "déplacé.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 16px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": '<p style="color:#888888;text-decoration:line-through;">'
                        "[%ancienne_date%] à [%ancienne_heure%]</p>"
                        "<p><strong>Nouvelle date : [%rdv_date%] à [%rdv_heure%]</strong></p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Modifier ou annuler", "url": "[%lien_annulation%]",
                "background_color": "#666666",
            }]},
        ],
    },

    "appointment_payment_pending": {
        "title": "Mail — Rendez-vous en attente de paiement",
        "subject": "[%site_nom%] — Réglez votre rendez-vous du [%rdv_date%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre créneau du <strong>[%rdv_date%] à [%rdv_heure%]</strong> "
                        "est réservé, mais le règlement de [%montant%] n'a pas encore "
                        "été enregistré.</p>"
                        "<p>Le créneau vous est conservé pendant [%expiration%].</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Régler mon rendez-vous", "url": "[%lien_action%]",
            }]},
        ],
    },

    "appointment_followup": {
        "title": "Mail — Suivi après rendez-vous",
        "subject": "[%site_nom%] — Merci pour votre venue",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Merci [%prenom%],</h1>"
                        "<p>Nous espérons que votre rendez-vous du [%rdv_date%] avec "
                        "[%pro_nom%] s'est bien passé.</p>"
                        "<p>Les documents évoqués sont disponibles ici : "
                        "[%lien_documents%]</p>"
                        "<p>Votre retour nous aide à nous améliorer — il ne prend "
                        "qu'une minute.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Donner mon avis", "url": "[%lien_action%]",
            }]},
        ],
    },

    "appointment_no_show": {
        "title": "Mail — Absence au rendez-vous",
        "subject": "[%site_nom%] — Nous ne vous avons pas vu",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Nous vous attendions le <strong>[%rdv_date%] à "
                        "[%rdv_heure%]</strong> et n'avons pas eu le plaisir de vous "
                        "recevoir.</p>"
                        "<p>Un imprévu ? Vous pouvez reprendre rendez-vous quand vous "
                        "le souhaitez.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Reprendre rendez-vous", "url": "[%lien_action%]",
            }]},
        ],
    },

    "appointment_reminder_pro_1h": {
        "title": "Mail — Rappel praticien (1 h avant)",
        "subject": "[%site_nom%] — Rendez-vous dans 1 h : [%client_nom%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Rendez-vous dans 1 h</h1>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 24px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>[%rdv_heure%]</strong> — [%rdv_type%] "
                        "([%rdv_duree%])<br>"
                        "<strong>Client :</strong> [%client_nom%]<br>"
                        "<strong>E-mail :</strong> [%client_email%]<br>"
                        "<strong>Lieu :</strong> [%lieu%]</p>",
            }]},
        ],
    },

    "appointment_daily_digest_pro": {
        "title": "Mail — Récapitulatif quotidien (praticien)",
        "subject": "[%site_nom%] — Vos rendez-vous du [%date_cible%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Rendez-vous du [%date_cible%]</h1>"
                        "<p>[%nombre_rdv%] rendez-vous à votre agenda.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 24px 24px",
                "text": "[%bloc_rdv%]",
            }]},
        ],
    },

    "appointment_waitlist_available": {
        "title": "Mail — Liste d'attente : une place s'est libérée",
        "subject": "[%site_nom%] — Une place s'est libérée le [%rdv_date%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Une place vient de se libérer pour "
                        "<strong>[%rdv_type%]</strong> le "
                        "<strong>[%rdv_date%] à [%rdv_heure%]</strong>.</p>"
                        "<p>Vous étiez en liste d'attente : la place vous est réservée "
                        "jusqu'à <strong>[%expiration%]</strong>. Passé ce délai, elle "
                        "sera proposée à la personne suivante.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 8px 24px",
                "label": "Réserver cette place", "url": "[%lien_action%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "0 24px 24px 24px",
                "text": "<p style='font-size:12px;color:#888;'>"
                        "Vous ne souhaitez plus être prévenu ? "
                        "<a href='[%lien_desinscription%]'>Quitter la liste d'attente</a>.</p>",
            }]},
        ],
    },

    "appointment_refunded": {
        "title": "Mail — Rendez-vous remboursé",
        "subject": "[%site_nom%] — Remboursement de votre rendez-vous du [%rdv_date%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 24px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre rendez-vous <strong>[%rdv_type%]</strong> du "
                        "<strong>[%rdv_date%] à [%rdv_heure%]</strong> a été annulé.</p>"
                        "<p>Un remboursement de <strong>[%montant%]</strong> a été émis. "
                        "Selon votre banque, il peut mettre quelques jours à apparaître "
                        "sur votre relevé.</p>",
            }]},
        ],
    },

    # =========================
    #  Questionnaires & tests
    # =========================

    "test_access_granted": {
        "title": "Mail — Accès au test accordé",
        "subject": "[%site_nom%] — Votre accès à « [%test_nom%] »",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre accès au test <strong>[%test_nom%]</strong> est ouvert. "
                        "Vous pouvez le passer quand vous le souhaitez.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Commencer le test", "url": "[%lien_action%]",
            }]},
        ],
    },

    "test_completed_results": {
        "title": "Mail — Résultats du test",
        "subject": "[%site_nom%] — Vos résultats : [%test_nom%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Merci d'avoir complété <strong>[%test_nom%]</strong>. "
                        "Voici votre résultat.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "16px 24px 16px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Profil :</strong> [%profil%]<br>"
                        "<strong>Score :</strong> [%score%]</p>"
                        "<p>[%profil_description%]</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 8px 24px",
                "text": "[%bloc_resultats%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Voir le rapport complet", "url": "[%lien_resultats%]",
            }]},
        ],
    },

    "test_results_admin": {
        "title": "Mail — Résultats du test (praticien)",
        "subject": "[%site_nom%] — [%client_nom%] a terminé « [%test_nom%] »",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Test terminé</h1>"
                        "<p><strong>[%client_nom%]</strong> ([%client_email%]) vient de "
                        "compléter <strong>[%test_nom%]</strong>.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 16px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Profil :</strong> [%profil%]<br>"
                        "<strong>Score :</strong> [%score%]</p>"
                        "[%bloc_resultats%]",
            }]},
            {"cols": "6-6", "blocs": [
                {"type": "BUTTON", "align": "center",
                 "bloc_padding": "8px 12px 24px 24px",
                 "label": "Fiche du répondant", "url": "[%lien_prospect%]"},
                {"type": "BUTTON", "align": "center",
                 "bloc_padding": "8px 24px 24px 12px",
                 "label": "Détail du test", "url": "[%lien_testdata%]",
                 "background_color": "#666666"},
            ]},
        ],
    },

    "test_invitation": {
        "title": "Mail — Invitation à passer le test",
        "subject": "[%site_nom%] — Vous êtes invité à passer « [%test_nom%] »",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour,</h1>"
                        "<p>Vous êtes invité à passer le test "
                        "<strong>[%test_nom%]</strong>. Comptez environ "
                        "[%duree_estimee%], sans création de compte.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Commencer le test", "url": "[%lien_action%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Ce lien vous est personnel et reste valable '
                        "[%expiration%].</p>",
            }]},
        ],
    },

    "test_abandoned_reminder": {
        "title": "Mail — Relance test non terminé",
        "subject": "[%site_nom%] — Votre test « [%test_nom%] » vous attend",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Vous avez commencé <strong>[%test_nom%]</strong> sans "
                        "le terminer — vous en êtes à [%progression%].</p>"
                        "<p>Vos réponses sont enregistrées : vous reprendrez là où "
                        "vous vous êtes arrêté.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Reprendre le test", "url": "[%lien_action%]",
            }]},
        ],
    },

    "prospect_captured_admin": {
        "title": "Mail — Nouveau prospect (administrateur)",
        "subject": "[%site_nom%] — Nouveau prospect : [%client_nom%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Nouveau prospect</h1>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 16px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Nom :</strong> [%client_nom%]<br>"
                        "<strong>E-mail :</strong> [%client_email%]<br>"
                        "<strong>Téléphone :</strong> [%client_tel%]<br>"
                        "<strong>Origine :</strong> [%origine%]</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Voir la fiche", "url": "[%lien_action%]",
            }]},
        ],
    },

    "test_retake_reminder": {
        "title": "Mail — Invitation à repasser le test",
        "subject": "[%site_nom%] — Et si vous repassiez « [%test_nom%] » ?",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Vous aviez passé <strong>[%test_nom%]</strong> le "
                        "[%date_dernier_passage%]. Les choses évoluent : refaire le "
                        "test permet de mesurer le chemin parcouru.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Repasser le test", "url": "[%lien_action%]",
            }]},
        ],
    },

    # =========================
    #  Formations
    # =========================

    "course_enrolled": {
        "title": "Mail — Inscription à la formation",
        "subject": "[%site_nom%] — Votre inscription à « [%formation_nom%] »",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre inscription à <strong>[%formation_nom%]</strong> est "
                        "confirmée. La formation compte [%nombre_chapitres%] chapitres, "
                        "à suivre à votre rythme.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Commencer la formation", "url": "[%lien_action%]",
            }]},
        ],
    },

    "course_access_granted_admin": {
        "title": "Mail — Accès formation accordé",
        "subject": "[%site_nom%] — Accès à « [%formation_nom%] »",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>L'accès à la formation <strong>[%formation_nom%]</strong> "
                        "vient de vous être ouvert.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Accéder à la formation", "url": "[%lien_action%]",
            }]},
        ],
    },

    "course_completed": {
        "title": "Mail — Formation terminée",
        "subject": "[%site_nom%] — Félicitations, vous avez terminé « [%formation_nom%] »",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Félicitations [%prenom%] !</h1>"
                        "<p>Vous avez terminé <strong>[%formation_nom%]</strong> "
                        "le [%date_fin%]. Votre attestation est disponible.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Télécharger mon attestation", "url": "[%lien_attestation%]",
            }]},
        ],
    },

    "course_suspended": {
        "title": "Mail — Accès formation suspendu",
        "subject": "[%site_nom%] — Votre accès à « [%formation_nom%] » est suspendu",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 16px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre accès à la formation <strong>[%formation_nom%]</strong> "
                        "a été suspendu.</p>"
                        "<p>Motif : [%motif%]</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Votre progression est conservée. '
                        "Répondez à ce message pour en discuter.</p>",
            }]},
        ],
    },

    "course_new_content": {
        "title": "Mail — Nouveau contenu publié",
        "subject": "[%site_nom%] — Du nouveau dans « [%formation_nom%] »",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p><strong>[%contenu_nom%]</strong> vient d'être ajouté à la "
                        "formation [%formation_nom%], à laquelle vous êtes inscrit.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Découvrir le nouveau contenu", "url": "[%lien_action%]",
            }]},
        ],
    },

    "course_progress_stalled": {
        "title": "Mail — Relance progression à l'arrêt",
        "subject": "[%site_nom%] — Reprenez « [%formation_nom%] » où vous en étiez",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Cela fait [%jours_inactivite%] jours que vous n'avez pas "
                        "avancé sur <strong>[%formation_nom%]</strong>. Vous en êtes "
                        "à [%progression%].</p>"
                        "<p>Quelques minutes suffisent pour reprendre le fil.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Reprendre la formation", "url": "[%lien_action%]",
            }]},
        ],
    },

    "quiz_passed": {
        "title": "Mail — Quiz réussi",
        "subject": "[%site_nom%] — Quiz réussi : [%quiz_nom%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bravo [%prenom%] !</h1>"
                        "<p>Vous avez réussi le quiz <strong>[%quiz_nom%]</strong> "
                        "avec un score de [%score%], dans la formation "
                        "[%formation_nom%].</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Continuer la formation", "url": "[%lien_action%]",
            }]},
        ],
    },

    "quiz_failed": {
        "title": "Mail — Quiz échoué",
        "subject": "[%site_nom%] — Résultat du quiz [%quiz_nom%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Vous avez obtenu <strong>[%score%]</strong> au quiz "
                        "[%quiz_nom%], alors que [%score_requis%] sont nécessaires "
                        "pour le valider.</p>"
                        "<p>Rien d'irrémédiable : relisez le chapitre et retentez "
                        "votre chance.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Retenter le quiz", "url": "[%lien_action%]",
            }]},
        ],
    },

    # =========================
    #  Boutique & paiements
    # =========================

    "order_confirmation": {
        "title": "Mail — Confirmation de commande",
        "subject": "[%site_nom%] — Commande [%commande_num%] confirmée",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Merci [%prenom%],</h1>"
                        "<p>Votre commande <strong>[%commande_num%]</strong> du "
                        "[%commande_date%] est confirmée.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 8px 24px",
                "text": "[%bloc_lignes%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 16px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Total : [%commande_total%]</strong></p>"
                        "<p><strong>Livraison :</strong><br>[%adresse_livraison%]</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Suivre ma commande", "url": "[%lien_action%]",
            }]},
        ],
    },

    "payment_received": {
        "title": "Mail — Paiement reçu",
        "subject": "[%site_nom%] — Paiement reçu pour la commande [%commande_num%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Nous avons bien reçu votre paiement de "
                        "<strong>[%montant%]</strong> par [%moyen_paiement%] pour la "
                        "commande [%commande_num%].</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Télécharger la facture", "url": "[%lien_facture%]",
            }]},
        ],
    },

    "payment_failed": {
        "title": "Mail — Échec du paiement",
        "subject": "[%site_nom%] — Échec du paiement de la commande [%commande_num%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Le paiement de <strong>[%montant%]</strong> pour la commande "
                        "[%commande_num%] n'a pas abouti.</p>"
                        "<p>Motif : [%motif%]</p>"
                        "<p>Votre commande est conservée : vous pouvez relancer le "
                        "paiement dès maintenant.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Relancer le paiement", "url": "[%lien_action%]",
            }]},
        ],
    },

    "order_admin_new": {
        "title": "Mail — Nouvelle commande (administrateur)",
        "subject": "[%site_nom%] — Nouvelle commande [%commande_num%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Nouvelle commande</h1>"
                        "<p><strong>[%commande_num%]</strong> — [%commande_total%]</p>"
                        "<p>Client : [%client_nom%] ([%client_email%])</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 8px 24px",
                "text": "[%bloc_lignes%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Voir en administration", "url": "[%lien_action%]",
            }]},
        ],
    },

    "order_shipped": {
        "title": "Mail — Commande expédiée",
        "subject": "[%site_nom%] — Votre commande [%commande_num%] est en route",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre commande <strong>[%commande_num%]</strong> vient "
                        "d'être expédiée.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 16px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Transporteur :</strong> [%transporteur%]<br>"
                        "<strong>Numéro de suivi :</strong> [%numero_suivi%]<br>"
                        "<strong>Livraison estimée :</strong> "
                        "[%date_livraison_estimee%]</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Suivre mon colis", "url": "[%lien_suivi%]",
            }]},
        ],
    },

    "order_cancelled": {
        "title": "Mail — Commande annulée",
        "subject": "[%site_nom%] — Votre commande [%commande_num%] a été annulée",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 16px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre commande <strong>[%commande_num%]</strong> "
                        "([%montant%]) a été annulée.</p>"
                        "<p>Motif : [%motif%]</p>"
                        "<p>Si un paiement avait été enregistré, il vous sera "
                        "intégralement remboursé.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Une question ? Répondez à ce message.</p>',
            }]},
        ],
    },

    "order_refunded": {
        "title": "Mail — Remboursement effectué",
        "subject": "[%site_nom%] — Remboursement de la commande [%commande_num%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 16px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Le remboursement de <strong>[%montant%]</strong> pour la "
                        "commande [%commande_num%] a été effectué sur "
                        "[%moyen_paiement%].</p>"
                        "<p>Le crédit apparaîtra sur votre relevé sous [%delai%], "
                        "selon votre établissement bancaire.</p>",
            }]},
        ],
    },

    "order_completed": {
        "title": "Mail — Commande terminée",
        "subject": "[%site_nom%] — Merci pour votre commande [%commande_num%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Merci [%prenom%],</h1>"
                        "<p>Votre commande <strong>[%commande_num%]</strong> est "
                        "clôturée. Nous espérons qu'elle vous donne satisfaction.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 8px 24px",
                "text": "[%bloc_lignes%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 8px 24px",
                "text": "<p>Votre avis aide les prochains acheteurs à se décider.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Donner mon avis", "url": "[%lien_action%]",
            }]},
        ],
    },

    "cart_abandoned": {
        "title": "Mail — Relance de panier",
        "subject": "[%site_nom%] — Votre panier vous attend",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Vous avez laissé des articles dans votre panier. "
                        "Ils vous attendent, pour un total de "
                        "<strong>[%panier_total%]</strong>.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 8px 24px",
                "text": "[%bloc_lignes%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Finaliser ma commande", "url": "[%lien_action%]",
            }]},
        ],
    },

    "product_back_in_stock": {
        "title": "Mail — Retour en stock",
        "subject": "[%site_nom%] — [%produit_nom%] est de retour",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonne nouvelle [%prenom%],</h1>"
                        "<p><strong>[%produit_nom%]</strong> est de nouveau "
                        "disponible, au prix de [%produit_prix%].</p>"
                        "<p>Les stocks sont limités : ne tardez pas.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Voir le produit", "url": "[%lien_action%]",
            }]},
        ],
    },

    "low_stock_admin": {
        "title": "Mail — Alerte stock bas (administrateur)",
        "subject": "[%site_nom%] — Stock bas : [%produit_nom%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Stock bas</h1>"
                        "<p><strong>[%produit_nom%]</strong> est passé sous le seuil "
                        "d'alerte.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 16px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Stock restant :</strong> [%stock_restant%]<br>"
                        "<strong>Seuil d'alerte :</strong> [%seuil%]</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Voir la fiche produit", "url": "[%lien_action%]",
            }]},
        ],
    },

    # =========================
    #  Site & formulaires
    # =========================

    "contact_form_admin": {
        "title": "Mail — Formulaire de contact (administrateur)",
        "subject": "[%site_nom%] — Message de [%expediteur_nom%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Nouveau message</h1>"
                        "<p>Formulaire : <strong>[%formulaire_nom%]</strong><br>"
                        "Page : [%page_origine%]</p>"
                        "<p>De : [%expediteur_nom%] ([%expediteur_email%])</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 24px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "[%bloc_reponses%]",
            }]},
        ],
    },

    "contact_form_receipt": {
        "title": "Mail — Accusé de réception (visiteur)",
        "subject": "[%site_nom%] — Nous avons bien reçu votre message",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Nous avons bien reçu votre message et vous répondrons "
                        "sous [%delai_reponse%].</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 16px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Rappel de votre message :</strong></p>"
                        "[%bloc_reponses%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Ce message est automatique, mais vous pouvez '
                        "y répondre directement.</p>",
            }]},
        ],
    },

    "newsletter_double_optin": {
        "title": "Mail — Confirmation d'inscription newsletter",
        "subject": "[%site_nom%] — Confirmez votre inscription",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Une dernière étape</h1>"
                        "<p>Confirmez votre adresse pour recevoir nos actualités. "
                        "Sans cette confirmation, vous ne recevrez rien.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Confirmer mon inscription", "url": "[%lien_action%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Ce lien est valable [%expiration%]. '
                        "Si vous n'avez rien demandé, ignorez ce message.</p>",
            }]},
        ],
    },

    "newsletter_welcome": {
        "title": "Mail — Bienvenue dans la newsletter",
        "subject": "[%site_nom%] — Bienvenue !",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 16px 24px",
                "text": "<h1>Bienvenue,</h1>"
                        "<p>Votre inscription est confirmée. Vous recevrez nos "
                        "actualités [%frequence%].</p>"
                        "<p>Nous écrivons peu, et seulement quand nous avons quelque "
                        "chose à dire.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "text": f'<p style="{NOTE}">Vous pouvez vous désinscrire à tout moment '
                        "depuis le lien en bas de chaque message.</p>",
            }]},
        ],
    },

    "newsletter_unsubscribe_confirm": {
        "title": "Mail — Confirmation de désinscription",
        "subject": "[%site_nom%] — Vous êtes désinscrit",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>C'est fait</h1>"
                        "<p>Vous ne recevrez plus nos actualités. Merci de nous avoir "
                        "suivis jusqu'ici.</p>"
                        "<p>Si c'était une erreur, un clic suffit à revenir.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Me réinscrire", "url": "[%lien_action%]",
                "background_color": "#666666",
            }]},
        ],
    },

    # =========================
    #  Interne & technique
    # =========================

    "smtp_test": {
        "title": "Mail — Test de configuration SMTP",
        "subject": "[%site_nom%] — Test de configuration du serveur mail",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Test de configuration</h1>"
                        "<p>Si vous lisez ce message, l'envoi d'e-mails fonctionne.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 24px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Serveur :</strong> [%serveur_smtp%]<br>"
                        "<strong>Utilisateur :</strong> [%utilisateur_smtp%]<br>"
                        "<strong>Date du test :</strong> [%date_heure%]</p>",
            }]},
        ],
    },
    "admin_new_user": {
        "title": "Mail — Nouvelle inscription (administrateur)",
        "subject": "[%site_nom%] — Nouvelle inscription : [%client_nom%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Nouvelle inscription</h1>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 16px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": "<p><strong>Nom :</strong> [%client_nom%]<br>"
                        "<strong>E-mail :</strong> [%client_email%]<br>"
                        "<strong>Inscrit le :</strong> [%date_heure%]</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Voir la fiche utilisateur", "url": "[%lien_action%]",
            }]},
        ],
    },

    "admin_daily_digest": {
        "title": "Mail — Récapitulatif quotidien (administrateur)",
        "subject": "[%site_nom%] — Récapitulatif du [%date_cible%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Récapitulatif du [%date_cible%]</h1>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 8px 24px",
                "text": "<h3>Rendez-vous</h3>[%bloc_rdv%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 8px 24px",
                "text": "<h3>Commandes</h3>[%bloc_commandes%]",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 24px 24px",
                "text": "<h3>Nouveaux prospects</h3>[%bloc_prospects%]",
            }]},
        ],
    },

    "admin_error_alert": {
        "title": "Mail — Alerte technique (administrateur)",
        "subject": "[%site_nom%] — Alerte technique : [%type_erreur%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Alerte technique</h1>"
                        "<p><strong>[%type_erreur%]</strong> — [%occurrences%] "
                        "occurrence(s), dernière le [%date_heure%].</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "8px 24px 24px 24px",
                "background_color": "rgba(245,245,245,1)",
                "text": '<p style="font-family:monospace;font-size:13px;">'
                        "[%detail_erreur%]</p>",
            }]},
        ],
    },

    # =========================
    #  Marketing & cycle de vie
    # =========================

    "birthday_wishes": {
        "title": "Mail — Anniversaire",
        "subject": "[%site_nom%] — Joyeux anniversaire [%prenom%] !",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Joyeux anniversaire [%prenom%] !</h1>"
                        "<p>Pour l'occasion, profitez du code "
                        "<strong>[%code_promo%]</strong>, valable [%expiration%].</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "En profiter", "url": "[%lien_action%]",
            }]},
        ],
    },

    "reactivation": {
        "title": "Mail — Réactivation",
        "subject": "[%site_nom%] — Cela fait un moment",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Votre dernière visite remonte au "
                        "[%date_derniere_visite%]. Beaucoup de choses ont changé "
                        "depuis — nous serions ravis de vous revoir.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Revenir sur le site", "url": "[%lien_action%]",
            }]},
        ],
    },

    "nps_survey": {
        "title": "Mail — Enquête de satisfaction",
        "subject": "[%site_nom%] — Votre avis en une minute",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>Bonjour [%prenom%],</h1>"
                        "<p>Suite à [%prestation_nom%], nous aimerions savoir ce que "
                        "vous en avez pensé. Une question, une minute.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "Donner mon avis", "url": "[%lien_action%]",
            }]},
        ],
    },

    "campaign_manual": {
        "title": "Mail — Campagne manuelle",
        "subject": "[%site_nom%] — [%titre_campagne%]",
        "lines": [
            {"cols": "12", "blocs": [{
                "type": "TEXT",
                "bloc_padding": "24px 24px 8px 24px",
                "text": "<h1>[%titre_campagne%]</h1>"
                        "<p>Ce modèle est un point de départ : remplacez ce texte par "
                        "le contenu de votre campagne, ajoutez images et boutons "
                        "depuis l'éditeur.</p>",
            }]},
            {"cols": "12", "blocs": [{
                "type": "BUTTON", "align": "center",
                "bloc_padding": "8px 24px 24px 24px",
                "label": "En savoir plus", "url": "[%lien_action%]",
            }]},
        ],
    },
}


def get_seed(code):
    return EMAIL_SEEDS.get(code)


def seeded_codes():
    return sorted(EMAIL_SEEDS.keys())
