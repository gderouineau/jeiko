from django.urls import path

from jeiko.emailing.views import client as client_views

app_name = "jeiko_client_emailing"

urlpatterns = [
    # Désinscription marketing. Sans connexion : le lien vient de l'e-mail et
    # doit suffire. Le jeton est signé, nominatif, et ne donne aucun autre
    # pouvoir que celui de couper les envois.
    path(
        "desinscription/<str:token>/",
        client_views.UnsubscribeView.as_view(),
        name="unsubscribe",
    ),
]
