# jeiko/emailing/tests_echecs_obligatoires.py
"""
Un e-mail obligatoire qui ne part pas doit CRIER.

Ce qui s'est passé
------------------
Constat de l'exploitant le 04/09 : « je n'ai pas reçu le mail de
réinitialisation ». En reproduisant, l'envoi échouait sur « Configuration email
manquante ou inactive » — et l'unique trace était une ligne `EmailLog` en
`failed`, plus un `logger.info` noyé au milieu du journal.

Le destinataire ne reçoit rien. L'exploitant ne voit rien. Le seul symptôme est
une absence, et une absence ne se remarque pas — c'est exactement le mode
d'échec qui a déjà coûté S-17 (le journal des agents vide partout).

La distinction qu'on pose ici
------------------------------
Un e-mail ORDINAIRE qu'on n'envoie pas est souvent une décision : le modèle est
décoché, l'opt-in marketing manque. `info` convient.

Un e-mail OBLIGATOIRE qu'on n'envoie pas est une **panne fonctionnelle**. Sans
la réinitialisation, l'utilisateur qui oublie son mot de passe perd son compte ;
sans la confirmation de commande, le client n'a plus de preuve d'achat. Cela va
dans le canal des erreurs, celui qu'on surveille.

`registry.is_mandatory` est l'autorité — le même qui empêche de décocher ces
e-mails dans l'administration et qui refuse leur désactivation par l'API.
"""

from unittest.mock import patch

from django.test import TestCase, override_settings

from jeiko.emailing import registry, services
from jeiko.emailing.models import EmailLog, EmailTemplate


class EchecDUnEmailObligatoireTests(TestCase):
    def setUp(self):
        self.modele = EmailTemplate.objects.get(code="password_reset_request")
        self.assertTrue(
            registry.is_mandatory("password_reset_request"),
            "Le test n'a de sens que si cet e-mail est bien obligatoire.",
        )

    def test_un_modele_inactif_est_journalise_en_erreur(self):
        EmailTemplate.objects.filter(pk=self.modele.pk).update(active=False)

        with self.assertLogs("jeiko.emailing.services", level="ERROR") as journal:
            envoye, raison = services.send_email(
                "password_reset_request", "client@exemple.fr",
                {"lien_action": "https://exemple.fr/x", "expiration": "3 jours"},
            )

        self.assertFalse(envoye)
        trace = "\n".join(journal.output)
        self.assertIn("OBLIGATOIRE", trace)
        self.assertIn("password_reset_request", trace)
        self.assertIn(
            "compte", trace,
            "Le message doit dire la CONSÉQUENCE — sans quoi l'exploitant lit "
            "un code d'erreur et passe à autre chose.",
        )

    def test_un_echec_d_envoi_est_journalise_en_erreur(self):
        """Le modèle est bon ; c'est la connexion SMTP qui manque."""
        with patch.object(services.sending, "send_message",
                          return_value=(False, "Configuration email manquante ou inactive")):
            with self.assertLogs("jeiko.emailing.services", level="ERROR") as journal:
                envoye, _ = services.send_email(
                    "password_reset_request", "client@exemple.fr",
                    {"lien_action": "https://exemple.fr/x", "expiration": "3 jours"},
                )

        self.assertFalse(envoye)
        self.assertIn("Configuration email", "\n".join(journal.output))
        self.assertEqual(
            EmailLog.objects.filter(status="failed").count(), 1,
            "L'échec doit rester traçable dans le journal des envois.",
        )

    def test_un_email_ordinaire_ne_crie_pas(self):
        """
        Sans cette borne, tout deviendrait une erreur et le canal ne servirait
        plus à rien : un modèle marketing décoché est une décision, pas une
        panne.
        """
        ordinaire = EmailTemplate.objects.exclude(
            code__in=[c for c in registry.EMAIL_EVENTS if registry.is_mandatory(c)]
        ).first()
        EmailTemplate.objects.filter(pk=ordinaire.pk).update(active=False)

        with self.assertLogs("jeiko.emailing.services", level="INFO") as journal:
            services.send_email(ordinaire.code, "client@exemple.fr", {})

        self.assertNotIn("ERROR", "\n".join(journal.output))


class InventaireDesEmailsObligatoiresTests(TestCase):
    """
    Les douze e-mails obligatoires doivent être configurés ET actifs.

    Ce contrôle vaut inventaire : il tombe le jour où un `seed` en oublie un,
    ou qu'une migration en désactive un par mégarde. C'est moins cher que de
    l'apprendre par un client qui ne peut plus se connecter.
    """

    def test_chacun_a_un_modele_actif_avec_un_corps(self):
        manquants = []
        for code in registry.EMAIL_EVENTS:
            if not registry.is_mandatory(code):
                continue
            modele = EmailTemplate.objects.filter(code=code).first()
            if modele is None:
                manquants.append(f"{code} : aucun modèle")
            elif not modele.active:
                manquants.append(f"{code} : inactif")
            elif modele.page_id is None:
                manquants.append(f"{code} : sans page de corps")

        self.assertEqual(manquants, [], "E-mail(s) obligatoire(s) inutilisable(s)")
