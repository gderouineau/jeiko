# jeiko/emailing/builder.py
"""
Construction de l'arbre de contenu d'un e-mail à partir d'une déclaration.

Une déclaration (voir seeds.py) est transformée en Page > Section > Line > Bloc >
Content, exactement la structure qu'utilise l'éditeur visuel. Une fois posée, la
page n'a plus rien de particulier : elle s'ouvre et se modifie comme n'importe
quelle page du site.

Ce module est la SEULE façon de matérialiser un contenu par défaut. La commande
`seed_email_templates` et le bouton « Revenir à la version par défaut » l'appellent
tous les deux, ce qui garantit qu'un e-mail réinitialisé est identique à un e-mail
fraîchement installé.
"""

import logging

from django.db import transaction
from django.utils import timezone

from jeiko.administration_pages.models import (
    Bloc, Content, ContentButton, ContentImage, ContentText, Line, Page,
    Section, StyleBox,
)

logger = logging.getLogger(__name__)

# Padding par défaut d'un bloc, quand la déclaration n'en impose pas.
DEFAULT_BLOC_PADDING = "0 24px 16px 24px"


def _style_boxes(padding=None):
    """
    Jeu complet de StyleBox attendu par un StylableElement.

    L'éditeur en crée huit à chaque bloc (voir views.py) ; un contenu construit
    ici doit être indiscernable d'un contenu créé à la main, sans quoi les
    écrans de réglages afficheraient des champs vides.
    """
    boxes = {}
    for kind in ("margin", "padding"):
        for device in ("phone", "tablet", "laptop", "computer"):
            if kind == "padding" and device == "computer" and padding:
                top, right, bottom, left = _split_padding(padding)
                boxes[f"{kind}_{device}"] = StyleBox.objects.create(
                    top=top, right=right, bottom=bottom, left=left
                )
            else:
                boxes[f"{kind}_{device}"] = StyleBox.objects.create()
    return boxes


def _split_padding(value):
    """'24px 16px' -> (24px, 16px, 24px, 16px), à la manière du raccourci CSS."""
    parts = str(value).split()

    if len(parts) == 1:
        return parts * 4
    if len(parts) == 2:
        return parts[0], parts[1], parts[0], parts[1]
    if len(parts) == 3:
        return parts[0], parts[1], parts[2], parts[1]
    return parts[0], parts[1], parts[2], parts[3]


def _columns_number(cols):
    """'6-6' -> 2, '12' -> 1."""
    return len([part for part in str(cols).split("-") if part.strip()]) or 1


def _create_content(bloc, declaration):
    """Crée le Content d'un bloc selon son type déclaré."""
    kind = declaration.get("type", "TEXT")

    if kind == "TEXT":
        return Content.objects.create(
            bloc=bloc,
            content_type="TEXT",
            content_text=ContentText.objects.create(text=declaration.get("text", "")),
        )

    if kind == "BUTTON":
        return Content.objects.create(
            bloc=bloc,
            content_type="BUTTON",
            content_button=ContentButton.objects.create(
                label=declaration.get("label", "En savoir plus"),
                external_url=declaration.get("url", ""),
                background_color=declaration.get("background_color", "#1e50a0"),
                text_color=declaration.get("text_color", "#ffffff"),
                padding=declaration.get("padding", "14px 28px"),
                border_radius=declaration.get("border_radius", "6px"),
                font_weight="700",
                open_in_new_tab=True,
            ),
        )

    if kind == "IMAGE":
        return Content.objects.create(
            bloc=bloc,
            content_type="IMAGE",
            content_image=ContentImage.objects.create(
                image_content=declaration["image_content"],
                alt=declaration.get("alt", ""),
            ),
        )

    logger.warning("Type de bloc inconnu dans une déclaration : %s", kind)
    return None


@transaction.atomic
def build_page(code, declaration):
    """
    Crée la Page de contenu d'un e-mail à partir de sa déclaration.

    La page est marquée `is_mail_template` : elle est de ce fait écartée des URLs
    publiques et de la liste des pages du site (voir querysets.public_pages).
    """
    page = Page.objects.create(
        title=declaration.get("title", f"Mail — {code}"),
        url_tag=f"mail_{code}",
        is_mail_template=True,
        show_default_main_menu=False,
        show_default_footer=False,
        active=True,
        is_protected=True,
    )

    section = Section.objects.create(
        page=page,
        position=1,
        background_color=declaration.get("background_color", "rgba(255,255,255,1)"),
        **_style_boxes(),
    )

    for position, line_declaration in enumerate(declaration.get("lines", []), start=1):
        cols = str(line_declaration.get("cols", "12"))

        line = Line.objects.create(
            section=section,
            position=position,
            columns_type=cols,
            columns_number=_columns_number(cols),
            background_color="rgba(255,255,255,0)",
            **_style_boxes(),
        )

        for bloc_position, bloc_declaration in enumerate(line_declaration.get("blocs", []), start=1):
            bloc = Bloc.objects.create(
                line=line,
                position=bloc_position,
                horizontal_align=bloc_declaration.get("align", ""),
                background_color=bloc_declaration.get("background_color", "rgba(255,255,255,0)"),
                **_style_boxes(bloc_declaration.get("bloc_padding", DEFAULT_BLOC_PADDING)),
            )
            _create_content(bloc, bloc_declaration)

    return page


@transaction.atomic
def apply_seed(code, force=False):
    """
    Pose le contenu par défaut d'un e-mail.

    Sans `force`, un e-mail qui a déjà une page de contenu n'est pas touché :
    la commande peut donc être rejouée sans écraser le travail de l'admin.
    Avec `force`, l'ancienne page est archivée puis remplacée — c'est le
    « Revenir à la version par défaut ».

    Retourne l'un de : "created", "reset", "skipped", "no_seed".
    """
    from jeiko.emailing.models import EmailTemplate
    from jeiko.emailing.seeds import get_seed

    declaration = get_seed(code)
    if declaration is None:
        return "no_seed"

    template, created = EmailTemplate.objects.get_or_create(
        code=code,
        defaults={"subject": declaration["subject"]},
    )

    if template.page_id and not force:
        return "skipped"

    previous = template.page

    # Détacher avant d'archiver : `page` est un OneToOne, l'ancienne et la
    # nouvelle ne peuvent pas être rattachées en même temps.
    template.page = None
    template.save(update_fields=["page"])
    archive_page(previous)

    template.page = build_page(code, declaration)
    template.subject = declaration["subject"]
    template.save(update_fields=["page", "subject"])

    return "created" if (created or previous is None) else "reset"


def apply_all_seeds(force=False):
    """
    Pose les contenus par défaut de tous les e-mails déclarés.

    Retourne un dict {résultat: [codes]}.
    """
    from jeiko.emailing.seeds import seeded_codes

    results = {}
    for code in seeded_codes():
        outcome = apply_seed(code, force=force)
        results.setdefault(outcome, []).append(code)

    return results


def archive_page(page):
    """
    Met de côté une page de contenu au lieu de la supprimer.

    Un « retour au défaut » déclenché par erreur ne doit pas effacer une heure de
    travail. La page est désactivée et renommée ; son url_tag change aussi, sinon
    la contrainte d'unicité empêcherait la reconstruction.
    """
    if page is None:
        return None

    stamp = timezone.localtime().strftime("%Y%m%d-%H%M%S")

    page.active = False
    page.is_protected = False
    page.title = f"{page.title} (avant réinitialisation {stamp})"
    page.url_tag = f"{page.url_tag}_archive_{stamp}"[:100]
    page.save(update_fields=["active", "is_protected", "title", "url_tag"])

    return page
