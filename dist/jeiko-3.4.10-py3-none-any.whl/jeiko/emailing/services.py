# jeiko/emailing/services.py
"""
Point d'entrée unique de l'envoi d'e-mails.

Tout le reste du projet passe par `send_email(code, to, context)` : aucun appel
direct à Django n'a besoin de connaître le SMTP, le rendu ni le journal.

    from jeiko.emailing.services import send_email

    send_email(
        "appointment_confirmed",
        appointment.email,
        {"rdv_date": ..., "rdv_heure": ...},
        user=appointment.user,
    )
"""

import logging

from django.utils import timezone

from jeiko.emailing import registry, render as email_render, sending
from jeiko.emailing.models import EmailLog, EmailTemplate

logger = logging.getLogger(__name__)

# Nombre de tentatives avant abandon définitif d'un envoi en file.
MAX_ATTEMPTS = 3


class Skipped(Exception):
    """L'envoi n'a pas lieu d'être — ce n'est pas une erreur."""


def _resolve_template(code):
    if registry.get_event(code) is None:
        raise Skipped(f"Code inconnu au catalogue : {code}")

    try:
        template = EmailTemplate.objects.select_related("page").get(code=code)
    except EmailTemplate.DoesNotExist:
        raise Skipped(f"Aucun modèle configuré pour {code}")

    if not template.active:
        raise Skipped(f"Modèle {code} inactif")

    return template


def _marketing_allowed(code, user):
    """
    Les e-mails transactionnels partent toujours. Les e-mails marketing exigent
    un opt-in explicite : sans utilisateur identifié, on s'abstient.
    """
    if registry.is_transactional(code):
        return True

    if user is None:
        return False

    preferences = getattr(user, "marketing_prefs", None)
    return bool(preferences and preferences.email_optin)


def _build_context(template, context, user, destinataire=None):
    """Complète le contexte fourni avec les valeurs d'identité du site."""
    site = email_render.site_context()

    values = {
        "site_nom": site["site_name"],
        "site_url": site["site_url"],
        "logo_url": site["logo_url"],
        "contact_tel": site["contact_tel"],
        "date": timezone.localtime().strftime("%d/%m/%Y"),
        "annee": timezone.localtime().strftime("%Y"),
    }

    if user is not None:
        values.update({
            "prenom": getattr(user, "first_name", "") or "",
            "nom": getattr(user, "last_name", "") or "",
            "email": getattr(user, "email", "") or "",
        })

    # Lien de désinscription — sur les e-mails marketing UNIQUEMENT.
    #
    # Le catalogue déclarait cette variable « obligatoire sur le marketing » et
    # le gabarit affichait le lien, mais personne ne la renseignait : l'adresse
    # partait vide, et le lecteur atterrissait sur la page d'accueil.
    #
    # Rien sur les e-mails transactionnels : proposer de se désinscrire d'une
    # confirmation de commande ou d'un code de connexion n'a pas de sens, et
    # laisserait croire qu'on peut couper des messages qui ne se coupent pas.
    if not registry.is_transactional(template.code):
        adresse = destinataire or values.get("email") or getattr(user, "email", "")
        if adresse:
            from .unsubscribe import build_url

            values["lien_desabonnement"] = build_url(adresse, user)

    # Le contexte de l'appelant prime toujours.
    values.update(context or {})
    return values


def send_email(code, to, context=None, user=None, attachments=None,
               connection=None, log=None, subject_override=None):
    """
    Rend et envoie un e-mail du catalogue.

    `log` permet de reprendre une entrée déjà en file plutôt que d'en créer une
    seconde ; il n'est utilisé que par `flush_queue`.

    `subject_override` remplace le sujet du modèle. Réservé aux cas où le sujet
    est déjà configuré ailleurs par l'utilisateur (ex. le champ « objet » d'un
    formulaire de contact), pour ne pas lui imposer celui du catalogue. Il accepte
    les mêmes variables [%cle%].

    Retourne (success: bool, message: str | None). Ne lève jamais : un e-mail qui
    ne part pas ne doit pas faire échouer l'action qui l'a déclenché.
    """
    try:
        template = _resolve_template(code)
    except Skipped as reason:
        # Un e-mail ORDINAIRE qu'on n'envoie pas est une décision : le modèle
        # est décoché, le catalogue ne connaît pas le code. `info` suffit.
        #
        # Un e-mail OBLIGATOIRE qu'on n'envoie pas est une panne. Sans la
        # réinitialisation de mot de passe, l'utilisateur qui l'oublie perd son
        # compte ; sans la confirmation de commande, le client n'a plus de
        # preuve d'achat. Or rien ne le signalait : le destinataire ne reçoit
        # rien, l'exploitant ne voit rien, et l'échec dormait en `info` au
        # milieu du journal.
        _consigner_l_echec(code, str(reason), log)
        return False, str(reason)

    if not _marketing_allowed(code, user):
        logger.info("E-mail %s non envoyé : pas d'opt-in marketing", code)
        if log is not None:
            log.mark_failed("Pas d'opt-in marketing")
        return False, "Pas d'opt-in marketing"

    if isinstance(to, str):
        to = [to]
    to = [address for address in (to or []) if address]
    if not to:
        return False, "Aucun destinataire"

    values = _build_context(template, context, user)
    subject, html, text, warnings = email_render.render_email(template, values)

    if subject_override:
        from jeiko.emailing.models import render_tags
        subject = render_tags(subject_override, values)

    for warning in warnings:
        logger.warning("Rendu de %s : %s", code, warning)

    if not html:
        logger.error("E-mail %s sans corps : envoi abandonné.", code)
        if log is not None:
            log.mark_failed("Aucun contenu à envoyer")
        return False, "Aucun contenu à envoyer"

    if log is None:
        log = EmailLog.objects.create(
            template_code=code,
            to_email=to[0],
            user=user if getattr(user, "pk", None) else None,
            subject=subject,
            context=_serialisable(values),
            attempts=1,
        )
    else:
        log.subject = subject
        log.context = _serialisable(values)
        log.save(update_fields=["subject", "context"])

    success, error = sending.send_message(
        subject=subject,
        text_body=text,
        html_body=html,
        to=to,
        from_email=template.from_email or None,
        reply_to=[template.reply_to_email] if template.reply_to_email else None,
        attachments=attachments,
        connection=connection,
    )

    if success:
        log.mark_sent()
    else:
        _consigner_l_echec(code, error, log)

    return success, error


def _consigner_l_echec(code, raison, log=None):
    """
    Journalise un échec d'envoi, au niveau que sa gravité mérite.

    La distinction n'est pas cosmétique : `logger.error` part dans le canal des
    erreurs — celui qu'on surveille, celui qui déclenche l'alerte technique —
    là où `logger.info` se noie. Un e-mail obligatoire qui ne part pas est une
    panne fonctionnelle, pas une information.

    `registry.is_mandatory` est l'autorité : c'est déjà lui qui empêche de
    décocher ces e-mails dans l'administration, et qui refuse leur
    désactivation par l'API. Une seconde liste ici divergerait.
    """
    if registry.is_mandatory(code):
        logger.error(
            "E-MAIL OBLIGATOIRE NON ENVOYÉ — %s : %s. %s",
            code, raison, registry.mandatory_reason(code),
        )
    else:
        logger.info("E-mail %s non envoyé : %s", code, raison)

    if log is not None:
        log.mark_failed(str(raison))


def queue_email(code, to, context=None, user=None):
    """
    Dépose un e-mail en file sans l'envoyer.

    Utile pour ce qui n'a pas à ralentir une requête (relances, campagnes) et
    pour ce qui est planifié (rappel de rendez-vous la veille). La commande
    `send_pending_emails` le reprendra.
    """
    if isinstance(to, str):
        to = [to]
    to = [address for address in (to or []) if address]
    if not to:
        return None

    return EmailLog.objects.create(
        template_code=code,
        to_email=to[0],
        user=user if getattr(user, "pk", None) else None,
        context=_serialisable(context or {}),
        status=EmailLog.STATUS_QUEUED,
    )


def flush_queue(limit=100):
    """
    Envoie les e-mails en file, en réutilisant une seule connexion SMTP.

    Retourne (envoyés, échecs).
    """
    pending = (
        EmailLog.objects
        .filter(status=EmailLog.STATUS_QUEUED, attempts__lt=MAX_ATTEMPTS)
        .order_by("queued_at")[:limit]
    )
    pending = list(pending)
    if not pending:
        return 0, 0

    connection, _, _ = sending.get_mail_connection()
    if not connection:
        logger.info("File d'attente non traitée : configuration email inactive.")
        return 0, 0

    sent = failed = 0
    try:
        connection.open()
        for log in pending:
            log.attempts += 1
            log.save(update_fields=["attempts"])

            # `log=log` : l'entrée en file est reprise, pas dupliquée.
            success, _ = send_email(
                log.template_code,
                log.to_email,
                context=log.context,
                user=log.user,
                connection=connection,
                log=log,
            )

            if success:
                sent += 1
            else:
                failed += 1
    finally:
        try:
            connection.close()
        except Exception:
            pass

    return sent, failed


def _serialisable(context):
    """Ne conserve du contexte que ce qui tient dans un JSONField."""
    clean = {}
    for key, value in (context or {}).items():
        if value is None or isinstance(value, (str, int, float, bool)):
            clean[key] = value
        else:
            clean[key] = str(value)
    return clean
