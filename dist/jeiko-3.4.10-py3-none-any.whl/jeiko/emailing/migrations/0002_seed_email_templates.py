"""
Pose les contenus par défaut des e-mails à l'installation.

La migration ne contient AUCUN contenu : elle délègue à `builder.apply_seed`,
qui lit seeds.py. C'est volontaire — une migration de données n'est jouée qu'une
fois, donc un contenu amélioré plus tard n'atteindrait jamais les installations
existantes, et le bouton « Revenir à la version par défaut » n'aurait pas de
source à laquelle revenir. Ici, `manage.py seed_email_templates` rejoué et le
bouton de réinitialisation produisent exactement le même résultat.
"""

from django.db import migrations


def seed(apps, schema_editor):
    # Import à l'exécution : le seed a besoin des vrais modèles (méthodes,
    # relations), pas des versions historiques fournies par `apps`.
    from jeiko.emailing.builder import apply_all_seeds

    apply_all_seeds(force=False)


def unseed(apps, schema_editor):
    """Retire les pages de contenu posées par le seed, sans toucher aux modèles."""
    EmailTemplate = apps.get_model("emailing", "EmailTemplate")
    Page = apps.get_model("administration_pages", "Page")

    for template in EmailTemplate.objects.filter(page__isnull=False):
        page_id = template.page_id
        template.page = None
        template.save(update_fields=["page"])
        Page.objects.filter(pk=page_id, is_mail_template=True).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("emailing", "0001_initial"),
        ("administration_pages", "0056_alter_bloc_options_alter_line_options_and_more"),
    ]

    operations = [
        migrations.RunPython(seed, unseed),
    ]
