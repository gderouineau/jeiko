# jeiko/emailing/views/client.py
"""
Désinscription des e-mails marketing, depuis le lien porté par l'e-mail.

Accessible sans connexion, à dessein : exiger un mot de passe pour partir est
une pratique de rétention, pas une mesure de sécurité — et beaucoup de
destinataires n'ont pas de compte.
"""

from django.shortcuts import render
from django.views import View

from jeiko.emailing import unsubscribe as service


class UnsubscribeView(View):
    """
    GET  : demande confirmation (un lien visité par un anti-virus ou un
           pré-chargeur de messagerie ne doit pas désinscrire tout seul).
    POST : coupe réellement les envois marketing.
    """

    template_name = "emailing/client/unsubscribe.html"

    def get(self, request, token):
        charge = service.read_token(token)
        if charge is None:
            return render(request, self.template_name,
                          {"invalide": True}, status=400)
        return render(request, self.template_name, {
            "email": charge.get("email", ""),
            "token": token,
        })

    def post(self, request, token):
        charge = service.read_token(token)
        if charge is None:
            return render(request, self.template_name,
                          {"invalide": True}, status=400)

        service.unsubscribe(charge.get("email"))
        # On confirme sans distinguer « c'était déjà fait » : l'important pour
        # la personne est de savoir qu'elle ne recevra plus rien.
        return render(request, self.template_name, {
            "email": charge.get("email", ""),
            "termine": True,
        })
