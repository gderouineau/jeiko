# jeiko/emailing/tests_logo.py
"""
Le logo des e-mails : lequel part, et dans quel format.

Ce que ces tests protègent
--------------------------
`_logo_url` choisissait `computer_size` en premier — une variante générée **en
WebP**. Or plusieurs messageries n'affichent pas ce format, Outlook pour
Windows au premier rang : une partie des destinataires recevait donc un e-mail
au logo cassé, sans que rien ne le signale côté expéditeur.

L'ordre est désormais porté par `Logo.email_image()` : le logo dédié aux
e-mails s'il existe, puis l'original téléversé (PNG ou JPEG dans la quasi-
totalité des cas), et seulement en dernier recours les variantes WebP.
"""

from django.test import TestCase

from jeiko.administration.models import Logo


class ChoixDuLogoDEmailTests(TestCase):

    def _logo(self, **champs):
        """Crée un Logo en posant directement les noms de fichier.

        On affecte `.name` plutôt que de téléverser : ces tests portent sur
        l'ORDRE de préférence, pas sur le traitement d'image — et un vrai
        téléversement déclencherait la génération des variantes, qui écraserait
        justement ce qu'on veut contrôler.
        """
        logo = Logo()
        for champ, valeur in champs.items():
            getattr(logo, champ).name = valeur
        return logo

    def test_le_logo_dedie_lemporte(self):
        logo = self._logo(
            mail_logo="images/logo/mail/marque.png",
            full_size="images/logo/marque.png",
            computer_size="images/logo/marque-computer.webp",
        )
        self.assertEqual(logo.email_image().name, "images/logo/mail/marque.png")

    def test_sans_logo_dedie_on_prend_loriginal_et_non_la_variante_webp(self):
        """
        Le correctif central : `computer_size` passait avant `full_size`.

        L'original est presque toujours un PNG ou un JPEG — un format que
        toutes les messageries savent afficher.
        """
        logo = self._logo(
            full_size="images/logo/marque.png",
            computer_size="images/logo/marque-computer.webp",
        )
        self.assertEqual(logo.email_image().name, "images/logo/marque.png")

    def test_les_variantes_restent_un_dernier_recours(self):
        """Un WebP vaut mieux que pas de logo du tout."""
        logo = self._logo(computer_size="images/logo/marque-computer.webp")
        self.assertEqual(logo.email_image().name, "images/logo/marque-computer.webp")

    def test_un_logo_vide_ne_renvoie_rien(self):
        self.assertIsNone(self._logo().email_image())

    def test_retirer_le_logo_dedie_revient_au_logo_du_site(self):
        """
        La présence du fichier VAUT activation : c'est ce qui remplace une case
        à cocher, et ce qui rend l'état impossible à rendre incohérent.
        """
        logo = self._logo(
            mail_logo="images/logo/mail/marque.png",
            full_size="images/logo/marque.png",
        )
        logo.mail_logo.name = ""
        self.assertEqual(logo.email_image().name, "images/logo/marque.png")


class RenduDuLogoDansLEmailTests(TestCase):
    """`_logo_url` doit suivre le modèle, et rendre une URL absolue."""

    class _Site:
        logo = None

    def _site_avec_logo(self):
        site = self._Site()
        site.logo = Logo()
        site.logo.mail_logo.name = "images/logo/mail/marque.png"
        return site

    def test_lurl_rendue_est_absolue(self):
        from jeiko.emailing.render import _logo_url

        # `SITE_URL` est le second recours de `site_base_url()`, après l'URL
        # renseignée dans l'identité du site. Sans l'un des deux, il n'y a
        # aucune racine à laquelle rattacher « /media/… ».
        with self.settings(SITE_URL="https://exemple.test"):
            url = _logo_url(self._site_avec_logo())

        self.assertTrue(
            url.startswith("http"),
            f"Une URL relative ({url}) ne s'affiche pas dans un client mail.",
        )
        self.assertIn("marque.png", url)

    def test_sans_url_de_site_le_defaut_est_signale(self):
        """
        Sans racine configurée, TOUTES les images de TOUS les e-mails sont
        cassées — et le site, lui, les affiche parfaitement. Rien ne permet
        donc de s'en apercevoir depuis l'administration : seul le journal peut
        le dire.
        """
        from jeiko.emailing.render import _logo_url

        with self.settings(SITE_URL=""):
            with self.assertLogs("jeiko.emailing.render", level="WARNING") as journal:
                _logo_url(self._site_avec_logo())

        self.assertTrue(
            any("relatif" in ligne for ligne in journal.output),
            "L'absence d'URL de site passe sous silence.",
        )

    def test_un_site_sans_logo_ne_casse_pas_le_rendu(self):
        from jeiko.emailing.render import _logo_url

        class _Site:
            logo = None

        self.assertEqual(_logo_url(_Site()), "")
