# jeiko/emailing/campaigns.py
"""
Envois déclenchés par le temps, et non par une action de l'utilisateur.

Anniversaire, relance de panier, formation en sommeil : ces e-mails n'ont
aucun événement applicatif pour les porter. Ils sont donc appelés par la tâche
quotidienne (`administration/management/commands/cron_24h.py`), qui les exécute
la nuit.

Deux propriétés que chaque campagne doit tenir
----------------------------------------------
**Idempotence.** Le timer peut repasser — reprise après incident, relance
manuelle, journée rejouée. On s'appuie sur `EmailLog`, déjà tenu par
`send_email`, pour ne jamais réexpédier le même message à la même personne dans
la fenêtre où cela ferait doublon. C'est ce qui distingue une relance d'un
harcèlement.

**Silence en cas d'échec partiel.** Une campagne qui plante au 12ᵉ destinataire
ne doit ni interrompre les suivantes, ni faire échouer le passage du timer :
`run_jobs` isole déjà les jobs entre eux, on isole ici les destinataires.

Le consentement, lui, n'est pas géré ici : `services.send_email` refuse déjà
tout envoi marketing sans opt-in explicite (`_marketing_allowed`), et
`EmailTemplate.active` permet de couper n'importe quel e-mail non obligatoire
depuis l'administration.
"""

import logging
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.utils import timezone

from .models import EmailLog
from .services import send_email

logger = logging.getLogger("jeiko.emailing.campaigns")

User = get_user_model()

#: Un panier est « abandonné » après ce délai sans modification.
PANIER_ABANDONNE_APRES = timedelta(days=1)

#: Au-delà, on ne relance plus : le panier est vieux, la relance serait absurde.
PANIER_TROP_VIEUX = timedelta(days=30)

#: Une formation commencée sans progrès depuis ce délai déclenche un rappel.
FORMATION_EN_SOMMEIL_APRES = timedelta(days=14)

#: Conservation du journal d'envoi.
RETENTION_JOURNAL = timedelta(days=365)


def _deja_envoye(code, email, depuis):
    """Vrai si ce message est déjà parti à cette adresse dans la fenêtre."""
    return EmailLog.objects.filter(
        template_code=code,
        to_email__iexact=email,
        queued_at__gte=timezone.now() - depuis,
    ).exists()


def _envoyer_un_a_un(code, destinataires, fenetre_anti_doublon):
    """
    Envoie à chaque destinataire, sans qu'un échec n'arrête les autres.

    `destinataires` est un itérable de (email, contexte, user).
    Retourne le nombre d'envois effectifs.
    """
    envoyes = 0
    for email, contexte, utilisateur in destinataires:
        if not email:
            continue
        if _deja_envoye(code, email, fenetre_anti_doublon):
            continue
        try:
            ok, _motif = send_email(code, email, contexte, user=utilisateur)
            if ok:
                envoyes += 1
        except Exception:
            logger.exception("Campagne %s : échec pour %s", code, email)
    return envoyes


# ---------------------------------------------------------------------------
#  Campagnes
# ---------------------------------------------------------------------------

def souhaiter_les_anniversaires():
    """
    Souhaite l'anniversaire aux comptes dont c'est le jour.

    Fenêtre anti-doublon d'un an : la même personne ne peut pas être souhaitée
    deux fois le même anniversaire, même si le timer repasse.
    """
    aujourdhui = timezone.localdate()
    comptes = (
        User.objects.filter(
            is_active=True,
            profile__date_of_birth__month=aujourdhui.month,
            profile__date_of_birth__day=aujourdhui.day,
        )
        .exclude(email="")
        .select_related("profile")
    )

    destinataires = (
        (u.email, {"prenom": u.first_name or ""}, u) for u in comptes.iterator()
    )
    envoyes = _envoyer_un_a_un("birthday_wishes", destinataires, timedelta(days=300))
    if envoyes:
        logger.info("Anniversaires : %s message(s) envoyé(s).", envoyes)
    return envoyes


def relancer_les_paniers_abandonnes():
    """
    Relance les paniers laissés en plan.

    Un seul rappel par panier : la fenêtre anti-doublon couvre la durée pendant
    laquelle le panier reste éligible.
    """
    from jeiko.shop.models import Cart

    maintenant = timezone.now()
    paniers = (
        Cart.objects.filter(
            is_locked=False,
            user__isnull=False,
            updated_at__lte=maintenant - PANIER_ABANDONNE_APRES,
            updated_at__gte=maintenant - PANIER_TROP_VIEUX,
        )
        .exclude(user__email="")
        .select_related("user")
        .prefetch_related("items")
    )

    def candidats():
        # `chunk_size` est exigé dès qu'on itère après un prefetch_related :
        # Django doit savoir par combien de lignes résoudre les relations.
        for panier in paniers.iterator(chunk_size=500):
            lignes = list(panier.items.all())
            if not lignes:
                continue  # panier vide : rien à relancer
            yield (
                panier.user.email,
                {
                    "prenom": panier.user.first_name or "",
                    "nb_articles": sum(l.quantity for l in lignes),
                },
                panier.user,
            )

    envoyes = _envoyer_un_a_un("cart_abandoned", candidats(), PANIER_TROP_VIEUX)
    if envoyes:
        logger.info("Paniers abandonnés : %s relance(s).", envoyes)
    return envoyes


def relancer_les_formations_en_sommeil():
    """Rappelle une formation commencée puis laissée de côté."""
    from jeiko.courses.models import CourseEnrollment

    limite = timezone.now() - FORMATION_EN_SOMMEIL_APRES
    inscriptions = (
        CourseEnrollment.objects.filter(
            status=CourseEnrollment.STATUS_ACTIVE,
            updated_at__lte=limite,
            progress_percentage__gt=0,
            progress_percentage__lt=100,
        )
        .exclude(user__email="")
        .select_related("user", "course")
    )

    def candidats():
        for inscription in inscriptions.iterator():
            yield (
                inscription.user.email,
                {
                    "prenom": inscription.user.first_name or "",
                    "formation": inscription.course.title,
                    "progression": f"{int(inscription.progress_percentage)} %",
                },
                inscription.user,
            )

    envoyes = _envoyer_un_a_un(
        "course_progress_stalled", candidats(), FORMATION_EN_SOMMEIL_APRES
    )
    if envoyes:
        logger.info("Formations en sommeil : %s rappel(s).", envoyes)
    return envoyes


def purger_le_journal_des_envois():
    """
    Retire les lignes de journal trop anciennes.

    Le journal grossit d'une ligne par e-mail : sans purge, il devient la plus
    grosse table du site. Un an couvre largement le besoin de diagnostic.
    """
    limite = timezone.now() - RETENTION_JOURNAL
    supprimes, _ = EmailLog.objects.filter(queued_at__lt=limite).delete()
    if supprimes:
        logger.info("Journal d'envoi : %s ligne(s) purgée(s).", supprimes)
    return supprimes
