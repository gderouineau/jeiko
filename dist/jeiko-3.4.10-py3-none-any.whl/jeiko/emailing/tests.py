"""
Campagnes quotidiennes et verrou des e-mails obligatoires.

Deux sujets, une même préoccupation : ce qui part automatiquement doit partir
une seule fois, et ce qui ne doit jamais être coupé doit être protégé.
"""

from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core import mail
from django.test import TestCase, override_settings
from django.utils import timezone

from jeiko.emailing import campaigns, registry
from jeiko.emailing.models import EmailLog

User = get_user_model()
LOCMEM = "django.core.mail.backends.locmem.EmailBackend"


class DecorEmail(TestCase):
    def setUp(self):
        from jeiko.administration.models import MailSettings, WebSite

        site = WebSite.objects.first()
        if site is not None:
            site.mail_settings = MailSettings.objects.create(
                host="localhost", port=587, active=True,
                default_from_email="site@exemple.test",
            )
            site.save(update_fields=["mail_settings"])
        mail.outbox = []

    def compte(self, nom="camille", optin=True, naissance=None):
        utilisateur = User.objects.create_user(
            nom, f"{nom}@exemple.test", "mdp", first_name="Camille"
        )
        if naissance is not None:
            profil = utilisateur.profile
            profil.date_of_birth = naissance
            profil.save(update_fields=["date_of_birth"])
        if optin:
            from jeiko.users.models import MarketingPreference

            MarketingPreference.objects.update_or_create(
                user=utilisateur, defaults={"email_optin": True}
            )
        return utilisateur


class EmailsObligatoiresTests(TestCase):
    """
    L'interrupteur `active` est exposé en administration : il faut donc que
    certains e-mails ne puissent pas être coupés, sous peine d'enfermer des
    utilisateurs dehors sans le moindre signal (l'envoi échoue en silence).
    """

    def test_les_acces_au_compte_sont_proteges(self):
        for code in ["password_reset_request", "twofa_code",
                     "account_email_verify", "email_change_confirm"]:
            with self.subTest(code=code):
                self.assertTrue(registry.is_mandatory(code))

    def test_les_preuves_d_achat_sont_protegees(self):
        self.assertTrue(registry.is_mandatory("order_confirmation"))
        self.assertTrue(registry.is_mandatory("payment_received"))

    def test_le_marketing_reste_desactivable(self):
        for code in ["birthday_wishes", "cart_abandoned", "nps_survey",
                     "reactivation", "newsletter_welcome"]:
            with self.subTest(code=code):
                self.assertFalse(registry.is_mandatory(code))

    def test_chaque_code_obligatoire_existe_au_catalogue(self):
        inconnus = [c for c in registry.MANDATORY_CODES
                    if c not in registry.EMAIL_EVENTS]
        self.assertEqual(inconnus, [], f"Codes obligatoires inexistants : {inconnus}")

    def test_un_motif_est_donne_a_l_administrateur(self):
        self.assertTrue(registry.mandatory_reason("twofa_code"))
        self.assertEqual(registry.mandatory_reason("birthday_wishes"), "")


@override_settings(EMAIL_BACKEND=LOCMEM)
class AnniversaireTests(DecorEmail):
    def test_le_jour_dit_le_message_part(self):
        aujourdhui = timezone.localdate()
        self.compte(naissance=aujourdhui.replace(year=1985))
        self.assertEqual(campaigns.souhaiter_les_anniversaires(), 1)

    def test_un_autre_jour_rien_ne_part(self):
        demain = timezone.localdate() + timedelta(days=1)
        self.compte(naissance=demain.replace(year=1985))
        self.assertEqual(campaigns.souhaiter_les_anniversaires(), 0)

    def test_le_timer_qui_repasse_ne_renvoie_rien(self):
        """La propriété qui distingue une attention d'un harcèlement."""
        aujourdhui = timezone.localdate()
        self.compte(naissance=aujourdhui.replace(year=1985))
        campaigns.souhaiter_les_anniversaires()
        self.assertEqual(campaigns.souhaiter_les_anniversaires(), 0)

    def test_sans_opt_in_rien_ne_part(self):
        aujourdhui = timezone.localdate()
        self.compte(optin=False, naissance=aujourdhui.replace(year=1985))
        self.assertEqual(campaigns.souhaiter_les_anniversaires(), 0)

    def test_un_compte_desactive_est_ignore(self):
        aujourdhui = timezone.localdate()
        compte = self.compte(naissance=aujourdhui.replace(year=1985))
        User.objects.filter(pk=compte.pk).update(is_active=False)
        self.assertEqual(campaigns.souhaiter_les_anniversaires(), 0)


@override_settings(EMAIL_BACKEND=LOCMEM)
class PurgeJournalTests(DecorEmail):
    def test_les_lignes_anciennes_sont_retirees(self):
        vieux = EmailLog.objects.create(
            template_code="birthday_wishes", to_email="x@exemple.test",
        )
        EmailLog.objects.filter(pk=vieux.pk).update(
            queued_at=timezone.now() - timedelta(days=400)
        )
        recent = EmailLog.objects.create(
            template_code="birthday_wishes", to_email="y@exemple.test",
        )

        campaigns.purger_le_journal_des_envois()

        self.assertFalse(EmailLog.objects.filter(pk=vieux.pk).exists())
        self.assertTrue(EmailLog.objects.filter(pk=recent.pk).exists())


class CronQuotidienTests(TestCase):
    def test_les_campagnes_sont_bien_branchees_au_quotidien(self):
        from jeiko.administration.management.commands.cron_24h import Command

        noms = [nom for nom, _ in Command().get_jobs()]
        for attendu in ["souhaits d'anniversaire", "relance des paniers abandonnés",
                        "relance des formations en sommeil",
                        "purge du journal d'envoi"]:
            self.assertIn(attendu, noms)

    def test_chaque_job_est_appelable_sans_donnees(self):
        """Une base vide ne doit pas faire échouer le passage du timer."""
        from jeiko.administration.management.commands.cron_24h import Command

        for nom, job in Command().get_jobs():
            if "JEIKO" in nom or "PageSpeed" in nom:
                continue  # réseau
            with self.subTest(job=nom):
                job()


@override_settings(EMAIL_BACKEND=LOCMEM)
class DesinscriptionTests(DecorEmail):
    """
    Le lien de désinscription partait avec une adresse VIDE : le catalogue
    déclarait la variable, le gabarit affichait le lien, et personne ne
    renseignait l'une ni ne servait l'autre. Le lecteur atterrissait sur la
    page d'accueil.
    """

    def test_le_lien_est_desormais_rempli_sur_le_marketing(self):
        from jeiko.emailing.unsubscribe import build_url

        self.assertTrue(build_url("camille@exemple.test"))

    def test_la_page_de_desinscription_repond(self):
        from django.urls import reverse

        from jeiko.emailing.unsubscribe import build_token

        url = reverse("jeiko_client_emailing:unsubscribe",
                      kwargs={"token": build_token("camille@exemple.test")})
        self.assertEqual(self.client.get(url).status_code, 200)

    def test_un_jeton_falsifie_est_refuse(self):
        from django.urls import reverse

        url = reverse("jeiko_client_emailing:unsubscribe",
                      kwargs={"token": "jeton-invente"})
        self.assertEqual(self.client.get(url).status_code, 400)

    def test_la_confirmation_coupe_reellement_le_marketing(self):
        from django.urls import reverse

        from jeiko.emailing.unsubscribe import build_token

        compte = self.compte(optin=True)
        url = reverse("jeiko_client_emailing:unsubscribe",
                      kwargs={"token": build_token(compte.email, compte)})
        self.client.post(url)

        compte.marketing_prefs.refresh_from_db()
        self.assertFalse(compte.marketing_prefs.email_optin)

    def test_une_simple_visite_ne_desinscrit_pas(self):
        """Un anti-virus ou un pré-chargeur ne doit pas désinscrire à la place
        du destinataire."""
        from django.urls import reverse

        from jeiko.emailing.unsubscribe import build_token

        compte = self.compte(optin=True)
        url = reverse("jeiko_client_emailing:unsubscribe",
                      kwargs={"token": build_token(compte.email, compte)})
        self.client.get(url)

        compte.marketing_prefs.refresh_from_db()
        self.assertTrue(compte.marketing_prefs.email_optin)

    def test_aucun_lien_sur_un_e_mail_transactionnel(self):
        """Proposer de se désinscrire d'un code de connexion n'a aucun sens."""
        from jeiko.emailing import registry

        self.assertTrue(registry.is_transactional("twofa_code"))
        self.assertFalse(registry.is_transactional("birthday_wishes"))


class InterrupteurAdminTests(TestCase):
    """
    L'état actif/inactif était affiché sans pouvoir être changé : la demande
    « choisir si on envoie ou pas » n'était donc pas satisfaite.
    """

    def setUp(self):
        from django.contrib.auth import get_user_model
        from django.contrib.auth.models import Permission

        from jeiko.emailing.models import EmailTemplate

        User = get_user_model()
        self.admin = User.objects.create_superuser("root", "root@exemple.test", "mdp")
        self.client.force_login(self.admin)
        self.facultatif = EmailTemplate.objects.get_or_create(
            code="birthday_wishes", defaults={"subject": "Bon anniversaire"}
        )[0]
        self.obligatoire = EmailTemplate.objects.get_or_create(
            code="password_reset_request", defaults={"subject": "Réinitialisation"}
        )[0]

    def url(self, code):
        from django.urls import reverse

        return reverse("jeiko_administration_emailing:template_toggle_active",
                       args=[code])

    def test_on_peut_couper_un_e_mail_facultatif(self):
        self.client.post(self.url("birthday_wishes"))
        self.facultatif.refresh_from_db()
        self.assertFalse(self.facultatif.active)

    def test_et_le_rallumer(self):
        self.client.post(self.url("birthday_wishes"))
        self.client.post(self.url("birthday_wishes"))
        self.facultatif.refresh_from_db()
        self.assertTrue(self.facultatif.active)

    def test_un_e_mail_obligatoire_refuse_d_etre_coupe(self):
        self.client.post(self.url("password_reset_request"))
        self.obligatoire.refresh_from_db()
        self.assertTrue(
            self.obligatoire.active,
            "La réinitialisation de mot de passe a été coupée : plus personne "
            "ne peut récupérer son compte.",
        )

    def test_le_refus_est_expliqué(self):
        reponse = self.client.post(self.url("password_reset_request"), follow=True)
        messages = [str(m) for m in reponse.context["messages"]]
        self.assertTrue(any("ne peut pas être désactivé" in m for m in messages),
                        messages)

    def test_un_e_mail_coupe_ne_part_plus(self):
        """Le bout du fil : couper doit réellement empêcher l'envoi."""
        from jeiko.emailing.services import send_email

        self.client.post(self.url("birthday_wishes"))
        ok, motif = send_email("birthday_wishes", "x@exemple.test", {})
        self.assertFalse(ok)
        self.assertIn("inactif", (motif or "").lower())

    def test_la_liste_propose_le_bouton(self):
        from django.urls import reverse

        page = self.client.get(reverse("jeiko_administration_emailing:template_list"))
        self.assertContains(page, "Désactiver")
        self.assertContains(page, "Obligatoire")


@override_settings(EMAIL_BACKEND=LOCMEM)
class AlertesAdministrateurTests(DecorEmail):
    """
    Le catalogue déclarait ces e-mails depuis le début, aucun n'était appelé :
    l'exploitant n'apprenait rien de ce qui se passait sur son site.
    """

    def setUp(self):
        super().setUp()
        from jeiko.administration.models import MailSettings

        # `admin_recipients()` lit l'expéditeur et l'adresse de test.
        MailSettings.objects.update(test_receiver="admin@exemple.test")
        mail.outbox = []

    def test_une_inscription_previent_l_exploitant(self):
        from jeiko.emailing.admin_alerts import notifier_nouvelle_inscription

        compte = self.compte(nom="nouveau")
        mail.outbox = []
        notifier_nouvelle_inscription(compte)
        self.assertEqual(len(mail.outbox), 1)

    def test_une_alerte_technique_part(self):
        from jeiko.emailing.admin_alerts import notifier_erreur

        notifier_erreur("Stripe : abonnements", "événement non traité")
        self.assertEqual(len(mail.outbox), 1)

    def test_une_alerte_technique_ne_leve_jamais(self):
        """Une alerte d'erreur qui échoue ne doit pas produire une 2e erreur."""
        from unittest import mock

        from jeiko.emailing.admin_alerts import notifier_erreur

        with mock.patch("jeiko.emailing.admin_alerts.send_email",
                        side_effect=RuntimeError("SMTP mort")):
            self.assertFalse(notifier_erreur("x", "y"))


class SeuilDeStockTests(TestCase):
    """
    NULL = aucune alerte · 0 = alerte à la rupture · n = alerte à n ou moins.
    Pas de valeur sentinelle : rien, dans un entier, ne distingue un drapeau
    d'un seuil.
    """

    def produit(self, stock, seuil):
        from jeiko.custom_objects.tests import CustomObjectFixture

        fixture = CustomObjectFixture()
        fixture.setUp()
        from jeiko.shop.models import Product

        Product.objects.filter(pk=fixture.product.pk).update(
            stock_quantity=stock, stock_alert_threshold=seuil,
            allow_negative_stock=False, is_active=True,
        )
        return Product.objects.get(pk=fixture.product.pk)

    def concernes(self):
        from django.db.models import F, Q

        from jeiko.shop.models import Product

        return Product.objects.filter(
            is_active=True, allow_negative_stock=False
        ).filter(
            stock_alert_threshold__isnull=False,
            stock_quantity__lte=F("stock_alert_threshold"),
        )

    def test_sans_seuil_aucune_alerte(self):
        self.produit(stock=0, seuil=None)
        self.assertEqual(self.concernes().count(), 0)

    def test_seuil_zero_alerte_a_la_rupture(self):
        self.produit(stock=0, seuil=0)
        self.assertEqual(self.concernes().count(), 1)

    def test_seuil_zero_pas_d_alerte_s_il_reste_du_stock(self):
        self.produit(stock=3, seuil=0)
        self.assertEqual(self.concernes().count(), 0)

    def test_seuil_n_alerte_au_niveau_ou_en_dessous(self):
        self.produit(stock=5, seuil=5)
        self.assertEqual(self.concernes().count(), 1)

    def test_au_dessus_du_seuil_rien(self):
        self.produit(stock=6, seuil=5)
        self.assertEqual(self.concernes().count(), 0)
