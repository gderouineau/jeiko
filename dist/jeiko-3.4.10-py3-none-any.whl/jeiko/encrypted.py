"""
Champs chiffrés au repos, adaptés aux conventions du package.

Pourquoi ne pas utiliser `encrypted_fields` directement
-------------------------------------------------------
Sa classe de base transforme toute valeur vide en `NULL` :

    def get_prep_value(self, value):
        if value:
            return self.f.encrypt(...)
        return None          # <- même pour ""

Or les champs concernés ici sont déclarés `blank=True` **sans** `null=True` :
leur valeur vide est la chaîne vide, et la colonne est NOT NULL. Utiliser la
bibliothèque telle quelle fait donc échouer tout enregistrement dont le secret
n'est pas renseigné — c'est-à-dire le cas courant d'une passerelle de paiement
à moitié configurée.

Passer les champs en `null=True` « pour que ça marche » aurait introduit deux
valeurs vides distinctes (`NULL` et `""`) sur des champs que tout le code teste
par `if gateway.secret_key`. On préfère conserver la convention du package et
adapter le champ.

Ce que fait le chiffrement, et ce qu'il ne fait pas
---------------------------------------------------
La clé est dérivée de `SECRET_KEY` (PBKDF2), qui vit dans le `.env` en 0600 et
jamais en base. Cela protège contre la **lecture de la base sans le fichier** :
sauvegarde égarée, disque de VPS revendu, accès en lecture seule, injection SQL.

Cela ne protège **pas** contre quelqu'un qui a déjà la main sur le serveur — il
lit le `.env` aussi — ni contre un administrateur du back-office, à qui les
écrans déchiffrent par construction.

⚠️ Changer `SECRET_KEY` rend les secrets illisibles. En cas de rotation,
renseigner l'ancienne valeur dans `SECRET_KEY_FALLBACKS` le temps de
réenregistrer les écrans concernés : la bibliothèque essaie chaque clé.
"""

import json
import logging

from encrypted_fields.fields import (
    EncryptedCharField as _EncryptedCharField,
    EncryptedJSONField as _EncryptedJSONField,
    EncryptedTextField as _EncryptedTextField,
)

logger = logging.getLogger(__name__)


class _VideRestVideMixin:
    """Conserve la chaîne vide au lieu de la transformer en NULL."""

    def get_prep_value(self, value):
        prepare = super().get_prep_value(value)
        if prepare is None and not self.null:
            return ""
        return prepare


class EncryptedCharField(_VideRestVideMixin, _EncryptedCharField):
    pass


class EncryptedTextField(_VideRestVideMixin, _EncryptedTextField):
    pass


class EncryptedJSONField(_EncryptedJSONField):
    """
    Le JSON vide est `{}`, pas la chaîne vide : la règle ci-dessus ne
    s'applique pas, et un dict vide n'a de toute façon aucun secret à protéger.

    Ce que chiffre réellement ce champ
    ----------------------------------
    **Les valeurs, pas les clés.** En base on lit toujours
    `{"private_key": "gAAAA…", "client_email": "gAAAA…"}` : la colonne reste du
    `jsonb`, la structure du document reste lisible, seules les feuilles sont
    chiffrées. C'est suffisant ici — le secret est dans les valeurs — mais il
    ne faut pas y ranger un document dont les *noms de clés* seraient sensibles.

    **Les scalaires reviennent en chaînes.** La bibliothèque fait `str(value)`
    avant de chiffrer : un `21` ressort `"21"`, un `True` ressort `"True"`.
    N'y ranger que des chaînes, ou convertir à la lecture.

    Pourquoi ce `to_python`
    -----------------------
    Une ligne écrite **avant** le passage au champ chiffré n'est pas
    déchiffrable. La bibliothèque avale alors l'échec (`except InvalidToken:
    pass`) et renvoie… le texte JSON brut, c'est-à-dire une `str` là où tout le
    code attend un `dict` — d'où un `AttributeError` sur le premier `.get()`,
    loin de la cause. On rétablit le `dict` et on journalise.

    Deux causes possibles, que l'on ne sait pas distinguer à cet endroit : la
    ligne date d'avant le chiffrement (une migration de données la règle), ou
    `SECRET_KEY` a changé sans `SECRET_KEY_FALLBACKS` — et dans ce second cas le
    `dict` rendu contient du chiffré illisible. Le message dit les deux.
    """

    def get_prep_value(self, value):
        prepare = super().get_prep_value(value)
        if prepare is None and not self.null:
            return "{}"
        return prepare

    def to_python(self, value):
        valeur = super().to_python(value)
        if not isinstance(valeur, str):
            return valeur
        if hasattr(self, "_already_decrypted"):
            # Nettoyage d'un formulaire : la valeur vient du navigateur, pas de
            # la base. Rien à rattraper, et surtout rien à journaliser.
            return valeur
        try:
            rendu = json.loads(valeur)
        except ValueError:
            return valeur
        logger.warning(
            "%s.%s : valeur non déchiffrée — ligne antérieure au chiffrement, "
            "ou SECRET_KEY changée sans SECRET_KEY_FALLBACKS.",
            getattr(self, "model", None) and self.model.__name__,
            self.name,
        )
        return rendu
