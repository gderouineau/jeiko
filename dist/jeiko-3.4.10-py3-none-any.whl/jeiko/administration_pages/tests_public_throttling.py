"""
Garde-fous des points d'entrée publics en écriture.

`calendars` était seul à en avoir. Ces tests couvrent les trois autres — envoi
de formulaire, consentement cookies, mesure de temps de lecture — et vérifient
surtout qu'un usage normal n'est pas gêné : un anti-abus trop serré coûte des
demandes de contact réelles.
"""

import json

from django.test import TestCase, override_settings
from django.urls import reverse

from jeiko.administration_pages.models import (
    ContentFormulaire,
    ContentFormSubmission,
)
from jeiko.throttling import reset_counters


class FormulairePublicTests(TestCase):
    def setUp(self):
        reset_counters()
        self.formulaire = ContentFormulaire.objects.create(name="Contact")
        self.formulaire.fields.create(
            name="message", label="Message", type="text", required=True, order=1
        )
        self.url = reverse("api_pages:formulaire_submit", args=[self.formulaire.pk])

    def envoyer(self, **extra):
        donnees = {"message": "Bonjour"}
        donnees.update(extra)
        return self.client.post(self.url, donnees)

    def test_un_envoi_normal_passe(self):
        self.assertEqual(self.envoyer().status_code, 200)
        self.assertEqual(ContentFormSubmission.objects.count(), 1)

    def test_le_leurre_rejette_sans_rien_enregistrer(self):
        reponse = self.envoyer(company="Robot SARL")
        self.assertEqual(reponse.status_code, 429)
        self.assertEqual(ContentFormSubmission.objects.count(), 0)

    def test_le_martelement_est_coupe(self):
        refuses = 0
        for _ in range(30):
            if self.envoyer().status_code == 429:
                refuses += 1
        self.assertGreater(refuses, 0, "Aucun plafond : relais de spam ouvert.")

    def test_le_plafond_borne_les_enregistrements(self):
        for _ in range(30):
            self.envoyer()
        self.assertLess(
            ContentFormSubmission.objects.count(), 30,
            "Toutes les soumissions ont été enregistrées malgré le plafond.",
        )

    @override_settings(JEIKO_FORM_SUBMISSION_LIMITS={"ip_attempts": (2, 3600)})
    def test_les_plafonds_sont_reglables(self):
        self.assertEqual(self.envoyer().status_code, 200)
        self.assertEqual(self.envoyer().status_code, 200)
        self.assertEqual(self.envoyer().status_code, 429)

    def test_un_champ_demesure_est_borne(self):
        self.envoyer(message="x" * 50_000)
        soumission = ContentFormSubmission.objects.first()
        self.assertLessEqual(len(soumission.data["message"]), 5000)

    def test_le_champ_leurre_est_present_dans_le_gabarit(self):
        """Sans le champ rendu, le leurre ne piège personne."""
        from django.template.loader import render_to_string

        html = render_to_string(
            "administration_pages/content/partials/content_formulaire.html",
            {"formulaire": self.formulaire},
        )
        self.assertIn('name="company"', html)
        self.assertIn("cf-hp", html)


class MesureAudienceTests(TestCase):
    def setUp(self):
        reset_counters()

    def test_le_plafond_finit_par_couper(self):
        url = reverse("stats_track_exit")
        corps = json.dumps({"id": "00000000-0000-4000-8000-000000000000", "d": 10})
        codes = {
            self.client.post(url, corps, content_type="application/json").status_code
            for _ in range(320)
        }
        self.assertIn(429, codes)

    def test_un_volume_normal_passe(self):
        url = reverse("stats_track_exit")
        corps = json.dumps({"id": "00000000-0000-4000-8000-000000000000", "d": 10})
        for _ in range(20):
            self.assertNotEqual(
                self.client.post(url, corps, content_type="application/json").status_code,
                429,
            )
