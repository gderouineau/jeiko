# jeiko/administration_pages/tests_js_jumeaux.py
"""
`alpine-blocks.js` et `alpine-blocks.min.js` doivent porter les mêmes correctifs.

Le piège
--------
`base.html` sert la version lisible en `DEBUG` et la **minifiée en
production**. Les deux fichiers sont maintenus à la main : `staticfiles.py`
minifie le CSS à `collectstatic` mais pas le JS, et le dit — « l'ajouter
demanderait un minifieur JS ».

Conséquence : corriger `alpine-blocks.js` seul ne livre RIEN. Le défaut
disparaît en développement et reste chez tous les clients. C'est exactement ce
qui était arrivé au CSS, où `main.min.css` avait divergé de onze mois et 175
sélecteurs — sauf qu'ici, aucune minification automatique ne viendra rattraper
l'oubli.

Ce que ce test fait, et ce qu'il ne fait pas
--------------------------------------------
Il vérifie que des marqueurs choisis — des bouts de code qui survivent à la
minification — sont présents des deux côtés. **Il ne prouve pas que les deux
fichiers sont équivalents** : ce serait le travail d'un minifieur, pas d'un
test. Il attrape l'oubli, qui est le mode d'échec réel.

Ajouter un marqueur ici fait partie de tout correctif portant sur ces fichiers.
La vraie sortie serait de minifier le JS à `collectstatic`, comme le CSS ; tant
que ce n'est pas fait, ce test est la seule barrière.
"""

import pathlib
import re

from django.test import SimpleTestCase

JS = pathlib.Path(__file__).resolve().parent.parent / "static" / "jeiko" / "js"

#: Marqueur → ce qu'il verrouille. Les espaces sont ignorés à la comparaison :
#: la minification les supprime, mais ne renomme pas ces identifiants.
MARQUEURS = {
    "hasYearly": "la bascule annuelle se cache quand aucune offre n'a de tarif annuel",
    "vide?NaN": "un prix vide vaut ABSENT, pas zéro (Number('') === 0)",
    "nombre+' '+currency": "le symbole monétaire suit le nombre en français",
}


def _sans_espaces(chemin):
    return re.sub(r"\s+", "", (JS / chemin).read_text())


class JumeauxJavascriptTests(SimpleTestCase):
    def test_les_deux_fichiers_portent_les_memes_correctifs(self):
        lisible = _sans_espaces("alpine-blocks.js")
        minifie = _sans_espaces("alpine-blocks.min.js")

        for marqueur, ce_qu_il_verrouille in MARQUEURS.items():
            attendu = re.sub(r"\s+", "", marqueur)
            with self.subTest(marqueur=marqueur):
                self.assertIn(
                    attendu, lisible,
                    f"Absent de alpine-blocks.js — {ce_qu_il_verrouille}.",
                )
                self.assertIn(
                    attendu, minifie,
                    f"Absent de alpine-blocks.min.js — {ce_qu_il_verrouille}. "
                    f"C'est CE fichier que reçoivent les visiteurs : le "
                    f"correctif n'est pas livré.",
                )

    def test_la_version_minifiee_reste_plus_petite(self):
        """
        Un garde-fou grossier contre la recopie du fichier lisible par-dessus.

        Ce serait sans danger fonctionnel, mais ferait perdre le gain de poids
        sans que personne le remarque.
        """
        lisible = (JS / "alpine-blocks.js").stat().st_size
        minifie = (JS / "alpine-blocks.min.js").stat().st_size
        self.assertLess(minifie, lisible)
