"""
Catalogue des types de contenu proposés dans l'éditeur.

Pourquoi ce fichier
-------------------
Les 23 types étaient écrits en dur dans le gabarit du sélecteur, rangés par
technologie — « les blocs de bases », puis « les blocs dynamiques » — avec pour
seul repère un libellé et une icône. Un administrateur non technique ne pouvait
pas deviner ce que produit « Stepper », « Filtre / Recherche live » ou « Grille
de Ressources » : il fallait l'insérer, le regarder, puis le supprimer.

On les décrit donc ici, groupés par **intention** — ce que l'on cherche à
faire, pas la technique employée — avec une phrase qui dit ce que le bloc
affiche et le nom d'un croquis qui en donne la silhouette (voir
`templates/administration_pages/includes/type_sketches.html`).

Ajouter un type = ajouter une entrée ici. Les codes doivent rester ceux
qu'attend `ContentTypeChoice` : ce sont eux qui sont postés.
"""


def _t(code, label, desc, sketch):
    return {"code": code, "label": label, "desc": desc, "sketch": sketch}


#: Les blocs utilisables dans un modèle d'e-mail : uniquement ceux que les
#: clients de messagerie savent rendre. Tout ce qui repose sur du JavaScript ou
#: du CSS moderne est sans effet dans une boîte de réception.
MAIL_SAFE_CODES = {"TEXT", "IMAGE", "BUTTON"}


GROUPS = {
    "present": [
        _t("TEXT", "Texte", "Un paragraphe, un titre, une liste.", "text"),
        _t("IMAGE", "Image", "Une photo ou une illustration.", "image"),
        _t("BUTTON", "Bouton", "Un lien mis en avant, vers une page ou un site.", "button"),
        _t("VIDEO", "Vidéo", "Une vidéo hébergée chez vous ou sur une plateforme.", "video"),
        _t("CHART", "Graphique", "Des chiffres présentés en barres ou en courbes.", "chart"),
    ],
    "structure": [
        _t("DYN_FAQ", "Questions fréquentes",
           "Des questions repliées, qui s'ouvrent au clic.", "faq"),
        _t("DYN_TABS", "Onglets",
           "Plusieurs contenus au même endroit, un seul visible à la fois.", "tabs"),
        _t("DYN_ACCORDION_ADV", "Accordéon détaillé",
           "Comme les questions fréquentes, mais avec des sous-niveaux.", "layers"),
        _t("DYN_CAROUSEL", "Diaporama",
           "Des images qui défilent une à une.", "carousel"),
        _t("DYN_FILTER", "Liste filtrable",
           "Une liste que le visiteur affine en tapant.", "filter"),
        _t("DYN_GALLERY_FILTER", "Galerie par catégories",
           "Des visuels triables par thème — utile pour un portfolio.", "grid"),
        _t("DYN_RESOURCE_CAROUSEL", "Ressources en diaporama",
           "Vos formations, produits ou articles, qui défilent.", "resource-row"),
        _t("DYN_RESOURCE_GRID", "Ressources en grille",
           "Vos formations, produits ou articles, présentés côte à côte.", "grid"),
    ],
    "convince": [
        _t("DYN_TESTIMONIALS", "Témoignages qui défilent",
           "Les avis de vos clients, un par un.", "quote"),
        _t("DYN_TESTIMONIALS_GRID", "Témoignages en grille",
           "Plusieurs avis visibles d'un coup d'œil.", "grid"),
        _t("DYN_RATING", "Note en étoiles",
           "Une note moyenne et le nombre d'avis.", "rating"),
        _t("DYN_PROGRESS", "Étapes ou chronologie",
           "Un déroulé en points successifs : parcours, historique, méthode.", "progress"),
        _t("DYN_STEPPER", "Parcours guidé",
           "Des étapes numérotées que le visiteur suit dans l'ordre.", "stepper"),
    ],
    "collect": [
        _t("FORM", "Formulaire",
           "Des champs à remplir, envoyés par e-mail.", "form"),
        _t("CALENDAR", "Prise de rendez-vous",
           "Vos créneaux disponibles, réservables en ligne.", "calendar"),
    ],
    "sell": [
        _t("DYN_PRICING_TABLE", "Tableau de tarifs",
           "Vos offres comparées colonne par colonne.", "pricing"),
        _t("DYN_COUNTDOWN", "Compte à rebours",
           "Le temps restant avant une échéance.", "countdown"),
        _t("DYN_COUNTDOWN_CTA", "Compte à rebours avec bouton",
           "Un compte à rebours suivi d'un appel à l'action.", "countdown"),
    ],
}


def groups_for(page):
    """Groupes de types proposables pour `page`.

    Un modèle d'e-mail ne reçoit que les blocs rendus par les messageries ; les
    autres groupes sont vides, et le gabarit ne les affiche pas.
    """
    if getattr(page, "is_mail_template", False):
        return {
            "present": [t for t in GROUPS["present"] if t["code"] in MAIL_SAFE_CODES],
            "structure": [], "convince": [], "collect": [], "sell": [],
        }
    return GROUPS
