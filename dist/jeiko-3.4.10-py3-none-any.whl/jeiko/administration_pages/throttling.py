"""
Garde-fous du formulaire public.

Politique propre à la soumission de formulaire ; les primitives sont partagées
(`jeiko.throttling`). Deux plafonds distincts, parce que les deux coûts ne sont
pas les mêmes :

- `ip_attempts` coupe le martèlement, y compris les envois refusés — c'est ce
  qui protège la base ;
- `ip_submissions` borne les soumissions *acceptées*, celles qui déclenchent
  deux e-mails chacune — c'est ce qui protège la réputation du domaine
  d'envoi.

Les valeurs par défaut sont volontairement larges : un formulaire de contact
légitime est utilisé quelques fois par jour, pas quelques fois par minute. Elles
restent réglables par `JEIKO_FORM_SUBMISSION_LIMITS`.
"""

import logging

from jeiko.throttling import get_client_ip, get_limits, hit, honeypot_filled, peek

logger = logging.getLogger(__name__)

# (nombre maximum, fenêtre en secondes)
DEFAULT_LIMITS = {
    "ip_attempts": (20, 3600),
    "ip_submissions": (5, 3600),
    "ip_submissions_day": (15, 86400),
}

SCOPE = "form"

GENERIC_REFUSAL = (
    "Trop d'envois depuis cet appareil. Merci de réessayer plus tard, "
    "ou de nous contacter directement."
)


def get_form_limits():
    return get_limits("JEIKO_FORM_SUBMISSION_LIMITS", DEFAULT_LIMITS)


def check_form_submission(request, data):
    """
    Contrôles AVANT enregistrement. `None` si l'envoi peut poursuivre, sinon un
    message pour le visiteur — volontairement vague, pour ne pas renseigner un
    robot sur la règle qui l'a arrêté.
    """
    limits = get_form_limits()
    ip = get_client_ip(request)

    if honeypot_filled(data):
        logger.warning("Formulaire rejeté (honeypot rempli) ip=%s", ip)
        return GENERIC_REFUSAL

    if hit(f"{SCOPE}:attempts", ip, *limits["ip_attempts"]):
        logger.warning("Formulaire rejeté (trop de tentatives) ip=%s", ip)
        return GENERIC_REFUSAL

    if peek(f"{SCOPE}:sent_h", ip, limits["ip_submissions"][0]) or \
       peek(f"{SCOPE}:sent_d", ip, limits["ip_submissions_day"][0]):
        logger.warning("Formulaire rejeté (plafond d'envois atteint) ip=%s", ip)
        return GENERIC_REFUSAL

    return None


def record_form_submission(request):
    """Comptabilise un envoi accepté (appelé après enregistrement)."""
    limits = get_form_limits()
    ip = get_client_ip(request)
    hit(f"{SCOPE}:sent_h", ip, *limits["ip_submissions"])
    hit(f"{SCOPE}:sent_d", ip, *limits["ip_submissions_day"])
