"""
Non-régression des filtres de rendu partagés (`jeiko/templatetags/`).

Ces filtres n'avaient aucun test, alors que ce sont eux qui décident si le
contenu saisi en administration ressort exécutable ou non. Deux failles y ont
été trouvées et corrigées ; ce fichier existe pour qu'elles ne reviennent pas.

Hébergé par `administration_pages` parce que `templatetags` n'est pas une
application installée : c'est l'app qui rend ces contenus.
"""

from django.template import Context, Template
from django.test import SimpleTestCase

from jeiko.templatetags.css_extras import clean_css_value
from jeiko.templatetags.custom_tags import render_custom_tags, resolve_button_label
from jeiko.templatetags.html_extras import html_unescape


class FauxBouton:
    """Le minimum que `resolve_button_label` regarde."""

    def __init__(self, label):
        self.label = label

    def get_url(self):
        return "#"


class LibelleBoutonTests(SimpleTestCase):
    """
    Le texte PORTEUR passé au moteur de tokens n'était pas échappé, alors que la
    fonction marque son résultat sûr : le libellé d'un bouton ressortait donc
    exécutable chez tous les visiteurs.
    """

    def rendu(self, label, contexte=None):
        return str(resolve_button_label(contexte or {}, FauxBouton(label), None))

    def test_balise_injectee_est_neutralisee(self):
        sortie = self.rendu('<img src=x onerror=alert(document.cookie)>')
        self.assertNotIn("<img", sortie)
        self.assertIn("&lt;img", sortie)

    def test_fermeture_de_balise_et_script(self):
        sortie = self.rendu("</button><script>alert(1)</script>")
        self.assertNotIn("<script", sortie)

    def test_sortie_d_attribut(self):
        # Le libellé est aussi rendu dans des contextes d'attribut.
        self.assertNotIn('"', self.rendu('x" onmouseover="alert(1)'))

    def test_libelle_ordinaire_reste_lisible(self):
        self.assertEqual(self.rendu("Réserver un créneau"), "Réserver un créneau")

    def test_esperluette_echappee_une_seule_fois(self):
        self.assertEqual(self.rendu("Tarifs & options"), "Tarifs &amp; options")

    def test_les_icones_fonctionnent_toujours(self):
        sortie = self.rendu("[[mi-o:phone|size=20|title=Nous appeler]] Appeler")
        self.assertIn('class="material-icons-outlined"', sortie)
        self.assertIn(">phone</span>", sortie)
        self.assertIn('aria-label="Nous appeler"', sortie)

    def test_le_titre_d_icone_reste_echappe(self):
        sortie = self.rendu('[[mi:phone|title=x" onmouseover="alert(1)]]')
        self.assertNotIn('onmouseover="alert', sortie)

    def test_les_variables_sont_toujours_substituees(self):
        self.assertEqual(self.rendu("Bonjour [% prenom %]", {"prenom": "Camille"}),
                         "Bonjour Camille")

    def test_une_variable_hostile_reste_echappee(self):
        sortie = self.rendu("[% nom %]", {"nom": "<script>alert(1)</script>"})
        self.assertNotIn("<script", sortie)


class TexteRicheTests(SimpleTestCase):
    """
    Le durcissement du porteur ne doit pas coûter la mise en forme du texte
    riche, qui arrive déjà assaini et marqué sûr par `html_unescape`.
    """

    def test_la_mise_en_forme_survit(self):
        riche = html_unescape(
            "&lt;h2&gt;Titre&lt;/h2&gt;&lt;p&gt;&lt;strong&gt;gras&lt;/strong&gt;&lt;/p&gt;"
        )
        sortie = str(render_custom_tags({}, riche))
        self.assertIn("<h2>Titre</h2>", sortie)
        self.assertIn("<strong>gras</strong>", sortie)

    def test_le_script_est_retire_du_texte_riche(self):
        riche = html_unescape("&lt;script&gt;alert(1)&lt;/script&gt;&lt;p&gt;ok&lt;/p&gt;")
        sortie = str(render_custom_tags({}, riche))
        self.assertNotIn("<script", sortie)
        self.assertIn("<p>ok</p>", sortie)

    def test_attribut_alt_d_image(self):
        # content_image.html injecte ce résultat dans alt="…" et title="…".
        self.assertNotIn('"', str(render_custom_tags({}, 'photo" onload="alert(1)')))


class ValeurCssTests(SimpleTestCase):
    """
    Dans un élément de style, l'échappement HTML est inefficace (il ne touche ni
    les accolades ni le point-virgule) et nuisible (les entités n'y sont pas
    décodées). D'où `css_value`.
    """

    def test_les_accolades_sont_retirees(self):
        self.assertNotIn("{", clean_css_value("red; } body{display:none} nav{"))
        self.assertNotIn("}", clean_css_value("red; } body{display:none} nav{"))

    def test_le_point_virgule_est_retire(self):
        self.assertNotIn(";", clean_css_value("#fff; color:red"))

    def test_la_regle_at_est_retiree(self):
        self.assertNotIn("@", clean_css_value("@import url(//exemple)"))

    def test_on_ne_peut_pas_quitter_l_element_de_style(self):
        sortie = clean_css_value("Arial</style><script>alert(1)</script>")
        self.assertNotIn("<", sortie)
        self.assertNotIn(">", sortie)

    def test_le_commentaire_est_retire(self):
        self.assertNotIn("/*", clean_css_value("red/* sortie */"))

    def test_les_valeurs_legitimes_passent_intactes(self):
        for valeur in ["#e5e7eb", "rgba(255, 255, 255, 0.9)", "transparent",
                       '"Playfair Display", serif', "0 4px 16px rgba(0,0,0,.08)",
                       "12px 24px"]:
            self.assertEqual(clean_css_value(valeur), valeur)

    def test_valeur_vide(self):
        self.assertEqual(clean_css_value(None), "")
        self.assertEqual(clean_css_value(""), "")


class BlocStyleDuMenuTests(SimpleTestCase):
    """Le gabarit complet, pour vérifier que le filtre y est bien branché."""

    CHAMPS = [
        "background_color", "text_color", "hover_text_color", "active_text_color",
        "submenu_background_color", "submenu_border_color",
        "submenu_hover_background_color", "font_family", "font_weight",
        "letter_spacing", "uppercase", "border_bottom_color",
    ]

    def style(self, **kw):
        objet = type("StyleFactice", (), {c: "" for c in self.CHAMPS})()
        for cle, valeur in kw.items():
            setattr(objet, cle, valeur)
        return objet

    def rendre(self, **kw):
        gabarit = Template("{% include 'menu/styles/main.html' %}")
        return gabarit.render(Context({"style": self.style(**kw), "menu_id": 1}))

    def test_pas_de_sortie_de_l_element_de_style(self):
        sortie = self.rendre(font_family="Arial</style><script>alert(1)</script><style>")
        self.assertNotIn("<script", sortie)
        # Celui du gabarit lui-même, et lui seul.
        self.assertEqual(sortie.count("</style>"), 1)

    def test_pas_de_regle_css_injectee(self):
        sortie = self.rendre(background_color="red; } body{display:none} nav{")
        self.assertNotIn("body{display:none}", sortie)

    def test_une_police_entre_guillemets_reste_utilisable(self):
        # Le piège qui avait motivé le `|safe` : l'échappement HTML aurait
        # produit &quot;, que le moteur CSS ne décode pas.
        self.assertIn('--font-family: "Playfair Display", serif;',
                      self.rendre(font_family='"Playfair Display", serif'))
