# jeiko/administration_pages/fabrique.py
"""
Création des sections, lignes et blocs — un seul endroit, deux appelants.

Pourquoi ce module existe
-------------------------
Créer une section, ce n'est pas créer une ligne en base : c'est en créer
**treize**. Un `Size` et deux `StyleBox` par appareil, plus la section
elle-même, avec des valeurs qui dépendent du gabarit choisi — une section
« pleine largeur » n'a pas les mêmes tailles qu'une section « classique ».

Cette logique vivait dans `views.SectionCreate`, atteignable seulement par un
POST de formulaire. L'API des agents en a besoin aussi. La recopier aurait
garanti que les deux divergent : le jour où l'on ajoute un gabarit ou que l'on
corrige une marge, un seul des deux chemins en profite, et l'écart ne se voit
pas — il produit des pages subtilement différentes selon qui les a créées.

C'est exactement le défaut qu'A-20 a coûté ailleurs : un outil correct que rien
ne relie à son second usage. On extrait donc, et les deux appelants lisent la
même source.

Ce que ce module ne fait pas
----------------------------
Il ne rend rien et ne répond à personne : ni HTML, ni JSON, ni redirection.
Les vues s'en chargent. Il ne vérifie pas non plus les permissions — c'est le
rôle de `EditorMutationMixin` côté éditeur et de `VueAgent` côté API, et les
deux le font avant d'arriver ici.
"""

from django.db import transaction

from .models import Bloc, Line, Section, Size, StyleBox

#: Gabarits de section. La différence tient aux largeurs par appareil : une
#: section « pleine largeur » occupe tout, une « classique » est centrée dans
#: une colonne de lecture.
GABARITS_SECTION = {
    "FULL": {
        "tailles": {
            "phone": "100%", "tablet": "100%", "laptop": "100%", "computer": "100%",
        },
    },
    "CLASSIC": {
        "tailles": {
            "phone": "92%", "tablet": "730px", "laptop": "950px", "computer": "1140px",
        },
    },
}

APPAREILS = ("phone", "tablet", "laptop", "computer")


def _boite(top="", right="", bottom="", left=""):
    return StyleBox.objects.create(top=top, right=right, bottom=bottom, left=left)


def _taille(largeur="", hauteur=""):
    return Size.objects.create(width=largeur, height=hauteur)


def _decor(tailles, marge=("0", "auto", "0", "auto"), padding=("0", "0", "0", "0")):
    """
    Les douze objets liés d'un élément stylable, en un dictionnaire prêt à
    passer en `**kwargs` à `objects.create`.
    """
    decor = {}
    for appareil in APPAREILS:
        decor[f"size_{appareil}"] = _taille(tailles.get(appareil, ""))
        decor[f"margin_{appareil}"] = _boite(*marge)
        decor[f"padding_{appareil}"] = _boite(*padding)
    return decor


def position_suivante(queryset):
    """
    La position à donner au prochain élément d'une famille.

    Passe par le maximum existant plutôt que par un décompte : après une
    suppression, compter donnerait une position déjà prise.
    """
    dernier = queryset.order_by("-position").first()
    if dernier is None or dernier.position is None:
        return 0
    return dernier.position + 1


@transaction.atomic
def creer_section(page, gabarit="CLASSIC", position=None):
    """Crée une section vide au gabarit demandé, en fin de page par défaut."""
    if gabarit not in GABARITS_SECTION:
        raise ValueError(
            f"Gabarit de section inconnu : « {gabarit} ». "
            f"Attendus : {', '.join(sorted(GABARITS_SECTION))}."
        )

    if position is None:
        position = position_suivante(Section.objects.filter(page=page))

    return Section.objects.create(
        page=page,
        position=position,
        is_model=False,
        **_decor(GABARITS_SECTION[gabarit]["tailles"]),
    )


@transaction.atomic
def creer_ligne(section, position=None, colonnes=1):
    """
    Crée une ligne dans une section.

    `colonnes` pose `columns_number` ; la répartition (`columns_type`) garde le
    défaut du modèle, que l'appelant ajustera par les paramètres s'il le veut.
    """
    if position is None:
        position = position_suivante(Line.objects.filter(section=section))

    return Line.objects.create(
        section=section,
        position=position,
        columns_number=max(1, int(colonnes)),
        is_model=False,
        **_decor({appareil: "100%" for appareil in APPAREILS}),
    )


@transaction.atomic
def creer_bloc(line, colonne=0, position_in_column=None):
    """
    Crée un bloc dans une colonne d'une ligne.

    `colonne` est le champ `position` du bloc — le vocabulaire du modèle est
    trompeur : c'est un numéro de colonne, pas un rang vertical. Le rang, c'est
    `position_in_column`.
    """
    if position_in_column is None:
        dernier = (
            line.blocs.filter(position=colonne)
            .order_by("-position_in_column")
            .first()
        )
        position_in_column = (dernier.position_in_column + 1) if dernier else 0

    return Bloc.objects.create(
        line=line,
        position=colonne,
        position_in_column=position_in_column,
        **_decor({appareil: "100%" for appareil in APPAREILS}),
    )
