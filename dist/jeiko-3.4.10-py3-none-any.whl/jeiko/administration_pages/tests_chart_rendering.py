# jeiko/administration_pages/tests_chart_rendering.py
"""
Le bloc graphique : options en JSON valide, et rien qui puisse s'exécuter.

Ce que ces tests attrapent
--------------------------
`content_chart.html` interpolait les options du graphique dans un attribut :

    x-data="chartBloc('…', '…', {{ chart.options_json|default:"{}"|safe }})"

`options_json` est un `JSONField` : le gabarit rendait la **repr Python** du
dictionnaire. Deux conséquences.

*Fonctionnelle, et bloquante* : `{'beginAtZero': True}` sortait avec `True`,
qui n'existe pas en JavaScript. Alpine levait une `ReferenceError` et le bloc
ne s'initialisait plus — **toute option contenant un booléen ou un `null`
empêchait le graphique de s'afficher**. Le défaut ne se voyait qu'à l'usage,
sur les graphiques configurés, jamais sur ceux laissés par défaut.

*Sécurité* : un guillemet dans une valeur refermait l'attribut.

Les options passent désormais par un bloc `<script type="application/json">`,
comme les données juste à côté, sérialisé par `tojson`.

Le second groupe couvre `build_chart_json`, qui alimente le bloc de données
depuis Python : `json.dumps` n'échappe ni `<`, ni `>`, ni `&`, si bien qu'un
titre de test contenant `</script>` refermait le bloc.
"""

import json
import re

from django.template.loader import render_to_string
from django.test import SimpleTestCase

GABARIT = "administration_pages/content/partials/content_chart.html"

_BLOC_OPTIONS = re.compile(
    r'<script type="application/json" id="chart-options-\d+">(.*?)</script>',
    re.DOTALL,
)


class _Chart:
    """Le minimum que le gabarit consulte d'un ContentChart."""

    chart_type = "bar"
    title = ""
    description = ""

    def __init__(self, options):
        self.options_json = options


def _rendre(options):
    return render_to_string(
        GABARIT,
        {"chart": _Chart(options), "chart_id": 7,
         "chart_data_json": '{"labels":[],"datasets":[]}'},
    )


def _options_rendues(options):
    trouve = _BLOC_OPTIONS.search(_rendre(options))
    return trouve.group(1).strip() if trouve else None


class OptionsDuGraphiqueTests(SimpleTestCase):

    def test_les_options_sont_du_json_valide_et_non_une_repr_python(self):
        """
        Le cas exact qui cassait l'affichage.

        `True` / `None` en Python s'écrivent `true` / `null` en JSON. Rendus
        tels quels dans du JavaScript, ils levaient une ReferenceError.
        """
        rendu = _options_rendues({"scales": {"y": {"beginAtZero": True}},
                                  "plugins": None})
        self.assertIsNotNone(rendu, "Le bloc d'options n'est pas rendu.")
        self.assertNotIn("True", rendu)
        self.assertNotIn("None", rendu)
        self.assertEqual(
            json.loads(rendu),
            {"scales": {"y": {"beginAtZero": True}}, "plugins": None},
        )

    def test_les_options_ne_sont_plus_dans_lattribut_x_data(self):
        """
        `x-data` ne reçoit plus que deux arguments, tous deux des chaînes.

        Tant que du JSON y transite, une valeur contenant un guillemet ferme
        l'attribut.
        """
        html = _rendre({"titre": 'aa"bb'})
        self.assertIn("""x-data="chartBloc('7', 'bar')\"""", html)
        self.assertNotIn('aa"bb', html.split("<script")[0])

    def test_une_valeur_ne_peut_pas_refermer_le_bloc_script(self):
        """`</script>` dans une option ne doit jamais ressortir littéralement."""
        rendu = _options_rendues({"titre": "</script><script>alert(1)</script>"})
        self.assertNotIn("</script>", rendu)
        self.assertIn("\\u003C", rendu)
        # Et cela reste du JSON que le navigateur relira à l'identique.
        self.assertEqual(
            json.loads(rendu)["titre"], "</script><script>alert(1)</script>"
        )

    def test_absence_doptions_ne_casse_pas_le_rendu(self):
        """Un graphique sans options configurées reste affichable."""
        for vide in (None, {}, ""):
            with self.subTest(options=vide):
                html = _rendre(vide)
                self.assertIn("chart-options-7", html)
                self.assertIn("chart-canvas-7", html)


class DonneesDuGraphiqueTests(SimpleTestCase):
    """`build_chart_json` — la sérialisation faite en Python, pas en gabarit."""

    def _donnees(self, titre_test, nom_profil):
        from jeiko.questionnaires_expert.views.client import build_chart_json

        class _Test:
            title = titre_test

        class _Data:
            test = _Test()
            data = {"scores": [
                {"name": nom_profil, "score": 3.0, "color": "#abc"}
            ]}

        return build_chart_json(_Data())

    def test_un_titre_de_test_ne_peut_pas_refermer_le_bloc(self):
        sortie = self._donnees("Test </script><script>alert(1)</script>", "Profil")
        self.assertNotIn("</script>", sortie)
        self.assertIn("\\u003C", sortie)

    def test_un_nom_de_profil_ne_peut_pas_injecter_de_balise(self):
        sortie = self._donnees("Test", "Profil <img src=x onerror=alert(1)>")
        self.assertNotIn("<img", sortie)
        self.assertEqual(
            json.loads(sortie)["labels"][0], "Profil <img src=x onerror=alert(1)>"
        )

    def test_les_scores_restent_lisibles(self):
        """L'échappement ne doit toucher que les trois caractères visés."""
        sortie = self._donnees("Test", "Profil")
        self.assertIn("3.0", sortie)
        self.assertEqual(json.loads(sortie)["datasets"][0]["data"], [3.0])
