"""
Rafraîchissement quotidien des mesures PageSpeed, page par page.

Ce que fait ce module
---------------------
Une fois par jour, il reprend les pages publiques dont la dernière mesure
remonte à plus d'une semaine et relance PageSpeed dessus. Il réutilise
`run_pagespeed_refresh`, le même service que le bouton « Rafraîchir » de
l'écran Insights : aucune logique de mesure n'est dupliquée ici.

Le quota est la contrainte qui dicte la forme
---------------------------------------------
L'API PageSpeed est limitée (par défaut 25 000 requêtes/jour et 240/minute,
et une mesure prend plusieurs secondes). Trois précautions en découlent :

- **un plafond par passage** (`MAX_PAGES_PER_RUN`), pour qu'un site de 300
  pages n'essaie pas de tout mesurer d'un coup ;
- **les plus anciennes d'abord**, pour que le plafond fasse tourner l'ensemble
  du site sur plusieurs jours au lieu de bloquer toujours sur les mêmes pages ;
- **on s'arrête au premier signe de quota dépassé** plutôt que d'insister : les
  pages non traitées restent « anciennes » et repasseront naturellement le
  lendemain. C'est la reprise que tu décrivais : si ça casse, on refait demain.

Aucune exception ne remonte : une mesure ratée ne doit ni interrompre la
cadence, ni empêcher les autres pages d'être mesurées.
"""

import logging
from datetime import timedelta

from django.utils import timezone

logger = logging.getLogger(__name__)

#: Au-delà, on laisse la suite au lendemain. 20 pages × 2 stratégies = 40
#: appels, très en deçà du quota, et quelques minutes de traitement.
MAX_PAGES_PER_RUN = 20

#: Une mesure plus récente que ça est considérée comme fraîche.
STALE_AFTER = timedelta(days=7)

#: Marqueurs d'un refus pour cause de quota dans le message d'erreur renvoyé
#: par l'API. On s'arrête net dès qu'on en voit un.
QUOTA_MARKERS = ("429", "quota", "rate limit", "rateLimitExceeded", "userRateLimitExceeded")


def _looks_like_quota(exc) -> bool:
    message = str(exc).lower()
    return any(marker.lower() in message for marker in QUOTA_MARKERS)


def stale_pages(limit=MAX_PAGES_PER_RUN, now=None):
    """Pages publiques dont la mesure la plus récente dépasse `STALE_AFTER`.

    Les pages jamais mesurées passent en premier (elles n'ont aucune date),
    puis les plus anciennes. Les gabarits d'e-mail, de PDF et d'objet
    personnalisé sont exclus : ils n'ont pas d'URL publique à mesurer.
    """
    from django.db.models import Max
    from jeiko.administration_pages.querysets import public_pages

    now = now or timezone.now()
    cutoff = now - STALE_AFTER

    return list(
        public_pages()
        .filter(active=True)
        .annotate(last_measured=Max("insights__fetched_at"))
        .filter(last_measured__isnull=True)
        .union(
            public_pages()
            .filter(active=True)
            .annotate(last_measured=Max("insights__fetched_at"))
            .filter(last_measured__lt=cutoff)
        )
        .order_by("last_measured")[:limit]
    )


def refresh_stale_insights(limit=MAX_PAGES_PER_RUN):
    """Relance PageSpeed sur les pages dont la mesure a plus d'une semaine.

    Renvoie (mesurées, échouées). Ne lève jamais.
    """
    from jeiko.administration_pages.models import Strategy
    from jeiko.administration_pages.services.pagespeed import run_pagespeed_refresh
    from jeiko.administration_pages.utils import (
        get_google_api_key, is_publicly_reachable, page_public_url,
    )

    if not get_google_api_key():
        logger.info("PageSpeed : aucune clé API configurée, rafraîchissement ignoré.")
        return 0, 0

    try:
        pages = stale_pages(limit=limit)
    except Exception:
        logger.exception("PageSpeed : sélection des pages à rafraîchir impossible.")
        return 0, 0

    # Une seule vérification pour tout le site : l'adresse publique ne dépend
    # pas de la page. Si elle est locale (développement, adresse non déclarée),
    # aucune mesure ne peut aboutir — inutile de consommer du quota.
    if pages and not is_publicly_reachable(page_public_url(pages[0])):
        logger.info(
            "PageSpeed : l'adresse publique du site n'est pas joignable depuis "
            "Internet (%s). Rafraîchissement ignoré — renseignez « Réglages → "
            "Identité du site ».",
            page_public_url(pages[0]),
        )
        return 0, 0

    measured = failed = 0
    for page in pages:
        for strategy in (Strategy.MOBILE, Strategy.DESKTOP):
            try:
                run_pagespeed_refresh(page, strategy)
                measured += 1
            except Exception as exc:
                failed += 1
                if _looks_like_quota(exc):
                    # Quota atteint : insister ne ferait qu'aggraver. Les pages
                    # restantes sont toujours périmées, elles repasseront demain.
                    logger.warning(
                        "PageSpeed : quota atteint après %s mesure(s), reprise demain.",
                        measured,
                    )
                    return measured, failed
                logger.warning(
                    "PageSpeed : échec sur la page %s (%s) — %s",
                    page.pk, strategy, exc,
                )

    logger.info("PageSpeed : %s mesure(s), %s échec(s).", measured, failed)
    return measured, failed
