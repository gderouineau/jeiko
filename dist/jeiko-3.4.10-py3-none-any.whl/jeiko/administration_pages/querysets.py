"""
Chargement de l'arborescence d'une page en un nombre constant de requêtes.

Le rendu parcourt page > sections > lignes > blocs > contenus, et chaque élément stylable
porte 17 relations lues par les templates de style : margin/padding/size pour les quatre
tailles d'écran, l'image de fond et ses paramètres, plus animation, border et custom_css.

Sans préchargement, Django les charge une par une : une page de 18 blocs de texte coûtait
191 requêtes, et le coût croît linéairement avec le nombre d'éléments. Le prefetch existait
déjà dans signals.py pour le calcul du héros, il n'avait jamais été porté sur le rendu.
"""

from django.db.models import Prefetch, Q

from jeiko.administration_pages.models import Page, Section, Line, Bloc

# Relations portées par Section, Line et Bloc (StylableElement + décorations).
STYLE_RELATIONS = (
    "margin_phone", "margin_tablet", "margin_laptop", "margin_computer",
    "padding_phone", "padding_tablet", "padding_laptop", "padding_computer",
    "size_phone", "size_tablet", "size_laptop", "size_computer",
    "background_image", "background_image_parameters",
    "animation", "border", "custom_css",
)

# Sous-objets d'un Content, tous en OneToOne : joignables en une seule requête.
CONTENT_RELATIONS = (
    "content",
    "content__content_text",
    "content__content_image",
    "content__content_image__image_content",
    "content__content_text_questionnaire",
    "content__content_chart",
    "content__content_button",
    "content__content_calendar",
    "content__content_formulaire",
    "content__content_video",
    "content__content_resource_config",
)

# Collections des blocs dynamiques : une requête chacune, pas une par bloc.
CONTENT_COLLECTIONS = (
    "content__faq_items",
    "content__tab_items",
    "content__carousel_slides",
    "content__carousel_slides__image",
    "content__progress_steps",
    "content__testimonial_items",
    "content__testimonial_items__avatar",
    "content__livefilter_items",
    "content__accordion_sections",
    "content__pricing_plans",
    "content__gallery_items",
)


def blocs_queryset():
    return (
        Bloc.objects
        .select_related(*STYLE_RELATIONS, *CONTENT_RELATIONS)
        .prefetch_related(*CONTENT_COLLECTIONS)
        # L'ordre compte : line.html fait {% regroup line.blocs.all by position %},
        # ce qui exige un tri par position. 'id' départage les positions égales.
        .order_by("position", "position_in_column", "id")
    )


def lines_queryset():
    return (
        Line.objects
        .select_related(*STYLE_RELATIONS)
        .prefetch_related(Prefetch("blocs", queryset=blocs_queryset()))
        .order_by("position", "id")
    )


def sections_queryset():
    return (
        Section.objects
        .select_related(*STYLE_RELATIONS)
        .prefetch_related(Prefetch("lines", queryset=lines_queryset()))
        .order_by("position", "id")
    )


def with_page_tree(queryset=None):
    """
    Ajoute le préchargement complet de l'arborescence à un queryset de Page.

        page = get_object_or_404(with_page_tree(), url_tag=tag)
    """
    base = Page.objects.all() if queryset is None else queryset
    return base.prefetch_related(Prefetch("sections", queryset=sections_queryset()))


# Pages qui ne sont pas des pages du site : elles servent de gabarit à autre
# chose (e-mail, PDF, objet custom) et ne doivent pas être servies sur une URL
# publique, même si elles portent un url_tag.
TEMPLATE_ONLY_FLAGS = (
    "is_mail_template",
    "is_pdf",
    "is_custom_object_template",
)


def public_pages(queryset=None, include_unpublished=False):
    """
    Queryset des pages réellement servies au public.

    Deux exclusions, pour deux raisons différentes :

    1. Les **gabarits** (e-mail, PDF, objet custom). Sans ce filtre, un modèle
       d'e-mail créé en administration serait accessible à tout visiteur sur
       /son-url-tag/.

    2. Les pages **non publiées** (`active=False`). Ce filtre manquait : le
       drapeau existait, l'administration l'affichait, mais aucune vue publique
       ne le regardait — dépublier une page ne la retirait donc PAS du site,
       elle restait servie sur son URL directe, listée au sitemap comprise.

    `include_unpublished=True` reste disponible pour les usages internes qui
    doivent voir toutes les pages (mesure de performance, outils d'édition).
    """
    base = Page.objects.all() if queryset is None else queryset

    # Un seul exclude() à trois arguments les combinerait en ET : il ne filtrerait
    # que les pages portant les trois drapeaux à la fois. Il faut un OU.
    condition = Q()
    for flag in TEMPLATE_ONLY_FLAGS:
        condition |= Q(**{flag: True})

    qs = base.exclude(condition)
    if not include_unpublished:
        qs = qs.filter(active=True)
    return qs
