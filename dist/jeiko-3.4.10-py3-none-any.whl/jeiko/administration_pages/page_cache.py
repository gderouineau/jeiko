"""
Cache du corps des pages publiques (le fragment ``#content``).

Le rendu de l'arbre section > ligne > bloc, avec un bloc ``<style>`` inline par
élément, est identique d'une requête à l'autre tant que la page (et, pour une
fiche d'objet custom, l'objet) ne change pas. C'est la partie coûteuse du rendu.
On met donc en cache ce fragment.

Deux propriétés du rendu public rendent la clé simple et sûre :

- **Indépendant du device** : ``mq_to_cq`` (templatetags/editor_responsive.py)
  ne duplique les media-queries en container-queries que dans le namespace
  éditeur. Sur le site public le CSS sort tel quel → même HTML mobile/desktop.
- **Indépendant de l'utilisateur** : les tokens ``[% code %]`` se résolvent
  depuis ``build_object_context(obj)`` (custom_objects/services.py), c.-à-d.
  depuis l'OBJET affiché, jamais depuis ``request.user``.

La clé n'a donc besoin que de l'identité (page, et objet le cas échéant) et d'une
**version** incrémentée à chaque modification de l'arbre. L'incrément est branché
sur ``signals._flush_pending_pages`` : la même infrastructure qui recalcule déjà
le héros une fois par page et par commit (dédupliquée) invalide ici le cache.

Ce qui reste HORS cache (déterminé par ``page_is_cacheable``) :
- un bloc ``FORM`` : il rend ``{% csrf_token %}``, un jeton lié au secret CSRF
  du visiteur ; le figer casserait l'envoi pour tous les autres ;
- un bloc ``CALENDAR`` : les créneaux dépendent des réservations (temps réel).

Les vues de résultats de questionnaire (chart_data_json par session) n'activent
tout simplement pas le cache : elles ne passent pas ``page_cache_enabled``.
"""

from django.core.cache import cache

# Compteur de version par page. Sans expiration : c'est un entier, pas une donnée
# lourde. Le fragment, lui, porte un TTL de garde ci-dessous.
_VERSION_KEY = "jeiko:page_body:ver:{page_id}"

# Idem pour une fiche d'objet custom. Nécessaire car CustomObjectValue n'a AUCUN
# timestamp et CustomObject.date_updated ne bouge qu'au save() du parent : on ne
# peut pas se fier à une date. Le compteur est bumpé par signal sur CustomObject
# et CustomObjectValue (custom_objects/signals.py).
_OBJ_VERSION_KEY = "jeiko:co_body:ver:{obj_id}"

# TTL de garde du fragment. La version invalide bien avant en cas d'édition ; ce
# TTL ne sert que de filet (éviction, cohérence après un éventuel reset du
# compteur sous pression mémoire).
PAGE_BODY_TTL = 60 * 60 * 24 * 7  # 7 jours

# Types de contenu qui interdisent la mise en cache du corps de page.
UNCACHEABLE_CONTENT_TYPES = frozenset({"FORM", "CALENDAR"})


def page_body_version(page_id) -> int:
    """Version courante du corps de la page (crée le compteur à 1 au besoin)."""
    if not page_id:
        return 0
    key = _VERSION_KEY.format(page_id=page_id)
    ver = cache.get(key)
    if ver is None:
        ver = 1
        cache.set(key, ver, None)
    return ver


def bump_page_body_version(page_id) -> None:
    """Invalide le corps de la page (appelé à chaque changement de l'arbre)."""
    if not page_id:
        return
    key = _VERSION_KEY.format(page_id=page_id)
    try:
        cache.incr(key)
    except ValueError:
        # Clé absente (jamais lue ou évincée) : un lecteur repartirait de 1, donc
        # on force >= 2 pour ne pas réutiliser une version déjà servie.
        cache.set(key, 2, None)


def object_body_version(obj_id) -> int:
    """Version courante d'une fiche d'objet custom (crée le compteur à 1)."""
    if not obj_id:
        return 0
    key = _OBJ_VERSION_KEY.format(obj_id=obj_id)
    ver = cache.get(key)
    if ver is None:
        ver = 1
        cache.set(key, ver, None)
    return ver


def bump_object_body_version(obj_id) -> None:
    """Invalide la fiche d'un objet custom (édition de l'objet ou d'une valeur)."""
    if not obj_id:
        return
    key = _OBJ_VERSION_KEY.format(obj_id=obj_id)
    try:
        cache.incr(key)
    except ValueError:
        cache.set(key, 2, None)


def page_is_cacheable(page) -> bool:
    """
    True si aucun bloc de l'arbre n'est per-requête (FORM) ou temps réel
    (CALENDAR). Parcourt l'arbre déjà préchargé par ``with_page_tree`` : aucune
    requête supplémentaire.
    """
    for section in page.sections.all():
        for line in section.lines.all():
            for bloc in line.blocs.all():
                content = getattr(bloc, "content", None)
                ctype = getattr(content, "content_type", None)
                if ctype in UNCACHEABLE_CONTENT_TYPES:
                    return False
    return True


def public_page_vary(page, obj=None) -> str:
    """
    Construit la chaîne ``vary_on`` unique du ``{% cache %}`` : identité + version.

    Pour une fiche d'objet custom, ``obj`` ajoute son id et sa version propre :
    - une édition de l'objet (ou d'une de ses valeurs) bumpe la version objet
      → nouvelle clé, contenu à jour ;
    - une édition du gabarit bumpe la version de la page → nouvelle clé pour
      TOUTES ses fiches, sans avoir à les énumérer.
    """
    parts = [str(page.id), str(page_body_version(page.id))]
    if obj is not None:
        parts += ["co", str(obj.pk), str(object_body_version(obj.pk))]
    return ":".join(parts)


def build_page_cache_context(page, obj=None) -> dict:
    """
    Renvoie les variables de contexte attendues par ``pages/main.html`` :
    ``page_cache_enabled`` (bool), ``page_cache_vary`` (str) et
    ``page_cache_ttl`` (int).

    Une vue qui ne veut jamais cacher (résultats de questionnaire) n'appelle
    simplement pas ce helper.
    """
    if not page_is_cacheable(page):
        return {"page_cache_enabled": False}
    return {
        "page_cache_enabled": True,
        "page_cache_vary": public_page_vary(page, obj=obj),
        "page_cache_ttl": PAGE_BODY_TTL,
    }
