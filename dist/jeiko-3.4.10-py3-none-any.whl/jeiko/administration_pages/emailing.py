# jeiko/administration_pages/emailing.py
"""
E-mails liés aux formulaires de contact.

Ces fonctions traduisent une soumission de ContentFormulaire en contexte et
délèguent à `jeiko.emailing` (codes `contact_form_admin` et `contact_form_receipt`).
Elles ne lèvent jamais : un e-mail qui ne part pas ne doit pas empêcher
l'enregistrement de la soumission ni la réponse au visiteur.
"""

import logging

from django.utils.html import escape

logger = logging.getLogger(__name__)


def _answers_table(label_values):
    """
    Tableau HTML des réponses, injecté via [%bloc_reponses%].

    Construit ici plutôt que dans le modèle éditable : une boucle sur des champs
    variables n'est pas exprimable en balises [%cle%]. Rendu en <table> à styles
    inline, seule forme fiable en messagerie.
    """
    rows = []
    for label, value in label_values.items():
        rows.append(
            '<tr>'
            '<td style="padding:6px 8px;border-bottom:1px solid #eeeeee;'
            'font-weight:700;vertical-align:top;">' + escape(str(label)) + '</td>'
            '<td style="padding:6px 8px;border-bottom:1px solid #eeeeee;'
            'vertical-align:top;">' + escape(str(value or "—")) + '</td>'
            '</tr>'
        )

    if not rows:
        return ""

    return (
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" '
        'border="0" style="width:100%;border-collapse:collapse;">'
        + "".join(rows) +
        '</table>'
    )


def _detect_sender(formulaire, values):
    """
    Devine, parmi des champs libres, l'e-mail et le nom du visiteur.

    Heuristique volontairement simple : premier champ de type e-mail pour
    l'adresse, premier champ dont le code ou le libellé évoque un nom pour
    l'identité. Renvoie ("", "") quand rien ne ressort.
    """
    email = ""
    name = ""

    for field in formulaire.fields.all().order_by("order", "id"):
        raw = (values.get(field.name) or "").strip()
        if not raw:
            continue

        if field.type == "email" and not email:
            email = raw

        looks_like_name = any(
            token in (field.name + " " + field.label).lower()
            for token in ("nom", "name", "prénom", "prenom")
        )
        if looks_like_name and not name:
            name = raw

    return email, name


def send_contact_form_emails(formulaire, label_values, values, request=None):
    """
    Notifie l'équipe d'une soumission, et accuse réception au visiteur si son
    adresse est identifiable.

    - `label_values` : {libellé du champ: valeur}, pour l'affichage.
    - `values`       : {code technique du champ: valeur}, pour la détection.
    """
    from jeiko.emailing.services import send_email

    sender_email, sender_name = _detect_sender(formulaire, values)
    answers = _answers_table(label_values)
    form_name = formulaire.name or "Formulaire de contact"

    page_origin = ""
    if request is not None:
        page_origin = request.META.get("HTTP_REFERER", "") or ""

    # --- Notification interne ---
    if formulaire.to_email:
        admin_context = {
            "formulaire_nom": form_name,
            "bloc_reponses": answers,
            "expediteur_nom": sender_name or "—",
            "expediteur_email": sender_email or "—",
            "page_origine": page_origin or "—",
        }
        try:
            send_email(
                "contact_form_admin",
                formulaire.to_email,
                admin_context,
                # L'objet configuré sur le formulaire prime sur celui du catalogue.
                subject_override=formulaire.mail_subject or None,
            )
        except Exception:
            logger.exception("Échec de la notification de formulaire #%s", formulaire.pk)

    # --- Accusé de réception au visiteur ---
    # Uniquement si une adresse a pu être identifiée : sans champ e-mail, on ne
    # devine pas de destinataire, et on n'écrit à personne au hasard.
    if sender_email:
        receipt_context = {
            "formulaire_nom": form_name,
            "bloc_reponses": answers,
            "delai_reponse": "48 heures",
        }
        if sender_name:
            parts = sender_name.split()
            receipt_context["prenom"] = parts[0]
            receipt_context["nom"] = " ".join(parts[1:])
        try:
            send_email("contact_form_receipt", sender_email, receipt_context)
        except Exception:
            logger.exception("Échec de l'accusé de réception du formulaire #%s", formulaire.pk)
