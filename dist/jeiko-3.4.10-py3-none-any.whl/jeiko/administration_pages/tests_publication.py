"""
Publication d'une page, et conséquences sur les menus.

Deux comportements distincts, souvent confondus :
  - dépublier une page doit réellement la retirer du site public ;
  - un menu qui la référence ne doit pas continuer à proposer un lien.
"""

from django.test import TestCase

from jeiko.administration_menu.models import (
    Menu, MenuItem, MenuLayout, MenuPlace,
)
from jeiko.administration_pages.models import Page


class PublicationTests(TestCase):
    def setUp(self):
        self.page = Page.objects.create(
            title="Secrète", url_tag="secrete", active=False
        )

    def test_une_page_depubliee_n_est_pas_servie(self):
        reponse = self.client.get(self.page.get_absolute_url())
        self.assertEqual(
            reponse.status_code, 404,
            "Une page dépubliée reste accessible par son URL directe : "
            "« dépublier » ne dépublie rien.",
        )

    def test_une_page_publiee_reste_servie(self):
        Page.objects.filter(pk=self.page.pk).update(active=True)
        self.assertEqual(
            self.client.get(self.page.get_absolute_url()).status_code, 200
        )


class MenuEtPublicationTests(TestCase):
    """
    Un menu qui pointe vers une page dépubliée envoie le visiteur sur une 404,
    ou — si l'item perd sa page — sur un lien « # » qui ne fait rien. Dans les
    deux cas, l'entrée n'a plus lieu d'être affichée.
    """

    def setUp(self):
        self.page = Page.objects.create(
            title="Tarifs", url_tag="tarifs", active=True
        )
        self.menu = Menu.objects.create(name="Principal", place=MenuPlace.MAIN,
                                        layout=MenuLayout.LOGO_LEFT_MENU_RIGHT)
        self.item = MenuItem.objects.create(
            menu=self.menu, page=self.page, title="Tarifs",
            position=1, active=True,
        )

    def entrees_affichees(self):
        """Entrées réellement retenues pour le rendu du menu."""
        from jeiko.templatetags.menu_tags import _prefetch_menu_by_id

        menu = _prefetch_menu_by_id(self.menu.pk)
        return list(menu.menu_items.all()) if menu else []

    def test_une_page_publiee_apparait(self):
        self.assertIn(self.item, self.entrees_affichees())

    def test_une_page_depubliee_ne_laisse_pas_de_lien_mort(self):
        Page.objects.filter(pk=self.page.pk).update(active=False)
        self.assertNotIn(
            self.item, self.entrees_affichees(),
            "Le menu propose encore une page dépubliée : le visiteur tombe "
            "sur une 404 depuis la navigation du site lui-même.",
        )

    def test_une_entree_sans_page_reste_affichee(self):
        """Un libellé de regroupement n'a jamais eu vocation à être cliquable."""
        from jeiko.administration_menu.models import MenuItem

        libelle = MenuItem.objects.create(
            menu=self.menu, page=None, title="Nos offres",
            position=2, active=True,
        )
        self.assertIn(libelle, self.entrees_affichees())


class AvertissementDepublicationTests(TestCase):
    """
    Dépublier une page présente dans un menu doit le dire : sans avertissement,
    l'administrateur casse une entrée de navigation sans le savoir.
    """

    def setUp(self):
        self.page = Page.objects.create(
            title="Tarifs", url_tag="tarifs", active=True
        )
        self.menu = Menu.objects.create(name="Principal", place=MenuPlace.MAIN,
                                        layout=MenuLayout.LOGO_LEFT_MENU_RIGHT)
        MenuItem.objects.create(
            menu=self.menu, page=self.page, title="Tarifs",
            position=1, active=True,
        )

    def test_on_sait_dire_si_une_page_est_dans_un_menu(self):
        from jeiko.administration_pages.publication import menus_referencing

        noms = menus_referencing(self.page)
        self.assertEqual(noms, ["Principal"])

    def test_une_page_hors_menu_ne_declenche_rien(self):
        from jeiko.administration_pages.publication import menus_referencing

        autre = Page.objects.create(title="Isolée", url_tag="isolee", active=True)
        self.assertEqual(menus_referencing(autre), [])


class AvertissementAffichéTests(TestCase):
    """L'avertissement doit atteindre l'administrateur, pas seulement exister."""

    def setUp(self):
        from django.contrib.auth import get_user_model
        from django.contrib.auth.models import Permission

        User = get_user_model()
        self.page = Page.objects.create(title="Tarifs", url_tag="tarifs", active=True)
        self.menu = Menu.objects.create(name="Principal", place=MenuPlace.MAIN,
                                        layout=MenuLayout.LOGO_LEFT_MENU_RIGHT)
        MenuItem.objects.create(menu=self.menu, page=self.page, title="Tarifs",
                                position=1, active=True)

        self.admin = User.objects.create_user("gestion", "g@exemple.test", "mdp")
        self.admin.user_permissions.set(
            Permission.objects.filter(content_type__app_label="administration_pages",
                                      codename="change_page")
        )
        self.client.force_login(self.admin)

    def url(self):
        from django.urls import reverse

        return reverse("jeiko_administration_pages:page_toggle_publish",
                       args=[self.page.pk])

    def test_depublier_avertit_que_la_page_est_dans_un_menu(self):
        reponse = self.client.post(self.url(), follow=True)
        messages = [str(m) for m in reponse.context["messages"]]
        self.assertTrue(
            any("menu « Principal »" in m for m in messages),
            f"Aucun avertissement sur le menu. Messages : {messages}",
        )

    def test_publier_n_avertit_de_rien(self):
        Page.objects.filter(pk=self.page.pk).update(active=False)
        reponse = self.client.post(self.url(), follow=True)
        messages = [str(m) for m in reponse.context["messages"]]
        self.assertFalse(any("menu" in m for m in messages))
