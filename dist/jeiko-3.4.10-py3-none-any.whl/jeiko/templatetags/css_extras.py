"""
Interpolation sûre de valeurs éditables dans une feuille de style.

Le problème que ce module résout
-------------------------------
Une quinzaine de gabarits construisent un bloc `<style>` à partir de champs
saisis en administration : couleurs, familles de police, marges, ombres. Or
l'échappement HTML de Django est, à cet endroit précis, à la fois **inefficace
et nuisible**.

*Inefficace* : `escape()` ne touche ni `{`, ni `}`, ni `;`, ni `@`. Une couleur
valant `red; } body{display:none} nav{` sort telle quelle et ajoute des règles
arbitraires — page blanche, calque invisible par-dessus l'interface, ou
détournement de clic. Le rédacteur n'a besoin que d'un rôle délégué pour ça.

*Nuisible* : le contenu d'un élément `<style>` n'est pas analysé comme du HTML,
donc les entités n'y sont **pas** décodées. Une famille de police
`"Playfair Display"` échappée en `&quot;Playfair Display&quot;` arrive
littéralement au moteur CSS et ne correspond à aucune police. C'est cette gêne
qui avait conduit à poser un `|safe` sur `font_family` dans le style de menu —
et ce `|safe`, lui, rouvrait la porte au `</style><script>`.

La bonne réponse n'est donc ni d'échapper, ni de marquer sûr : c'est de retirer
les caractères qui ont une *structure* en CSS, puis de marquer sûr.

Portée
------
`css_value` garantit qu'une valeur ne peut pas **sortir de sa déclaration** :
ni fermer le bloc, ni en ouvrir un autre, ni terminer l'élément `<style>`, ni
introduire une règle « at ». Il ne prétend pas valider que la valeur est un CSS
correct — une couleur absurde reste une couleur absurde, simplement inoffensive.

⚠️ À réserver au contenu d'un élément `<style>`. Dans un attribut
`style="…"`, les guillemets — que ce filtre conserve, car les familles de
police en ont besoin — permettraient de sortir de l'attribut. Aucun gabarit du
package n'interpole de champ éditable dans un attribut `style` ; si cela devait
arriver, l'échappement HTML standard y est la bonne réponse.
"""

import re

from django import template
from django.utils.safestring import mark_safe

register = template.Library()

# Les caractères qui portent une structure en CSS :
#   { }  ouvrent et ferment un bloc de déclarations
#   ;    termine une déclaration et en autorise une suivante
#   @    introduit une règle « at » (@import, @media…)
#   < >  permettraient de former </style> et de quitter l'élément
#   \    ouvre une séquence d'échappement CSS
#   /* */ ouvrent et ferment un commentaire, autre moyen de sortir d'une valeur
_CSS_STRUCTURE_RE = re.compile(r"[{};@<>\\]|/\*|\*/")

# Un saut de ligne ne casse rien en CSS mais rend le bloc généré illisible, et
# une valeur multi-lignes n'a aucun usage légitime ici.
_WHITESPACE_RE = re.compile(r"\s+")


def clean_css_value(value):
    """
    Retourne la valeur débarrassée de ses caractères de structure CSS.

    Chaîne nue (non marquée sûre) : c'est au filtre de gabarit de la marquer,
    pour que chaque `mark_safe` du code reste visible.
    """
    if value is None:
        return ""

    text = _CSS_STRUCTURE_RE.sub("", str(value))
    return _WHITESPACE_RE.sub(" ", text).strip()


@register.filter
def css_value(value):
    """
    Interpole une valeur éditable dans un bloc `<style>`.

        color: {{ font.color|css_value }};
        font-family: {{ font.family|css_value }};

    Marque le résultat sûr **après** nettoyage : sans cela l'échappement HTML
    de Django casserait les familles de police entre guillemets, les entités
    n'étant pas décodées dans un élément `<style>`.
    """
    return mark_safe(clean_css_value(value))
