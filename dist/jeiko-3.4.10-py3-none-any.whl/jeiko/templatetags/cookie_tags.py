# cookies/templatetags/cookie_tags.py
# ou jeiko_cookies/templatetags/cookie_tags.py
from django import template
from django.utils.safestring import mark_safe
from decimal import Decimal

register = template.Library()

# Traduction symbolique -> box-shadow réel
_SHADOWS = {
    "none": "none",
    "sm": "0 4px 12px rgba(0,0,0,.12)",
    "md": "0 12px 30px rgba(0,0,0,.20)",
    "lg": "0 20px 60px rgba(0,0,0,.30)",
}

# Mapping JSON -> nom de variable CSS
_MAPPING = {
    "font_family": "--jk-font-family",
    "font_size_px": "--jk-font-size",
    "line_height": "--jk-line-height",
    "banner_bg": "--jk-banner-bg",
    "banner_fg": "--jk-banner-fg",
    "link_color": "--jk-link-color",
    "btn_radius_px": "--jk-btn-radius",
    "btn_primary_bg": "--jk-btn-primary-bg",
    "btn_primary_fg": "--jk-btn-primary-fg",
    "btn_outline_fg": "--jk-btn-outline-fg",
    "btn_outline_border": "--jk-btn-outline-border",
    "btn_ghost_fg": "--jk-btn-ghost-fg",
    "modal_bg": "--jk-modal-bg",
    "modal_fg": "--jk-modal-fg",
    "modal_shadow": "--jk-modal-shadow",
}

def _fmt_value(key, val):
    if val is None:
        return ""
    # nombres -> str propre
    if key.endswith("_px"):
        try:
            return f"{int(val)}px"
        except Exception:
            return ""
    if key == "line_height":
        try:
            if isinstance(val, Decimal):
                val = float(val)
            return f"{float(val)}"
        except Exception:
            return ""
    if key == "modal_shadow":
        return _SHADOWS.get(str(val), _SHADOWS["lg"])
    # Couleurs et familles de police : nettoyées avant interpolation.
    #
    # Le commentaire précédent disait « renvoi brut (contrôlé par nos forms) ».
    # Le contrôle par formulaire ne suffit pas : `style` est un JSONField, que
    # l'import, la duplication ou un accès direct peuvent remplir sans passer
    # par le formulaire. Et la sortie est marquée sûre puis posée dans un
    # attribut `style="…"` — un guillemet y ferme l'attribut, un `;` y ajoute
    # une déclaration.
    #
    # `clean_css_value` retire ce qui a une structure en CSS ; on retire ici en
    # plus les guillemets, inoffensifs dans un bloc <style> mais pas dans un
    # attribut. C'est la réserve que css_extras.py énonce dans son en-tête.
    from jeiko.templatetags.css_extras import clean_css_value

    return clean_css_value(val).replace('"', "").replace("'", "")

@register.filter
def css_vars(style_dict):
    """
    Transforme le JSON 'style' en liste de variables CSS:
    {"banner_bg":"#000","btn_radius_px":8} -> "--jk-banner-bg:#000; --jk-btn-radius:8px"
    À utiliser dans un attribut style="" sur #jk-cookie-root.
    """
    if not isinstance(style_dict, dict):
        return ""
    parts = []
    for key, cssvar in _MAPPING.items():
        if key in style_dict:
            v = _fmt_value(key, style_dict[key])
            if v != "":
                parts.append(f"{cssvar}: {v}")
    return mark_safe("; ".join(parts))
