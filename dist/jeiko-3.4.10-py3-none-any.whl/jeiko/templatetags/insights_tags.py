"""
Derniers scores PageSpeed d'une page, pour la barre d'administration.

Pourquoi ces scores remontent dans la barre
-------------------------------------------
Ils n'étaient consultables que depuis un écran dédié, atteint en trois clics
depuis la liste des pages. Or c'est en regardant une page qu'on se demande si
elle est lente — pas en parcourant un tableau. Les afficher là où l'on est
transforme une donnée qu'on va chercher en une donnée qu'on remarque.

La lecture est volontairement bon marché : une requête, mise en cache une
heure. Les mesures ne bougent qu'une fois par jour (cf.
`administration_pages/insights_cron.py`), une barre d'administration n'a aucune
raison d'interroger la base à chaque page vue.
"""

from django import template
from django.core.cache import cache

register = template.Library()

CACHE_TTL = 3600


@register.simple_tag
def page_insight_scores(page):
    """Renvoie {'mobile': int|None, 'desktop': int|None} pour `page`.

    La valeur retenue est la moyenne des quatre catégories PageSpeed, arrondie
    — c'est ce que la liste des pages affiche déjà, on garde le même repère.
    Renvoie des `None` si la page n'a jamais été mesurée : l'appelant affiche
    alors un tiret plutôt qu'un zéro, qui se lirait comme un mauvais score.
    """
    page_id = getattr(page, "pk", None)
    if not page_id:
        return {"mobile": None, "desktop": None}

    key = f"jeiko:insight_scores:{page_id}"
    cached = cache.get(key)
    if cached is not None:
        return cached

    scores = {"mobile": None, "desktop": None}
    try:
        from jeiko.administration_pages.models import PageInsights, Strategy

        fields = ("score_performance", "score_accessibility",
                  "score_best_practices", "score_seo")
        for strategy, label in ((Strategy.MOBILE, "mobile"), (Strategy.DESKTOP, "desktop")):
            latest = (
                PageInsights.objects
                .filter(page_id=page_id, strategy=strategy)
                .order_by("-fetched_at")
                .first()
            )
            if not latest:
                continue
            values = [getattr(latest, f) for f in fields]
            values = [v for v in values if v is not None]
            if values:
                scores[label] = round(sum(values) / len(values))
    except Exception:
        # Une barre d'administration ne tombe pas parce qu'une mesure manque.
        return {"mobile": None, "desktop": None}

    cache.set(key, scores, CACHE_TTL)
    return scores


@register.filter
def insight_level(score):
    """Classe de couleur d'un score, selon les seuils de Google (90 / 50)."""
    if score is None:
        return "none"
    if score >= 90:
        return "good"
    if score >= 50:
        return "average"
    return "poor"
