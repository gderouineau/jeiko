"""
Aide au rendu homogène des champs de formulaire dans l'administration.

Le problème que ce module résout
-------------------------------
48 gabarits admin écrivaient leurs étiquettes à la main, sous la forme :

    <label for="id_page_form_-title">Titre :</label>
    {{ page_form.title }}

Trois conséquences, toutes vérifiées sur les écrans rendus :

*L'étiquette ne désigne rien.* L'identifiant est recopié à la main, donc il
dérive. Sur le formulaire de création de page, les **huit** attributs ``for``
pointaient vers des identifiants inexistants (``id_page_form_-title`` alors que
le préfixe ``page_`` produit ``id_page_-title``). Cliquer l'étiquette ne
focalisait pas le champ, et un lecteur d'écran n'annonçait aucun libellé.

*Le texte d'aide disparaît.* Environ 200 ``help_text`` sont écrits dans les
modèles et les formulaires ; 11 gabarits seulement les affichaient. L'explication
de « Tag URL » existait déjà dans ``Page.url_tag`` sans jamais atteindre l'écran.

*Rien ne signale l'obligatoire.* Aucun marqueur, aucune convention.

Le partiel ``includes/field.html`` rend tout cela une fois pour toutes ; les
filtres ci-dessous lui donnent ce que le langage de gabarit ne sait pas faire
seul : poser une classe sur un widget et reconnaître son type.
"""

from django import template
from django.forms import (
    CheckboxInput,
    CheckboxSelectMultiple,
    ClearableFileInput,
    FileInput,
    RadioSelect,
    Select,
    SelectMultiple,
    Textarea,
)

register = template.Library()


def _widget(field):
    """Widget d'un ``BoundField``, ou ``None`` si l'objet n'en est pas un.

    Les gabarits passent parfois autre chose qu'un champ lié (une chaîne, un
    ``None`` issu d'un ``{% if %}`` mal fermé). On préfère un rendu dégradé à
    une ``TemplateSyntaxError`` en production.
    """
    return getattr(getattr(field, "field", None), "widget", None)


@register.filter
def add_class(field, css):
    """Ajoute des classes CSS au widget, sans écraser celles déjà posées.

    Usage : ``{{ form.title|add_class:"form-control" }}``

    Les classes existantes sont conservées : un widget qui portait déjà une
    classe métier depuis ``forms.py`` la garde. Les doublons sont retirés, en
    conservant l'ordre d'apparition.
    """
    widget = _widget(field)
    if widget is None:
        return field

    existing = widget.attrs.get("class", "")
    seen, merged = set(), []
    for cls in f"{existing} {css}".split():
        if cls not in seen:
            seen.add(cls)
            merged.append(cls)
    return field.as_widget(attrs={**widget.attrs, "class": " ".join(merged)})


@register.filter
def field_class(field):
    """Classe de mise en forme adaptée au widget.

    Les cases à cocher et les boutons radio ne doivent surtout pas recevoir
    ``.form-control`` (largeur 100 %) : ils seraient étirés sur toute la ligne.
    """
    widget = _widget(field)
    if widget is None or isinstance(
        widget, (CheckboxInput, CheckboxSelectMultiple, RadioSelect)
    ):
        return ""
    return "form-control"


@register.filter
def styled(field, extra=""):
    """Rend le widget avec la classe de mise en forme adaptée à son type.

    Usage : ``{{ form.title|styled }}`` — ou ``{{ form.title|styled:"w-50" }}``
    pour ajouter une classe au passage. Existe parce qu'un gabarit Django ne
    peut pas passer le résultat d'un filtre en argument d'un autre :
    ``{{ f|add_class:f|field_class }}`` n'est pas une expression valide.
    """
    css = " ".join(part for part in (field_class(field), extra) if part)
    return add_class(field, css) if css else field


@register.filter
def is_checkbox(field):
    """Vrai pour une case à cocher unique.

    C'est le seul cas où l'étiquette se place APRÈS le champ : une case posée
    sous son libellé se lit visuellement comme appartenant au libellé suivant.
    """
    return isinstance(_widget(field), CheckboxInput)


@register.filter
def is_multi_choice(field):
    """Vrai pour un groupe de cases ou de boutons radio (étiquette au-dessus,
    champ non étiré)."""
    return isinstance(_widget(field), (CheckboxSelectMultiple, RadioSelect))


@register.filter
def is_file(field):
    """Vrai pour un champ de téléversement (rendu spécifique : pas de bordure
    pleine largeur, et le fichier courant s'affiche à côté)."""
    return isinstance(_widget(field), (FileInput, ClearableFileInput))


@register.filter
def is_textarea(field):
    return isinstance(_widget(field), Textarea)


@register.filter
def is_select(field):
    return isinstance(_widget(field), (Select, SelectMultiple))
