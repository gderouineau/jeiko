"""
Filtres de rendu HTML des contenus.

`html_unescape` faisait auparavant :

    mark_safe(html.unescape(value or ""))

soit exactement l'inverse d'une protection : il ré-activait du HTML qui avait
déjà été neutralisé. `&lt;script&gt;alert(1)&lt;/script&gt;` ressortait en
`<script>alert(1)</script>`, exécuté chez tous les visiteurs — administrateurs
compris, donc avec vol de session à la clé.

Le dé-échappement reste nécessaire (les contenus sont stockés échappés par
l'éditeur), mais il est désormais suivi d'un assainissement par liste blanche.
Voir jeiko/sanitize.py pour la liste des balises et attributs autorisés, et le
réglage JEIKO_SANITIZE_HTML.
"""

import html
import re

from django import template
from django.utils.safestring import mark_safe

from jeiko.sanitize import clean_html

register = template.Library()

# Un contenu Quill est toujours découpé en blocs (`<p>`, `<h1>`…`<h6>`, `<ul>`,
# `<blockquote>`…). Ce motif détecte un tel début de bloc pour savoir si le
# contenu porte déjà sa propre structure.
_BLOCK_START_RE = re.compile(
    r"^\s*<(?:h[1-6]|p|ul|ol|li|dl|blockquote|pre|figure|table|div|hr|section|article)\b",
    re.IGNORECASE,
)


@register.filter
def html_unescape(value):
    """
    Restitue le HTML stocké échappé, après assainissement.

    La mise en forme est conservée ; `<script>`, les attributs `on*` et les URL
    `javascript:` sont retirés.
    """
    return mark_safe(clean_html(html.unescape(value or "")))


@register.filter
def ensure_block(value):
    """
    Garantit que le contenu texte porte un élément de bloc de premier niveau.

    L'éditeur Quill enveloppe déjà chaque ligne dans un bloc (`<p>`, `<h1>`…
    `<h6>`, `<ul>`, `<blockquote>`…) : dans ce cas on renvoie le contenu tel
    quel, pour laisser les titres remonter comme vrais `<h1>`…`<h6>` (bon pour
    le référencement) au lieu d'être enfermés dans un `<p>` — imbrication HTML
    invalide qui cassait la sémantique.

    Seul un contenu hérité stocké en texte brut (avant Quill) n'a pas de bloc :
    on l'enveloppe alors dans un `<p>` pour qu'il garde la police du corps de
    texte (`.content p`).
    """
    if not value:
        return value
    if _BLOCK_START_RE.match(str(value)):
        return value
    return mark_safe("<p>" + str(value) + "</p>")


@register.filter
def sanitize_html(value):
    """
    Assainit du HTML BRUT (déjà stocké tel quel, non échappé) avant rendu.

    À utiliser à la place de `|safe` sur un contenu éditable : la mise en forme
    est conservée mais `<script>`, les attributs `on*` et les URL `javascript:`
    sont retirés (liste blanche, cf. jeiko/sanitize.py).
    """
    return mark_safe(clean_html(value or ""))
