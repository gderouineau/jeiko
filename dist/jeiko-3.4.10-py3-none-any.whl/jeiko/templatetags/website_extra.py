# blog/templatetags/blog_extras.py

from django.template import Library, Node

from jeiko.administration.website_cache import get_website_data

register = Library()

class GetWebSiteData(Node):
    def render(self, context):
        # Objet de site mis en cache (identity + logo joints), invalidé par
        # signal — cf. administration/website_cache.py. Évite ~3 requêtes par
        # page pour un objet qui change rarement.
        context['website_data'] = get_website_data()
        return ''

@register.tag(name="get_website_data")
def get_all_menus(parser, token):

    return GetWebSiteData()

