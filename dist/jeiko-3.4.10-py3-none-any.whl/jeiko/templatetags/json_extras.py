"""
Sérialisation JSON sûre pour insertion dans un gabarit.

Historique : ce module exposait un filtre `tojson` qui faisait

    mark_safe(json.dumps(value, ensure_ascii=False))

`json.dumps` n'échappe ni `<`, ni `>`, ni `&`. Le résultat étant inséré dans un
bloc `<script type="application/json">`, il suffisait qu'une chaîne de données
contienne littéralement `</script>` pour que le navigateur referme le bloc et
interprète la suite comme du HTML — soit une injection de script stockée,
déclenchée chez tous les visiteurs, administrateurs compris.

La parade n'est pas de « nettoyer » la valeur mais d'échapper les caractères
qui ont un sens pour l'analyseur HTML. C'est ce que fait le `json_script` de
Django, dont on reprend ici la table d'échappement : les séquences \\uXXXX
restent du JSON valide et `JSON.parse` les rend à l'identique.
"""

import json

from django import template
from django.utils.html import json_script as _django_json_script
from django.utils.safestring import mark_safe

register = template.Library()

#: Les trois caractères qui ont un sens pour l'analyseur HTML et qu'il faut
#: neutraliser avant d'insérer du JSON dans un `<script>`. Table de Django.
#:
#: Publique, et non préfixée : la sérialisation n'a pas toujours lieu en
#: gabarit. `questionnaires_expert.views.client.build_chart_json` construit son
#: JSON en Python et l'importe d'ici — deux copies de cette table divergeraient
#: le jour où l'une serait corrigée sans l'autre.
JSON_SCRIPT_ESCAPES = {
    ord(">"): "\\u003E",
    ord("<"): "\\u003C",
    ord("&"): "\\u0026",
}


@register.filter
def tojson(value):
    """
    Sérialise en JSON insérable dans un bloc <script>, accents conservés.

    À réserver aux gabarits où la balise <script> est déjà écrite. Pour un
    nouveau bloc, préférer `json_script`, qui génère la balise et son
    identifiant :

        {{ content.data|json_script:"mon-bloc-data" }}
    """
    encoded = json.dumps(value, ensure_ascii=False)
    return mark_safe(encoded.translate(JSON_SCRIPT_ESCAPES))


@register.filter(name="json_script")
def json_script(value, element_id=None):
    """Expose le `json_script` de Django comme filtre de gabarit."""
    return _django_json_script(value, element_id)
