"""
Rattrape le drapeau `is_product` sur les modèles de contenu déjà rattachés à
un type de produit.

`is_product` a été ajouté (0002) avec default=False, et shop ne le positionne
qu'à la création du CustomObjectModel. Les modèles créés avant restaient donc
à False. Maintenant que l'administration des objets personnalisés s'en sert
pour masquer les fiches produit, ces modèles anciens continueraient d'y
apparaître — et permettraient d'y créer des objets sans Product associé.

Le critère est la relation elle-même (`product_types`), pas une heuristique
sur le slug : un modèle rattaché à un type de produit est un modèle produit.
"""

from django.db import migrations


def marquer_les_modeles_produit(apps, schema_editor):
    CustomObjectModel = apps.get_model("custom_objects", "CustomObjectModel")
    (
        CustomObjectModel.objects
        .filter(product_types__isnull=False, is_product=False)
        .distinct()
        .update(is_product=True)
    )


def demarquer(apps, schema_editor):
    # Retour en arrière : on remet à False ce que la migration a marqué.
    CustomObjectModel = apps.get_model("custom_objects", "CustomObjectModel")
    (
        CustomObjectModel.objects
        .filter(product_types__isnull=False, is_product=True)
        .distinct()
        .update(is_product=False)
    )


class Migration(migrations.Migration):

    dependencies = [
        ("custom_objects", "0006_customobject_main_image"),
        # La relation inverse `product_types` vient de shop.ProductType.
        ("shop", "0005_product_linked_course"),
    ]

    operations = [
        migrations.RunPython(marquer_les_modeles_produit, demarquer),
    ]
