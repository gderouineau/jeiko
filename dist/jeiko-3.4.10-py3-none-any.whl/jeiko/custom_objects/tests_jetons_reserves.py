# jeiko/custom_objects/tests_jetons_reserves.py
"""
`[%titre%]` doit fonctionner dans un gabarit, sans qu'on ait à déclarer un champ.

Le défaut
---------
`build_object_context` ne renvoyait que les champs DÉCLARÉS par le type de
fiche. Or le titre n'est pas un champ : c'est une propriété de la fiche
elle-même, saisie dans le même formulaire, affichée dans les listes, utilisée
comme titre d'onglet.

Écrire `[%titre%]` dans un gabarit — le premier réflexe de qui découvre le
système — laissait donc la chaîne « [%titre%] » **telle quelle sur la page
publique**. Aucune erreur, aucun avertissement : un gabarit visiblement cassé,
et rien pour dire que `titre` n'était pas un champ.

C'est exactement ce qui est arrivé en montant les trois formules JEIKO : les
quatre champs déclarés se sont substitués, `[%titre%]` est resté écrit.

La règle de priorité
--------------------
Les jetons réservés sont posés AVANT la boucle sur les champs. Un type qui
déclare un champ `titre` l'emporte donc sur le jeton réservé — ce que le modèle
déclare explicitement gagne sur ce que le système offre par défaut. Sans quoi
on casserait des gabarits en service pour leur rendre service.
"""

from django.test import TestCase

from jeiko.administration_pages.models import Page
from jeiko.custom_objects.models import (
    CustomObject, CustomObjectField, CustomObjectModel, CustomObjectValue,
)
from jeiko.custom_objects.services import build_object_context


class JetonsReservesTests(TestCase):
    def setUp(self):
        gabarit = Page.objects.create(
            title="Gabarit", url_tag="gab-jetons", is_custom_object_template=True
        )
        self.modele = CustomObjectModel.objects.create(
            name="Formule", slug="formule-jetons", page_template=gabarit
        )
        self.fiche = CustomObject.objects.create(
            model=self.modele, title="Équipe", slug="equipe", is_published=True
        )

    def test_le_titre_est_disponible_sans_champ_declare(self):
        contexte = build_object_context(self.fiche)
        self.assertEqual(contexte["titre"], "Équipe")

    def test_le_slug_aussi(self):
        self.assertEqual(build_object_context(self.fiche)["slug"], "equipe")

    def test_title_en_anglais_pour_les_gabarits_existants(self):
        """
        Les deux orthographes : le reste de JEIKO parle anglais en base, et un
        gabarit écrit avant cette correction a pu tenter « [%title%] ».
        """
        self.assertEqual(build_object_context(self.fiche)["title"], "Équipe")

    def test_un_champ_declare_titre_l_emporte(self):
        champ = CustomObjectField.objects.create(
            model=self.modele, code="titre", label="Titre affiché",
            field_type=CustomObjectField.TEXT, position=1,
        )
        CustomObjectValue.objects.create(
            obj=self.fiche, field=champ, value_text="Formule Équipe 5 accès"
        )
        self.assertEqual(
            build_object_context(self.fiche)["titre"],
            "Formule Équipe 5 accès",
            "Un champ explicitement déclaré doit primer sur le jeton réservé, "
            "sans quoi cette correction casserait des gabarits en service.",
        )


class NomDuProduitDansLaPageTests(TestCase):
    """
    `[%titre%]` sur une page produit doit rendre LE NOM DU PRODUIT.

    Pourquoi c'est le titre de la fiche et rien d'autre
    ---------------------------------------------------
    `Product` ne porte pas de nom : il a une référence (`sku`), un prix, un
    stock. Le nom — « pot de cornichons », « séance de coaching 1 h »,
    « voiture » — vit entièrement dans `CustomObject.title`. Il n'y a donc
    aucune ambiguïté à lever : le titre de la fiche EST le nom du produit, et
    c'est ce que doit rendre `[%titre%]`.

    Le piège du gabarit partagé
    ---------------------------
    Une page modèle sert TOUTES les fiches de son type — c'est tout l'intérêt.
    Si le corps de page était mis en cache par le seul identifiant de page,
    les trois produits afficheraient le nom du premier servi. Ce n'est pas le
    cas : `public_page_vary` ajoute `co:<id>:<version>` à la clé. Ce test le
    vérifie plutôt que de le supposer, parce que la panne serait spectaculaire
    et silencieuse — chaque page correcte prise isolément, toutes fausses
    ensemble.
    """

    def setUp(self):
        from jeiko.administration_pages.models import (
            Bloc, Content, ContentText, Line, Section,
        )

        self.gabarit = Page.objects.create(
            title="Gabarit produit", url_tag="gab-produit-nom",
            is_custom_object_template=True, active=True,
        )
        section = Section.objects.create(page=self.gabarit, position=0)
        ligne = Line.objects.create(
            section=section, position=0, columns_type="12", columns_number=1
        )
        bloc = Bloc.objects.create(line=ligne, position=1, position_in_column=0)
        contenu = Content.objects.create(bloc=bloc, content_type="TEXT")
        contenu.content_text = ContentText.objects.create(text="<h1>[%titre%]</h1>")
        contenu.save()

        self.modele = CustomObjectModel.objects.create(
            name="Produit", slug="produit-nom", page_template=self.gabarit,
            is_product=True,
        )

    def _fiche(self, titre, slug):
        return CustomObject.objects.create(
            model=self.modele, title=titre, slug=slug, is_published=True
        )

    def test_le_titre_rendu_est_le_nom_du_produit(self):
        for nom in ("Pot de cornichons", "Séance de coaching 1 h", "Voiture"):
            with self.subTest(produit=nom):
                fiche = self._fiche(nom, slugify_simple(nom))
                self.assertEqual(build_object_context(fiche)["titre"], nom)

    def test_deux_fiches_du_meme_gabarit_ne_se_melangent_pas(self):
        """
        La clé de cache doit distinguer les fiches, pas seulement les pages.
        """
        from jeiko.administration_pages.page_cache import public_page_vary

        cornichons = self._fiche("Pot de cornichons", "cornichons")
        coaching = self._fiche("Séance de coaching 1 h", "coaching")

        self.assertNotEqual(
            public_page_vary(self.gabarit, obj=cornichons),
            public_page_vary(self.gabarit, obj=coaching),
            "Deux fiches partagent la même clé de cache : elles afficheraient "
            "toutes le nom de la première servie.",
        )


def slugify_simple(texte):
    from django.utils.text import slugify

    return slugify(texte)
