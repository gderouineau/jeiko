from django import forms

from .models import (
    CustomObjectModel,
    CustomObjectField,
    CustomObject,
    CustomObjectValue,
    CustomObjectMetadata,
)


class CustomObjectModelForm(forms.ModelForm):
    """
    Formulaire pour créer / modifier un modèle d’objet.
    Ex : Article, Livre, Produit, Formation, etc.
    """

    class Meta:
        model = CustomObjectModel
        fields = [
            "name",
            "slug",
            "page_template",
        ]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "slug": forms.TextInput(attrs={"class": "form-control"}),
            "page_template": forms.Select(attrs={"class": "form-control"}),
        }


class CustomObjectFieldForm(forms.ModelForm):
    """
    Formulaire pour gérer les champs d’un modèle.
    Ex :
        - code = title_1, field_type = text
        - code = description, field_type = rich_text
        - code = cover_image, field_type = image
    """

    code = forms.CharField(
        label="Code",
        help_text="Code utilisé dans les templates : [%code%]. Sera converti en slug (ex: 'Mon Titre' -> 'mon-titre').",
        widget=forms.TextInput(attrs={"class": "form-control"})
    )

    class Meta:
        model = CustomObjectField
        fields = [
            "code",
            "label",
            "field_type",
            "required",
            "help_text",
            "position",
        ]
        widgets = {
            "label": forms.TextInput(attrs={"class": "form-control"}),
            "field_type": forms.Select(attrs={"class": "form-control"}),
            "required": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "help_text": forms.TextInput(attrs={"class": "form-control"}),
            "position": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
        }

    def clean_code(self):
        code = self.cleaned_data.get("code")
        if code:
            from django.utils.text import slugify
            return slugify(code)
        return code




# =====================================================================
#  Ajout imports pour ImageForm
# =====================================================================
from jeiko.administration_pages.forms import ImageForm
from jeiko.administration_pages.models import ImageContent

from .services import discard_image_if_orphan

# =====================================================================
#  Surcharges des forms pour gérer l'upload image
# =====================================================================

class CustomObjectForm(forms.ModelForm):
    """
    Formulaire pour une instance d’objet.
    Ex :
        - Article : "Les 5 erreurs à éviter"
        - Produit : "Atelier de céramique - Niveau 1"
    """
    
    class Meta:
        model = CustomObject
        fields = [
            "model",
            "title",
            "slug",
            "is_published",
            "main_image",
        ]
        widgets = {
            "model": forms.Select(attrs={"class": "form-control"}),
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "slug": forms.TextInput(attrs={"class": "form-control"}),
            "is_published": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "main_image": forms.Select(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Image déjà en place, mémorisée avant que super().save() n'écrase
        # l'instance : elle devient candidate à la suppression si un envoi de
        # fichier la remplace (cf. discard_image_if_orphan).
        self._previous_main_image = (
            self.instance.main_image if self.instance and self.instance.pk else None
        )

        # On utilise directement self.data et self.files peuplés par super().__init__
        # instance=None pour toujours créer une NOUVELLE image si upload
        self.image_form = ImageForm(
            data=self.data if self.is_bound else None,
            files=self.files if self.is_bound else None,
            instance=None, 
            prefix=f"{self.prefix or 'co'}_main_img"
        )
        
        # Amélioration UI : rendre le champ main_image (Select) optionnel ou caché si on veut juste uploader
        # Pour l'instant on laisse le Select visible (choix existant) + Upload (nouveau).
        self.fields['main_image'].required = False
        self.fields['main_image'].label = "Choisir une image existante"

        # IMPORTANT : rendre l'upload optionnel dans la validation du sous-form
        self.image_form.fields['original_image'].required = False
        self.image_form.fields['alt'].required = False
        self.image_form.fields['original_image'].label = "" 
        self.image_form.fields['alt'].label = "Texte alternatif (alt)"

    def is_valid(self):
        valid = super().is_valid()
        # On ne valide le sous-form que si on a envoyé des données (POST)
        if self.image_form.is_bound:
             # Hack : si image_form n'a pas de fichier, on considère valide.
             prefix = self.image_form.prefix
             has_file = False
             if self.files:
                 for k in self.files.keys():
                     if k.startswith(prefix):
                         has_file = True
                         break
             
             if has_file:
                 return valid and self.image_form.is_valid()
        
        return valid

    def save(self, commit=True):
        # 1. Image upload handling
        uploaded_image = None
        if self.image_form.is_bound and self.image_form.is_valid():
             original = self.image_form.cleaned_data.get('original_image')
             if original:
                 uploaded_image = self.image_form.save()
        
        # 2. Main object save (shallow)
        # On force commit=False pour pouvoir modifier l'instance avant save final
        obj = super().save(commit=False)
        
        # 3. Override si upload
        if uploaded_image:
            obj.main_image = uploaded_image

        if commit:
            obj.save()
            self.save_m2m() # Important pour ModelForm

            # L'ancienne image n'est plus référencée ici : on la reprend si
            # plus personne d'autre ne s'en sert.
            if uploaded_image and self._previous_main_image_replaced(uploaded_image):
                discard_image_if_orphan(self._previous_main_image)

        return obj

    def _previous_main_image_replaced(self, uploaded_image):
        previous = self._previous_main_image
        return previous is not None and previous.pk != uploaded_image.pk


class CustomObjectValueForm(forms.ModelForm):
    """
    Formulaire pour la valeur d’un champ donné.
    Utilisé en formset (un formulaire par champ du modèle).
    """

    class Meta:
        model = CustomObjectValue
        fields = [
            "field",
            "value_text",
            "image",
            "video_url",
            # ⬇⬇⬇ nouveaux pour le type BUTTON
            "button_label",
            "button_page",
            "button_test_slug",
            "button_external_url",
        ]
        widgets = {
            "field": forms.HiddenInput(),
            "value_text": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 3,
                }
            ),
            "image": forms.Select(attrs={"class": "form-control"}),
            "video_url": forms.URLInput(attrs={"class": "form-control"}),
            "button_label": forms.TextInput(attrs={"class": "form-control"}),
            "button_page": forms.Select(attrs={"class": "form-control"}),
            "button_test_slug": forms.TextInput(attrs={"class": "form-control"}),
            "button_external_url": forms.URLInput(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        """
        Adapter les labels selon le type de champ.
        """
        super().__init__(*args, **kwargs)

        field = None
        # Cas 1 : instance existante (Update)
        if self.instance and getattr(self.instance, 'field_id', None):
            field = self.instance.field
        # Cas 2 : initial data (Create)
        elif self.initial and 'field' in self.initial:
            field = self.initial['field']

        # Initialisation du sous-form Image
        # Prefix unique indispensable car on est dans un formset
        # self.prefix est ex: "values_formset-0"
        img_prefix = f"{self.prefix}_subimg" if self.prefix else "subimg"

        # Image déjà en place : candidate à la suppression si un envoi de
        # fichier la remplace (cf. discard_image_if_orphan).
        self._previous_image = (
            self.instance.image if self.instance and self.instance.pk else None
        )

        # Utilisation de self.data / self.files
        # instance=None pour toujours créer une NOUVELLE image si upload
        self.image_form = ImageForm(
            data=self.data if self.is_bound else None,
            files=self.files if self.is_bound else None,
            instance=None, 
            prefix=img_prefix
        )
        # On rend l'upload optionnel dans le form (Validation manuelle plus bas)
        self.image_form.fields['original_image'].required = False
        self.image_form.fields['alt'].required = False

        if field:
            # Texte / Rich text
            if field.field_type in (field.TEXT, field.RICH_TEXT):
                self.fields["value_text"].label = field.label

            # Image
            elif field.field_type == field.IMAGE:
                self.fields["image"].label = "Choisir image existante (" + field.label + ")"
                self.fields["image"].required = False

            # Vidéo
            elif field.field_type == field.VIDEO:
                self.fields["video_url"].label = field.label

            # Bouton
            elif field.field_type == field.BUTTON:
                self.fields["button_label"].label = "Texte du bouton"
                self.fields["button_page"].label = "Page cible"
                self.fields["button_test_slug"].label = "Slug de questionnaire"
                self.fields["button_external_url"].label = "URL externe"
    
    def _get_field(self):
        """Helper to get the field from instance or cleaned_data"""
        # Try instance first (for existing values)
        if self.instance and getattr(self.instance, 'field_id', None):
            return self.instance.field
        # Try cleaned_data (for bound forms during validation/save)
        if hasattr(self, 'cleaned_data') and 'field' in self.cleaned_data:
            return self.cleaned_data['field']
        # Try initial (for new forms)
        if self.initial and 'field' in self.initial:
            return self.initial['field']
        return None
    
    def has_changed(self):
        """Override to include image_form changes"""
        # Check if main form has changed
        main_changed = super().has_changed()
        
        # Check if image_form has changed (file uploaded)
        target_field = self._get_field()
        if target_field and target_field.field_type == CustomObjectField.IMAGE:
            if self.image_form.is_bound:
                # Si un fichier a été uploadé, considérer comme modifié
                has_file = self._has_uploaded_file()
                if has_file:
                    return True

        return main_changed

    def _has_uploaded_file(self):
        """Vrai si un fichier a été envoyé pour le sous-formulaire image."""
        if not self.files:
            return False
        prefix = self.image_form.prefix
        return any(key.startswith(prefix) for key in self.files.keys())

    def is_valid(self):
        valid = super().is_valid()
        # Si c'est un champ Image, on doit valider le sous-form
        # Mais seulement si un fichier est uploadé
        target_field = self._get_field()
        if target_field and target_field.field_type == CustomObjectField.IMAGE:
             if self._has_uploaded_file():
                 # On force la validation de image_form
                 # Comme on a mis required=False, ça passera, mais ça permet de clean
                 if not self.image_form.is_valid():
                     return False

        return valid

    def save(self, commit=True):
        # 1. Image upload handling
        uploaded_image = None
        target_field = self._get_field()
        if target_field and target_field.field_type == CustomObjectField.IMAGE:
             if self.image_form.is_bound and self.image_form.is_valid():
                  original = self.image_form.cleaned_data.get('original_image')
                  if original:
                      uploaded_image = self.image_form.save()

        # 2. Main object save (shallow)
        obj = super().save(commit=False)

        # 3. Override if upload
        if uploaded_image:
            obj.image = uploaded_image

        if commit:
            obj.save()
            self.save_m2m() # Important pour ModelForm

            # L'image remplacée n'est plus référencée ici : on la reprend si
            # plus personne d'autre ne s'en sert.
            previous = self._previous_image
            if uploaded_image and previous is not None and previous.pk != uploaded_image.pk:
                discard_image_if_orphan(previous)

        return obj


class CustomObjectMetadataForm(forms.ModelForm):
    """
    SEO spécifique à une instance d’objet.
    """

    class Meta:
        model = CustomObjectMetadata
        fields = [
            "title",
            "description",
        ]
        widgets = {
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "description": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 3,
                }
            ),
        }
