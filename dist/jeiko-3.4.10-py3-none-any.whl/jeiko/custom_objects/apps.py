from django.apps import AppConfig


class CustomObjectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko.custom_objects'

    def ready(self):
        # Branche l'invalidation du cache de corps de fiche (signals.py).
        from . import signals
        signals.connect()
