"""
Self-hosting des Google Fonts (public).

Objectif : ne plus émettre des dizaines de `<link>` render-blocking vers
fonts.googleapis.com sur les pages publiques, mais servir les polices depuis
notre propre domaine.

Principe (décidé le 2026-08-06) :
- À l'enregistrement des polices en admin, on télécharge SYNCHRONEMENT les
  fichiers woff2 nécessaires (les polices sont une config de départ, changée
  très rarement — un save un peu plus lent est acceptable).
- On génère un CSS `@font-face` local par site, servi depuis MEDIA_URL.
- L'éditeur/admin, lui, continue d'utiliser le CDN Google (fluidité d'édition).

Robustesse : toute erreur réseau est isolée. Si Google est injoignable, on
journalise et on conserve le bundle précédent — jamais on ne casse un save.

Stockage :
- woff2 partagés entre sites : MEDIA_ROOT/fonts/families/<slug>/<fichier>.woff2
- CSS par site :               MEDIA_ROOT/fonts/site-<website_id>.css
"""

from __future__ import annotations

import logging
import os
import re
import time

from django.conf import settings
from django.utils.text import slugify

logger = logging.getLogger(__name__)

# Mémo-cache en process de la réponse CSS2 par famille. Un même enregistrement
# admin peut déclencher plusieurs reconstructions (save de h1..h6 puis du Fonts,
# ou édition en masse) : sans cache, chacune re-solliciterait Google. TTL court :
# on veut juste absorber la rafale d'une requête, pas figer durablement.
_CSS2_TTL_SECONDS = 300
_CSS2_CACHE: dict[str, tuple[float, str]] = {}

# Familles génériques ou système : jamais téléchargées depuis Google.
GENERIC_FAMILIES = {
    "serif", "sans-serif", "monospace", "cursive", "fantasy", "system-ui",
    "ui-serif", "ui-sans-serif", "ui-monospace", "ui-rounded",
    "arial", "georgia", "helvetica", "tahoma", "verdana", "courier new",
    "times new roman", "times", "courier", "inherit", "initial", "unset",
}

# Rôles d'un objet Fonts (les 13 — google_fonts.html en oubliait 2 :
# sub_menu et sub_menu_hover ; corrigé ici).
FONT_ROLES = (
    "links", "links_hover", "menu", "menu_hover", "sub_menu", "sub_menu_hover",
    "text", "h1", "h2", "h3", "h4", "h5", "h6",
)

# Breakpoints (3 objets Fonts par site).
FONTS_SLOTS = ("fonts_computer", "fonts_tablet", "fonts_phone")

# On ne garde que le latin pour un site francophone : évite de télécharger
# cyrillique/grec/vietnamien (Google renvoie ~9 sous-ensembles par variante).
KEEP_SUBSETS = {"latin", "latin-ext"}

# Jeu de variantes demandé : 400 + 700, normal + italique. Couvre le gras et
# l'italique posés EN LIGNE par Quill (non stockés dans Font.weight), sinon le
# navigateur synthétise un faux-gras / faux-italique.
_ITAL_WGHT_AXIS = "ital,wght@0,400;0,700;1,400;1,700"

# Chaîne de replis si la famille ne propose pas tous les axes (Google renvoie
# 400 sinon). On essaie du plus complet au plus simple.
_AXIS_FALLBACKS = (
    _ITAL_WGHT_AXIS,
    "wght@400;700",
    "wght@400",
    "",  # famille par défaut, sans axe
)

_BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

# /* subset */ suivi d'un bloc @font-face { ... }
_FACE_RE = re.compile(
    r"/\*\s*(?P<subset>[a-z0-9\-\[\]]+)\s*\*/\s*(?P<block>@font-face\s*\{[^}]*\})",
    re.IGNORECASE,
)
_SRC_URL_RE = re.compile(r"url\((?P<url>https://[^)]+?\.woff2)\)", re.IGNORECASE)


def _is_generic(family: str) -> bool:
    return not family or family.strip().lower() in GENERIC_FAMILIES


def family_slug(family: str) -> str:
    return slugify(family) or "font"


def _fonts_root() -> str:
    return os.path.join(settings.MEDIA_ROOT, "fonts")


def collect_families(website) -> set[str]:
    """Familles Google uniques réellement utilisées par le site (tous rôles,
    tous breakpoints). Ignore les génériques/système."""
    families: set[str] = set()
    for slot in FONTS_SLOTS:
        fonts = getattr(website, slot, None)
        if not fonts:
            continue
        for role in FONT_ROLES:
            font = getattr(fonts, role, None)
            fam = getattr(font, "family", None)
            if fam and not _is_generic(fam):
                families.add(fam.strip())
    return families


def _fetch_css2(family: str, session) -> str | None:
    """Récupère le CSS2 Google pour `family`, en essayant les jeux d'axes du
    plus complet au plus simple. Retourne le texte CSS ou None.

    Mémoïsé (TTL court) : plusieurs rebuilds au sein d'une même requête ne font
    qu'un seul aller-retour réseau par famille."""
    cached = _CSS2_CACHE.get(family)
    if cached and (time.monotonic() - cached[0]) < _CSS2_TTL_SECONDS:
        return cached[1]

    base = "https://fonts.googleapis.com/css2"
    fam_param = family.replace(" ", "+")
    for axis in _AXIS_FALLBACKS:
        spec = f"{fam_param}:{axis}" if axis else fam_param
        url = f"{base}?family={spec}&display=swap"
        try:
            r = session.get(url, headers={"User-Agent": _BROWSER_UA}, timeout=10)
        except Exception as exc:  # noqa: BLE001 — on isole toute erreur réseau
            logger.warning("Google Fonts injoignable pour %r (%s) : %s", family, axis, exc)
            return None
        if r.status_code == 200 and ".woff2" in r.text:
            _CSS2_CACHE[family] = (time.monotonic(), r.text)
            return r.text
        # 400 = combinaison d'axes non supportée par cette famille -> on tente
        # le repli suivant. Tout autre code : on abandonne cette famille.
        if r.status_code != 400:
            logger.warning("Google Fonts a répondu %s pour %r", r.status_code, family)
            return None
    logger.warning("Aucune variante récupérable pour la police %r", family)
    return None


def _download_woff2(url: str, dest_dir: str, session) -> str | None:
    """Télécharge un woff2 (nom = dernier segment d'URL, stable et unique côté
    Google). Skip si déjà présent. Retourne le chemin absolu local ou None."""
    basename = url.rsplit("/", 1)[-1]
    if not basename.endswith(".woff2"):
        basename += ".woff2"
    dest = os.path.join(dest_dir, basename)
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return dest
    try:
        r = session.get(url, headers={"User-Agent": _BROWSER_UA}, timeout=15)
        r.raise_for_status()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Échec téléchargement woff2 %s : %s", url, exc)
        return None
    os.makedirs(dest_dir, exist_ok=True)
    tmp = dest + ".part"
    with open(tmp, "wb") as fh:
        fh.write(r.content)
    os.replace(tmp, dest)
    return dest


def build_family_css(family: str, session) -> str:
    """CSS `@font-face` local pour une famille : télécharge les woff2 des
    sous-ensembles retenus et réécrit les `src` vers MEDIA_URL. '' si échec."""
    css = _fetch_css2(family, session)
    if not css:
        return ""

    slug = family_slug(family)
    dest_dir = os.path.join(_fonts_root(), "families", slug)
    media_url = settings.MEDIA_URL.rstrip("/")

    out_blocks: list[str] = []
    for m in _FACE_RE.finditer(css):
        subset = m.group("subset").lower()
        if subset not in KEEP_SUBSETS:
            continue
        block = m.group("block")

        url_m = _SRC_URL_RE.search(block)
        if not url_m:
            continue
        local_path = _download_woff2(url_m.group("url"), dest_dir, session)
        if not local_path:
            continue

        basename = os.path.basename(local_path)
        local_url = f"{media_url}/fonts/families/{slug}/{basename}"
        block = _SRC_URL_RE.sub(f"url({local_url})", block)
        out_blocks.append(block)

    if not out_blocks:
        logger.warning("Police %r : aucun woff2 exploitable, ignorée", family)
        return ""
    return "\n".join(out_blocks)


def rebuild_site_fonts(website) -> dict:
    """(Re)génère le bundle CSS local des polices du site.

    Retourne un récap {families, ok, failed, css_path}. Ne lève jamais : en cas
    d'échec total on conserve le CSS précédent (le bundle n'est pas écrasé).
    """
    import requests  # import local : dépendance lourde, hors chemin de rendu

    families = sorted(collect_families(website))
    session = requests.Session()

    parts: list[str] = []
    ok, failed = [], []
    for fam in families:
        css = build_family_css(fam, session)
        if css:
            parts.append(f"/* {fam} */\n{css}")
            ok.append(fam)
        else:
            failed.append(fam)

    fonts_root = _fonts_root()
    css_path = os.path.join(fonts_root, f"site-{website.id}.css")

    if not parts:
        # Rien à écrire : soit le site n'a que des polices système, soit Google
        # est injoignable. On ne détruit pas un bundle existant.
        if not families:
            # Aucune police custom : un bundle vide est légitime.
            os.makedirs(fonts_root, exist_ok=True)
            with open(css_path, "w", encoding="utf-8") as fh:
                fh.write("/* aucune police Google à self-héberger */\n")
        else:
            logger.warning(
                "Bundle fonts du site %s non régénéré (échec total) — "
                "ancien bundle conservé.", website.id
            )
        return {"families": families, "ok": ok, "failed": failed, "css_path": css_path}

    os.makedirs(fonts_root, exist_ok=True)
    header = "/* Généré automatiquement par jeiko.fonts_selfhost — ne pas éditer. */\n"
    tmp = css_path + ".part"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(header + "\n".join(parts) + "\n")
    os.replace(tmp, css_path)

    logger.info("Bundle fonts site %s : %d OK, %d échec(s)", website.id, len(ok), len(failed))
    return {"families": families, "ok": ok, "failed": failed, "css_path": css_path}


def site_css_relurl(website) -> str | None:
    """URL relative (sous MEDIA_URL) du bundle du site s'il existe, sinon None."""
    css_path = os.path.join(_fonts_root(), f"site-{website.id}.css")
    if os.path.exists(css_path):
        return f"{settings.MEDIA_URL.rstrip('/')}/fonts/site-{website.id}.css"
    return None


def gc_orphan_families() -> None:
    """Supprime les dossiers de familles woff2 (`fonts/families/<slug>/`) qui ne
    sont plus référencés par AUCUN site. À appeler après reconstruction : quand
    une police cesse d'être utilisée, ses fichiers ne s'accumulent plus.

    On calcule l'ensemble GLOBAL des familles utilisées (tous les WebSite), pas
    seulement celles du site qu'on vient de reconstruire — sinon on effacerait
    des polices encore utilisées ailleurs. N'échoue jamais."""
    import shutil

    families_root = os.path.join(_fonts_root(), "families")
    if not os.path.isdir(families_root):
        return

    try:
        from jeiko.administration.models import WebSite
        keep = set()
        for site in WebSite.objects.all():
            for fam in collect_families(site):
                keep.add(family_slug(fam))
    except Exception:  # noqa: BLE001 — la purge ne doit jamais casser un save
        logger.exception("GC fonts : impossible de lister les familles utilisées, purge annulée")
        return

    for name in os.listdir(families_root):
        path = os.path.join(families_root, name)
        if os.path.isdir(path) and name not in keep:
            shutil.rmtree(path, ignore_errors=True)
            logger.info("GC fonts : dossier famille orphelin supprimé (%s)", name)


def rebuild_for_websites(websites) -> None:
    """Reconstruit le bundle de chaque site, en isolant les erreurs : un échec
    (réseau, disque…) ne doit jamais remonter jusqu'au save de l'admin."""
    for site in websites:
        try:
            rebuild_site_fonts(site)
        except Exception:  # noqa: BLE001
            logger.exception("Self-host fonts : échec de reconstruction du site %s",
                             getattr(site, "id", "?"))
    # Purge des woff2 devenus orphelins (police retirée de la config).
    try:
        gc_orphan_families()
    except Exception:  # noqa: BLE001
        logger.exception("Self-host fonts : échec de la purge des familles orphelines")
