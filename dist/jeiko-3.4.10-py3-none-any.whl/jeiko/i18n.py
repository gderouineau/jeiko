"""
La langue de l'INTERFACE, par opposition à celle du contenu.

Le besoin
---------
95 % des sites JEIKO sont monolingues — mais pas forcément en français. Un
exploitant hispanophone qui tient un site en espagnol se heurtait à une
administration entièrement française : ce n'est pas un problème de traduction
de contenu, c'est un problème de langue de l'OUTIL. C'est celui-là qu'on règle
ici, et il touche tout le monde ; un moteur multilingue de contenu ne servirait
que les 5 % restants.

Pourquoi un middleware maison
------------------------------
`LocaleMiddleware` de Django décide de la langue à partir du cookie, puis de
l'en-tête `Accept-Language`. Il s'exécute **avant** `AuthenticationMiddleware`
— l'ordre est imposé par Django — donc `request.user` n'existe pas encore et
il ne peut pas consulter une préférence de compte.

D'où cette pièce, placée après l'authentification : elle relit la préférence de
la personne et réactive la langue si elle diffère. La préférence suit ainsi le
compte, pas le navigateur — un exploitant qui se connecte depuis un autre poste
retrouve son interface dans sa langue.

Ce que ce module ne fait PAS
-----------------------------
Il ne touche pas à la langue du **contenu** des pages publiques. Un site en
français reste en français pour ses visiteurs, quelle que soit la langue dans
laquelle son administrateur travaille. Les deux réglages sont indépendants, et
les confondre ferait qu'un exploitant anglophone publierait sans le vouloir un
site en anglais.
"""

import logging

from django.conf import settings
from django.utils import translation

logger = logging.getLogger("jeiko")


def langues_disponibles():
    """Les couples (code, nom) proposés, tels que le projet les déclare."""
    return list(getattr(settings, "LANGUAGES", []))


def est_disponible(code):
    """
    Une langue proposée par ce site, et elle seule.

    Sans ce filtre, une valeur restée en base après un changement de
    configuration — ou glissée par un formulaire — activerait une langue sans
    traduction. L'interface retomberait silencieusement sur l'anglais de
    Django, ce qui ressemble à une panne plutôt qu'à un choix.
    """
    if not code:
        return False
    return any(code == disponible for disponible, _ in langues_disponibles())


def langue_de_l_utilisateur(user):
    """
    La langue d'administration d'une personne, ou `None` si elle n'a rien choisi.

    `None` et non la langue par défaut : l'appelant doit pouvoir distinguer
    « cette personne veut l'espagnol » de « cette personne n'a rien demandé ».
    Le second cas doit suivre le site, y compris quand celui-ci change de
    langue par la suite.
    """
    profil = getattr(user, "profile", None)
    code = getattr(profil, "langue_admin", "") if profil else ""
    return code if est_disponible(code) else None


class LangueDeLAdministrationMiddleware:
    """
    Active la langue choisie par la personne connectée.

    À placer **après** `AuthenticationMiddleware` : avant, `request.user`
    n'existe pas et la préférence est invisible.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        user = getattr(request, "user", None)
        if user is not None and user.is_authenticated:
            code = langue_de_l_utilisateur(user)
            if code and code != translation.get_language():
                translation.activate(code)
                # `request.LANGUAGE_CODE` est ce que lisent les gabarits et
                # `{% get_current_language %}`. Le laisser à la valeur posée
                # par LocaleMiddleware afficherait un sélecteur en désaccord
                # avec la page qu'il surmonte.
                request.LANGUAGE_CODE = code

        return self.get_response(request)
