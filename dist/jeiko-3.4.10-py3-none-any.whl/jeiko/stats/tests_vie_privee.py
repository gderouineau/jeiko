# jeiko/stats/tests_vie_privee.py
"""
La mesure d'audience reste anonyme — et c'est ce qui la dispense de consentement.

Ce que ces tests protègent
--------------------------
`PageView` ne porte ni adresse IP, ni identifiant de session, ni identifiant de
compte, ni empreinte d'appareil. Rien n'est déposé sur l'appareil du visiteur.
C'est **pour cette raison** que le site n'a pas à demander un consentement pour
mesurer son audience.

Cette propriété ne se voit pas : elle tient à l'absence de quelques colonnes.
Un jour, quelqu'un voudra « dédoublonner les visiteurs » et ajoutera un champ
`ip` ou un cookie d'identification — geste d'une ligne, parfaitement
raisonnable en apparence, qui fait basculer toute la mesure dans le RGPD et
rend le site non conforme sans qu'aucun test ne bronche.

Ces tests bronchent. Ils ne disent pas « n'ajoutez jamais » : ils disent
« si vous ajoutez cela, la position juridique change, allez la retraiter ».

R-01 : l'écart d'origine était l'inverse de ce qu'on croyait. Le bandeau
promettait un réglage de mesure d'audience qui n'existait pas — les fonctions
`jeikoStartAnalytics` n'étaient définies nulle part — alors que la mesure,
elle, n'avait rien à demander.
"""

import pathlib
import re

from django.test import SimpleTestCase

from jeiko.stats.models import PageView

GABARITS = pathlib.Path(__file__).resolve().parent.parent / "templates"

#: Tout champ dont le nom évoque un identifiant de personne ou d'appareil.
#: La liste est volontairement large : mieux vaut un test à réexaminer qu'un
#: champ qui passe.
CHAMPS_INTERDITS = (
    "ip", "ip_address", "adresse_ip", "remote_addr",
    "session", "session_key", "user", "utilisateur",
    "visitor", "visiteur", "client_id", "device_id",
    "fingerprint", "empreinte", "cookie",
)


class MesureAnonymeTests(SimpleTestCase):
    def test_aucun_identifiant_de_personne_dans_pageview(self):
        champs = {f.name for f in PageView._meta.get_fields()}
        fautifs = sorted(champs & set(CHAMPS_INTERDITS))

        self.assertEqual(
            fautifs, [],
            f"PageView porte maintenant {fautifs} : la mesure n'est plus "
            f"anonyme. Elle entre dans le RGPD et exige une base légale, une "
            f"information et une durée de conservation — et le bandeau cookies "
            f"doit alors vraiment proposer un choix. Voir l'en-tête de "
            f"stats/middleware.py.",
        )

    def test_le_beacon_ne_depose_rien_sur_l_appareil(self):
        """
        Le beacon renvoie l'identifiant de la vue et une durée. S'il se mettait
        à écrire un cookie ou du `localStorage`, le consentement ePrivacy
        deviendrait obligatoire — même sans donnée personnelle.
        """
        source = (
            pathlib.Path(__file__).resolve().parent / "middleware.py"
        ).read_text()
        # On ne regarde que le fragment injecté dans la page.
        fragment = source[source.index("snippet = f"):source.index("</script>")]

        for stockage in ("document.cookie", "localStorage", "sessionStorage", "indexedDB"):
            with self.subTest(stockage=stockage):
                self.assertNotIn(stockage, fragment)


class BandeauSansPromesseVideTests(SimpleTestCase):
    """
    Les gabarits de base ne doivent plus appeler une mesure inexistante.

    `if (window.jeikoStartAnalytics) …` ne levait jamais : le code paraissait
    piloter un dispositif d'audience et ne pilotait rien. Un `if` sur une
    fonction absente est une promesse qu'aucune erreur ne vient démentir.
    """

    BASES = (
        "base.html",
        "base_questionnaire.html",
        "courses/base_courses.html",
    )

    def test_plus_aucun_appel_a_une_fonction_inexistante(self):
        for nom in self.BASES:
            with self.subTest(gabarit=nom):
                source = (GABARITS / nom).read_text()
                # On retire les commentaires, qui expliquent justement le défaut.
                sans_commentaires = re.sub(r"^\s*//.*$", "", source, flags=re.MULTILINE)
                self.assertNotIn("window.jeikoStartAnalytics", sans_commentaires)
                self.assertNotIn("window.jeikoStopAnalytics", sans_commentaires)
