"""
Client-facing views for courses app.
Views for users accessing and consuming course content.
"""
import mimetypes
import os

from django.conf import settings
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse, Http404, FileResponse
from django.utils.encoding import iri_to_uri
from django.views.decorators.http import require_http_methods
from django.views.decorators.cache import never_cache
from django.utils import timezone
from django.db.models import Q

from ..models import (
    Course, Section, VideoContent, PDFContent, TextContent, QuizContent,
    CourseEnrollment, SectionProgress, QuizAttempt
)
from ..utils import check_section_access, get_video_url
from ..utils_progress import update_course_progress


@login_required
@never_cache
def my_courses(request):
    """
    Liste des formations de l'utilisateur avec progression.
    """
    enrollments = CourseEnrollment.objects.filter(
        user=request.user,
        status__in=[CourseEnrollment.STATUS_ACTIVE, CourseEnrollment.STATUS_COMPLETED]
    ).select_related('course').order_by('-enrolled_at')
    
    # Calculer le point de reprise pour chaque enrollment
    for enrollment in enrollments:
        # Récupérer les sections complétées
        completed_section_ids = list(SectionProgress.objects.filter(
            enrollment=enrollment,
            is_completed=True
        ).values_list('section_id', flat=True))
        
        # Trouver la première section non complétée
        # Note: Cette approche est simplifiée. Pour une précision parfaite, il faudrait charger toute la structure
        # comme dans course_detail, mais ça peut être lourd pour une liste.
        # On va faire une requête optimisée pour trouver la première section non complétée.
        
        # Récupérer toutes les sections publiées du cours dans l'ordre
        sections = Section.objects.filter(
            chapter__part__course=enrollment.course,
            is_published=True,
            chapter__is_published=True,
            chapter__part__is_published=True
        ).order_by('chapter__part__position', 'chapter__position', 'position')
        
        resume_url = None
        first_url = None
        
        for sec in sections:
            from django.urls import reverse
            url = reverse('jeiko_courses:jeiko_courses_client:section_view', args=[enrollment.course.slug, sec.id])
            
            if not first_url:
                first_url = url
                
            if sec.id not in completed_section_ids:
                resume_url = url
                break
        
        if not resume_url:
            if completed_section_ids:
                from django.urls import reverse
                resume_url = reverse('jeiko_courses:jeiko_courses_client:course_complete', args=[enrollment.course.slug])
            else:
                resume_url = first_url
                
        enrollment.resume_url = resume_url

    context = {
        'enrollments': enrollments,
    }
    return render(request, 'courses/my_courses.html', context)


@never_cache
def course_detail(request, course_slug):
    """
    Page d'accueil d'une formation avec structure parties/chapitres/sections.
    """
    course = get_object_or_404(Course, slug=course_slug, is_active=True)

    # Produit boutique qui vend cette formation (pour proposer l'achat quand
    # l'utilisateur n'a pas encore l'accès). related_name 'products' sur
    # Product.linked_course ; le moins cher d'abord.
    linked_product = course.products.filter(is_active=True).order_by('price_ht').first()

    # Vérifier l'accès
    has_access = False
    enrollment = None
    
    if request.user.is_authenticated:
        if request.user.is_staff:
            # Le staff a toujours accès. On charge l'inscription si elle existe
            # (pour afficher sa progression) SANS jamais dégrader l'accès.
            has_access = True
            enrollment = CourseEnrollment.objects.filter(
                user=request.user, course=course
            ).first()
        elif not course.is_restricted:
            has_access = True
        else:
            try:
                enrollment = CourseEnrollment.objects.get(user=request.user, course=course)
                has_access = enrollment.is_access_valid()
            except CourseEnrollment.DoesNotExist:
                pass
    elif not course.is_restricted:
        has_access = True
    
    # Charger la structure du cours
    parts = course.parts.filter(is_published=True).prefetch_related(
        'chapters',
        'chapters__sections'
    ).order_by('position')
    
    # Calculer la progression et le point de reprise
    completed_section_ids = []
    completed_chapter_ids = []
    completed_part_ids = []
    resume_section_url = None
    first_section_url = None
    
    if enrollment:
        completed_section_ids = list(SectionProgress.objects.filter(
            enrollment=enrollment,
            is_completed=True
        ).values_list('section_id', flat=True))
        
        # Logique pour déterminer les chapitres/parties complétés et le point de reprise
        found_resume_point = False
        
        for part in parts:
            part_fully_completed = True
            part_has_chapters = False
            
            for chapter in part.chapters.all():
                if not chapter.is_published:
                    continue
                part_has_chapters = True
                
                chapter_fully_completed = True
                chapter_has_sections = False
                
                for sec in chapter.sections.all():
                    if not sec.is_published:
                        continue
                    chapter_has_sections = True
                    
                    # Sauvegarder la première section absolue
                    if not first_section_url:
                        from django.urls import reverse
                        first_section_url = reverse('jeiko_courses:jeiko_courses_client:section_view', args=[course.slug, sec.id])
                    
                    if sec.id not in completed_section_ids:
                        chapter_fully_completed = False
                        part_fully_completed = False
                        
                        # C'est la première section non complétée -> point de reprise
                        if not found_resume_point:
                            from django.urls import reverse
                            resume_section_url = reverse('jeiko_courses:jeiko_courses_client:section_view', args=[course.slug, sec.id])
                            found_resume_point = True
                
                if chapter_has_sections and chapter_fully_completed:
                    completed_chapter_ids.append(chapter.id)
                elif not chapter_has_sections:
                    completed_chapter_ids.append(chapter.id)
                else:
                    part_fully_completed = False
            
            if part_has_chapters and part_fully_completed:
                completed_part_ids.append(part.id)
            elif not part_has_chapters:
                completed_part_ids.append(part.id)
    
    # Si tout est complété ou pas de point de reprise trouvé mais inscrit, reprendre au début ou à la fin ?
    # Si inscrit mais pas de progression, resume_section_url sera la première section (définie dans la boucle)
    if enrollment and not resume_section_url:
        if completed_section_ids:
            # Tout est fini ? Rediriger vers la page de fin ou la dernière section ?
            # Pour l'instant, disons page de fin
            from django.urls import reverse
            resume_section_url = reverse('jeiko_courses:jeiko_courses_client:course_complete', args=[course.slug])
        else:
            # Rien commencé
            resume_section_url = first_section_url
    context = {
        'course': course,
        'has_access': has_access,
        'enrollment': enrollment,
        'parts': parts,
        'completed_section_ids': completed_section_ids,
        'completed_chapter_ids': completed_chapter_ids,
        'completed_part_ids': completed_part_ids,
        'resume_section_url': resume_section_url,
        'linked_product': linked_product,
    }
    return render(request, 'courses/course_detail.html', context)


@login_required
@never_cache
def section_view(request, course_slug, section_id):
    """
    Vue d'une section (vidéo, texte, PDF, quiz).
    """
    section = get_object_or_404(
        Section.objects.select_related(
            'chapter__part__course'
        ),
        id=section_id,
        chapter__part__course__slug=course_slug
    )
    
    course = section.chapter.part.course
    
    # Vérifier l'accès
    has_access, reason = check_section_access(request.user, section)
    if not has_access:
        return render(request, 'courses/access_denied.html', {
            'course': course,
            'section': section,
            'reason': reason
        }, status=403)
    
    # Récupérer ou créer l'enrollment
    enrollment = None
    if request.user.is_authenticated:
        if course.is_restricted or request.user.is_staff:
            enrollment, created = CourseEnrollment.objects.get_or_create(
                user=request.user,
                course=course,
                defaults={
                    'status': CourseEnrollment.STATUS_ACTIVE,
                    'has_payed': False,
                    'granted_by': request.user if request.user.is_staff else None
                }
            )
    
    # Récupérer le contenu selon le type
    content = None
    video_url = None
    
    if section.section_type == Section.SECTION_TYPE_VIDEO:
        content = getattr(section, 'video_content', None)
        if content:
            video_url = get_video_url(content, request.user)
    elif section.section_type == Section.SECTION_TYPE_TEXT:
        content = getattr(section, 'text_content', None)
    elif section.section_type == Section.SECTION_TYPE_PDF:
        content = getattr(section, 'pdf_content', None)
    elif section.section_type == Section.SECTION_TYPE_QUIZ:
        content = getattr(section, 'quiz_content', None)
        
    # Récupérer la tentative de quiz si existante
    quiz_attempt = None
    if section.section_type == Section.SECTION_TYPE_QUIZ and content:
        # Try to find enrollment first (might be None for staff)
        if enrollment:
            quiz_attempt = QuizAttempt.objects.filter(
                user=request.user,
                quiz=content,
                enrollment=enrollment
            ).order_by('-completed_at').first()
        elif request.user.is_staff:
             # For staff without enrollment, we might want to show the last attempt if we can find one
             # But QuizAttempt requires enrollment. 
             # If we created a dummy enrollment in quiz_submit, we should find it.
             dummy_enrollment = CourseEnrollment.objects.filter(user=request.user, course=course).first()
             if dummy_enrollment:
                 quiz_attempt = QuizAttempt.objects.filter(
                    user=request.user,
                    quiz=content,
                    enrollment=dummy_enrollment
                ).order_by('-completed_at').first()
    
    # Navigation (section précédente/suivante)
    all_sections = Section.objects.filter(
        chapter__part__course=course,
        is_published=True
    ).order_by(
        'chapter__part__position',
        'chapter__position',
        'position'
    )
    
    section_ids = list(all_sections.values_list('id', flat=True))
    try:
        current_index = section_ids.index(section.id)
        prev_section_id = section_ids[current_index - 1] if current_index > 0 else None
        next_section_id = section_ids[current_index + 1] if current_index < len(section_ids) - 1 else None
    except (ValueError, IndexError):
        prev_section_id = None
        next_section_id = None
        
    # Determine navigation labels
    next_section_label = "Section suivante"
    is_last_section = False
    
    if next_section_id:
        next_section_obj = Section.objects.select_related('chapter__part').get(id=next_section_id)
        if next_section_obj.chapter_id != section.chapter_id:
            if next_section_obj.chapter.part_id != section.chapter.part_id:
                next_section_label = "Partie suivante"
            else:
                next_section_label = "Chapitre suivant"
    else:
        is_last_section = True
        next_section_label = "Terminer la formation"
    
    # Récupérer la progression
    section_progress = None
    completed_section_ids = []
    if enrollment:
        section_progress = SectionProgress.objects.filter(
            enrollment=enrollment,
            section=section
        ).first()
        completed_section_ids = list(SectionProgress.objects.filter(
            enrollment=enrollment,
            is_completed=True
        ).values_list('section_id', flat=True))

    # Charger la structure pour la sidebar
    parts = course.parts.filter(is_published=True).prefetch_related(
        'chapters',
        'chapters__sections'
    ).order_by('position')
    
    # Calculer les chapitres et parties complétés
    completed_chapter_ids = []
    completed_part_ids = []
    
    if enrollment:
        for part in parts:
            part_fully_completed = True
            part_has_chapters = False
            
            for chapter in part.chapters.all():
                if not chapter.is_published:
                    continue
                part_has_chapters = True
                
                chapter_fully_completed = True
                chapter_has_sections = False
                
                for sec in chapter.sections.all():
                    if not sec.is_published:
                        continue
                    chapter_has_sections = True
                    if sec.id not in completed_section_ids:
                        chapter_fully_completed = False
                        part_fully_completed = False
                        # On ne break pas ici car on veut vérifier tous les chapitres pour la partie
                
                if chapter_has_sections and chapter_fully_completed:
                    completed_chapter_ids.append(chapter.id)
                elif not chapter_has_sections:
                    # Chapitre vide = complété ? Disons oui pour l'affichage
                    completed_chapter_ids.append(chapter.id)
                else:
                    part_fully_completed = False
            
            if part_has_chapters and part_fully_completed:
                completed_part_ids.append(part.id)
            elif not part_has_chapters:
                completed_part_ids.append(part.id)
    
    context = {
        'course': course,
        'section': section,
        'content': content,
        'video_url': video_url,
        'enrollment': enrollment,
        'section_progress': section_progress,
        'prev_section_id': prev_section_id,
        'next_section_id': next_section_id,
        'quiz_attempt': quiz_attempt,
        'next_section_label': next_section_label,
        'is_last_section': is_last_section,
        'parts': parts,
        'completed_section_ids': completed_section_ids,
        'completed_chapter_ids': completed_chapter_ids,
        'completed_part_ids': completed_part_ids,
    }
    
    return render(request, 'courses/section_view.html', context)


@login_required
@never_cache
@require_http_methods(["POST"])
def quiz_submit(request, course_slug, quiz_id):
    """
    Soumission d'un quiz.
    """
    quiz = get_object_or_404(QuizContent, id=quiz_id)
    course = quiz.section.chapter.part.course
    
    # Vérifier l'accès
    has_access, reason = check_section_access(request.user, quiz.section)
    if not has_access:
        return JsonResponse({'error': 'Accès refusé'}, status=403)
    
    # Récupérer l'enrollment
    try:
        enrollment = CourseEnrollment.objects.get(user=request.user, course=course)
    except CourseEnrollment.DoesNotExist:
        if request.user.is_staff:
            # Create a dummy enrollment for staff testing
            enrollment, created = CourseEnrollment.objects.get_or_create(
                user=request.user,
                course=course,
                defaults={
                    'status': CourseEnrollment.STATUS_ACTIVE,
                    'has_payed': False,
                    'granted_by': request.user
                }
            )
        else:
            return JsonResponse({'error': 'Non inscrit'}, status=403)
    
    # Récupérer les réponses soumises.
    # IMPORTANT: request.POST.items() n'expose que la DERNIÈRE valeur d'une clé
    # répétée. Pour les questions à choix multiples (plusieurs <input> de même
    # name), il faut impérativement passer par getlist().
    answers_data = {}
    for key in request.POST:
        if not key.startswith('question_'):
            continue
        question_id = key.replace('question_', '', 1)
        parsed = []
        for v in request.POST.getlist(key):
            try:
                parsed.append(int(v))
            except (TypeError, ValueError):
                # Valeur non numérique -> on l'ignore au lieu de planter (500).
                continue
        answers_data[question_id] = parsed

    # Calculer le score
    total_points = 0
    earned_points = 0

    for question in quiz.questions.all():
        total_points += question.points
        question_answers = answers_data.get(str(question.id), [])
        correct_answers = list(question.answers.filter(is_correct=True).values_list('id', flat=True))

        # Vérifier si la réponse est correcte.
        # On exige au moins une bonne réponse définie, sinon une question mal
        # configurée (aucune réponse correcte) attribuerait les points à une
        # soumission vide (set() == set()).
        if correct_answers and set(question_answers) == set(correct_answers):
            earned_points += question.points
    
    score_percentage = (earned_points / total_points * 100) if total_points > 0 else 0
    is_passed = score_percentage >= quiz.passing_score
    
    # Créer la tentative
    attempt = QuizAttempt.objects.create(
        user=request.user,
        quiz=quiz,
        enrollment=enrollment,
        completed_at=timezone.now(),
        score_percentage=score_percentage,
        is_passed=is_passed,
        answers_data=answers_data
    )
    
    # Mettre à jour la progression si réussi
    if is_passed:
        SectionProgress.objects.update_or_create(
            enrollment=enrollment,
            section=quiz.section,
            defaults={
                'is_completed': True,
                'completed_at': timezone.now(),
                'is_skipped': False
            }
        )
        update_course_progress(enrollment)
    
    return JsonResponse({
        'success': True,
        'score': score_percentage,
        'passed': is_passed,
        'passing_score': quiz.passing_score,
        'can_skip': quiz.allow_skip
    })


@login_required
@never_cache
@require_http_methods(["POST"])
def quiz_skip(request, course_slug, quiz_id):
    """
    Passer un quiz without completing it.
    """
    quiz = get_object_or_404(QuizContent, id=quiz_id)

    if not quiz.allow_skip:
        return JsonResponse({'error': 'Ce quiz ne peut pas être passé'}, status=400)

    # `quiz_submit`, juste au-dessus, vérifie l'accès à la section ; celle-ci ne
    # le faisait pas. Une inscription suspendue ou expirée pouvait donc encore
    # marquer des sections comme faites et faire progresser le parcours.
    has_access, _reason = check_section_access(request.user, quiz.section)
    if not has_access:
        return JsonResponse({'error': 'Accès refusé'}, status=403)

    course = quiz.section.chapter.part.course

    # Récupérer l'enrollment
    try:
        enrollment = CourseEnrollment.objects.get(user=request.user, course=course)
    except CourseEnrollment.DoesNotExist:
        if request.user.is_staff:
            # Create a dummy enrollment for staff testing
            enrollment, created = CourseEnrollment.objects.get_or_create(
                user=request.user,
                course=course,
                defaults={
                    'status': CourseEnrollment.STATUS_ACTIVE,
                    'has_payed': False,
                    'granted_by': request.user
                }
            )
        else:
            return JsonResponse({'error': 'Non inscrit'}, status=403)
    
    # Créer une tentative "skipped"
    attempt = QuizAttempt.objects.create(
        user=request.user,
        quiz=quiz,
        enrollment=enrollment,
        was_skipped=True,
        completed_at=timezone.now()
    )
    
    # Mettre à jour la progression (marqué comme passé/skipped)
    SectionProgress.objects.update_or_create(
        enrollment=enrollment,
        section=quiz.section,
        defaults={
            'is_completed': True, # On considère complété pour avancer
            'completed_at': timezone.now(),
            'is_skipped': True
        }
    )
    update_course_progress(enrollment)
    
    return JsonResponse({'success': True, 'skipped': True})


@login_required
@never_cache
def course_certificate(request, course_slug):
    """
    Génération de certificat (TODO).
    """
    course = get_object_or_404(Course, slug=course_slug)
    
    try:
        enrollment = CourseEnrollment.objects.get(
            user=request.user,
            course=course,
            status=CourseEnrollment.STATUS_COMPLETED
        )
    except CourseEnrollment.DoesNotExist:
        return HttpResponse("La formation n'est pas terminée", status=403)
    
    # TODO: Générer un PDF de certificat
    context = {
        'course': course,
        'enrollment': enrollment,
        'user': request.user,
    }
    
    return render(request, 'courses/certificate.html', context)


@login_required
@never_cache
def course_complete(request, course_slug):
    """
    Page de félicitations fin de cours.

    Réservée aux personnes ayant réellement accès à la formation (inscrit,
    staff, ou formation libre) — pas d'affichage pour une URL devinée.
    """
    course = get_object_or_404(Course, slug=course_slug)

    allowed = (
        request.user.is_staff
        or not course.is_restricted
        or CourseEnrollment.objects.filter(user=request.user, course=course).exists()
    )
    if not allowed:
        return redirect('jeiko_courses:jeiko_courses_client:course_detail', course_slug=course.slug)

    return render(request, 'courses/course_complete.html', {'course': course})


@login_required
@never_cache
@require_http_methods(["POST"])
def mark_section_complete(request, course_slug, section_id):
    """
    Marquer une section (Texte/PDF) comme terminée.
    """
    # Lier la section au cours de l'URL : on ne valide pas une section
    # arbitraire d'un autre cours en passant un section_id quelconque.
    section = get_object_or_404(
        Section.objects.select_related('chapter__part__course'),
        id=section_id,
        chapter__part__course__slug=course_slug,
    )
    course = section.chapter.part.course

    # Contrôle d'accès (bloque suspendu/expiré ; autorise le staff et le libre).
    has_access, reason = check_section_access(request.user, section)
    if not has_access:
        return JsonResponse({'error': 'Accès refusé'}, status=403)

    # Vérifier l'enrollment
    try:
        enrollment = CourseEnrollment.objects.get(user=request.user, course=course)
    except CourseEnrollment.DoesNotExist:
        if request.user.is_staff:
             # Create dummy for staff
            enrollment, created = CourseEnrollment.objects.get_or_create(
                user=request.user,
                course=course,
                defaults={
                    'status': CourseEnrollment.STATUS_ACTIVE,
                    'has_payed': False,
                    'granted_by': request.user
                }
            )
        else:
            return JsonResponse({'error': 'Non inscrit'}, status=403)
            
    # Mettre à jour la progression
    SectionProgress.objects.update_or_create(
        enrollment=enrollment,
        section=section,
        defaults={
            'is_completed': True,
            'completed_at': timezone.now()
        }
    )
    
    new_progress = update_course_progress(enrollment)
    
    return JsonResponse({
        'success': True,
        'progress': new_progress
    })


# =============================================================================
# PROTECTED FILE SERVING
# =============================================================================

def _serve_protected_file(file_field, content_type):
    """
    Sert un fichier local uniquement après contrôle des permissions par l'appelant.

    En production, les fichiers de cours NE DOIVENT PAS être servis directement
    par le serveur web sur /media/ (sinon l'URL devinée contourne toute
    authentification). Deux modes :

    - Si settings.COURSES_XACCEL_MEDIA_PREFIX est défini, on délègue à Nginx via
      X-Accel-Redirect (la `location` correspondante doit être marquée `internal;`
      et pointer sur MEDIA_ROOT). Le fichier ne transite alors pas par Python et
      reste inaccessible en direct.
    - Sinon (dev), on streame via FileResponse. Django 4.2+ gère nativement les
      requêtes HTTP Range, donc le déplacement dans la vidéo fonctionne.
    """
    filename = os.path.basename(file_field.name)
    disposition = f'inline; filename="{filename}"'

    xaccel_prefix = getattr(settings, 'COURSES_XACCEL_MEDIA_PREFIX', None)
    if xaccel_prefix:
        # file_field.name est relatif à MEDIA_ROOT ; on le préfixe par la
        # location interne Nginx (ex: '/protected-media/').
        internal_path = xaccel_prefix.rstrip('/') + '/' + file_field.name.lstrip('/')
        response = HttpResponse(content_type=content_type)
        response['X-Accel-Redirect'] = iri_to_uri(internal_path)
        response['Content-Disposition'] = disposition
        return response

    response = FileResponse(file_field.open('rb'), content_type=content_type)
    response['Content-Disposition'] = disposition
    return response


@login_required
def serve_video(request, video_id):
    """
    Sert une vidéo protégée après vérification des permissions.
    """
    video = get_object_or_404(VideoContent, id=video_id)

    # Vérifier l'accès
    has_access, reason = check_section_access(request.user, video.section)
    if not has_access:
        raise Http404("Vidéo non trouvée")

    # Si stockage local, servir le fichier avec le bon type MIME (mp4, webm,
    # mov…), déduit de l'extension — plus de 'video/mp4' codé en dur.
    if video.storage_type == VideoContent.STORAGE_LOCAL and video.video_file:
        content_type = mimetypes.guess_type(video.video_file.name)[0] or 'video/mp4'
        return _serve_protected_file(video.video_file, content_type)

    # Sinon, rediriger vers l'URL signée
    video_url = get_video_url(video, request.user)
    if video_url:
        return redirect(video_url)

    raise Http404("Vidéo non disponible")


@login_required
def serve_pdf(request, pdf_id):
    """
    Sert un PDF protégé après vérification des permissions.
    """
    pdf = get_object_or_404(PDFContent, id=pdf_id)

    # Vérifier l'accès
    has_access, reason = check_section_access(request.user, pdf.section)
    if not has_access:
        raise Http404("PDF non trouvé")

    # Si stockage local, servir le fichier
    if pdf.storage_type == PDFContent.STORAGE_LOCAL and pdf.file:
        return _serve_protected_file(pdf.file, 'application/pdf')

    # Sinon, rediriger vers l'URL distante
    if pdf.remote_url:
        return redirect(pdf.remote_url)

    raise Http404("PDF non disponible")
