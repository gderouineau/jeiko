"""
Views for managing the ordering of course content (Parts, Chapters, Sections, Questions).
"""
from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import permission_required
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods
from django.db import transaction
from django.db.models import Max
from django.contrib import messages

from ..models import Part, Chapter, Section, QuizQuestion

def _move_item(item, direction, sibling_filter):
    """
    Generic function to move an item up or down within its siblings.
    sibling_filter: dict to filter siblings (e.g. {'course': item.course})

    Part/Chapter/Section ont une contrainte unique_together (parent, position).
    PostgreSQL vérifie les contraintes UNIQUE immédiatement : on ne peut donc
    PAS écrire directement la position de destination tant que l'autre élément
    l'occupe encore. On passe par une position temporaire libre (max + 1).
    """
    model = item.__class__

    if direction == 'up':
        sibling = model.objects.filter(
            **sibling_filter,
            position__lt=item.position
        ).order_by('-position').first()
    elif direction == 'down':
        sibling = model.objects.filter(
            **sibling_filter,
            position__gt=item.position
        ).order_by('position').first()
    else:
        return False

    if not sibling:
        return False

    with transaction.atomic():
        # Verrouiller les deux lignes pour éviter les courses concurrentes.
        item = model.objects.select_for_update().get(pk=item.pk)
        sibling = model.objects.select_for_update().get(pk=sibling.pk)

        item_position = item.position
        sibling_position = sibling.position

        # Position temporaire garantie libre parmi les frères.
        temp_position = (
            model.objects.filter(**sibling_filter).aggregate(m=Max('position'))['m'] or 0
        ) + 1

        item.position = temp_position
        item.save(update_fields=['position'])

        sibling.position = item_position
        sibling.save(update_fields=['position'])

        item.position = sibling_position
        item.save(update_fields=['position'])

    return True


@permission_required("courses.change_course", raise_exception=True)
@never_cache
@require_http_methods(["POST"])
def move_part(request, part_id, direction):
    part = get_object_or_404(Part, id=part_id)
    if _move_item(part, direction, {'course': part.course}):
        messages.success(request, "Position mise à jour.")
    return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=part.course.id)


@permission_required("courses.change_course", raise_exception=True)
@never_cache
@require_http_methods(["POST"])
def move_chapter(request, chapter_id, direction):
    chapter = get_object_or_404(Chapter, id=chapter_id)
    if _move_item(chapter, direction, {'part': chapter.part}):
        messages.success(request, "Position mise à jour.")
    return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=chapter.part.course.id)


@permission_required("courses.change_course", raise_exception=True)
@never_cache
@require_http_methods(["POST"])
def move_section(request, section_id, direction):
    section = get_object_or_404(Section, id=section_id)
    if _move_item(section, direction, {'chapter': section.chapter}):
        messages.success(request, "Position mise à jour.")
    return redirect('jeiko_courses:jeiko_courses_admin:course_structure', course_id=section.chapter.part.course.id)


@permission_required("courses.change_course", raise_exception=True)
@never_cache
@require_http_methods(["POST"])
def move_quiz_question(request, question_id, direction):
    question = get_object_or_404(QuizQuestion, id=question_id)
    if _move_item(question, direction, {'quiz': question.quiz}):
        messages.success(request, "Position mise à jour.")
    return redirect('jeiko_courses:jeiko_courses_admin:quiz_content_edit', content_id=question.quiz.id)
