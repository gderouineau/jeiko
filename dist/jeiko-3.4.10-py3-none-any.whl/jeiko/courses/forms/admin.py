"""
Admin forms for courses management.
"""
from django import forms
from django.core.exceptions import ValidationError
from ..models import (
    Course, Part, Chapter, Section,
    VideoStorageProvider, VideoContent, TextContent, PDFContent,
    QuizContent, QuizQuestion, QuizAnswer,
    CourseEnrollment
)


class CourseForm(forms.ModelForm):
    """Création et modification d'une formation."""

    class Meta:
        model = Course
        fields = [
            'title', 'slug', 'description', 'thumbnail',
            'is_active', 'is_restricted', 'level', 'estimated_duration'
        ]
        labels = {
            'title': "Titre de la formation",
            'slug': "Adresse de la formation",
            'description': "Description",
            'thumbnail': "Image de présentation",
            'is_active': "Formation visible",
            'is_restricted': "Accès réservé",
            'level': "Niveau",
            'estimated_duration': "Durée estimée (minutes)",
        }
        help_texts = {
            'slug': "Dernier segment de l'adresse, en minuscules et sans accent. "
                    "Exemple : « django-debutants ».",
            'description': "Présentée sur la fiche de la formation, avant inscription.",
            'thumbnail': "Vignette affichée dans la liste des formations.",
            'is_active': "Décochée, la formation n'apparaît nulle part, même pour les inscrits.",
            'is_restricted': "Cochée, la formation exige un achat ou un accès accordé à la main.",
            'estimated_duration': "Indicatif : aide l'élève à savoir dans quoi il s'engage.",
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Titre de la formation'}),
            'slug': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'django-debutants'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'level': forms.Select(attrs={'class': 'form-control'}),
            'estimated_duration': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Durée en minutes'}),
        }


class PartForm(forms.ModelForm):
    """Création et modification d'une part de formation."""

    class Meta:
        model = Part
        # `course` est posé par la vue, pas par le formulaire : voir le commentaire
        # ci-dessus. L'y laisser rendait la création impossible.
        fields = ['title', 'description', 'content_details', 'is_published']
        labels = {
            'title': "Titre",
            'description': "Description",
            'content_details': "Contenu détaillé",
            'is_published': "Publié",
        }
        help_texts = {
            'description': "Courte introduction, affichée avant d'ouvrir la partie.",
            'content_details': "Notes internes ou complément affiché à l'élève.",
            'is_published': "Décoché, la partie reste invisible pour les élèves.",
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'content_details': forms.Textarea(attrs={'class': 'form-control', 'rows': 6}),
        }


class ChapterForm(forms.ModelForm):
    """Création et modification d'une chapter de formation."""

    class Meta:
        model = Chapter
        # `part` est posé par la vue (cf. PartForm).
        fields = ['title', 'description', 'content_details', 'is_published']
        labels = {
            'title': "Titre",
            'description': "Description",
            'content_details': "Contenu détaillé",
            'is_published': "Publié",
        }
        help_texts = {
            'description': "Courte introduction, affichée avant d'ouvrir le chapitre.",
            'content_details': "Notes internes ou complément affiché à l'élève.",
            'is_published': "Décoché, le chapitre reste invisible pour les élèves.",
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'content_details': forms.Textarea(attrs={'class': 'form-control', 'rows': 6}),
        }


class SectionForm(forms.ModelForm):
    """Création et modification d'une section de formation."""

    class Meta:
        model = Section
        # `chapter` est posé par la vue (cf. PartForm).
        fields = ['title', 'description', 'content_details', 'section_type', 'is_published']
        labels = {
            'title': "Titre",
            'description': "Description",
            'content_details': "Contenu détaillé",
            'is_published': "Publié",
            'section_type': "Type de section",
        }
        help_texts = {
            'description': "Courte introduction, affichée avant d'ouvrir la section.",
            'content_details': "Notes internes ou complément affiché à l'élève.",
            'is_published': "Décoché, la section reste invisible pour les élèves.",
            'section_type': "Vidéo, texte, PDF ou quiz — définit ce que l'élève verra.",
        }
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'content_details': forms.Textarea(attrs={'class': 'form-control', 'rows': 6}),
            'content_details': forms.Textarea(attrs={'class': 'form-control', 'rows': 6}),
            'section_type': forms.Select(attrs={'class': 'form-control'}),
        }


class VideoStorageProviderForm(forms.ModelForm):
    """Form for creating/editing video storage providers."""
    
    config_help = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'readonly': True, 'rows': 8, 'class': 'help-text'}),
        initial="""
Exemples de configuration JSON selon le type:

Vimeo: {"access_token": "...", "client_id": "...", "client_secret": "..."}
Bunny: {"library_id": "...", "api_key": "...", "cdn_hostname": "...", "token_key": "..."}
S3: {"bucket": "...", "region": "...", "access_key": "...", "secret_key": "..."}
FTP: {"host": "...", "port": 21, "username": "...", "password": "...", "base_path": "..."}
        """.strip()
    )
    
    class Meta:
        model = VideoStorageProvider
        fields = ['name', 'provider_type', 'is_active', 'config', 'url_signing_enabled', 'url_expiry_seconds', 'notes']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: Vimeo Production'}),
            'provider_type': forms.Select(attrs={'class': 'form-control'}),
            'config': forms.Textarea(attrs={'class': 'form-control monospace', 'rows': 6, 'placeholder': '{"key": "value"}'}),
            'url_expiry_seconds': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': '3600'}),
            'notes': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }
    
    def clean_config(self):
        """Validate JSON config."""
        import json
        config = self.cleaned_data.get('config')
        if config:
            try:
                if isinstance(config, str):
                    json.loads(config)
            except json.JSONDecodeError as e:
                raise ValidationError(f"JSON invalide : {e}")
        return config


class VideoContentForm(forms.ModelForm):
    """Form for creating/editing video content."""
    
    class Meta:
        model = VideoContent
        fields = [
            'section', 'title', 'description', 'duration_seconds', 'thumbnail', 'is_preview',
            'storage_type', 'video_file', 'remote_provider', 'remote_video_id', 'remote_video_hash',
            'direct_url', 'ftp_path'
        ]
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'duration_seconds': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Durée en secondes'}),
            'storage_type': forms.Select(attrs={'class': 'form-control'}),
            'remote_video_id': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'ID de la vidéo'}),
            'remote_video_hash': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Hash de la vidéo (ex: Vimeo non listée)'}),
            'direct_url': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'https://...'}),
            'ftp_path': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '/videos/...'}),
        }


class EnrollmentGrantForm(forms.Form):
    """Form to grant course access to a user."""
    
    user = forms.ModelChoiceField(
        queryset=None,  # Will be set in __init__
        widget=forms.Select(attrs={'class': 'form-control'}),
        label="Utilisateur"
    )
    course = forms.ModelChoiceField(
        queryset=None,  # Will be set in __init__
        widget=forms.Select(attrs={'class': 'form-control'}),
        label="Formation"
    )
    notes = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        label="Notes"
    )
    access_expires_at = forms.DateTimeField(
        required=False,
        widget=forms.DateTimeInput(attrs={'class': 'form-control', 'type': 'datetime-local'}),
        label="Date d'expiration (optionnel)"
    )
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from django.contrib.auth import get_user_model
        User = get_user_model()
        self.fields['user'].queryset = User.objects.filter(is_active=True).order_by('email')
        self.fields['course'].queryset = Course.objects.filter(is_active=True, is_restricted=True).order_by('title')
