"""
Calcul de la progression d'une inscription.

Historiquement, deux fonctions calculaient la progression avec des règles
DIFFÉRENTES (`utils.calculate_course_progress` vs cette fonction), ce qui
faisait « bouger » le pourcentage selon le chemin de code emprunté. La logique
est désormais unifiée dans `utils.calculate_course_progress`. Ce module ne
garde qu'un shim pour préserver les imports existants.
"""
from .utils import calculate_course_progress


def update_course_progress(enrollment):
    """
    Alias rétro-compatible vers `utils.calculate_course_progress`.

    Retourne un float (les appelants JSON — mark_section_complete — attendaient
    un nombre, pas un Decimal).
    """
    return float(calculate_course_progress(enrollment))
