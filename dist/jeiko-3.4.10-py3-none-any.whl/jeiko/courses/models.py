from django.db import models
from jeiko.encrypted import EncryptedJSONField
from jeiko.uploads import valider_extension_pdf, valider_l_image, valider_le_pdf
from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator
from django.utils import timezone

User = get_user_model()

# Extensions vidéo acceptées pour le stockage local (self-host).
ALLOWED_VIDEO_EXTENSIONS = ['mp4', 'm4v', 'webm', 'ogg', 'ogv', 'mov']


def validate_video_upload_size(value):
    """
    Garde-fou applicatif sur la taille d'une vidéo locale.

    La vraie limite se règle côté serveur web (Nginx `client_max_body_size`) ;
    ce validateur évite juste qu'un fichier manifestement trop gros passe.
    Réglable via settings.COURSES_MAX_VIDEO_UPLOAD_MB (défaut 2048 = 2 Go).
    """
    max_mb = getattr(settings, 'COURSES_MAX_VIDEO_UPLOAD_MB', 2048)
    if value and getattr(value, 'size', None) and value.size > max_mb * 1024 * 1024:
        raise ValidationError(f"Fichier trop volumineux (maximum {max_mb} Mo).")


# =============================================================================
# CORE MODELS: Course Structure
# =============================================================================

class Course(models.Model):
    """
    Formation en ligne (LMS).
    Peut être accessible librement ou nécessiter un accès (payant ou privé).
    """
    
    LEVEL_BEGINNER = 'beginner'
    LEVEL_INTERMEDIATE = 'intermediate'
    LEVEL_ADVANCED = 'advanced'
    
    LEVEL_CHOICES = [
        (LEVEL_BEGINNER, 'Débutant'),
        (LEVEL_INTERMEDIATE, 'Intermédiaire'),
        (LEVEL_ADVANCED, 'Avancé'),
    ]
    
    title = models.CharField(
        max_length=255,
        verbose_name="Titre"
    )
    slug = models.SlugField(
        max_length=255,
        unique=True,
        verbose_name="URL"
    )
    description = models.TextField(
        blank=True,
        verbose_name="Description"
    )
    thumbnail = models.ImageField(
        upload_to='courses/thumbnails/',
        null=True,
        blank=True,
        validators=[valider_l_image],
        verbose_name="Image de présentation"
    )
    
    is_active = models.BooleanField(
        default=True,
        verbose_name="Actif",
        help_text="Si décoché, la formation n'est visible par personne (sauf admin)."
    )
    is_restricted = models.BooleanField(
        default=True,
        verbose_name="Accès restreint",
        help_text="Si coché, nécessite un accès (payant ou accordé manuellement). Si décoché, accessible à tous."
    )
    
    level = models.CharField(
        max_length=20,
        choices=LEVEL_CHOICES,
        default=LEVEL_BEGINNER,
        verbose_name="Niveau"
    )
    estimated_duration = models.PositiveIntegerField(
        default=0,
        verbose_name="Durée estimée (minutes)",
        help_text="Durée totale estimée de la formation en minutes."
    )
    
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_courses',
        verbose_name="Créé par"
    )
    
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Créé le"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Modifié le"
    )
    
    class Meta:
        verbose_name = "Formation"
        verbose_name_plural = "Formations"
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title


class Part(models.Model):
    """
    Partie d'une formation (regroupement de chapitres).
    Ex: "Module 1", "Introduction", "Fondamentaux"
    """
    
    course = models.ForeignKey(
        Course,
        on_delete=models.CASCADE,
        related_name='parts',
        verbose_name="Formation"
    )
    title = models.CharField(
        max_length=255,
        verbose_name="Titre"
    )
    description = models.TextField(
        blank=True,
        verbose_name="Description courte"
    )
    content_details = models.TextField(
        blank=True,
        verbose_name="Contenu détaillé",
        help_text="Contenu riche pour une description plus complète (optionnel)."
    )
    position = models.PositiveIntegerField(
        default=0,
        verbose_name="Position",
        help_text="Ordre d'affichage dans la formation."
    )
    is_published = models.BooleanField(
        default=False,
        verbose_name="Publié",
        help_text="Si décoché, la partie est en brouillon et invisible pour les utilisateurs."
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Partie"
        verbose_name_plural = "Parties"
        ordering = ['course', 'position', 'id']
        unique_together = [('course', 'position')]
    
    def __str__(self):
        return f"{self.course.title} - {self.title}"


class Chapter(models.Model):
    """
    Chapitre d'une partie.
    Contient plusieurs sections (vidéos, textes, PDFs, quiz).
    """
    
    part = models.ForeignKey(
        Part,
        on_delete=models.CASCADE,
        related_name='chapters',
        verbose_name="Partie"
    )
    title = models.CharField(
        max_length=255,
        verbose_name="Titre"
    )
    description = models.TextField(
        blank=True,
        verbose_name="Description courte"
    )
    content_details = models.TextField(
        blank=True,
        verbose_name="Contenu détaillé",
        help_text="Contenu riche pour une description plus complète (optionnel)."
    )
    position = models.PositiveIntegerField(
        default=0,
        verbose_name="Position",
        help_text="Ordre d'affichage dans la partie."
    )
    is_published = models.BooleanField(
        default=False,
        verbose_name="Publié"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Chapitre"
        verbose_name_plural = "Chapitres"
        ordering = ['part', 'position', 'id']
        unique_together = [('part', 'position')]
    
    def __str__(self):
        return f"{self.part.title} - {self.title}"


class Section(models.Model):
    """
    Section de contenu dans un chapitre.
    Une section correspond à UNE unité de contenu : vidéo OU texte OU PDF OU quiz.
    """
    
    SECTION_TYPE_VIDEO = 'video'
    SECTION_TYPE_TEXT = 'text'
    SECTION_TYPE_PDF = 'pdf'
    SECTION_TYPE_QUIZ = 'quiz'
    SECTION_TYPE_EXTERNAL_LINK = 'external_link'
    
    SECTION_TYPE_CHOICES = [
        (SECTION_TYPE_VIDEO, 'Vidéo'),
        (SECTION_TYPE_TEXT, 'Texte'),
        (SECTION_TYPE_PDF, 'PDF'),
        (SECTION_TYPE_QUIZ, 'Quiz'),
        (SECTION_TYPE_EXTERNAL_LINK, 'Lien externe'),
    ]
    
    chapter = models.ForeignKey(
        Chapter,
        on_delete=models.CASCADE,
        related_name='sections',
        verbose_name="Chapitre"
    )
    title = models.CharField(
        max_length=255,
        verbose_name="Titre"
    )
    description = models.TextField(
        blank=True,
        verbose_name="Description courte"
    )
    content_details = models.TextField(
        blank=True,
        verbose_name="Contenu détaillé",
        help_text="Contenu riche pour une description plus complète (optionnel)."
    )
    position = models.PositiveIntegerField(
        default=0,
        verbose_name="Position"
    )
    section_type = models.CharField(
        max_length=20,
        choices=SECTION_TYPE_CHOICES,
        verbose_name="Type de section"
    )
    is_published = models.BooleanField(
        default=False,
        verbose_name="Publié"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Section"
        verbose_name_plural = "Sections"
        ordering = ['chapter', 'position', 'id']
        unique_together = [('chapter', 'position')]
    
    def __str__(self):
        return f"{self.chapter.title} - {self.title} ({self.get_section_type_display()})"


# =============================================================================
# STORAGE PROVIDERS
# =============================================================================

class VideoStorageProvider(models.Model):
    """
    Configuration d'un fournisseur de stockage vidéo.
    Permet de gérer plusieurs providers (Vimeo, Bunny, S3, FTP, etc.)
    et de les configurer via l'interface admin.
    """
    
    PROVIDER_VIMEO = 'vimeo'
    PROVIDER_BUNNY = 'bunny'
    PROVIDER_S3 = 's3'
    PROVIDER_FTP = 'ftp'
    PROVIDER_CUSTOM = 'custom'
    
    PROVIDER_TYPE_CHOICES = [
        (PROVIDER_VIMEO, 'Vimeo'),
        (PROVIDER_BUNNY, 'Bunny.net'),
        (PROVIDER_S3, 'Amazon S3 / Compatible'),
        (PROVIDER_FTP, 'FTP'),
        (PROVIDER_CUSTOM, 'Personnalisé'),
    ]
    
    name = models.CharField(
        max_length=100,
        unique=True,
        verbose_name="Nom",
        help_text="Nom identifiant ce provider (ex: 'Vimeo Production', 'Bunny CDN Europe')."
    )
    provider_type = models.CharField(
        max_length=20,
        choices=PROVIDER_TYPE_CHOICES,
        verbose_name="Type de provider"
    )
    is_active = models.BooleanField(
        default=True,
        verbose_name="Actif",
        help_text="Provider activé et utilisable."
    )
    
    # Chiffrée au repos : ce champ porte le jeton Vimeo, la clé secrète S3
    # ou le mot de passe FTP selon le fournisseur.
    config = EncryptedJSONField(
        default=dict,
        blank=True,
        verbose_name="Configuration",
        help_text=(
            "Configuration spécifique au provider (credentials, endpoints, etc.). "
            "Exemples:\n"
            "- Vimeo: {\"access_token\": \"...\", \"client_id\": \"...\", \"client_secret\": \"...\"}\n"
            "- Bunny: {\"library_id\": \"...\", \"api_key\": \"...\", \"cdn_hostname\": \"...\"}\n"
            "- S3: {\"bucket\": \"...\", \"region\": \"...\", \"access_key\": \"...\", \"secret_key\": \"...\"}\n"
            "- FTP: {\"host\": \"...\", \"port\": 21, \"username\": \"...\", \"password\": \"...\", \"base_path\": \"...\"}"
        )
    )
    
    url_signing_enabled = models.BooleanField(
        default=True,
        verbose_name="URLs signées activées",
        help_text="Générer des URLs signées avec expiration pour sécuriser l'accès."
    )
    url_expiry_seconds = models.PositiveIntegerField(
        default=3600,
        verbose_name="Durée de validité des URLs (secondes)",
        help_text="Durée de validité des URLs signées (par défaut: 3600 = 1 heure)."
    )
    
    notes = models.TextField(
        blank=True,
        verbose_name="Notes",
        help_text="Notes administratives sur ce provider."
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Fournisseur de stockage vidéo"
        verbose_name_plural = "Fournisseurs de stockage vidéo"
        ordering = ['name']
    
    def __str__(self):
        status = "✓" if self.is_active else "✗"
        return f"{status} {self.name} ({self.get_provider_type_display()})"


# =============================================================================
# CONTENT MODELS
# =============================================================================

class VideoContent(models.Model):
    """
    Contenu vidéo pour une section.
    Supporte stockage local, distant (via provider), FTP, ou lien direct.
    """
    
    STORAGE_LOCAL = 'local'
    STORAGE_REMOTE = 'remote'
    STORAGE_FTP = 'ftp'
    STORAGE_DIRECT_LINK = 'direct_link'
    
    STORAGE_TYPE_CHOICES = [
        (STORAGE_LOCAL, 'Stockage local'),
        (STORAGE_REMOTE, 'Stockage distant (provider)'),
        (STORAGE_FTP, 'FTP'),
        (STORAGE_DIRECT_LINK, 'Lien direct'),
    ]
    
    section = models.OneToOneField(
        Section,
        on_delete=models.CASCADE,
        related_name='video_content',
        verbose_name="Section"
    )
    
    title = models.CharField(
        max_length=255,
        blank=True,
        verbose_name="Titre",
        help_text="Si vide, utilise le titre de la section."
    )
    description = models.TextField(
        blank=True,
        verbose_name="Description"
    )
    duration_seconds = models.PositiveIntegerField(
        default=0,
        verbose_name="Durée (secondes)"
    )
    
    # Storage configuration
    storage_type = models.CharField(
        max_length=20,
        choices=STORAGE_TYPE_CHOICES,
        default=STORAGE_LOCAL,
        verbose_name="Type de stockage"
    )
    
    # Local storage
    video_file = models.FileField(
        upload_to='courses/videos/',
        null=True,
        blank=True,
        validators=[
            FileExtensionValidator(allowed_extensions=ALLOWED_VIDEO_EXTENSIONS),
            validate_video_upload_size,
        ],
        verbose_name="Fichier vidéo (local)",
        help_text="Formats acceptés : " + ", ".join(ALLOWED_VIDEO_EXTENSIONS) + "."
    )
    
    # Remote storage (via provider)
    remote_provider = models.ForeignKey(
        VideoStorageProvider,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='videos',
        verbose_name="Provider distant"
    )
    remote_video_id = models.CharField(
        max_length=255,
        blank=True,
        verbose_name="ID vidéo distant",
        help_text="ID de la vidéo sur le provider distant (ex: Vimeo video ID)."
    )
    remote_video_hash = models.CharField(
        max_length=255,
        blank=True,
        verbose_name="Hash / clé privée de la vidéo",
        help_text=(
            "Clé publique PROPRE À CETTE VIDÉO (ex: le hash 'h=' d'une vidéo "
            "Vimeo non listée). Ne JAMAIS mettre ici un token d'API donnant "
            "accès au compte : cette valeur est exposée dans la page du lecteur."
        )
    )
    
    # Direct URL / Embed
    direct_url = models.URLField(
        max_length=500,
        blank=True,
        verbose_name="URL directe",
        help_text="URL directe ou embed code pour vidéo hébergée ailleurs."
    )
    
    # FTP
    ftp_path = models.CharField(
        max_length=500,
        blank=True,
        verbose_name="Chemin FTP"
    )
    
    # Preview / Thumbnail
    is_preview = models.BooleanField(
        default=False,
        verbose_name="Vidéo d'aperçu",
        help_text="Si coché, accessible même sans accès à la formation (pour preview)."
    )
    thumbnail = models.ImageField(
        upload_to='courses/video_thumbnails/',
        null=True,
        blank=True,
        validators=[valider_l_image],
        verbose_name="Miniature"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Contenu vidéo"
        verbose_name_plural = "Contenus vidéo"
    
    def __str__(self):
        return self.title or self.section.title

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Auto-détection de la durée pour une vidéo LOCALE quand elle n'a pas
        # été saisie (best-effort via ffprobe ; sans ffprobe, on ne fait rien).
        # La durée serveur est ce qui rend la progression fiable.
        if (self.storage_type == self.STORAGE_LOCAL and self.video_file
                and not self.duration_seconds):
            try:
                from .utils import probe_video_duration
                duration = probe_video_duration(self.video_file.path)
            except (NotImplementedError, ValueError, OSError):
                duration = None
            if duration:
                # update() pour ne pas relancer save() (récursion).
                type(self).objects.filter(pk=self.pk).update(duration_seconds=duration)
                self.duration_seconds = duration

    def clean(self):
        """Validation de la configuration de stockage."""
        if self.storage_type == self.STORAGE_LOCAL and not self.video_file:
            raise ValidationError({
                'video_file': "Le fichier vidéo est requis pour le stockage local."
            })
        elif self.storage_type == self.STORAGE_REMOTE:
            if not self.remote_provider:
                raise ValidationError({
                    'remote_provider': "Le provider distant est requis pour le stockage distant."
                })
            if not self.remote_video_id:
                raise ValidationError({
                    'remote_video_id': "L'ID de la vidéo distante est requis."
                })
        elif self.storage_type == self.STORAGE_FTP and not self.ftp_path:
            raise ValidationError({
                'ftp_path': "Le chemin FTP est requis pour le stockage FTP."
            })
        elif self.storage_type == self.STORAGE_DIRECT_LINK and not self.direct_url:
            raise ValidationError({
                'direct_url': "L'URL directe est requise pour le lien direct."
            })


class TextContent(models.Model):
    """
    Contenu texte pour une section.
    """
    
    section = models.OneToOneField(
        Section,
        on_delete=models.CASCADE,
        related_name='text_content',
        verbose_name="Section"
    )
    content = models.TextField(
        verbose_name="Contenu",
        help_text="Contenu texte riche (HTML/Markdown supporté)."
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Contenu texte"
        verbose_name_plural = "Contenus texte"
    
    def __str__(self):
        return f"Texte - {self.section.title}"


class PDFContent(models.Model):
    """
    Contenu PDF pour une section.
    """
    
    STORAGE_LOCAL = 'local'
    STORAGE_REMOTE = 'remote'
    STORAGE_FTP = 'ftp'
    
    STORAGE_TYPE_CHOICES = [
        (STORAGE_LOCAL, 'Stockage local'),
        (STORAGE_REMOTE, 'URL distante'),
        (STORAGE_FTP, 'FTP'),
    ]
    
    section = models.OneToOneField(
        Section,
        on_delete=models.CASCADE,
        related_name='pdf_content',
        verbose_name="Section"
    )
    
    storage_type = models.CharField(
        max_length=20,
        choices=STORAGE_TYPE_CHOICES,
        default=STORAGE_LOCAL,
        verbose_name="Type de stockage"
    )
    
    # S-11 — le champ n'avait aucun validateur : ni extension, ni poids, ni
    # contenu. `views.client.serve_pdf` renvoie ensuite ce fichier depuis le
    # domaine du site, avec un `Content-Type: application/pdf` affirmé par
    # nous. Voir jeiko/uploads.py pour ce que la signature protège, et ce
    # qu'elle ne protège pas.
    file = models.FileField(
        upload_to='courses/pdfs/',
        null=True,
        blank=True,
        validators=[valider_extension_pdf, valider_le_pdf],
        verbose_name="Fichier PDF (local)",
        help_text="Fichier PDF, 25 Mo au maximum.",
    )
    remote_url = models.URLField(
        max_length=500,
        blank=True,
        verbose_name="URL distante"
    )
    ftp_path = models.CharField(
        max_length=500,
        blank=True,
        verbose_name="Chemin FTP"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Contenu PDF"
        verbose_name_plural = "Contenus PDF"
    
    def __str__(self):
        return f"PDF - {self.section.title}"
    
    def clean(self):
        if self.storage_type == self.STORAGE_LOCAL and not self.file:
            raise ValidationError({
                'file': "Le fichier PDF est requis pour le stockage local."
            })
        elif self.storage_type == self.STORAGE_REMOTE and not self.remote_url:
            raise ValidationError({
                'remote_url': "L'URL distante est requise pour le stockage distant."
            })
        elif self.storage_type == self.STORAGE_FTP and not self.ftp_path:
            raise ValidationError({
                'ftp_path': "Le chemin FTP est requis pour le stockage FTP."
            })


class QuizContent(models.Model):
    """
    Questionnaire QCM pour une section.
    """
    
    section = models.OneToOneField(
        Section,
        on_delete=models.CASCADE,
        related_name='quiz_content',
        verbose_name="Section"
    )
    title = models.CharField(
        max_length=255,
        blank=True,
        verbose_name="Titre",
        help_text="Si vide, utilise le titre de la section."
    )
    passing_score = models.PositiveIntegerField(
        default=70,
        verbose_name="Score de réussite (%)",
        help_text="Score minimum suggéré pour valider le quiz (en pourcentage)."
    )
    allow_skip = models.BooleanField(
        default=True,
        verbose_name="Autoriser à passer",
        help_text="Si coché, l'utilisateur peut passer le quiz sans le réussir."
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Quiz"
        verbose_name_plural = "Quiz"
    
    def __str__(self):
        return self.title or self.section.title


class QuizQuestion(models.Model):
    """
    Question d'un quiz.
    """
    
    QUESTION_TYPE_SINGLE = 'single'
    QUESTION_TYPE_MULTIPLE = 'multiple'
    QUESTION_TYPE_TRUE_FALSE = 'true_false'
    
    QUESTION_TYPE_CHOICES = [
        (QUESTION_TYPE_SINGLE, 'Choix unique'),
        (QUESTION_TYPE_MULTIPLE, 'Choix multiples'),
        (QUESTION_TYPE_TRUE_FALSE, 'Vrai/Faux'),
    ]
    
    quiz = models.ForeignKey(
        QuizContent,
        on_delete=models.CASCADE,
        related_name='questions',
        verbose_name="Quiz"
    )
    question_text = models.TextField(
        verbose_name="Question"
    )
    question_type = models.CharField(
        max_length=20,
        choices=QUESTION_TYPE_CHOICES,
        default=QUESTION_TYPE_SINGLE,
        verbose_name="Type de question"
    )
    position = models.PositiveIntegerField(
        default=0,
        verbose_name="Position"
    )
    points = models.PositiveIntegerField(
        default=1,
        verbose_name="Points",
        help_text="Points attribués pour cette question."
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Question de quiz"
        verbose_name_plural = "Questions de quiz"
        ordering = ['quiz', 'position', 'id']
    
    def __str__(self):
        return f"Q{self.position+1}: {self.question_text[:50]}"


class QuizAnswer(models.Model):
    """
    Réponse possible à une question de quiz.
    """
    
    question = models.ForeignKey(
        QuizQuestion,
        on_delete=models.CASCADE,
        related_name='answers',
        verbose_name="Question"
    )
    answer_text = models.CharField(
        max_length=500,
        verbose_name="Réponse"
    )
    is_correct = models.BooleanField(
        default=False,
        verbose_name="Réponse correcte",
        help_text=(
            "Pour les questions à choix unique/vrai-faux: une seule réponse correcte. "
            "Pour les questions à choix multiples: plusieurs réponses correctes possibles."
        )
    )
    position = models.PositiveIntegerField(
        default=0,
        verbose_name="Position"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Réponse"
        verbose_name_plural = "Réponses"
        ordering = ['question', 'position', 'id']
    
    def __str__(self):
        marker = "✓" if self.is_correct else "✗"
        return f"{marker} {self.answer_text[:50]}"


# =============================================================================
# USER PROGRESSION MODELS
# =============================================================================

class CourseEnrollment(models.Model):
    """
    Inscription d'un utilisateur à une formation.
    Trace l'accès (payant ou gratuit) et la progression globale.
    """
    
    STATUS_ACTIVE = 'active'
    STATUS_COMPLETED = 'completed'
    STATUS_SUSPENDED = 'suspended'
    
    STATUS_CHOICES = [
        (STATUS_ACTIVE, 'Active'),
        (STATUS_COMPLETED, 'Terminée'),
        (STATUS_SUSPENDED, 'Suspendue'),
    ]
    
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='course_enrollments',
        verbose_name="Utilisateur"
    )
    course = models.ForeignKey(
        Course,
        on_delete=models.CASCADE,
        related_name='enrollments',
        verbose_name="Formation"
    )
    
    enrolled_at = models.DateTimeField(
        default=timezone.now,
        verbose_name="Inscrit le"
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_ACTIVE,
        verbose_name="Statut"
    )
    progress_percentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=0.00,
        verbose_name="Progression (%)",
        help_text="Progression globale dans la formation (0-100%)."
    )
    completed_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Terminée le"
    )
    
    # Access management
    granted_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='granted_course_accesses',
        verbose_name="Accès accordé par",
        help_text="Administrateur ayant accordé l'accès manuellement (null si achat)."
    )
    has_payed = models.BooleanField(
        default=False,
        verbose_name="A payé",
        help_text="Indique si la formation a été achetée (vs accès manuel gratuit)."
    )
    order = models.ForeignKey(
        'shop.Order',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='course_enrollments',
        verbose_name="Commande",
        help_text="Commande d'achat associée (pour traçabilité)."
    )
    access_expires_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Accès expire le",
        help_text="Date d'expiration de l'accès (optionnel)."
    )
    notes = models.TextField(
        blank=True,
        verbose_name="Notes",
        help_text="Notes administratives."
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Inscription"
        verbose_name_plural = "Inscriptions"
        unique_together = [('user', 'course')]
        ordering = ['-enrolled_at']
    
    def __str__(self):
        return f"{self.user} - {self.course.title} ({self.progress_percentage}%)"
    
    def is_access_valid(self):
        """Vérifie si l'accès est toujours valide."""
        if self.status == self.STATUS_SUSPENDED:
            return False
        if self.access_expires_at and timezone.now() > self.access_expires_at:
            return False
        return True


class SectionProgress(models.Model):
    """
    Progression d'un utilisateur sur une section.
    """
    
    enrollment = models.ForeignKey(
        CourseEnrollment,
        on_delete=models.CASCADE,
        related_name='section_progresses',
        verbose_name="Inscription"
    )
    section = models.ForeignKey(
        Section,
        on_delete=models.CASCADE,
        related_name='user_progresses',
        verbose_name="Section"
    )
    
    is_completed = models.BooleanField(
        default=False,
        verbose_name="Complétée"
    )
    completed_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Complétée le"
    )
    is_skipped = models.BooleanField(
        default=False,
        verbose_name="Passée",
        help_text="Section passée volontairement (ex: quiz non réussi mais autorisé à passer)."
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Progression section"
        verbose_name_plural = "Progressions section"
        unique_together = [('enrollment', 'section')]
        ordering = ['enrollment', 'section__chapter__part__position', 'section__chapter__position', 'section__position']
    
    def __str__(self):
        status = "✓" if self.is_completed else ("⊘" if self.is_skipped else "○")
        return f"{status} {self.enrollment.user} - {self.section.title}"


class VideoProgress(models.Model):
    """
    Progression de visionnage d'une vidéo.
    Enregistre la position de lecture et le taux de visionnage.
    """
    
    enrollment = models.ForeignKey(
        CourseEnrollment,
        on_delete=models.CASCADE,
        related_name='video_progresses',
        verbose_name="Inscription"
    )
    section = models.ForeignKey(
        Section,
        on_delete=models.CASCADE,
        related_name='video_progresses',
        verbose_name="Section vidéo"
    )
    
    last_position_seconds = models.PositiveIntegerField(
        default=0,
        verbose_name="Position (secondes)",
        help_text="Dernière position de lecture en secondes."
    )
    watched_percentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=0.00,
        verbose_name="Pourcentage visionné (%)"
    )
    is_completed = models.BooleanField(
        default=False,
        verbose_name="Complétée",
        help_text="Vidéo visionnée en entier (>= 90%)."
    )
    completed_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Complétée le"
    )
    last_watched_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Dernier visionnage"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Progression vidéo"
        verbose_name_plural = "Progressions vidéo"
        unique_together = [('enrollment', 'section')]
        ordering = ['-last_watched_at']
    
    def __str__(self):
        return f"{self.enrollment.user} - {self.section.title} ({self.watched_percentage}%)"


class QuizAttempt(models.Model):
    """
    Tentative de quiz par un utilisateur.
    """
    
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='quiz_attempts',
        verbose_name="Utilisateur"
    )
    quiz = models.ForeignKey(
        QuizContent,
        on_delete=models.CASCADE,
        related_name='attempts',
        verbose_name="Quiz"
    )
    enrollment = models.ForeignKey(
        CourseEnrollment,
        on_delete=models.CASCADE,
        related_name='quiz_attempts',
        verbose_name="Inscription"
    )
    
    started_at = models.DateTimeField(
        default=timezone.now,
        verbose_name="Commencé le"
    )
    completed_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Terminé le"
    )
    
    score_percentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=0.00,
        verbose_name="Score (%)"
    )
    is_passed = models.BooleanField(
        default=False,
        verbose_name="Réussi",
        help_text="Quiz réussi (score >= passing_score)."
    )
    was_skipped = models.BooleanField(
        default=False,
        verbose_name="Passé sans finir",
        help_text="L'utilisateur a choisi de passer le quiz sans le terminer."
    )
    
    answers_data = models.JSONField(
        default=dict,
        blank=True,
        verbose_name="Réponses",
        help_text="Données des réponses soumises (format: {question_id: [answer_id, ...], ...})."
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Tentative de quiz"
        verbose_name_plural = "Tentatives de quiz"
        ordering = ['-started_at']
    
    def __str__(self):
        status = "✓" if self.is_passed else ("⊘" if self.was_skipped else "✗")
        return f"{status} {self.user} - {self.quiz.title or self.quiz.section.title} ({self.score_percentage}%)"

