"""
Utility functions for the courses app.
"""
from decimal import Decimal
from django.utils import timezone
from django.db.models import Count, Q
from .models import CourseEnrollment, SectionProgress, VideoProgress, Section


def grant_course_access(user, course, granted_by=None, has_payed=False, order=None, notes=''):
    """
    Accorde l'accès à une formation pour un utilisateur.
    
    Args:
        user: L'utilisateur
        course: La formation
        granted_by: L'admin qui accorde l'accès (None si achat automatique)
        has_payed: True si achat, False si accès gratuit/manuel
        order: La commande associée (si achat)
        notes: Notes administratives
    
    Returns:
        CourseEnrollment: L'inscription créée ou mise à jour
    """
    enrollment, created = CourseEnrollment.objects.get_or_create(
        user=user,
        course=course,
        defaults={
            'granted_by': granted_by,
            'has_payed': has_payed,
            'order': order,
            'notes': notes,
        }
    )

    if created:
        return enrollment

    # Inscription déjà existante : réactiver si suspendue ET tracer un éventuel
    # achat, même si l'accès n'était pas suspendu (un achat après un accès
    # gratuit doit être enregistré).
    changed = False
    if enrollment.status == CourseEnrollment.STATUS_SUSPENDED:
        enrollment.status = CourseEnrollment.STATUS_ACTIVE
        changed = True
    if granted_by and not enrollment.granted_by_id:
        enrollment.granted_by = granted_by
        changed = True
    if has_payed and not enrollment.has_payed:
        enrollment.has_payed = True
        changed = True
    if order and not enrollment.order_id:
        enrollment.order = order
        changed = True
    if notes:
        enrollment.notes = f"{enrollment.notes}\n{notes}".strip()
        changed = True
    if changed:
        enrollment.save()

    return enrollment


def check_section_access(user, section):
    """
    Vérifie si un utilisateur a accès à une section.
    
    Args:
        user: L'utilisateur
        section: La section
    
    Returns:
        tuple: (has_access: bool, reason: str)
    """
    chapter = section.chapter
    part = chapter.part
    course = part.course

    # Le staff a un accès complet : prévisualisation, contenu non publié,
    # formation restreinte sans inscription, etc. (On traite ce cas en premier
    # pour ne pas retomber dans le "Pas d'inscription" plus bas.)
    if user.is_staff:
        return True, "Accès staff"

    # Si la formation n'est pas active, personne (hors staff) n'y accède
    if not course.is_active:
        return False, "Formation désactivée"

    # Contenu en brouillon : la section ET toute sa hiérarchie doivent être
    # publiées. Une section publiée sous un chapitre/partie en brouillon ne
    # doit pas être accessible par URL directe.
    if not part.is_published:
        return False, "Partie non publiée"
    if not chapter.is_published:
        return False, "Chapitre non publié"
    if not section.is_published:
        return False, "Section non publiée"

    # Si la formation n'est pas restreinte, tout le monde y a accès
    if not course.is_restricted:
        return True, "Accès libre"
    
    # Pour les vidéos en preview, accès libre
    if section.section_type == Section.SECTION_TYPE_VIDEO:
        if hasattr(section, 'video_content') and section.video_content.is_preview:
            return True, "Vidéo de prévisualisation"
    
    # Vérifier l'inscription
    try:
        enrollment = CourseEnrollment.objects.get(user=user, course=course)
        if enrollment.is_access_valid():
            return True, "Accès via inscription"
        else:
            return False, "Accès expiré ou suspendu"
    except CourseEnrollment.DoesNotExist:
        return False, "Pas d'inscription"


def calculate_course_progress(enrollment):
    """
    Calcule la progression globale d'un utilisateur dans une formation.
    
    Args:
        enrollment: CourseEnrollment
    
    Returns:
        Decimal: Pourcentage de progression (0-100)
    """
    course = enrollment.course

    # Compter toutes les sections publiées de la formation (hiérarchie publiée).
    total_sections = Section.objects.filter(
        chapter__part__course=course,
        chapter__part__is_published=True,
        chapter__is_published=True,
        is_published=True
    ).count()

    if total_sections == 0:
        progress = Decimal('0.00')
    else:
        # Compter les sections complétées OU passées, en se limitant aux
        # sections encore publiées : une section validée puis dépubliée ne doit
        # pas gonfler la progression au-delà de 100 %.
        completed_sections = SectionProgress.objects.filter(
            enrollment=enrollment,
            section__chapter__part__course=course,
            section__is_published=True,
            section__chapter__is_published=True,
            section__chapter__part__is_published=True,
        ).filter(
            Q(is_completed=True) | Q(is_skipped=True)
        ).count()

        progress = (Decimal(completed_sections) / Decimal(total_sections)) * Decimal('100.00')
        if progress > Decimal('100.00'):
            progress = Decimal('100.00')

    # Mettre à jour l'enrollment
    enrollment.progress_percentage = progress
    if progress >= 100 and enrollment.status == CourseEnrollment.STATUS_ACTIVE:
        enrollment.status = CourseEnrollment.STATUS_COMPLETED
        if not enrollment.completed_at:
            enrollment.completed_at = timezone.now()
    enrollment.save(update_fields=['progress_percentage', 'status', 'completed_at', 'updated_at'])

    return progress


def update_video_progress(user, section, position_seconds, duration_seconds=None):
    """
    Met à jour la progression de visionnage d'une vidéo.

    Args:
        user: L'utilisateur
        section: La section vidéo
        position_seconds: Position actuelle en secondes (fournie par le client)
        duration_seconds: Durée transmise par le client — utilisée UNIQUEMENT en
            repli si la vidéo n'a pas de durée renseignée en base.

    Returns:
        VideoProgress: La progression mise à jour
    """
    # Récupérer l'enrollment
    course = section.chapter.part.course
    try:
        enrollment = CourseEnrollment.objects.get(user=user, course=course)
    except CourseEnrollment.DoesNotExist:
        return None

    # Durée FAISANT AUTORITÉ : celle configurée sur la vidéo côté serveur.
    # On ne se fie pas à la durée envoyée par le client, sinon un simple
    # position=10&duration=10 donnerait 100 % « visionné ». On ne retombe sur
    # la valeur client que si l'admin n'a pas renseigné la durée en base.
    video_content = getattr(section, 'video_content', None)
    if video_content and video_content.duration_seconds:
        authoritative_duration = video_content.duration_seconds
    else:
        authoritative_duration = duration_seconds or 0

    # Borner la position dans [0, durée] : on ne peut pas « sauter » au-delà de
    # la fin réelle de la vidéo.
    if position_seconds < 0:
        position_seconds = 0
    if authoritative_duration and position_seconds > authoritative_duration:
        position_seconds = authoritative_duration

    # Calculer le pourcentage
    if authoritative_duration > 0:
        watched_percentage = (Decimal(position_seconds) / Decimal(authoritative_duration)) * Decimal('100.00')
        watched_percentage = min(watched_percentage, Decimal('100.00'))
    else:
        watched_percentage = Decimal('0.00')
    
    # Créer ou mettre à jour la progression vidéo
    video_progress, created = VideoProgress.objects.update_or_create(
        enrollment=enrollment,
        section=section,
        defaults={
            'last_position_seconds': position_seconds,
            'watched_percentage': watched_percentage,
            'is_completed': watched_percentage >= Decimal('90.00'),  # Considéré complété à 90%
            'completed_at': timezone.now() if watched_percentage >= Decimal('90.00') else None,
        }
    )
    
    # Mettre à jour la progression de la section si vidéo complétée
    if video_progress.is_completed:
        section_progress, created = SectionProgress.objects.update_or_create(
            enrollment=enrollment,
            section=section,
            defaults={
                'is_completed': True,
                'completed_at': timezone.now(),
            }
        )
        
        # Recalculer la progression globale
        calculate_course_progress(enrollment)
    
    return video_progress


def probe_video_duration(file_path):
    """
    Durée d'une vidéo locale en secondes (int), via ffprobe.

    Best-effort : retourne None si ffprobe n'est pas installé ou en cas
    d'erreur — ne lève jamais, pour ne pas casser l'enregistrement d'une vidéo.
    """
    import shutil
    import subprocess
    import json as _json

    if not file_path or not shutil.which('ffprobe'):
        return None
    try:
        result = subprocess.run(
            [
                'ffprobe', '-v', 'quiet', '-print_format', 'json',
                '-show_format', str(file_path),
            ],
            capture_output=True, text=True, timeout=30,
        )
        data = _json.loads(result.stdout or '{}')
        duration = data.get('format', {}).get('duration')
        return int(float(duration)) if duration else None
    except Exception:
        return None


def get_video_url(video_content, user):
    """
    Génére l'URL d'accès à une vidéo selon son type de stockage.
    
    Args:
        video_content: VideoContent
        user: L'utilisateur demandant l'accès
    
    Returns:
        str: URL d'accès à la vidéo
    """
    from .storage import get_signed_url
    
    if video_content.storage_type == video_content.STORAGE_LOCAL:
        # Pour le stockage local, on passe par une view protégée
        from django.urls import reverse
        return reverse('jeiko_courses:jeiko_courses_client:serve_video', kwargs={'video_id': video_content.pk})
    
    elif video_content.storage_type == video_content.STORAGE_REMOTE:
        # Provider distant avec URL signée si activé
        if video_content.remote_provider and video_content.remote_provider.url_signing_enabled:
            return get_signed_url(video_content)
        else:
            # URL directe du provider
            return get_provider_video_url(video_content)
    
    elif video_content.storage_type == video_content.STORAGE_DIRECT_LINK:
        return video_content.direct_url
    
    elif video_content.storage_type == video_content.STORAGE_FTP:
        # FTP : on proxy via Django
        from django.urls import reverse
        return reverse('jeiko_courses:jeiko_courses_client:serve_video', kwargs={'video_id': video_content.pk})
    
    return ''


def get_provider_video_url(video_content):
    """
    Génère l'URL de la vidéo sur le provider distant.
    
    Args:
        video_content: VideoContent
    
    Returns:
        str: URL de la vidéo
    """
    provider = video_content.remote_provider
    if not provider:
        return ''
    
    provider_type = provider.provider_type
    config = provider.config
    video_id = video_content.remote_video_id
    
    if provider_type == provider.PROVIDER_VIMEO:
        # Hash public par vidéo (non listée). Ne jamais utiliser l'access_token
        # du compte ici : il serait exposé au navigateur.
        video_hash = (video_content.remote_video_hash or '').strip()
        if video_hash:
            return f"https://player.vimeo.com/video/{video_id}?h={video_hash}"
        return f"https://player.vimeo.com/video/{video_id}"
    
    elif provider_type == provider.PROVIDER_BUNNY:
        cdn_hostname = config.get('cdn_hostname', '')
        return f"https://{cdn_hostname}/{video_id}/playlist.m3u8"
    
    elif provider_type == provider.PROVIDER_S3:
        bucket = config.get('bucket', '')
        region = config.get('region', 'us-east-1')
        return f"https://{bucket}.s3.{region}.amazonaws.com/{video_id}"
    
    return ''


def test_provider_connection(provider):
    """
    Teste la connexion à un provider de stockage.
    
    Args:
        provider: VideoStorageProvider
    
    Returns:
        dict: {'success': bool, 'message': str}
    """
    # Cette fonction sera complétée avec les implémentations spécifiques
    # de chaque provider (API calls, etc.)
    
    if not provider.is_active:
        return {'success': False, 'message': 'Provider désactivé'}
    
    provider_type = provider.provider_type
    config = provider.config
    
    # Validation basique de la configuration
    if provider_type == provider.PROVIDER_VIMEO:
        if not config.get('access_token'):
            return {'success': False, 'message': 'access_token manquant dans la configuration'}
        return {'success': True, 'message': 'Configuration Vimeo valide'}
    
    elif provider_type == provider.PROVIDER_BUNNY:
        if not config.get('api_key') or not config.get('library_id'):
            return {'success': False, 'message': 'api_key ou library_id manquant'}
        return {'success': True, 'message': 'Configuration Bunny valide'}
    
    elif provider_type == provider.PROVIDER_S3:
        required_keys = ['bucket', 'access_key', 'secret_key']
        missing = [k for k in required_keys if not config.get(k)]
        if missing:
            return {'success': False, 'message': f'Clés manquantes: {", ".join(missing)}'}
        return {'success': True, 'message': 'Configuration S3 valide'}
    
    elif provider_type == provider.PROVIDER_FTP:
        required_keys = ['host', 'username', 'password']
        missing = [k for k in required_keys if not config.get(k)]
        if missing:
            return {'success': False, 'message': f'Clés manquantes: {", ".join(missing)}'}
        return {'success': True, 'message': 'Configuration FTP valide'}
    
    return {'success': True, 'message': 'Provider configuré'}


def migrate_video_storage(video_content, new_provider=None, new_storage_type=None):
    """
    Migre une vidéo d'un provider à un autre.
    
    Args:
        video_content: VideoContent
        new_provider: Nouveau VideoStorageProvider (si storage_type='remote')
        new_storage_type: Nouveau type de stockage
    
    Returns:
        dict: {'success': bool, 'message': str}
    """
    # NON IMPLÉMENTÉE — et elle lève, désormais, au lieu de renvoyer un
    # dictionnaire d'échec.
    #
    # Une valeur de retour `{'success': False}` se confond avec un échec
    # ordinaire : un appelant pouvait croire que la migration avait été tentée
    # puis avait échoué, alors qu'aucune ligne de code ne déplace quoi que ce
    # soit. Cette fonction n'est aujourd'hui appelée nulle part ; lever garantit
    # qu'un futur appelant s'en aperçoive immédiatement plutôt qu'en production.
    #
    # Ce qu'il resterait à écrire : télécharger depuis le stockage d'origine,
    # téléverser vers le nouveau fournisseur, vérifier l'intégrité, mettre à
    # jour le VideoContent, puis seulement supprimer la source.
    raise NotImplementedError(
        "La migration de stockage vidéo n'est pas implémentée. "
        "Déplacer une vidéo d'un fournisseur à un autre se fait aujourd'hui à "
        "la main, puis en corrigeant la fiche vidéo en administration."
    )
