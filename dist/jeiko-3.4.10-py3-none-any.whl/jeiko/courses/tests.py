"""
Tests du module courses (LMS formations vidéo).

Couvre les correctifs de sécurité/cohérence apportés au module :
- contrôle d'accès (check_section_access) : staff, brouillons, suspendu, expiré,
  preview, cours libre ;
- scoring des quiz (choix unique / multiple / réponse mal configurée) et le
  parsing POST getlist ;
- réordonnancement sans IntegrityError (unique_together) ;
- calcul de progression unifié (cap à 100, sections publiées) ;
- durée vidéo faisant autorité côté serveur ;
- grant_course_access (achat tracé sur inscription existante) ;
- certificat, et vues POST-only (CSRF).
"""
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.core.exceptions import ValidationError as DjangoValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from datetime import timedelta

from .models import (
    Course, Part, Chapter, Section,
    VideoContent, TextContent, PDFContent,
    QuizContent, QuizQuestion, QuizAnswer,
    CourseEnrollment, SectionProgress,
)
from .utils import (
    check_section_access, calculate_course_progress,
    update_video_progress, grant_course_access,
)
from .utils_progress import update_course_progress
from .views.admin_ordering import _move_item

User = get_user_model()


class CoursesFixture(TestCase):
    """Décor commun : une formation restreinte avec 1 partie / 1 chapitre / 2 sections."""

    def setUp(self):
        self.user = User.objects.create_user("eleve", "eleve@example.test", "pw")
        self.other = User.objects.create_user("autre", "autre@example.test", "pw")
        self.staff = User.objects.create_user("staff", "staff@example.test", "pw", is_staff=True)
        # Les vues d'administration des formations sont passées de
        # `@staff_member_required` aux permissions de rôle. Le seul drapeau
        # `is_staff` ne suffit donc plus, et les tests qui vérifiaient autre
        # chose — le refus des mutations en GET, par exemple — recevaient un 403
        # avant même d'atteindre ce qu'ils mesuraient. On donne ici à ce compte
        # les droits que son nom laisse entendre : un gestionnaire de formations.
        self.staff.user_permissions.set(
            Permission.objects.filter(content_type__app_label="courses")
        )

        self.course = Course.objects.create(
            title="Django", slug="django", is_active=True, is_restricted=True,
        )
        self.part = Part.objects.create(course=self.course, title="P1", position=1, is_published=True)
        self.chapter = Chapter.objects.create(part=self.part, title="C1", position=1, is_published=True)
        self.s_text = Section.objects.create(
            chapter=self.chapter, title="Intro", position=1,
            section_type=Section.SECTION_TYPE_TEXT, is_published=True,
        )
        self.s_video = Section.objects.create(
            chapter=self.chapter, title="Vidéo", position=2,
            section_type=Section.SECTION_TYPE_VIDEO, is_published=True,
        )
        TextContent.objects.create(section=self.s_text, content="<p>Bonjour</p>")
        self.video = VideoContent.objects.create(
            section=self.s_video, duration_seconds=100,
            storage_type=VideoContent.STORAGE_DIRECT_LINK, direct_url="https://x/y",
        )

    def enroll(self, user, **kwargs):
        return CourseEnrollment.objects.create(user=user, course=self.course, **kwargs)


class AccessControlTests(CoursesFixture):
    def test_non_inscrit_refuse(self):
        ok, _ = check_section_access(self.user, self.s_text)
        self.assertFalse(ok)

    def test_inscrit_actif_autorise(self):
        self.enroll(self.user)
        ok, _ = check_section_access(self.user, self.s_text)
        self.assertTrue(ok)

    def test_suspendu_refuse(self):
        self.enroll(self.user, status=CourseEnrollment.STATUS_SUSPENDED)
        ok, _ = check_section_access(self.user, self.s_text)
        self.assertFalse(ok)

    def test_acces_expire_refuse(self):
        self.enroll(self.user, access_expires_at=timezone.now() - timedelta(days=1))
        ok, _ = check_section_access(self.user, self.s_text)
        self.assertFalse(ok)

    def test_staff_autorise_sans_inscription(self):
        ok, _ = check_section_access(self.staff, self.s_text)
        self.assertTrue(ok)

    def test_staff_voit_contenu_en_brouillon(self):
        self.s_text.is_published = False
        self.s_text.save()
        ok, _ = check_section_access(self.staff, self.s_text)
        self.assertTrue(ok)

    def test_chapitre_brouillon_masque_section_publiee(self):
        # Régression : une section publiée sous un chapitre en brouillon ne doit
        # pas être accessible par URL directe.
        self.enroll(self.user)
        self.chapter.is_published = False
        self.chapter.save()
        ok, reason = check_section_access(self.user, self.s_text)
        self.assertFalse(ok)
        self.assertEqual(reason, "Chapitre non publié")

    def test_partie_brouillon_masque_section(self):
        self.enroll(self.user)
        self.part.is_published = False
        self.part.save()
        ok, reason = check_section_access(self.user, self.s_text)
        self.assertFalse(ok)

    def test_cours_libre_autorise_sans_inscription(self):
        self.course.is_restricted = False
        self.course.save()
        ok, _ = check_section_access(self.user, self.s_text)
        self.assertTrue(ok)

    def test_video_preview_autorisee_sans_inscription(self):
        self.video.is_preview = True
        self.video.save()
        ok, _ = check_section_access(self.user, self.s_video)
        self.assertTrue(ok)


class QuizScoringTests(CoursesFixture):
    def setUp(self):
        super().setUp()
        self.enroll(self.user)
        self.s_quiz = Section.objects.create(
            chapter=self.chapter, title="Quiz", position=3,
            section_type=Section.SECTION_TYPE_QUIZ, is_published=True,
        )
        self.quiz = QuizContent.objects.create(
            section=self.s_quiz, passing_score=70, allow_skip=False,
        )
        # Q1 choix unique (1 bonne réponse)
        self.q1 = QuizQuestion.objects.create(
            quiz=self.quiz, question_text="Q1", question_type=QuizQuestion.QUESTION_TYPE_SINGLE,
            position=1, points=1,
        )
        self.q1_a1 = QuizAnswer.objects.create(question=self.q1, answer_text="bon", is_correct=True, position=1)
        self.q1_a2 = QuizAnswer.objects.create(question=self.q1, answer_text="faux", is_correct=False, position=2)
        # Q2 choix multiple (2 bonnes réponses)
        self.q2 = QuizQuestion.objects.create(
            quiz=self.quiz, question_text="Q2", question_type=QuizQuestion.QUESTION_TYPE_MULTIPLE,
            position=2, points=1,
        )
        self.q2_a1 = QuizAnswer.objects.create(question=self.q2, answer_text="a", is_correct=True, position=1)
        self.q2_a2 = QuizAnswer.objects.create(question=self.q2, answer_text="b", is_correct=True, position=2)
        self.q2_a3 = QuizAnswer.objects.create(question=self.q2, answer_text="c", is_correct=False, position=3)
        self.client.force_login(self.user)
        self.url = reverse(
            "jeiko_courses:jeiko_courses_client:quiz_submit",
            args=[self.course.slug, self.quiz.id],
        )

    def test_multiple_choix_toutes_bonnes_reponses(self):
        # Régression du bug getlist : les 2 valeurs de q2 doivent être lues.
        resp = self.client.post(self.url, {
            f"question_{self.q1.id}": str(self.q1_a1.id),
            f"question_{self.q2.id}": [str(self.q2_a1.id), str(self.q2_a2.id)],
        })
        data = resp.json()
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(data["score"], 100.0)
        self.assertTrue(data["passed"])

    def test_multiple_reponse_partielle_echoue(self):
        resp = self.client.post(self.url, {
            f"question_{self.q1.id}": str(self.q1_a1.id),
            f"question_{self.q2.id}": [str(self.q2_a1.id)],  # une seule des deux
        })
        data = resp.json()
        self.assertEqual(data["score"], 50.0)  # seul Q1 correct
        self.assertFalse(data["passed"])

    def test_valeur_non_numerique_ignoree_pas_de_500(self):
        resp = self.client.post(self.url, {
            f"question_{self.q1.id}": "abc",
        })
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()["score"], 0.0)


class ReorderingTests(CoursesFixture):
    def test_move_section_swap_sans_integrity_error(self):
        # s_text(pos1) <-> s_video(pos2)
        moved = _move_item(self.s_video, "up", {"chapter": self.chapter})
        self.assertTrue(moved)
        self.s_text.refresh_from_db()
        self.s_video.refresh_from_db()
        self.assertEqual(self.s_video.position, 1)
        self.assertEqual(self.s_text.position, 2)

    def test_move_en_bordure_ne_fait_rien(self):
        moved = _move_item(self.s_text, "up", {"chapter": self.chapter})
        self.assertFalse(moved)

    def test_move_view_refuse_get(self):
        self.client.force_login(self.staff)
        url = reverse("jeiko_courses:jeiko_courses_admin:move_section", args=[self.s_video.id, "up"])
        self.assertEqual(self.client.get(url).status_code, 405)


class ProgressTests(CoursesFixture):
    def test_progression_moitie(self):
        enr = self.enroll(self.user)
        SectionProgress.objects.create(enrollment=enr, section=self.s_text, is_completed=True)
        enr.refresh_from_db()
        self.assertEqual(enr.progress_percentage, Decimal("50.00"))

    def test_progression_complete_passe_en_termine(self):
        enr = self.enroll(self.user)
        SectionProgress.objects.create(enrollment=enr, section=self.s_text, is_completed=True)
        SectionProgress.objects.create(enrollment=enr, section=self.s_video, is_completed=True)
        enr.refresh_from_db()
        self.assertEqual(enr.progress_percentage, Decimal("100.00"))
        self.assertEqual(enr.status, CourseEnrollment.STATUS_COMPLETED)
        self.assertIsNotNone(enr.completed_at)

    def test_section_passee_compte(self):
        enr = self.enroll(self.user)
        SectionProgress.objects.create(enrollment=enr, section=self.s_text, is_skipped=True)
        p = calculate_course_progress(enr)
        self.assertEqual(p, Decimal("50.00"))

    def test_pas_de_depassement_100_apres_depublication(self):
        enr = self.enroll(self.user)
        SectionProgress.objects.create(enrollment=enr, section=self.s_text, is_completed=True)
        SectionProgress.objects.create(enrollment=enr, section=self.s_video, is_completed=True)
        # On dépublie une section déjà validée
        self.s_video.is_published = False
        self.s_video.save()
        p = calculate_course_progress(enr)
        self.assertLessEqual(p, Decimal("100.00"))

    def test_les_deux_fonctions_donnent_le_meme_resultat(self):
        enr = self.enroll(self.user)
        SectionProgress.objects.create(enrollment=enr, section=self.s_text, is_completed=True)
        a = Decimal(str(update_course_progress(enr)))
        b = calculate_course_progress(enr)
        self.assertEqual(a, b)


class VideoProgressTests(CoursesFixture):
    def test_duree_serveur_fait_autorite(self):
        # video.duration_seconds = 100 ; le client prétend duration=10.
        self.enroll(self.user)
        vp = update_video_progress(self.user, self.s_video, position_seconds=10, duration_seconds=10)
        self.assertEqual(vp.watched_percentage, Decimal("10.00"))
        self.assertFalse(vp.is_completed)

    def test_position_bornee_a_la_duree(self):
        self.enroll(self.user)
        vp = update_video_progress(self.user, self.s_video, position_seconds=9999, duration_seconds=0)
        self.assertEqual(vp.last_position_seconds, 100)
        self.assertEqual(vp.watched_percentage, Decimal("100.00"))
        self.assertTrue(vp.is_completed)

    def test_completion_video_marque_la_section(self):
        enr = self.enroll(self.user)
        update_video_progress(self.user, self.s_video, position_seconds=95)
        self.assertTrue(
            SectionProgress.objects.filter(
                enrollment=enr, section=self.s_video, is_completed=True
            ).exists()
        )


class VideoUploadValidationTests(CoursesFixture):
    def _new_video_section(self):
        return Section.objects.create(
            chapter=self.chapter, title="V2", position=5,
            section_type=Section.SECTION_TYPE_VIDEO, is_published=True,
        )

    def test_extension_non_video_refusee(self):
        vc = VideoContent(
            section=self._new_video_section(),
            storage_type=VideoContent.STORAGE_LOCAL,
            video_file=SimpleUploadedFile("piege.txt", b"pas une video"),
        )
        with self.assertRaises(DjangoValidationError):
            vc.full_clean()

    def test_extension_video_acceptee(self):
        vc = VideoContent(
            section=self._new_video_section(),
            storage_type=VideoContent.STORAGE_LOCAL,
            video_file=SimpleUploadedFile("cours.mp4", b"\x00\x00\x00\x18ftypmp42"),
        )
        # Ne doit pas lever sur l'extension/la taille.
        vc.full_clean()


class GrantAccessTests(CoursesFixture):
    def test_achat_trace_sur_inscription_active_existante(self):
        enr = self.enroll(self.user, has_payed=False)
        grant_course_access(self.user, self.course, has_payed=True)
        enr.refresh_from_db()
        self.assertTrue(enr.has_payed)

    def test_reactive_inscription_suspendue(self):
        self.enroll(self.user, status=CourseEnrollment.STATUS_SUSPENDED)
        enr = grant_course_access(self.user, self.course, granted_by=self.staff)
        self.assertEqual(enr.status, CourseEnrollment.STATUS_ACTIVE)


class CertificateTests(CoursesFixture):
    def test_certificat_refuse_si_non_termine(self):
        self.enroll(self.user, status=CourseEnrollment.STATUS_ACTIVE)
        self.client.force_login(self.user)
        url = reverse("jeiko_courses:jeiko_courses_client:course_certificate", args=[self.course.slug])
        self.assertEqual(self.client.get(url).status_code, 403)

    def test_certificat_ok_si_termine(self):
        self.enroll(self.user, status=CourseEnrollment.STATUS_COMPLETED, completed_at=timezone.now())
        self.client.force_login(self.user)
        url = reverse("jeiko_courses:jeiko_courses_client:course_certificate", args=[self.course.slug])
        self.assertEqual(self.client.get(url).status_code, 200)


class CourseDetailTests(CoursesFixture):
    def test_page_detail_rend_et_affiche_acces_restreint(self):
        # Sans produit lié : la page rend et propose de contacter l'admin
        # (exerce le nouveau contexte linked_product=None sans planter).
        resp = self.client.get(
            reverse("jeiko_courses:jeiko_courses_client:course_detail", args=[self.course.slug])
        )
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Accès restreint")


class ProtectedFileTests(CoursesFixture):
    def test_serve_pdf_refuse_sans_acces(self):
        pdf_section = Section.objects.create(
            chapter=self.chapter, title="Doc", position=4,
            section_type=Section.SECTION_TYPE_PDF, is_published=True,
        )
        pdf = PDFContent.objects.create(
            section=pdf_section, storage_type=PDFContent.STORAGE_REMOTE,
            remote_url="https://x/doc.pdf",
        )
        self.client.force_login(self.user)  # non inscrit
        url = reverse("jeiko_courses:jeiko_courses_client:serve_pdf", args=[pdf.id])
        self.assertEqual(self.client.get(url).status_code, 404)


class CsrfPostOnlyTests(CoursesFixture):
    def test_enrollment_cancel_revoke_refuse_get(self):
        enr = self.enroll(self.user, status=CourseEnrollment.STATUS_SUSPENDED)
        self.client.force_login(self.staff)
        url = reverse("jeiko_courses:jeiko_courses_admin:enrollment_cancel_revoke", args=[enr.id])
        self.assertEqual(self.client.get(url).status_code, 405)
        enr.refresh_from_db()
        self.assertEqual(enr.status, CourseEnrollment.STATUS_SUSPENDED)  # inchangé
