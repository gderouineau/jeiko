from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('courses', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='videocontent',
            name='remote_video_hash',
            field=models.CharField(
                blank=True,
                help_text=(
                    "Clé publique PROPRE À CETTE VIDÉO (ex: le hash 'h=' d'une "
                    "vidéo Vimeo non listée). Ne JAMAIS mettre ici un token "
                    "d'API donnant accès au compte : cette valeur est exposée "
                    "dans la page du lecteur."
                ),
                max_length=255,
                verbose_name='Hash / clé privée de la vidéo',
            ),
        ),
    ]
