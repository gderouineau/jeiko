"""
Rattrapage de `0004` : la bascule en `EncryptedJSONField` n'avait pas repris
les données.

`0004` s'est contentée d'un `AlterField`. Comme la colonne ne change pas
(`jsonb` de part et d'autre), la migration passait sans rien signaler — mais
les lignes déjà présentes restaient en clair. Pire, une ligne en clair n'est
pas déchiffrable : la lecture rendait une `str` là où `courses/utils.py` et
`courses/storage.py` font `config.get('access_token')`, donc un
`AttributeError` au premier accès au fournisseur vidéo.

`jeiko.encrypted.EncryptedJSONField.to_python` rétablit désormais le `dict` et
journalise ; cette migration supprime la cause.
"""

import json

from django.db import migrations


def chiffrer(apps, schema_editor):
    Provider = apps.get_model('courses', 'VideoStorageProvider')
    for provider in Provider.objects.all():
        valeur = provider.config
        if isinstance(valeur, str):
            try:
                valeur = json.loads(valeur)
            except ValueError:
                continue
        if not isinstance(valeur, dict) or not valeur:
            continue
        provider.config = valeur
        provider.save(update_fields=['config'])


def dechiffrer(apps, schema_editor):
    Provider = apps.get_model('courses', 'VideoStorageProvider')
    table = Provider._meta.db_table
    with schema_editor.connection.cursor() as curseur:
        for provider in Provider.objects.all():
            valeur = provider.config
            if not isinstance(valeur, dict):
                continue
            curseur.execute(
                f'UPDATE {table} SET config = %s WHERE id = %s',
                [json.dumps(valeur), provider.pk],
            )


class Migration(migrations.Migration):

    dependencies = [
        ('courses', '0004_alter_videostorageprovider_config'),
    ]

    operations = [
        migrations.RunPython(chiffrer, dechiffrer),
    ]
