# jeiko/courses/emailing.py
"""
E-mails du module « Formations » (LMS).

Ce fichier ne compose aucun message : il traduit une inscription
(`CourseEnrollment`) ou une tentative de quiz (`QuizAttempt`) en variables de
catalogue, puis délègue à `jeiko.emailing.services.send_email`, où sujets et
mises en page restent éditables en back-office. Aucune fonction ne lève : un
e-mail qui ne part pas ne doit jamais faire échouer une inscription, une
progression ou la soumission d'un quiz.

Les envois sont déclenchés par les signaux du module (voir `signals.py`).

Codes utilisés — course_enrolled, course_access_granted_admin, course_completed,
course_suspended, quiz_passed, quiz_failed.
"""

import logging

from django.urls import NoReverseMatch, reverse
from django.utils import timezone

from jeiko.emailing.render import site_base_url
from jeiko.emailing.services import send_email

logger = logging.getLogger(__name__)


# =========================
#  Helpers
# =========================

def _absolute(url_name, **kwargs):
    """URL absolue vers une vue nommée (les signaux n'ont pas de requête)."""
    try:
        path = reverse(url_name, kwargs=kwargs)
    except NoReverseMatch:
        path = "/"
    return f"{site_base_url().rstrip('/')}{path}"


def _course_url(course):
    return _absolute("jeiko_courses:course_detail", course_slug=course.slug)


def _certificate_url(course):
    return _absolute("jeiko_courses:course_certificate", course_slug=course.slug)


def _published_chapters(course):
    """Nombre de chapitres publiés (dans une partie publiée)."""
    from jeiko.courses.models import Chapter
    return Chapter.objects.filter(
        part__course=course,
        part__is_published=True,
        is_published=True,
    ).count()


def _score_label(value):
    try:
        return f"{round(float(value))} %"
    except (TypeError, ValueError):
        return "—"


def _section_url(course, section):
    return _absolute(
        "jeiko_courses:section_view",
        course_slug=course.slug,
        section_id=section.id,
    )


# =========================
#  Inscriptions
# =========================

def send_enrolled(enrollment):
    """Confirmation d'inscription (achat ou accès libre)."""
    user = enrollment.user
    course = enrollment.course
    send_email(
        "course_enrolled",
        user.email,
        {
            "formation_nom": course.title,
            "lien_action": _course_url(course),
            "nombre_chapitres": _published_chapters(course),
        },
        user=user,
    )


def send_access_granted(enrollment):
    """Accès ouvert manuellement par un administrateur."""
    user = enrollment.user
    course = enrollment.course
    send_email(
        "course_access_granted_admin",
        user.email,
        {
            "formation_nom": course.title,
            "lien_action": _course_url(course),
        },
        user=user,
    )


def send_completed(enrollment):
    """Félicitations à l'achèvement de la formation."""
    user = enrollment.user
    course = enrollment.course
    completed = enrollment.completed_at or timezone.now()
    send_email(
        "course_completed",
        user.email,
        {
            "formation_nom": course.title,
            "date_fin": timezone.localtime(completed).strftime("%d/%m/%Y"),
            "lien_attestation": _certificate_url(course),
        },
        user=user,
    )


def send_suspended(enrollment, motif=""):
    """Notification de suspension de l'accès."""
    user = enrollment.user
    course = enrollment.course
    send_email(
        "course_suspended",
        user.email,
        {
            "formation_nom": course.title,
            "motif": motif or "—",
        },
        user=user,
    )


# =========================
#  Quiz
# =========================

# =========================
#  Nouveau contenu (action admin explicite)
# =========================

def notify_new_content(section):
    """Prévient les inscrits (accès non suspendu) qu'une section est publiée.

    Déclenché par un bouton d'administration, jamais automatiquement : l'admin
    décide quand une formation est « enrichie ». Retourne le nombre d'envois.
    """
    from jeiko.courses.models import CourseEnrollment

    course = section.chapter.part.course
    lien = _section_url(course, section)
    enrollments = (
        CourseEnrollment.objects
        .filter(course=course)
        .exclude(status=CourseEnrollment.STATUS_SUSPENDED)
        .select_related("user")
    )

    sent = 0
    for enrollment in enrollments:
        user = enrollment.user
        if not getattr(user, "email", None):
            continue
        success, _ = send_email(
            "course_new_content",
            user.email,
            {
                "formation_nom": course.title,
                "contenu_nom": section.title,
                "lien_action": lien,
            },
            user=user,
        )
        if success:
            sent += 1
    return sent


def send_quiz_result(attempt):
    """Résultat d'une tentative de quiz : réussite ou échec."""
    user = attempt.user
    quiz = attempt.quiz
    course = quiz.section.chapter.part.course
    quiz_nom = quiz.title or quiz.section.title

    if attempt.is_passed:
        send_email(
            "quiz_passed",
            user.email,
            {
                "formation_nom": course.title,
                "quiz_nom": quiz_nom,
                "score": _score_label(attempt.score_percentage),
                "lien_action": _course_url(course),
            },
            user=user,
        )
    else:
        send_email(
            "quiz_failed",
            user.email,
            {
                "formation_nom": course.title,
                "quiz_nom": quiz_nom,
                "score": _score_label(attempt.score_percentage),
                "score_requis": f"{quiz.passing_score} %",
                "lien_action": _course_url(course),
            },
            user=user,
        )
