"""
Signals for the courses app.
Handles automatic progression updates and shop integration.
"""
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.utils import timezone

from .models import CourseEnrollment, VideoProgress, SectionProgress, QuizAttempt
from .utils import calculate_course_progress
from . import emailing


@receiver(post_save, sender=VideoProgress)
def update_section_progress_on_video_complete(sender, instance, created, **kwargs):
    """
    Quand une vidéo est complétée, marquer la section comme complétée.
    """
    if instance.is_completed:
        section_progress, created = SectionProgress.objects.get_or_create(
            enrollment=instance.enrollment,
            section=instance.section,
            defaults={
                'is_completed': True,
                'completed_at': timezone.now()
            }
        )
        
        if not created and not section_progress.is_completed:
            section_progress.is_completed = True
            section_progress.completed_at = timezone.now()
            section_progress.save()


@receiver(post_save, sender=SectionProgress)
def recalculate_course_progress_on_section_update(sender, instance, **kwargs):
    """
    Recalculer la progression globale quand une section est marquée comme complétée/skippée.
    """
    if instance.is_completed or instance.is_skipped:
        calculate_course_progress(instance.enrollment)


@receiver(post_save, sender=QuizAttempt)
def update_section_progress_on_quiz_attempt(sender, instance, created, **kwargs):
    """
    Mettre à jour la progression de section après une tentative de quiz.
    """
    if instance.completed_at or instance.was_skipped:
        section = instance.quiz.section
        enrollment = instance.enrollment
        
        section_progress, created = SectionProgress.objects.get_or_create(
            enrollment=enrollment,
            section=section,
            defaults={
                'is_completed': instance.is_passed,
                'is_skipped': instance.was_skipped,
                'completed_at': timezone.now() if (instance.is_passed or instance.was_skipped) else None
            }
        )
        
        if not created:
            # Mettre à jour si nécessaire
            if instance.is_passed and not section_progress.is_completed:
                section_progress.is_completed = True
                section_progress.completed_at = timezone.now()
                section_progress.save()
            elif instance.was_skipped and not section_progress.is_skipped:
                section_progress.is_skipped = True
                section_progress.completed_at = timezone.now()
                section_progress.save()


# =============================================================================
# E-MAILS « FORMATIONS »
# =============================================================================
#
# Déclenchés par les transitions d'inscription et les tentatives de quiz. La
# composition est déléguée à emailing.py (catalogue éditable). Voir aussi la
# feuille de route pour course_new_content et course_progress_stalled, non
# branchés ici (déclencheur/CRON à décider).

@receiver(pre_save, sender=CourseEnrollment)
def _stash_enrollment_status(sender, instance, **kwargs):
    """Mémorise le statut en base avant enregistrement, pour détecter une
    transition dans le post_save (create = pas d'ancien statut)."""
    if instance.pk:
        instance._jeiko_old_status = CourseEnrollment.objects.filter(
            pk=instance.pk).values_list('status', flat=True).first()
    else:
        instance._jeiko_old_status = None


@receiver(post_save, sender=CourseEnrollment)
def _email_on_enrollment(sender, instance, created, **kwargs):
    if created:
        # Accès accordé par un admin à quelqu'un d'autre → mail dédié ;
        # sinon (achat ou accès libre) → confirmation d'inscription.
        granted_by_admin = (
            instance.granted_by_id and instance.granted_by_id != instance.user_id
        )
        if granted_by_admin:
            emailing.send_access_granted(instance)
        else:
            emailing.send_enrolled(instance)
        return

    old_status = getattr(instance, '_jeiko_old_status', None)
    if old_status == instance.status:
        return
    if instance.status == CourseEnrollment.STATUS_COMPLETED:
        emailing.send_completed(instance)
    elif instance.status == CourseEnrollment.STATUS_SUSPENDED:
        emailing.send_suspended(instance)


@receiver(post_save, sender=QuizAttempt)
def _email_on_quiz_attempt(sender, instance, created, **kwargs):
    # Une tentative est créée déjà terminée (soumission) ou passée (skip).
    # On n'envoie qu'à la soumission d'une vraie tentative.
    if created and instance.completed_at and not instance.was_skipped:
        emailing.send_quiz_result(instance)


# =============================================================================
# SHOP INTEGRATION
# =============================================================================
#
# L'octroi d'accès aux formations après paiement est géré de façon UNIQUE et
# idempotente par jeiko.shop.services.mark_order_paid (_grant_access), appelé
# aussi bien par le retour navigateur que par le webhook, sous verrou de ligne.
#
# L'ancien signal `auto_grant_course_access_on_payment` (post_save sur
# shop.Order) a été RETIRÉ : il faisait doublon, se redéclenchait à chaque
# sauvegarde d'une commande déjà payée (y compris le save interne de
# mark_order_paid) et réécrivait les notes à chaque passage.
