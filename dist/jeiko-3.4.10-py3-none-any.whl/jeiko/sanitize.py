"""
Assainissement du HTML saisi dans l'administration.

Le contenu des pages est du HTML : les rédacteurs doivent pouvoir mettre en
forme, insérer des liens, des images. On ne peut donc pas simplement tout
échapper. Mais on ne peut pas non plus le rendre tel quel — un `<script>`, un
attribut `onerror=` ou une URL `javascript:` s'exécuteraient chez tous les
visiteurs, y compris les administrateurs, ce qui permet le vol de session vers
un compte plus privilégié.

Stratégie, par ordre de préférence :

1. `nh3` — liaison Python d'`ammonia` (Rust), l'analyseur de référence. C'est la
   dépendance déclarée dans requirements.txt.
2. `bleach` — repli si le projet l'a déjà.
3. Aucun des deux — on **échappe intégralement**. Le rendu perd sa mise en
   forme, ce qui se voit immédiatement, plutôt que de laisser passer du script
   silencieusement. Un défaut visible vaut mieux qu'une faille invisible.

Le comportement est pilotable par `JEIKO_SANITIZE_HTML` (défaut : True). Le
passer à False rend le HTML brut : à ne faire que si les seuls rédacteurs sont
de confiance et qu'aucun rôle n'est délégué à un tiers.
"""

import logging
import re

from django.conf import settings
from django.utils.html import escape
from django.utils.safestring import mark_safe

logger = logging.getLogger("jeiko")

# Balises de mise en forme, de structure et de média. Volontairement sans
# <script>, <style>, <iframe>, <object>, <embed>, <form> ni <input>.
ALLOWED_TAGS = {
    "a", "abbr", "b", "blockquote", "br", "caption", "cite", "code", "col",
    "colgroup", "dd", "del", "div", "dl", "dt", "em", "figcaption", "figure",
    "h1", "h2", "h3", "h4", "h5", "h6", "hr", "i", "img", "ins", "li", "mark",
    "ol", "p", "picture", "pre", "q", "s", "small", "source", "span", "strong",
    "sub", "sup", "table", "tbody", "td", "tfoot", "th", "thead", "time", "tr",
    "u", "ul", "video", "audio",
}

# Aucun attribut `on*` : c'est la voie d'exécution la plus courante.
ALLOWED_ATTRIBUTES = {
    "*": {"class", "id", "title", "dir", "lang", "role", "aria-label", "aria-hidden"},
    # « rel » est absent volontairement : nh3 le pose lui-même via link_rel et
    # refuse qu'on le déclare en plus. Le repli bleach l'ajoute de son côté.
    "a": {"href", "target"},
    "img": {"src", "alt", "width", "height", "loading", "srcset", "sizes"},
    "source": {"src", "srcset", "type", "media"},
    "video": {"src", "controls", "poster", "width", "height", "preload"},
    "audio": {"src", "controls", "preload"},
    "td": {"colspan", "rowspan"},
    "th": {"colspan", "rowspan", "scope"},
    "time": {"datetime"},
    "col": {"span"},
    "colgroup": {"span"},
}

# `javascript:` et `data:` exclus — `data:text/html` est un vecteur d'exécution.
ALLOWED_SCHEMES = {"http", "https", "mailto", "tel"}

_BACKEND = None


def _resolve_backend():
    """Choisit l'implémentation une fois pour toutes, et le dit dans le journal."""
    global _BACKEND
    if _BACKEND is not None:
        return _BACKEND

    try:
        import nh3  # noqa: F401
        _BACKEND = "nh3"
    except ImportError:
        try:
            import bleach  # noqa: F401
            _BACKEND = "bleach"
        except ImportError:
            _BACKEND = "escape"
            logger.warning(
                "Ni nh3 ni bleach ne sont installés : le HTML des contenus sera "
                "intégralement échappé et perdra sa mise en forme. "
                "Installer nh3 (déjà présent dans requirements.txt) pour "
                "rétablir le rendu."
            )
    return _BACKEND


def clean_html(value):
    """
    Retourne une chaîne sûre à insérer telle quelle dans un gabarit.

    La valeur de retour n'est PAS marquée sûre : c'est à l'appelant de le faire
    explicitement, pour que chaque `mark_safe` du code reste visible.
    """
    if not value:
        return ""

    text = str(value)

    if not getattr(settings, "JEIKO_SANITIZE_HTML", True):
        return text

    backend = _resolve_backend()

    if backend == "nh3":
        import nh3
        return nh3.clean(
            text,
            tags=ALLOWED_TAGS,
            attributes={k: set(v) for k, v in ALLOWED_ATTRIBUTES.items()},
            url_schemes=ALLOWED_SCHEMES,
            link_rel="noopener noreferrer",
        )

    if backend == "bleach":
        import bleach
        attributes = {k: list(v) for k, v in ALLOWED_ATTRIBUTES.items()}
        # bleach ne pose pas rel="noopener" tout seul : on autorise l'attribut
        # pour que celui déjà présent dans le contenu survive.
        attributes["a"] = attributes.get("a", []) + ["rel"]
        return bleach.clean(
            text,
            tags=ALLOWED_TAGS,
            attributes=attributes,
            protocols=list(ALLOWED_SCHEMES),
            strip=True,
        )

    return escape(text)


def clean_html_safe(value):
    """`clean_html` suivi de `mark_safe` — pour un usage direct en gabarit."""
    return mark_safe(clean_html(value))


# ---------------------------------------------------------------------------
#  SVG
# ---------------------------------------------------------------------------
#
# Un SVG est un document XML, pas une image inerte : il peut porter un
# `<script>`, un attribut `on*` ou un lien `javascript:`. Servi depuis /media/,
# il s'exécute sur l'origine du site — donc avec la session du visiteur qui
# l'ouvre. `clean_html` ne convient pas ici : sa liste blanche est faite pour du
# HTML de contenu et retirerait tout le dessin.
#
# On procède donc par retrait ciblé des seules constructions exécutables. C'est
# suffisant pour un fichier d'icône, qui n'a besoin d'aucune d'entre elles.

#: Éléments qui peuvent exécuter, ou faire exécuter, quelque chose.
#:
#: `set`, `animate` et leurs variantes n'exécutent rien elles-mêmes : elles
#: écrivent un attribut pendant l'animation. `<set attributeName="onload"
#: to="alert(1)"/>` pose donc un gestionnaire d'événement APRÈS le nettoyage,
#: et `<animate attributeName="href" values="javascript:…"/>` réintroduit un
#: lien exécutable. Elles sont aussi dangereuses que `<script>`.
_ELEMENTS_DANGEREUX = (
    "script", "foreignObject", "iframe", "embed", "object", "handler",
    "set", "animate", "animateTransform", "animateMotion",
)

_NOMS = "|".join(_ELEMENTS_DANGEREUX)

# S-06 — La forme AUTO-FERMANTE portait une liste plus courte que la forme
# appariée : `handler`, `set` et `animate` n'y figuraient pas. `<set …>` fermé
# par une paire était retiré, `<set …/>` passait. Or c'est la forme naturelle
# de ces éléments, qui n'ont pas de contenu. Les deux branches lisent
# désormais la même liste, ce qui rend l'écart impossible.
_SVG_DANGEROUS_ELEMENTS = re.compile(
    rf"<\s*({_NOMS})\b[^>]*>.*?<\s*/\s*\1\s*>"
    rf"|<\s*(?:{_NOMS})\b[^>]*/?>",
    re.IGNORECASE | re.DOTALL,
)

# Attributs gestionnaires d'événement : onload, onclick, onmouseover…
# Pas de forme encodée à prévoir ici : les références de caractères ne sont
# décodées que dans les VALEURS d'attribut, jamais dans leur nom.
_SVG_EVENT_ATTRS = re.compile(r"\son[a-z]+\s*=\s*(\"[^\"]*\"|'[^']*'|[^\s>]+)",
                              re.IGNORECASE)


def _lettre_encodable(caractere):
    """
    Une lettre, ou l'une de ses écritures en référence de caractère XML.

    `&#106;`, `&#0000106;`, `&#x6A;`, `&#X6a`, avec ou sans point-virgule
    final : les navigateurs acceptent toutes ces formes dans une valeur
    d'attribut, et les décodent avant de lire le schéma de l'URL.
    """
    code = ord(caractere)
    return (
        f"(?:[{caractere.lower()}{caractere.upper()}]"
        rf"|&#0*{code};?"
        rf"|&#[xX]0*{code:x};?)"
    )


def _mot_encodable(mot):
    """
    Le mot, lettre par lettre, chacune éventuellement encodée.

    Les séparateurs autorisés entre deux lettres sont la tabulation, le saut
    de ligne, le retour chariot et le caractère nul : les navigateurs les
    retirent d'une URL avant de l'interpréter, si bien que `java\tscript:` et
    `java&#10;script:` valent `javascript:`. C'est un contournement classique,
    et il ne coûte rien de le fermer.
    """
    separateur = r"[\t\n\r\x00]*"
    return separateur.join(_lettre_encodable(lettre) for lettre in mot)


# S-06 — Liens exécutables. La version précédente cherchait le mot en clair :
# `href="&#106;avascript:alert(1)"` passait intact, alors que le navigateur y
# lit `javascript:`. On accepte donc les mêmes écritures que lui.
_SVG_JS_URLS = re.compile(
    r"(?:href|xlink:href|src)\s*=\s*(\"|')?\s*"
    rf"(?:{_mot_encodable('javascript')}|{_mot_encodable('data')})"
    r"\s*:[^\"'>]*(\"|')?",
    re.IGNORECASE,
)


def clean_svg(value):
    """
    Retire d'un SVG ce qui peut s'exécuter. Retourne le document nettoyé.

    Accepte des octets ou une chaîne. Ne valide pas que l'entrée est un SVG
    correct : ce n'est pas le sujet, un fichier illisible restera illisible.
    """
    if not value:
        return ""

    if isinstance(value, (bytes, bytearray)):
        text = value.decode("utf-8", errors="replace")
    else:
        text = str(value)

    text = _SVG_DANGEROUS_ELEMENTS.sub("", text)
    text = _SVG_EVENT_ATTRS.sub("", text)
    text = _SVG_JS_URLS.sub("", text)
    return text
