# jeiko/administration_menu/tests_panier.py
"""
L'icône panier : présente quand on la demande, absente sinon, dans les quatre
dispositions.

Pourquoi une option et pas une détection
----------------------------------------
`menu_tags.render_main_menu` met le HTML du menu en cache **trente jours**, par
identifiant de menu et sans contexte de requête. Tout ce qui est rendu ici est
donc figé pour un mois et servi à tous les visiteurs.

Cela exclut deux idées naturelles :

* un **compteur d'articles** — il afficherait à tout le monde le panier du
  premier visiteur servi ;
* un affichage **conditionné à l'existence de produits** — la réponse resterait
  fausse un mois après la création du premier produit.

`Menu.show_cart` est une propriété du menu, et modifier le menu invalide sa
clé de cache. C'est la seule des trois formes qui reste juste.

Le test des quatre dispositions n'est pas décoratif : `administration_menu/
tests_layouts.py` existe parce qu'une disposition avait déjà divergé des
autres, laissant le menu mobile inopérant sur l'une d'elles seulement.
"""

import pathlib

from django.test import SimpleTestCase, TestCase
from django.template.loader import render_to_string

from jeiko.administration_menu.models import Menu, MenuPlace

LAYOUTS = (
    pathlib.Path(__file__).resolve().parent.parent
    / "templates" / "menu" / "layouts"
)


class InclusionDansLesDispositionsTests(SimpleTestCase):
    def test_les_quatre_dispositions_incluent_le_panier(self):
        """
        Une disposition oubliée priverait ses sites de l'accès au panier, sans
        rien signaler — le menu s'afficherait, simplement amputé.
        """
        manquantes = [
            f.name for f in sorted(LAYOUTS.glob("*.html"))
            if "menu/partials/panier.html" not in f.read_text()
        ]
        self.assertEqual(manquantes, [])

    def test_l_inclusion_est_toujours_conditionnee(self):
        """
        Une icône panier sur un site qui ne vend rien mène à une page vide.
        """
        for f in sorted(LAYOUTS.glob("*.html")):
            with self.subTest(disposition=f.name):
                texte = f.read_text()
                avant = texte[: texte.index("menu/partials/panier.html")]
                self.assertIn(
                    "menu.show_cart", avant[-120:],
                    "L'inclusion du panier n'est pas gardée par menu.show_cart.",
                )


class RenduDuPanierTests(TestCase):
    def _rendre(self, show_cart):
        menu = Menu.objects.create(
            name="Principal", place=MenuPlace.MAIN,
            layout="logo-left-menu-right", show_cart=show_cart,
        )
        return render_to_string(
            "menu/layouts/logo-left-menu-right.html", {"menu": menu}
        )

    def test_l_icone_apparait_quand_l_option_est_active(self):
        html = self._rendre(True)
        self.assertIn('class="menu-cart"', html)
        self.assertIn('aria-label="Mon panier"', html)

    def test_l_icone_est_absente_par_defaut(self):
        """
        `show_cart` vaut False par défaut : les sites existants ne voient rien
        changer à leur menu au moment de la mise à jour.
        """
        self.assertNotIn('class="menu-cart"', self._rendre(False))

    def test_l_icone_pointe_vers_le_panier(self):
        from django.urls import reverse

        self.assertIn(
            f'href="{reverse("jeiko_client_shop:cart_detail")}"',
            self._rendre(True),
        )
