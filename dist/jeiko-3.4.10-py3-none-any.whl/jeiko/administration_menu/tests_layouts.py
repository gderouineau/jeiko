# jeiko/administration_menu/tests_layouts.py
"""
Le menu mobile s'ouvre — vérifié sur les quatre layouts.

Pourquoi ce fichier existe
--------------------------
Les quatre gabarits de layout portaient un attribut Alpine décomposé :

    <div class="menu menu-panel mobile ? 'is-open' : ''"
         :
         x-cloak="menu">

L'expression `mobile ? 'is-open' : ''` s'était retrouvée **à l'intérieur** de
l'attribut `class`, où elle ne vaut rien, et il ne restait qu'un `:` orphelin à
la place de `:class`. La classe `is-open` n'était donc jamais posée.

Or `menu/styles/toggle_menu.html` déclare, sous 992 px :

    nav.top-menu .menu-panel        { display:none; }
    nav.top-menu .menu-panel.is-open{ display:block; }

Conséquence : **le menu ne s'ouvrait sur aucun mobile, sur aucun layout.** Le
bouton bascule bien l'état `mobile`, mais rien ne l'écoutait.

Ce que ces tests attrapent
--------------------------
Le défaut était invisible : le gabarit compile, la page se rend, aucune erreur
n'est levée — le panneau reste simplement fermé. Seul un contrôle sur le HTML
produit peut le voir, d'où ces tests plutôt qu'une relecture.

Ils vérifient le HTML **rendu**, pas le source du gabarit : c'est ce que reçoit
le navigateur qui compte, et c'est la seule forme qui résiste à un changement
d'écriture du gabarit.
"""

import re

from django.template.loader import render_to_string
from django.test import RequestFactory, SimpleTestCase

from .models import MenuLayout

#: Les quatre layouts livrés, et le nombre de panneaux mobiles de chacun.
#: `logo-center-sides` en a deux — un de chaque côté du logo — qui s'ouvrent
#: ensemble sur le même état.
LAYOUTS = {
    MenuLayout.LOGO_LEFT_MENU_RIGHT: 1,
    MenuLayout.LOGO_TOP_MENU_LEFT: 1,
    MenuLayout.LOGO_CENTER_BELOW: 1,
    MenuLayout.LOGO_CENTER_SIDES: 2,
}

#: Le binding attendu, tel qu'il doit ressortir dans le HTML.
BINDING = """:class="mobile ? 'is-open' : ''\""""


class _MenuFactice:
    """
    Le minimum qu'un layout consulte, sans toucher la base.

    Les gabarits n'ont besoin que de `id`, `name` et `menu_items.all` : un objet
    nu suffit et garde ces tests en `SimpleTestCase`, donc rapides et sans
    migrations.
    """

    id = 1
    name = "Menu de test"

    class _Items:
        @staticmethod
        def all():
            return []

    menu_items = _Items()


#: Les blocs <style> embarqués, à retirer avant de compter.
_STYLE_RE = re.compile(r"<style\b.*?</style>", re.IGNORECASE | re.DOTALL)


def _rendre(layout):
    """
    Rend un layout isolément et renvoie son BALISAGE, sans les blocs `<style>`.

    Deux précautions :

    - `request` est indispensable : `logo-center-sides` inclut
      `menu/styles/toggle_menu.html`, dont le `{% filter mq_to_cq:request %}`
      lève sans lui. On le fournit aux quatre, pour un chemin identique.
    - Les `<style>` sont retirés : ce même partiel écrit ses règles dans la
      page, et elles contiennent les mots `menu-panel` et `x-cloak`. Les
      compter reviendrait à mesurer la feuille de style au lieu du balisage.
    """
    html = render_to_string(
        f"menu/layouts/{layout}.html",
        {"menu": _MenuFactice(), "logo_obj": None,
         "request": RequestFactory().get("/")},
    )
    return _STYLE_RE.sub("", html)


class BindingDuPanneauMobileTests(SimpleTestCase):
    """Le panneau mobile est bien piloté par Alpine, sur les quatre layouts."""

    def test_chaque_layout_pose_le_binding_alpine(self):
        for layout, nombre in LAYOUTS.items():
            with self.subTest(layout=layout):
                html = _rendre(layout)
                self.assertEqual(
                    html.count(BINDING), nombre,
                    f"{layout} : {html.count(BINDING)} binding(s) trouvé(s), "
                    f"{nombre} attendu(s). Sans lui, la classe « is-open » "
                    f"n'est jamais posée et le menu ne s'ouvre pas sur mobile.",
                )

    def test_lexpression_alpine_ne_fuit_pas_dans_lattribut_class(self):
        """
        C'est la forme exacte du défaut d'origine.

        Une expression ternaire à l'intérieur de `class="…"` ne produit pas de
        classe : elle ajoute les jetons « mobile », « ? », « 'is-open' » et
        « : » à la liste des classes, où ils ne correspondent à aucune règle.
        """
        for layout in LAYOUTS:
            with self.subTest(layout=layout):
                html = _rendre(layout)
                self.assertNotIn(
                    "menu-panel mobile ?", html,
                    f"{layout} : l'expression Alpine est retombée dans "
                    f"l'attribut « class ».",
                )

    def test_le_panneau_porte_la_classe_darrimage_du_css(self):
        """
        `.menu-panel` est ce que cible toggle_menu.html pour cacher et montrer.

        Le nombre compte : c'est lui qui dit que les deux panneaux de
        `logo-center-sides` sont bien tous les deux pilotés, et qu'un layout
        à panneau unique n'en a pas gagné un second par accident.
        """
        for layout, nombre in LAYOUTS.items():
            with self.subTest(layout=layout):
                html = _rendre(layout)
                self.assertEqual(
                    html.count("menu-panel"), nombre,
                    f"{layout} : {html.count('menu-panel')} panneau(x) trouvé(s), "
                    f"{nombre} attendu(s).",
                )

    def test_x_cloak_est_un_attribut_nu(self):
        """
        `x-cloak` prend sa valeur du sélecteur CSS `[x-cloak]`, pas d'une valeur.

        La forme `x-cloak="menu"` avait entraîné l'écriture d'un sélecteur
        `[x-cloak="menu"]` dans le CSS — le style avait été ajusté à l'attribut
        cassé au lieu de l'inverse.
        """
        for layout in LAYOUTS:
            with self.subTest(layout=layout):
                html = _rendre(layout)
                self.assertNotIn('x-cloak="menu"', html)
                self.assertIn("x-cloak", html)

    def test_aucun_commentaire_ne_ressort_dans_la_page(self):
        """
        Les commentaires `{# … #}` de Django sont MONO-LIGNE.

        Dès qu'un retour à la ligne sépare l'ouverture de la fermeture, le
        moteur ne reconnaît plus un commentaire et rend le contenu en texte
        brut, en évaluant au passage les variables qu'il contient. Le défaut
        est décrit en B12 de AUDIT_EDITOR.md — et il a été réintroduit ici en
        commentant la correction du binding, ce qu'aucune relecture n'avait vu.
        """
        for layout in LAYOUTS:
            with self.subTest(layout=layout):
                html = _rendre(layout)
                self.assertNotIn(
                    "{#", html,
                    f"{layout} : un commentaire multi-lignes ressort dans la "
                    f"page. Utiliser {{% comment %}}.",
                )

    def test_le_bouton_bascule_letat_lu_par_le_panneau(self):
        """
        Le bouton et le panneau doivent parler du même état.

        Sans ce contrôle, renommer `mobile` d'un seul côté rouvrirait
        exactement le même défaut, tout aussi silencieusement.
        """
        for layout in LAYOUTS:
            with self.subTest(layout=layout):
                html = _rendre(layout)
                self.assertIn('x-data="{ mobile:false }"', html)
                self.assertIn('x-on:click="mobile = !mobile"', html)
                self.assertIn(BINDING, html)
