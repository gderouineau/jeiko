

from django.db import models, transaction
from django.db.models import Q, Max, Index
from django.core.exceptions import ValidationError
from django.core.cache import cache
from django.db.models.signals import post_save, post_delete, pre_save, pre_delete
from django.dispatch import receiver
from django.db.models import TextChoices

from jeiko.administration_pages.models import Page



class MenuStyle(models.Model):
    name = models.CharField(
        max_length=120,
        default="Style par défaut",
        help_text="Nom interne pour retrouver ce style."
    )

    # Couleurs
    background_color = models.CharField(
        max_length=20, default="#ffffff", help_text="Couleur de fond du menu."
    )
    text_color = models.CharField(
        max_length=20, default="#111111", help_text="Couleur du texte des liens."
    )
    hover_text_color = models.CharField(
        max_length=20, default="#111111", help_text="Couleur du texte au survol."
    )
    active_text_color = models.CharField(
        max_length=20, default="#111111", help_text="Couleur du lien actif (optionnel)."
    )
    submenu_background_color = models.CharField(
        max_length=20, default="#ffffff", help_text="Fond des sous-menus."
    )
    submenu_border_color = models.CharField(
        max_length=20, default="#e5e7eb", help_text="Bordure des sous-menus."
    )
    submenu_hover_background_color = models.CharField(
        max_length=20, default="#f7f7f7", help_text="Fond au survol d’un item de sous-menu."
    )

    # Typo
    font_family = models.CharField(
        max_length=120, blank=True, default="",
        help_text="Nom de police (si vide, utiliser la police du site)."
    )
    font_weight = models.CharField(
        max_length=12,
        choices=[
            ("normal", "Normal"),
            ("500", "Medium (500)"),
            ("600", "Semibold (600)"),
            ("700", "Bold (700)"),
        ],
        default="normal",
    )
    font_size_mobile = models.PositiveSmallIntegerField(
        default=16, help_text="Taille de police mobile (px)."
    )
    font_size_desktop = models.PositiveSmallIntegerField(
        default=16, help_text="Taille de police desktop (px)."
    )
    letter_spacing = models.DecimalField(
        max_digits=4, decimal_places=2, default=0.0, help_text="Espacement (em)."
    )
    uppercase = models.BooleanField(default=False)

    # Dimensions / espacements
    menu_min_height = models.PositiveSmallIntegerField(
        default=80, help_text="Hauteur minimale du menu (px)."
    )
    padding_y_mobile = models.PositiveSmallIntegerField(
        default=10, help_text="Padding vertical mobile (px)."
    )
    padding_y_desktop = models.PositiveSmallIntegerField(
        default=12, help_text="Padding vertical desktop (px)."
    )
    gap_desktop = models.PositiveSmallIntegerField(
        default=32, help_text="Espacement entre liens desktop (px)."
    )
    gap_mobile = models.PositiveSmallIntegerField(
        default=0, help_text="Espacement vertical entre liens mobile (px)."
    )

    # Logo
    logo_width_mobile = models.PositiveSmallIntegerField(
        default=80, help_text="Largeur logo mobile (px)."
    )
    logo_width_desktop = models.PositiveSmallIntegerField(
        default=100, help_text="Largeur logo desktop (px)."
    )
    logo_height_desktop = models.PositiveSmallIntegerField(
        default=100, help_text="Hauteur logo desktop (px)."
    )

    # Bordure / séparation
    border_bottom_width = models.PositiveSmallIntegerField(
        default=0, help_text="Bordure bas (px). 0 pour aucune."
    )
    border_bottom_color = models.CharField(
        max_length=20, default="#e5e7eb", help_text="Couleur de la bordure bas."
    )

    # Comportement
    sticky = models.BooleanField(
        default=False, help_text="Menu sticky (collé en haut) ?"
    )
    sticky_shadow = models.BooleanField(
        default=True, help_text="Ajouter une ombre quand sticky."
    )
    transitions_ms = models.PositiveSmallIntegerField(
        default=180, help_text="Durée des transitions (ms)."
    )
    rounded_submenu = models.PositiveSmallIntegerField(
        default=8, help_text="Rayon de bordure des sous-menus (px)."
    )

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Style de menu"
        verbose_name_plural = "Styles de menu"
        ordering = ["name"]

    def __str__(self):
        return self.name


    pass


class MenuPlace(TextChoices):
    NULL = "NULL", "Non assigné"
    MAIN = "MAIN", "Menu Principal"
    FOOTER = "FOOTER", "Footer"


class MenuLayout(TextChoices):
    LOGO_LEFT_MENU_RIGHT = "logo-left-menu-right", "Logo à gauche, menu à droite"
    LOGO_TOP_MENU_LEFT = "logo-top-menu-left",   "Logo haut gauche, menu dessous aligné à gauche"
    LOGO_CENTER_SIDES = "logo-center-sides",    "Logo centré avec menu de part et d’autre"
    LOGO_CENTER_BELOW = "logo-center-below",    "Logo centré, menu en dessous centré"


LAYOUTS_BY_PLACE = {
    MenuPlace.MAIN: {
        MenuLayout.LOGO_LEFT_MENU_RIGHT,
        MenuLayout.LOGO_TOP_MENU_LEFT,
        MenuLayout.LOGO_CENTER_SIDES,
        MenuLayout.LOGO_CENTER_BELOW,
    },
    MenuPlace.FOOTER: set(),   # on remplira le jour où tu ajoutes des layouts footer
    MenuPlace.NULL: set(),
}


class Menu(models.Model):

    name = models.CharField(
        max_length=200,
        verbose_name='nom',
        default=""
    )

    place = models.CharField(
        max_length=10,
        default=MenuPlace.NULL,
        choices=MenuPlace.choices,
    )

    layout = models.CharField(
        max_length=32,
        choices=MenuLayout.choices,
        blank=True,
        null=True,
    )

    menu_style = models.ForeignKey(
        MenuStyle,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="menus"
    )

    updated_at = models.DateTimeField(
        auto_now=True
    )

    is_default = models.BooleanField(
        default=False,
        help_text="Cocher pour définir ce menu comme défaut pour cet emplacement."
    )

    logo = models.ForeignKey(
        'administration.Logo',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='menus'
    )

    show_cart = models.BooleanField(
        default=False,
        verbose_name="Afficher l'icône panier",
        help_text=(
            "Ajoute un accès au panier en haut à droite du menu. "
            "À n'activer que sur un site qui vend."
        ),
    )

    class Meta:
        constraints = [
            # Un seul DEFAULT par place (MAIN)
            models.UniqueConstraint(
                fields=["place"],
                condition=Q(place=MenuPlace.MAIN) & Q(is_default=True),
                name="uniq_default_menu_main",
            ),
            # Un seul DEFAULT par place (FOOTER)
            models.UniqueConstraint(
                fields=["place"],
                condition=Q(place=MenuPlace.FOOTER) & Q(is_default=True),
                name="uniq_default_menu_footer",
            ),
            # Règle layout: requis uniquement pour MAIN, interdit ailleurs (comme tu l’avais)
            models.CheckConstraint(
                name="menu_layout_required_for_main_only",
                condition=(
                        (Q(place=MenuPlace.MAIN) & Q(layout__isnull=False)) |
                        (Q(place__in=[MenuPlace.FOOTER, MenuPlace.NULL]) & Q(layout__isnull=True))
                ),
            ),
        ]

    def clean(self):
        errors = {}

        # Layout requis UNIQUEMENT pour MAIN
        if self.place == MenuPlace.MAIN and not self.layout:
            errors['layout'] = "Un layout est requis pour un menu principal (MAIN)."
        if self.place in [MenuPlace.FOOTER, MenuPlace.NULL] and self.layout:
            errors['layout'] = "Aucun layout n'est attendu pour cet emplacement."

        # (Option) Vérifier que le layout appartient bien aux layouts autorisés pour cet emplacement
        allowed = LAYOUTS_BY_PLACE.get(self.place, set())
        if self.place == MenuPlace.MAIN and self.layout and self.layout not in allowed:
            errors['layout'] = "Ce layout n’est pas autorisé pour MAIN."

        if errors:
            from django.core.exceptions import ValidationError
            raise ValidationError(errors)

    def __str__(self):
        return self.name

    def effective_logo(self):
        """
        Retourne le Logo à utiliser pour ce menu :
        - logo du menu s'il est défini,
        - sinon logo du site (WebSite.logo),
        - sinon None.
        """
        if getattr(self, "logo_id", None):
            return self.logo
        try:
            from jeiko.administration.models import WebSite
            site = WebSite.objects.select_related('logo').first()
            return getattr(site, 'logo', None)
        except Exception:
            return None



class MenuItem(models.Model):
    title = models.CharField(max_length=100, verbose_name="titre", default="")
    position = models.IntegerField(default=0)

    menu = models.ForeignKey(
        Menu, related_name="menu_items", on_delete=models.CASCADE,
        null=True, blank=True,
    )
    active = models.BooleanField(default=False)

    main_menu = models.ForeignKey(
        'self', related_name="submenus",
        on_delete=models.CASCADE, null=True, blank=True,
    )

    page = models.ForeignKey(
        Page, related_name="menus",
        on_delete=models.SET_NULL, null=True, blank=True,
    )

    class Meta:
        ordering = ('position',)
        constraints = [
            models.UniqueConstraint(
                fields=['menu', 'position'],
                condition=Q(main_menu__isnull=True),
                name='uq_menuitem_top_position'
            ),
            models.UniqueConstraint(
                fields=['main_menu', 'position'],
                name='uq_menuitem_sub_position'
            ),
        ]
        indexes = [
            Index(fields=['menu', 'position']),
            Index(fields=['main_menu', 'position']),
        ]

    def __str__(self):
        return self.title

    @property
    def is_sub_menu(self) -> bool:
        return self.main_menu_id is not None

    def clean(self):
        """
        - Item top-level  => menu requis.
        - Sous-menu       => parent != soi et parent dans le même menu.
        """
        errors = {}

        if self.main_menu_id is None:
            # Top-level
            if self.menu_id is None:
                errors["menu"] = "Un item top-level doit appartenir à un menu."
        else:
            # Sous-menu
            if self.main_menu_id == self.id:
                errors["main_menu"] = "Un élément de menu ne peut pas être son propre parent."
            if self.main_menu and self.menu_id is None:
                errors["menu"] = "Un sous-menu doit appartenir au même menu que son parent."
            if self.main_menu and self.main_menu.menu_id != self.menu_id:
                errors["menu"] = "Le parent doit appartenir au même menu."

        if errors:
            raise ValidationError(errors)

        super().clean()

    def _siblings_qs(self):
        if self.main_menu_id:
            return MenuItem.objects.filter(main_menu=self.main_menu)
        return MenuItem.objects.filter(menu=self.menu, main_menu__isnull=True)

    def _same_scope(self, other: 'MenuItem') -> bool:
        if not isinstance(other, MenuItem):
            return False
        if self.main_menu_id and other.main_menu_id:
            return self.main_menu_id == other.main_menu_id
        if not self.main_menu_id and not other.main_menu_id:
            return self.menu_id == other.menu_id
        return False

    def _assign_position_if_needed(self):
        if not self._state.adding:
            return
        if self.position and self.position > 0:
            return
        qs = self._siblings_qs()
        max_pos = qs.exclude(pk=self.pk).aggregate(m=Max('position'))['m']
        self.position = 0 if max_pos is None else max_pos + 1

    def save(self, *args, **kwargs):
        self._assign_position_if_needed()
        self.full_clean()
        super().save(*args, **kwargs)

    @transaction.atomic
    def move_up(self) -> bool:
        prev_item = self._siblings_qs().filter(position__lt=self.position).order_by('-position').first()
        if not prev_item:
            return False
        return self._swap_positions(prev_item)

    @transaction.atomic
    def move_down(self) -> bool:
        next_item = self._siblings_qs().filter(position__gt=self.position).order_by('position').first()
        if not next_item:
            return False
        return self._swap_positions(next_item)

    def _swap_positions(self, other: 'MenuItem') -> bool:
        if not self._same_scope(other) or self.id == other.id:
            return False
        a_pos, b_pos = self.position, other.position
        MenuItem.objects.filter(pk=self.pk).update(position=-1)
        MenuItem.objects.filter(pk=other.pk).update(position=a_pos)
        MenuItem.objects.filter(pk=self.pk).update(position=b_pos)
        self.position, other.position = b_pos, a_pos
        # Le swap passe par .update() (pas de save()) : aucun signal ne se
        # déclenche, on invalide donc explicitement le HTML de rendu du menu
        # pour que le nouvel ordre soit pris en compte.
        _invalidate_menu_cache_by_ids(menu_id=self.menu_id)
        return True





# --------- Helpers ---------

def _invalidate_menu_cache_by_ids(menu_id=None, place=None):
    """
    Invalide les caches liés à un menu (HTML rendu + lookup par place).
    """
    if menu_id:
        cache.delete(f"menu:render:{menu_id}")          # cache HTML du rendu (render_main_menu)
    if place:
        cache.delete(f"menu:place:{place}:generic")     # id du menu par place (get_menu)


def _safe_get_menu_place(menu_id, fallback=None):
    """
    Récupère la place d'un menu sans lever d'exception.
    """
    if not menu_id:
        return fallback
    return Menu.objects.filter(pk=menu_id).values_list("place", flat=True).first() or fallback


# --------- Menu : gérer le changement de place proprement ---------

@receiver(pre_save, sender=Menu)
def menu_pre_save(sender, instance: Menu, **kwargs):
    """
    Si le menu change de place, on nettoie l'ancienne clé 'menu:place:<OLD>'.
    On nettoie aussi le rendu HTML existant pour ce menu (par sécurité).
    """
    if not instance.pk:
        return
    # place actuelle en base (avant sauvegarde)
    old_place = Menu.objects.filter(pk=instance.pk).values_list("place", flat=True).first()
    if old_place and old_place != instance.place:
        _invalidate_menu_cache_by_ids(menu_id=instance.pk, place=old_place)


@receiver(post_save, sender=Menu)
@receiver(post_delete, sender=Menu)
def menu_post_change(sender, instance: Menu, **kwargs):
    """
    Après création / update / suppression : invalider les clés courantes.
    """
    _invalidate_menu_cache_by_ids(menu_id=instance.pk, place=instance.place)


# --------- MenuItem : invalider le menu auquel il appartient ---------

@receiver(post_save, sender=MenuItem)
@receiver(post_delete, sender=MenuItem)
def menuitem_post_change(sender, instance: MenuItem, **kwargs):
    """
    Tout changement d'item impacte le rendu et le lookup par place du menu parent.
    """
    menu_id = instance.menu_id
    place = getattr(instance.menu, "place", None) or _safe_get_menu_place(menu_id)
    _invalidate_menu_cache_by_ids(menu_id=menu_id, place=place)


# --------- MenuStyle : invalider tous les menus qui l'utilisent ---------

@receiver(post_save, sender=MenuStyle)
@receiver(post_delete, sender=MenuStyle)
def menustyle_post_change(sender, instance: MenuStyle, **kwargs):
    """
    Le style change : invalider tous les menus liés (HTML + place).
    """
    for m in instance.menus.only("id", "place"):
        _invalidate_menu_cache_by_ids(menu_id=m.id, place=m.place)


# --------- Page : le HTML de menu embarque page.get_absolute_url ---------

def _invalidate_menus_referencing_page(page_id):
    """
    items.html rend {{ item.page.get_absolute_url }} : si l'URL d'une page
    change (slug/chemin) ou si la page est supprimée, le HTML mis en cache des
    menus qui la référencent doit être régénéré. Les signals Menu/MenuItem ne
    couvrent pas ce cas (la page vit dans une autre app).
    """
    if not page_id:
        return
    rows = (
        MenuItem.objects
        .filter(page_id=page_id)
        .values_list("menu_id", "menu__place")
        .distinct()
    )
    for menu_id, place in rows:
        _invalidate_menu_cache_by_ids(menu_id=menu_id, place=place)


@receiver(post_save, sender=Page)
def page_saved_invalidate_menus(sender, instance: Page, **kwargs):
    _invalidate_menus_referencing_page(instance.pk)


@receiver(pre_delete, sender=Page)
def page_deleted_invalidate_menus(sender, instance: Page, **kwargs):
    # pre_delete : la FK MenuItem.page (SET_NULL) est encore renseignée ici,
    # on peut donc retrouver les menus concernés avant qu'elle soit nullifiée.
    _invalidate_menus_referencing_page(instance.pk)
