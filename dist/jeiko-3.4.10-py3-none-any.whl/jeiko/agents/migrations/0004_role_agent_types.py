# jeiko/agents/migrations/0004_role_agent_types.py
"""
Le rôle « Agent fiches et boutique » ne pouvait pas DÉFINIR un type de fiche.

Il savait remplir des fiches et créer des produits, mais pas déclarer le type
« Formule » et ses champs : il fallait passer par l'administration à mi-chemin.
Un agent à qui on demande « fais-moi trois formules » s'arrêtait donc au milieu
du travail, et l'obstacle n'était pas une règle de sécurité — c'était un oubli.

Ce qui est ajouté, et ce qui reste refusé
------------------------------------------
Ajouté : créer et modifier un type de fiche, ses champs, et un type de produit.

Toujours refusé : **toute suppression.** Supprimer un type de fiche emporte ses
champs, ses fiches et leurs valeurs — et `page_template` est en PROTECT, donc
l'échec serait au mieux brutal, au pire partiel. Même règle que pour les pages :
un agent crée et corrige, il n'efface pas.

Les rôles de JEIKO ne sont pas ceux de Django
----------------------------------------------
Une première version de cette migration cherchait un `auth.Group`. JEIKO a son
propre système — `users.Role`, `users.RolePermission`, `users.RoleAssignment` —
et `Group.objects.filter(...)` n'y trouvait rien. La migration s'exécutait,
était enregistrée comme appliquée, **et ne faisait rien**. En silence : le
garde-fou « rôle absent, on ne devine pas » avalait le cas.

C'est le mode d'échec le plus coûteux du dépôt (voir A-12, A-17, A-22) : une
écriture qui réussit et ne produit rien. `0005` rattrape les installations où
la version fautive est déjà passée.
"""

from django.db import migrations

SLUG = "agent-fiches-boutique"

#: app_label → codenames. En clair, pour que la migration se lise sans aller
#: chercher les modèles concernés.
PERMISSIONS = {
    "custom_objects": (
        "add_customobjectmodel", "change_customobjectmodel",
        "add_customobjectfield", "change_customobjectfield",
    ),
    "shop": ("add_producttype", "change_producttype"),
}


def ajouter(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role = Role.objects.filter(slug=SLUG).first()
    if role is None:
        # Le rôle vient de 0003. Son absence signifie une base montée
        # autrement : on ne la devine pas, on ne casse pas la migration.
        return

    for app_label, codenames in PERMISSIONS.items():
        for codename in codenames:
            permission = Permission.objects.filter(
                codename=codename, content_type__app_label=app_label
            ).first()
            if permission:
                RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role = Role.objects.filter(slug=SLUG).first()
    if role is None:
        return

    for app_label, codenames in PERMISSIONS.items():
        RolePermission.objects.filter(
            role=role,
            permission__in=Permission.objects.filter(
                codename__in=codenames, content_type__app_label=app_label
            ),
        ).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0003_role_agent_boutique"),
        ("custom_objects", "0001_initial"),
        ("shop", "0001_initial"),
        ("users", "0001_initial"),
    ]

    operations = [migrations.RunPython(ajouter, retirer)]
