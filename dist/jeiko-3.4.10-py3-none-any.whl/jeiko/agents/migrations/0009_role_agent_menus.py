# jeiko/agents/migrations/0009_role_agent_menus.py
"""
Rôle « Agent menus » — la navigation, et les sous-sites.

Ce qu'il permet
---------------
Créer et modifier des menus, leur arborescence, et **les affecter aux
catégories**. C'est ce dernier point qui compte : `Category.main_menu` et
`Category.footer_menu` font qu'une branche du site — « Électricité »,
« Plomberie » — porte ses propres liens tout en gardant l'apparence commune.
Autrement dit, des sous-sites.

Le rôle porte aussi `change_category`, sans quoi l'affectation serait
impossible : c'est la catégorie qui désigne son menu, pas l'inverse.

Ce qu'il ne permet pas
----------------------
**Le design des menus** (`MenuStyle`) : couleurs, polices, survols. Demandé
explicitement — « pas des designs ». Un style se partage entre menus ; le
modifier depuis une clé de structure changerait l'apparence de menus qu'on ne
visait pas. Il relève du rôle « Agent design ».

**La suppression.** Un menu supprimé emporte ses entrées et laisse sans
navigation toutes les catégories qui le désignaient — un site cassé partout à
la fois, sans qu'aucune page ne paraisse en cause.
"""

from django.db import migrations

SLUG = "agent-menus"
NOM = "Agent menus"

PERMISSIONS = {
    "administration_menu": (
        "view_menu", "add_menu", "change_menu",
        "view_menuitem", "add_menuitem", "change_menuitem",
        # Le style se LIT — pour dupliquer un menu en gardant son apparence —
        # mais ne se modifie pas.
        "view_menustyle",
    ),
    # L'affectation vit sur la catégorie.
    "administration_pages": ("view_category", "change_category"),
}


def creer_le_role(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role, cree = Role.objects.get_or_create(
        slug=SLUG,
        defaults={
            "name": NOM,
            "description": (
                "Permet à un agent de construire les menus et de les affecter "
                "aux catégories, ce qui permet des sous-sites. N'autorise ni "
                "la suppression, ni le design des menus."
            ),
            "is_active": True,
        },
    )
    if not cree:
        return

    for app_label, codenames in PERMISSIONS.items():
        for codename in codenames:
            permission = Permission.objects.filter(
                codename=codename, content_type__app_label=app_label
            ).first()
            if permission:
                RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer_le_role(apps, schema_editor):
    apps.get_model("users", "Role").objects.filter(slug=SLUG).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0008_role_agent_design"),
        ("administration_menu", "0019_menu_show_cart"),
        ("users", "0001_initial"),
    ]

    operations = [migrations.RunPython(creer_le_role, retirer_le_role)]
