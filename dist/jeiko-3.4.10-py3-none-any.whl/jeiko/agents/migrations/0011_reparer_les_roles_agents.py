# jeiko/agents/migrations/0011_reparer_les_roles_agents.py
"""
Les rôles d'agents naissaient VIDES sur toute installation neuve.

Le défaut
---------
Les migrations 0002 à 0010 créent chacune un rôle et lui attachent ses
permissions, en les cherchant ainsi :

    Permission.objects.filter(codename=…, content_type__app_label=…).first()

Sur un site **existant**, ces lignes sont là et tout fonctionne. Sur un site
**neuf**, elles n'existent pas encore : Django crée les `auth.Permission` dans
un signal `post_migrate`, c'est-à-dire **après que toutes les migrations sont
passées**. Le `.first()` rendait donc `None`, le `if permission:` était faux,
et le rôle était enregistré sans une seule permission.

Aucune erreur, aucun avertissement. Le rôle apparaît dans l'administration,
s'assigne à un agent, se lit dans `/qui-suis-je/` — et n'autorise rien. C'est
ce qui s'est vu à la première installation de jeiko.fr : huit rôles affichés,
zéro permission.

Le second défaut, dessous
------------------------
`if not cree: return` — les migrations d'origine ne peuplent le rôle que si
elles viennent de le créer. Un rôle existant mais vide ne serait jamais
réparé, même en rejouant. Cette migration-ci peuple **toujours**, ce qui la
rend rejouable sans risque : `get_or_create` sur chaque lien n'ajoute rien
deux fois.

Pourquoi une migration de plus plutôt que corriger les précédentes
-------------------------------------------------------------------
Django ne rejoue pas une migration déjà appliquée. Corriger 0002-0010
réparerait les installations futures et laisserait toutes les autres cassées —
exactement le piège rencontré avec 0004, et rattrapé par 0005.

Celle-ci force d'abord la création des permissions manquantes, puis peuple.
Elle est donc juste dans les deux cas : site neuf où rien n'existe encore,
site en service dont les rôles sont vides.
"""

from django.db import migrations

#: slug → (app_label, codenames). Le même inventaire que les migrations
#: d'origine, rassemblé pour être appliqué d'un seul tenant.
ROLES = {
    "agent-editeur-pages": {
        "administration_pages": ("view_page", "add_page", "change_page"),
    },
    "agent-fiches-boutique": {
        "custom_objects": (
            "view_customobject", "add_customobject", "change_customobject",
            "view_customobjectvalue", "add_customobjectvalue",
            "change_customobjectvalue",
            "view_customobjectmodel", "add_customobjectmodel",
            "change_customobjectmodel",
            "view_customobjectfield", "add_customobjectfield",
            "change_customobjectfield",
        ),
        "shop": (
            "view_product", "add_product", "change_product",
            "view_producttype", "add_producttype", "change_producttype",
        ),
    },
    "agent-questionnaires": {
        "questionnaires_expert": (
            "view_experttest", "add_experttest", "change_experttest",
            "view_expertprofiletype", "add_expertprofiletype",
            "change_expertprofiletype",
            "view_expertquestion", "add_expertquestion", "change_expertquestion",
            "view_expertanswer", "add_expertanswer", "change_expertanswer",
            "view_expertanswerprofileweight", "add_expertanswerprofileweight",
            "change_expertanswerprofileweight",
            "view_expertprofilecombination", "add_expertprofilecombination",
            "change_expertprofilecombination",
            "view_expertprofilecriterion", "add_expertprofilecriterion",
            "change_expertprofilecriterion",
        ),
    },
    "agent-emails": {
        "emailing": (
            "view_emailtemplate", "add_emailtemplate", "change_emailtemplate",
        ),
    },
    "agent-design": {
        "administration": (
            "view_website", "change_website",
            "view_theme", "add_theme", "change_theme",
            "view_fonts", "change_fonts",
            "view_font", "add_font", "change_font",
        ),
    },
    "agent-menus": {
        "administration_menu": (
            "view_menu", "add_menu", "change_menu",
            "view_menuitem", "add_menuitem", "change_menuitem",
            "view_menustyle",
        ),
        "administration_pages": ("view_category", "change_category"),
    },
    "agent-calendrier": {
        "calendars": (
            "view_appointmenttype", "add_appointmenttype",
            "change_appointmenttype",
            "view_availability", "add_availability", "change_availability",
            "delete_availability",
            "view_slot",
        ),
    },
    "agent-agenda-lecture": {
        "calendars": ("view_appointment",),
    },
}


def peupler(apps, schema_editor):
    """
    Force la création des permissions manquantes, PUIS peuple les rôles.

    Django crée les `auth.Permission` dans un signal `post_migrate`, donc après
    toutes les migrations. Une migration de données qui en cherche pendant un
    `migrate` initial n'en trouve aucune — et échoue en silence, puisqu'elle ne
    fait que sauter ce qu'elle ne trouve pas.

    `create_permissions` est la fonction que Django appelle lui-même dans ce
    signal ; on l'appelle en avance, application par application. Elle est
    idempotente : elle ne recrée pas ce qui existe.

    Le registre RÉEL et non celui de la migration : `create_permissions` attend
    une configuration d'application complète, que le registre historique ne
    fournit pas.
    """
    from django.apps import apps as registre_reel
    from django.contrib.auth.management import create_permissions

    concernees = {
        app_label
        for permissions in ROLES.values()
        for app_label in permissions
    }
    for app_label in sorted(concernees):
        try:
            config = registre_reel.get_app_config(app_label)
        except LookupError:
            continue
        # Idempotent : `create_permissions` ne recrée pas ce qui existe.
        create_permissions(config, verbosity=0)

    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    for slug, par_application in ROLES.items():
        role = Role.objects.filter(slug=slug).first()
        if role is None:
            # Le rôle vient d'une migration précédente. Son absence signifie
            # une base montée autrement : on ne la devine pas.
            continue

        for app_label, codenames in par_application.items():
            for codename in codenames:
                permission = Permission.objects.filter(
                    codename=codename, content_type__app_label=app_label
                ).first()
                if permission is not None:
                    RolePermission.objects.get_or_create(
                        role=role, permission=permission
                    )


def retirer(apps, schema_editor):
    """
    Volontairement vide.

    Annuler cette migration ne doit pas retirer des permissions que les
    migrations d'origine sont censées avoir posées. Ce sont elles qui les
    retirent, en descendant plus bas.
    """


class Migration(migrations.Migration):

    dependencies = [("jeiko_agents", "0010_role_agent_calendrier")]

    operations = [migrations.RunPython(peupler, retirer)]
