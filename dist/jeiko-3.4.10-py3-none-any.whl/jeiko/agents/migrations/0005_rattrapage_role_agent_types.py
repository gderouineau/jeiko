# jeiko/agents/migrations/0005_rattrapage_role_agent_types.py
"""
Rattrape les installations où `0004` est passée sans rien faire.

La première version de `0004` cherchait le rôle parmi les `auth.Group` de
Django. JEIKO a les siens (`users.Role`), et la requête ne trouvait rien : la
migration s'exécutait, Django l'enregistrait comme appliquée, et aucune
permission n'était posée. Sur ateliersderouineau.com, l'agent s'est retrouvé
avec les nouvelles routes et sans le droit de les appeler.

Corriger `0004` suffit pour une base neuve, pas pour une base où elle est déjà
inscrite : Django ne rejoue pas une migration appliquée. D'où celle-ci, qui
refait le même travail — l'opération est idempotente (`get_or_create`), la
rejouer sur une base déjà correcte ne change rien.

Le retour est volontairement vide : annuler cette migration ne doit pas retirer
des permissions que `0004` est censée avoir posées. C'est `0004` qui les
retire, en descendant d'un cran de plus.
"""

from importlib import import_module

from django.db import migrations

# `from .0004_… import` n'est pas du Python : un nom de module ne peut pas
# commencer par un chiffre. On importe donc par son nom, en chaîne — et on
# réutilise la fonction plutôt que d'en recopier une seconde, qui divergerait
# le jour où l'on ajouterait une permission.
ajouter = import_module(
    "jeiko.agents.migrations.0004_role_agent_types"
).ajouter


class Migration(migrations.Migration):

    dependencies = [("jeiko_agents", "0004_role_agent_types")]

    operations = [migrations.RunPython(ajouter, migrations.RunPython.noop)]
