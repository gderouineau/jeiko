# jeiko/agents/migrations/0008_role_agent_design.py
"""
Rôle « Agent design » — l'identité visuelle du site.

Ce qu'il permet
---------------
Lire et modifier `WebSite` : les dix couleurs du thème et les onze rôles de
police, sur les trois appareils. C'est ce que l'exploitant appelle « la strat
au-dessus » : l'identité, pas le contenu.

Pourquoi un rôle à part
-----------------------
Une erreur de contenu abîme une page. **Une erreur d'identité les abîme
toutes en même temps**, et sans qu'aucune page en particulier paraisse en
cause. Ce n'est pas un droit qu'on ajoute par commodité à une clé d'édition :
c'est un mandat distinct, qu'on confie à un agent chargé du design.

Ce qu'il ne permet pas
----------------------
Ni créer ni supprimer un site : `WebSite` est un singleton de configuration,
posé à l'installation. Le supprimer emporterait polices et thème.
"""

from django.db import migrations

SLUG = "agent-design"
NOM = "Agent design"

PERMISSIONS = {
    "administration": (
        "view_website", "change_website",
        "view_theme", "add_theme", "change_theme",
        "view_fonts", "change_fonts",
        "view_font", "add_font", "change_font",
    ),
}


def creer_le_role(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role, cree = Role.objects.get_or_create(
        slug=SLUG,
        defaults={
            "name": NOM,
            "description": (
                "Permet à un agent de régler l'identité visuelle par l'API : "
                "couleurs du thème et polices, sur les trois appareils. "
                "Ne touche à aucun contenu."
            ),
            "is_active": True,
        },
    )
    if not cree:
        return

    for app_label, codenames in PERMISSIONS.items():
        for codename in codenames:
            permission = Permission.objects.filter(
                codename=codename, content_type__app_label=app_label
            ).first()
            if permission:
                RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer_le_role(apps, schema_editor):
    apps.get_model("users", "Role").objects.filter(slug=SLUG).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0007_role_agent_emails"),
        ("administration", "0030_theme_du_site"),
        ("users", "0001_initial"),
    ]

    operations = [migrations.RunPython(creer_le_role, retirer_le_role)]
