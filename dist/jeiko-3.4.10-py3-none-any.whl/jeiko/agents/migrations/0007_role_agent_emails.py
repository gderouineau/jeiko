# jeiko/agents/migrations/0007_role_agent_emails.py
"""
Rôle « Agent e-mails » — habiller les e-mails, pas lire ceux qui sont partis.

Ce qu'il permet
---------------
Créer et modifier les `EmailTemplate` : le sujet, la page qui sert de corps,
l'expéditeur, l'activation. C'est le travail que l'exploitant décrit comme
« chiant à faire à la main, et quand on doit changer un truc il faut tous les
changer ».

Ce qu'il ne permet pas
----------------------
**Lire les journaux d'envoi.** `EmailLog` porte l'adresse de chaque
destinataire et le contexte de rendu de chaque message — donc des données
personnelles, parfois nominatives. La permission est absente ET aucune route
ne l'expose : les deux barrières, comme partout ailleurs dans cette API.

**Supprimer.** Un modèle supprimé, c'est un événement qui repart sur le
gabarit par défaut sans que personne le remarque — jusqu'à ce qu'un client
reçoive un message qui ne ressemble pas au site.

À combiner avec « Agent éditeur de pages » : le corps d'un e-mail EST une
page, et il faut pouvoir la construire.
"""

from django.db import migrations

SLUG = "agent-emails"
NOM = "Agent e-mails"

PERMISSIONS = {
    "emailing": (
        "view_emailtemplate", "add_emailtemplate", "change_emailtemplate",
    ),
}


def creer_le_role(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role, cree = Role.objects.get_or_create(
        slug=SLUG,
        defaults={
            "name": NOM,
            "description": (
                "Permet à un agent d'écrire les e-mails transactionnels par "
                "l'API : sujet, page de corps, expéditeur. N'autorise NI la "
                "suppression, NI l'accès aux journaux d'envoi."
            ),
            "is_active": True,
        },
    )
    if not cree:
        return

    for app_label, codenames in PERMISSIONS.items():
        for codename in codenames:
            permission = Permission.objects.filter(
                codename=codename, content_type__app_label=app_label
            ).first()
            if permission:
                RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer_le_role(apps, schema_editor):
    apps.get_model("users", "Role").objects.filter(slug=SLUG).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0006_role_agent_questionnaires"),
        ("emailing", "0001_initial"),
        ("users", "0001_initial"),
    ]

    operations = [migrations.RunPython(creer_le_role, retirer_le_role)]
