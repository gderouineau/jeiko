"""
Le rôle « Agent fiches et boutique », prêt à assigner.

Pourquoi le livrer plutôt que de le laisser composer
----------------------------------------------------
Comme pour « Agent éditeur de pages » : ce rôle porte une règle, pas une
préférence. Un agent remplit des fiches et fixe des prix ; il **ne supprime
rien** et ne touche pas aux commandes.

Cette dernière limite est la moins évidente et la plus importante. Une commande
est une pièce comptable : la modifier après coup, même de bonne foi, fausse un
historique que l'exploitant devra peut-être présenter. Un agent n'a aucune
raison d'y accéder — et le lui interdire par le rôle vaut mieux que d'y penser
à chaque fois.

Composé à la main sur chaque site, ce rôle serait juste le premier jour et
approximatif au dixième : il suffit de cocher une case de trop dans une liste
qui en compte quarante.

`get_or_create` : un site qui aurait déjà ce rôle le garde tel quel. Une
migration ne doit pas écraser un réglage d'exploitant.
"""

from django.db import migrations

SLUG = "agent-fiches-boutique"
NOM = "Agent fiches et boutique"

#: Voir, créer, modifier. Jamais `delete_`. Et rien sur `order`, `cart`,
#: `orderline` : la comptabilité n'est pas du contenu.
PERMISSIONS = {
    "custom_objects": (
        "view_customobject", "add_customobject", "change_customobject",
        "view_customobjectvalue", "add_customobjectvalue", "change_customobjectvalue",
        # Les MODÈLES de fiche se lisent seulement : ils définissent la
        # structure du site. Un agent les remplit, il ne les redessine pas.
        "view_customobjectmodel", "view_customobjectfield",
    ),
    "shop": (
        "view_product", "add_product", "change_product",
        # Le type de produit se lit : il porte la TVA et la nature (physique,
        # numérique, abonnement), qui sont des décisions commerciales.
        "view_producttype",
    ),
}


def creer_le_role(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role, cree = Role.objects.get_or_create(
        slug=SLUG,
        defaults={
            "name": NOM,
            "description": (
                "Permet à un agent de créer et modifier des fiches (objets "
                "personnalisés) et des produits par l'API : contenu, prix, "
                "stock. N'autorise NI la suppression, NI l'accès aux "
                "commandes."
            ),
            "is_active": True,
        },
    )
    if not cree:
        return

    for app_label, codenames in PERMISSIONS.items():
        for codename in codenames:
            permission = Permission.objects.filter(
                codename=codename, content_type__app_label=app_label
            ).first()
            if permission:
                RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer_le_role(apps, schema_editor):
    apps.get_model("users", "Role").objects.filter(slug=SLUG).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0002_role_agent_editeur"),
        ("custom_objects", "0001_initial"),
        ("shop", "0001_initial"),
    ]

    operations = [migrations.RunPython(creer_le_role, retirer_le_role)]
