# jeiko/agents/migrations/0006_role_agent_questionnaires.py
"""
Rôle « Agent questionnaires » — construire un test, pas lire ses passages.

Pourquoi un rôle à part
-----------------------
Un questionnaire n'est pas du contenu comme un autre : ses passages
(`ExpertTestData`, `Prospect`) contiennent les réponses de visiteurs
identifiables. Fondre ces droits dans « Agent éditeur de pages » aurait donné
à toute clé d'édition un voisinage de données personnelles.

Le rôle ne porte donc QUE la construction : le test, ses profils, ses
questions, ses réponses et leurs poids, ses combinaisons et leurs critères.

Ce qu'il ne porte pas
---------------------
* **Aucune suppression.** Supprimer un test emporte ses questions, ses poids
  et les passages déjà enregistrés — donc des données de visiteurs. Même règle
  que pour les pages.
* **Aucun accès aux passages ni aux prospects.** Ce n'est pas seulement une
  permission absente : aucune route ne les expose. Les deux barrières, comme
  pour la suppression de page.

À combiner avec « Agent éditeur de pages » : les profils pointent vers des
pages de résultat, et il faut pouvoir les créer.
"""

from django.db import migrations

SLUG = "agent-questionnaires"
NOM = "Agent questionnaires"

PERMISSIONS = {
    "questionnaires_expert": (
        "view_experttest", "add_experttest", "change_experttest",
        "view_expertprofiletype", "add_expertprofiletype", "change_expertprofiletype",
        "view_expertquestion", "add_expertquestion", "change_expertquestion",
        "view_expertanswer", "add_expertanswer", "change_expertanswer",
        "view_expertanswerprofileweight", "add_expertanswerprofileweight",
        "change_expertanswerprofileweight",
        "view_expertprofilecombination", "add_expertprofilecombination",
        "change_expertprofilecombination",
        "view_expertprofilecriterion", "add_expertprofilecriterion",
        "change_expertprofilecriterion",
    ),
}


def creer_le_role(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role, cree = Role.objects.get_or_create(
        slug=SLUG,
        defaults={
            "name": NOM,
            "description": (
                "Permet à un agent de construire des questionnaires experts "
                "par l'API : profils, questions, réponses, poids, "
                "combinaisons. N'autorise NI la suppression, NI l'accès aux "
                "passages et aux prospects."
            ),
            "is_active": True,
        },
    )
    if not cree:
        return

    for app_label, codenames in PERMISSIONS.items():
        for codename in codenames:
            permission = Permission.objects.filter(
                codename=codename, content_type__app_label=app_label
            ).first()
            if permission:
                RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer_le_role(apps, schema_editor):
    apps.get_model("users", "Role").objects.filter(slug=SLUG).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0005_rattrapage_role_agent_types"),
        ("questionnaires_expert", "0001_initial"),
        ("users", "0001_initial"),
    ]

    operations = [migrations.RunPython(creer_le_role, retirer_le_role)]
