# jeiko/agents/migrations/0010_role_agent_calendrier.py
"""
Deux rôles pour le calendrier, et c'est délibéré.

« Agent calendrier » — gérer l'offre
-------------------------------------
Types de rendez-vous, disponibilités, créneaux. C'est le travail décrit par
l'exploitant : « plus simple que d'aller sur le site pour ajouter un créneau à
l'intérieur d'un type de rendez-vous ».

La suppression de disponibilité est accordée — l'API la garde elle-même : elle
refuse d'effacer une plage qui porte des rendez-vous, parce que
`Appointment.slot` est en CASCADE et que ce seraient des personnes réelles qui
disparaîtraient de l'agenda.

« Agent agenda (lecture) » — voir qui a réservé
------------------------------------------------
`Appointment` porte le **nom et l'adresse e-mail** du client. Fondre ce droit
dans le rôle précédent donnerait à toute clé de gestion de créneaux un accès à
des données personnelles qu'elle n'a aucune raison de lire.

Deux rôles, donc, qu'on cumule quand c'est voulu — par exemple pour brancher un
assistant qui répond « il vous reste deux rendez-vous jeudi ». Aucune route ne
modifie ni n'annule un rendez-vous : une annulation doit prévenir la personne,
et ce n'est pas le travail de cette API.
"""

from django.db import migrations

ROLES = (
    (
        "agent-calendrier",
        "Agent calendrier",
        (
            "Permet à un agent de gérer l'offre de rendez-vous par l'API : "
            "types, disponibilités, ouverture et capacité des créneaux. "
            "NE DONNE PAS accès aux rendez-vous pris."
        ),
        (
            "view_appointmenttype", "add_appointmenttype", "change_appointmenttype",
            "view_availability", "add_availability", "change_availability",
            "delete_availability",
            "view_slot",
        ),
    ),
    (
        "agent-agenda-lecture",
        "Agent agenda (lecture)",
        (
            "Permet à un agent de LIRE les rendez-vous pris, nom et adresse "
            "du client compris. Aucune modification, aucune annulation. "
            "Rôle à part : ce sont des données personnelles."
        ),
        ("view_appointment",),
    ),
)


def creer_les_roles(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    for slug, nom, description, codenames in ROLES:
        role, cree = Role.objects.get_or_create(
            slug=slug,
            defaults={"name": nom, "description": description, "is_active": True},
        )
        if not cree:
            continue
        for codename in codenames:
            permission = Permission.objects.filter(
                codename=codename, content_type__app_label="calendars"
            ).first()
            if permission:
                RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer_les_roles(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    Role.objects.filter(slug__in=[slug for slug, *_ in ROLES]).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0009_role_agent_menus"),
        ("calendars", "0001_initial"),
        ("users", "0001_initial"),
    ]

    operations = [migrations.RunPython(creer_les_roles, retirer_les_roles)]
