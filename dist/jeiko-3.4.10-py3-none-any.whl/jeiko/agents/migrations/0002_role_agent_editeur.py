"""
Le rôle « Agent éditeur de pages », prêt à assigner.

Pourquoi le livrer plutôt que de le laisser composer
----------------------------------------------------
Ce rôle porte une règle décidée avec l'exploitant : un agent construit et
modifie des pages, il n'en supprime aucune. Écrite ici, elle est appliquée du
premier coup et partout ; laissée à composer à la main sur chaque site, elle
serait exacte le premier jour et approximative au dixième — il suffit de cocher
une case de trop.

C'est la **seconde** barrière contre la suppression de page. La première est
l'absence de route dans `agents/urls_api.py`. Aucune ne suffit seule : une
route peut être ajoutée par distraction, une permission peut être cochée à la
main. Les deux ensemble demandent deux erreurs.

`get_or_create` : un site qui aurait déjà ce rôle le garde tel quel. Une
migration ne doit pas écraser un réglage d'exploitant.
"""

from django.db import migrations

SLUG = "agent-editeur-pages"
NOM = "Agent éditeur de pages"

#: Voir, créer, modifier. Pas `delete_page`, et ce n'est pas un oubli.
PERMISSIONS = ("view_page", "add_page", "change_page")


def creer_le_role(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    RolePermission = apps.get_model("users", "RolePermission")
    Permission = apps.get_model("auth", "Permission")

    role, cree = Role.objects.get_or_create(
        slug=SLUG,
        defaults={
            "name": NOM,
            "description": (
                "Permet à un agent de construire et modifier des pages par "
                "l'API — sections, lignes, blocs, contenus et paramètres. "
                "N'autorise PAS la suppression d'une page."
            ),
            "is_active": True,
        },
    )
    if not cree:
        return

    for codename in PERMISSIONS:
        permission = Permission.objects.filter(
            codename=codename, content_type__app_label="administration_pages"
        ).first()
        if permission:
            RolePermission.objects.get_or_create(role=role, permission=permission)


def retirer_le_role(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    Role.objects.filter(slug=SLUG).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0001_initial"),
        ("users", "0001_initial"),
        ("auth", "0012_alter_user_first_name_max_length"),
    ]

    operations = [migrations.RunPython(creer_le_role, retirer_le_role)]
