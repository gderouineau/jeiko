# jeiko/agents/vues_emails.py
"""
Les e-mails transactionnels — le sujet, le corps, l'expéditeur.

Comment ça marche
-----------------
JEIKO envoie des e-mails à des moments précis : inscription, réinitialisation
de mot de passe, confirmation de commande, rappel de rendez-vous… Chacun de ces
moments est un **événement** du catalogue `emailing.registry` — 67 au total,
qu'on ne choisit pas, ils sont posés par le code qui les déclenche.

Un `EmailTemplate` habille un de ces événements :

* un **sujet**, qui accepte les `[%cle%]` ;
* un **corps**, qui est une **PAGE** marquée `is_mail_template` — donc
  construite avec les mêmes sections, lignes et blocs que le reste du site, par
  les mêmes routes ;
* un expéditeur et une adresse de réponse, facultatifs.

C'est exactement le mécanisme des fiches de la boutique : une page dessinée
une fois, rendue avec les valeurs du moment.

Le point qui compte : SAVOIR quelles clés existent
---------------------------------------------------
Chaque événement fournit ses propres variables — `lien_action` pour une
vérification d'adresse, `commande_numero` pour une confirmation d'achat — plus
les globales du site. Écrire `[%commande_numero%]` dans un e-mail de bienvenue
ne produit rien : la clé n'est pas fournie, et elle reste **affichée en clair**
dans le message reçu.

D'où `GET /emails/evenements/`, qui donne pour chaque événement ses clés et ce
qu'elles contiennent. C'est le contrat, et c'est la première chose à lire.

Ce qui est refusé
-----------------
**Désactiver un e-mail obligatoire.** Certains ne sont pas décoratifs : sans
l'e-mail de réinitialisation, un utilisateur qui perd son mot de passe perd son
compte ; sans la confirmation de commande, le client n'a plus de preuve
d'achat. Le registre les marque, l'administration refuse déjà de les
décocher — l'API fait de même, avec la raison.

**Créer un événement.** Le catalogue vient du code qui déclenche les envois :
inventer un code produirait un modèle que rien n'utilise jamais.

**Les journaux d'envoi** (`EmailLog`) : ils contiennent les adresses des
destinataires et le contexte de rendu, c'est-à-dire des données personnelles.
Aucune route ne les expose.
"""

from django.db import transaction
from django.shortcuts import get_object_or_404

from jeiko.administration_pages.models import Page
from jeiko.emailing import registry
from jeiko.emailing.models import EmailTemplate, extract_tags

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR = "emailing.view_emailtemplate"
AJOUTER = "emailing.add_emailtemplate"
MODIFIER = "emailing.change_emailtemplate"

CLES_MODELE = {
    "sujet", "page", "actif", "expediteur", "adresse_de_reponse",
}


def _modele_en_dict(modele):
    return {
        "id": modele.id,
        "evenement": modele.code,
        "sujet": modele.subject,
        "page": modele.page_id,
        "actif": modele.active,
        "expediteur": modele.from_email or "",
        "adresse_de_reponse": modele.reply_to_email or "",
        "obligatoire": registry.is_mandatory(modele.code),
    }


def _evenement_en_dict(code, evenement):
    return {
        "code": code,
        "libelle": evenement.get("label", ""),
        "categorie": evenement.get("category", ""),
        "destinataire": evenement.get("audience", ""),
        "description": evenement.get("description", ""),
        "obligatoire": registry.is_mandatory(code),
        "raison_obligatoire": registry.mandatory_reason(code),
        # Les clés utilisables, avec ce qu'elles contiennent. Sans elles, un
        # agent écrirait des jetons au jugé — et un jeton inconnu reste
        # AFFICHÉ EN CLAIR dans le message reçu par le destinataire.
        "cles": {
            variable["key"]: variable["description"]
            for variable in registry.available_variables(code)
        },
    }


def _verifier_les_cles_du_texte(code, texte, ou):
    """
    Refuse un `[%jeton%]` que l'événement ne fournit pas.

    Un jeton inconnu n'est pas remplacé : il part tel quel dans l'e-mail, sous
    les yeux du destinataire. C'est le pire endroit possible pour une panne
    muette — on ne relit pas les e-mails transactionnels après coup, et le
    destinataire, lui, ne dira rien.
    """
    if not texte:
        return
    autorisees = registry.variable_keys(code)
    inconnues = sorted(extract_tags(texte) - autorisees)
    if inconnues:
        raise CorpsInvalide(
            f"{ou} : clé(s) que « {code} » ne fournit pas — "
            f"{', '.join('[%' + c + '%]' for c in inconnues)}. "
            f"Elles resteraient affichées en clair dans l'e-mail. "
            f"Disponibles : {', '.join(sorted(autorisees))}."
        )


def _page_de_corps(identifiant):
    """
    La page qui sert de corps, marquée gabarit d'e-mail au passage.

    `EmailTemplate.page` attend une page `is_mail_template`. Marquer nous-mêmes
    évite un aller-retour dont le seul effet serait de rendre cet appel
    possible — même raisonnement que pour les gabarits de fiches.
    """
    if identifiant in (None, "", 0):
        return None

    page = Page.objects.filter(pk=identifiant).first()
    if page is None:
        raise CorpsInvalide(f"Aucune page nº {identifiant}.")

    if not page.is_mail_template:
        page.is_mail_template = True
        page.save(update_fields=["is_mail_template"])
    return page


# --------------------------------------------------------------------------- #
#  Le catalogue
# --------------------------------------------------------------------------- #
class ListeDesEvenements(VueAgent):
    """
    Les 67 événements, avec leurs clés. À LIRE AVANT d'écrire un e-mail.

    C'est le pendant de `/modeles/` pour la boutique : le contrat que le corps
    et le sujet doivent respecter.
    """

    permission_requise = VOIR

    def get(self, request):
        categorie = request.GET.get("categorie")
        evenements = [
            _evenement_en_dict(code, evenement)
            for code, evenement in registry.EMAIL_EVENTS.items()
            if not categorie or evenement.get("category") == categorie
        ]
        return ok({
            "evenements": evenements,
            "categories": registry.CATEGORY_LABELS,
        })


# --------------------------------------------------------------------------- #
#  Les modèles
# --------------------------------------------------------------------------- #
class ListeDesEmails(VueAgent):
    permission_requise = VOIR

    def get(self, request):
        modeles = EmailTemplate.objects.order_by("code")
        return ok({"emails": [_modele_en_dict(m) for m in modeles]})


class CreationEmail(VueAgent):
    permission_requise = AJOUTER

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)
        inconnues = sorted(set(corps) - CLES_MODELE - {"evenement"})
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Acceptées : evenement, {', '.join(sorted(CLES_MODELE))}."
            )

        code = str(corps.get("evenement") or "").strip()
        if code not in registry.EMAIL_EVENTS:
            raise CorpsInvalide(
                f"Événement « {code or 'absent'} » inconnu. Le catalogue vient "
                f"du code qui déclenche les envois : voir /emails/evenements/."
            )
        if EmailTemplate.objects.filter(code=code).exists():
            raise CorpsInvalide(
                f"Un e-mail existe déjà pour « {code} » — un événement n'en a "
                f"qu'un. Le modifier plutôt : PATCH /emails/<id>/."
            )

        sujet = str(corps.get("sujet") or "").strip()
        if not sujet:
            raise CorpsInvalide("« sujet » est obligatoire.")
        _verifier_les_cles_du_texte(code, sujet, "Sujet")

        modele = EmailTemplate.objects.create(
            code=code,
            subject=sujet[:255],
            page=_page_de_corps(corps.get("page")),
            # Inactif à la création, comme une page ou un questionnaire : un
            # e-mail dont le corps n'est pas encore écrit partirait vide.
            active=False,
            from_email=str(corps.get("expediteur") or "")[:255],
            reply_to_email=str(corps.get("adresse_de_reponse") or "")[:255],
        )
        return ok({"email": _modele_en_dict(modele)}, statut=201)


class DetailEmail(VueAgent):
    permission_requise = VOIR

    def get(self, request, email_id):
        modele = get_object_or_404(EmailTemplate, pk=email_id)
        document = _modele_en_dict(modele)
        document["cles_disponibles"] = _evenement_en_dict(
            modele.code, registry.get_event(modele.code) or {}
        )["cles"]
        return ok({"email": document})

    @transaction.atomic
    def patch(self, request, email_id):
        if not request.user.has_perm(MODIFIER):
            return erreur("Modification d'e-mail non autorisée.", statut=403)

        modele = get_object_or_404(EmailTemplate, pk=email_id)
        corps = self.corps(request)
        inconnues = sorted(set(corps) - CLES_MODELE)
        if inconnues:
            raise CorpsInvalide(
                f"Clé(s) inconnue(s) : {', '.join(inconnues)}. "
                f"Acceptées : {', '.join(sorted(CLES_MODELE))}. "
                f"« evenement » ne se change pas : ce serait un autre e-mail."
            )

        modifies = []
        if "sujet" in corps:
            sujet = str(corps["sujet"]).strip()
            _verifier_les_cles_du_texte(modele.code, sujet, "Sujet")
            modele.subject = sujet[:255]
            modifies.append("subject")

        if "page" in corps:
            modele.page = _page_de_corps(corps["page"])
            modifies.append("page")

        if "actif" in corps:
            actif = bool(corps["actif"])
            if not actif and registry.is_mandatory(modele.code):
                raise CorpsInvalide(
                    f"« {modele.code} » ne peut pas être désactivé. "
                    f"{registry.mandatory_reason(modele.code)}"
                )
            modele.active = actif
            modifies.append("active")

        for cle, champ in (("expediteur", "from_email"),
                           ("adresse_de_reponse", "reply_to_email")):
            if cle in corps:
                setattr(modele, champ, str(corps[cle] or "")[:255])
                modifies.append(champ)

        if modifies:
            modele.save(update_fields=modifies)
        return ok({"email": _modele_en_dict(modele), "modifie": modifies})
