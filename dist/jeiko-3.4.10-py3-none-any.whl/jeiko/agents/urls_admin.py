from django.urls import path

from .vues_admin import (
    BasculeActivation, CreationAgent, DetailAgent, ListeDesAgents,
    ModificationAgent, ReinitialisationDuJeton,
)

app_name = "jeiko_agents_admin"

urlpatterns = [
    path("", ListeDesAgents.as_view(), name="liste"),
    path("nouveau/", CreationAgent.as_view(), name="creer"),
    path("<int:pk>/", DetailAgent.as_view(), name="detail"),
    path("<int:pk>/modifier/", ModificationAgent.as_view(), name="modifier"),
    # POST : les deux ont un effet immédiat sur l'accès en cours.
    path("<int:pk>/jeton/", ReinitialisationDuJeton.as_view(), name="reinitialiser_jeton"),
    path("<int:pk>/activation/", BasculeActivation.as_view(), name="activation"),
]
