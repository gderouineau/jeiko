# jeiko/agents/tests_emails.py
"""
Écrire les e-mails transactionnels par l'API, sans pouvoir casser l'essentiel.

Le risque propre aux e-mails
-----------------------------
Une page ratée se corrige : on la regarde, on voit le défaut. **Un e-mail parti
ne revient pas.** Personne ne relit un message transactionnel après coup, et le
destinataire, lui, ne dira rien. Les contrôles portent donc sur ce qui se
découvre trop tard :

* **un jeton que l'événement ne fournit pas** reste affiché en clair dans le
  message reçu — « Bonjour [%prenom%] » chez le client ;
* **désactiver un e-mail obligatoire** prive l'utilisateur de son compte (plus
  de réinitialisation de mot de passe) ou le client de sa preuve d'achat ;
* **les journaux d'envoi** portent les adresses des destinataires ; aucune
  route ne doit y mener.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Page
from jeiko.emailing import registry
from jeiko.emailing.models import EmailTemplate

from .tests import SocleMixin, donner_le_role

RACINE = "/api/agent/v1"
EVENEMENTS = f"{RACINE}/emails/evenements/"
CREER = f"{RACINE}/emails/creer/"


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class SocleEmail(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user,
            "view_emailtemplate", "add_emailtemplate", "change_emailtemplate",
            app="emailing", nom="Rôle de test e-mails",
        )
        self.page = Page.objects.create(title="Corps", url_tag="corps-mail")

    def _patch(self, chemin, corps):
        return self.client.patch(
            chemin, data=json.dumps(corps), content_type="application/json",
            **self.entetes(self.jeton),
        )


class CatalogueTests(SocleEmail):
    def test_le_catalogue_donne_les_cles_de_chaque_evenement(self):
        """
        C'est le contrat. Sans lui, un agent écrit des jetons au jugé.
        """
        lu = self.client.get(EVENEMENTS, **self.entetes(self.jeton)).json()
        self.assertEqual(len(lu["evenements"]), len(registry.EMAIL_EVENTS))

        par_code = {e["code"]: e for e in lu["evenements"]}
        verification = par_code["account_email_verify"]
        self.assertIn("lien_action", verification["cles"])
        self.assertTrue(
            verification["cles"]["lien_action"],
            "Une clé sans description n'apprend rien de ce qu'elle contient.",
        )

    def test_les_evenements_obligatoires_disent_pourquoi(self):
        lu = self.client.get(EVENEMENTS, **self.entetes(self.jeton)).json()
        obligatoires = [e for e in lu["evenements"] if e["obligatoire"]]
        self.assertTrue(obligatoires)
        for evenement in obligatoires:
            with self.subTest(code=evenement["code"]):
                self.assertTrue(
                    evenement["raison_obligatoire"],
                    "Un verrou sans raison ressemble à une limitation arbitraire.",
                )


class EcritureTests(SocleEmail):
    """
    Le flux réel est la MODIFICATION, pas la création.

    Une migration sème un `EmailTemplate` pour chaque événement du catalogue :
    un site neuf a déjà ses 67 e-mails, avec leur sujet par défaut. Le travail
    d'un agent consiste donc à les habiller — sujet, corps, expéditeur — et la
    création ne sert qu'aux événements ajoutés après coup.
    """

    def test_un_email_recoit_son_corps_et_reste_maitre_de_son_activation(self):
        modele = EmailTemplate.objects.get(code="account_welcome")
        reponse = self._patch(f"{RACINE}/emails/{modele.id}/", {
            "sujet": "Bienvenue sur [%site_nom%]",
            "page": self.page.id,
        })
        self.assertEqual(reponse.status_code, 200)

        modele.refresh_from_db()
        self.assertEqual(modele.page, self.page)
        self.assertEqual(modele.subject, "Bienvenue sur [%site_nom%]")

    def test_la_page_de_corps_est_marquee_gabarit_de_mail(self):
        """
        `EmailTemplate.page` attend une page `is_mail_template`. Laisser ce
        marquage à l'appelant produirait un aller-retour dont le seul effet
        serait de rendre cet appel possible.
        """
        self.assertFalse(self.page.is_mail_template)
        modele = EmailTemplate.objects.get(code="account_welcome")
        self._patch(f"{RACINE}/emails/{modele.id}/", {"page": self.page.id})
        self.page.refresh_from_db()
        self.assertTrue(self.page.is_mail_template)

    def test_un_evenement_inconnu_est_refuse(self):
        reponse = self.json_post(CREER, {
            "evenement": "mon_evenement", "sujet": "S",
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("/emails/evenements/", reponse.json()["erreur"])

    def test_un_second_email_pour_le_meme_evenement_est_refuse(self):
        reponse = self.json_post(CREER, {"evenement": "account_welcome",
                                         "sujet": "B"}, self.jeton)
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("existe déjà", reponse.json()["erreur"])


class JetonsInconnusTests(SocleEmail):
    def test_un_jeton_que_l_evenement_ne_fournit_pas_est_refuse(self):
        """
        Il ne serait pas remplacé : il partirait tel quel chez le destinataire.
        """
        modele = EmailTemplate.objects.get(code="account_welcome")
        avant = modele.subject
        reponse = self._patch(f"{RACINE}/emails/{modele.id}/", {
            "sujet": "Votre commande [%commande_numero%]"
        })
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("commande_numero", reponse.json()["erreur"])

        modele.refresh_from_db()
        self.assertEqual(modele.subject, avant, "Rien ne doit être écrit.")

    def test_le_message_liste_les_cles_disponibles(self):
        modele = EmailTemplate.objects.get(code="account_welcome")
        reponse = self._patch(f"{RACINE}/emails/{modele.id}/",
                              {"sujet": "[%inexistant%]"})
        self.assertIn("Disponibles", reponse.json()["erreur"])

    def test_les_jetons_de_l_evenement_passent(self):
        modele = EmailTemplate.objects.get(code="account_email_verify")
        reponse = self._patch(f"{RACINE}/emails/{modele.id}/", {
            "sujet": "Confirmez votre adresse — [%expiration%]"
        })
        self.assertEqual(reponse.status_code, 200)


class EmailsObligatoiresTests(SocleEmail):
    def test_un_email_obligatoire_ne_se_desactive_pas(self):
        modele = EmailTemplate.objects.get(code="password_reset_request")
        EmailTemplate.objects.filter(pk=modele.pk).update(active=True)
        modele.refresh_from_db()
        reponse = self._patch(f"{RACINE}/emails/{modele.id}/", {"actif": False})

        self.assertEqual(reponse.status_code, 400)
        self.assertIn("compte", reponse.json()["erreur"])
        modele.refresh_from_db()
        self.assertTrue(
            modele.active,
            "Sans cet e-mail, un utilisateur qui perd son mot de passe perd "
            "son compte.",
        )

    def test_un_email_ordinaire_se_desactive(self):
        modele = EmailTemplate.objects.get(code="account_welcome")
        self.assertEqual(
            self._patch(f"{RACINE}/emails/{modele.id}/", {"actif": False}).status_code,
            200,
        )

    def test_l_evenement_ne_se_change_pas(self):
        """Changer le code ferait de ce modèle un AUTRE e-mail."""
        modele = EmailTemplate.objects.get(code="account_welcome")
        reponse = self._patch(f"{RACINE}/emails/{modele.id}/",
                              {"evenement": "order_confirmation"})
        self.assertEqual(reponse.status_code, 400)


class DonneesPersonnellesTests(SocleEmail):
    def test_aucune_route_ne_mene_aux_journaux_d_envoi(self):
        """
        `EmailLog` porte l'adresse de chaque destinataire et le contexte de
        rendu de chaque message.
        """
        from jeiko.agents.urls_api import urlpatterns

        chemins = " ".join(str(m.pattern) for m in urlpatterns)
        for interdit in ("journal", "log", "envoi", "destinataire"):
            with self.subTest(mot=interdit):
                self.assertNotIn(interdit, chemins)
