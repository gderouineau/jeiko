# jeiko/agents/tests_types_de_fiches.py
"""
L'API doit pouvoir DÉFINIR un type de fiche, pas seulement le remplir.

Le manque
---------
Jusqu'ici un agent savait créer une fiche « Formule Essentiel », à condition
que quelqu'un ait déclaré le type « Formule » et ses champs depuis
l'administration. Demander « fais-moi trois formules » l'arrêtait donc au
milieu du travail — et l'obstacle n'était pas une règle de sécurité, c'était un
oubli. Ces routes le comblent.

Ce que les tests gardent
------------------------
**Les codes de champ ne se renomment pas.** Un code est écrit dans le gabarit
sous la forme `[%code%]` et dans chaque fiche remplie. Le renommer casserait
les deux en silence : le jeton cesserait d'être reconnu et resterait affiché en
clair sur la page publique. Le PATCH ajoute, il ne rebaptise pas.

**Rien n'est écrit avant que tout soit valide.** Un type à moitié déclaré,
refusé sur son quatrième champ, serait plus pénible à réparer qu'un refus net.

**La suppression reste fermée**, comme pour les pages.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Page
from jeiko.custom_objects.models import CustomObjectModel
from jeiko.shop.models import ProductType

from .tests import SocleMixin, donner_le_role

MODELES = "/api/agent/v1/modeles/"
CREER_MODELE = "/api/agent/v1/modeles/creer/"
CREER_TYPE = "/api/agent/v1/types-de-produit/creer/"


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class CreationDeTypeDeFicheTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user,
            "view_customobject", "add_customobjectmodel",
            "change_customobjectmodel", "add_customobjectfield",
            app="custom_objects", nom="Agent types de fiches",
        )
        self.gabarit = Page.objects.create(
            title="Gabarit formule", url_tag="gabarit-formule"
        )

    def _creer(self, **surcharges):
        corps = {
            "nom": "Formule",
            "slug": "formule",
            "gabarit_de_page": self.gabarit.id,
            "est_un_produit": True,
            "champs": [
                {"code": "accroche", "libelle": "Accroche", "type": "text",
                 "obligatoire": True},
                {"code": "detail", "libelle": "Détail", "type": "rich_text"},
            ],
        }
        corps.update(surcharges)
        return self.json_post(CREER_MODELE, corps, self.jeton)

    def test_un_type_se_cree_avec_ses_champs(self):
        reponse = self._creer()
        self.assertEqual(reponse.status_code, 201)

        modele = CustomObjectModel.objects.get(slug="formule")
        self.assertTrue(modele.is_product)
        self.assertEqual(
            list(modele.fields.order_by("position").values_list("code", flat=True)),
            ["accroche", "detail"],
        )

    def test_la_page_gabarit_est_marquee_d_office(self):
        """
        `page_template` n'accepte que des pages marquées gabarit.

        Laisser ce marquage à l'appelant produirait une erreur de validation
        opaque, et un aller-retour dont le seul effet serait de rendre cet
        appel possible.
        """
        self.assertFalse(self.gabarit.is_custom_object_template)
        self._creer()
        self.gabarit.refresh_from_db()
        self.assertTrue(self.gabarit.is_custom_object_template)

    def test_un_slug_deja_pris_est_refuse(self):
        self._creer()
        reponse = self._creer(nom="Autre formule")
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("déjà pris", reponse.json()["erreur"])

    def test_un_type_de_champ_inconnu_est_refuse_avant_toute_ecriture(self):
        reponse = self._creer(champs=[
            {"code": "bon", "libelle": "Bon", "type": "text"},
            {"code": "mauvais", "libelle": "Mauvais", "type": "couleur"},
        ])
        self.assertEqual(reponse.status_code, 400)
        self.assertFalse(
            CustomObjectModel.objects.filter(slug="formule").exists(),
            "Le type a été créé malgré un champ refusé : il faut tout valider "
            "avant d'écrire quoi que ce soit.",
        )

    def test_deux_champs_de_meme_code_sont_refuses(self):
        reponse = self._creer(champs=[
            {"code": "prix", "libelle": "Prix", "type": "text"},
            {"code": "prix", "libelle": "Prix barré", "type": "text"},
        ])
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("deux fois", reponse.json()["erreur"])

    def test_un_champ_s_ajoute_mais_ne_se_renomme_pas(self):
        self._creer()
        modele = CustomObjectModel.objects.get(slug="formule")

        ajout = self.client.patch(
            f"{MODELES}{modele.id}/",
            data=json.dumps({"champs": [
                {"code": "duree", "libelle": "Durée", "type": "text"}
            ]}),
            content_type="application/json",
            **self.entetes(self.jeton),
        )
        self.assertEqual(ajout.status_code, 200)
        self.assertIn("duree", modele.fields.values_list("code", flat=True))

        rebaptise = self.client.patch(
            f"{MODELES}{modele.id}/",
            data=json.dumps({"champs": [
                {"code": "accroche", "libelle": "Autre libellé", "type": "text"}
            ]}),
            content_type="application/json",
            **self.entetes(self.jeton),
        )
        self.assertEqual(rebaptise.status_code, 400)
        self.assertIn("existe déjà", rebaptise.json()["erreur"])

    def test_sans_permission_rien_ne_se_cree(self):
        autre, jeton = self.creer(nom="Sans droits")
        reponse = self.json_post(CREER_MODELE, {"nom": "X"}, jeton)
        self.assertEqual(reponse.status_code, 403)
        self.assertFalse(CustomObjectModel.objects.exists())


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class CreationDeTypeDeProduitTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_producttype", "add_producttype",
            app="shop", nom="Agent types de produit",
        )
        donner_le_role(
            self.agent.user, "view_customobject",
            app="custom_objects", nom="Agent lecture fiches",
        )
        gabarit = Page.objects.create(
            title="Gabarit", url_tag="gabarit-t", is_custom_object_template=True
        )
        self.modele = CustomObjectModel.objects.create(
            name="Formule", slug="formule", page_template=gabarit, is_product=True
        )

    def test_un_type_de_produit_se_relie_a_son_type_de_fiche(self):
        reponse = self.json_post(CREER_TYPE, {
            "nom": "Abonnement", "code": "abonnement",
            "nature": "service", "modele": "formule",
        }, self.jeton)
        self.assertEqual(reponse.status_code, 201)

        type_produit = ProductType.objects.get(code="abonnement")
        self.assertEqual(type_produit.content_model, self.modele)
        self.assertFalse(
            type_produit.is_physical,
            "Un service marqué physique fausserait la livraison et la TVA.",
        )

    def test_une_nature_inconnue_est_refusee(self):
        reponse = self.json_post(CREER_TYPE, {
            "nom": "X", "code": "x", "nature": "magique",
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("nature", reponse.json()["erreur"])

    def test_un_type_de_fiche_inexistant_est_refuse(self):
        reponse = self.json_post(CREER_TYPE, {
            "nom": "X", "code": "x", "modele": "inexistant",
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)
        self.assertFalse(ProductType.objects.filter(code="x").exists())


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class BlocRessourceCibleTests(SocleMixin, TestCase):
    """
    Un bloc ressource doit pouvoir dire QUOI lister, pas seulement « des produits ».

    Sans cela, une page de présentation ne pouvait pas lister les trois
    formules et renvoyer vers chacune : c'est pourtant tout l'intérêt du bloc —
    aucun lien écrit à la main, et une formule ajoutée demain apparaît toute
    seule.

    La cible se désigne par CODE (type de produit) ou par SLUG (type de fiche),
    jamais par identifiant numérique : un agent qui a lu /types-de-produit/ et
    /modeles/ connaît ces valeurs, et elles restent lisibles dans un document
    JSON qu'un humain relira.
    """

    def setUp(self):
        from jeiko.administration_pages.models import Bloc, Line, Section

        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent pages",
        )
        gabarit = Page.objects.create(
            title="Gabarit", url_tag="gab-res", is_custom_object_template=True
        )
        self.modele = CustomObjectModel.objects.create(
            name="Formule", slug="formule", page_template=gabarit, is_product=True
        )
        self.type_produit = ProductType.objects.create(
            name="Abonnement", code="abonnement", kind="service",
            content_model=self.modele, is_physical=False,
        )

        page = Page.objects.create(title="Offres", url_tag="offres")
        section = Section.objects.create(page=page, position=0)
        line = Line.objects.create(
            section=section, position=0, columns_type="12", columns_number=1
        )
        self.bloc = Bloc.objects.create(
            line=line, position=1, position_in_column=0
        )

    def _poser(self, config):
        return self.client.put(
            f"/api/agent/v1/blocs/{self.bloc.id}/contenu/",
            data=json.dumps({"type": "DYN_RESOURCE_GRID", "dyn_resource_grid": config}),
            content_type="application/json",
            **self.entetes(self.jeton),
        )

    def test_la_grille_cible_un_type_de_produit_par_son_code(self):
        reponse = self._poser({
            "source": "PRODUCT", "type_de_produit": "abonnement",
            "colonnes_ordinateur": 3, "colonnes_telephone": 1,
            "libelle_bouton": "En savoir plus",
        })
        self.assertEqual(reponse.status_code, 200)

        self.bloc.refresh_from_db()
        config = self.bloc.content.content_resource_config
        self.assertEqual(config.product_type, self.type_produit)
        self.assertEqual(config.columns_phone, 1)

    def test_la_relecture_rend_le_code_et_non_l_objet(self):
        """
        Ce que l'API relit doit pouvoir être renvoyé tel quel.

        Rendre l'objet — ou son identifiant — obligerait l'appelant à traduire
        avant de réécrire, et une relecture non renvoyable est un piège.
        """
        self._poser({"source": "PRODUCT", "type_de_produit": "abonnement"})
        lu = self.client.get(
            f"/api/agent/v1/blocs/{self.bloc.id}/", **self.entetes(self.jeton)
        ).json()
        self.assertEqual(
            lu["bloc"]["contenu"]["dyn_resource_grid"]["type_de_produit"],
            "abonnement",
        )

    def test_la_grille_cible_un_type_de_fiche_par_son_slug(self):
        self._poser({"source": "CUSTOM_OBJECT", "modele_de_fiche": "formule"})
        self.bloc.refresh_from_db()
        self.assertEqual(
            self.bloc.content.content_resource_config.custom_object_model,
            self.modele,
        )

    def test_une_cible_inconnue_est_refusee_en_disant_ou_chercher(self):
        reponse = self._poser({"source": "PRODUCT", "type_de_produit": "inexistant"})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("/types-de-produit/", reponse.json()["erreur"])


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class ExpeditionDuTypeDeProduitTests(SocleMixin, TestCase):
    """
    Un type « service » ne doit pas exiger d'expédition.

    Le défaut, trouvé en vérifiant une publication
    -----------------------------------------------
    `CreationTypeDeProduit` posait `kind` et `is_physical`, mais **pas**
    `requires_shipping` — qui vaut `True` par défaut. Un type créé « service »
    se retrouvait donc à exiger une expédition.

    Or c'est ce champ, et lui seul, que consultent le panier, le JSON-LD et le
    décrément de stock à la commande (voir `Product.suit_le_stock`). Le type
    « abonnement » d'ateliersderouineau, créé par l'API, était donc **traité
    comme un produit qui s'épuise** : `OutOfStock` chez Google, et panier qui
    refuse.

    Autrement dit : le défaut S-18 qu'on venait de corriger dans le produit,
    réintroduit par la porte d'à côté — le point d'entrée qui crée les types.
    Trois champs disent la même chose, et n'en renseigner que deux suffit à
    les faire diverger.

    D'où aussi `PATCH /types-de-produit/<id>/` : sans lui, un type mal créé
    restait faux pour toujours — le code est unique, la création ne se rejoue
    pas.
    """

    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_producttype", "add_producttype",
            "change_producttype",
            app="shop", nom="Agent types de produit — expédition",
        )

    def _creer(self, **surcharges):
        corps = {"nom": "Abonnement", "code": "abo", "nature": "service"}
        corps.update(surcharges)
        return self.json_post(CREER_TYPE, corps, self.jeton)

    def test_un_service_n_exige_pas_d_expedition(self):
        self._creer()
        type_produit = ProductType.objects.get(code="abo")
        self.assertFalse(
            type_produit.requires_shipping,
            "Un service marqué expédiable consomme du stock : il devient "
            "« épuisé » et le panier le refuse.",
        )

    def test_un_produit_physique_l_exige(self):
        self._creer(code="colis", nature="physical")
        self.assertTrue(ProductType.objects.get(code="colis").requires_shipping)

    def test_l_expedition_se_force_a_la_creation(self):
        """
        Un « service » qui expédie un support imprimé existe ; l'inverse — un
        bien numérique livré par colis — non. On peut donc forcer.
        """
        self._creer(code="atelier", nature="service", expedition=True)
        self.assertTrue(ProductType.objects.get(code="atelier").requires_shipping)

    def test_un_type_mal_cree_se_corrige(self):
        type_produit = ProductType.objects.create(
            name="Abonnement", code="ancien", kind="service",
            is_physical=False, requires_shipping=True,
        )
        reponse = self.client.patch(
            f"/api/agent/v1/types-de-produit/{type_produit.id}/",
            data=json.dumps({"expedition": False}),
            content_type="application/json", **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 200)
        type_produit.refresh_from_db()
        self.assertFalse(type_produit.requires_shipping)

    def test_corriger_la_nature_entraine_l_expedition(self):
        """
        Sans cela, corriger la nature laisserait le produit invendable pour la
        raison qu'on croyait avoir réglée.
        """
        type_produit = ProductType.objects.create(
            name="X", code="x-nature", kind="physical",
            is_physical=True, requires_shipping=True,
        )
        self.client.patch(
            f"/api/agent/v1/types-de-produit/{type_produit.id}/",
            data=json.dumps({"nature": "service"}),
            content_type="application/json", **self.entetes(self.jeton),
        )
        type_produit.refresh_from_db()
        self.assertFalse(type_produit.requires_shipping)

    def test_le_code_ne_se_modifie_pas(self):
        """Il est dans l'URL de chaque page produit du type."""
        type_produit = ProductType.objects.create(
            name="X", code="x-code", kind="service", requires_shipping=False
        )
        reponse = self.client.patch(
            f"/api/agent/v1/types-de-produit/{type_produit.id}/",
            data=json.dumps({"code": "autre"}),
            content_type="application/json", **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 400)

    def test_l_expedition_est_visible_en_lecture(self):
        """
        La taire l'a rendue invisible : le type disait « service » et
        personne ne pouvait voir qu'il exigeait une expédition.
        """
        self._creer()
        lu = self.client.get(
            "/api/agent/v1/types-de-produit/", **self.entetes(self.jeton)
        ).json()
        abo = [t for t in lu["types"] if t["code"] == "abo"][0]
        self.assertIn("expedition", abo)
        self.assertFalse(abo["expedition"])
