# jeiko/agents/tests_roles_peuples.py
"""
Les rôles d'agents doivent porter des permissions — sur une base NEUVE aussi.

Ce qui s'est passé
------------------
Première installation de jeiko.fr : la clé d'agent portait ses huit rôles, et
`/qui-suis-je/` répondait **zéro permission**. Le rôle existait, s'affichait
dans l'administration, s'assignait — et n'autorisait rien.

La cause tient à l'ordre dans lequel Django travaille. Les migrations 0002 à
0010 attachent leurs permissions ainsi :

    Permission.objects.filter(codename=…, content_type__app_label=…).first()

Or Django crée les `auth.Permission` dans un signal `post_migrate`, donc
**après que toutes les migrations sont passées**. Sur un site en service elles
sont déjà là et tout fonctionne ; sur un site neuf, le `.first()` rend `None`,
le `if permission:` est faux, et le rôle est enregistré vide.

Aucune erreur. Le défaut ne se voyait que sur une installation neuve — c'est-à-
dire jamais en développement, où la base a déjà migré une fois.

Pourquoi ce test est écrit ainsi
---------------------------------
La base de test est construite en rejouant TOUTES les migrations depuis zéro :
c'est exactement le cas qui échouait. Vérifier que les rôles sont peuplés ici,
c'est vérifier ce qu'obtient un client le jour de son installation.

Le test compte les permissions plutôt que de les énumérer : la liste bougera,
le fait qu'un rôle sans permission n'autorise rien ne bougera pas.
"""

from django.test import TestCase

from jeiko.users.models import Role, RolePermission

#: Le minimum attendu par rôle. Des seuils, pas des égalités : ajouter une
#: permission à un rôle ne doit pas faire tomber un test qui garde autre chose.
MINIMUM = {
    "agent-editeur-pages": 3,
    "agent-fiches-boutique": 10,
    "agent-questionnaires": 15,
    "agent-emails": 3,
    "agent-design": 8,
    "agent-menus": 6,
    "agent-calendrier": 6,
    "agent-agenda-lecture": 1,
}


class RolesPeuplesTests(TestCase):
    def test_chaque_role_livre_porte_ses_permissions(self):
        vides = []
        for slug, attendu in MINIMUM.items():
            role = Role.objects.filter(slug=slug).first()
            if role is None:
                vides.append(f"{slug} : rôle absent")
                continue
            combien = RolePermission.objects.filter(role=role).count()
            if combien < attendu:
                vides.append(f"{slug} : {combien} permission(s), {attendu} attendues")

        self.assertEqual(
            vides, [],
            "Rôle(s) sans permissions sur une base neuve. Un rôle vide "
            "s'affiche, s'assigne, et n'autorise rien — c'est ce qu'a obtenu "
            "la première installation de jeiko.fr.",
        )

    def test_un_role_vide_n_autorise_rien(self):
        """
        Le rappel de ce qui est en jeu : ce n'est pas une liste incomplète,
        c'est un agent qui ne peut rien faire.
        """
        from django.contrib.auth import get_user_model

        from jeiko.users.models import RoleAssignment

        User = get_user_model()
        porteur = User.objects.create_user("vide", "vide@exemple.fr", "Mot-De-Passe-42")
        role = Role.objects.create(name="Rôle sans droits", slug="sans-droits")
        RoleAssignment.objects.create(user=porteur, role=role)

        porteur = User.objects.get(pk=porteur.pk)
        self.assertEqual(porteur.get_all_permissions(), set())

    def test_le_role_editeur_permet_bien_d_ecrire_une_page(self):
        """
        Un contrôle de bout en bout : la permission attachée est celle que les
        vues exigent réellement, pas une homonyme.
        """
        from django.contrib.auth import get_user_model

        from jeiko.users.models import RoleAssignment

        User = get_user_model()
        agent = User.objects.create_user("agent", "agent@exemple.fr", "Mot-De-Passe-42")
        RoleAssignment.objects.create(
            user=agent, role=Role.objects.get(slug="agent-editeur-pages")
        )

        agent = User.objects.get(pk=agent.pk)
        self.assertTrue(agent.has_perm("administration_pages.change_page"))
        self.assertFalse(
            agent.has_perm("administration_pages.delete_page"),
            "La suppression de page reste refusée : c'est la règle du rôle.",
        )
