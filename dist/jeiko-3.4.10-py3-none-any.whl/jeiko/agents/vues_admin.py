# jeiko/agents/vues_admin.py
"""
Écrans d'administration des agents.

Le jeton ne s'affiche qu'une fois
---------------------------------
À la création et à la réinitialisation, et nulle part ailleurs : la base ne
contient que son empreinte (voir `jetons.py`). L'écran le montre donc en clair
une seule fois, en disant que c'est la seule.

C'est un inconfort assumé. L'alternative — un jeton relisable — ferait d'une
base lue, d'une sauvegarde égarée ou d'une capture d'écran de cet écran un
accès permanent au site.

Ce que ces écrans ne font pas
-----------------------------
Ils n'attribuent pas de droits. Un agent tout neuf ne peut RIEN : ses
permissions passent par les rôles, sur l'écran des rôles, comme pour une
personne. C'est délibéré — une seule vérité sur « qui a le droit de quoi ».
"""

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.generic import DetailView, ListView

from .formulaires import AgentForm
from .models import Agent, AppelAgent
from .services import creer_agent, reinitialiser_le_jeton

#: Un agent est un porteur de droits : le créer, c'est ouvrir un accès. On le
#: garde derrière la permission qui gouverne déjà les comptes.
PERM = "auth.change_user"

#: Le jeton en clair transite par la session, pas par l'URL ni par la base.
#: Une URL part dans les journaux et l'historique ; la session, elle, est
#: purgée dès la première lecture (voir `_reprendre_le_jeton`).
CLE_SESSION_JETON = "jeiko_agent_jeton_en_clair"


def _deposer_le_jeton(request, jeton):
    request.session[CLE_SESSION_JETON] = jeton


def _reprendre_le_jeton(request):
    """Rend le jeton et l'efface : il ne survit pas à un rafraîchissement."""
    return request.session.pop(CLE_SESSION_JETON, "")


@method_decorator(never_cache, name="dispatch")
class ListeDesAgents(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Agent
    template_name = "agents/admin/liste.html"
    context_object_name = "agents"
    permission_required = PERM
    raise_exception = True

    def get_queryset(self):
        return Agent.objects.select_related("user").prefetch_related("jetons")


@method_decorator(never_cache, name="dispatch")
class CreationAgent(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "agents/admin/formulaire.html"
    permission_required = PERM
    raise_exception = True

    def get(self, request):
        from django.shortcuts import render

        return render(request, self.template_name, {"form": AgentForm()})

    def post(self, request):
        from django.shortcuts import render

        form = AgentForm(request.POST)
        if not form.is_valid():
            return render(request, self.template_name, {"form": form})

        agent, jeton = creer_agent(
            nom=form.cleaned_data["nom"],
            description=form.cleaned_data["description"],
            expire_le=form.cleaned_data["expire_le"],
            ips_autorisees=form.cleaned_data["ips_autorisees"],
            cree_par=request.user,
        )
        agent.actif = form.cleaned_data["actif"]
        agent.save(update_fields=["actif"])

        _deposer_le_jeton(request, jeton)
        messages.success(
            request,
            f"Agent « {agent.nom} » créé. Donnez-lui un rôle pour qu'il puisse "
            f"faire quelque chose : sans rôle, il ne peut rien.",
        )
        return redirect("jeiko_agents_admin:detail", pk=agent.pk)


@method_decorator(never_cache, name="dispatch")
class DetailAgent(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = Agent
    template_name = "agents/admin/detail.html"
    context_object_name = "agent"
    permission_required = PERM
    raise_exception = True

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["jeton_en_clair"] = _reprendre_le_jeton(self.request)
        ctx["jetons"] = self.object.jetons.all()
        ctx["appels"] = AppelAgent.objects.filter(agent=self.object)[:50]
        ctx["roles"] = self.object.user.role_assignments.select_related("role")
        ctx["url_api"] = self.request.build_absolute_uri("/api/agent/v1/")
        return ctx


@method_decorator(never_cache, name="dispatch")
class ModificationAgent(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "agents/admin/formulaire.html"
    permission_required = PERM
    raise_exception = True

    def get(self, request, pk):
        from django.shortcuts import render

        agent = get_object_or_404(Agent, pk=pk)
        return render(
            request, self.template_name, {"form": AgentForm(instance=agent), "agent": agent}
        )

    def post(self, request, pk):
        from django.shortcuts import render

        agent = get_object_or_404(Agent, pk=pk)
        form = AgentForm(request.POST, instance=agent)
        if not form.is_valid():
            return render(request, self.template_name, {"form": form, "agent": agent})
        form.save()
        messages.success(request, "Agent enregistré.")
        return redirect("jeiko_agents_admin:detail", pk=agent.pk)


@method_decorator(never_cache, name="dispatch")
class ReinitialisationDuJeton(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Fabrique un jeton neuf et révoque les précédents.

    POST uniquement : c'est une action, et elle coupe l'accès en cours.
    """

    permission_required = PERM
    raise_exception = True

    def post(self, request, pk):
        agent = get_object_or_404(Agent, pk=pk)
        jeton = reinitialiser_le_jeton(
            agent, libelle=request.POST.get("libelle", "")[:150], par=request.user
        )
        _deposer_le_jeton(request, jeton)
        messages.success(
            request,
            "Nouveau jeton créé, les précédents sont révoqués. "
            "Notez-le maintenant : il ne sera plus affiché.",
        )
        return redirect("jeiko_agents_admin:detail", pk=agent.pk)


@method_decorator(never_cache, name="dispatch")
class BasculeActivation(LoginRequiredMixin, PermissionRequiredMixin, View):
    permission_required = PERM
    raise_exception = True

    def post(self, request, pk):
        agent = get_object_or_404(Agent, pk=pk)
        agent.actif = not agent.actif
        agent.save(update_fields=["actif", "maj_le"])
        messages.success(
            request,
            f"Agent « {agent.nom} » {'réactivé' if agent.actif else 'désactivé'}.",
        )
        return redirect("jeiko_agents_admin:detail", pk=agent.pk)
