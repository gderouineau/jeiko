# jeiko/agents/tests_menus.py
"""
Construire des menus, et faire des sous-sites.

Le cas d'usage réel
-------------------
Sur ateliersderouineau.com, « Électricité » et « Plomberie » ont des menus
**identiques à l'œil et différents dans leurs liens**. C'est ce que permet
`Category.main_menu` : toutes les pages d'une catégorie prennent ses menus.

Reconstruire un menu entrée par entrée pour chaque branche est long et
produit des écarts qu'on ne voit pas — une entrée oubliée dans une seule
branche. D'où `copie_de`, testé ici comme le geste central.

Ce que ces tests gardent
------------------------
* **la copie est fidèle**, sous-entrées comprises, et **indépendante** : la
  modifier ne doit pas toucher son modèle ;
* **rien n'est écrit à moitié** — un menu à demi réécrit, c'est une navigation
  amputée sur toutes les pages de la branche à la fois ;
* **un menu ne se rend pas à une place qui n'est pas la sienne** ;
* **le design reste fermé**, comme demandé.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_menu.models import Menu, MenuItem, MenuPlace
from jeiko.administration_pages.models import Category, Page

from .tests import SocleMixin, donner_le_role

MENUS = "/api/agent/v1/menus/"

DROITS_MENU = ("view_menu", "add_menu", "change_menu",
               "view_menuitem", "add_menuitem", "change_menuitem")


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class SocleMenu(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, *DROITS_MENU,
            app="administration_menu", nom="Rôle de test menus",
        )
        donner_le_role(
            self.agent.user, "view_category", "change_category",
            app="administration_pages", nom="Rôle de test catégories",
        )
        self.accueil = Page.objects.create(title="Accueil", url_tag="acc-menu")
        self.elec = Page.objects.create(title="Électricité", url_tag="elec-menu")
        self.tarifs = Page.objects.create(title="Tarifs", url_tag="tarifs-menu")

    def _patch(self, chemin, corps):
        return self.client.patch(
            chemin, data=json.dumps(corps), content_type="application/json",
            **self.entetes(self.jeton),
        )

    def _menu_avec_arborescence(self):
        reponse = self.json_post(f"{MENUS}creer/", {
            "nom": "Menu général",
            "emplacement": MenuPlace.MAIN,
            "disposition": "logo-left-menu-right",
            "elements": [
                {"titre": "Accueil", "page": self.accueil.id},
                {"titre": "Services", "sous_elements": [
                    {"titre": "Électricité", "page": self.elec.id},
                    {"titre": "Tarifs", "page": self.tarifs.id},
                ]},
            ],
        }, self.jeton)
        self.assertEqual(reponse.status_code, 201, reponse.content[:300])
        return Menu.objects.get(pk=reponse.json()["menu"]["id"])


class ArborescenceTests(SocleMenu):
    def test_un_menu_se_cree_avec_ses_sous_entrees(self):
        menu = self._menu_avec_arborescence()

        racine = menu.menu_items.filter(main_menu__isnull=True).order_by("position")
        self.assertEqual([e.title for e in racine], ["Accueil", "Services"])
        self.assertEqual(
            [e.title for e in racine[1].submenus.order_by("position")],
            ["Électricité", "Tarifs"],
        )

    def test_reecrire_les_elements_remplace_l_arborescence(self):
        """
        `MenuItem` porte deux contraintes d'unicité sur la position : une mise
        à jour partielle les violerait dès qu'on insère au milieu.
        """
        menu = self._menu_avec_arborescence()
        self._patch(f"{MENUS}{menu.id}/", {
            "elements": [{"titre": "Contact", "page": self.accueil.id}]
        })
        self.assertEqual(
            list(menu.menu_items.values_list("title", flat=True)), ["Contact"]
        )

    def test_une_entree_vers_une_page_inexistante_est_refusee(self):
        menu = self._menu_avec_arborescence()
        avant = list(menu.menu_items.values_list("title", flat=True))

        reponse = self._patch(f"{MENUS}{menu.id}/", {
            "elements": [
                {"titre": "Bonne", "page": self.accueil.id},
                {"titre": "Mauvaise", "page": 999999},
            ]
        })
        self.assertEqual(reponse.status_code, 400)
        self.assertEqual(
            list(menu.menu_items.values_list("title", flat=True)), avant,
            "Un menu à moitié réécrit ampute la navigation de toutes les "
            "pages à la fois.",
        )

    def test_une_entree_sans_titre_est_refusee(self):
        menu = self._menu_avec_arborescence()
        reponse = self._patch(f"{MENUS}{menu.id}/", {
            "elements": [{"titre": "", "page": self.accueil.id}]
        })
        self.assertEqual(reponse.status_code, 400)


class CopieTests(SocleMenu):
    """`copie_de` — le geste qui fait les sous-sites."""

    def test_la_copie_reprend_l_arborescence_complete(self):
        source = self._menu_avec_arborescence()
        reponse = self.json_post(f"{MENUS}creer/", {
            "nom": "Menu plomberie", "copie_de": source.id,
        }, self.jeton)
        self.assertEqual(reponse.status_code, 201)

        copie = Menu.objects.get(pk=reponse.json()["menu"]["id"])
        self.assertEqual(copie.layout, source.layout)
        self.assertEqual(
            list(copie.menu_items.filter(main_menu__isnull=True)
                 .order_by("position").values_list("title", flat=True)),
            ["Accueil", "Services"],
        )
        services = copie.menu_items.get(title="Services")
        self.assertEqual(
            list(services.submenus.order_by("position").values_list("title", flat=True)),
            ["Électricité", "Tarifs"],
        )

    def test_la_copie_est_independante_de_son_modele(self):
        """
        Sans quoi « les mêmes visuellement, des liens différents » serait
        impossible : modifier la branche plomberie changerait l'électricité.
        """
        source = self._menu_avec_arborescence()
        reponse = self.json_post(f"{MENUS}creer/", {
            "nom": "Copie", "copie_de": source.id,
        }, self.jeton)
        copie = Menu.objects.get(pk=reponse.json()["menu"]["id"])

        self._patch(f"{MENUS}{copie.id}/", {
            "elements": [{"titre": "Autre chose", "page": self.tarifs.id}]
        })
        self.assertEqual(
            list(source.menu_items.filter(main_menu__isnull=True)
                 .order_by("position").values_list("title", flat=True)),
            ["Accueil", "Services"],
            "Modifier la copie a touché le modèle.",
        )

    def test_copier_un_menu_inexistant_est_refuse(self):
        reponse = self.json_post(f"{MENUS}creer/", {
            "nom": "X", "copie_de": 999999,
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)


class SousSitesTests(SocleMenu):
    def test_une_categorie_recoit_son_menu(self):
        menu = self._menu_avec_arborescence()
        categorie = Category.objects.create(name="Électricité", slug="elec")

        reponse = self._patch(
            f"/api/agent/v1/categories/{categorie.id}/menus/",
            {"menu_principal": menu.id},
        )
        self.assertEqual(reponse.status_code, 200)
        categorie.refresh_from_db()
        self.assertEqual(categorie.main_menu, menu)

    def test_un_menu_de_pied_de_page_ne_va_pas_en_menu_principal(self):
        """Les dispositions ne sont pas les mêmes : il ne se rendrait pas."""
        # Un menu de pied de page n'a PAS de disposition : `LAYOUTS_BY_PLACE`
        # n'en déclare aucune pour cette place, et une contrainte de base le
        # fait respecter.
        pied = Menu.objects.create(
            name="Pied", place=MenuPlace.FOOTER, layout=None
        )
        categorie = Category.objects.create(name="Plomberie", slug="plomb")

        reponse = self._patch(
            f"/api/agent/v1/categories/{categorie.id}/menus/",
            {"menu_principal": pied.id},
        )
        self.assertEqual(reponse.status_code, 400)
        categorie.refresh_from_db()
        self.assertIsNone(categorie.main_menu)

    def test_on_peut_retirer_le_menu_d_une_categorie(self):
        menu = self._menu_avec_arborescence()
        categorie = Category.objects.create(
            name="Divers", slug="divers", main_menu=menu
        )
        self._patch(
            f"/api/agent/v1/categories/{categorie.id}/menus/",
            {"menu_principal": None},
        )
        categorie.refresh_from_db()
        self.assertIsNone(categorie.main_menu)


class DispositionTests(SocleMenu):
    def test_une_disposition_sur_un_pied_de_page_est_refusee(self):
        """
        Une contrainte de base le refuse déjà — mais par une `CheckViolation`,
        donc une 500. Un défaut de l'API ne doit pas se rendre comme une panne
        de serveur.
        """
        reponse = self.json_post(f"{MENUS}creer/", {
            "nom": "Pied", "emplacement": MenuPlace.FOOTER,
            "disposition": "logo-left-menu-right",
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("disposition", reponse.json()["erreur"])

    def test_un_pied_de_page_se_cree_sans_disposition(self):
        reponse = self.json_post(f"{MENUS}creer/", {
            "nom": "Pied de page", "emplacement": MenuPlace.FOOTER,
        }, self.jeton)
        self.assertEqual(reponse.status_code, 201, reponse.content[:300])


class DesignFermeTests(SocleMenu):
    def test_le_style_visuel_n_est_pas_modifiable(self):
        """« Pas des designs » : un style se partage entre menus."""
        menu = self._menu_avec_arborescence()
        reponse = self._patch(f"{MENUS}{menu.id}/", {"style": 1})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("style", reponse.json()["erreur"].lower())

    def test_declarer_un_menu_par_defaut_libere_l_ancien(self):
        """
        Une contrainte n'autorise qu'un défaut par emplacement : sans transfert
        explicite, c'est une UniqueViolation, donc une 500.
        """
        ancien = Menu.objects.filter(
            place=MenuPlace.MAIN, is_default=True
        ).first()
        if ancien is None:
            ancien = Menu.objects.create(
                name="Défaut", place=MenuPlace.MAIN,
                layout="logo-left-menu-right", is_default=True,
            )
        nouveau = self._menu_avec_arborescence()

        reponse = self._patch(f"{MENUS}{nouveau.id}/", {"par_defaut": True})
        self.assertEqual(reponse.status_code, 200)

        ancien.refresh_from_db()
        nouveau.refresh_from_db()
        self.assertFalse(ancien.is_default)
        self.assertTrue(nouveau.is_default)
