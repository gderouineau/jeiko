# jeiko/agents/formulaires.py
"""Saisie d'un agent. Le jeton, lui, ne se saisit jamais : il se tire au sort."""

from django import forms

from .models import Agent


class AgentForm(forms.ModelForm):
    class Meta:
        model = Agent
        fields = ("nom", "description", "expire_le", "ips_autorisees", "actif")
        widgets = {
            "nom": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "ex. Rédaction assistée",
            }),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "expire_le": forms.DateTimeInput(
                attrs={"class": "form-control", "type": "datetime-local"},
                format="%Y-%m-%dT%H:%M",
            ),
            "ips_autorisees": forms.Textarea(attrs={
                "class": "form-control",
                "rows": 3,
                "placeholder": "une adresse par ligne",
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Le navigateur n'accepte que ce format pour `datetime-local`, et sans
        # lui le champ se vide à chaque réaffichage du formulaire.
        self.fields["expire_le"].input_formats = ["%Y-%m-%dT%H:%M"]
