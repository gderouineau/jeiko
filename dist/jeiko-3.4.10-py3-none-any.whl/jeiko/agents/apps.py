from django.apps import AppConfig


class AgentsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "jeiko.agents"
    label = "jeiko_agents"
    verbose_name = "Agents IA"
