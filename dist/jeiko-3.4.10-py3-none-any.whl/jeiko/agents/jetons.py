# jeiko/agents/jetons.py
"""
Fabrication et vérification des jetons d'accès des agents.

Ce que porte un jeton
---------------------
    jk_ag_<préfixe>_<secret>
    │     │          └─ 43 caractères tirés au sort, JAMAIS enregistrés
    │     └─ 12 caractères publics, uniques, indexés : servent à retrouver la
    │        ligne en une requête, sans balayer la table
    └─ marque de fabrique, pour qu'un jeton trouvé dans un journal ou un dépôt
       soit reconnaissable au premier coup d'œil et révocable sans enquête

Pourquoi le secret n'est enregistré que haché
---------------------------------------------
Une base lue — sauvegarde égarée, injection SQL, accès en lecture — ne doit pas
livrer de quoi se connecter. On garde donc l'empreinte, pas le secret : le
jeton n'est affiché qu'UNE fois, à sa création. Perdu, il se remplace ; il ne
se retrouve pas. C'est volontairement irréversible.

Pourquoi SHA-256 et non un hachage lent (PBKDF2, bcrypt)
--------------------------------------------------------
Ces algorithmes existent pour ralentir la recherche exhaustive d'un secret
*devinable* — un mot de passe humain. Ici le secret fait 256 bits tirés au
sort : il n'y a rien à deviner, et l'exhaustif n'a pas de sens. En revanche le
jeton est vérifié à CHAQUE appel : un hachage lent coûterait à chaque requête
ce qu'il ne protège de rien. C'est le même raisonnement que pour les jetons
d'API de GitHub ou de Stripe.

Ce que cela ne protège pas
--------------------------
Rien ici ne protège un jeton divulgué : quiconque l'a peut s'en servir jusqu'à
sa révocation. C'est le rôle des autres gardes — HTTPS obligatoire, liste d'IP,
expiration, journalisation — de réduire la fenêtre et de rendre l'usage
visible.
"""

import hashlib
import secrets

#: Reconnaissable, et assez court pour ne pas gêner. `ag` pour « agent » :
#: d'autres familles de jetons pourront cohabiter sans ambiguïté.
PREFIXE_MARQUE = "jk_ag"

#: 6 octets → 12 caractères hexadécimaux. L'unicité est garantie par la base,
#: pas par la probabilité : voir `AgentToken.creer`.
LONGUEUR_PREFIXE_OCTETS = 6

#: 32 octets → 43 caractères url-safe. Au-delà du raisonnable, à dessein.
LONGUEUR_SECRET_OCTETS = 32


def fabriquer():
    """Renvoie `(prefixe, secret, jeton_complet)`. Le secret n'est vu qu'ici."""
    prefixe = secrets.token_hex(LONGUEUR_PREFIXE_OCTETS)
    secret = secrets.token_urlsafe(LONGUEUR_SECRET_OCTETS)
    return prefixe, secret, f"{PREFIXE_MARQUE}_{prefixe}_{secret}"


def empreinte(secret):
    """L'empreinte enregistrée en base. Jamais le secret lui-même."""
    return hashlib.sha256(secret.encode("utf-8")).hexdigest()


def decouper(jeton):
    """
    Sépare un jeton présenté en `(prefixe, secret)`, ou `(None, None)`.

    Tolère l'absence de jeton et les formes bancales sans lever : cette
    fonction est appelée sur une valeur venue du réseau, donc arbitraire.
    """
    if not jeton or not isinstance(jeton, str):
        return None, None

    morceaux = jeton.strip().split("_")
    # jk _ ag _ prefixe _ secret — le secret peut contenir des « - » et « _ »,
    # d'où le regroupement de tout ce qui suit le préfixe.
    if len(morceaux) < 4:
        return None, None
    if f"{morceaux[0]}_{morceaux[1]}" != PREFIXE_MARQUE:
        return None, None

    prefixe = morceaux[2]
    secret = "_".join(morceaux[3:])
    if not prefixe or not secret:
        return None, None
    return prefixe, secret
