# jeiko/agents/tests_alignement.py
"""
Un alignement réglé doit s'appliquer — et une valeur inventée doit être refusée.

Ce qui s'est passé
------------------
`Bloc.horizontal_align` et `Bloc.vertical_align` existent depuis longtemps,
l'éditeur les propose, l'API les enregistrait. **Aucun gabarit ne les rendait :**
`grep -rn "horizontal_align" templates/` ne trouvait rien.

Le cas qui l'a révélé : un bouton « Ajouter au panier » restait centré sous un
texte aligné à gauche. Le centrage venait de `.bloc-BUTTON` dans main.css, et
rien ne permettait de le contredire.

Le second défaut, dessous
-------------------------
L'écriture des champs propres était un `setattr` brut, sans validation.
« flex-start » a donc été enregistré dans un champ qui n'accepte que « left »,
« center », « right » ou « justify ». La base l'a pris, l'API l'a relu
fidèlement, et le gabarit — ne sachant pas traduire un mot-clé flexbox — n'a
rien aligné. **Le réglage avait l'air posé et ne faisait rien.**

La validation interroge désormais les `choices` du MODÈLE. Pas une liste
recopiée ici : les valeurs sont déjà écrites une fois, et une seconde copie
divergerait au premier choix ajouté.
"""

import json

from django.test import TestCase, override_settings
from django.template.loader import render_to_string
from django.test import RequestFactory

from jeiko.administration_pages.models import Bloc, Line, Page, Section

from .tests import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class ValidationDesAlignementsTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Rôle de test alignement",
        )
        page = Page.objects.create(title="Essai", url_tag="essai-align")
        section = Section.objects.create(page=page, position=0)
        ligne = Line.objects.create(
            section=section, position=0, columns_type="12", columns_number=1
        )
        self.bloc = Bloc.objects.create(
            line=ligne, position=1, position_in_column=0
        )

    def _patch(self, corps):
        return self.client.patch(
            f"/api/agent/v1/blocs/{self.bloc.id}/",
            data=json.dumps(corps), content_type="application/json",
            **self.entetes(self.jeton),
        )

    def test_une_valeur_flexbox_est_refusee(self):
        """
        « flex-start » n'est pas dans les choix du modèle. L'accepter donnait
        un champ que le gabarit ne sait pas traduire — donc un réglage sans
        effet, que la relecture confirmait pourtant.
        """
        reponse = self._patch({"horizontal_align": "flex-start"})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("'left'", reponse.json()["erreur"])

        self.bloc.refresh_from_db()
        self.assertEqual(self.bloc.horizontal_align, "")

    def test_les_valeurs_du_modele_passent(self):
        for valeur in ("left", "center", "right", "justify"):
            with self.subTest(valeur=valeur):
                self.assertEqual(self._patch({"horizontal_align": valeur}).status_code, 200)
                self.bloc.refresh_from_db()
                self.assertEqual(self.bloc.horizontal_align, valeur)

    def test_l_alignement_vertical_suit_la_meme_regle(self):
        self.assertEqual(self._patch({"vertical_align": "middle"}).status_code, 200)
        self.assertEqual(self._patch({"vertical_align": "center"}).status_code, 400)

    def test_la_repartition_des_colonnes_est_validee_aussi(self):
        """
        La validation lit les `choices` du modèle : elle couvre donc tous les
        champs propres, pas seulement l'alignement.
        """
        reponse = self.client.patch(
            f"/api/agent/v1/lignes/{self.bloc.line_id}/",
            data=json.dumps({"columns_type": "n-importe-quoi"}),
            content_type="application/json", **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 400)


class RenduDeLAlignementTests(TestCase):
    """Le gabarit doit RENDRE ce que l'API enregistre."""

    def _styles(self, **reglages):
        page = Page.objects.create(title="Essai", url_tag="essai-rendu-align")
        section = Section.objects.create(page=page, position=0)
        ligne = Line.objects.create(
            section=section, position=0, columns_type="12", columns_number=1
        )
        bloc = Bloc.objects.create(
            line=ligne, position=1, position_in_column=0, **reglages
        )
        return render_to_string(
            "administration_pages/styles/bloc.html",
            {"bloc": bloc, "request": RequestFactory().get("/")},
        ), bloc

    def test_gauche_produit_flex_start(self):
        rendu, bloc = self._styles(horizontal_align="left")
        self.assertIn(f"#bloc-{bloc.id}", rendu)
        self.assertIn("justify-content:", rendu.replace(" ", "").replace("\n", "")
                      and rendu)
        self.assertIn("flex-start", rendu)

    def test_droite_produit_flex_end(self):
        rendu, _ = self._styles(horizontal_align="right")
        self.assertIn("flex-end", rendu)

    def test_le_display_flex_est_pose_avec(self):
        """Sans lui, `justify-content` n'aurait aucun effet sur un bloc block."""
        rendu, _ = self._styles(horizontal_align="center")
        self.assertIn("display: flex", rendu)

    def test_sans_reglage_rien_n_est_impose(self):
        """
        Un bloc sans alignement ne doit pas se voir imposer un flex : cela
        changerait la mise en page de toutes les pages en service.
        """
        rendu, bloc = self._styles()
        self.assertNotIn("justify-content", rendu)

    def test_l_alignement_vertical_se_rend(self):
        rendu, _ = self._styles(vertical_align="bottom")
        self.assertIn("align-items", rendu)
        self.assertIn("flex-end", rendu)
