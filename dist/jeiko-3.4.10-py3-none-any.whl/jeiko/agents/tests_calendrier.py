# jeiko/agents/tests_calendrier.py
"""
Le calendrier par l'API — et ce que la CASCADE oblige à garder.

Le fait qui décide de tout
---------------------------
`Slot.availability` et `Appointment.slot` sont tous deux en CASCADE. Supprimer
une disponibilité efface donc ses créneaux **et les rendez-vous pris dessus** :
des personnes qui se sont déplacées, ou vont le faire, disparues de l'agenda
sans qu'aucun message ne le dise.

C'est le test le plus important de ce fichier.

Le second fait
--------------
On ne crée pas un créneau : on déclare une disponibilité, qui les GÉNÈRE — et
qui nettoie ceux qui sortent de sa plage. Un créneau posé à la main serait
effacé au prochain passage. L'API n'en propose donc pas la création, et ces
tests vérifient que la génération produit bien ce qu'on attend.
"""

import json
from datetime import timedelta

from django.test import TestCase, override_settings
from django.utils import timezone

from jeiko.calendars.models import (
    Appointment, AppointmentType, Availability, Slot,
)

from .tests import SocleMixin, donner_le_role

RACINE = "/api/agent/v1"

DROITS_GESTION = (
    "view_appointmenttype", "add_appointmenttype", "change_appointmenttype",
    "view_availability", "add_availability", "change_availability",
    "delete_availability", "view_slot",
)


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class SocleCalendrier(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, *DROITS_GESTION,
            app="calendars", nom="Rôle de test calendrier",
        )
        self.type = AppointmentType.objects.create(
            name="Séance de coaching 1 h", duration=timedelta(minutes=60),
            capacity=1, max_places_per_booking=1,
        )
        self.demain = (timezone.now() + timedelta(days=1)).replace(
            hour=9, minute=0, second=0, microsecond=0
        )

    def _patch(self, chemin, corps):
        return self.client.patch(
            chemin, data=json.dumps(corps), content_type="application/json",
            **self.entetes(self.jeton),
        )

    def _creer_dispo(self, heures=3):
        reponse = self.json_post(f"{RACINE}/rdv/disponibilites/creer/", {
            "debut": self.demain.isoformat(),
            "fin": (self.demain + timedelta(hours=heures)).isoformat(),
            "types": [self.type.id],
        }, self.jeton)
        self.assertEqual(reponse.status_code, 201, reponse.content[:300])
        return Availability.objects.get(pk=reponse.json()["disponibilite"]["id"])


class TypesTests(SocleCalendrier):
    def test_un_type_se_cree_avec_sa_duree(self):
        reponse = self.json_post(f"{RACINE}/rdv/types/creer/", {
            "nom": "Diagnostic", "duree_minutes": 30, "capacite": 4,
            "places_max_par_reservation": 2,
        }, self.jeton)
        self.assertEqual(reponse.status_code, 201)

        type_rdv = AppointmentType.objects.get(name="Diagnostic")
        self.assertEqual(type_rdv.duration, timedelta(minutes=30))

    def test_une_duree_est_obligatoire(self):
        """C'est elle qui découpe la plage : sans elle, aucun créneau."""
        reponse = self.json_post(f"{RACINE}/rdv/types/creer/",
                                 {"nom": "Sans durée"}, self.jeton)
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("duree_minutes", reponse.json()["erreur"])

    def test_un_maximum_superieur_a_la_capacite_est_refuse(self):
        """
        Aucune réservation de cette taille ne pourrait aboutir — et le réglage
        n'aurait pas l'air fautif.
        """
        reponse = self.json_post(f"{RACINE}/rdv/types/creer/", {
            "nom": "Impossible", "duree_minutes": 30,
            "capacite": 2, "places_max_par_reservation": 5,
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)


class DisponibilitesTests(SocleCalendrier):
    def test_une_disponibilite_genere_ses_creneaux(self):
        dispo = self._creer_dispo(heures=3)
        self.assertEqual(
            dispo.slots.count(), 3,
            "Trois heures découpées par un type d'une heure font trois créneaux.",
        )

    def test_sans_type_aucun_creneau_donc_c_est_refuse(self):
        reponse = self.json_post(f"{RACINE}/rdv/disponibilites/creer/", {
            "debut": self.demain.isoformat(),
            "fin": (self.demain + timedelta(hours=2)).isoformat(),
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("types", reponse.json()["erreur"])

    def test_une_plage_inversee_est_refusee(self):
        reponse = self.json_post(f"{RACINE}/rdv/disponibilites/creer/", {
            "debut": (self.demain + timedelta(hours=2)).isoformat(),
            "fin": self.demain.isoformat(),
            "types": [self.type.id],
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)

    def test_une_date_illisible_le_dit(self):
        reponse = self.json_post(f"{RACINE}/rdv/disponibilites/creer/", {
            "debut": "jeudi prochain", "fin": self.demain.isoformat(),
            "types": [self.type.id],
        }, self.jeton)
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("ISO", reponse.json()["erreur"])


class SuppressionTests(SocleCalendrier):
    """Le garde-fou qui compte."""

    def test_supprimer_une_plage_sans_rdv_est_permis(self):
        dispo = self._creer_dispo()
        reponse = self.client.delete(
            f"{RACINE}/rdv/disponibilites/{dispo.id}/", **self.entetes(self.jeton)
        )
        self.assertEqual(reponse.status_code, 200)
        self.assertFalse(Availability.objects.filter(pk=dispo.id).exists())

    def test_supprimer_une_plage_qui_porte_des_rdv_est_refuse(self):
        """
        `Appointment.slot` est en CASCADE : ce seraient des personnes réelles
        effacées de l'agenda, sans un mot.
        """
        dispo = self._creer_dispo()
        creneau = dispo.slots.first()
        Appointment.objects.create(
            type=self.type, slot=creneau,
            start=creneau.start, end=creneau.end,
            client_name="Mme Durand", email="durand@exemple.fr", places=1,
        )

        reponse = self.client.delete(
            f"{RACINE}/rdv/disponibilites/{dispo.id}/", **self.entetes(self.jeton)
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("fermer", reponse.json()["erreur"].lower())
        self.assertTrue(Availability.objects.filter(pk=dispo.id).exists())
        self.assertEqual(Appointment.objects.count(), 1)


class CreneauxTests(SocleCalendrier):
    """
    Les créneaux se LISENT. Ils ne s'écrivent pas, et c'est délibéré.

    Un créneau n'est pas une chose qu'on règle : c'est le résultat d'une
    disponibilité. Le créer serait effacé au prochain `generate_slots()` ;
    l'ouvrir ou le fermer à la main le désynchroniserait de la plage qui le
    produit, et la régénération suivante déferait le réglage **sans le dire**.

    Le geste de « je ne suis pas disponible ce jeudi-là » est une date exclue
    sur la disponibilité. C'est le seul qui tienne.
    """

    def test_les_creneaux_se_lisent(self):
        dispo = self._creer_dispo(heures=3)
        lu = self.client.get(
            f"{RACINE}/rdv/creneaux/?type={self.type.id}", **self.entetes(self.jeton)
        ).json()
        self.assertEqual(len(lu["creneaux"]), 3)
        self.assertEqual(lu["creneaux"][0]["disponibilite"], dispo.id)

    def test_aucune_route_n_ecrit_un_creneau(self):
        """L'absence de route est ce qui empêche de croire l'écriture possible."""
        from jeiko.agents.urls_api import urlpatterns

        chemins = [str(m.pattern) for m in urlpatterns]
        self.assertNotIn("rdv/creneaux/creer/", chemins)
        self.assertNotIn("rdv/creneaux/<int:creneau_id>/", chemins)

    def test_une_date_exclue_est_le_geste_qui_tient(self):
        """
        Fermer un jeudi passe par la disponibilité, pas par ses créneaux.
        """
        dispo = self._creer_dispo(heures=3)
        avant = dispo.slots.count()

        jour = dispo.start.date().isoformat()
        reponse = self._patch(f"{RACINE}/rdv/disponibilites/{dispo.id}/",
                              {"dates_exclues": [jour]})
        self.assertEqual(reponse.status_code, 200)
        dispo.refresh_from_db()
        self.assertEqual(dispo.recurrence_exdates, [jour])
        self.assertLessEqual(dispo.slots.count(), avant)


class RendezVousTests(SocleCalendrier):
    def test_lire_les_rdv_demande_une_permission_a_part(self):
        """
        Une clé qui pose des créneaux n'a pas à lire qui a réservé.
        """
        reponse = self.client.get(f"{RACINE}/rdv/", **self.entetes(self.jeton))
        self.assertEqual(reponse.status_code, 403)

    def test_avec_la_permission_les_rdv_se_lisent(self):
        donner_le_role(
            self.agent.user, "view_appointment",
            app="calendars", nom="Rôle de test agenda",
        )
        dispo = self._creer_dispo()
        creneau = dispo.slots.first()
        Appointment.objects.create(
            type=self.type, slot=creneau, start=creneau.start, end=creneau.end,
            client_name="M. Martin", email="martin@exemple.fr", places=1,
        )

        lu = self.client.get(f"{RACINE}/rdv/", **self.entetes(self.jeton)).json()
        self.assertEqual(len(lu["rendez_vous"]), 1)
        self.assertEqual(lu["rendez_vous"][0]["client"], "M. Martin")

    def test_aucune_route_ne_modifie_un_rdv(self):
        """
        Annuler un rendez-vous doit prévenir la personne : ce n'est pas le
        travail de cette API.
        """
        from jeiko.agents.urls_api import urlpatterns

        chemins = [str(m.pattern) for m in urlpatterns]
        self.assertNotIn("rdv/<int:rdv_id>/", chemins)
