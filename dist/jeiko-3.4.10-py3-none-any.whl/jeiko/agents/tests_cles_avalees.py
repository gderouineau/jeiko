# jeiko/agents/tests_cles_avalees.py
"""
Une clé que l'API ne comprend pas doit faire ÉCHOUER l'appel, pas être ignorée.

Ce que ce défaut a coûté
------------------------
En montant les trois formules JEIKO, deux appels ont renvoyé **200 OK** sans
rien écrire :

* `PUT /blocs/604/contenu/` avec `{"texte_questionnaire": …}` — l'API attend
  `text_questionnaire`. `corps.get(type_demande.lower()) or {}` transformait la
  faute de frappe en succès, et le gabarit restait vide.
* `PATCH /pages/88/` avec `{"active": true}` — le champ s'appelle `publiee`.
  La page est restée en brouillon, et la réponse disait 200.

Dans les deux cas le défaut n'a été trouvé qu'en ouvrant la page publique.
C'est la même famille qu'A-12 (une classe jamais posée), A-17 (une règle qui
vise à côté), A-22 (des éléments écrits nulle part) et S-17 (un journal vidé
par une exception avalée) : **une écriture qui réussit et ne produit rien.**

Un appelant ne peut pas se corriger si personne ne lui dit qu'il s'est trompé.
Un agent encore moins : il n'ira pas regarder la page.

Ces tests exigent le refus, et exigent que le message dise quoi écrire — un
« clé inconnue » sec obligerait à relire le code source.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Bloc, Line, Page, Section

from .tests import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class ClesInconnuesTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent pages",
        )
        self.page = Page.objects.create(title="Essai", url_tag="essai-cles")
        section = Section.objects.create(page=self.page, position=0)
        ligne = Line.objects.create(
            section=section, position=0, columns_type="12", columns_number=1
        )
        self.bloc = Bloc.objects.create(
            line=ligne, position=1, position_in_column=0
        )

    def _patch(self, chemin, corps):
        return self.client.patch(
            chemin, data=json.dumps(corps), content_type="application/json",
            **self.entetes(self.jeton),
        )

    def _put_contenu(self, corps):
        return self.client.put(
            f"/api/agent/v1/blocs/{self.bloc.id}/contenu/",
            data=json.dumps(corps), content_type="application/json",
            **self.entetes(self.jeton),
        )

    # --- Page ---------------------------------------------------------- #
    def test_publier_avec_la_mauvaise_cle_est_refuse(self):
        reponse = self._patch(f"/api/agent/v1/pages/{self.page.id}/",
                              {"active": True})
        self.assertEqual(
            reponse.status_code, 400,
            "« active » n'existe pas — le champ est « publiee ». Répondre 200 "
            "laisse croire que la page est en ligne alors qu'elle est en "
            "brouillon.",
        )
        self.page.refresh_from_db()
        self.assertFalse(self.page.active)
        self.assertIn("publiee", reponse.json()["erreur"])

    def test_la_bonne_cle_publie_toujours(self):
        reponse = self._patch(f"/api/agent/v1/pages/{self.page.id}/",
                              {"publiee": True})
        self.assertEqual(reponse.status_code, 200)
        self.page.refresh_from_db()
        self.assertTrue(self.page.active)

    def test_les_metadonnees_restent_acceptees(self):
        """Elles ne sont pas dans CHAMPS_PAGE_MODIFIABLES, mais sont valides."""
        reponse = self._patch(
            f"/api/agent/v1/pages/{self.page.id}/",
            {"metadonnees": {"titre": "T", "description": "D"}},
        )
        self.assertEqual(reponse.status_code, 200)

    # --- Contenu d'un bloc --------------------------------------------- #
    def test_un_document_mal_nomme_est_refuse(self):
        reponse = self._put_contenu({"type": "TEXT", "text": "Bonjour"})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("texte", reponse.json()["erreur"])

    def test_le_message_dit_quoi_ecrire(self):
        """
        Un refus qui n'apprend rien ne vaut guère mieux qu'un succès muet.
        """
        reponse = self._put_contenu({"type": "BUTTON", "boutton": {}})
        message = reponse.json()["erreur"]
        self.assertIn("bouton", message)
        self.assertIn("guide", message.lower())

    def test_un_bloc_dynamique_refuse_aussi(self):
        reponse = self._put_contenu({
            "type": "DYN_FAQ", "questions": [{"question": "?"}]
        })
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("elements", reponse.json()["erreur"])

    def test_les_documents_valides_passent_toujours(self):
        for corps in (
            {"type": "TEXT", "texte": "<p>Bonjour</p>"},
            {"type": "DYN_FAQ", "elements": [{"question": "?", "reponse": "!"}]},
            {"type": "DYN_RATING", "options": {"rating": 4.5}},
        ):
            with self.subTest(type=corps["type"]):
                self.assertEqual(self._put_contenu(corps).status_code, 200)
