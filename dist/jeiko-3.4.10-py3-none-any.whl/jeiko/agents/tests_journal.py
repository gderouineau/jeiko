# jeiko/agents/tests_journal.py
"""
Le journal des appels doit s'écrire, y compris sans adresse IP.

Ce qui s'est passé
------------------
Aucun appel d'agent n'était enregistré, sur aucune installation. Pas un seul,
depuis la mise en service — et rien ne le disait : la page « Agents IA »
montrait une liste vide, ce qui ressemble à un agent qui n'a pas travaillé.

`get_client_ip` renvoie la chaîne `"unknown"` quand `REMOTE_ADDR` est absent.
C'est une clé de compteur, parfaitement valable pour `bucket_key`. Mais
`AppelAgent.ip` est un `GenericIPAddressField`, et PostgreSQL refuse d'écrire
« unknown » dans un `inet` : « invalid input syntax for type inet ».
`_tracer` attrapait l'exception — à raison, tracer ne doit pas casser
l'appel — la consignait dans les logs et rendait la main sans avoir rien écrit.

Et `REMOTE_ADDR` est absent dans le cas NORMAL : gunicorn est servi sur une
socket unix (`scripts/11_configure_nginx.sh`), où il n'existe pas d'adresse
distante. Autrement dit le défaut touchait toutes les installations produites
par l'INSTALLER, et aucune installation de développement — d'où son invisibilité.

Deux verrous, comme pour A-17, parce qu'il a fallu deux erreurs :

* `ip_stockable` sépare l'adresse ENREGISTRÉE de la clé COMPTÉE ;
* le gabarit de settings fait confiance aux en-têtes du proxy, si bien qu'il y
  a une vraie adresse à écrire.

L'un des deux suffit à rendre le journal fonctionnel. Ensemble, ils font qu'une
adresse manquante ou malformée ne peut plus faire disparaître une trace.
"""

from django.test import RequestFactory, TestCase, override_settings

from jeiko.agents.authentification import _tracer
from jeiko.agents.models import AppelAgent
from jeiko.throttling import INCONNUE, get_client_ip, ip_stockable


class IpStockableTests(TestCase):
    def setUp(self):
        self.fabrique = RequestFactory()

    def test_sans_adresse_on_stocke_None_et_pas_une_chaine(self):
        requete = self.fabrique.get("/")
        requete.META.pop("REMOTE_ADDR", None)

        self.assertEqual(
            get_client_ip(requete), INCONNUE,
            "Le compteur a besoin d'un seau, même sans adresse.",
        )
        self.assertIsNone(
            ip_stockable(requete),
            "« unknown » ne doit jamais partir vers un champ IP.",
        )

    def test_une_adresse_malformee_ne_part_pas_en_base(self):
        """
        L'en-tête vient du proxy, mais rien ne garantit sa forme.

        Un `X-Forwarded-For` contenant un port, un nom d'hôte ou n'importe
        quoi d'autre ne doit pas faire disparaître la trace.
        """
        with override_settings(JEIKO_TRUST_X_FORWARDED_FOR=True):
            requete = self.fabrique.get("/", HTTP_X_FORWARDED_FOR="1.2.3.4:5678")
            self.assertIsNone(ip_stockable(requete))

    def test_une_adresse_valide_est_conservee(self):
        with override_settings(JEIKO_TRUST_X_FORWARDED_FOR=True):
            requete = self.fabrique.get("/", HTTP_X_FORWARDED_FOR="203.0.113.7")
            self.assertEqual(ip_stockable(requete), "203.0.113.7")

    def test_x_real_ip_est_lu_a_defaut(self):
        """
        nginx pose les deux ; `X-Real-IP` survit à une réécriture de la chaîne.
        """
        with override_settings(JEIKO_TRUST_X_FORWARDED_FOR=True):
            requete = self.fabrique.get("/", HTTP_X_REAL_IP="203.0.113.9")
            self.assertEqual(get_client_ip(requete), "203.0.113.9")


class TracageSansAdresseTests(TestCase):
    """Le cœur du défaut : la trace doit survivre à l'absence d'adresse."""

    def test_l_appel_est_journalise_meme_sans_remote_addr(self):
        requete = RequestFactory().get("/api/agent/v1/")
        requete.META.pop("REMOTE_ADDR", None)

        _tracer(requete, None, "abcdef", 200)

        self.assertEqual(
            AppelAgent.objects.count(), 1,
            "Aucune trace écrite sans REMOTE_ADDR — c'est le cas NORMAL "
            "derrière une socket unix, donc sur toute installation en "
            "production.",
        )
        appel = AppelAgent.objects.get()
        self.assertIsNone(appel.ip)
        self.assertEqual(appel.statut, 200)
        self.assertEqual(appel.chemin, "/api/agent/v1/")
