# jeiko/agents/urls_api.py
"""
Routes de l'API des agents.

Aucune route de suppression de page : voir l'en-tête de `vues_pages.py`. Ce
n'est pas un oubli, c'est la règle — et son absence ici est la première des
deux barrières.
"""

from django.urls import path

from .vues_api import Guide, QuiSuisJe
from .vues_objets import (
    CreationModele, CreationObjet, CreationProduit, CreationTypeDeProduit,
    DetailModele, DetailObjet, DetailProduit, DetailTypeDeProduit,
    ListeDesModeles, ListeDesObjets, ListeDesProduits, ListeDesTypesDeProduit,
)
from .vues_calendrier import (
    CreationDisponibilite, CreationTypeDeRdv, DetailDisponibilite,
    DetailTypeDeRdv, ListeDesCreneaux, ListeDesDisponibilites,
    ListeDesRendezVous, ListeDesTypesDeRdv,
)
from .vues_identite import Identite
from .vues_menus import (
    CreationMenu, DetailMenu, ListeDesMenus, MenusDeLaCategorie,
)
from .vues_emails import (
    CreationEmail, DetailEmail, ListeDesEmails, ListeDesEvenements,
)
from .vues_questionnaires import (
    CombinaisonsDuQuestionnaire, CreationQuestionnaire, DetailCombinaison,
    DetailProfil, DetailQuestion, DetailQuestionnaire, ListeDesQuestionnaires,
    ProfilsDuQuestionnaire, QuestionsDuQuestionnaire,
)
from .vues_pages import (
    BlocsDeLaLigne, ContenuDuBloc, CreationCategorie, CreationDePage, Deplacement,
    DetailBloc, DetailLigne, DetailPage, DetailSection, LignesDeLaSection,
    ListeDesCategories, ListeDesImages, ListeDesPages, MesuresDeLaPage,
    SectionsDeLaPage,
)

app_name = "jeiko_agents_api"

urlpatterns = [
    # Le mode d'emploi, à la racine ET nommé : c'est le premier appel qu'un
    # agent doit faire, et il ne doit pas avoir à le chercher.
    path("", Guide.as_view(), name="guide"),
    path("guide/", Guide.as_view(), name="guide_explicite"),

    # Vérifier son jeton et découvrir ses droits.
    path("qui-suis-je/", QuiSuisJe.as_view(), name="whoami"),

    # Pages — lecture, création, modification. Jamais de suppression.
    path("pages/", ListeDesPages.as_view(), name="pages"),
    path("pages/creer/", CreationDePage.as_view(), name="page_creer"),
    path("pages/<int:page_id>/", DetailPage.as_view(), name="page"),
    path("pages/<int:page_id>/sections/", SectionsDeLaPage.as_view(), name="page_sections"),
    # Ce que Google mesure. Lecture seule : lancer une analyse consomme un
    # quota facturé, et une boucle d'agent le viderait en une après-midi.
    path("pages/<int:page_id>/mesures/", MesuresDeLaPage.as_view(), name="page_mesures"),

    # Sections
    path("sections/<int:section_id>/", DetailSection.as_view(), name="section"),
    path("sections/<int:section_id>/lignes/", LignesDeLaSection.as_view(), name="section_lignes"),

    # Lignes
    path("lignes/<int:ligne_id>/", DetailLigne.as_view(), name="ligne"),
    path("lignes/<int:ligne_id>/blocs/", BlocsDeLaLigne.as_view(), name="ligne_blocs"),

    # Blocs
    path("blocs/<int:bloc_id>/", DetailBloc.as_view(), name="bloc"),
    path("blocs/<int:bloc_id>/contenu/", ContenuDuBloc.as_view(), name="bloc_contenu"),

    # Déplacer un élément — un seul point d'entrée pour les trois niveaux.
    # `position` n'est volontairement pas modifiable par PATCH : l'écrire à la
    # main produirait deux éléments au même rang.
    path("deplacer/<str:niveau>/<int:element_id>/", Deplacement.as_view(), name="deplacer"),

    # Médiathèque — lecture seule. Le téléversement reste dans
    # l'administration, où s'appliquent les validateurs de S-10.
    path("images/", ListeDesImages.as_view(), name="images"),

    # Calendrier. On ne crée pas un créneau : on déclare une DISPONIBILITÉ,
    # qui les génère. Un créneau posé à la main serait effacé au prochain
    # passage de génération — voir l'en-tête de vues_calendrier.py.
    path("rdv/types/", ListeDesTypesDeRdv.as_view(), name="rdv_types"),
    path("rdv/types/creer/", CreationTypeDeRdv.as_view(), name="rdv_type_creer"),
    path("rdv/types/<int:type_id>/", DetailTypeDeRdv.as_view(), name="rdv_type"),
    path("rdv/disponibilites/", ListeDesDisponibilites.as_view(),
         name="rdv_disponibilites"),
    path("rdv/disponibilites/creer/", CreationDisponibilite.as_view(),
         name="rdv_disponibilite_creer"),
    path("rdv/disponibilites/<int:dispo_id>/", DetailDisponibilite.as_view(),
         name="rdv_disponibilite"),
    # Les créneaux se LISENT seulement : ils découlent d'une disponibilité,
    # et tout réglage posé sur eux serait défait à la prochaine génération.
    path("rdv/creneaux/", ListeDesCreneaux.as_view(), name="rdv_creneaux"),
    path("rdv/", ListeDesRendezVous.as_view(), name="rdv"),

    # Menus — la structure et les liens, pas le design. L'affectation d'un
    # menu à une catégorie est ce qui fait les sous-sites.
    path("menus/", ListeDesMenus.as_view(), name="menus"),
    path("menus/creer/", CreationMenu.as_view(), name="menu_creer"),
    path("menus/<int:menu_id>/", DetailMenu.as_view(), name="menu"),
    path("categories/<int:categorie_id>/menus/", MenusDeLaCategorie.as_view(),
         name="categorie_menus"),

    # Identité visuelle du site — couleurs du thème et polices. Un seul
    # point d'entrée : ce n'est pas du contenu mais ce qui décide de quoi tout
    # le contenu a l'air.
    path("identite/", Identite.as_view(), name="identite"),

    # E-mails transactionnels. Le corps est une PAGE : il se construit avec
    # les mêmes routes que le reste du site. Aucune route vers les journaux
    # d'envoi, qui portent les adresses des destinataires.
    path("emails/evenements/", ListeDesEvenements.as_view(), name="email_evenements"),
    path("emails/", ListeDesEmails.as_view(), name="emails"),
    path("emails/creer/", CreationEmail.as_view(), name="email_creer"),
    path("emails/<int:email_id>/", DetailEmail.as_view(), name="email"),

    # Questionnaires experts — définir le test, ses profils, ses questions et
    # leurs poids. Aucune route de suppression, et aucune vers les passages :
    # ceux-ci contiennent des réponses de personnes identifiables.
    path("questionnaires/", ListeDesQuestionnaires.as_view(), name="questionnaires"),
    path("questionnaires/creer/", CreationQuestionnaire.as_view(),
         name="questionnaire_creer"),
    path("questionnaires/<int:test_id>/", DetailQuestionnaire.as_view(),
         name="questionnaire"),
    path("questionnaires/<int:test_id>/profils/", ProfilsDuQuestionnaire.as_view(),
         name="questionnaire_profils"),
    path("questionnaires/<int:test_id>/questions/", QuestionsDuQuestionnaire.as_view(),
         name="questionnaire_questions"),
    path("questionnaires/<int:test_id>/combinaisons/",
         CombinaisonsDuQuestionnaire.as_view(), name="questionnaire_combinaisons"),
    path("profils/<int:profil_id>/", DetailProfil.as_view(), name="profil"),
    path("questions/<int:question_id>/", DetailQuestion.as_view(), name="question"),
    path("combinaisons/<int:combinaison_id>/", DetailCombinaison.as_view(),
         name="combinaison"),

    # Catégories de pages — à lire avant de classer une page.
    path("categories/", ListeDesCategories.as_view(), name="categories"),
    path("categories/creer/", CreationCategorie.as_view(), name="categorie_creer"),

    # Modèles de fiche — le contrat à lire avant de créer quoi que ce soit :
    # quels types existent, et quels champs les composent.
    path("modeles/", ListeDesModeles.as_view(), name="modeles"),
    path("modeles/creer/", CreationModele.as_view(), name="modele_creer"),
    path("modeles/<int:modele_id>/", DetailModele.as_view(), name="modele"),

    # Types de produit — la couche commerciale, reliée à un type de fiche.
    path("types-de-produit/", ListeDesTypesDeProduit.as_view(), name="types_produit"),
    path("types-de-produit/creer/", CreationTypeDeProduit.as_view(),
         name="type_produit_creer"),
    path("types-de-produit/<int:type_id>/", DetailTypeDeProduit.as_view(),
         name="type_produit"),

    # Fiches (objets personnalisés). Pas de suppression, comme pour les pages.
    path("objets/", ListeDesObjets.as_view(), name="objets"),
    path("objets/creer/", CreationObjet.as_view(), name="objet_creer"),
    path("objets/<int:objet_id>/", DetailObjet.as_view(), name="objet"),

    # Produits — le commerce d'une fiche : référence, prix, TVA, stock.
    path("produits/", ListeDesProduits.as_view(), name="produits"),
    path("produits/creer/", CreationProduit.as_view(), name="produit_creer"),
    path("produits/<int:produit_id>/", DetailProduit.as_view(), name="produit"),
]
