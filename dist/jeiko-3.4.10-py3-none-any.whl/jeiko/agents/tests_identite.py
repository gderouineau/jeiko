# jeiko/agents/tests_identite.py
"""
L'identité visuelle : couleurs du thème et polices, par l'API.

Ce qui rend cette surface différente des autres
------------------------------------------------
Une erreur de contenu abîme une page. **Une erreur d'identité les abîme toutes
en même temps**, sans qu'aucune page en particulier paraisse en cause — on
cherche le défaut dans le gabarit, dans le CSS, dans le cache, et il est dans
une valeur de police changée trois jours plus tôt.

Deux conséquences, que ces tests verrouillent :

* **la modification est partielle, toujours.** Envoyer la seule couleur
  d'accent ne doit pas remettre les neuf autres à leur défaut, et régler la
  taille du `h1` sur téléphone ne doit toucher ni sa famille ni le `h1` des
  autres appareils. Sans cela, changer une valeur obligerait à en renvoyer 330,
  et la première oubliée repartirait à zéro ;
* **les valeurs sont assainies.** Elles finissent dans des déclarations CSS
  générées (`--jk-accent: …;` sur `:root`) : un point-virgule y ouvrirait une
  déclaration de plus.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration.models import Theme, WebSite

from .tests import SocleMixin, donner_le_role

IDENTITE = "/api/agent/v1/identite/"


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class SocleIdentite(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user,
            "view_website", "change_website", "view_theme", "add_theme",
            "change_theme", "view_fonts", "change_fonts", "view_font",
            "add_font", "change_font",
            app="administration", nom="Rôle de test design",
        )
        self.site = WebSite.objects.first()

    def _patch(self, corps):
        return self.client.patch(
            IDENTITE, data=json.dumps(corps), content_type="application/json",
            **self.entetes(self.jeton),
        )


class LectureTests(SocleIdentite):
    def test_l_identite_se_lit_avec_ses_variables_css(self):
        lu = self.client.get(IDENTITE, **self.entetes(self.jeton)).json()["identite"]
        self.assertIn("couleurs", lu)
        self.assertIn("polices", lu)
        self.assertEqual(
            sorted(lu["polices"]), ["ordinateur", "tablette", "telephone"]
        )

    def test_les_variables_css_portent_les_noms_reels(self):
        """
        Ce sont ces noms qu'un agent écrira dans du CSS personnalisé :
        `var(--jk-accent)`. Les taire l'obligerait à les deviner.
        """
        lu = self.client.get(IDENTITE, **self.entetes(self.jeton)).json()["identite"]
        if lu["variables_css"]:
            self.assertIn("--jk-accent", lu["variables_css"])


class ModificationPartielleTests(SocleIdentite):
    def test_changer_une_couleur_laisse_les_autres(self):
        self._patch({"couleurs": {"accent": "rgb(180, 83, 9)",
                                  "secondaire": "#123456"}})
        self._patch({"couleurs": {"accent": "#ff0000"}})

        theme = Theme.objects.get(pk=WebSite.objects.first().theme_id)
        self.assertEqual(theme.accent, "#ff0000")
        self.assertEqual(
            theme.secondaire, "#123456",
            "Changer une couleur a remis les autres à leur défaut : il "
            "faudrait renvoyer les dix pour en changer une.",
        )

    def test_changer_une_police_laisse_les_autres_appareils(self):
        reponse = self._patch({"polices": {
            "telephone": {"h1": {"taille": "28px"}},
        }})
        self.assertEqual(reponse.status_code, 200)

        site = WebSite.objects.select_related(
            "fonts_phone__h1", "fonts_computer__h1"
        ).first()
        self.assertEqual(site.fonts_phone.h1.size, "28px")
        self.assertNotEqual(
            site.fonts_computer.h1.size, "28px",
            "Le réglage d'un appareil a débordé sur les autres.",
        )

    def test_changer_un_attribut_laisse_les_autres(self):
        self._patch({"polices": {
            "ordinateur": {"h1": {"famille": "Playfair Display", "taille": "48px"}}
        }})
        self._patch({"polices": {"ordinateur": {"h1": {"taille": "52px"}}}})

        police = WebSite.objects.select_related("fonts_computer__h1").first(
        ).fonts_computer.h1
        self.assertEqual(police.size, "52px")
        self.assertEqual(police.family, "Playfair Display")


class RefusTests(SocleIdentite):
    def test_un_role_de_couleur_inconnu_est_refuse(self):
        """
        Les couleurs se nomment par leur RÔLE. « bleu » n'en est pas un, et
        l'accepter en silence donnerait un thème qui ne change rien.
        """
        reponse = self._patch({"couleurs": {"bleu": "#0000ff"}})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("accent", reponse.json()["erreur"])

    def test_un_appareil_inconnu_est_refuse(self):
        reponse = self._patch({"polices": {"montre": {"h1": {"taille": "8px"}}}})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("telephone", reponse.json()["erreur"])

    def test_un_role_de_police_inconnu_est_refuse(self):
        reponse = self._patch({"polices": {"ordinateur": {"h9": {"taille": "8px"}}}})
        self.assertEqual(reponse.status_code, 400)

    def test_une_cle_de_premier_niveau_inconnue_est_refusee(self):
        reponse = self._patch({"logo": 3})
        self.assertEqual(reponse.status_code, 400)


class AssainissementTests(SocleIdentite):
    def test_une_couleur_ne_peut_pas_ouvrir_une_declaration(self):
        """
        La valeur finit dans `--jk-accent: …;` sur `:root`. Un point-virgule
        y ajouterait une déclaration choisie par l'appelant.
        """
        self._patch({"couleurs": {"accent": "red; --jk-fond: black"}})
        theme = Theme.objects.get(pk=WebSite.objects.first().theme_id)
        self.assertNotIn(";", theme.accent)

    def test_une_police_est_assainie_de_meme(self):
        self._patch({"polices": {
            "ordinateur": {"h1": {"famille": "Arial; color: red"}}
        }})
        police = WebSite.objects.select_related("fonts_computer__h1").first(
        ).fonts_computer.h1
        self.assertNotIn(";", police.family)


class PermissionTests(SocleIdentite):
    def test_lire_ne_suffit_pas_pour_ecrire(self):
        autre, jeton = self.creer(nom="Lecteur seul")
        donner_le_role(
            autre.user, "view_website",
            app="administration", nom="Rôle lecture identité",
        )
        reponse = self.client.patch(
            IDENTITE, data=json.dumps({"couleurs": {"accent": "#000"}}),
            content_type="application/json", **self.entetes(jeton),
        )
        self.assertEqual(reponse.status_code, 403)
