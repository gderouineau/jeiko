# jeiko/agents/vues_api.py
"""
Socle des vues de l'API : entrée, sortie, et refus uniformes.

Trois choses valent d'être expliquées.

**La permission est obligatoire, pas optionnelle.** `VueAgent` refuse de
répondre si la sous-classe n'a pas déclaré `permission_requise`. Une vue qu'on
oublie de garder est le défaut le plus banal d'une API — et il est invisible,
puisque tout fonctionne. Ici l'oubli produit une erreur immédiate, sur le
premier appel, en développement.

**Le corps est du JSON, et sa taille est bornée.** Un agent envoie du JSON ;
accepter autre chose n'apporte rien et élargit la surface. La borne évite qu'un
appel unique fasse allouer un document arbitrairement gros.

**Les erreurs se ressemblent toutes.** Un objet `{"erreur": "…"}` et un code
HTTP juste. Les vues ne renvoient jamais une trace ni un message d'exception :
ils décrivent l'intérieur du système à quelqu'un qui n'a pas à le connaître.
"""

import json
import logging

from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt

from .authentification import exige_un_agent

logger = logging.getLogger(__name__)

#: 1 Mio. Un arbre de page complet tient très largement dedans ; au-delà, c'est
#: qu'il se passe autre chose.
TAILLE_MAX_CORPS = 1024 * 1024


def ok(donnees=None, statut=200):
    return JsonResponse(donnees if donnees is not None else {}, status=statut)


def erreur(message, statut=400, **extra):
    corps = {"erreur": message}
    corps.update(extra)
    return JsonResponse(corps, status=statut)


#: Sentinelle : cette vue se contente d'un agent authentifié, sans permission
#: supplémentaire. Écrite en toutes lettres pour qu'on ne la confonde pas avec
#: un oubli — c'est toute la différence entre un choix et une négligence, et la
#: seule qui se voie à la relecture.
AUTHENTIFICATION_SEULE = "authentification-seule"


class CorpsInvalide(Exception):
    """Le corps de la requête n'est pas exploitable. Porte le message à rendre."""


@method_decorator(csrf_exempt, name="dispatch")
@method_decorator(never_cache, name="dispatch")
@method_decorator(exige_un_agent, name="dispatch")
class VueAgent(View):
    """
    Base de toute vue de l'API.

    L'exemption CSRF est sûre ICI et seulement ici : ces vues n'acceptent que
    l'en-tête `Authorization`, jamais la session. Voir `authentification.py`.
    """

    #: À déclarer dans chaque sous-classe. `None` fait échouer la vue.
    permission_requise = None

    def dispatch(self, request, *args, **kwargs):
        if not self.permission_requise:
            logger.error(
                "%s ne déclare pas de `permission_requise` : appel refusé.",
                type(self).__name__,
            )
            return erreur(
                "Cette ressource est mal configurée côté serveur.", statut=500
            )

        if self.permission_requise != AUTHENTIFICATION_SEULE and not request.user.has_perm(
            self.permission_requise
        ):
            return erreur(
                "Cet agent n'a pas le droit d'effectuer cette action.",
                statut=403,
                permission_manquante=self.permission_requise,
            )

        try:
            return super().dispatch(request, *args, **kwargs)
        except CorpsInvalide as souci:
            return erreur(str(souci), statut=400)

    # ------------------------------------------------------------------ #
    #  Lecture du corps
    # ------------------------------------------------------------------ #
    def corps(self, request, *, obligatoire=True):
        """Le corps JSON de la requête, en dictionnaire."""
        brut = request.body or b""

        if len(brut) > TAILLE_MAX_CORPS:
            raise CorpsInvalide("Corps de requête trop volumineux.")

        if not brut:
            if obligatoire:
                raise CorpsInvalide("Un corps JSON est attendu.")
            return {}

        try:
            donnees = json.loads(brut.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            raise CorpsInvalide("Le corps doit être du JSON valide, encodé en UTF-8.")

        if not isinstance(donnees, dict):
            raise CorpsInvalide("Le corps doit être un objet JSON.")
        return donnees

    def http_method_not_allowed(self, request, *args, **kwargs):
        return erreur("Méthode non autorisée sur cette ressource.", statut=405)


class Guide(VueAgent):
    """
    Le mode d'emploi de l'API, à l'adresse racine.

    Sans permission : c'est de la documentation, et un agent doit pouvoir la
    lire avant qu'on lui ait accordé quoi que ce soit. Lui refuser le mode
    d'emploi tant qu'il n'a pas de rôle reviendrait à lui demander de deviner
    ce qu'il a le droit de demander.
    """

    permission_requise = AUTHENTIFICATION_SEULE

    def get(self, request):
        from .guide import construire

        return ok(construire())


class QuiSuisJe(VueAgent):
    """
    Carte d'identité de l'agent : qui il est, et ce qu'il a le droit de faire.

    Premier appel utile d'un agent : il lui évite de découvrir ses droits en
    se heurtant à des 403, et rend le diagnostic immédiat quand un rôle a été
    mal assigné.
    """

    #: Aucune permission : un agent doit pouvoir vérifier que son jeton
    #: fonctionne AVANT qu'on lui ait donné le moindre rôle. Exiger une
    #: permission ici ferait répondre 403 à un jeton parfaitement valide, et
    #: enverrait chercher la panne du mauvais côté.
    permission_requise = AUTHENTIFICATION_SEULE

    def get(self, request):
        agent = request.agent
        permissions = sorted(request.user.get_all_permissions())

        return ok({
            "agent": {
                "nom": agent.nom,
                "description": agent.description,
                "expire_le": agent.expire_le.isoformat() if agent.expire_le else None,
            },
            "roles": [
                assignation.role.name
                for assignation in agent.user.role_assignments.select_related("role")
            ],
            "permissions": permissions,
            "peut": {
                "creer_une_page": request.user.has_perm("administration_pages.add_page"),
                "modifier_une_page": request.user.has_perm(
                    "administration_pages.change_page"
                ),
                # Toujours faux : l'API ne propose aucune suppression de page.
                # Dit explicitement pour qu'un agent ne la cherche pas.
                "supprimer_une_page": False,
            },
            "jeton": {"prefixe": request.jeton_agent.prefixe},
        })
