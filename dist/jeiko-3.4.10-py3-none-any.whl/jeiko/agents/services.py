# jeiko/agents/services.py
"""
Création et cycle de vie d'un agent, en un seul endroit.

Un agent n'existe pas sans son compte porteur, et ce compte n'est pas un compte
ordinaire : il ne doit jamais pouvoir se connecter par le formulaire. Trois
précautions, prises ici pour qu'aucun écran n'ait à y penser :

* `set_unusable_password()` — aucun mot de passe ne peut correspondre ;
* pas d'adresse confirmée — avec `ACCOUNT_EMAIL_VERIFICATION = "mandatory"`,
  allauth refuserait la connexion de toute façon. Ceinture et bretelles ;
* `is_staff` et `is_superuser` restent faux — les droits passent par les rôles,
  jamais par le statut, sans quoi « donner un rôle à un agent » cesserait d'être
  la seule vérité sur ce qu'il peut faire.

Le nom d'utilisateur est préfixé `agent-` : sur l'écran des utilisateurs, on
doit voir d'un coup d'œil qu'une ligne n'est pas une personne.
"""

import re

from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils.text import slugify

from .models import Agent, AgentToken

#: Préfixe du compte porteur. Change le tri et rend la nature du compte lisible.
PREFIXE_COMPTE = "agent-"


def _identifiant_libre(nom):
    """Un `username` disponible, dérivé du nom de l'agent."""
    User = get_user_model()
    base = slugify(nom)[:100] or "sans-nom"
    candidat = f"{PREFIXE_COMPTE}{base}"

    if not User.objects.filter(username=candidat).exists():
        return candidat

    for suffixe in range(2, 100):
        essai = f"{candidat}-{suffixe}"
        if not User.objects.filter(username=essai).exists():
            return essai

    raise RuntimeError("Impossible de trouver un identifiant de compte libre.")


@transaction.atomic
def creer_agent(*, nom, description="", expire_le=None, ips_autorisees="", cree_par=None):
    """
    Crée l'agent, son compte porteur et son premier jeton.

    Renvoie `(agent, jeton_en_clair)`. Le jeton n'est lisible qu'ici : voir
    `jetons.py` pour la raison.
    """
    User = get_user_model()

    compte = User.objects.create(
        username=_identifiant_libre(nom),
        email="",
        is_active=True,
        is_staff=False,
        is_superuser=False,
    )
    compte.set_unusable_password()
    compte.save(update_fields=["password"])

    agent = Agent.objects.create(
        nom=nom,
        description=description,
        user=compte,
        expire_le=expire_le,
        ips_autorisees=ips_autorisees or "",
        cree_par=cree_par,
    )

    _, en_clair = AgentToken.creer(agent, libelle="Jeton initial", cree_par=cree_par)
    return agent, en_clair


@transaction.atomic
def reinitialiser_le_jeton(agent, *, libelle="", par=None, revoquer_les_anciens=True):
    """
    Fabrique un nouveau jeton et révoque les précédents.

    `revoquer_les_anciens=False` permet une rotation sans coupure : on crée le
    nouveau, on bascule l'appelant, puis on révoque l'ancien à la main. Par
    défaut on révoque, parce qu'on réinitialise le plus souvent après une
    divulgation — et dans ce cas laisser l'ancien vivant n'aurait aucun sens.
    """
    if revoquer_les_anciens:
        for ancien in agent.jetons_actifs():
            ancien.revoquer()

    _, en_clair = AgentToken.creer(agent, libelle=libelle, cree_par=par)
    return en_clair


def desactiver(agent):
    """Coupure immédiate, sans rien perdre de l'historique."""
    agent.actif = False
    agent.save(update_fields=["actif", "maj_le"])
