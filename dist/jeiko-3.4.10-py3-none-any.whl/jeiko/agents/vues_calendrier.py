# jeiko/agents/vues_calendrier.py
"""
Le calendrier — types de rendez-vous, disponibilités, créneaux, réservations.

Comment ça marche, et pourquoi ça change la forme de cette API
---------------------------------------------------------------
On ne crée pas un créneau : **on déclare une disponibilité**, et le calendrier
en dérive les créneaux. `Availability` porte une plage (début, fin) et une
règle de récurrence ; `generate_slots()` en produit les `Slot` pour chaque
type de rendez-vous associé, et **nettoie ceux qui sortent de la plage**.

Conséquence directe : un créneau créé à la main serait effacé au prochain
passage de génération. L'API n'en propose donc pas la création — elle
propose la disponibilité, qui est le geste qui tient. Ce n'est pas une
restriction de prudence, c'est le seul chemin qui produise un résultat stable.

Les créneaux ne sont donc **jamais écrits par cette API** — seulement lus,
pour répondre à « qu'est-ce qui est libre jeudi ». Fermer un créneau à la main
le désynchroniserait de la plage qui le produit, et la prochaine régénération
déferait le réglage sans le dire. Le geste de « je ne suis pas disponible ce
jeudi-là » est une **date exclue** sur la disponibilité.

La suppression, et pourquoi elle est gardée
--------------------------------------------
`Appointment.slot` est en CASCADE, et `Slot.availability` aussi. Supprimer une
disponibilité efface donc ses créneaux, **et les rendez-vous déjà pris
dessus** — c'est-à-dire des personnes qui se sont déplacées, ou vont le faire.
Silencieusement, et sans que rien ne le rattrape.

L'API refuse donc de supprimer une disponibilité qui porte des réservations, et
dit quoi faire à la place : la fermer, ce qui libère les créneaux à venir sans
toucher au passé.

Les données personnelles
------------------------
`Appointment` porte le nom et l'adresse e-mail du client. La lecture des
rendez-vous est donc **une permission à part** (`view_appointment`), et non un
effet de bord du droit de gérer le calendrier : une clé qui pose des créneaux
n'a pas à lire qui a réservé. Aucune route ne les modifie ni ne les supprime.
"""

from datetime import timedelta

from django.db import transaction
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from jeiko.calendars.models import (
    Appointment, AppointmentType, Availability, Slot,
)

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR_TYPE = "calendars.view_appointmenttype"
AJOUTER_TYPE = "calendars.add_appointmenttype"
MODIFIER_TYPE = "calendars.change_appointmenttype"
VOIR_DISPO = "calendars.view_availability"
AJOUTER_DISPO = "calendars.add_availability"
MODIFIER_DISPO = "calendars.change_availability"
SUPPRIMER_DISPO = "calendars.delete_availability"
VOIR_RDV = "calendars.view_appointment"

CLES_TYPE = {
    "nom", "duree_minutes", "description", "payant", "prix",
    "inscription_requise", "capacite", "places_max_par_reservation",
    "liste_d_attente", "couleur",
}
CLES_DISPO = {
    "debut", "fin", "types", "regle_de_recurrence", "ouverte",
    "dates_exclues",
}


# --------------------------------------------------------------------------- #
#  Sérialisation
# --------------------------------------------------------------------------- #
def _type_en_dict(type_rdv):
    return {
        "id": type_rdv.id,
        "nom": type_rdv.name,
        "duree_minutes": int(type_rdv.duration.total_seconds() // 60),
        "description": type_rdv.description or "",
        "payant": type_rdv.is_paid,
        "prix": str(type_rdv.price) if type_rdv.price is not None else None,
        "inscription_requise": type_rdv.is_registration_required,
        "capacite": type_rdv.capacity,
        "places_max_par_reservation": type_rdv.max_places_per_booking,
        "liste_d_attente": type_rdv.allow_waitlist,
        "couleur": type_rdv.color or "",
    }


def _dispo_en_dict(dispo):
    return {
        "id": dispo.id,
        "debut": dispo.start.isoformat() if dispo.start else None,
        "fin": dispo.end.isoformat() if dispo.end else None,
        "ouverte": dispo.is_available,
        "regle_de_recurrence": dispo.recurring_rule or "",
        "dates_exclues": dispo.recurrence_exdates or [],
        "types": list(dispo.appointment_types.values_list("id", flat=True)),
        "nombre_de_creneaux": dispo.slots.count(),
    }


def _creneau_en_dict(creneau):
    return {
        "id": creneau.id,
        "type": creneau.type_id,
        "disponibilite": creneau.availability_id,
        "debut": creneau.start.isoformat(),
        "fin": creneau.end.isoformat(),
        "ouvert": creneau.is_available,
        "capacite": creneau.capacity,
        "places_restantes": creneau.remaining_places,
    }


def _rdv_en_dict(rdv):
    return {
        "id": rdv.id,
        "type": rdv.type_id,
        "creneau": rdv.slot_id,
        "debut": rdv.start.isoformat() if rdv.start else None,
        "fin": rdv.end.isoformat() if rdv.end else None,
        "client": rdv.client_name or "",
        "email": rdv.email or "",
        "places": rdv.places,
        "paye": rdv.is_paid,
        "cree_le": rdv.created.isoformat() if rdv.created else None,
    }


# --------------------------------------------------------------------------- #
#  Aides
# --------------------------------------------------------------------------- #
def _refuser_les_cles(corps, connues, quoi):
    inconnues = sorted(set(corps) - set(connues))
    if inconnues:
        raise CorpsInvalide(
            f"Clé(s) inconnue(s) pour {quoi} : {', '.join(inconnues)}. "
            f"Acceptées : {', '.join(sorted(connues))}."
        )


def _instant(valeur, quoi):
    """
    Une date-heure ISO, rendue consciente du fuseau.

    Une date naïve enregistrée telle quelle décale tous les créneaux d'une
    disponibilité, et le décalage ne se voit qu'en comparant à l'agenda réel.
    """
    if not valeur:
        raise CorpsInvalide(f"« {quoi} » est obligatoire (date-heure ISO).")

    instant = parse_datetime(str(valeur))
    if instant is None:
        raise CorpsInvalide(
            f"« {quoi} » n'est pas une date-heure ISO lisible : « {valeur} ». "
            f"Exemple : 2026-09-15T09:00:00+02:00."
        )
    if timezone.is_naive(instant):
        instant = timezone.make_aware(instant)
    return instant


# --------------------------------------------------------------------------- #
#  Types de rendez-vous
# --------------------------------------------------------------------------- #
class ListeDesTypesDeRdv(VueAgent):
    permission_requise = VOIR_TYPE

    def get(self, request):
        types = AppointmentType.objects.order_by("name")
        return ok({"types": [_type_en_dict(t) for t in types]})


class CreationTypeDeRdv(VueAgent):
    permission_requise = AJOUTER_TYPE

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_TYPE, "un type de rendez-vous")

        nom = str(corps.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide("« nom » est obligatoire.")

        minutes = corps.get("duree_minutes")
        if not minutes:
            raise CorpsInvalide(
                "« duree_minutes » est obligatoire : c'est elle qui découpe "
                "les disponibilités en créneaux."
            )

        type_rdv = AppointmentType(name=nom[:200], duration=timedelta(minutes=int(minutes)))
        _ecrire_le_type(type_rdv, corps)
        type_rdv.save()
        return ok({"type": _type_en_dict(type_rdv)}, statut=201)


def _ecrire_le_type(type_rdv, corps):
    if "nom" in corps:
        type_rdv.name = str(corps["nom"]).strip()[:200]
    if "duree_minutes" in corps:
        type_rdv.duration = timedelta(minutes=int(corps["duree_minutes"]))
    if "description" in corps:
        type_rdv.description = str(corps["description"])
    if "payant" in corps:
        type_rdv.is_paid = bool(corps["payant"])
    if "prix" in corps:
        type_rdv.price = corps["prix"] or 0
    if "inscription_requise" in corps:
        type_rdv.is_registration_required = bool(corps["inscription_requise"])
    if "capacite" in corps:
        type_rdv.capacity = int(corps["capacite"])
    if "places_max_par_reservation" in corps:
        type_rdv.max_places_per_booking = int(corps["places_max_par_reservation"])
    if "liste_d_attente" in corps:
        type_rdv.allow_waitlist = bool(corps["liste_d_attente"])
    if "couleur" in corps:
        type_rdv.color = str(corps["couleur"])[:50]

    # Une réservation qui dépasse la capacité du créneau serait refusée à
    # l'inscription, sans que le réglage ait l'air fautif.
    if type_rdv.max_places_per_booking > type_rdv.capacity:
        raise CorpsInvalide(
            f"« places_max_par_reservation » ({type_rdv.max_places_per_booking}) "
            f"dépasse « capacite » ({type_rdv.capacity}) : aucune réservation "
            f"de cette taille ne pourrait aboutir."
        )


class DetailTypeDeRdv(VueAgent):
    permission_requise = VOIR_TYPE

    def get(self, request, type_id):
        return ok({"type": _type_en_dict(get_object_or_404(AppointmentType, pk=type_id))})

    @transaction.atomic
    def patch(self, request, type_id):
        if not request.user.has_perm(MODIFIER_TYPE):
            return erreur("Modification de type non autorisée.", statut=403)

        type_rdv = get_object_or_404(AppointmentType, pk=type_id)
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_TYPE, "un type de rendez-vous")

        _ecrire_le_type(type_rdv, corps)
        type_rdv.save()
        return ok({"type": _type_en_dict(type_rdv)})


# --------------------------------------------------------------------------- #
#  Disponibilités — le geste qui produit les créneaux
# --------------------------------------------------------------------------- #
class ListeDesDisponibilites(VueAgent):
    permission_requise = VOIR_DISPO

    def get(self, request):
        dispos = Availability.objects.prefetch_related(
            "appointment_types"
        ).order_by("start")
        return ok({"disponibilites": [_dispo_en_dict(d) for d in dispos]})


class CreationDisponibilite(VueAgent):
    """
    Déclare une plage disponible, et génère ses créneaux.

    C'est le geste utile : « tous les jeudis de 9 h à 12 h, pour ce type de
    rendez-vous ». Les créneaux en découlent, découpés à la durée du type.
    """

    permission_requise = AJOUTER_DISPO

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_DISPO, "une disponibilité")

        debut = _instant(corps.get("debut"), "debut")
        fin = _instant(corps.get("fin"), "fin")
        if fin <= debut:
            raise CorpsInvalide(
                "« fin » doit suivre « debut » : une plage vide ne produirait "
                "aucun créneau."
            )

        types = _types_demandes(corps.get("types"))

        dispo = Availability.objects.create(
            start=debut, end=fin,
            recurring_rule=str(corps.get("regle_de_recurrence") or ""),
            recurrence_exdates=corps.get("dates_exclues") or [],
            is_available=bool(corps.get("ouverte", True)),
        )
        dispo.appointment_types.set(types)
        dispo.generate_slots()

        dispo.refresh_from_db()
        return ok({"disponibilite": _dispo_en_dict(dispo)}, statut=201)


def _types_demandes(identifiants):
    if not identifiants:
        raise CorpsInvalide(
            "« types » est obligatoire : sans type associé, aucun créneau "
            "n'est produit — c'est la durée du type qui découpe la plage."
        )
    if not isinstance(identifiants, list):
        raise CorpsInvalide("« types » doit être une liste d'identifiants.")

    types = list(AppointmentType.objects.filter(pk__in=identifiants))
    manquants = sorted(set(identifiants) - {t.id for t in types})
    if manquants:
        raise CorpsInvalide(
            f"Type(s) de rendez-vous inconnu(s) : {manquants}. "
            f"Voir /rdv/types/."
        )
    return types


class DetailDisponibilite(VueAgent):
    permission_requise = VOIR_DISPO

    def get(self, request, dispo_id):
        dispo = get_object_or_404(
            Availability.objects.prefetch_related("appointment_types"), pk=dispo_id
        )
        return ok({"disponibilite": _dispo_en_dict(dispo)})

    @transaction.atomic
    def patch(self, request, dispo_id):
        if not request.user.has_perm(MODIFIER_DISPO):
            return erreur("Modification de disponibilité non autorisée.", statut=403)

        dispo = get_object_or_404(Availability, pk=dispo_id)
        corps = self.corps(request)
        _refuser_les_cles(corps, CLES_DISPO, "une disponibilité")

        if "debut" in corps:
            dispo.start = _instant(corps["debut"], "debut")
        if "fin" in corps:
            dispo.end = _instant(corps["fin"], "fin")
        if dispo.end <= dispo.start:
            raise CorpsInvalide("« fin » doit suivre « debut ».")

        if "regle_de_recurrence" in corps:
            dispo.recurring_rule = str(corps["regle_de_recurrence"] or "")
        if "dates_exclues" in corps:
            dispo.recurrence_exdates = corps["dates_exclues"] or []
        if "ouverte" in corps:
            dispo.is_available = bool(corps["ouverte"])

        dispo.save()
        if "types" in corps:
            dispo.appointment_types.set(_types_demandes(corps["types"]))

        # La régénération recalcule les créneaux et ferme ceux qui sortent de
        # la plage : sans elle, changer les horaires laisserait réservables des
        # créneaux qui n'existent plus.
        dispo.generate_slots()

        dispo.refresh_from_db()
        return ok({"disponibilite": _dispo_en_dict(dispo)})

    @transaction.atomic
    def delete(self, request, dispo_id):
        if not request.user.has_perm(SUPPRIMER_DISPO):
            return erreur("Suppression de disponibilité non autorisée.", statut=403)

        dispo = get_object_or_404(Availability, pk=dispo_id)

        # `Slot.availability` et `Appointment.slot` sont en CASCADE : supprimer
        # cette plage effacerait les rendez-vous pris dessus. Des personnes qui
        # se sont déplacées, ou vont le faire, et que plus rien ne rattrape.
        reserves = Appointment.objects.filter(slot__availability=dispo).count()
        if reserves:
            raise CorpsInvalide(
                f"Cette plage porte {reserves} rendez-vous : la supprimer les "
                f"effacerait. La FERMER (« ouverte »: false) libère les "
                f"créneaux à venir sans toucher à ce qui est réservé."
            )

        dispo.delete()
        return ok({"supprime": True})


# --------------------------------------------------------------------------- #
#  Créneaux — on les lit, on les ferme, on ne les crée pas
# --------------------------------------------------------------------------- #
class ListeDesCreneaux(VueAgent):
    """
    Les créneaux, filtrables par type et par période.

    **Lecture seule.** Un créneau n'est pas une chose qu'on règle : c'est le
    résultat d'une disponibilité. Le créer serait effacé au prochain
    `generate_slots()` ; l'ouvrir ou le fermer à la main désynchroniserait
    l'agenda de la plage qui le produit, et la prochaine régénération
    déferait le réglage sans le dire.

    Tout se pilote donc par la disponibilité : sa plage, sa récurrence, ses
    dates exclues, son ouverture. Les créneaux suivent.
    """

    permission_requise = VOIR_DISPO

    def get(self, request):
        creneaux = Slot.objects.select_related("type").order_by("start")

        if request.GET.get("type"):
            creneaux = creneaux.filter(type_id=request.GET["type"])
        if request.GET.get("depuis"):
            creneaux = creneaux.filter(
                start__gte=_instant(request.GET["depuis"], "depuis")
            )
        if request.GET.get("jusqu_a"):
            creneaux = creneaux.filter(
                start__lte=_instant(request.GET["jusqu_a"], "jusqu_a")
            )
        if request.GET.get("ouverts") == "1":
            creneaux = creneaux.filter(is_available=True)

        return ok({"creneaux": [_creneau_en_dict(c) for c in creneaux[:500]]})


# --------------------------------------------------------------------------- #
#  Rendez-vous — lecture seule
# --------------------------------------------------------------------------- #
class ListeDesRendezVous(VueAgent):
    """
    Les rendez-vous pris, filtrables par période et par type.

    **Lecture seule, et permission à part.** Ces enregistrements portent le nom
    et l'adresse du client : une clé qui pose des créneaux n'a pas à lire qui a
    réservé. Aucune route ne les modifie ni ne les annule — une annulation
    doit prévenir la personne, ce qui n'est pas le travail de cette API.
    """

    permission_requise = VOIR_RDV

    def get(self, request):
        rdv = Appointment.objects.select_related("type", "slot").order_by("start")

        if request.GET.get("type"):
            rdv = rdv.filter(type_id=request.GET["type"])
        if request.GET.get("depuis"):
            rdv = rdv.filter(start__gte=_instant(request.GET["depuis"], "depuis"))
        if request.GET.get("jusqu_a"):
            rdv = rdv.filter(start__lte=_instant(request.GET["jusqu_a"], "jusqu_a"))

        return ok({"rendez_vous": [_rdv_en_dict(r) for r in rdv[:500]]})
