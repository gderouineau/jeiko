# jeiko/agents/tests_bouton_panier.py
"""
Un bouton « ajouter au panier » doit pouvoir désigner SON produit.

Le manque, trouvé en construisant
----------------------------------
`ContentButton` porte `product_target` — « Produit cible (si manuel) » — et
`custom_object_target`. **Ni l'un ni l'autre n'était exposé par l'API.**

Sur une page MODÈLE, cela ne se voyait pas : le produit se déduit de la fiche
affichée, et le bouton posé sur le gabarit des formules fonctionnait
parfaitement. Mais sur une page ordinaire — une page de tarifs, une page
d'accueil — il n'y a rien à déduire. Le bouton s'affichait, et ne faisait rien.

C'est la panne muette habituelle, à ceci près qu'ici elle coûte une vente : le
visiteur clique, rien ne se passe, il s'en va.

Ce que ces tests gardent
------------------------
* la cible se désigne par **référence** (et la fiche par slug), et la
  relecture rend la même chose — un identifiant obligerait l'appelant à
  traduire avant de réécrire ;
* une référence inconnue est refusée, en disant où chercher ;
* un bouton panier SANS cible est accepté — il est légitime sur un gabarit —
  mais la réponse **avertit**, parce que c'est le seul moment où quelqu'un
  peut encore le corriger.
"""

import json
from decimal import Decimal

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Bloc, Line, Page, Section
from jeiko.custom_objects.models import CustomObject, CustomObjectModel
from jeiko.shop.models import Product, ProductType

from .tests import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class CibleDuBoutonTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent pages pour panier",
        )

        gabarit = Page.objects.create(
            title="Gabarit", url_tag="gab-panier", is_custom_object_template=True
        )
        modele = CustomObjectModel.objects.create(
            name="Formule", slug="formule-panier", page_template=gabarit,
            is_product=True,
        )
        type_produit = ProductType.objects.create(
            name="Abonnement", code="abo-panier", kind=ProductType.KIND_SERVICE,
            is_physical=False, requires_shipping=False, content_model=modele,
        )
        self.fiche = CustomObject.objects.create(
            model=modele, title="Équipe", slug="equipe-panier", is_published=True
        )
        self.produit = Product.objects.create(
            type=type_produit, content=self.fiche, sku="JEIKO-EQUIPE-P",
            price_ht=Decimal("39.00"), is_active=True,
        )

        page = Page.objects.create(title="Tarifs", url_tag="tarifs-panier")
        section = Section.objects.create(page=page, position=0)
        ligne = Line.objects.create(
            section=section, position=0, columns_type="12", columns_number=1
        )
        self.bloc = Bloc.objects.create(
            line=ligne, position=1, position_in_column=0
        )

    def _poser(self, bouton):
        return self.client.put(
            f"/api/agent/v1/blocs/{self.bloc.id}/contenu/",
            data=json.dumps({"type": "BUTTON", "bouton": bouton}),
            content_type="application/json", **self.entetes(self.jeton),
        )

    def _relire(self):
        return self.client.get(
            f"/api/agent/v1/blocs/{self.bloc.id}/", **self.entetes(self.jeton)
        ).json()["bloc"]["contenu"]["bouton"]

    def test_le_produit_cible_se_designe_par_sa_reference(self):
        reponse = self._poser({
            "libelle": "Ajouter au panier",
            "ajouter_au_panier": True,
            "produit_cible": "JEIKO-EQUIPE-P",
        })
        self.assertEqual(reponse.status_code, 200)

        self.bloc.refresh_from_db()
        self.assertEqual(
            self.bloc.content.content_button.product_target, self.produit,
            "Sans cible, le bouton s'affiche sur une page ordinaire et ne "
            "fait rien : le visiteur clique, et s'en va.",
        )

    def test_la_relecture_rend_la_reference(self):
        self._poser({"libelle": "Acheter", "ajouter_au_panier": True,
                     "produit_cible": "JEIKO-EQUIPE-P"})
        self.assertEqual(self._relire()["produit_cible"], "JEIKO-EQUIPE-P")

    def test_la_fiche_cible_se_designe_par_son_slug(self):
        self._poser({"libelle": "Voir", "fiche_cible": "equipe-panier"})
        self.bloc.refresh_from_db()
        self.assertEqual(
            self.bloc.content.content_button.custom_object_target, self.fiche
        )

    def test_une_reference_inconnue_est_refusee_en_disant_ou_chercher(self):
        reponse = self._poser({
            "libelle": "Acheter", "ajouter_au_panier": True,
            "produit_cible": "REF-QUI-N-EXISTE-PAS",
        })
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("/produits/", reponse.json()["erreur"])

    def test_on_peut_retirer_la_cible(self):
        self._poser({"libelle": "Acheter", "ajouter_au_panier": True,
                     "produit_cible": "JEIKO-EQUIPE-P"})
        self._poser({"libelle": "Acheter", "produit_cible": None})
        self.bloc.refresh_from_db()
        self.assertIsNone(self.bloc.content.content_button.product_target)

    def test_un_bouton_panier_sans_cible_est_accepte_mais_averti(self):
        """
        Il est LÉGITIME sur un gabarit — le produit vient de la fiche. Le
        refuser casserait le cas normal. Mais l'accepter en silence laisse
        poser des boutons morts sur les pages ordinaires : on avertit, au seul
        moment où quelqu'un peut encore corriger.
        """
        reponse = self._poser({"libelle": "Acheter", "ajouter_au_panier": True})
        self.assertEqual(reponse.status_code, 200)
        self.assertIn("_avertissement", self._relire())
        self.assertIn("page MODÈLE", self._relire()["_avertissement"])

    def test_un_bouton_avec_cible_n_est_pas_averti(self):
        self._poser({"libelle": "Acheter", "ajouter_au_panier": True,
                     "produit_cible": "JEIKO-EQUIPE-P"})
        self.assertNotIn("_avertissement", self._relire())
