# jeiko/agents/tests_champs_de_page.py
"""
Tous les champs d'une page, y compris son classement et ses métadonnées.

Ce qui manquait
---------------
Un agent pouvait créer une page et en écrire le contenu, mais pas la CLASSER
(catégorie, sous-catégorie) ni déclarer sa nature (page d'accueil, gabarit de
fiche). Il s'arrêtait donc au milieu, laissant le reste à faire à la main —
et les pages qu'il créait restaient hors de tout classement, donc invisibles
des blocs qui filtrent par catégorie.

Les métadonnées, elles, n'étaient écrivables qu'APRÈS coup. Une page publiée
sans titre ni description de recherche part avec un handicap que personne ne
revient corriger : le bon moment pour les écrire est la création, pendant
qu'on sait de quoi la page parle.

Ce qui reste fermé, et pourquoi
--------------------------------
`is_protected` gouverne l'ACCÈS à la page, pas son contenu. Le confier à un
jeton reviendrait à laisser un agent retirer la protection d'une page réservée
— ou en protéger une par erreur, ce qui la ferait disparaître pour les
visiteurs sans que rien ne l'explique.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Category, Page

from .tests import SocleMixin, donner_le_role

PAGES = "/api/agent/v1/pages/"
CATEGORIES = "/api/agent/v1/categories/"


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class ChampsDePageTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent pages",
        )
        self.categorie = Category.objects.create(name="Services", slug="services")
        self.sous = Category.objects.create(
            name="Électricité", slug="electricite", main_category=self.categorie
        )

    def _patch(self, page, corps):
        return self.client.patch(
            f"{PAGES}{page.id}/", data=json.dumps(corps),
            content_type="application/json", **self.entetes(self.jeton),
        )

    # --- Classement ----------------------------------------------------- #
    def test_une_page_se_classe_par_slug(self):
        page = Page.objects.create(title="Essai", url_tag="essai-classement")
        reponse = self._patch(page, {"categorie": "services",
                                     "sous_categorie": "electricite"})
        self.assertEqual(reponse.status_code, 200)

        page.refresh_from_db()
        self.assertEqual(page.category, self.categorie)
        self.assertEqual(page.sub_category, self.sous)

    def test_la_relecture_rend_les_slugs(self):
        page = Page.objects.create(
            title="Essai", url_tag="essai-relecture", category=self.categorie
        )
        lu = self.client.get(f"{PAGES}{page.id}/", **self.entetes(self.jeton)).json()
        self.assertEqual(lu["page"]["categorie"], "services")
        self.assertIsNone(lu["page"]["sous_categorie"])

    def test_une_categorie_inconnue_est_refusee_en_listant_les_connues(self):
        page = Page.objects.create(title="Essai", url_tag="essai-inconnue")
        reponse = self._patch(page, {"categorie": "plomberie"})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("services", reponse.json()["erreur"])

    def test_on_peut_declasser_une_page(self):
        page = Page.objects.create(
            title="Essai", url_tag="essai-declassement", category=self.categorie
        )
        self._patch(page, {"categorie": None})
        page.refresh_from_db()
        self.assertIsNone(page.category)

    # --- Nature de la page ---------------------------------------------- #
    def test_les_drapeaux_de_nature_sont_ouverts(self):
        page = Page.objects.create(title="Essai", url_tag="essai-nature")
        self._patch(page, {"racine": True, "gabarit_de_fiche": True})
        page.refresh_from_db()
        self.assertTrue(page.is_root)
        self.assertTrue(page.is_custom_object_template)

    def test_la_protection_reste_fermee(self):
        """
        `protegee` se lit, ne s'écrit pas : c'est un contrôle d'accès.
        """
        page = Page.objects.create(title="Essai", url_tag="essai-protection")
        reponse = self._patch(page, {"protegee": True})
        self.assertEqual(reponse.status_code, 400)
        page.refresh_from_db()
        self.assertFalse(page.is_protected)

    # --- Métadonnées ---------------------------------------------------- #
    def test_les_metadonnees_s_ecrivent_des_la_creation(self):
        reponse = self.json_post(f"{PAGES}creer/", {
            "titre": "Nos formules",
            "url_tag": "nos-formules-test",
            "metadonnees": {"titre": "Nos formules — JEIKO",
                            "description": "Trois formules, le même outil."},
            "categorie": "services",
        }, self.jeton)
        self.assertEqual(reponse.status_code, 201)

        page = Page.objects.get(url_tag="nos-formules-test")
        self.assertEqual(page.metadata.title, "Nos formules — JEIKO")
        self.assertEqual(page.category, self.categorie)
        self.assertFalse(page.active, "Une page créée par un agent naît en brouillon.")


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class CategoriesTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent pages",
        )

    def test_la_liste_donne_les_slugs_et_la_hierarchie(self):
        parente = Category.objects.create(name="Services", slug="services")
        Category.objects.create(name="Électricité", slug="electricite",
                                main_category=parente)

        lu = self.client.get(CATEGORIES, **self.entetes(self.jeton)).json()
        par_slug = {c["slug"]: c for c in lu["categories"]}
        self.assertEqual(par_slug["electricite"]["categorie_parente"], "services")
        self.assertIsNone(par_slug["services"]["categorie_parente"])

    def test_une_categorie_se_cree_sous_une_autre(self):
        self.json_post(f"{CATEGORIES}creer/", {"nom": "Services"}, self.jeton)
        reponse = self.json_post(
            f"{CATEGORIES}creer/",
            {"nom": "Plomberie", "categorie_parente": "services"},
            self.jeton,
        )
        self.assertEqual(reponse.status_code, 201)
        self.assertEqual(
            Category.objects.get(slug="plomberie").main_category.slug, "services"
        )

    def test_un_slug_deja_pris_est_refuse(self):
        self.json_post(f"{CATEGORIES}creer/", {"nom": "Services"}, self.jeton)
        reponse = self.json_post(f"{CATEGORIES}creer/", {"nom": "Services"}, self.jeton)
        self.assertEqual(reponse.status_code, 400)


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class HierarchieEtRacineTests(SocleMixin, TestCase):
    """
    Deux cas que la base accepte et qui n'ont pourtant pas de sens.

    **Une sous-catégorie qui n'appartient pas à sa catégorie.** `category` et
    `sub_category` sont deux clés étrangères indépendantes : rien n'empêche de
    classer une page dans « Services » avec la sous-catégorie « Résultats de
    questionnaire ». Le classement devient incohérent, et personne ne le voit
    avant qu'un listage filtré revienne vide ou trop plein.

    **Une deuxième page racine.** Là, au contraire, la base refuse
    (`only_one_is_root_page`) — mais elle refuse par une `UniqueViolation`,
    c'est-à-dire une erreur 500 : un défaut de l'API rendu comme une panne du
    serveur. On transfère, parce que c'est ce que veut dire la demande.
    """

    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent pages",
        )
        self.services = Category.objects.create(name="Services", slug="services")
        self.elec = Category.objects.create(
            name="Électricité", slug="electricite", main_category=self.services
        )
        self.gabarits = Category.objects.create(name="Gabarits", slug="gabarits")
        self.sous_gabarit = Category.objects.create(
            name="Résultats", slug="resultats", main_category=self.gabarits
        )
        # Une catégorie de REGROUPEMENT : pas de slug, elle n'est dans aucune URL.
        self.regroupement = Category.objects.create(name="Interne", slug=None)

    def _patch(self, page, corps):
        return self.client.patch(
            f"{PAGES}{page.id}/", data=json.dumps(corps),
            content_type="application/json", **self.entetes(self.jeton),
        )

    def test_une_sous_categorie_d_une_autre_branche_est_refusee(self):
        page = Page.objects.create(title="Essai", url_tag="essai-branche")
        reponse = self._patch(page, {"categorie": "services",
                                     "sous_categorie": "resultats"})
        self.assertEqual(reponse.status_code, 400)
        message = reponse.json()["erreur"]
        self.assertIn("gabarits", message)
        page.refresh_from_db()
        self.assertIsNone(page.category, "Rien ne doit être écrit sur un refus.")

    def test_la_bonne_branche_passe(self):
        page = Page.objects.create(title="Essai", url_tag="essai-bonne-branche")
        self.assertEqual(
            self._patch(page, {"categorie": "services",
                               "sous_categorie": "electricite"}).status_code,
            200,
        )

    def test_la_categorie_deja_posee_est_prise_en_compte(self):
        """
        Envoyer la seule sous-catégorie doit se vérifier contre la catégorie
        DÉJÀ enregistrée — sinon le contrôle ne servirait qu'au premier appel.
        """
        page = Page.objects.create(
            title="Essai", url_tag="essai-partiel", category=self.services
        )
        reponse = self._patch(page, {"sous_categorie": "resultats"})
        self.assertEqual(reponse.status_code, 400)

    def test_une_categorie_de_regroupement_s_utilise_par_son_nom(self):
        """
        Sans slug, il reste le nom exact et l'identifiant. Refuser reviendrait
        à rendre inutilisables des catégories parfaitement légitimes.
        """
        page = Page.objects.create(title="Essai", url_tag="essai-regroupement")
        self.assertEqual(
            self._patch(page, {"categorie": "Interne"}).status_code, 200
        )
        page.refresh_from_db()
        self.assertEqual(page.category, self.regroupement)

        autre = Page.objects.create(title="Autre", url_tag="essai-par-id")
        self.assertEqual(
            self._patch(autre, {"categorie": str(self.regroupement.id)}).status_code,
            200,
        )

    def test_declarer_une_nouvelle_racine_transfere_l_ancienne(self):
        # Une page racine existe déjà — posée par une migration. C'est
        # justement la situation réelle : on ne part jamais d'un site sans
        # accueil.
        Page.objects.filter(is_root=True).update(is_root=False)
        ancienne = Page.objects.create(
            title="Accueil", url_tag="accueil-ancien", is_root=True
        )
        nouvelle = Page.objects.create(title="Nouvel accueil", url_tag="accueil-neuf")

        reponse = self._patch(nouvelle, {"racine": True})
        self.assertEqual(
            reponse.status_code, 200,
            "Une deuxième page racine levait une UniqueViolation — donc un 500.",
        )
        ancienne.refresh_from_db()
        nouvelle.refresh_from_db()
        self.assertFalse(ancienne.is_root)
        self.assertTrue(nouvelle.is_root)
