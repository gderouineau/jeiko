# jeiko/tests_uploads.py
"""
Ce qu'on accepte de recevoir — images (S-10) et PDF (S-11).

Les deux défauts que ces tests verrouillent ne se voient pas à l'usage normal :
tout fonctionne, jusqu'au fichier qu'on n'attendait pas.

* Une **bombe de décompression** est un fichier minuscule qui annonce des
  dimensions énormes. `ImageContent.save()` produit cinq variantes en
  redimensionnant : chaque passe déplie l'image en mémoire, quatre octets par
  pixel. Un PNG de 40 Ko annonçant 60 000 × 60 000 réclame quatorze
  gigaoctets. Le garde-fou de Pillow existe, mais à 89 mégapixels — largement
  de quoi mettre à genoux une machine de VPS avant qu'il ne serve.

* Le champ du **PDF de formation** n'avait aucun validateur. Le fichier est
  ensuite renvoyé par `courses.views.client.serve_pdf` depuis le domaine du
  site, sous un `Content-Type` que nous affirmons.

Les en-têtes PNG sont fabriqués à la main : c'est exactement ce que fait une
bombe, et cela permet d'annoncer cent mégapixels sans en allouer un seul.
"""

import struct
import zlib
from io import BytesIO

from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import SimpleTestCase, override_settings
from PIL import Image

from jeiko.uploads import (
    LIMITE_PIXELS_PAR_DEFAUT,
    appliquer_les_limites_pillow,
    valider_l_image,
    valider_le_pdf,
)


def _png_annoncant(largeur, hauteur):
    """
    Un vrai PNG minuscule, dont l'en-tête ment sur ses dimensions.

    C'est la définition même d'une bombe de décompression : le fichier reste
    petit, l'en-tête annonce une image gigantesque, et le mal est fait au
    moment où on la déplie. Pillow lit `size` depuis cet en-tête sans décoder
    un seul pixel — c'est ce qui nous laisse la refuser à temps.

    Réécrire les octets d'un PNG valide plutôt que fabriquer l'en-tête seul :
    Pillow refuse un fichier qui s'arrête après IHDR, et on testerait alors le
    chemin « fichier illisible » en croyant tester le plafond.

    Disposition d'un PNG : 8 octets de signature, puis la taille du bloc (4),
    son type (4), ses données (13 pour IHDR), son CRC (4). La largeur et la
    hauteur sont les huit premiers octets des données, en 16..24 ; le CRC
    porte sur le type et les données, soit 12..29.
    """
    tampon = BytesIO()
    Image.new("RGB", (1, 1)).save(tampon, format="PNG")
    octets = bytearray(tampon.getvalue())

    octets[16:24] = struct.pack(">II", largeur, hauteur)
    octets[29:33] = struct.pack(">I", zlib.crc32(bytes(octets[12:29])))
    return bytes(octets)


def _fichier(nom, contenu, type_mime="application/octet-stream"):
    return SimpleUploadedFile(nom, contenu, content_type=type_mime)


class PlafondPillowTests(SimpleTestCase):
    def test_le_plafond_est_pose_au_demarrage(self):
        """
        `jeiko.apps.ready()` l'applique ; on le vérifie plutôt que de le
        supposer, car c'est une variable globale qu'un autre import pourrait
        remettre à la valeur d'origine.
        """
        appliquer_les_limites_pillow()
        self.assertEqual(Image.MAX_IMAGE_PIXELS, LIMITE_PIXELS_PAR_DEFAUT)
        self.assertLess(
            Image.MAX_IMAGE_PIXELS, 89_478_485,
            "le plafond est remonté à la valeur par défaut de Pillow.",
        )


class ImagesTests(SimpleTestCase):
    def setUp(self):
        appliquer_les_limites_pillow()

    def test_une_image_ordinaire_passe(self):
        # 1920 × 1080, la taille d'une image de site : 2 Mpx.
        valider_l_image(_fichier("photo.png", _png_annoncant(1920, 1080), "image/png"))

    def test_une_image_au_dessus_de_25_mpx_est_refusee(self):
        # 6000 × 5000 = 30 Mpx : au-dessus de notre plafond, en dessous du
        # double, donc Pillow ne dirait rien. C'est nous qui tranchons.
        with self.assertRaises(ValidationError) as leve:
            valider_l_image(
                _fichier("enorme.png", _png_annoncant(6000, 5000), "image/png")
            )
        self.assertIn("6000", str(leve.exception))

    def test_une_bombe_de_decompression_est_refusee(self):
        """
        60 octets qui en réclament quarante gigaoctets à l'ouverture.

        Au-delà du double du plafond, c'est Pillow qui lève — on vérifie que
        son exception ressort en erreur de formulaire lisible, et non en 500.
        """
        bombe = _png_annoncant(100_000, 100_000)  # 10 000 Mpx
        self.assertLess(len(bombe), 100, "la bombe doit rester minuscule")
        with self.assertRaises(ValidationError):
            valider_l_image(_fichier("bombe.png", bombe, "image/png"))

    @override_settings(JEIKO_MAX_IMAGE_UPLOAD_MB=1)
    def test_une_image_trop_lourde_est_refusee(self):
        """
        Le plafond en pixels ne dit rien du poids : un JPEG de 200 Mo tient
        dans 25 Mpx.
        """
        with self.assertRaises(ValidationError) as leve:
            valider_l_image(_fichier("lourde.png", b"x" * (2 * 1024 * 1024)))
        self.assertIn("lourde", str(leve.exception).lower())

    def test_un_fichier_illisible_ne_leve_pas_ici(self):
        """
        `ImageField` dira mieux que nous qu'un fichier n'est pas une image.

        Lever ici masquerait son message par le nôtre, moins précis.
        """
        valider_l_image(_fichier("pas-une-image.png", b"bonjour"))


class PdfTests(SimpleTestCase):
    PDF_MINIMAL = b"%PDF-1.4\n1 0 obj\n<<>>\nendobj\ntrailer\n<<>>\n%%EOF\n"

    def test_un_vrai_pdf_passe(self):
        valider_le_pdf(_fichier("cours.pdf", self.PDF_MINIMAL, "application/pdf"))

    def test_un_html_deguise_en_pdf_est_refuse(self):
        """
        Le cœur de S-11.

        `serve_pdf` renvoie le fichier depuis le domaine du site. Un document
        HTML servi sous ce nom s'exécuterait dans l'origine du site si le
        navigateur reniflait le contenu. `SECURE_CONTENT_TYPE_NOSNIFF` l'en
        empêche — mais c'est un réglage, dans un autre fichier, qu'un site peut
        perdre. La signature, elle, ne dépend d'aucun réglage.
        """
        faux = b"<html><script>alert(document.cookie)</script></html>"
        with self.assertRaises(ValidationError):
            valider_le_pdf(_fichier("piege.pdf", faux, "application/pdf"))

    @override_settings(JEIKO_MAX_PDF_UPLOAD_MB=1)
    def test_un_pdf_trop_lourd_est_refuse(self):
        gros = self.PDF_MINIMAL + b"0" * (2 * 1024 * 1024)
        with self.assertRaises(ValidationError):
            valider_le_pdf(_fichier("gros.pdf", gros, "application/pdf"))

    def test_le_curseur_est_rendu_ou_il_etait(self):
        """
        Le validateur lit le début du fichier ; s'il ne remet pas le curseur,
        l'enregistrement qui suit écrit un fichier amputé de ses cinq premiers
        octets — un PDF valide devenu illisible, sans la moindre erreur.
        """
        fichier = _fichier("cours.pdf", self.PDF_MINIMAL, "application/pdf")
        valider_le_pdf(fichier)
        fichier.seek(0)
        self.assertEqual(fichier.read(), self.PDF_MINIMAL)
