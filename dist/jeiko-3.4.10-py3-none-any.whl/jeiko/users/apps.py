from django.apps import AppConfig


class UsersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko.users'

    def ready(self):
        import jeiko.users.signals
        # Journal de sécurité et suivi des sessions, branchés sur les signaux
        # d'authentification (cf. security_log.py).
        import jeiko.users.security_log  # noqa: F401

