from django.contrib.auth.backends import BaseBackend
from django.contrib.auth.models import Permission
from django.db.models import Q
from django.utils import timezone


def _active_assignments(user_obj):
    """
    Assignations de rôles actives pour l'utilisateur :
    - rôle actif,
    - non expirées (expires_at nul ou dans le futur).
    """
    now = timezone.now()
    return user_obj.role_assignments.filter(
        Q(expires_at__isnull=True) | Q(expires_at__gt=now),
        role__is_active=True,
    )


class RolePermissionBackend(BaseBackend):
    """
    Donne des permissions via les rôles (Role ↔ RoleAssignment ↔ Permission).
    Ne gère PAS l'authentification (authenticate retourne None).

    Deux façons d'obtenir des droits :
    - un rôle « super-rôle » (is_superrole) accorde TOUTES les permissions ;
    - sinon, l'union des permissions attachées aux rôles actifs assignés.
    Les assignations expirées (expires_at dépassé) sont ignorées.
    """

    def authenticate(self, request, **credentials):
        return None

    def _has_superrole(self, user_obj):
        return _active_assignments(user_obj).filter(role__is_superrole=True).exists()

    def has_perm(self, user_obj, perm, obj=None):
        if not user_obj or not user_obj.is_active:
            return False
        if user_obj.is_superuser:
            return True
        if self._has_superrole(user_obj):
            return True
        if not perm or "." not in perm:
            return False
        app_label, codename = perm.split(".", 1)
        now = timezone.now()
        return user_obj.role_assignments.filter(
            Q(expires_at__isnull=True) | Q(expires_at__gt=now),
            role__is_active=True,
            role__permissions__content_type__app_label=app_label,
            role__permissions__codename=codename,
        ).exists()

    def has_module_perms(self, user_obj, app_label):
        if not user_obj or not user_obj.is_active:
            return False
        if user_obj.is_superuser:
            return True
        if self._has_superrole(user_obj):
            return True
        return _active_assignments(user_obj).filter(
            role__permissions__content_type__app_label=app_label,
        ).exists()

    def get_all_permissions(self, user_obj, obj=None):
        if not user_obj or not user_obj.is_active:
            return set()
        if user_obj.is_superuser or self._has_superrole(user_obj):
            # Renvoie toutes les perms "app.codename"
            qs = Permission.objects.all().values_list(
                "content_type__app_label", "codename"
            )
            return {f"{a}.{c}" for a, c in qs}
        now = timezone.now()
        qs = Permission.objects.filter(
            Q(roles__assignments__expires_at__isnull=True)
            | Q(roles__assignments__expires_at__gt=now),
            roles__assignments__user=user_obj,
            roles__is_active=True,
        ).values_list("content_type__app_label", "codename").distinct()
        return {f"{a}.{c}" for a, c in qs}
