"""
Redirection vers une destination fournie par la requête (S-12).

Le problème
-----------
Six écrans acceptaient un paramètre `next` — pour ramener l'administrateur là
d'où il venait — et le passaient tel quel à `redirect()`. Rien ne vérifiait
qu'il désignait bien ce site.

    /administration/cache/clear?next=https://site-piege.example/connexion

Le lien part de votre domaine, porte votre certificat, et dépose l'utilisateur
sur une copie de votre page de connexion. C'est une redirection ouverte : elle
ne casse rien, ne lève rien, et n'existe que dans un lien envoyé par courriel.

Pourquoi `url_has_allowed_host_and_scheme` et pas un test maison
---------------------------------------------------------------
Le seul écran qui vérifiait quelque chose faisait :

    if back.startswith('/') and not back.startswith('//'):

Cela paraît suffisant, et cela ne l'est pas : ``/\\site-piege.example`` commence
par une barre oblique et pas par deux, donc il passe — et les navigateurs
traitent la barre oblique inverse comme une barre oblique à cet endroit. La
destination est bien externe.

Django résout ce genre de détail depuis quinze ans, dans la fonction qui garde
son propre `next` de connexion. On l'utilise, plutôt que de refaire le
raisonnement à six endroits.

Ce que cela ne fait pas
-----------------------
Cela n'autorise pas moins qu'avant sur les cas légitimes : un chemin relatif du
site passe. Cela ne dit rien non plus des droits sur la page d'arrivée — la
destination reste une page du site, protégée par ses propres gardes.
"""

from django.utils.http import url_has_allowed_host_and_scheme


def destination_sure(request, cible, defaut):
    """
    Renvoie `cible` si elle désigne ce site, sinon `defaut`.

    `defaut` peut être un chemin comme un nom de route : la valeur rendue est
    destinée à `redirect()`, qui accepte les deux. C'est ce qui permet de
    remplacer les appels existants sans toucher à leur repli.
    """
    if cible and url_has_allowed_host_and_scheme(
        url=cible,
        allowed_hosts={request.get_host()},
        require_https=request.is_secure(),
    ):
        return cible
    return defaut
