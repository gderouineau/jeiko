"""
Réconciliation des commandes avec Stripe.

Le webhook n'ayant jamais été joignable, seules les commandes dont le client
est resté sur l'onglet après paiement ont été honorées. Les autres ont été
réglées côté Stripe mais sont restées `pending` chez nous — accès jamais
accordés, stock jamais décrémenté.

On ne peut pas partir de la commande : l'Order ne mémorise pas l'ID du
PaymentIntent. On balaie donc les PaymentIntents `succeeded` de Stripe, on lit
leur `metadata.order_id`, et on rejoue `mark_order_paid` sur les commandes
encore en attente. Le service étant idempotent, repasser sur une commande déjà
réglée ne fait rien.

Garde-fou : on ne règle une commande que si le montant encaissé correspond au
total attendu. Un écart (panier modifié après création de l'intent, devise…)
est signalé et laissé de côté, jamais honoré automatiquement.
"""

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterator, Optional

from django.utils import timezone

from jeiko.shop.models import Order
from jeiko.shop.services import mark_order_paid, to_minor_units

# États d'une ligne de rapport.
RECONCILED = "reconciled"          # commande réglée par cet appel
WOULD_RECONCILE = "would_reconcile"  # à régler (mode dry-run)
ALREADY_PAID = "already_paid"      # déjà réglée, rien à faire
ORDER_MISSING = "order_missing"    # order_id inconnu en base
AMOUNT_MISMATCH = "amount_mismatch"  # montant encaissé ≠ total commande


@dataclass
class Result:
    status: str
    intent_id: str
    order_id: Optional[str] = None
    detail: str = ""


def _iter_succeeded_intents(stripe_module, *, created_after=None, page_size=100):
    """
    Parcourt les PaymentIntents `succeeded` portant un `order_id`.

    Isolé pour être mocké dans les tests : c'est le seul point qui parle au
    réseau. `created_after` est un timestamp Unix (bornage par date).
    """
    params = {"limit": page_size}
    if created_after is not None:
        params["created"] = {"gte": int(created_after)}

    for intent in stripe_module.PaymentIntent.list(**params).auto_paging_iter():
        if intent.get("status") != "succeeded":
            continue
        metadata = intent.get("metadata") or {}
        if not metadata.get("order_id"):
            # Les rendez-vous du module calendars portent
            # `jeiko_appointment_id`, pas `order_id` : ils sont ignorés ici.
            continue
        yield intent


def reconcile_orders(stripe_module, *, dry_run=True, days=None, limit=None):
    """
    Rapproche les PaymentIntents `succeeded` des commandes.

    Retourne la liste des Result. En dry-run, aucune écriture : les commandes à
    régler ressortent en WOULD_RECONCILE.
    """
    created_after = None
    if days:
        created_after = (timezone.now() - timezone.timedelta(days=days)).timestamp()

    results = []
    for intent in _iter_succeeded_intents(stripe_module, created_after=created_after):
        results.append(_reconcile_one(intent, dry_run=dry_run))
        if limit and len(results) >= limit:
            break
    return results


def _reconcile_one(intent, *, dry_run):
    intent_id = intent.get("id", "?")
    order_id = (intent.get("metadata") or {}).get("order_id")

    order = (
        Order.objects
        .filter(pk=order_id)
        .prefetch_related("lines")
        .first()
    )
    if order is None:
        return Result(ORDER_MISSING, intent_id, order_id,
                      "Aucune commande pour cet order_id.")

    if order.payment_status == Order.PAYMENT_STATUS_PAID:
        return Result(ALREADY_PAID, intent_id, order_id)

    # Le montant encaissé doit correspondre au total de la commande. Un écart
    # veut dire que le panier a bougé entre la création de l'intent et le
    # paiement : on ne devine pas, on signale.
    attendu = to_minor_units(order.total_ttc)
    encaisse = int(intent.get("amount_received") or intent.get("amount") or 0)
    if encaisse != attendu:
        return Result(
            AMOUNT_MISMATCH, intent_id, order_id,
            f"Encaissé {encaisse} c ≠ total commande {attendu} c "
            f"({Decimal(encaisse) / 100} vs {order.total_ttc}).",
        )

    if dry_run:
        return Result(WOULD_RECONCILE, intent_id, order_id,
                      f"À régler : {order.total_ttc} {order.currency}.")

    mark_order_paid(order, source="reconcile")
    return Result(RECONCILED, intent_id, order_id,
                  f"Réglée : {order.total_ttc} {order.currency}.")
