"""
Rapproche les commandes JEIKO des paiements Stripe.

Utile après une période où le webhook n'a pas fonctionné : retrouve les
commandes réglées côté Stripe mais restées `pending` en base, et les honore
(accès, stock, verrouillage du panier).

    # Voir sans rien changer (recommandé en premier) :
    manage.py jeiko_payments_reconcile_orders --dry-run

    # Se limiter aux 30 derniers jours :
    manage.py jeiko_payments_reconcile_orders --dry-run --days 30

    # Appliquer :
    manage.py jeiko_payments_reconcile_orders

Sans risque à relancer : le règlement est idempotent, une commande déjà payée
est laissée telle quelle. Les écarts de montant ne sont jamais réglés
automatiquement — ils sont signalés pour vérification manuelle.
"""

from django.core.management.base import BaseCommand, CommandError

from jeiko.payments import reconcile
from jeiko.payments.services.stripe import StripeService


class Command(BaseCommand):
    help = "Réconcilie les commandes en attente avec les paiements Stripe réussis."

    def add_arguments(self, parser):
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Liste les commandes à régler sans rien modifier.",
        )
        parser.add_argument(
            "--days", type=int, default=None,
            help="Ne regarder que les paiements des N derniers jours.",
        )
        parser.add_argument(
            "--limit", type=int, default=None,
            help="S'arrêter après N paiements examinés.",
        )

    def handle(self, *args, **options):
        import stripe

        service = StripeService()
        if not service.gateway:
            raise CommandError("Aucune passerelle Stripe configurée.")
        if not service.gateway.secret_key:
            raise CommandError("La clé secrète Stripe n'est pas renseignée.")

        dry_run = options["dry_run"]
        results = reconcile.reconcile_orders(
            stripe,
            dry_run=dry_run,
            days=options["days"],
            limit=options["limit"],
        )

        self._print_report(results, dry_run=dry_run)

    def _print_report(self, results, *, dry_run):
        compteurs = {}
        for r in results:
            compteurs[r.status] = compteurs.get(r.status, 0) + 1

        # Détail : on met en avant ce qui demande une action ou un regard.
        for r in results:
            ligne = f"[{r.status}] intent={r.intent_id} order={r.order_id or '-'}"
            if r.detail:
                ligne += f" — {r.detail}"

            if r.status in (reconcile.RECONCILED, reconcile.WOULD_RECONCILE):
                self.stdout.write(self.style.SUCCESS(ligne))
            elif r.status in (reconcile.AMOUNT_MISMATCH, reconcile.ORDER_MISSING):
                self.stdout.write(self.style.WARNING(ligne))
            else:  # already_paid : bruit de fond, on le laisse discret
                self.stdout.write(ligne)

        # Synthèse
        self.stdout.write("")
        examines = len(results)
        a_regler = (
            compteurs.get(reconcile.WOULD_RECONCILE, 0)
            + compteurs.get(reconcile.RECONCILED, 0)
        )
        self.stdout.write(f"Paiements examinés      : {examines}")
        self.stdout.write(f"Déjà réglées            : {compteurs.get(reconcile.ALREADY_PAID, 0)}")
        self.stdout.write(self.style.WARNING(
            f"Écarts de montant       : {compteurs.get(reconcile.AMOUNT_MISMATCH, 0)}"
        ))
        self.stdout.write(self.style.WARNING(
            f"Commandes introuvables  : {compteurs.get(reconcile.ORDER_MISSING, 0)}"
        ))

        if dry_run:
            self.stdout.write(self.style.WARNING(
                f"À régler                : {a_regler} "
                f"— relancer sans --dry-run pour appliquer."
            ))
        else:
            self.stdout.write(self.style.SUCCESS(
                f"Commandes réglées       : {a_regler}"
            ))
