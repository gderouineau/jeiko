import stripe
from django.conf import settings

from jeiko.shop.services import to_minor_units

from ..models import PaymentGateway

class StripeService:
    def __init__(self):
        self.gateway = PaymentGateway.objects.filter(code='stripe').first()
        if self.gateway:
            stripe.api_key = self.gateway.secret_key

    def create_payment_intent(self, amount, currency='eur', metadata=None):
        if not self.gateway or not self.gateway.is_active:
            raise Exception("Stripe gateway is not active or configured")
        
        try:
            intent = stripe.PaymentIntent.create(
                # Arrondi au centime avant conversion : int() seul tronquait
                # (cf. jeiko.shop.services.to_minor_units).
                amount=to_minor_units(amount),
                currency=currency,
                metadata=metadata or {}
            )
            return intent
        except stripe.error.StripeError as e:
            # Handle error
            raise e

    def construct_event(self, payload, sig_header):
        if not self.gateway:
             raise Exception("Stripe gateway is not configured")
        
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, self.gateway.webhook_secret
            )
            return event
        except ValueError as e:
            # Invalid payload
            raise e
        except stripe.error.SignatureVerificationError as e:
            # Invalid signature
            raise e
