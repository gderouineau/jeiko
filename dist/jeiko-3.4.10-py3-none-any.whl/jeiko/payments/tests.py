"""
Tests de jeiko.payments.

L'écran de configuration des passerelles manipule les clés Stripe en clair :
son contrôle d'accès est la première chose à vérifier.

Les tests de webhook simulent l'événement signé (construct_event mocké) pour
exercer le trajet vue → service → dispatcher → mark_order_paid sans réseau ni
serveur public. Seule la vérification de signature de Stripe reste hors de
portée : elle ne peut être validée que sur un serveur réel.
"""

from decimal import Decimal
from unittest import mock

from django.contrib.auth import get_user_model
from django.test import TestCase

from jeiko.payments.models import PaymentGateway

User = get_user_model()

WEBHOOK_URL = "/shop/webhook/stripe/"

# Emplacement où le service construit l'évènement : c'est le seul point à
# neutraliser pour se passer d'une vraie signature Stripe.
CONSTRUCT_EVENT = "stripe.Webhook.construct_event"

SECRET_KEY = "sk_test_valeur_secrete_a_ne_pas_divulguer"
WEBHOOK_SECRET = "whsec_valeur_secrete_a_ne_pas_divulguer"


class GatewayAccessTests(TestCase):
    def setUp(self):
        self.gateway = PaymentGateway.objects.create(
            name="Stripe",
            code="stripe",
            is_active=True,
            api_key="pk_test_publique",
            secret_key=SECRET_KEY,
            webhook_secret=WEBHOOK_SECRET,
        )
        self.liste = "/administration/payments/gateways/"
        self.fiche = f"/administration/payments/gateways/{self.gateway.pk}/"

    def test_anonyme_refuse(self):
        # 403 et non redirection vers la connexion : c'est l'effet de
        # raise_exception = True, et la convention de tout le reste de
        # l'administration JEIKO.
        for url in (self.liste, self.fiche):
            self.assertEqual(self.client.get(url).status_code, 403)

    def test_utilisateur_simple_refuse(self):
        """
        Un compte client ordinaire ne doit pas atteindre l'écran : le
        formulaire y rend les clés Stripe en clair (PasswordInput avec
        render_value=True les écrit dans l'attribut value).
        """
        User.objects.create_user("client", "c@example.test", "pw")
        self.client.login(username="client", password="pw")

        for url in (self.liste, self.fiche):
            response = self.client.get(url)
            self.assertEqual(response.status_code, 403, f"{url} accessible")
            corps = response.content.decode()
            self.assertNotIn(SECRET_KEY, corps)
            self.assertNotIn(WEBHOOK_SECRET, corps)

    def test_staff_sans_role_refuse(self):
        """is_staff ne suffit pas : il faut la permission, comme ailleurs."""
        User.objects.create_user("staffeur", "s@example.test", "pw", is_staff=True)
        self.client.login(username="staffeur", password="pw")
        self.assertEqual(self.client.get(self.fiche).status_code, 403)

    def test_superuser_autorise(self):
        User.objects.create_user(
            "boss", "b@example.test", "pw", is_staff=True, is_superuser=True
        )
        self.client.login(username="boss", password="pw")
        self.assertEqual(self.client.get(self.fiche).status_code, 200)

    def test_les_secrets_ne_repartent_jamais_au_navigateur(self):
        """Même pour un superuser autorisé : la clé enregistrée ne se relit pas."""
        User.objects.create_user(
            "boss", "b@example.test", "pw", is_staff=True, is_superuser=True
        )
        self.client.login(username="boss", password="pw")
        corps = self.client.get(self.fiche).content.decode()
        self.assertNotIn(SECRET_KEY, corps)
        self.assertNotIn(WEBHOOK_SECRET, corps)
        self.assertIn("pk_test_publique", corps)  # la clé publique, elle, s'affiche


class GatewayFormTests(TestCase):
    def setUp(self):
        self.gateway = PaymentGateway.objects.create(
            name="Stripe", code="stripe", is_active=True,
            api_key="pk_test", secret_key=SECRET_KEY,
            webhook_secret=WEBHOOK_SECRET,
        )

    def _donnees(self, **extra):
        base = {
            "name": "Stripe", "code": "stripe", "is_active": "on",
            "api_key": "pk_test", "secret_key": "", "webhook_secret": "",
            "test_mode": "on",
        }
        base.update(extra)
        return base

    def test_champ_vide_conserve_la_cle_existante(self):
        from jeiko.payments.forms import PaymentGatewayForm

        form = PaymentGatewayForm(self._donnees(), instance=self.gateway)
        self.assertTrue(form.is_valid(), form.errors)
        gateway = form.save()
        self.assertEqual(gateway.secret_key, SECRET_KEY)
        self.assertEqual(gateway.webhook_secret, WEBHOOK_SECRET)

    def test_valeur_saisie_remplace_la_cle(self):
        from jeiko.payments.forms import PaymentGatewayForm

        form = PaymentGatewayForm(
            self._donnees(webhook_secret="whsec_nouveau"), instance=self.gateway
        )
        self.assertTrue(form.is_valid(), form.errors)
        gateway = form.save()
        self.assertEqual(gateway.webhook_secret, "whsec_nouveau")
        self.assertEqual(gateway.secret_key, SECRET_KEY)  # l'autre est intacte


class GatewayModelTests(TestCase):
    def test_une_seule_passerelle_active(self):
        a = PaymentGateway.objects.create(name="A", code="stripe", is_active=True)
        PaymentGateway.objects.create(name="B", code="paypal", is_active=True)
        a.refresh_from_db()
        self.assertFalse(a.is_active)


class StripeWebhookTests(TestCase):
    """
    Trajet complet du webhook, signature Stripe neutralisée.

    On mocke `stripe.Webhook.construct_event` : c'est la frontière exacte entre
    ce qui dépend d'un secret réel (la vérification cryptographique) et ce que
    JEIKO contrôle (routage de l'URL, dispatch, règlement de la commande). Tout
    le reste s'exécute pour de vrai, y compris mark_order_paid.
    """

    def setUp(self):
        from jeiko.administration_pages.models import Page
        from jeiko.custom_objects.models import CustomObject, CustomObjectModel
        from jeiko.shop.models import (
            Cart, Order, OrderLine, Product, ProductType,
        )

        # La passerelle doit exister : StripeService la charge à l'init, et
        # construct_event refuse de tourner sans elle.
        PaymentGateway.objects.create(
            name="Stripe", code="stripe", is_active=True,
            secret_key="sk_test", webhook_secret="whsec_test",
        )

        page = Page.objects.create(
            title="Gabarit", url_tag="gabarit", active=True,
            is_custom_object_template=True,
        )
        com = CustomObjectModel.objects.create(
            name="Produit", slug="produit", page_template=page, is_product=True,
        )
        ptype = ProductType.objects.create(
            name="Objet", code="objet", content_model=com,
            kind=ProductType.KIND_PHYSICAL, requires_shipping=True,
        )
        contenu = CustomObject.objects.create(
            model=com, title="Mug", slug="mug", is_published=True,
        )
        self.product = Product.objects.create(
            type=ptype, content=contenu, sku="mug-1",
            price_ht=Decimal("10.00"), tax_rate=Decimal("20.00"),
            stock_quantity=7, is_active=True,
        )

        self.user = User.objects.create_user("client", "c@example.test", "pw")
        self.cart = Cart.objects.create(user=self.user)
        self.order = Order.objects.create(user=self.user, cart=self.cart)
        OrderLine.objects.create(
            order=self.order, product=self.product, label="Mug", sku="mug-1",
            quantity=2, unit_price_ht=Decimal("10.00"), tax_rate=Decimal("20.00"),
        )

    def _event(self, event_type, order_id, intent_id="pi_test_1"):
        obj = {"id": intent_id, "metadata": {}}
        if order_id is not None:
            obj["metadata"]["order_id"] = str(order_id)
        return {"type": event_type, "data": {"object": obj}}

    def _post(self, event):
        # construct_event renvoie l'évènement tout construit : la signature
        # n'est jamais vérifiée, le corps et l'en-tête peuvent être bidon.
        with mock.patch(CONSTRUCT_EVENT, return_value=event):
            return self.client.post(
                WEBHOOK_URL,
                data=b"{}",
                content_type="application/json",
                HTTP_STRIPE_SIGNATURE="t=1,v1=peu-importe",
            )

    def test_paiement_reussi_regle_la_commande(self):
        from jeiko.shop.models import Order, ProductStockMovement

        response = self._post(
            self._event("payment_intent.succeeded", self.order.pk)
        )
        self.assertEqual(response.status_code, 200)

        self.order.refresh_from_db()
        self.product.refresh_from_db()
        self.assertEqual(self.order.payment_status, Order.PAYMENT_STATUS_PAID)
        self.assertEqual(self.order.order_status, Order.ORDER_STATUS_CONFIRMED)
        self.assertEqual(self.product.stock_quantity, 5)  # 7 - 2
        self.assertEqual(ProductStockMovement.objects.count(), 1)
        self.assertTrue(self.order.cart.is_locked)

    def test_evenement_rejoue_reste_idempotent(self):
        from jeiko.shop.models import ProductStockMovement

        event = self._event("payment_intent.succeeded", self.order.pk)
        self.assertEqual(self._post(event).status_code, 200)
        self.assertEqual(self._post(event).status_code, 200)  # Stripe rejoue

        self.product.refresh_from_db()
        self.assertEqual(self.product.stock_quantity, 5)  # pas 3
        self.assertEqual(ProductStockMovement.objects.count(), 1)

    def test_signature_invalide_renvoie_400(self):
        import stripe
        from jeiko.shop.models import Order

        erreur = stripe.error.SignatureVerificationError("mauvaise signature", "sig")
        with mock.patch(CONSTRUCT_EVENT, side_effect=erreur):
            response = self.client.post(
                WEBHOOK_URL, data=b"{}", content_type="application/json",
                HTTP_STRIPE_SIGNATURE="t=1,v1=faux",
            )
        self.assertEqual(response.status_code, 400)

        self.order.refresh_from_db()
        self.assertEqual(self.order.payment_status, Order.PAYMENT_STATUS_PENDING)

    def test_commande_inconnue_ne_plante_pas(self):
        # Stripe rejouerait indéfiniment sur une 500 : l'ID absent doit
        # renvoyer 200 sans lever.
        response = self._post(
            self._event("payment_intent.succeeded", 999999)
        )
        self.assertEqual(response.status_code, 200)

    def test_evenement_sans_order_id_ignore(self):
        from jeiko.shop.models import Order

        response = self._post(
            self._event("payment_intent.succeeded", None)
        )
        self.assertEqual(response.status_code, 200)
        self.order.refresh_from_db()
        self.assertEqual(self.order.payment_status, Order.PAYMENT_STATUS_PENDING)

    def test_paiement_echoue_marque_la_commande(self):
        from jeiko.shop.models import Order, ProductStockMovement

        response = self._post(
            self._event("payment_intent.payment_failed", self.order.pk)
        )
        self.assertEqual(response.status_code, 200)

        self.order.refresh_from_db()
        self.assertEqual(self.order.payment_status, Order.PAYMENT_STATUS_FAILED)
        # Un échec ne touche pas au stock.
        self.assertEqual(ProductStockMovement.objects.count(), 0)

    def test_type_non_gere_renvoie_200(self):
        # Le dispatcher retombe sur handle_unknown : accusé de réception, rien
        # d'autre.
        response = self._post(
            self._event("invoice.created", None, intent_id="in_1")
        )
        self.assertEqual(response.status_code, 200)


class _Intent(dict):
    """PaymentIntent au strict nécessaire : `stripe` rend un dict à attributs."""

    def __getattr__(self, nom):
        try:
            return self[nom]
        except KeyError as absent:
            raise AttributeError(nom) from absent


class RetourNavigateurTests(TestCase):
    """
    S-14 — `PaymentCheckView`, le retour du navigateur après Stripe.

    L'adresse acceptait n'importe quel `payment_intent`, sans compte et sans
    confronter le `client_secret` que Stripe place pourtant dans l'URL pour
    cela. Ces tests verrouillent les trois gardes ajoutées : compte connecté,
    secret conforme, commande appartenant au visiteur.

    `PaymentIntent.retrieve` est mocké : c'est la seule frontière réseau.
    """

    SECRET = "pi_test_1_secret_le_vrai"

    def setUp(self):
        from django.urls import reverse
        from jeiko.shop.models import Cart, Order

        PaymentGateway.objects.create(
            name="Stripe", code="stripe", is_active=True,
            secret_key="sk_test", webhook_secret="whsec_test",
        )
        self.carol = User.objects.create_user("carol", "carol@example.test", "pw")
        self.mallory = User.objects.create_user("mallory", "m@example.test", "pw")
        self.order = Order.objects.create(
            user=self.carol, cart=Cart.objects.create(user=self.carol),
        )
        self.url = reverse("jeiko_payments_client:check")

    def _intent(self, statut="succeeded", secret=None, order_id=...):
        return _Intent(
            id="pi_test_1",
            status=statut,
            client_secret=self.SECRET if secret is None else secret,
            metadata={
                "order_id": str(self.order.pk) if order_id is ... else order_id
            },
        )

    def _retour(self, secret=None, intent=None, **params):
        cible = intent if intent is not None else self._intent()
        if secret is not None:
            params["payment_intent_client_secret"] = secret
        params.setdefault("payment_intent", "pi_test_1")
        with mock.patch("stripe.PaymentIntent.retrieve", return_value=cible) as appel:
            reponse = self.client.get(self.url, params)
        reponse.retrieve = appel
        return reponse

    def _statut_commande(self):
        self.order.refresh_from_db()
        return self.order.payment_status

    def test_visiteur_anonyme_refuse(self):
        from jeiko.shop.models import Order

        reponse = self._retour(secret=self.SECRET)
        self.assertEqual(reponse.status_code, 302)
        self.assertNotIn("/orders/", reponse["Location"])
        # Stripe n'est même pas interrogé : le mixin coupe avant.
        reponse.retrieve.assert_not_called()
        self.assertEqual(self._statut_commande(), Order.PAYMENT_STATUS_PENDING)

    def test_client_secret_absent_refuse(self):
        from jeiko.shop.models import Order

        self.client.login(username="carol", password="pw")
        reponse = self._retour()
        self.assertEqual(reponse.status_code, 302)
        self.assertNotIn("/orders/", reponse["Location"])
        self.assertEqual(self._statut_commande(), Order.PAYMENT_STATUS_PENDING)

    def test_client_secret_incorrect_refuse(self):
        from jeiko.shop.models import Order

        self.client.login(username="carol", password="pw")
        reponse = self._retour(secret="pi_test_1_secret_devine")
        self.assertEqual(reponse.status_code, 302)
        self.assertNotIn("/orders/", reponse["Location"])
        self.assertEqual(self._statut_commande(), Order.PAYMENT_STATUS_PENDING)

    def test_commande_d_un_autre_compte_refusee(self):
        """
        Le cœur de S-14 : même muni d'un `pi_…` et de son secret, un tiers
        connecté ne règle pas la commande de quelqu'un d'autre.
        """
        from jeiko.shop.models import Order

        self.client.login(username="mallory", password="pw")
        reponse = self._retour(secret=self.SECRET)
        self.assertEqual(reponse.status_code, 302)
        self.assertNotIn("/orders/", reponse["Location"])
        self.assertEqual(self._statut_commande(), Order.PAYMENT_STATUS_PENDING)

    def test_retour_legitime_regle_la_commande(self):
        from jeiko.shop.models import Order

        self.client.login(username="carol", password="pw")
        reponse = self._retour(secret=self.SECRET)
        self.assertEqual(reponse.status_code, 302)
        self.assertIn(f"/orders/{self.order.pk}/", reponse["Location"])
        self.assertEqual(self._statut_commande(), Order.PAYMENT_STATUS_PAID)

    def test_intention_non_aboutie_ne_regle_rien(self):
        from jeiko.shop.models import Order

        self.client.login(username="carol", password="pw")
        reponse = self._retour(
            secret=self.SECRET, intent=self._intent(statut="requires_payment_method")
        )
        self.assertEqual(reponse.status_code, 302)
        self.assertEqual(self._statut_commande(), Order.PAYMENT_STATUS_PENDING)


class _FakeStripe:
    """
    Faux module stripe pour la réconciliation : sert une liste figée de
    PaymentIntents, sans réseau. Reproduit l'interface utilisée —
    PaymentIntent.list(...).auto_paging_iter().
    """

    def __init__(self, intents):
        self._intents = intents
        self.calls = []

        outer = self

        class _PaymentIntent:
            @staticmethod
            def list(**params):
                outer.calls.append(params)
                return outer._Page(outer._intents, params)

        self.PaymentIntent = _PaymentIntent

    class _Page:
        def __init__(self, intents, params):
            self._intents = intents
            self._params = params

        def auto_paging_iter(self):
            created = self._params.get("created") or {}
            gte = created.get("gte")
            for intent in self._intents:
                if gte is not None and intent.get("created", 0) < gte:
                    continue
                yield intent


class ReconcileTests(TestCase):
    """
    Rapprochement commandes ↔ paiements Stripe (jeiko.payments.reconcile),
    avec un faux module stripe : on éprouve toute la logique de décision sans
    toucher au réseau.
    """

    def setUp(self):
        from jeiko.administration_pages.models import Page
        from jeiko.custom_objects.models import CustomObject, CustomObjectModel
        from jeiko.shop.models import (
            Cart, Order, OrderLine, Product, ProductType,
        )

        self.Order = Order

        page = Page.objects.create(
            title="Gabarit", url_tag="gabarit", active=True,
            is_custom_object_template=True,
        )
        com = CustomObjectModel.objects.create(
            name="Produit", slug="produit", page_template=page, is_product=True,
        )
        ptype = ProductType.objects.create(
            name="Objet", code="objet", content_model=com,
            kind=ProductType.KIND_PHYSICAL, requires_shipping=True,
        )
        contenu = CustomObject.objects.create(
            model=com, title="Mug", slug="mug", is_published=True,
        )
        self.product = Product.objects.create(
            type=ptype, content=contenu, sku="mug-1",
            price_ht=Decimal("10.00"), tax_rate=Decimal("20.00"),
            stock_quantity=7, is_active=True,
        )
        self.user = User.objects.create_user("client", "c@example.test", "pw")

    def _commande(self, quantite=1, statut=None):
        from jeiko.shop.models import Cart, OrderLine

        cart = Cart.objects.create(user=self.user)
        order = self.Order.objects.create(
            user=self.user, cart=cart,
            total_ht=Decimal("10.00") * quantite,
            total_ttc=Decimal("12.00") * quantite,
        )
        if statut:
            order.payment_status = statut
            order.save(update_fields=["payment_status"])
        OrderLine.objects.create(
            order=order, product=self.product, label="Mug", sku="mug-1",
            quantity=quantite, unit_price_ht=Decimal("10.00"),
            tax_rate=Decimal("20.00"),
        )
        return order

    def _intent(self, order_id, amount, status="succeeded", intent_id="pi_1",
                created=None):
        return {
            "id": intent_id,
            "status": status,
            "amount": amount,
            "amount_received": amount,
            "metadata": {"order_id": str(order_id)} if order_id else {},
            "created": created or 0,
        }

    def test_dry_run_ne_modifie_rien(self):
        from jeiko.payments import reconcile

        order = self._commande(quantite=1)  # total 12.00 -> 1200 c
        fake = _FakeStripe([self._intent(order.pk, 1200)])

        results = reconcile.reconcile_orders(fake, dry_run=True)
        self.assertEqual([r.status for r in results], [reconcile.WOULD_RECONCILE])

        order.refresh_from_db()
        self.assertEqual(order.payment_status, self.Order.PAYMENT_STATUS_PENDING)

    def test_application_regle_la_commande(self):
        from jeiko.payments import reconcile
        from jeiko.shop.models import ProductStockMovement

        order = self._commande(quantite=2)  # total 24.00 -> 2400 c
        fake = _FakeStripe([self._intent(order.pk, 2400)])

        results = reconcile.reconcile_orders(fake, dry_run=False)
        self.assertEqual([r.status for r in results], [reconcile.RECONCILED])

        order.refresh_from_db()
        self.product.refresh_from_db()
        self.assertEqual(order.payment_status, self.Order.PAYMENT_STATUS_PAID)
        self.assertEqual(self.product.stock_quantity, 5)  # 7 - 2
        self.assertEqual(ProductStockMovement.objects.count(), 1)

    def test_commande_deja_payee_ignoree(self):
        from jeiko.payments import reconcile

        order = self._commande(
            quantite=1, statut=self.Order.PAYMENT_STATUS_PAID
        )
        fake = _FakeStripe([self._intent(order.pk, 1200)])

        results = reconcile.reconcile_orders(fake, dry_run=False)
        self.assertEqual([r.status for r in results], [reconcile.ALREADY_PAID])

    def test_ecart_de_montant_signale_jamais_regle(self):
        from jeiko.payments import reconcile

        order = self._commande(quantite=1)  # attendu 1200 c
        fake = _FakeStripe([self._intent(order.pk, 999)])  # encaissé 999 c

        results = reconcile.reconcile_orders(fake, dry_run=False)
        self.assertEqual([r.status for r in results], [reconcile.AMOUNT_MISMATCH])

        order.refresh_from_db()
        self.assertEqual(order.payment_status, self.Order.PAYMENT_STATUS_PENDING)

    def test_order_id_inconnu_signale(self):
        from jeiko.payments import reconcile

        fake = _FakeStripe([self._intent(999999, 1200)])
        results = reconcile.reconcile_orders(fake, dry_run=True)
        self.assertEqual([r.status for r in results], [reconcile.ORDER_MISSING])

    def test_intent_sans_order_id_ignore(self):
        from jeiko.payments import reconcile

        # Typiquement un paiement de rendez-vous (metadata jeiko_appointment_id).
        fake = _FakeStripe([self._intent(None, 5000)])
        results = reconcile.reconcile_orders(fake, dry_run=True)
        self.assertEqual(results, [])

    def test_intent_non_succeeded_ignore(self):
        from jeiko.payments import reconcile

        order = self._commande(quantite=1)
        fake = _FakeStripe([
            self._intent(order.pk, 1200, status="requires_payment_method")
        ])
        self.assertEqual(reconcile.reconcile_orders(fake, dry_run=True), [])

    def test_borne_temporelle_transmise_a_stripe(self):
        from jeiko.payments import reconcile

        order = self._commande(quantite=1)
        # Cet intent est plus vieux que la fenêtre : le faux module l'exclut.
        fake = _FakeStripe([self._intent(order.pk, 1200, created=0)])
        results = reconcile.reconcile_orders(fake, dry_run=True, days=7)

        self.assertEqual(results, [])
        self.assertIn("created", fake.calls[0])  # borne bien transmise
