import logging

from jeiko.shop.models import Order
from jeiko.shop.services import mark_order_paid

logger = logging.getLogger(__name__)

class StripeWebhookDispatcher:
    def dispatch(self, event):
        event_type = event['type']
        handler_name = 'handle_' + event_type.replace('.', '_')
        handler = getattr(self, handler_name, self.handle_unknown)
        
        logger.info(f"Dispatching Stripe event: {event_type}")
        return handler(event)

    def handle_unknown(self, event):
        """
        Événement Stripe qu'aucun gestionnaire ne traite.

        Journalisé en AVERTISSEMENT et non en information : c'est le signe qu'un
        flux a été activé côté Stripe sans contrepartie côté site, et personne
        ne l'apprendrait en le noyant dans le bruit.
        """
        logger.warning("Événement Stripe non traité : %s", event['type'])

    def _signaler_non_implemente(self, event, fonctionnalite):
        """
        Prévient l'exploitant qu'un événement est arrivé sans être traité.

        Sans cela, un abonnement souscrit, modifié ou résilié chez Stripe ne
        laisse aucune trace côté site : ni facturation suivie, ni accès ouvert
        ou fermé. Mieux vaut une alerte qu'un silence.
        """
        objet = event.get('data', {}).get('object', {}) or {}
        logger.warning(
            "Stripe — %s non implémenté (événement %s, objet %s)",
            fonctionnalite, event.get('type'), objet.get('id'),
        )
        try:
            from jeiko.emailing.admin_alerts import notifier_erreur

            notifier_erreur(
                f"Stripe : {fonctionnalite} non pris en charge",
                f"Événement « {event.get('type')} » reçu pour l'objet "
                f"{objet.get('id')}. JEIKO ne gère pas encore ce flux : "
                f"l'événement n'a produit aucun effet sur le site.",
            )
        except Exception:
            logger.exception("Alerte d'événement Stripe non traité impossible")

    # -------------------------------------------------------------------------
    # 1. Paiements (PaymentIntent)
    # -------------------------------------------------------------------------
    def handle_payment_intent_succeeded(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent succeeded: {payment_intent['id']}")

        # Rendez-vous du module calendars : la logique reste dans calendars,
        # on ne fait que la déclencher ici.
        self._handle_appointment_payment(payment_intent)

        order_id = payment_intent.get('metadata', {}).get('order_id')
        if order_id:
            try:
                order = Order.objects.get(pk=order_id)
            except Order.DoesNotExist:
                logger.error(f"Order #{order_id} not found for PaymentIntent {payment_intent['id']}")
                return

            # Le webhook accorde désormais les accès et décrémente le stock,
            # comme le retour navigateur : c'est le seul chemin fiable quand
            # le client ferme son onglet après paiement.
            if mark_order_paid(order, source="stripe:webhook"):
                logger.info(f"Order #{order.pk} marked as PAID via webhook.")

    def _handle_appointment_payment(self, payment_intent):
        """Confirme un rendez-vous payé, si l'évènement en désigne un."""
        if not (payment_intent.get('metadata') or {}).get('jeiko_appointment_id'):
            return
        try:
            from jeiko.calendars import payments as calendar_payments
            from jeiko.calendars.views import send_booking_emails_safe

            appointment, confirmed = calendar_payments.confirm_from_webhook(payment_intent)
            if confirmed:
                logger.info("Rendez-vous #%s confirmé par webhook Stripe.", appointment.pk)
                send_booking_emails_safe(appointment.pk)
        except Exception:
            # Un webhook qui lève renvoie une 500 à Stripe, qui le rejoue en
            # boucle : on journalise et on rend la main.
            logger.exception(
                "Confirmation de rendez-vous impossible pour le PaymentIntent %s",
                payment_intent.get('id'),
            )

    def handle_payment_intent_payment_failed(self, event):
        payment_intent = event['data']['object']
        logger.warning(f"PaymentIntent failed: {payment_intent['id']} - {payment_intent.get('last_payment_error', {}).get('message')}")
        
        order_id = payment_intent.get('metadata', {}).get('order_id')
        if order_id:
            try:
                order = Order.objects.get(pk=order_id)
                order.payment_status = Order.PAYMENT_STATUS_FAILED
                order.save()
            except Order.DoesNotExist:
                return

            # Le client doit savoir que son paiement n'est pas passé, et
            # pouvoir le reprendre. Le motif vient de Stripe : il est plus
            # utile que « une erreur est survenue » (carte expirée, plafond…).
            from jeiko.shop.emailing import send_payment_failed_email

            motif = (payment_intent.get('last_payment_error') or {}).get('message') or ""
            try:
                send_payment_failed_email(order, motif=motif)
            except Exception:
                logger.exception(
                    "E-mail d'échec de paiement impossible (commande #%s)", order.pk
                )

    def handle_payment_intent_processing(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent processing: {payment_intent['id']}")

    def handle_payment_intent_canceled(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent canceled: {payment_intent['id']}")
        
        order_id = payment_intent.get('metadata', {}).get('order_id')
        if order_id:
            try:
                order = Order.objects.get(pk=order_id)
                order.payment_status = Order.PAYMENT_STATUS_FAILED # Or cancelled?
                order.order_status = Order.ORDER_STATUS_CANCELLED
                order.save()
            except Order.DoesNotExist:
                pass

    def handle_payment_intent_requires_action(self, event):
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent requires action: {payment_intent['id']}")

    # -------------------------------------------------------------------------
    # 2. Checkout (Sessions)
    # -------------------------------------------------------------------------
    def handle_checkout_session_completed(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session completed: {session['id']}")
        
        # Logic similar to payment_intent_succeeded if using checkout sessions for orders
        # For now, we are using PaymentIntents directly in the current flow, 
        # but if we switch to Checkout Sessions, this is where we'd handle fulfillment.
        if session.get('payment_status') == 'paid':
             # Fulfill order
             pass

    def handle_checkout_session_async_payment_succeeded(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session async payment succeeded: {session['id']}")

    def handle_checkout_session_async_payment_failed(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session async payment failed: {session['id']}")

    def handle_checkout_session_expired(self, event):
        session = event['data']['object']
        logger.info(f"Checkout Session expired: {session['id']}")

    # -------------------------------------------------------------------------
    # 3. Abonnements (Billing)
    # -------------------------------------------------------------------------
    def handle_customer_subscription_created(self, event):
        self._signaler_non_implemente(event, "abonnements")

    def handle_customer_subscription_updated(self, event):
        self._signaler_non_implemente(event, "abonnements")

    def handle_customer_subscription_deleted(self, event):
        self._signaler_non_implemente(event, "abonnements")

    def handle_customer_subscription_paused(self, event):
        self._signaler_non_implemente(event, "abonnements")

    def handle_customer_subscription_resumed(self, event):
        self._signaler_non_implemente(event, "abonnements")

    def handle_customer_subscription_trial_will_end(self, event):
        self._signaler_non_implemente(event, "abonnements")

    # Invoices
    def handle_invoice_created(self, event):
        self._signaler_non_implemente(event, "abonnements")

    def handle_invoice_finalized(self, event):
        self._signaler_non_implemente(event, "abonnements")

    def handle_invoice_payment_succeeded(self, event):
        self._signaler_non_implemente(event, "abonnements")

    def handle_invoice_payment_failed(self, event):
        self._signaler_non_implemente(event, "abonnements")

    def handle_invoice_marked_uncollectible(self, event):
        self._signaler_non_implemente(event, "abonnements")

    def handle_invoice_voided(self, event):
        self._signaler_non_implemente(event, "abonnements")

    # -------------------------------------------------------------------------
    # 4. Paiements à l’étranger / SCA (Mandats)
    # -------------------------------------------------------------------------
    def handle_mandate_updated(self, event):
        mandate = event['data']['object']
        logger.info(f"Mandate updated: {mandate['id']}")

    def handle_mandate_created(self, event):
        mandate = event['data']['object']
        logger.info(f"Mandate created: {mandate['id']}")

    # -------------------------------------------------------------------------
    # 5. Clients
    # -------------------------------------------------------------------------
    def handle_customer_created(self, event):
        customer = event['data']['object']
        logger.info(f"Customer created: {customer['id']}")

    def handle_customer_updated(self, event):
        customer = event['data']['object']
        logger.info(f"Customer updated: {customer['id']}")

    def handle_customer_deleted(self, event):
        customer = event['data']['object']
        logger.info(f"Customer deleted: {customer['id']}")

    # -------------------------------------------------------------------------
    # 6. Produits & Prix
    # -------------------------------------------------------------------------
    def handle_product_created(self, event):
        product = event['data']['object']
        logger.info(f"Product created: {product['id']}")

    def handle_product_updated(self, event):
        product = event['data']['object']
        logger.info(f"Product updated: {product['id']}")

    def handle_price_created(self, event):
        price = event['data']['object']
        logger.info(f"Price created: {price['id']}")

    def handle_price_updated(self, event):
        price = event['data']['object']
        logger.info(f"Price updated: {price['id']}")

    # -------------------------------------------------------------------------
    # Charges (Legacy but useful)
    # -------------------------------------------------------------------------
    def handle_charge_succeeded(self, event):
        charge = event['data']['object']
        logger.info(f"Charge succeeded: {charge['id']}")

    def handle_charge_failed(self, event):
        charge = event['data']['object']
        logger.info(f"Charge failed: {charge['id']}")

    def handle_charge_refunded(self, event):
        charge = event['data']['object']
        logger.info(f"Charge refunded: {charge['id']}")
        # Répercute sur le rendez-vous concerné (remboursement fait depuis le
        # tableau de bord Stripe, ou confirmation d'un remboursement déclenché
        # par le site). La logique reste dans calendars.
        try:
            from jeiko.calendars import payments as calendar_payments
            calendar_payments.mark_refunded_from_charge(charge)
        except Exception:
            logger.exception("Répercussion du remboursement impossible (charge=%s)",
                             charge.get('id'))

    def handle_charge_dispute_created(self, event):
        dispute = event['data']['object']
        logger.warning(f"Dispute created: {dispute['id']}")

    def handle_charge_dispute_closed(self, event):
        dispute = event['data']['object']
        logger.info(f"Dispute closed: {dispute['id']}")
