from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import transaction
from django.views.generic import TemplateView, View
from django.http import JsonResponse, HttpResponse, HttpResponseRedirect
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from ..services.stripe import StripeService
from jeiko.shop.models import Cart, Order, OrderLine
from jeiko.shop.services import compute_order_totals, mark_order_paid
from jeiko.shop.views.client import get_or_create_cart
import json
import logging
import stripe
from secrets import compare_digest

logger = logging.getLogger(__name__)


class CheckoutView(LoginRequiredMixin, TemplateView):
    """
    Entrée du tunnel de paiement.

    Une commande exige un compte. Sans lui, `shop.services._grant_access` n'a
    personne à qui ouvrir une formation ou un questionnaire : le paiement était
    encaissé, la commande passait en payée, le stock était décrémenté, et rien
    n'était délivré — sans erreur ni message.

    Le panier, lui, reste accessible en anonyme : c'est seulement au moment de
    commander qu'on demande un compte. Le panier constitué avant la connexion
    est repris par `shop.signals`, sans quoi cette exigence ferait perdre son
    panier à l'acheteur juste après le détour qu'on lui impose.
    """

    template_name = 'payments/client/checkout.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Get cart and total
        cart = get_or_create_cart(self.request)
        items = cart.items.select_related("product").all()
        _total_ht, _total_tva, total_ttc = compute_order_totals(items)

        context['cart'] = cart
        context['total_ttc'] = total_ttc
        
        stripe_service = StripeService()
        if stripe_service.gateway:
            context['stripe_public_key'] = stripe_service.gateway.api_key
        return context

class CreatePaymentIntentView(LoginRequiredMixin, View):
    """
    Création de l'intention de paiement.

    Gardée comme `CheckoutView` : sans cela, l'exigence de compte se contournerait
    en appelant directement ce point d'entrée.
    """

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        try:
            # Get cart and total
            cart = get_or_create_cart(request)

            # Verrou de ligne sur le panier pendant toute la préparation de la
            # commande. Sans lui, deux envois simultanés — double clic, onglet
            # rejoué — créaient deux PaymentIntent pour la même commande : le
            # garde `PAYMENT_STATUS_PAID` plus bas ne couvre pas la fenêtre
            # entre les deux, et le client pouvait être débité deux fois.
            Cart.objects.select_for_update().get(pk=cart.pk)

            items = cart.items.all()
            if not items:
                 return JsonResponse({'error': 'Cart is empty'}, status=400)

            total_ht, total_tva, total_ttc = compute_order_totals(items)

            # Create or update Order
            order, created = Order.objects.get_or_create(
                cart=cart,
                defaults={
                    'user': request.user,
                    'order_status': Order.ORDER_STATUS_DRAFT,
                    'payment_status': Order.PAYMENT_STATUS_PENDING,
                    'currency': 'EUR', # Should come from cart/settings
                    'total_ht': total_ht,
                    'total_tva': total_tva,
                    'total_ttc': total_ttc,
                }
            )

            if not created:
                # Une commande déjà réglée ne doit plus être resynchronisée
                # sur le panier ni repayée.
                if order.payment_status == Order.PAYMENT_STATUS_PAID:
                    return JsonResponse(
                        {'error': 'Cette commande a déjà été réglée.'}, status=409
                    )

                champs = ['total_ht', 'total_tva', 'total_ttc', 'updated_at']

                # Brouillon laissé par l'ancien parcours invité, ou panier repris
                # à la connexion : la commande doit suivre le compte, sinon elle
                # se réglerait sans destinataire.
                if order.user_id is None:
                    order.user = request.user
                    champs.append('user')

                # Update totals if order already existed
                order.total_ht = total_ht
                order.total_tva = total_tva
                order.total_ttc = total_ttc
                order.save(update_fields=champs)

            # Create OrderLines if needed (or sync them)
            # For simplicity, we wipe and recreate lines to ensure sync with cart
            order.lines.all().delete()
            for item in items:
                OrderLine.objects.create(
                    order=order,
                    product=item.product,
                    label=f"{item.product.sku} - {item.product.content.title}",
                    sku=item.product.sku,
                    quantity=item.quantity,
                    unit_price_ht=item.unit_price_ht,
                    tax_rate=item.tax_rate
                )

            stripe_service = StripeService()
            # Pass order_id in metadata
            intent = stripe_service.create_payment_intent(
                amount=total_ttc, 
                currency='eur',
                metadata={'order_id': order.pk}
            )
            
            return JsonResponse({
                'clientSecret': intent['client_secret']
            })
        except Exception:
            # str(e) renvoyait au navigateur le message brut de l'exception —
            # y compris les erreurs de configuration Stripe.
            logger.exception("Échec de création du PaymentIntent")
            return JsonResponse(
                {'error': "Le paiement n'a pas pu être initialisé."}, status=400
            )


@method_decorator(csrf_exempt, name='dispatch')
class StripeWebhookView(View):
    def post(self, request, *args, **kwargs):
        payload = request.body
        sig_header = request.META.get('HTTP_STRIPE_SIGNATURE')
        
        stripe_service = StripeService()
        
        try:
            event = stripe_service.construct_event(payload, sig_header)
        except Exception as e:
            return HttpResponse(status=400)

        # Handle the event using the Dispatcher
        from ..webhooks.stripe import StripeWebhookDispatcher
        dispatcher = StripeWebhookDispatcher()
        dispatcher.dispatch(event)
        
        return HttpResponse(status=200)


class PaymentCheckView(LoginRequiredMixin, View):
    """
    Retour du navigateur après le passage sur Stripe (S-14).

    Cette adresse ne recevait aucun contrôle : elle acceptait n'importe quel
    `payment_intent`, d'un visiteur anonyme, et réglait la commande désignée par
    les métadonnées de l'intention — celle d'un autre client comprise.

    Trois gardes, dont deux manquaient :

    * **le compte** — le tunnel entier exige déjà d'être connecté
      (`CheckoutView`, `CreatePaymentIntentView`), cette porte-là restait
      ouverte ;
    * **le `client_secret`** — Stripe le renvoie dans l'URL précisément pour
      qu'on le confronte à celui de l'intention. Sans cette vérification,
      connaître un identifiant `pi_…` suffisait ; or il n'est pas secret, il
      traverse les journaux de serveur, les référents et l'historique du
      navigateur ;
    * **le propriétaire** — la commande doit être celle du visiteur.

    Ce que cela ne corrige pas : rien ici n'est le chemin fiable. Le client peut
    fermer son onglet avant le retour, c'est le webhook qui fait foi
    (`StripeWebhookView`), et `payments.reconcile` rattrape le reste.
    `mark_order_paid` est idempotent : celui des trois qui arrive en second ne
    fait rien.
    """

    def get(self, request, *args, **kwargs):
        payment_intent_id = request.GET.get('payment_intent')
        secret_recu = request.GET.get('payment_intent_client_secret') or ''

        if not payment_intent_id:
             return redirect('jeiko_payments_client:checkout')

        stripe_service = StripeService()
        try:
            # Ensure secret key is set
            stripe.api_key = stripe_service.gateway.secret_key

            # Retrieve the PaymentIntent from Stripe
            intent = stripe.PaymentIntent.retrieve(payment_intent_id)

            # Comparaison à temps constant : on compare bien un secret.
            if not compare_digest(str(intent.get('client_secret') or ''), secret_recu):
                logger.warning(
                    "Retour de paiement %s refusé : client_secret absent ou "
                    "incorrect (compte %s).", payment_intent_id, request.user.pk,
                )
                return redirect('jeiko_payments_client:checkout')

            if intent.status == 'succeeded':
                order_id = intent.metadata.get('order_id')
                if order_id:
                    order = Order.objects.filter(
                        pk=order_id, user=request.user
                    ).first()
                    if order is None:
                        logger.warning(
                            "Retour de paiement %s : commande %s inconnue ou "
                            "étrangère au compte %s.",
                            payment_intent_id, order_id, request.user.pk,
                        )
                        return redirect('jeiko_payments_client:checkout')

                    # Même traitement que le webhook, et idempotent : celui
                    # des deux qui arrive en second ne fait rien.
                    mark_order_paid(order, source="stripe:return")

                    return redirect('jeiko_users_client:order_detail', pk=order.pk)

            # If not succeeded or other issue
            return redirect('jeiko_payments_client:checkout')

        except Exception:
            logger.exception("Échec de la vérification du paiement %s", payment_intent_id)
            return redirect('jeiko_payments_client:checkout')

class PaymentSuccessView(TemplateView):
    template_name = 'payments/client/success.html'

class PaymentCancelView(TemplateView):
    template_name = 'payments/client/cancel.html'
