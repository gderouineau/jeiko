from django.db import models
from jeiko.encrypted import EncryptedCharField
from django.utils.translation import gettext_lazy as _

class PaymentGateway(models.Model):
    GATEWAY_CHOICES = (
        ('stripe', 'Stripe'),
    )

    name = models.CharField(_("Nom"), max_length=100)
    code = models.SlugField(_("Code"), unique=True, choices=GATEWAY_CHOICES, default='stripe', help_text=_("Identifiant unique (ex: stripe)"))
    is_active = models.BooleanField(_("Actif"), default=False)
    
    # API Keys
    api_key = models.CharField(_("Clé API publique"), max_length=255, blank=True)
    # Chiffrés au repos : un dump de base volé ne doit pas livrer de quoi
    # émettre des remboursements ni forger des webhooks. La clé dérive de
    # SECRET_KEY, qui vit dans le .env (0600) et non dans la base.
    secret_key = EncryptedCharField(_("Clé secrète"), max_length=255, blank=True)
    webhook_secret = EncryptedCharField(_("Secret Webhook"), max_length=255, blank=True)
    
    test_mode = models.BooleanField(_("Mode Test"), default=True)

    class Meta:
        verbose_name = _("Moyen de paiement")
        verbose_name_plural = _("Moyens de paiement")

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if self.is_active:
            # Ensure only this gateway is active
            PaymentGateway.objects.filter(is_active=True).exclude(pk=self.pk).update(is_active=False)
        super().save(*args, **kwargs)
