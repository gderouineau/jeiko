from django import forms

from .models import PaymentGateway

#: Clés qui ne doivent jamais repartir vers le navigateur.
CHAMPS_SECRETS = ("secret_key", "webhook_secret")


class PaymentGatewayForm(forms.ModelForm):
    """
    Les deux clés secrètes étaient rendues avec `PasswordInput(render_value=True)` :
    le masque n'est que visuel, la valeur partait en clair dans l'attribut
    `value` du HTML. Une fois la clé enregistrée, on ne la renvoie plus — un
    champ laissé vide conserve la valeur en base.
    """

    class Meta:
        model = PaymentGateway
        fields = [
            'name', 'code', 'is_active',
            'api_key', 'secret_key', 'webhook_secret',
            'test_mode',
        ]
        widgets = {
            'secret_key': forms.PasswordInput(render_value=False),
            'webhook_secret': forms.PasswordInput(render_value=False),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        deja_enregistre = bool(self.instance and self.instance.pk)
        for nom in CHAMPS_SECRETS:
            champ = self.fields[nom]
            champ.required = False
            if deja_enregistre and getattr(self.instance, nom, ""):
                champ.help_text = (
                    "Une clé est enregistrée. Laisser vide pour la conserver, "
                    "ou saisir la nouvelle pour la remplacer."
                )
            else:
                champ.help_text = "Aucune clé enregistrée pour le moment."

    def _conserver_si_vide(self, nom):
        valeur = (self.cleaned_data.get(nom) or "").strip()
        if valeur:
            return valeur
        # Champ laissé vide : on garde ce qui est en base plutôt que de
        # l'effacer par inadvertance.
        return getattr(self.instance, nom, "") if self.instance.pk else ""

    def clean_secret_key(self):
        return self._conserver_si_vide("secret_key")

    def clean_webhook_secret(self):
        return self._conserver_si_vide("webhook_secret")
