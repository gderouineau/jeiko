"""
Chiffrement au repos des secrets.

Ce qui est vérifié n'est pas « ça se relit » — ce serait vrai même sans
chiffrement — mais **ce que contient réellement la colonne**. Le test lit donc
la base en SQL brut, seul moyen de prouver qu'un dump volé ne livre rien.

Menace visée : la lecture de la base sans le `.env` (sauvegarde égarée, disque
revendu, accès en lecture seule). La clé dérive de `SECRET_KEY`, qui ne se
trouve pas dans la base.
"""

from django.contrib.auth import get_user_model
from django.db import connection
from django.test import TestCase

from jeiko.administration.models import MailSettings
from jeiko.courses.models import VideoStorageProvider
from jeiko.payments.models import PaymentGateway
from jeiko.users.models import ProviderConfig

User = get_user_model()

SECRET_STRIPE = "sk_live_ne_doit_jamais_apparaitre_en_clair"
SECRET_SMTP = "motdepasse_smtp_confidentiel"


def colonne_brute(table, colonne, pk):
    """Valeur telle qu'elle est stockée, sans passer par l'ORM."""
    with connection.cursor() as cur:
        cur.execute(f'SELECT {colonne} FROM {table} WHERE id = %s', [pk])
        return cur.fetchone()[0]


class SecretsChiffresTests(TestCase):
    def test_la_cle_stripe_n_est_pas_lisible_en_base(self):
        passerelle = PaymentGateway.objects.create(
            name="Stripe", code="stripe", secret_key=SECRET_STRIPE,
        )
        brut = colonne_brute("payments_paymentgateway", "secret_key", passerelle.pk)
        self.assertNotIn(
            SECRET_STRIPE, brut or "",
            "La clé secrète Stripe est lisible dans un dump de base.",
        )

    def test_mais_l_application_la_relit_correctement(self):
        passerelle = PaymentGateway.objects.create(
            name="Stripe", code="stripe", secret_key=SECRET_STRIPE,
        )
        passerelle.refresh_from_db()
        self.assertEqual(passerelle.secret_key, SECRET_STRIPE)

    def test_le_secret_de_webhook_est_chiffre(self):
        passerelle = PaymentGateway.objects.create(
            name="Stripe", code="stripe", webhook_secret="whsec_confidentiel",
        )
        brut = colonne_brute("payments_paymentgateway", "webhook_secret", passerelle.pk)
        self.assertNotIn("whsec_confidentiel", brut or "")

    def test_la_cle_publique_reste_en_clair(self):
        """Elle est publique par nature : la chiffrer n'apporterait rien."""
        passerelle = PaymentGateway.objects.create(
            name="Stripe", code="stripe", api_key="pk_live_publique",
        )
        brut = colonne_brute("payments_paymentgateway", "api_key", passerelle.pk)
        self.assertIn("pk_live_publique", brut or "")

    def test_le_mot_de_passe_smtp_est_chiffre(self):
        reglages = MailSettings.objects.create(
            host="smtp.exemple.test", host_password=SECRET_SMTP,
        )
        brut = colonne_brute("administration_mailsettings", "host_password", reglages.pk)
        self.assertNotIn(SECRET_SMTP, brut or "")
        reglages.refresh_from_db()
        self.assertEqual(reglages.host_password, SECRET_SMTP)

    def test_le_secret_oauth_est_chiffre(self):
        fournisseur = ProviderConfig.objects.create(
            provider="google", client_id="public", client_secret="oauth_confidentiel",
        )
        brut = colonne_brute("users_providerconfig", "client_secret", fournisseur.pk)
        self.assertNotIn("oauth_confidentiel", brut or "")
        fournisseur.refresh_from_db()
        self.assertEqual(fournisseur.client_secret, "oauth_confidentiel")

    def test_les_identifiants_video_sont_chiffres(self):
        fournisseur = VideoStorageProvider.objects.create(
            name="Vimeo", provider_type="vimeo",
            config={"access_token": "jeton_vimeo_confidentiel"},
        )
        brut = colonne_brute("courses_videostorageprovider", "config", fournisseur.pk)
        self.assertNotIn("jeton_vimeo_confidentiel", str(brut))
        fournisseur.refresh_from_db()
        self.assertEqual(
            fournisseur.config["access_token"], "jeton_vimeo_confidentiel"
        )

    def test_une_valeur_vide_le_reste(self):
        """Ne pas transformer un champ vide en jeton chiffré illisible."""
        passerelle = PaymentGateway.objects.create(
            name="Sans secret", code="autre", secret_key="",
        )
        passerelle.refresh_from_db()
        self.assertFalse(passerelle.secret_key)

    def test_une_valeur_deja_en_clair_reste_lisible(self):
        """
        Transition : tant qu'une ligne n'a pas été réenregistrée, elle est en
        clair en base. L'application doit continuer de la lire, sinon la mise à
        jour couperait les paiements avant que la migration ait tourné.
        """
        passerelle = PaymentGateway.objects.create(name="Legacy", code="legacy")
        with connection.cursor() as cur:
            cur.execute(
                "UPDATE payments_paymentgateway SET secret_key = %s WHERE id = %s",
                ["valeur_heritee_en_clair", passerelle.pk],
            )
        passerelle.refresh_from_db()
        self.assertEqual(passerelle.secret_key, "valeur_heritee_en_clair")
