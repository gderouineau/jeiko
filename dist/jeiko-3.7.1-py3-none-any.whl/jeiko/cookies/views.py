# cookies/views.py
import json
from ipaddress import ip_address, IPv4Address, IPv6Address
from django.conf import settings
from django.contrib.sites.shortcuts import get_current_site
from django.http import JsonResponse, HttpResponseBadRequest
from django.utils import timezone
from django.utils.translation import get_language
from django.views import View
from django.views.generic import TemplateView
from django.core import signing
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import ensure_csrf_cookie

from jeiko.throttling import rate_limited

from .models import (
    CookieCategory,
    CookieBannerConfig,
    CookiePolicyVersion,
    CookieDefinition,
    CookieVendor,
    CookieConsent,
    CookieAppSettings,
    default_locale,
)
from .forms import ConsentPreferencesForm
from django.utils.translation import gettext_lazy as _


# --------- Constantes / utils ---------

CONSENT_COOKIE_NAME = getattr(settings, "CONSENT_COOKIE_NAME", "site_consent")
CONSENT_COOKIE_MAX_AGE = getattr(settings, "CONSENT_COOKIE_MAX_AGE", 365 * 24 * 3600)  # 1 an
CONSENT_COOKIE_SAMESITE = getattr(settings, "CONSENT_COOKIE_SAMESITE", "Lax")  # "Strict" ou "Lax" ou "None"
CONSENT_COOKIE_SALT = getattr(settings, "CONSENT_COOKIE_SALT", "cookies.consent")

def _now_iso():
    return timezone.now().isoformat(timespec="seconds")

def _current_locale(request):
    """
    La langue dont le bandeau doit parler : celle que LIT le visiteur.

    Sur un site en plusieurs langues, c'est le code de la langue ajoutée
    (« en ») ; partout ailleurs — site monolingue, langue d'origine, écrans
    d'administration — la langue du site telle que les enregistrements la
    portent (`default_locale()`, « fr-fr »).

    Ce n'est plus `get_language()` : depuis que l'administration se traduit,
    un administrateur qui travaille en anglais aurait édité — et créé — un
    bandeau « en » à la place de celui du site.
    """
    from jeiko.langues_du_site import langue_du_site

    return langue_du_site() or default_locale()


def _dans_la_langue(texte, enregistre_en, locale):
    """
    Un texte de bandeau saisi dans une autre langue que celle demandée.

    Les textes d'origine (« Tout accepter », la phrase par défaut) sont connus
    des catalogues de JEIKO : ils sortent traduits sans que l'exploitant ait
    rien à écrire. Un texte qu'il a personnalisé n'y figure pas et sort tel
    quel — il le traduit alors dans Cookies › Bannière, onglet de la langue.
    """
    if not texte or enregistre_en == locale:
        return texte
    from django.utils.translation import gettext

    return gettext(texte)


def _textes_du_bandeau(banner, locale):
    return {
        cle: _dans_la_langue(getattr(banner, cle), banner.locale, locale)
        for cle in ("message_text", "accept_all_label", "refuse_all_label",
                    "customize_label", "save_choices_label", "more_info_label")
    }

def _truncate_ip(raw_ip: str | None) -> str:
    """
    Tronque l'IP pour la preuve (IPv4 => x.y.0.0 ; IPv6 => /64)
    """
    if not raw_ip:
        return ""
    try:
        ip = ip_address(raw_ip)
        if isinstance(ip, IPv4Address):
            parts = raw_ip.split(".")
            if len(parts) == 4:
                return f"{parts[0]}.{parts[1]}.0.0"
        elif isinstance(ip, IPv6Address):
            # On retourne un préfixe /64 grossier (documentaire)
            hex_groups = raw_ip.split(":")
            # garder 4 groupes puis ::
            return ":".join(hex_groups[:4]) + "::/64"
    except ValueError:
        pass
    return ""

def _get_active_policy(site) -> CookiePolicyVersion | None:
    return CookiePolicyVersion.objects.filter(site=site, is_active=True).order_by("-published_at", "-created_at").first()

def _au_plus_pres_de(qs, locale):
    """
    Les enregistrements de `qs` dans la langue demandée — ou, à défaut, dans
    la plus proche, par élargissements successifs :

      1. la langue exacte (« en ») ;
      2. sa famille (« en-gb » accepte « en », « fr-fr » accepte « fr ») ;
      3. la langue du site, puis sa famille ;
      4. tout ce qui existe.

    L'ordre compte sur un site en plusieurs langues : un visiteur français
    dont le bandeau a été enregistré sous « fr » (et non « fr-fr ») doit
    recevoir celui-là, pas le bandeau anglais qui se trouverait être le plus
    récent. Et jamais rien : le consentement ne se recueille pas sur du vide.
    """
    if not locale:
        return qs
    defaut = default_locale()
    for filtre in (
        {"locale": locale},
        {"locale__startswith": locale.split("-")[0]},
        {"locale": defaut},
        {"locale__startswith": defaut.split("-")[0]},
    ):
        proches = qs.filter(**filtre)
        if proches.exists():
            return proches
    return qs


def _get_active_banner(site, locale: str | None = None) -> CookieBannerConfig | None:
    qs = CookieBannerConfig.objects.filter(site=site, is_active=True).order_by(
        "priority", "-updated_at"
    )
    return _au_plus_pres_de(qs, locale).first()

def _categories(site, locale: str | None = None):
    """
    Les catégories du site, dans la langue demandée — et jamais AUCUNE.

    Le filtrage par langue était exact : `locale="en"` ne rendait que les
    catégories enregistrées en anglais. Or elles ne sont saisies que dans la
    langue du site. Conséquences, invisibles tant que `LocaleMiddleware`
    n'était pas monté :

    * un visiteur anglophone obtenait une liste **vide** — donc une bannière
      de cookies sans aucune catégorie, ce qui n'est pas un affichage dégradé
      mais un manquement : le consentement ne peut pas être recueilli sur
      rien ;
    * `fr` et `fr-fr` ne se rencontraient pas. Les catégories sont créées avec
      `LANGUAGE_CODE` (« fr-fr ») tandis que `get_language()` rend la forme
      normalisée (« fr ») : la correspondance ne tenait qu'au fait que, sans
      middleware de langue, les deux valaient « fr-fr ».

    On procède donc par élargissements successifs : la langue exacte, puis sa
    famille (« en-gb » accepte « en »), puis la langue du site. La liste finale
    n'est jamais vide s'il existe la moindre catégorie.
    """
    base = CookieCategory.objects.filter(site=site, is_active=True).order_by(
        "display_order", "key"
    )
    # Aucune correspondance de langue : mieux vaut la bannière dans une
    # langue que pas de bannière du tout — voir `_au_plus_pres_de`.
    return _au_plus_pres_de(base, locale)

def _default_choices_for_site(site, locale: str | None = None) -> dict:
    out = {}
    for cat in _categories(site, locale):
        out[cat.key] = True if cat.is_essential else bool(cat.default_enabled)
    return out

def _load_consent_from_cookie(request) -> dict | None:
    raw = request.COOKIES.get(CONSENT_COOKIE_NAME)
    if not raw:
        return None
    try:
        data = signing.loads(raw, salt=CONSENT_COOKIE_SALT)
        # attendu: {"v": "...", "choices": {...}, "ts": "..."}
        if isinstance(data, dict) and "choices" in data:
            return data
    except signing.BadSignature:
        return None
    return None

def _set_consent_cookie(response, request, payload: dict):
    """
    payload: {"v": "1.0", "choices": {...}, "ts": "..."}
    - Cookie lisible par JS (HttpOnly=False) pour que le front puisse déterminer l'état.
    - Signé pour éviter la falsification côté client.
    """
    signed = signing.dumps(payload, salt=CONSENT_COOKIE_SALT)
    secure = True if request.is_secure() or getattr(settings, "SESSION_COOKIE_SECURE", False) else False

    # Rappel : pour empêcher l'usage ailleurs, on ne définit PAS Domain (host-only), Path="/",
    # et on peut viser SameSite="Strict" si c'est compatible avec ton UX.
    response.set_cookie(
        key=CONSENT_COOKIE_NAME,
        value=signed,
        max_age=CONSENT_COOKIE_MAX_AGE,
        path="/",
        secure=secure,
        httponly=False,  # lisible par JS si nécessaire
        samesite=CONSENT_COOKIE_SAMESITE,  # "Lax" recommandé ; "Strict" si tu veux être plus restrictif
    )


# --------- API: status / banner / consent --------
@method_decorator(ensure_csrf_cookie, name="dispatch")
class ConsentStatusView(View):
    """
    GET /api/cookies/status
    Retourne l'état actuel du consentement + config utile.
    """
    def get(self, request, *args, **kwargs):
        site = get_current_site(request)
        locale = _current_locale(request)

        # Lire cookie signé si présent
        cookie_state = _load_consent_from_cookie(request)

        # Déterminer la version de politique active (ou fallback "1.0")
        policy = _get_active_policy(site)
        policy_version = policy.version if policy else "1.0"

        # Catégories
        cats = list(_categories(site, locale))
        cats_payload = [
            {
                "key": c.key,
                "label": _dans_la_langue(c.label, c.locale, locale),
                "description": _dans_la_langue(c.description, c.locale, locale),
                "is_essential": c.is_essential,
                "default_enabled": c.default_enabled,
            }
            for c in cats
        ]

        # Choix actuels
        if cookie_state and isinstance(cookie_state.get("choices"), dict):
            choices = cookie_state["choices"]
        else:
            choices = _default_choices_for_site(site, locale)

        # Bannière active (textes)
        banner = _get_active_banner(site, locale)
        banner_payload = None
        if banner:
            banner_payload = {
                **_textes_du_bandeau(banner, locale),
                "more_info_url": banner.more_info_url,
                "show_refuse_all": banner.show_refuse_all,
                "style": banner.style or {},
            }

        # App settings (tracking staff/superusers)
        app_settings = getattr(site, "cookie_app_settings", None)
        disable_staff = bool(getattr(app_settings, "disable_tracking_for_staff", True))
        disable_super = bool(getattr(app_settings, "disable_tracking_for_superusers", True))
        tracking_allowed = True
        if (disable_staff and request.user.is_staff) or (disable_super and request.user.is_superuser):
            tracking_allowed = False

        return JsonResponse({
            "policy_version": policy_version,
            "choices": choices,
            "categories": cats_payload,
            "banner": banner_payload,
            "tracking_allowed": tracking_allowed,
            "ts": _now_iso(),
        }, status=200)


class BannerConfigView(View):
    """
    GET /api/cookies/banner
    """
    def get(self, request, *args, **kwargs):
        site = get_current_site(request)
        locale = _current_locale(request)
        banner = _get_active_banner(site, locale)
        if not banner:
            return JsonResponse({"banner": None}, status=200)

        data = {
            **_textes_du_bandeau(banner, locale),
            "more_info_url": banner.more_info_url,
            "show_refuse_all": banner.show_refuse_all,
            # ✅ NOUVEAU : style JSON contrôlé
            "style": banner.style or {},
        }
        return JsonResponse({"banner": data}, status=200)


class ConsentPersistView(View):
    """
    POST /api/cookies/consent
    Body JSON: { "choices": {"analytics": true, ...}, "source": "banner|panel" (optional) }
    - Force 'essential' = True
    - Enregistre CookieConsent
    - Dépose un cookie signé (lisible JS) avec version + choices
    """
    def post(self, request, *args, **kwargs):
        # Chaque appel crée une ligne CookieConsent ET force la création d'une
        # session côté anonyme : deux tables grossissent sans limite depuis
        # l'extérieur. La preuve de consentement, qui est une obligation,
        # devenait le vecteur. Plafond confortable : un visiteur qui hésite
        # entre « tout accepter » et « personnaliser » fait quelques appels,
        # pas quelques centaines.
        if rate_limited(request, "cookies:consent", 60, 3600):
            return JsonResponse(
                {"ok": False, "message": _("Trop de requêtes.")}, status=429
            )

        site = get_current_site(request)
        locale = _current_locale(request)

        # Policy version
        policy = _get_active_policy(site)
        policy_version = policy.version if policy else "1.0"

        try:
            payload = json.loads(request.body.decode("utf-8"))
        except Exception:
            return HttpResponseBadRequest("Invalid JSON")
        posted_choices = payload.get("choices") or {}
        source = payload.get("source") or "banner"

        # Charger catégories et construire form dynamique
        cats = list(_categories(site, locale))
        # Construire des data POST "comme un form" :
        form_data = {}
        for cat in cats:
            key = cat.key
            want = bool(posted_choices.get(key, False))
            if cat.is_essential:
                want = True
            # BooleanField: pour False, on omet le champ ; pour True, on met 'on'
            if want:
                form_data[f"cat__{key}"] = "on"

        form = ConsentPreferencesForm(data=form_data, categories=cats)
        if not form.is_valid():
            return HttpResponseBadRequest("Invalid choices")

        choices = form.choices_dict()

        # Enregistrer la preuve (user nullable, session_key si dispo)
        session_key = request.session.session_key or ""
        if not session_key:
            # `create()` et non `save()` : ce dernier écrit bien en base, mais ne
            # marque pas la session comme modifiée — le middleware n'émettait
            # donc jamais le cookie, et chaque appel repartait sur une session
            # neuve. Conséquence sur la preuve : le dédoublonnage de
            # `CookieConsent.save()` filtre sur `session_key` et ne retrouvait
            # jamais l'enregistrement précédent, si bien que TOUS les
            # consentements d'un visiteur anonyme restaient marqués « courant ».
            # Impossible, dans ce cas, de dire lequel fait foi.
            request.session.create()
            session_key = request.session.session_key or ""

        ip_trunc = _truncate_ip(request.META.get("REMOTE_ADDR"))
        ua = request.META.get("HTTP_USER_AGENT", "")[:1000]  # limiter longueur

        consent = CookieConsent.objects.create(
            site=site,
            locale=locale,
            user=request.user if request.user.is_authenticated else None,
            session_key=session_key,
            ip_truncated=ip_trunc,
            user_agent=ua,
            choices=choices,
            policy_version=policy_version,
            source=source,
            is_latest=True,
        )

        # Déposer le cookie signé (lisible par JS)
        response = JsonResponse({
            "ok": True,
            "policy_version": policy_version,
            "choices": choices,
            "consent_token": str(consent.consent_token),
            "ts": _now_iso(),
        }, status=200)

        cookie_payload = {
            "v": policy_version,
            "choices": choices,
            "ts": _now_iso(),
        }
        _set_consent_cookie(response, request, cookie_payload)
        return response


# --------- Page "Cookies & Vie privée" (rendue côté serveur, optionnel) ---------

class CookiePolicyPageView(TemplateView):
    """
    Page documentaire /cookies/ (optionnelle)
    Template par défaut: templates/cookies/policy.html
    Contexte : catégories, définitions, vendors, version active
    """
    template_name = "cookies/policy.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        request = self.request
        site = get_current_site(request)
        locale = _current_locale(request)

        ctx["policy"] = _get_active_policy(site)
        ctx["categories"] = _categories(site, locale)
        # Les cookies ne sont décrits que dans la langue du site : un lecteur
        # d'une autre langue lit cette liste plutôt qu'une liste vide.
        ctx["definitions"] = _au_plus_pres_de(
            CookieDefinition.objects.filter(site=site).order_by("name"), locale
        )
        ctx["vendors"] = CookieVendor.objects.filter(site=site, is_active=True).order_by("name")
        return ctx
