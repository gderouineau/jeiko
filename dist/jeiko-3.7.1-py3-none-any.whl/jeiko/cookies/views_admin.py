# cookies/views_admin.py
import csv
from io import StringIO
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.sites.shortcuts import get_current_site
from django.http import JsonResponse, HttpResponse, HttpResponseBadRequest
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views import View

from django.utils.translation import get_language

from django.shortcuts import render, redirect

from django.contrib import messages

from .forms_admin import BannerTextUpdateForm

from .models import (
    CookieBannerConfig,
    CookiePolicyVersion,
    CookieConsent,
    CookieAppSettings,
)

from .views import _current_locale, _get_active_policy

from .forms import CookieBannerConfigForm
from django.utils.translation import gettext_lazy as _


@method_decorator(staff_member_required, name="dispatch")
class ActivateBannerView(View):
    """
    POST /admin/cookies/activate-banner/<int:banner_id>/
    Body vide. Active la bannière et désactive les autres pour le site/locale.
    """
    def post(self, request, banner_id, *args, **kwargs):
        try:
            banner = CookieBannerConfig.objects.get(pk=banner_id)
        except CookieBannerConfig.DoesNotExist:
            return HttpResponseBadRequest("Bannière introuvable")
        banner.activate()
        return JsonResponse({"ok": True, "banner_id": banner_id})


@method_decorator(staff_member_required, name="dispatch")
class ActivatePolicyVersionView(View):
    """
    POST /admin/cookies/activate-policy/<int:policy_id>/
    Active la version de politique donnée et désactive les autres (site/locale).
    """
    def post(self, request, policy_id, *args, **kwargs):
        try:
            policy = CookiePolicyVersion.objects.get(pk=policy_id)
        except CookiePolicyVersion.DoesNotExist:
            return HttpResponseBadRequest("Version introuvable")
        policy.activate()
        return JsonResponse({"ok": True, "policy_id": policy_id, "version": policy.version})


@method_decorator(staff_member_required, name="dispatch")
class ExportConsentsCSVView(View):
    """
    GET /admin/cookies/consents/export/
    Exporte les consentements en CSV (simple).
    """
    def get(self, request, *args, **kwargs):
        site = get_current_site(request)
        qs = CookieConsent.objects.filter(site=site).order_by("-created_at")

        buffer = StringIO()
        writer = csv.writer(buffer)
        writer.writerow([
            "id", "created_at", "locale", "user_id", "session_key",
            "ip_truncated", "user_agent", "policy_version", "source",
            "is_latest", "choices", "consent_token",
        ])

        for c in qs.iterator():
            writer.writerow([
                str(c.id),
                c.created_at.isoformat(),
                c.locale,
                c.user_id or "",
                c.session_key,
                c.ip_truncated,
                (c.user_agent or "")[:200],  # tronqué pour lisibilité
                c.policy_version,
                c.source,
                "1" if c.is_latest else "0",
                c.choices,
                str(c.consent_token),
            ])

        resp = HttpResponse(buffer.getvalue(), content_type="text/csv; charset=utf-8")
        resp["Content-Disposition"] = 'attachment; filename="cookie_consents.csv"'
        return resp


@method_decorator(staff_member_required, name="dispatch")
class PurgeOldConsentsView(View):
    """
    POST /admin/cookies/consents/purge/
    Supprime les consentements plus vieux que retention_days (CookieAppSettings) ou 730j par défaut.
    """
    def post(self, request, *args, **kwargs):
        site = get_current_site(request)
        app_settings = getattr(site, "cookie_app_settings", None)
        retention_days = getattr(app_settings, "retention_days", 730)
        cutoff = timezone.now() - timezone.timedelta(days=retention_days)
        qs = CookieConsent.objects.filter(site=site, created_at__lt=cutoff)
        count = qs.count()
        qs.delete()
        return JsonResponse({"ok": True, "deleted": count, "cutoff": cutoff.isoformat()})




@method_decorator(staff_member_required, name="dispatch")
class EditBannerTextView(View):
    """
    GET/POST /admin/cookies/banner/edit/
    Édite message + labels + style JSON de la bannière (site/locale).
    Crée une bannière si aucune n'existe (et l’active).
    """
    template_name = "cookies/banner_edit.html"

    def _get_or_create_banner(self, site, locale):
        from .models import default_locale

        bandeaux = CookieBannerConfig.objects.filter(site=site).order_by(
            "-is_active", "-updated_at"
        )
        banner = bandeaux.filter(locale=locale).first()
        if banner is None and locale == default_locale():
            # Le bandeau du site a pu être enregistré sous « fr » quand la
            # langue du site est « fr-fr » (l'ancien écran prenait la langue de
            # l'administrateur). C'est celui-là que voient les visiteurs :
            # c'est lui qu'on édite, plutôt que d'en créer un second.
            banner = bandeaux.filter(locale__startswith=locale.split("-")[0]).first()
        if not banner:
            from django.utils import translation
            from django.utils.translation import gettext

            policy = _get_active_policy(site)
            # Le bandeau d'une langue ajoutée naît avec les textes d'origine
            # DANS cette langue, et l'apparence de celui du site : il n'y a
            # plus qu'à retoucher la phrase.
            famille = default_locale().split("-")[0]
            origine = (
                bandeaux.filter(locale=default_locale()).first()
                or bandeaux.filter(locale__startswith=famille).first()
            )
            with translation.override(locale):
                textes = dict(
                    message_text=gettext("Nous utilisons des cookies essentiels au fonctionnement du site."),
                    accept_all_label=gettext("Tout accepter"),
                    refuse_all_label=gettext("Tout refuser"),
                    customize_label=gettext("Personnaliser"),
                    save_choices_label=gettext("Enregistrer"),
                    more_info_label=gettext("En savoir plus"),
                )
            banner = CookieBannerConfig.objects.create(
                site=site,
                locale=locale,
                policy=policy,
                more_info_url=origine.more_info_url if origine else "",
                show_refuse_all=origine.show_refuse_all if origine else True,
                is_active=True,
                priority=100,
                # style a déjà un default callable → rien à passer
                **({"style": origine.style} if origine and locale != origine.locale else {}),
                **textes,
            )
        return banner

    @staticmethod
    def _locale_editee(request):
        """
        Le bandeau qu'on édite : celui du site, ou — `?langue=en` — celui
        d'une langue ajoutée. Jamais la langue de l'administrateur.
        """
        from jeiko.langues_du_site import langues_actives

        from .models import default_locale

        code = request.GET.get("langue") or request.POST.get("langue") or ""
        return code if code in langues_actives() else default_locale()

    def _contexte(self, request, form, banner, locale):
        """
        `locale` : la langue DEMANDÉE (celle de l'onglet), pas `banner.locale` —
        le bandeau du site peut être enregistré sous « fr » quand la langue du
        site est « fr-fr », et c'est pourtant bien l'onglet d'origine.
        """
        from jeiko.langues_du_site import langue_d_origine, langues_actives, nom_de_la_langue

        from .models import default_locale

        d_origine = locale == default_locale()
        onglets = [
            {"code": "", "nom": nom_de_la_langue(langue_d_origine()), "courant": d_origine}
        ] + [
            {"code": c, "nom": nom_de_la_langue(c), "courant": locale == c}
            for c in langues_actives()
        ] if langues_actives() else []
        return {
            "form": form, "banner": banner, "onglets": onglets,
            "langue_editee": "" if d_origine else locale,
        }

    def get(self, request, *args, **kwargs):
        site = get_current_site(request)
        locale = self._locale_editee(request)
        banner = self._get_or_create_banner(site, locale)

        form = CookieBannerConfigForm(instance=banner)
        # Si ton SiteAwareFormMixin attend _site :
        setattr(form, "_site", site)

        return render(request, self.template_name, self._contexte(request, form, banner, locale))

    def post(self, request, *args, **kwargs):
        site = get_current_site(request)
        locale = self._locale_editee(request)
        banner = self._get_or_create_banner(site, locale)

        form = CookieBannerConfigForm(request.POST, instance=banner)
        setattr(form, "_site", site)

        if form.is_valid():
            form.save()
            messages.success(request, _("Bannière mise à jour."))
            suite = redirect("jeiko_cookies_admin:edit_banner_text")
            from .models import default_locale
            if locale != default_locale():
                # On reste sur l'onglet de la langue qu'on vient d'enregistrer.
                suite["Location"] += f"?langue={locale}"
            return suite

        return render(request, self.template_name, self._contexte(request, form, banner, locale), status=400)
