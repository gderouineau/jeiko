# stats/middleware.py
"""
Mesure d'audience — et pourquoi elle ne demande aucun consentement (R-01).

Ce qui est enregistré, et ce qui ne l'est pas
--------------------------------------------
Une ligne `PageView` porte : le chemin, le référent, le jour, le code de
réponse, quatre drapeaux (référent interne, page d'entrée, visiteur connecté,
robot, mobile), la taille de la réponse et le temps passé.

Elle ne porte **ni adresse IP, ni identifiant de session, ni identifiant de
compte, ni empreinte de navigateur**. Deux vues consécutives du même visiteur
sont indiscernables de deux vues de deux visiteurs différents : il n'existe
aucun moyen, dans ces données, de relier une ligne à une personne.

Et rien n'est déposé sur l'appareil : le beacon de temps passé
(`_try_inject_beacon_script`) renvoie l'identifiant de la vue — tiré au sort
côté serveur, jamais stocké côté client — et une durée. Pas de cookie, pas de
`localStorage`.

La conséquence
--------------
Le consentement de la directive ePrivacy porte sur le fait de **stocker ou de
lire une information sur l'appareil** : sans cookie ni stockage local, il n'est
pas déclenché. Et le RGPD demande une base légale pour des **données
personnelles** : il n'y en a pas ici.

Cette mesure n'a donc rien à demander, et rien à interrompre. C'est pour cela
que les fonctions `startAnalytics` / `stopAnalytics` des gabarits de base sont
vides : elles appelaient une mesure qui n'a jamais existé, derrière un `if` qui
rendait le vide invisible.

⚠️ Ce qui ferait basculer tout cela
-----------------------------------
Ajouter à `PageView` un champ `ip`, `session_key`, `user`, ou toute empreinte
d'appareil — même « pour dédoublonner les visiteurs » — fait entrer cette
mesure dans le RGPD, et un cookie l'y ferait entrer par ePrivacy. Ce serait un
changement de nature, pas une amélioration : il exigerait un consentement
préalable, une information, une durée de conservation et une base légale.

Si ce besoin se présente, la bonne réponse est de le traiter comme un nouveau
dispositif, pas comme une colonne de plus.
"""

import logging
import re
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from django.conf import settings
from django.db import connections
from django.utils import timezone
from django.urls import reverse, NoReverseMatch
from .models import PageView

logger = logging.getLogger("jeiko.stats")

# Pool dédié à l'écriture des vues de page hors du chemin de réponse. Deux
# threads suffisent : un INSERT est court, et on ne veut pas ouvrir une nuée de
# connexions PostgreSQL en pic de trafic. À l'arrêt de l'interpréteur,
# concurrent.futures joint les threads en cours : les INSERT en vol se terminent.
_PERSIST_EXECUTOR = ThreadPoolExecutor(max_workers=2, thread_name_prefix="jeiko-pageview")

#: Plafond de la file d'attente d'écriture.
#:
#: `ThreadPoolExecutor` accepte les tâches dans une file EN MÉMOIRE ET SANS
#: LIMITE. Si la base ralentit ou se bloque, les INSERT s'accumulent au rythme
#: des requêtes entrantes, sans que rien ne freine : la mémoire du worker monte
#: jusqu'à ce que le noyau le tue. Une mesure d'audience ne doit jamais pouvoir
#: emporter le site qu'elle observe.
#:
#: Passé ce seuil on renonce à la vue de page. C'est le bon arbitrage : perdre
#: quelques lignes de statistique pendant un incident est sans conséquence,
#: perdre le site n'en est pas une.
FILE_MAX = 1000

#: Compteur des tâches en vol. Un entier suffit — le GIL rend l'incrément et
#: le décrément atomiques, et une approximation à une unité près n'a aucune
#: incidence sur un plafond de mille.
_en_vol = 0
_dernier_avertissement = 0.0


def _persist_pageview_async(fields):
    """
    Crée le PageView dans un thread du pool. Django ouvre une connexion propre
    au thread ; on la ferme en fin de tâche pour ne pas laisser filer une
    connexion par thread réutilisé (CONN_MAX_AGE la garderait sinon ouverte).
    """
    global _en_vol
    try:
        PageView.objects.create(**fields)
    except Exception:
        logger.exception("Enregistrement PageView asynchrone impossible (path=%s)",
                         fields.get("path"))
    finally:
        _en_vol -= 1
        connections.close_all()


def _soumettre(fields):
    """
    Confie l'écriture au pool, sauf si la file est déjà pleine.

    Retourne True si la tâche a été acceptée.
    """
    global _en_vol, _dernier_avertissement

    if _en_vol >= FILE_MAX:
        # Journal volontairement espacé : sous saturation, l'événement se
        # produirait à chaque requête et le journal deviendrait lui-même une
        # charge — on remplacerait une saturation par une autre.
        maintenant = time.monotonic()
        if maintenant - _dernier_avertissement > 60:
            _dernier_avertissement = maintenant
            logger.warning(
                "File d'écriture des vues de page saturée (%s en attente) : "
                "mesure d'audience suspendue le temps que la base rattrape.",
                _en_vol,
            )
        return False

    _en_vol += 1
    try:
        _PERSIST_EXECUTOR.submit(_persist_pageview_async, fields)
    except RuntimeError:
        # Pool arrêté (extinction du processus) : rien à mesurer de plus.
        _en_vol -= 1
        return False
    return True

BOT_RE = re.compile(
    r"("
    r"bot|crawler|spider|slurp|uptime|monitor|pingdom|crawl|scan|checker|fetch|proxy|archiver|"
    r"googlebot|bingbot|yandex|baiduspider|duckduckbot|sogou|exabot|qwantify|"
    r"gptbot|claudebot|anthropic|perplexitybot|bytespider|ccbot|cohere-ai|omgilibot|diffbot|facebookbot|turnitinbot|imagesiftbot|youbot|"
    r"semrushbot|ahrefsbot|mj12bot|dotbot|seznambot|screaming\s*frog|dataforseobot|linkdexbot|serpstatbot|rogersbot|siteauditbot|"
    r"python-requests|python-urllib|httpx|aiohttp|curl/|wget/|httpie|go-http-client|java/|postmanruntime|insomnia|axios|node-fetch|libwww-perl|zgrab|nmap|masscan|nikto|sqlmap|censys|shodan|"
    r"facebookexternalhit|twitterbot|linkedinbot|whatsapp|telegrambot|discordbot|applebot|slackbot|skypeuripreview|"
    r"headlesschrome|phantomjs|selenium|puppeteer|playwright|cypress|webdriver"
    r")",
    re.I
)

MOBILE_RE = re.compile(r"(android|iphone|ipad|ipod|mobile|blackberry|iemobile|opera mini)", re.I)

IGNORED_EXTENSIONS = (
    ".ico", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".css", ".js",
    ".map", ".xml", ".json", ".txt", ".php", ".pdf", ".zip", ".gz", ".woff",
    ".woff2", ".ttf", ".eot", ".mp3", ".mp4"
)

IGNORED_PATH_PREFIXES = (
    "/.well-known/", "/robots.txt", "/favicon.ico", "/sitemap.xml",
    "/apple-touch-icon", "/.env", "/.git", "/wp-", "/phpmyadmin"
)

def _is_probably_bot(user_agent: str) -> bool:
    if not user_agent or not user_agent.strip():
        return True
    return bool(BOT_RE.search(user_agent))

def _is_mobile_device(user_agent: str) -> bool:
    if not user_agent:
        return False
    return bool(MOBILE_RE.search(user_agent))

def _safe_int(v):
    try:
        return int(v)
    except Exception:
        return None

def _path_is_ignored(path: str) -> bool:
    path_lower = path.lower()
    
    if any(path_lower.endswith(ext) for ext in IGNORED_EXTENSIONS):
        return True
        
    if any(path_lower.startswith(prefix) for prefix in IGNORED_PATH_PREFIXES):
        return True

    prefixes = getattr(settings, "STATS_IGNORE_PATH_PREFIXES", [])
    if prefixes:
        for p in prefixes:
            # Les préfixes intégrés sont insensibles à la casse. Appliquer la
            # même règle aux préfixes configurés évite qu'une simple majuscule
            # réintroduise dans les statistiques une route pourtant exclue.
            if path_lower.startswith(str(p).lower()):
                return True
    return False

def _canon_host(h: str | None) -> str:
    """Hôte comparable : sans port, sans ``www.``, en minuscules.

    Une adresse IPv6 s'écrit entre crochets dans un en-tête Host ou une URL
    (``[2001:db8::1]:8000``) : la couper au premier ``:`` donnait ``[2001``,
    si bien que deux machines distinctes du même préfixe se confondaient, et
    qu'un référent extérieur passait pour interne (Q-04). On retire donc le
    port APRÈS le crochet fermant. Une IPv6 nue, sans crochets ni port, est
    gardée entière : plusieurs ``:`` ne peuvent pas y annoncer un port.
    """
    if not h:
        return ""
    h = h.strip().lower()
    if h.startswith("["):
        fin = h.find("]")
        h = h[1:fin] if fin != -1 else h[1:]
    elif h.count(":") == 1:
        h = h.split(":")[0]
    if h.startswith("www."):
        h = h[4:]
    return h

def _is_internal_by_host(request, ref_netloc: str | None) -> bool:
    if not ref_netloc:
        return True
    try:
        cur_host = request.get_host()
    except Exception:
        cur_host = request.META.get("HTTP_HOST", "")
    cur = _canon_host(cur_host)
    ref = _canon_host(ref_netloc)
    if cur and ref == cur:
        return True
    extra = getattr(settings, "STATS_INTERNAL_HOSTS", [])
    extra_norm = {_canon_host(x) for x in extra if x}
    return ref in extra_norm

def _beacon_url() -> str:
    try:
        return reverse("stats_track_exit")
    except NoReverseMatch:
        return getattr(settings, "STATS_TRACK_EXIT_URL", "/stats/track-exit/")

def _try_inject_beacon_script(response, pageview_id: str):
    try:
        if getattr(response, "streaming", False):
            return
        
        if response.has_header("Content-Encoding"):
            return
            
        content = response.content
        if not isinstance(content, (bytes, bytearray)):
            return
            
        body_close = b"</body>"
        idx = content.lower().rfind(body_close)
        if idx == -1:
            return

        beacon = _beacon_url()
        snippet = f"""
<script>
(function(){{try{{
    var start = performance.now(), sent=false;
    function send(ms){{
        if(sent) return; sent=true;
        var data = JSON.stringify({{id:"{pageview_id}", d: Math.round(ms)}});
        navigator.sendBeacon("{beacon}", new Blob([data], {{type:"application/json"}}));
    }}
    function handler(){{ send(performance.now()-start); }}
    document.addEventListener("visibilitychange", function(){{ if(document.visibilityState==="hidden"){{ handler(); }} }});
    window.addEventListener("pagehide", handler);
}}catch(e){{}}}})();
</script>
""".encode("utf-8")
        response.content = content[:idx] + snippet + content[idx:]
        if response.has_header("Content-Length"):
            response["Content-Length"] = str(len(response.content))
    except Exception:
        pass

class PageViewCounterMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        try:
            if request.method != "GET":
                return response

            user = getattr(request, "user", None)
            if user and getattr(user, "is_authenticated", False) and (user.is_staff or user.is_superuser):
                return response

            path = request.path or "/"

            admin_url = getattr(settings, "ADMIN_URL", "/admin/")
            if path.startswith(admin_url):
                return response

            if _path_is_ignored(path):
                return response

            status = getattr(response, "status_code", 0) or 0
            if status != 200:
                return response

            ct = response.get("Content-Type", "")
            if not ct.startswith("text/html"):
                return response

            ua = request.META.get("HTTP_USER_AGENT", "")
            is_bot = _is_probably_bot(ua)
            is_mobile = _is_mobile_device(ua)

            if is_bot and getattr(settings, "STATS_IGNORE_BOTS", False):
                return response

            ref_raw = request.META.get("HTTP_REFERER", "")
            referrer_path = None
            referrer_domain = None
            is_internal_referrer = False

            if ref_raw:
                p = urlparse(ref_raw)
                if _is_internal_by_host(request, p.netloc):
                    is_internal_referrer = True
                    referrer_path = p.path or "/"
                else:
                    is_internal_referrer = False
                    referrer_domain = _canon_host(p.netloc) or "direct"
            else:
                referrer_domain = "direct"

            is_entry = (not is_internal_referrer) and (not is_bot)

            # La PK est un UUID à défaut Python (PageView.id = UUIDField) : on la
            # génère ici, sans toucher la base. Le beacon peut donc être injecté
            # immédiatement et l'INSERT partir en tâche de fond — l'écriture ne
            # bloque plus le TTFB. content_length est lu AVANT l'injection (comme
            # avant) : c'est la taille du corps effectivement rendu par la vue.
            fields = dict(
                id=uuid.uuid4(),
                path=path,
                referrer_path=referrer_path,
                referrer_domain=referrer_domain,
                day=timezone.localdate(),
                status_code=status,
                is_internal_referrer=is_internal_referrer,
                is_entry=is_entry,
                is_authenticated=bool(user and getattr(user, "is_authenticated", False)),
                is_bot=is_bot,
                is_mobile=is_mobile,
                content_length=_safe_int(response.get("Content-Length")),
            )

            if getattr(settings, "STATS_ASYNC", True):
                # L'INSERT part au thread de fond et ne retarde jamais la
                # réponse. Au-delà de FILE_MAX tâches en attente, la vue est
                # abandonnée plutôt qu'empilée : voir le commentaire de FILE_MAX.
                _soumettre(fields)
            else:
                # Mode synchrone (tests, diagnostic) : même connexion que la
                # requête, pas de fermeture — on ne casse pas la transaction de
                # test.
                PageView.objects.create(**fields)

            if not is_bot and getattr(settings, "STATS_ENABLE_DWELL", True):
                _try_inject_beacon_script(response, str(fields["id"]))

        except Exception:
            pass

        return response
