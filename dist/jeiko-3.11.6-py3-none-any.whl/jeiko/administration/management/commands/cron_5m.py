"""
Tâches planifiées — toutes les 5 minutes.

Lancé par le timer systemd jeiko-cron-5m@<site>.timer.

Jobs :
  - rappels de rendez-vous (24 h et 2 h avant — 1 h en visio), idempotents ;
  - vidage de la file d'attente des e-mails différés, et reprise des envois
    en échec (trois nouveaux essais : 5 min, 30 min, 2 h) ;
  - un lot de newsletter, sous le plafond horaire (NEWS-01) ;
  - les gros imports d'abonnés, deux minutes par passage (NEWS-03) ;
  - rappels des séances en visio, la veille et une heure avant (VISIO-01) ;
  - rattrapage des salles de visio : retirer qui n'a plus de lien, refermer
    ce qui doit l'être (visio/acces.reconcilier, audit V-02) ;
  - remboursements des places de visio non livrées : les essais dont l'heure
    est venue (visio/vente.relancer_les_remboursements, audit V-07) ;
  - libération des créneaux payants non réglés ;
  - signalement des erreurs 500 à l'exploitant (administration/erreurs.py) ;
  - copie statique de la page 500, si elle a changé (pages_erreur.py) ;
  - historique des pages : une version de chaque page modifiée puis laissée
    tranquille, et les brouillons programmés publiés à leur heure
    (administration_pages/historique.py).
"""
from jeiko.administration.management.commands._cron import CronCommand


def job_appointment_reminders():
    from jeiko.calendars.emailing import send_due_reminders
    sent_24h, sent_2h, sent_pro = send_due_reminders()
    return (f"{sent_24h} rappel(s) client 24 h, {sent_2h} à 2 h, "
            f"{sent_pro} rappel(s) praticien 1 h")


def job_flush_email_queue():
    from jeiko.emailing.services import flush_queue, reprendre_les_echecs
    sent, failed = flush_queue()
    repris, encore = reprendre_les_echecs()
    return (f"{sent} envoyé(s), {failed} échec(s) ; "
            f"échecs repris : {repris} envoyé(s), {encore} encore en échec")


def job_newsletter():
    from jeiko.newsletter.envoi import envoyer_un_lot
    return f"{envoyer_un_lot()} newsletter(s) envoyée(s)"


def job_imports_newsletter():
    from jeiko.newsletter.imports import poursuivre_les_imports
    return f"{poursuivre_les_imports()} ligne(s) d'import traitée(s)"


def job_rattrapage_visio():
    from jeiko.visio.acces import reconcilier_les_seances_en_cours
    return f"{reconcilier_les_seances_en_cours()} séance(s) de visio vérifiée(s)"


def job_remboursements_visio():
    from jeiko.visio.vente import relancer_les_remboursements
    return f"{relancer_les_remboursements()} remboursement(s) de place essayé(s)"


def job_rappels_visio():
    from jeiko.visio.suivi import envoyer_les_rappels
    return f"{envoyer_les_rappels()} rappel(s) de visio"


def job_expire_holds():
    from jeiko.calendars import payments
    released = payments.expire_holds()
    return f"{released} créneau(x) libéré(s)"


def job_signaler_les_erreurs():
    from jeiko.administration.erreurs import signaler
    return f"{signaler()} erreur(s) 500 signalée(s)"


def job_copie_de_la_page_500():
    from jeiko.administration_pages.pages_erreur import rafraichir_la_page_500
    return rafraichir_la_page_500()


def job_historique_des_pages():
    from jeiko.administration_pages.historique import historiser_les_pages_modifiees, publier_les_brouillons_dus
    publies = publier_les_brouillons_dus()
    return f"{publies} brouillon(s) publié(s) ; {historiser_les_pages_modifiees()} version(s) de page gardée(s)"


class Command(CronCommand):
    help = "Tâches planifiées à exécuter toutes les 5 minutes."
    cadence = "5m"

    def get_jobs(self):
        return [
            ("rappels de rendez-vous", job_appointment_reminders),
            ("file d'attente e-mails", job_flush_email_queue),
            ("newsletter", job_newsletter),
            ("imports d'abonnés", job_imports_newsletter),
            ("rappels de visio", job_rappels_visio),
            ("rattrapage des salles de visio", job_rattrapage_visio),
            ("remboursements des places de visio", job_remboursements_visio),
            ("libération des créneaux non réglés", job_expire_holds),
            ("erreurs 500", job_signaler_les_erreurs),
            ("copie de la page 500", job_copie_de_la_page_500),
            ("historique des pages", job_historique_des_pages),
        ]
