"""
Navigation de l'espace d'administration, déclarée en données.

Pourquoi ce module existe
-------------------------
Le menu vivait dans `templates/includes/admin_menu.html` : 400 lignes de HTML
répétitif où chaque entrée recopiait à la main son libellé, son `{% url %}`,
sa garde de permission et son test d'état actif. Quatre familles de défauts en
découlaient, toutes constatées à l'audit :

*Des liens morts.* L'entrée « Shop » pointait sur `#`.

*Des états actifs qui ne s'allument jamais.* « Menus » comparait le nom de vue
`jeiko_administration_menu:main` alors que son lien visait `menu_list` ; une
autre entrée testait `url_name == ''`, jamais vrai.

*Des gardes de permission croisées.* La section Boutique était conditionnée par
`view_product / view_order / view_paymentgateway` mais contenait un item régi
par `view_producttype` : un rôle qui n'a que ce dernier ne voyait jamais son
écran. « Les calendriers » était conditionné par `view_googlecalendarconfig`,
sans rapport avec ce qu'il ouvre.

*Des écrans absents.* Sept écrans réels (e-mails, cookies, pages légales,
identité, serveur mail, API Google, mise à jour) n'apparaissaient nulle part :
on n'y accédait que par la pile de liens de l'accueil.

Déclarer la navigation en données rend ces quatre défauts structurellement
impossibles : l'URL est résolue par `reverse()` (un nom faux lève à la
construction au lieu de produire un lien mort), l'état actif se déduit du nom
de vue courant, et la garde de permission est portée par l'item lui-même — donc
une section est visible exactement quand au moins un de ses items l'est.

Ajouter un écran au menu = ajouter une ligne ici.
"""

from dataclasses import dataclass, field as dc_field
from typing import Tuple

from django.urls import NoReverseMatch, reverse
import logging

from django.utils.translation import gettext_lazy as _

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class NavItem:
    """Une entrée de menu.

    `perms` : l'item est visible si l'utilisateur détient **au moins une** de
    ces permissions (OU logique). Vide = visible par quiconque atteint l'admin.

    `staff_only` : réservé aux comptes `is_staff`, pour un écran gardé par
    `staff_member_required` plutôt que par le backend de rôles — le menu doit
    refléter la garde réelle, sinon il propose un écran qui renverra
    l'utilisateur vers une page de connexion. Cookies, pages légales et
    identité sont passés aux rôles le 09/10/2026 (D-08).

    `also_active` : autres noms de vue qui allument cette entrée, pour qu'une
    sous-page (formulaire, détail) garde son parent en surbrillance.
    """

    label: str
    url_name: str
    perms: Tuple[str, ...] = ()
    staff_only: bool = False
    superuser_only: bool = False
    also_active: Tuple[str, ...] = ()
    #: Nom d'un compteur calculé par `_badges()`. Non nul, il s'affiche sur
    #: l'entrée ET se cumule sur sa section — sans quoi une notification posée
    #: dans une section repliée resterait invisible.
    badge: str = ""
    #: Une entrée qui ouvre une PAGE À ONGLETS (A-67, A-89) : chaque onglet
    #: est un écran existant, avec son adresse et sa garde. L'entrée est
    #: visible si un onglet l'est, mène au premier onglet permis, et s'allume
    #: sur chacun. La barre d'onglets est posée par `base_admin.html`
    #: (`onglets_admin`) : un onglet sans droit n'y apparaît pas.
    onglets: Tuple["NavItem", ...] = ()
    #: Nom d'un réglage qui doit être vrai pour que l'entrée existe — un
    #: module allumé par le .env, comme le serveur de licences (LIC-01).
    reglage: str = ""
    #: Module du site dont dépend l'entrée (administration/modules.py, MOD-01) :
    #: éteint dans Réglages › Général, l'entrée n'est pas montrée.
    module: str = ""
    #: Un onglet qui est une VUE D'UN MÊME ÉCRAN, choisie par l'adresse :
    #: (« quand », « passees ») mène à `?quand=passees` et ne s'allume que là ;
    #: une valeur vide est l'onglet par défaut, sans paramètre (ADMIN-01).
    parametre: Tuple[str, ...] = ()
    #: Le titre d'un GROUPE, quand son libellé de menu ne suffit pas hors du
    #: menu : « Réglages » sous Boutique s'intitule « Réglages de la
    #: boutique ». Vide : le libellé.
    titre: str = ""

    def is_visible(self, user) -> bool:
        if self.module:
            from jeiko.administration.modules import module_actif

            if not module_actif(self.module):
                return False
        if self.reglage:
            from django.conf import settings

            if not getattr(settings, self.reglage, False):
                return False
        if self.onglets:
            return any(o.is_visible(user) for o in self.onglets)
        if self.superuser_only and not user.is_superuser:
            return False
        if self.staff_only and not (user.is_staff or user.is_superuser):
            return False
        if not self.perms:
            return True
        return any(user.has_perm(p) for p in self.perms)

    def matches(self, view_name: str, params=None) -> bool:
        if self.onglets:
            return any(o.matches(view_name, params) for o in self.onglets)
        if view_name != self.url_name and view_name not in self.also_active:
            return False
        if self.parametre and params is not None:
            cle, valeur = self.parametre
            return (params.get(cle) or "") == valeur
        return True

    def adresse(self):
        url = reverse(self.url_name)
        if self.parametre and self.parametre[1]:
            url += f"?{self.parametre[0]}={self.parametre[1]}"
        return url

    def onglets_visibles(self, user):
        """[(onglet, url)] permis à `user`, dans l'ordre."""
        visibles = []
        for onglet in self.onglets:
            if not onglet.is_visible(user):
                continue
            try:
                visibles.append((onglet, onglet.adresse()))
            except NoReverseMatch:
                continue
        return visibles


@dataclass(frozen=True)
class NavSection:
    label: str
    items: Tuple[NavItem, ...] = dc_field(default_factory=tuple)
    #: Module du site dont dépend toute la section (MOD-01) : éteint, elle
    #: n'apparaît pas — ses écrans restent joignables par leur adresse.
    module: str = ""
    #: Une section d'UNE entrée qui porte son nom (« Tableau de bord ») : le
    #: menu la dessine en lien direct, sans repli à ouvrir pour un seul choix.
    direct: bool = False


# ---------------------------------------------------------------------------
# La navigation.
#
# Les libellés sont des noms de choses, pas des ordres : « Pages », pas « Voir
# les pages ». L'ancien menu mélangeait trois grammaires (« Voir les pages »,
# « Les modèles », « Gestion des créneaux ») et portait des fautes visibles
# (« Moyens de payment », « Gestion de accès », « Les roles »). Le menu fait
# 180 px de large : les libellés courts évitent le retour à la ligne.
# ---------------------------------------------------------------------------

NAVIGATION: Tuple[NavSection, ...] = (
    # L'ancienne entrée « Shop » de cette section pointait sur `#`. Elle n'est
    # pas remplacée : la boutique n'a pas de page d'index côté client (les URLs
    # publiques de `shop` ne couvrent que la fiche produit et le panier), donc
    # aucune cible honnête n'existe. Le jour où une page « boutique » est créée
    # dans les pages, ajouter ici son `url_name`.
    NavSection(_("Le site"), (
        NavItem(_("Voir le site"), "jeiko_pages:root_page"),
    )),

    # ADMIN-01 (Guillaume, 14/10/2026) : le tableau de bord est la VIE du
    # site — notifications, chiffres, mise en route, ce qui attend. Ce qu'on
    # règle une fois est dans Réglages. Ancienne section « Pilotage ».
    NavSection(_("Tableau de bord"), direct=True, items=(
        NavItem(_("Tableau de bord"), "jeiko_administration:main", badge="notifications", onglets=(
            NavItem(_("Résumé"), "jeiko_administration:main", perms=("users.access_admin",)),
            NavItem(_("Statistiques"), "jeiko_administration_stats:stats_overview",
                    perms=("users.config_edit_site",),
                    also_active=("jeiko_administration_stats:stats_pages",
                                 "jeiko_administration_stats:stats_page_detail")),
            NavItem(_("Mise en route"), "jeiko_administration:mise_en_route",
                    perms=("users.config_edit_site",)),
            # Ce que la protection des scripts aurait bloqué (S-03) : de quoi
            # décider du mode bloquant. Technique, donc superutilisateurs.
            NavItem(_("Signalements CSP"), "jeiko_administration:signalements_csp", superuser_only=True),
        )),
    )),

    # Réglages : une entrée par GROUPE, qui ouvre une page à onglets (A-67,
    # A-89, ADMIN-01). Un écran de configuration seul n'a pas d'entrée : il
    # est un onglet de son groupe (« API Google » dans Général, 14/10).
    NavSection(_("Réglages"), (
        NavItem(_("Général"), "jeiko_administration:modules", titre=_("Réglages généraux"), onglets=(
            NavItem(_("Général"), "jeiko_administration:modules", perms=("users.config_edit_site",)),
            NavItem(_("Notifications du menu"), "jeiko_administration:notifications",
                    perms=("users.config_edit_site",)),
            NavItem(_("Langues du site"), "jeiko_administration:langues_du_site",
                    perms=("users.config_edit_site",)),
            NavItem(_("Langue de l'administration"), "jeiko_administration:langue_admin",
                    perms=("users.config_edit_site",)),
            NavItem(_("Logo"), "jeiko_administration:logo_update", perms=("users.config_edit_site",)),
            NavItem(_("Favicon"), "jeiko_administration:favicon_update", perms=("users.config_edit_site",)),
            NavItem(_("API Google"), "jeiko_administration:google_api_config",
                    perms=("users.config_edit_site",)),
        )),
        NavItem(_("Identité"), "jeiko_administration:site_identity", onglets=(
            NavItem(_("Identité et réseaux sociaux"), "jeiko_administration:site_identity",
                    perms=("users.config_edit_site",)),
            NavItem(_("Connexions sociales"), "jeiko_administration:social_login_config",
                    perms=("users.config_edit_site",)),
        )),
        NavItem(_("Style"), "jeiko_administration:fonts_view", onglets=(
            NavItem(_("Polices"), "jeiko_administration:fonts_view",
                    perms=("users.config_edit_fonts",)),
            NavItem(_("Thème"), "jeiko_administration:theme_view",
                    perms=("users.config_edit_fonts",)),
            NavItem(_("CSS global"), "jeiko_administration:css_site",
                    perms=("users.config_edit_site",)),
            NavItem(_("Administration"), "jeiko_administration:apparence_admin",
                    perms=("users.config_edit_site",)),
        )),
        NavItem(_("E-mails"), "jeiko_administration_emailing:template_list", onglets=(
            NavItem(_("Modèles d'e-mails"), "jeiko_administration_emailing:template_list",
                    perms=("users.config_edit_mail",),
                    also_active=("jeiko_administration_emailing:template_edit",)),
            NavItem(_("Historique des envois"), "jeiko_administration_emailing:envois",
                    perms=("users.config_edit_mail",),
                    also_active=("jeiko_administration_emailing:envoi",)),
            # D-16 : le rapport d'activité, par personne et par cadence.
            NavItem(_("Rapports"), "jeiko_administration_emailing:rapports",
                    perms=("users.config_edit_mail",)),
            NavItem(_("Serveur e-mail"), "jeiko_administration:mail_settings_edit",
                    perms=("users.config_edit_mail",)),
        )),
        NavItem(_("Cookies"), "jeiko_cookies_admin:edit_banner_text", onglets=(
            NavItem(_("Bannière"), "jeiko_cookies_admin:edit_banner_text", perms=("users.config_edit_site",)),
            # L-16 (16/10) : les catégories, et leurs textes par langue.
            NavItem(_("Catégories"), "jeiko_cookies_admin:categories", perms=("users.config_edit_site",)),
        )),
        NavItem(_("Pages légales"), "jeiko_administration:legals_view", perms=("users.config_edit_site",)),
        # L'ancienne section « Utilisateurs » (ADMIN-01, 14/10) : on règle qui
        # peut quoi, une fois — c'est un réglage. Les membres sont au CRM.
        NavItem(_("Utilisateurs"), "jeiko_administration_users:role_list", onglets=(
            NavItem(_("Rôles"), "jeiko_administration_users:role_list",
                    perms=("users.view_role",)),
            NavItem(_("Journal de sécurité"), "jeiko_administration_users:security_event_list",
                    perms=("users.view_securityevent",)),
            NavItem(_("Double authentification"), "jeiko_administration_users:twofa_list",
                    perms=("users.view_twofactordevice",)),
            # PAS d'onglet « Connexions OAuth » (users.ProviderConfig) : c'est
            # un doublon INERTE de « Identité › Connexions sociales » — seul
            # `administration.SocialProvider` écrit réellement le `SocialApp`
            # d'allauth. L'exposer invitait à saisir des clés qui ne partent
            # nulle part.
            NavItem(_("Notifications aux membres"), "jeiko_administration_users:notif_compose",
                    perms=("users.add_notification",)),
        )),
        # Les agents portent des droits comme un compte : ils se règlent là où
        # l'on règle le site, pas dans un coin à part.
        NavItem(_("Agents IA"), "jeiko_agents_admin:liste",
                perms=("auth.change_user",),
                also_active=("jeiko_agents_admin:detail",
                             "jeiko_agents_admin:creer",
                             "jeiko_agents_admin:modifier")),
        # La couche de jeiko.fr (LIC-01) : absente partout où le .env ne
        # l'allume pas, réservée aux super-administrateurs. Ancienne section
        # « Licences » (ADMIN-01, 14/10).
        NavItem(_("Licences"), "jeiko_licences:liste", reglage="JEIKO_SERVEUR_DE_LICENCES", onglets=(
            NavItem(_("Licences"), "jeiko_licences:liste", superuser_only=True,
                    also_active=("jeiko_licences:nouvelle", "jeiko_licences:fiche", "jeiko_licences:action")),
            NavItem(_("Journal des vérifications"), "jeiko_licences:journal", superuser_only=True),
            NavItem(_("Réglages des licences"), "jeiko_licences:reglages", superuser_only=True),
        )),
        # A-81 : durées de conservation, délais, plafonds — sans toucher au .env.
        NavItem(_("Réglages avancés"), "jeiko_administration:reglages_avances",
                perms=("users.config_edit_site",)),
        # Trois onglets (04/10/2026) : les réglages (mise à jour automatique,
        # partage des erreurs), le serveur, le site — dans l'ordre où les
        # choses se font. En dernier : des gestes rares.
        NavItem(_("Mises à jour"), "jeiko_administration:update_jeiko_reglages",
                badge="update", onglets=(
            NavItem(_("Réglages"), "jeiko_administration:update_jeiko_reglages",
                    perms=("users.config_edit_site",)),
            NavItem(_("Serveur"), "jeiko_administration:update_jeiko_serveur",
                    perms=("users.config_edit_site",)),
            NavItem(_("Site"), "jeiko_administration:update_jeiko",
                    perms=("users.config_edit_site",)),
        )),
    )),

    # Le suivi des personnes : les contacts, leurs notes et leurs relances
    # (PLAN_ACTION, CRM-01 à CRM-10 ; jeiko/crm/).
    NavSection(_("CRM"), (
        NavItem(_("Contacts"), "jeiko_crm:liste",
                perms=("questionnaires_expert.view_prospect",),
                also_active=("jeiko_crm:fiche", "jeiko_crm:nouveau", "jeiko_crm:modifier",
                             "jeiko_crm:import_csv", "jeiko_crm:rapprocher")),
        NavItem(_("Entreprises"), "jeiko_crm:entreprises",
                perms=("questionnaires_expert.view_prospect",),
                also_active=("jeiko_crm:entreprise", "jeiko_crm:entreprise_nouvelle",
                             "jeiko_crm:entreprise_modifier")),
        NavItem(_("À relancer"), "jeiko_crm:relances",
                perms=("questionnaires_expert.view_prospect",)),
        # Ce que les visiteurs écrivent par les formulaires du site : des
        # personnes à suivre, donc le CRM (ADMIN-01, 14/10 ; était sous Pages).
        NavItem(_("Messages reçus"), "jeiko_administration_pages:form_submissions", badge="messages",
                perms=("administration_pages.view_contentformsubmission",)),
        # NEWS-01 : listes, abonnés, lettres et leur suivi — une page à onglets.
        NavItem(_("Newsletter"), "jeiko_newsletter_admin:newsletters", onglets=(
            NavItem(_("Newsletters"), "jeiko_newsletter_admin:newsletters",
                    perms=("questionnaires_expert.view_prospect",),
                    also_active=("jeiko_newsletter_admin:fiche",)),
            NavItem(_("Séquences"), "jeiko_newsletter_admin:sequences",
                    perms=("questionnaires_expert.view_prospect",),
                    also_active=("jeiko_newsletter_admin:sequence",)),
            NavItem(_("Listes"), "jeiko_newsletter_admin:listes",
                    perms=("questionnaires_expert.view_prospect",),
                    also_active=("jeiko_newsletter_admin:liste",)),
            NavItem(_("Abonnés"), "jeiko_newsletter_admin:abonnes",
                    perms=("questionnaires_expert.view_prospect",)),
            NavItem(_("Réglages"), "jeiko_newsletter_admin:reglages",
                    perms=("questionnaires_expert.view_prospect",)),
        )),
        NavItem(_("Prospects des questionnaires"), "jeiko_crm:prospects_questionnaires", module="questionnaires",
                perms=("questionnaires_expert.view_prospect",)),
        # Les comptes inscrits, avec leur historique (rendez-vous, formations,
        # commandes) : du CRM, plus de « Utilisateurs » (Guillaume, 12/10/2026).
        NavItem(_("Membres"), "jeiko_administration_users:user_list", badge="membres",
                perms=("auth.view_user",),
                also_active=("jeiko_administration_users:user_detail",)),
    )),

    # Ordre voulu par Guillaume (14/10) : ce qu'on fait le plus souvent en
    # haut, les modèles ensuite, les réglages en bas.
    NavSection(_("Pages"), (
        NavItem(_("Toutes les pages"), "jeiko_administration_pages:main",
                perms=("administration_pages.view_page",),
                also_active=("jeiko_administration_pages:page_update",
                             "jeiko_administration_pages:page_insights")),
        NavItem(_("Ajouter une page"), "jeiko_administration_pages:page_add",
                perms=("administration_pages.add_page",)),
        # D-11 : les documents à télécharger, construits dans l'éditeur.
        NavItem(_("Documents PDF"), "jeiko_pdf_admin:documents",
                perms=("administration_pages.view_page",)),
        # Du contenu, pas un réglage : elle vit avec les pages qui l'utilisent.
        NavItem(_("Médiathèque"), "jeiko_administration_pages:media_list",
                perms=("administration_pages.view_imagecontent",
                       "administration_pages.add_imagecontent",
                       "administration_pages.change_imagecontent",
                       "administration_pages.delete_imagecontent"),
                also_active=("jeiko_administration_pages:media_add",
                             "jeiko_administration_pages:media_update",
                             "jeiko_administration_pages:media_delete")),
        NavItem(_("Catégories"), "jeiko_administration_pages:categories",
                perms=("administration_pages.view_page",)),
        NavItem(_("Menus"), "jeiko_administration_menu:menu_list",
                perms=("users.config_edit_site",),
                also_active=("jeiko_administration_menu:menu_detail",
                             "jeiko_administration_menu:menu_add",
                             "jeiko_administration_menu:menu_update")),
        NavItem(_("Modèles de page"), "jeiko_administration_pages:model_library",
                perms=("administration_pages.view_page",)),
        # TPL-01 : un site tout prêt, par métier.
        NavItem(_("Modèles de site"), "jeiko_administration_pages:modeles_de_site",
                perms=("users.config_edit_site",)),
        # Les anciennes adresses des pages renommées (Q-20) et les pages 404,
        # 403, 500, 400 écrites dans l'éditeur (A-10) : ce qui se règle une
        # fois pour toutes les pages.
        NavItem(_("Réglages"), "jeiko_administration_pages:redirections", titre=_("Réglages des pages"), onglets=(
            NavItem(_("Redirections"), "jeiko_administration_pages:redirections",
                    perms=("administration_pages.view_page",)),
            NavItem(_("Pages d'erreur"), "jeiko_administration_pages:pages_erreur",
                    perms=("administration_pages.view_page",)),
        )),
    )),

    NavSection(_("Fiches"), (
        NavItem(_("Modèles de fiches"), "jeiko_administration_custom_objects:model_list",
                perms=("custom_objects.view_customobjectmodel",)),
    )),

    NavSection(_("Boutique"), module="boutique", items=(
        NavItem(_("Produits"), "jeiko_administration_shop:product_list_all", badge="stock_bas",
                perms=("shop.view_product",)),
        NavItem(_("Types de produits"), "jeiko_administration_shop:product_type_list",
                perms=("shop.view_producttype",)),
        NavItem(_("Commandes"), "jeiko_shop_admin_orders:order_list", badge="commandes",
                perms=("shop.view_order",)),
        NavItem(_("Ventes"), "jeiko_shop_admin_orders:sales_dashboard",
                perms=("shop.view_order",)),
        NavItem(_("Avis clients"), "jeiko_administration_shop:review_list",
                perms=("shop.view_productreview",)),
        NavItem(_("Codes promo"), "jeiko_administration_shop:coupon_list",
                perms=("shop.view_coupon",),
                also_active=("jeiko_administration_shop:coupon_create",
                             "jeiko_administration_shop:coupon_update",
                             "jeiko_administration_shop:coupon_delete")),
        # FACT-01 : devis, factures et leurs réglages.
        NavItem(_("Facturation"), "jeiko_administration_shop:pieces_devis", onglets=(
            NavItem(_("Devis"), "jeiko_administration_shop:pieces_devis",
                    perms=("shop.view_piecedevente",)),
            NavItem(_("Factures"), "jeiko_administration_shop:pieces_factures",
                    perms=("shop.view_piecedevente",)),
            NavItem(_("Réglages de facturation"), "jeiko_administration_shop:facturation_reglages",
                    perms=("shop.change_producttype",)),
        )),
        # Ce qui vaut pour toute la boutique, par opposition à ce qui se règle
        # produit par produit. Général et TVA séparés (ADMIN-01, 14/10).
        NavItem(_("Réglages"), "jeiko_administration_shop:settings", titre=_("Réglages de la boutique"), onglets=(
            NavItem(_("Général"), "jeiko_administration_shop:settings",
                    perms=("shop.change_producttype",), parametre=("onglet", "")),
            NavItem(_("TVA et prix"), "jeiko_administration_shop:settings",
                    perms=("shop.change_producttype",), parametre=("onglet", "tva")),
            NavItem(_("Livraison"), "jeiko_administration_shop:settings",
                    perms=("shop.change_producttype",), parametre=("onglet", "livraison")),
            NavItem(_("Moyens de paiement"), "jeiko_payments_admin:gateway_list",
                    perms=("payments.view_paymentgateway",)),
            NavItem(_("Google Merchant"), "jeiko_administration_shop:google_merchant",
                    perms=("shop.view_product",)),
        )),
    )),

    NavSection(_("Formations"), module="formations", items=(
        NavItem(_("Toutes les formations"), "jeiko_courses:jeiko_courses_admin:course_list",
                perms=("courses.view_course",),
                also_active=("jeiko_courses:jeiko_courses_admin:course_edit",
                             "jeiko_courses:jeiko_courses_admin:course_structure")),
        NavItem(_("Ajouter une formation"), "jeiko_courses:jeiko_courses_admin:course_create",
                perms=("courses.add_course",)),
        NavItem(_("Accès aux formations"), "jeiko_courses:jeiko_courses_admin:enrollment_list",
                perms=("courses.view_courseenrollment",)),
        NavItem(_("Réglages"), "jeiko_courses:jeiko_courses_admin:provider_list", titre=_("Réglages des formations"), onglets=(
            NavItem(_("Hébergement vidéo"), "jeiko_courses:jeiko_courses_admin:provider_list",
                    perms=("courses.change_course",)),
        )),
    )),

    NavSection(_("Rendez-vous"), module="rendez_vous", items=(
        NavItem(_("Rendez-vous à venir"), "jeiko_administration_calendars:appointment_list_upcoming", badge="rendez_vous",
                perms=("calendars.view_appointment",)),
        NavItem(_("Rendez-vous passés"), "jeiko_administration_calendars:appointment_list_past",
                perms=("calendars.view_appointment",)),
        NavItem(_("Séances et inscrits"), "jeiko_administration_calendars:seances",
                perms=("calendars.view_appointment",)),
        NavItem(_("Types de rendez-vous"), "jeiko_administration_calendars:appointmenttype_list",
                perms=("calendars.view_appointmenttype",)),
        NavItem(_("Créneaux"), "jeiko_administration_calendars:availability_list",
                perms=("calendars.view_availability",)),
        NavItem(_("Calendriers"), "jeiko_administration_calendars:calendar_list",
                perms=("calendars.view_googlecalendarconfig",)),
        NavItem(_("Réglages"), "jeiko_administration_calendars:google_config", titre=_("Réglages des rendez-vous"), onglets=(
            NavItem(_("Connexion Google"), "jeiko_administration_calendars:google_config",
                    perms=("calendars.view_googlecalendarconfig",)),
            NavItem(_("Supervision"), "jeiko_administration_calendars:google_configs_all",
                    superuser_only=True),
        )),
    )),

    # VISIO-01 — « Conférence » (nom provisoire, Guillaume, 12/10/2026) : la
    # visio du site, module éteint par défaut (LiveKit doit être installé).
    NavSection(_("Conférence"), module="visio", items=(
        NavItem(_("Séances"), "jeiko_visio_admin:seances", badge="visio_attente", titre=_("Séances en visio"), onglets=(
            NavItem(_("À venir"), "jeiko_visio_admin:seances", perms=("visio.view_salle",),
                    parametre=("quand", ""), also_active=("jeiko_visio_admin:nouvelle",)),
            # Le suivi d'après : qui était inscrit, qui est venu (14/10).
            NavItem(_("Passées"), "jeiko_visio_admin:seances", perms=("visio.view_salle",),
                    parametre=("quand", "passees")),
        )),
        # Les places payées non livrées et leur remboursement (audit V-07, 16/10).
        NavItem(_("Remboursements"), "jeiko_visio_admin:remboursements", perms=("visio.view_salle",),
                also_active=("jeiko_visio_admin:remboursement",)),
        NavItem(_("Réglages"), "jeiko_visio_admin:serveur", titre=_("Réglages de la conférence"), onglets=(
            NavItem(_("Serveur de visio"), "jeiko_visio_admin:serveur",
                    perms=("visio.view_salle",)),
        )),
    )),

    NavSection(_("Questionnaires"), module="questionnaires", items=(
        NavItem(_("Tous les tests"), "jeiko_administration_questionnaires_expert:test_list",
                perms=("questionnaires_expert.view_questionnaire",)),
        NavItem(_("Ajouter un test"), "jeiko_administration_questionnaires_expert:test_add",
                perms=("questionnaires_expert.add_questionnaire",)),
        # Les personnes qui ont passé un questionnaire, gardées ici aussi
        # (03/10). Écran distinct de « CRM › Prospects des questionnaires » :
        # une vue n'a qu'une entrée, sinon deux sections s'allument.
        NavItem(_("Prospects"), "jeiko_administration_questionnaires_expert:prospect_list", badge="questionnaires",
                perms=("questionnaires_expert.view_prospect",),
                also_active=("jeiko_administration_questionnaires_expert:prospects_for_test",)),
    )),
)

def _badges(user=None):
    """Compteurs à afficher dans le menu, par nom de badge.

    « update » lit `WebSite` depuis le cache (`website_cache`), déjà chargé à
    chaque rendu. Les notifications (NOTIF-01, administration/notifications.py)
    sont propres à la personne et gardées une minute en cache ; leur total
    va sur « Général ». Ne lève jamais — un compteur indisponible ne doit pas
    empêcher le menu de s'afficher.
    """
    counts = {}
    try:
        from jeiko.administration.website_cache import get_website_data
        site = get_website_data()
        if site is not None and getattr(site, "mise_a_jour_disponible", ""):
            counts["update"] = 1
    except Exception:
        logger.warning("Badge de mise à jour indisponible", exc_info=True)
    if user is not None:
        try:
            from jeiko.administration.notifications import compteurs
            notes = compteurs(user)
            counts.update(notes)
            counts["notifications"] = sum(notes.values())
        except Exception:
            logger.warning("Pastilles de notification indisponibles", exc_info=True)
    return counts


def build_nav(user, view_name: str, path: str = ""):
    """Sections visibles par `user`, avec URL résolue et état actif.

    Une entrée dont le nom de vue n'existe pas est **écartée** plutôt que rendue
    en lien mort : c'est la garantie qu'un renommage d'URL se voit (l'entrée
    disparaît) au lieu de produire un 404 silencieux.

    Une section sans aucun item visible n'est pas rendue : plus besoin de tenir
    à jour, à la main, une condition de section qui répète celles des items.

    L'état actif se décide en deux temps. D'abord par **nom de vue** — exact,
    et c'est ce qui fait autorité. À défaut, par **préfixe d'URL le plus long** :
    sans cela, un administrateur en train de modifier un rendez-vous ou une
    formation ne voit plus aucune entrée en surbrillance et perd le fil de
    l'endroit où il se trouve. On ne prend que le préfixe le plus spécifique,
    pour que « /administration/users/… » allume « Utilisateurs » et non
    « Général » (dont l'URL, « /administration/ », préfixe tout l'espace).
    """
    from jeiko.administration.modules import module_actif

    resolved = []
    for section in NAVIGATION:
        if section.module and not module_actif(section.module):
            continue
        for item in section.items:
            if not item.is_visible(user):
                continue
            if item.onglets:
                visibles = item.onglets_visibles(user)
                if not visibles:
                    continue
                url = visibles[0][1]
            else:
                try:
                    url = reverse(item.url_name)
                except NoReverseMatch:
                    continue
            resolved.append((section, item, url))

    active_by_name = any(item.matches(view_name) for _, item, _ in resolved)

    fallback_url = None
    if not active_by_name and path:
        # « Général » vit à la racine de l'espace (/administration/), donc son
        # URL préfixe TOUT l'admin. Sans cette garde, un sous-formulaire sans
        # entrée propre (révoquer une session, lier un prospect…) allumerait
        # « Général » — une indication fausse, pire que pas d'indication. On ne
        # retient un préfixe que s'il est plus spécifique que cette racine, sauf
        # à être exactement sur l'écran Général.
        candidates = [
            url for _, _, url in resolved
            if url != "/" and path.startswith(url) and (len(url) > len("/administration/") or path == url)
        ]
        if candidates:
            fallback_url = max(candidates, key=len)

    # NOTIF-01 : ouvrir la liste d'une notification « du nouveau » la remet à
    # zéro — AVANT de compter, pour que la pastille s'éteigne sur cette page.
    from jeiko.administration.notifications import marquer_vue

    for _section, item, _url in resolved:
        if item.badge and item.matches(view_name):
            marquer_vue(user, item.badge)
    badges = _badges(user)
    sections, current = [], None
    for section, item, url in resolved:
        is_active = item.matches(view_name) if active_by_name else url == fallback_url
        count = badges.get(item.badge, 0) if item.badge else 0
        if current is None or current["label"] != section.label:
            current = {"label": section.label, "items": [], "is_open": False, "badge": 0,
                       "direct": section.direct}
            sections.append(current)
        current["items"].append({
            "label": item.label,
            "url": url,
            "is_active": is_active,
            "badge": count,
        })
        # Le compte remonte sur la section : repliée par défaut, elle serait
        # sinon le seul endroit visible et n'afficherait rien.
        current["badge"] += count
        if is_active:
            current["is_open"] = True
    return sections


def onglets_de_la_page(user, view_name, params=None):
    """
    La barre d'onglets de l'écran courant, s'il fait partie d'un groupe :
    {"titre", "section", "onglets": [{"label", "url", "is_active"}]} ou None.
    `params` : la requête (`request.GET`), pour les onglets qui sont des
    vues d'un même écran (`NavItem.parametre`).
    """
    for section in NAVIGATION:
        for item in section.items:
            if item.onglets and item.matches(view_name):
                visibles = item.onglets_visibles(user)
                if len(visibles) < 1:
                    return None
                return {
                    "titre": item.label,
                    "section": section.label,
                    "onglets": [{"label": o.label, "url": url, "is_active": o.matches(view_name, params or {})}
                                for o, url in visibles],
                }
    return None



def ecran_du_menu(user, view_name, params=None):
    """
    L'en-tête d'un écran DU MENU (ADMIN-01, 14/10/2026) :
    {"titre", "fil": [(libellé, url ou None)], "onglets": … ou None}, ou None
    pour un écran qui n'est pas une entrée du menu (fiche, formulaire…).

    Le titre est ce qu'on a cliqué — le libellé du menu, ou le titre du groupe
    pour chacun de ses onglets —, le fil d'Ariane suit le menu. Ils étaient
    écrits à la main, écran par écran, et avaient divergé : « Gestion des
    pages » sous « Toutes les pages », « Événements Google Calendar » sous
    « Calendriers », un titre différent par onglet d'un même groupe.

    Seule la vue EXACTE de l'entrée compte : une fiche qui allume une entrée
    (`also_active`) garde son titre, qui nomme l'objet.
    """
    params = params if params is not None else {}
    for section in NAVIGATION:
        for item in section.items:
            candidats = item.onglets or (item,)
            for onglet in candidats:
                if onglet.url_name != view_name:
                    continue
                if onglet.parametre and (params.get(onglet.parametre[0]) or "") != onglet.parametre[1]:
                    continue
                if not onglet.is_visible(user):
                    return None
                titre = item.titre or item.label
                try:
                    racine = reverse("jeiko_administration:main")
                except NoReverseMatch:
                    racine = None
                if section.direct:
                    fil = [(titre, None)]
                else:
                    fil = [(_("Administration"), racine), (section.label, None), (titre, None)]
                return {"titre": titre, "fil": fil,
                        "onglets": onglets_de_la_page(user, view_name, params) if item.onglets else None}
    return None
