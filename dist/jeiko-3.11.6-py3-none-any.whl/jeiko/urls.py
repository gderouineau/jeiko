from django.urls import include, path

from jeiko.administration import csp
from jeiko.administration.llms_txt import llms_txt
from jeiko.agents import oauth
from jeiko.agents.mcp import ServeurMcp
from jeiko.licences import views as licences_views
from jeiko.newsletter import vues_publiques as newsletter_vues
from jeiko.administration.views import robots_txt, sitemap_xml, sitemap_xsl
urlpatterns = [

    path("robots.txt", robots_txt, name="robots_txt"),
    path('sitemap.xml', sitemap_xml, name='sitemap_xml'),
    path('sitemap.xsl', sitemap_xsl, name='sitemap_xsl'),
    # La carte du site à l'usage des modèles de langue. Remplie toute seule
    # depuis les pages publiées et leurs métadonnées — voir llms_txt.py.
    path("llms.txt", llms_txt, name="llms_txt"),
    # Les signalements de la protection des scripts (CSP), postés par les
    # navigateurs des visiteurs — voir administration/csp.py.
    path("csp-rapport/", csp.recevoir, name="csp_rapport"),

    # AGENTS IA — OAuth du serveur MCP, pour claude.ai et l'app Claude (P-04).
    # À la racine, hors de /api/agent/ : ces routes délivrent un jeton, elles
    # n'en portent pas. Voir jeiko/agents/oauth.py.
    path(".well-known/oauth-protected-resource", oauth.metadonnees_ressource,
         name="oauth_ressource"),
    path(".well-known/oauth-protected-resource/<path:suffixe>",
         oauth.metadonnees_ressource, name="oauth_ressource_suffixee"),
    path(".well-known/oauth-authorization-server", oauth.metadonnees_serveur,
         name="oauth_serveur"),
    path("oauth/register", oauth.enregistrer, name="oauth_register"),
    path("oauth/authorize", oauth.autoriser, name="oauth_authorize"),
    path("oauth/token", oauth.jeton, name="oauth_token"),

    # ADMINISTRATION
    path(
        'administration/',
        include('jeiko.administration.urls')
    ),

    # PAGES
    path(
        'jeiko/administration/pages/',
        include('jeiko.administration_pages.urls'),
    ),
    path(
        'api/pages/',
        include('jeiko.administration_pages.urls_api'),
    ),

    # AGENTS IA — écrans de gestion, et API à jeton porteur.
    path(
        'administration/agents/',
        include('jeiko.agents.urls_admin'),
    ),

    # AGENTS IA — API à jeton porteur. Aucune vue de session ici : voir
    # jeiko/agents/authentification.py pour ce que cette séparation protège.
    path(
        'api/agent/v1/',
        include('jeiko.agents.urls_api'),
    ),

    # AGENTS IA — le même accès, dans le protocole des assistants (MCP). Un
    # serveur par site, avec les jetons de ses agents : voir agents/mcp.py.
    path(
        'api/agent/mcp/',
        ServeurMcp.as_view(),
        name='agents_mcp',
    ),
    # La même adresse SANS barre finale. C'est souvent ainsi qu'on la saisit
    # dans claude.ai ; sans cette route, Django répondait 301 (APPEND_SLASH),
    # et un client MCP ne suit pas une redirection sur un POST : l'autorisation
    # passait, puis chaque appel échouait (« … a renvoyé une erreur lors de la
    # connexion », constaté sur jeiko.fr le 28/09, P-04).
    path(
        'api/agent/mcp',
        ServeurMcp.as_view(),
        name='agents_mcp_sans_barre',
    ),

    # MENUS
    path(
        'administration/menu/',
        include('jeiko.administration_menu.urls'),
    ),

    # CALENDARS
    path(
        'administration/calendars/',
        include('jeiko.calendars.urls'),
    ),
    path(
        'api/calendars/',
        include('jeiko.calendars.urls_api'),
    ),
    path(
        'rendez-vous/',
        include('jeiko.calendars.urls_public'),
    ),

    # ACCOUNTS
    path(
        'accounts/',
        include('jeiko.users.urls.auth'),
    ),
    path(
        'accounts/',
        include('allauth.urls'),
    ),

    # USERS
    path(
        'users/',
        include('jeiko.users.urls.client'),
    ),
    path(
        'administration/users/',
        include('jeiko.users.urls.admin'),
    ),

    # CRM — la fiche des personnes (jeiko/crm/)
    # NEWS-01 — CRM › Newsletter (avant le CRM : rien n'y attrape tout, mais l'ordre se lit mieux)
    path('administration/crm/newsletter/', include('jeiko.newsletter.urls_admin')),
    path('administration/crm/', include('jeiko.crm.urls')),

    # D-11 — Pages › Documents PDF.
    path('administration/pdf/', include('jeiko.pdf.urls_admin')),
    # VISIO-01 — Conférence : séances, invités, serveur de visio.
    path('administration/visio/', include('jeiko.visio.urls_admin')),

    # LICENCES — la couche de jeiko.fr (jeiko/licences/, LIC-01). Montées
    # partout, mais 404 tant que JEIKO_SERVEUR_DE_LICENCES n'est pas allumé.
    path('administration/licences/', include('jeiko.licences.urls')),
    path('api/licences/verifier/', licences_views.Verifier.as_view(), name='licences_verifier'),
    path('users/profile/licences/<int:pk>/domaine/', licences_views.DomaineDeMaLicence.as_view(),
         name='licence_domaine'),
    # NEWS-01 — « Mes newsletters » du compte client.
    path('users/profile/abonnements/', newsletter_vues.MesAbonnements.as_view(),
         name='mes_abonnements'),

    # QUESTIONNAIRES
    path(
        'administration/questionnaires-expert/',
        include('jeiko.questionnaires_expert.urls.admin'),
    ),
    path(
        'pass-test/',
        include('jeiko.questionnaires_expert.urls.client'),
    ),

    # COOKIES
    path(
        'administration/cookies/',
        include('jeiko.cookies.urls_admin'),
    ),
    path(
        '',
        include('jeiko.cookies.urls'),
    ),

    # CUSTOM OBJECT
    path(
        'administration/custom_objects/',
        include('jeiko.custom_objects.urls.admin'),
    ),
    path("co/", include("jeiko.custom_objects.urls.client")),

    # COURSES
    path('', include('jeiko.courses.urls')),

    # SHOP
    path(
        'administration/shop/',
        include('jeiko.shop.urls.admin')
    ),
    path(
        'administration/shop/',
        include('jeiko.shop.urls.admin_orders')
    ),

    # PAYMENTS
    path(
        'administration/payments/',
        include('jeiko.payments.urls.admin')
    ),

    # Les routes de paiement partagent le préfixe « shop/ » avec la fiche
    # produit, dont le motif <type>/<sku>/ consomme deux segments : monté en
    # premier, il capturait /shop/webhook/stripe/ et renvoyait un 404. Le
    # webhook Stripe doit être déclaré AVANT la route produit.
    path(
        'shop/',
        include('jeiko.payments.urls.client')
    ),
    path(
        'shop/',
        include('jeiko.shop.urls.client')
    ),

    # STATS
    path(
        "stats/",
        include("jeiko.stats.urls.client")
    ),
    path(
        "administration/stats/",
        include("jeiko.stats.urls.admin")
    ),

    # EMAILING
    # Déclaré AVANT les pages : celles-ci se terminent par un motif attrape-tout
    # (`<slug:category_slug>/<slug:url_tag>/`) monté sur la racine, qui capterait
    # /administration/emailing/ et renverrait un 404 de page introuvable.
    path(
        'administration/emailing/',
        include('jeiko.emailing.urls.admin')
    ),
    path(
        'emailing/',
        include('jeiko.emailing.urls.client')
    ),
    # NEWS-01 — inscription, confirmation, désinscription, liens suivis.
    path('newsletter/', include('jeiko.newsletter.urls_publiques')),
    # VISIO-01 — la salle, ouverte par le lien personnel d'un invité.
    path('visio/', include('jeiko.visio.urls_publiques')),
    # D-11 — un document PDF en ligne : /pdf/<url_tag>.pdf.
    path('pdf/', include('jeiko.pdf.urls_publiques')),

    # PAGES (attrape-tout : doit rester en dernier)
    path(
        '',
        include('jeiko.administration_pages.urls_client'),
    ),

]



