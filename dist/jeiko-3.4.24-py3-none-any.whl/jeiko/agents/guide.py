# jeiko/agents/guide.py
"""
Le mode d'emploi que l'API se donne à elle-même.

Pourquoi c'est le point d'entrée le plus important
--------------------------------------------------
Une IA qui découvre cette API ne connaît ni JEIKO, ni son modèle de page, ni
les pièges de son vocabulaire. Sans mode d'emploi, elle procède par essais et
par 400 : elle devine des noms de champs, se trompe, recommence. Chaque erreur
coûte un aller-retour, et certaines — poser un bloc dans une colonne qui
n'existe pas — produisent une page bancale sans rien signaler.

Ce guide lui donne, en un appel, ce qu'un développeur mettrait une heure à
lire dans le code : la forme de l'arbre, le vocabulaire, les documents
attendus, et un exemple complet qui marche.

La règle qui rend ce guide fiable
---------------------------------
**Tout ce qui peut être déduit du code l'est.** Les noms d'appareils, les côtés
d'une boîte, les champs d'animation, de bordure et de CSS, les gabarits de
section, les types de contenu ouverts, les champs de page modifiables et la
liste des points d'entrée sont lus dans les constantes et dans le routeur — pas
recopiés. Une documentation recopiée devient fausse au premier changement, et
une documentation fausse est pire que pas de documentation : elle fait perdre
du temps avec autorité.

Seule la prose est écrite à la main. Elle explique des intentions, que le code
ne porte pas.
"""

from django.urls import get_resolver

from jeiko.administration_pages import fabrique

from . import contenus_dynamiques as _dyn
from . import parametres
from .vues_api import AUTHENTIFICATION_SEULE
from .vues_pages import (
    CHAMPS_PAGE_CATEGORIES, CHAMPS_PAGE_MODIFIABLES, CHAMPS_VIDEO,
    CONTENUS_SIMPLES, TYPES_OUVERTS,
)

RACINE = "/api/agent/v1/"


def _points_d_entree():
    """
    Les routes réellement montées, lues dans le routeur.

    Les décrire à la main garantirait qu'un jour l'une manque ou qu'une autre
    n'existe plus. Le routeur, lui, ne peut pas mentir.
    """
    from .urls_api import urlpatterns

    descriptions = {
        "guide": ("GET", "Ce mode d'emploi. À lire en premier."),
        "guide_explicite": ("GET", "Le même mode d'emploi, à une adresse qui se retient."),
        "whoami": ("GET", "Qui je suis et ce que j'ai le droit de faire."),
        "pages": ("GET", "La liste des pages du site."),
        "page_creer": ("POST", "Créer une page. Elle naît en brouillon."),
        "page": ("GET, PATCH", "L'arbre complet d'une page ; PATCH modifie ses champs."),
        "page_sections": ("POST", "Ajouter une section à une page."),
        "page_mesures": ("GET", "Scores PageSpeed, Core Web Vitals et audits ratés. Lecture seule."),
        "section": ("GET, PATCH, DELETE", "Une section et ses paramètres."),
        "section_lignes": ("POST", "Ajouter une ligne à une section."),
        "ligne": ("GET, PATCH, DELETE", "Une ligne et ses paramètres."),
        "ligne_blocs": ("POST", "Ajouter un bloc dans une colonne de la ligne."),
        "bloc": ("GET, PATCH, DELETE", "Un bloc et ses paramètres."),
        "bloc_contenu": ("PUT", "Poser ou remplacer le contenu d'un bloc."),
        "images": ("GET", "La médiathèque, en lecture. Donne les identifiants à réutiliser."),
        "categories": ("GET", "Les catégories et sous-catégories, avec leurs slugs."),
        "rdv_types": ("GET", "Les types de rendez-vous. Leur durée découpe les disponibilités."),
        "rdv_type_creer": ("POST", "Créer un type de rendez-vous."),
        "rdv_type": ("GET, PATCH", "Un type : durée, capacité, prix, liste d'attente."),
        "rdv_disponibilites": ("GET", "Les plages déclarées disponibles."),
        "rdv_disponibilite_creer": ("POST", "Déclarer une plage — elle GÉNÈRE ses créneaux."),
        "rdv_disponibilite": ("GET, PATCH, DELETE", "Une plage. La suppression est refusée si des rendez-vous y sont pris."),
        "rdv_creneaux": ("GET", "Les créneaux générés — LECTURE SEULE. Filtres : type, depuis, jusqu_a, ouverts."),
        "rdv": ("GET", "Les rendez-vous pris. Lecture seule, permission à part : données personnelles."),
        "menus": ("GET", "Les menus, leur arborescence et les catégories qu'ils servent."),
        "menu_creer": ("POST", "Créer un menu — « copie_de » duplique un existant, arborescence comprise."),
        "menu": ("GET, PATCH", "Un menu ; envoyer « elements » REMPLACE son arborescence."),
        "categorie_menus": ("PATCH", "Affecter les menus d'une catégorie — c'est ce qui fait les sous-sites."),
        "identite": ("GET, PATCH", "Les couleurs du thème et les polices du site. Modification partielle."),
        "email_evenements": ("GET", "Les 67 événements d'e-mail et LEURS CLÉS. À lire avant d'écrire un e-mail."),
        "emails": ("GET", "Les e-mails configurés."),
        "email_creer": ("POST", "Habiller un événement : sujet, page de corps. Naît INACTIF."),
        "email": ("GET, PATCH", "Un e-mail : sujet, corps, expéditeur, activation."),
        "questionnaires": ("GET", "Les questionnaires experts."),
        "questionnaire_creer": ("POST", "Créer un questionnaire. Il naît INACTIF."),
        "questionnaire": ("GET, PATCH", "L'arbre complet : profils, questions, réponses, poids, combinaisons."),
        "questionnaire_profils": ("POST", "Ajouter un profil — un résultat possible, avec sa page."),
        "questionnaire_questions": ("POST", "Ajouter une question, ses réponses et leurs poids."),
        "questionnaire_combinaisons": ("POST", "Ajouter une combinaison — l'arbitrage entre deux profils proches."),
        "profil": ("PATCH", "Un profil. Son slug ne se modifie pas : il est dans l'URL du résultat."),
        "question": ("PATCH, DELETE", "Une question ; envoyer « reponses » REMPLACE la liste, poids compris. Suppression refusée si le test a déjà été passé."),
        "reponse": ("DELETE", "Supprimer une réponse seule, sans réécrire les autres."),
        "combinaison": ("PATCH", "Une combinaison et ses critères."),
        "categorie_creer": ("POST", "Créer une catégorie. « afficher_dans_l_url » la met dans l'adresse des pages."),
        "categorie": ("GET, PATCH, DELETE", "Corriger une catégorie. Le slug ne change pas : il est dans les adresses. La suppression n'accepte qu'une catégorie VIDE."),
        "deplacer": ("POST", "Monter ou descendre une section, une ligne ou un bloc."),
        "modeles": ("GET", "Les types de fiches et leurs champs. À lire avant d'en créer une."),
        "modele_creer": ("POST", "Créer un type de fiche avec ses champs, et marquer sa page gabarit."),
        "modele": ("GET, PATCH", "Un type de fiche ; PATCH AJOUTE des champs, n'en renomme aucun."),
        "types_produit": ("GET", "Les types de produit — la couche commerciale."),
        "type_produit_creer": ("POST", "Créer un type de produit. « expedition » décide s'il consomme du stock."),
        "type_produit": ("GET, PATCH", "Corriger un type de produit. Le code ne change pas : il est dans les URL."),
        "objets": ("GET", "Les fiches existantes. `?modele=<slug>` pour filtrer."),
        "objet_creer": ("POST", "Créer une fiche. Elle naît non publiée."),
        "objet": ("GET, PATCH", "Une fiche et ses valeurs ; PATCH en modifie une partie."),
        "produits": ("GET", "Les produits."),
        "produit_creer": ("POST", "Créer un produit sur une fiche existante."),
        "produit": ("GET, PATCH", "Un produit : référence, prix, TVA, stock."),
    }

    entrees = []
    for motif in urlpatterns:
        nom = motif.name
        methodes, quoi = descriptions.get(nom, ("?", ""))
        entrees.append({
            "nom": nom,
            "methodes": methodes,
            "chemin": RACINE + str(motif.pattern),
            "role": quoi,
            "permission": _permission_de(motif),
        })
    return entrees


def _permission_de(motif):
    """
    La permission qu'exige réellement la vue, lue sur la classe elle-même.

    Un agent doit pouvoir savoir AVANT d'appeler s'il a le droit, plutôt que
    de le découvrir sur un 403. Et l'écrire à la main dans le guide reviendrait
    à entretenir une seconde vérité, qui finirait par se tromper — c'est
    exactement le genre d'écart qui rend une documentation dangereuse : un
    agent qui la croit renonce à une action permise, ou en tente une interdite.
    """
    vue = getattr(motif.callback, "view_class", None)
    exigee = getattr(vue, "permission_requise", None)
    if exigee is None:
        return "?"
    if exigee is AUTHENTIFICATION_SEULE:
        return "aucune — un jeton valide suffit"
    return exigee


def _document_de_parametres():
    """La forme exacte d'un document de paramètres, déduite des constantes."""
    cotes = list(parametres.COTES)
    appareils = list(parametres.APPAREILS)

    return {
        "principe": (
            "Tout ce qui n'est pas mentionné reste inchangé. Envoyer "
            "{'paddings': {'phone': {'haut': '20px'}}} ne touche ni les autres "
            "appareils, ni les autres familles."
        ),
        "appareils": appareils,
        "marges": {"forme": {a: {c: "valeur CSS" for c in cotes} for a in ["computer"]},
                   "note": f"Un objet par appareil parmi {appareils}."},
        "paddings": {"identique_a": "marges"},
        "tailles": {
            "forme": {"computer": {"largeur": "1140px", "hauteur": ""}},
            "piege_hauteur": (
                "« hauteur: 100% » ne veut pas dire « toute la page » : le bloc "
                "prend la hauteur de sa LIGNE, donc celle du plus grand bloc à "
                "côté de lui. C'est ce qu'on veut pour égaliser des cartes "
                "voisines, et seulement pour cela. Posé sur un titre placé à "
                "côté d'un long tableau, il étire ce titre sur toute la hauteur "
                "du tableau : des milliers de pixels de vide, et le reste de la "
                "page qui passe dessous. Ne l'utilisez que sur des blocs de même "
                "nature."
            ),
            "piege_marge": (
                "Un bloc en « hauteur: 100% » remplit son conteneur : sa marge "
                "basse déborde au lieu de pousser, et n'écarte plus rien. Pour "
                "séparer deux rangées de cartes, posez la marge en HAUT de "
                "celle du dessous."
            ),
        },
        "fond": {
            "couleur": "rgba(255,255,255,0) — couleur CSS",
            "image_id": "identifiant d'une image DÉJÀ dans la médiathèque, ou null pour détacher",
            "cle_image_dynamique": "code d'un champ IMAGE d'objet custom",
            "reglages_image": list(parametres.CHAMPS_IMAGE_DE_FOND),
        },
        "animation": list(parametres.SATELLITES["animation"][1]),
        "bordure": list(parametres.SATELLITES["bordure"][1]),
        "css": list(parametres.SATELLITES["css"][1]),
        "champs_propres": {
            "section": list(parametres.CHAMPS_PROPRES.get(
                __import__("jeiko.administration_pages.models", fromlist=["Section"]).Section, ())),
            "ligne": list(parametres.CHAMPS_PROPRES.get(
                __import__("jeiko.administration_pages.models", fromlist=["Line"]).Line, ())),
            "bloc": list(parametres.CHAMPS_PROPRES.get(
                __import__("jeiko.administration_pages.models", fromlist=["Bloc"]).Bloc, ())),
        },
    }


PROSE = """
# Piloter les pages de JEIKO

Vous êtes un agent connecté à l'API d'un site JEIKO. Ce document dit ce que
vous manipulez, dans quel ordre, et où sont les pièges. Lisez-le en entier
avant d'écrire : il est court, et il vous évitera des allers-retours.

## L'arbre d'une page

Une page est un empilement à quatre niveaux, et **rien ne s'invente en dehors
de cet ordre** :

    Page
     └─ Section      une bande horizontale, pleine largeur ou centrée
         └─ Ligne    une rangée, découpée en 1 à 12 colonnes
             └─ Bloc une case dans une colonne
                 └─ Contenu  du texte, une image, un bouton…

Pour créer quelque chose, il faut donc toujours créer le parent d'abord. Une
page vide est légitime, une section sans ligne aussi : rien ne vous oblige à
tout remplir d'un coup.

## Le piège de vocabulaire, à lire deux fois

Sur un bloc, le champ `colonne` est **le numéro de la colonne**, pas un rang
vertical. Le rang, c'est `rang`. Deux blocs dans la même colonne se suivent
verticalement ; deux blocs dans des colonnes différentes sont côte à côte.

Les colonnes sont numérotées à partir de **0**. Une ligne à 2 colonnes accepte
`colonne: 0` et `colonne: 1`, rien d'autre — une valeur hors bornes est
refusée avec un message qui vous dit les bornes.

## Les quatre appareils

Tout se règle par appareil, et les quatre existent toujours :

- `phone`    — jusqu'à 767 px
- `tablet`   — 768 à 991 px
- `laptop`   — 992 à 1199 px
- `computer` — 1200 px et au-delà

Régler `computer` seul ne règle que les grands écrans. Un site qui n'a l'air
correct que sur ordinateur est un site cassé pour la majorité des visiteurs :
pensez à `phone`.

## Comment travailler

1. `GET /pages/` — repérez la page, ou créez-la.
2. `GET /pages/<id>/` — **lisez l'arbre complet avant de modifier.** Il vous
   donne tous les identifiants et tous les paramètres actuels.
3. Créez ou modifiez, un appel par élément.
4. `GET /pages/<id>/` à nouveau pour vérifier ce que vous avez fait.

Les modifications de paramètres sont **partielles** : ce que vous n'envoyez
pas n'est pas touché. C'est ce qui permet de régler le padding du téléphone
sans effacer celui de l'ordinateur.

## Ce que vous ne pouvez pas faire, et pourquoi

**Supprimer une page.** Aucune route, aucune permission. Vous pouvez tout
construire et tout défaire à l'intérieur d'une page — sections, lignes, blocs —
mais la page elle-même ne disparaît que par la main d'un humain. Ne le
cherchez pas : ce n'est pas un oubli.

**Publier une page en la créant.** Une page naît en brouillon. La mettre en
ligne est une décision éditoriale ; elle se fait par un `PATCH` explicite avec
`{"publiee": true}`, ou par un humain dans l'administration.

**Téléverser une image.** L'API rattache une image déjà présente dans la
médiathèque, par son identifiant. Le fichier lui-même passe par
l'administration, où s'appliquent les contrôles de poids et de dimensions.

## LA RÈGLE LA PLUS IMPORTANTE : écrire du contenu qui reste modifiable

Un site JEIKO n'est pas livré une fois pour toutes. Après votre passage, un
humain ouvrira l'administration pour corriger un mot, changer une couleur,
ajouter un paragraphe. **Ce que vous écrivez doit lui rester accessible.**

Le contenu des blocs TEXT est édité dans l'administration par un éditeur
visuel qui ne travaille pas sur du HTML : il possède son propre modèle de
document. Ce qu'il ne sait pas représenter, il ne l'abîme pas — il le fait
disparaître. Et pas au moment où l'on modifie : **ouvrir un bloc et
enregistrer sans rien toucher suffit à le vider**.

Un site réel a perdu neuf blocs de sa page d'accueil de cette façon. Ils
s'affichaient parfaitement ; ils étaient simplement devenus impossibles à
éditer, et personne ne le savait.

### Les trois niveaux, dans cet ordre

**1. La boîte — jamais en HTML, toujours en paramètres.**
Fond, bordure, rayon, ombre, marges, paddings, largeurs, hauteurs, colonnes :
tout cela se règle par `PATCH` sur le bloc, la ligne ou la section, appareil
par appareil. C'est la voie normale, et c'est la seule que l'exploitant
pourra ensuite modifier depuis son interface.

N'enveloppez jamais du contenu dans un `<div>` pour lui donner un fond ou une
bordure. Le bloc EST la boîte.

**2. Le texte — à plat, avec des classes.**
`<p class="…">`, `<h1>`…`<h6 class="…">`, `<strong>`, `<em>`, `<a href>`.
Les classes posées sur ces éléments-là **survivent** à l'éditeur. Une couleur
ponctuelle s'écrit en style en ligne, qui survit aussi.

**3. Les polices — uniquement par les réglages du site.**
Le site ne charge QUE les polices déclarées dans son identité, et il les
auto-héberge. Un `font-family` écrit dans du CSS nomme donc une police qui
n'est pas chargée : le navigateur retombe sur autre chose, différemment selon
la machine du visiteur. **N'écrivez jamais `font-family` dans `css.custom`.**
Pour changer une police, passez par `PATCH /identite/`.

**4. `css.custom` — en dernier recours seulement.**
Pour ce qu'aucun des trois premiers ne permet : une grille, un
pseudo-élément, un séparateur. Rien de ce qui a déjà un réglage.

Ce n'est pas une question de goût. Tout ce que vous peignez en CSS
**disparaît de l'interface** : l'exploitant voit un bloc dont il ne peut
changer ni le fond, ni la bordure, ni l'espacement, parce que ces valeurs
vivent dans une feuille qu'il n'a aucune raison d'aller lire.

### Ce qui traverse l'éditeur, et ce qui détruit le bloc

Éprouvé contre l'éditeur réel, pas déduit d'une documentation.

**Conservé, classes comprises**

    <p class="…">        <h1>…<h6 class="…">      <blockquote>
    <strong>  <em>  <a href>  <img>  <table>
    style="color: …; background-color: …; text-align: …"

**DÉTRUIT LE BLOC ENTIER** — le contenu devient vide, en totalité

    <div>      <section>    <article>    <figure>
    <pre>      <details>    <ul>

**Perdu en silence** — le texte reste, le balisage disparaît

    <span class="…">     la classe est retirée, le texte survit
    <hr>                 devient un paragraphe vide

### Les listes

C'est le piège le plus contre-intuitif : **`<ul>` détruit le bloc**. L'éditeur
n'écrit pas les listes ainsi. Le format qu'il relit — et que le site rend à
l'identique, puces comprises — est :

    <ol><li data-list="bullet">Premier</li>
        <li data-list="bullet">Deuxième</li></ol>

Pour une liste numérotée, `data-list="ordered"`. Pour une case à cocher,
`"unchecked"` ou `"checked"`. L'attribut `data-list` porte la puce : sans lui
la liste s'affiche numérotée.

### L'exemple qui résume tout

Une carte — titre, texte, lien — avec un fond et une bordure.

**Ce qu'il ne faut pas faire.** Le bloc sera vide dès qu'on l'ouvrira, et
l'exploitant ne pourra rien régler :

    PUT /blocs/12/contenu/  {"type": "TEXT", "texte":
      "<div class=\"carte\"><h2>Électricité</h2><p>Installation.</p></div>"}
    PATCH /sections/3/  {"css": {"custom": ".carte{background:#fff;border:1px solid #ddd;padding:24px;}"}}

**Ce qu'il faut faire.** Le contenu à plat, la boîte en paramètres :

    PUT /blocs/12/contenu/  {"type": "TEXT", "texte":
      "<h2 class=\"tt\">Électricité</h2><p class=\"tp\">Installation.</p>"}

    PATCH /blocs/12/  {"fond": {"couleur": "#ffffff"},
                       "bordure": {"border_width": "1px",
                                   "border_style": "solid",
                                   "border_color": "#dddddd",
                                   "border_radius": "10px"},
                       "paddings": {"computer": {"haut": "24px", "bas": "24px",
                                                 "gauche": "24px", "droite": "24px"},
                                    "phone":    {"haut": "18px", "bas": "18px",
                                                 "gauche": "16px", "droite": "16px"}}}

Le rendu est le même. La différence est que le second reste vivant : le fond
se change en deux clics, et le texte s'édite sans rien perdre.

L'API refuse le premier. Le message vous dira quoi mettre à la place.

## Les seize blocs dynamiques : préférez-les au HTML

C'est la suite directe de la règle précédente, et le réflexe à prendre.

Beaucoup de ce qu'on est tenté d'écrire à la main — une FAQ dépliable, des
onglets, un carrousel, une table de tarifs, des témoignages — **existe déjà en
bloc**. Un bloc dynamique n'est pas un raccourci de mise en forme : c'est une
structure de données. Ses entrées se modifient une par une dans
l'administration, et l'exploitant peut en ajouter, en retirer, en réordonner
sans toucher à une ligne de HTML.

Écrite à la main, la même chose serait figée dans un bloc de texte — quand
elle survivrait à l'éditeur, ce qui est rarement le cas.

### La forme, commune aux seize

Deux champs, et deux seulement :

    PUT /blocs/12/contenu/
    {
      "type": "DYN_FAQ",
      "options":  { "multiple": false },
      "elements": [
        { "question": "Intervenez-vous le week-end ?",
          "reponse":  "Oui, en urgence.",
          "ouvert":   true },
        { "question": "Quels délais ?",
          "reponse":  "Sous 48 h en général." }
      ]
    }

`options` règle le comportement du bloc. `elements` est sa liste de contenu.
Le catalogue (`catalogue_des_blocs`, plus bas dans ce document) donne pour
chaque type le rôle exact, les options avec leurs valeurs par défaut, et les
champs admis dans un élément. **Lisez-le avant d'écrire** : il est généré
depuis le code, donc il ne peut pas décrire une option qui n'existe plus.

Quatre types n'ont pas d'`elements` du tout — compte à rebours, note — parce
que tout tient dans `options`. Le catalogue le dit explicitement.

### La règle qui surprend : `elements` REMPLACE

Envoyer `elements` remplace **la liste entière**. Ce n'est pas une fusion.

Une liste ordonnée n'a pas de clé stable sur laquelle rapprocher : fusionner
par position mettrait une réponse sous la mauvaise question dès qu'on
insérerait une entrée au milieu. On préfère un remplacement franc à une
fusion qui se trompe en silence.

Pour ajouter une entrée, relisez donc le bloc, ajoutez à la liste obtenue, et
renvoyez le tout. Omettre `elements` ne touche qu'aux `options` — c'est ainsi
qu'on change un réglage sans risquer le contenu.

### Lequel choisir

    Une question / une réponse dépliable ......... DYN_FAQ
    Des sections repliables à deux niveaux ....... DYN_ACCORDION_ADV
    Du contenu par onglets ....................... DYN_TABS
    Des images qui défilent ...................... DYN_CAROUSEL
    Des images filtrables par catégorie .......... DYN_GALLERY_FILTER
    Une liste filtrable au clavier ............... DYN_FILTER
    Des formules et leurs prix ................... DYN_PRICING_TABLE
    Des avis clients, un par un .................. DYN_TESTIMONIALS
    Des avis clients, en grille .................. DYN_TESTIMONIALS_GRID
    Un parcours en étapes numérotées ............. DYN_STEPPER
    Des barres de progression .................... DYN_PROGRESS
    Une note sur cinq étoiles .................... DYN_RATING
    Un compte à rebours .......................... DYN_COUNTDOWN
    Un compte à rebours avec bouton .............. DYN_COUNTDOWN_CTA

Deux se distinguent des autres : `DYN_RESOURCE_GRID` et
`DYN_RESOURCE_CAROUSEL` ne portent pas de contenu. **Ils affichent les fiches
du site** — produits, articles, formations — selon un modèle et une limite.
Leur contenu suit donc les fiches : en créer une nouvelle la fait apparaître,
sans toucher à la page. C'est le bon outil pour une liste de produits ou un
blog, et le mauvais pour trois encadrés fixes.

### Ce qu'ils ne remplacent pas

Un bloc dynamique met en forme une liste. Il ne met pas en page : il n'a ni
colonnes ni gouttières. La disposition reste l'affaire des lignes et des
paramètres, comme pour tout le reste.

## Les sept blocs de contenu ordinaires

Le catalogue plus bas donne pour chacun ses champs exacts. Voici ce qu'ils
font, quand les choisir, et le piège de chacun.

### TEXT — du texte riche

Le bloc le plus courant, et le seul qui contienne du HTML. Tout ce qui précède
sur l'éditeur le concerne : à plat, avec des classes, sans conteneur.

    PUT /blocs/12/contenu/  {"type": "TEXT", "texte": "<h2 class=\"t\">Titre</h2>"}

C'est aussi **le bloc des gabarits de fiche** : les jetons `[%code_champ%]`
qu'il contient sont remplacés au rendu par les valeurs de la fiche affichée.
Un seul bloc TEXT sert alors mille fiches.

### BUTTON — un appel à l'action

Sa destination dépend de sa nature, et **on n'en donne qu'une** :

    page_id           vers une page du site
    url_externe       vers l'extérieur
    fiche_cible       vers une fiche, par son slug
    produit_cible     vers un produit, par son SKU
    questionnaire     vers un test
    ajouter_au_panier ajoute un produit au panier, sans quitter la page

Il n'a pas de champ `url` : c'est l'erreur la plus fréquente, et le message
de refus vous le dira. `style` choisit son apparence parmi celles du thème.

### IMAGE — une image de la médiathèque

L'API ne téléverse pas : elle **rattache** une image déjà présente, par son
identifiant. `GET /images/` les liste, avec pour chacune son `url`, son
`apercu`, ses `variantes` et un drapeau `fichier_absent` qui signale les
entrées orphelines.

Renseignez toujours l'`alt` : c'est ce que lisent les lecteurs d'écran et les
moteurs de recherche, et personne ne revient l'ajouter.

### VIDEO — une vidéo

Soit un fichier déjà déposé, soit une URL externe (YouTube, Vimeo). Le champ
`source` dit lequel des deux.

### FORM — un formulaire de contact

Ses champs, son destinataire, son message de succès, et son apparence.
`champs` est une **liste ordonnée** : l'envoyer REMPLACE l'ensemble, parce
qu'un formulaire est un tout et que fusionner par position mélangerait les
libellés.

Les soumissions arrivent par e-mail et dans les prospects. Un agent ne les lit
pas : ce sont des données personnelles.

### CALENDAR — la prise de rendez-vous

Un seul champ, `titre`. Tout le reste — types de rendez-vous, disponibilités,
créneaux — se règle par les routes du calendrier. Le bloc n'est que la
fenêtre.

### CHART — un graphique

Type de graphique, axe principal, séries. Utile pour un tableau de bord
public ; rarement pour un site vitrine.

## Les fiches et la boutique

C'est le dispositif le plus riche de JEIKO, et le plus mal compris. Trois
objets distincts, dans cet ordre.

### 1. Le modèle de fiche — la forme

Un `CustomObjectModel` décrit **quels champs** aura chaque fiche : un titre,
un prix, une image, un texte riche, une date. Il pointe vers une **page
gabarit** qui dit à quoi ressemble le rendu.

    POST /modeles/  {"nom": "Prestation", "slug": "prestation",
                     "champs": [{"code": "duree", "libelle": "Durée",
                                 "type": "text"}]}

Le gabarit est une page ordinaire, avec des blocs ordinaires. Ses blocs TEXT
portent des jetons `[%duree%]` remplacés au rendu. **Dessinée une fois,
servie par toutes les fiches du modèle.**

Une page gabarit répond 404 si on l'ouvre directement : elle n'a pas
d'existence propre. `GET /pages/` la signale par `gabarit_de_fiche: true`.

### 2. La fiche — le contenu

Un `CustomObject` remplit les champs du modèle. C'est elle qui a une adresse,
un slug, et **ses propres métadonnées de recherche** :

    PATCH /objets/42/  {"titre": "Dépannage électrique",
                        "metadonnees": {
                          "titre": "Dépannage électrique 24h/24 — Paris 6ᵉ",
                          "description": "Intervention sous 2 h…"},
                        "valeurs": {"duree": "1 h"}}

**Les métadonnées vont sur la FICHE**, jamais sur le gabarit — il est partagé,
un titre posé là vaudrait pour toutes les fiches à la fois — et jamais sur le
produit, qui n'en a pas. Sans elles, chaque page produit sort avec le titre
brut de la fiche et **aucune description** : Google reprend alors un morceau
du corps, souvent un prix isolé.

Une fiche naît **non publiée**. `{"publie": true}` est un acte séparé.

### 3. Le produit — le commerce

Un `Product` ajoute à une fiche ce qui relève de la vente : prix, TVA, stock,
SKU, expédition. La fiche reste le contenu ; le produit est sa dimension
marchande.

    POST /produits/  {"objet_id": 42, "type_id": 3, "sku": "DEP-001",
                      "prix_ht": "89.00", "taux_tva": "20.00"}

Le **type de produit** (`ProductType`) dit ce que la vente entraîne :
livraison d'un colis, accès à une formation, réservation d'un créneau, envoi
d'un questionnaire. C'est lui qui relie la boutique aux autres modules.

Un produit naît **inactif**, comme la fiche naît non publiée.

### La liste, sur une page

On n'écrit pas les fiches à la main dans une page : on pose un
`DYN_RESOURCE_GRID` ou un `DYN_RESOURCE_CAROUSEL`, on lui donne le modèle et
une limite, et il affiche les fiches publiées. En créer une nouvelle la fait
apparaître, sans toucher à la page.

### L'ordre à respecter

    type de produit → modèle de fiche → page gabarit → fiche → produit
                                                          ↳ métadonnées

Chaque étape a besoin de la précédente. Sauter le gabarit donne une fiche qui
ne s'affiche nulle part ; sauter les métadonnées donne une boutique invisible
des moteurs de recherche.

## Quatre pièges qui vous feront perdre une passe entière

Ils ne lèvent aucune erreur. Votre appel répond 200, et le résultat n'est pas
celui que vous attendiez. Lisez-les avant d'écrire du HTML.

### 1. Vos styles en ligne sont RÉDUITS — silencieusement

Le HTML que vous envoyez est assaini avant d'être rendu. Sont conservés
`class`, `id`, `title`, `role` et les `aria-*`.

L'attribut `style` traverse, mais **amputé de tout ce qui n'est pas dans cette
liste** :

    color   background-color   text-align
    font-weight   font-style   text-decoration

Le filtre travaille déclaration par déclaration. `style="position:fixed;
color:red"` arrive donc en `style="color: red"` : la couleur passe, le
positionnement disparaît. Si rien ne survit, l'attribut entier est retiré.

Aucune des propriétés retenues ne positionne, n'anime, ni ne charge de
ressource — c'est exactement ce qui les rend acceptables. Un `style` libre est
une porte ouverte sans avoir besoin du moindre script : un `position:fixed;
inset:0` recouvre la page d'un calque invisible et détourne les clics, et un
`url()` fait signer chaque affichage à un serveur tiers.

N'y voyez donc pas une limitation à contourner. Et surtout, **ne vous
appuyez pas dessus pour mettre en page** : six propriétés ne font pas une mise
en forme. Vous avez trois voies, et chacune a son domaine.

**Les paramètres, pour tout ce qui a un réglage.** Fond, marges, paddings,
tailles, bordures, image de fond : ils se posent par `PATCH` sur la section, la
ligne ou le bloc, appareil par appareil. C'est la voie normale — préférez-la.

**Le texte lui-même, pour la couleur et la mise en valeur.** `color`,
`background-color` et `text-align` en ligne, `<strong>` et `<em>` : ces
six-là ne sont pas un pis-aller, c'est leur bon endroit. L'éditeur de
l'administration les rend à l'exploitant dans sa barre d'outils, et un style en
ligne l'emporte sur toutes les feuilles — la vôtre comme celle du site. Un
titre en blanc sur un fond sombre s'écrit donc

    <h2 style="color:#fff">Nos tarifs</h2>

et non dans une classe, qui se ferait battre par les réglages de police du
site (piège nº 2) et que l'exploitant ne pourrait pas retoucher.

Les variables du thème passent ici aussi : `style="color: var(--jk-accent)"`
donne un texte qui suivra la charte le jour où l'exploitant la change. C'est
la meilleure des deux écritures — préférez-la à une couleur en dur dès que la
couleur en question EST une couleur du site.

**Le CSS du bloc, pour ce qui n'a aucune des deux.** Taille de texte, graisse,
interlignage, largeurs, espacements entre éléments, survols, pseudo-éléments.
Une exception qui n'en souffre pas : **jamais `font-family`** — le site ne
charge que les polices de son identité, et en nommer une autre laisse le
navigateur retomber sur ce qu'il veut. Écrivez des `class` dans votre HTML,
puis posez la feuille dans `css.custom` d'une section :

    PATCH /sections/8/  {"css": {"custom": ".content .mon-titre{letter-spacing:.2em}"}}

`css` accepte aussi `current`, `hover`, et leurs variantes par appareil
(`current_phone`, `hover_tablet`…). Une seule feuille posée sur la première
section suffit pour toute la page.

Et si c'est toute la typographie de la page qui doit changer, ce n'est
d'aucune de ces trois voies qu'il s'agit : ce sont les polices du SITE. Voir
« Les polices se règlent AILLEURS ».

### 2. Les réglages de police du site l'emportent sur vos classes

Le site pose ses propres règles, du genre `.content h1 { color: … }`. En
spécificité CSS, cela vaut (0,1,1) — et votre `.mon-titre` ne vaut que (0,1,0).
**Le site gagne, et votre couleur est ignorée.**

Le symptôme est spectaculaire et facile à ne pas voir : un titre blanc demandé
sur un fond sombre s'affiche en noir sur noir.

**Le style en ligne, lui, gagne toujours** : `<h2 style="color:#fff">` passe
devant les deux. C'est la raison pour laquelle la couleur s'écrit dans le
texte plutôt que dans une classe — elle n'a pas de bataille de spécificité à
livrer, et l'exploitant la retrouve dans son éditeur.

La parade tient en un préfixe : écrivez `.content .mon-titre`, qui vaut (0,2,0)
et l'emporte. N'utilisez pas `!important` — vous gagneriez contre le site, mais
aussi contre l'exploitant qui voudra ajuster sa page ensuite.

Et posez-vous d'abord la question de l'endroit : si vous vous battez contre les
règles de police du site, c'est souvent que le réglage devait aller dans les
polices du site, pas dans le CSS d'un bloc. Voir « Les polices se règlent
AILLEURS ».

### 3. Vos balises aussi passent par une liste blanche — mais on vous le dit

Le HTML est réduit à des balises de contenu. **`<svg>`, `<iframe>`, `<style>`
et `<script>` sont retirés**, avec tout ce qu'ils contiennent. `<details>` et
`<summary>` passent, eux : c'est de quoi écrire un repli sans une ligne de
script.

Le point important n'est pas la liste, c'est **quand** elle s'applique. L'API
assainit à l'ÉCRITURE : ce que vous relisez est exactement ce que le visiteur
verra. Ce ne fut pas toujours le cas — l'assainissement n'existait qu'au
rendu, votre relecture vous confirmait un HTML intact, et la page publiée
était amputée. La relecture que ce guide vous recommande est donc redevenue
une vraie garantie.

Et la réponse du `PUT` porte un tableau `avertissements` dès qu'elle a retiré
quelque chose :

    PUT /blocs/614/contenu/  {"type": "TEXT", "texte": "<p><svg…></svg>Bonjour</p>"}
    → 200  {"bloc": {…},
            "avertissements": ["balise <svg> retirée — …"]}

Lisez-le. Il est vide quand tout est passé, ce qui en fait un signal et non un
bruit de fond.

Pour dessiner sans passer par la médiathèque — que vous ne pouvez pas
alimenter — la voie est `css.custom` : dégradés, formes, bordures composées.
Elle arrive intacte dans la page.

### 4. Une répartition doit décrire toutes les colonnes

`columns_type` dit comment les colonnes d'une ligne se partagent les douze
unités de la grille. **Il lui faut autant de segments que la ligne a de
colonnes**, sur chacun des trois appareils.

Écrire « 12 » sur une ligne de trois colonnes n'en sert qu'une : les deux
autres n'ont aucune largeur et leurs blocs tombent à trente pixels,
illisibles. C'est refusé, avec la valeur attendue dans le message — mais
autant ne pas avoir à le lire.

Une ligne créée par `POST /sections/<id>/lignes/ {"colonnes": 3}` naît déjà
décrite : `4-4-4` sur les grands écrans, `12-12-12` sur téléphone, où trois
colonnes côte à côte n'ont aucun sens. Vous n'avez à toucher `columns_type`
que pour vous écarter de ce défaut, par exemple pour un `8-4`.

## L'inventaire : ce qui se règle, et où

Trois endroits, et un seul est bon pour chaque chose. Les confondre est la
cause la plus fréquente d'une passe perdue.

### Section, ligne, bloc : les mêmes sept familles

Les trois niveaux héritent du même jeu de paramètres, posés par `PATCH` sur
`/sections/<id>/`, `/lignes/<id>/` ou `/blocs/<id>/`. Le document
`parametres` du guide en donne la liste exacte, lue sur les modèles :

    fond        couleur, image de fond, et ses sept réglages (répétition,
                cadrage, position, flou, luminosité, opacité, attachement)
    marges      les quatre côtés, pour chacun des quatre appareils
    paddings    idem
    tailles     largeur et hauteur, par appareil
    bordure     épaisseur, style, couleur, rayon
    animation   préréglage, déclencheur, durée, délai, et l'activation
                appareil par appareil
    css         object_classes, before, current, after, hover, custom,
                et les variantes par appareil (current_phone, hover_tablet…)

À quoi s'ajoutent les champs propres à chaque niveau — `is_hero` pour une
section, la répartition des colonnes pour une ligne, la colonne et le rang
pour un bloc. Ils sont dans `parametres.champs_propres`.

**Choisissez le bon niveau.** Un fond qui doit couvrir toute la largeur va sur
la SECTION ; une gouttière entre deux colonnes, sur la LIGNE ; un décalage qui
ne concerne qu'un titre, sur le BLOC. Poser sur le bloc ce qui relève de la
section produit une page qui se déforme au premier changement de largeur.

### Contenu par contenu : où vit l'apparence

Un contenu n'a presque jamais de style à lui. Le tableau dit lequel en a un,
et où va le reste.

    TEXT         aucun champ de style. La couleur et le style du texte
                 s'écrivent DANS le texte, en balises — voir ci-dessous.
    BUTTON       « bouton.style » : fond, couleur_texte, rayon, padding.
    FORM         « style » : couleur du bouton, du survol, du texte, rayon.
                 En hexadécimal — « var(--jk-accent) » est refusé ici.
    IMAGE        aucun style propre : cadrage et taille par les paramètres
                 du bloc.
    VIDEO        des champs de comportement (ratio, contrôles, autoplay…),
                 pas de style : le reste par le bloc.
    CHART        titre, type de graphique, axe, options ; couleurs comprises
                 dans « options ».
    CALENDAR     un titre. L'apparence vient du produit.
    DYN_*        tout est dans « options » — colonnes, intervalles, libellés —
                 et le contenu dans « elements ».

Le catalogue des blocs donne, pour chaque type, ses champs et cette même
indication sous la clé « style ».

### Le texte : couleur et style s'écrivent dans le texte

C'est la règle qui surprend le plus, et elle est délibérée. Un bloc TEXT ne
porte ni couleur, ni graisse, ni alignement : **il porte du HTML**, et c'est ce
HTML qui dit la mise en forme.

    <p><strong>Un mot en gras</strong>, <em>un autre en italique</em>,
       <span style="color:#A34A09">et un troisième en couleur</span>.</p>
    <p style="text-align:center">Un paragraphe centré.</p>

Les balises qui **survivent à l'éditeur** sont mesurées, pas supposées :
`<strong>`, `<em>`, `<a href>`, `<img>`, `<table>`, `<blockquote>`, les `<p>`
et `<h1>`…`<h6>` avec leur `class`, et les listes en
`<ol><li data-list="bullet">`. C'est la raison de fond de cette règle : ce qui
est écrit dans le texte reste modifiable par la personne qui tient le site ;
ce qui est écrit dans une feuille de style ne l'est plus.

D'autres balises passent l'assainissement (`u`, `s`, `mark`, `sup`, `sub`…) :
le site les rendra correctement, mais l'éditeur ne les rendra pas à
l'exploitant. À réserver à ce qui n'a pas vocation à être retouché.

L'attribut `style` passe aussi, mais réduit à six propriétés — `color`,
`background-color`, `text-align`, `font-weight`, `font-style`,
`text-decoration`. Assez pour une mise en valeur ponctuelle, pas pour une mise
en page : voir le piège nº 1.

Et pour tout ce qui dépasse — une taille, une typographie, une largeur — ne
forcez pas le texte : posez une `class` dans votre HTML et la règle dans le
`css` du bloc ou de la section, ou réglez la police du SITE si c'est toute la
page qui doit changer.

## Ce que l'API refuse, et pourquoi elle le fait bruyamment

**Une clé qu'elle ne connaît pas, à la création comme à la modification.**
`{"gabarit_de_section": "HERO"}` là où le champ s'appelle `gabarit` rend un
400 qui liste les clés acceptées, et **ne crée rien**. Une faute de frappe
coûte un message, jamais une ligne en base : c'est ce qui vous évite de
découvrir, trois passes plus tard, une section vide que vous croyiez avoir
remplie.

Le principe est constant : **une clé inconnue lève, elle n'est jamais avalée.**
Cela vaut pour les contenus de bloc comme pour les paramètres.

    PATCH /sections/126/  {"couleur_de_fond": "#ffffff"}
    → 400, avec la liste des clés acceptées

La bonne écriture est `{"fond": {"couleur": "#ffffff"}}`. Le message d'erreur
la donne : lisez-le plutôt que de revenir ici.

Cette règle existe pour vous. Un 200 qui ne produit rien vous fait passer à la
suite en croyant avoir écrit, et le défaut ne se découvre qu'en relisant le
rendu — s'il vous vient à l'idée de le faire. Un 400 vous corrige tout de
suite.

## Réordonner

`position` n'est pas modifiable par `PATCH` : l'écrire à la main produirait
deux éléments au même rang, donc un ordre d'affichage arbitraire. On passe par
un point d'entrée qui renumérote les deux côtés :

    POST /deplacer/section/12/  {"sens": "haut"}
    POST /deplacer/ligne/45/    {"sens": "bas"}
    POST /deplacer/bloc/78/     {"sens": "haut"}

La réponse porte `deplace: false` quand l'élément est déjà en bout de course —
ce n'est pas une erreur, et la `raison` le dit. N'insistez pas.

**Un bloc se déplace dans SA colonne.** Deux blocs de colonnes différentes sont
côte à côte, pas l'un au-dessus de l'autre : les monter ne les échangera jamais.

## Les métadonnées : à remplir sur CHAQUE page, sans exception

Le titre et la description qui partent dans les résultats de recherche :

    PATCH /pages/12/  {"metadonnees": {"titre": "Nos tarifs — Atelier",
                                       "description": "Trois formules…"}}

**Ce n'est pas une finition, c'est une partie de la page.** Une page livrée
sans métadonnées est une page à moitié faite : Google découpe alors un morceau
du corps, souvent le fil d'Ariane ou un bout de menu, et c'est ce morceau-là
qui représente le site dans les résultats. Personne ne l'a choisi.

La même description sert une seconde fois : `/llms.txt`, la carte du site à
l'usage des modèles de langue, est construite à partir d'elle. Sans elle, la
page n'y figure qu'avec son titre — et un assistant qui doit répondre sur ce
site ne saura pas ce qu'elle contient.

**Le titre.** Le sujet de la page, puis le nom du site, séparés par un tiret
cadratin. Autour de soixante signes : au-delà, Google le coupe et la fin est
perdue. Il diffère du titre affiché dans la page quand celui-ci est court ou
allusif — « Nos tarifs » devient « Tarifs de l'accompagnement individuel —
Atelier Untel ». Deux pages ne partagent jamais le même titre : deux titres
identiques, ce sont deux pages qui se disputent le même résultat.

**La description.** Une à deux phrases, cent cinquante signes environ, qui
disent ce qu'on trouve sur la page et ce qu'on peut y faire. Elle s'adresse à
quelqu'un qui hésite entre dix liens, pas à un moteur : on y écrit une phrase
complète, jamais une liste de mots-clés. Elle reprend les termes que la
personne utiliserait pour chercher — le métier, la ville, le nom de la
formule — parce que ce sont ceux qu'elle reconnaîtra.

**Rien d'inventé.** Une description qui promet ce que la page ne contient pas
fait repartir le visiteur en trois secondes, et ce départ se voit. Si vous ne
savez pas décrire la page, c'est la page qu'il faut reprendre.

Cas particulier : une page de résultat de questionnaire ou une page de gabarit
de fiche a, elle aussi, droit à ses métadonnées — c'est souvent la première
page du site qu'un visiteur rencontre depuis une recherche.

## Ranger les pages : catégories et sous-catégories

Une page porte une `categorie` et, si la catégorie en a, une
`sous_categorie`. Ce n'est pas du classement pour le plaisir de classer : la
catégorie **entre dans l'adresse** de la page quand elle est marquée
`afficher_dans_l_url`, elle groupe les pages dans `/llms.txt` et dans le plan
du site, et c'est à elle qu'on accroche les menus — c'est ce qui permet à une
partie du site d'avoir sa propre navigation.

    GET  /categories/                  ce qui existe déjà, avec les slugs
    POST /categories/creer/            {"nom": …, "slug": …,
                                        "categorie_parente": <slug>,
                                        "afficher_dans_l_url": true}
    PATCH /pages/12/                   {"categorie": "questionnaires",
                                        "sous_categorie": "bilan-de-carriere"}

Quatre règles à connaître avant de créer :

* **Le slug ne se modifie pas.** Il est dans les adresses publiées ; le
  renommer casserait des liens sans le dire. Choisissez-le à la création.
* **Une sous-catégorie ne peut pas se montrer dans l'URL si sa parente ne s'y
  montre pas.** L'API le refuse en le disant, plutôt que de produire une
  adresse à trou.
* **Un même nom et un même slug servent sous deux parentes différentes.** Ce
  qui doit être unique, c'est l'ADRESSE, pas le mot : « Actualités » sous
  « Formations » et sous « Coaching » donnent `/formations/actualites/` et
  `/coaching/actualites/`, que rien ne confond. Inutile d'inventer
  « actualites-2 » — le visiteur le lirait dans la barre d'adresse.
* **Deux catégories qui n'apparaissent PAS dans les URL ne peuvent pas
  partager un slug.** Sans chemin, plus rien ne les sépare — ni pour le
  visiteur, ni pour vous : `{"categorie": "actualites"}` deviendrait ambigu.
  Quand un slug désigne plusieurs catégories, l'API refuse et vous rend la
  liste avec leurs identifiants ; désignez celle que vous visez par son
  identifiant.

### Retirer une catégorie des URL déplace ses pages

`{"afficher_dans_l_url": false}` n'est pas un réglage d'affichage : il **retire
un segment à l'adresse de toutes les pages de la catégorie**, qui remontent
d'un cran — jusqu'à la racine du site s'il s'agit de la catégorie principale.
`/formations/tarifs/` devient `/tarifs/`.

Là où deux pages ne se distinguaient que par ce segment, elles se retrouvent à
la même adresse : une seule répond, l'autre devient inatteignable. L'API
vérifie donc, avant d'écrire, qu'aucune page n'irait occuper une adresse déjà
prise, et refuse en nommant les pages et l'adresse en cause. Renommez leur
`url_tag`, ou laissez la catégorie paraître dans l'URL.

La même règle vaut pour les pages : deux pages portent le même `url_tag` tant
que leur classement les sépare, et `409` tombe dès que l'adresse complète est
déjà celle d'une autre — la réponse la nomme.

### L'exemple à copier : les pages de résultat d'un questionnaire

Un questionnaire a un profil par résultat possible, et chaque profil désigne
sa `page_de_resultat`. Trois questionnaires de quatre profils, c'est douze
pages qui n'ont rien à faire à la racine du site.

Rangez-les à deux niveaux : une catégorie `questionnaires` pour la famille,
une sous-catégorie **par test** pour le distinguer.

    POST /categories/creer/  {"nom": "Questionnaires", "slug": "questionnaires"}
    POST /categories/creer/  {"nom": "Bilan de carrière",
                              "slug": "bilan-de-carriere",
                              "categorie_parente": "questionnaires"}

    POST /pages/creer/       {"titre": "Votre profil : le bâtisseur", …}
    PATCH /pages/57/         {"categorie": "questionnaires",
                              "sous_categorie": "bilan-de-carriere"}

L'adresse devient `/questionnaires/bilan-de-carriere/le-batisseur/` : le
visiteur qui la lit sait où il est, et l'exploitant qui ouvre son
administration six mois plus tard retrouve ses douze pages ensemble au lieu de
les chercher parmi deux cents.

## La palette du site

Le site a un thème réglé par son exploitant : dix couleurs, exposées en
variables CSS sur `:root`. `GET /api/agent/v1/` vous les donne dans
`theme_du_site`.

**Servez-vous-en plutôt que d'inventer.** Écrire `var(--jk-accent)` plutôt
qu'une couleur en dur, c'est faire une page qui suivra le jour où l'exploitant
changera d'avis — et qui ne détonnera pas avec le reste du site. Ces variables
s'écrivent aussi bien dans le `css` d'un bloc que dans le `style` en ligne d'un
texte : `style="color: var(--jk-accent)"` traverse l'assainissement.

    --jk-accent           boutons, liens, éléments actifs
    --jk-accent-survol    sa version foncée
    --jk-sur-accent       le texte posé SUR un fond d'accent
    --jk-secondaire       bandeaux, pieds de page, fonds sombres
    --jk-tertiaire        touches discrètes, fonds de mise en avant
    --jk-texte            --jk-texte-attenue
    --jk-fond             --jk-fond-attenue
    --jk-bordure

## Les polices se règlent AILLEURS — jamais dans votre CSS

N'écrivez **ni `@import`, ni `url()` distante** dans le CSS d'une section,
d'une ligne ou d'un bloc. L'API les refuse, et deux raisons le justifient — la
première suffirait.

**Un `@import` ne marche pas là où vous l'écrivez.** Le CSS personnalisé est
rendu dans un `<style>` que quatre règles précèdent déjà. Or la règle du CSS
veut qu'un `@import` vienne avant toute règle : placé après, il est **ignoré
par tous les navigateurs**. La police n'est jamais chargée, la page retombe
sur la police de secours, et rien ne le signale. Vous croyez avoir posé une
typographie ; vous avez posé du Georgia.

**Et s'il marchait, ce serait pire.** Une adresse `fonts.googleapis.com` fait
partir l'adresse IP de chaque visiteur chez un tiers, à chaque page, avant
tout consentement. Le produit auto-héberge ses polices exactement pour éviter
cela ; en rappeler une par le CDN annulerait ce travail sur votre page.

**Ce qu'il faut faire à la place.** Les polices sont un réglage de SITE :

    PATCH /api/agent/v1/identite/
    {"polices": {"ordinateur": {"h1": {"famille": "EB Garamond",
                                       "secours": "Georgia, serif",
                                       "taille": "58px",
                                       "url_google_fonts": "https://fonts.googleapis.com/css2?family=EB+Garamond"}}}}

Onze rôles — `text`, `h1` à `h4`, `links`, `menu`… — déclinés sur trois
appareils : `telephone`, `tablette`, `ordinateur`. Chaque rôle porte famille,
secours, taille, graisse, style, variante, étirement, couleur, interlignage.
`GET /api/agent/v1/identite/` vous rend l'état courant, `PATCH` n'écrit que ce
que vous envoyez.

`url_google_fonts` est la façon PROPRE de demander une famille de Google : le
site la télécharge et la sert lui-même. C'est la même famille, sans le tiers.

**Une exception à connaître : le rôle `menu`.** Sa famille vient bien d'ici,
mais sa TAILLE et sa COULEUR sortent du style de menu, qui pose ses propres
variables CSS avec une spécificité plus forte et l'emporte toujours. Le style
de menu n'est pas ouvert à l'API — un même style sert plusieurs menus, et le
changer depuis une clé d'édition repeindrait des menus qu'on ne visait pas.
Régler la seule famille laisse donc un menu à la taille qu'il avait :
demandez le reste à l'exploitant, qui le règle dans Administration → Menus. La
réponse du `PATCH` porte une « remarque » qui le redit quand vous touchez à ce
rôle.

Un réglage de site vaut partout, et c'est le but : une page dont la
typographie ne ressemble à aucune autre du site n'est pas une page réussie.
Si votre rôle ne vous donne pas `/identite/`, demandez la police à
l'exploitant — ne la contournez pas en CSS, vous feriez une page qui ne
suivra jamais un changement de charte.

## Les images

Vous ne téléversez pas de fichier : vous **réutilisez** ce qui est déjà dans la
médiathèque.

    GET /images/            → [{"id": 42, "alt": "…", "url": "…"}, …]
    GET /images/?apres=42   → la page suivante

L'identifiant obtenu se pose dans un champ image de fiche, ou dans
`fond.image_id` d'une section. Le téléversement passe par l'administration :
c'est là que s'appliquent le plafond de poids et la garde contre les images
qui font tomber le serveur en se dépliant.

## Les fiches : une page dessinée une fois, autant de pages qu'il y a de fiches

C'est le cas d'usage le plus rentable de cette API, et il mérite d'être compris
avant de construire trente pages à la main.

Un **modèle de fiche** (« Produit », « Réalisation », « Membre de l'équipe »)
déclare des champs et désigne une page qui lui sert de gabarit. Cette page
contient des jetons `[%code%]` remplacés, pour chaque fiche, par ses valeurs.

    GET /modeles/     ← le contrat : quels modèles, quels champs, quels types
    POST /objets/creer/  {"modele": "produit",
                          "titre": "Chaise Ada",
                          "valeurs": {"description": "…", "prix_barre": "149 €"}}

Le `GET /modeles/` n'est pas facultatif : c'est là que vous apprenez qu'un
champ s'appelle `prix_barre` et qu'il attend du texte court. Écrire un code de
champ au jugé produit une erreur 400 — utile, elle liste les codes valides,
mais c'est un aller-retour de perdu.

**Les champs se remplissent selon leur type** :

    text / rich_text  "une chaîne"
    image             12                      (identifiant d'une image de la médiathèque)
    video             "https://…"
    button            {"libelle": "Acheter", "page_id": 7}
                      ou "url_externe", ou "questionnaire"

Comme pour les paramètres de page, **ce que vous ne mentionnez pas ne bouge
pas** : corriger un prix ne remet pas la description à zéro.

## Les produits : le commerce d'une fiche

Une fiche porte le contenu, un produit porte la vente. Les deux sont liés :

    POST /produits/creer/  {"type": "objet", "fiche_id": 42,
                            "sku": "chaise-ada", "prix_ht": "120.00", "stock": 8}

Créer la fiche d'abord, le produit ensuite. Un produit sans fiche n'a rien à
afficher.

## Un exemple complet

Créer une page « Nos tarifs » avec une section à deux colonnes :

    POST /pages/creer/            {"titre": "Nos tarifs"}
                                  → page.id
    POST /pages/<page>/sections/  {"gabarit": "CLASSIC"}
                                  → section.id
    POST /sections/<sec>/lignes/  {"colonnes": 2}
                                  → ligne.id
    POST /lignes/<lig>/blocs/     {"colonne": 0}
                                  → bloc.id
    PUT  /blocs/<bloc>/contenu/   {"type": "TEXT", "texte": "<h2>Nos tarifs</h2>"}
    PATCH /sections/<sec>/        {"fond": {"couleur": "rgba(246,246,246,1)"},
                                   "paddings": {"computer": {"haut": "60px", "bas": "60px"},
                                                "phone": {"haut": "30px", "bas": "30px"}}}
    PATCH /pages/<page>/          {"publiee": true}

Sept appels pour une page complète et en ligne.

## Quand ça ne marche pas

- **401** — votre jeton n'est pas accepté. Le message ne dit jamais pourquoi,
  volontairement. Vérifiez que vous l'envoyez bien en en-tête
  `Authorization: Bearer <jeton>`, et que vous êtes en HTTPS.
- **429** — votre jeton est bon, mais vous avez épuisé votre plafond d'appels.
  Celui-là s'explique : la réponse donne le plafond, la fenêtre et le nombre
  de secondes à attendre, aussi en en-tête `Retry-After`. Attendez ce délai
  plutôt que de réessayer en boucle — chaque essai refusé compte aussi. Si
  vous CONSTRUISEZ un site, quelques centaines d'appels par heure sont
  normales : demandez à l'exploitant de relever le plafond de votre agent
  dans son administration, plutôt que de travailler au ralenti.
- **403** — vous êtes identifié mais votre rôle ne le permet pas. La réponse
  nomme la permission qui manque ; c'est à l'exploitant du site de vous
  l'accorder.
- **400** — votre document est mal formé. Le message dit quoi, et liste
  souvent les valeurs acceptées.
- **409** — conflit, typiquement une adresse de page déjà prise.
""".strip()


def _theme_du_site():
    """
    La palette du site, pour qu'un agent l'emploie au lieu d'inventer.

    Sans elle, chaque page construite par une IA arrive avec ses propres
    couleurs, et le site devient un patchwork. Avec elle, l'agent écrit
    `var(--jk-accent)` et suit ce que l'exploitant a réglé.
    """
    from jeiko.administration.website_cache import get_website_data

    site = get_website_data()
    theme = getattr(site, "theme", None) if site else None
    if theme is None:
        return None

    return {
        "couleurs": theme.couleurs(),
        "variables_css": [variable for _, variable in theme.VARIABLES],
        "comment_s_en_servir": (
            "Écrivez var(--jk-accent) dans le CSS d'un bloc plutôt qu'une "
            "couleur en dur : le jour où l'exploitant change sa palette dans "
            "Réglages ▸ Thème, votre page suit toute seule."
        ),
    }



# ---------------------------------------------------------------------------
#  Le catalogue
# ---------------------------------------------------------------------------
#
# Un agent qui découvre JEIKO ne connaît pas ses blocs. Lui donner la liste des
# routes ne suffit pas : il saura POSER un contenu sans savoir LEQUEL choisir.
# D'où ce catalogue — une phrase par outil, qui dit à quoi il sert et ce qu'il
# attend.
#
# Les options viennent de `DYNAMIC_DEFAULTS`, les éléments de `TYPES` : ce sont
# les constantes que le code applique réellement. Une option ajoutée demain
# apparaîtra ici sans que personne y pense.

#: À quoi sert chaque bloc, en une phrase. La seule part écrite à la main du
#: catalogue — une intention ne s'introspecte pas. Un type absent d'ici sortira
#: quand même, sans sa phrase : le catalogue reste complet, jamais tronqué.
#: Où se règle l'APPARENCE de chaque type, en une phrase.
#:
#: Le rôle dit à quoi sert un bloc ; il ne dit pas où le rendre beau. Un agent
#: qui l'ignore écrit du CSS pour ce qui avait un champ, ou cherche un champ
#: pour ce qui relevait du CSS — dans les deux cas il perd une passe, et le
#: résultat se défait au premier changement.
#:
#: Les types absents de ce dictionnaire tombent sur `STYLE_PAR_DEFAUT`, qui
#: est la réponse juste pour la majorité : rien en propre, tout par le bloc.
STYLE_PAR_DEFAUT = (
    "Aucun champ de style en propre : l'apparence vient des paramètres du "
    "bloc (fond, marges, paddings, tailles, bordure) et de son « css »."
)

STYLE_DES_BLOCS = {
    "TEXT": (
        "AUCUN champ de style — et c'est délibéré. La couleur et le style du "
        "texte s'écrivent DANS le texte : <strong>, <em>, et style=\"color: "
        "…; background-color: …; text-align: …\" en ligne (six propriétés "
        "acceptées, pas une de plus). Ce qui est dans le texte reste "
        "modifiable par l'exploitant dans son éditeur ; ce qui est dans une "
        "feuille de style ne l'est plus. Pour la typographie et les largeurs, "
        "posez une class et la règle dans le « css » du bloc ou de la section."
    ),
    "BUTTON": (
        "« bouton.style » : fond, couleur_texte, rayon, padding. Le reste "
        "(marges, alignement) par les paramètres du bloc."
    ),
    "FORM": (
        "« style » : couleur_du_bouton, couleur_du_bouton_survol, "
        "couleur_du_texte_du_bouton, rayon_du_bouton. En HEXADÉCIMAL — "
        "« var(--jk-accent) » est refusé ici. Sans style, le bouton garde le "
        "bleu par défaut, qui jure sur un site aux couleurs de la maison."
    ),
    "CHART": (
        "Les couleurs et l'axe se règlent dans « options » du graphique, pas "
        "en CSS : le rendu est dessiné, une règle CSS ne l'atteindrait pas."
    ),
    "VIDEO": (
        "Des champs de COMPORTEMENT (ratio, contrôles, lecture automatique, "
        "boucle…), pas de style. Le cadre vient des paramètres du bloc."
    ),
}

ROLE_DES_BLOCS = {
    "TEXT": ("Du texte riche (HTML). Le bloc le plus courant : titres, paragraphes, "
             "listes. C'est AUSSI le bloc des pages modèles : les jetons [%code%] "
             "qu'il contient sont remplacés au rendu par les valeurs de la fiche "
             "affichée — plus « titre » et « slug », que toute fiche possède."),

    "IMAGE": "Une image de la médiathèque. Le fichier se dépose depuis l'administration.",
    "BUTTON": "Un bouton d'appel à l'action, vers une page, une URL ou un panier.",
    "VIDEO": "Une vidéo.",
    "FORM": "Un formulaire de contact : ses champs, son destinataire, son message de succès.",
    "CALENDAR": "Un calendrier de prise de rendez-vous.",
    "CHART": "Un graphique.",
    "DYN_FAQ": "Questions/réponses dépliables. « multiple » autorise plusieurs ouvertes à la fois.",
    "DYN_TABS": "Des onglets. « active » est l'index de celui ouvert au chargement.",
    "DYN_CAROUSEL": "Un carrousel d'images qui défile.",
    "DYN_PROGRESS": "Des barres de progression, ou un fil d'étapes franchies.",
    "DYN_TESTIMONIALS": "Des témoignages qui défilent, un à la fois.",
    "DYN_TESTIMONIALS_GRID": "Des témoignages en grille. « perRow » fixe le nombre par rangée.",
    "DYN_FILTER": "Une liste filtrable en direct. « keys » dit sur quels champs porte la recherche.",
    "DYN_COUNTDOWN": "Un compte à rebours vers « deadline » (date ISO).",
    "DYN_COUNTDOWN_CTA": "Un compte à rebours doublé d'un bouton.",
    "DYN_ACCORDION_ADV": "Un accordéon à deux niveaux : des sections, chacune avec ses entrées.",
    "DYN_PRICING_TABLE": "Une table de tarifs. « yearly » affiche d'emblée la bascule annuelle.",
    "DYN_GALLERY_FILTER": "Une galerie d'images filtrable par catégorie.",
    "DYN_STEPPER": "Un parcours en étapes numérotées.",
    "DYN_RATING": "Une note sur « max » étoiles, avec le nombre d'avis.",
    "DYN_RESOURCE_CAROUSEL": "Un carrousel alimenté par des ressources du site.",
    "DYN_RESOURCE_GRID": "Une grille alimentée par des ressources du site.",
}


def _catalogue_des_blocs():
    """
    Tous les contenus posables, avec leurs options et leurs éléments.

    L'ordre des clés est celui de la lecture : ce que c'est, puis ce qui se
    règle, puis ce qui se liste.
    """
    from jeiko.administration_pages.models import DYNAMIC_DEFAULTS

    catalogue = {}
    for type_ in sorted(TYPES_OUVERTS):
        fiche = {
            "role": ROLE_DES_BLOCS.get(type_, ""),
            "style": STYLE_DES_BLOCS.get(type_, STYLE_PAR_DEFAUT),
        }

        defauts = DYNAMIC_DEFAULTS.get(type_)
        if defauts is not None:
            # Les listes de `DYNAMIC_DEFAULTS` sont l'emplacement des éléments,
            # pas une option : les montrer ferait croire qu'on peut les écrire
            # directement dans « options ». Elles se remplissent par
            # « elements », et par lui seul.
            fiche["options"] = {
                cle: valeur for cle, valeur in defauts.items()
                if not isinstance(valeur, list)
            }

        if type_ in _dyn.TYPES:
            _, _, correspondances = _dyn.TYPES[type_]
            fiche["elements"] = sorted(correspondances)
        elif type_ in _dyn.TYPES_SANS_ELEMENTS:
            fiche["elements"] = "aucun — tout se règle dans « options »"

        # Les contenus non dynamiques ont, eux, un document de champs nommé
        # d'après le type (« dyn_resource_grid », « chart »…). Ne pas les
        # documenter laissait un agent deviner que la grille de ressources
        # accepte « type_de_produit » — c'est-à-dire ne jamais s'en servir.
        if type_ in CONTENUS_SIMPLES:
            lien, _, correspondances = CONTENUS_SIMPLES[type_]
            fiche["document"] = type_.lower()
            fiche["champs"] = sorted(correspondances)

        # VIDEO n'est ni dynamique ni « simple » : ses champs sont écrits en
        # dur dans la vue. Les taire laissait deviner qu'on règle le ratio et
        # les contrôles — c'est-à-dire ne jamais s'en servir.
        if type_ == "VIDEO":
            fiche["document"] = "video"
            fiche["champs"] = sorted(CHAMPS_VIDEO)

        catalogue[type_] = fiche
    return catalogue


#: Version de l'API, et ce qu'elle promet.
#:
#: `/api/agent/v1/` est la v1. Ce qui suit n'est pas une intention mais une
#: règle, parce qu'un agent écrit du code contre ce contrat et ne relit pas le
#: guide à chaque appel.
#:
#: **Ce qui peut changer dans la v1**, sans prévenir :
#:   * l'AJOUT d'une route, d'un champ, d'un type de bloc ;
#:   * l'ajout d'une clé dans une réponse ;
#:   * un message d'erreur, qui est pour l'humain qui lit le journal.
#:
#: **Ce qui ne change pas dans la v1** :
#:   * le nom et le sens d'une clé existante — en requête comme en réponse ;
#:   * le chemin d'une route livrée ;
#:   * la permission exigée par une route, sauf pour l'assouplir.
#:
#: Le jour où l'un de ces trois derniers doit bouger, ce sera `/v2/`, servie
#: **à côté** de la v1 le temps que les agents migrent — pas à la place. Une
#: rupture silencieuse sur la même adresse est le pire des deux mondes : le
#: code continue de tourner et écrit n'importe quoi.
#:
#: Les refus de clés inconnues, ajoutés le 03/09, rendent cette promesse
#: tenable : un agent qui envoie une clé retirée reçoit une erreur au lieu
#: d'un succès muet.
VERSION = {
    "numero": "1",
    "racine": RACINE,
    "compatible": [
        "Ajout d'une route, d'un champ, d'un type de bloc.",
        "Ajout d'une clé dans une réponse.",
        "Reformulation d'un message d'erreur.",
    ],
    "rupture": [
        "Renommer ou changer le sens d'une clé existante.",
        "Déplacer ou retirer une route livrée.",
        "Durcir la permission exigée par une route.",
    ],
    "en_cas_de_rupture": (
        "Une /v2/ est servie À CÔTÉ de la v1, pas à la place, le temps que "
        "les agents migrent. Une rupture silencieuse sur la même adresse "
        "laisserait le code tourner en écrivant n'importe quoi."
    ),
}


def construire():
    """Le guide complet, prose et références."""
    return {
        "guide": PROSE,
        "racine": RACINE,
        "version": VERSION,
        "points_d_entree": _points_d_entree(),
        "theme_du_site": _theme_du_site(),
        "vocabulaire": {
            "page": "Une adresse du site. Contient des sections, dans l'ordre.",
            "section": "Une bande horizontale. Contient des lignes.",
            "ligne": "Une rangée découpée en colonnes. Contient des blocs.",
            "bloc": "Une case dans une colonne. Contient un contenu.",
            "colonne": "Numéro de colonne d'un bloc, à partir de 0. PAS un rang vertical.",
            "repartition": (
                "« columns_type », « columns_type_tablet » et "
                "« columns_type_phone » décrivent la largeur de CHAQUE bloc de "
                "la ligne, en douzièmes, séparés par des tirets. Le nombre de "
                "segments doit égaler le nombre de blocs : « 4-4-4 » pour trois "
                "blocs côte à côte, « 12-12-12 » pour les mêmes empilés. "
                "Écrire « 12 » sur une ligne de trois blocs n'en sert qu'un : "
                "les deux autres sont écrasés, sans erreur."
            ),
            "rang": "Position verticale d'un bloc dans sa colonne, à partir de 0.",
        },
        "gabarits_de_section": {
            nom: "largeurs : " + ", ".join(
                f"{appareil} {largeur}"
                for appareil, largeur in gabarit["tailles"].items()
            )
            for nom, gabarit in fabrique.GABARITS_SECTION.items()
        },
        "parametres": _document_de_parametres(),
        "contenus": {
            "modifiables_par_l_api": list(TYPES_OUVERTS),
            "tous_ouverts": True,
            "note": (
                "Les vingt-quatre types sont ouverts. Les blocs dynamiques "
                "— FAQ, onglets, carrousel, tarifs, témoignages, galerie… — "
                "partagent une même forme : des « options » (un objet libre) "
                "et une liste « elements ». Envoyer « elements » REMPLACE la "
                "liste entière : une liste ordonnée n'a pas de clé stable sur "
                "laquelle fusionner, et rapprocher par position mettrait une "
                "réponse sous la mauvaise question. Omettre « elements » ne "
                "touche qu'aux options."
            ),
            "formes": {
                "TEXT": {"type": "TEXT", "texte": "<p>du HTML</p>"},
                "BUTTON": {
                    "type": "BUTTON",
                    "bouton": {
                        "libelle": "Nous contacter",
                        "page_id": 7,
                        "_ou_bien": "url_externe / questionnaire / ajouter_au_panier",
                        "nouvel_onglet": False,
                        "produit_cible": "JEIKO-EQUIPE",
                        "style": {"fond": "rgb(180,83,9)", "couleur_texte": "#fff",
                                  "rayon": "9px", "padding": "14px 28px"},
                    },
                    "_note": ("Le bouton n'a PAS de champ « url » : sa destination "
                              "dépend de sa nature. Écrire « url » ne fait rien. "
                              "Pour « ajouter_au_panier », renseigner "
                              "« produit_cible » (la référence du produit) — "
                              "SAUF sur une page modèle, où le produit se "
                              "déduit de la fiche affichée. Sans cible et hors "
                              "page modèle, le bouton s'affiche et ne fait rien."),
                },
                "FORM": {
                    "type": "FORM",
                    "formulaire": {
                        "nom": "Contact",
                        "destinataire": "contact@exemple.fr",
                        "sujet": "Nouveau message",
                        "message_de_succes": "Merci, nous vous répondons vite.",
                        "champs": [
                            {"nom": "email", "libelle": "Votre e-mail",
                             "type": "email", "obligatoire": True},
                            {"nom": "message", "libelle": "Votre message",
                             "type": "textarea", "obligatoire": True},
                        ],
                    },
                    "style": {
                        "couleur_du_bouton": "#b45309",
                        "couleur_du_bouton_survol": "#92400e",
                        "couleur_du_texte_du_bouton": "#ffffff",
                        "rayon_du_bouton": 8,
                    },
                    "_style": ("Les couleurs sont HEXADÉCIMALES : « var(--jk-accent) » "
                               "est refusé, il faut la valeur. Sans style, le bouton "
                               "garde le bleu par défaut, qui jure sur un site aux "
                               "couleurs de la maison."),
                    "_note": ("Envoyer « champs » REMPLACE la liste entière : un "
                              "formulaire est un tout, et fusionner par position "
                              "mélangerait les libellés. Omettre « champs » laisse "
                              "les existants intacts."),
                },
                "IMAGE": {"type": "IMAGE",
                          "note": "Crée le réceptacle ; le fichier se dépose depuis l'administration."},
            },
        },
        "catalogue_des_blocs": _catalogue_des_blocs(),
        "champs_de_page": {
            "modifiables": sorted(
                list(CHAMPS_PAGE_MODIFIABLES)
                + list(CHAMPS_PAGE_CATEGORIES)
                + ["metadonnees"]
            ),
            "fermes": {
                "protegee": (
                    "Se lit, ne s'écrit pas : c'est un contrôle d'ACCÈS, pas "
                    "de contenu. Retirer la protection d'une page réservée, ou "
                    "en protéger une par erreur, sont des décisions "
                    "d'exploitant."
                ),
            },
            "a_savoir": {
                "metadonnees": (
                    "« titre » (~60 caractères) et « description » "
                    "(~155 caractères) : c'est ce que Google affiche, et ce "
                    "que montrent les partages. Facultatives en base, elles "
                    "devraient être écrites À LA CRÉATION — une page publiée "
                    "sans elles part avec un handicap que personne ne revient "
                    "corriger. Laissées vides, le titre de la page sert de "
                    "repli, et la description n'existe pas."
                ),
                "racine": (
                    "Une seule page racine par site : la déclarer DÉPLACE la "
                    "page d'accueil, l'ancienne perd le drapeau. Ce n'est pas "
                    "destructeur, mais ce n'est pas anodin."
                ),
                "categorie": (
                    "Par slug, par identifiant ou par nom exact — certaines "
                    "catégories ne servent qu'au regroupement et n'ont pas de "
                    "slug. La sous-catégorie doit appartenir à la catégorie "
                    "annoncée. Voir /categories/."
                ),
                "publiee": (
                    "Une page créée par un agent naît en BROUILLON. La mise "
                    "en ligne est un appel séparé et explicite."
                ),
            },
        },
        "interdits": [
            "Supprimer une page — aucune route, aucune permission.",
            "Publier une page à sa création — elle naît en brouillon.",
            "Téléverser un fichier — la médiathèque passe par l'administration.",
            "Supprimer une fiche ou un produit — un agent crée et corrige, il n'efface pas.",
            "Publier une fiche ou activer un produit à la création — les deux naissent inactifs.",
            "Poser un « style » qui positionne, anime ou charge une ressource — "
            "seules color, background-color, text-align, font-weight, font-style "
            "et text-decoration traversent l'assainissement.",
            "Écrire une clé que l'API ne connaît pas — elle lève, elle n'ignore "
            "jamais. Le message nomme les clés acceptées.",
            "Poser un <svg>, un <iframe>, un <style> ou un <script> — retirés "
            "à l'écriture, avec leur contenu. La réponse le dit dans "
            "« avertissements ». Pour dessiner : css.custom.",
            "Donner une répartition de colonnes qui ne décrit pas toutes les "
            "colonnes de la ligne.",
        ],
    }
