from django import forms
from django.forms import inlineformset_factory
from .models import (
    ExpertTest, ExpertQuestion, ExpertAnswer,
    ExpertAnswerProfileWeight, ExpertProfileType,
    ExpertProfileCombination, Prospect,
    ExpertTestStyle, DEFAULT_TEST_STYLE, validate_test_style,
    ExpertDimensionBand,
)
from django.utils.translation import gettext_lazy as _

from jeiko.questionnaires_expert import coordonnees


class ProspectForm(forms.ModelForm):
    """
    Coordonnées saisies en fin de questionnaire par un visiteur non connecté.

    Remplace la lecture directe de request.POST : sans validation, un POST sans
    `firstname` provoquait une IntegrityError, et rien ne garantissait la
    validité de l'email.
    """

    consent = forms.BooleanField(
        required=True,
        label=(
            _("J'accepte que mes réponses et mes coordonnées soient enregistrées "
            "afin de me transmettre mon résultat.")
        ),
        error_messages={
            "required": _("Votre accord est nécessaire pour enregistrer votre résultat.")
        },
    )
    # Case distincte et facultative : le RGPD interdit de déduire l'accord
    # commercial de l'accord de traitement.
    marketing_optin = forms.BooleanField(
        required=False,
        label=_("J'accepte de recevoir des informations et offres par email."),
    )
    # Encore distincte : l'autorisation d'être recontacté au sujet des résultats
    # n'est ni le traitement (case `consent`, obligatoire) ni la prospection
    # commerciale (case `marketing_optin`). Facultative, décochée par défaut.
    contact_optin = forms.BooleanField(
        required=False,
        label=_("J'autorise à être recontacté(e) au sujet de mes résultats."),
    )

    class Meta:
        model = Prospect
        fields = ["firstname", "lastname", "email", "phone"]

    def __init__(self, *args, test=None, **kwargs):
        super().__init__(*args, **kwargs)
        # Le modèle les rend facultatifs — une fiche du CRM peut naître d'une
        # réservation ou d'un appel —, mais le questionnaire les exige : ils
        # décident du rattachement à une fiche existante (`resolve_prospect`).
        for exige in ("firstname", "lastname", "email"):
            self.fields[exige].required = True
        # Téléphone, société, fonction : selon le réglage du questionnaire
        # (`coordonnees.py`). Les deux derniers ne sont pas des champs du
        # formulaire de modèle : `company` est le nom du champ leurre.
        for cle, (champ, libelle, longueur) in coordonnees.CATALOGUE.items():
            nom = "phone" if cle == "telephone" else cle
            etat = coordonnees.etat(test, cle)
            if etat == coordonnees.ABSENT:
                self.fields.pop(nom, None)
                continue
            if nom not in self.fields:
                self.fields[nom] = forms.CharField(label=libelle, max_length=longueur)
            self.fields[nom].required = etat == coordonnees.OBLIGATOIRE
        # Les cases d'accord restent APRÈS les coordonnées.
        for case in ("consent", "marketing_optin", "contact_optin"):
            self.fields[case] = self.fields.pop(case)
        for name, field in self.fields.items():
            if isinstance(field.widget, (forms.TextInput, forms.EmailInput)):
                field.widget.attrs.setdefault("class", "prospect-input")
                field.widget.attrs.setdefault("placeholder", field.label)

    def clean_email(self):
        return (self.cleaned_data.get("email") or "").strip().lower()

    def clean_phone(self):
        return (self.cleaned_data.get("phone") or "").strip()

    def coordonnees_saisies(self):
        """{champ de la fiche contact: valeur} pour les seuls champs demandés."""
        return {champ: (self.cleaned_data.get("phone" if cle == "telephone" else cle) or "").strip()
                for cle, (champ, _l, _n) in coordonnees.CATALOGUE.items()
                if ("phone" if cle == "telephone" else cle) in self.fields}


class DynamicExpertTestForm(forms.Form):
    def __init__(self, test, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for question in test.questions.all():
            choices = [(a.id, a.text) for a in question.answers.all()]

            # On vérifie le type de la question
            is_multiple = question.question_type == 'multiple'

            field_class = forms.MultipleChoiceField if is_multiple else forms.ChoiceField
            widget = forms.CheckboxSelectMultiple() if is_multiple else forms.RadioSelect()

            # Style dynamique éventuel
            if hasattr(question, "style") and question.style:
                widget.attrs.update(question.style)

            self.fields[f"question_{question.id}"] = field_class(
                label=question.text,
                choices=choices,
                widget=widget,
                required=False  # Pour éviter les erreurs si la réponse est laissée vide
            )


class ExpertProfileTypeForm(forms.ModelForm):
    class Meta:
        model = ExpertProfileType
        fields = [
            "name", "description", "result_page", "is_complex",
            "parent_profiles",  # ManyToMany
            "is_score_profile", "min_score", "max_score", "score_axis",
            "color",
        ]
        widgets = {
            "parent_profiles": forms.CheckboxSelectMultiple,
            "description": forms.Textarea(attrs={"rows": 2}),
            "color": forms.TextInput(attrs={"type": "color"}),
        }

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("is_score_profile"):
            min_score = cleaned.get("min_score")
            max_score = cleaned.get("max_score")
            if min_score is None or max_score is None:
                raise forms.ValidationError(
                    _("Pour un profil par score direct, vous devez définir min_score et max_score."))
            if min_score >= max_score:
                raise forms.ValidationError(_("min_score doit être inférieur à max_score."))
        return cleaned

    def __init__(self, *args, **kwargs):
        test = kwargs.pop('test', None)
        super().__init__(*args, **kwargs)
        if test:
            self.fields["parent_profiles"].queryset = ExpertProfileType.objects.filter(test=test)
        # NB: `score_axis` est un champ texte libre, non exploité par le moteur
        # de scoring. Lui affecter un `queryset` n'avait aucun effet.


class ExpertAnswerForm(forms.ModelForm):
    class Meta:
        model = ExpertAnswer
        fields = ["text"]


class ExpertAnswerProfileWeightForm(forms.ModelForm):
    class Meta:
        model = ExpertAnswerProfileWeight
        fields = ["profile_type", "weight"]

    def __init__(self, *args, **kwargs):
        answer = kwargs.pop("answer", None)
        super().__init__(*args, **kwargs)
        if answer:
            test = answer.question.test
            self.fields["profile_type"].queryset = ExpertProfileType.objects.filter(test=test)


AnswerProfileWeightFormSet = inlineformset_factory(
    parent_model=ExpertAnswer,
    model=ExpertAnswerProfileWeight,
    form=ExpertAnswerProfileWeightForm,
    extra=1,
    can_delete=True
)


class ExpertProfileCombinationForm(forms.ModelForm):
    class Meta:
        model = ExpertProfileCombination
        fields = ["title", "parent_profile", "preferred_profile", "alternative_profile"]

    def __init__(self, *args, **kwargs):
        test = kwargs.pop("test", None)
        super().__init__(*args, **kwargs)
        if test:
            queryset = ExpertProfileType.objects.filter(test=test)
            self.fields["parent_profile"].queryset = queryset
            self.fields["preferred_profile"].queryset = queryset
            self.fields["alternative_profile"].queryset = queryset




class ExpertTestStyleForm(forms.ModelForm):
    # on mappe des champs explicites aux clés du JSON
    font_family = forms.CharField(label=_("Police"), required=False)

    title_color = forms.CharField(label=_("Couleur du titre"), widget=forms.TextInput(attrs={"type": "color"}))
    title_size_mobile_px = forms.IntegerField(label=_("Taille titre · Mobile (px)"), min_value=12, max_value=64)
    title_size_tablet_px = forms.IntegerField(label=_("Taille titre · Tablette (px)"), min_value=12, max_value=64)
    title_size_desktop_px = forms.IntegerField(label=_("Taille titre · Ordinateur (px)"), min_value=12, max_value=64)

    input_font_size_mobile_px = forms.IntegerField(label=_("Taille réponses · Mobile (px)"), min_value=12, max_value=40)
    input_font_size_tablet_px = forms.IntegerField(label=_("Taille réponses · Tablette (px)"), min_value=12, max_value=40)
    input_font_size_desktop_px = forms.IntegerField(label=_("Taille réponses · Ordinateur (px)"), min_value=12, max_value=40)

    submit_font_size_px = forms.IntegerField(label=_("Taille du bouton (px)"), min_value=12, max_value=40)

    theme_color = forms.CharField(label=_("Couleur du thème"), widget=forms.TextInput(attrs={"type": "color"}))
    body_bg = forms.CharField(label=_("Couleur de fond (body)"), widget=forms.TextInput(attrs={"type": "color"}))

    answer_radius_px = forms.IntegerField(label=_("Arrondi des réponses (px)"), min_value=0, max_value=40, required=False)
    submit_radius_px = forms.IntegerField(label=_("Arrondi du bouton (px)"), min_value=0, max_value=40, required=False)

    class Meta:
        model = ExpertTestStyle
        fields = ["style"]  # on persiste dans style JSON, pas ces champs "virtuels"
        widgets = {"style": forms.HiddenInput()}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # `style` est entièrement reconstruit dans clean() à partir des champs
        # visibles : l'exiger dans le POST ferait échouer le formulaire sur une
        # valeur qu'on s'apprête de toute façon à remplacer.
        self.fields["style"].required = False

        st = {**DEFAULT_TEST_STYLE, **(self.instance.style or {})}

        for k, v in st.items():
            if k in self.fields:
                self.fields[k].initial = v

    def clean(self):
        cleaned = super().clean()
        # Le JSON est reconstruit à partir des champs « virtuels ». Toute clé du
        # schéma absente d'ici serait effacée à chaque enregistrement : on part
        # donc de DEFAULT_TEST_STYLE plutôt que d'une liste tenue à la main.
        style = {}
        for key in DEFAULT_TEST_STYLE:
            value = self.cleaned_data.get(key)
            if value in (None, ""):
                # Champ absent du formulaire ou laissé vide : on conserve la
                # valeur déjà enregistrée, à défaut le défaut du schéma.
                value = (self.instance.style or {}).get(key, DEFAULT_TEST_STYLE[key])
            style[key] = value

        # validation centralisée
        validate_test_style(style)

        cleaned["style"] = style
        return cleaned

# --------------------------------------------------------------------------- #
#  Résultat « par dimensions » — un seul écran, trois familles de formulaires
# --------------------------------------------------------------------------- #
class DimensionsSettingsForm(forms.ModelForm):
    """Les réglages du questionnaire propres au résultat par dimensions."""

    class Meta:
        model = ExpertTest
        fields = [
            "result_mode", "dimension_scale_min", "dimension_scale_max",
            "nuanced_text", "closing_text", "cta_label", "cta_page",
        ]
        widgets = {
            "nuanced_text": forms.Textarea(attrs={"rows": 4}),
            "closing_text": forms.Textarea(attrs={"rows": 3}),
        }

    def clean(self):
        cleaned = super().clean()
        mini, maxi = cleaned.get("dimension_scale_min"), cleaned.get("dimension_scale_max")
        if mini is not None and maxi is not None and mini >= maxi:
            raise forms.ValidationError(_("Le score minimal doit être inférieur au score maximal."))
        return cleaned


class DimensionProfileForm(forms.ModelForm):
    """Le rang et les deux pôles d'une dimension."""

    class Meta:
        model = ExpertProfileType
        fields = ["order", "low_pole_label", "high_pole_label"]


class DimensionBandForm(forms.ModelForm):
    """
    Une tranche. Laissée entièrement vide, elle n'existe pas — c'est ce qui
    permet de n'afficher que trois blocs fixes sans rien imposer.
    """

    CHAMPS_DE_CONTENU = ("title", "text", "strengths", "watch_point", "reflection")

    class Meta:
        model = ExpertDimensionBand
        fields = [
            "min_score", "max_score", "title", "text",
            "strengths", "watch_point", "reflection",
        ]
        widgets = {
            "text": forms.Textarea(attrs={"rows": 5}),
            "strengths": forms.Textarea(attrs={"rows": 3}),
            "watch_point": forms.Textarea(attrs={"rows": 2}),
            "reflection": forms.Textarea(attrs={"rows": 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Obligatoires seulement si la tranche a un contenu : voir clean().
        self.fields["min_score"].required = False
        self.fields["max_score"].required = False

    def est_vide(self):
        donnees = getattr(self, "cleaned_data", {}) or {}
        return (
            donnees.get("min_score") is None
            and donnees.get("max_score") is None
            and not any((donnees.get(c) or "").strip() for c in self.CHAMPS_DE_CONTENU)
        )

    def clean(self):
        cleaned = super().clean()
        if self.est_vide():
            return cleaned
        mini, maxi = cleaned.get("min_score"), cleaned.get("max_score")
        if mini is None:
            self.add_error("min_score", _("Indiquez où commence la tranche."))
        if maxi is None:
            self.add_error("max_score", _("Indiquez où finit la tranche."))
        if mini is not None and maxi is not None and mini > maxi:
            self.add_error("max_score", _("La fin de la tranche doit être après son début."))
        return cleaned

    def _post_clean(self):
        # Une tranche vide ne sera pas enregistrée : inutile de valider le
        # modèle (ses bornes sont NOT NULL et lèveraient une erreur).
        if not self.est_vide():
            super()._post_clean()


class ExpertTestForm(forms.ModelForm):
    """
    Les réglages d'un questionnaire, et ce que sa fin demande au visiteur :
    téléphone, société, fonction — chacun non demandé, facultatif ou
    obligatoire (`coordonnees.py`). Trois listes plutôt qu'un champ JSON :
    c'est un écran pour l'exploitant.
    """

    class Meta:
        model = ExpertTest
        fields = [
            "title", "slug", "description", "intro_warning", "is_active", "is_restricted",
            "main_image", "presentation_page",
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for cle, (_champ, libelle, _n) in coordonnees.CATALOGUE.items():
            self.fields[f"demander_{cle}"] = forms.ChoiceField(
                label=_("En fin de questionnaire : %(champ)s") % {"champ": libelle},
                choices=coordonnees.CHOIX_ETATS,
                initial=coordonnees.etat(self.instance, cle),
            )

    def save(self, commit=True):
        self.instance.champs_demandes = {
            cle: self.cleaned_data[f"demander_{cle}"] for cle in coordonnees.CATALOGUE
        }
        return super().save(commit)


class ExpertTestEditForm(ExpertTestForm):
    # `slug` est volontairement absent : il est figé après création, sinon les
    # liens déjà diffusés (emails, pages, produits) cessent de fonctionner.
    class Meta(ExpertTestForm.Meta):
        fields = [f for f in ExpertTestForm.Meta.fields if f != "slug"]
