# jeiko/agents/contenus_dynamiques.py
"""
Les blocs dynamiques — FAQ, onglets, carrousel, tarifs… — en un seul mécanisme.

Ce qu'ils ont tous en commun
----------------------------
Un bloc dynamique, c'est **une liste ordonnée d'éléments** rattachés au
`Content`, plus des options rangées dans `Content.data`. Une FAQ a des
questions, un carrousel a des diapositives, une table de prix a des offres :
même forme, noms différents.

Les ouvrir un par un aurait produit vingt fonctions se ressemblant à 90 %, et
la vingt-et-unième aurait divergé. On décrit donc chaque type en **données** —
son modèle d'élément, ses champs, son vocabulaire français — et un seul couple
lire/écrire les sert tous.

La règle d'écriture, la même partout
------------------------------------
Envoyer « elements » **remplace** la liste entière. C'est le choix fait pour le
formulaire, et pour la même raison : une liste ordonnée n'a pas de clé stable
sur laquelle fusionner. Rapprocher deux listes par position mélangerait les
contenus — une réponse sous la mauvaise question — sans rien signaler.

Ne pas envoyer « elements » laisse les existants intacts : on peut donc changer
les seules options.

Ce que ce module ne fait pas
----------------------------
Il ne valide pas la cohérence métier d'un bloc : une table de prix sans offre
est acceptée, un carrousel sans image aussi. Ce sont des états transitoires
légitimes quand on construit une page en plusieurs appels.
"""

import re

from django.db import transaction
from jeiko.liens import url_sure

from jeiko.administration_pages import models as M
from jeiko.administration_pages.utils import _snapshot_for_content


class ElementInvalide(Exception):
    """Le document d'un bloc dynamique n'est pas exploitable."""


#: Description d'un type dynamique :
#:   (modèle de l'élément, related_name sur Content, {clé API: champ modèle})
#:
#: Le vocabulaire est en français côté API, comme partout ailleurs : c'est
#: l'exploitant qui lira ces documents quand une page n'aura pas l'air de ce
#: qu'il attendait.
TYPES = {
    "DYN_FAQ": (M.DynFAQItem, "faq_items", {
        "question": "title", "reponse": "answer", "ouvert": "open",
    }),
    "DYN_TABS": (M.DynTabItem, "tab_items", {
        "libelle": "label", "contenu": "body",
    }),
    "DYN_CAROUSEL": (M.DynCarouselSlide, "carousel_slides", {
        "image_id": "image", "source_externe": "external_src", "alt": "alt",
        "legende": "caption", "lien": "href", "nouvel_onglet": "open_in_new_tab",
        "cadrage": "object_position",
    }),
    "DYN_PROGRESS": (M.DynProgressStep, "progress_steps", {
        "libelle": "label", "fait": "done",
    }),
    "DYN_TESTIMONIALS": (M.DynTestimonialItem, "testimonial_items", {
        "citation": "quote", "auteur": "author", "role": "role", "avatar_id": "avatar",
    }),
    "DYN_TESTIMONIALS_GRID": (M.DynTestimonialItem, "testimonial_items", {
        "citation": "quote", "auteur": "author", "role": "role", "avatar_id": "avatar",
    }),
    "DYN_FILTER": (M.DynLiveFilterItem, "livefilter_items", {
        "titre": "title", "categorie": "category", "description": "description",
    }),
    "DYN_ACCORDION_ADV": (M.DynAccordionSection, "accordion_sections", {
        "titre": "title", "ouvert": "open",
    }),
    "DYN_PRICING_TABLE": (M.DynPricingPlan, "pricing_plans", {
        "nom": "name", "prix_mensuel": "price_monthly", "prix_annuel": "price_yearly",
        "mis_en_avant": "popular", "libelle_bouton": "cta_label", "lien_bouton": "cta_href",
    }),
    "DYN_GALLERY_FILTER": (M.DynGalleryItem, "gallery_items", {
        "image_id": "image", "categorie": "category", "titre": "title",
    }),
    "DYN_STEPPER": (M.DynStepperStep, "stepper_steps", {
        "titre": "title", "contenu": "body",
    }),
}

#: Les listes DANS un élément : les entrées d'une section d'accordéon, les
#: lignes d'une offre de tarifs. Sans elles, un agent produisait un accordéon
#: aux panneaux vides et des offres sans contenu — l'éditeur seul savait les
#: remplir. (type → clé d'API, modèle, lien vers le parent, related_name,
#: {clé: champ} — ou None pour une simple liste de textes.)
SOUS_LISTES = {
    "DYN_ACCORDION_ADV": ("entrees", M.DynAccordionChild, "section", "children",
                          {"titre": "title", "contenu": "body", "ouvert": "open"}),
    "DYN_PRICING_TABLE": ("fonctionnalites", M.DynPricingFeature, "plan", "features", None),
}


def cles_d_element(type_contenu):
    """Les clés admises dans un élément de ce type, sous-liste comprise."""
    cles = set(TYPES[type_contenu][2])
    if type_contenu in SOUS_LISTES:
        cles.add(SOUS_LISTES[type_contenu][0])
    return cles


def _preparer_la_sous_liste(type_contenu, rang, brut):
    """La sous-liste d'un élément, validée ; [] si absente."""
    cle, _modele, _lien, _related, champs = SOUS_LISTES[type_contenu]
    if brut is None:
        return []
    if not isinstance(brut, list):
        raise ElementInvalide(f"Élément nº {rang + 1} : « {cle} » doit être une liste.")
    prepares = []
    for i, entree in enumerate(brut):
        if champs is None:
            if not isinstance(entree, str) or not entree.strip():
                raise ElementInvalide(f"Élément nº {rang + 1}, « {cle} » nº {i + 1} : un texte non vide est attendu.")
            prepares.append({"label": entree.strip()[:200], "order": i})
            continue
        if not isinstance(entree, dict):
            raise ElementInvalide(f"Élément nº {rang + 1}, « {cle} » nº {i + 1} : un objet est attendu.")
        inconnues = sorted(set(entree) - set(champs))
        if inconnues:
            raise ElementInvalide(
                f"Élément nº {rang + 1}, « {cle} » nº {i + 1} — clé(s) inconnue(s) : "
                f"{', '.join(inconnues)}. Acceptées : {', '.join(sorted(champs))}.")
        prepares.append({**{champs[k]: v for k, v in entree.items()}, "order": i})
    return prepares


#: Types dynamiques SANS liste d'éléments : tout tient dans les options.
TYPES_SANS_ELEMENTS = ("DYN_COUNTDOWN", "DYN_COUNTDOWN_CTA", "DYN_RATING")

#: Les champs qui désignent une image : leur valeur d'API est un identifiant.
CHAMPS_IMAGE = {"image", "avatar"}



#: Les champs d'élément qui finissent dans un `href` ou un `src`, et leur usage.
CHAMPS_URL = {"href": "lien", "cta_href": "lien", "external_src": "media"}

#: Une position CSS d'image (`object-position`) : deux valeurs au plus.
_UNE_POSITION = r"(?:\d{1,3}(?:\.\d+)?%|left|center|right|top|bottom)"
POSITION_CSS = re.compile(rf"{_UNE_POSITION}(?:\s+{_UNE_POSITION})?")

def est_dynamique(type_contenu):
    return type_contenu in TYPES or type_contenu in TYPES_SANS_ELEMENTS


def _elements_de(content, type_contenu):
    _, lien, _ = TYPES[type_contenu]
    return getattr(content, lien).all().order_by("order", "id")


def lire(content):
    """Les options et les éléments d'un bloc dynamique."""
    donnees = {"options": content.data or {}}

    if content.content_type in TYPES_SANS_ELEMENTS:
        return donnees

    _, _, correspondances = TYPES[content.content_type]
    donnees["elements"] = []
    for element in _elements_de(content, content.content_type):
        rendu = {}
        for cle, champ in correspondances.items():
            valeur = getattr(element, champ)
            if champ in CHAMPS_IMAGE:
                valeur = getattr(element, f"{champ}_id")
            rendu[cle] = valeur
        if content.content_type in SOUS_LISTES:
            cle, _modele, _parent, related, champs = SOUS_LISTES[content.content_type]
            filles = getattr(element, related).order_by("order", "id")
            rendu[cle] = ([f.label for f in filles] if champs is None else
                          [{k: getattr(f, champ) for k, champ in champs.items()} for f in filles])
        donnees["elements"].append(rendu)
    return donnees



#: Options qu'ajoute l'éditeur humain en plus de DYNAMIC_DEFAULTS.
OPTIONS_EDITEUR = {
    "DYN_FAQ": {"title_tag": "h4", "main_title": "", "main_title_tag": "h3"},
    "DYN_CAROUSEL": {"hide_label": True, "fit": "cover"},
    "DYN_PROGRESS": {"progress": 0.0},
}

#: Options à valeur fermée. `fit` finit dans un attribut `style`
#: (`object-fit:` + valeur) : un texte libre y ouvrirait une injection de
#: déclarations. « contain » montre l'image entière — un logo, un schéma ;
#: « cover » remplit le cadre en rognant — une photo.
CLES_CHOIX = {"fit": {"cover", "contain"}}

#: Ce que `data` porte pour JEIKO lui-même, pas une option : la marque des
#: nouveaux défauts (BLOCS-01). Relue dans un GET, elle peut revenir dans un
#: PUT : on l'ignore, et le bloc garde la sienne.
CLES_INTERNES = {"apparence"}

#: La clé de projection de chaque type : recalculée depuis les éléments,
#: jamais écrite par les options (un GET renvoyé tel quel la contient).
CLES_DE_PROJECTION = {"items", "plans", "sections"}

#: Options qui deviennent un NOM DE BALISE (`<{{ tag }}>`) — Fable 1 §5.1.
CLES_BALISE = {"title_tag", "main_title_tag"}
BALISES_DE_TITRE = {f"h{n}" for n in range(1, 7)}

#: Options qui finissent dans un `href`.
CLES_LIEN = {"ctaHref"}


def valider_les_options(type_contenu, options):
    """
    Liste blanche des options d'un bloc dynamique (rapport Fable 1, §5.1).

    `options` était écrit tel quel dans `Content.data`. Le gabarit FAQ insère
    `main_title_tag|safe` comme NOM de balise : `"script>alert(1)</script><h3"`
    exécutait un script chez chaque visiteur. L'éditeur humain le validait,
    l'API non. Désormais : clés documentées seulement (DYNAMIC_DEFAULTS et
    l'éditeur), valeur du même type que la valeur par défaut, balises de titre
    h1 à h6, liens passés au contrôle unique des URL.
    """
    from jeiko.administration_pages.models import DYNAMIC_DEFAULTS

    defauts = {**DYNAMIC_DEFAULTS.get(type_contenu, {}), **OPTIONS_EDITEUR.get(type_contenu, {})}
    connues = set(defauts) - CLES_DE_PROJECTION
    inconnues = sorted(set(options) - connues - CLES_DE_PROJECTION - CLES_INTERNES)
    if inconnues:
        raise ElementInvalide(
            f"Option(s) inconnue(s) pour {type_contenu} : {', '.join(inconnues)}. "
            f"Acceptées : {', '.join(sorted(connues)) or 'aucune'}."
        )
    propres = {}
    for cle, valeur in options.items():
        if cle in CLES_DE_PROJECTION or cle in CLES_INTERNES:
            continue  # recalculée depuis les éléments, ou propre à JEIKO
        attendu = defauts[cle]
        if cle in CLES_BALISE:
            valeur = str(valeur or "").strip().lower()
            if valeur not in BALISES_DE_TITRE:
                raise ElementInvalide(f"« {cle} » vaut h1 à h6 — reçu {options[cle]!r}.")
        elif cle in CLES_CHOIX:
            if valeur not in CLES_CHOIX[cle]:
                raise ElementInvalide(
                    f"« {cle} » vaut {' ou '.join(sorted(CLES_CHOIX[cle]))} — reçu {options[cle]!r}."
                )
        elif cle in CLES_LIEN:
            try:
                valeur = url_sure(valeur, "lien", cle)
            except ValueError as souci:
                raise ElementInvalide(str(souci))
        elif isinstance(attendu, bool):
            if not isinstance(valeur, bool):
                raise ElementInvalide(f"« {cle} » attend true ou false — reçu {valeur!r}.")
        elif isinstance(attendu, int):
            if isinstance(valeur, bool) or not isinstance(valeur, int):
                raise ElementInvalide(f"« {cle} » attend un nombre entier — reçu {valeur!r}.")
        elif isinstance(attendu, float) or attendu is None:
            if valeur is not None and (isinstance(valeur, bool) or not isinstance(valeur, (int, float))):
                raise ElementInvalide(f"« {cle} » attend un nombre — reçu {valeur!r}.")
        elif isinstance(attendu, list):
            if not isinstance(valeur, list) or not all(isinstance(v, (str, int, float)) for v in valeur):
                raise ElementInvalide(f"« {cle} » attend une liste de valeurs simples.")
        elif isinstance(attendu, str):
            if not isinstance(valeur, (str, int, float)) or isinstance(valeur, bool):
                raise ElementInvalide(f"« {cle} » attend un texte — reçu {valeur!r}.")
            valeur = str(valeur)[:500]
        propres[cle] = valeur
    return propres

@transaction.atomic
def appliquer(content, donnees):
    """
    Écrit les options, et remplace la liste d'éléments si elle est fournie.

    Renvoie la liste de ce qui a changé.
    """
    if not isinstance(donnees, dict):
        raise ElementInvalide("Le contenu dynamique doit être un objet.")

    touches = []

    options = donnees.get("options")
    if options is not None:
        if not isinstance(options, dict):
            raise ElementInvalide("« options » doit être un objet.")
        options = valider_les_options(content.content_type, options)
        for cle in CLES_INTERNES & set(content.data or {}):
            options[cle] = content.data[cle]  # la marque du bloc ne se réécrit pas
        content.data = options
        content.save(update_fields=["data"])
        touches.append("options")

    if content.content_type in TYPES_SANS_ELEMENTS:
        if "elements" in donnees:
            raise ElementInvalide(
                f"« {content.content_type} » n'a pas d'éléments : tout se règle "
                f"dans « options »."
            )
        return touches

    if "elements" not in donnees:
        if options is not None:
            _projeter(content)  # les options viennent d'écraser la projection
        return touches

    elements = donnees["elements"]
    if not isinstance(elements, list):
        raise ElementInvalide("« elements » doit être une liste.")

    modele, lien, correspondances = TYPES[content.content_type]

    # On valide TOUT avant d'effacer quoi que ce soit : une liste à moitié
    # écrite parce que le troisième élément était mal formé serait pire que
    # le refus complet.
    prepares = []
    for rang, brut in enumerate(elements):
        if not isinstance(brut, dict):
            raise ElementInvalide(f"Élément nº {rang + 1} : un objet est attendu.")
        admises = cles_d_element(content.content_type)
        inconnus = sorted(set(brut) - admises)
        if inconnus:
            raise ElementInvalide(
                f"Élément nº {rang + 1} — clé(s) inconnue(s) : {', '.join(inconnus)}. "
                f"Acceptées pour {content.content_type} : "
                f"{', '.join(sorted(admises))}."
            )
        valeurs = {"content": content, "order": rang}
        sous_liste = []
        if content.content_type in SOUS_LISTES:
            brut = dict(brut)
            sous_liste = _preparer_la_sous_liste(
                content.content_type, rang, brut.pop(SOUS_LISTES[content.content_type][0], None))
        for cle, valeur in brut.items():
            champ = correspondances[cle]
            if champ in CHAMPS_IMAGE:
                if valeur in (None, "", 0):
                    valeurs[champ] = None
                else:
                    image = M.ImageContent.objects.filter(pk=valeur).first()
                    if image is None:
                        raise ElementInvalide(
                            f"Élément nº {rang + 1} : aucune image nº {valeur} "
                            f"dans la médiathèque. Voir /images/."
                        )
                    valeurs[champ] = image
            elif champ == "object_position":
                # Posé dans un attribut `style` : borné à une position CSS.
                texte = str(valeur or "").strip().lower()
                if texte and not POSITION_CSS.fullmatch(texte):
                    raise ElementInvalide(
                        f"Élément nº {rang + 1} : « cadrage » s'écrit comme "
                        f"« 50% 50% » ou « center top »."
                    )
                valeurs[champ] = texte or "50% 50%"
            elif champ in CHAMPS_URL:
                # Fable 2 §1.1 : `:href` Alpine pose l'attribut sans filtrer
                # le schéma. Contrôle partagé, voir jeiko/liens.py.
                try:
                    valeurs[champ] = url_sure(valeur, CHAMPS_URL[champ], cle)
                except ValueError as souci:
                    raise ElementInvalide(f"Élément nº {rang + 1} : {souci}")
            else:
                valeurs[champ] = valeur
        prepares.append((valeurs, sous_liste))

    getattr(content, lien).all().delete()
    for valeurs, sous_liste in prepares:
        parent = modele.objects.create(**valeurs)
        if content.content_type in SOUS_LISTES:
            _cle, modele_fille, champ_parent, _related, _champs = SOUS_LISTES[content.content_type]
            for fille in sous_liste:
                modele_fille.objects.create(**{champ_parent: parent}, **fille)

    touches.append("elements")
    _projeter(content)
    return touches


def _projeter(content):
    """
    Recopie les éléments dans `Content.data`, d'où le navigateur les lit.

    Ce n'est PAS un cache dont on pourrait se passer. Treize des quatorze
    gabarits `content/dyn/*.html` sérialisent `content.data` dans un
    `<script type="application/json">` et le donnent à Alpine : les lignes
    filles (`DynFAQItem`, `DynPricingPlan`…) ne sont jamais lues au rendu.
    Écrire les filles sans reprojeter produit donc un bloc **structurellement
    correct et visuellement vide** — c'est exactement ce qui est arrivé à la
    table de prix créée par l'API : trois offres en base, aucune à l'écran.

    Le formulaire de l'éditeur fait la même chose, à la même place
    (`administration_pages/views.py`, après chaque `formset.save()`). On
    appelle sa fonction plutôt que d'en écrire une seconde : deux projections
    parallèles divergeraient au premier champ ajouté.

    Cas particulier des options : les écrire remplace `data` en entier, donc
    efface la projection précédente. La reprojection systématique ici la
    rétablit — c'est pourquoi elle n'est pas conditionnée à l'envoi
    d'« elements ».
    """
    content.data = _snapshot_for_content(content)
    content.save(update_fields=["data"])
