"""
La mise en route d'un site (D-01, 11/10/2026).

Ce qu'il faut régler pour qu'un site neuf tienne debout, dans l'ordre où on
le fait, avec pour chaque étape : faite ou non, pourquoi elle compte, et
l'écran qui la règle. Un écran à part (Réglages ▸ Mise en route), qu'on
rouvre quand on veut, et sa progression sur l'accueil tant qu'il reste une
étape obligatoire.

Ce que ce n'est pas : un parcours qui enferme. Chaque étape mène à l'écran
ordinaire qui la règle ; l'assistant ne fait que regarder où en est le site.
Une étape FACULTATIVE (vendre, Google, licence…) peut être marquée « pas pour
ce site » : elle ne compte plus, et se reprend d'un clic.

À la différence de `dashboard.setup_checklist` (accueil, ce qui MANQUE,
selon les droits de chacun), la liste est complète et la même pour tous :
c'est un état des lieux, pas une pile de tâches.
"""
from dataclasses import dataclass
from typing import Callable, Optional

from django.conf import settings
from django.urls import NoReverseMatch, reverse
from django.utils.translation import gettext_lazy as _


@dataclass(frozen=True)
class Etape:
    code: str
    groupe: str
    titre: str
    pourquoi: str
    url_name: Optional[str]
    fait: Callable
    facultative: bool = False
    #: Pour une étape qui ne se règle pas à l'écran (le serveur) : ce qu'il faut faire.
    consigne: str = ""


def _sur(fn, defaut=False):
    """Une étape dont le contrôle lève ne casse pas l'écran : elle est « à faire »."""
    try:
        return bool(fn())
    except Exception:
        return defaut


def _identite(site):
    identite = getattr(site, "identity", None)
    return bool(identite and (identite.name or "").strip())


def _serveur_email(site):
    from jeiko.administration.models import MailSettings

    mail = site.mail_settings or MailSettings.objects.first()
    return bool(mail and (mail.host or "").strip() and mail.active)


def _accueil(site):
    from jeiko.administration_pages.models import Page

    return Page.objects.filter(is_root=True, active=True).exists()


def _menu(site):
    from jeiko.administration_menu.models import Menu, MenuPlace

    return Menu.objects.filter(place=MenuPlace.MAIN, is_default=True, menu_items__isnull=False).exists()


def _pages_legales(site):
    legales = getattr(site, "legals", None)
    return bool(legales and legales.mentions_page_id and legales.privacy_page_id
                and legales.mentions_page.active and legales.privacy_page.active)


def _cookies(site):
    from jeiko.cookies.models import CookieBannerConfig

    return CookieBannerConfig.objects.filter(is_active=True).exists()


def _paiement(site):
    from jeiko.payments.models import PaymentGateway

    return PaymentGateway.objects.filter(is_active=True).exists()


def _facturation(site):
    from jeiko.shop.models import ShopSettings

    return bool((ShopSettings.get_solo().billing_name or "").strip())


def _google(site):
    from jeiko.administration.models import GoogleApi

    api = GoogleApi.objects.first()
    return bool(api and api.psi_api_key)


ETAPES = (
    Etape("nom", _("Identité"), _("Nommer le site et ses coordonnées"),
          _("Nom, adresse et téléphone : Google, les réseaux sociaux et les e-mails s'en servent."),
          "jeiko_administration:site_identity", _identite),
    Etape("logo", _("Identité"), _("Ajouter le logo"),
          _("Il apparaît dans l'en-tête du site et dans vos e-mails."),
          "jeiko_administration:logo_update", lambda s: s.logo_id and s.logo.full_size),
    Etape("favicon", _("Identité"), _("Ajouter le favicon"),
          _("La petite icône de l'onglet du navigateur et des favoris."),
          "jeiko_administration:favicon_update", lambda s: s.favicon_id and s.favicon.png_32),
    Etape("email", _("E-mails"), _("Configurer le serveur d'e-mails"),
          _("Sans lui, aucune confirmation, aucun mot de passe oublié, aucune relance ne part. Envoyez-vous un essai depuis l'écran."),
          "jeiko_administration:mail_settings_edit", _serveur_email),
    Etape("accueil", _("Contenu"), _("Publier la page d'accueil"),
          _("C'est la première page que voit un visiteur."),
          "jeiko_administration_pages:main", _accueil),
    Etape("menu", _("Contenu"), _("Construire le menu principal"),
          _("Un menu par défaut, avec au moins une entrée : sans lui, le visiteur ne circule pas."),
          "jeiko_administration_menu:menu_list", _menu),
    Etape("erreurs", _("Contenu"), _("Choisir les pages d'erreur"),
          _("Page introuvable, accès refusé, erreur du serveur : sans elles, le visiteur lit le message par défaut."),
          "jeiko_administration_pages:pages_erreur", lambda s: s.page_404_id),
    Etape("legales", _("Conformité"), _("Remplir les mentions légales et la politique de confidentialité"),
          _("Obligatoires pour tout site professionnel. Les deux pages doivent être publiées."),
          "jeiko_administration:legals_view", _pages_legales),
    Etape("cookies", _("Conformité"), _("Activer le bandeau de cookies"),
          _("Le consentement des visiteurs avant toute mesure d'audience ou contenu tiers."),
          "jeiko_cookies_admin:edit_banner_text", _cookies),
    Etape("paiement", _("Vente"), _("Activer un moyen de paiement"),
          _("Pour encaisser la boutique, les rendez-vous payants et les factures en ligne."),
          "jeiko_payments_admin:gateway_list", _paiement, facultative=True),
    Etape("facturation", _("Vente"), _("Renseigner l'identité de facturation"),
          _("Raison sociale, SIRET, TVA : ils figurent sur chaque facture."),
          "jeiko_administration_shop:facturation_reglages", _facturation, facultative=True),
    Etape("google", _("Visibilité"), _("Brancher l'API Google"),
          _("Pour mesurer la vitesse des pages (PageSpeed) depuis l'administration."),
          "jeiko_administration:google_api_config", _google, facultative=True),
    Etape("https", _("Sécurité et maintenance"), _("Passer le site en HTTPS"),
          _("Le cadenas du navigateur, des formulaires et des paiements chiffrés."),
          None, lambda s: getattr(settings, "JEIKO_SSL", False),
          consigne=_("Sur le serveur : activer le certificat (ENABLE_SSL dans la fiche du site, puis jeiko-server-update).")),
    Etape("licence", _("Sécurité et maintenance"), _("Saisir la clé de licence"),
          _("Fournie par JEIKO, elle autorise les mises à jour du site."),
          "jeiko_administration:update_jeiko_reglages", lambda s: s.licence_cle, facultative=True),
    Etape("maj_auto", _("Sécurité et maintenance"), _("Choisir la mise à jour automatique"),
          _("Chaque semaine, la nuit : le serveur puis le site, avec retour arrière en cas d'échec."),
          "jeiko_administration:update_jeiko_reglages", lambda s: s.mise_a_jour_auto, facultative=True),
)


def _url(nom):
    if not nom:
        return ""
    try:
        return reverse(nom)
    except NoReverseMatch:
        return ""


def etat(site):
    """
    Les étapes, groupées dans l'ordre, chacune avec `fait`, `ignoree` et son
    adresse ; plus la progression sur les étapes qui comptent (obligatoires,
    et facultatives non écartées).
    """
    ignorees = set(site.mise_en_route_ignorees or []) if site else set()
    groupes, faites, comptees = [], 0, 0
    for etape in ETAPES:
        fait = _sur(lambda: etape.fait(site)) if site else False
        ignoree = etape.facultative and etape.code in ignorees and not fait
        if not ignoree:
            comptees += 1
            faites += fait
        ligne = {"etape": etape, "fait": fait, "ignoree": ignoree, "url": _url(etape.url_name)}
        if not groupes or groupes[-1]["nom"] != etape.groupe:
            groupes.append({"nom": etape.groupe, "etapes": []})
        groupes[-1]["etapes"].append(ligne)
    return {
        "groupes": groupes,
        "faites": faites,
        "comptees": comptees,
        "pourcent": round(100 * faites / comptees) if comptees else 100,
        "terminee": faites == comptees,
    }
