"""
Les écrans des licences (super-administrateurs de jeiko.fr) et l'API que
`jeiko-client-update` interroge. Tout répond 404 tant que
`JEIKO_SERVEUR_DE_LICENCES` n'est pas allumé dans le .env.
"""
import json

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import ListView

from jeiko import throttling
from jeiko.administration.models import Licence, ReglagesDesLicences, VerificationDeLicence
from jeiko.listes import ListeRechercheeEtPaginee

from . import service
from .forms import LicenceForm, NouvelleCleForm, ReglagesForm


def serveur_allume():
    return bool(getattr(settings, "JEIKO_SERVEUR_DE_LICENCES", False))


class _Allume:
    def dispatch(self, request, *args, **kwargs):
        if not serveur_allume():
            raise Http404
        return super().dispatch(request, *args, **kwargs)


class _Acces(_Allume, LoginRequiredMixin, UserPassesTestMixin):
    """Super-administrateurs seulement : c'est la couche de Guillaume."""

    raise_exception = True

    def test_func(self):
        return self.request.user.is_superuser


@method_decorator(never_cache, name="dispatch")
class ListeDesLicences(_Acces, ListeRechercheeEtPaginee, ListView):
    template_name = "licences/admin/liste.html"
    context_object_name = "licences"
    champs_de_recherche = ("titulaire", "email", "domaine", "indice")

    def get_queryset(self):
        qs = Licence.objects.order_by("titulaire", "-cree_le")
        return self.rechercher(qs)

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        contexte["reglages"] = ReglagesDesLicences.get_solo()
        return contexte


def _cle_affichee(request, licence, cle):
    """La clé qui vient d'être créée : rendue directement, jamais en session ni dans l'adresse."""
    return render(request, "licences/admin/cle.html", {"licence": licence, "cle": cle})


@method_decorator(never_cache, name="dispatch")
class NouvelleLicence(_Acces, View):
    def get(self, request):
        return render(request, "licences/admin/formulaire.html", {"form": LicenceForm()})

    def post(self, request):
        form = LicenceForm(request.POST)
        if form.is_valid():
            d = form.cleaned_data
            try:
                licence, cle = service.creer(
                    titulaire=d["titulaire"], email=d["email"], notes=d["notes"], domaine=d["domaine"],
                    expire_le=d["expire_le"], cle=d.get("cle") or "", cree_par=request.user,
                )
            except ValueError as souci:
                form.add_error("cle", str(souci))
            else:
                if not d["active"]:
                    licence.active = False
                    licence.save(update_fields=["active"])
                return _cle_affichee(request, licence, cle)
        return render(request, "licences/admin/formulaire.html", {"form": form})


@method_decorator(never_cache, name="dispatch")
class FicheDeLaLicence(_Acces, View):
    def _contexte(self, licence, form=None, form_cle=None):
        return {
            "licence": licence,
            "form": form or LicenceForm(instance=licence),
            "form_cle": form_cle or NouvelleCleForm(),
            "verifications": licence.verifications.all()[:20],
        }

    def get(self, request, pk):
        licence = get_object_or_404(Licence, pk=pk)
        return render(request, "licences/admin/fiche.html", self._contexte(licence))

    def post(self, request, pk):
        licence = get_object_or_404(Licence, pk=pk)
        form = LicenceForm(request.POST, instance=licence)
        if form.is_valid():
            form.save()
            messages.success(request, _("Licence enregistrée."))
            return redirect("jeiko_licences:fiche", pk=licence.pk)
        return render(request, "licences/admin/fiche.html", self._contexte(licence, form=form))


@method_decorator(never_cache, name="dispatch")
class ActionSurLaLicence(_Acces, View):
    def post(self, request, pk, action):
        licence = get_object_or_404(Licence, pk=pk)
        if action == "delier":
            licence.domaine = ""
            licence.save(update_fields=["domaine"])
            messages.success(request, _("Domaine délié : la clé se liera au prochain site qui la présente."))
        elif action == "nouvelle-cle":
            form = NouvelleCleForm(request.POST)
            if form.is_valid():
                try:
                    cle = service.remplacer_la_cle(licence, form.cleaned_data["cle"])
                except ValueError as souci:
                    messages.error(request, str(souci))
                else:
                    return _cle_affichee(request, licence, cle)
            else:
                messages.error(request, " ".join(form.errors.get("cle", [])))
        elif action == "supprimer":
            licence.delete()
            messages.success(request, _("Licence supprimée."))
            return redirect("jeiko_licences:liste")
        else:
            raise Http404
        return redirect("jeiko_licences:fiche", pk=licence.pk)


@method_decorator(never_cache, name="dispatch")
class JournalDesVerifications(_Acces, ListeRechercheeEtPaginee, ListView):
    template_name = "licences/admin/journal.html"
    context_object_name = "verifications"
    champs_de_recherche = ("domaine", "indice", "motif")

    def get_queryset(self):
        qs = VerificationDeLicence.objects.select_related("licence").order_by("-le")
        decision = self.request.GET.get("decision")
        if decision in dict(VerificationDeLicence.DECISIONS):
            qs = qs.filter(decision=decision)
        return self.rechercher(qs)

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        contexte["decisions"] = VerificationDeLicence.DECISIONS
        contexte["decision"] = self.request.GET.get("decision", "")
        return contexte


@method_decorator(never_cache, name="dispatch")
class ReglagesDesLicencesVue(_Acces, View):
    def get(self, request):
        return render(request, "licences/admin/reglages.html",
                      {"form": ReglagesForm(instance=ReglagesDesLicences.get_solo())})

    def post(self, request):
        form = ReglagesForm(request.POST, instance=ReglagesDesLicences.get_solo())
        if form.is_valid():
            form.save()
            messages.success(request, _("Réglages enregistrés."))
            return redirect("jeiko_licences:reglages")
        return render(request, "licences/admin/reglages.html", {"form": form})


@method_decorator(csrf_exempt, name="dispatch")
class Verifier(_Allume, View):
    """
    POST JSON {cle, domaine, version_actuelle, version_visee} → {autorisee,
    mode, message[, expire_le]}. Sans authentification : la clé EST l'accès.
    Corps borné, plafond par adresse (une clé ne se devine pas à 30 essais
    par minute), aucune page d'erreur HTML — l'appelant est un script.
    """

    TAILLE_MAX = 4096

    def post(self, request):
        if throttling.rate_limited(request, "licence_verifier", 30, 60):
            return JsonResponse({"erreur": "trop de demandes"}, status=429)
        if len(request.body) > self.TAILLE_MAX:
            return JsonResponse({"erreur": "corps trop long"}, status=413)
        try:
            corps = json.loads(request.body or b"{}")
        except (ValueError, UnicodeDecodeError):
            return JsonResponse({"erreur": "JSON attendu"}, status=400)
        if not isinstance(corps, dict):
            return JsonResponse({"erreur": "objet JSON attendu"}, status=400)
        return JsonResponse(service.verifier(
            corps.get("cle"), corps.get("domaine"), corps.get("version_actuelle"),
            corps.get("version_visee"), ip=throttling.ip_stockable(request),
        ))

    def get(self, request):
        return JsonResponse({"erreur": "POST attendu"}, status=405)


@method_decorator(never_cache, name="dispatch")
class DomaineDeMaLicence(_Allume, LoginRequiredMixin, View):
    """
    Le CLIENT relie sa licence à son site, depuis son compte (« Mes
    licences »). Sans cela, la clé se liait au premier site qui la
    présentait — personne ne choisissait.

    Tant que la clé n'a autorisé aucune mise à jour sur ce domaine, le client
    peut le corriger (une faute de frappe, un site pas encore en ligne).
    Ensuite, le changer revient à délier la clé : c'est une décision de
    l'exploitant (fiche de la licence, « Délier »), sinon une même clé
    servirait un site après l'autre.
    """

    def post(self, request, pk):
        licence = get_object_or_404(Licence, pk=pk, compte=request.user)
        retour = redirect(reverse("jeiko_users_client:profile-detail") + "#licences")
        if not licence.domaine_modifiable:
            messages.error(request, _("Cette clé sert déjà %(domaine)s : pour la relier à un autre site, "
                                      "écrivez-nous.") % {"domaine": licence.domaine})
            return retour
        domaine = service.domaine_canonique(request.POST.get("domaine", ""))
        if "." not in domaine:
            messages.error(request, _("Nom de domaine invalide : écrivez-le sans https://, par exemple monsite.fr."))
            return retour
        licence.domaine = domaine
        licence.save(update_fields=["domaine"])
        messages.success(request, _("Licence reliée à %(domaine)s.") % {"domaine": domaine})
        return retour
