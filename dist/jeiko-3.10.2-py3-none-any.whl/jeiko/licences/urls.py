from django.urls import path

from . import views

app_name = "jeiko_licences"

urlpatterns = [
    path("", views.ListeDesLicences.as_view(), name="liste"),
    path("nouvelle/", views.NouvelleLicence.as_view(), name="nouvelle"),
    path("journal/", views.JournalDesVerifications.as_view(), name="journal"),
    path("reglages/", views.ReglagesDesLicencesVue.as_view(), name="reglages"),
    path("<int:pk>/", views.FicheDeLaLicence.as_view(), name="fiche"),
    path("<int:pk>/<slug:action>/", views.ActionSurLaLicence.as_view(), name="action"),
]
