import datetime

from django import forms
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

from jeiko.administration.models import Licence, ReglagesDesLicences

from . import cles
from .service import domaine_canonique


class LicenceForm(forms.ModelForm):
    """
    Créer ou modifier une licence. La validité se choisit en clair : l'essai
    (durée des réglages), jusqu'à une date, ou à vie — `expire_le` en découle.
    À la création seulement, la clé peut être SAISIE (sinon fabriquée).
    """

    ESSAI, DATE, VIE = "essai", "date", "vie"
    validite = forms.ChoiceField(
        label=_("Validité"), widget=forms.RadioSelect,
        choices=[(ESSAI, _("Essai")), (DATE, _("Jusqu'à une date")), (VIE, _("À vie"))],
    )
    cle = forms.CharField(
        label=_("Clé"), required=False, max_length=80,
        help_text=_("Vide : une clé est fabriquée. Sinon 12 à 64 caractères, lettres, chiffres et tirets."),
    )

    class Meta:
        model = Licence
        fields = ["titulaire", "email", "domaine", "expire_le", "active", "notes"]
        widgets = {
            "expire_le": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        essai = ReglagesDesLicences.get_solo().duree_essai_jours
        self.fields["validite"].choices = [
            (self.ESSAI, _("Essai de %(jours)s jours") % {"jours": essai}),
            (self.DATE, _("Jusqu'à une date")),
            (self.VIE, _("À vie")),
        ]
        self.duree_essai = essai
        if self.instance.pk:
            del self.fields["cle"]
            self.fields["validite"].initial = self.VIE if self.instance.expire_le is None else self.DATE
        else:
            self.fields["validite"].initial = self.ESSAI

    def clean_domaine(self):
        brut = (self.cleaned_data.get("domaine") or "").strip()
        if not brut:
            return ""
        domaine = domaine_canonique(brut)
        if not domaine:
            raise forms.ValidationError(_("Domaine invalide (exemple.fr)."))
        return domaine

    def clean_cle(self):
        brut = self.cleaned_data.get("cle") or ""
        if brut.strip() and not cles.canonique(brut):
            raise forms.ValidationError(_("Une clé : 12 à 64 caractères, lettres, chiffres et tirets."))
        return cles.canonique(brut)

    def clean(self):
        donnees = super().clean()
        validite = donnees.get("validite")
        if validite == self.VIE:
            donnees["expire_le"] = None
        elif validite == self.ESSAI:
            donnees["expire_le"] = timezone.localdate() + datetime.timedelta(days=self.duree_essai)
        elif validite == self.DATE and not donnees.get("expire_le"):
            self.add_error("expire_le", _("Indiquer la date de fin."))
        self.instance.expire_le = donnees.get("expire_le")
        return donnees


class NouvelleCleForm(forms.Form):
    cle = forms.CharField(
        label=_("Nouvelle clé"), required=False, max_length=80,
        help_text=_("Vide : une clé est fabriquée."),
    )

    def clean_cle(self):
        brut = self.cleaned_data.get("cle") or ""
        if brut.strip() and not cles.canonique(brut):
            raise forms.ValidationError(_("Une clé : 12 à 64 caractères, lettres, chiffres et tirets."))
        return cles.canonique(brut)


class ReglagesForm(forms.ModelForm):
    class Meta:
        model = ReglagesDesLicences
        fields = ["blocage_actif", "duree_essai_jours"]
