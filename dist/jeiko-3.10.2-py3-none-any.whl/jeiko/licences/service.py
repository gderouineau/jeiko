"""
La décision : cette mise à jour est-elle autorisée ?

Appelée par l'API (`views.Verifier`) pour chaque demande d'un site. Rend un
dict qui part tel quel en JSON, et note la demande dans le journal.
"""

import datetime
import re

from django.db import transaction
from django.utils import timezone
from django.utils.translation import gettext as _

from jeiko.administration.models import Licence, ReglagesDesLicences, VerificationDeLicence

from . import cles

#: Ce qu'un site envoie est borné avant d'entrer en base ou dans un message.
DOMAINE = re.compile(r"[a-z0-9]([a-z0-9.-]{0,251}[a-z0-9])?")
VERSION = re.compile(r"[0-9A-Za-z.+-]{1,32}")

#: Durée de conservation du journal des vérifications.
CONSERVATION_JOURS = 180


def domaine_canonique(domaine):
    """Minuscules, sans « www. » ni point final : www.exemple.fr = exemple.fr."""
    if not isinstance(domaine, str):
        return ""
    domaine = domaine.strip().lower().rstrip(".")
    if domaine.startswith("www."):
        domaine = domaine[4:]
    return domaine if DOMAINE.fullmatch(domaine) else ""


def _version(valeur):
    return valeur if isinstance(valeur, str) and VERSION.fullmatch(valeur) else ""


def verifier(cle, domaine, version_actuelle="", version_visee="", ip=None, aujourd_hui=None):
    aujourd_hui = aujourd_hui or timezone.localdate()
    domaine = domaine_canonique(domaine)
    forme = cles.canonique(cle)
    reglages = ReglagesDesLicences.get_solo()
    licence, motif = None, ""

    with transaction.atomic():
        if not forme:
            motif = _("Aucune clé de licence sur ce site.") if not cle else _("Clé de licence mal formée.")
        else:
            licence = Licence.objects.select_for_update().filter(empreinte=cles.empreinte(forme)).first()
            if licence is None:
                motif = _("Clé de licence inconnue.")
            elif not licence.active:
                motif = _("Clé de licence désactivée.")
            elif licence.expiree(aujourd_hui):
                motif = _("Clé de licence expirée le %(date)s.") % {"date": licence.expire_le.strftime("%d/%m/%Y")}
            elif not domaine:
                motif = _("Domaine du site absent ou invalide.")
            elif licence.domaine and licence.domaine != domaine:
                motif = _("Cette clé est liée à un autre domaine.")
        valide = licence is not None and not motif

        if licence is not None:
            champs = ["derniere_verification_le"]
            licence.derniere_verification_le = timezone.now()
            if valide and not licence.domaine:
                # Le premier domaine qui présente la clé se l'attache.
                licence.domaine = domaine
                champs.append("domaine")
            if valide and _version(version_actuelle):
                licence.derniere_version = _version(version_actuelle)
                champs.append("derniere_version")
            licence.save(update_fields=champs)

        if valide:
            decision = VerificationDeLicence.AUTORISEE
        elif reglages.blocage_actif:
            decision = VerificationDeLicence.REFUSEE
        else:
            decision = VerificationDeLicence.OBSERVATION
        VerificationDeLicence.objects.create(
            licence=licence, indice=cles.indice(forme) if forme else "", domaine=domaine,
            version_actuelle=_version(version_actuelle), version_visee=_version(version_visee),
            ip=ip or None, decision=decision, motif=motif[:200],
        )

    reponse = {
        "autorisee": decision != VerificationDeLicence.REFUSEE,
        "mode": "blocage" if reglages.blocage_actif else "observation",
        "message": motif or _("Licence valide."),
    }
    if valide:
        reponse["expire_le"] = licence.expire_le.isoformat() if licence.expire_le else None
    return reponse


def purger(maintenant=None):
    """Le journal au-delà de sa conservation. Rend le nombre de lignes retirées."""
    limite = (maintenant or timezone.now()) - datetime.timedelta(days=CONSERVATION_JOURS)
    return VerificationDeLicence.objects.filter(le__lt=limite).delete()[0]


def creer(*, titulaire, email="", notes="", domaine="", expire_le=None, cle="", cree_par=None,
          compte=None, commande=None):
    """
    Crée une licence. `cle` vide : une clé est fabriquée. Rend
    `(licence, clé en clair)` ; la clé est aussi gardée chiffrée. Lève
    ValueError si la clé saisie est mal formée ou déjà prise.
    """
    en_clair = cles.canonique(cle) if cle else cles.fabriquer()
    if not en_clair:
        raise ValueError(_("Une clé : 12 à 64 caractères, lettres, chiffres et tirets."))
    if Licence.objects.filter(empreinte=cles.empreinte(en_clair)).exists():
        raise ValueError(_("Cette clé existe déjà."))
    licence = Licence.objects.create(
        titulaire=titulaire, email=email, notes=notes, domaine=domaine_canonique(domaine),
        expire_le=expire_le, empreinte=cles.empreinte(en_clair), indice=cles.indice(en_clair),
        cle_chiffree=en_clair, cree_par=cree_par, compte=compte, commande=commande,
    )
    return licence, en_clair


def remplacer_la_cle(licence, cle=""):
    """Nouvelle clé pour la même licence (l'ancienne cesse de valoir)."""
    en_clair = cles.canonique(cle) if cle else cles.fabriquer()
    if not en_clair:
        raise ValueError(_("Une clé : 12 à 64 caractères, lettres, chiffres et tirets."))
    if Licence.objects.filter(empreinte=cles.empreinte(en_clair)).exclude(pk=licence.pk).exists():
        raise ValueError(_("Cette clé existe déjà."))
    licence.empreinte = cles.empreinte(en_clair)
    licence.indice = cles.indice(en_clair)
    licence.cle_chiffree = en_clair
    licence.save(update_fields=["empreinte", "indice", "cle_chiffree"])
    return en_clair
