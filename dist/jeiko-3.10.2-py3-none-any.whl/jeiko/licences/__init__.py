"""
Le serveur de licences de JEIKO (LIC-01, 11/10/2026).

Une couche à Guillaume, par-dessus JEIKO : sur jeiko.fr, les clés des clients
et l'API que `jeiko-client-update` interroge avant chaque mise à jour d'un
site. Allumée par `JEIKO_SERVEUR_DE_LICENCES=True` dans le .env ; partout
ailleurs, ses écrans et son API répondent 404 et le menu ne la montre pas.

Comme le CRM, ce paquet n'a pas de modèle à lui : `Licence`,
`VerificationDeLicence` et `ReglagesDesLicences` vivent dans
`administration.models`. Une application de plus aurait dû entrer dans le
gabarit de settings, et un site resté sur un ancien settings ne démarrerait
plus.

Ce qui fait foi
---------------
* La clé se cherche par son empreinte (`cles.py`), et elle est gardée
  chiffrée (LIC-02) pour que le client la retrouve dans son compte et
  Guillaume dans la fiche : une base lue sans le .env ne la livre pas.
* La boutique de jeiko.fr vend des licences (`boutique.py`) : créées au
  paiement, ou prolongées quand le client l'a choisi depuis son compte.
* Une clé sert UN domaine : le premier qui la présente, ou celui qu'on lui
  donne. La délier se fait à l'écran.
* Tant que l'interrupteur (`ReglagesDesLicences.blocage_actif`) est coupé,
  toute mise à jour passe et la demande est seulement notée : on distribue
  les clés d'abord, on bloque ensuite, sans rien republier.
* Côté site, un serveur injoignable laisse passer la mise à jour (décision
  de Guillaume, 11/10) : une panne de jeiko.fr ne bloque jamais un client,
  ni ses correctifs de sécurité.

Ce que ça ne fait pas : empêcher qui tient la racine de son serveur de
contourner le contrôle. Il protège ce qu'on héberge ; chez un client qui
s'héberge, c'est une règle, pas un verrou.
"""
