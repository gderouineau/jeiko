"""
Les clés de licence : fabrication, forme canonique, empreinte.

Une clé fabriquée ressemble à `JK-7Q4MX-2HD9P-KW3RT-8VNCE` : 20 caractères
tirés au sort dans un alphabet sans les lettres qu'on confond à la lecture ou
au téléphone (0/O, 1/I/L, U) — 100 bits, rien à deviner. Une clé SAISIE à la
main (Guillaume, 11/10 : « super important ») est acceptée telle quelle si
elle tient dans la forme permise ; elle est alors aussi solide que ce qu'on a
choisi — d'où le minimum de 12 caractères et le lien à un domaine.

La forme canonique (majuscules, sans espaces) est ce qui est haché : une clé
recopiée en minuscules, ou avec un espace en trop, reste la même clé.
"""

import hashlib
import re
import secrets

ALPHABET = "23456789ABCDEFGHJKMNPQRSTVWXYZ"
FORME = re.compile(r"[A-Z0-9-]{12,64}")


def fabriquer():
    corps = "".join(secrets.choice(ALPHABET) for __ in range(20))
    return "JK-" + "-".join(corps[i:i + 5] for i in range(0, 20, 5))


def canonique(cle):
    """La forme comparée et hachée, ou "" si la clé n'en est pas une."""
    if not isinstance(cle, str):
        return ""
    cle = "".join(cle.split()).upper()
    return cle if FORME.fullmatch(cle) else ""


def empreinte(cle):
    return hashlib.sha256(canonique(cle).encode("ascii")).hexdigest()


def indice(cle):
    return canonique(cle)[-4:]
