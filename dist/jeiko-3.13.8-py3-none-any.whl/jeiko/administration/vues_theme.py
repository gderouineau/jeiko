# jeiko/administration/vues_theme.py
"""Écran de réglage des thèmes."""

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.cache import never_cache

from .forms_theme import ThemeForm
from .models import Theme, WebSite
from .website_cache import invalidate_website_data
from django.utils.translation import gettext_lazy as _


def theme_du_site():
    """
    Le site et son thème par défaut, créé s'il manque.

    La migration en pose un sur les sites existants, mais un site créé
    après elle — ou une base restaurée d'ailleurs — pourrait ne pas en
    avoir. Un écran qui plante dans ce cas serait un mauvais accueil.
    """
    site = WebSite.objects.select_related("theme").first()
    if site is None:
        return None, None
    if site.theme is None:
        site.theme = Theme.objects.create(nom=str(_("Défaut")))
        site.save(update_fields=["theme"])
    return site, site.theme


@method_decorator(never_cache, name="dispatch")
class ThemeView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Les palettes du site : celle par défaut, et celles que des catégories
    choisissent pour leurs pages.

    Gardée par la permission qui gouverne déjà l'identité et les polices :
    changer la palette change l'aspect de toutes les pages d'un coup.
    """

    template_name = "administration/theme/update.html"
    permission_required = "users.config_edit_fonts"
    raise_exception = True

    def _choisi(self, request, defaut):
        """Le thème demandé par `?theme=`, sinon celui du site."""
        brut = request.POST.get("theme") or request.GET.get("theme")
        if brut and str(brut).isdigit():
            return Theme.objects.filter(pk=brut).first() or defaut
        return defaut

    def _rendre(self, request, form, theme, defaut):
        return render(request, self.template_name, {
            "form": form, "theme": theme, "theme_defaut": defaut,
            "themes": Theme.objects.order_by("pk"),
            "categories": theme.categories.order_by("name"),
        })

    def _vers(self, theme):
        return redirect(f"{reverse('jeiko_administration:theme_view')}?theme={theme.pk}")

    def get(self, request):
        site, defaut = theme_du_site()
        if defaut is None:
            messages.error(request, _("Aucun site n'est encore configuré."))
            return redirect("jeiko_administration:main")
        theme = self._choisi(request, defaut)
        return self._rendre(request, ThemeForm(instance=theme), theme, defaut)

    def post(self, request):
        site, defaut = theme_du_site()
        if defaut is None:
            return redirect("jeiko_administration:main")
        theme = self._choisi(request, defaut)
        action = request.POST.get("action")

        if action == "nouveau":
            # Un nouveau thème part de celui qu'on regarde : on retouche une
            # palette qui marche plutôt que de repartir de zéro.
            copie = Theme.objects.get(pk=theme.pk)
            copie.pk = None
            copie.nom = str(_("Nouveau thème"))
            copie.save()
            messages.success(request, _("Thème créé. Choisissez-le dans une catégorie pour l'appliquer à ses pages."))
            return self._vers(copie)

        if action == "supprimer":
            if theme.pk == defaut.pk:
                messages.error(request, _("Le thème par défaut du site ne se supprime pas."))
                return self._vers(theme)
            # Les catégories qui le portaient reviennent au thème du site
            # (on_delete=SET_NULL) : rien ne casse.
            theme.delete()
            invalidate_website_data()
            messages.success(request, _("Thème supprimé. Ses catégories reprennent le thème par défaut."))
            return self._vers(defaut)

        form = ThemeForm(request.POST, instance=theme)
        if not form.is_valid():
            return self._rendre(request, form, theme, defaut)
        form.save()

        # Le thème voyage dans `website_data`, qui est en cache : sans cette
        # purge, l'exploitant enregistre et ne voit rien changer pendant 24 h.
        invalidate_website_data()

        messages.success(request, _("Thème enregistré."))
        return self._vers(theme)
