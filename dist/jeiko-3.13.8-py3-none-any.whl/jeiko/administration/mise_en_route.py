"""
La mise en route d'un site (D-01, 11/10/2026).

Ce qu'il faut régler pour qu'un site neuf tienne debout, dans l'ordre où on
le fait, avec pour chaque étape : faite ou non, pourquoi elle compte, et
l'écran qui la règle. Un écran à part (Tableau de bord ▸ Mise en route), qu'on
rouvre quand on veut, et sa progression sur l'accueil tant qu'il reste une
étape obligatoire.

Ce que ce n'est pas : un parcours qui enferme. Chaque étape mène à l'écran
ordinaire qui la règle ; l'assistant ne fait que regarder où en est le site.
Une étape FACULTATIVE (vendre, Google, licence…) peut être marquée « pas pour
ce site » : elle ne compte plus, et se reprend d'un clic.

À la différence de `dashboard.setup_checklist` (accueil, ce qui MANQUE,
selon les droits de chacun), la liste est complète et la même pour tous :
c'est un état des lieux, pas une pile de tâches.
"""
from dataclasses import dataclass
from typing import Callable, Optional

from django.conf import settings
from django.urls import NoReverseMatch, reverse
from django.utils.translation import gettext_lazy as _


@dataclass(frozen=True)
class Etape:
    code: str
    groupe: str
    titre: str
    pourquoi: str
    url_name: Optional[str]
    fait: Callable
    facultative: bool = False
    #: Pour une étape qui ne se règle pas à l'écran (le serveur) : ce qu'il faut faire.
    consigne: str = ""
    #: Réglé n'est pas éprouvé : un serveur d'e-mails saisi avec une faute de
    #: frappe est « configuré » et n'envoie rien. Quand l'étape le permet, ce
    #: contrôle dit si le réglage a déjà marché ; tant qu'il dit non, l'étape
    #: est « à éprouver » et ne compte pas comme faite.
    eprouve: Optional[Callable] = None
    epreuve: str = ""
    #: Un module masqué (MOD-01) ôte ses étapes : on ne réclame pas de régler
    #: la newsletter d'un site qui l'a écartée.
    module: str = ""


def _sur(fn, defaut=False):
    """Une étape dont le contrôle lève ne casse pas l'écran : elle est « à faire »."""
    try:
        return bool(fn())
    except Exception:
        return defaut


def _identite(site):
    identite = getattr(site, "identity", None)
    return bool(identite and (identite.name or "").strip())


def _serveur_email(site):
    from jeiko.administration.models import MailSettings

    mail = site.mail_settings or MailSettings.objects.first()
    return bool(mail and (mail.host or "").strip() and mail.active)


def _email_eprouve(site):
    """Le dernier envoi (hors file d'attente) est parti : le réglage marche."""
    from jeiko.emailing.models import EmailLog

    dernier = (EmailLog.objects.exclude(status=EmailLog.STATUS_QUEUED)
               .order_by("-queued_at").values_list("status", flat=True).first())
    return dernier == EmailLog.STATUS_SENT


def _domaine_d_envoi(site):
    """SPF, DKIM et DMARC du domaine de l'adresse d'envoi, tous trois lus dans le DNS."""
    from jeiko.administration.models import MailSettings
    from jeiko.newsletter import delivrabilite

    mail = site.mail_settings or MailSettings.objects.first()
    domaine = delivrabilite.domaine_de(mail and (mail.default_from_email or mail.host_user))
    lignes = delivrabilite.verifier(domaine, hote=mail.host or "") if domaine else []
    return bool(lignes) and all(etat == "ok" for etat, _l, _d in lignes)


def _inscription_newsletter(site):
    """Un bloc « Inscription à la newsletter » est posé quelque part."""
    from jeiko.administration_pages.models import Content

    return Content.objects.filter(content_type="DYN_NEWSLETTER").exists()


def _rebonds_newsletter(site):
    from jeiko.emailing.models import ReglagesNewsletter

    return bool((ReglagesNewsletter.du_site().rebonds_hote or "").strip())


def _paiement_eprouve(site):
    """Le prestataire a déjà joint le site : le webhook est branché."""
    from jeiko.payments.models import PaymentGateway

    return PaymentGateway.objects.filter(is_active=True, dernier_evenement_le__isnull=False).exists()


def _accueil(site):
    from jeiko.administration_pages.models import Page

    return Page.objects.filter(is_root=True, active=True).exists()


def _menu(site):
    from jeiko.administration_menu.models import Menu, MenuPlace

    return Menu.objects.filter(place=MenuPlace.MAIN, is_default=True, menu_items__isnull=False).exists()


def _pages_legales(site):
    legales = getattr(site, "legals", None)
    return bool(legales and legales.mentions_page_id and legales.privacy_page_id
                and legales.mentions_page.active and legales.privacy_page.active)


def _cookies(site):
    from jeiko.cookies.models import CookieBannerConfig

    return CookieBannerConfig.objects.filter(is_active=True).exists()


def _paiement(site):
    from jeiko.payments.models import PaymentGateway

    return PaymentGateway.objects.filter(is_active=True).exists()


def _facturation(site):
    from jeiko.shop.models import ShopSettings

    return bool((ShopSettings.get_solo().billing_name or "").strip())


def _google(site):
    from jeiko.administration.models import GoogleApi

    api = GoogleApi.objects.first()
    return bool(api and api.psi_api_key)


ETAPES = (
    Etape("nom", _("Identité"), _("Nommer le site et ses coordonnées"),
          _("Nom, adresse et téléphone : Google, les réseaux sociaux et les e-mails s'en servent."),
          "jeiko_administration:site_identity", _identite),
    Etape("logo", _("Identité"), _("Ajouter le logo"),
          _("Il apparaît dans l'en-tête du site et dans vos e-mails."),
          "jeiko_administration:logo_update", lambda s: s.logo_id and s.logo.full_size),
    Etape("favicon", _("Identité"), _("Ajouter le favicon"),
          _("La petite icône de l'onglet du navigateur et des favoris."),
          "jeiko_administration:favicon_update", lambda s: s.favicon_id and s.favicon.png_32),
    Etape("email", _("E-mails"), _("Configurer le serveur d'e-mails"),
          _("Sans lui, aucune confirmation, aucun mot de passe oublié, aucune relance ne part. Envoyez-vous un essai depuis l'écran."),
          "jeiko_administration:mail_settings_edit", _serveur_email,
          eprouve=_email_eprouve,
          epreuve=_("Réglé, mais aucun e-mail n'est encore parti — ou le dernier a échoué : envoyez-vous un essai depuis l'écran.")),
    Etape("domaine_envoi", _("E-mails"), _("Déclarer SPF, DKIM et DMARC du domaine d'envoi"),
          _("Trois enregistrements de la zone DNS du domaine de l'adresse d'envoi, chez son hébergeur : sans eux, Gmail et Outlook classent vos e-mails en indésirables. L'écran du serveur e-mail dit lesquels manquent et quoi créer."),
          "jeiko_administration:mail_settings_edit", _domaine_d_envoi),
    Etape("newsletter_inscription", _("Newsletter"), _("Proposer l'inscription à la newsletter"),
          _("Posez le bloc « Inscription à la newsletter » sur une page (famille Collecter) : les visiteurs s'inscrivent et confirment par e-mail."),
          "jeiko_administration_pages:main", _inscription_newsletter, facultative=True, module="newsletter"),
    Etape("newsletter_reglages", _("Newsletter"), _("Régler la newsletter"),
          _("Plafond d'envois de votre hébergeur, expéditeur, texte du consentement, et la boîte des rebonds différés : une adresse refusée ne reçoit plus rien."),
          "jeiko_newsletter_admin:reglages", _rebonds_newsletter, facultative=True, module="newsletter"),
    Etape("accueil", _("Contenu"), _("Publier la page d'accueil"),
          _("C'est la première page que voit un visiteur."),
          "jeiko_administration_pages:main", _accueil),
    Etape("menu", _("Contenu"), _("Construire le menu principal"),
          _("Un menu par défaut, avec au moins une entrée : sans lui, le visiteur ne circule pas."),
          "jeiko_administration_menu:menu_list", _menu),
    Etape("erreurs", _("Contenu"), _("Choisir les pages d'erreur"),
          _("Page introuvable, accès refusé, erreur du serveur : sans elles, le visiteur lit le message par défaut."),
          "jeiko_administration_pages:pages_erreur", lambda s: s.page_404_id),
    Etape("legales", _("Conformité"), _("Remplir les mentions légales et la politique de confidentialité"),
          _("Obligatoires pour tout site professionnel. Les deux pages doivent être publiées."),
          "jeiko_administration:legals_view", _pages_legales),
    Etape("cookies", _("Conformité"), _("Activer le bandeau de cookies"),
          _("Le consentement des visiteurs avant toute mesure d'audience ou contenu tiers."),
          "jeiko_cookies_admin:edit_banner_text", _cookies),
    Etape("paiement", _("Vente"), _("Activer un moyen de paiement"),
          _("Pour encaisser la boutique, les rendez-vous payants et les factures en ligne."),
          "jeiko_payments_admin:gateway_list", _paiement, facultative=True,
          eprouve=_paiement_eprouve,
          epreuve=_("Activé, mais le prestataire n'a encore rien envoyé au site : vérifiez le webhook depuis l'écran des paiements.")),
    Etape("facturation", _("Vente"), _("Renseigner l'identité de facturation"),
          _("Raison sociale, SIRET, TVA : ils figurent sur chaque facture."),
          "jeiko_administration_shop:facturation_reglages", _facturation, facultative=True),
    Etape("google", _("Visibilité"), _("Brancher l'API Google"),
          _("Pour mesurer la vitesse des pages (PageSpeed) depuis l'administration."),
          "jeiko_administration:google_api_config", _google, facultative=True),
    Etape("https", _("Sécurité et maintenance"), _("Passer le site en HTTPS"),
          _("Le cadenas du navigateur, des formulaires et des paiements chiffrés."),
          None, lambda s: getattr(settings, "JEIKO_SSL", False),
          consigne=_("Sur le serveur : activer le certificat (ENABLE_SSL dans la fiche du site, puis jeiko-server-update).")),
    Etape("licence", _("Sécurité et maintenance"), _("Saisir la clé de licence"),
          _("Fournie par JEIKO, elle autorise les mises à jour du site."),
          "jeiko_administration:update_jeiko_reglages", lambda s: s.licence_cle, facultative=True),
    Etape("maj_auto", _("Sécurité et maintenance"), _("Choisir la mise à jour automatique"),
          _("Chaque semaine, la nuit : le serveur puis le site, avec retour arrière en cas d'échec."),
          "jeiko_administration:update_jeiko_reglages", lambda s: s.mise_a_jour_auto, facultative=True),
)


def _url(nom):
    if not nom:
        return ""
    try:
        return reverse(nom)
    except NoReverseMatch:
        return ""


def etat(site):
    """
    Les étapes, groupées dans l'ordre, chacune avec `fait`, `ignoree` et son
    adresse ; plus la progression sur les étapes qui comptent (obligatoires,
    et facultatives non écartées).
    """
    ignorees = set(site.mise_en_route_ignorees or []) if site else set()
    groupes, faites, comptees = [], 0, 0
    from jeiko.administration.modules import module_actif

    for etape in ETAPES:
        if etape.module and not module_actif(etape.module, site):
            continue
        regle = _sur(lambda: etape.fait(site)) if site else False
        a_eprouver = regle and etape.eprouve is not None and not _sur(lambda: etape.eprouve(site))
        fait = regle and not a_eprouver
        ignoree = etape.facultative and etape.code in ignorees and not regle
        if not ignoree:
            comptees += 1
            faites += fait
        ligne = {"etape": etape, "fait": fait, "a_eprouver": a_eprouver, "ignoree": ignoree,
                 "url": _url(etape.url_name)}
        if not groupes or groupes[-1]["nom"] != etape.groupe:
            groupes.append({"nom": etape.groupe, "etapes": []})
        groupes[-1]["etapes"].append(ligne)
    return {
        "groupes": groupes,
        "faites": faites,
        "comptees": comptees,
        "pourcent": round(100 * faites / comptees) if comptees else 100,
        "terminee": faites == comptees,
    }
