"""
Tâches planifiées — toutes les 30 minutes.

Lancé par le timer systemd jeiko-cron-30m@<site>.timer.

Jobs :
  - retour en stock : prévient les inscrits dont le produit est revenu
    (`shop.relances`) ;
  - agendas Google : leurs événements ferment les créneaux qu'ils
    chevauchent (`calendars.google_api.synchroniser_les_agendas`).

Pour en ajouter un : écrire une fonction `job_xxx()` qui retourne un court
résumé, puis l'inscrire dans `get_jobs()`.
"""
from jeiko.administration.management.commands._cron import CronCommand


def job_agendas_google():
    from jeiko.calendars.google_api import synchroniser_les_agendas
    reussis, echoues = synchroniser_les_agendas()
    return f"{reussis} agenda(s) Google importé(s), {echoues} en échec"


def job_retours_en_stock():
    from jeiko.shop.relances import prevenir_les_retours_en_stock
    return f"{prevenir_les_retours_en_stock()} alerte(s) de retour en stock envoyée(s)"


class Command(CronCommand):
    help = "Tâches planifiées à exécuter toutes les 30 minutes."
    cadence = "30m"

    def get_jobs(self):
        return [
            ("retour en stock", job_retours_en_stock),
            ("agendas Google → créneaux", job_agendas_google),
        ]
