# cookies/models.py
from __future__ import annotations

import uuid
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.sites.models import Site
from django.core.validators import RegexValidator, URLValidator, MinValueValidator
from django.db import models, transaction
from django.db.models import Q
from django.utils import timezone
from django.core.exceptions import ValidationError
from copy import deepcopy
from decimal import Decimal
from django.utils.translation import gettext_lazy as _

User = get_user_model()


# ---------- Helpers / Base ----------

def default_locale():
    # Ex: "fr" ou "fr-fr" selon settings.LANGUAGE_CODE
    return (getattr(settings, "LANGUAGE_CODE", "fr") or "fr").lower()


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(default=timezone.now, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


COOKIE_NAME_VALIDATOR = RegexValidator(
    regex=r"^[!#$%&'*+\-.\^_`|~0-9A-Za-z]+$",
    message=_("Nom de cookie invalide (RFC 6265)."),
)


class SameSite(models.TextChoices):
    LAX = "Lax", _("Lax")
    STRICT = "Strict", _("Strict")
    NONE = "None", _("None")
    UNSPECIFIED = "Unspecified", _("Unspecified")  # pour documentation uniquement


class ConsentSource(models.TextChoices):
    BANNER = "banner", _("Bannière")
    PANEL = "panel", _("Panneau de préférences")
    UPDATE = "update", _("Mise à jour")
    IMPORT = "import", _("Import / migration")


# ---------- Taxonomie ----------

class CookieCategory(TimeStampedModel):
    """
    Catégorie de cookies (ex: essential, analytics, marketing, preferences, ecommerce).
    """
    site = models.ForeignKey(Site, on_delete=models.CASCADE, related_name="cookie_categories")
    locale = models.CharField(max_length=16, default=default_locale, db_index=True)

    key = models.SlugField(max_length=50, db_index=True)  # ex: "essential", "analytics"
    label = models.CharField(max_length=120)
    description = models.TextField(blank=True)

    is_essential = models.BooleanField(default=False)   # non refusables
    is_active = models.BooleanField(default=True)
    default_enabled = models.BooleanField(
        default=False,
        help_text=_("État proposé par défaut dans l'UI (hors 'essential').")
    )
    display_order = models.PositiveIntegerField(default=100)
    #: L-16 — le libellé et la description dans les langues ajoutées, rangés EN
    #: PLACE (comme le nom d'une catégorie de pages) : {"en": {"label": …,
    #: "description": …}}. Une catégorie ne se duplique pas par langue — sa clé
    #: porte le consentement, il n'y en a qu'une.
    traductions = models.JSONField(default=dict, blank=True)

    class Meta:
        unique_together = (("site", "locale", "key"),)
        ordering = ["site_id", "locale", "display_order", "key"]

    def __str__(self):
        return f"{self.site.domain} [{self.locale}] · {self.key}"

    def _texte_pour(self, champ, locale):
        """
        Ce que lit un visiteur de `locale` : la traduction saisie, sinon le
        texte d'origine — passé par les catalogues de JEIKO, qui connaissent
        les libellés habituels (« Mesure d'audience »…) ; un texte
        personnalisé non traduit sort tel quel.
        """
        texte = getattr(self, champ)
        if not locale or locale == self.locale:
            return texte
        traductions = self.traductions or {}
        for code in (locale, locale.split("-")[0]):
            traduit = (traductions.get(code) or {}).get(champ)
            if traduit:
                return traduit
        if not texte:
            return texte
        from django.utils.translation import gettext, override

        with override(locale):
            return gettext(texte)

    def label_pour(self, locale):
        return self._texte_pour("label", locale)

    def description_pour(self, locale):
        return self._texte_pour("description", locale)


class CookieVendor(TimeStampedModel):
    """
    Fournisseur / tiers (ex: Stripe, YouTube, etc.), pour documenter la page 'Cookies'.
    """
    site = models.ForeignKey(Site, on_delete=models.CASCADE, related_name="cookie_vendors")
    name = models.CharField(max_length=120)
    website_url = models.URLField(blank=True, validators=[URLValidator()])
    privacy_url = models.URLField(blank=True, validators=[URLValidator()])
    description = models.TextField(blank=True)
    categories = models.ManyToManyField(CookieCategory, blank=True, related_name="vendors")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["site_id", "name"]

    def __str__(self):
        return f"{self.site.domain} · {self.name}"


class CookieDefinition(TimeStampedModel):
    """
    Fiche d'un cookie posé (pour la page 'Cookies') — purement documentaire.
    Ne 'crée' pas le cookie, mais décrit nom, finalité, durée, sécurité.
    """
    site = models.ForeignKey(Site, on_delete=models.CASCADE, related_name="cookie_definitions")
    locale = models.CharField(max_length=16, default=default_locale, db_index=True)

    name = models.CharField(max_length=128, validators=[COOKIE_NAME_VALIDATOR], db_index=True)  # ex: sessionid
    category = models.ForeignKey(CookieCategory, on_delete=models.PROTECT, related_name="definitions")
    vendor = models.ForeignKey(CookieVendor, null=True, blank=True, on_delete=models.SET_NULL, related_name="cookies")

    purpose = models.TextField(blank=True)
    duration_days = models.PositiveIntegerField(
        null=True, blank=True, validators=[MinValueValidator(0)],
        help_text=_("Durée indicative de conservation côté navigateur (jours). Laisser vide pour 'session'.")
    )

    # Attributs de sécurité (documentaires)
    is_http_only = models.BooleanField(default=True)
    is_secure = models.BooleanField(default=True)
    same_site = models.CharField(max_length=12, choices=SameSite.choices, default=SameSite.LAX)
    host_only = models.BooleanField(
        default=True,
        help_text=_("Host-only = sans attribut Domain (recommandé).")
    )
    path = models.CharField(max_length=255, default="/")
    domain = models.CharField(
        max_length=255, blank=True,
        help_text=_("Laisser vide si host-only.")
    )

    class Meta:
        unique_together = (("site", "locale", "name"),)
        ordering = ["site_id", "locale", "name"]

    def __str__(self):
        return f"{self.site.domain} [{self.locale}] · {self.name}"


# ---------- Version / Bannière (textes modifiables) ----------

class CookiePolicyVersion(TimeStampedModel):
    """
    Versionner le texte de politique cookies. Une 'active' par (site, locale).
    """
    site = models.ForeignKey(Site, on_delete=models.CASCADE, related_name="cookie_policy_versions")
    locale = models.CharField(max_length=16, default=default_locale, db_index=True)

    version = models.CharField(max_length=32, default="1.0")
    changelog = models.TextField(blank=True)
    published_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=False)

    class Meta:
        unique_together = (("site", "locale", "version"),)
        ordering = ["site_id", "locale", "-published_at", "-created_at"]

    def __str__(self):
        return f"{self.site.domain} [{self.locale}] · v{self.version}"

    def clean(self):
        # Assure unicité 'is_active' par (site, locale) (vérifiée à l’activation)
        super().clean()

    def activate(self):
        with transaction.atomic():
            CookiePolicyVersion.objects.filter(
                site=self.site, locale=self.locale, is_active=True
            ).exclude(pk=self.pk).update(is_active=False)
            self.is_active = True
            if not self.published_at:
                self.published_at = timezone.now()
            self.save(update_fields=["is_active", "published_at", "updated_at"])

# Clés autorisées et types attendus
ALLOWED_STYLE_SCHEMA = {
    "font_family": str,        # "system-ui" | "Inter" | ...
    "font_size_px": int,       # 10..24
    "line_height": float,      # 1.2..1.8
    "banner_bg": str,          # "#RRGGBB"
    "banner_fg": str,
    "link_color": str,
    "btn_radius_px": int,      # 0..24
    "btn_primary_bg": str,
    "btn_primary_fg": str,
    "btn_outline_fg": str,
    "btn_outline_border": str,
    "btn_ghost_fg": str,
    "modal_bg": str,
    "modal_fg": str,
    "modal_shadow": str,       # "none" | "sm" | "md" | "lg"
}

DEFAULT_BANNER_STYLE = {
    "font_family": "system-ui",
    "font_size_px": 14,
    "line_height": 1.45,
    "banner_bg": "#f5f7fa",
    "banner_fg": "#111827",
    "link_color": "#2563eb",
    "btn_radius_px": 8,
    "btn_primary_bg": "#e5e7eb",
    "btn_primary_fg": "#111827",
    "btn_outline_fg": "#111827",
    "btn_outline_border": "#cbd5e1",
    "btn_ghost_fg": "#334155",
    "modal_bg": "#ffffff",
    "modal_fg": "#111827",
    "modal_shadow": "lg",  # « mg » jusqu'au 07/10 : valeur inconnue, rendue « lg »
}

def default_banner_style():
    return deepcopy(DEFAULT_BANNER_STYLE)

def validate_banner_style(value):
    if not isinstance(value, dict):
        raise ValidationError(_("Le style doit être un objet JSON."))

    # Coercions légères pour éviter les soucis de types (Decimal, etc.)
    num_like = (int, float, Decimal)

    if "font_size_px" in value and not isinstance(value["font_size_px"], int):
        try:
            value["font_size_px"] = int(value["font_size_px"])
        except Exception:
            raise ValidationError(_("font_size_px doit être un entier."))

    if "btn_radius_px" in value and not isinstance(value["btn_radius_px"], int):
        try:
            value["btn_radius_px"] = int(value["btn_radius_px"])
        except Exception:
            raise ValidationError(_("btn_radius_px doit être un entier."))

    if "line_height" in value and not isinstance(value["line_height"], num_like):
        try:
            value["line_height"] = float(value["line_height"])
        except Exception:
            raise ValidationError(_("line_height doit être un nombre."))

    # Bornes
    if "font_size_px" in value and not (10 <= value["font_size_px"] <= 24):
        raise ValidationError(_("font_size_px doit être entre 10 et 24."))
    if "line_height" in value and not (1.2 <= float(value["line_height"]) <= 1.8):
        raise ValidationError(_("line_height doit être entre 1.2 et 1.8."))
    if "btn_radius_px" in value and not (0 <= value["btn_radius_px"] <= 24):
        raise ValidationError(_("btn_radius_px doit être entre 0 et 24."))
    if "modal_shadow" in value and value["modal_shadow"] not in {"none", "sm", "md", "lg"}:
        raise ValidationError(_("modal_shadow doit être parmi: none, sm, md, lg."))

class CookieBannerConfig(TimeStampedModel):
    """
    Configuration de la bannière : textes et labels modifiables par site/locale.
    """
    site = models.ForeignKey(Site, on_delete=models.CASCADE, related_name="cookie_banners")
    locale = models.CharField(max_length=16, default=default_locale, db_index=True)
    policy = models.ForeignKey(
        CookiePolicyVersion, null=True, blank=True, on_delete=models.SET_NULL,
        related_name="banners", help_text=_("Version de politique associée à cette bannière.")
    )

    # Textes modifiables :
    message_text = models.TextField(
        help_text=_("Texte principal de la bannière (bref).")
    )
    accept_all_label = models.CharField(max_length=80, default="Tout accepter")
    refuse_all_label = models.CharField(max_length=80, default="Tout refuser")
    customize_label = models.CharField(max_length=80, default="Personnaliser")
    save_choices_label = models.CharField(max_length=80, default="Enregistrer")
    more_info_label = models.CharField(max_length=80, default="En savoir plus")
    more_info_url = models.URLField(blank=True)

    show_refuse_all = models.BooleanField(default=True)
    is_active = models.BooleanField(default=False)
    priority = models.PositiveIntegerField(default=100)

    style = models.JSONField(default=default_banner_style, validators=[validate_banner_style])


    class Meta:
        ordering = ["site_id", "locale", "priority", "-updated_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["site", "locale"],
                condition=Q(is_active=True),
                name="unique_active_banner_per_site_locale",
            )
        ]

    def __str__(self):
        return f"{self.site.domain} [{self.locale}] · Banner ({'active' if self.is_active else 'inactive'})"

    @classmethod
    def get_active(cls, site: Site, locale: str | None = None) -> "CookieBannerConfig | None":
        qs = cls.objects.filter(site=site, is_active=True)
        if locale:
            qs = qs.filter(locale=locale.lower())
        return qs.order_by("priority", "-updated_at").first()

    def activate(self):
        with transaction.atomic():
            CookieBannerConfig.objects.filter(
                site=self.site, locale=self.locale, is_active=True
            ).exclude(pk=self.pk).update(is_active=False)
            self.is_active = True
            self.save(update_fields=["is_active", "updated_at"])

    def get_style(self) -> dict:
        """
        Retourne un dict de variables CSS valides.
        On n'impose pas la liste, mais on peut filtrer si besoin.
        """
        data = self.style or {}
        if not isinstance(data, dict):
            return {}
        # Optionnel: sanitation minimale (keys en str, values en str)
        out = {}
        for k, v in data.items():
            if isinstance(k, str) and k.startswith("--jk-"):
                out[k] = str(v)
        return out

# ---------- Consentements (preuves) ----------

class CookieConsent(TimeStampedModel):
    """
    Preuve de consentement (historisée).
    - user : optionnel (visiteur non connecté)
    - session_key : pour lier un anonyme (facultatif)
    - consent_token : identifiant public/partageable (UUID)
    - choices : JSON {category_key: bool}
    - policy_version : string (lié à CookiePolicyVersion.version au moment de l’accept)
    - is_latest : drapeau pour retrouver rapidement le dernier consentement
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    site = models.ForeignKey(Site, on_delete=models.CASCADE, related_name="cookie_consents")
    locale = models.CharField(max_length=16, default=default_locale, db_index=True)

    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="cookie_consents")
    session_key = models.CharField(max_length=64, blank=True, db_index=True)

    consent_token = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)

    ip_truncated = models.CharField(
        max_length=64, blank=True,
        help_text=_("IP tronquée (ex: 192.168.xxx.xxx ou /64 pour IPv6).")
    )
    user_agent = models.TextField(blank=True)

    choices = models.JSONField(default=dict)  # ex: {"essential": True, "analytics": False}
    policy_version = models.CharField(max_length=32, default="1.0")
    source = models.CharField(max_length=16, choices=ConsentSource.choices, default=ConsentSource.BANNER)

    is_latest = models.BooleanField(default=True, db_index=True)

    class Meta:
        indexes = [
            models.Index(fields=["site", "locale"]),
            models.Index(fields=["user", "created_at"]),
            models.Index(fields=["session_key", "created_at"]),
            models.Index(fields=["is_latest", "created_at"]),
        ]
        ordering = ["-created_at"]

    def __str__(self):
        who = self.user or self.session_key or "anon"
        return f"{self.site.domain} [{self.locale}] · {who} · v{self.policy_version}"

    def save(self, *args, **kwargs):
        """
        Garantit qu'il n'y a qu'un seul 'is_latest=True' par {site, locale, user|session}.
        """
        # `self.pk is None` ne détecte PAS une création ici : la clé primaire est
        # un UUIDField avec `default=uuid.uuid4`, donc renseignée dès
        # l'instanciation. Le test était toujours faux et ce dédoublonnage ne
        # s'exécutait jamais — tous les consentements d'un même visiteur
        # restaient marqués « courant », et plus rien n'indiquait lequel faisait
        # foi. `_state.adding` est le drapeau que Django tient à jour pour ça ;
        # il doit être lu AVANT super().save(), qui le repasse à False.
        new_record = self._state.adding
        super().save(*args, **kwargs)
        if new_record and self.is_latest:
            with transaction.atomic():
                q = CookieConsent.objects.filter(
                    site=self.site,
                    locale=self.locale,
                    is_latest=True,
                ).exclude(pk=self.pk)

                if self.user_id:
                    q = q.filter(user_id=self.user_id)
                elif self.session_key:
                    q = q.filter(user__isnull=True, session_key=self.session_key)
                else:
                    # visiteur totalement anonyme : on ne sait pas isoler un groupe précis
                    q = q.none()

                q.update(is_latest=False)


# ---------- Réglages applicatifs ----------

class CookieAppSettings(TimeStampedModel):
    """
    Réglages globaux par site/locale, pour piloter le comportement serveur/JS.
    (Ne remplace pas settings.py, mais sert de configuration métier.)
    """
    site = models.OneToOneField(Site, on_delete=models.CASCADE, related_name="cookie_app_settings")
    locale = models.CharField(max_length=16, default=default_locale)

    # Rétention des preuves de consentement (jours)
    retention_days = models.PositiveIntegerField(default=730)

    # Analytics maison : désactiver pour staff/superuser
    disable_tracking_for_staff = models.BooleanField(default=True)
    disable_tracking_for_superusers = models.BooleanField(default=True)

    # Valeurs par défaut documentaires
    default_same_site = models.CharField(max_length=12, choices=SameSite.choices, default=SameSite.LAX)
    default_secure = models.BooleanField(default=True)
    default_http_only = models.BooleanField(default=True)

    class Meta:
        verbose_name = _("Réglages de l'app Cookies")

    def __str__(self):
        return f"{self.site.domain} · settings"

    @property
    def retention_timedelta(self):
        return timezone.timedelta(days=self.retention_days)
