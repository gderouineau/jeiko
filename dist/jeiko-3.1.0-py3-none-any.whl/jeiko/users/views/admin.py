# users/views_admin.py

from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db import transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse, reverse_lazy
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views import View
from django.views.generic import (
    ListView, DetailView, UpdateView, CreateView, DeleteView, FormView
)

from jeiko.questionnaires_expert.models import ExpertTestData, Prospect

# --- Forms (site-admin) ---
from jeiko.users.forms_admin import (
    # Users
    AdminUserFilterForm, AdminUserEditForm, AdminUserCreateForm,
    # Roles & perms
    RoleForm, RolePermissionForm, RoleAssignmentForm,
    BulkAssignRoleForm, BulkRevokeRoleForm,
    # Providers
    ProviderConfigForm,
    # Sécurité & sessions
    TwoFactorDeviceForm, TwoFactorToggleForm, UserSessionRevokeForm, SecurityEventFilterForm,
    # Consent & prefs
    ConsentForm, MarketingPreferenceForm,
    # Notifications
    NotificationChannelForm, NotificationComposeForm, BulkNotificationForm,
    # Bridge
    ProspectLinkForm,
)

# --- Models ---
from jeiko.users.models import (
    Role, RolePermission, RoleAssignment,
    ProviderConfig,
    TwoFactorDevice, SecurityEvent, UserSession,
    Consent, MarketingPreference,
    NotificationChannel, Notification,
    ProspectLink,
)

User = get_user_model()

decorators = [never_cache]
# ----------------------------------------------------------
#  Mixins & helpers
# ----------------------------------------------------------

def back(request, fallback_name, **kwargs):
    """
    Redirige vers referer sinon vers une named url fallback.
    """
    return redirect(request.META.get("HTTP_REFERER") or reverse(fallback_name, kwargs=kwargs))


def _client_ip(request):
    xff = request.META.get("HTTP_X_FORWARDED_FOR", "")
    if xff:
        return xff.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR")


def _log_security_event(request, target_user, event_type, extra=None):
    """
    Journalise un événement sécurité (audit). L'utilisateur enregistré est la
    personne concernée par le changement ; l'auteur de l'action est tracé dans
    ``extra['by']``.
    """
    try:
        SecurityEvent.objects.create(
            user=target_user,
            event_type=event_type,
            ip_address=_client_ip(request),
            user_agent=request.META.get("HTTP_USER_AGENT", ""),
            extra={**(extra or {}), "by": getattr(request.user, "pk", None)},
        )
    except Exception:
        # L'audit ne doit jamais casser l'action métier.
        pass


# ----------------------------------------------------------
#  Utilisateurs (ta base existante)
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class AdminUserListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = User
    template_name = "users/admin/user/list.html"
    context_object_name = "users"
    paginate_by = 25

    permission_required = 'auth.view_user'
    raise_exception = True

    def get_queryset(self):
        qs = super().get_queryset().prefetch_related('groups', 'role_assignments__role')
        form = AdminUserFilterForm(self.request.GET)
        if form.is_valid():
            cd = form.cleaned_data
            if cd.get('search'):
                qs = qs.filter(Q(username__icontains=cd['search']) | Q(email__icontains=cd['search']))
            if cd.get('is_active') in ('0', '1'):
                qs = qs.filter(is_active=bool(int(cd['is_active'])))
            if cd.get('group'):
                qs = qs.filter(groups=cd['group'])
            if cd.get('role'):
                qs = qs.filter(role_assignments__role=cd['role'])
            if cd.get('date_joined_from'):
                qs = qs.filter(date_joined__gte=cd['date_joined_from'])
            if cd.get('date_joined_to'):
                qs = qs.filter(date_joined__lte=cd['date_joined_to'])
        return qs.order_by('-date_joined')

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['form'] = AdminUserFilterForm(self.request.GET)
        ctx['roles'] = Role.objects.filter(is_active=True)
        return ctx


@method_decorator(never_cache, name='dispatch')
class AdminUserDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = User
    context_object_name = 'user_obj'
    template_name = 'users/admin/user/detail.html'

    permission_required = 'auth.view_user'
    raise_exception = True

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        from jeiko.calendars.models import Appointment
        from jeiko.courses.models import CourseEnrollment
        from django.utils import timezone
        ctx['appointments'] = (
            Appointment.objects
            .filter(user=self.object)
            .select_related('type', 'slot')
            .order_by('-start')
        )
        ctx['now'] = timezone.now()
        # Le gestionnaire ne peut créer un RDV que si son calendrier propose des
        # créneaux : le lien de création n'a de sens qu'avec la permission.
        ctx['can_add_appointment'] = self.request.user.has_perm('calendars.add_appointment')
        # La présence d'un RDV passé ne se marque qu'avec le droit de le modifier.
        ctx['can_mark_attendance'] = self.request.user.has_perm('calendars.change_appointment')
        # Inscriptions aux formations : progression + gestion de l'accès.
        ctx['enrollments'] = (
            CourseEnrollment.objects
            .filter(user=self.object)
            .select_related('course', 'granted_by')
            .order_by('-enrolled_at')
        )
        ctx['can_manage_courses'] = self.request.user.has_perm('courses.change_courseenrollment')
        # Actions périphériques : n'afficher les boutons que si la permission suit.
        ctx['can_grant_test_access'] = self.request.user.has_perm('questionnaires_expert.add_usertestaccess')
        ctx['can_revoke_test_access'] = self.request.user.has_perm('questionnaires_expert.delete_usertestaccess')
        ctx['tabs'] = [
            ('infos', 'Informations'),
            ('cours', 'Formations'),
            ('rdv', 'Rendez-vous'),
            ('questionnaires', 'Questionnaires'),
        ]
        ctx['test_datas'] = ExpertTestData.objects.filter(user=self.object)
        ctx['test_accesses'] = UserTestAccess.objects.filter(user=self.object).select_related('test', 'granted_by')
        ctx['role_assignments'] = RoleAssignment.objects.filter(user=self.object).select_related('role')
        ctx['prospect_links'] = ProspectLink.objects.filter(user=self.object).select_related('prospect')
        ctx['sessions'] = UserSession.objects.filter(user=self.object, is_active=True).order_by('-last_seen')
        ctx['twofa_devices'] = TwoFactorDevice.objects.filter(user=self.object, is_active=True)
        return ctx


@method_decorator(never_cache, name='dispatch')
class AdminUserDataExportView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Export RGPD (droit d'accès / portabilité) d'un utilisateur donné, pour traiter
    une demande reçue hors ligne. Gardé par la même permission que la fiche.
    """
    permission_required = 'auth.view_user'
    raise_exception = True

    def get(self, request, pk):
        import json
        from django.http import HttpResponse
        from jeiko.users.rgpd import build_user_export, export_filename

        target = get_object_or_404(User, pk=pk)
        body = json.dumps(build_user_export(target), ensure_ascii=False, indent=2)
        response = HttpResponse(body, content_type="application/json")
        response["Content-Disposition"] = (
            f'attachment; filename="{export_filename(target)}"'
        )
        return response


@method_decorator(never_cache, name='dispatch')
class AdminUserDataDeleteView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Effacement RGPD (droit à l'oubli) d'un utilisateur, pour traiter une demande
    reçue hors ligne. Irréversible : confirmation par saisie de « SUPPRIMER ».
    Garde-fous : ni un superutilisateur, ni son propre compte (passer par
    l'espace personnel pour ce dernier).
    """
    permission_required = 'auth.delete_user'
    raise_exception = True
    template_name = 'users/admin/user/delete_confirm.html'

    def _guard(self, request, target):
        if target.is_superuser:
            messages.error(request, "Un superutilisateur ne peut pas être effacé ainsi.")
            return redirect('jeiko_administration_users:user_detail', pk=target.pk)
        if target.pk == request.user.pk:
            messages.error(request, "Pour votre propre compte, utilisez votre espace personnel.")
            return redirect('jeiko_administration_users:user_detail', pk=target.pk)
        return None

    def get(self, request, pk):
        target = get_object_or_404(User, pk=pk)
        blocked = self._guard(request, target)
        if blocked:
            return blocked
        return render(request, self.template_name, {'user_obj': target})

    def post(self, request, pk):
        from jeiko.users.rgpd import erase_user_data, notify_account_deactivated
        target = get_object_or_404(User, pk=pk)
        blocked = self._guard(request, target)
        if blocked:
            return blocked
        if (request.POST.get('confirm') or '').strip().upper() != 'SUPPRIMER':
            messages.error(request, "Veuillez saisir « SUPPRIMER » pour confirmer.")
            return render(request, self.template_name, {'user_obj': target})
        old_email, _summary = erase_user_data(target, actor=request.user, reason="admin")
        notify_account_deactivated(old_email)
        messages.success(request, "Données de l'utilisateur effacées ; compte désactivé.")
        return redirect('jeiko_administration_users:user_list')


@method_decorator(never_cache, name='dispatch')
class AdminUserCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    """
    Création d'un utilisateur depuis l'administration.

    Le compte naît sans mot de passe utilisable ; l'utilisateur définit le sien
    via le lien envoyé par account_created_by_admin. L'e-mail part APRÈS COMMIT
    (le lien contient un jeton lié au pk : la ligne doit exister en base).
    """
    model = User
    form_class = AdminUserCreateForm
    template_name = 'users/admin/user/create.html'
    success_url = reverse_lazy('jeiko_administration_users:user_list')

    permission_required = 'auth.add_user'
    raise_exception = True

    def form_valid(self, form):
        user = form.save(commit=False)
        user.set_unusable_password()
        user.is_active = True
        user.save()
        self.object = user

        from jeiko.users import emailing as account_emailing
        transaction.on_commit(
            lambda: account_emailing.send_account_created_by_admin(user, self.request)
        )
        messages.success(
            self.request,
            f"Utilisateur « {user.username} » créé. Un e-mail lui a été envoyé "
            "pour définir son mot de passe.",
        )
        return redirect(self.get_success_url())


class AdminUserUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = User
    form_class = AdminUserEditForm
    context_object_name = 'user_obj'
    template_name = 'users/admin/user/form.html'
    success_url = reverse_lazy('jeiko_administration_users:user_list')

    permission_required = 'auth.change_user'
    raise_exception = True

    def get_form_kwargs(self):
        kw = super().get_form_kwargs()
        kw["request"] = self.request
        return kw

    def form_valid(self, form):
        # État en base avant enregistrement, pour détecter une désactivation.
        was_active = User.objects.filter(pk=self.object.pk).values_list(
            'is_active', flat=True).first()
        response = super().form_valid(form)
        if was_active and not self.object.is_active:
            from jeiko.users import emailing as account_emailing
            account_emailing.notify_account_deactivated(self.object)
        return response

# ----------------------------------------------------------
#  Rôles & permissions
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class RoleListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Role
    template_name = "users/admin/roles/list.html"
    context_object_name = "roles"

    permission_required = 'users.view_role'
    raise_exception = True

    def get_queryset(self):
        return Role.objects.all().order_by("name")


@method_decorator(never_cache, name='dispatch')
class RoleCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Role
    form_class = RoleForm
    template_name = "users/admin/roles/form.html"

    permission_required = 'users.add_role'
    raise_exception = True

    def get_form_kwargs(self):
        kw = super().get_form_kwargs()
        kw["request"] = self.request
        return kw

    def get_success_url(self):
        messages.success(self.request, "Rôle créé.")
        return reverse('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class RoleUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Role
    form_class = RoleForm
    template_name = "users/admin/roles/form.html"

    permission_required = 'users.change_role'
    raise_exception = True

    def get_form_kwargs(self):
        kw = super().get_form_kwargs()
        kw["request"] = self.request
        return kw

    def get_success_url(self):
        messages.success(self.request, "Rôle mis à jour.")
        return reverse('jeiko_administration_users:role_list')



@method_decorator(never_cache, name='dispatch')
class RoleDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Role
    template_name = "users/admin/roles/confirm_delete.html"

    permission_required = 'users.delete_role'
    raise_exception = True

    def dispatch(self, request, *args, **kwargs):
        # Un rôle protégé (ex. Administrateur) ne peut pas être supprimé.
        self.object = self.get_object()
        if self.object.is_protected:
            messages.error(request, "Ce rôle est protégé et ne peut pas être supprimé.")
            return redirect('jeiko_administration_users:role_list')
        return super().dispatch(request, *args, **kwargs)

    def get_success_url(self):
        messages.success(self.request, "Rôle supprimé.")
        return reverse('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class RolePermissionCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = RolePermission
    form_class = RolePermissionForm
    template_name = "users/admin/roles/role_permission_form.html"
    permission_required = 'users.change_role'
    raise_exception = True

    def get_initial(self):
        initial = super().get_initial()
        role_id = self.request.GET.get('role')
        if role_id:
            initial['role'] = get_object_or_404(Role, pk=role_id)
        return initial

    def get_success_url(self):
        messages.success(self.request, "Permission ajoutée au rôle.")
        return reverse('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class RolePermissionDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = RolePermission
    template_name = "users/admin/roles/role_permission_confirm_delete.html"
    permission_required = 'users.change_role'
    raise_exception = True

    def get_success_url(self):
        messages.success(self.request, "Permission retirée du rôle.")
        return reverse('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class RoleAssignmentCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = RoleAssignment
    form_class = RoleAssignmentForm
    template_name = "users/admin/roles/role_assignment_form.html"
    permission_required = 'users.assign_role'
    raise_exception = True

    def form_valid(self, form):
        form.instance.assigned_by = self.request.user
        response = super().form_valid(form)
        _log_security_event(
            self.request, self.object.user, 'role_changed',
            {"action": "assign", "role": self.object.role.slug}
        )
        return response

    def get_initial(self):
        initial = super().get_initial()
        user_id = self.request.GET.get('user')
        role_id = self.request.GET.get('role')
        if user_id:
            initial['user'] = get_object_or_404(User, pk=user_id)
        if role_id:
            initial['role'] = get_object_or_404(Role, pk=role_id)
        return initial

    def get_success_url(self):
        messages.success(self.request, "Rôle assigné.")
        return reverse('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class RoleAssignmentDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = RoleAssignment
    template_name = "users/admin/roles/role_assignment_confirm_delete.html"
    permission_required = 'users.assign_role'
    raise_exception = True

    def dispatch(self, request, *args, **kwargs):
        # Anti-lockout : on ne retire jamais la dernière assignation active à un
        # super-rôle, sous peine de laisser le site sans administrateur applicatif.
        self.object = self.get_object()
        if self.object.role.is_superrole:
            remaining = RoleAssignment.objects.filter(
                role__is_superrole=True, role__is_active=True
            ).exclude(pk=self.object.pk).count()
            if remaining == 0:
                messages.error(
                    request,
                    "Impossible : c'est la dernière personne disposant d'un rôle "
                    "d'administrateur. Assignez d'abord ce rôle à quelqu'un d'autre."
                )
                return redirect('jeiko_administration_users:user_detail', pk=self.object.user_id)
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        _log_security_event(
            self.request, self.object.user, 'role_changed',
            {"action": "revoke", "role": self.object.role.slug}
        )
        return super().form_valid(form)

    def get_success_url(self):
        messages.success(self.request, "Assignation supprimée.")
        return back(self.request, 'jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class BulkAssignRoleView(LoginRequiredMixin, PermissionRequiredMixin, FormView):
    form_class = BulkAssignRoleForm
    template_name = "users/admin/roles/role_bulk_assign.html"
    permission_required = 'users.assign_role'
    raise_exception = True

    def form_valid(self, form):
        user_ids = form.cleaned_data['user_ids']
        role = form.cleaned_data['role']
        users = User.objects.filter(id__in=user_ids)
        created = 0
        for u in users:
            _, was_created = RoleAssignment.objects.get_or_create(
                user=u, role=role, defaults={'assigned_by': self.request.user}
            )
            if was_created:
                created += 1
                _log_security_event(
                    self.request, u, 'role_changed',
                    {"action": "assign", "role": role.slug, "bulk": True}
                )
        messages.success(
            self.request,
            f"{created} assignation(s) créée(s) sur {users.count()} utilisateur(s) sélectionné(s)."
        )
        return redirect('jeiko_administration_users:user_list')


@method_decorator(never_cache, name='dispatch')
class BulkRevokeRoleView(LoginRequiredMixin, PermissionRequiredMixin, FormView):
    form_class = BulkRevokeRoleForm
    template_name = "users/admin/roles/role_bulk_revoke.html"
    permission_required = 'users.assign_role'
    raise_exception = True

    def form_valid(self, form):
        user_ids = form.cleaned_data['user_ids']
        role = form.cleaned_data['role']
        qs = RoleAssignment.objects.filter(user_id__in=user_ids, role=role)

        # Anti-lockout : ne jamais retirer en masse la totalité des porteurs
        # d'un super-rôle s'il ne resterait plus personne d'autre.
        if role.is_superrole:
            remaining = (
                RoleAssignment.objects
                .filter(role__is_superrole=True, role__is_active=True)
                .exclude(pk__in=qs.values_list('pk', flat=True))
                .count()
            )
            if remaining == 0:
                messages.error(
                    self.request,
                    "Impossible : cela retirerait le rôle d'administrateur à tout le "
                    "monde. Conservez au moins un administrateur."
                )
                return redirect('jeiko_administration_users:user_list')

        affected_user_ids = list(qs.values_list('user_id', flat=True))
        count = qs.count()
        qs.delete()
        for uid in affected_user_ids:
            _log_security_event(
                self.request, User.objects.filter(pk=uid).first(), 'role_changed',
                {"action": "revoke", "role": role.slug, "bulk": True}
            )
        messages.success(self.request, f"{count} assignation(s) supprimée(s).")
        return redirect('jeiko_administration_users:user_list')


# ----------------------------------------------------------
#  Providers (allauth)
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class ProviderListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = ProviderConfig
    template_name = "users/admin/providers/list.html"
    context_object_name = "providers"
    ordering = ("provider", "label")

    permission_required = 'users.view_providerconfig'
    raise_exception = True


@method_decorator(never_cache, name='dispatch')
class ProviderCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = ProviderConfig
    form_class = ProviderConfigForm
    template_name = "users/admin/providers/form.html"

    permission_required = 'users.add_providerconfig'
    raise_exception = True


    def get_success_url(self):
        messages.success(self.request, "Provider enregistré.")
        return reverse('jeiko_administration_users:provider_list')


@method_decorator(never_cache, name='dispatch')
class ProviderUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = ProviderConfig
    form_class = ProviderConfigForm
    template_name = "users/admin/providers/form.html"

    permission_required = 'users.change_providerconfig'
    raise_exception = True

    def get_success_url(self):
        messages.success(self.request, "Provider mis à jour.")
        return reverse('jeiko_administration_users:provider_list')


@method_decorator(never_cache, name='dispatch')
class ProviderDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = ProviderConfig
    template_name = "users/admin/providers/confirm_delete.html"

    permission_required = 'users.delete_providerconfig'
    raise_exception = True


    def get_success_url(self):
        messages.success(self.request, "Provider supprimé.")
        return reverse('jeiko_administration_users:provider_list')


# ----------------------------------------------------------
#  Sécurité : 2FA, sessions, audit
# ----------------------------------------------------------
@method_decorator(never_cache, name='dispatch')
class TwoFactorDeviceListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    permission_required = "users.view_twofactordevice"
    raise_exception = True
    model = TwoFactorDevice
    template_name = "users/admin/security/twofa_list.html"
    context_object_name = "devices"
    ordering = ("-updated_at",)


@method_decorator(never_cache, name='dispatch')
class TwoFactorDeviceCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    permission_required = "users.add_twofactordevice"
    raise_exception = True
    model = TwoFactorDevice
    form_class = TwoFactorDeviceForm
    template_name = "users/admin/security/twofa_form.html"

    def get_success_url(self):
        messages.success(self.request, "Dispositif 2FA créé.")
        return reverse('jeiko_administration_users:twofa_list')


@method_decorator(never_cache, name='dispatch')
class TwoFactorDeviceUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    permission_required = "users.change_twofactordevice"
    raise_exception = True
    model = TwoFactorDevice
    form_class = TwoFactorDeviceForm
    template_name = "users/admin/security/twofa_form.html"

    def get_success_url(self):
        messages.success(self.request, "Dispositif 2FA mis à jour.")
        return reverse('jeiko_administration_users:twofa_list')


@method_decorator(never_cache, name='dispatch')
class TwoFactorDeviceDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    permission_required = "users.delete_twofactordevice"
    raise_exception = True
    model = TwoFactorDevice
    template_name = "users/admin/security/twofa_confirm_delete.html"

    def get_success_url(self):
        messages.success(self.request, "Dispositif 2FA supprimé.")
        return reverse('jeiko_administration_users:twofa_list')


@method_decorator(never_cache, name='dispatch')
class UserSessionRevokeView(LoginRequiredMixin, PermissionRequiredMixin, FormView):
    permission_required = "users.change_usersession"
    raise_exception = True
    form_class = UserSessionRevokeForm
    template_name = "users/admin/security/session_revoke.html"

    def form_valid(self, form):
        ids = form.cleaned_data['session_ids']
        count = UserSession.objects.filter(id__in=ids).update(is_active=False)
        messages.success(self.request, f"{count} session(s) révoquées.")
        return back(self.request, 'jeiko_administration_users:user_list')


@method_decorator(never_cache, name='dispatch')
class SecurityEventListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    permission_required = "users.view_securityevent"
    raise_exception = True
    model = SecurityEvent
    template_name = "users/admin/security/security_event_list.html"
    context_object_name = "events"
    paginate_by = 50
    ordering = ("-occured_at",)

    def get_queryset(self):
        qs = super().get_queryset().select_related('user')
        form = SecurityEventFilterForm(self.request.GET)
        if form.is_valid():
            cd = form.cleaned_data
            if cd.get('user'):
                qs = qs.filter(user=cd['user'])
            if cd.get('event_type'):
                qs = qs.filter(event_type=cd['event_type'])
            if cd.get('date_from'):
                qs = qs.filter(occured_at__gte=cd['date_from'])
            if cd.get('date_to'):
                qs = qs.filter(occured_at__lte=cd['date_to'])
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['form'] = SecurityEventFilterForm(self.request.GET)
        return ctx


# ----------------------------------------------------------
#  Consentements & préférences
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class ConsentCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    permission_required = "users.add_consent"
    raise_exception = True
    model = Consent
    form_class = ConsentForm
    template_name = "users/admin/consent/form.html"

    def get_success_url(self):
        messages.success(self.request, "Consentement enregistré.")
        return back(self.request, 'jeiko_administration_users:consent_create')


@method_decorator(never_cache, name='dispatch')
class MarketingPreferenceUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    permission_required = "users.change_marketingpreference"
    raise_exception = True
    model = MarketingPreference
    form_class = MarketingPreferenceForm
    template_name = "users/admin/consent/marketing_pref_form.html"

    def get_success_url(self):
        messages.success(self.request, "Préférences marketing mises à jour.")
        return back(self.request, 'jeiko_administration_users:user_list')


# ----------------------------------------------------------
#  Notifications
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class NotificationChannelCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    permission_required = "users.add_notificationchannel"
    raise_exception = True
    model = NotificationChannel
    form_class = NotificationChannelForm
    template_name = "users/admin/notifications/channel_form.html"

    def get_success_url(self):
        messages.success(self.request, "Canal de notification enregistré.")
        return back(self.request, 'jeiko_administration_users:user_list')


@method_decorator(never_cache, name='dispatch')
class NotificationComposeView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    permission_required = "users.add_notification"
    raise_exception = True
    model = Notification
    form_class = NotificationComposeForm
    template_name = "users/admin/notifications/form.html"

    def get_success_url(self):
        messages.success(self.request, "Notification enregistrée.")
        return back(self.request, 'jeiko_administration_users:user_list')


@method_decorator(never_cache, name='dispatch')
class BulkNotificationView(LoginRequiredMixin, PermissionRequiredMixin, FormView):
    permission_required = "users.add_notification"
    raise_exception = True
    form_class = BulkNotificationForm
    template_name = "users/admin/notifications/notification_bulk_form.html"

    def form_valid(self, form):
        ids = form.cleaned_data['user_ids']
        notif_type = form.cleaned_data['notif_type']
        payload = form.cleaned_data.get('payload') or ""
        users = User.objects.filter(id__in=ids)
        created = 0
        for u in users:
            Notification.objects.create(user=u, notif_type=notif_type, payload={"body": payload})
            created += 1
        messages.success(self.request, f"{created} notification(s) créées.")
        return back(self.request, 'jeiko_administration_users:user_list')


# ----------------------------------------------------------
#  Bridge User ↔ Prospect
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class ProspectLinkCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    permission_required = "questionnaires_expert.change_prospect"
    raise_exception = True
    model = ProspectLink
    form_class = ProspectLinkForm
    template_name = "users/admin/prospects/prospect_link_form.html"

    def get_initial(self):
        initial = super().get_initial()
        user_id = self.request.GET.get('user')
        prospect_id = self.request.GET.get('prospect')
        if user_id:
            initial['user'] = get_object_or_404(User, pk=user_id)
        if prospect_id:
            initial['prospect'] = get_object_or_404(Prospect, pk=prospect_id)
        return initial

    def get_success_url(self):
        messages.success(self.request, "Lien User ↔ Prospect créé.")
        return back(self.request, 'jeiko_administration_users:user_list')


@method_decorator(never_cache, name='dispatch')
class ProspectLinkDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    permission_required = "questionnaires_expert.change_prospect"
    raise_exception = True
    model = ProspectLink
    template_name = "users/admin/prospects/prospect_link_confirm_delete.html"

    def get_success_url(self):
        messages.success(self.request, "Lien User ↔ Prospect supprimé.")
        return back(self.request, 'jeiko_administration_users:user_list')


# ----------------------------------------------------------
#  User Test Access
# ----------------------------------------------------------

from jeiko.questionnaires_expert.models import UserTestAccess
from jeiko.users.forms_admin import UserTestAccessForm

@method_decorator(never_cache, name='dispatch')
class UserTestAccessCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    permission_required = "questionnaires_expert.add_usertestaccess"
    raise_exception = True
    model = UserTestAccess
    form_class = UserTestAccessForm
    template_name = "users/admin/user/test_access_form.html"

    def get_initial(self):
        initial = super().get_initial()
        user_id = self.request.GET.get('user')
        if user_id:
            initial['user'] = get_object_or_404(User, pk=user_id)
        return initial

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user_id = self.request.GET.get('user')
        if user_id:
            context['user_obj'] = get_object_or_404(User, pk=user_id)
        return context

    def form_valid(self, form):
        form.instance.granted_by = self.request.user
        return super().form_valid(form)

    def get_success_url(self):
        messages.success(self.request, "Accès au test accordé.")
        return reverse('jeiko_administration_users:user_detail', args=[self.object.user.id])


@method_decorator(never_cache, name='dispatch')
class UserTestAccessDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    permission_required = "questionnaires_expert.delete_usertestaccess"
    raise_exception = True
    model = UserTestAccess
    template_name = "users/admin/user/test_access_confirm_delete.html"

    def get_success_url(self):
        messages.success(self.request, "Accès au test révoqué.")
        return reverse('jeiko_administration_users:user_detail', args=[self.object.user.id])
