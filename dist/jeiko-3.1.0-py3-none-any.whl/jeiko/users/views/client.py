import json

from django.urls import reverse_lazy
from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views import View
from django.views.generic import DetailView, UpdateView, ListView, CreateView, DeleteView
from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponse

from django.utils import timezone

from ..forms import ProfileForm, AddressForm
from ..models import Profile, Address
from ..rgpd import build_user_export, export_filename, erase_user_data, notify_account_deactivated
from jeiko.shop.models import Order
from jeiko.courses.models import CourseEnrollment
from jeiko.calendars.models import Appointment
from jeiko.questionnaires_expert.models import ExpertTestData, UserTestAccess

class ProfileDetailView(LoginRequiredMixin, DetailView):
    model = Profile
    template_name = 'users/client/profile_detail.html'

    def get_object(self):
        # Crée le profile si l'utilisateur n'en a pas déjà un
        profile, created = Profile.objects.get_or_create(user=self.request.user)
        return profile

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        # Commandes
        context['orders'] = Order.objects.filter(user=user).order_by('-created_at')
        # Adresses
        context['addresses'] = Address.objects.filter(user=user)
        # Formations : accès actifs ou terminés (les suspendus restent masqués côté client)
        context['enrollments'] = (
            CourseEnrollment.objects
            .filter(user=user, status__in=[CourseEnrollment.STATUS_ACTIVE,
                                           CourseEnrollment.STATUS_COMPLETED])
            .select_related('course')
            .order_by('-enrolled_at')
        )
        # Rendez-vous liés au compte
        context['appointments'] = (
            Appointment.objects
            .filter(user=user)
            .select_related('type')
            .order_by('-start')
        )
        context['now'] = timezone.now()
        # Questionnaires passés (avec lien vers le résultat porté par le jeton)
        context['test_datas'] = (
            ExpertTestData.objects
            .filter(user=user)
            .select_related('test', 'result_profile')
            .order_by('-created_at')
        )
        # Questionnaires auxquels l'utilisateur a accès (à démarrer)
        context['available_tests'] = (
            UserTestAccess.objects
            .filter(user=user)
            .select_related('test')
            .order_by('test__title')
        )
        return context


class ProfileUpdateView(LoginRequiredMixin, UpdateView):
    model = Profile
    form_class = ProfileForm
    template_name = 'users/client/profile_form.html'
    success_url = reverse_lazy('jeiko_users_client:profile-detail')

    def get_object(self):
        profile, created = Profile.objects.get_or_create(user=self.request.user)
        return profile

class ProfileDataExportView(LoginRequiredMixin, View):
    """
    Droit d'accès / portabilité (RGPD art. 15 & 20) en self-service : télécharge
    toutes ses propres données au format JSON. On n'exporte que le compte connecté.
    """
    def get(self, request):
        payload = build_user_export(request.user)
        body = json.dumps(payload, ensure_ascii=False, indent=2)
        response = HttpResponse(body, content_type="application/json")
        response["Content-Disposition"] = (
            f'attachment; filename="{export_filename(request.user)}"'
        )
        return response


class ProfileDataDeleteView(LoginRequiredMixin, View):
    """
    Droit à l'oubli (RGPD art. 17) en self-service. Irréversible : on exige une
    confirmation explicite (saisie du mot « SUPPRIMER »). Les commandes/factures
    sont anonymisées, pas supprimées (obligation légale).
    """
    template_name = "users/client/profile_delete_confirm.html"

    def get(self, request):
        return render(request, self.template_name)

    def post(self, request):
        if (request.POST.get("confirm") or "").strip().upper() != "SUPPRIMER":
            messages.error(request, "Veuillez saisir « SUPPRIMER » pour confirmer.")
            return render(request, self.template_name)
        old_email, _summary = erase_user_data(
            request.user, actor=request.user, reason="self-service"
        )
        notify_account_deactivated(old_email)
        logout(request)
        messages.success(
            request,
            "Votre compte et vos données personnelles ont été supprimés. "
            "Les documents comptables obligatoires sont conservés sous forme anonymisée."
        )
        return redirect("/")


class OrderDetailView(LoginRequiredMixin, DetailView):
    model = Order
    template_name = 'users/client/order_detail.html'
    context_object_name = 'order'

    def get_queryset(self):
        # Ensure user can only see their own orders
        return Order.objects.filter(user=self.request.user)


# =========================
#  Address Views
# =========================

class AddressListView(LoginRequiredMixin, ListView):
    model = Address
    template_name = 'users/client/address_list.html'
    context_object_name = 'addresses'

    def get_queryset(self):
        return Address.objects.filter(user=self.request.user)


class AddressCreateView(LoginRequiredMixin, CreateView):
    model = Address
    form_class = AddressForm
    template_name = 'users/client/address_form.html'
    success_url = reverse_lazy('jeiko_users_client:profile-detail') # Or address list

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


class AddressUpdateView(LoginRequiredMixin, UpdateView):
    model = Address
    form_class = AddressForm
    template_name = 'users/client/address_form.html'
    success_url = reverse_lazy('jeiko_users_client:profile-detail')

    def get_queryset(self):
        return Address.objects.filter(user=self.request.user)


class AddressDeleteView(LoginRequiredMixin, DeleteView):
    model = Address
    template_name = 'users/client/address_confirm_delete.html' # Optional, can use a modal or simple post
    success_url = reverse_lazy('jeiko_users_client:profile-detail')

    def get_queryset(self):
        return Address.objects.filter(user=self.request.user)
