# jeiko/users/adapters.py
"""
Adaptateur de compte allauth.

allauth compose ses e-mails transactionnels à partir de gabarits `.txt`/`.html`
livrés dans le package. On surcharge ici les points d'extension documentés qui
donnent un accès typé à l'utilisateur et au lien, pour rediriger ces envois vers
le catalogue emailing éditable en back-office.

  - `send_password_reset_mail`  → password_reset_request
  - `send_confirmation_mail`    → account_email_verify (inscription)
                                  / email_change_confirm (changement d'adresse)

Les notifications de sécurité (mot de passe modifié, alerte de changement
d'adresse) passent, elles, par les signaux allauth (voir `signals.py`) : elles
ne dépendent pas de ces méthodes.

En cas d'imprévu, on retombe sur le comportement natif d'allauth pour ne jamais
priver l'utilisateur d'un mail critique (réinitialisation, confirmation).
"""

import logging

from allauth.account import app_settings as allauth_settings
from allauth.account.adapter import DefaultAccountAdapter

from jeiko.users import emailing

logger = logging.getLogger(__name__)


class JeikoAccountAdapter(DefaultAccountAdapter):

    def send_password_reset_mail(self, user, email, context):
        url = context.get("password_reset_url")
        if url:
            try:
                emailing.send_password_reset(user, email, url, self.request)
                return
            except Exception:
                logger.exception("Repli allauth pour password_reset_request")
        return super().send_password_reset_mail(user, email, context)

    def send_confirmation_mail(self, request, emailconfirmation, signup):
        # En vérification par code (pas de lien), on laisse allauth gérer.
        if allauth_settings.EMAIL_VERIFICATION_BY_CODE_ENABLED:
            return super().send_confirmation_mail(request, emailconfirmation, signup)

        email_address = emailconfirmation.email_address
        url = self.get_email_confirmation_url(request, emailconfirmation)
        if url:
            try:
                user = email_address.user
                if signup:
                    emailing.send_email_verification(user, email_address.email, url)
                else:
                    emailing.send_email_change_confirm(user, email_address.email, url)
                return
            except Exception:
                logger.exception("Repli allauth pour la confirmation d'adresse")
        return super().send_confirmation_mail(request, emailconfirmation, signup)
