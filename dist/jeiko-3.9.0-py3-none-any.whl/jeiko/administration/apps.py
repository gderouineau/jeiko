from django.apps import AppConfig


class AdministrationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko.administration'

    def ready(self):
        from . import signals
        from . import erreurs  # noqa: F401 — branche le signal des 500