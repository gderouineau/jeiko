"""
Les erreurs 500 du site : gardées avec leur trace, signalées à l'exploitant.

Le problème (A-84)
------------------
Le 02/10, des écritures simultanées de l'API ont répondu 500 sur jeiko.fr.
L'agent l'a vu, personne d'autre : la trace dormait dans `logs/django.log`, sur
le serveur, et quand on a voulu la lire il fallait se connecter en SSH. Le
défaut n'a jamais pu être reproduit ailleurs — sans la trace, on ne sait pas
où chercher.

Ce que fait ce module
---------------------
* `enregistrer` (signal `got_request_exception`, émis par Django pour toute
  exception non rattrapée, donc toute 500) : la trace, la méthode et le
  chemin, en base. Les 500 identiques — même exception, levée au même endroit
  du code — ne font qu'une ligne, avec un compteur.
* `signaler` (cron des 5 minutes) : un e-mail `admin_error_alert` aux
  destinataires internes pour chaque erreur nouvelle ou revenue, trace
  comprise. Au plus un par erreur et par jour : une avalanche de 500 ne doit
  pas devenir une avalanche d'e-mails.
* `rapport_aux_developpeurs` (cron quotidien) : si le site l'a accepté —
  `WebSite.partager_les_erreurs`, case de « Mises à jour ▸ Réglages »,
  décochée par défaut (P4-a) —, les erreurs des dernières 24 heures partent à
  `DEVELOPPEURS`. Un défaut que seul un site rencontre arrive ainsi chez ceux
  qui peuvent le corriger, sans que l'exploitant ait à le transmettre.
* `purger` (cron quotidien) : rien n'est gardé plus de `CONSERVATION`.

Ce qu'il ne fait pas
--------------------
* Il ne voit que les 500 que Django sert lui-même. Un processus gunicorn tué,
  une 502 de nginx, une erreur dans une tâche cron : ailleurs.
* La query string n'est pas gardée : elle peut porter un jeton. Le corps de
  la requête non plus, ni les variables locales — des données personnelles
  n'ont rien à faire dans un journal technique.
* Les secrets cités DANS le texte de l'erreur sont masqués avant tout
  enregistrement (`masquer`) : paramètres d'une adresse (« …?key=AIza… »
  dans l'erreur d'un appel d'API raté), couples « password=… », « token=… »,
  « Bearer … ». Le texte part en base, par e-mail aux administrateurs, et
  chaque jour aux développeurs : une clé d'API n'a rien à y faire. Un secret
  sous une autre forme reste possible — d'où la case qui se décoche.
* Le message d'une exception peut citer une valeur (une adresse e-mail dans
  une erreur d'unicité, par exemple) : c'est pourquoi le partage avec les
  développeurs est décoché tant que personne ne l'a voulu.
* Une base indisponible empêche l'enregistrement : il reste alors le journal
  de fichier, qui reçoit toujours la même trace.
"""

import hashlib
import logging
import re
import sys
import traceback
from datetime import timedelta

from django.core.signals import got_request_exception
from django.db import IntegrityError, transaction
from django.db.models import F
from django.utils import timezone

logger = logging.getLogger(__name__)

CONSERVATION = timedelta(days=30)

# Taille au-delà de laquelle masquer() ne regarde pas (P4-b). On tronque AVANT
# de masquer ; l'appelant retronque ensuite à sa propre borne.
_MAX_A_MASQUER = 40000

# Chaque motif ci-dessous est en temps LINÉAIRE. Il tourne dans le fil de la
# requête en 500, sur un texte que le visiteur choisit en partie : le message
# d'une exception cite souvent la valeur reçue. Un motif à retours arrière —
# « [a-z0-9_-]*(?:key|…)[a-z0-9_-]* » — prenait 47 s pour 2 000 caractères de
# « keyxkeyx… » (07/10) : un worker gunicorn tué à chaque 500 provoquée. D'où
# des répétitions bornées et ancrées au DÉBUT d'un mot (« (?<!…) »), et pas de
# quantificateur possessif : Python 3.10, que le paquet accepte, ne le connaît
# pas — le module ne se chargerait plus.
#
# Les paramètres d'une adresse : « https://hote/chemin?key=…&x=… ».
_PARAMETRES_D_URL = re.compile(r"""(https?://[^\s'"<>?#]{1,2048})\?[^\s'"<>]*""")
# Le mot de passe d'une URL : « scheme://user:MOTDEPASSE@hote ».
_URL_USERINFO = re.compile(
    r"""(?i)(?<![a-z0-9+.-])([a-z][a-z0-9+.-]{0,30}://[^\s:/@'"]{1,256}:)[^\s@'"]{1,256}@"""
)
# Un schéma d'autorisation porteur de jeton : « Bearer eyJ… », « Token 9f… ».
_PORTEUR = re.compile(r"(?i)\b(bearer|basic|digest|token|apikey)\s+[A-Za-z0-9._~+/=-]+")
# « nom = valeur », « nom: valeur », « "nom": "valeur" » : un nom (un mot
# entier, 64 caractères au plus) et son séparateur. La valeur est lue à part.
_NOM_ET_SEPARATEUR = re.compile(r"""(?<![\w-])([\w-]{1,64})(\s{0,3}["']?\s{0,3}[:=]\s{0,3}["']?)""")
_VALEUR = re.compile(r"""[^\s'",;)}\]]+""")
# Un nom qui désigne un secret, préfixe ou suffixe compris : SECRET_KEY,
# DB_PASSWORD, id_token (P4-a). « auth » est volontairement absent : il aurait
# pris « Bearer » pour la valeur d'« Authorization » et laissé le jeton qui
# suit — c'est _PORTEUR qui s'en charge.
_NOM_SECRET = re.compile(r"(?i)passw(?:or)?d|pwd|secret|token|key|signature")


def _masquer_les_couples(texte):
    morceaux, fin = [], 0
    for m in _NOM_ET_SEPARATEUR.finditer(texte):
        if m.start() < fin or not _NOM_SECRET.search(m.group(1)):
            continue
        valeur = _VALEUR.match(texte, m.end())
        if valeur:
            morceaux += [texte[fin:m.end()], "[…]"]
            fin = valeur.end()
    morceaux.append(texte[fin:])
    return "".join(morceaux)


def masquer(texte):
    """Le texte d'une erreur, sans les secrets qu'il cite.

    Mieux vaut masquer trop (un « monkey=… » anodin) que laisser fuir : ce
    texte part en base, par e-mail aux administrateurs, et chaque jour aux
    développeurs. L'ordre compte : la valeur d'URL et le jeton porteur d'abord,
    pour que « Authorization: Bearer eyJ… » soit traité avant le balayage
    nom=valeur.
    """
    texte = texte[:_MAX_A_MASQUER]
    texte = _PARAMETRES_D_URL.sub(r"\1?[…]", texte)
    texte = _URL_USERINFO.sub(r"\1[…]@", texte)
    texte = _PORTEUR.sub(r"\1 […]", texte)
    return _masquer_les_couples(texte)


DEVELOPPEURS = "contact@jeiko.fr"
RAPPEL = timedelta(days=1)


def _signature(exc):
    """Le type et le lieu de la levée : deux 500 au même endroit sont une seule erreur."""
    lieu = traceback.extract_tb(exc.__traceback__)[-1:] if exc.__traceback__ else []
    cle = type(exc).__qualname__ + "".join(f"|{f.filename}:{f.lineno}" for f in lieu)
    return hashlib.sha256(cle.encode()).hexdigest()


def enregistrer(sender=None, request=None, **kwargs):
    """Ne lève jamais : une erreur ne doit pas en cacher une autre."""
    from .models import ErreurServeur

    exc = sys.exc_info()[1]
    if exc is None:
        return
    try:
        signature = _signature(exc)
        # On tronque AVANT de masquer (P4-b) : masquer() ne travaille jamais sur
        # plus que sa borne, et la trace garde sa FIN (là où l'erreur est levée).
        trace_brute = "".join(traceback.format_exception(exc))[-40000:]
        valeurs = {
            "exception": masquer(f"{type(exc).__name__}: {exc}"[:400])[:200],
            "methode": (getattr(request, "method", "") or "")[:10],
            "chemin": (getattr(request, "path", "") or "")[:500],
            "trace": masquer(trace_brute)[-20000:],
            "derniere": timezone.now(),
        }
        with transaction.atomic():
            mis_a_jour = ErreurServeur.objects.filter(signature=signature).update(
                occurrences=F("occurrences") + 1, **valeurs)
            if not mis_a_jour:
                try:
                    with transaction.atomic():
                        ErreurServeur.objects.create(signature=signature, **valeurs)
                except IntegrityError:
                    # Une requête simultanée l'a créée : on compte la nôtre.
                    ErreurServeur.objects.filter(signature=signature).update(
                        occurrences=F("occurrences") + 1, **valeurs)
    except Exception:
        logger.exception("Erreur 500 non enregistrée")


got_request_exception.connect(enregistrer, dispatch_uid="jeiko_erreurs_serveur")


def signaler():
    """Prévient l'exploitant des erreurs nouvelles ou revenues. Rend leur nombre."""
    from jeiko.emailing.admin_alerts import notifier_erreur

    from .models import ErreurServeur

    maintenant = timezone.now()
    nombre = 0
    a_signaler = ErreurServeur.objects.filter(occurrences__gt=F("occurrences_signalees")).exclude(
        signalee_le__gt=maintenant - RAPPEL)
    for erreur in a_signaler:
        nouvelles = erreur.occurrences - erreur.occurrences_signalees
        # La fin de la trace est ce qui situe l'erreur ; l'e-mail en garde 2 000 caractères.
        detail = f"{erreur.methode} {erreur.chemin}\n\n{erreur.trace[-1800:]}"
        if notifier_erreur(f"Erreur 500 — {erreur.exception}", detail, occurrences=nouvelles):
            ErreurServeur.objects.filter(pk=erreur.pk).update(
                occurrences_signalees=erreur.occurrences, signalee_le=maintenant)
            nombre += 1
    return nombre


def rapport_aux_developpeurs():
    """Le rapport du jour aux développeurs de JEIKO. Rend le nombre d'erreurs envoyées."""
    from jeiko.administration.models import WebSite
    from jeiko.emailing.render import site_base_url
    from jeiko.emailing.sending import send_message

    from .models import ErreurServeur

    site = WebSite.objects.first()
    if site is None or not site.partager_les_erreurs:
        return 0
    erreurs = list(ErreurServeur.objects.filter(derniere__gte=timezone.now() - RAPPEL))
    if not erreurs:
        return 0

    from importlib.metadata import PackageNotFoundError, version
    try:
        version_installee = version("jeiko")
    except PackageNotFoundError:
        version_installee = "?"
    adresse = site_base_url()
    parties = [f"Site : {adresse or '?'}", f"JEIKO : {version_installee}", ""]
    for erreur in erreurs:
        parties += [
            "=" * 72,
            erreur.exception,
            f"{erreur.methode} {erreur.chemin}",
            f"{erreur.occurrences} fois, du {timezone.localtime(erreur.premiere):%d/%m/%Y %H:%M}"
            f" au {timezone.localtime(erreur.derniere):%d/%m/%Y %H:%M}",
            "",
            erreur.trace[-4000:],
            "",
        ]
    ok, motif = send_message(
        f"[JEIKO] {len(erreurs)} erreur(s) 500 — {adresse or '?'}",
        "\n".join(parties), DEVELOPPEURS,
    )
    if not ok:
        logger.warning("Rapport d'erreurs aux développeurs non envoyé : %s", motif)
        return 0
    return len(erreurs)


def purger():
    from .models import ErreurServeur

    return ErreurServeur.objects.filter(derniere__lt=timezone.now() - CONSERVATION).delete()[0]
