"""
La mise à jour du SERVEUR et la mise à jour automatique, vues depuis le site.

Le problème
-----------
Le site savait mettre à jour son paquet (bouton « Lancer la mise à jour »,
`jeiko-client-update`), pas son serveur : il fallait une commande en SSH. Et
rien n'empêchait de mettre le paquet à jour AVANT le serveur, alors qu'un
paquet récent peut attendre une configuration serveur qui n'existe pas encore
— une bibliothèque système, une règle sudo, une clé du .env.

Ce que fait ce module
---------------------
Le site ne met rien à jour lui-même. Il LIT ce que l'outillage root a écrit,
et DEMANDE, par la seule commande que son sudoers autorise
(`systemctl start --no-block jeiko-maj-serveur@<site>.service`), la mise à jour
du serveur. Le travail est fait par `/usr/local/sbin/jeiko-maj`
(`INSTALLER/updater/jeiko-maj`), qui passe le serveur d'abord, les sites
ensuite.

Ce qu'il lit :
* `/usr/local/share/jeiko/VERSION` — l'installeur dont l'outillage est déposé ;
* `/var/lib/jeiko/<site>/serveur.version` — l'installeur avec lequel CE site a
  été convergé ;
* `/var/lib/jeiko/maj-serveur.state` — la dernière passe, hebdomadaire ou
  demandée par un site ;
* une fois par jour (cron), le `version.json` du dépôt de l'installeur, comme
  `update_check` le fait pour le paquet.

Ce qu'il ne fait pas
--------------------
* Garantir l'ordre : c'est `jeiko-client-update` qui REFUSE le paquet tant que
  le site n'est pas convergé avec l'installeur publié. L'écran le montre et
  désactive le bouton ; il n'est pas la garantie.
* Lire le journal de la mise à jour serveur : il nomme les sites voisins de la
  machine, qui peuvent appartenir à d'autres clients. Il reste à root.
* Bloquer quoi que ce soit sur un serveur dont l'outillage ne connaît pas
  encore jeiko-maj : le bouton du site y fonctionne comme avant.
"""

import json
import logging
import re
import subprocess
from datetime import datetime, timedelta
from pathlib import Path

from django.utils import timezone
from django.utils.translation import gettext as _

from .update_check import _parse, fetch_published_version

logger = logging.getLogger(__name__)

# Chemins figés, jamais construits à partir d'une donnée de requête.
JEIKO_MAJ = Path("/usr/local/sbin/jeiko-maj")
VERSION_OUTILLAGE = Path("/usr/local/share/jeiko/VERSION")
ETAT_SERVEUR = Path("/var/lib/jeiko/maj-serveur.state")
DOSSIER_DES_SITES = Path("/var/lib/jeiko")
JEIKO_SYSTEMCTL = "/usr/bin/systemctl"

#: Le dépôt de l'installeur — identique à JEIKO_INSTALLER_CHANNEL_URL de
#: `INSTALLER/lib/jeiko-common.sh`.
CANAL_INSTALLEUR = "https://raw.githubusercontent.com/gderouineau/jeiko_installer/main"

#: Au-delà, une passe « en cours » qui ne donne plus signe de vie est tenue
#: pour interrompue (les unités l'arrêtent au bout de 3 h ou 5 h).
SILENCE_MAX = timedelta(hours=5, minutes=30)

#: Un échec plus ancien n'est pas signalé : la première passe du cron après
#: une mise à jour ne doit pas exhumer un échec réglé depuis longtemps.
ECHEC_SIGNALE_SI_RECENT = timedelta(days=7)


def _lire_version(chemin):
    """Une version dans un fichier root ; « » si absent, illisible ou mal formé."""
    try:
        texte = Path(chemin).read_text(encoding="utf-8").strip()[:32]
    except OSError:
        return ""
    return texte if _parse(texte) else ""


def plus_recente(a, b):
    """Vrai si la version `a` est strictement plus récente que `b`.

    Une version `b` absente vaut « rien » — un site jamais convergé avec
    l'outillage actuel est en retard sur n'importe quel installeur. Une version
    `a` illisible ne l'emporte jamais.
    """
    gauche = _parse(a)
    return bool(gauche) and gauche > _parse(b)


def mecanisme_present():
    """L'outillage de cette machine connaît-il jeiko-maj ?"""
    return JEIKO_MAJ.is_file()


def versions_du_serveur(site, installeur_publie=""):
    """Où en est le serveur pour ce site.

    `requise` est la plus récente de l'installeur publié et de l'outillage
    déposé : le site doit avoir été convergé avec elle. C'est la règle même de
    `jeiko-client-update`.
    """
    outillage = _lire_version(VERSION_OUTILLAGE)
    convergee = _lire_version(DOSSIER_DES_SITES / site / "serveur.version")
    publie = installeur_publie if _parse(installeur_publie) else ""
    requise = publie if plus_recente(publie, outillage) else outillage
    return {
        "outillage": outillage,
        "convergee": convergee,
        "publie": publie,
        "requise": requise,
        "en_retard": bool(requise) and plus_recente(requise, convergee),
    }


def _lire_json(chemin):
    try:
        return json.loads(Path(chemin).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, ValueError):
        return {"statut": "illisible"}


def _horodatage(texte):
    try:
        moment = datetime.fromisoformat(str(texte))
    except (TypeError, ValueError):
        return None
    return moment if moment.tzinfo else timezone.make_aware(moment)


def etat_serveur():
    """La dernière passe de jeiko-maj, telle que l'administration la montre."""
    etat = _lire_json(ETAT_SERVEUR)
    if etat.get("statut") == "en_cours":
        moment = _horodatage(etat.get("maj"))
        if moment and timezone.now() - moment > SILENCE_MAX:
            etat["statut"] = "interrompu"
            etat["message"] = _("Aucun signe de vie depuis plus de cinq heures : la mise à jour a été interrompue.")
    return etat


#: Une demande de site toutes les 5 minutes au plus — la même règle que
#: jeiko-maj, qui ignore une demande trop rapprochée sans rien dire. L'écran
#: l'applique avant de demander, pour dire pourquoi rien ne se passe.
ESPACEMENT_DES_DEMANDES = timedelta(minutes=5)


def derniere_passe_recente():
    """La dernière passe a-t-elle écrit son état il y a moins de 5 minutes ?"""
    try:
        moment = datetime.fromtimestamp(ETAT_SERVEUR.stat().st_mtime, tz=timezone.get_current_timezone())
    except OSError:
        return False
    return timezone.now() - moment < ESPACEMENT_DES_DEMANDES


def demander_la_mise_a_jour_du_serveur(site):
    """Déclenche jeiko-maj-serveur@<site>. Rend (réussi, message).

    La commande doit correspondre AU CARACTÈRE PRÈS à la règle de
    /etc/sudoers.d/jeiko-<site> (jeiko_ecrire_sudoers) : sudo compare la ligne
    entière.
    """
    commande = [
        "sudo", "-n", JEIKO_SYSTEMCTL,
        "start", "--no-block", f"jeiko-maj-serveur@{site}.service",
    ]
    try:
        subprocess.run(commande, capture_output=True, text=True, timeout=15, check=True)
    except FileNotFoundError:
        return False, _("sudo ou systemctl introuvable sur ce serveur.")
    except subprocess.TimeoutExpired:
        return False, _("La demande de mise à jour du serveur n'a pas répondu.")
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        if "password" in detail.lower() or "mot de passe" in detail.lower():
            return False, _(
                "Ce site n'a pas encore le droit de demander la mise à jour du serveur. "
                "Sur le serveur, une fois : sudo jeiko-server-update %(site)s"
            ) % {"site": site}
        return False, _("Impossible de demander la mise à jour du serveur. %(detail)s") % {"detail": detail}
    return True, _("Mise à jour du serveur demandée. Son avancement s'affiche ci-dessous.")


# --------------------------------------------------------------------------- #
# Tâches planifiées
# --------------------------------------------------------------------------- #
def verifier_l_installeur():
    """Lit la version publiée de l'installeur et la range sur WebSite.

    Ne lève jamais : comme `update_check.check_for_update`, une vérification
    est une commodité.
    """
    from .models import WebSite

    site = WebSite.objects.first()
    if site is None:
        return None
    try:
        publiee = fetch_published_version(CANAL_INSTALLEUR)
    except RuntimeError as exc:
        logger.warning("Vérification de l'installeur JEIKO échouée : %s", exc)
        return None
    # La règle de jeiko-maj, exactement : X.Y.Z. L'écran et le serveur ne
    # doivent pas diverger sur ce qu'est une version publiée.
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", publiee):
        logger.warning("Version d'installeur publiée refusée : %r", publiee[:40])
        return None
    site.installeur_disponible = publiee
    site.save(update_fields=["installeur_disponible"])
    return publiee


def signaler_les_mises_a_jour_ratees(site_name):
    """Prévient l'exploitant d'un échec de mise à jour, une fois par échec.

    Deux sources : l'état de la mise à jour du paquet de CE site
    (`update.state`) et celui de la dernière passe serveur. Chaque échec est
    repéré par son horodatage ; il n'est signalé qu'une fois, et seulement s'il
    a moins de sept jours. Rend le nombre d'e-mails envoyés.
    """
    from jeiko.emailing.admin_alerts import notifier_erreur

    from .models import WebSite

    site = WebSite.objects.first()
    if site is None:
        return 0
    envoyes = 0
    maintenant = timezone.now()

    etat = _lire_json(DOSSIER_DES_SITES / site_name / "update.state")
    repere = str(etat.get("heartbeat") or etat.get("started_at") or "")
    moment = _horodatage(repere)
    if (etat.get("status") == "failed" and repere and repere != site.echec_maj_site_signale
            and moment and maintenant - moment < ECHEC_SIGNALE_SI_RECENT):
        # Le contenu des e-mails reste en français (règle de la maison) : pas de _().
        detail = "%(message)s\nÉtape : %(etape)s\nVersion : %(avant)s → %(apres)s" % {
            "message": etat.get("message", ""), "etape": etat.get("step", ""),
            "avant": etat.get("version_before", "?"), "apres": etat.get("version_after", "?"),
        }
        # Marqué « signalé » seulement une fois l'e-mail parti : un SMTP en
        # panne à cette heure-là ne doit pas perdre l'alerte — elle est
        # retentée l'heure suivante, sept jours durant.
        if notifier_erreur("Mise à jour du site en échec", detail):
            envoyes += 1
            site.echec_maj_site_signale = repere[:40]
            site.save(update_fields=["echec_maj_site_signale"])

    etat = etat_serveur()
    repere = str(etat.get("maj") or "")
    moment = _horodatage(repere)
    if (etat.get("statut") == "echec" and repere and repere != site.echec_maj_serveur_signale
            and moment and maintenant - moment < ECHEC_SIGNALE_SI_RECENT):
        detail = "%(message)s\nÉtape : %(etape)s\nInstalleur : %(avant)s → %(apres)s" % {
            "message": etat.get("message", ""), "etape": etat.get("etape", ""),
            "avant": etat.get("installeur_avant", "?"), "apres": etat.get("installeur_apres", "?"),
        }
        if notifier_erreur("Mise à jour du serveur en échec", detail):
            envoyes += 1
            site.echec_maj_serveur_signale = repere[:40]
            site.save(update_fields=["echec_maj_serveur_signale"])

    return envoyes
