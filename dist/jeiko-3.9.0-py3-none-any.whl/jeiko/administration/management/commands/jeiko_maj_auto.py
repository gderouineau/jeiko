"""
La question que pose /usr/local/sbin/jeiko-maj à chaque site, chaque semaine :
« as-tu coché la mise à jour automatique ? »

Répond « oui » ou « non », sur une ligne, rien d'autre : jeiko-maj ne lit que
la dernière ligne, et toute autre réponse — une erreur, un paquet trop ancien
pour connaître cette commande — vaut « non ». Le serveur demande au site
plutôt que de lire sa base : il n'a pas ses identifiants, et n'a pas à les
avoir.
"""

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Le site a-t-il coché « Mise à jour automatique » ? Répond « oui » ou « non » (lu par jeiko-maj)."

    # Pas de contrôles système : leurs avertissements n'ont rien à faire dans
    # une réponse lue par un script, et la question doit coûter peu — elle est
    # posée à chaque site de la machine.
    requires_system_checks = []

    def handle(self, *args, **options):
        from jeiko.administration.models import WebSite

        site = WebSite.objects.first()
        self.stdout.write("oui" if site is not None and site.mise_a_jour_auto else "non")
