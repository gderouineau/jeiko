"""
Tâches planifiées — toutes les heures.

Lancé par le timer systemd jeiko-cron-1h@<site>.timer.

Jobs :
  - récapitulatif quotidien du praticien : balayé chaque heure, ne part qu'à
    l'heure d'envoi (DAILY_DIGEST_HOUR dans calendars.emailing) ;
  - mises à jour en échec (paquet du site ou serveur) : un e-mail par échec.

Autres candidats : relance des formations en pause, alerte de stock bas,
réactivation des inactifs.
"""
from jeiko.administration.management.commands._cron import CronCommand


def job_daily_provider_digests():
    from jeiko.calendars.emailing import send_daily_provider_digests
    sent = send_daily_provider_digests()
    return f"{sent} récapitulatif(s) envoyé(s)"


def job_signaler_les_mises_a_jour_ratees():
    """Un e-mail à l'exploitant pour chaque mise à jour en échec — du paquet de
    ce site ou du serveur —, une fois par échec. Voir
    administration/mise_a_jour.py."""
    from jeiko.administration.mise_a_jour import signaler_les_mises_a_jour_ratees
    from jeiko.administration.views import _jeiko_site_name
    try:
        site = _jeiko_site_name()
    except ValueError:
        return "nom de site indéterminable : rien à lire"
    return f"{signaler_les_mises_a_jour_ratees(site)} échec(s) signalé(s)"


class Command(CronCommand):
    help = "Tâches planifiées à exécuter toutes les heures."
    cadence = "1h"

    def get_jobs(self):
        return [
            ("récapitulatif quotidien praticien", job_daily_provider_digests),
            ("mises à jour en échec", job_signaler_les_mises_a_jour_ratees),
        ]
