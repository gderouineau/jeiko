# jeiko/agents/guide.py
"""
Le mode d'emploi que l'API se donne à elle-même.

Pourquoi c'est le point d'entrée le plus important
--------------------------------------------------
Une IA qui découvre cette API ne connaît ni JEIKO, ni son modèle de page, ni
les pièges de son vocabulaire. Sans mode d'emploi, elle procède par essais et
par 400 : elle devine des noms de champs, se trompe, recommence. Chaque erreur
coûte un aller-retour, et certaines — poser un bloc dans une colonne qui
n'existe pas — produisent une page bancale sans rien signaler.

Ce guide lui donne, en un appel, ce qu'un développeur mettrait une heure à
lire dans le code : la forme de l'arbre, le vocabulaire, les documents
attendus, et un exemple complet qui marche.

La règle qui rend ce guide fiable
---------------------------------
**Tout ce qui peut être déduit du code l'est.** Les noms d'appareils, les côtés
d'une boîte, les champs d'animation, de bordure et de CSS, les gabarits de
section, les types de contenu ouverts, les champs de page modifiables et la
liste des points d'entrée sont lus dans les constantes et dans le routeur — pas
recopiés. Une documentation recopiée devient fausse au premier changement, et
une documentation fausse est pire que pas de documentation : elle fait perdre
du temps avec autorité.

Seule la prose est écrite à la main. Elle explique des intentions, que le code
ne porte pas.
"""

from django.urls import get_resolver

from jeiko.administration_pages import fabrique

from . import contenus_dynamiques as _dyn
from . import parametres
from .vues_api import AUTHENTIFICATION_SEULE
from .vues_pages import (
    CHAMPS_PAGE_CATEGORIES, CHAMPS_PAGE_MODIFIABLES, CONTENUS_SIMPLES,
    TYPES_OUVERTS,
)

RACINE = "/api/agent/v1/"


def _points_d_entree():
    """
    Les routes réellement montées, lues dans le routeur.

    Les décrire à la main garantirait qu'un jour l'une manque ou qu'une autre
    n'existe plus. Le routeur, lui, ne peut pas mentir.
    """
    from .urls_api import urlpatterns

    descriptions = {
        "guide": ("GET", "Ce mode d'emploi. À lire en premier."),
        "guide_explicite": ("GET", "Le même mode d'emploi, à une adresse qui se retient."),
        "whoami": ("GET", "Qui je suis et ce que j'ai le droit de faire."),
        "pages": ("GET", "La liste des pages du site."),
        "page_creer": ("POST", "Créer une page. Elle naît en brouillon."),
        "page": ("GET, PATCH", "L'arbre complet d'une page ; PATCH modifie ses champs."),
        "page_sections": ("POST", "Ajouter une section à une page."),
        "page_mesures": ("GET", "Scores PageSpeed, Core Web Vitals et audits ratés. Lecture seule."),
        "section": ("GET, PATCH, DELETE", "Une section et ses paramètres."),
        "section_lignes": ("POST", "Ajouter une ligne à une section."),
        "ligne": ("GET, PATCH, DELETE", "Une ligne et ses paramètres."),
        "ligne_blocs": ("POST", "Ajouter un bloc dans une colonne de la ligne."),
        "bloc": ("GET, PATCH, DELETE", "Un bloc et ses paramètres."),
        "bloc_contenu": ("PUT", "Poser ou remplacer le contenu d'un bloc."),
        "images": ("GET", "La médiathèque, en lecture. Donne les identifiants à réutiliser."),
        "categories": ("GET", "Les catégories et sous-catégories, avec leurs slugs."),
        "rdv_types": ("GET", "Les types de rendez-vous. Leur durée découpe les disponibilités."),
        "rdv_type_creer": ("POST", "Créer un type de rendez-vous."),
        "rdv_type": ("GET, PATCH", "Un type : durée, capacité, prix, liste d'attente."),
        "rdv_disponibilites": ("GET", "Les plages déclarées disponibles."),
        "rdv_disponibilite_creer": ("POST", "Déclarer une plage — elle GÉNÈRE ses créneaux."),
        "rdv_disponibilite": ("GET, PATCH, DELETE", "Une plage. La suppression est refusée si des rendez-vous y sont pris."),
        "rdv_creneaux": ("GET", "Les créneaux générés — LECTURE SEULE. Filtres : type, depuis, jusqu_a, ouverts."),
        "rdv": ("GET", "Les rendez-vous pris. Lecture seule, permission à part : données personnelles."),
        "menus": ("GET", "Les menus, leur arborescence et les catégories qu'ils servent."),
        "menu_creer": ("POST", "Créer un menu — « copie_de » duplique un existant, arborescence comprise."),
        "menu": ("GET, PATCH", "Un menu ; envoyer « elements » REMPLACE son arborescence."),
        "categorie_menus": ("PATCH", "Affecter les menus d'une catégorie — c'est ce qui fait les sous-sites."),
        "identite": ("GET, PATCH", "Les couleurs du thème et les polices du site. Modification partielle."),
        "email_evenements": ("GET", "Les 67 événements d'e-mail et LEURS CLÉS. À lire avant d'écrire un e-mail."),
        "emails": ("GET", "Les e-mails configurés."),
        "email_creer": ("POST", "Habiller un événement : sujet, page de corps. Naît INACTIF."),
        "email": ("GET, PATCH", "Un e-mail : sujet, corps, expéditeur, activation."),
        "questionnaires": ("GET", "Les questionnaires experts."),
        "questionnaire_creer": ("POST", "Créer un questionnaire. Il naît INACTIF."),
        "questionnaire": ("GET, PATCH", "L'arbre complet : profils, questions, réponses, poids, combinaisons."),
        "questionnaire_profils": ("POST", "Ajouter un profil — un résultat possible, avec sa page."),
        "questionnaire_questions": ("POST", "Ajouter une question, ses réponses et leurs poids."),
        "questionnaire_combinaisons": ("POST", "Ajouter une combinaison — l'arbitrage entre deux profils proches."),
        "profil": ("PATCH", "Un profil. Son slug ne se modifie pas : il est dans l'URL du résultat."),
        "question": ("PATCH", "Une question ; envoyer « reponses » REMPLACE la liste, poids compris."),
        "combinaison": ("PATCH", "Une combinaison et ses critères."),
        "categorie_creer": ("POST", "Créer une catégorie, éventuellement sous une autre."),
        "deplacer": ("POST", "Monter ou descendre une section, une ligne ou un bloc."),
        "modeles": ("GET", "Les types de fiches et leurs champs. À lire avant d'en créer une."),
        "modele_creer": ("POST", "Créer un type de fiche avec ses champs, et marquer sa page gabarit."),
        "modele": ("GET, PATCH", "Un type de fiche ; PATCH AJOUTE des champs, n'en renomme aucun."),
        "types_produit": ("GET", "Les types de produit — la couche commerciale."),
        "type_produit_creer": ("POST", "Créer un type de produit, relié à un type de fiche."),
        "objets": ("GET", "Les fiches existantes. `?modele=<slug>` pour filtrer."),
        "objet_creer": ("POST", "Créer une fiche. Elle naît non publiée."),
        "objet": ("GET, PATCH", "Une fiche et ses valeurs ; PATCH en modifie une partie."),
        "produits": ("GET", "Les produits."),
        "produit_creer": ("POST", "Créer un produit sur une fiche existante."),
        "produit": ("GET, PATCH", "Un produit : référence, prix, TVA, stock."),
    }

    entrees = []
    for motif in urlpatterns:
        nom = motif.name
        methodes, quoi = descriptions.get(nom, ("?", ""))
        entrees.append({
            "nom": nom,
            "methodes": methodes,
            "chemin": RACINE + str(motif.pattern),
            "role": quoi,
            "permission": _permission_de(motif),
        })
    return entrees


def _permission_de(motif):
    """
    La permission qu'exige réellement la vue, lue sur la classe elle-même.

    Un agent doit pouvoir savoir AVANT d'appeler s'il a le droit, plutôt que
    de le découvrir sur un 403. Et l'écrire à la main dans le guide reviendrait
    à entretenir une seconde vérité, qui finirait par se tromper — c'est
    exactement le genre d'écart qui rend une documentation dangereuse : un
    agent qui la croit renonce à une action permise, ou en tente une interdite.
    """
    vue = getattr(motif.callback, "view_class", None)
    exigee = getattr(vue, "permission_requise", None)
    if exigee is None:
        return "?"
    if exigee is AUTHENTIFICATION_SEULE:
        return "aucune — un jeton valide suffit"
    return exigee


def _document_de_parametres():
    """La forme exacte d'un document de paramètres, déduite des constantes."""
    cotes = list(parametres.COTES)
    appareils = list(parametres.APPAREILS)

    return {
        "principe": (
            "Tout ce qui n'est pas mentionné reste inchangé. Envoyer "
            "{'paddings': {'phone': {'haut': '20px'}}} ne touche ni les autres "
            "appareils, ni les autres familles."
        ),
        "appareils": appareils,
        "marges": {"forme": {a: {c: "valeur CSS" for c in cotes} for a in ["computer"]},
                   "note": f"Un objet par appareil parmi {appareils}."},
        "paddings": {"identique_a": "marges"},
        "tailles": {"forme": {"computer": {"largeur": "1140px", "hauteur": ""}}},
        "fond": {
            "couleur": "rgba(255,255,255,0) — couleur CSS",
            "image_id": "identifiant d'une image DÉJÀ dans la médiathèque, ou null pour détacher",
            "cle_image_dynamique": "code d'un champ IMAGE d'objet custom",
            "reglages_image": list(parametres.CHAMPS_IMAGE_DE_FOND),
        },
        "animation": list(parametres.SATELLITES["animation"][1]),
        "bordure": list(parametres.SATELLITES["bordure"][1]),
        "css": list(parametres.SATELLITES["css"][1]),
        "champs_propres": {
            "section": list(parametres.CHAMPS_PROPRES.get(
                __import__("jeiko.administration_pages.models", fromlist=["Section"]).Section, ())),
            "ligne": list(parametres.CHAMPS_PROPRES.get(
                __import__("jeiko.administration_pages.models", fromlist=["Line"]).Line, ())),
            "bloc": list(parametres.CHAMPS_PROPRES.get(
                __import__("jeiko.administration_pages.models", fromlist=["Bloc"]).Bloc, ())),
        },
    }


PROSE = """
# Piloter les pages de JEIKO

Vous êtes un agent connecté à l'API d'un site JEIKO. Ce document dit ce que
vous manipulez, dans quel ordre, et où sont les pièges. Lisez-le en entier
avant d'écrire : il est court, et il vous évitera des allers-retours.

## L'arbre d'une page

Une page est un empilement à quatre niveaux, et **rien ne s'invente en dehors
de cet ordre** :

    Page
     └─ Section      une bande horizontale, pleine largeur ou centrée
         └─ Ligne    une rangée, découpée en 1 à 12 colonnes
             └─ Bloc une case dans une colonne
                 └─ Contenu  du texte, une image, un bouton…

Pour créer quelque chose, il faut donc toujours créer le parent d'abord. Une
page vide est légitime, une section sans ligne aussi : rien ne vous oblige à
tout remplir d'un coup.

## Le piège de vocabulaire, à lire deux fois

Sur un bloc, le champ `colonne` est **le numéro de la colonne**, pas un rang
vertical. Le rang, c'est `rang`. Deux blocs dans la même colonne se suivent
verticalement ; deux blocs dans des colonnes différentes sont côte à côte.

Les colonnes sont numérotées à partir de **0**. Une ligne à 2 colonnes accepte
`colonne: 0` et `colonne: 1`, rien d'autre — une valeur hors bornes est
refusée avec un message qui vous dit les bornes.

## Les quatre appareils

Tout se règle par appareil, et les quatre existent toujours :

- `phone`    — jusqu'à 767 px
- `tablet`   — 768 à 991 px
- `laptop`   — 992 à 1199 px
- `computer` — 1200 px et au-delà

Régler `computer` seul ne règle que les grands écrans. Un site qui n'a l'air
correct que sur ordinateur est un site cassé pour la majorité des visiteurs :
pensez à `phone`.

## Comment travailler

1. `GET /pages/` — repérez la page, ou créez-la.
2. `GET /pages/<id>/` — **lisez l'arbre complet avant de modifier.** Il vous
   donne tous les identifiants et tous les paramètres actuels.
3. Créez ou modifiez, un appel par élément.
4. `GET /pages/<id>/` à nouveau pour vérifier ce que vous avez fait.

Les modifications de paramètres sont **partielles** : ce que vous n'envoyez
pas n'est pas touché. C'est ce qui permet de régler le padding du téléphone
sans effacer celui de l'ordinateur.

## Ce que vous ne pouvez pas faire, et pourquoi

**Supprimer une page.** Aucune route, aucune permission. Vous pouvez tout
construire et tout défaire à l'intérieur d'une page — sections, lignes, blocs —
mais la page elle-même ne disparaît que par la main d'un humain. Ne le
cherchez pas : ce n'est pas un oubli.

**Publier une page en la créant.** Une page naît en brouillon. La mettre en
ligne est une décision éditoriale ; elle se fait par un `PATCH` explicite avec
`{"publiee": true}`, ou par un humain dans l'administration.

**Téléverser une image.** L'API rattache une image déjà présente dans la
médiathèque, par son identifiant. Le fichier lui-même passe par
l'administration, où s'appliquent les contrôles de poids et de dimensions.

## Deux pièges qui vous feront perdre une passe entière

Ils ne lèvent aucune erreur. Votre appel répond 200, et le résultat n'est pas
celui que vous attendiez. Lisez-les avant d'écrire du HTML.

### 1. Vos styles en ligne sont retirés — silencieusement

Le HTML que vous envoyez est assaini avant d'être rendu. Sont conservés
`class`, `id`, `title`, `role` et les `aria-*`. **L'attribut `style` est
retiré.** Un contenu joliment mis en forme dans le HTML arrivera nu dans la
page, sans le moindre avertissement.

Ce n'est pas une limitation à contourner : c'est ce qui empêche un agent
d'injecter n'importe quoi dans l'apparence d'un site. Vous avez deux voies
légitimes, et elles suffisent :

**Les paramètres, pour tout ce qui a un réglage.** Fond, marges, paddings,
tailles, bordures, image de fond : ils se posent par `PATCH` sur la section, la
ligne ou le bloc, appareil par appareil. C'est la voie normale — préférez-la.

**Le CSS du bloc, pour ce qui n'a pas de réglage** — typographie, couleur du
texte, mise en forme fine. Écrivez des `class` dans votre HTML, puis posez la
feuille dans `css.custom` d'une section :

    PATCH /sections/8/  {"css": {"custom": ".mon-titre{color:#fff;}"}}

`css` accepte aussi `current`, `hover`, et leurs variantes par appareil
(`current_phone`, `hover_tablet`…). Une seule feuille posée sur la première
section suffit pour toute la page.

### 2. Les réglages de police du site l'emportent sur vos classes

Le site pose ses propres règles, du genre `.content h1 { color: … }`. En
spécificité CSS, cela vaut (0,1,1) — et votre `.mon-titre` ne vaut que (0,1,0).
**Le site gagne, et votre couleur est ignorée.**

Le symptôme est spectaculaire et facile à ne pas voir : un titre blanc demandé
sur un fond sombre s'affiche en noir sur noir.

La parade tient en un préfixe : écrivez `.content .mon-titre`, qui vaut (0,2,0)
et l'emporte. N'utilisez pas `!important` — vous gagneriez contre le site, mais
aussi contre l'exploitant qui voudra ajuster sa page ensuite.

## Réordonner

`position` n'est pas modifiable par `PATCH` : l'écrire à la main produirait
deux éléments au même rang, donc un ordre d'affichage arbitraire. On passe par
un point d'entrée qui renumérote les deux côtés :

    POST /deplacer/section/12/  {"sens": "haut"}
    POST /deplacer/ligne/45/    {"sens": "bas"}
    POST /deplacer/bloc/78/     {"sens": "haut"}

La réponse porte `deplace: false` quand l'élément est déjà en bout de course —
ce n'est pas une erreur, et la `raison` le dit. N'insistez pas.

**Un bloc se déplace dans SA colonne.** Deux blocs de colonnes différentes sont
côte à côte, pas l'un au-dessus de l'autre : les monter ne les échangera jamais.

## Les métadonnées

Le titre et la description qui partent dans les résultats de recherche :

    PATCH /pages/12/  {"metadonnees": {"titre": "Nos tarifs — Atelier",
                                       "description": "Trois formules…"}}

Sans description, Google reprend un morceau du corps de la page, souvent mal
choisi. Une page construite par un agent devrait toujours en recevoir une.

## La palette du site

Le site a un thème réglé par son exploitant : dix couleurs, exposées en
variables CSS sur `:root`. `GET /api/agent/v1/` vous les donne dans
`theme_du_site`.

**Servez-vous-en plutôt que d'inventer.** Écrire `var(--jk-accent)` dans le CSS
d'un bloc plutôt qu'une couleur en dur, c'est faire une page qui suivra le jour
où l'exploitant changera d'avis — et qui ne détonnera pas avec le reste du site.

    --jk-accent           boutons, liens, éléments actifs
    --jk-accent-survol    sa version foncée
    --jk-sur-accent       le texte posé SUR un fond d'accent
    --jk-secondaire       bandeaux, pieds de page, fonds sombres
    --jk-tertiaire        touches discrètes, fonds de mise en avant
    --jk-texte            --jk-texte-attenue
    --jk-fond             --jk-fond-attenue
    --jk-bordure

## Les images

Vous ne téléversez pas de fichier : vous **réutilisez** ce qui est déjà dans la
médiathèque.

    GET /images/            → [{"id": 42, "alt": "…", "url": "…"}, …]
    GET /images/?apres=42   → la page suivante

L'identifiant obtenu se pose dans un champ image de fiche, ou dans
`fond.image_id` d'une section. Le téléversement passe par l'administration :
c'est là que s'appliquent le plafond de poids et la garde contre les images
qui font tomber le serveur en se dépliant.

## Les fiches : une page dessinée une fois, autant de pages qu'il y a de fiches

C'est le cas d'usage le plus rentable de cette API, et il mérite d'être compris
avant de construire trente pages à la main.

Un **modèle de fiche** (« Produit », « Réalisation », « Membre de l'équipe »)
déclare des champs et désigne une page qui lui sert de gabarit. Cette page
contient des jetons `[%code%]` remplacés, pour chaque fiche, par ses valeurs.

    GET /modeles/     ← le contrat : quels modèles, quels champs, quels types
    POST /objets/creer/  {"modele": "produit",
                          "titre": "Chaise Ada",
                          "valeurs": {"description": "…", "prix_barre": "149 €"}}

Le `GET /modeles/` n'est pas facultatif : c'est là que vous apprenez qu'un
champ s'appelle `prix_barre` et qu'il attend du texte court. Écrire un code de
champ au jugé produit une erreur 400 — utile, elle liste les codes valides,
mais c'est un aller-retour de perdu.

**Les champs se remplissent selon leur type** :

    text / rich_text  "une chaîne"
    image             12                      (identifiant d'une image de la médiathèque)
    video             "https://…"
    button            {"libelle": "Acheter", "page_id": 7}
                      ou "url_externe", ou "questionnaire"

Comme pour les paramètres de page, **ce que vous ne mentionnez pas ne bouge
pas** : corriger un prix ne remet pas la description à zéro.

## Les produits : le commerce d'une fiche

Une fiche porte le contenu, un produit porte la vente. Les deux sont liés :

    POST /produits/creer/  {"type": "objet", "fiche_id": 42,
                            "sku": "chaise-ada", "prix_ht": "120.00", "stock": 8}

Créer la fiche d'abord, le produit ensuite. Un produit sans fiche n'a rien à
afficher.

## Un exemple complet

Créer une page « Nos tarifs » avec une section à deux colonnes :

    POST /pages/creer/            {"titre": "Nos tarifs"}
                                  → page.id
    POST /pages/<page>/sections/  {"gabarit": "CLASSIC"}
                                  → section.id
    POST /sections/<sec>/lignes/  {"colonnes": 2}
                                  → ligne.id
    POST /lignes/<lig>/blocs/     {"colonne": 0}
                                  → bloc.id
    PUT  /blocs/<bloc>/contenu/   {"type": "TEXT", "texte": "<h2>Nos tarifs</h2>"}
    PATCH /sections/<sec>/        {"fond": {"couleur": "rgba(246,246,246,1)"},
                                   "paddings": {"computer": {"haut": "60px", "bas": "60px"},
                                                "phone": {"haut": "30px", "bas": "30px"}}}
    PATCH /pages/<page>/          {"publiee": true}

Sept appels pour une page complète et en ligne.

## Quand ça ne marche pas

- **401** — votre jeton n'est pas accepté. Le message ne dit jamais pourquoi,
  volontairement. Vérifiez que vous l'envoyez bien en en-tête
  `Authorization: Bearer <jeton>`, et que vous êtes en HTTPS.
- **403** — vous êtes identifié mais votre rôle ne le permet pas. La réponse
  nomme la permission qui manque ; c'est à l'exploitant du site de vous
  l'accorder.
- **400** — votre document est mal formé. Le message dit quoi, et liste
  souvent les valeurs acceptées.
- **409** — conflit, typiquement une adresse de page déjà prise.
""".strip()


def _theme_du_site():
    """
    La palette du site, pour qu'un agent l'emploie au lieu d'inventer.

    Sans elle, chaque page construite par une IA arrive avec ses propres
    couleurs, et le site devient un patchwork. Avec elle, l'agent écrit
    `var(--jk-accent)` et suit ce que l'exploitant a réglé.
    """
    from jeiko.administration.website_cache import get_website_data

    site = get_website_data()
    theme = getattr(site, "theme", None) if site else None
    if theme is None:
        return None

    return {
        "couleurs": theme.couleurs(),
        "variables_css": [variable for _, variable in theme.VARIABLES],
        "comment_s_en_servir": (
            "Écrivez var(--jk-accent) dans le CSS d'un bloc plutôt qu'une "
            "couleur en dur : le jour où l'exploitant change sa palette dans "
            "Réglages ▸ Thème, votre page suit toute seule."
        ),
    }



# ---------------------------------------------------------------------------
#  Le catalogue
# ---------------------------------------------------------------------------
#
# Un agent qui découvre JEIKO ne connaît pas ses blocs. Lui donner la liste des
# routes ne suffit pas : il saura POSER un contenu sans savoir LEQUEL choisir.
# D'où ce catalogue — une phrase par outil, qui dit à quoi il sert et ce qu'il
# attend.
#
# Les options viennent de `DYNAMIC_DEFAULTS`, les éléments de `TYPES` : ce sont
# les constantes que le code applique réellement. Une option ajoutée demain
# apparaîtra ici sans que personne y pense.

#: À quoi sert chaque bloc, en une phrase. La seule part écrite à la main du
#: catalogue — une intention ne s'introspecte pas. Un type absent d'ici sortira
#: quand même, sans sa phrase : le catalogue reste complet, jamais tronqué.
ROLE_DES_BLOCS = {
    "TEXT": ("Du texte riche (HTML). Le bloc le plus courant : titres, paragraphes, "
             "listes. C'est AUSSI le bloc des pages modèles : les jetons [%code%] "
             "qu'il contient sont remplacés au rendu par les valeurs de la fiche "
             "affichée — plus « titre » et « slug », que toute fiche possède."),

    "IMAGE": "Une image de la médiathèque. Le fichier se dépose depuis l'administration.",
    "BUTTON": "Un bouton d'appel à l'action, vers une page, une URL ou un panier.",
    "VIDEO": "Une vidéo.",
    "FORM": "Un formulaire de contact : ses champs, son destinataire, son message de succès.",
    "CALENDAR": "Un calendrier de prise de rendez-vous.",
    "CHART": "Un graphique.",
    "DYN_FAQ": "Questions/réponses dépliables. « multiple » autorise plusieurs ouvertes à la fois.",
    "DYN_TABS": "Des onglets. « active » est l'index de celui ouvert au chargement.",
    "DYN_CAROUSEL": "Un carrousel d'images qui défile.",
    "DYN_PROGRESS": "Des barres de progression, ou un fil d'étapes franchies.",
    "DYN_TESTIMONIALS": "Des témoignages qui défilent, un à la fois.",
    "DYN_TESTIMONIALS_GRID": "Des témoignages en grille. « perRow » fixe le nombre par rangée.",
    "DYN_FILTER": "Une liste filtrable en direct. « keys » dit sur quels champs porte la recherche.",
    "DYN_COUNTDOWN": "Un compte à rebours vers « deadline » (date ISO).",
    "DYN_COUNTDOWN_CTA": "Un compte à rebours doublé d'un bouton.",
    "DYN_ACCORDION_ADV": "Un accordéon à deux niveaux : des sections, chacune avec ses entrées.",
    "DYN_PRICING_TABLE": "Une table de tarifs. « yearly » affiche d'emblée la bascule annuelle.",
    "DYN_GALLERY_FILTER": "Une galerie d'images filtrable par catégorie.",
    "DYN_STEPPER": "Un parcours en étapes numérotées.",
    "DYN_RATING": "Une note sur « max » étoiles, avec le nombre d'avis.",
    "DYN_RESOURCE_CAROUSEL": "Un carrousel alimenté par des ressources du site.",
    "DYN_RESOURCE_GRID": "Une grille alimentée par des ressources du site.",
}


def _catalogue_des_blocs():
    """
    Tous les contenus posables, avec leurs options et leurs éléments.

    L'ordre des clés est celui de la lecture : ce que c'est, puis ce qui se
    règle, puis ce qui se liste.
    """
    from jeiko.administration_pages.models import DYNAMIC_DEFAULTS

    catalogue = {}
    for type_ in sorted(TYPES_OUVERTS):
        fiche = {"role": ROLE_DES_BLOCS.get(type_, "")}

        defauts = DYNAMIC_DEFAULTS.get(type_)
        if defauts is not None:
            # Les listes de `DYNAMIC_DEFAULTS` sont l'emplacement des éléments,
            # pas une option : les montrer ferait croire qu'on peut les écrire
            # directement dans « options ». Elles se remplissent par
            # « elements », et par lui seul.
            fiche["options"] = {
                cle: valeur for cle, valeur in defauts.items()
                if not isinstance(valeur, list)
            }

        if type_ in _dyn.TYPES:
            _, _, correspondances = _dyn.TYPES[type_]
            fiche["elements"] = sorted(correspondances)
        elif type_ in _dyn.TYPES_SANS_ELEMENTS:
            fiche["elements"] = "aucun — tout se règle dans « options »"

        # Les contenus non dynamiques ont, eux, un document de champs nommé
        # d'après le type (« dyn_resource_grid », « chart »…). Ne pas les
        # documenter laissait un agent deviner que la grille de ressources
        # accepte « type_de_produit » — c'est-à-dire ne jamais s'en servir.
        if type_ in CONTENUS_SIMPLES:
            lien, _, correspondances = CONTENUS_SIMPLES[type_]
            fiche["document"] = type_.lower()
            fiche["champs"] = sorted(correspondances)

        catalogue[type_] = fiche
    return catalogue


#: Version de l'API, et ce qu'elle promet.
#:
#: `/api/agent/v1/` est la v1. Ce qui suit n'est pas une intention mais une
#: règle, parce qu'un agent écrit du code contre ce contrat et ne relit pas le
#: guide à chaque appel.
#:
#: **Ce qui peut changer dans la v1**, sans prévenir :
#:   * l'AJOUT d'une route, d'un champ, d'un type de bloc ;
#:   * l'ajout d'une clé dans une réponse ;
#:   * un message d'erreur, qui est pour l'humain qui lit le journal.
#:
#: **Ce qui ne change pas dans la v1** :
#:   * le nom et le sens d'une clé existante — en requête comme en réponse ;
#:   * le chemin d'une route livrée ;
#:   * la permission exigée par une route, sauf pour l'assouplir.
#:
#: Le jour où l'un de ces trois derniers doit bouger, ce sera `/v2/`, servie
#: **à côté** de la v1 le temps que les agents migrent — pas à la place. Une
#: rupture silencieuse sur la même adresse est le pire des deux mondes : le
#: code continue de tourner et écrit n'importe quoi.
#:
#: Les refus de clés inconnues, ajoutés le 03/09, rendent cette promesse
#: tenable : un agent qui envoie une clé retirée reçoit une erreur au lieu
#: d'un succès muet.
VERSION = {
    "numero": "1",
    "racine": RACINE,
    "compatible": [
        "Ajout d'une route, d'un champ, d'un type de bloc.",
        "Ajout d'une clé dans une réponse.",
        "Reformulation d'un message d'erreur.",
    ],
    "rupture": [
        "Renommer ou changer le sens d'une clé existante.",
        "Déplacer ou retirer une route livrée.",
        "Durcir la permission exigée par une route.",
    ],
    "en_cas_de_rupture": (
        "Une /v2/ est servie À CÔTÉ de la v1, pas à la place, le temps que "
        "les agents migrent. Une rupture silencieuse sur la même adresse "
        "laisserait le code tourner en écrivant n'importe quoi."
    ),
}


def construire():
    """Le guide complet, prose et références."""
    return {
        "guide": PROSE,
        "racine": RACINE,
        "version": VERSION,
        "points_d_entree": _points_d_entree(),
        "theme_du_site": _theme_du_site(),
        "vocabulaire": {
            "page": "Une adresse du site. Contient des sections, dans l'ordre.",
            "section": "Une bande horizontale. Contient des lignes.",
            "ligne": "Une rangée découpée en colonnes. Contient des blocs.",
            "bloc": "Une case dans une colonne. Contient un contenu.",
            "colonne": "Numéro de colonne d'un bloc, à partir de 0. PAS un rang vertical.",
            "rang": "Position verticale d'un bloc dans sa colonne, à partir de 0.",
        },
        "gabarits_de_section": {
            nom: "largeurs : " + ", ".join(
                f"{appareil} {largeur}"
                for appareil, largeur in gabarit["tailles"].items()
            )
            for nom, gabarit in fabrique.GABARITS_SECTION.items()
        },
        "parametres": _document_de_parametres(),
        "contenus": {
            "modifiables_par_l_api": list(TYPES_OUVERTS),
            "tous_ouverts": True,
            "note": (
                "Les vingt-quatre types sont ouverts. Les blocs dynamiques "
                "— FAQ, onglets, carrousel, tarifs, témoignages, galerie… — "
                "partagent une même forme : des « options » (un objet libre) "
                "et une liste « elements ». Envoyer « elements » REMPLACE la "
                "liste entière : une liste ordonnée n'a pas de clé stable sur "
                "laquelle fusionner, et rapprocher par position mettrait une "
                "réponse sous la mauvaise question. Omettre « elements » ne "
                "touche qu'aux options."
            ),
            "formes": {
                "TEXT": {"type": "TEXT", "texte": "<p>du HTML</p>"},
                "BUTTON": {
                    "type": "BUTTON",
                    "bouton": {
                        "libelle": "Nous contacter",
                        "page_id": 7,
                        "_ou_bien": "url_externe / questionnaire / ajouter_au_panier",
                        "nouvel_onglet": False,
                        "style": {"fond": "rgb(180,83,9)", "couleur_texte": "#fff",
                                  "rayon": "9px", "padding": "14px 28px"},
                    },
                    "_note": ("Le bouton n'a PAS de champ « url » : sa destination "
                              "dépend de sa nature. Écrire « url » ne fait rien."),
                },
                "FORM": {
                    "type": "FORM",
                    "formulaire": {
                        "nom": "Contact",
                        "destinataire": "contact@exemple.fr",
                        "sujet": "Nouveau message",
                        "message_de_succes": "Merci, nous vous répondons vite.",
                        "champs": [
                            {"nom": "email", "libelle": "Votre e-mail",
                             "type": "email", "obligatoire": True},
                            {"nom": "message", "libelle": "Votre message",
                             "type": "textarea", "obligatoire": True},
                        ],
                    },
                    "_note": ("Envoyer « champs » REMPLACE la liste entière : un "
                              "formulaire est un tout, et fusionner par position "
                              "mélangerait les libellés. Omettre « champs » laisse "
                              "les existants intacts."),
                },
                "IMAGE": {"type": "IMAGE",
                          "note": "Crée le réceptacle ; le fichier se dépose depuis l'administration."},
            },
        },
        "catalogue_des_blocs": _catalogue_des_blocs(),
        "champs_de_page": {
            "modifiables": sorted(
                list(CHAMPS_PAGE_MODIFIABLES)
                + list(CHAMPS_PAGE_CATEGORIES)
                + ["metadonnees"]
            ),
            "fermes": {
                "protegee": (
                    "Se lit, ne s'écrit pas : c'est un contrôle d'ACCÈS, pas "
                    "de contenu. Retirer la protection d'une page réservée, ou "
                    "en protéger une par erreur, sont des décisions "
                    "d'exploitant."
                ),
            },
            "a_savoir": {
                "metadonnees": (
                    "« titre » (~60 caractères) et « description » "
                    "(~155 caractères) : c'est ce que Google affiche, et ce "
                    "que montrent les partages. Facultatives en base, elles "
                    "devraient être écrites À LA CRÉATION — une page publiée "
                    "sans elles part avec un handicap que personne ne revient "
                    "corriger. Laissées vides, le titre de la page sert de "
                    "repli, et la description n'existe pas."
                ),
                "racine": (
                    "Une seule page racine par site : la déclarer DÉPLACE la "
                    "page d'accueil, l'ancienne perd le drapeau. Ce n'est pas "
                    "destructeur, mais ce n'est pas anodin."
                ),
                "categorie": (
                    "Par slug, par identifiant ou par nom exact — certaines "
                    "catégories ne servent qu'au regroupement et n'ont pas de "
                    "slug. La sous-catégorie doit appartenir à la catégorie "
                    "annoncée. Voir /categories/."
                ),
                "publiee": (
                    "Une page créée par un agent naît en BROUILLON. La mise "
                    "en ligne est un appel séparé et explicite."
                ),
            },
        },
        "interdits": [
            "Supprimer une page — aucune route, aucune permission.",
            "Publier une page à sa création — elle naît en brouillon.",
            "Téléverser un fichier — la médiathèque passe par l'administration.",
            "Supprimer une fiche ou un produit — un agent crée et corrige, il n'efface pas.",
            "Publier une fiche ou activer un produit à la création — les deux naissent inactifs.",
        ],
    }
