# jeiko/administration/tests_police_pied_de_page.py
"""
Le pied de page doit suivre la police du site, crédits compris.

Ce qui s'est passé
------------------
Constat de l'exploitant après avoir changé la police du site : « le footer
personnalisable avec le menu est bien passé en Inter, mais pas le bas bas ».

Le menu du pied recevait bien la police — il porte la classe `.menu`, visée par
les règles générées. Les crédits, eux, n'étaient visés par aucune règle : ils
restaient dans la police par défaut du navigateur.

Sur un site dont tout le reste a changé, c'est le seul bloc qui détonne — et
il est en bas de chaque page.

Ce que ce test garde
--------------------
Il lit le CSS généré plutôt qu'un rendu : c'est cette feuille qui part chez le
visiteur, et une règle manquante y est absente quelle que soit la page.
"""

from django.contrib.auth import get_user_model
from django.test import TestCase


class PoliceDuPiedDePageTests(TestCase):
    def _css_de_la_page(self):
        reponse = self.client.get("/")
        self.assertEqual(reponse.status_code, 200)
        return reponse.content.decode()

    def test_les_credits_recoivent_une_police(self):
        css = self._css_de_la_page()
        self.assertIn(
            "footer .credits", css,
            "Aucune règle ne vise les crédits : ils restent dans la police par "
            "défaut du navigateur, seuls sur un site entièrement rhabillé.",
        )

    def test_la_regle_couvre_les_trois_appareils(self):
        """
        Les polices sont déclinées par appareil. Ne couvrir que l'ordinateur
        laisserait le défaut réapparaître sur téléphone — là où on regarde le
        moins.
        """
        css = self._css_de_la_page()
        self.assertGreaterEqual(
            css.count("footer .credits"), 3,
            "La règle doit figurer dans les trois blocs d'appareil.",
        )

    def test_le_menu_du_pied_reste_couvert(self):
        """Il l'était déjà : la correction ne doit pas le lui retirer."""
        self.assertIn(".menu a", self._css_de_la_page())
