"""
BOITE-01 — la boîte de réception du CRM : relever les e-mails des visiteurs,
y répondre depuis le site.

Les e-mails du site partent d'une adresse « no-reply », avec l'adresse de
contact en reply-to. Quand un visiteur répond, sa réponse arrive dans la boîte
de contact — lue hors du site, et absente de la fiche. Ce module relève cette
boîte (et d'autres : `CompteMessagerie`), et range chaque message sous
l'ADRESSE de son expéditeur : le fil d'une personne se lit sur sa fiche,
comme le reste de son historique.

La connexion IMAP est celle des rebonds (`newsletter/rebonds.py`) :
bibliothèque standard, certificat et nom du serveur vérifiés.

Ce que la relève ne fait pas, par choix :
* toucher à la boîte : dossier ouvert en LECTURE SEULE (`EXAMINE`), corps lus
  avec `BODY.PEEK` — rien n'est marqué lu, déplacé ni supprimé ; la boîte
  reste utilisable dans la messagerie habituelle ;
* remonter tout le passé : la première relève d'un compte part des 30
  derniers jours, puis suit les UID ;
* garder les avis de non-remise (c'est le travail des rebonds), les réponses
  automatiques (`Auto-Submitted`), ni les messages de plus de 20 Mo ;
* copier les pièces jointes : seuls leur nom et leur taille sont gardés ; la
  pièce est relue dans la boîte au clic (`piece_jointe`). Effacée de la boîte,
  elle n'est plus téléchargeable.

Le HTML d'un e-mail entrant est écrit par n'importe qui : il passe par
`jeiko/sanitize.py`, puis perd ses images et médias (pixels espions,
chargements qui disent au tiers que le message est lu) et ses classes et
identifiants (un faux bouton aux couleurs de l'administration, un `id` qui
écrase celui d'un élément de la page). Si l'assainissement est désactivé
(`JEIKO_SANITIZE_HTML = False`, qui vise des rédacteurs de confiance), le HTML
entrant n'est pas gardé du tout : seul le texte l'est.

Ce que `repondre` garantit : rien ne part sans le geste d'une personne de
l'équipe ; aucune réponse automatique n'existe. Ce qu'elle ne fait pas : copier
la réponse dans le dossier « Envoyés » de la boîte — elle n'est que sur le site.
"""
import email
import imaplib
import logging
import re
import ssl
from datetime import timedelta
from email import policy
from email.utils import getaddresses, make_msgid, parsedate_to_datetime

from django.conf import settings
from django.db import IntegrityError, transaction
from django.utils import timezone
from django.utils.html import strip_tags

from jeiko.emailing.models import CompteMessagerie, MessageEmail

logger = logging.getLogger(__name__)

#: Au plus par relevé et par compte : une boîte pleine ne bloque pas le cron.
MESSAGES_PAR_RELEVE = 50
#: Plus gros, un message n'est pas relevé (il reste lisible dans la messagerie).
TAILLE_MAXIMALE = 20_000_000
#: La première relève d'un compte ne remonte pas plus loin.
PREMIERE_RELEVE = timedelta(days=30)
#: Un corps de texte au-delà est tronqué : c'est un e-mail, pas une archive.
TEXTE_MAXIMAL = 200_000


# ---------------------------------------------------------------------------
#  Lire un message
# ---------------------------------------------------------------------------

_MEDIAS = re.compile(r"</?(?:img|video|audio|source|picture)\b[^>]*>", re.IGNORECASE)
_ATTRIBUTS_DE_PAGE = re.compile(r'\s(?:class|id|role)="[^"]*"', re.IGNORECASE)


def nettoyer_html(html):
    """Le HTML d'un e-mail entrant, sûr à afficher dans l'administration — ou "" (voir l'en-tête)."""
    if not html or not getattr(settings, "JEIKO_SANITIZE_HTML", True):
        return ""
    from jeiko.sanitize import clean_html

    propre = clean_html(html)
    return _ATTRIBUTS_DE_PAGE.sub("", _MEDIAS.sub("", propre)).strip()


def _une_ligne(valeur, longueur):
    return " ".join(str(valeur or "").split())[:longueur]


def _nom_de_fichier(nom):
    """Un nom de pièce jointe sans chemin ni caractère de contrôle."""
    nom = re.sub(r"[\x00-\x1f\x7f/\\]", "_", str(nom or "")).strip(" .")
    return nom[:150] or "piece-jointe"


def _pieces(message):
    """[(index, partie)] des pièces jointes, dans l'ordre de `walk()` — qui est stable pour un même message."""
    return [(i, partie) for i, partie in enumerate(message.walk())
            if not partie.is_multipart()
            and (partie.get_content_disposition() == "attachment"
                 or (partie.get_filename() and partie.get_content_disposition() != "inline"))]


def _contenu(partie):
    try:
        return partie.get_content()
    except (LookupError, ValueError, AssertionError):  # jeu de caractères inconnu, encodage cassé
        octets = partie.get_payload(decode=True) or b""
        return octets.decode("utf-8", errors="replace")


def lire(brut):
    """
    Les champs d'un `MessageEmail` reçu, d'après le message brut — ou None
    quand il n'a rien à faire dans la boîte (avis de non-remise, réponse
    automatique, expéditeur illisible).
    """
    message = email.message_from_bytes(brut, policy=policy.default)
    if message.get_content_type() == "multipart/report":
        return None
    if (message.get("Auto-Submitted") or "no").strip().lower() != "no":
        return None
    try:
        expediteurs = getaddresses([str(message.get("From") or "")])
    except (TypeError, ValueError):
        return None
    nom, adresse = expediteurs[0] if expediteurs else ("", "")
    adresse = (adresse or "").strip().lower()
    if "@" not in adresse:
        return None
    try:
        date = parsedate_to_datetime(str(message.get("Date")))
        if timezone.is_naive(date):
            date = timezone.make_aware(date, timezone.utc)
    except (TypeError, ValueError, IndexError):
        date = timezone.now()

    texte = html = ""
    corps = message.get_body(preferencelist=("plain",))
    if corps is not None:
        texte = _contenu(corps)
    corps_html = message.get_body(preferencelist=("html",))
    if corps_html is not None:
        brut_html = _contenu(corps_html)
        html = nettoyer_html(brut_html)
        if not texte.strip():
            texte = strip_tags(brut_html)

    return {
        "adresse": adresse[:254],
        "nom": _une_ligne(nom, 200),
        "sujet": _une_ligne(message.get("Subject"), 300),
        "date": date,
        "message_id": _une_ligne(message.get("Message-ID"), 300),
        "en_reponse_a": _une_ligne(message.get("In-Reply-To"), 300),
        "references": _une_ligne(message.get("References"), 5000),
        "texte": texte.strip()[:TEXTE_MAXIMAL],
        "html": html[:TEXTE_MAXIMAL],
        "pieces_jointes": [
            {"index": i, "nom": _nom_de_fichier(p.get_filename()), "taille": len(p.get_payload(decode=True) or b"")}
            for i, p in _pieces(message)
        ],
    }


# ---------------------------------------------------------------------------
#  Relever
# ---------------------------------------------------------------------------

def _ouvrir(compte):
    """Une session IMAP sur le dossier du compte, en lecture seule. Rend (boîte, uidvalidity)."""
    # Sans contexte, imaplib chiffre SANS vérifier le certificat (audit NL-03).
    boite = imaplib.IMAP4_SSL(compte.imap_hote, compte.imap_port, timeout=30,
                              ssl_context=ssl.create_default_context())
    try:
        boite.login(compte.imap_utilisateur, compte.imap_mot_de_passe)
        etat, _info = boite.select(compte.imap_dossier or "INBOX", readonly=True)
        if etat != "OK":
            raise imaplib.IMAP4.error(f"dossier introuvable : {compte.imap_dossier}")
        _nom, valeurs = boite.response("UIDVALIDITY")
        uidvalidity = (valeurs[0] or b"").decode() if valeurs and valeurs[0] else ""
    except Exception:
        _fermer(boite)
        raise
    return boite, uidvalidity


def _fermer(boite):
    try:
        boite.logout()
    except Exception:  # noqa: BLE001 — la session peut déjà être fermée
        pass


def _uids(boite, *criteres):
    etat, donnees = boite.uid("SEARCH", None, *criteres)
    if etat != "OK":
        raise imaplib.IMAP4.error("recherche refusée par le serveur")
    return sorted(int(u) for u in (donnees[0] or b"").split())


def _octets(boite, uid):
    _etat, morceaux = boite.uid("FETCH", str(uid), "(BODY.PEEK[])")
    return next((m[1] for m in morceaux or [] if isinstance(m, tuple)), None)


def relever(compte):
    """Relève un compte. Rend le nombre de messages enregistrés. Ne lève jamais."""
    if not (compte.imap_hote and compte.imap_utilisateur and compte.imap_mot_de_passe):
        return 0
    enregistres, erreur = 0, ""
    try:
        boite, uidvalidity = _ouvrir(compte)
        try:
            if uidvalidity != compte.uidvalidity:
                # Dossier recréé : les anciens UID ne désignent plus rien.
                compte.uidvalidity, compte.dernier_uid = uidvalidity, 0
            criteres = [f"UID {compte.dernier_uid + 1}:*"]
            if compte.dernier_uid == 0:
                depuis = timezone.localdate() - PREMIERE_RELEVE
                criteres.append(f"SINCE {depuis.strftime('%d-%b-%Y')}")
            # « n:* » rend toujours le dernier message, même plus ancien que n.
            tous = [u for u in _uids(boite, *criteres) if u > compte.dernier_uid][:MESSAGES_PAR_RELEVE]
            petits = set(_uids(boite, *criteres, f"SMALLER {TAILLE_MAXIMALE}")) if tous else set()
            propres = {a.lower() for a in CompteMessagerie.objects.values_list("adresse", flat=True)}
            for uid in tous:
                brut = _octets(boite, uid) if uid in petits else None
                champs = lire(brut) if brut else None
                # Une copie de ce qu'un compte a lui-même envoyé n'est pas un message reçu.
                if champs and champs["adresse"] not in propres:
                    try:
                        with transaction.atomic():
                            MessageEmail.objects.create(compte=compte, sens=MessageEmail.Sens.RECU, uid=uid,
                                                        uidvalidity=uidvalidity, **champs)
                        enregistres += 1
                    except IntegrityError:
                        pass  # déjà enregistré par une relève concurrente
                compte.dernier_uid = uid
                CompteMessagerie.objects.filter(pk=compte.pk).update(
                    uidvalidity=compte.uidvalidity, dernier_uid=uid)
        finally:
            _fermer(boite)
    except Exception as exc:  # noqa: BLE001 — un serveur injoignable ne doit pas faire échouer le cron
        logger.warning("Relevé de la boîte « %s » impossible : %s", compte.nom, exc)
        erreur = str(exc)[:300]
    CompteMessagerie.objects.filter(pk=compte.pk).update(
        uidvalidity=compte.uidvalidity, releve_le=timezone.now(), erreur=erreur)
    return enregistres


def relever_tout():
    """Relève tous les comptes actifs (cron_5m). Rend le nombre de messages enregistrés."""
    return sum(relever(compte) for compte in CompteMessagerie.objects.filter(actif=True))


def piece_jointe(message, index):
    """
    (nom, octets) de la pièce jointe `index` d'un message reçu, relue dans la
    boîte — ou None si elle n'y est plus. Lève si le serveur est injoignable.
    """
    connue = next((p for p in message.pieces_jointes if p.get("index") == index), None)
    compte = message.compte
    if connue is None or compte is None or message.uid is None:
        return None
    boite, uidvalidity = _ouvrir(compte)
    try:
        if uidvalidity != message.uidvalidity:
            return None
        brut = _octets(boite, message.uid)
    finally:
        _fermer(boite)
    if not brut:
        return None
    pieces = dict(_pieces(email.message_from_bytes(brut, policy=policy.default)))
    partie = pieces.get(index)
    if partie is None or _nom_de_fichier(partie.get_filename()) != connue["nom"]:
        return None
    return connue["nom"], partie.get_payload(decode=True) or b""


# ---------------------------------------------------------------------------
#  Répondre
# ---------------------------------------------------------------------------

def compte_pour_repondre(message):
    """Le compte qui a reçu le message ; s'il n'existe plus, le compte par défaut."""
    return message.compte or CompteMessagerie.objects.filter(par_defaut=True).first()


def _connexion(compte):
    from django.core.mail import get_connection

    from jeiko.emailing.sending import SMTP_BACKEND, get_mail_connection

    configure = getattr(settings, "EMAIL_BACKEND", SMTP_BACKEND)
    if configure != SMTP_BACKEND:
        # locmem sous les tests, console en développement (voir sending.py).
        return get_connection(backend=configure)
    if compte.smtp_hote:
        return get_connection(backend=SMTP_BACKEND, host=compte.smtp_hote, port=compte.smtp_port,
                              username=compte.smtp_utilisateur or None,
                              password=compte.smtp_mot_de_passe or None,
                              use_tls=compte.smtp_tls, use_ssl=compte.smtp_ssl, timeout=10)
    return get_mail_connection()[0]


def citation(message):
    """Le message d'origine, cité sous la réponse, à la façon des messageries."""
    entete = f"{timezone.localtime(message.date):%d/%m/%Y %H:%M}, {message.nom or message.adresse} <{message.adresse}> :"
    lignes = (message.texte or "").splitlines() or [""]
    return entete + "\n" + "\n".join(f"> {ligne}" for ligne in lignes)


def repondre(message, corps, auteur):
    """
    Répond à `message` (reçu) par le compte qui l'a reçu. Rend (réponse | None,
    erreur | None). Appelée par une vue, sur le geste d'une personne : rien
    d'autre dans JEIKO n'envoie depuis la boîte.
    """
    from jeiko.emailing.sending import send_message

    compte = compte_pour_repondre(message)
    if compte is None:
        return None, "Aucun compte de messagerie"
    connexion = _connexion(compte)
    if connexion is None:
        return None, "Configuration email manquante ou inactive"

    sujet = message.sujet or ""
    if not re.match(r"^\s*(re|ré|aw|sv)\s*:", sujet, re.IGNORECASE):
        sujet = f"Re: {sujet}".strip()
    domaine = compte.adresse.rsplit("@", 1)[-1]
    message_id = make_msgid(domain=domaine)
    entetes = {"Message-ID": message_id}
    references = " ".join(x for x in (message.references, message.message_id) if x)
    if message.message_id:
        # La messagerie du visiteur range la réponse dans le même fil.
        entetes.update({"In-Reply-To": message.message_id, "References": references})
    texte = f"{corps.strip()}\n\n{citation(message)}"

    ok, erreur = send_message(sujet, texte, to=[message.adresse], from_email=compte.adresse,
                              reply_to=[compte.adresse], connection=connexion, headers=entetes)
    if not ok:
        return None, erreur
    reponse = MessageEmail.objects.create(
        compte=compte, sens=MessageEmail.Sens.ENVOYE, adresse=message.adresse, nom=message.nom,
        sujet=sujet[:300], date=timezone.now(), message_id=message_id, en_reponse_a=message.message_id,
        references=references, texte=texte, envoye_par=auteur,
    )
    if message.lu_le is None:
        MessageEmail.objects.filter(pk=message.pk).update(lu_le=timezone.now())
    return reponse, None
