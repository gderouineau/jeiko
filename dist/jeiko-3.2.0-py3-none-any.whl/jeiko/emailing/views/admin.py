# jeiko/emailing/views/admin.py
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views import View

from jeiko.emailing import registry, render as email_render
from jeiko.emailing.builder import apply_seed
from jeiko.emailing.forms import EmailTemplateForm
from jeiko.emailing.models import EmailTemplate
from jeiko.emailing.seeds import get_seed

# Réutilise la permission des réglages email tant que l'app n'a pas les siennes.
EMAILING_PERMISSION = "users.config_edit_mail"


class EmailTemplateListView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """Catalogue des e-mails, groupé par catégorie."""

    template_name = "emailing/admin/template_list.html"
    permission_required = EMAILING_PERMISSION

    def get(self, request):
        templates_by_code = {t.code: t for t in EmailTemplate.objects.select_related("page")}

        categories = []
        for key, label, events in registry.events_by_category():
            rows = [
                {
                    "code": code,
                    "event": event,
                    "audience_label": registry.AUDIENCE_LABELS.get(event["audience"], ""),
                    "template": templates_by_code.get(code),
                    "has_seed": get_seed(code) is not None,
                    # Un e-mail obligatoire ne se coupe pas : la liste affiche
                    # le verrou et le motif plutôt qu'un bouton qui échouerait.
                    "mandatory": registry.is_mandatory(code),
                    "mandatory_reason": registry.mandatory_reason(code),
                }
                for code, event in events
            ]
            categories.append({
                "key": key,
                "label": label,
                "rows": rows,
                "configured": sum(1 for row in rows if row["template"]),
                "total": len(rows),
            })

        # Templates dont le code a disparu du catalogue.
        orphans = [t for t in templates_by_code.values() if t.is_orphan]

        return render(request, self.template_name, {
            "categories": categories,
            "orphans": orphans,
            "total_events": len(registry.EMAIL_EVENTS),
            "total_configured": sum(1 for t in templates_by_code.values() if not t.is_orphan),
        })


class EmailTemplateUpdateView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Édition du sujet et des réglages d'envoi d'un e-mail.

    Le template est créé à la volée au premier accès : le catalogue fait foi,
    la base ne stocke que ce qui a été personnalisé.
    """

    template_name = "emailing/admin/template_form.html"
    permission_required = EMAILING_PERMISSION

    def get_object(self, code):
        event = registry.get_event(code)
        if event is None:
            # Code hors catalogue : on n'édite que ce qui existe déjà en base.
            return get_object_or_404(EmailTemplate, code=code)

        template, _ = EmailTemplate.objects.get_or_create(
            code=code,
            defaults={"subject": f"[%site_nom%] — {event['label']}"},
        )
        return template

    def get_context(self, template, form):
        context = email_render.sample_context(template.code)
        _, warnings = email_render.render_page(template.page, context)

        return {
            "template": template,
            "form": form,
            "variables": template.available_variables(),
            "is_transactional": registry.is_transactional(template.code),
            "preview_subject": template.render_subject(context),
            "preview_warnings": warnings,
            "preview_url": reverse(
                "jeiko_administration_emailing:template_preview",
                args=[template.code],
            ),
            "has_seed": get_seed(template.code) is not None,
        }

    def get(self, request, code):
        template = self.get_object(code)
        form = EmailTemplateForm(instance=template)
        return render(request, self.template_name, self.get_context(template, form))

    def post(self, request, code):
        template = self.get_object(code)
        form = EmailTemplateForm(request.POST, instance=template)

        if form.is_valid():
            form.save()
            messages.success(request, "Modèle d'e-mail enregistré.")
            return redirect(reverse("jeiko_administration_emailing:template_edit", args=[code]))

        return render(request, self.template_name, self.get_context(template, form))


class EmailTemplateResetView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Remet un e-mail dans son état d'origine.

    Passe par le même `apply_seed` que l'installation : un e-mail réinitialisé
    est rigoureusement identique à un e-mail fraîchement posé. L'ancienne page
    n'est pas supprimée mais archivée, pour qu'un clic malheureux ne fasse pas
    perdre le travail de mise en page.
    """

    permission_required = EMAILING_PERMISSION

    def post(self, request, code):
        get_object_or_404(EmailTemplate, code=code)

        outcome = apply_seed(code, force=True)

        if outcome == "no_seed":
            messages.error(
                request,
                "Aucun contenu par défaut n'est déclaré pour cet e-mail.",
            )
        else:
            messages.success(
                request,
                "Contenu réinitialisé. La version précédente a été archivée "
                "et reste consultable dans les pages désactivées.",
            )

        # Réinitialiser depuis la liste doit y ramener, pas ouvrir l'édition.
        if request.POST.get("next") == "list":
            return redirect(reverse("jeiko_administration_emailing:template_list"))

        return redirect(reverse("jeiko_administration_emailing:template_edit", args=[code]))


class EmailTemplatePreviewView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Rendu e-mail brut, destiné à être affiché dans une iframe.

    Indispensable : l'éditeur visuel montre le rendu web (grille CSS, media
    queries), pas ce qui sera réellement envoyé.
    """

    permission_required = EMAILING_PERMISSION

    def get(self, request, code):
        template = get_object_or_404(EmailTemplate, code=code)
        context = email_render.sample_context(code)
        html, _ = email_render.render_page(template.page, context)

        if not html:
            html = (
                "<!DOCTYPE html><html><body "
                "style=\"font-family:Arial,sans-serif;padding:24px;color:#888;\">"
                "Aucun contenu à afficher.</body></html>"
            )

        return HttpResponse(html)


class EmailTemplateToggleActiveView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Active ou coupe un e-mail, en un geste depuis la liste.

    Le drapeau `EmailTemplate.active` existait et `services.send_email` le
    respectait déjà, mais aucun écran ne permettait de le changer : l'état était
    affiché sans pouvoir être touché.

    Certains e-mails refusent d'être coupés (`registry.MANDATORY_CODES`). Sans
    ce garde-fou, une case décochée par mégarde enfermerait des utilisateurs
    dehors — l'envoi échouant en silence, par conception, personne ne s'en
    apercevrait avant les réclamations.

    POST uniquement : c'est un changement d'état, il n'a rien à faire derrière
    un lien qu'un préchargement peut déclencher.
    """

    permission_required = EMAILING_PERMISSION

    def post(self, request, code):
        template = get_object_or_404(EmailTemplate, code=code)
        libelle = registry.get_event(code) or {}
        nom = libelle.get("label", code)

        if template.active and registry.is_mandatory(code):
            messages.error(
                request,
                f"« {nom} » ne peut pas être désactivé. "
                f"{registry.mandatory_reason(code)}",
            )
        else:
            template.active = not template.active
            template.save(update_fields=["active", "updated_at"])
            if template.active:
                messages.success(request, f"« {nom} » sera de nouveau envoyé.")
            else:
                messages.success(
                    request,
                    f"« {nom} » ne sera plus envoyé, jusqu'à réactivation.",
                )

        return redirect(reverse("jeiko_administration_emailing:template_list"))
