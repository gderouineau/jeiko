import logging

from django.db.models.signals import post_save
from django.dispatch import receiver
from django.conf import settings

logger = logging.getLogger(__name__)

from allauth.account.signals import (
    email_changed as allauth_email_changed,
    password_changed as allauth_password_changed,
    password_reset as allauth_password_reset,
    password_set as allauth_password_set,
    user_signed_up as allauth_user_signed_up,
)

from .models import Profile
from . import emailing as account_emailing


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)


# ---------------------------------------------------------------------------
#  E-mails « Compte & sécurité » — notifications déclenchées par allauth.
#  Les mails d'action (lien) passent par l'adaptateur (voir adapters.py).
# ---------------------------------------------------------------------------

@receiver(allauth_user_signed_up)
def _email_on_signup(request, user, **kwargs):
    account_emailing.send_welcome(user, request)

    # Notification interne : l'exploitant n'apprenait rien des inscriptions sans
    # aller consulter la liste des comptes. Ne doit jamais faire échouer une
    # inscription — l'accessoire ne casse pas le principal.
    try:
        from jeiko.emailing.admin_alerts import notifier_nouvelle_inscription

        notifier_nouvelle_inscription(user)
    except Exception:
        logger.exception("Notification d'inscription à l'administrateur impossible")


@receiver([allauth_password_changed, allauth_password_reset, allauth_password_set])
def _email_on_password_changed(request, user, **kwargs):
    # Couvre la modification (connecté), la réinitialisation (lien) et la
    # première définition d'un mot de passe (compte social).
    account_emailing.notify_password_changed(user, request)


@receiver(allauth_email_changed)
def _email_on_email_changed(request, user, from_email_address, to_email_address, **kwargs):
    account_emailing.notify_email_changed(
        user, from_email_address.email, to_email_address.email, request,
    )