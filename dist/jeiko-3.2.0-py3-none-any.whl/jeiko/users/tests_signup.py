"""
Inscription : le parcours doit aboutir, et échouer visiblement s'il échoue.

Signalé en production : l'inscription renvoyait le formulaire vide, sans aucun
message. Cause — `CustomSignupForm` déclare `first_name` et `last_name`
OBLIGATOIRES, mais le gabarit ne les rendait pas (sa boucle ne parcourait que
`hidden_fields`, or ce sont des champs visibles). Ils étaient donc absents du
POST, la validation échouait, et les erreurs portaient sur des champs
invisibles : rien ne s'affichait.

D'où les deux garanties testées ici : l'inscription aboutit, et **tout champ
obligatoire du formulaire est effectivement rendu** — c'est cette seconde
garantie qui empêche le défaut de revenir sous une autre forme.
"""

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from jeiko.users.forms import CustomSignupForm

User = get_user_model()


class FormulaireRenduTests(TestCase):
    def test_tous_les_champs_obligatoires_sont_rendus(self):
        """
        La garantie qui compte : un champ obligatoire absent du gabarit rend
        l'inscription impossible ET muette.
        """
        page = self.client.get(reverse("jeiko_allauth:signup"))
        html = page.content.decode()

        manquants = [
            nom for nom, champ in CustomSignupForm().fields.items()
            if champ.required and f'name="{nom}"' not in html
        ]
        self.assertEqual(
            manquants, [],
            f"Champs obligatoires jamais affichés : {manquants}. "
            "L'inscription échouera sans message.",
        )


class InscriptionTests(TestCase):
    URL = None

    def setUp(self):
        self.URL = reverse("jeiko_allauth:signup")

    def donnees(self, **surcharge):
        base = {
            "email": "nouveau@exemple.test",
            "username": "nouveau",
            "first_name": "Camille",
            "last_name": "Durand",
            "password1": "MotDePasse-Solide-42",
            "password2": "MotDePasse-Solide-42",
        }
        base.update(surcharge)
        return base

    def test_une_inscription_complete_cree_le_compte(self):
        self.client.post(self.URL, self.donnees())
        self.assertTrue(
            User.objects.filter(username="nouveau").exists(),
            "Le compte n'a pas été créé alors que le formulaire était complet.",
        )

    def test_le_prenom_et_le_nom_sont_enregistres(self):
        self.client.post(self.URL, self.donnees())
        compte = User.objects.get(username="nouveau")
        self.assertEqual(compte.first_name, "Camille")
        self.assertEqual(compte.last_name, "Durand")

    def test_l_inscription_connecte_le_nouveau_compte(self):
        self.client.post(self.URL, self.donnees())
        self.assertTrue(self.client.session.get("_auth_user_id"))

    def test_un_echec_affiche_un_message(self):
        """Un refus doit se voir : c'est tout le problème d'origine."""
        reponse = self.client.post(
            self.URL, self.donnees(password2="pas-le-meme"), follow=True
        )
        self.assertContains(reponse, "error", status_code=200)

    def test_une_adresse_deja_prise_est_signalee(self):
        User.objects.create_user("deja", "nouveau@exemple.test", "mdp")
        reponse = self.client.post(self.URL, self.donnees(username="autre"))
        self.assertEqual(reponse.status_code, 200)  # réaffichage, pas redirection
        self.assertTrue(reponse.context["form"].errors)


class DepuisLaConnexionTests(TestCase):
    def test_la_page_de_connexion_propose_de_creer_un_compte(self):
        """
        Le tunnel de commande exige désormais un compte : sans ce lien, un
        acheteur envoyé vers la connexion n'a aucun moyen d'en créer un.
        """
        page = self.client.get(reverse("jeiko_allauth:login"))
        self.assertContains(page, reverse("jeiko_allauth:signup"))
