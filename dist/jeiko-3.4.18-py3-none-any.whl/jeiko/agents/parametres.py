# jeiko/agents/parametres.py
"""
Lecture et écriture des paramètres d'une section, d'une ligne ou d'un bloc.

Pourquoi un seul module pour les trois
--------------------------------------
`Section`, `Line` et `Bloc` héritent tous de `StylableElement` : marges,
paddings, tailles et fond, déclinés sur quatre appareils. Ce sont **douze
objets liés** par élément — un `StyleBox` ou un `Size` par appareil et par
famille. Écrire trois fois la même traduction, c'est se garantir que les trois
divergeront ; ce paquet a déjà payé ce prix ailleurs.

Chaque modèle ajoute ensuite ses champs propres, décrits dans `CHAMPS_PROPRES`.

La forme choisie, et pourquoi
-----------------------------
    {
      "fond": {"couleur": "rgba(255,255,255,0)"},
      "marges":   {"computer": {"haut": "0", "droite": "auto"}},
      "paddings": {"phone": {"haut": "20px"}},
      "tailles":  {"computer": {"largeur": "1200px", "hauteur": ""}}
    }

Groupée par famille puis par appareil, plutôt que quarante-huit champs à plat.
Un agent qui veut « la même marge partout » écrit quatre lignes au lieu de
seize, et **tout ce qui n'est pas mentionné reste inchangé** — ce qui rend les
modifications partielles naturelles et évite d'écraser par distraction ce
qu'on ne visait pas.

Les noms sont en français, comme le reste des écrans : c'est l'exploitant qui
lira ces documents quand quelque chose ira de travers.

Ce que ce module ne fait pas
----------------------------
Il ne valide pas les valeurs CSS. « largeur : 12 patates » sera enregistré tel
quel et ne produira rien à l'écran. Valider vraiment demanderait un analyseur
CSS ; on s'en tient à borner la longueur, comme le fait le modèle.
"""

from django.db import transaction

from jeiko.administration_pages.models import (
    Animation, BackgroundImageParameters, Bloc, Border, CustomCSS, ImageContent,
    Line, Section, Size, StyleBox,
)

#: Les quatre appareils, dans l'ordre où l'éditeur les présente.
APPAREILS = ("phone", "tablet", "laptop", "computer")

#: Les quatre côtés d'une boîte, en français côté API.
COTES = {"haut": "top", "droite": "right", "bas": "bottom", "gauche": "left"}

#: Les trois « satellites » d'un élément stylable : chacun est un modèle à part,
#: relié par un `OneToOneField` nullable, avec une contrainte qui impose qu'un
#: seul des trois rattachements (section / ligne / bloc) soit renseigné.
#:
#: Ils n'existent pas tant qu'on ne les a pas créés — d'où `_satellite()`, qui
#: les fabrique à la demande plutôt que d'exiger que l'appelant sache lequel
#: manque.
SATELLITES = {
    "animation": (Animation, (
        "enabled", "preset", "trigger", "duration_ms", "delay_ms", "easing",
        "iterations", "direction", "fill_mode", "animation_range",
        "enable_phone", "enable_tablet", "enable_laptop", "enable_computer",
        "params", "reduce_motion_strategy",
    )),
    "bordure": (Border, (
        "border_width", "border_style", "border_color", "border_radius",
    )),
    "css": (CustomCSS, (
        "object_classes", "before", "current", "after", "hover", "custom",
        "current_phone", "current_tablet", "current_laptop", "current_computer",
        "hover_phone", "hover_tablet", "hover_laptop", "hover_computer",
    )),
}

#: Nom du rattachement inverse sur l'élément, par satellite.
LIEN_SATELLITE = {"animation": "animation", "bordure": "border", "css": "custom_css"}

#: Réglages de l'image de fond. Ils vivent dans un objet séparé, lui aussi
#: absent tant qu'on n'a pas d'image.
CHAMPS_IMAGE_DE_FOND = (
    "background_repeat", "background_size", "background_position",
    "background_attachment", "background_blur", "background_brightness",
    "background_opacity",
)

#: Champs propres à chaque modèle, modifiables par l'API.
#:
#: `position` n'y figure PAS : elle se change par les points d'entrée de
#: déplacement, qui renumérotent les voisins. La laisser modifiable ici
#: produirait des positions en double, donc un ordre d'affichage arbitraire.
#: `is_model`, `model_source` et `model_name` non plus : la bibliothèque de
#: modèles est un autre chantier (Q-06), et un agent n'a rien à y écrire.
CHAMPS_PROPRES = {
    Section: ("is_hero",),
    Line: (
        "columns_number",
        "columns_type",
        "columns_type_tablet",
        "columns_type_phone",
        "is_hero",
    ),
    Bloc: ("horizontal_align", "vertical_align"),
}


class ParametreInvalide(Exception):
    """Le document de paramètres n'est pas exploitable. Porte le message rendu."""


#: Les valeurs qu'un humain écrit spontanément pour « vrai » et « faux ».
#: JSON a des booléens, mais un agent recopie parfois ce qu'il a lu ailleurs.
_VRAI = {"true", "1", "oui", "yes", "vrai", "on"}
_FAUX = {"false", "0", "non", "no", "faux", "off", ""}


def _valeur_typee(champ, champ_modele, valeur):
    """
    Convertit et VALIDE selon le type du champ, quand il n'a pas de `choices`.

    Le défaut, remonté depuis un site en service : `PATCH /sections/128/
    {"is_hero": "ZZZ"}` renvoyait une **page d'erreur HTML 500**. La valeur
    traversait intacte jusqu'au `save()`, et c'est PostgreSQL qui refusait
    d'écrire « ZZZ » dans une colonne booléenne.

    Un 500 n'est pas seulement laid : il ne dit rien à l'appelant, il remplit
    le journal d'erreurs de l'exploitant avec des incidents qui n'en sont pas,
    et il laisse croire à une panne du site. Une saisie fautive doit produire
    un 400 qui explique.

    Le contrôle vaut pour TOUS les champs propres — booléens et entiers — et
    non pour le seul `is_hero` : c'est le mécanisme qui était troué, pas ce
    champ-là.
    """
    from django.db import models

    if valeur is None:
        return valeur

    if isinstance(champ_modele, models.BooleanField):
        if isinstance(valeur, bool):
            return valeur
        texte = str(valeur).strip().lower()
        if texte in _VRAI:
            return True
        if texte in _FAUX:
            return False
        raise ParametreInvalide(
            f"« {champ} » attend un booléen : true ou false. "
            f"Reçu : {valeur!r}."
        )

    if isinstance(champ_modele, (models.IntegerField, models.SmallIntegerField)):
        try:
            return int(valeur)
        except (TypeError, ValueError):
            raise ParametreInvalide(
                f"« {champ} » attend un nombre entier. Reçu : {valeur!r}."
            )

    return valeur


def _valeur_propre(element, champ, valeur):
    """
    Valide une valeur contre les `choices` du MODÈLE, quand il en a.

    L'écriture était un `setattr` brut : n'importe quoi passait. C'est ainsi
    que « flex-start » s'est retrouvé dans `horizontal_align`, qui n'accepte
    que « left », « center », « right » ou « justify ». La base l'a pris,
    l'API l'a relu fidèlement — et le gabarit, ne sachant pas le traduire,
    n'a rien aligné. Le réglage avait l'air posé et ne faisait rien.

    On interroge le modèle plutôt que d'entretenir une liste ici : les valeurs
    autorisées sont déjà écrites une fois, et une seconde copie divergerait au
    premier choix ajouté.
    """
    try:
        champ_modele = type(element)._meta.get_field(champ)
    except Exception:
        return valeur

    choix = [code for code, _ in (champ_modele.choices or [])]
    if not choix:
        return _valeur_typee(champ, champ_modele, valeur)

    texte = "" if valeur is None else str(valeur)
    if texte not in choix:
        raise ParametreInvalide(
            f"« {champ} » n'accepte que : "
            f"{', '.join(repr(c) for c in choix)}. Reçu : {valeur!r}."
        )
    return texte


# --------------------------------------------------------------------------- #
#  Lecture
# --------------------------------------------------------------------------- #
def _lire_boite(boite):
    if boite is None:
        return None
    return {fr: getattr(boite, en, "") for fr, en in COTES.items()}


def _lire_taille(taille):
    if taille is None:
        return None
    return {"largeur": taille.width, "hauteur": taille.height}


def _satellite_existant(element, cle):
    """Le satellite s'il existe, `None` sinon — sans lever."""
    try:
        return getattr(element, LIEN_SATELLITE[cle], None)
    except Exception:
        # `RelatedObjectDoesNotExist` sur un OneToOne absent. On ne l'attrape
        # pas par son nom : il est fabriqué à la volée par Django, et diffère
        # d'un modèle à l'autre.
        return None


def _lire_satellite(element, cle):
    objet = _satellite_existant(element, cle)
    if objet is None:
        return None
    _, champs = SATELLITES[cle]
    return {champ: getattr(objet, champ) for champ in champs}


def _lire_image_de_fond(element):
    image = element.background_image
    reglages = element.background_image_parameters
    return {
        "id": element.background_image_id,
        "url": (image.original_image.url if image and image.original_image else ""),
        "alt": (image.alt if image else ""),
        "reglages": (
            {champ: getattr(reglages, champ) for champ in CHAMPS_IMAGE_DE_FOND}
            if reglages else None
        ),
    }


def lire(element):
    """Tous les paramètres d'un élément, prêts à sérialiser."""
    donnees = {
        "fond": {
            "couleur": element.background_color or "",
            "cle_image_dynamique": element.background_image_dynamic_key or "",
            "image": _lire_image_de_fond(element),
        },
        "animation": _lire_satellite(element, "animation"),
        "bordure": _lire_satellite(element, "bordure"),
        "css": _lire_satellite(element, "css"),
        "marges": {
            a: _lire_boite(getattr(element, f"margin_{a}")) for a in APPAREILS
        },
        "paddings": {
            a: _lire_boite(getattr(element, f"padding_{a}")) for a in APPAREILS
        },
        "tailles": {a: _lire_taille(getattr(element, f"size_{a}")) for a in APPAREILS},
    }

    for champ in CHAMPS_PROPRES.get(type(element), ()):
        donnees[champ] = getattr(element, champ)

    return donnees


# --------------------------------------------------------------------------- #
#  Écriture
# --------------------------------------------------------------------------- #
def _exiger_dict(valeur, ou):
    if not isinstance(valeur, dict):
        raise ParametreInvalide(f"« {ou} » doit être un objet.")
    return valeur


def _exiger_appareil(appareil):
    if appareil not in APPAREILS:
        raise ParametreInvalide(
            f"Appareil inconnu : « {appareil} ». Attendus : {', '.join(APPAREILS)}."
        )


def _appliquer_boite(element, famille, appareil, valeurs):
    """
    Écrit une boîte, en la créant si elle manque.

    Les éléments anciens peuvent porter des `StyleBox` à `None` : les créer à la
    volée évite qu'une modification échoue sur un décor incomplet, ce qui
    n'apprendrait rien à personne.
    """
    champ = f"{famille}_{appareil}"
    boite = getattr(element, champ)

    if boite is None:
        boite = StyleBox.objects.create(top="", right="", bottom="", left="")
        setattr(element, champ, boite)

    modifies = []
    for fr, en in COTES.items():
        if fr in valeurs:
            setattr(boite, en, str(valeurs[fr])[:10])
            modifies.append(en)

    if modifies:
        boite.save(update_fields=modifies)
    return champ


def _appliquer_taille(element, appareil, valeurs):
    champ = f"size_{appareil}"
    taille = getattr(element, champ)

    if taille is None:
        taille = Size.objects.create(width="", height="")
        setattr(element, champ, taille)

    modifies = []
    if "largeur" in valeurs:
        taille.width = str(valeurs["largeur"])[:50]
        modifies.append("width")
    if "hauteur" in valeurs:
        taille.height = str(valeurs["hauteur"])[:50]
        modifies.append("height")

    if modifies:
        taille.save(update_fields=modifies)
    return champ


def _lien_du_satellite(element):
    """
    Le nom du champ de rattachement, selon la nature de l'élément.

    `Animation`, `Border` et `CustomCSS` portent trois liens nullables et une
    contrainte qui exige qu'un seul soit renseigné : il faut donc désigner le
    bon, pas les trois.
    """
    if isinstance(element, Section):
        return "section"
    if isinstance(element, Line):
        return "line"
    if isinstance(element, Bloc):
        return "bloc"
    raise ParametreInvalide("Élément de type inattendu.")


def _satellite(element, cle):
    """Le satellite, créé s'il n'existe pas encore."""
    existant = _satellite_existant(element, cle)
    if existant is not None:
        return existant
    modele, _ = SATELLITES[cle]
    return modele.objects.create(**{_lien_du_satellite(element): element})


def _appliquer_satellite(element, cle, valeurs):
    objet = _satellite(element, cle)
    _, autorises = SATELLITES[cle]

    modifies = []
    for champ, valeur in valeurs.items():
        if champ not in autorises:
            raise ParametreInvalide(
                f"« {cle}.{champ} » n'existe pas. "
                f"Champs acceptés : {', '.join(autorises)}."
            )
        setattr(objet, champ, valeur)
        modifies.append(champ)

    if modifies:
        objet.save(update_fields=modifies)
    return modifies


def _appliquer_image_de_fond(element, image_id):
    """
    Rattache une image DÉJÀ présente dans la médiathèque, ou la détache.

    L'API ne reçoit pas de fichier : le téléversement passe par les écrans
    d'administration, où s'appliquent les validateurs de S-10 — plafond de
    poids et garde anti-bombe de décompression. Un agent qui pousserait des
    octets contournerait les deux.
    """
    if image_id in (None, "", 0):
        element.background_image = None
        return "background_image"

    image = ImageContent.objects.filter(pk=image_id).first()
    if image is None:
        raise ParametreInvalide(
            f"Aucune image nº {image_id} dans la médiathèque. "
            f"Les images se téléversent depuis l'administration."
        )
    element.background_image = image
    return "background_image"


def _appliquer_reglages_image(element, valeurs):
    reglages = element.background_image_parameters
    if reglages is None:
        reglages = BackgroundImageParameters.objects.create()
        element.background_image_parameters = reglages

    modifies = []
    for champ, valeur in valeurs.items():
        if champ not in CHAMPS_IMAGE_DE_FOND:
            raise ParametreInvalide(
                f"« {champ} » n'est pas un réglage d'image de fond. "
                f"Acceptés : {', '.join(CHAMPS_IMAGE_DE_FOND)}."
            )
        setattr(reglages, champ, valeur)
        modifies.append(champ)

    if modifies:
        reglages.save(update_fields=modifies)
    return modifies


#: Les familles de paramètres acceptées quel que soit l'élément.
FAMILLES_COMMUNES = ("fond", "marges", "paddings", "tailles")

#: Les clés acceptées sous « fond ».
CLES_DE_FOND = ("couleur", "cle_image_dynamique", "image_id", "reglages_image")


def cles_acceptees(element):
    """Toutes les clés de premier niveau que `appliquer()` sait lire."""
    return sorted(
        set(FAMILLES_COMMUNES)
        | set(SATELLITES)
        | set(CHAMPS_PROPRES.get(type(element), ()))
    )


def _refuser_les_cles_inconnues(element, donnees):
    """
    Une clé que personne ne lit doit lever, jamais disparaître.

    Le défaut, remonté en montant un site de bout en bout : un
    `PATCH /sections/126/ {"couleur_de_fond": "#ffffff"}` répondait 200 sans
    rien changer. `appliquer()` ne lisait que les clés qu'elle connaissait, et
    « couleur_de_fond » — qui n'existe pas, la bonne écriture étant
    `{"fond": {"couleur": …}}` — tombait en silence.

    Pour un humain c'est une minute perdue. Pour un agent c'est pire : il tient
    la réponse 200 pour une confirmation, passe à la suite, et le défaut ne se
    découvre qu'en relisant le rendu — s'il y pense. Le mode d'emploi lui
    PROMET d'ailleurs le contraire : « une clé inconnue est refusée, jamais
    ignorée ». La promesse était tenue pour les contenus, pas pour les
    paramètres.

    Le message nomme les clés acceptées : c'est ce qui permet de se corriger
    sans relire la documentation.
    """
    inconnues = sorted(set(donnees) - set(cles_acceptees(element)))
    if not inconnues:
        return
    quoi = type(element).__name__.lower()
    raise ParametreInvalide(
        f"Clé(s) inconnue(s) pour {quoi} : {', '.join(inconnues)}. "
        f"Acceptées : {', '.join(cles_acceptees(element))}. "
        f"Les couleurs, images et réglages de fond vivent tous sous « fond » — "
        f"par exemple {{\"fond\": {{\"couleur\": \"rgba(24,28,38,1)\"}}}}."
    )


def _refuser_les_cles_de_fond(fond):
    """Même règle un cran plus bas : « fond » a quatre clés, pas une de plus."""
    inconnues = sorted(set(fond) - set(CLES_DE_FOND))
    if inconnues:
        raise ParametreInvalide(
            f"Clé(s) inconnue(s) sous « fond » : {', '.join(inconnues)}. "
            f"Acceptées : {', '.join(CLES_DE_FOND)}."
        )


@transaction.atomic
def appliquer(element, donnees):
    """
    Applique un document de paramètres. Ne touche QUE ce qui est présent.

    Renvoie la liste de ce qui a été modifié : un agent doit pouvoir vérifier
    que sa demande a été prise sans avoir à relire l'élément.
    """
    donnees = _exiger_dict(donnees, "parametres")
    _refuser_les_cles_inconnues(element, donnees)
    touches = []
    champs_element = []

    fond = donnees.get("fond")
    if fond is not None:
        fond = _exiger_dict(fond, "fond")
        _refuser_les_cles_de_fond(fond)
        if "couleur" in fond:
            element.background_color = str(fond["couleur"])[:30]
            champs_element.append("background_color")
            touches.append("fond.couleur")
        if "cle_image_dynamique" in fond:
            element.background_image_dynamic_key = str(fond["cle_image_dynamique"])[:100]
            champs_element.append("background_image_dynamic_key")
            touches.append("fond.cle_image_dynamique")
        if "image_id" in fond:
            champs_element.append(_appliquer_image_de_fond(element, fond["image_id"]))
            touches.append("fond.image_id")
        if "reglages_image" in fond:
            _appliquer_reglages_image(element, _exiger_dict(fond["reglages_image"],
                                                           "fond.reglages_image"))
            champs_element.append("background_image_parameters")
            touches.append("fond.reglages_image")

    for cle in SATELLITES:
        valeurs = donnees.get(cle)
        if valeurs is None:
            continue
        touches.extend(
            f"{cle}.{champ}"
            for champ in _appliquer_satellite(element, cle, _exiger_dict(valeurs, cle))
        )

    for cle, famille in (("marges", "margin"), ("paddings", "padding")):
        groupe = donnees.get(cle)
        if groupe is None:
            continue
        for appareil, valeurs in _exiger_dict(groupe, cle).items():
            _exiger_appareil(appareil)
            champs_element.append(
                _appliquer_boite(element, famille, appareil, _exiger_dict(valeurs, cle))
            )
            touches.append(f"{cle}.{appareil}")

    tailles = donnees.get("tailles")
    if tailles is not None:
        for appareil, valeurs in _exiger_dict(tailles, "tailles").items():
            _exiger_appareil(appareil)
            champs_element.append(
                _appliquer_taille(element, appareil, _exiger_dict(valeurs, "tailles"))
            )
            touches.append(f"tailles.{appareil}")

    for champ in CHAMPS_PROPRES.get(type(element), ()):
        if champ in donnees:
            setattr(element, champ, _valeur_propre(element, champ, donnees[champ]))
            champs_element.append(champ)
            touches.append(champ)

    if champs_element:
        element.save(update_fields=sorted(set(champs_element)))

    return touches
