# jeiko/newsletter/envoi.py
"""
NEWS-01 — envoyer une newsletter : par lots, sous le plafond horaire du
serveur d'envoi, une fois par adresse.

Le chemin :
1. `programmer()` — une personne (jamais un agent, jamais l'API) décide de
   l'envoi, maintenant ou à une date. Rien ne part encore.
2. `cron_5m` appelle `envoyer_un_lot()`. À l'heure dite, la newsletter
   passe « en cours » et ses destinataires sont FIGÉS (`EnvoiNewsletter`,
   une ligne par adresse, unique : un abonné de deux listes visées ne reçoit
   qu'un exemplaire). Un abonné inscrit après ce moment ne la reçoit pas.
3. Chaque passage envoie ce que le plafond de l'heure permet ; la suite part
   au passage suivant. Le dernier envoi passe la newsletter « envoyée ».

Le rendu se fait UNE fois par newsletter (`render_page` lit toute la page) ;
chaque destinataire reçoit ensuite sa copie : prénom, lien de désinscription
signé à son nom, liens suivis s'il y a lieu.

Ce que ce module ne fait pas : lire les rebonds différés. Un refus immédiat
du serveur (code 5xx sur le destinataire) bloque l'adresse ; un rebond qui
revient plus tard dans la boîte de l'expéditeur n'est pas lu — il faudrait
une boîte à relever ou le webhook d'un service d'envoi.
"""
import logging
import re
from datetime import timedelta
from html import escape

from django.core import signing
from django.db import transaction
from django.urls import reverse
from django.utils import timezone

from jeiko.emailing.models import Abonne, EnvoiNewsletter, Newsletter, ReglagesNewsletter

from . import abonnes

logger = logging.getLogger(__name__)

SEL_DESINSCRIPTION = "jeiko.newsletter.desinscrire"
SEL_CLIC = "jeiko.newsletter.clic"
SEL_NAVIGATEUR = "jeiko.newsletter.navigateur"

#: Au plus par passage du cron (toutes les 5 minutes), quel que soit le plafond :
#: un passage doit finir avant le suivant.
LOT_MAXIMUM = 200

# Jetons posés dans le rendu commun, remplacés destinataire par destinataire.
# Lettres et chiffres seulement : ni l'échappement HTML ni Quill ne les touchent.
_JETONS = {"prenom": "JKNLPRENOMx7", "nom": "JKNLNOMx7", "email": "JKNLEMAILx7",
           "lien_desabonnement": "JKNLDESABOx7"}
_LIEN = re.compile(r'href="(https?://[^"]+)"', re.I)


class EnvoiImpossible(Exception):
    pass


# --- Avant l'envoi ---

def problemes(newsletter):
    """Ce qui empêche l'envoi, en phrases. Vide : prête."""
    from django.utils.translation import gettext as _

    erreurs = []
    if not newsletter.objet.strip():
        erreurs.append(_("L'objet est vide."))
    if newsletter.page is None or not newsletter.page.sections.exists():
        erreurs.append(_("Le contenu est vide."))
    if not newsletter.listes.exists():
        erreurs.append(_("Aucune liste n'est choisie."))
    elif not abonnes.destinataires_de(newsletter).exists():
        erreurs.append(_("Personne ne correspond : les listes choisies n'ont aucun inscrit dont la fiche du CRM "
                         "porte ces étiquettes ou ce statut.") if newsletter.etiquettes_crm or newsletter.statut_crm
                       else _("Les listes choisies n'ont aucun inscrit."))
    from jeiko.emailing.sending import get_mail_settings

    reglages = get_mail_settings()
    if reglages is None or not reglages.active:
        erreurs.append(_("L'envoi d'e-mails n'est pas configuré (Réglages › E-mail)."))
    return erreurs


@transaction.atomic
def programmer(newsletter, par, quand=None):
    newsletter = Newsletter.objects.select_for_update().get(pk=newsletter.pk)
    if newsletter.sequence_id:
        from django.utils.translation import gettext as _

        raise EnvoiImpossible(_("C'est une étape de séquence : elle part d'elle-même, à chaque nouvel inscrit."))
    if not newsletter.modifiable:
        raise EnvoiImpossible(newsletter.get_statut_display())
    erreurs = problemes(newsletter)
    if erreurs:
        raise EnvoiImpossible(" ".join(erreurs))
    newsletter.statut = Newsletter.Statut.PROGRAMMEE
    newsletter.programmee_le = quand or timezone.now()
    newsletter.envoyee_par = par
    newsletter.save(update_fields=["statut", "programmee_le", "envoyee_par", "modifiee_le"])
    return newsletter


@transaction.atomic
def annuler(newsletter):
    """Une newsletter programmée revient au brouillon ; une en cours s'arrête là."""
    newsletter = Newsletter.objects.select_for_update().get(pk=newsletter.pk)
    if newsletter.statut == Newsletter.Statut.PROGRAMMEE:
        newsletter.statut = Newsletter.Statut.BROUILLON
    elif newsletter.statut == Newsletter.Statut.EN_COURS:
        newsletter.statut = Newsletter.Statut.ANNULEE
        newsletter.envoi_termine_le = timezone.now()
        newsletter.envois.filter(statut=EnvoiNewsletter.Statut.A_ENVOYER).update(statut=EnvoiNewsletter.Statut.IGNORE)
    newsletter.save(update_fields=["statut", "envoi_termine_le", "modifiee_le"])
    return newsletter


@transaction.atomic
def dupliquer(newsletter, par):
    from jeiko.administration_pages.versions import dupliquer_la_page

    copie = Newsletter.objects.create(
        objet=newsletter.objet, pre_entete=newsletter.pre_entete, suivi_des_clics=newsletter.suivi_des_clics,
        etiquettes_crm=list(newsletter.etiquettes_crm or []), statut_crm=newsletter.statut_crm,
        dupliquee_de=newsletter, creee_par=par,
    )
    if newsletter.page is not None:
        copie.page = dupliquer_la_page(newsletter.page, titre=f"Newsletter — {copie.objet}",
                                       url_tag=f"newsletter_{copie.pk}")
        copie.save(update_fields=["page"])
    copie.listes.set(newsletter.listes.all())
    return copie


def creer(objet, par, listes=None, modele=""):
    """
    Une newsletter neuve, avec sa page de corps prête pour l'éditeur : vide,
    ou posée d'après un modèle (`newsletter/modeles.py`).
    """
    from jeiko.administration_pages.models import Page

    from .modeles import MODELES

    newsletter = Newsletter.objects.create(objet=objet, creee_par=par)
    titre = f"Newsletter — {objet}"[:200]
    if modele in MODELES:
        from jeiko.emailing.builder import build_page

        newsletter.page = build_page(f"newsletter_{newsletter.pk}", {"title": titre, **MODELES[modele]})
    else:
        newsletter.page = Page.objects.create(
            title=titre, url_tag=f"newsletter_{newsletter.pk}", is_mail_template=True,
            show_default_main_menu=False, show_default_footer=False, active=True, is_protected=True,
        )
    newsletter.save(update_fields=["page"])
    newsletter.listes.set(listes or [abonnes.Liste.par_defaut_du_site()])
    return newsletter


# --- Les liens ---

def _absolu(chemin):
    from jeiko.emailing.render import site_base_url

    return f"{site_base_url()}{chemin}"


def lien_de_desinscription(envoi, un_clic=False):
    jeton = signing.dumps({"v": envoi.pk}, salt=SEL_DESINSCRIPTION)
    nom = "jeiko_newsletter:desinscription_un_clic" if un_clic else "jeiko_newsletter:desinscription"
    return _absolu(reverse(nom, args=[jeton]))


def lire_le_jeton_de_desinscription(jeton):
    try:
        return EnvoiNewsletter.objects.select_related("newsletter").filter(
            pk=signing.loads(jeton, salt=SEL_DESINSCRIPTION)["v"]).first()
    except (signing.BadSignature, KeyError, TypeError):
        return None


def lien_suivi(envoi, url):
    return _absolu(reverse("jeiko_newsletter:clic", args=[signing.dumps({"v": envoi.pk, "u": url}, salt=SEL_CLIC)]))


def lire_le_clic(jeton):
    """(envoi, url) ou (None, None). Signé : le site ne redirige jamais vers une adresse qu'il n'a pas écrite."""
    try:
        charge = signing.loads(jeton, salt=SEL_CLIC)
    except signing.BadSignature:
        return None, None
    return EnvoiNewsletter.objects.filter(pk=charge.get("v")).first(), charge.get("u")


def lien_navigateur(newsletter):
    return _absolu(reverse("jeiko_newsletter:navigateur",
                           args=[signing.dumps(newsletter.pk, salt=SEL_NAVIGATEUR)]))


# --- Le rendu ---

def rendu_commun(newsletter, valeurs=None):
    """(objet, html) avec les jetons des données personnelles, pour tous les destinataires."""
    from jeiko.emailing.models import render_tags
    from jeiko.emailing.render import render_page

    contexte = {**_valeurs_du_site(), **(valeurs or _JETONS),
                "lien_navigateur": lien_navigateur(newsletter)}
    html, _avertissements = render_page(newsletter.page, contexte)
    if newsletter.pre_entete:
        html = re.sub(r"(<body[^>]*>)", r'\1<div style="display:none;max-height:0;overflow:hidden;">'
                      + escape(newsletter.pre_entete) + "</div>", html, count=1)
    return render_tags(newsletter.objet, contexte), html


def _valeurs_du_site():
    from jeiko.emailing.render import site_context

    site = site_context()
    maintenant = timezone.localtime()
    return {"site_nom": site["site_name"], "site_url": site["site_url"], "logo_url": site["logo_url"],
            "contact_tel": site["contact_tel"], "date": maintenant.strftime("%d/%m/%Y"),
            "annee": maintenant.strftime("%Y")}


def _valeurs_personnelles(envoi):
    abonne = envoi.abonne
    return {"prenom": getattr(abonne, "prenom", ""), "nom": getattr(abonne, "nom", ""), "email": envoi.email,
            "lien_desabonnement": lien_de_desinscription(envoi)}


def personnaliser_l_objet(objet, envoi):
    valeurs = _valeurs_personnelles(envoi)
    for cle, jeton in _JETONS.items():
        objet = objet.replace(jeton, valeurs[cle])
    return objet


def personnaliser(html, envoi, suivi):
    valeurs = _valeurs_personnelles(envoi)
    if suivi:
        def suivre(m):
            url = m.group(1)
            if _JETONS["lien_desabonnement"] in url or "/newsletter/" in url:
                return m.group(0)
            return f'href="{escape(lien_suivi(envoi, url))}"'
        html = _LIEN.sub(suivre, html)
    for cle, jeton in _JETONS.items():
        html = html.replace(jeton, escape(valeurs[cle]))
    return html


# --- L'envoi ---

def _deja_envoyes_cette_heure():
    return EnvoiNewsletter.objects.filter(envoye_le__gte=timezone.now() - timedelta(hours=1)).count()


def _demarrer_celles_qui_sont_dues():
    dues = Newsletter.objects.filter(statut=Newsletter.Statut.PROGRAMMEE, programmee_le__lte=timezone.now())
    for newsletter in dues:
        with transaction.atomic():
            newsletter = Newsletter.objects.select_for_update().get(pk=newsletter.pk)
            if newsletter.statut != Newsletter.Statut.PROGRAMMEE:
                continue
            EnvoiNewsletter.objects.bulk_create(
                [EnvoiNewsletter(newsletter=newsletter, abonne=a, email=a.email)
                 for a in abonnes.destinataires_de(newsletter)],
                ignore_conflicts=True,
            )
            newsletter.statut = Newsletter.Statut.EN_COURS
            newsletter.envoi_commence_le = timezone.now()
            newsletter.save(update_fields=["statut", "envoi_commence_le"])


_REFUS_DEFINITIF = re.compile(r"\(5\d\d,")


def envoyer_un_lot():
    """Appelé par cron_5m. Retourne le nombre d'e-mails partis."""
    from jeiko.emailing.sending import get_mail_connection, send_message

    from django.db.models import Q

    from . import sequences

    _demarrer_celles_qui_sont_dues()
    sequences.planifier()
    reglages = ReglagesNewsletter.du_site()
    reste = min(LOT_MAXIMUM, max(0, reglages.envois_par_heure - _deja_envoyes_cette_heure()))
    if not reste:
        return 0

    partis = 0
    # Les lettres en cours d'envoi, puis les étapes des séquences actives.
    a_traiter = (Newsletter.objects
                 .filter(Q(statut=Newsletter.Statut.EN_COURS, sequence__isnull=True) | Q(sequence__active=True))
                 .select_related("sequence").order_by("envoi_commence_le", "pk"))
    for newsletter in a_traiter:
        a_faire = list(newsletter.envois.select_related("abonne")
                       .filter(statut=EnvoiNewsletter.Statut.A_ENVOYER).order_by("pk")[:reste])
        if a_faire:
            connexion, expediteur, reponse = get_mail_connection()
            if connexion is None:
                return partis
            objet, html_commun = rendu_commun(newsletter)
            from jeiko.emailing.render import html_to_text

            for envoi in a_faire:
                # Ligne prise une seule fois, même si deux passages se chevauchent.
                if not EnvoiNewsletter.objects.filter(pk=envoi.pk, statut=EnvoiNewsletter.Statut.A_ENVOYER).update(
                        statut=EnvoiNewsletter.Statut.ENVOYE, envoye_le=timezone.now()):
                    continue
                if envoi.abonne is None or envoi.abonne.bloque_le or (
                        newsletter.sequence_id and not sequences.toujours_inscrit(newsletter, envoi.abonne)):
                    EnvoiNewsletter.objects.filter(pk=envoi.pk).update(statut=EnvoiNewsletter.Statut.IGNORE)
                    continue
                html = personnaliser(html_commun, envoi, newsletter.suivi_des_clics)
                un_clic = lien_de_desinscription(envoi, un_clic=True)
                ok, erreur = send_message(
                    personnaliser_l_objet(objet, envoi), html_to_text(html), envoi.email, html_body=html,
                    from_email=reglages.expediteur or expediteur,
                    reply_to=reglages.reponse_a or reponse, connection=connexion,
                    headers={"List-Unsubscribe": f"<{un_clic}>",
                             "List-Unsubscribe-Post": "List-Unsubscribe=One-Click"},
                )
                if ok:
                    partis += 1
                else:
                    EnvoiNewsletter.objects.filter(pk=envoi.pk).update(
                        statut=EnvoiNewsletter.Statut.ECHEC, envoye_le=None, erreur=(erreur or "")[:500])
                    # ponytail: refus immédiat seulement ; les rebonds différés ne sont pas lus.
                    if _REFUS_DEFINITIF.search(erreur or ""):
                        abonnes.bloquer(envoi.email, Abonne.Blocage.REBOND)
                reste -= 1
            if not reste:
                break
        if not newsletter.sequence_id and not newsletter.envois.filter(statut=EnvoiNewsletter.Statut.A_ENVOYER).exists():
            Newsletter.objects.filter(pk=newsletter.pk, statut=Newsletter.Statut.EN_COURS).update(
                statut=Newsletter.Statut.ENVOYEE, envoi_termine_le=timezone.now())
    return partis


def envoyer_un_essai(newsletter, adresse):
    """Un exemplaire à `adresse`, avec des valeurs d'exemple ; ne compte nulle part."""
    from jeiko.emailing.render import html_to_text
    from jeiko.emailing.sending import send_message

    objet, html = rendu_commun(newsletter, {"prenom": "Camille", "nom": "Dupont", "email": adresse,
                                            "lien_desabonnement": "#"})
    return send_message(f"[TEST] {objet}", html_to_text(html), adresse, html_body=html,
                        from_email=ReglagesNewsletter.du_site().expediteur or None)


def statistiques(newsletter):
    envois = newsletter.envois
    total = envois.count()
    envoyes = envois.filter(statut=EnvoiNewsletter.Statut.ENVOYE).count()
    cliqueurs = envois.filter(clics__gt=0).count()
    return {
        "destinataires": total, "envoyes": envoyes,
        "echecs": envois.filter(statut=EnvoiNewsletter.Statut.ECHEC).count(),
        "a_envoyer": envois.filter(statut=EnvoiNewsletter.Statut.A_ENVOYER).count(),
        "cliqueurs": cliqueurs, "taux_de_clic": round(100 * cliqueurs / envoyes, 1) if envoyes else 0,
        "desinscriptions": envois.filter(desinscrit_le__isnull=False).count(),
    }
