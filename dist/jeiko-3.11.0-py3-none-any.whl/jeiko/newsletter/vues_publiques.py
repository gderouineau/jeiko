# jeiko/newsletter/vues_publiques.py
"""
NEWS-01 — ce que voit le public : s'inscrire (le bloc), confirmer,
se désinscrire, suivre un lien, lire la lettre dans le navigateur.

Rien ici n'exige de compte. Les liens sont signés : on ne peut ni désinscrire
quelqu'un d'autre, ni faire rediriger le site vers une adresse qu'il n'a pas
écrite lui-même dans une newsletter.
"""
from django.http import Http404, HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import render
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _
from django.views import View
from django.views.decorators.csrf import csrf_exempt

from jeiko.emailing.models import EnvoiNewsletter, Inscription, Liste, Newsletter

from . import abonnes, envoi as moteur

GABARIT = "newsletter/public.html"


class Inscrire(View):
    """POST du bloc d'inscription (JavaScript). Répond en JSON."""

    def post(self, request, bloc_id):
        from django.core.validators import validate_email
        from django.core.exceptions import ValidationError

        from jeiko.administration_pages.antispam import verdict
        from jeiko.administration_pages.models import Bloc
        from jeiko.throttling import honeypot_filled, ip_stockable, rate_limited

        bloc = Bloc.objects.select_related("content").filter(pk=bloc_id).first()
        if bloc is None or getattr(bloc, "content", None) is None or bloc.content.content_type != "DYN_NEWSLETTER":
            raise Http404
        reglage = bloc.content.data or {}
        succes = {"success": True, "message": reglage.get("message") or _(
            "Merci ! Un e-mail de confirmation vient de vous être envoyé.")}

        if rate_limited(request, "newsletter_inscription", 10, 3600):
            return JsonResponse({"success": False, "errors": {"email": _("Trop de tentatives. Réessayez plus tard.")}},
                                status=429)
        email = (request.POST.get("email") or "").strip()
        try:
            validate_email(email)
        except ValidationError:
            return JsonResponse({"success": False, "errors": {"email": _("Cette adresse e-mail n'est pas valide.")}})
        if not request.POST.get("consentement"):
            return JsonResponse({"success": False, "errors": {"consentement": _("Cochez la case pour vous inscrire.")}})
        # Un robot reçoit la même réponse qu'un humain : rien ne lui dit qu'il est repéré.
        if honeypot_filled(request.POST) or verdict(f"newsletter-{bloc.pk}", request.POST, {"email": email}):
            return JsonResponse(succes)

        liste = Liste.objects.filter(pk=reglage.get("liste")).first() or Liste.par_defaut_du_site()
        abonnes.inscrire(
            email, [liste], source=Inscription.Source.BLOC, detail=request.META.get("HTTP_REFERER", "")[:255],
            texte=_texte_du_consentement(reglage), ip=ip_stockable(request),
            prenom=(request.POST.get("prenom") or "").strip(),
            user=request.user if request.user.is_authenticated and request.user.email.lower() == email.lower() else None,
        )
        if not liste.double_opt_in:
            succes["message"] = reglage.get("message") or _("Merci, vous êtes inscrit.")
        return JsonResponse(succes)


def _texte_du_consentement(reglage):
    from jeiko.emailing.models import ReglagesNewsletter

    return reglage.get("consentement") or ReglagesNewsletter.du_site().texte_consentement


class Confirmer(View):
    def get(self, request, jeton):
        abonne = abonnes.confirmer(jeton)
        return render(request, GABARIT, {"etat": "confirme" if abonne else "invalide"},
                      status=200 if abonne else 400)


class Desinscrire(View):
    """GET demande confirmation (un antivirus qui suit les liens ne désinscrit personne) ; POST agit."""

    def get(self, request, jeton):
        envoi = moteur.lire_le_jeton_de_desinscription(jeton)
        if envoi is None:
            return render(request, GABARIT, {"etat": "invalide"}, status=400)
        return render(request, GABARIT, {"etat": "desinscription", "email": envoi.email,
                                         "listes": envoi.newsletter.listes.all()})

    def post(self, request, jeton):
        envoi = moteur.lire_le_jeton_de_desinscription(jeton)
        if envoi is None:
            return render(request, GABARIT, {"etat": "invalide"}, status=400)
        tout = request.POST.get("portee") == "tout"
        _desinscrire(envoi, tout)
        return render(request, GABARIT, {"etat": "desinscrit", "email": envoi.email, "tout": tout})


def _desinscrire(envoi, tout):
    abonnes.desinscrire(envoi.email, None if tout else list(envoi.newsletter.listes.all()))
    EnvoiNewsletter.objects.filter(pk=envoi.pk, desinscrit_le__isnull=True).update(desinscrit_le=timezone.now())


@method_decorator(csrf_exempt, name="dispatch")
class DesinscrireEnUnClic(View):
    """RFC 8058 : la messagerie (Gmail, Yahoo) poste ici quand on clique « Se désabonner »."""

    def post(self, request, jeton):
        envoi = moteur.lire_le_jeton_de_desinscription(jeton)
        if envoi is None:
            return HttpResponse(status=400)
        _desinscrire(envoi, tout=False)
        return HttpResponse(status=200)

    def get(self, request, jeton):
        return HttpResponseRedirect(request.path.replace("/un-clic/", "/"))


class Clic(View):
    def get(self, request, jeton):
        envoi, url = moteur.lire_le_clic(jeton)
        if not url:
            raise Http404
        if envoi is not None:
            from django.db.models import F

            from jeiko.emailing.models import ClicNewsletter

            maintenant = timezone.now()
            EnvoiNewsletter.objects.filter(pk=envoi.pk).update(clics=F("clics") + 1)
            EnvoiNewsletter.objects.filter(pk=envoi.pk, premier_clic_le__isnull=True).update(premier_clic_le=maintenant)
            ClicNewsletter.objects.create(envoi=envoi, url=url[:1000])
        return HttpResponseRedirect(url)


class DansLeNavigateur(View):
    """La lettre telle qu'envoyée, sans rien de personnel (ni prénom, ni lien de désinscription)."""

    def get(self, request, jeton):
        from django.core import signing

        try:
            pk = signing.loads(jeton, salt=moteur.SEL_NAVIGATEUR)
        except signing.BadSignature:
            raise Http404
        newsletter = Newsletter.objects.filter(pk=pk).exclude(page=None).first()
        if newsletter is None:
            raise Http404
        _objet, html = moteur.rendu_commun(newsletter, {"prenom": "", "nom": "", "email": "",
                                                        "lien_desabonnement": ""})
        reponse = HttpResponse(html)
        reponse["X-Robots-Tag"] = "noindex"
        return reponse


class MesAbonnements(View):
    """
    « Mes newsletters » du compte client : cocher, c'est s'inscrire (sans
    lien à confirmer, l'adresse du compte est vérifiée) ; décocher, se
    désinscrire de cette liste. « Ne plus rien recevoir » vaut pour tout.
    """

    def post(self, request):
        from django.contrib import messages
        from django.shortcuts import redirect
        from django.urls import reverse

        from jeiko.throttling import ip_stockable

        if not request.user.is_authenticated or not request.user.email:
            return redirect(reverse("account_login"))
        retour = redirect(reverse("jeiko_users_client:profile-detail") + "#newsletter")
        email = request.user.email
        if request.POST.get("rien"):
            abonnes.desinscrire(email)
            messages.success(request, _("C'est noté : vous ne recevrez plus aucune de nos lettres."))
            return retour
        cochees = set(request.POST.getlist("listes"))
        proposees = {str(l.pk): l for l in Liste.objects.filter(proposee_aux_clients=True)}
        etats = {str(e["liste"].pk): e["etat"] for e in abonnes.listes_du_compte(request.user)}
        a_inscrire = [l for pk, l in proposees.items() if pk in cochees and not etats.get(pk)]
        a_retirer = [l for pk, l in proposees.items() if pk not in cochees and etats.get(pk)]
        if a_inscrire:
            abonnes.inscrire(email, a_inscrire, source=Inscription.Source.COMPTE, detail=_("Compte client"),
                             texte=_texte_du_consentement({}), ip=ip_stockable(request),
                             prenom=request.user.first_name, nom=request.user.last_name, user=request.user)
        if a_retirer:
            abonnes.desinscrire(email, a_retirer)
        messages.success(request, _("Vos abonnements sont enregistrés."))
        return retour
