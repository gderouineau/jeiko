from django.urls import path

from . import vues_publiques as vues

app_name = "jeiko_newsletter"

urlpatterns = [
    path("inscription/<int:bloc_id>/", vues.Inscrire.as_view(), name="inscrire"),
    path("confirmation/<str:jeton>/", vues.Confirmer.as_view(), name="confirmer"),
    path("desinscription/<str:jeton>/", vues.Desinscrire.as_view(), name="desinscription"),
    path("desinscription/<str:jeton>/un-clic/", vues.DesinscrireEnUnClic.as_view(), name="desinscription_un_clic"),
    path("lien/<str:jeton>/", vues.Clic.as_view(), name="clic"),
    path("lire/<str:jeton>/", vues.DansLeNavigateur.as_view(), name="navigateur"),
]
