# jeiko/newsletter/rebonds.py
"""
NEWS-01 — les rebonds DIFFÉRÉS : l'adresse acceptée par le serveur d'envoi,
puis refusée plus tard par celui du destinataire (« boîte inexistante »).
L'avis revient dans une boîte aux lettres, pas dans la réponse SMTP : sans
le lire, on réécrivait à chaque lettre à une adresse morte — ce que Gmail et
Yahoo comptent contre la réputation de l'expéditeur.

Toutes les heures (`cron_1h`), on relève la boîte réglée dans CRM ›
Newsletter › Réglages, en IMAP (bibliothèque standard), et on y lit les avis
de non-remise au format normalisé (RFC 3464 : `multipart/report`,
`message/delivery-status`). Un destinataire en échec définitif (statut 5.x.x)
qui est un abonné passe sur la liste de suppression ; son dernier envoi est
marqué en échec, avec le code.

Ce que ça ne fait pas :
* lire les avis en texte libre, hors norme (rares aujourd'hui) ;
* toucher aux autres messages de la boîte : le serveur ne rend que les
  messages `…report` non lus ; seuls les avis reconnus sont marqués comme
  lus ; on lit avec BODY.PEEK, qui ne change rien au reste ;
* retenir un avis pour une adresse à qui rien n'est parti ces 30 derniers
  jours (`traiter`) ;
* traiter les échecs temporaires (4.x.x : boîte pleine) : le serveur
  d'envoi réessaie de lui-même.
"""
import email
import imaplib
import logging
import ssl
from datetime import timedelta
from email import policy

from django.utils import timezone

from jeiko.emailing.models import Abonne, EnvoiNewsletter, ReglagesNewsletter

from . import abonnes

logger = logging.getLogger(__name__)

#: Au plus par relevé : une boîte pleine d'anciens messages ne bloque pas le cron.
MESSAGES_PAR_RELEVE = 200

def meme_boite(reglages, hote, utilisateur):
    """La boîte enregistrée est-elle celle-ci ? Sinon, son mot de passe ne la suit pas (audit NL-02)."""
    return ((hote or "").strip().lower() == (reglages.rebonds_hote or "").strip().lower()
            and (utilisateur or "").strip() == (reglages.rebonds_utilisateur or "").strip())


def echecs_definitifs(message):
    """[(adresse, statut)] des destinataires en échec définitif d'un avis de non-remise (RFC 3464)."""
    if message.get_content_type() != "multipart/report":
        return []
    trouves = []
    for partie in message.walk():
        if partie.get_content_type() != "message/delivery-status":
            continue
        # Une suite de blocs d'en-têtes : le premier décrit le message, les
        # suivants, un par destinataire.
        blocs = partie.get_payload()
        for bloc in blocs if isinstance(blocs, list) else []:
            destinataire = bloc.get("Final-Recipient") or bloc.get("Original-Recipient") or ""
            statut = (bloc.get("Status") or "").strip()
            action = (bloc.get("Action") or "failed").strip().lower()
            adresse = destinataire.split(";", 1)[-1].strip(" <>").lower()
            if "@" in adresse and statut.startswith("5.") and action == "failed":
                trouves.append((adresse, statut))
    return trouves


#: Un avis ne compte que pour une adresse à qui une lettre est partie dans
#: ce délai : un faux avis glissé dans la boîte ne bloque pas n'importe qui.
FENETRE_D_UN_REBOND = timedelta(days=30)


def traiter(adresse, statut):
    """
    Bloque l'abonné et marque son dernier envoi. Vrai si l'avis a été retenu.

    Retenu seulement si une lettre est partie vers cette adresse récemment
    (audit NL-06) : sans corrélation, un avis fabriqué suffisait à retirer une
    adresse valide. Ce que ça ne prouve pas : que l'avis vienne bien du
    serveur du destinataire — il faudrait les événements signés d'un
    prestataire d'envoi (voir le plan).
    """
    dernier = (EnvoiNewsletter.objects
               .filter(email=adresse, statut=EnvoiNewsletter.Statut.ENVOYE,
                       envoye_le__gte=timezone.now() - FENETRE_D_UN_REBOND)
               .order_by("-envoye_le").first())
    if dernier is None or not Abonne.objects.filter(email=adresse).exists():
        return False
    abonnes.bloquer(adresse, Abonne.Blocage.REBOND)
    if dernier is not None:
        EnvoiNewsletter.objects.filter(pk=dernier.pk).update(
            statut=EnvoiNewsletter.Statut.ECHEC, erreur=f"Rebond différé : {statut}")
    return True


def relever():
    """Relève la boîte des rebonds. Retourne le nombre d'abonnés bloqués. Ne lève jamais."""
    reglages = ReglagesNewsletter.du_site()
    if not (reglages.rebonds_hote and reglages.rebonds_utilisateur and reglages.rebonds_mot_de_passe):
        return 0
    bloques, erreur = 0, ""
    try:
        # Sans contexte, imaplib chiffre SANS vérifier le certificat ni le nom du
        # serveur : un intercepteur recevrait le mot de passe (audit NL-03).
        boite = imaplib.IMAP4_SSL(reglages.rebonds_hote, reglages.rebonds_port, timeout=30,
                                  ssl_context=ssl.create_default_context())
        try:
            boite.login(reglages.rebonds_utilisateur, reglages.rebonds_mot_de_passe)
            etat, _info = boite.select(reglages.rebonds_dossier or "INBOX")
            if etat != "OK":
                raise imaplib.IMAP4.error(f"dossier introuvable : {reglages.rebonds_dossier}")
            # Le serveur ne rend que les avis de non-remise non lus, et pas les
            # gros messages : les autres courriers, jamais touchés, ne peuvent
            # plus remplir le lot et cacher les rebonds derrière eux (audit NL-07).
            etat, donnees = boite.search(None, "UNSEEN", "HEADER", "Content-Type", "report", "SMALLER", "2000000")
            if etat != "OK":
                raise imaplib.IMAP4.error("recherche refusée par le serveur")
            numeros = (donnees[0] or b"").split()[:MESSAGES_PAR_RELEVE]
            for numero in numeros:
                _etat, morceaux = boite.fetch(numero, "(BODY.PEEK[])")
                brut = next((m[1] for m in morceaux if isinstance(m, tuple)), None)
                if not brut:
                    continue
                echecs = echecs_definitifs(email.message_from_bytes(brut, policy=policy.compat32))
                if not echecs:
                    continue
                bloques += sum(traiter(adresse, statut) for adresse, statut in echecs)
                boite.store(numero, "+FLAGS", "\\Seen")
        finally:
            try:
                boite.logout()
            except Exception:  # noqa: BLE001 — la session peut déjà être fermée
                pass
    except Exception as exc:  # noqa: BLE001 — un serveur injoignable ne doit pas faire échouer le cron
        logger.warning("Relevé des rebonds impossible : %s", exc)
        erreur = str(exc)[:300]
    ReglagesNewsletter.objects.filter(pk=reglages.pk).update(rebonds_releve_le=timezone.now(), rebonds_erreur=erreur)
    return bloques
