# jeiko/newsletter/sequences.py
"""
NEWS-01 — les séquences automatiques : « bienvenue » à J+0, un conseil à
J+3, une offre à J+10… à chaque nouvel inscrit d'une liste, sans que
personne n'appuie sur rien.

Une étape EST une `Newsletter` (champ `sequence`, `delai_jours`) : elle se
compose dans l'éditeur, se rend, se suit et porte la désinscription comme
une lettre ordinaire. Ce module ne fait que dire QUI doit la recevoir, et
quand : `planifier()`, appelé à chaque passage de `envoyer_un_lot()`
(cron_5m), pose les `EnvoiNewsletter` dus ; l'envoi par lots les fait partir
sous le même plafond horaire que le reste.

Les règles :
* seules les inscriptions confirmées APRÈS l'activation comptent : allumer
  une séquence n'écrit pas d'un coup à toute la liste ;
* le délai court depuis la confirmation de l'inscription à la liste ;
* une étape part une seule fois par adresse (contrainte d'unicité), même si
  la personne se désinscrit puis revient ;
* désinscrit ou bloqué entre-temps : la suite ne part pas.

Ce que ça ne fait pas : des conditions (« s'il a cliqué… »), des
déclencheurs autres que l'inscription à une liste (un achat, un rendez-vous).
"""
from datetime import timedelta

from django.db import transaction
from django.utils import timezone

from jeiko.emailing.models import EnvoiNewsletter, Inscription, Newsletter, Sequence


def creer(nom, liste):
    return Sequence.objects.create(nom=nom[:120], liste=liste)


def ajouter_une_etape(sequence, objet, par, delai_jours=0, modele=""):
    from .envoi import creer

    etape = creer(objet, par, [sequence.liste], modele=modele)
    etape.sequence = sequence
    etape.delai_jours = delai_jours
    etape.save(update_fields=["sequence", "delai_jours"])
    return etape


def etapes(sequence):
    return sequence.etapes.order_by("delai_jours", "pk")


@transaction.atomic
def activer(sequence, active=True):
    sequence = Sequence.objects.select_for_update().get(pk=sequence.pk)
    sequence.active = active
    if active and sequence.active_depuis is None:
        sequence.active_depuis = timezone.now()
    sequence.save(update_fields=["active", "active_depuis"])
    return sequence


def problemes(sequence):
    """Ce qui empêche la séquence de tourner, en phrases."""
    from django.utils.translation import gettext as _

    erreurs = []
    if not sequence.etapes.exists():
        erreurs.append(_("La séquence n'a aucune étape."))
    vides = [e.objet for e in sequence.etapes.all() if e.page is None or not e.page.sections.exists()]
    if vides:
        erreurs.append(_("Étape(s) sans contenu : %(objets)s.") % {"objets": ", ".join(vides)})
    return erreurs


def planifier(maintenant=None):
    """Pose les envois dus de toutes les séquences actives. Retourne leur nombre."""
    maintenant = maintenant or timezone.now()
    poses = 0
    for sequence in Sequence.objects.filter(active=True, active_depuis__isnull=False):
        inscrites = (Inscription.objects
                     .filter(liste=sequence.liste, statut=Inscription.Statut.INSCRIT,
                             confirmee_le__gte=sequence.active_depuis, abonne__bloque_le__isnull=True)
                     .select_related("abonne"))
        for etape in etapes(sequence):
            if etape.page is None or not etape.page.sections.exists():
                continue
            limite = maintenant - timedelta(days=etape.delai_jours)
            dues = [EnvoiNewsletter(newsletter=etape, abonne=i.abonne, email=i.abonne.email)
                    for i in inscrites.filter(confirmee_le__lte=limite)
                    .exclude(abonne__envois__newsletter=etape)]
            if dues:
                poses += len(EnvoiNewsletter.objects.bulk_create(dues, ignore_conflicts=True))
    return poses


def a_deja_envoye(sequence):
    """
    Une étape est-elle déjà partie ? Alors la liste de la séquence ne change
    plus : le lien de désinscription d'un message envoyé retire de la liste
    de ses étapes, et doit continuer à viser celle à laquelle la personne était
    inscrite (audit NL-12).
    """
    return EnvoiNewsletter.objects.filter(newsletter__sequence=sequence).exists()


def toujours_inscrit(lettre, abonne):
    """
    Au moment de partir : la personne est-elle encore inscrite à l'une des
    listes de la lettre (pour une étape : la liste de la séquence) ?
    """
    listes = [lettre.sequence.liste_id] if lettre.sequence_id else list(lettre.listes.values_list("pk", flat=True))
    return Inscription.objects.filter(liste_id__in=listes, abonne=abonne,
                                      statut=Inscription.Statut.INSCRIT).exists()


def statistiques(sequence):
    from .envoi import statistiques as stats

    return [{"etape": e, **stats(e)} for e in etapes(sequence)]


def lettres_ordinaires():
    """Les newsletters qui ne sont pas des étapes de séquence."""
    return Newsletter.objects.filter(sequence__isnull=True)
