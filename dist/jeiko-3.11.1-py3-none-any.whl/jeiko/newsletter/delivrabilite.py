# jeiko/newsletter/delivrabilite.py
"""
NEWS-01 — le domaine d'envoi est-il en règle ? SPF, DKIM, DMARC.

Le problème : depuis 2024, Gmail et Yahoo rejettent ou classent en
indésirables les envois en nombre d'un domaine sans SPF ni DKIM, et sans
DMARC au-delà de quelques milliers par jour. Rien ne le signale à
l'exploitant : la newsletter part, le serveur dit « envoyé », et personne ne
la lit. On lit donc le DNS du domaine de l'expéditeur, et on dit ce qui
manque.

Ce que ça ne fait pas :
* prouver que les messages passent — un SPF peut exister sans inclure le
  serveur réellement utilisé, une signature DKIM peut ne pas être posée ;
  seul un essai vers une boîte Gmail (« Afficher l'original ») le prouve ;
* trouver une clé DKIM à coup sûr : son nom (le « sélecteur ») est choisi
  par l'hébergeur d'e-mails et ne se devine pas. On essaie les plus courants ;
  sans réponse, c'est « à vérifier », pas « absent ».

Les réponses sont gardées une heure en cache : l'écran ne doit pas attendre
le DNS à chaque affichage.
"""
from django.core.cache import cache
from django.utils.translation import gettext as _

SELECTEURS_DKIM = ("default", "google", "selector1", "selector2", "k1", "k2", "s1", "s2", "mail", "dkim",
                   "smtp", "ovh", "mxvault", "protonmail", "zoho", "brevo", "mailjet")
DUREE_DU_CACHE = 3600


def domaine_d_envoi():
    from jeiko.emailing.models import ReglagesNewsletter
    from jeiko.emailing.sending import get_mail_settings

    adresse = ReglagesNewsletter.du_site().expediteur
    if not adresse:
        reglages = get_mail_settings()
        adresse = getattr(reglages, "default_from_email", "") or getattr(reglages, "host_user", "") or ""
    adresse = adresse.split("<")[-1].strip(" >")
    return adresse.rsplit("@", 1)[-1].lower() if "@" in adresse else ""


def _txt(nom):
    """Les enregistrements TXT de `nom`, ou [] s'il n'y en a pas. None : le DNS n'a pas répondu."""
    try:
        import dns.exception
        import dns.resolver
    except ImportError:  # dnspython pas encore installé sur ce site : « pas de réponse », pas d'erreur.
        return None

    try:
        reponse = dns.resolver.resolve(nom, "TXT", lifetime=3)
    except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
        return []
    except dns.exception.DNSException:
        return None
    return [b"".join(r.strings).decode("utf-8", "replace") for r in reponse]


def verifier(domaine=None):
    """
    [(etat, libelle, detail)] — etat : "ok", "attention" ou "manque". Vide si
    aucun domaine d'envoi n'est connu.
    """
    domaine = domaine or domaine_d_envoi()
    if not domaine:
        return []
    cle = f"jeiko:newsletter:dns:{domaine}"
    deja = cache.get(cle)
    if deja is not None:
        return deja

    lignes = []
    spf = _txt(domaine)
    if spf is None:
        lignes.append(("attention", "SPF", _("Le DNS de %(d)s n'a pas répondu ; réessayez plus tard.") % {"d": domaine}))
    else:
        trouve = [t for t in spf if t.lower().startswith("v=spf1")]
        lignes.append(("ok", "SPF", trouve[0]) if trouve else (
            "manque", "SPF", _("Aucun enregistrement SPF sur %(d)s : ajoutez celui que donne votre hébergeur "
                               "d'e-mails (« v=spf1 include:… ~all »).") % {"d": domaine}))

    dkim = None
    for selecteur in SELECTEURS_DKIM:
        enregistrements = _txt(f"{selecteur}._domainkey.{domaine}") or []
        if any("p=" in t for t in enregistrements):
            dkim = selecteur
            break
    lignes.append(("ok", "DKIM", _("Clé trouvée (sélecteur « %(s)s »).") % {"s": dkim}) if dkim else (
        "attention", "DKIM", _("Aucune clé trouvée parmi les sélecteurs courants. Vérifiez chez votre hébergeur "
                               "d'e-mails que la signature DKIM est activée pour %(d)s.") % {"d": domaine}))

    dmarc = _txt(f"_dmarc.{domaine}")
    trouve = [t for t in (dmarc or []) if t.lower().startswith("v=dmarc1")]
    lignes.append(("ok", "DMARC", trouve[0]) if trouve else (
        "manque", "DMARC", _("Aucun DMARC : ajoutez un enregistrement TXT « _dmarc.%(d)s » valant au moins "
                             "« v=DMARC1; p=none; ». Gmail et Yahoo l'exigent pour les envois en nombre.")
        % {"d": domaine}))

    cache.set(cle, lignes, DUREE_DU_CACHE)
    return lignes
