# jeiko/newsletter/abonnes.py
"""
NEWS-01 — inscrire, confirmer, désinscrire. Le seul chemin d'écriture des
abonnés : le bloc du site, les questionnaires, l'administration, l'import et
l'API passent tous par `inscrire()`, pour que la preuve soit toujours tenue
de la même façon.

Deux règles qui ne se discutent pas :

* **Qui s'inscrit lui-même confirme** (si la liste l'exige) : une adresse
  saisie dans un formulaire public n'est pas une preuve — n'importe qui peut
  y taper celle d'un autre. L'inscription reste « en attente » jusqu'au clic
  sur le lien reçu ; elle ne reçoit rien d'ici là.
* **Une adresse bloquée ne se réinscrit que d'elle-même.** Désinscrite de
  tout, ou en échec définitif : l'administration et l'import ne peuvent pas
  la remettre sur une liste. Seule la personne, en ligne, peut revenir.

Ce que ce module ne fait pas : juger qu'un import est consenti. La personne
qui importe atteste que les adresses ont donné leur accord ; on garde son
nom, le fichier et la date (`detail_source`).
"""
import logging

from django.core import signing
from django.db import transaction
from django.utils import timezone

from jeiko.emailing.models import Abonne, Inscription, Liste

logger = logging.getLogger(__name__)

SEL_CONFIRMATION = "jeiko.newsletter.confirmer"
VALIDITE_CONFIRMATION = 60 * 60 * 24 * 7
VALIDITE_LIBELLE = "7 jours"

#: Les sources où la personne agit elle-même : la double confirmation y
#: s'applique, et elles seules lèvent un blocage.
SOURCES_PERSONNELLES = (Inscription.Source.BLOC, Inscription.Source.QUESTIONNAIRE, Inscription.Source.COMPTE)


class AdresseBloquee(Exception):
    """L'adresse est sur la liste de suppression : on ne l'inscrit pas pour elle."""


def _abonne(email, prenom="", nom="", user=None):
    email = (email or "").strip().lower()
    abonne, _cree = Abonne.objects.get_or_create(email=email)
    changes = []
    if prenom and not abonne.prenom:
        abonne.prenom, changes = prenom[:120], changes + ["prenom"]
    if nom and not abonne.nom:
        abonne.nom, changes = nom[:120], changes + ["nom"]
    if user is not None and abonne.user_id is None:
        abonne.user, changes = user, changes + ["user"]
    if changes:
        abonne.save(update_fields=changes)
    return abonne


@transaction.atomic
def inscrire(email, listes=None, *, source, detail="", texte="", ip=None, prenom="", nom="", user=None):
    """
    Inscrit `email` sur `listes` (la liste par défaut si rien n'est donné).

    Retourne la liste des inscriptions touchées. Envoie l'e-mail de
    confirmation quand l'une d'elles l'attend. Lève `AdresseBloquee` quand
    l'administration ou l'import visent une adresse sur la liste de suppression.
    """
    listes = list(listes or [Liste.par_defaut_du_site()])
    abonne = _abonne(email, prenom, nom, user)
    personnel = source in SOURCES_PERSONNELLES

    # Une adresse sur la liste de suppression ne revient que par la personne
    # elle-même : son compte (adresse déjà prouvée) la débloque ; un
    # formulaire, que n'importe qui peut remplir avec son adresse, demande
    # qu'elle confirme d'abord — le blocage tient jusque-là (audit NL-05).
    a_debloquer = False
    if abonne.bloque_le:
        if not personnel:
            raise AdresseBloquee(abonne.email)
        if source == Inscription.Source.COMPTE:
            abonne.bloque_le, abonne.blocage = None, ""
            abonne.save(update_fields=["bloque_le", "blocage"])
        else:
            a_debloquer = True

    maintenant = timezone.now()
    touchees, a_confirmer = [], []
    for liste in listes:
        inscription = Inscription.objects.filter(abonne=abonne, liste=liste).first()
        if inscription and inscription.statut == Inscription.Statut.INSCRIT and not a_debloquer:
            touchees.append(inscription)
            continue
        # Le compte client a déjà prouvé son adresse (vérification obligatoire
        # à l'inscription) : pas de second lien à cliquer.
        attendre = a_debloquer or (personnel and liste.double_opt_in and source != Inscription.Source.COMPTE)
        valeurs = {
            "statut": Inscription.Statut.EN_ATTENTE if attendre else Inscription.Statut.INSCRIT,
            "source": source, "detail_source": (detail or "")[:255], "texte_consentement": texte or "",
            "ip": ip, "demandee_le": maintenant, "confirmee_le": None if attendre else maintenant,
            "desinscrite_le": None,
        }
        inscription, _cree = Inscription.objects.update_or_create(abonne=abonne, liste=liste, defaults=valeurs)
        touchees.append(inscription)
        if attendre:
            a_confirmer.append(liste)

    if a_confirmer:
        transaction.on_commit(lambda: envoyer_la_confirmation(abonne.email, [l.pk for l in a_confirmer]))
    if len(a_confirmer) < len(listes):
        transaction.on_commit(lambda: au_crm(abonne))
    return touchees


def au_crm(abonne):
    """
    L'abonné inscrit a sa fiche dans le CRM (origine « Newsletter ») : la
    même règle de rattachement que les formulaires et les réservations
    (`crm/rattachement.py`) — une fiche existante est complétée, jamais
    écrasée. Ne lève jamais.
    """
    from jeiko.crm.rattachement import rattacher
    from jeiko.questionnaires_expert.models import Prospect

    return rattacher(abonne.email, nom=f"{abonne.prenom} {abonne.nom}".strip(), origine=Prospect.Origine.NEWSLETTER)


def jeton_de_confirmation(email, liste_ids):
    return signing.dumps({"e": email, "l": sorted(liste_ids)}, salt=SEL_CONFIRMATION)


def envoyer_la_confirmation(email, liste_ids):
    from django.urls import reverse

    from jeiko.emailing.render import site_base_url
    from jeiko.emailing.services import send_email

    chemin = reverse("jeiko_newsletter:confirmer", args=[jeton_de_confirmation(email, liste_ids)])
    return send_email("newsletter_double_optin", email, {
        "lien_action": f"{site_base_url()}{chemin}", "expiration": VALIDITE_LIBELLE,
    })


@transaction.atomic
def confirmer(jeton):
    """Valide les inscriptions en attente que porte le jeton. Retourne l'abonné, ou None."""
    try:
        charge = signing.loads(jeton, salt=SEL_CONFIRMATION, max_age=VALIDITE_CONFIRMATION)
    except signing.BadSignature:
        return None
    abonne = Abonne.objects.filter(email=charge.get("e", "")).first()
    if abonne is None:
        return None
    attente = Inscription.objects.select_for_update().filter(
        abonne=abonne, liste_id__in=charge.get("l", []), statut=Inscription.Statut.EN_ATTENTE)
    if attente.update(statut=Inscription.Statut.INSCRIT, confirmee_le=timezone.now()):
        # La personne a cliqué depuis sa boîte : elle peut sortir de la liste de suppression.
        if abonne.bloque_le:
            Abonne.objects.filter(pk=abonne.pk).update(bloque_le=None, blocage="")
        from jeiko.emailing.services import send_email

        transaction.on_commit(lambda: send_email("newsletter_welcome", abonne.email, {"frequence": "par e-mail"}))
        transaction.on_commit(lambda: au_crm(abonne))
    return abonne


@transaction.atomic
def desinscrire(email, listes=None):
    """
    Désinscrit `email` de `listes` ; de TOUT si `listes` vaut None — l'adresse
    passe alors sur la liste de suppression, et les préférences marketing
    d'un compte portant cette adresse sont éteintes.
    Retourne le nombre d'inscriptions retirées.
    """
    email = (email or "").strip().lower()
    abonne = Abonne.objects.filter(email=email).first()
    retirees = 0
    if abonne is not None:
        actives = abonne.inscriptions.exclude(statut=Inscription.Statut.DESINSCRIT)
        if listes is not None:
            actives = actives.filter(liste__in=listes)
        retirees = actives.update(statut=Inscription.Statut.DESINSCRIT, desinscrite_le=timezone.now())
        if listes is None:
            abonne.bloque_le, abonne.blocage = timezone.now(), Abonne.Blocage.DESINSCRIT
            abonne.save(update_fields=["bloque_le", "blocage"])
    if listes is None:
        from jeiko.emailing.unsubscribe import unsubscribe

        unsubscribe(email)
    return retirees


def bloquer(email, motif):
    """Rebond définitif ou plainte : plus aucun envoi à cette adresse."""
    Abonne.objects.filter(email=(email or "").strip().lower(), bloque_le__isnull=True).update(
        bloque_le=timezone.now(), blocage=motif)


def destinataires(listes, etiquettes=None, statut=""):
    """
    Les abonnés à écrire : inscrits sur l'une des listes, non bloqués, chacun
    une fois. `etiquettes` / `statut` : seulement ceux dont la fiche du CRM
    porte l'une de ces étiquettes, ou ce statut (une adresse sans fiche est
    alors écartée).
    """
    qs = (Abonne.objects
          .filter(bloque_le__isnull=True,
                  inscriptions__liste__in=listes,
                  inscriptions__statut=Inscription.Statut.INSCRIT)
          .distinct())
    if etiquettes or statut:
        from functools import reduce
        from operator import or_

        from django.db.models import Q
        from django.db.models.functions import Lower

        from jeiko.questionnaires_expert.models import Prospect

        fiches = Prospect.objects.exclude(email="")
        if etiquettes:
            fiches = fiches.filter(reduce(or_, (Q(tags__contains=[e]) for e in etiquettes)))
        if statut:
            fiches = fiches.filter(status=statut)
        qs = qs.filter(email__in=fiches.annotate(e=Lower("email")).values("e"))
    return qs


def destinataires_de(newsletter):
    return destinataires(newsletter.listes.all(), newsletter.etiquettes_crm, newsletter.statut_crm)


# --- RGPD : droit d'accès et effacement d'une adresse ---

def export_de_l_adresse(email):
    """Les abonnements d'une adresse et leur preuve (droit d'accès)."""
    abonne = Abonne.objects.filter(email=(email or "").strip().lower()).first()
    if abonne is None:
        return []
    return [
        {"liste": i.liste.nom, "statut": i.get_statut_display(), "source": i.get_source_display(),
         "detail": i.detail_source, "texte_du_consentement": i.texte_consentement,
         "demandee_le": i.demandee_le.isoformat(),
         "confirmee_le": i.confirmee_le.isoformat() if i.confirmee_le else None,
         "desinscrite_le": i.desinscrite_le.isoformat() if i.desinscrite_le else None}
        for i in abonne.inscriptions.select_related("liste")
    ]


def effacer_l_adresse(email):
    """
    L'abonné, ses inscriptions, et la trace des lettres reçues (destinataire,
    clics). L'adresse quitte aussi la liste de suppression : l'effacement
    l'emporte — si elle est réimportée un jour, c'est à celui qui importe de
    s'assurer de l'accord.
    """
    from jeiko.emailing.models import EnvoiNewsletter

    email = (email or "").strip().lower()
    if not email:
        return 0
    envois = EnvoiNewsletter.objects.filter(email=email).delete()[0]
    return Abonne.objects.filter(email=email).delete()[0] + envois


def listes_du_compte(user):
    """
    « Mes newsletters » : les listes proposées aux clients, et pour chacune
    l'état de l'inscription de ce compte (par son adresse) — "inscrit",
    "attente" ou "".
    """
    abonne = Abonne.objects.filter(email=(user.email or "").strip().lower()).first()
    etats = {}
    if abonne is not None:
        etats = {i.liste_id: i.statut for i in abonne.inscriptions.all()}
    return [{"liste": liste, "etat": "" if etats.get(liste.pk) == Inscription.Statut.DESINSCRIT else etats.get(liste.pk, "")}
            for liste in Liste.objects.filter(proposee_aux_clients=True)]
