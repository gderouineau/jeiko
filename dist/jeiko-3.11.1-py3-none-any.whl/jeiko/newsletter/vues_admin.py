# jeiko/newsletter/vues_admin.py
"""
NEWS-01 — CRM › Newsletter : une page, cinq onglets (Newsletters, Listes,
Abonnés, Séquences, Réglages). Les onglets sont des ADRESSES, pas des
panneaux masqués : la liste des abonnés se cherche et se pagine, et un lien
garde l'onglet.

Droits : lire avec « voir les contacts », écrire avec « modifier les
contacts » — ce sont les mêmes personnes. Tout ce qui FAIT PARTIR des e-mails
demande en plus le droit sur les e-mails du site, puisqu'une newsletter part
au nom du site : programmer, envoyer un essai à une autre adresse que la
sienne, activer une séquence ou modifier une séquence active ; et les
Réglages (expéditeur, cadence, boîte des rebonds et son mot de passe) — audit
NL-01, NL-02.
"""
import csv
import io
from urllib.parse import urlencode

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Count, Q
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.dateparse import parse_datetime
from django.utils.decorators import method_decorator
from django.utils.translation import gettext as _
from django.views import View
from django.views.decorators.cache import never_cache
from django.views.decorators.clickjacking import xframe_options_sameorigin

from jeiko.emailing.models import Abonne, EnvoiNewsletter, Inscription, Liste, Newsletter, ReglagesNewsletter
from jeiko.listes import paginer

from . import abonnes as service, envoi as moteur
from .forms import AjoutAbonneForm, ImportForm, ListeForm, NewsletterForm, ReglagesForm

VOIR = "questionnaires_expert.view_prospect"
MODIFIER = "questionnaires_expert.change_prospect"
ENVOYER = "users.config_edit_mail"


@method_decorator(never_cache, name="dispatch")
class _Acces(LoginRequiredMixin, PermissionRequiredMixin, View):
    raise_exception = True
    permission_required = VOIR
    onglet_actif = ""

    def ecrire(self):
        return self.request.user.has_perm(MODIFIER)

    def rendre(self, gabarit, **contexte):
        contexte.setdefault("onglet", self.onglet_actif)
        contexte.setdefault("peut_ecrire", self.ecrire())
        return render(self.request, gabarit, contexte)

    def refuser_si_lecture_seule(self):
        if not self.ecrire():
            from django.core.exceptions import PermissionDenied

            raise PermissionDenied


# --- Newsletters ---

class Newsletters(_Acces):
    onglet_actif = "newsletters"

    def get(self, request):
        lettres = (Newsletter.objects.filter(sequence__isnull=True).prefetch_related("listes")
                   .annotate(nb_envoyes=Count("envois", filter=Q(envois__statut=EnvoiNewsletter.Statut.ENVOYE)),
                             nb_cliqueurs=Count("envois", filter=Q(envois__clics__gt=0))))
        objets, pagination = paginer(request, lettres)
        from .modeles import choix

        return self.rendre("newsletter/admin/newsletters.html", newsletters=objets, modeles=choix(), **pagination)

    def post(self, request):
        self.refuser_si_lecture_seule()
        objet = (request.POST.get("objet") or "").strip() or _("Nouvelle newsletter")
        lettre = moteur.creer(objet[:200], request.user, modele=request.POST.get("modele", ""))
        return redirect("jeiko_newsletter_admin:fiche", lettre.pk)


class Fiche(_Acces):
    onglet_actif = "newsletters"

    def contexte(self, lettre, form):
        envois = lettre.envois.select_related("abonne").order_by("-clics", "email")
        filtre = self.request.GET.get("envois")
        if filtre in EnvoiNewsletter.Statut.values:
            envois = envois.filter(statut=filtre)
        objets, pagination = paginer(self.request, envois)
        from jeiko.emailing.models import ClicNewsletter

        liens = (ClicNewsletter.objects.filter(envoi__newsletter=lettre).values("url")
                 .annotate(clics=Count("id"), personnes=Count("envoi", distinct=True)).order_by("-clics")[:20])
        return {
            "lettre": lettre, "form": form, "stats": moteur.statistiques(lettre),
            "problemes": moteur.problemes(lettre) if lettre.modifiable else [],
            "dns_en_defaut": self._dns_en_defaut() if lettre.modifiable else [],
            "nb_destinataires": service.destinataires_de(lettre).count() if lettre.modifiable else None,
            "envois": objets, **pagination, "liens": liens, "statuts_envoi": EnvoiNewsletter.Statut.choices,
            "peut_envoyer": self.request.user.has_perm(ENVOYER),
            "lien_navigateur": moteur.lien_navigateur(lettre),
        }

    @staticmethod
    def _dns_en_defaut():
        from . import delivrabilite

        return [libelle for etat, libelle, _d in delivrabilite.verifier() if etat == "manque"]

    def get(self, request, pk):
        lettre = get_object_or_404(Newsletter, pk=pk)
        return self.rendre("newsletter/admin/fiche.html", **self.contexte(lettre, NewsletterForm(instance=lettre)))

    def post(self, request, pk):
        self.refuser_si_lecture_seule()
        lettre = get_object_or_404(Newsletter, pk=pk)
        if not lettre.modifiable:
            messages.error(request, _("Une newsletter envoyée ne se modifie plus : dupliquez-la."))
            return redirect("jeiko_newsletter_admin:fiche", pk)
        form = NewsletterForm(request.POST, instance=lettre)
        if form.is_valid():
            form.save()
            messages.success(request, _("Newsletter enregistrée."))
            return redirect("jeiko_newsletter_admin:fiche", pk)
        return self.rendre("newsletter/admin/fiche.html", **self.contexte(lettre, form))


@method_decorator(xframe_options_sameorigin, name="dispatch")
class Apercu(_Acces):
    def get(self, request, pk):
        lettre = get_object_or_404(Newsletter, pk=pk)
        _objet, html = moteur.rendu_commun(lettre, {"prenom": "Camille", "nom": "Dupont",
                                                    "email": "camille@exemple.fr", "lien_desabonnement": "#"})
        return HttpResponse(html)


class Action(_Acces):
    """Dupliquer, envoyer un essai, programmer, annuler, supprimer un brouillon."""

    def post(self, request, pk, action):
        self.refuser_si_lecture_seule()
        lettre = get_object_or_404(Newsletter, pk=pk)
        if action == "dupliquer":
            copie = moteur.dupliquer(lettre, request.user)
            messages.success(request, _("Copie créée : elle est en brouillon."))
            return redirect("jeiko_newsletter_admin:fiche", copie.pk)
        if action == "essai":
            adresse = (request.POST.get("adresse") or request.user.email or "").strip()
            # Un essai à sa propre adresse, oui ; à une autre, c'est un envoi :
            # le droit sur les e-mails du site (audit NL-01).
            if adresse.lower() != (request.user.email or "").lower() and not request.user.has_perm(ENVOYER):
                messages.error(request, _("Envoyer un essai à une autre adresse que la vôtre demande le droit "
                                          "sur les e-mails du site."))
                return redirect("jeiko_newsletter_admin:fiche", pk)
            ok, erreur = moteur.envoyer_un_essai(lettre, adresse)
            if ok:
                messages.success(request, _("Essai envoyé à %(adresse)s.") % {"adresse": adresse})
            else:
                messages.error(request, _("L'essai n'est pas parti : %(erreur)s") % {"erreur": erreur})
        elif action == "programmer":
            if not request.user.has_perm(ENVOYER):
                messages.error(request, _("Programmer un envoi demande le droit sur les e-mails du site."))
                return redirect("jeiko_newsletter_admin:fiche", pk)
            quand = parse_datetime(request.POST.get("quand") or "")
            if quand is not None and timezone.is_naive(quand):
                quand = timezone.make_aware(quand)
            try:
                moteur.programmer(lettre, request.user, quand)
            except moteur.EnvoiImpossible as erreur:
                messages.error(request, _("Envoi impossible : %(motif)s") % {"motif": erreur})
            else:
                messages.success(request, _("Envoi programmé. Il part par lots, dans les minutes qui viennent."))
        elif action == "annuler":
            moteur.annuler(lettre)
            messages.success(request, _("Envoi arrêté."))
        elif action == "supprimer" and lettre.statut == Newsletter.Statut.BROUILLON:
            page, sequence_id = lettre.page, lettre.sequence_id
            lettre.delete()
            if page is not None:
                page.delete()
            messages.success(request, _("Brouillon supprimé."))
            if sequence_id:
                return redirect("jeiko_newsletter_admin:sequence", sequence_id)
            return redirect("jeiko_newsletter_admin:newsletters")
        return redirect("jeiko_newsletter_admin:fiche", pk)


# --- Listes ---

def _listes_avec_comptes():
    statut = Inscription.Statut
    Liste.par_defaut_du_site()
    return Liste.objects.annotate(
        inscrits=Count("inscriptions", filter=Q(inscriptions__statut=statut.INSCRIT,
                                                inscriptions__abonne__bloque_le__isnull=True)),
        en_attente=Count("inscriptions", filter=Q(inscriptions__statut=statut.EN_ATTENTE)),
        desinscrits=Count("inscriptions", filter=Q(inscriptions__statut=statut.DESINSCRIT)),
    )


class Listes(_Acces):
    onglet_actif = "listes"

    def get(self, request):
        return self.rendre("newsletter/admin/listes.html", listes=_listes_avec_comptes(), form=ListeForm())

    def post(self, request):
        self.refuser_si_lecture_seule()
        form = ListeForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, _("Liste créée."))
            return redirect("jeiko_newsletter_admin:listes")
        return self.rendre("newsletter/admin/listes.html", listes=_listes_avec_comptes(), form=form)


class ModifierListe(_Acces):
    onglet_actif = "listes"

    def get(self, request, pk):
        liste = get_object_or_404(Liste, pk=pk)
        return self.rendre("newsletter/admin/liste.html", liste=liste, form=ListeForm(instance=liste))

    def post(self, request, pk):
        self.refuser_si_lecture_seule()
        liste = get_object_or_404(Liste, pk=pk)
        if request.POST.get("supprimer"):
            if liste.par_defaut:
                messages.error(request, _("La liste par défaut ne se supprime pas."))
            else:
                liste.delete()
                messages.success(request, _("Liste supprimée. Les abonnés restent, sur leurs autres listes."))
                return redirect("jeiko_newsletter_admin:listes")
            return redirect("jeiko_newsletter_admin:liste", pk)
        form = ListeForm(request.POST, instance=liste)
        if form.is_valid():
            form.save()
            messages.success(request, _("Liste enregistrée."))
            return redirect("jeiko_newsletter_admin:listes")
        return self.rendre("newsletter/admin/liste.html", liste=liste, form=form)


# --- Abonnés ---

class Abonnes(_Acces):
    onglet_actif = "abonnes"

    def queryset(self):
        qs = Abonne.objects.prefetch_related("inscriptions__liste").order_by("-cree_le")
        terme = (self.request.GET.get("q") or "").strip()
        if terme:
            qs = qs.filter(Q(email__icontains=terme) | Q(prenom__icontains=terme) | Q(nom__icontains=terme))
        liste = self.request.GET.get("liste")
        statut = self.request.GET.get("statut")
        if statut == "bloque":
            qs = qs.filter(bloque_le__isnull=False)
        elif liste or statut in Inscription.Statut.values:
            filtre = {}
            if liste:
                filtre["inscriptions__liste_id"] = liste
            if statut in Inscription.Statut.values:
                filtre["inscriptions__statut"] = statut
            qs = qs.filter(**filtre).distinct()
        return qs

    def get(self, request):
        objets, pagination = paginer(request, self.queryset())
        return self.rendre(
            "newsletter/admin/abonnes.html", abonnes=objets, **pagination,
            listes=Liste.objects.all(), statuts=Inscription.Statut.choices,
            form=AjoutAbonneForm(initial={"listes": [Liste.par_defaut_du_site()]}), import_form=ImportForm(),
            recherche=request.GET.get("q", ""),
        )

    def post(self, request):
        self.refuser_si_lecture_seule()
        form = AjoutAbonneForm(request.POST)
        if form.is_valid():
            donnees = form.cleaned_data
            try:
                service.inscrire(donnees["email"], donnees["listes"], source=Inscription.Source.MANUEL,
                                 detail=_("Ajouté par %(nom)s") % {"nom": request.user.get_username()},
                                 prenom=donnees["prenom"], nom=donnees["nom"])
            except service.AdresseBloquee:
                messages.error(request, _("Cette adresse s'est désinscrite de tout (ou ne reçoit plus) : "
                                          "seule la personne peut se réinscrire, depuis le site."))
            else:
                messages.success(request, _("Abonné ajouté."))
            return redirect("jeiko_newsletter_admin:abonnes")
        objets, pagination = paginer(request, self.queryset())
        return self.rendre("newsletter/admin/abonnes.html", abonnes=objets, **pagination,
                           listes=Liste.objects.all(), statuts=Inscription.Statut.choices,
                           form=form, import_form=ImportForm(), recherche="")


class Importer(_Acces):
    def post(self, request):
        self.refuser_si_lecture_seule()
        form = ImportForm(request.POST, request.FILES)
        if not form.is_valid():
            for erreurs in form.errors.values():
                messages.error(request, " ".join(erreurs))
            return redirect("jeiko_newsletter_admin:abonnes")
        brut = form.cleaned_data["fichier"].read().decode("utf-8-sig", errors="replace")
        try:
            dialecte = csv.Sniffer().sniff(brut[:2048], delimiters=",;\t")
        except csv.Error:
            dialecte = csv.excel
        lecteur = csv.DictReader(io.StringIO(brut), dialect=dialecte)
        champs = {(c or "").strip().lower(): c for c in (lecteur.fieldnames or [])}
        colonne = champs.get("email") or champs.get("e-mail") or champs.get("mail")
        if colonne is None:
            messages.error(request, _("Le fichier n'a pas de colonne « email »."))
            return redirect("jeiko_newsletter_admin:abonnes")
        detail = _("Import « %(fichier)s » par %(nom)s") % {"fichier": form.cleaned_data["fichier"].name,
                                                            "nom": request.user.get_username()}
        from django.core.exceptions import ValidationError
        from django.core.validators import validate_email

        ajoutes = bloques = invalides = 0
        for ligne in lecteur:
            adresse = (ligne.get(colonne) or "").strip()
            try:
                validate_email(adresse)
            except ValidationError:
                invalides += 1
                continue
            try:
                service.inscrire(adresse, [form.cleaned_data["liste"]], source=Inscription.Source.IMPORT,
                                 detail=detail, prenom=(ligne.get(champs.get("prenom", ""), "") or "").strip(),
                                 nom=(ligne.get(champs.get("nom", ""), "") or "").strip())
                ajoutes += 1
            except service.AdresseBloquee:
                bloques += 1
        messages.success(request, _("%(ajoutes)s adresse(s) inscrite(s) ; %(bloques)s écartée(s) car désinscrite(s) "
                                    "de tout ; %(invalides)s invalide(s).")
                         % {"ajoutes": ajoutes, "bloques": bloques, "invalides": invalides})
        return redirect("jeiko_newsletter_admin:abonnes")


class DesinscrireAbonne(_Acces):
    def post(self, request, pk):
        self.refuser_si_lecture_seule()
        abonne = get_object_or_404(Abonne, pk=pk)
        liste_id = request.POST.get("liste")
        service.desinscrire(abonne.email, Liste.objects.filter(pk=liste_id) if liste_id else None)
        messages.success(request, _("Désinscription enregistrée."))
        return redirect(reverse("jeiko_newsletter_admin:abonnes") + "?" + urlencode({"q": abonne.email}))


class ExporterAbonnes(Abonnes):
    permission_required = (VOIR, "questionnaires_expert.export_contacts")

    def get(self, request):
        # Le prénom vient d'une inscription publique : « =… » serait lu comme une
        # formule par le tableur (audit NL-10) — la neutralisation de C-10.
        from jeiko.shop.facturation_export import _texte as cellule

        sortie = io.StringIO()
        ecrivain = csv.writer(sortie, delimiter=";")
        ecrivain.writerow(["email", "prenom", "nom", "liste", "statut", "source", "demandee_le", "confirmee_le"])
        for abonne in self.queryset():
            for inscription in abonne.inscriptions.all():
                ecrivain.writerow([cellule(abonne.email), cellule(abonne.prenom), cellule(abonne.nom),
                                   cellule(inscription.liste.nom),
                                   inscription.statut, inscription.source,
                                   inscription.demandee_le.isoformat(),
                                   inscription.confirmee_le.isoformat() if inscription.confirmee_le else ""])
        reponse = HttpResponse(sortie.getvalue(), content_type="text/csv; charset=utf-8")
        reponse["Content-Disposition"] = 'attachment; filename="abonnes.csv"'
        return reponse


# --- Réglages ---

class Reglages(_Acces):
    onglet_actif = "reglages"

    def get(self, request):
        from . import delivrabilite

        return self.rendre("newsletter/admin/reglages.html", form=ReglagesForm(instance=ReglagesNewsletter.du_site()),
                           domaine=delivrabilite.domaine_d_envoi(), dns=delivrabilite.verifier())

    def ecrire(self):
        # Expéditeur, cadence, boîte des rebonds et son mot de passe : des
        # réglages d'envoi, pas de contacts — le droit d'envoi, comme l'API (audit NL-02).
        return self.request.user.has_perm(ENVOYER)

    def post(self, request):
        self.refuser_si_lecture_seule()
        form = ReglagesForm(request.POST, instance=ReglagesNewsletter.du_site())
        if form.is_valid():
            form.save()
            messages.success(request, _("Réglages enregistrés."))
            return redirect("jeiko_newsletter_admin:reglages")
        return self.rendre("newsletter/admin/reglages.html", form=form)


class InscrireLeContact(_Acces):
    """Depuis la fiche d'un contact du CRM : l'inscrire à des listes, en attestant son accord."""

    def post(self, request, pk):
        from jeiko.questionnaires_expert.models import Prospect

        self.refuser_si_lecture_seule()
        contact = get_object_or_404(Prospect, pk=pk)
        retour = redirect(reverse("jeiko_crm:fiche", args=[pk]) + "#consentements")
        listes = Liste.objects.filter(pk__in=request.POST.getlist("listes"))
        if not contact.email or not listes or not request.POST.get("accord"):
            messages.error(request, _("Choisissez une liste et attestez l'accord de la personne."))
            return retour
        try:
            service.inscrire(contact.email, listes, source=Inscription.Source.MANUEL,
                             detail=_("Depuis la fiche CRM, par %(nom)s") % {"nom": request.user.get_username()},
                             prenom=contact.firstname, nom=contact.lastname)
        except service.AdresseBloquee:
            messages.error(request, _("Cette adresse s'est désinscrite de tout (ou ne reçoit plus) : seule la "
                                      "personne peut se réinscrire, depuis le site."))
        else:
            messages.success(request, _("Contact inscrit."))
        return retour


# --- Séquences automatiques ---

class Sequences(_Acces):
    onglet_actif = "sequences"

    def get(self, request, form=None):
        from jeiko.emailing.models import Sequence

        from .forms import SequenceForm

        Liste.par_defaut_du_site()
        return self.rendre("newsletter/admin/sequences.html",
                           sequences=Sequence.objects.select_related("liste").annotate(nb_etapes=Count("etapes")),
                           form=form or SequenceForm())

    def post(self, request):
        from .forms import SequenceForm
        from . import sequences

        self.refuser_si_lecture_seule()
        form = SequenceForm(request.POST)
        if not form.is_valid():
            return self.get(request, form)
        sequence = sequences.creer(form.cleaned_data["nom"], form.cleaned_data["liste"])
        messages.success(request, _("Séquence créée. Ajoutez ses étapes, puis activez-la."))
        return redirect("jeiko_newsletter_admin:sequence", sequence.pk)


class FicheSequence(_Acces):
    onglet_actif = "sequences"

    def get(self, request, pk, etape_form=None, form=None):
        from jeiko.emailing.models import Sequence

        from .forms import EtapeForm, SequenceForm
        from . import sequences

        sequence = get_object_or_404(Sequence.objects.select_related("liste"), pk=pk)
        return self.rendre("newsletter/admin/sequence.html", sequence=sequence,
                           etapes=sequences.statistiques(sequence), problemes=sequences.problemes(sequence),
                           form=form or SequenceForm(instance=sequence), etape_form=etape_form or EtapeForm())

    def post(self, request, pk):
        from jeiko.emailing.models import Sequence

        from .forms import EtapeForm, SequenceForm
        from . import sequences

        self.refuser_si_lecture_seule()
        sequence = get_object_or_404(Sequence, pk=pk)
        action = request.POST.get("action")
        # Activer une séquence, ou changer une séquence active (une étape de
        # plus, une autre liste), fait partir des e-mails : le droit d'envoi (audit NL-01).
        diffuse = action == "activer" or (sequence.active and action not in ("desactiver", "supprimer"))
        if diffuse and not request.user.has_perm(ENVOYER):
            messages.error(request, _("Activer une séquence, ou modifier une séquence active, demande le droit "
                                      "sur les e-mails du site."))
            return redirect("jeiko_newsletter_admin:sequence", pk)
        if action == "ajouter":
            form = EtapeForm(request.POST)
            if not form.is_valid():
                return self.get(request, pk, etape_form=form)
            etape = sequences.ajouter_une_etape(sequence, form.cleaned_data["objet"], request.user,
                                                form.cleaned_data["delai_jours"], form.cleaned_data["modele"])
            return redirect("jeiko_newsletter_admin:fiche", etape.pk)
        if action in ("activer", "desactiver"):
            if action == "activer" and sequences.problemes(sequence):
                messages.error(request, " ".join(sequences.problemes(sequence)))
            else:
                sequences.activer(sequence, action == "activer")
                messages.success(request, _("Séquence activée : chaque nouvel inscrit la recevra.")
                                 if action == "activer" else _("Séquence en pause : plus rien ne part."))
        elif action == "supprimer":
            for etape in sequence.etapes.all():
                page = etape.page
                etape.delete()
                if page is not None:
                    page.delete()
            sequence.delete()
            messages.success(request, _("Séquence supprimée."))
            return redirect("jeiko_newsletter_admin:sequences")
        else:
            liste_avant = sequence.liste_id
            form = SequenceForm(request.POST, instance=sequence)
            if not form.is_valid():
                return self.get(request, pk, form=form)
            if form.cleaned_data["liste"].pk != liste_avant and sequences.a_deja_envoye(sequence):
                # Les liens de désinscription déjà partis visent l'ancienne liste (audit NL-12).
                messages.error(request, _("Cette séquence a déjà écrit à des abonnés : sa liste ne change plus. "
                                          "Créez une nouvelle séquence pour l'autre liste."))
                return redirect("jeiko_newsletter_admin:sequence", pk)
            sequence = form.save()
            # Les étapes suivent : leur lien de désinscription vise la liste de la séquence.
            for etape in sequence.etapes.all():
                etape.listes.set([sequence.liste])
            messages.success(request, _("Séquence enregistrée."))
        return redirect("jeiko_newsletter_admin:sequence", pk)


class InscrireLaSelection(_Acces):
    """Depuis la liste des contacts du CRM : inscrire les contacts cochés à une liste, accord attesté."""

    def post(self, request):
        from jeiko.questionnaires_expert.models import Prospect

        self.refuser_si_lecture_seule()
        suite = request.POST.get("next") or ""
        retour = redirect(suite if suite.startswith("/") and not suite.startswith("//")
                          else reverse("jeiko_crm:liste"))
        liste = Liste.objects.filter(pk=request.POST.get("liste")).first()
        ids = [int(x) for x in (request.POST.get("contact_ids") or "").split(",") if x.strip().isdigit()]
        if liste is None or not ids or not request.POST.get("accord"):
            messages.error(request, _("Choisissez des contacts et une liste, et attestez leur accord."))
            return retour
        detail = _("Depuis la liste du CRM, par %(nom)s") % {"nom": request.user.get_username()}
        inscrits = bloques = sans_adresse = 0
        for contact in Prospect.objects.filter(pk__in=ids):
            if not contact.email:
                sans_adresse += 1
                continue
            try:
                service.inscrire(contact.email, [liste], source=Inscription.Source.MANUEL, detail=detail,
                                 prenom=contact.firstname, nom=contact.lastname)
                inscrits += 1
            except service.AdresseBloquee:
                bloques += 1
        messages.success(request, _("%(inscrits)s contact(s) inscrit(s) à « %(liste)s » ; %(bloques)s écarté(s) car "
                                    "désinscrit(s) de tout ; %(sans)s sans adresse.")
                         % {"inscrits": inscrits, "liste": liste.nom, "bloques": bloques, "sans": sans_adresse})
        return retour
