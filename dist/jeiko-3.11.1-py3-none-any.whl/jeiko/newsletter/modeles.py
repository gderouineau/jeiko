# jeiko/newsletter/modeles.py
"""
NEWS-01 — des points de départ pour une newsletter : une mise en page déjà
posée, des textes à remplacer. Même format que les e-mails du catalogue
(`emailing/seeds.py`), matérialisé par le même constructeur
(`emailing.builder.build_page`) : la page obtenue s'ouvre dans l'éditeur
comme n'importe quelle autre.

En français seulement, comme les e-mails du site (décision de Guillaume).
Ce que ces modèles ne font pas : remplir le contenu à votre place — chaque
texte entre crochets est à réécrire avant l'envoi.
"""
from django.utils.translation import gettext_lazy as _

NOTE = "font-size:13px;color:#888888;"

MODELES = {
    "actualites": {
        "nom": _("Actualités"),
        "lines": [
            {"cols": "12", "blocs": [{"type": "TEXT", "bloc_padding": "24px 24px 8px 24px",
                                      "text": "<h1>Les nouvelles de [%site_nom%]</h1>"
                                              "<p>Bonjour [%prenom%],</p>"
                                              "<p>[Une phrase d'accroche : ce qui s'est passé ce mois-ci.]</p>"}]},
            {"cols": "12", "blocs": [{"type": "TEXT",
                                      "text": "<h2>[Première nouvelle]</h2><p>[Deux ou trois phrases.]</p>"}]},
            {"cols": "12", "blocs": [{"type": "TEXT",
                                      "text": "<h2>[Deuxième nouvelle]</h2><p>[Deux ou trois phrases.]</p>"}]},
            {"cols": "12", "blocs": [{"type": "BUTTON", "align": "center", "bloc_padding": "8px 24px 24px 24px",
                                      "label": "Lire la suite sur le site", "url": "[%site_url%]"}]},
        ],
    },
    "nouveautes": {
        "nom": _("Nouveaux produits"),
        "lines": [
            {"cols": "12", "blocs": [{"type": "TEXT", "bloc_padding": "24px 24px 8px 24px",
                                      "text": "<h1>Du nouveau chez [%site_nom%]</h1>"
                                              "<p>[Ce qui arrive, et pourquoi c'est une bonne nouvelle.]</p>"}]},
            {"cols": "6-6", "blocs": [
                {"type": "TEXT", "text": "<h3>[Produit 1]</h3><p>[Une phrase, le prix.]</p>"},
                {"type": "TEXT", "text": "<h3>[Produit 2]</h3><p>[Une phrase, le prix.]</p>"}]},
            {"cols": "12", "blocs": [{"type": "BUTTON", "align": "center", "bloc_padding": "8px 24px 24px 24px",
                                      "label": "Voir la boutique", "url": "[%site_url%]"}]},
        ],
    },
    "invitation": {
        "nom": _("Invitation à un événement"),
        "lines": [
            {"cols": "12", "blocs": [{"type": "TEXT", "bloc_padding": "24px 24px 8px 24px",
                                      "text": "<h1>[Nom de l'événement]</h1>"
                                              "<p>Bonjour [%prenom%],</p>"
                                              "<p>Nous serions heureux de vous accueillir le <strong>[date]</strong> "
                                              "à <strong>[heure]</strong>, [lieu].</p>"
                                              "<p>[Ce qui vous attend, en deux phrases.]</p>"}]},
            {"cols": "12", "blocs": [{"type": "BUTTON", "align": "center", "bloc_padding": "8px 24px 16px 24px",
                                      "label": "Je m'inscris", "url": "[%site_url%]"}]},
            {"cols": "12", "blocs": [{"type": "TEXT",
                                      "text": f'<p style="{NOTE}">[Places limitées, informations pratiques.]</p>'}]},
        ],
    },
    "lettre_du_mois": {
        "nom": _("Lettre du mois"),
        "lines": [
            {"cols": "12", "blocs": [{"type": "TEXT", "bloc_padding": "24px 24px 8px 24px",
                                      "text": "<h1>La lettre de [mois]</h1>"
                                              "<p>Bonjour [%prenom%],</p>"
                                              "<p>[Un mot d'introduction, personnel.]</p>"}]},
            {"cols": "12", "blocs": [{"type": "TEXT",
                                      "text": "<h2>Ce mois-ci</h2><ul><li>[Un point]</li><li>[Un autre]</li>"
                                              "<li>[Un dernier]</li></ul>"}]},
            {"cols": "12", "blocs": [{"type": "TEXT",
                                      "text": "<h2>Le conseil du mois</h2><p>[Un conseil utile, concret.]</p>"}]},
            {"cols": "12", "blocs": [{"type": "TEXT",
                                      "text": "<p>À très vite,<br>[Votre prénom]</p>"}]},
        ],
    },
}


def choix():
    return [("", _("Vide"))] + [(cle, m["nom"]) for cle, m in MODELES.items()]
