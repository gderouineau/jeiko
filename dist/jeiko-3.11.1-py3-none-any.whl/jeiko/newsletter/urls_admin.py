from django.urls import path

from . import vues_admin as vues

app_name = "jeiko_newsletter_admin"

urlpatterns = [
    path("", vues.Newsletters.as_view(), name="newsletters"),
    path("<int:pk>/", vues.Fiche.as_view(), name="fiche"),
    path("<int:pk>/apercu/", vues.Apercu.as_view(), name="apercu"),
    path("<int:pk>/<str:action>/", vues.Action.as_view(), name="action"),
    path("listes/", vues.Listes.as_view(), name="listes"),
    path("listes/<int:pk>/", vues.ModifierListe.as_view(), name="liste"),
    path("abonnes/", vues.Abonnes.as_view(), name="abonnes"),
    path("abonnes/import/", vues.Importer.as_view(), name="importer"),
    path("abonnes/export.csv", vues.ExporterAbonnes.as_view(), name="exporter"),
    path("abonnes/<int:pk>/desinscrire/", vues.DesinscrireAbonne.as_view(), name="desinscrire"),
    path("reglages/", vues.Reglages.as_view(), name="reglages"),
    path("sequences/", vues.Sequences.as_view(), name="sequences"),
    path("sequences/<int:pk>/", vues.FicheSequence.as_view(), name="sequence"),
    path("contact/<int:pk>/inscrire/", vues.InscrireLeContact.as_view(), name="inscrire_contact"),
    path("contacts/inscrire/", vues.InscrireLaSelection.as_view(), name="inscrire_selection"),
]
