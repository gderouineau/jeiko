from django import forms
from django.utils.translation import gettext_lazy as _

from jeiko.emailing.models import Liste, Newsletter, ReglagesNewsletter

ACCORD = _("Ces personnes ont donné leur accord pour recevoir cette liste par e-mail, et je peux le prouver.")


class NewsletterForm(forms.ModelForm):
    """Les réglages d'une newsletter ; les étiquettes du CRM se saisissent séparées par des virgules."""

    etiquettes = forms.CharField(
        label=_("Seulement les contacts du CRM portant l'une de ces étiquettes"), required=False,
        help_text=_("Séparées par des virgules. Vide : tous les inscrits des listes."))

    class Meta:
        model = Newsletter
        fields = ["objet", "pre_entete", "listes", "statut_crm", "suivi_des_clics", "delai_jours"]
        widgets = {"listes": forms.CheckboxSelectMultiple}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from jeiko.questionnaires_expert.models import Prospect

        self.fields["statut_crm"] = forms.ChoiceField(
            label=_("Seulement les contacts du CRM au statut"), required=False,
            choices=[("", _("Quel que soit le statut"))] + list(Prospect.Statut.choices))
        self.fields["etiquettes"].initial = ", ".join(self.instance.etiquettes_crm or [])
        self.order_fields(["objet", "pre_entete", "delai_jours", "listes", "etiquettes", "statut_crm", "suivi_des_clics"])
        # Une étape de séquence part à chaque inscrit de la liste de sa
        # séquence : ni listes ni ciblage à elle ; un délai, en revanche.
        if self.instance.sequence_id:
            for nom in ("listes", "etiquettes", "statut_crm"):
                self.fields.pop(nom)
        else:
            self.fields.pop("delai_jours")

    def save(self, commit=True):
        if "etiquettes" in self.fields:
            brut = self.cleaned_data.get("etiquettes") or ""
            self.instance.etiquettes_crm = [e.strip() for e in brut.split(",") if e.strip()]
        return super().save(commit)


class ListeForm(forms.ModelForm):
    class Meta:
        model = Liste
        fields = ["nom", "description", "double_opt_in", "proposee_aux_clients"]
        widgets = {"description": forms.Textarea(attrs={"rows": 2})}


class AjoutAbonneForm(forms.Form):
    email = forms.EmailField(label=_("E-mail"))
    prenom = forms.CharField(label=_("Prénom"), max_length=120, required=False)
    nom = forms.CharField(label=_("Nom"), max_length=120, required=False)
    listes = forms.ModelMultipleChoiceField(label=_("Listes"), queryset=Liste.objects.all(),
                                            widget=forms.CheckboxSelectMultiple)
    accord = forms.BooleanField(label=_("Cette personne a donné son accord pour recevoir ces listes par e-mail, "
                                        "et je peux le prouver."))


class ImportForm(forms.Form):
    fichier = forms.FileField(label=_("Fichier CSV"),
                              help_text=_("Une colonne « email » ; « prenom » et « nom » si vous les avez. 2 Mo au plus."))
    liste = forms.ModelChoiceField(label=_("Liste"), queryset=Liste.objects.all(), empty_label=None)
    accord = forms.BooleanField(label=ACCORD)

    def clean_fichier(self):
        fichier = self.cleaned_data["fichier"]
        if fichier.size > 2 * 1024 * 1024:
            raise forms.ValidationError(_("Le fichier dépasse 2 Mo."))
        return fichier


class ReglagesForm(forms.ModelForm):
    class Meta:
        model = ReglagesNewsletter
        fields = ["envois_par_heure", "expediteur", "reponse_a", "texte_consentement",
                  "questionnaire_case_email", "questionnaire_case_telephone",
                  "rebonds_hote", "rebonds_port", "rebonds_utilisateur", "rebonds_mot_de_passe", "rebonds_dossier"]
        widgets = {"texte_consentement": forms.Textarea(attrs={"rows": 3}),
                   # Jamais réaffiché ; vide à l'enregistrement : l'ancien est gardé.
                   "rebonds_mot_de_passe": forms.PasswordInput(render_value=False, attrs={"autocomplete": "new-password"})}

    def clean_rebonds_mot_de_passe(self):
        nouveau = self.cleaned_data.get("rebonds_mot_de_passe")
        if nouveau:
            return nouveau
        # Le mot de passe gardé ne suit jamais un autre serveur ni un autre
        # identifiant : sinon, changer l'hôte suffisait à le faire présenter à
        # un serveur choisi par qui modifie l'écran (audit NL-02).
        from .rebonds import meme_boite

        if not meme_boite(self.instance, self.data.get("rebonds_hote"), self.data.get("rebonds_utilisateur")):
            return ""
        return self.instance.rebonds_mot_de_passe


class SequenceForm(forms.ModelForm):
    class Meta:
        from jeiko.emailing.models import Sequence

        model = Sequence
        fields = ["nom", "liste"]


class EtapeForm(forms.Form):
    objet = forms.CharField(label=_("Objet"), max_length=200)
    delai_jours = forms.IntegerField(label=_("Délai (jours après l'inscription)"), min_value=0, initial=0)
    modele = forms.ChoiceField(label=_("Partir de"), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from .modeles import choix

        self.fields["modele"].choices = choix()
