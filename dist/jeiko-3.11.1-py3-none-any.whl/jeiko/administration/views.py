import os, sys
import re
import subprocess
from datetime import datetime
from pathlib import Path
from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic.base import TemplateView
from django.views.generic.edit import UpdateView
from django.urls import reverse_lazy, reverse, NoReverseMatch

from django.http import HttpResponse, JsonResponse
from django.views.decorators.http import require_GET, require_safe

from django.db import transaction
from django.db.models import Q, F

from django.contrib import messages

from xml.sax.saxutils import escape as xml_escape

from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache, cache_control
from jeiko.administration.website_cache import invalidate_website_data
import json
from datetime import date, timedelta
from jeiko.stats import services
from .models import (
    WebSite,
    Fonts, Logo, Favicon, Font,
    MailSettings, GoogleApi,
    Legals, SiteIdentity,
    SocialProvider,
)
from .forms import (
    FontForm, HoverFontForm, LogoForm, FaviconForm,
    MailSettingsForm, FontFamilyUpdateAllForm,
    GoogleApiForm,
    LegalsAdminForm,
    SiteIdentityForm, SocialLinkFormSet,
    SocialProviderForm,
)

from .utils import get_current_website
from django.utils.translation import gettext_lazy as _


decorators = [never_cache]

from jeiko.administration_pages.models import Page
from jeiko.redirections import destination_sure


class Main(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    template_name = 'administration/main.html'

    # Porte d'entrée de l'espace d'administration.
    permission_required = "users.access_admin"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        # L'accueil n'est plus une pile de liens : il répond d'abord aux deux
        # questions qu'on se pose en arrivant — où en est le site, et qu'est-ce
        # qui n'est pas encore fait. Les réglages viennent après. Voir
        # `administration/dashboard.py`.
        from jeiko.administration.dashboard import key_figures, setup_checklist
        from jeiko.administration.website_cache import get_website_data

        site = get_website_data()
        context = {
            "figures": key_figures(request.user),
            "checklist": setup_checklist(request.user, site),
            "site": site,
        }
        if request.user.has_perm("users.config_edit_site") and site is not None:
            from jeiko.administration.modules import MODULES

            context["modules"] = [
                {"champ": champ, "libelle": libelle, "aide": site._meta.get_field(champ).help_text,
                 "actif": getattr(site, champ)}
                for champ, libelle in MODULES.values()
            ]
        # NOTIF-01 : ce qui attend, avec le lien vers sa liste (jusqu'au produit
        # en stock bas), et les interrupteurs pour qui règle le site.
        from django.urls import NoReverseMatch, reverse as _reverse

        from jeiko.administration import notifications as notif

        nombres = notif.compteurs(request.user)
        allumees = notif.actives(site)
        a_voir = []
        for code, (libelle, _nature, _perm, _module, vue) in notif.NOTIFICATIONS.items():
            if not nombres.get(code):
                continue
            try:
                lien = _reverse(vue)
            except NoReverseMatch:
                continue
            entree = {"code": code, "libelle": libelle, "nombre": nombres[code], "lien": lien}
            if code == "stock_bas":
                entree["produits"] = [
                    {"titre": p.title, "stock": p.stock_quantity,
                     "lien": _reverse("jeiko_administration_shop:product_update", args=[p.type_id, p.pk])}
                    for p in notif.produits_en_stock_bas()[:5]]
            a_voir.append(entree)
        context["notifications"] = a_voir
        if request.user.has_perm("users.config_edit_site"):
            context["reglage_des_notifications"] = [
                {"code": code, "libelle": libelle, "actif": allumees[code]}
                for code, (libelle, *_r) in notif.NOTIFICATIONS.items()]
        # La progression de la mise en route (D-01), tant qu'elle n'est pas
        # finie, pour qui peut la mener.
        if request.user.has_perm("users.config_edit_site"):
            from jeiko.administration.mise_en_route import etat

            mise_en_route = etat(WebSite.objects.first())
            if not mise_en_route["terminee"]:
                context["mise_en_route"] = mise_en_route
        return render(request, self.template_name, context)


class ModulesView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Réglages › Général › Modules (MOD-01) : les cases qui montrent ou masquent
    Boutique, Rendez-vous, Formations et Questionnaires dans le menu de
    l'administration. POST seulement — l'écran est le bloc de Général.
    """

    permission_required = "users.config_edit_site"
    raise_exception = True
    http_method_names = ["post"]

    def post(self, request):
        from django.contrib import messages

        from jeiko.administration.modules import MODULES

        site = WebSite.objects.first()
        if site is not None:
            for _code, (champ, _libelle) in MODULES.items():
                setattr(site, champ, request.POST.get(champ) == "on")
            # save() et non update() : le signal vide le cache du site, que le menu lit.
            site.save(update_fields=[champ for champ, _l in MODULES.values()])
            messages.success(request, _("Modules enregistrés : le menu de l'administration suit."))
        return redirect("jeiko_administration:main")


class NotificationsView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Réglages › Général › Notifications (NOTIF-01) : allumer ou éteindre chaque
    pastille du menu. POST seulement — l'écran est le bloc de Général.
    """

    permission_required = "users.config_edit_site"
    raise_exception = True
    http_method_names = ["post"]

    def post(self, request):
        from django.contrib import messages
        from django.core.cache import cache

        from jeiko.administration.notifications import NOTIFICATIONS

        site = WebSite.objects.first()
        if site is not None:
            site.notifications = {code: request.POST.get(f"notif_{code}") == "on" for code in NOTIFICATIONS}
            # save() et non update() : le signal vide le cache du site, que le menu lit.
            site.save(update_fields=["notifications"])
            cache.delete(f"jeiko:notifications:{request.user.pk}")
            messages.success(request, _("Notifications enregistrées : le menu suit."))
        return redirect("jeiko_administration:main")


class MiseEnRouteView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Réglages ▸ Mise en route (D-01) : où en est le site, étape par étape, et
    l'écran qui règle chacune. POST : écarter ou reprendre une étape
    facultative.
    """

    permission_required = "users.config_edit_site"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request):
        from jeiko.administration.mise_en_route import etat

        return render(request, "administration/mise_en_route.html", {"etat": etat(WebSite.objects.first())})

    def post(self, request):
        from jeiko.administration.mise_en_route import ETAPES

        site = WebSite.objects.first()
        code = request.POST.get("etape", "")
        facultatives = {e.code for e in ETAPES if e.facultative}
        if site is not None and code in facultatives:
            ignorees = [c for c in (site.mise_en_route_ignorees or []) if c in facultatives and c != code]
            if request.POST.get("action") == "ignorer":
                ignorees.append(code)
            site.mise_en_route_ignorees = ignorees
            site.save(update_fields=["mise_en_route_ignorees"])
        return redirect("jeiko_administration:mise_en_route")


class GlobalView(LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    template_name = "administration/global/main.html"

    permission_required = "users.config_edit_site"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        # Paramètre simple: ?days=7 ou ?days=30 (défaut 7)
        days_param = (request.GET.get("days") or "7").strip()
        preset = "1m" if days_param == "30" else "1w"

        # KPIs + bornes via services.summary
        kpis = services.summary(preset=preset)
        start, end = kpis["start"], kpis["end"]

        # Série quotidienne pour le graphe
        series_items = services.daily_series(start, end)
        # sérialisation pour Chart.js (dates ISO)
        series = []
        for row in series_items:
            series.append({
                "day": row["day"].isoformat(),
                "pageviews": row.get("pageviews", 0),
                "visits": row.get("visits", 0),
            })
        series_json = json.dumps(series)

        context = {
            "days": "30" if preset == "1m" else "7",
            "kpis": kpis,
            "series": series_json,
        }
        # Ce qu'un indépendant regarde le matin : les relances dues (CRM).
        if request.user.has_perm("questionnaires_expert.view_prospect"):
            from jeiko.crm.views import contacts_a_relancer
            context["a_relancer"] = contacts_a_relancer().count()
        return render(request, self.template_name, context)



class FontsView(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration/fonts/view.html"

    permission_required = "users.config_edit_fonts"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        web_site = WebSite.objects.all().first()
        form = FontFamilyUpdateAllForm()

        context = {
            "web_site": web_site,
            "form": form,
            "fonts_count": Font.objects.count(),
            "families": Font.objects.values_list("family", flat=True).distinct().order_by("family"),
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        form = FontFamilyUpdateAllForm(request.POST)
        if not form.is_valid():
            web_site = WebSite.objects.all().first()
            context = {
                "web_site": web_site,
                "form": form,
                "fonts_count": Font.objects.count(),
                "families": Font.objects.values_list("family", flat=True).distinct().order_by("family"),
            }
            return render(request, self.template_name, context)

        family = form.cleaned_data["family"]
        updated = Font.objects.update(family=family)
        # .update() en masse ne déclenche pas post_save(Font) : le signal qui
        # incrémente assets_version ne s'exécute pas. On bump donc manuellement
        # la version des assets pour invalider le fragment "site_assets_block".
        WebSite.objects.update(assets_version=F("assets_version") + 1)
        # Ces deux .update() en masse ne déclenchent NI post_save(Font) NI
        # post_save(WebSite) : ni le signal Font (invalidate_website_data via
        # _bump_assets_for_websites_using_fonts) ni le signal WebSite ne partent.
        # Sans cette purge explicite, l'objet WebSite en cache (website_cache.py)
        # garderait l'ancien assets_version et le head servirait des polices périmées.
        invalidate_website_data()
        # .update() en masse ne déclenche aucun signal : on reconstruit donc
        # explicitement les bundles de polices self-hostées (woff2 + CSS local).
        # Synchrone et à erreurs isolées (cf. jeiko.fonts_selfhost).
        from jeiko.fonts_selfhost import rebuild_for_websites
        rebuild_for_websites(WebSite.objects.all())
        messages.success(request, _("Famille « %(family)s » appliquée à %(updated)s police(s).") % {"family": family, "updated": updated})
        return redirect(request.path)


class FontsTitleUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration/fonts/update_title.html"
    font_form = FontForm

    permission_required = "users.config_edit_fonts"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        h1_form = self.font_form(
            instance=fonts.h1,
            prefix='h1_',
        )
        h2_form = self.font_form(
            instance=fonts.h2,
            prefix='h2_',
        )
        h3_form = self.font_form(
            instance=fonts.h3,
            prefix='h3_',
        )
        h4_form = self.font_form(
            instance=fonts.h4,
            prefix='h4_',
        )
        h5_form = self.font_form(
            instance=fonts.h5,
            prefix='h5_',
        )
        h6_form = self.font_form(
            instance=fonts.h6,
            prefix='h6_',
        )

        context = {
            'fonts': fonts,
            'h1_form': h1_form,
            'h2_form': h2_form,
            'h3_form': h3_form,
            'h4_form': h4_form,
            'h5_form': h5_form,
            'h6_form': h6_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        h1_form = self.font_form(
            request.POST,
            instance=fonts.h1,
            prefix='h1_',
        )
        h2_form = self.font_form(
            request.POST,
            instance=fonts.h2,
            prefix='h2_',
        )
        h3_form = self.font_form(
            request.POST,
            instance=fonts.h3,
            prefix='h3_',
        )
        h4_form = self.font_form(
            request.POST,
            instance=fonts.h4,
            prefix='h4_',
        )
        h5_form = self.font_form(
            request.POST,
            instance=fonts.h5,
            prefix='h5_',
        )
        h6_form = self.font_form(
            request.POST,
            instance=fonts.h6,
            prefix='h6_',
        )

        if h1_form.is_valid() \
                and h2_form.is_valid() \
                and h3_form.is_valid() \
                and h4_form.is_valid() \
                and h5_form.is_valid() \
                and h6_form.is_valid:

            h1 = h1_form.save()
            h2 = h2_form.save()
            h3 = h3_form.save()
            h4 = h4_form.save()
            h5 = h5_form.save()
            h6 = h6_form.save()

            fonts.h1 = h1
            fonts.h2 = h2
            fonts.h3 = h3
            fonts.h4 = h4
            fonts.h5 = h5
            fonts.h6 = h6

            fonts.save()

            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'h1_form': h1_form,
            'h2_form': h2_form,
            'h3_form': h3_form,
            'h4_form': h4_form,
            'h5_form': h5_form,
            'h6_form': h6_form,
        }
        return render(request, self.template_name, context)


class FontsTextUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration/fonts/update_text.html"
    text_form = FontForm

    permission_required = "users.config_edit_fonts"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        text_form = self.text_form(
            instance=fonts.text,
            prefix='text_',
        )


        context = {
            'fonts': fonts,
            'text_form': text_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        text_form = self.text_form(
            request.POST,
            instance=fonts.text,
            prefix='text_',
        )



        if text_form.is_valid():


            text = text_form.save()


            fonts.text = text


            fonts.save()

            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'text_form': text_form,

        }
        return render(request, self.template_name, context)


class FontsLinkUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):

    template_name = "administration/fonts/update_link.html"
    form = FontForm

    permission_required = "users.config_edit_fonts"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        link_form = self.form(
            instance=fonts.links,
            prefix='link_',
        )
        link_hover_form = HoverFontForm(
            instance=fonts.links_hover,
            prefix='link_hover_',

        )


        context = {
            'fonts': fonts,
            'link_form': link_form,
            'link_hover_form': link_hover_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(
            Fonts,
            id=kwargs['fonts_id']
        )

        link_form = self.form(
            request.POST,
            instance=fonts.links,
            prefix='link_',
        )
        link_hover_form = HoverFontForm(
            request.POST,
            instance=fonts.links_hover,
            prefix='link_hover_',

        )



        if link_form.is_valid() and link_hover_form.is_valid():


            link = link_form.save()
            link_hover = link_hover_form.save()


            fonts.links = link
            fonts.links_hover = link_hover


            fonts.save()

            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'link_form': link_form,
            'link_hover_form': link_hover_form,

        }
        return render(request, self.template_name, context)


class FontsMenuUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):
    """Édite la police du menu (état normal + survol). Ces polices sont bien
    appliquées en rendu (`.menu a` / `.menu a:hover` dans base_style) mais
    n'avaient jusqu'ici aucun écran d'édition."""

    template_name = "administration/fonts/update_menu.html"
    form = FontForm

    permission_required = "users.config_edit_fonts"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        fonts = get_object_or_404(Fonts, id=kwargs['fonts_id'])

        menu_form = self.form(instance=fonts.menu, prefix='menu_')
        menu_hover_form = HoverFontForm(instance=fonts.menu_hover, prefix='menu_hover_')

        context = {
            'fonts': fonts,
            'menu_form': menu_form,
            'menu_hover_form': menu_hover_form,
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        fonts = get_object_or_404(Fonts, id=kwargs['fonts_id'])

        menu_form = self.form(request.POST, instance=fonts.menu, prefix='menu_')
        menu_hover_form = HoverFontForm(request.POST, instance=fonts.menu_hover, prefix='menu_hover_')

        if menu_form.is_valid() and menu_hover_form.is_valid():
            fonts.menu = menu_form.save()
            fonts.menu_hover = menu_hover_form.save()
            fonts.save()
            return redirect('jeiko_administration:fonts_view')

        context = {
            'fonts': fonts,
            'menu_form': menu_form,
            'menu_hover_form': menu_hover_form,
        }
        return render(request, self.template_name, context)


class LogoUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):

    template_name = 'administration/logo/update.html'
    logo_form = LogoForm

    permission_required = "users.config_edit_site"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        website = WebSite.objects.all().first()

        if not website.logo:
            logo = Logo()
            logo.save()
            website.logo = logo
            website.save()
        else:
            logo = website.logo

        logo_form = self.logo_form(
            instance=logo,
            prefix='logo_'
        )

        context = {
            'logo_form': logo_form,
        }

        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        website = WebSite.objects.all().first()

        logo = website.logo

        logo_form = self.logo_form(
            request.POST,
            request.FILES,
            instance=logo,
            prefix='logo_',
        )

        if logo_form.is_valid():
            logo = logo_form.save(commit=False)
            website.logo = logo
            website.save()
            logo.save()
            return redirect('jeiko_administration:global_view')

        context = {
            'logo_form': logo_form,
        }

        return render(request, self.template_name, context)


class FaviconUpdate(LoginRequiredMixin, PermissionRequiredMixin, View):

    template_name = 'administration/favicon/update.html'
    favicon_form = FaviconForm

    permission_required = "users.config_edit_site"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        website = WebSite.objects.all().first()

        if not website.favicon:
            favicon = Favicon()
            favicon.save()
            website.favicon = favicon
            website.save()
        else:
            favicon = website.favicon

        favicon_form = self.favicon_form(instance=favicon, prefix='favicon_')
        return render(request, self.template_name, {'favicon_form': favicon_form})

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        website = WebSite.objects.all().first()
        favicon = website.favicon or Favicon()

        favicon_form = self.favicon_form(
            request.POST, request.FILES, instance=favicon, prefix='favicon_',
        )

        if favicon_form.is_valid():
            favicon = favicon_form.save()
            if website.favicon_id != favicon.id:
                website.favicon = favicon
                website.save()
            # Le head lit website_data.favicon (objet caché) : on purge pour
            # que la nouvelle favicon apparaisse tout de suite.
            invalidate_website_data()
            return redirect('jeiko_administration:global_view')

        return render(request, self.template_name, {'favicon_form': favicon_form})


class ClearCache(LoginRequiredMixin, PermissionRequiredMixin, View):

    permission_required = "users.config_clear_cache"
    raise_exception = True

    @method_decorator(never_cache)
    def get(self, request, *args, ** kwargs):
        cache.clear()

        # `next` vient d'un lien : la barre rapide y met la page courante.
        # Sans garde, ce lien conduit où l'on veut, depuis votre domaine.
        # Écrit d'un seul tenant à dessein : `tests_transversaux/test_redirections.py` relit les
        # appels à `redirect()` et ne peut pas suivre une variable posée plus
        # haut.
        return redirect(destination_sure(request, request.GET.get('next'), '/'))


def _page_path(page: Page) -> str:
    """Construit le chemin public d'une page.
    Hypothèse: racine = '/', sinon '/<url_tag>/'."""
    return "/" if page.is_root else f"/{page.url_tag.strip('/')}/"



def _canon_path_from_page(page):
    """
    Retourne un chemin canonique normalisé (leading & trailing slash).
    Utilise get_absolute_url() si disponible, sinon tente _page_path(page).
    """
    url = "/"
    if hasattr(page, "get_absolute_url"):
        url = page.get_absolute_url() or "/"
    else:
        try:
            # Compat rétro si _page_path existe dans le projet
            url = _page_path(page) or "/"
        except NameError:
            url = "/"

    if not url.startswith("/"):
        url = "/" + url
    if not url.endswith("/"):
        url = url + "/"
    return url


@require_safe  # GET et HEAD : certains robots ne demandent que les en-têtes.
@cache_control(public=True, max_age=3600)  # 1h
def robots_txt(request):
    """
    Robots.txt : Allow explicite pour les custom objects publiés,
    Disallow pour les zones d'admin et les pages non indexables.

    Les brouillons (custom objects non publiés) n'apparaissent nulle part :
    les lister en Disallow reviendrait à publier leurs URLs.
    Option globale : settings.JEIKO_ROBOTS_DISALLOW_ALL = True -> Disallow: /
    """
    from jeiko.reglages_avances import valeur  # A-81 : réglable à l'écran
    if valeur("masquer_aux_moteurs", False):
        content = "User-agent: *\nDisallow: /\n"
        return HttpResponse(content, content_type="text/plain; charset=utf-8")

    lines = [
        "User-agent: *",
        "Disallow: /admin/",
        "Disallow: /administration/",
        "Disallow: /jeiko/administration/",
        "Disallow: /pass-test/",
        # Écrans de la boutique sans contenu à indexer : panier, tunnel de
        # commande, résultats de recherche (une page par mot tapé).
        "Disallow: /shop/cart/",
        "Disallow: /shop/checkout/",
        "Disallow: /shop/recherche/",
        "Disallow: /shop/facture/",
        "Disallow: /shop/avoir/",
        "Disallow: /shop/envies/",
    ]

    # Les custom objects publiés ne sont volontairement PAS listés en Allow :
    # sans « Disallow: / », tout est déjà crawlable par défaut. Un Allow par
    # fiche serait redondant et ferait grossir robots.txt sans limite — or
    # Google ignore silencieusement le fichier au-delà de 500 Ko, ce qui
    # ferait sauter les Disallow d'admin ci-dessus. Le sitemap porte ces URLs.
    #
    # Les custom objects non publiés ne sont pas listés non plus : un Disallow
    # publierait l'URL de chaque brouillon en clair. Ils sont protégés côté vue
    # (404 hors staff) et par un meta robots noindex.

    # Pages publiées mais non indexables -> Disallow (hors racine).
    # select_related : get_absolute_url consulte category / sub_category, sinon
    # une requête par page bloquée.
    # public_pages() écarte les pages-gabarits : une page mail/pdf/objet en
    # google_index=False figurerait sinon en « Disallow: /mail_… », ce qui
    # publierait son URL en clair dans robots.txt.
    from jeiko.administration_pages.querysets import public_pages
    # Une page dépubliée n'est volontairement pas révélée ici : sa vue répond
    # déjà 404 au public. La citer dans robots.txt publierait précisément
    # l'adresse que l'exploitant vient de retirer du site.
    blocked_pages = public_pages(
        Page.objects
        .filter(active=True, google_index=False)
        .select_related("category", "sub_category", "sub_category__main_category")
    )
    disallow_paths = set()
    for p in blocked_pages:
        path = p.get_absolute_url()
        if path != "/":
            disallow_paths.add(path)

    for path in sorted(disallow_paths):
        lines.append(f"Disallow: {path}")

    # `/llms.txt` — la carte du site à l'usage des modèles de langue.
    #
    # Elle est déjà explorable : sans « Disallow: / », tout l'est par défaut.
    # L'« Allow » explicite ne change donc rien au comportement des robots ;
    # il déclare une intention, et protège d'un « Disallow » ajouté plus tard
    # qui l'attraperait sans qu'on y pense.
    #
    # Le commentaire, lui, sert au lecteur humain : robots.txt est le premier
    # endroit où l'on regarde pour savoir ce qu'un site expose, et il n'existe
    # aucune directive normalisée pour annoncer llms.txt.
    try:
        llms_url = request.build_absolute_uri(reverse("llms_txt"))
        lines.append("Allow: /llms.txt")
        lines.append(f"# llms.txt (carte du site pour les modèles) : {llms_url}")
    except NoReverseMatch:
        pass

    # Sitemap si présent
    try:
        sm_url = request.build_absolute_uri(reverse("sitemap_xml"))
        lines.append(f"Sitemap: {sm_url}")
    except NoReverseMatch:
        pass

    content = "\n".join(lines) + "\n"
    return HttpResponse(content, content_type="text/plain; charset=utf-8")


@require_safe
@cache_control(public=True, max_age=3600)  # 1h
def sitemap_xml(request):
    """
    Sitemap des pages actives & indexables + custom objects publiés.
    Si besoin >50k URLs ou >50Mo, passer à un sitemap index.
    """
    from jeiko.custom_objects.versions import fiches_publiques
    from jeiko.administration_pages.querysets import public_pages

    # public_pages() écarte les pages-gabarits (is_mail_template, is_pdf,
    # is_custom_object_template) : sans lui, les corps d'e-mails éditables
    # (url_tag « mail_… », active=True) fuitaient dans le sitemap et se
    # retrouvaient « explorées, non indexées » dans la Search Console.
    pages = (
        public_pages(
            Page.objects.filter(active=True, google_index=True)
        )
        # `traduction_de` : une version traduite lui demande si elle est l'accueil.
        .select_related("category", "sub_category", "sub_category__main_category", "traduction_de")
        .order_by("id")
    )
    
    # Custom objects publiés — chaque version à son adresse. Cf. robots_txt :
    # on n'indexe pas une fiche dont le produit n'est plus vendable
    # (`fiches_publiques`, qui précharge ce que l'adresse consulte).
    custom_objects = list(fiches_publiques().order_by("id"))

    base = request.build_absolute_uri("/")[:-1]  # https://domaine.tld (sans slash final)

    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        # La présentation pour un humain qui l'ouvre ; les moteurs l'ignorent.
        f'<?xml-stylesheet type="text/xsl" href="{reverse("sitemap_xsl")}"?>',
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"'
        ' xmlns:xhtml="http://www.w3.org/1999/xhtml">'
    ]

    # Site en plusieurs langues : chaque page annonce ses autres versions
    # publiées (hreflang), comme le fait déjà son <head>. Les pages listées
    # ici sont exactement celles qui s'annoncent : publiées et indexables.
    from jeiko.langues_du_site import langue_d_origine

    pages = list(pages)
    versions = {}
    for p in pages:
        versions.setdefault(p.traduction_de_id or p.id, []).append(p)

    # Pages classiques
    for p in pages:
        loc_url = f"{base}{p.get_absolute_url()}"
        loc = xml_escape(loc_url)
        groupe = versions[p.traduction_de_id or p.id]
        alternates = [
            f'    <xhtml:link rel="alternate" hreflang="{v.langue or langue_d_origine()}" '
            f'href="{xml_escape(base + v.get_absolute_url())}"/>'
            for v in sorted(groupe, key=lambda v: v.langue)
        ] if len(groupe) > 1 else []

        # lastmod : updated_at prioritaire si dispo, sinon date_created
        lastmod = None
        if getattr(p, "updated_at", None):
            lastmod = p.updated_at.date().isoformat()
        elif getattr(p, "date_created", None):
            lastmod = p.date_created.date().isoformat()

        lines.append("  <url>")
        lines.append(f"    <loc>{loc}</loc>")
        lines.extend(alternates)
        if lastmod:
            lines.append(f"    <lastmod>{lastmod}</lastmod>")
        # lines.append("    <changefreq>weekly</changefreq>")
        # lines.append("    <priority>0.5</priority>")
        lines.append("  </url>")
    
    # Custom objects publiés. Comme les pages : une fiche publiée en plusieurs
    # langues annonce ses autres versions.
    versions_de_fiche = {}
    for obj in custom_objects:
        versions_de_fiche.setdefault(obj.traduction_de_id or obj.id, []).append(obj)

    for obj in custom_objects:
        loc_url = f"{base}{obj.get_absolute_url()}"
        loc = xml_escape(loc_url)
        groupe = versions_de_fiche[obj.traduction_de_id or obj.id]
        alternates = [
            f'    <xhtml:link rel="alternate" hreflang="{v.langue or langue_d_origine()}" '
            f'href="{xml_escape(base + v.get_absolute_url())}"/>'
            for v in sorted(groupe, key=lambda v: v.langue)
        ] if len(groupe) > 1 else []

        # lastmod : date_updated pour custom objects
        lastmod = None
        if getattr(obj, "date_updated", None):
            lastmod = obj.date_updated.date().isoformat()

        lines.append("  <url>")
        lines.append(f"    <loc>{loc}</loc>")
        lines.extend(alternates)
        if lastmod:
            lines.append(f"    <lastmod>{lastmod}</lastmod>")
        lines.append("  </url>")

    lines.append("</urlset>")
    xml = "\n".join(lines)
    return HttpResponse(xml, content_type="application/xml; charset=utf-8")


@require_safe
@cache_control(public=True, max_age=86400)
def sitemap_xsl(request):
    """
    La feuille de style du sitemap : un tableau lisible pour l'humain qui
    l'ouvre (Chrome n'affiche pas l'arbre XML d'un sitemap qui porte des
    xhtml:link). Traduite dans la langue du lecteur ; jamais indexée.
    """
    from django.template.loader import render_to_string

    reponse = HttpResponse(render_to_string("seo/sitemap_xsl.html", request=request).lstrip(),
                           content_type="text/xsl; charset=utf-8")
    reponse["X-Robots-Tag"] = "noindex"
    return reponse



@method_decorator(never_cache, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class MailSettingsUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = MailSettings
    form_class = MailSettingsForm
    template_name = "administration/mail/settings_form.html"

    permission_required = "users.config_edit_mail"
    raise_exception = True

    def get_object(self, queryset=None):
        # Ici, tu récupères la config liée au site courant (à adapter si multisite)
        website = WebSite.objects.first()  # ou récupère selon l'utilisateur/site courant
        mail_settings, created = MailSettings.objects.get_or_create(pk=getattr(website, "mail_settings_id", None))
        if not website.mail_settings:
            website.mail_settings = mail_settings
            website.save()
        return mail_settings

    def get_success_url(self):
        return reverse_lazy("jeiko_administration:main")  # à adapter à ton url


@method_decorator(never_cache, name='dispatch')
class TestMailSettingsView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Vue pour tester la configuration email actuelle.
    Envoie un email de test en utilisant les paramètres configurés.
    """
    permission_required = "users.config_edit_mail"
    raise_exception = True

    def post(self, request):
        """Envoie un email de test et retourne le résultat en JSON."""
        from jeiko.administration.emailing import send_test_email
        
        try:
            success, message, trace = send_test_email()
            
            if success:
                return JsonResponse({
                    "success": True,
                    "message": message
                })
            else:
                response_data = {
                    "success": False,
                    "error": message
                }
                if trace:
                    response_data["trace"] = trace
                return JsonResponse(response_data, status=500)
                
        except Exception as e:
            import traceback
            return JsonResponse({
                "success": False,
                "error": f"Erreur inattendue: {str(e)}",
                "trace": traceback.format_exc()
            }, status=500)




# ───────────────────────────────────────────────────────────────────────────
# Mise à jour du package JEIKO
#
# L'ancienne implémentation lançait `sudo <script dans site-packages>` en
# subprocess bloquant. Elle ne pouvait pas fonctionner :
#   · sudo n'autorisait pas ce script → demande de mot de passe, sans terminal ;
#   · le script se réinstallait par-dessus lui-même pendant son exécution ;
#   · il redémarrait gunicorn, donc tuait le processus qui l'attendait ;
#   · la requête dépassait de toute façon le proxy_read_timeout de nginx.
#
# Désormais la vue ne fait que DÉCLENCHER une unité systemd. Le travail réel a
# lieu dans /usr/local/sbin/jeiko-client-update (root:root, hors de portée
# de l'application), et l'avancement est lu depuis un fichier d'état.
#
# Ce script client ne met à jour que le package et les gabarits du projet
# (settings.py, urls.py). La configuration serveur — nginx, systemd,
# sudoers — relève de jeiko-server-update, lancé à la main depuis le
# terminal : un clic dans l'administration ne réécrit pas un vhost.
# ───────────────────────────────────────────────────────────────────────────

# Le nom du site devient un nom d'unité systemd passé à sudo : il ne doit
# jamais provenir d'une saisie utilisateur, et il est validé quand même.
_SITE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_]{0,30}$")

# Chemins figés, jamais construits à partir d'une donnée de requête.
JEIKO_CLIENT_UPDATER = "/usr/local/sbin/jeiko-client-update"
JEIKO_SYSTEMCTL = "/usr/bin/systemctl"


def _jeiko_site_name():
    """Nom du site tel que connu de l'installeur (dossier de settings.py)."""
    name = os.getenv("JEIKO_SITE_NAME") or Path(settings.BASE_DIR).name
    if not _SITE_NAME_RE.match(name or ""):
        raise ValueError(f"Nom de site invalide : {name!r}")
    return name


def _jeiko_installed_version():
    try:
        from importlib.metadata import version
        return version("jeiko")
    except Exception:
        return None


def _jeiko_update_state(site):
    """
    Lit l'état écrit par jeiko-client-update.

    Le fichier appartient à root et n'est lisible que par le groupe du site ;
    l'application ne peut donc pas le falsifier pour se déclarer à jour.
    """
    state_path = Path(f"/var/lib/jeiko/{site}/update.state")

    # On lit directement plutôt que de tester l'existence au préalable : sous
    # Python 3.13, Path.exists() ne masque plus PermissionError, et un dossier
    # parent non traversable — /var/lib/jeiko appartenant au groupe d'un autre
    # site — faisait remonter l'erreur jusqu'à une 500. Un état illisible doit
    # dégrader l'affichage, jamais casser la page.
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {"status": "idle", "step": "", "message": ""}
    except PermissionError:
        return {
            "status": "unknown", "step": "",
            "message": (
                f"État illisible : {state_path} n'est pas accessible à ce site. "
                "Sur le serveur : sudo jeiko-server-update <site>."
            ),
        }
    except (OSError, ValueError):
        return {"status": "unknown", "step": "", "message": _("État illisible.")}

    # Un script tué par SIGKILL n'a pas pu écrire son état final : sans ce
    # garde-fou, l'interface tournerait indéfiniment sur « en cours ».
    if state.get("status") == "running":
        try:
            beat = datetime.fromisoformat(state.get("heartbeat", ""))
            age = (datetime.now(beat.tzinfo) - beat).total_seconds()
            if age > 900:
                state["status"] = "stalled"
                state["message"] = (
                    f"Aucun signe de vie depuis {int(age // 60)} minutes. "
                    f"La mise à jour a probablement été interrompue."
                )
        except (TypeError, ValueError):
            pass

    return state


def _jeiko_update_log(site, max_bytes=60_000):
    log_path = Path(f"/var/log/jeiko/{site}/update.log")
    # Pas de test d'existence préalable : cf. _jeiko_update_state, Path.exists()
    # laisse remonter PermissionError depuis Python 3.13.
    try:
        with log_path.open("rb") as fh:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            fh.seek(max(0, size - max_bytes))
            return fh.read().decode("utf-8", errors="replace")
    except FileNotFoundError:
        return ""
    except OSError as exc:
        return f"(journal illisible : {exc})"


class JeikoUpdateAccessMixin:
    """
    Contrôle d'accès aux vues de mise à jour.

    Déclencher une mise à jour applique des migrations, réécrit settings.py et
    redémarre le site. C'est plus lourd que « modifier les réglages du site »,
    avec quoi cette action partageait sa seule permission. Le statut de
    superutilisateur est donc exigé en plus, sauf à passer
    JEIKO_UPDATE_REQUIRES_SUPERUSER à False.
    """

    permission_required = "users.config_edit_site"
    raise_exception = True

    def has_permission(self):
        if not super().has_permission():
            return False
        if getattr(settings, "JEIKO_UPDATE_REQUIRES_SUPERUSER", True):
            return bool(getattr(self.request.user, "is_superuser", False))
        return True


@method_decorator(staff_member_required, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class UpdateJeikoView(JeikoUpdateAccessMixin, LoginRequiredMixin, PermissionRequiredMixin, TemplateView):
    template_name = "administration/update/form.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # AVANT le point de sortie ci-dessous, délibérément.
        #
        # Ce que le cron a relevé ne dépend ni du nom du site ni de la présence
        # de l'updater : c'est une information sur le CANAL de publication.
        # La placer après la sortie anticipée la rendait invisible exactement
        # quand elle sert le plus — un serveur mal configuré est un serveur qui
        # ne se met pas à jour, et il faut au moins savoir qu'une version
        # attend.
        #
        # Les trois champs vivent sur `WebSite`, déjà chargé et mis en cache :
        # les lire ne coûte aucune requête supplémentaire.
        site_web = WebSite.objects.first()
        if site_web is not None:
            # On profite du passage pour effacer un instantané devenu faux :
            # après une mise à jour réussie, le champ annonce encore la version
            # qu'on vient justement d'installer (Q-13).
            site_web.oublier_la_mise_a_jour_appliquee()
            context["version_disponible"] = site_web.mise_a_jour_disponible
            context["derniere_verification"] = site_web.update_last_checked_at
            context["erreur_de_verification"] = site_web.update_check_error or ""

        try:
            site = _jeiko_site_name()
        except ValueError as exc:
            context["configuration_error"] = str(exc)
            return context

        context["site_name"] = site
        context["installed_version"] = _jeiko_installed_version()
        context["state"] = _jeiko_update_state(site)
        context["log"] = _jeiko_update_log(site)
        context["updater_present"] = Path(JEIKO_CLIENT_UPDATER).is_file()
        context["serveur"] = _serveur_avant_le_site(site, site_web)
        return context

    def post(self, request, *args, **kwargs):
        try:
            site = _jeiko_site_name()
        except ValueError as exc:
            messages.error(request, str(exc))
            return redirect("jeiko_administration:update_jeiko")

        if not Path(JEIKO_CLIENT_UPDATER).is_file():
            messages.error(
                request,
                _("Le script de mise à jour n'est pas installé sur ce serveur. "
                "Sur le serveur : sudo ./migrate_site.sh <site> depuis le "
                "dossier INSTALLER, ou sudo jeiko-server-update <site>.")
            )
            return redirect("jeiko_administration:update_jeiko")

        state = _jeiko_update_state(site)
        if state.get("status") == "running":
            messages.warning(request, _("Une mise à jour est déjà en cours."))
            return redirect("jeiko_administration:update_jeiko")

        # Le serveur d'abord. jeiko-client-update le refuserait de toute façon ;
        # refuser ici évite de lancer une mise à jour vouée à l'échec, et dit
        # pourquoi à l'endroit où l'on a cliqué.
        serveur = _serveur_avant_le_site(site, WebSite.objects.first())
        if serveur["bloque"]:
            messages.error(request, _(
                "Le serveur doit être mis à jour avant ce site (installeur %(version)s) : "
                "onglet Serveur."
            ) % {"version": serveur["requise"]})
            return redirect("jeiko_administration:update_jeiko")

        # Cette commande doit correspondre AU CARACTÈRE PRÈS à la règle de
        # /etc/sudoers.d/jeiko-<site> : sudo compare la ligne de commande
        # complète, pas seulement le binaire.
        command = [
            "sudo", "-n", JEIKO_SYSTEMCTL,
            "start", "--no-block", f"jeiko-update@{site}.service",
        ]

        try:
            # 15 s suffisent largement : --no-block rend la main immédiatement.
            # C'est tout l'intérêt du dispositif — la requête HTTP ne porte plus
            # la durée de la mise à jour.
            result = subprocess.run(
                command, capture_output=True, text=True, timeout=15, check=True,
            )
        except FileNotFoundError:
            messages.error(request, _("sudo ou systemctl introuvable sur ce serveur."))
        except subprocess.TimeoutExpired:
            messages.error(request, _("Le déclenchement de la mise à jour n'a pas répondu."))
        except subprocess.CalledProcessError as exc:
            detail = (exc.stderr or exc.stdout or "").strip()
            if "password" in detail.lower() or "mot de passe" in detail.lower():
                detail = (
                    "sudo réclame un mot de passe : la règle sudoers est absente "
                    f"ou ne correspond pas. Vérifie /etc/sudoers.d/jeiko-{site}."
                )
            messages.error(request, _("Impossible de lancer la mise à jour. %(detail)s") % {"detail": detail})
        else:
            messages.success(request, _("Mise à jour lancée. L'avancement s'affiche ci-dessous."))
            del result

        return redirect("jeiko_administration:update_jeiko")


def _serveur_avant_le_site(site, site_web):
    """Où en est le serveur pour ce site, et faut-il bloquer la mise à jour du paquet.

    On ne bloque que sur une machine dont l'outillage connaît jeiko-maj : là,
    le site peut demander la mise à jour du serveur lui-même, et
    jeiko-client-update refuserait de toute façon. Sur un outillage plus
    ancien, le bouton du site fonctionne comme avant.
    """
    from jeiko.administration.mise_a_jour import mecanisme_present, versions_du_serveur

    publie = getattr(site_web, "installeur_disponible", "") if site_web is not None else ""
    serveur = versions_du_serveur(site, publie)
    serveur["mecanisme"] = mecanisme_present()
    serveur["bloque"] = serveur["mecanisme"] and serveur["en_retard"]
    return serveur


@method_decorator(staff_member_required, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class ReglagesDeMiseAJourView(JeikoUpdateAccessMixin, LoginRequiredMixin, PermissionRequiredMixin, View):
    """Mises à jour ▸ Réglages : la mise à jour automatique, le partage des erreurs."""

    template_name = "administration/update/reglages.html"

    def get(self, request):
        site_web = WebSite.objects.first()
        return render(request, self.template_name, {
            "mise_a_jour_auto": bool(site_web and site_web.mise_a_jour_auto),
            "partager_les_erreurs": bool(site_web and site_web.partager_les_erreurs),
            "licence_cle": site_web.licence_cle if site_web else "",
        })

    def post(self, request):
        from jeiko.licences.cles import canonique

        site_web = WebSite.objects.first()
        if site_web is not None:
            # La clé de licence (LIC-01) : vide, ou une forme valide — une clé
            # mal recopiée se dit ici, pas à la prochaine mise à jour.
            brute = request.POST.get("licence_cle", "")
            cle = canonique(brute)
            if brute.strip() and not cle:
                messages.error(request, _("Clé de licence mal formée : 12 à 64 caractères, lettres, chiffres et tirets."))
                return redirect("jeiko_administration:update_jeiko_reglages")
            site_web.mise_a_jour_auto = request.POST.get("mise_a_jour_auto") == "on"
            site_web.partager_les_erreurs = request.POST.get("partager_les_erreurs") == "on"
            site_web.licence_cle = cle
            site_web.save(update_fields=["mise_a_jour_auto", "partager_les_erreurs", "licence_cle"])
            messages.success(request, _("Réglages enregistrés."))
        return redirect("jeiko_administration:update_jeiko_reglages")


@method_decorator(staff_member_required, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class ServeurDeMiseAJourView(JeikoUpdateAccessMixin, LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Mises à jour ▸ Serveur : où en est l'outillage de la machine, et la
    demande de mise à jour du serveur (jeiko-maj, voir mise_a_jour.py).

    La demande concerne TOUS les sites de la machine : l'écran le dit. Elle ne
    fait rien si le serveur est à jour — jeiko-maj le vérifie lui-même.
    """

    template_name = "administration/update/serveur.html"

    def get(self, request):
        from jeiko.administration.mise_a_jour import etat_serveur

        site_web = WebSite.objects.first()
        contexte = {}
        try:
            site = _jeiko_site_name()
        except ValueError as exc:
            contexte["configuration_error"] = str(exc)
            return render(request, self.template_name, contexte)
        contexte["site_name"] = site
        contexte["serveur"] = _serveur_avant_le_site(site, site_web)
        contexte["etat"] = etat_serveur()
        return render(request, self.template_name, contexte)

    def post(self, request):
        from jeiko.administration.mise_a_jour import (
            demander_la_mise_a_jour_du_serveur, derniere_passe_recente, etat_serveur,
            mecanisme_present,
        )

        try:
            site = _jeiko_site_name()
        except ValueError as exc:
            messages.error(request, str(exc))
            return redirect("jeiko_administration:update_jeiko_serveur")
        if not mecanisme_present():
            messages.error(request, _(
                "La mise à jour du serveur depuis l'administration n'est pas encore installée "
                "sur cette machine (outillage antérieur)."
            ))
            return redirect("jeiko_administration:update_jeiko_serveur")
        if etat_serveur().get("statut") == "en_cours":
            messages.warning(request, _("Une mise à jour du serveur est déjà en cours."))
            return redirect("jeiko_administration:update_jeiko_serveur")
        if derniere_passe_recente():
            messages.warning(request, _(
                "Une mise à jour du serveur vient de se terminer : réessayez dans quelques minutes."
            ))
            return redirect("jeiko_administration:update_jeiko_serveur")

        reussi, message = demander_la_mise_a_jour_du_serveur(site)
        (messages.success if reussi else messages.error)(request, message)
        return redirect("jeiko_administration:update_jeiko_serveur")


@method_decorator(staff_member_required, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class EtatDuServeurView(JeikoUpdateAccessMixin, LoginRequiredMixin, PermissionRequiredMixin, View):
    """Interrogé en boucle par l'onglet Serveur pendant une mise à jour."""

    def get(self, request):
        from jeiko.administration.mise_a_jour import etat_serveur

        etat = etat_serveur()
        return JsonResponse({
            "statut": etat.get("statut", ""),
            "etape": etat.get("etape", ""),
            "message": etat.get("message", ""),
            "maj": etat.get("maj", ""),
        })


@method_decorator(staff_member_required, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class UpdateJeikoStatusView(JeikoUpdateAccessMixin, LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Point d'entrée interrogé en boucle par la page de mise à jour.

    Rend possible l'affichage du journal en direct sans maintenir une requête
    HTTP ouverte pendant toute la durée de l'opération. Le journal révèle des
    chemins et des versions : il suit donc le même contrôle d'accès que le
    déclenchement.
    """

    def get(self, request, *args, **kwargs):
        try:
            site = _jeiko_site_name()
        except ValueError as exc:
            return JsonResponse({"status": "error", "message": str(exc)}, status=400)

        state = _jeiko_update_state(site)
        return JsonResponse({
            "status": state.get("status", "idle"),
            "step": state.get("step", ""),
            "message": state.get("message", ""),
            "version_before": state.get("version_before", ""),
            "version_after": state.get("version_after", ""),
            "installed_version": _jeiko_installed_version(),
            "log": _jeiko_update_log(site),
        })


@method_decorator(staff_member_required, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class GoogleApiConfigView(LoginRequiredMixin, PermissionRequiredMixin, View):
    template_name = "administration/google_api/config.html"
    permission_required = "users.config_edit_site"
    raise_exception = True

    def get(self, request):
        obj = GoogleApi.get_solo()
        form = GoogleApiForm(instance=obj)
        return render(request, self.template_name, {"form": form})

    def post(self, request):
        obj = GoogleApi.get_solo()
        form = GoogleApiForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            return redirect("jeiko_administration:google_api_config")
        return render(request, self.template_name, {"form": form})


class SocialLoginConfigView(LoginRequiredMixin, PermissionRequiredMixin, View):
    """
    Configuration des connexions sociales (Google, Apple, Facebook) :
    saisie des clés + activation/désactivation, depuis le back-office.
    Un seul écran, un formulaire par fournisseur.
    """
    template_name = "administration/social_login/config.html"
    permission_required = "users.config_edit_site"
    raise_exception = True

    def _build_forms(self, data=None):
        forms = []
        for provider in SocialProvider.all_providers():
            prefix = provider.provider
            forms.append(
                SocialProviderForm(data, instance=provider, prefix=prefix)
            )
        return forms

    def get(self, request):
        return render(request, self.template_name, {"provider_forms": self._build_forms()})

    def post(self, request):
        forms = self._build_forms(request.POST)
        if all(f.is_valid() for f in forms):
            for f in forms:
                f.save()  # SocialProvider.save() resynchronise allauth
            messages.success(request, _("Connexions sociales mises à jour."))
            return redirect("jeiko_administration:social_login_config")
        messages.error(request, _("Corrige les erreurs ci-dessous."))
        return render(request, self.template_name, {"provider_forms": forms})



# D-08 (09/10/2026) : pages légales et identité suivent le système de rôles,
# comme les autres réglages du site, au lieu du seul drapeau `is_staff`.
GARDE_CONFIGURATION = [login_required, permission_required("users.config_edit_site", raise_exception=True)]

@method_decorator(GARDE_CONFIGURATION, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class LegalsOverviewView(View):
    """
    Affiche les 4 pages légales (liens Voir / Éditer).
    Pas de formulaire de choix : les pages sont protégées et créées par migration.
    """

    template_name = 'administration/legals/main.html'

    def _get_site(self):
        return WebSite.objects.first()

    def _get_legals(self, site):
        legals, __ = Legals.objects.get_or_create(site=site)
        return legals

    def _ensure_links(self, legals):
        """
        Si les FK du modèle Legals ne sont pas encore renseignées,
        on les pointe automatiquement vers les pages créées par migration.
        """
        updated_fields = []

        def _get(url_tag):
            # La page d'ORIGINE : la version traduite d'une page légale porte
            # le même nom d'adresse, et ce n'est pas elle que les réglages
            # désignent (le lien suit ensuite la langue du lecteur).
            return Page.objects.filter(
                url_tag__iexact=url_tag, traduction_de__isnull=True
            ).first()

        mapping = {
            'mentions_page': _get('mentionslegales'),
            'cgu_page': _get('cgu'),
            'cgv_page': _get('cgv'),
            'privacy_page': _get('privacy'),
        }

        for attr, page in mapping.items():
            if getattr(legals, attr) is None and page is not None:
                setattr(legals, attr, page)
                updated_fields.append(attr)

        if updated_fields:
            legals.save(update_fields=updated_fields)

        return legals

    def get(self, request):
        site = self._get_site()
        legals = self._ensure_links(self._get_legals(site))

        context = {
            'legals': legals,
            # pratique si tu préfères accéder directement à ces variables dans le template
            'mentions_page': legals.mentions_page,
            'cgu_page': legals.cgu_page,
            'cgv_page': legals.cgv_page,
            'privacy_page': legals.privacy_page,
            # paires (libellé, page) pour un rendu en tableau
            'legal_items': [
                (_("Mentions légales"), legals.mentions_page),
                ("CGU", legals.cgu_page),
                ("CGV", legals.cgv_page),
                ("RGPD / Privacy", legals.privacy_page),
            ],
        }
        return render(request, self.template_name, context)

    def post(self, request):
        # Pas d’édition ici. On revient simplement sur la page.
        return redirect(request.path)

@method_decorator(GARDE_CONFIGURATION, name='dispatch')
@method_decorator(never_cache, name='dispatch')
class SiteIdentityView(View):
    template_name = "administration/identity/form.html"

    def _website(self, request):
        # Une installation neuve doit pouvoir ouvrir son premier écran de
        # réglages sans passer par une initialisation cachée ailleurs.
        return get_current_website(request) or WebSite.objects.create()

    def _context(self, website, identity, form, social_formset):
        return {
            "form": form,
            "identity": identity,
            "website": website,
            "social_formset": social_formset,
        }

    def get(self, request):
        website = self._website(request)
        identity, __ = SiteIdentity.objects.get_or_create(
            website=website,
            defaults={"type": SiteIdentity.TYPE_ORG, "name": (getattr(website, "name", "") or "")},
        )
        form = SiteIdentityForm(instance=identity)
        social_formset = SocialLinkFormSet(instance=website, prefix="social")
        return render(
            request,
            self.template_name,
            self._context(website, identity, form, social_formset),
        )

    def post(self, request):
        website = self._website(request)
        identity, __ = SiteIdentity.objects.get_or_create(
            website=website,
            defaults={"type": SiteIdentity.TYPE_ORG, "name": (getattr(website, "name", "") or "")},
        )
        form = SiteIdentityForm(request.POST, instance=identity)
        social_formset = SocialLinkFormSet(
            request.POST,
            request.FILES,
            instance=website,
            prefix="social",
        )
        if form.is_valid() and social_formset.is_valid():
            with transaction.atomic():
                obj = form.save(commit=False)
                obj.website = website
                obj.save()
                social_formset.save()
            messages.success(request, _("Identité et réseaux sociaux enregistrés."))
            if request.headers.get("X-Requested-With") == "fetch":
                return JsonResponse({"ok": True})
            return redirect("jeiko_administration:site_identity")
        if request.headers.get("X-Requested-With") == "fetch":
            return JsonResponse({
                "ok": False,
                "errors": {
                    "identity": form.errors,
                    "social_links": social_formset.errors,
                    "social_links_global": social_formset.non_form_errors(),
                },
            }, status=400)
        return render(
            request,
            self.template_name,
            self._context(website, identity, form, social_formset),
        )
