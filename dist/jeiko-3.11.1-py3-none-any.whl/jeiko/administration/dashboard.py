"""
Contenu du tableau de bord d'administration.

Ce que ce module remplace
-------------------------
L'écran d'accueil de l'administration était une pile de dix cartes contenant
un lien chacune, du logo jusqu'à « Mettre à jour JEIKO » — réglages d'identité,
configuration technique et maintenance système mélangés, sans icône, sans
description, et surtout **sans aucun état**. Le favicon pouvait manquer : il
fallait remarquer que le lien disait « Ajouter » plutôt que « Modifier » pour
le déduire.

Deux fonctions ici, correspondant aux deux questions qu'on se pose en arrivant :

- `key_figures()` — « où en est le site ? »
- `setup_checklist()` — « qu'est-ce qui n'est pas encore fait ? »

Toutes deux sont tolérantes : une application absente ou une table vide ne
doit pas empêcher l'accueil de s'afficher. Un tableau de bord qui tombe en
panne est pire qu'un tableau de bord incomplet.
"""

import logging

from django.urls import NoReverseMatch, reverse
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

logger = logging.getLogger(__name__)


def _safe(fn, default=None):
    """Exécute `fn`, renvoie `default` si quoi que ce soit échoue."""
    try:
        return fn()
    except Exception:
        logger.debug(_("Tableau de bord : indicateur indisponible."), exc_info=True)
        return default


def _url(name, *args):
    try:
        return reverse(name, args=args)
    except NoReverseMatch:
        return None


def key_figures(user):
    """Quelques chiffres, filtrés par ce que l'utilisateur a le droit de voir.

    On n'affiche un indicateur que si son écran est accessible : proposer un
    chiffre qu'on ne peut pas aller consulter est une impasse.
    """
    figures = []

    if user.has_perm("administration_pages.view_page"):
        from jeiko.administration_pages.models import Page
        total = _safe(lambda: Page.objects.count(), 0)
        online = _safe(lambda: Page.objects.filter(active=True).count(), 0)
        figures.append({
            "label": _("Pages"),
            "value": online,
            "hint": f"en ligne sur {total}" if total else "aucune page",
            "url": _url("jeiko_administration_pages:main"),
            "warn": total > 0 and online == 0,
        })

    if user.has_perm("calendars.view_appointment"):
        from jeiko.calendars.models import Appointment
        upcoming = _safe(
            lambda: Appointment.objects.firm().filter(start__gte=timezone.now()).count(), 0
        )
        figures.append({
            "label": _("Rendez-vous à venir"),
            "value": upcoming,
            "hint": _("confirmés"),
            "url": _url("jeiko_administration_calendars:appointment_list_upcoming"),
        })

    if user.has_perm("shop.view_order"):
        from jeiko.shop.models import Order
        month_start = timezone.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        count = _safe(lambda: Order.objects.filter(created_at__gte=month_start).count(), 0)
        figures.append({
            "label": _("Commandes"),
            "value": count,
            "hint": _("ce mois-ci"),
            "url": _url("jeiko_shop_admin_orders:order_list"),
        })

    if user.has_perm("courses.view_course"):
        from jeiko.courses.models import Course
        count = _safe(lambda: Course.objects.filter(is_active=True).count(), 0)
        figures.append({
            "label": _("Formations"),
            "value": count,
            "hint": "actives",
            "url": _url("jeiko_courses:jeiko_courses_admin:course_list"),
        })

    return [f for f in figures if f.get("url")]


def setup_checklist(user, site):
    """Ce qui reste à configurer, formulé comme une action à faire.

    Chaque entrée porte le geste attendu, pas le nom du réglage : « Ajoutez un
    favicon » plutôt que « Favicon ». On ne liste que ce qui MANQUE — une liste
    qui se vide à mesure qu'on avance vaut mieux qu'une liste de cases cochées
    qu'il faut relire à chaque fois.
    """
    items = []

    def add(label, hint, url_name, *args, level="todo"):
        url = _url(url_name, *args)
        if url:
            items.append({"label": label, "hint": hint, "url": url, "level": level, "code": url_name})

    if site is None:
        return items

    # --- Mise à jour disponible : en premier, c'est daté et ça se périme.
    if getattr(site, "mise_a_jour_disponible", "") and user.has_perm("users.config_edit_site"):
        add(
            _("Mettre à jour JEIKO (%(version)s)") % {"version": site.mise_a_jour_disponible},
            _("Une version plus récente est publiée."),
            "jeiko_administration:update_jeiko",
            level="update",
        )

    # --- Identité visuelle.
    if user.has_perm("users.config_edit_site"):
        if not _safe(lambda: bool(site.logo and site.logo.full_size)):
            add(_("Ajouter votre logo"), _("Il apparaît dans l'en-tête et dans vos e-mails."),
                "jeiko_administration:logo_update")
        if not _safe(lambda: bool(site.favicon and site.favicon.png_32)):
            add(_("Ajouter un favicon"), _("La petite icône de l'onglet du navigateur."),
                "jeiko_administration:favicon_update")

    # --- Identité déclarée : elle sert au référencement ET à l'adresse
    #     publique utilisée par la mesure de performance.
    identity = getattr(site, "identity", None)
    if user.is_staff and not (identity and (identity.name or "").strip()):
        add(_("Renseigner l'identité du site"),
            _("Nom, adresse et coordonnées : utilisés par Google et les réseaux sociaux."),
            "jeiko_administration:site_identity")

    # --- Envoi d'e-mails.
    if user.has_perm("users.config_edit_mail"):
        from jeiko.administration.models import MailSettings
        mail = _safe(lambda: MailSettings.objects.first())
        if not (mail and (mail.host or "").strip()):
            add(_("Configurer le serveur d'e-mails"),
                "Sans lui, aucune confirmation ni relance ne part.",
                "jeiko_administration:mail_settings_edit", level="warn")

    # --- Contenu : un site sans page publiée n'existe pas.
    if user.has_perm("administration_pages.view_page"):
        from jeiko.administration_pages.models import Page
        if not _safe(lambda: Page.objects.filter(active=True).exists(), True):
            add(_("Publier une première page"),
                _("Aucune page n'est visible des visiteurs pour l'instant."),
                "jeiko_administration_pages:main", level="warn")

    # --- Pages d'erreur (A-10) : la 404 est celle qu'un visiteur rencontre ;
    #     tant qu'elle n'est pas choisie, il lit le message de JEIKO.
    if user.has_perm("administration_pages.change_page") and not getattr(site, "page_404_id", None):
        add(_("Choisir vos pages d'erreur"),
            _("Page introuvable, accès refusé, erreur du serveur : sans elles, le visiteur lit le message par défaut de JEIKO."),
            "jeiko_administration_pages:pages_erreur")

    # --- Encaissement : seulement si une boutique existe vraiment. Réclamer
    #     une passerelle à un site sans produit serait du bruit.
    if user.has_perm("payments.view_paymentgateway"):
        from jeiko.payments.models import PaymentGateway
        from jeiko.shop.models import Product
        has_products = _safe(lambda: Product.objects.exists(), False)
        has_gateway = _safe(lambda: PaymentGateway.objects.filter(is_active=True).exists(), True)
        if has_products and not has_gateway:
            add(_("Activer un moyen de paiement"),
                _("Des produits existent, mais aucune passerelle ne peut encaisser."),
                "jeiko_payments_admin:gateway_list", level="warn")
        # STRIPE-01 : active ne veut pas dire branchée. Sans avis de Stripe
        # reçu (ou avec une signature refusée en dernier), les paiements
        # passent chez Stripe et les commandes restent « en attente ».
        stripe = _safe(lambda: PaymentGateway.objects.filter(code="stripe", is_active=True).first(), None)
        if stripe and (not stripe.dernier_evenement_le or (
                stripe.dernier_refus_le and stripe.dernier_refus_le > stripe.dernier_evenement_le)):
            add(_("Vérifier le webhook Stripe"),
                _("Le site n'a encore reçu aucun avis valide de Stripe : les commandes payées resteraient « en attente »."),
                "jeiko_payments_admin:gateway_update", stripe.pk, level="warn")

    return items
