"""Tests du module `courses`."""
