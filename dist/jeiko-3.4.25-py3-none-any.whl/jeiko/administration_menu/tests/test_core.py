"""Règles métier et droits des menus, au-delà de leur rendu HTML."""

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.test import TestCase
from django.urls import reverse

from jeiko.administration_menu.models import Menu, MenuItem, MenuLayout, MenuPlace


class MenuModelTests(TestCase):
    def test_un_menu_principal_exige_une_disposition(self):
        menu = Menu(name="Principal", place=MenuPlace.MAIN, layout=None)
        with self.assertRaises(ValidationError):
            menu.full_clean()

    def test_un_menu_de_pied_refuse_une_disposition_principale(self):
        menu = Menu(
            name="Pied", place=MenuPlace.FOOTER,
            layout=MenuLayout.LOGO_LEFT_MENU_RIGHT,
        )
        with self.assertRaises(ValidationError):
            menu.full_clean()

    def test_les_positions_s_attribuent_et_se_deplacent_sans_collision(self):
        menu = Menu.objects.create(
            name="Principal", place=MenuPlace.MAIN,
            layout=MenuLayout.LOGO_LEFT_MENU_RIGHT,
        )
        premier = MenuItem.objects.create(menu=menu, title="Premier")
        second = MenuItem.objects.create(menu=menu, title="Second")
        self.assertEqual((premier.position, second.position), (0, 1))

        cache.set(f"menu:render:{menu.pk}", "ancien rendu", 60)
        self.assertTrue(second.move_up())
        premier.refresh_from_db()
        second.refresh_from_db()
        self.assertEqual((second.position, premier.position), (0, 1))
        self.assertIsNone(cache.get(f"menu:render:{menu.pk}"))

    def test_un_sous_menu_ne_peut_pas_pointer_vers_un_autre_menu(self):
        menu_a = Menu.objects.create(
            name="A", place=MenuPlace.MAIN,
            layout=MenuLayout.LOGO_LEFT_MENU_RIGHT,
        )
        menu_b = Menu.objects.create(
            name="B", place=MenuPlace.MAIN,
            layout=MenuLayout.LOGO_CENTER_BELOW,
        )
        parent = MenuItem.objects.create(menu=menu_a, title="Parent")
        enfant = MenuItem(menu=menu_b, main_menu=parent, title="Enfant")
        with self.assertRaises(ValidationError):
            enfant.full_clean()


class MenuPermissionsTests(TestCase):
    def test_la_liste_refuse_un_compte_sans_droit(self):
        user = get_user_model().objects.create_user("sans-droit", password="secret")
        self.client.force_login(user)
        self.assertEqual(
            self.client.get(reverse("jeiko_administration_menu:menu_list")).status_code,
            403,
        )

    def test_la_liste_est_accessible_a_un_superutilisateur(self):
        user = get_user_model().objects.create_superuser(
            "admin-menu", "admin-menu@example.test", "secret"
        )
        self.client.force_login(user)
        self.assertEqual(
            self.client.get(reverse("jeiko_administration_menu:menu_list")).status_code,
            200,
        )
