"""Tests du module de menus d'administration."""
