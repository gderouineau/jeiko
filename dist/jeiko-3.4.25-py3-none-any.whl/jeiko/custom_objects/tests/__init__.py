"""Tests organisés du module custom_objects.

La fixture reste exportée au niveau du paquet pour conserver l'import public
utilisé par les tests des modules ``shop`` et ``emailing``.
"""

from .test_core import CustomObjectFixture

__all__ = ["CustomObjectFixture"]
