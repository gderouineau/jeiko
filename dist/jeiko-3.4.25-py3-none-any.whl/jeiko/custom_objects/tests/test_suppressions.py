"""La suppression d'une fiche explique les dépendances au lieu de faire 500."""

from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from jeiko.administration_pages.models import Page
from jeiko.custom_objects.models import CustomObject, CustomObjectModel
from jeiko.shop.models import Product, ProductType


class SuppressionObjetTests(TestCase):
    def setUp(self):
        self.admin = get_user_model().objects.create_superuser(
            "admin-objet", "admin-objet@example.test", "mot-de-passe"
        )
        self.client.force_login(self.admin)
        page = Page.objects.create(
            title="Gabarit", url_tag="gabarit-suppression", is_custom_object_template=True
        )
        self.modele = CustomObjectModel.objects.create(
            name="Réalisation", slug="realisation-suppression", page_template=page
        )

    def test_objet_libre_est_supprime(self):
        objet = CustomObject.objects.create(
            model=self.modele, title="Libre", slug="libre"
        )
        reponse = self.client.post(reverse(
            "jeiko_administration_custom_objects:object_delete",
            kwargs={"model_pk": self.modele.pk, "pk": objet.pk},
        ))
        self.assertEqual(reponse.status_code, 302)
        self.assertFalse(CustomObject.objects.filter(pk=objet.pk).exists())

    def test_objet_portant_un_produit_est_refuse_avec_une_redirection(self):
        modele_produit = CustomObjectModel.objects.create(
            name="Produit", slug="produit-suppression", page_template=self.modele.page_template,
            is_product=True,
        )
        objet = CustomObject.objects.create(
            model=modele_produit, title="Produit", slug="produit"
        )
        type_produit = ProductType.objects.create(
            name="Service", code="service-suppression", content_model=modele_produit,
        )
        Product.objects.create(
            type=type_produit, content=objet, sku="sku-suppression",
            price_ht=Decimal("10.00"), tax_rate=Decimal("20.00"),
        )
        reponse = self.client.post(reverse(
            "jeiko_administration_custom_objects:object_delete",
            kwargs={"model_pk": modele_produit.pk, "pk": objet.pk},
        ))
        self.assertEqual(reponse.status_code, 302)
        self.assertTrue(CustomObject.objects.filter(pk=objet.pk).exists())
