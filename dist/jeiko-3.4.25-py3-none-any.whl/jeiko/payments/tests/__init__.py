"""Tests du module `payments`."""
