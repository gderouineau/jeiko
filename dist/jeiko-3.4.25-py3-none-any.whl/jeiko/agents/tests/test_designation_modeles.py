"""Un slug numérique ne doit pas détourner silencieusement une fiche."""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Page
from jeiko.custom_objects.models import CustomObject, CustomObjectModel
from jeiko.shop.models import ProductType

from .test_core import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class DesignationModelesTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(self.agent.user, "view_customobject", "add_customobject",
                       app="custom_objects", nom="Fiches numériques")
        donner_le_role(self.agent.user, "view_producttype", "add_producttype",
                       "change_producttype", app="shop", nom="Types numériques")
        page = Page.objects.create(title="Gabarit", url_tag="designation-modeles",
                                   is_custom_object_template=True)
        self.par_id = CustomObjectModel.objects.create(name="Modèle par ID", slug="principal",
                                                       page_template=page)
        self.par_slug = CustomObjectModel.objects.create(name="Modèle par slug",
                                                         slug=str(self.par_id.pk),
                                                         page_template=page)
        self.texte_ambigu = str(self.par_id.pk)

    def verifier_refus(self, reponse):
        self.assertEqual(reponse.status_code, 400, reponse.content)
        self.assertTrue(reponse["Content-Type"].startswith("application/json"))
        message = reponse.json()["erreur"]
        self.assertIn("ambigu", message.lower())
        self.assertIn(self.par_id.name, message)
        self.assertIn(self.par_slug.name, message)
        self.assertIn(f"id:{self.par_id.pk}", message)
        self.assertIn(f"slug:{self.par_slug.slug}", message)

    def test_filtres_objets_et_fiches_refusent_la_collision(self):
        for route in ("objets", "fiches"):
            with self.subTest(route=route):
                self.verifier_refus(self.client.get(
                    f"/api/agent/v1/{route}/", {"modele": self.texte_ambigu},
                    **self.entetes(self.jeton),
                ))

    def test_creation_fiche_refuse_la_collision_sans_ecrire(self):
        for designation in (self.texte_ambigu, self.par_id.pk):
            with self.subTest(designation=designation):
                self.verifier_refus(self.json_post("/api/agent/v1/objets/creer/",
                    {"modele": designation, "titre": "Ne pas créer"}, self.jeton))
        self.assertFalse(CustomObject.objects.filter(title="Ne pas créer").exists())

    def test_creation_type_refuse_la_collision_sans_ecrire(self):
        self.verifier_refus(self.json_post("/api/agent/v1/types-de-produit/creer/",
            {"nom": "Type refusé", "code": "type_refuse", "modele": self.texte_ambigu}, self.jeton))
        self.assertFalse(ProductType.objects.filter(code="type_refuse").exists())

    def test_patch_type_refuse_la_collision_et_preserve_tous_les_champs(self):
        produit = ProductType.objects.create(name="Nom initial", code="initial",
                                             content_model=self.par_slug)
        reponse = self.client.patch(f"/api/agent/v1/types-de-produit/{produit.pk}/",
            data=json.dumps({"nom": "Nom refusé", "modele": self.texte_ambigu}),
            content_type="application/json", **self.entetes(self.jeton))
        self.verifier_refus(reponse)
        produit.refresh_from_db()
        self.assertEqual(produit.name, "Nom initial")
        self.assertEqual(produit.content_model_id, self.par_slug.pk)

    def test_references_explicites_choisissent_chaque_modele(self):
        for modele, reference in ((self.par_id, f"id:{self.par_id.pk}"),
                                   (self.par_slug, f"slug:{self.par_slug.slug}")):
            with self.subTest(reference=reference):
                creation = self.json_post("/api/agent/v1/objets/creer/",
                    {"modele": reference, "titre": modele.name}, self.jeton)
                self.assertEqual(creation.status_code, 201, creation.content)
                objet = CustomObject.objects.get(pk=creation.json()["objet"]["id"])
                self.assertEqual(objet.model_id, modele.pk)
                lecture = self.client.get("/api/agent/v1/objets/", {"modele": reference},
                                           **self.entetes(self.jeton))
                self.assertEqual(lecture.status_code, 200, lecture.content)
                self.assertEqual([o["id"] for o in lecture.json()["objets"]], [objet.pk])

    def test_id_et_slug_identiques_du_meme_modele_ne_sont_pas_ambigus(self):
        self.par_slug.slug = str(self.par_slug.pk)
        self.par_slug.save(update_fields=["slug"])
        reponse = self.json_post("/api/agent/v1/objets/creer/",
            {"modele": self.par_slug.pk, "titre": "Même modèle"}, self.jeton)
        self.assertEqual(reponse.status_code, 201, reponse.content)

    def test_slug_et_id_non_ambigus_restent_acceptes(self):
        for reference in ("principal", str(self.par_slug.pk)):
            with self.subTest(reference=reference):
                reponse = self.client.get("/api/agent/v1/objets/", {"modele": reference},
                                           **self.entetes(self.jeton))
                self.assertEqual(reponse.status_code, 200, reponse.content)

    def test_references_invalides_repondent_json_sans_500(self):
        for reference in ("id:abc", "id:-1", "id:", "slug:", "²", "9" * 100):
            with self.subTest(reference=reference):
                reponse = self.client.get("/api/agent/v1/objets/", {"modele": reference},
                                           **self.entetes(self.jeton))
                self.assertEqual(reponse.status_code, 400, reponse.content)
                self.assertTrue(reponse["Content-Type"].startswith("application/json"))

    def test_type_produit_accepte_les_references_explicites_en_creation_et_patch(self):
        creation = self.json_post("/api/agent/v1/types-de-produit/creer/",
            {"nom": "Type explicite", "code": "explicite", "modele": f"id:{self.par_id.pk}"},
            self.jeton)
        self.assertEqual(creation.status_code, 201, creation.content)
        produit = ProductType.objects.get(pk=creation.json()["type"]["id"])
        self.assertEqual(produit.content_model_id, self.par_id.pk)
        reponse = self.client.patch(f"/api/agent/v1/types-de-produit/{produit.pk}/",
            data=json.dumps({"modele": f"slug:{self.par_slug.slug}"}),
            content_type="application/json", **self.entetes(self.jeton))
        self.assertEqual(reponse.status_code, 200, reponse.content)
        produit.refresh_from_db()
        self.assertEqual(produit.content_model_id, self.par_slug.pk)

    def test_reference_inconnue_ou_structuree_ne_cree_pas_de_fiche(self):
        for reference in ("slug:absent", "id:9223372036854775808", [], {"id": self.par_id.pk}, True):
            with self.subTest(reference=reference):
                reponse = self.json_post("/api/agent/v1/objets/creer/",
                    {"modele": reference, "titre": "Référence invalide"}, self.jeton)
                self.assertEqual(reponse.status_code, 400, reponse.content)
        self.assertFalse(CustomObject.objects.filter(title="Référence invalide").exists())
