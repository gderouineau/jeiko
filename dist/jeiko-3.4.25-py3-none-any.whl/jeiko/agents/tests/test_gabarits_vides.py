"""A-63 : valeurs écrites par l'API, puis contexte et partiel de rendu réels."""

import json

from django.template import Context, Template
from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Bloc, Line, Page, Section
from jeiko.custom_objects.models import CustomObject, CustomObjectField, CustomObjectModel
from jeiko.custom_objects.services import build_object_context

from .test_core import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class GabaritsVidesTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(self.agent.user, "view_customobject", "add_customobject",
                       "change_customobject", app="custom_objects", nom="Valeurs vides")
        donner_le_role(self.agent.user, "change_page", nom="Gabarits vides")
        gabarit = Page.objects.create(title="Gabarit", url_tag="gabarit-vide-api",
                                      is_custom_object_template=True)
        self.modele = CustomObjectModel.objects.create(name="Fiche", slug="fiche-vide-api",
                                                       page_template=gabarit)
        for code, type_champ in (("description", "text"), ("details", "rich_text")):
            CustomObjectField.objects.create(model=self.modele, code=code, label=code,
                                             field_type=type_champ)
        section = Section.objects.create(page=gabarit, position=0)
        ligne = Line.objects.create(section=section, position=0)
        self.bloc = Bloc.objects.create(line=ligne, position=0, position_in_column=0)
        creation = self.json_post("/api/agent/v1/objets/creer/",
            {"modele": self.modele.slug, "titre": "Une fiche"}, self.jeton)
        self.assertEqual(creation.status_code, 201, creation.content)
        self.objet = CustomObject.objects.get(pk=creation.json()["objet"]["id"])

    def rendre(self, texte, valeurs):
        patch = self.client.patch(f"/api/agent/v1/objets/{self.objet.pk}/",
            data=json.dumps({"valeurs": valeurs}), content_type="application/json",
            **self.entetes(self.jeton))
        self.assertEqual(patch.status_code, 200, patch.content)
        ecriture = self.client.put(f"/api/agent/v1/blocs/{self.bloc.pk}/contenu/",
            data=json.dumps({"type": "TEXT", "texte": texte}), content_type="application/json",
            **self.entetes(self.jeton))
        self.assertEqual(ecriture.status_code, 200, ecriture.content)
        self.bloc.refresh_from_db()
        contexte = build_object_context(self.objet)
        contexte["texte"] = self.bloc.content.content_text.text
        return Template('{% include "administration_pages/content/partials/content_text.html" '
                        'with text=texte %}').render(Context(contexte)).strip()

    def test_champ_texte_vide_et_null_produisent_un_element_sans_espace(self):
        for valeur in ("", None):
            with self.subTest(valeur=valeur):
                self.assertEqual(self.rendre('<h3 class="carte-description">[%description%]</h3>',
                    {"description": valeur}), '<h3 class="carte-description"></h3>')

    def test_champ_riche_vide_produit_un_element_reellement_vide(self):
        self.assertEqual(self.rendre('<blockquote class="details">[%details%]</blockquote>',
            {"details": ""}), '<blockquote class="details"></blockquote>')

    def test_jetons_repetes_et_espaces_dans_le_code_traversent_assainissement(self):
        self.assertEqual(self.rendre('<h3>[%description%]</h3><p>[% description %]</p>',
            {"description": ""}), '<h3></h3><p></p>')

    def test_champ_absent_ou_jeton_inconnu_n_est_pas_efface_silencieusement(self):
        self.assertEqual(self.rendre('<p>[%description%] [%inconnu%]</p>', {}),
                         '<p>[%description%] [%inconnu%]</p>')

    def test_contenu_riche_non_vide_conserve_son_html_assaini(self):
        sortie = self.rendre('<blockquote>[%details%]</blockquote>',
            {"details": '<p>Bonjour</p><script>alert(1)</script>'})
        self.assertIn("<p>Bonjour</p>", sortie)
        self.assertNotIn("<script", sortie)

    def test_paragraphe_quill_vide_n_est_pas_un_element_css_empty(self):
        self.assertEqual(self.rendre('<blockquote>[%details%]</blockquote>',
            {"details": "<p><br></p>"}), '<blockquote><p><br></p></blockquote>')
