"""Régressions ajoutées pour les lots de corrections API."""

import json

from django.contrib.auth.models import Permission
from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Bloc, ImageContent, Line, Page, Section
from jeiko.custom_objects.models import CustomObjectModel
from jeiko.shop.models import ProductType
from jeiko.agents.services import creer_agent
from jeiko.users.models import Role, RoleAssignment, RolePermission

from ..vues_objets import _type_produit_par_id_ou_code


def donner_le_role(user, *codenames, nom="Rôle de test"):
    role = Role.objects.create(name=nom, slug=nom.lower().replace(" ", "-"))
    for code in codenames:
        RolePermission.objects.create(
            role=role,
            permission=Permission.objects.get(
                codename=code,
                content_type__app_label=(
                    "custom_objects" if code == "view_customobject"
                    else "administration_pages"
                ),
            ),
        )
    RoleAssignment.objects.create(user=user, role=role)


class SocleMixin:
    def creer(self):
        return creer_agent(nom="Agent de test")

    def entetes(self, jeton):
        return {"HTTP_AUTHORIZATION": f"Bearer {jeton}"}


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class CorrectionsChatGPTTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            "view_customobject",
            nom="Régressions API",
        )

    def test_une_route_inconnue_reste_une_erreur_json_explicite(self):
        reponse = self.client.get(
            "/api/agent/v1/route-qui-n-existe-pas/",
            **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 404)
        self.assertTrue(reponse["Content-Type"].startswith("application/json"))
        self.assertIn("Route API inconnue", reponse.json()["erreur"])

    def test_un_champ_ignore_est_refuse_en_json_plutot_que_repondre_200(self):
        reponse = self.client.post(
            "/api/agent/v1/pages/creer/",
            data=json.dumps({
                "titre": "Page avec faute",
                "champ_qui_serait_ignore": True,
            }),
            content_type="application/json",
            **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertTrue(reponse["Content-Type"].startswith("application/json"))
        self.assertIn("champ_qui_serait_ignore", reponse.json()["erreur"])
        self.assertFalse(Page.objects.filter(title="Page avec faute").exists())

    def test_qui_suis_je_expose_le_quota(self):
        reponse = self.client.get(
            "/api/agent/v1/qui-suis-je/", **self.entetes(self.jeton)
        )
        self.assertEqual(reponse.status_code, 200)
        quota = reponse.json()["quota"]
        self.assertEqual(set(quota), {
            "utilises", "restants", "maximum", "fenetre_secondes",
            "reinitialisation_dans_secondes",
        })
        self.assertGreaterEqual(quota["maximum"], quota["utilises"])

    def test_ligne_vide_expose_ses_colonnes(self):
        page = Page.objects.create(title="Colonnes", url_tag="colonnes")
        section = Section.objects.create(page=page, position=0)
        ligne = Line.objects.create(
            section=section, position=0, columns_number=3, columns_type="4-4-4"
        )
        reponse = self.client.get(
            f"/api/agent/v1/lignes/{ligne.pk}/", **self.entetes(self.jeton)
        )
        self.assertEqual(reponse.status_code, 200)
        rendu = reponse.json()["ligne"]
        # Les champs de style et de structure sont exposés sous `parametres`,
        # comme pour les sections et les blocs. Le test vérifie leur présence
        # même quand `blocs` est vide.
        self.assertEqual(rendu["parametres"]["columns_number"], 3)
        self.assertEqual(rendu["parametres"]["columns_type"], "4-4-4")

    def test_un_bloc_image_utilise_l_image_de_la_mediatheque(self):
        page = Page.objects.create(title="Image", url_tag="image")
        section = Section.objects.create(page=page, position=0)
        ligne = Line.objects.create(section=section, position=0, columns_number=1,
                                     columns_type="12")
        bloc = Bloc.objects.create(line=ligne, position=0, position_in_column=0)
        image = ImageContent.objects.create()
        reponse = self.client.put(
            f"/api/agent/v1/blocs/{bloc.pk}/contenu/",
            data=json.dumps({"type": "IMAGE", "image_id": image.pk}),
            content_type="application/json", **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 200, reponse.content[:500])
        bloc.refresh_from_db()
        self.assertEqual(bloc.content.content_image.image_content_id, image.pk)

    def test_filtre_modele_accepte_id(self):
        gabarit = Page.objects.create(
            title="Gabarit réalisation",
            url_tag="gabarit-realisation",
            is_custom_object_template=True,
        )
        modele = CustomObjectModel.objects.create(
            name="Réalisation",
            slug="realisation",
            page_template=gabarit,
        )
        reponse = self.client.get(
            f"/api/agent/v1/objets/?modele={modele.pk}", **self.entetes(self.jeton)
        )
        self.assertEqual(reponse.status_code, 200)

    def test_creation_bloc_accepte_un_rang_explicit(self):
        page = Page.objects.create(title="Rang", url_tag="rang")
        section = Section.objects.create(page=page, position=0)
        ligne = Line.objects.create(section=section, position=0, columns_number=1,
                                     columns_type="12")
        premier = self.client.post(
            f"/api/agent/v1/lignes/{ligne.pk}/blocs/",
            data=json.dumps({"colonne": 0}), content_type="application/json",
            **self.entetes(self.jeton),
        )
        self.assertEqual(premier.status_code, 201)
        second = self.client.post(
            f"/api/agent/v1/lignes/{ligne.pk}/blocs/",
            data=json.dumps({"colonne": 0, "rang": 0}),
            content_type="application/json", **self.entetes(self.jeton),
        )
        self.assertEqual(second.status_code, 201)
        self.assertEqual(second.json()["bloc"]["rang"], 0)

    def test_type_de_produit_est_resolu_par_id_ou_code(self):
        type_produit = ProductType.objects.create(name="Service", code="service")
        self.assertEqual(_type_produit_par_id_ou_code(type_produit.pk), type_produit)
        self.assertEqual(_type_produit_par_id_ou_code("service"), type_produit)
