"""Téléversement d'images par un agent, avec les mêmes gardes que l'admin."""

import tempfile
from io import BytesIO

from PIL import Image

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings

from jeiko.administration_pages.models import ImageContent
from jeiko.agents.services import creer_agent

from .test_core import donner_le_role


def image_png(name="agent.png"):
    stream = BytesIO()
    Image.new("RGB", (8, 6), (50, 120, 180)).save(stream, format="PNG")
    return SimpleUploadedFile(name, stream.getvalue(), content_type="image/png")


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True, JEIKO_IMAGES_ASYNC=False)
class AgentMediaUploadTests(TestCase):
    def setUp(self):
        self.media = tempfile.TemporaryDirectory()
        self.settings_override = override_settings(MEDIA_ROOT=self.media.name)
        self.settings_override.enable()
        self.agent, self.jeton = creer_agent(nom="Agent média")

    def tearDown(self):
        self.settings_override.disable()
        self.media.cleanup()

    def entetes(self):
        return {"HTTP_AUTHORIZATION": f"Bearer {self.jeton}"}

    def test_la_permission_d_upload_est_distincte_de_la_lecture_des_pages(self):
        donner_le_role(self.agent.user, "view_page", nom="Lecture seule média")
        reponse = self.client.post(
            "/api/agent/v1/images/creer/",
            {"fichier": image_png(), "alt": "Refusée"},
            **self.entetes(),
        )
        self.assertEqual(reponse.status_code, 403)
        self.assertTrue(reponse["Content-Type"].startswith("application/json"))

    def test_un_agent_autorise_televerse_et_recoit_l_identifiant(self):
        donner_le_role(
            self.agent.user, "add_imagecontent",
            app="administration_pages", nom="Upload média",
        )
        reponse = self.client.post(
            "/api/agent/v1/images/creer/",
            {"fichier": image_png(), "titre": "Hero API", "alt": "Visuel API"},
            **self.entetes(),
        )
        self.assertEqual(reponse.status_code, 201, reponse.content[:500])
        donnees = reponse.json()["image"]
        self.assertTrue(ImageContent.objects.filter(pk=donnees["id"], alt="Visuel API").exists())
        self.assertEqual(donnees["titre"], "Hero API")
        self.assertIn("url", donnees)

    def test_un_faux_fichier_image_est_refuse_en_json_sans_ecriture(self):
        donner_le_role(
            self.agent.user, "add_imagecontent",
            app="administration_pages", nom="Upload invalide",
        )
        faux = SimpleUploadedFile("faux.png", b"pas une image", content_type="image/png")
        reponse = self.client.post(
            "/api/agent/v1/images/creer/",
            {"fichier": faux, "alt": "Faux"},
            **self.entetes(),
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertTrue(reponse["Content-Type"].startswith("application/json"))
        self.assertIn("champs", reponse.json())
        self.assertFalse(ImageContent.objects.filter(alt="Faux").exists())

    def test_un_champ_inconnu_est_refuse_avant_toute_ecriture(self):
        donner_le_role(
            self.agent.user, "add_imagecontent",
            app="administration_pages", nom="Upload strict",
        )
        reponse = self.client.post(
            "/api/agent/v1/images/creer/",
            {"fichier": image_png(), "alt": "Inconnue", "legende": "ignorée"},
            **self.entetes(),
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("legende", reponse.json()["erreur"])
        self.assertFalse(ImageContent.objects.filter(alt="Inconnue").exists())
