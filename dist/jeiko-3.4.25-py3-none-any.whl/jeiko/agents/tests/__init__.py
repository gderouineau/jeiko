"""Tests organisés par domaine de l'API des agents."""
