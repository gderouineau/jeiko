"""P1/A-60 : la documentation explique les informations déjà exposées."""

from django.test import SimpleTestCase, TestCase, override_settings

from jeiko.administration_pages.models import Category, Page, PageInsights
from jeiko.administration_pages.utils import page_public_url
from jeiko.agents.guide import PROSE
from jeiko.agents.models import Agent
from jeiko.users.testing import reinitialiser_les_plafonds

from .test_core import SocleMixin, donner_le_role


class ContratsGuideTests(SimpleTestCase):
    def test_le_guide_explique_les_releves_obsoletes(self):
        for mot in ("mesure_obsolete", "url_testee", "url_actuelle", "mesure: null"):
            self.assertTrue(mot in PROSE, f"Le guide doit expliquer {mot}.")

    def test_le_guide_explique_le_quota_et_son_reglage_par_agent(self):
        for mot in ("qui-suis-je", "Agent.plafond_horaire", "utilises", "restants",
                    "maximum", "fenetre_secondes", "reinitialisation_dans_secondes"):
            self.assertTrue(mot in PROSE, f"Le guide doit expliquer {mot}.")


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True,
                   JEIKO_AGENTS_LIMITS={"jeton": (3, 3600), "echecs_ip": (20, 900)})
class QuotaExposeTests(SocleMixin, TestCase):
    def setUp(self):
        reinitialiser_les_plafonds()
        self.agent, self.jeton = self.creer()

    def quota(self):
        reponse = self.client.get("/api/agent/v1/qui-suis-je/", **self.entetes(self.jeton))
        self.assertEqual(reponse.status_code, 200)
        return reponse.json()["quota"]

    def test_qui_suis_je_rend_le_plafond_propre_et_compte_son_appel(self):
        Agent.objects.filter(pk=self.agent.pk).update(plafond_horaire=5)
        quota = self.quota()
        self.assertEqual((quota["maximum"], quota["utilises"], quota["restants"]), (5, 1, 4))
        self.assertEqual(quota["fenetre_secondes"], 3600)
        self.assertTrue(0 < quota["reinitialisation_dans_secondes"] <= 3600)

    def test_qui_suis_je_rend_le_plafond_du_site_sans_reglage_propre(self):
        quota = self.quota()
        self.assertEqual((quota["maximum"], quota["utilises"], quota["restants"]), (3, 1, 2))


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class MesuresDocumenteesTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(self.agent.user, "view_page", nom="Mesures documentées")
        self.page = Page.objects.create(title="Mesure", url_tag="mesure-guide-api")

    def mesurer(self):
        reponse = self.client.get(f"/api/agent/v1/pages/{self.page.pk}/mesures/",
                                  **self.entetes(self.jeton))
        self.assertEqual(reponse.status_code, 200)
        return reponse.json()["mesure"]

    def test_absence_de_releve_rend_null_et_ne_declenche_pas_analyse(self):
        self.assertIsNone(self.mesurer())
        self.assertFalse(PageInsights.objects.filter(page=self.page).exists())

    def test_changement_de_categorie_signale_le_releve_meme_si_etat_ok(self):
        precedente = page_public_url(self.page)
        self.page.category = Category.objects.create(name="Catégorie mesures", slug="mesures",
                                                     show_cat_in_url=True)
        self.page.save(update_fields=["category"])
        PageInsights.objects.create(page=self.page, strategy="desktop", status="ok",
                                    url_tested=precedente, score_performance=100)
        mesure = self.mesurer()
        self.assertTrue(mesure["mesure_obsolete"])
        self.assertEqual(mesure["etat"], "ok")
        self.assertEqual(mesure["url_testee"], precedente)
        self.assertTrue(mesure["url_actuelle"].endswith("/mesures/mesure-guide-api/"))
        self.assertEqual(PageInsights.objects.filter(page=self.page).count(), 1)

    def test_releve_sur_url_canonique_avec_sous_categorie_n_est_pas_obsolete(self):
        parente = Category.objects.create(name="Mesures parentes", slug="mesures-parentes",
                                          show_cat_in_url=True)
        self.page.category = parente
        self.page.sub_category = Category.objects.create(name="Mesures enfants", slug="enfants",
                                                         main_category=parente, show_cat_in_url=True)
        self.page.save(update_fields=["category", "sub_category"])
        courante = page_public_url(self.page)
        PageInsights.objects.create(page=self.page, strategy="mobile", status="ok", url_tested=courante)
        mesure = self.mesurer()
        self.assertFalse(mesure["mesure_obsolete"])
        self.assertEqual(mesure["url_actuelle"], courante)
        self.assertTrue(courante.endswith("/mesures-parentes/enfants/mesure-guide-api/"))
