"""A-54 et M-02 : échanges réels de l'API, sans simuler ses paramètres."""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import (
    BackgroundImageParameters, Bloc, ImageContent, Line, Page, Section,
)

from .test_chatgpt import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class FondEtImagesPartageesTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(self.agent.user, "view_page", "change_page", nom="Fonds API")
        self.page = Page.objects.create(title="Fonds", url_tag="fonds-api")
        self.section = Section.objects.create(page=self.page, position=0)
        self.image = ImageContent.objects.create(alt="Image partagée")

    def patch_fond(self, fond):
        return self.client.patch(
            f"/api/agent/v1/sections/{self.section.pk}/",
            data=json.dumps({"fond": fond}), content_type="application/json",
            **self.entetes(self.jeton),
        )

    def lire_fond(self):
        reponse = self.client.get(
            f"/api/agent/v1/sections/{self.section.pk}/", **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 200)
        return reponse.json()["section"]["parametres"]["fond"]

    def test_aller_retour_get_patch_du_fond_avec_et_sans_image_ni_reglages(self):
        for avec_image, avec_reglages in ((False, False), (True, False),
                                         (False, True), (True, True)):
            with self.subTest(image=avec_image, reglages=avec_reglages):
                self.section.background_image = self.image if avec_image else None
                self.section.background_image_parameters = (
                    BackgroundImageParameters.objects.create() if avec_reglages else None
                )
                self.section.save()
                fond = self.lire_fond()
                reponse = self.patch_fond(fond)
                self.assertEqual(reponse.status_code, 200, reponse.content)
                self.assertEqual(self.lire_fond(), fond)

    def test_image_riche_seule_utilise_id_et_reglages(self):
        reponse = self.patch_fond({"image": {
            "id": self.image.pk, "reglages": {"background_size": "contain"},
        }})
        self.assertEqual(reponse.status_code, 200, reponse.content)
        self.section.refresh_from_db()
        self.assertEqual(self.section.background_image_id, self.image.pk)
        self.assertEqual(self.section.background_image_parameters.background_size, "contain")

    def test_identifiants_contradictoires_refuses_sans_modification(self):
        autre = ImageContent.objects.create()
        reponse = self.patch_fond({"couleur": "red", "image_id": autre.pk,
                                   "image": {"id": self.image.pk}})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("conflit", reponse.json()["erreur"].lower())
        self.section.refresh_from_db()
        self.assertIsNone(self.section.background_image_id)
        self.assertNotEqual(self.section.background_color, "red")

    def test_reglages_contradictoires_refuses(self):
        reponse = self.patch_fond({
            "image": {"id": self.image.pk, "reglages": {"background_size": "cover"}},
            "reglages_image": {"background_size": "contain"},
        })
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("conflit", reponse.json()["erreur"].lower())

    def test_image_nulle_detache_et_reglages_nuls_detachent(self):
        self.section.background_image = self.image
        self.section.background_image_parameters = BackgroundImageParameters.objects.create()
        self.section.save()
        reponse = self.patch_fond({"image": None, "reglages_image": None})
        self.assertEqual(reponse.status_code, 200, reponse.content)
        self.section.refresh_from_db()
        self.assertIsNone(self.section.background_image_id)
        self.assertIsNone(self.section.background_image_parameters_id)

    def test_image_invalide_ou_metadonnees_modifiees_refusees_en_json(self):
        for image in ("image", {}, {"id": []}, {"id": True}, {"id": -1},
                      {"id": self.image.pk, "inconnu": 1},
                      {"id": self.image.pk, "alt": "Modification ignorée"},
                      {"id": self.image.pk, "url": "https://example.test/autre.png"}):
            with self.subTest(image=image):
                reponse = self.patch_fond({"image": image})
                self.assertEqual(reponse.status_code, 400, reponse.content)
                self.assertTrue(reponse["Content-Type"].startswith("application/json"))

    def test_image_id_texte_et_id_entier_coherents(self):
        reponse = self.patch_fond({"image_id": str(self.image.pk),
                                   "image": {"id": self.image.pk}})
        self.assertEqual(reponse.status_code, 200, reponse.content)

    def test_image_id_invalide_refuse_sans_500(self):
        for identifiant in ([], {}, True, False, 0.0, 1.2, -1, "abc", "9" * 100):
            with self.subTest(identifiant=identifiant):
                reponse = self.patch_fond({"image_id": identifiant})
                self.assertEqual(reponse.status_code, 400, reponse.content)

    def test_alias_nuls_et_zero_sont_coherents(self):
        for identifiant in (None, "", 0, "0"):
            with self.subTest(identifiant=identifiant):
                reponse = self.patch_fond({"image_id": identifiant, "image": {"id": None}})
                self.assertEqual(reponse.status_code, 200, reponse.content)

    def test_patch_partiel_preserve_image_et_reglages_non_mentionnes(self):
        self.section.background_image = self.image
        reglages = BackgroundImageParameters.objects.create(background_size="contain")
        self.section.background_image_parameters = reglages
        self.section.save()
        reponse = self.patch_fond({"couleur": "red"})
        self.assertEqual(reponse.status_code, 200, reponse.content)
        self.section.refresh_from_db()
        self.assertEqual(self.section.background_image_id, self.image.pk)
        self.assertEqual(self.section.background_image_parameters_id, reglages.pk)

    def test_aller_retour_fond_sur_ligne_et_bloc(self):
        ligne = Line.objects.create(section=self.section, position=0, background_image=self.image)
        bloc = Bloc.objects.create(line=ligne, position=0, position_in_column=0,
                                   background_image=self.image)
        for famille, element, cle in (("lignes", ligne, "ligne"), ("blocs", bloc, "bloc")):
            with self.subTest(famille=famille):
                url = f"/api/agent/v1/{famille}/{element.pk}/"
                lecture = self.client.get(url, **self.entetes(self.jeton))
                self.assertEqual(lecture.status_code, 200)
                fond = lecture.json()[cle]["parametres"]["fond"]
                reponse = self.client.patch(url, data=json.dumps({"fond": fond}),
                                            content_type="application/json",
                                            **self.entetes(self.jeton))
                self.assertEqual(reponse.status_code, 200, reponse.content)
                self.assertEqual(reponse.json()[cle]["parametres"]["fond"], fond)

    def test_deux_blocs_image_reutilisent_le_meme_media(self):
        ligne = Line.objects.create(section=self.section, position=0)
        blocs = [Bloc.objects.create(line=ligne, position=i, position_in_column=0)
                 for i in range(2)]
        for bloc in blocs:
            reponse = self.client.put(
                f"/api/agent/v1/blocs/{bloc.pk}/contenu/",
                data=json.dumps({"type": "IMAGE", "image_id": self.image.pk}),
                content_type="application/json", **self.entetes(self.jeton),
            )
            self.assertEqual(reponse.status_code, 200, reponse.content)
            bloc.refresh_from_db()
            self.assertEqual(bloc.content.content_image.image_content_id, self.image.pk)
        self.assertNotEqual(blocs[0].content.content_image_id, blocs[1].content.content_image_id)
