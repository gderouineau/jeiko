"""La médiathèque doit rester atteignable depuis la navigation admin."""

from django.contrib.auth import get_user_model
from django.test import TestCase

from jeiko.administration.admin_nav import build_nav


class MediaNavigationTests(TestCase):
    def test_un_administrateur_voit_un_lien_resolu_vers_la_mediatheque(self):
        user = get_user_model().objects.create_superuser(
            username="nav-media", email="nav@example.test", password="secret"
        )
        navigation = build_nav(user, "jeiko_administration_pages:media_list")
        items = [item for section in navigation for item in section["items"]]
        media = next(item for item in items if item["label"] == "Médiathèque")
        self.assertEqual(media["url"], "/jeiko/administration/pages/media/")
        self.assertTrue(media["is_active"])
