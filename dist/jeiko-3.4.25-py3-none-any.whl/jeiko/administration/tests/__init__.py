"""Tests du module d'administration générale."""
