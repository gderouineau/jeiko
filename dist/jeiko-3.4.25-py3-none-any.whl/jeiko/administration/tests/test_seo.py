"""Régressions des réglages SEO E-03, E-05 et E-06."""

import json
import tempfile
from io import BytesIO
from types import SimpleNamespace

from PIL import Image

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.template.loader import render_to_string
from django.test import RequestFactory, TestCase, override_settings
from django.urls import reverse

from jeiko.administration.models import SiteIdentity, SocialLink, WebSite
from jeiko.administration_pages.media_library import delete_image_safely
from jeiko.administration_pages.models import ImageContent, Page
from jeiko.templatetags.site_identity_tags import site_identity_jsonld


def image_png(name="partage.png"):
    stream = BytesIO()
    Image.new("RGB", (8, 6), (28, 88, 160)).save(stream, format="PNG")
    return SimpleUploadedFile(name, stream.getvalue(), content_type="image/png")


@override_settings(ALLOWED_HOSTS=["testserver"], JEIKO_IMAGES_ASYNC=False)
class SeoSettingsTests(TestCase):
    def setUp(self):
        self.media = tempfile.TemporaryDirectory()
        self.media_override = override_settings(MEDIA_ROOT=self.media.name)
        self.media_override.enable()
        self.site = WebSite.objects.first() or WebSite.objects.create(name="Jeiko test")
        SocialLink.objects.filter(website=self.site).delete()
        SiteIdentity.objects.filter(website=self.site).delete()
        self.identity = SiteIdentity.objects.create(
            website=self.site,
            type=SiteIdentity.TYPE_ORG,
            name="Jeiko test",
            url="https://example.test/",
        )
        self.admin = get_user_model().objects.create_superuser(
            username="seo-admin", email="seo@example.test", password="secret"
        )
        self.client.force_login(self.admin)

    def tearDown(self):
        self.media_override.disable()
        self.media.cleanup()

    def _identity_data(self, *, total=1, initial=0, **social):
        data = {
            "type": SiteIdentity.TYPE_ORG,
            "name": "Jeiko test",
            "url": "https://example.test/",
            "telephone": "",
            "street_address": "",
            "address_locality": "",
            "address_region": "",
            "postal_code": "",
            "address_country": "",
            "geo_lat": "",
            "geo_lng": "",
            "price_range": "",
            "default_share_image": "",
            "social-TOTAL_FORMS": str(total),
            "social-INITIAL_FORMS": str(initial),
            "social-MIN_NUM_FORMS": "0",
            "social-MAX_NUM_FORMS": "1000",
        }
        defaults = {
            "platform": "instagram",
            "profile_url": "https://www.instagram.com/jeiko-test/",
            "handle": "@jeiko-test",
            "display_name": "Jeiko sur Instagram",
            "aria_label": "Suivre Jeiko sur Instagram",
            "position": "1",
            "is_active": "on",
        }
        defaults.update(social)
        for key, value in defaults.items():
            data[f"social-0-{key}"] = value
        return data

    def test_l_ecran_permet_d_ajouter_modifier_desactiver_et_supprimer_un_reseau(self):
        url = reverse("jeiko_administration:site_identity")
        page = self.client.get(url)
        self.assertContains(page, "Ajouter un réseau")

        response = self.client.post(url, self._identity_data())
        self.assertEqual(response.status_code, 302)
        link = SocialLink.objects.get(website=self.site)

        update = self._identity_data(
            initial=1,
            id=str(link.pk),
            display_name="Instagram officiel",
            is_active="",
        )
        response = self.client.post(url, update)
        self.assertEqual(response.status_code, 302)
        link.refresh_from_db()
        self.assertEqual(link.display_name, "Instagram officiel")
        self.assertFalse(link.is_active)

        delete = self._identity_data(initial=1, id=str(link.pk), DELETE="on")
        response = self.client.post(url, delete)
        self.assertEqual(response.status_code, 302)
        self.assertFalse(SocialLink.objects.filter(pk=link.pk).exists())

    def test_same_as_ne_contient_que_les_profils_actifs_avec_url(self):
        SocialLink.objects.create(
            website=self.site,
            platform="instagram",
            profile_url="https://www.instagram.com/jeiko-test/",
            is_active=True,
        )
        SocialLink.objects.create(
            website=self.site,
            platform="facebook",
            profile_url="https://www.facebook.com/jeiko-test/",
            is_active=False,
        )
        request = RequestFactory().get("/", HTTP_HOST="testserver")
        data = json.loads(site_identity_jsonld({"request": request}, self.site))
        self.assertEqual(data["sameAs"], ["https://www.instagram.com/jeiko-test/"])

    def test_image_de_partage_par_defaut_fournit_url_dimensions_et_alt(self):
        image = ImageContent.objects.create(
            original_image=image_png(), title="Partage", alt="Atelier en activité"
        )
        self.identity.default_share_image = image
        self.identity.save(update_fields=["default_share_image"])
        self.site.refresh_from_db()
        page = Page(title="Sans image", url_tag="sans-image", main_image=None)
        request = RequestFactory().get("/sans-image/", HTTP_HOST="testserver")
        html = render_to_string("includes/open_graph.html", {
            "request": request,
            "website_data": self.site,
            "page": page,
            "custom_object": None,
            "metadata": SimpleNamespace(title="Titre partagé", description="Résumé"),
            "canonical_url": "https://example.test/sans-image/",
        })
        self.assertIn('property="og:image" content="http://testserver/', html)
        self.assertIn('property="og:image:width" content="8"', html)
        self.assertIn('property="og:image:height" content="6"', html)
        self.assertIn('property="og:image:alt" content="Atelier en activité"', html)
        self.assertIn('name="twitter:image:alt" content="Atelier en activité"', html)

    def test_image_de_partage_est_protegee_par_la_mediatheque(self):
        image = ImageContent.objects.create(original_image=image_png(), alt="Partage")
        self.identity.default_share_image = image
        self.identity.save(update_fields=["default_share_image"])
        result = delete_image_safely(image)
        self.assertFalse(result.deleted)
        self.assertIn("Images de partage par défaut", [usage.label for usage in result.usages])
        self.assertTrue(ImageContent.objects.filter(pk=image.pk).exists())


@override_settings(ALLOWED_HOSTS=["testserver"])
class RobotsTxtSeoTests(TestCase):
    def test_une_page_depubliee_n_est_pas_revelee_mais_une_page_noindex_l_est(self):
        Page.objects.create(
            title="Brouillon secret", url_tag="brouillon-secret", active=False,
            google_index=False,
        )
        Page.objects.create(
            title="Page publiée noindex", url_tag="page-noindex", active=True,
            google_index=False,
        )
        robots = self.client.get("/robots.txt").content.decode()
        self.assertNotIn("/brouillon-secret/", robots)
        self.assertIn("Disallow: /page-noindex/", robots)
