"""A-01 : contourner le menu sans perdre les retours ou la mise en page.

Le repère appartient à la base commune, pas à chaque écran. Les tests rendent
cette base et plusieurs vraies vues ; ils ne prétendent pas simuler un lecteur
d'écran ni mesurer la visibilité du focus dans un navigateur.
"""

from html.parser import HTMLParser
from pathlib import Path
import re
from unittest.mock import patch

from django.contrib.messages import SUCCESS
from django.contrib.messages.storage.base import Message
from django.template import Context, Template
from django.test import SimpleTestCase, TestCase
from django.urls import reverse
from django.utils.translation import override

from jeiko.administration.models import WebSite
from jeiko.users.testing import creer_compte_verifie


PAQUET = Path(__file__).resolve().parents[2]


class ReperesHTML(HTMLParser):
    """Retient les ancêtres pour distinguer contenu, navigation et dialogue."""

    VIDES = {"area", "base", "br", "col", "embed", "hr", "img", "input",
             "link", "meta", "param", "source", "track", "wbr"}

    def __init__(self, texte):
        super().__init__()
        self.pile = []
        self.elements = []
        self.feed(texte)

    def handle_starttag(self, tag, attrs):
        self.elements.append((tag, dict(attrs), tuple(self.pile)))
        if tag not in self.VIDES:
            self.pile.append(tag)

    def handle_startendtag(self, tag, attrs):
        self.elements.append((tag, dict(attrs), tuple(self.pile)))

    def handle_endtag(self, tag):
        if tag in self.pile:
            index = len(self.pile) - 1 - self.pile[::-1].index(tag)
            del self.pile[index:]


class BaseAdministrationAccessibleTests(SimpleTestCase):
    def rendre(self, messages=()):
        # Le site et les rôles n'ont aucune influence sur le contrat de repère.
        # Les mocker évite toute requête dans ces tests de structure du rendu.
        with patch("jeiko.templatetags.website_extra.get_website_data", return_value={}), \
             patch("jeiko.templatetags.admin_nav_tags.build_nav", return_value=[]), \
             override("fr"):
            return Template('{% extends "base_admin.html" %}{% block content %}'
                            '<div class="admin-content"><h1 id="contenu-essai">Essai</h1>'
                            '<input id="champ-essai"></div>{% endblock %}').render(
                                Context({"messages": messages}))

    def test_un_seul_main_focusable_contient_le_bloc_de_l_ecran(self):
        elements = ReperesHTML(self.rendre()).elements
        principaux = [attrs for tag, attrs, _ in elements if tag == "main"]
        self.assertEqual(len(principaux), 1)
        self.assertEqual(principaux[0].get("id"), "jk-admin-main")
        self.assertEqual(principaux[0].get("tabindex"), "-1")
        titre = next(e for e in elements if e[1].get("id") == "contenu-essai")
        self.assertIn("main", titre[2])
        # Pas de seconde classe admin-content : ses marges restent à l'écran.
        self.assertNotIn("admin-content", principaux[0].get("class", "").split())

    def test_lien_d_evitement_premier_controle_et_cible_unique(self):
        rendu = self.rendre()
        elements = ReperesHTML(rendu).elements
        controles = [e for e in elements if (e[0] == "a" and "href" in e[1])
                     or e[0] in {"button", "input", "select", "textarea"}]
        self.assertEqual(controles[0][0], "a")
        self.assertEqual(controles[0][1].get("href"), "#jk-admin-main")
        self.assertIn("jk-skip-link", controles[0][1].get("class", "").split())
        self.assertEqual(sum(e[1].get("id") == "jk-admin-main" for e in elements), 1)
        self.assertIn("Aller au contenu principal", rendu)

    def test_les_messages_restent_accessibles_dans_le_main(self):
        rendu = self.rendre([Message(SUCCESS, "Enregistrement confirmé")])
        elements = ReperesHTML(rendu).elements
        statut = next(e for e in elements if e[1].get("role") == "status")
        self.assertIn("main", statut[2])
        self.assertEqual(statut[1].get("aria-live"), "polite")
        self.assertEqual(rendu.count("Enregistrement confirmé"), 1)

    def test_navigation_et_confirmation_ne_sont_pas_dans_le_main(self):
        elements = ReperesHTML(self.rendre()).elements
        navigation = next(e for e in elements if e[0] == "nav")
        dialogue = next(e for e in elements if e[1].get("role") == "dialog")
        self.assertNotIn("main", navigation[2])
        self.assertNotIn("main", dialogue[2])

    def test_les_ecrans_enfants_ne_dupliquent_pas_le_repere(self):
        coupables = []
        for chemin in (PAQUET / "templates").rglob("*.html"):
            source = chemin.read_text()
            if re.search(r"\{%\s*extends\s+['\"]base_admin\.html['\"]", source):
                if re.search(r"<main\b", source):
                    coupables.append(str(chemin.relative_to(PAQUET)))
        self.assertEqual(coupables, [], "Le main est fourni par la base commune.")

    def test_le_css_masque_sans_retirer_la_tabulation_et_revele_au_focus(self):
        css = (PAQUET / "static/jeiko/css/admin/admin_ui.css").read_text()
        css = re.sub(r"/\*.*?\*/", "", css, flags=re.DOTALL)
        normal = re.search(r"a\.jk-skip-link\s*\{([^}]+)\}", css)
        self.assertIsNotNone(normal)
        self.assertIn("position: fixed", normal[1])
        self.assertIn("transform: translateY", normal[1])
        self.assertNotRegex(normal[1], r"display\s*:\s*none|visibility\s*:\s*hidden")
        self.assertRegex(css, r"a\.jk-skip-link:focus\s*\{[^}]*transform:\s*translateY\(0\)")
        self.assertRegex(css, r"\.jk-admin-main:focus\s*\{[^}]*outline:\s*3px solid")


class EcransAdministrationAccessiblesTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.chef = creer_compte_verifie("reperes-admin", "reperes@example.test", "pw",
                                       is_staff=True, is_superuser=True)
        WebSite.objects.get_or_create(defaults={"name": "Repères"})

    def test_les_vraies_vues_heritent_du_lien_et_du_main_unique(self):
        self.client.force_login(self.chef)
        for route in ("jeiko_administration:main", "jeiko_administration:theme_view",
                      "jeiko_administration_pages:media_list",
                      "jeiko_administration_shop:settings"):
            with self.subTest(route=route):
                reponse = self.client.get(reverse(route))
                self.assertEqual(reponse.status_code, 200)
                elements = ReperesHTML(reponse.content.decode()).elements
                principaux = [e for e in elements if e[0] == "main"]
                self.assertEqual(len(principaux), 1)
                self.assertEqual(principaux[0][1].get("tabindex"), "-1")
                self.assertTrue(any(e[0] == "a" and e[1].get("href") == "#jk-admin-main"
                                    for e in elements))
