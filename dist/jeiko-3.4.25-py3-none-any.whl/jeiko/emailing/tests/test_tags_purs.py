"""
Contrats purs des helpers `render_tags` et `extract_tags` de
`emailing/models.py`.

Aucun modèle enregistré, aucune instance `EmailTemplate`, aucun
ORM : les helpers sont des fonctions module-level qui ne tirent
aucune dépendance d'un modèle.

Ce que ces tests ne vérifient pas
---------------------------------
- `render_tags` substitue du texte, ce n'est PAS un assainisseur
  HTML. Un contexte malicieux passe tel quel : aucune promesse
  d'échappement HTML, ni de protection XSS.
- `extract_tags` retourne un `set` : la déduplication est garantie,
  mais l'ORDRE des clés n'est pas testé (un `set` n'a pas
  d'ordre stable en Python < 3.7 et reste non déterministe
  pour la sérialisation). On teste l'appartenance, pas la
  séquence.
- La syntaxe des jetons est `[\%\s*(\w+)\s*\%]` (cf. TAG_PATTERN
  dans `models.py`). En Python 3, `\w` est Unicode-aware par
  défaut : il couvre `[a-zA-Z0-9_]` PLUS les lettres/chiffres
  Unicode (cf. `re.UNICODE` implicite). Les tirets et points
  restent NON capturés ; les caractères accentués le SONT.
"""

from django.test import SimpleTestCase

from jeiko.emailing.models import extract_tags, render_tags



class RenderTagsTests(SimpleTestCase):
    """Substitution des jetons présents dans un contexte."""

    def test_jeton_connu_est_substitué(self):
        self.assertEqual(
            render_tags("Bonjour [% nom %]", {"nom": "Alice"}),
            "Bonjour Alice",
        )

    def test_jeton_inconnu_est_conservé_littéralement(self):
        """Un jeton absent du contexte reste tel quel, sans warning."""
        self.assertEqual(
            render_tags("Voici [% fantome %]", {"nom": "Alice"}),
            "Voici [% fantome %]",
        )

    def test_occurrences_répétées_sont_toutes_substituées(self):
        self.assertEqual(
            render_tags("[% nom %] et [% nom %]", {"nom": "Alice"}),
            "Alice et Alice",
        )

    def test_espaces_dans_le_jeton_sont_acceptés(self):
        """Les espaces autour de la clé sont tolérés (cf. TAG_PATTERN)."""
        self.assertEqual(
            render_tags("[%   nom   %]", {"nom": "Alice"}),
            "Alice",
        )

    def test_contexte_avec_chaîne_vide_substitue_par_vide(self):
        """Une clé présente avec une valeur chaîne vide est rendue vide."""
        self.assertEqual(
            render_tags("Bonjour [% nom %] !", {"nom": ""}),
            "Bonjour  !",
        )

    def test_contexte_avec_zero_est_rendu(self):
        """`0` est une valeur valide et doit apparaître textuellement."""
        self.assertEqual(
            render_tags("Il reste [% n %] articles.", {"n": 0}),
            "Il reste 0 articles.",
        )

    def test_texte_vide_retourne_chaîne_vide(self):
        """`text=None` ou `text=""` retourne `""`, jamais None."""
        self.assertEqual(render_tags("", {"nom": "Alice"}), "")
        self.assertEqual(render_tags(None, {"nom": "Alice"}), "")

    def test_texte_sans_jeton_retourné_intact(self):
        self.assertEqual(
            render_tags("Bonjour à toutes et tous", {"nom": "Alice"}),
            "Bonjour à toutes et tous",
        )

    def test_jeton_avec_tiret_n_est_pas_reconnu(self):
        """`[% a-b %]` ne capture pas `a-b` (tiret hors de \w) :
        le texte est laissé tel quel."""
        self.assertEqual(
            render_tags("[% a-b %]", {"a-b": "X"}),
            "[% a-b %]",
        )

    def test_jeton_avec_point_n_est_pas_reconnu(self):
        """`[% a.b %]` : le point n'est pas capturé, jeton laissé tel quel."""
        self.assertEqual(
            render_tags("[% a.b %]", {"a.b": "X"}),
            "[% a.b %]",
        )

    def test_caractères_unicode_dans_jeton_sont_capturés(self):
        """`\w+` en Python 3 inclut les lettres/chiffres Unicode ;
        un jeton `prénom` EST capturé et substitué. Le commentaire
        de TAG_PATTERN parle de « même syntaxe » qu'administration_pages ;
        les contenus d'administration utilisent un pattern équivalent."""
        self.assertEqual(
            render_tags("[% prénom %]", {"prénom": "Alice"}),
            "Alice",
        )


# ---------- extract_tags ----------


class ExtractTagsTests(SimpleTestCase):
    """Découverte des jetons dans un texte."""

    def test_texte_vide_renvoie_un_ensemble_vide(self):
        self.assertEqual(extract_tags(""), set())
        self.assertEqual(extract_tags(None), set())

    def test_texte_sans_jeton_renvoie_un_ensemble_vide(self):
        self.assertEqual(
            extract_tags("Bonjour à toutes et tous"),
            set(),
        )

    def test_jetons_multiples_sont_extraits(self):
        self.assertEqual(
            extract_tags("[% nom %] et [% email %]"),
            {"nom", "email"},
        )

    def test_occurrences_répétées_sont_dédupliquées(self):
        """Un même jeton plusieurs fois ne sort qu'une fois (set)."""
        self.assertEqual(
            extract_tags("[% nom %] [% nom %] [% nom %]"),
            {"nom"},
        )

    def test_espaces_dans_le_jeton_normalisés_à_la_capture(self):
        """Les espaces autour de la clé sont strippés dans la sortie."""
        self.assertEqual(
            extract_tags("[%   nom   %] [% email%]"),
            {"nom", "email"},
        )

    def test_tiret_et_point_ne_sont_pas_capturés(self):
        """`a-b` et `a.b` ne sont pas des jetons valides."""
        self.assertEqual(
            extract_tags("[% a-b %] [% a.b %]"),
            set(),
        )

    def test_mélange_connu_et_inconnu(self):
        """L'extraction ne distingue pas connu/inconnu — c'est le
        rôle du validateur de formulaires plus tard."""
        self.assertEqual(
            extract_tags("[% nom %] [% fantome %]"),
            {"nom", "fantome"},
        )
