"""Tests du module `emailing`."""
