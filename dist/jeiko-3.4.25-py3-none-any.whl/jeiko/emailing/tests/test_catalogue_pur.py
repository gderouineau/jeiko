"""
Contrats purs du catalogue d'e-mails `emailing/registry.py` :
`get_event`, `event_choices`, `available_variables`, `variable_keys`,
`is_transactional`, `events_by_category`, `is_mandatory`,
`mandatory_reason`.

Aucun modèle enregistré, aucune instance `EmailTemplate`. Les
modifications de `EMAIL_EVENTS` ou `GLOBAL_VARIABLES` pour tester
une collision de variable propre / globale sont faites via
`patch.dict` dans un contexte qui restaure l'état du module —
la source du catalogue n'est jamais modifiée de façon persistante.

Ce que ces tests ne vérifient pas
---------------------------------
- Aucun nombre figé d'événements : un ajout futur au catalogue
  ne fait pas échouer les tests tant qu'il respecte les invariants.
- Les libellés et descriptions ne sont pas figés mot pour mot ;
  on compare des clés ou ensembles, pas des snapshots massifs.
"""

from unittest.mock import patch

from django.test import SimpleTestCase

from jeiko.emailing import registry


# ---------- get_event ----------


class GetEventTests(SimpleTestCase):
    """Lecture directe d'un événement au catalogue."""

    def test_code_inconnu_retourne_none(self):
        self.assertIsNone(registry.get_event("n importe quoi"))

    def test_code_connu_retourne_son_dict(self):
        """Un code connu rend le dict complet de l'événement."""
        ev = registry.get_event("password_reset_request")
        self.assertIsNotNone(ev)
        self.assertIn("label", ev)
        self.assertIn("category", ev)
        self.assertIn("audience", ev)
        self.assertIn("variables", ev)

    def test_variables_propres_sont_un_dict(self):
        """Les variables propres sont un dict clé → description."""
        ev = registry.get_event("password_reset_request")
        self.assertIn("lien_action", ev["variables"])
        self.assertIsInstance(ev["variables"]["lien_action"], str)


# ---------- event_choices ----------


class EventChoicesTests(SimpleTestCase):
    """Choices Django groupés par catégorie, dans l'ordre."""

    def test_choices_groupes_par_categories(self):
        """event_choices rend des groupes (label, choix), pas une
        liste plate — chaque groupe est non vide pour les catégories
        effectivement présentes."""
        groups = registry.event_choices()
        self.assertIsInstance(groups, list)
        self.assertGreater(len(groups), 0)
        for group in groups:
            label, choices = group
            self.assertIsInstance(label, str)
            self.assertGreater(len(label), 0)
            self.assertIsInstance(choices, list)
            self.assertGreater(len(choices), 0)

    def test_tous_les_codes_du_catalogue_apparaissent(self):
        """L'union des `(code, label)` dans tous les groupes doit
        couvrir exactement l'ensemble des codes d'EMAIL_EVENTS."""
        groups = registry.event_choices()
        codes_dans_choices = {code for _, choices in groups for code, _ in choices}
        self.assertEqual(codes_dans_choices, set(registry.EMAIL_EVENTS.keys()))


# ---------- available_variables / variable_keys ----------


class AvailableVariablesTests(SimpleTestCase):
    """Variables propres + globales, sans doublon, propres d'abord."""

    def test_proprietes_et_globales_sans_doublon(self):
        """`available_variables(code)` rend propres d'abord, puis
        globales, et chaque clé apparaît au plus une fois."""
        for code in ["account_welcome", "password_reset_request",
                     "order_confirmation"]:
            with self.subTest(code=code):
                variables = registry.available_variables(code)
                keys = [v["key"] for v in variables]
                self.assertEqual(
                    len(keys), len(set(keys)),
                    f"Doublons dans available_variables({code!r})",
                )
                propres = set(registry.get_event(code)["variables"].keys())
                self.assertTrue(
                    propres.issubset(set(keys)),
                    f"Variables propres manquantes pour {code!r}",
                )

    def test_toutes_les_propres_precedent_toutes_les_globales(self):
        """La séquence rendue par `available_variables` doit
        contenir TOUTES les propres AVANT la première globale —
        pas seulement la première propre avant la première globale.
        On vérifie cela par un découpage d'indice : la liste
        `keys` doit pouvoir être coupée en deux segments
        contigus, le premier 100% propres, le second 100%
        globales (et aucun autre découpage ne peut marcher)."""
        code = "password_reset_request"
        variables = registry.available_variables(code)
        keys = [v["key"] for v in variables]
        propres = set(registry.get_event(code)["variables"].keys())
        globales = set(registry.GLOBAL_VARIABLES.keys()) - propres

        # Toutes les propres doivent précéder toute globale.
        idx_max_propre = max(
            (keys.index(k) for k in propres if k in keys),
            default=-1,
        )
        idx_min_globale = min(
            (keys.index(k) for k in globales if k in keys),
            default=len(keys),
        )
        self.assertLess(
            idx_max_propre, idx_min_globale,
            "Au moins une globale apparaît avant une propre dans la "
            "séquence rendue par available_variables().",
        )

    def test_code_inconnu_rend_les_variables_globales(self):
        """Pas d'événement → pas de propres ; toutes les globales."""
        variables = registry.available_variables("code_inconnu")
        propres = [v for v in variables if v["scope"] == "event"]
        globals_ = [v for v in variables if v["scope"] == "global"]
        self.assertEqual(propres, [])
        self.assertGreater(len(globals_), 0)

    def test_variable_keys_contient_propres_et_globales(self):
        """variable_keys() retourne l'ensemble des clés autorisées."""
        keys = registry.variable_keys("password_reset_request")
        self.assertIn("lien_action", keys)  # propre
        self.assertIn("site_nom", keys)     # globale
        self.assertIsInstance(keys, set)

    def test_collision_propre_globale_propre_l_emporte_valeur_et_description(self):
        """Quand une clé figure à la fois en propre et en globale,
        c'est la valeur ET la description propres qui doivent
        l'emporter dans `available_variables` — pas seulement
        le scope. Couvre la priorité de la valeur, pas seulement
        le marqueur scope.

        `patch.dict` est utilisé dans un `with`, ce qui restaure
        l'état du module à la sortie — la source du catalogue
        n'est jamais modifiée de façon persistante."""
        event_code = "account_welcome"
        propre_description = registry.get_event(event_code)["variables"]["lien_action"]
        with patch.dict(
            registry.GLOBAL_VARIABLES,
            {"lien_action": "Trompeuse"}, clear=False,
        ):
            variables = registry.available_variables(event_code)
            scopes_par_cle = {v["key"]: v["scope"] for v in variables}
            # Priorité du scope : 'event' et non 'global'.
            self.assertEqual(
                scopes_par_cle.get("lien_action"), "event",
                "La variable propre doit l'emporter sur la globale.",
            )
            # Priorité de la valeur : c'est la description propre
            # qui est utilisée, pas la chaîne "Trompeuse" injectée.
            entries = [v for v in variables if v["key"] == "lien_action"]
            self.assertEqual(len(entries), 1)
            self.assertEqual(
                entries[0]["description"], propre_description,
                "La description propre doit primer sur la globale.",
            )


# ---------- is_transactional ----------
class IsTransactionalTests(SimpleTestCase):
    """Décide si l'envoi ignore les préférences marketing."""

    def test_code_inconnu_est_traite_comme_transactionnel(self):
        """Un code inconnu est True — mieux vaut envoyer par défaut."""
        self.assertTrue(registry.is_transactional("code_inconnu"))

    def test_marketing_n_est_pas_transactionnel(self):
        """Seule la catégorie MARKETING n'est pas transactionnelle :
        account, appointment, test, course, shop, site, internal
        sont dans TRANSACTIONAL_CATEGORIES."""
        for code in ["birthday_wishes", "nps_survey",
                     "reactivation", "campaign_manual"]:
            with self.subTest(code=code):
                self.assertFalse(
                    registry.is_transactional(code),
                    f"{code} classé marketing doit être non transactionnel",
                )

    def test_account_et_shop_sont_transactionnels(self):
        """Account et shop sont transactionnels (accès, preuves d'achat)."""
        self.assertTrue(registry.is_transactional("password_reset_request"))
        self.assertTrue(registry.is_transactional("order_confirmation"))
        self.assertTrue(registry.is_transactional("payment_received"))


# ---------- events_by_category ----------


class EventsByCategoryTests(SimpleTestCase):
    """Catalogue groupé pour les écrans de liste."""

    def test_retourne_une_liste_de_groupes(self):
        groups = registry.events_by_category()
        self.assertIsInstance(groups, list)
        self.assertGreater(len(groups), 0)

    def test_chaque_groupe_a_une_cle_un_libelle_et_des_evenements(self):
        groups = registry.events_by_category()
        for category_key, category_label, events in groups:
            self.assertIsInstance(category_key, str)
            self.assertIsInstance(category_label, str)
            self.assertGreater(len(category_label), 0)
            self.assertGreater(len(events), 0)
            for code, ev in events:
                self.assertIn("category", ev)
                self.assertEqual(
                    ev["category"], category_key,
                    f"{code} classé dans {ev['category']!r} "
                    f"mais le groupe est {category_key!r}",
                )

    def test_categories_connues_apparaissent(self):
        """Les catégories effectivement utilisées dans EMAIL_EVENTS
        apparaissent dans le groupement."""
        groups = registry.events_by_category()
        categories_vues = [key for key, _, _ in groups]
        categories_présentes = {
            ev["category"] for ev in registry.EMAIL_EVENTS.values()
        }
        for cat in categories_présentes:
            self.assertIn(
                cat, categories_vues,
                f"Catégorie {cat!r} absente du groupement",
            )


# ---------- is_mandatory / mandatory_reason ----------


class IsMandatoryTests(SimpleTestCase):
    """E-mails dont la désactivation est interdite."""

    def test_les_codes_obligatoires_sont_reconnus(self):
        for code in ["password_reset_request", "twofa_code",
                     "account_email_verify", "email_change_confirm",
                     "account_created_by_admin", "order_confirmation",
                     "payment_received", "password_changed",
                     "email_changed_alert", "twofa_enabled",
                     "twofa_disabled", "account_deactivated"]:
            with self.subTest(code=code):
                self.assertTrue(registry.is_mandatory(code))

    def test_le_marketing_n_est_pas_obligatoire(self):
        for code in ["birthday_wishes", "nps_survey",
                     "reactivation", "campaign_manual"]:
            with self.subTest(code=code):
                self.assertFalse(registry.is_mandatory(code))

    def test_code_inconnu_n_est_pas_obligatoire(self):
        """Un code inexistant n'est pas dans MANDATORY_CODES."""
        self.assertFalse(registry.is_mandatory("code_inconnu"))

    def test_chaque_code_obligatoire_existe_au_catalogue(self):
        """Aucun code obligatoire ne pointe vers un événement
        absent d'EMAIL_EVENTS — invariant de cohérence."""
        inconnus = [
            c for c in registry.MANDATORY_CODES
            if c not in registry.EMAIL_EVENTS
        ]
        self.assertEqual(inconnus, [],
                         f"Codes obligatoires inexistants : {inconnus}")

    def test_mandatory_reason_non_vide_pour_chaque_obligatoire(self):
        """Tout code obligatoire a une raison affichée à l'admin."""
        for code in registry.MANDATORY_CODES:
            with self.subTest(code=code):
                self.assertTrue(
                    registry.mandatory_reason(code),
                    f"{code} : raison vide",
                )

    def test_mandatory_reason_vide_pour_un_non_obligatoire(self):
        """Un code non obligatoire n'a pas de raison (sinon l'admin
        verrait un cadenas trompeur)."""
        self.assertEqual(registry.mandatory_reason("birthday_wishes"), "")
        self.assertEqual(registry.mandatory_reason("campaign_manual"), "")
        self.assertEqual(registry.mandatory_reason("code_inconnu"), "")

    def test_mandatory_reason_distincte_par_groupe(self):
        """Les trois familles (accès, achat, sécurité) ont des
        raisons distinctes — la raison est porteuse de sens."""
        raisons = {
            registry.mandatory_reason("password_reset_request"),
            registry.mandatory_reason("order_confirmation"),
            registry.mandatory_reason("password_changed"),
        }
        self.assertEqual(
            len(raisons), 3,
            f"Raisons non distinctes : {raisons}",
        )
