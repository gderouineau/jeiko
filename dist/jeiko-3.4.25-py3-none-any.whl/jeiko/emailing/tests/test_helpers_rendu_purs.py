"""
Contrats purs des helpers `_box`, `_color`, `_hex_color`,
`column_widths`, `html_to_text` de `emailing/render.py`.

Aucune base, ORM, client HTTP, ni lecture de settings (`render.py`
charge `settings` à l'import via `EMAIL_WIDTH` et des
context_processors ; les helpers testés ici ne lisent pas de
modèle — on ne déclenche donc pas de queryset).

On utilise `SimpleNamespace` pour les objets de style et de ligne,
afin de ne pas dépendre des modèles `Section`/`Line`.

Les attendus sont calculés indépendamment du code de
production : on ne se contente pas de rejouer la formule. Si une
entrée de bord révèle un défaut existant, on le consigne dans le
journal sans modifier la production et sans écrire un faux test
de réussite.
"""

from types import SimpleNamespace

from django.test import SimpleTestCase

from jeiko.emailing.render import (
    _box,
    _color,
    _hex_color,
    column_widths,
    html_to_text,
)


# ---------- _box ----------


class BoxHelperTests(SimpleTestCase):
    """Mise en forme des paddings/marges."""

    def test_none_retourne_none(self):
        self.assertIsNone(_box(None))

    def test_les_quatre_côtés_nuls_retournent_none(self):
        """Les quatre côtés à 0 (ou '0'/'0px') sont fusionnés en None
        pour ne pas polluer le style inline."""
        stylebox = SimpleNamespace(top="0", right="0", bottom="0", left="0")
        self.assertIsNone(_box(stylebox))
        stylebox = SimpleNamespace(top="0px", right="0px", bottom="0px", left="0px")
        self.assertIsNone(_box(stylebox))

    def test_valeurs_numériques_deviennent_px(self):
        """Une valeur numérique nue (ex. '10') est interprétée comme px."""
        stylebox = SimpleNamespace(top="10", right="20", bottom="30", left="40")
        self.assertEqual(_box(stylebox), "10px 20px 30px 40px")

    def test_unités_css_sont_conservées_mais_zero_devient_0px(self):
        """Une valeur déjà munie d'une unité CSS (em, %, rem…) est
        laissée telle quelle. En revanche, la chaîne `0` est
        convertie en `0px` (`.isdigit()` matche), même si on
        s'attendrait à `0` brut — c'est un détail du helper."""
        stylebox = SimpleNamespace(top="2em", right="50%", bottom="0", left="1rem")
        self.assertEqual(_box(stylebox), "2em 50% 0px 1rem")

    def test_ordre_top_right_bottom_left(self):
        """L'ordre de sortie est haut, droite, bas, gauche,
        indépendamment de l'ordre de définition de l'objet."""
        stylebox = SimpleNamespace(left="1", top="2", right="3", bottom="4")
        self.assertEqual(_box(stylebox), "2px 3px 4px 1px")

    def test_valeur_manquante_devient_0px(self):
        """Si un attribut est absent, la valeur tombe à '0' qui
        passe par `isdigit()` et ressort `0px` — confirmé par le
        helper, c'est le format qu'il émet."""
        stylebox = SimpleNamespace(top="10", right="0")  # pas bottom/left
        self.assertEqual(_box(stylebox), "10px 0px 0px 0px")


# ---------- _color ----------


class ColorHelperTests(SimpleTestCase):
    """Filtre des couleurs totalement transparentes pour Outlook."""

    def test_chaine_vide_retourne_chaine_vide(self):
        self.assertEqual(_color(""), "")
        self.assertEqual(_color(None), "")

    def test_rouge_pur_est_conserve(self):
        """Le rouge pur finit par `,0)` — son bleu, pas un alpha.

        Le helper testait `endswith(",0)")` et le rendait donc
        absent de l'e-mail. Ce test verrouille la correction : un
        `rgb()` a trois composantes, aucune n'est un canal alpha."""
        self.assertEqual(_color("rgb(255, 0, 0)"), "rgb(255, 0, 0)")
        self.assertEqual(_color("rgb(0, 128, 0)"), "rgb(0, 128, 0)")

    def test_rgba_avec_alpha_zero_est_transparent(self):
        """Couverture directe du contrat visé par le helper :
        `rgba(r, g, b, 0)` est transparent et doit retourner
        `""`. C'est le CAS QUE LE HELPER VISE ; sa sélectivité
        est trop large (cf. test précédent), mais ce cas doit
        fonctionner."""
        self.assertEqual(_color("rgba(0, 0, 0, 0)"), "")
        self.assertEqual(_color("rgba(255, 255, 255, 0)"), "")

    def test_vert_pur_est_conserve(self):
        """Même piège que le rouge : le 0 final est le bleu."""
        self.assertEqual(_color("rgb(0, 255, 0)"), "rgb(0, 255, 0)")

    def test_alpha_nul_est_transparent_quelle_que_soit_son_ecriture(self):
        """Un alpha vaut 0 aussi écrit `0.0`, `.0` ou `0%`."""
        for ecriture in ("0", "0.0", ".0", "0%", "0.00"):
            with self.subTest(alpha=ecriture):
                self.assertEqual(_color(f"rgba(12, 34, 56, {ecriture})"), "")
        self.assertEqual(_color("hsla(120, 50%, 50%, 0)"), "")

    def test_rgb_avec_dernier_composant_non_nul_est_conserve(self):
        """Couverture du cas non-alpha-zéro : `rgb(255, 0, 1)` ne
        se termine pas par `,0)` — le helper laisse passer."""
        self.assertEqual(_color("rgb(255, 0, 1)"), "rgb(255, 0, 1)")

    def test_couleur_hex_est_conservee(self):
        """Une couleur hexadécimale est laissée telle quelle."""
        self.assertEqual(_color("#ff0000"), "#ff0000")

    def test_couleur_avec_alpha_non_nul_est_conservee(self):
        """Un alpha différent de zéro passe — la chaîne ne se
        termine pas par `,0)`."""
        self.assertEqual(_color("rgba(0, 0, 0, 0.5)"), "rgba(0, 0, 0, 0.5)")


# ---------- _hex_color ----------

class HexColorHelperTests(SimpleTestCase):
    """Conversion en hex pour l'attribut bgcolor d'Outlook."""

    def test_chaine_vide_retourne_chaine_vide(self):
        self.assertEqual(_hex_color(""), "")
        self.assertEqual(_hex_color(None), "")

    def test_couleur_hex_est_conservee_telle_quelle(self):
        self.assertEqual(_hex_color("#ff0000"), "#ff0000")
        self.assertEqual(_hex_color("#00ff00"), "#00ff00")
        self.assertEqual(_hex_color("#0000ff"), "#0000ff")

    def test_rgb_dont_dernier_composant_non_zero_est_converti(self):
        """`rgb(255, 0, 1)` ne se termine pas par `,0)` : conversion."""
        self.assertEqual(_hex_color("rgb(255, 0, 1)"), "#ff0001")

    def test_rgba_avec_alpha_non_nul_est_converti(self):
        self.assertEqual(_hex_color("rgba(255, 0, 0, 0.5)"), "#ff0000")

    def test_rgba_avec_alpha_zero_retourne_chaine_vide(self):
        """`alpha=0` doit retourner '' — filtré via `_color`."""
        self.assertEqual(_hex_color("rgba(0, 0, 0, 0)"), "")

    def test_couleur_nommée_est_conservee(self):
        """Une couleur non reconnue par RGB_PATTERN est laissée
        telle quelle — bgcolor accepte les couleurs nommées."""
        self.assertEqual(_hex_color("white"), "white")
        self.assertEqual(_hex_color("red"), "red")

    def test_rgb_opaque_dont_le_bleu_est_nul_est_converti(self):
        """`_hex_color` passe par `_color` : le filtre trop large
        privait `bgcolor` du rouge et du vert, c'est-à-dire de
        l'attribut même qu'Outlook lit pour peindre un <td>."""
        self.assertEqual(_hex_color("rgb(255, 0, 0)"), "#ff0000")
        self.assertEqual(_hex_color("rgb(0, 255, 0)"), "#00ff00")
        self.assertEqual(_hex_color("rgb(0, 0, 255)"), "#0000ff")


# ---------- column_widths ----------


class ColumnWidthsTests(SimpleTestCase):
    """Conversion de `columns_type` en pourcentages par colonne."""

    def _line(self, columns_type, columns_number=1):
        return SimpleNamespace(columns_type=columns_type, columns_number=columns_number)
    def test_chaine_12_rend_100_pour_cent(self):
        self.assertEqual(column_widths(self._line("12")), ["100"])

    def test_chaine_6_6_rend_deux_colonnes_egales(self):
        self.assertEqual(column_widths(self._line("6-6")), ["50", "50"])

    def test_chaine_3_9_rend_25_et_75_pour_cent(self):
        self.assertEqual(column_widths(self._line("3-9")), ["25", "75"])

    def test_chaine_4_4_4_rend_trois_largeurs_egales_arrondies(self):
        """Trois colonnes 4-4-4 : la SOMME des valeurs arrondies
        peut NE PAS tomber juste à 100 (arrondi flottant 4*100/12
        ≈ 33.3333 répété trois fois ≈ 99.9999). On ne vérifie
        donc PAS l'égalité stricte de la somme à 100 : on vérifie
        que les trois largeurs sont identiques et valent le
        arrondi à 4 décimales attendu."""
        widths = column_widths(self._line("4-4-4"))
        self.assertEqual(len(widths), 3)
        for w in widths:
            self.assertEqual(w, widths[0])  # toutes identiques
        # Chaque largeur vaut (4*100/12) ≈ 33.3333 → '33.3333'.
        self.assertEqual(widths[0], "33.3333")
        widths = column_widths(self._line("3-3-3-3"))
        self.assertEqual(widths, ["25", "25", "25", "25"])

    def test_chaine_avec_point_décimal_est_préservée(self):
        """Les largeurs renvoyées sont des chaînes ; le format
        `:.4f` produit un point décimal, jamais une virgule (même
        en locale fr-fr, le formatage Python utilise le point)."""
        widths = column_widths(self._line("4-4-4"))
        for w in widths:
            self.assertNotIn(",", w, f"Largeur {w!r} ne doit pas contenir de virgule")

    def test_chaine_vide_et_columns_number(self):
        """Sans `columns_type`, on retombe sur le calcul à partir
        de `columns_number`. Pour `columns_number=3`, on attend
        trois colonnes de 4."""
        self.assertEqual(
            column_widths(self._line("", columns_number=3)),
            ["33.3333", "33.3333", "33.3333"],
        )

    def test_chaine_invalide_et_columns_number(self):
        """`columns_type` non numérique + `columns_number=2` :
        on retombe sur `[12//2]*2 = [6, 6]`."""
        self.assertEqual(
            column_widths(self._line("abc", columns_number=2)),
            ["50", "50"],
        )


# ---------- html_to_text ----------


class HtmlToTextTests(SimpleTestCase):
    """Conversion HTML → texte brut, version e-mail."""

    def test_chaine_vide_retourne_chaine_vide(self):
        self.assertEqual(html_to_text(""), "")
        self.assertEqual(html_to_text(None), "")

    def test_supprime_head_script_et_style(self):
        """`<script>` et `<style>` sont retirés avant tout
        post-traitement : leur contenu ne doit jamais apparaître."""
        html = (
            "<html><head>"
            "<style>body { color: red; }</style>"
            "<script>alert('x')</script>"
            "</head><body><p>OK</p></body></html>"
        )
        out = html_to_text(html)
        self.assertNotIn("alert", out)
        self.assertNotIn("color: red", out)
        self.assertIn("OK", out)

    def test_balises_br_introduisent_un_saut_de_ligne_entre_textes(self):
        """`<br>` doit produire un saut de ligne ENTRE les deux
        textes — pas juste leur présence. Sans ce contrôle, un
        helper qui joint par un espace passerait le test."""
        out = html_to_text("<p>Ligne 1<br>Ligne 2</p>")
        self.assertIn("Ligne 1\nLigne 2", out)

    def test_balises_de_bloc_introduisent_une_nouvelle_ligne(self):
        """`</p>`, `</div>`, `</tr>`, `</h1-6>`, `</li>`, `</table>`
        introduisent un saut de ligne entre les blocs, pas un simple
        retour à la ligne final (le strip final masquerait la
        marque). On vérifie donc qu'avec DEUX blocs le séparateur
        apparaît entre eux."""
        for tag in ("p", "div", "tr", "h2", "li", "table"):
            with self.subTest(tag=tag):
                html = f"<{tag}>A</{tag}><{tag}>B</{tag}>"
                out = html_to_text(html)
                self.assertIn("A\nB", out)

    def test_entités_html_sont_décodées(self):
        """`&eacute;`, `&amp;`, etc. sont décodées."""
        out = html_to_text("<p>Caf&eacute; &amp; th&eacute;</p>")
        self.assertIn("Café", out)
        self.assertIn("&", out)
        self.assertIn("thé", out)

    def test_lien_conserve_texte_et_url(self):
        """Un `<a href="URL">texte</a>` devient `texte (URL)`."""
        out = html_to_text(
            '<body><p>Voir <a href="https://exemple.fr/page">ma page</a>.</p></body>'
        )
        self.assertIn("ma page", out)
        self.assertIn("https://exemple.fr/page", out)
        self.assertIn("ma page (https://exemple.fr/page)", out)

    def test_liens_vides_dans_html(self):
        """Un `<a>` sans texte affiche juste l'URL entre parenthèses."""
        out = html_to_text('<body><a href="https://exemple.fr/x"></a></body>')
        self.assertIn("https://exemple.fr/x", out)

    def test_lignes_vides_consecutives_sont_plafonnées(self):
        """Plus de deux sauts de ligne consécutifs sont ramenés à deux."""
        out = html_to_text("<p>A</p>\n\n\n\n\n<p>B</p>")
        self.assertNotIn("\n\n\n", out)

    def test_hors_body_est_ignoré(self):
        """Le contenu hors `<body>` (header, doctype…) ne doit pas
        apparaître en texte."""
        html = (
            "<html><head><title>Ne pas lire</title></head>"
            "<body><p>Lu</p></body></html>"
        )
        out = html_to_text(html)
        self.assertIn("Lu", out)
        self.assertNotIn("Ne pas lire", out)

    def test_strip_final(self):
        """Le résultat est strippé — pas d'espace ou newline final."""
        out = html_to_text("<body><p>Texte</p>\n\n\n</body>")
        self.assertFalse(out.endswith("\n"))
        self.assertFalse(out.endswith(" "))
