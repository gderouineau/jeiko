"""Tests du module `cookies`."""
