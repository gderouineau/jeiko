"""
Contrats purs des helpers `_validate_cookie_prefix_constraints`
et `_locale_choices` de `cookies/forms.py`.

Aucun modèle, aucune requête ORM, aucun client HTTP : ces tests
appellent directement les deux fonctions pour verrouiller leur
comportement réel, indépendamment des formulaires qui les utilisent.

Pourquoi ce fichier
-------------------
Les préfixes `__Host-` et `__Secure-` portent une grammaire stricte
(RFC 6265 bis). Un cookie mal nommé peut être refusé par le navigateur
sans qu'aucune erreur ne remonte côté Django : c'est un cookie qui
semble s'écrire et qui n'est jamais relu. Chaque contrainte du préfixe
`__Host-` (Secure, host-only, Path, Domain) est silencieuse quand elle
est violée — il n'y a que la stricte lecture du code pour la voir.

`_locale_choices` alimente les `ChoiceField` de plusieurs formulaires
de l'app ; un couple (code_minuscule, libellé) qui dérive casse la liste
déroulante sans erreur visible. Ces tests ferment ces deux issues sans
dépendre d'un formulaire complet ni d'une instance enregistrée.
"""

from django.core.exceptions import ValidationError
from django.test import SimpleTestCase, override_settings

from jeiko.cookies.forms import (
    _locale_choices,
    _validate_cookie_prefix_constraints,
)


# ---------- _validate_cookie_prefix_constraints ----------


class ValidateCookiePrefixConstraintsTests(SimpleTestCase):
    """
    Chaque méthode isole une contrainte. Le helper lève `ValidationError`
    dès la première violation rencontrée (ordre : Secure, Domain,
    Path, host-only) ; on vérifie donc que le message d'erreur identifie
    la contrainte, sans figer toute sa ponctuation.
    """

    # --- Conformité d'un `__Host-` ---------------------------------------

    def test_host_valide_accepte(self):
        """Un `__Host-` conforme (Secure=True, path='/', host_only=True,
        domain vide) ne lève pas."""
        cleaned = {
            "is_secure": True,
            "host_only": True,
            "path": "/",
            "domain": "",
        }
        # Doit retourner silencieusement.
        result = _validate_cookie_prefix_constraints("__Host-session", cleaned)
        self.assertIsNone(result)

    # --- Les quatre violations `__Host-` --------------------------------

    def test_host_refuse_quand_secure_false(self):
        cleaned = {
            "is_secure": False,
            "host_only": True,
            "path": "/",
            "domain": "",
        }
        with self.assertRaises(ValidationError) as ctx:
            _validate_cookie_prefix_constraints("__Host-session", cleaned)
        self.assertIn("Secure", str(ctx.exception))

    def test_host_refuse_quand_domain_renseigne(self):
        cleaned = {
            "is_secure": True,
            "host_only": True,
            "path": "/",
            "domain": "example.com",
        }
        with self.assertRaises(ValidationError) as ctx:
            _validate_cookie_prefix_constraints("__Host-session", cleaned)
        # Le message courant mentionne à la fois "Domain" et "host-only".
        msg = str(ctx.exception)
        self.assertTrue(
            "Domain" in msg or "host-only" in msg,
            f"Message attendu évoquant Domain ou host-only, obtenu : {msg!r}",
        )

    def test_host_refuse_quand_path_different_de_slash(self):
        cleaned = {
            "is_secure": True,
            "host_only": True,
            "path": "/admin",
            "domain": "",
        }
        with self.assertRaises(ValidationError) as ctx:
            _validate_cookie_prefix_constraints("__Host-session", cleaned)
        self.assertIn("Path", str(ctx.exception))

    def test_host_refuse_quand_pas_host_only(self):
        """host_only=False sans domain renseigné : c'est le 4ᵉ check
        (host-only) qui doit lever."""
        cleaned = {
            "is_secure": True,
            "host_only": False,
            "path": "/",
            "domain": "",
        }
        with self.assertRaises(ValidationError) as ctx:
            _validate_cookie_prefix_constraints("__Host-session", cleaned)
        self.assertIn("host-only", str(ctx.exception))

    # --- Comportements périphériques sur `__Host-` -----------------------

    def test_host_traite_domaine_espaces_comme_vide(self):
        """Un domain réduit à des espaces est blanchi par le helper
        avant tout contrôle ; un `__Host-` reste valide."""
        cleaned = {
            "is_secure": True,
            "host_only": True,
            "path": "/",
            "domain": "   ",
        }
        result = _validate_cookie_prefix_constraints("__Host-session", cleaned)
        self.assertIsNone(result)

    def test_host_path_manquant_devient_slash(self):
        """Si `path` est absent ou falsy, le helper retombe sur '/'
        avant la vérification de préfixe."""
        cleaned = {
            "is_secure": True,
            "host_only": True,
            "path": None,
            "domain": "",
        }
        result = _validate_cookie_prefix_constraints("__Host-session", cleaned)
        self.assertIsNone(result)

    # --- `__Secure-` : Secure=True seulement ------------------------------

    def test_secure_exige_secure_true(self):
        cleaned = {
            "is_secure": False,
            "host_only": True,
            "path": "/",
            "domain": "",
        }
        with self.assertRaises(ValidationError) as ctx:
            _validate_cookie_prefix_constraints("__Secure-token", cleaned)
        self.assertIn("Secure", str(ctx.exception))

    def test_secure_n_impose_pas_host_only(self):
        """`__Secure-` n'exige PAS host-only."""
        cleaned = {
            "is_secure": True,
            "host_only": False,
            "path": "/",
            "domain": "",
        }
        result = _validate_cookie_prefix_constraints("__Secure-token", cleaned)
        self.assertIsNone(result)

    def test_secure_n_impose_pas_path_slash(self):
        """`__Secure-` accepte un path arbitraire."""
        cleaned = {
            "is_secure": True,
            "host_only": True,
            "path": "/admin",
            "domain": "",
        }
        result = _validate_cookie_prefix_constraints("__Secure-token", cleaned)
        self.assertIsNone(result)

    def test_secure_accepte_domain_et_path_arbitraires(self):
        """`__Secure-` accepte domain non vide ET path != '/'."""
        cleaned = {
            "is_secure": True,
            "host_only": False,
            "path": "/admin",
            "domain": "example.com",
        }
        result = _validate_cookie_prefix_constraints("__Secure-token", cleaned)
        self.assertIsNone(result)

    # --- Nom sans préfixe -----------------------------------------------

    def test_nom_ordinaire_sans_contraintes_de_prefixe(self):
        """Un nom sans `__Host-` ni `__Secure-` n'est pas concerné par
        ce helper, même si Secure=False, le domain est défini, etc.
        ATTENTION : cela ne dit rien du formulaire complet, qui peut
        imposer ses propres règles (cf. CookieDefinitionForm)."""
        cleaned = {
            "is_secure": False,
            "host_only": False,
            "path": "/admin",
            "domain": "example.com",
        }
        result = _validate_cookie_prefix_constraints("session", cleaned)
        self.assertIsNone(result)


# ---------- _locale_choices ----------


class LocaleChoicesTests(SimpleTestCase):
    """
    Choix de locale utilisés par les `ChoiceField` des formulaires
    cookies. `override_settings` isole chaque scénario sans modifier
    la configuration globale.
    """

    @override_settings(LANGUAGES=[("EN", "Anglais"), ("FR", "Français")])
    def test_languages_minuscule_libelle_conserve(self):
        """LANGUAGES non vide : code abaissé en minuscule, libellé
        conservé tel quel, ordre préservé."""
        result = list(_locale_choices())
        self.assertEqual(result, [("en", "Anglais"), ("fr", "Français")])

    @override_settings(LANGUAGES=[])
    def test_languages_vide_retombe_sur_language_code(self):
        """LANGUAGES falsy (liste vide) : on retombe sur LANGUAGE_CODE."""
        with override_settings(LANGUAGE_CODE="en"):
            result = list(_locale_choices())
        self.assertEqual(result, [("en", "en")])

    @override_settings(LANGUAGES=[], LANGUAGE_CODE="")
    def test_fallback_final_fr_si_language_code_vide(self):
        """LANGUAGES vide ET LANGUAGE_CODE vide : ultime repli sur 'fr'."""
        result = list(_locale_choices())
        self.assertEqual(result, [("fr", "fr")])

    @override_settings(LANGUAGES=[], LANGUAGE_CODE="EN")
    def test_language_code_abaissement_minuscule(self):
        """LANGUAGE_CODE est abaissé en minuscule dans le chemin de repli."""
        result = list(_locale_choices())
        self.assertEqual(result, [("en", "en")])
