"""Sécurité, inventaire et interface de la médiathèque."""

import tempfile
from io import BytesIO

from PIL import Image

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db.models.deletion import ProtectedError
from django.test import TestCase, override_settings
from django.urls import reverse

from jeiko.administration_pages.media_library import (
    delete_image_safely, image_usage_count_map, image_usages,
)
from jeiko.administration_pages.models import (
    Bloc, Content, ContentImage, ImageContent, Line, Page, Section,
)


def image_png(name="image.png", color=(28, 88, 160)):
    stream = BytesIO()
    Image.new("RGB", (8, 6), color).save(stream, format="PNG")
    return SimpleUploadedFile(name, stream.getvalue(), content_type="image/png")


@override_settings(JEIKO_IMAGES_ASYNC=False)
class MediaLibraryTests(TestCase):
    def setUp(self):
        self.media = tempfile.TemporaryDirectory()
        self.settings_override = override_settings(MEDIA_ROOT=self.media.name)
        self.settings_override.enable()
        self.page = Page.objects.create(title="Médiathèque", url_tag="media-relations")

    def tearDown(self):
        self.settings_override.disable()
        self.media.cleanup()

    def structure(self, image=None):
        section = Section.objects.create(page=self.page, position=0, background_image=image)
        ligne = Line.objects.create(section=section, position=0, background_image=image)
        bloc = Bloc.objects.create(line=ligne, position=0, position_in_column=0)
        return section, ligne, bloc

    def test_une_image_peut_etre_le_fond_de_plusieurs_elements(self):
        image = ImageContent.objects.create(alt="Fond partagé")
        section, ligne, _ = self.structure(image)
        self.assertEqual(section.background_image_id, image.pk)
        self.assertEqual(ligne.background_image_id, image.pk)

    def test_supprimer_un_fond_ne_supprime_pas_la_section(self):
        image = ImageContent.objects.create(alt="Fond amovible")
        section = Section.objects.create(page=self.page, position=0, background_image=image)
        image.delete()
        section.refresh_from_db()
        self.assertIsNone(section.background_image_id)
        self.assertTrue(Section.objects.filter(pk=section.pk).exists())

    def test_supprimer_un_bloc_nettoie_le_satellite_sans_supprimer_le_media(self):
        image = ImageContent.objects.create(alt="Image réutilisable")
        _, _, bloc = self.structure()
        satellite = ContentImage.objects.create(image_content=image)
        Content.objects.create(bloc=bloc, content_type="IMAGE", content_image=satellite)

        bloc.delete()

        self.assertFalse(ContentImage.objects.filter(pk=satellite.pk).exists())
        self.assertTrue(ImageContent.objects.filter(pk=image.pk).exists())

    def test_l_inventaire_agrege_tous_les_usages(self):
        image = ImageContent.objects.create(alt="Très partagée")
        self.structure(image)
        groupes = image_usages(image)
        comptes = image_usage_count_map([image])
        self.assertEqual(comptes[image.pk], 2)
        self.assertEqual(sum(groupe.count for groupe in groupes), 2)

    def test_deux_blocs_partagent_un_media_avec_inventaire_et_protection(self):
        image = ImageContent.objects.create(alt="Deux blocs")
        _, ligne, premier = self.structure()
        second = Bloc.objects.create(line=ligne, position=1, position_in_column=0)
        for bloc in (premier, second):
            satellite = ContentImage.objects.create(image_content=image)
            Content.objects.create(bloc=bloc, content_type="IMAGE", content_image=satellite)
        self.assertEqual(image_usage_count_map([image])[image.pk], 2)
        self.assertEqual(sum(usage.count for usage in image_usages(image)), 2)
        self.assertFalse(delete_image_safely(image).deleted)
        with self.assertRaises(ProtectedError):
            image.delete()
        premier.delete()
        second.refresh_from_db()
        self.assertEqual(second.content.content_image.image_content_id, image.pk)
        self.assertEqual(image_usage_count_map([image])[image.pk], 1)
        self.assertFalse(delete_image_safely(image).deleted)
        second.content.reset()
        self.assertEqual(image_usage_count_map([image])[image.pk], 0)
        self.assertTrue(delete_image_safely(image).deleted)

    def test_la_suppression_sure_refuse_un_media_utilise_et_garde_ses_fichiers(self):
        image = ImageContent.objects.create(original_image=image_png(), alt="Protégée")
        nom = image.original_image.name
        self.structure(image)
        resultat = delete_image_safely(image)
        self.assertFalse(resultat.deleted)
        self.assertIn("usage", resultat.message)
        self.assertTrue(ImageContent.objects.filter(pk=image.pk).exists())
        self.assertTrue(image.original_image.storage.exists(nom))

    def test_protect_empeche_aussi_la_suppression_directe_d_un_bloc_image(self):
        image = ImageContent.objects.create(original_image=image_png(), alt="Protégée en base")
        nom = image.original_image.name
        ContentImage.objects.create(image_content=image)
        with self.assertRaises(ProtectedError):
            image.delete()
        self.assertTrue(ImageContent.objects.filter(pk=image.pk).exists())
        self.assertTrue(image.original_image.storage.exists(nom))

    def test_la_suppression_sure_efface_l_image_libre_et_ses_fichiers_apres_commit(self):
        image = ImageContent.objects.create(original_image=image_png(), alt="Libre")
        noms = [
            getattr(image, champ).name
            for champ in ("original_image", "full_size", "computer_size", "laptop_size", "tablet_size", "mobile_size")
            if getattr(image, champ)
        ]
        with self.captureOnCommitCallbacks(execute=True):
            resultat = delete_image_safely(image)
        self.assertTrue(resultat.deleted)
        self.assertFalse(ImageContent.objects.filter(pk=image.pk).exists())
        self.assertTrue(all(not image.original_image.storage.exists(nom) for nom in noms))


@override_settings(JEIKO_IMAGES_ASYNC=False)
class MediaLibraryViewsTests(TestCase):
    def setUp(self):
        self.media = tempfile.TemporaryDirectory()
        self.settings_override = override_settings(MEDIA_ROOT=self.media.name)
        self.settings_override.enable()
        self.user = get_user_model().objects.create_superuser(
            username="media-admin", email="media@example.test", password="secret"
        )
        self.client.force_login(self.user)

    def tearDown(self):
        self.settings_override.disable()
        self.media.cleanup()

    def test_la_liste_et_le_formulaire_sont_accessibles(self):
        self.assertEqual(self.client.get(reverse("jeiko_administration_pages:media_list")).status_code, 200)
        self.assertEqual(self.client.get(reverse("jeiko_administration_pages:media_add")).status_code, 200)

    def test_ajouter_puis_modifier_une_image(self):
        reponse = self.client.post(
            reverse("jeiko_administration_pages:media_add"),
            {"original_image": image_png(), "title": "Hero", "alt": "Premier texte"},
        )
        self.assertEqual(reponse.status_code, 302)
        image = ImageContent.objects.get(alt="Premier texte")
        reponse = self.client.post(
            reverse("jeiko_administration_pages:media_update", args=[image.pk]),
            {"title": "Hero corrigé", "alt": "Texte corrigé"},
        )
        self.assertEqual(reponse.status_code, 302)
        image.refresh_from_db()
        self.assertEqual(image.title, "Hero corrigé")
        self.assertEqual(image.alt, "Texte corrigé")

    def test_l_ecran_refuse_explicitement_la_suppression_d_une_image_utilisee(self):
        image = ImageContent.objects.create(original_image=image_png(), alt="Utilisée")
        page = Page.objects.create(title="Page", url_tag="page-media", main_image=image)
        url = reverse("jeiko_administration_pages:media_delete", args=[image.pk])
        detail = self.client.get(url)
        self.assertContains(detail, "Suppression impossible")
        self.assertContains(detail, str(page.pk))
        reponse = self.client.post(url)
        self.assertEqual(reponse.status_code, 409)
        self.assertTrue(ImageContent.objects.filter(pk=image.pk).exists())

    def test_l_ecran_supprime_une_image_libre(self):
        image = ImageContent.objects.create(original_image=image_png(), alt="Libre")
        reponse = self.client.post(
            reverse("jeiko_administration_pages:media_delete", args=[image.pk])
        )
        self.assertEqual(reponse.status_code, 302)
        self.assertFalse(ImageContent.objects.filter(pk=image.pk).exists())
