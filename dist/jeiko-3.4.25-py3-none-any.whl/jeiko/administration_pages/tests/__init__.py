"""Tests organisés de l'administration des pages."""
