"""Les blocs intégrés héritent des variables du thème public."""

from pathlib import Path

from django.test import SimpleTestCase


class BlocsDynamiquesEtThemeTests(SimpleTestCase):
    def test_les_composants_avec_couleur_de_marque_utilisent_jk_accent(self):
        racine = Path(__file__).resolve().parents[1]
        fichiers = (
            racine / "../templates/administration_pages/content/partials/content_formulaire.html",
            racine / "../templates/administration_pages/content/partials/content_calendar.html",
        )
        for fichier in fichiers:
            with self.subTest(fichier=fichier.name):
                texte = fichier.resolve().read_text(encoding="utf-8")
                self.assertIn("--jk-accent", texte)

