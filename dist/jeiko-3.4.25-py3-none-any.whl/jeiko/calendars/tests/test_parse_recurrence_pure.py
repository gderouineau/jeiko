"""
Contrats purs du helper `_parse_recurrence_block` de `calendars/forms.py`.

Aucun formulaire complet, aucun queryset, aucune instance enregistrée :
on appelle la fonction et on observe le dict qu'elle renvoie.

Ce que ces tests ne vérifient pas
---------------------------------
- Le parseur n'est PAS un aller-retour vers `build_rrulestr` : il
  extrait `freq`, `byday`, `until_date`, `exdates` — sans promettre
  une conservation exacte du format, ni une validation de tout le
  standard iCal.
- Aucun timezone n'est attaché aux dates : `until_date` et les
  `exdates` sont des `date`/`str` au sens « calendrier civil ».
- Les défauts signalés dans le journal (parseur silencieux sur
  UNTIL/EXDATE mal formés) sont verrouillés ici comme contrat, pas
  comme défaut à corriger.
"""

from datetime import date

from django.test import SimpleTestCase

from jeiko.calendars.forms import _parse_recurrence_block


# ---------- défauts et cas vides ----------


class DefautsEtCasVidesTests(SimpleTestCase):
    """Valeur par défaut et chaînes vides ou inutiles."""

    def test_chaine_vide_renvoie_le_dictionnaire_par_defaut(self):
        out = _parse_recurrence_block("")
        self.assertEqual(
            out, {"freq": None, "byday": [], "until_date": None, "exdates": []}
        )

    def test_chaine_avec_espaces_et_lignes_vides_seulement(self):
        """Une chaîne contenant uniquement des espaces/lignes vides
        est traitée comme vide après strip ligne par ligne."""
        out = _parse_recurrence_block("   \n  \n\n   \n")
        self.assertEqual(out["freq"], None)
        self.assertEqual(out["byday"], [])
        self.assertEqual(out["until_date"], None)
        self.assertEqual(out["exdates"], [])

    def test_exdate_est_extrait_meme_sans_rrule(self):
        """Le helper extrait les EXDATE indépendamment de la
        présence de RRULE : le segment EXDATE est parsé par sa
        propre boucle, avant toute contrainte de bloc. Seuls
        `freq`, `byday` et `until_date` restent à leurs défauts
        quand RRULE manque."""
        out = _parse_recurrence_block("EXDATE:20251111T140000Z")
        self.assertEqual(out["freq"], None)
        self.assertEqual(out["byday"], [])
        self.assertEqual(out["until_date"], None)
        self.assertEqual(out["exdates"], ["2025-11-11"])
# ---------- RRULE : DAILY / WEEKLY ----------


class RruleParsingTests(SimpleTestCase):
    """Lecture d'une ligne RRULE et de ses segments."""

    def test_rrule_daily(self):
        out = _parse_recurrence_block("RRULE:FREQ=DAILY")
        self.assertEqual(out["freq"], "DAILY")
        self.assertEqual(out["byday"], [])
        self.assertEqual(out["until_date"], None)

    def test_rrule_weekly_avec_byday(self):
        out = _parse_recurrence_block("RRULE:FREQ=WEEKLY;BYDAY=MO,TU,WE")
        self.assertEqual(out["freq"], "WEEKLY")
        self.assertEqual(out["byday"], ["MO", "TU", "WE"])

    def test_freq_inconnu_reste_none(self):
        """Une FREQ non reconnue (autre que DAILY/WEEKLY) n'est pas
        posée — le parseur ne sait que ces deux-là."""
        out = _parse_recurrence_block("RRULE:FREQ=MONTHLY;BYDAY=MO")
        self.assertEqual(out["freq"], None)
        # BYDAY reste lu même si FREQ n'est pas posée.
        self.assertEqual(out["byday"], ["MO"])

    def test_byday_avec_espaces_est_normalisé(self):
        out = _parse_recurrence_block("RRULE:FREQ=WEEKLY;BYDAY= MO , TU ,WE ")
        self.assertEqual(out["byday"], ["MO", "TU", "WE"])


# ---------- RRULE : UNTIL avec / sans Z ----------


class UntilParsingTests(SimpleTestCase):
    """Lecture du segment UNTIL, en UTC explicite ou local."""

    def test_until_avec_z(self):
        out = _parse_recurrence_block(
            "RRULE:FREQ=DAILY;UNTIL=20251231T235959Z"
        )
        self.assertEqual(out["until_date"], date(2025, 12, 31))

    def test_until_sans_z(self):
        out = _parse_recurrence_block(
            "RRULE:FREQ=DAILY;UNTIL=20251231T235959"
        )
        self.assertEqual(out["until_date"], date(2025, 12, 31))

    def test_until_mal_formé_reste_none(self):
        """UNTIL qui ne respecte pas le format attendu est ignoré
        silencieusement (try/except dans le helper)."""
        out = _parse_recurrence_block(
            "RRULE:FREQ=DAILY;UNTIL=pas-une-date"
        )
        self.assertIsNone(out["until_date"])

    def test_until_date_uniquement(self):
        """UNTIL sans composante horaire complète n'est pas accepté."""
        out = _parse_recurrence_block(
            "RRULE:FREQ=DAILY;UNTIL=20251231"
        )
        self.assertIsNone(out["until_date"])


# ---------- EXDATE ----------


class ExdateParsingTests(SimpleTestCase):
    """Lecture des lignes EXDATE, dans l'ordre du fichier."""

    def test_exdate_unique_avec_z(self):
        out = _parse_recurrence_block(
            "DTSTART:20250101T100000Z\n"
            "RRULE:FREQ=DAILY\n"
            "EXDATE:20251111T140000Z"
        )
        self.assertEqual(out["exdates"], ["2025-11-11"])

    def test_exdates_multiples_ordre_conservé(self):
        """Plusieurs EXDATE : l'ordre d'apparition est conservé,
        chaque date conserve son segment date/heure (mais l'heure
        n'est pas restituée : seul `date().isoformat()` ressort)."""
        out = _parse_recurrence_block(
            "RRULE:FREQ=DAILY\n"
            "EXDATE:20251111T140000Z\n"
            "EXDATE:20251225T080000Z\n"
            "EXDATE:20260101T120000Z"
        )
        self.assertEqual(
            out["exdates"], ["2025-11-11", "2025-12-25", "2026-01-01"]
        )

    def test_exdate_mal_formé_est_ignoré(self):
        """Un EXDATE qui ne respecte pas le format est ignoré
        silencieusement, sans casser les voisins valides."""
        out = _parse_recurrence_block(
            "RRULE:FREQ=DAILY\n"
            "EXDATE:20251111T140000Z\n"
            "EXDATE:pas-une-date\n"
            "EXDATE:20251225T080000Z"
        )
        self.assertEqual(out["exdates"], ["2025-11-11", "2025-12-25"])

    def test_exdate_sans_z(self):
        """Le `Z` final est strippé avant le parsing."""
        out = _parse_recurrence_block(
            "RRULE:FREQ=DAILY\nEXDATE:20251111T140000"
        )
        self.assertEqual(out["exdates"], ["2025-11-11"])


# ---------- bloc complet ----------


class BlocCompletTests(SimpleTestCase):
    """RRULE + BYDAY + UNTIL + EXDATE, combinés."""

    def test_bloc_multi_lignes(self):
        bloc = (
            "DTSTART:20250101T100000Z\n"
            "RRULE:FREQ=WEEKLY;BYDAY=MO,WE,FR;UNTIL=20251231T235959Z\n"
            "EXDATE:20251111T140000Z\n"
            "EXDATE:20251225T080000Z"
        )
        out = _parse_recurrence_block(bloc)
        self.assertEqual(out["freq"], "WEEKLY")
        self.assertEqual(out["byday"], ["MO", "WE", "FR"])
        self.assertEqual(out["until_date"], date(2025, 12, 31))
        self.assertEqual(out["exdates"], ["2025-11-11", "2025-12-25"])
