"""Tests du module `calendars`."""
