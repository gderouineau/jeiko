"""
Contrats purs des helpers `_to_utc_str` et `build_rrulestr` de
`calendars/recurrence.py`.
Aucun modèle, ORM, client HTTP, ni fixture DB. Les datetimes
naïfs sont interprétés par `timezone.override`, ce qui rend les
attendus calculables indépendamment de l'horloge du test runner.

Ce que ces tests ne vérifient pas
---------------------------------
- `_to_utc_str` et `build_rrulestr` ne sont pas un validateur
  complet iCal : ils n'imposent pas une grammaire sur FREQ ni
  sur les jours BYDAY. On ne cherche donc pas à tester un refus
  de FREQ invalide.
- Aucune création de `Slot` ou `Appointment` n'est exercée ici.
"""

from datetime import date, datetime, timedelta, timezone as dt_timezone
from django.test import SimpleTestCase

from django.utils import timezone

from jeiko.calendars.recurrence import _to_utc_str, build_rrulestr


# ---------- _to_utc_str ----------


class ToUtcStrTests(SimpleTestCase):
    """Format iCal UTC (YYYYMMDDTHHMMSSZ), sans perte de secondes."""

    def test_datetime_utc_aware_rendu_en_utc_exact(self):
        """Un datetime aware en UTC sort tel quel, sans conversion."""
        dt = datetime(2026, 3, 15, 14, 30, 45, tzinfo=dt_timezone.utc)
        self.assertEqual(_to_utc_str(dt), "20260315T143045Z")

    def test_datetime_aware_dans_une_autre_timezone_est_converti(self):
        """Un datetime aware non-UTC est converti en UTC."""
        tz_plus_3 = dt_timezone(timedelta(hours=3))
        dt = datetime(2026, 3, 15, 14, 30, 45, tzinfo=tz_plus_3)
        # 14:30+03 == 11:30 UTC
        self.assertEqual(_to_utc_str(dt), "20260315T113045Z")

    def test_datetime_naif_herite_de_la_timezone_courante(self):
        """Par défaut (Europe/Paris), un datetime naïf est rendu en
        UTC selon le décalage hiver/été en vigueur ce jour-là."""
        # Hiver : mars = CET (UTC+1) jusqu'au passage à l'heure d'été.
        # 2024-03-15 est encore en CET.
        with timezone.override("Europe/Paris"):
            self.assertEqual(
                _to_utc_str(datetime(2024, 3, 15, 14, 30, 45)),
                "20240315T133045Z",  # 14:30 Paris = 13:30 UTC
            )

    def test_datetime_naif_en_ete(self):
        """Été : 2024-07-15 est en CEST (UTC+2)."""
        with timezone.override("Europe/Paris"):
            self.assertEqual(
                _to_utc_str(datetime(2024, 7, 15, 14, 30, 45)),
                "20240715T123045Z",  # 14:30 Paris = 12:30 UTC
            )

    def test_datetime_naif_avec_timezone_courante_forcee_utc(self):
        """Si la timezone courante est UTC, le naïf est traité comme
        du UTC ; aucun décalage n'est appliqué."""
        with timezone.override("UTC"):
            self.assertEqual(
                _to_utc_str(datetime(2026, 3, 15, 14, 30, 45)),
                "20260315T143045Z",
            )

    def test_secondes_conservees(self):
        """Aucune seconde perdue, y compris à 0."""
        self.assertEqual(
            _to_utc_str(datetime(2026, 3, 15, 14, 30, 0, tzinfo=dt_timezone.utc)),
            "20260315T143000Z",
        )


# ---------- build_rrulestr ----------


class BuildRrulestrTests(SimpleTestCase):
    """Construction du bloc iCal multi-lignes."""

    def setUp(self):
        # Start en UTC, à une heure/minute/seconde reconnaissables,
        # pour que les EXDATE qui en héritent soient lisibles.
        self.start = datetime(2026, 3, 15, 10, 30, 45, tzinfo=dt_timezone.utc)

    def test_regle_daily_minimale(self):
        """DAILY seul : DTSTART + RRULE, sans BYDAY ni UNTIL ni EXDATE."""
        result = build_rrulestr(start=self.start, freq="DAILY")
        self.assertEqual(
            result,
            "DTSTART:20260315T103045Z\nRRULE:FREQ=DAILY",
        )

    def test_regle_weekly_byday_conservé_dans_l_ordre_passé(self):
        """WEEKLY + byday : BYDAY reprend l'ordre passé, sans tri."""
        result = build_rrulestr(
            start=self.start,
            freq="WEEKLY",
            byday=["MO", "TU", "WE", "TH", "FR"],
        )
        self.assertEqual(
            result,
            "DTSTART:20260315T103045Z\nRRULE:FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR",
        )

    def test_until_date_fin_de_journee_23_59_59_en_utc(self):
        """`until_date` produit 23:59:59 du jour ; pour un attendu
        simple, on force la timezone courante à UTC."""
        with timezone.override("UTC"):
            result = build_rrulestr(
                start=self.start, freq="DAILY", until_date=date(2025, 12, 31)
            )
        self.assertEqual(
            result,
            "DTSTART:20260315T103045Z\n"
            "RRULE:FREQ=DAILY;UNTIL=20251231T235959Z",
        )

    def test_until_date_naif_herite_de_la_timezone_courante(self):
        """Sans override, `until_date` est naïf et hérite de la
        timezone courante au moment de l'appel — c'est un piège
        connu du constructeur, on le verrouille pour qu'un futur
        refactor le signale."""
        with timezone.override("Europe/Paris"):
            result = build_rrulestr(
                start=self.start, freq="DAILY", until_date=date(2025, 12, 31)
            )
        # 31 décembre = hiver → 23:59:59 Paris = 22:59:59 UTC.
        self.assertIn("RRULE:FREQ=DAILY;UNTIL=20251231T225959Z", result)

    def test_deux_exdates_reprennent_heure_minute_seconde_de_start(self):
        """Chaque EXDATE hérite de l'heure de start, en UTC si start
        est en UTC ; l'ordre passé est conservé."""
        result = build_rrulestr(
            start=self.start,
            freq="DAILY",
            exdates=["2026-03-20", "2026-03-25"],
        )
        self.assertEqual(
            result,
            "DTSTART:20260315T103045Z\n"
            "RRULE:FREQ=DAILY\n"
            "EXDATE:20260320T103045Z\n"
            "EXDATE:20260325T103045Z",
        )

    def test_listes_vides_omet_byday_et_exdate(self):
        """byday=[] et exdates=[] : aucun segment optionnel n'est ajouté."""
        result = build_rrulestr(
            start=self.start, freq="DAILY", byday=[], exdates=[]
        )
        self.assertEqual(
            result,
            "DTSTART:20260315T103045Z\nRRULE:FREQ=DAILY",
        )

    def test_byday_none_omet_byday(self):
        """byday=None (défaut) : pas de BYDAY ajouté."""
        result = build_rrulestr(start=self.start, freq="DAILY", byday=None)
        self.assertNotIn("BYDAY", result)

    def test_exdates_none_omet_exdate(self):
        """exdates=None (défaut) : pas d'EXDATE ajouté."""
        result = build_rrulestr(start=self.start, freq="DAILY", exdates=None)
        self.assertNotIn("EXDATE", result)
