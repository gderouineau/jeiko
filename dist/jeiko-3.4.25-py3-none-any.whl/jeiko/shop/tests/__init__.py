"""Tests organisés du module shop."""
