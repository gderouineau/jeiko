"""
Les licences vendues par la boutique de jeiko.fr (LIC-02, 11/10/2026).

Un produit qui « délivre une licence JEIKO » (`Product.licence_jeiko`, durée
`licence_mois`, 0 = à vie) crée, une fois la commande payée, une licence par
unité achetée — un site chacune, ou `licence_cles` par unité pour un pack. Si le client a cliqué « Prolonger » sur une
de SES licences (espace client), la ligne porte `licence_a_prolonger` : la
quantité multiplie alors la durée de CETTE licence, rien n'est créé.

Appelé par `shop.services.mark_order_paid`, dans sa transaction et sous son
verrou : une commande n'est réglée qu'une fois, les licences ne sont donc
accordées qu'une fois. Les e-mails partent APRÈS commit.

Rien de tout cela n'existe hors de jeiko.fr : sans JEIKO_SERVEUR_DE_LICENCES,
ni réglage produit, ni bouton, ni licence accordée.
"""
import calendar
import logging

from django.db import transaction
from django.utils import timezone
from django.utils.translation import gettext as _

from . import service
from .views import serveur_allume

logger = logging.getLogger(__name__)


def ajouter_des_mois(jour, mois):
    """Le même quantième, `mois` plus tard ; le dernier jour du mois s'il manque (31/01 + 1 → 28/02)."""
    total = jour.month - 1 + mois
    annee, mois_ = jour.year + total // 12, total % 12 + 1
    return jour.replace(year=annee, month=mois_, day=min(jour.day, calendar.monthrange(annee, mois_)[1]))


def prolonger(licence, mois, aujourd_hui=None):
    """
    `mois` de plus, comptés depuis la fin actuelle — ou depuis aujourd'hui si
    elle est passée : on n'achète pas des mois déjà écoulés. 0 : à vie. Une
    licence à vie le reste. Une licence désactivée à la main le reste aussi :
    un achat ne lève pas une décision de Guillaume.
    """
    # Relue SOUS VERROU : deux commandes payées en même temps, chacune avec
    # son instance lue avant l'autre, gardaient une seule des deux
    # prolongations (audit du 11/10/2026, F12). Appelée dans la transaction
    # de mark_order_paid, le verrou tient jusqu'à son commit.
    from django.db import transaction

    from jeiko.administration.models import Licence

    with transaction.atomic():
        licence = Licence.objects.select_for_update().get(pk=licence.pk)
        return _prolonger_verrouillee(licence, mois, aujourd_hui)


def _prolonger_verrouillee(licence, mois, aujourd_hui):
    if licence.expire_le is None:
        return licence
    if mois == 0:
        licence.expire_le = None
    else:
        depart = max(licence.expire_le, aujourd_hui or timezone.localdate())
        licence.expire_le = ajouter_des_mois(depart, mois)
    licence.save(update_fields=["expire_le"])
    return licence


def essai_refuse(user, lines, order=None):
    """
    Pourquoi cette commande GRATUITE ne peut pas ouvrir de licence, ou "".

    Une licence à 0 € est l'essai de jeiko.fr : un compte, un essai, une
    clé. Sans cette règle, recommander l'essai chaque mois prolongerait
    l'essai indéfiniment — il ne coûte rien. Ce que ça ne couvre pas : qui
    crée un second compte (une autre adresse e-mail) obtient un second essai ;
    la vérification de l'adresse et le plafond des inscriptions le freinent.
    """
    from jeiko.shop.models import Order, OrderLine

    for line in lines:
        produit = line.product
        if produit is None or not produit.licence_jeiko:
            continue
        if line.quantity != 1:
            return _("Un seul essai gratuit à la fois.")
        deja = OrderLine.objects.filter(
            order__user=user, order__payment_status=Order.PAYMENT_STATUS_PAID,
            product=produit, unit_price_ht=0,
        )
        if order is not None:
            deja = deja.exclude(order=order)
        if deja.exists():
            return _("Vous avez déjà profité de l'essai gratuit.")
    return ""


def accorder(order, lines, aujourd_hui=None):
    """Crée ou prolonge les licences d'une commande qui vient d'être payée."""
    if not serveur_allume() or not order.user_id:
        return []
    aujourd_hui = aujourd_hui or timezone.localdate()
    utilisateur = order.user
    titulaire = order.billing_name or utilisateur.get_full_name() or utilisateur.email or utilisateur.get_username()
    accordees = []
    for line in lines:
        produit = line.product
        # Un abonnement gère ses licences lui-même, au rythme des paiements
        # (shop/abonnements.py) : les créer ici en ferait deux jeux.
        if produit is None or not produit.licence_jeiko or produit.intervalle(line.variant):
            continue
        cible = line.licence_a_prolonger
        # Une ligne à 0 € ne prolonge rien (l'essai gratuit, voir
        # essai_refuse) : elle tombe dans la création, que la règle d'un essai
        # par compte borne.
        if cible is not None and cible.compte_id == order.user_id and line.unit_price_ht:
            mois = 0 if produit.licence_mois == 0 else produit.licence_mois * line.quantity
            accordees.append((prolonger(cible, mois, aujourd_hui), "prolongee"))
            continue
        # L'essai gratuit, une fois par compte et une clé — y compris glissé
        # dans un panier payant, qui ne passe pas par la vue de la commande
        # gratuite. Refusé ici sans bloquer le reste de la commande, payée.
        if not line.unit_price_ht and essai_refuse(utilisateur, [line], order):
            logger.warning("Commande #%s : essai gratuit déjà pris par le compte %s, aucune licence.",
                           order.pk, order.user_id)
            continue
        for __ in range(line.quantity * produit.licence_cles):
            fin = None if produit.licence_mois == 0 else ajouter_des_mois(aujourd_hui, produit.licence_mois)
            licence, __cle = service.creer(
                titulaire=titulaire[:200], email=utilisateur.email or "", expire_le=fin,
                compte=utilisateur, commande=order,
                notes=f"Commande #{order.pk} — {line.label}"[:500],
            )
            accordees.append((licence, "creee"))
    if accordees:
        ids = [(l.pk, action) for l, action in accordees]
        transaction.on_commit(lambda: _envoyer(ids))
    return accordees


def _envoyer(ids):
    """Un e-mail par licence, avec la clé. Ne lève jamais : la commande est réglée."""
    from jeiko.administration.models import Licence
    from jeiko.emailing.services import send_email

    for pk, action in ids:
        try:
            licence = Licence.objects.select_related("compte").get(pk=pk)
            if not licence.compte or not licence.compte.email:
                continue
            send_email("licence_delivered", licence.compte.email, {
                "client_nom": licence.titulaire,
                "cle": licence.cle_chiffree,
                "validite": "à vie" if licence.a_vie else f"jusqu'au {licence.expire_le.strftime('%d/%m/%Y')}",
                "action": "prolongée" if action == "prolongee" else "créée",
                # Se lit après « Elle sert à » (gabarit en base sur chaque site,
                # emailing/seeds.py) : « à le premier site » partait chez les
                # clients (relevé par Guillaume le 12/10/2026).
                "domaine": licence.domaine or "votre site, celui où vous la saisirez en premier",
            })
        except Exception:
            logger.exception("E-mail de la licence #%s impossible", pk)
