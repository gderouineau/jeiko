"""
Tests du module custom_objects et de son articulation avec shop.

Ils couvrent les régressions corrigées : URL canonique des fiches produit,
rendu du texte riche, cloisonnement des modèles de contenu produit dans
l'administration, publication (sitemap / robots.txt) et reprise des images
orphelines à l'upload.
"""

import io
import tempfile
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings

from jeiko.administration_pages.models import ImageContent, Page
from jeiko.custom_objects.models import (
    CustomObject,
    CustomObjectField,
    CustomObjectModel,
    CustomObjectValue,
)
from jeiko.custom_objects.services import build_object_context, discard_image_if_orphan
from jeiko.shop.models import Product, ProductType

User = get_user_model()


def png_bytes(couleur="red"):
    """Un vrai PNG minuscule : ImageField valide qu'il s'agit d'une image."""
    from PIL import Image

    buffer = io.BytesIO()
    Image.new("RGB", (2, 2), couleur).save(buffer, "PNG")
    return buffer.getvalue()


def uploaded_png(nom="img.png", couleur="red"):
    return SimpleUploadedFile(nom, png_bytes(couleur), content_type="image/png")


class CustomObjectFixture(TestCase):
    """
    Décor partagé : un modèle de contenu produit, son type, une fiche publiée
    et le produit qui la porte. Sert aussi aux tests de jeiko.shop.
    """

    def setUp(self):
        self.page = Page.objects.create(
            title="Gabarit produit",
            url_tag="gabarit-produit",
            active=True,
            is_custom_object_template=True,
        )
        self.com = CustomObjectModel.objects.create(
            name="Produit - Formation",
            slug="product-formation",
            page_template=self.page,
            is_product=True,
        )
        self.ptype = ProductType.objects.create(
            name="Formation",
            code="formation",
            content_model=self.com,
            kind=ProductType.KIND_COURSE,
            requires_shipping=False,
        )
        self.obj = CustomObject.objects.create(
            model=self.com,
            title="Ma formation",
            slug="ma-formation",
            is_published=True,
        )
        self.product = Product.objects.create(
            type=self.ptype,
            content=self.obj,
            sku="form-42",
            price_ht=Decimal("100.00"),
            tax_rate=Decimal("20.00"),
            stock_quantity=5,
            is_active=True,
        )


class CanonicalUrlTests(CustomObjectFixture):
    def test_objet_produit_pointe_vers_la_boutique(self):
        self.assertEqual(self.obj.get_absolute_url(), "/shop/formation/form-42/")
        self.assertEqual(self.product.get_absolute_url(), "/shop/formation/form-42/")

    def test_objet_sans_produit_garde_url_co(self):
        modele = CustomObjectModel.objects.create(
            name="Article", slug="article", page_template=self.page
        )
        article = CustomObject.objects.create(
            model=modele, title="A", slug="mon-article", is_published=True
        )
        self.assertEqual(article.get_absolute_url(), "/co/article/mon-article/")

    def test_url_co_redirige_vers_la_boutique(self):
        response = self.client.get("/co/product-formation/ma-formation/")
        self.assertEqual(response.status_code, 301)
        self.assertEqual(response["Location"], "/shop/formation/form-42/")


class ObjectContextTests(CustomObjectFixture):
    def test_texte_riche_assaini_et_marque_sur(self):
        champ = CustomObjectField.objects.create(
            model=self.com,
            code="description",
            label="Desc",
            field_type=CustomObjectField.RICH_TEXT,
        )
        CustomObjectValue.objects.create(
            obj=self.obj,
            field=champ,
            value_text="<p>Bonjour <b>toi</b></p><script>alert(1)</script>",
        )

        valeur = build_object_context(self.obj)["description"]
        self.assertIn("<b>toi</b>", valeur)
        self.assertNotIn("script", valeur)
        self.assertTrue(hasattr(valeur, "__html__"))

    def test_texte_simple_reste_echappable(self):
        champ = CustomObjectField.objects.create(
            model=self.com,
            code="titre",
            label="Titre",
            field_type=CustomObjectField.TEXT,
        )
        CustomObjectValue.objects.create(
            obj=self.obj, field=champ, value_text="<b>brut</b>"
        )
        self.assertFalse(hasattr(build_object_context(self.obj)["titre"], "__html__"))

    def test_clean_sans_champ_ne_leve_pas(self):
        # field_id absent : doit sortir sans RelatedObjectDoesNotExist.
        CustomObjectValue(obj=self.obj).clean()


class RenderTests(CustomObjectFixture):
    def test_fiche_produit_rend_200(self):
        response = self.client.get("/shop/formation/form-42/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.context["product"].pk, self.product.pk)
        self.assertEqual(response.context["product_price"], Decimal("120.00"))

    def test_fiche_objet_rend_200(self):
        modele = CustomObjectModel.objects.create(
            name="Article", slug="article", page_template=self.page
        )
        CustomObject.objects.create(
            model=modele, title="A", slug="mon-article", is_published=True
        )
        self.assertEqual(self.client.get("/co/article/mon-article/").status_code, 200)


class SitemapRobotsTests(CustomObjectFixture):
    def test_sitemap_annonce_l_url_boutique(self):
        contenu = self.client.get("/sitemap.xml").content.decode()
        self.assertIn("/shop/formation/form-42/", contenu)
        self.assertNotIn("/co/product-formation/ma-formation/", contenu)

    def test_sitemap_exclut_produit_inactif(self):
        Product.objects.filter(pk=self.product.pk).update(is_active=False)
        self.assertNotIn("form-42", self.client.get("/sitemap.xml").content.decode())

    def test_robots_annonce_l_url_boutique(self):
        contenu = self.client.get("/robots.txt").content.decode()
        self.assertIn("Allow: /shop/formation/form-42/", contenu)


class AdminIsProductTests(CustomObjectFixture):
    """
    Les modèles de contenu produit appartiennent à shop : ils ne doivent pas
    être pilotables depuis l'administration des objets personnalisés.
    """

    def setUp(self):
        super().setUp()
        self.staff = User.objects.create_user(
            "staff-co", "staff@example.test", "pw", is_staff=True, is_superuser=True
        )
        self.client.force_login(self.staff)
        self.libre = CustomObjectModel.objects.create(
            name="Article", slug="article", page_template=self.page
        )

    def test_liste_des_modeles_exclut_les_fiches_produit(self):
        response = self.client.get("/administration/custom_objects/models/")
        self.assertEqual(response.status_code, 200)
        noms = {m.name for m in response.context["models"]}
        self.assertIn("Article", noms)
        self.assertNotIn("Produit - Formation", noms)

    def test_edition_d_un_modele_produit_refusee(self):
        response = self.client.get(
            f"/administration/custom_objects/models/{self.com.pk}/edit/"
        )
        self.assertEqual(response.status_code, 404)

    def test_objets_d_un_modele_produit_inaccessibles(self):
        response = self.client.get(
            f"/administration/custom_objects/models/{self.com.pk}/objects/"
        )
        self.assertEqual(response.status_code, 404)

    def test_duplication_refuse_le_get(self):
        obj = CustomObject.objects.create(
            model=self.libre, title="A", slug="a", is_published=True
        )
        url = (
            f"/administration/custom_objects/models/{self.libre.pk}"
            f"/objects/{obj.pk}/duplicate/"
        )
        self.assertEqual(self.client.get(url).status_code, 405)
        self.assertEqual(self.client.post(url).status_code, 302)
        self.assertEqual(CustomObject.objects.filter(model=self.libre).count(), 2)


class DiscardOrphanImageTests(TestCase):
    """
    Cœur de la reprise des images : discard_image_if_orphan supprime une
    ImageContent devenue inutilisée, mais jamais une image encore référencée
    — le balayage passe par les relations inverses réelles du modèle.
    """

    def setUp(self):
        self.page = Page.objects.create(
            title="Gabarit", url_tag="gabarit", active=True,
            is_custom_object_template=True,
        )
        self.com = CustomObjectModel.objects.create(
            name="Article", slug="article", page_template=self.page
        )
        self.obj = CustomObject.objects.create(
            model=self.com, title="A", slug="a", is_published=True
        )

    def test_image_non_referencee_supprimee(self):
        image = ImageContent.objects.create(alt="orpheline")
        self.assertTrue(discard_image_if_orphan(image))
        self.assertFalse(ImageContent.objects.filter(pk=image.pk).exists())

    def test_image_referencee_par_une_valeur_conservee(self):
        image = ImageContent.objects.create(alt="utilisée")
        champ = CustomObjectField.objects.create(
            model=self.com, code="img", label="Image",
            field_type=CustomObjectField.IMAGE,
        )
        CustomObjectValue.objects.create(obj=self.obj, field=champ, image=image)

        self.assertFalse(discard_image_if_orphan(image))
        self.assertTrue(ImageContent.objects.filter(pk=image.pk).exists())

    def test_image_referencee_comme_image_principale_conservee(self):
        image = ImageContent.objects.create(alt="couverture")
        CustomObject.objects.filter(pk=self.obj.pk).update(main_image=image)

        self.assertFalse(discard_image_if_orphan(image))
        self.assertTrue(ImageContent.objects.filter(pk=image.pk).exists())

    def test_none_ne_leve_pas(self):
        self.assertFalse(discard_image_if_orphan(None))


@override_settings(MEDIA_ROOT=tempfile.mkdtemp())
class ValueFormImageUploadTests(TestCase):
    """
    Chemin d'upload du sous-formulaire image de CustomObjectValueForm :
    un envoi crée une ImageContent, et un remplacement reprend l'ancienne.
    """

    def setUp(self):
        self.page = Page.objects.create(
            title="Gabarit", url_tag="gabarit", active=True,
            is_custom_object_template=True,
        )
        self.com = CustomObjectModel.objects.create(
            name="Article", slug="article", page_template=self.page
        )
        self.obj = CustomObject.objects.create(
            model=self.com, title="A", slug="a", is_published=True
        )
        self.champ = CustomObjectField.objects.create(
            model=self.com, code="img", label="Image",
            field_type=CustomObjectField.IMAGE,
        )

    def _form(self, value, upload, prefix="values-0"):
        from jeiko.custom_objects.forms import CustomObjectValueForm

        data = {
            f"{prefix}-field": str(self.champ.pk),
            f"{prefix}-id": str(value.pk),
            f"{prefix}-value_text": "",
            f"{prefix}-video_url": "",
            f"{prefix}-button_label": "",
            f"{prefix}-button_test_slug": "",
            f"{prefix}-button_external_url": "",
        }
        files = {f"{prefix}_subimg-original_image": upload}
        return CustomObjectValueForm(
            data=data, files=files, instance=value, prefix=prefix
        )

    def test_upload_cree_une_image(self):
        value = CustomObjectValue.objects.create(obj=self.obj, field=self.champ)
        form = self._form(value, uploaded_png())
        self.assertTrue(form.is_valid(), form.errors)
        form.save()

        value.refresh_from_db()
        self.assertIsNotNone(value.image_id)
        self.assertTrue(value.image.original_image)

    def test_remplacement_reprend_l_ancienne_image(self):
        image_ancienne = ImageContent.objects.create(
            alt="v1", original_image=SimpleUploadedFile(
                "v1.png", png_bytes("blue"), content_type="image/png"
            ),
        )
        value = CustomObjectValue.objects.create(
            obj=self.obj, field=self.champ, image=image_ancienne
        )

        form = self._form(value, uploaded_png("v2.png", "green"))
        self.assertTrue(form.is_valid(), form.errors)
        form.save()

        value.refresh_from_db()
        # Nouvelle image en place, ancienne reprise (plus référencée).
        self.assertNotEqual(value.image_id, image_ancienne.pk)
        self.assertFalse(
            ImageContent.objects.filter(pk=image_ancienne.pk).exists()
        )

    def test_remplacement_conserve_l_ancienne_si_partagee(self):
        image_partagee = ImageContent.objects.create(
            alt="partagée", original_image=SimpleUploadedFile(
                "s.png", png_bytes("blue"), content_type="image/png"
            ),
        )
        value = CustomObjectValue.objects.create(
            obj=self.obj, field=self.champ, image=image_partagee
        )
        # Un second objet pointe la même image : elle ne doit pas disparaître.
        CustomObject.objects.filter(pk=self.obj.pk).update(main_image=image_partagee)

        form = self._form(value, uploaded_png("v2.png", "green"))
        self.assertTrue(form.is_valid(), form.errors)
        form.save()

        self.assertTrue(
            ImageContent.objects.filter(pk=image_partagee.pk).exists()
        )
