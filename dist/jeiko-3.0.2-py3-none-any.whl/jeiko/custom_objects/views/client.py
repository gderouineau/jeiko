from django.http import HttpResponsePermanentRedirect
from django.shortcuts import render, get_object_or_404
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import ensure_csrf_cookie

from ..models import CustomObject
from ..services import OBJECT_VALUE_PREFETCH, build_object_context


@method_decorator(ensure_csrf_cookie, name="get")
class CustomObjectView(View):
    """
    Vue client pour afficher un objet custom :
    URL canonique : /co/<model_slug>/<object_slug>/

    Les objets qui portent une fiche produit sont redirigés vers la boutique
    par le contrôle canonique ci-dessous : leur page de référence est celle de
    `shop`, seule à disposer du prix, du stock et du panier.
    """

    template_name = "pages/main.html"  # même template que PageView

    def get(self, request, *args, **kwargs):
        model_slug = kwargs.get("model_slug")
        object_slug = kwargs.get("object_slug")

        # Récupération de l'objet + modèle + page template
        qs = (
            CustomObject.objects
            .select_related(
                "model",
                "model__page_template",
                # get_absolute_url interroge la fiche produit éventuelle
                "product",
                "product__type",
            )
            .prefetch_related(*OBJECT_VALUE_PREFETCH)
        )

        # Les brouillons restent visibles pour le staff (préversion), mais sont
        # invisibles pour le public. Un objet absent ou non publié doit renvoyer
        # un 404 : un .get() nu levait DoesNotExist -> 500, ce qui fait chuter
        # le crawl Google.
        if not request.user.is_staff:
            qs = qs.filter(is_published=True)

        obj = get_object_or_404(qs, model__slug=model_slug, slug=object_slug)

        # Canonical check
        canonical_path = obj.get_absolute_url()
        if request.path != canonical_path:
            return HttpResponsePermanentRedirect(canonical_path)

        page = obj.model.page_template

        # Contexte de base
        context = {
            "page": page,
            "custom_object": obj,
            "object": obj,  # alias si besoin
        }

        # Metadata éventuelle
        metadata = getattr(obj, "metadata", None)
        if metadata is not None:
            context["metadata"] = metadata

        # Valeurs des champs, aplaties sous leur code pour les jetons [%code%]
        context.update(build_object_context(obj))

        return render(request, self.template_name, context)
