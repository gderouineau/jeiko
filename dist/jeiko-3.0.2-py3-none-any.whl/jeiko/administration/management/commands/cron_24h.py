"""
Tâches planifiées — une fois par jour.

Lancé par le timer systemd jeiko-cron-24h@<site>.timer.

Aucun job pour l'instant. Candidats : récapitulatif quotidien à l'administrateur
et au praticien, souhaits d'anniversaire, purge des journaux d'e-mails anciens.
"""
from jeiko.administration.management.commands._cron import CronCommand


class Command(CronCommand):
    help = "Tâches planifiées à exécuter une fois par jour."
    cadence = "24h"

    def get_jobs(self):
        return []
