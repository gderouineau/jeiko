# jeiko/emailing/registry.py
"""
Catalogue des e-mails envoyables par la plateforme.

Source de vérité unique : un code d'événement y est déclaré une fois, avec son
libellé, sa catégorie, son destinataire et les variables qu'il expose. Le reste
en découle — la notice affichée dans l'admin, la validation des clés saisies
dans un sujet, et le seed des contenus par défaut.

Les variables s'écrivent [%cle%] dans le sujet comme dans le corps, avec la même
syntaxe que les contenus d'administration_pages (voir TAG_PATTERN dans
templatetags/custom_tags.py).
"""

# =========================
#  Catégories
# =========================

CATEGORY_ACCOUNT = "account"
CATEGORY_APPOINTMENT = "appointment"
CATEGORY_TEST = "test"
CATEGORY_COURSE = "course"
CATEGORY_SHOP = "shop"
CATEGORY_SITE = "site"
CATEGORY_INTERNAL = "internal"
CATEGORY_MARKETING = "marketing"

CATEGORY_LABELS = {
    CATEGORY_ACCOUNT: "Compte & sécurité",
    CATEGORY_APPOINTMENT: "Rendez-vous",
    CATEGORY_TEST: "Questionnaires & tests",
    CATEGORY_COURSE: "Formations",
    CATEGORY_SHOP: "Boutique & paiements",
    CATEGORY_SITE: "Site & formulaires",
    CATEGORY_INTERNAL: "Interne & technique",
    CATEGORY_MARKETING: "Marketing & cycle de vie",
}

# Ordre d'affichage dans l'administration.
CATEGORY_ORDER = [
    CATEGORY_ACCOUNT,
    CATEGORY_APPOINTMENT,
    CATEGORY_TEST,
    CATEGORY_COURSE,
    CATEGORY_SHOP,
    CATEGORY_SITE,
    CATEGORY_INTERNAL,
    CATEGORY_MARKETING,
]

# =========================
#  Destinataires
# =========================

AUDIENCE_USER = "user"
AUDIENCE_PROSPECT = "prospect"
AUDIENCE_ADMIN = "admin"
AUDIENCE_PROVIDER = "provider"

AUDIENCE_LABELS = {
    AUDIENCE_USER: "Utilisateur / client",
    AUDIENCE_PROSPECT: "Prospect (sans compte)",
    AUDIENCE_ADMIN: "Administrateur",
    AUDIENCE_PROVIDER: "Praticien / intervenant",
}

# =========================
#  Variables globales
# =========================

# Injectées dans tous les e-mails, quel que soit l'événement.
GLOBAL_VARIABLES = {
    "site_nom": "Nom du site",
    "site_url": "URL du site (absolue)",
    "logo_url": "URL du logo (absolue)",
    "prenom": "Prénom du destinataire",
    "nom": "Nom du destinataire",
    "email": "Adresse e-mail du destinataire",
    "date": "Date du jour (JJ/MM/AAAA)",
    "annee": "Année en cours",
    "contact_email": "Adresse de contact du site",
    "contact_tel": "Téléphone de contact du site",
    "lien_compte": "Lien vers l'espace personnel",
    "lien_desabonnement": "Lien de désinscription (obligatoire sur le marketing)",
    "signature": "Signature configurée pour le site",
}

# =========================
#  Événements
# =========================

# Chaque entrée : label, category, audience, description, variables.
# `variables` ne liste QUE les variables propres à l'événement — les globales
# ci-dessus sont toujours disponibles en plus.
EMAIL_EVENTS = {

    # ---------- Compte & sécurité ----------
    "account_welcome": {
        "label": "Bienvenue",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé après la validation de l'inscription.",
        "variables": {
            "lien_action": "Lien vers l'espace personnel",
        },
    },
    "account_email_verify": {
        "label": "Vérification de l'adresse e-mail",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé à l'inscription pour confirmer l'adresse.",
        "variables": {
            "lien_action": "Lien de vérification",
            "code": "Code de vérification (si saisie manuelle)",
            "expiration": "Durée de validité du lien",
        },
    },
    "password_reset_request": {
        "label": "Réinitialisation du mot de passe",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé sur demande de réinitialisation.",
        "variables": {
            "lien_action": "Lien de réinitialisation",
            "expiration": "Durée de validité du lien",
            "ip": "Adresse IP à l'origine de la demande",
        },
    },
    "password_changed": {
        "label": "Mot de passe modifié",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Notification de sécurité, sans action attendue.",
        "variables": {
            "date_heure": "Date et heure de la modification",
            "ip": "Adresse IP",
            "appareil": "Navigateur / appareil",
        },
    },
    "account_created_by_admin": {
        "label": "Compte créé par l'administrateur",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Compte ouvert depuis l'administration.",
        "variables": {
            "lien_action": "Lien de définition du mot de passe",
            "expiration": "Durée de validité du lien",
        },
    },
    "email_change_confirm": {
        "label": "Confirmation de la nouvelle adresse",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé à la NOUVELLE adresse pour la confirmer.",
        "variables": {
            "lien_action": "Lien de confirmation",
            "nouvel_email": "Nouvelle adresse demandée",
            "expiration": "Durée de validité du lien",
        },
    },
    "email_changed_alert": {
        "label": "Alerte de changement d'adresse",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé à l'ANCIENNE adresse pour signaler le changement.",
        "variables": {
            "nouvel_email": "Nouvelle adresse",
            "date_heure": "Date et heure du changement",
        },
    },
    "twofa_code": {
        "label": "Code de double authentification",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Code à usage unique envoyé par e-mail.",
        "variables": {
            "code": "Code à usage unique",
            "expiration": "Durée de validité du code",
        },
    },
    "twofa_enabled": {
        "label": "Double authentification activée",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Notification de sécurité.",
        "variables": {
            "date_heure": "Date et heure de l'activation",
            "methode": "Méthode utilisée (application, e-mail…)",
        },
    },
    "twofa_disabled": {
        "label": "Double authentification désactivée",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Notification de sécurité.",
        "variables": {
            "date_heure": "Date et heure de la désactivation",
        },
    },
    "login_new_device": {
        "label": "Connexion depuis un nouvel appareil",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Déclenché sur une IP ou un appareil inconnu.",
        "variables": {
            "date_heure": "Date et heure de la connexion",
            "ip": "Adresse IP",
            "appareil": "Navigateur / appareil",
            "localisation": "Localisation approximative",
        },
    },
    "account_locked": {
        "label": "Compte temporairement bloqué",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Après plusieurs tentatives de connexion échouées.",
        "variables": {
            "duree_blocage": "Durée du blocage",
            "lien_action": "Lien de réinitialisation du mot de passe",
        },
    },
    "account_deactivated": {
        "label": "Compte désactivé",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Confirmation de désactivation ou de suppression.",
        "variables": {
            "date_heure": "Date et heure de la désactivation",
        },
    },
    "rgpd_data_export_ready": {
        "label": "Export de données prêt",
        "category": CATEGORY_ACCOUNT,
        "audience": AUDIENCE_USER,
        "description": "Export RGPD disponible au téléchargement.",
        "variables": {
            "lien_action": "Lien de téléchargement",
            "expiration": "Durée de validité du lien",
        },
    },

    # ---------- Rendez-vous ----------
    "appointment_confirmed": {
        "label": "Confirmation de rendez-vous",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé au client dès la réservation.",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "rdv_heure": "Heure du rendez-vous",
            "rdv_duree": "Durée",
            "rdv_type": "Type de rendez-vous",
            "pro_nom": "Nom du praticien",
            "lieu": "Lieu du rendez-vous",
            "lien_visio": "Lien de visioconférence",
            "lien_annulation": "Lien d'annulation / modification",
        },
    },
    "appointment_admin_new": {
        "label": "Nouvelle réservation (praticien)",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_PROVIDER,
        "description": "Copie envoyée au praticien et aux administrateurs.",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "rdv_heure": "Heure du rendez-vous",
            "rdv_duree": "Durée",
            "rdv_type": "Type de rendez-vous",
            "client_nom": "Nom du client",
            "client_email": "E-mail du client",
            "client_tel": "Téléphone du client",
            "rdv_id": "Identifiant interne",
        },
    },
    "appointment_reminder_24h": {
        "label": "Rappel — 24 h avant",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé la veille par la tâche planifiée.",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "rdv_heure": "Heure du rendez-vous",
            "rdv_duree": "Durée",
            "rdv_type": "Type de rendez-vous",
            "pro_nom": "Nom du praticien",
            "lieu": "Lieu du rendez-vous",
            "lien_visio": "Lien de visioconférence",
            "lien_annulation": "Lien d'annulation / modification",
        },
    },
    "appointment_reminder_2h": {
        "label": "Rappel — 2 h avant",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Rappel court, utile surtout en visioconférence.",
        "variables": {
            "rdv_heure": "Heure du rendez-vous",
            "rdv_type": "Type de rendez-vous",
            "lieu": "Lieu du rendez-vous",
            "lien_visio": "Lien de visioconférence",
        },
    },
    "appointment_cancelled_client": {
        "label": "Annulation par le client",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Accusé d'annulation, envoyé au client et au praticien.",
        "variables": {
            "rdv_date": "Date du rendez-vous annulé",
            "rdv_heure": "Heure du rendez-vous annulé",
            "rdv_type": "Type de rendez-vous",
            "lien_action": "Lien pour reprendre un rendez-vous",
        },
    },
    "appointment_cancelled_pro": {
        "label": "Annulation par le praticien",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Le praticien annule ; le client est invité à replanifier.",
        "variables": {
            "rdv_date": "Date du rendez-vous annulé",
            "rdv_heure": "Heure du rendez-vous annulé",
            "rdv_type": "Type de rendez-vous",
            "pro_nom": "Nom du praticien",
            "motif": "Motif de l'annulation",
            "lien_action": "Lien de nouvelle réservation",
        },
    },
    "appointment_rescheduled": {
        "label": "Rendez-vous déplacé",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Le créneau a changé.",
        "variables": {
            "rdv_date": "Nouvelle date",
            "rdv_heure": "Nouvelle heure",
            "ancienne_date": "Ancienne date",
            "ancienne_heure": "Ancienne heure",
            "rdv_type": "Type de rendez-vous",
            "pro_nom": "Nom du praticien",
            "lien_annulation": "Lien d'annulation / modification",
        },
    },
    "appointment_payment_pending": {
        "label": "Rendez-vous en attente de paiement",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Créneau réservé mais non réglé.",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "rdv_heure": "Heure du rendez-vous",
            "montant": "Montant à régler",
            "lien_action": "Lien de paiement",
            "expiration": "Délai avant libération du créneau",
        },
    },
    "appointment_followup": {
        "label": "Suivi après rendez-vous",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Envoyé le lendemain : remerciement, documents, avis.",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "pro_nom": "Nom du praticien",
            "lien_action": "Lien vers le formulaire d'avis",
            "lien_documents": "Lien vers les documents partagés",
        },
    },
    "appointment_no_show": {
        "label": "Absence au rendez-vous",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Le client ne s'est pas présenté.",
        "variables": {
            "rdv_date": "Date du rendez-vous manqué",
            "rdv_heure": "Heure du rendez-vous manqué",
            "lien_action": "Lien de nouvelle réservation",
        },
    },
    "appointment_reminder_pro_1h": {
        "label": "Rappel praticien — 1 h avant",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_PROVIDER,
        "description": "Rappelle au praticien son rendez-vous imminent (tâche planifiée).",
        "variables": {
            "rdv_date": "Date du rendez-vous",
            "rdv_heure": "Heure du rendez-vous",
            "rdv_duree": "Durée",
            "rdv_type": "Type de rendez-vous",
            "client_nom": "Nom du client",
            "client_email": "E-mail du client",
            "lieu": "Lieu du rendez-vous",
        },
    },
    "appointment_daily_digest_pro": {
        "label": "Récapitulatif quotidien (praticien)",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_PROVIDER,
        "description": "Rendez-vous du lendemain, envoyé par la tâche planifiée.",
        "variables": {
            "date_cible": "Journée concernée",
            "nombre_rdv": "Nombre de rendez-vous",
            "bloc_rdv": "Tableau des rendez-vous (généré)",
        },
    },
    "appointment_waitlist_available": {
        "label": "Liste d'attente — une place s'est libérée",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Une place se libère sur un créneau complet ; la personne "
                       "en tête de liste est prévenue, place tenue quelques minutes.",
        "variables": {
            "prenom": "Prénom du client",
            "rdv_date": "Date du créneau",
            "rdv_heure": "Heure du créneau",
            "rdv_type": "Type de rendez-vous",
            "pro_nom": "Nom du praticien",
            "lien_action": "Lien de réservation en 1 clic",
            "lien_desinscription": "Lien pour quitter la liste d'attente",
            "expiration": "Heure jusqu'à laquelle la place est tenue",
        },
    },
    "appointment_refunded": {
        "label": "Rendez-vous remboursé",
        "category": CATEGORY_APPOINTMENT,
        "audience": AUDIENCE_USER,
        "description": "Confirme au client le remboursement d'un rendez-vous payant annulé.",
        "variables": {
            "prenom": "Prénom du client",
            "rdv_date": "Date du rendez-vous annulé",
            "rdv_heure": "Heure du rendez-vous annulé",
            "rdv_type": "Type de rendez-vous",
            "montant": "Montant remboursé",
        },
    },

    # ---------- Questionnaires & tests ----------
    "test_access_granted": {
        "label": "Accès au test accordé",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_USER,
        "description": "Accès ouvert par achat, par un administrateur ou offert.",
        "variables": {
            "test_nom": "Nom du test",
            "lien_action": "Lien pour démarrer le test",
            "origine_acces": "Origine de l'accès (achat, admin, offert)",
        },
    },
    "test_completed_results": {
        "label": "Résultats du test",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_USER,
        "description": "Envoyé à la fin du test, avec le profil obtenu.",
        "variables": {
            "test_nom": "Nom du test",
            "score": "Score obtenu",
            "profil": "Profil identifié",
            "profil_description": "Description du profil",
            "bloc_resultats": "Détail des résultats (généré)",
            "lien_resultats": "Lien vers le rapport complet",
        },
    },
    "test_results_admin": {
        "label": "Résultats du test (praticien)",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_PROVIDER,
        "description": "Notifie l'administration qu'un test vient d'être passé.",
        "variables": {
            "test_nom": "Nom du test",
            "client_nom": "Nom du répondant",
            "client_email": "E-mail du répondant",
            "score": "Score obtenu",
            "profil": "Profil identifié",
            "bloc_resultats": "Détail des résultats (généré)",
            "lien_resultats": "Lien vers le rapport complet",
            "lien_prospect": "Lien vers la fiche du répondant (administration)",
            "lien_testdata": "Lien vers le détail du test passé (administration)",
        },
    },
    "test_invitation": {
        "label": "Invitation à passer le test",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_PROSPECT,
        "description": "Invitation à jeton, sans création de compte.",
        "variables": {
            "test_nom": "Nom du test",
            "lien_action": "Lien d'accès au test",
            "expiration": "Durée de validité du lien",
            "duree_estimee": "Durée estimée du test",
        },
    },
    "test_abandoned_reminder": {
        "label": "Relance — test non terminé",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_USER,
        "description": "Test commencé mais laissé en cours.",
        "variables": {
            "test_nom": "Nom du test",
            "progression": "Progression atteinte",
            "lien_action": "Lien pour reprendre le test",
        },
    },
    "prospect_captured_admin": {
        "label": "Nouveau prospect",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_ADMIN,
        "description": "Un prospect vient d'être enregistré.",
        "variables": {
            "client_nom": "Nom du prospect",
            "client_email": "E-mail du prospect",
            "client_tel": "Téléphone du prospect",
            "origine": "Origine de la capture",
            "lien_action": "Lien vers la fiche prospect",
        },
    },
    "test_retake_reminder": {
        "label": "Invitation à repasser le test",
        "category": CATEGORY_TEST,
        "audience": AUDIENCE_USER,
        "description": "Relance à distance du dernier passage.",
        "variables": {
            "test_nom": "Nom du test",
            "date_dernier_passage": "Date du dernier passage",
            "lien_action": "Lien pour repasser le test",
        },
    },

    # ---------- Formations ----------
    "course_enrolled": {
        "label": "Inscription à la formation",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Envoyé à la création de l'inscription.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "lien_action": "Lien vers la formation",
            "nombre_chapitres": "Nombre de chapitres",
        },
    },
    "course_access_granted_admin": {
        "label": "Accès formation accordé",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Accès ouvert par un administrateur.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "lien_action": "Lien vers la formation",
        },
    },
    "course_completed": {
        "label": "Formation terminée",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Félicitations et attestation.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "date_fin": "Date d'achèvement",
            "lien_attestation": "Lien vers l'attestation",
        },
    },
    "course_suspended": {
        "label": "Accès formation suspendu",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "L'inscription passe en statut suspendu.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "motif": "Motif de la suspension",
        },
    },
    "course_new_content": {
        "label": "Nouveau contenu publié",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Envoyé aux inscrits d'une formation enrichie.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "contenu_nom": "Titre du nouveau contenu",
            "lien_action": "Lien vers le contenu",
        },
    },
    "course_progress_stalled": {
        "label": "Relance — progression à l'arrêt",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Aucune progression depuis un certain temps.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "progression": "Progression actuelle (%)",
            "lien_action": "Lien pour reprendre",
            "jours_inactivite": "Nombre de jours d'inactivité",
        },
    },
    "quiz_passed": {
        "label": "Quiz réussi",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Résultat positif à un quiz.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "quiz_nom": "Nom du quiz",
            "score": "Score obtenu",
            "lien_action": "Lien vers la suite de la formation",
        },
    },
    "quiz_failed": {
        "label": "Quiz échoué",
        "category": CATEGORY_COURSE,
        "audience": AUDIENCE_USER,
        "description": "Invitation à retenter le quiz.",
        "variables": {
            "formation_nom": "Nom de la formation",
            "quiz_nom": "Nom du quiz",
            "score": "Score obtenu",
            "score_requis": "Score requis",
            "lien_action": "Lien pour retenter",
        },
    },

    # ---------- Boutique & paiements ----------
    "order_confirmation": {
        "label": "Confirmation de commande",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "La commande passe en statut confirmée.",
        "variables": {
            "commande_num": "Numéro de commande",
            "commande_date": "Date de la commande",
            "commande_total": "Montant total",
            "bloc_lignes": "Tableau des articles (généré)",
            "adresse_livraison": "Adresse de livraison",
            "lien_action": "Lien vers la commande",
        },
    },
    "payment_received": {
        "label": "Paiement reçu",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Le paiement est confirmé ; la facture est jointe.",
        "variables": {
            "commande_num": "Numéro de commande",
            "montant": "Montant réglé",
            "moyen_paiement": "Moyen de paiement",
            "lien_facture": "Lien vers la facture",
        },
    },
    "payment_failed": {
        "label": "Échec du paiement",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Le paiement a échoué ; lien de reprise.",
        "variables": {
            "commande_num": "Numéro de commande",
            "montant": "Montant dû",
            "motif": "Motif de l'échec",
            "lien_action": "Lien pour relancer le paiement",
        },
    },
    "order_admin_new": {
        "label": "Nouvelle commande (administrateur)",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_ADMIN,
        "description": "Notification interne de commande.",
        "variables": {
            "commande_num": "Numéro de commande",
            "commande_total": "Montant total",
            "client_nom": "Nom du client",
            "client_email": "E-mail du client",
            "bloc_lignes": "Tableau des articles (généré)",
            "lien_action": "Lien vers la commande en administration",
        },
    },
    "order_shipped": {
        "label": "Commande expédiée",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "La commande passe en statut expédiée.",
        "variables": {
            "commande_num": "Numéro de commande",
            "transporteur": "Transporteur",
            "numero_suivi": "Numéro de suivi",
            "lien_suivi": "Lien de suivi du colis",
            "date_livraison_estimee": "Date de livraison estimée",
        },
    },
    "order_cancelled": {
        "label": "Commande annulée",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "La commande passe en statut annulée.",
        "variables": {
            "commande_num": "Numéro de commande",
            "motif": "Motif de l'annulation",
            "montant": "Montant concerné",
        },
    },
    "order_refunded": {
        "label": "Remboursement effectué",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Le paiement passe en statut remboursé.",
        "variables": {
            "commande_num": "Numéro de commande",
            "montant": "Montant remboursé",
            "moyen_paiement": "Moyen de remboursement",
            "delai": "Délai avant réception",
        },
    },
    "order_completed": {
        "label": "Commande terminée",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Remerciement et demande d'avis.",
        "variables": {
            "commande_num": "Numéro de commande",
            "bloc_lignes": "Tableau des articles (généré)",
            "lien_action": "Lien vers le formulaire d'avis",
        },
    },
    "cart_abandoned": {
        "label": "Relance de panier",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Panier non converti après un délai.",
        "variables": {
            "bloc_lignes": "Tableau des articles du panier (généré)",
            "panier_total": "Montant du panier",
            "lien_action": "Lien de reprise du panier",
        },
    },
    "product_back_in_stock": {
        "label": "Retour en stock",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_USER,
        "description": "Envoyé aux inscrits à l'alerte stock.",
        "variables": {
            "produit_nom": "Nom du produit",
            "produit_prix": "Prix du produit",
            "lien_action": "Lien vers la fiche produit",
        },
    },
    "low_stock_admin": {
        "label": "Alerte stock bas",
        "category": CATEGORY_SHOP,
        "audience": AUDIENCE_ADMIN,
        "description": "Un produit passe sous le seuil configuré.",
        "variables": {
            "produit_nom": "Nom du produit",
            "stock_restant": "Stock restant",
            "seuil": "Seuil d'alerte",
            "lien_action": "Lien vers la fiche produit en administration",
        },
    },

    # ---------- Site & formulaires ----------
    "contact_form_admin": {
        "label": "Formulaire de contact (administrateur)",
        "category": CATEGORY_SITE,
        "audience": AUDIENCE_ADMIN,
        "description": "Notification interne à chaque soumission.",
        "variables": {
            "formulaire_nom": "Nom du formulaire",
            "bloc_reponses": "Tableau des réponses (généré)",
            "expediteur_nom": "Nom du visiteur",
            "expediteur_email": "E-mail du visiteur",
            "page_origine": "Page d'où vient la soumission",
        },
    },
    "contact_form_receipt": {
        "label": "Accusé de réception (visiteur)",
        "category": CATEGORY_SITE,
        "audience": AUDIENCE_PROSPECT,
        "description": "Confirmation envoyée au visiteur.",
        "variables": {
            "formulaire_nom": "Nom du formulaire",
            "bloc_reponses": "Rappel des réponses (généré)",
            "delai_reponse": "Délai de réponse annoncé",
        },
    },
    "newsletter_double_optin": {
        "label": "Confirmation d'inscription newsletter",
        "category": CATEGORY_SITE,
        "audience": AUDIENCE_PROSPECT,
        "description": "Double opt-in : confirme l'inscription.",
        "variables": {
            "lien_action": "Lien de confirmation",
            "expiration": "Durée de validité du lien",
        },
    },
    "newsletter_welcome": {
        "label": "Bienvenue dans la newsletter",
        "category": CATEGORY_SITE,
        "audience": AUDIENCE_PROSPECT,
        "description": "Envoyé une fois l'inscription confirmée.",
        "variables": {
            "frequence": "Fréquence d'envoi annoncée",
        },
    },
    "newsletter_unsubscribe_confirm": {
        "label": "Confirmation de désinscription",
        "category": CATEGORY_SITE,
        "audience": AUDIENCE_PROSPECT,
        "description": "Accusé de désinscription.",
        "variables": {
            "lien_action": "Lien de réinscription",
        },
    },

    # ---------- Interne & technique ----------
    "smtp_test": {
        "label": "Test de configuration SMTP",
        "category": CATEGORY_INTERNAL,
        "audience": AUDIENCE_ADMIN,
        "description": "Envoyé par le bouton de test de la configuration mail.",
        "variables": {
            "serveur_smtp": "Serveur et port SMTP",
            "utilisateur_smtp": "Utilisateur SMTP",
            "date_heure": "Date et heure du test",
        },
    },
    "admin_new_user": {
        "label": "Nouvelle inscription (administrateur)",
        "category": CATEGORY_INTERNAL,
        "audience": AUDIENCE_ADMIN,
        "description": "Notification interne à chaque inscription.",
        "variables": {
            "client_nom": "Nom du nouvel inscrit",
            "client_email": "E-mail du nouvel inscrit",
            "date_heure": "Date et heure de l'inscription",
            "lien_action": "Lien vers la fiche utilisateur",
        },
    },
    "admin_daily_digest": {
        "label": "Récapitulatif quotidien",
        "category": CATEGORY_INTERNAL,
        "audience": AUDIENCE_ADMIN,
        "description": "Synthèse envoyée par la tâche planifiée.",
        "variables": {
            "date_cible": "Journée concernée",
            "bloc_rdv": "Rendez-vous du jour (généré)",
            "bloc_commandes": "Commandes du jour (généré)",
            "bloc_prospects": "Nouveaux prospects (généré)",
        },
    },
    "admin_error_alert": {
        "label": "Alerte technique",
        "category": CATEGORY_INTERNAL,
        "audience": AUDIENCE_ADMIN,
        "description": "Échecs d'envoi répétés, erreur de webhook, etc.",
        "variables": {
            "type_erreur": "Type d'erreur",
            "detail_erreur": "Détail technique",
            "date_heure": "Date et heure",
            "occurrences": "Nombre d'occurrences",
        },
    },

    # ---------- Marketing & cycle de vie ----------
    "birthday_wishes": {
        "label": "Anniversaire",
        "category": CATEGORY_MARKETING,
        "audience": AUDIENCE_USER,
        "description": "Message d'anniversaire, éventuellement avec offre.",
        "variables": {
            "code_promo": "Code promotionnel",
            "expiration": "Validité de l'offre",
            "lien_action": "Lien vers l'offre",
        },
    },
    "reactivation": {
        "label": "Réactivation",
        "category": CATEGORY_MARKETING,
        "audience": AUDIENCE_USER,
        "description": "Relance des utilisateurs inactifs.",
        "variables": {
            "date_derniere_visite": "Date de la dernière visite",
            "lien_action": "Lien de retour sur le site",
        },
    },
    "nps_survey": {
        "label": "Enquête de satisfaction",
        "category": CATEGORY_MARKETING,
        "audience": AUDIENCE_USER,
        "description": "Sollicitation d'avis après une prestation.",
        "variables": {
            "prestation_nom": "Prestation concernée",
            "lien_action": "Lien vers l'enquête",
        },
    },
    "campaign_manual": {
        "label": "Campagne manuelle",
        "category": CATEGORY_MARKETING,
        "audience": AUDIENCE_USER,
        "description": "Envoi ponctuel déclenché depuis l'administration.",
        "variables": {
            "titre_campagne": "Titre de la campagne",
            "lien_action": "Lien principal de la campagne",
        },
    },
}

# Événements dont l'envoi est transactionnel : ils partent toujours, sans tenir
# compte des préférences marketing, et n'ont pas besoin de lien de désinscription.
TRANSACTIONAL_CATEGORIES = {
    CATEGORY_ACCOUNT,
    CATEGORY_APPOINTMENT,
    CATEGORY_TEST,
    CATEGORY_COURSE,
    CATEGORY_SHOP,
    CATEGORY_SITE,
    CATEGORY_INTERNAL,
}


# =========================
#  Accès
# =========================

def get_event(code):
    """Retourne la déclaration d'un événement, ou None s'il n'est pas au catalogue."""
    return EMAIL_EVENTS.get(code)


def event_choices():
    """Choices Django, groupés par catégorie, dans l'ordre d'affichage."""
    groups = []
    for category in CATEGORY_ORDER:
        codes = [
            (code, event["label"])
            for code, event in EMAIL_EVENTS.items()
            if event["category"] == category
        ]
        if codes:
            groups.append((CATEGORY_LABELS[category], codes))
    return groups


def available_variables(code):
    """
    Variables utilisables dans le sujet et le corps d'un événement :
    ses variables propres, plus les globales.

    Retourne une liste de dicts triée — propres d'abord, globales ensuite —
    pour l'affichage de la notice.
    """
    event = get_event(code)
    own = event["variables"] if event else {}

    variables = [
        {"key": key, "description": description, "scope": "event"}
        for key, description in own.items()
    ]
    variables += [
        {"key": key, "description": description, "scope": "global"}
        for key, description in GLOBAL_VARIABLES.items()
        if key not in own
    ]
    return variables


def variable_keys(code):
    """Ensemble des clés autorisées pour un événement (validation des saisies)."""
    return {variable["key"] for variable in available_variables(code)}


def is_transactional(code):
    event = get_event(code)
    if not event:
        return True
    return event["category"] in TRANSACTIONAL_CATEGORIES


def events_by_category():
    """
    Catalogue groupé pour les écrans de liste :
    [(clé_catégorie, libellé, [(code, événement), ...]), ...]
    """
    grouped = []
    for category in CATEGORY_ORDER:
        events = [
            (code, event)
            for code, event in EMAIL_EVENTS.items()
            if event["category"] == category
        ]
        if events:
            grouped.append((category, CATEGORY_LABELS[category], events))
    return grouped
