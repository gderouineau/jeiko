from django.urls import path
from jeiko.emailing.views import admin as admin_views

app_name = "jeiko_administration_emailing"

urlpatterns = [
    path(
        "",
        admin_views.EmailTemplateListView.as_view(),
        name="template_list",
    ),
    path(
        "<slug:code>/",
        admin_views.EmailTemplateUpdateView.as_view(),
        name="template_edit",
    ),
    path(
        "<slug:code>/apercu/",
        admin_views.EmailTemplatePreviewView.as_view(),
        name="template_preview",
    ),
    path(
        "<slug:code>/reinitialiser/",
        admin_views.EmailTemplateResetView.as_view(),
        name="template_reset",
    ),
]