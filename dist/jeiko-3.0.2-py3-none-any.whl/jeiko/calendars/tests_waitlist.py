# jeiko/calendars/tests_waitlist.py
"""
Liste d'attente : inscription sur un créneau complet, notification en cascade
quand une place se libère, place tenue le temps de la réservation.

Les e-mails sont mockés — on teste la mécanique (occupation, ordre, hold), pas
le rendu des messages.
"""
import json
from datetime import timedelta
from decimal import Decimal
from io import StringIO
from unittest import mock

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.core.management import call_command
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from . import payments, waitlist
from .models import Appointment, AppointmentType, Availability, Slot, WaitlistEntry

User = get_user_model()

JOIN_URL = "api_calendars:api_join_waitlist"
BOOK_URL = "api_calendars:api_book_appointment"
AVAIL_URL = "api_calendars:api_availabilities"


class WaitlistFixture(TestCase):
    CAPACITY = 1

    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user(username="prov", password="pwd12345")
        self.type = AppointmentType.objects.create(
            name="Consultation", user=self.user, duration=timedelta(hours=1),
            capacity=self.CAPACITY, allow_waitlist=True,
        )
        start = (timezone.now() + timedelta(days=3)).replace(
            minute=0, second=0, microsecond=0
        )
        self.availability = Availability.objects.create(
            user=self.user, start=start, end=start + timedelta(hours=1)
        )
        self.availability.appointment_types.add(self.type)
        self.slot = Slot.objects.get(availability=self.availability, type=self.type)
        # Sature le créneau : une réservation ferme.
        self.holder = Appointment.objects.create(
            type=self.type, slot=self.slot, start=self.slot.start, end=self.slot.end,
            email="holder@example.com", places=self.CAPACITY,
        )
        self.slot.sync_remaining_places()
        self.availability.update_slots_availability()
        self.slot.refresh_from_db()

    def join(self, email, name="Jean Dupont", places=None, slot=None):
        payload = {"slot_id": (slot or self.slot).id, "email": email, "name": name}
        if places is not None:
            payload["places"] = places
        return self.client.post(
            reverse(JOIN_URL), data=json.dumps(payload), content_type="application/json"
        )

    def enroll(self, email, places=1):
        """Inscrit directement, sans passer par l'API (pour préparer un état)."""
        entry, _ = waitlist.join(self.slot, email, places=places)
        return entry


class JoinTests(WaitlistFixture):

    def test_slot_is_full(self):
        self.assertEqual(self.slot.remaining_places, 0)
        self.assertFalse(self.slot.is_available)

    def test_join_a_full_slot(self):
        resp = self.join("wait@example.com")
        self.assertEqual(resp.status_code, 200, resp.content)
        body = resp.json()
        self.assertTrue(body["success"])
        self.assertEqual(body["position"], 1)
        self.assertTrue(WaitlistEntry.objects.filter(email="wait@example.com").exists())

    def test_cannot_join_when_places_remain(self):
        free_type = AppointmentType.objects.create(
            name="Libre", user=self.user, duration=timedelta(hours=1),
            capacity=2, allow_waitlist=True,
        )
        self.availability.appointment_types.add(free_type)
        free_slot = Slot.objects.get(availability=self.availability, type=free_type)
        resp = self.join("wait@example.com", slot=free_slot)
        self.assertEqual(resp.status_code, 400)
        self.assertIn("encore de la place", resp.json()["message"])

    def test_cannot_join_when_waitlist_disabled(self):
        self.type.allow_waitlist = False
        self.type.save()
        resp = self.join("wait@example.com")
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(WaitlistEntry.objects.count(), 0)

    def test_joining_twice_is_idempotent(self):
        self.join("wait@example.com")
        resp = self.join("wait@example.com")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(
            WaitlistEntry.objects.filter(email="wait@example.com").count(), 1
        )

    def test_position_reflects_order(self):
        self.join("first@example.com")
        self.join("second@example.com")
        r3 = self.join("third@example.com")
        self.assertEqual(r3.json()["position"], 3)

    def test_invalid_email_refused(self):
        resp = self.join("pas-un-email")
        self.assertEqual(resp.status_code, 400)

    def test_honeypot_blocks_join(self):
        resp = self.client.post(
            reverse(JOIN_URL),
            data=json.dumps({"slot_id": self.slot.id, "email": "bot@example.com",
                             "name": "Bot", "company": "Acme"}),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 429)
        self.assertEqual(WaitlistEntry.objects.count(), 0)

    def test_full_slot_with_waitlist_appears_in_api(self):
        resp = self.client.get(reverse(AVAIL_URL))
        row = next((r for r in resp.json() if r["id"] == self.slot.id), None)
        self.assertIsNotNone(row)
        self.assertTrue(row["waitlist_open"])
        self.assertEqual(row["remaining_places"], 0)

    def test_full_slot_without_waitlist_absent_from_api(self):
        self.type.allow_waitlist = False
        self.type.save()
        resp = self.client.get(reverse(AVAIL_URL))
        self.assertNotIn(self.slot.id, [r["id"] for r in resp.json()])


class NotificationTests(WaitlistFixture):

    def setUp(self):
        super().setUp()
        # On coupe l'envoi réel d'e-mail : on teste la mécanique.
        patcher = mock.patch("jeiko.calendars.waitlist.send_waitlist_available_email"
                             if False else "jeiko.calendars.emailing.send_waitlist_available_email")
        self.mail = patcher.start()
        self.addCleanup(patcher.stop)

    def test_cancellation_notifies_first_in_line(self):
        first = self.enroll("first@example.com")
        self.enroll("second@example.com")

        with self.captureOnCommitCallbacks(execute=True):
            self.holder.cancel()

        first.refresh_from_db()
        self.assertEqual(first.status, WaitlistEntry.Status.NOTIFIED)
        self.assertIsNotNone(first.claim_expires_at)
        # La deuxième reste en attente.
        self.assertEqual(
            WaitlistEntry.objects.get(email="second@example.com").status,
            WaitlistEntry.Status.WAITING,
        )

    def test_notified_hold_keeps_the_place_occupied(self):
        self.enroll("first@example.com")
        with self.captureOnCommitCallbacks(execute=True):
            self.holder.cancel()

        # La place libérée par l'annulation est aussitôt tenue pour la personne
        # prévenue : le créneau reste complet pour tout le monde d'autre.
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 0)

    def test_notified_place_cannot_be_grabbed_by_a_stranger(self):
        self.enroll("first@example.com")
        with self.captureOnCommitCallbacks(execute=True):
            self.holder.cancel()

        # Un visiteur qui tente de réserver directement le créneau tenu échoue.
        resp = self.client.post(
            reverse(BOOK_URL),
            data=json.dumps({"slot_id": self.slot.id, "email": "intrus@example.com",
                             "name": "Intrus"}),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 400)

    def test_only_one_person_notified_at_a_time(self):
        self.enroll("first@example.com")
        self.enroll("second@example.com")
        with self.captureOnCommitCallbacks(execute=True):
            self.holder.cancel()

        notified = WaitlistEntry.objects.filter(status=WaitlistEntry.Status.NOTIFIED)
        self.assertEqual(notified.count(), 1)

    def test_entry_wanting_more_places_than_freed_is_skipped(self):
        # Créneau à 2 places, saturé par 2 réservations distinctes.
        self.type.capacity = 2
        self.type.max_places_per_booking = 2
        self.type.save()
        self.availability.save()
        slot = Slot.objects.get(pk=self.slot.pk)
        Appointment.objects.filter(pk=self.holder.pk).update(places=1)
        second_holder = Appointment.objects.create(
            type=self.type, slot=slot, start=slot.start, end=slot.end,
            email="holder2@example.com", places=1,
        )
        slot.sync_remaining_places()

        greedy = waitlist.join(slot, "greedy@example.com", places=2)[0]
        modest = waitlist.join(slot, "modest@example.com", places=1)[0]

        # Une seule place se libère : on saute la demande de 2 places.
        with self.captureOnCommitCallbacks(execute=True):
            second_holder.cancel()

        greedy.refresh_from_db()
        modest.refresh_from_db()
        self.assertEqual(greedy.status, WaitlistEntry.Status.WAITING)
        self.assertEqual(modest.status, WaitlistEntry.Status.NOTIFIED)


@override_settings(JEIKO_CALENDARS_WAITLIST_CLAIM_MINUTES=30)
class ClaimTests(WaitlistFixture):

    def setUp(self):
        super().setUp()
        patcher = mock.patch("jeiko.calendars.emailing.send_waitlist_available_email")
        patcher.start()
        self.addCleanup(patcher.stop)
        # Aussi couper l'e-mail de confirmation de réservation.
        patcher2 = mock.patch("jeiko.calendars.views.send_booking_emails_safe")
        patcher2.start()
        self.addCleanup(patcher2.stop)

    def _notified_entry(self):
        entry = self.enroll("first@example.com")
        with self.captureOnCommitCallbacks(execute=True):
            self.holder.cancel()
        entry.refresh_from_db()
        return entry

    def test_claim_page_shows_when_notified(self):
        entry = self._notified_entry()
        resp = self.client.get(entry.get_claim_url())
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(resp.context["claimable"])

    def test_claim_creates_confirmed_appointment(self):
        entry = self._notified_entry()
        with self.captureOnCommitCallbacks(execute=True):
            resp = self.client.post(entry.get_claim_url())
        self.assertEqual(resp.status_code, 200)

        entry.refresh_from_db()
        self.assertEqual(entry.status, WaitlistEntry.Status.CONVERTED)
        appt = Appointment.objects.get(email="first@example.com")
        self.assertEqual(appt.status, Appointment.Status.CONFIRMED)
        # Occupation inchangée : la place tenue est devenue le rendez-vous.
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 0)

    def test_claim_after_expiry_is_refused(self):
        entry = self._notified_entry()
        WaitlistEntry.objects.filter(pk=entry.pk).update(
            claim_expires_at=timezone.now() - timedelta(minutes=1)
        )
        resp = self.client.post(entry.get_claim_url())
        self.assertEqual(resp.status_code, 200)
        self.assertFalse(Appointment.objects.filter(email="first@example.com").exists())

    def test_expired_claim_notifies_next(self):
        first = self.enroll("first@example.com")
        second = self.enroll("second@example.com")
        with self.captureOnCommitCallbacks(execute=True):
            self.holder.cancel()

        # La première ne réserve pas : son délai expire.
        WaitlistEntry.objects.filter(pk=first.pk).update(
            claim_expires_at=timezone.now() - timedelta(minutes=1)
        )
        with self.captureOnCommitCallbacks(execute=True):
            released = waitlist.expire_claims()

        self.assertEqual(released, 1)
        first.refresh_from_db()
        second.refresh_from_db()
        self.assertEqual(first.status, WaitlistEntry.Status.EXPIRED)
        self.assertEqual(second.status, WaitlistEntry.Status.NOTIFIED)

    def test_leaving_while_notified_frees_the_place_for_next(self):
        first = self.enroll("first@example.com")
        second = self.enroll("second@example.com")
        with self.captureOnCommitCallbacks(execute=True):
            self.holder.cancel()
        first.refresh_from_db()
        self.assertEqual(first.status, WaitlistEntry.Status.NOTIFIED)

        with self.captureOnCommitCallbacks(execute=True):
            waitlist.leave(first)

        second.refresh_from_db()
        self.assertEqual(second.status, WaitlistEntry.Status.NOTIFIED)

    def test_management_command_expires_and_advances(self):
        first = self.enroll("first@example.com")
        self.enroll("second@example.com")
        with self.captureOnCommitCallbacks(execute=True):
            self.holder.cancel()
        WaitlistEntry.objects.filter(pk=first.pk).update(
            claim_expires_at=timezone.now() - timedelta(minutes=1)
        )
        out = StringIO()
        with self.captureOnCommitCallbacks(execute=True):
            call_command("jeiko_calendars_expire_waitlist", stdout=out)
        self.assertIn("libérée", out.getvalue())


@override_settings(JEIKO_CALENDARS_WAITLIST_CLAIM_MINUTES=30)
class PaidClaimTests(WaitlistFixture):
    CAPACITY = 1

    def setUp(self):
        super().setUp()
        self.type.is_paid = True
        self.type.price = Decimal("40.00")
        self.type.save()

        gw = mock.patch.object(
            payments, "get_gateway",
            return_value=mock.Mock(secret_key="sk", api_key="pk",
                                   webhook_secret="wh", is_active=True),
        )
        gw.start(); self.addCleanup(gw.stop)

        def _intent(appt):
            Appointment.objects.filter(pk=appt.pk).update(payment_intent_id="pi_wl")
            return "pi_wl_secret", "pk"
        ip = mock.patch.object(payments, "create_payment_intent", side_effect=_intent)
        ip.start(); self.addCleanup(ip.stop)

        for path in ("jeiko.calendars.emailing.send_waitlist_available_email",
                     "jeiko.calendars.views.send_appointment_email_safe"):
            pt = mock.patch(path); pt.start(); self.addCleanup(pt.stop)

    def test_claim_of_paid_type_goes_to_payment(self):
        entry = self.enroll("first@example.com")
        with self.captureOnCommitCallbacks(execute=True):
            self.holder.cancel()
        entry.refresh_from_db()

        with self.captureOnCommitCallbacks(execute=True):
            resp = self.client.post(entry.get_claim_url())
        # Redirection vers la page de paiement.
        self.assertEqual(resp.status_code, 302)
        self.assertIn("/paiement/", resp["Location"])

        appt = Appointment.objects.get(email="first@example.com")
        self.assertEqual(appt.status, Appointment.Status.PENDING_PAYMENT)
        self.assertEqual(appt.amount_due, Decimal("40.00"))
        entry.refresh_from_db()
        self.assertEqual(entry.status, WaitlistEntry.Status.CONVERTED)
