# jeiko/calendars/tests_payments.py
"""
Rendez-vous payants.

Stripe est simulé de bout en bout : aucun appel réseau, mais le contrat est
respecté — un PaymentIntent porte `metadata`, `status` et `amount_received`,
et c'est toujours Stripe qui fait autorité sur le statut, jamais le navigateur.
"""
import json
from datetime import timedelta
from decimal import Decimal
from io import StringIO
from unittest import mock

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.core.management import call_command
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from . import payments
from .forms import AppointmentTypeForm
from .models import Appointment, AppointmentType, Availability, Slot
from .payments import METADATA_KEY

User = get_user_model()

BOOK_URL = "api_calendars:api_book_appointment"


def fake_intent(appointment, status="succeeded", amount=None, intent_id="pi_test_123"):
    """PaymentIntent minimal, tel que Stripe le renvoie."""
    cents = amount if amount is not None else int(round(float(appointment.amount_due) * 100))
    return {
        "id": intent_id,
        "status": status,
        "amount": cents,
        "amount_received": cents if status == "succeeded" else 0,
        "client_secret": f"{intent_id}_secret_abc",
        "metadata": {METADATA_KEY: str(appointment.pk)},
    }


class PaidFixture(TestCase):
    PRICE = Decimal("45.00")

    def setUp(self):
        cache.clear()
        self.user = User.objects.create_user(username="prov", password="pwd12345")
        self.paid_type = AppointmentType.objects.create(
            name="Consultation", user=self.user, duration=timedelta(hours=1),
            capacity=3, max_places_per_booking=2,
            is_paid=True, price=self.PRICE,
        )
        start = (timezone.now() + timedelta(days=3)).replace(
            minute=0, second=0, microsecond=0
        )
        self.availability = Availability.objects.create(
            user=self.user, start=start, end=start + timedelta(hours=1)
        )
        self.availability.appointment_types.add(self.paid_type)
        self.slot = Slot.objects.get(availability=self.availability, type=self.paid_type)

        # Passerelle Stripe active, avec des clés factices.
        gateway_patch = mock.patch.object(
            payments, "get_gateway",
            return_value=mock.Mock(secret_key="sk_test_x", api_key="pk_test_x",
                                   webhook_secret="whsec_x", is_active=True),
        )
        gateway_patch.start()
        self.addCleanup(gateway_patch.stop)

        # StripeService.create_payment_intent -> PaymentIntent factice
        self.created_intents = []

        def _create_intent(appointment):
            intent = fake_intent(appointment)
            self.created_intents.append(intent)
            Appointment.objects.filter(pk=appointment.pk).update(
                payment_intent_id=intent["id"]
            )
            appointment.payment_intent_id = intent["id"]
            return intent["client_secret"], "pk_test_x"

        intent_patch = mock.patch.object(
            payments, "create_payment_intent", side_effect=_create_intent
        )
        intent_patch.start()
        self.addCleanup(intent_patch.stop)

    def book(self, email="client@example.com", places=None, slot=None):
        payload = {"slot_id": (slot or self.slot).id, "email": email, "name": "Jean Dupont"}
        if places is not None:
            payload["places"] = places
        return self.client.post(
            reverse(BOOK_URL), data=json.dumps(payload), content_type="application/json"
        )


class PaidBookingHoldsPlaceTests(PaidFixture):

    def test_booking_a_paid_type_awaits_payment(self):
        resp = self.book()
        self.assertEqual(resp.status_code, 200, resp.content)
        body = resp.json()
        self.assertTrue(body["payment_required"])
        self.assertIn("/paiement/", body["payment_url"])

        appt = Appointment.objects.get(email="client@example.com")
        self.assertEqual(appt.status, Appointment.Status.PENDING_PAYMENT)
        self.assertFalse(appt.is_paid)
        self.assertEqual(appt.amount_due, self.PRICE)
        self.assertIsNotNone(appt.hold_expires_at)

    def test_hold_occupies_the_place(self):
        self.book()
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 2)   # 3 - 1 tenue

    def test_amount_follows_the_number_of_places(self):
        self.book(places=2)
        appt = Appointment.objects.get(email="client@example.com")
        self.assertEqual(appt.amount_due, self.PRICE * 2)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 1)

    def test_no_google_sync_while_unpaid(self):
        with mock.patch("jeiko.calendars.signals.upsert_event") as upsert:
            self.book()
        upsert.assert_not_called()

    def test_no_confirmation_email_while_unpaid(self):
        with mock.patch("jeiko.calendars.views.send_booking_emails_safe") as mailer:
            self.book()
        mailer.assert_not_called()

    def test_payment_link_email_is_sent(self):
        # L'envoi passe par transaction.on_commit, qui ne se déclenche pas
        # spontanément dans un TestCase.
        with mock.patch("jeiko.calendars.views.send_payment_pending_email") as mailer:
            with self.captureOnCommitCallbacks(execute=True):
                self.book()
        self.assertEqual(mailer.call_count, 1)
        sent_appt = mailer.call_args.args[0]
        self.assertEqual(sent_appt.status, Appointment.Status.PENDING_PAYMENT)
        self.assertEqual(sent_appt.amount_due, self.PRICE)

    def test_no_payment_link_email_for_free_type(self):
        free = AppointmentType.objects.create(
            name="Gratuit", user=self.user, duration=timedelta(hours=1), capacity=1
        )
        self.availability.appointment_types.add(free)
        free_slot = Slot.objects.get(availability=self.availability, type=free)
        with mock.patch("jeiko.calendars.views.send_payment_pending_email") as mailer:
            with self.captureOnCommitCallbacks(execute=True):
                self.book(email="gratuit@example.com", slot=free_slot)
        mailer.assert_not_called()

    def test_free_type_is_confirmed_immediately(self):
        free = AppointmentType.objects.create(
            name="Découverte", user=self.user, duration=timedelta(hours=1), capacity=2
        )
        self.availability.appointment_types.add(free)
        free_slot = Slot.objects.get(availability=self.availability, type=free)

        resp = self.book(email="gratuit@example.com", slot=free_slot)
        self.assertEqual(resp.status_code, 200, resp.content)
        self.assertNotIn("payment_required", resp.json())
        appt = Appointment.objects.get(email="gratuit@example.com")
        self.assertEqual(appt.status, Appointment.Status.CONFIRMED)


class PaymentConfirmationTests(PaidFixture):

    def _pending(self):
        self.book()
        return Appointment.objects.get(email="client@example.com")

    def test_return_page_confirms_after_successful_payment(self):
        appt = self._pending()
        with mock.patch("stripe.PaymentIntent.retrieve", return_value=fake_intent(appt)):
            resp = self.client.get(appt.get_payment_return_url())
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(resp.context["paid"])

        appt.refresh_from_db()
        self.assertEqual(appt.status, Appointment.Status.CONFIRMED)
        self.assertTrue(appt.is_paid)
        self.assertIsNotNone(appt.paid_at)
        self.assertIsNone(appt.hold_expires_at)

    def test_unsuccessful_intent_leaves_appointment_pending(self):
        appt = self._pending()
        with mock.patch("stripe.PaymentIntent.retrieve",
                        return_value=fake_intent(appt, status="requires_payment_method")):
            self.client.get(appt.get_payment_return_url())
        appt.refresh_from_db()
        self.assertEqual(appt.status, Appointment.Status.PENDING_PAYMENT)

    def test_underpayment_is_refused(self):
        """Le montant encaissé fait foi, pas ce que dit le navigateur."""
        appt = self._pending()
        with mock.patch("stripe.PaymentIntent.retrieve",
                        return_value=fake_intent(appt, amount=100)):   # 1 € au lieu de 45
            self.client.get(appt.get_payment_return_url())
        appt.refresh_from_db()
        self.assertEqual(appt.status, Appointment.Status.PENDING_PAYMENT)

    def test_confirmation_is_idempotent(self):
        appt = self._pending()
        intent = fake_intent(appt)
        with mock.patch("stripe.PaymentIntent.retrieve", return_value=intent):
            self.client.get(appt.get_payment_return_url())
            appt.refresh_from_db()
            first_paid_at = appt.paid_at
            self.client.get(appt.get_payment_return_url())

        appt.refresh_from_db()
        self.assertEqual(appt.paid_at, first_paid_at)

    def test_webhook_confirms_the_appointment(self):
        appt = self._pending()
        _, confirmed = payments.confirm_from_webhook(fake_intent(appt))
        self.assertTrue(confirmed)
        appt.refresh_from_db()
        self.assertEqual(appt.status, Appointment.Status.CONFIRMED)

    def test_webhook_then_return_page_do_not_double_confirm(self):
        """Les deux chemins arrivent dans un ordre non garanti."""
        appt = self._pending()
        intent = fake_intent(appt)
        payments.confirm_from_webhook(intent)
        appt.refresh_from_db()
        paid_at = appt.paid_at

        with mock.patch("stripe.PaymentIntent.retrieve", return_value=intent):
            self.client.get(appt.get_payment_return_url())
        appt.refresh_from_db()
        self.assertEqual(appt.paid_at, paid_at)

    def test_webhook_on_unknown_appointment_is_harmless(self):
        intent = {"id": "pi_x", "status": "succeeded", "amount_received": 100,
                  "metadata": {METADATA_KEY: "999999"}}
        appointment, confirmed = payments.confirm_from_webhook(intent)
        self.assertIsNone(appointment)
        self.assertFalse(confirmed)

    def test_confirmation_email_is_sent_once_paid(self):
        appt = self._pending()
        # L'envoi passe par transaction.on_commit, qui ne se déclenche pas
        # spontanément dans un TestCase (la transaction est annulée).
        with mock.patch("jeiko.calendars.views.send_booking_emails_safe") as mailer, \
             mock.patch("stripe.PaymentIntent.retrieve", return_value=fake_intent(appt)):
            with self.captureOnCommitCallbacks(execute=True):
                self.client.get(appt.get_payment_return_url())
        mailer.assert_called_once_with(appt.pk)

    def test_no_email_when_payment_did_not_succeed(self):
        appt = self._pending()
        with mock.patch("jeiko.calendars.views.send_booking_emails_safe") as mailer, \
             mock.patch("stripe.PaymentIntent.retrieve",
                        return_value=fake_intent(appt, status="requires_payment_method")):
            with self.captureOnCommitCallbacks(execute=True):
                self.client.get(appt.get_payment_return_url())
        mailer.assert_not_called()


class HoldExpiryTests(PaidFixture):

    def _expire(self, appt):
        Appointment.objects.filter(pk=appt.pk).update(
            hold_expires_at=timezone.now() - timedelta(minutes=1)
        )
        appt.refresh_from_db()
        return appt

    def test_expired_hold_releases_the_place(self):
        self.book()
        appt = self._expire(Appointment.objects.get(email="client@example.com"))
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 2)

        released = payments.expire_holds()
        self.assertEqual(released, 1)

        appt.refresh_from_db()
        self.assertEqual(appt.status, Appointment.Status.CANCELLED)
        self.assertEqual(appt.cancelled_by, Appointment.CancelledBy.SYSTEM)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 3)

    def test_hold_still_valid_is_untouched(self):
        self.book()
        self.assertEqual(payments.expire_holds(), 0)
        appt = Appointment.objects.get(email="client@example.com")
        self.assertEqual(appt.status, Appointment.Status.PENDING_PAYMENT)

    def test_new_booking_reclaims_an_abandoned_place(self):
        """Un panier abandonné ne doit pas bloquer le créneau jusqu'au cron."""
        # On sature le créneau avec 3 réservations non réglées, puis on les périme.
        for i in range(3):
            self.book(email=f"abandon{i}@example.com")
        for appt in Appointment.objects.all():
            self._expire(appt)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 0)

        resp = self.book(email="nouveau@example.com")
        self.assertEqual(resp.status_code, 200, resp.content)
        self.assertTrue(
            Appointment.objects.filter(
                email="nouveau@example.com",
                status=Appointment.Status.PENDING_PAYMENT,
            ).exists()
        )

    def test_payment_page_reports_an_expired_hold(self):
        self.book()
        appt = self._expire(Appointment.objects.get(email="client@example.com"))
        resp = self.client.get(appt.get_payment_url())
        self.assertEqual(resp.status_code, 200)
        self.assertIn("unavailable", resp.context)
        appt.refresh_from_db()
        self.assertEqual(appt.status, Appointment.Status.CANCELLED)

    def test_management_command(self):
        self.book()
        self._expire(Appointment.objects.get(email="client@example.com"))
        out = StringIO()
        call_command("jeiko_calendars_expire_holds", stdout=out)
        self.assertIn("1 réservation", out.getvalue())

    def test_management_command_dry_run(self):
        self.book()
        self._expire(Appointment.objects.get(email="client@example.com"))
        out = StringIO()
        call_command("jeiko_calendars_expire_holds", dry_run=True, stdout=out)
        self.assertIn("à libérer", out.getvalue())
        self.assertEqual(
            Appointment.objects.get(email="client@example.com").status,
            Appointment.Status.PENDING_PAYMENT,
        )

    @override_settings(JEIKO_CALENDARS_PAYMENT_HOLD_MINUTES=5)
    def test_hold_duration_is_configurable(self):
        self.assertEqual(payments.hold_duration(), timedelta(minutes=5))


class RegistrationRequiredTests(PaidFixture):
    """Le drapeau « réservé aux inscrits » n'était appliqué nulle part."""

    def setUp(self):
        super().setUp()
        self.members_only = AppointmentType.objects.create(
            name="Suivi", user=self.user, duration=timedelta(hours=1),
            capacity=2, is_registration_required=True,
        )
        self.availability.appointment_types.add(self.members_only)
        self.members_slot = Slot.objects.get(
            availability=self.availability, type=self.members_only
        )

    def test_anonymous_visitor_is_refused(self):
        resp = self.book(email="anon@example.com", slot=self.members_slot)
        self.assertEqual(resp.status_code, 403)
        self.assertTrue(resp.json()["login_required"])
        self.assertEqual(Appointment.objects.count(), 0)

    def test_logged_in_visitor_is_accepted(self):
        client_user = User.objects.create_user(username="membre", password="pwd12345")
        self.client.force_login(client_user)
        resp = self.book(email="membre@example.com", slot=self.members_slot)
        self.assertEqual(resp.status_code, 200, resp.content)
        appt = Appointment.objects.get(email="membre@example.com")
        self.assertEqual(appt.user, client_user)
        self.assertEqual(appt.status, Appointment.Status.CONFIRMED)


class GatewayMisconfiguredTests(PaidFixture):

    def test_paid_booking_without_gateway_is_refused_cleanly(self):
        with mock.patch.object(payments, "is_available", return_value=False):
            resp = self.book()
        self.assertEqual(resp.status_code, 503)
        self.assertIn("indisponible", resp.json()["message"])
        # Aucune place ne doit rester tenue par une réservation impossible à régler
        self.assertEqual(Appointment.objects.count(), 0)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 3)

    def test_stripe_failure_rolls_the_booking_back(self):
        with mock.patch.object(payments, "create_payment_intent",
                               side_effect=RuntimeError("Stripe down")):
            resp = self.book()
        self.assertEqual(resp.status_code, 500)
        self.assertEqual(Appointment.objects.count(), 0)
        self.slot.refresh_from_db()
        self.assertEqual(self.slot.remaining_places, 3)


class PriceValidationTests(TestCase):
    BASE = {
        "name": "Consultation", "duration": "01:00:00", "color": "#2ecc40",
        "font": "Inter", "description": "", "capacity": 1,
        "max_places_per_booking": 1,
    }

    def test_paid_type_without_price_is_refused(self):
        form = AppointmentTypeForm({**self.BASE, "is_paid": True, "price": 0})
        self.assertFalse(form.is_valid())
        self.assertIn("price", form.errors)

    def test_paid_type_with_price_is_accepted(self):
        form = AppointmentTypeForm({**self.BASE, "is_paid": True, "price": "45.00"})
        self.assertTrue(form.is_valid(), form.errors)
        self.assertTrue(form.save(commit=False).requires_payment)

    def test_free_type_ignores_price(self):
        form = AppointmentTypeForm({**self.BASE, "is_paid": False, "price": 0})
        self.assertTrue(form.is_valid(), form.errors)
        self.assertFalse(form.save(commit=False).requires_payment)
