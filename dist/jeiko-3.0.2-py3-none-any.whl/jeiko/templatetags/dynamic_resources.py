from django import template
from django.db.models import QuerySet

# Imports wrapped in try/except to avoid hard errors if apps are missing/changed
try:
    from jeiko.shop.models import Product
except ImportError:
    Product = None

try:
    from jeiko.custom_objects.models import CustomObject
except ImportError:
    CustomObject = None

try:
    from jeiko.administration_pages.models import Page
except ImportError:
    Page = None

try:
    from jeiko.questionnaires_expert.models import ExpertTest
except ImportError:
    ExpertTest = None

register = template.Library()

@register.simple_tag
def get_resources(config):
    """
    Fetches resources based on DynResourceConfig.
    Returns a QuerySet or list of objects.
    """
    if not config:
        return []

    qs = []

    if config.source_type == 'PRODUCT' and Product:
        # La fiche n'est publiable que si le produit est en vente ET que son
        # CustomObject est publié : mêmes conditions que ProductView.
        qs = (
            Product.objects
            .filter(is_active=True, content__is_published=True)
            .select_related("type", "content", "content__main_image")
        )

        if config.product_type:
            # Le champ de Product s'appelle `type` : filtrer sur
            # `product_type` levait un FieldError sur tout carrousel ou
            # grille configuré avec un type de produit.
            qs = qs.filter(type=config.product_type)

    elif config.source_type == 'CUSTOM_OBJECT' and CustomObject:
        if config.custom_object_model:
            qs = (
                CustomObject.objects
                .filter(model=config.custom_object_model, is_published=True)
                .select_related("model", "main_image")
            )


    elif config.source_type == 'PAGE' and Page:
        qs = Page.objects.filter(active=True)
        if config.category:
            qs = qs.filter(category=config.category)
        if config.sub_category:
             qs = qs.filter(sub_category=config.sub_category)

    elif config.source_type == 'EXPERT_TEST' and ExpertTest:
         # Assuming ExpertTest has is_active or similar
         qs = ExpertTest.objects.all()
         if hasattr(ExpertTest, 'is_active'):
             qs = qs.filter(is_active=True)

    # Sorting
    if hasattr(qs, 'order_by'):
         qs = qs.order_by('-id')

    # Limiting
    if config.limit and isinstance(config.limit, int) and config.limit > 0:
        qs = qs[:config.limit]
        
    return qs
