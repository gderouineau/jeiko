# jeiko/administration_pages/tests_style_formulaire_rendu.py
"""
Le style d'un formulaire doit ARRIVER dans la page.

Ce qui s'est passé
------------------
Le style s'enregistrait, se relisait par l'API — et le bouton restait orange
quelle que soit la couleur choisie. En comparant le gabarit au modèle :

    le gabarit lisait          le modèle enregistre
    ----------------------     --------------------------
    style.btn_bg               button_bg_color
    style.btn_bg_hover         button_hover_bg_color
    style.btn_text_color       button_text_color
    style.btn_radius_px        button_radius_px
    style.title_font_size_px   title_size_px
    style.title_color          title_color        ← la seule qui coïncidait

**Cinq clés sur six ne correspondaient pas.** Tous les formulaires de tous les
sites portaient donc les valeurs codées en dur dans le gabarit, quel que soit
le réglage — depuis l'administration comme depuis l'API.

Rien ne pouvait le signaler : un gabarit qui lit une clé absente ne lève pas,
il prend son `default`. Même famille qu'A-12 (une classe jamais posée) et A-22
(des éléments écrits nulle part).

Le correctif
------------
Le gabarit passe par `ContentFormulaire.css_vars()`, l'accès normalisé du
modèle. Il n'y a plus qu'un endroit où les noms de clés sont écrits, donc plus
d'écart possible. Ces tests lisent le HTML rendu, seul endroit où le défaut
était observable.
"""

from django.template.loader import render_to_string
from django.test import RequestFactory, TestCase

from jeiko.administration_pages.models import ContentFormulaire


class StyleAppliqueTests(TestCase):
    def _rendu(self, style=None):
        formulaire = ContentFormulaire.objects.create(
            name="Contact", style=style or {}
        )
        return render_to_string(
            "administration_pages/content/partials/content_formulaire.html",
            {"formulaire": formulaire, "request": RequestFactory().get("/")},
        )

    def test_la_couleur_choisie_arrive_dans_la_page(self):
        rendu = self._rendu({"button_bg_color": "#b45309"})
        self.assertIn(
            "#b45309", rendu,
            "La couleur enregistrée n'atteint pas le rendu : le gabarit lit "
            "une clé que le modèle n'écrit pas.",
        )

    def test_toutes_les_cles_du_modele_atteignent_le_rendu(self):
        """
        Une seule clé oubliée suffit à rendre un réglage inopérant, sans
        erreur. On les vérifie donc toutes.
        """
        style = {
            "button_bg_color": "#111111",
            "button_hover_bg_color": "#222222",
            "button_text_color": "#333333",
            "title_color": "#444444",
            "button_radius_px": 7,
            "title_size_px": 29,
        }
        rendu = self._rendu(style)
        absentes = [
            cle for cle, valeur in style.items()
            if str(valeur) not in rendu
        ]
        self.assertEqual(
            absentes, [],
            "Clé(s) enregistrée(s) mais jamais rendue(s) — le réglage "
            "correspondant est sans effet.",
        )

    def test_un_formulaire_sans_style_garde_les_defauts_du_modele(self):
        """
        Les défauts du gabarit doivent être ceux du modèle, sinon un
        formulaire non réglé n'a pas l'apparence que l'administration annonce.
        """
        from jeiko.administration_pages.models import DEFAULT_FORM_STYLE

        rendu = self._rendu()
        self.assertIn(DEFAULT_FORM_STYLE["button_bg_color"], rendu)

    def test_le_leurre_reste_masque(self):
        """La réécriture du bloc de style ne doit pas l'avoir emporté."""
        rendu = self._rendu()
        self.assertIn("cf-hp", rendu)
        self.assertIn("-9999px", rendu)
