# jeiko/administration_pages/tests_horodatage.py
"""
Les horodatages qui servent de clé de cache doivent bouger. Toujours.

Le défaut
---------
`base.html` met le `<head>` en cache trente jours sous une clé qui contient
`metadata.updated_at`. L'API des agents écrivait le titre et la description
par `save(update_fields=["title", "description"])` — et Django n'écrit pas un
champ `auto_now` absent de `update_fields`. L'horodatage restait donc figé,
la clé de cache aussi, et la page continuait d'annoncer aux moteurs de
recherche l'ancien titre et l'ancienne description. Pendant trente jours.

Le symptôme était particulièrement traître : la base était juste. Relire la
page par l'API confirmait la nouvelle valeur. Seul le HTML servi au visiteur
mentait — et personne ne le compare à la base.

Ce qu'on verrouille
-------------------
Deux choses, parce que la première seule ne tiendrait pas :

* le comportement — une sauvegarde partielle fait bouger l'horodatage, sur
  chacun des modèles concernés ;
* la liste elle-même — toute clé `{% cache %}` de `base.html` qui repose sur
  un `updated_at` doit correspondre à un modèle inscrit ici. Sans ce second
  test, la clé de cache ajoutée l'an prochain ramènerait le défaut intact.
"""

import pathlib
import re
import time

from django.test import TestCase

from jeiko.administration.models import Logo, SiteIdentity, WebSite
from jeiko.administration_pages.models import Metadata, Page

#: Les modèles dont un `auto_now` sert de clé de cache dans `base.html`,
#: avec le nom sous lequel le gabarit les désigne.
SOUS_CACHE = {
    "metadata": Metadata,
    "identity": SiteIdentity,
    "logo": Logo,
}


class SauvegardePartielleTests(TestCase):
    """Le comportement, modèle par modèle."""

    def _verifier(self, objet, champ, valeur):
        avant = objet.updated_at
        self.assertIsNotNone(avant, "l'objet doit être horodaté au départ")
        time.sleep(0.01)  # la résolution est large ; on s'assure d'un écart

        setattr(objet, champ, valeur)
        objet.save(update_fields=[champ])   # SANS updated_at : c'est le piège
        objet.refresh_from_db()

        self.assertGreater(
            objet.updated_at, avant,
            f"{type(objet).__name__}.updated_at n'a pas bougé après une "
            f"sauvegarde partielle. Toute clé de cache qui en dépend est "
            f"désormais figée. Faire hériter le modèle de "
            f"jeiko.horodatage.HorodatageFiable.",
        )

    def test_metadonnees_de_page(self):
        page = Page.objects.create(title="Essai", url_tag="essai-horodatage")
        meta = Metadata.objects.create(page=page, title="Avant", description="x")
        self._verifier(meta, "title", "Après")

    def test_identite_du_site(self):
        site = WebSite.objects.first() or WebSite.objects.create()
        identite = getattr(site, "identity", None) or SiteIdentity.objects.create(
            website=site, name="Avant"
        )
        self._verifier(identite, "name", "Nouveau nom")

    def test_logo(self):
        logo = Logo.objects.create()
        self._verifier(logo, "mail_logo", "images/logo/mail/essai.png")


class ToutesLesClesSontCouvertesTests(TestCase):
    """
    La liste ci-dessus doit suivre le gabarit, pas l'inverse.

    On lit les clés `{% cache %}` de `base.html` et on vérifie que chaque
    `<quelque chose>.updated_at` qui y figure correspond à une entrée de
    `SOUS_CACHE`. Une clé nouvelle sur un modèle non protégé fait échouer ce
    test avec le nom qui manque — c'est tout ce qu'on lui demande.
    """

    GABARIT = (
        pathlib.Path(__file__).resolve().parent.parent
        / "templates" / "base.html"
    )

    #: `{% cache … %}` et tout ce qui suit jusqu'à la fermeture de la balise.
    _CACHE = re.compile(r"\{%\s*cache\s(.*?)%\}", re.DOTALL)
    #: `foo.bar.updated_at` — on ne garde que le segment qui précède.
    _HORODATAGE = re.compile(r"([A-Za-z_][\w]*)\.updated_at")

    def test_aucune_cle_ne_repose_sur_un_modele_non_protege(self):
        source = self.GABARIT.read_text()
        inconnus = set()
        for cle in self._CACHE.findall(source):
            for nom in self._HORODATAGE.findall(cle):
                if nom not in SOUS_CACHE:
                    inconnus.add(nom)

        self.assertEqual(
            inconnus, set(),
            "Clé de cache appuyée sur l'horodatage de "
            + ", ".join(sorted(inconnus))
            + ", qui n'est pas déclaré dans SOUS_CACHE. Si ce modèle peut "
              "être sauvegardé partiellement, son updated_at ne bougera pas "
              "et le fragment restera figé trente jours. L'ajouter ici et "
              "lui faire hériter de HorodatageFiable.",
        )

    def test_la_liste_ne_contient_pas_de_modele_devenu_inutile(self):
        """Une entrée qui ne correspond plus à aucune clé est un faux confort."""
        source = self.GABARIT.read_text()
        utilises = {
            nom
            for cle in self._CACHE.findall(source)
            for nom in self._HORODATAGE.findall(cle)
        }
        self.assertEqual(
            set(SOUS_CACHE) - utilises, set(),
            "SOUS_CACHE déclare un modèle qu'aucune clé de cache n'utilise "
            "plus. Le retirer, ou vérifier que la clé n'a pas été renommée.",
        )
