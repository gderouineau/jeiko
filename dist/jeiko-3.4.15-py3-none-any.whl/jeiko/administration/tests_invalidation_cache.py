# jeiko/administration/tests_invalidation_cache.py
"""
Changer une police, une couleur ou un logo doit se voir tout de suite.

Ce qui s'est passé
------------------
Une nouvelle échelle typographique a été posée par l'API. Les valeurs étaient
bien en base, l'API les relisait correctement — et le visiteur continuait de
recevoir l'ancienne feuille de style. On changeait une police, rien ne
bougeait, et on en concluait que le réglage ne fonctionnait pas.

`website_cache` garde l'objet de site pour éviter une requête à chaque rendu.
Son invalidation était branchée sur `WebSite`, `SiteIdentity`, `Logo` et
`Favicon` — **mais ni sur `Font`, ni sur `Fonts`, ni sur `Theme`**. La vue du
thème appelait `invalidate_website_data()` à la main ; celle des polices, non.

Le défaut touchait donc l'administration autant que l'API : il suffisait
d'emprunter un chemin qui n'y avait pas pensé.

Pourquoi ces tests portent sur le COMPORTEMENT
-----------------------------------------------
Vérifier qu'un signal est branché reviendrait à relire le code depuis le code.
Ce qui compte est observable : le cache est rempli, on écrit, le cache doit
être vide. Un correctif qui passerait par un autre chemin — un appel explicite,
un middleware — resterait juste au regard de ce test, et c'est bien ce qu'on
veut garantir.
"""

from django.core.cache import cache
from django.test import TestCase

from jeiko.administration.models import Font, Fonts, Theme, WebSite
from jeiko.administration.website_cache import (
    WEBSITE_DATA_KEY, get_website_data,
)


class InvalidationTests(TestCase):
    def _remplir_le_cache(self):
        get_website_data()
        self.assertIsNotNone(
            cache.get(WEBSITE_DATA_KEY),
            "Le cache doit être rempli avant qu'on puisse vérifier sa purge.",
        )

    def test_modifier_une_police_purge_le_cache(self):
        police = Font.objects.first()
        if police is None:
            self.skipTest("Aucune police en base.")

        self._remplir_le_cache()
        police.size = "42px"
        police.save(update_fields=["size"])

        self.assertIsNone(
            cache.get(WEBSITE_DATA_KEY),
            "Changer une police laissait le visiteur sur l'ancienne feuille "
            "de style jusqu'à l'expiration du cache.",
        )

    def test_modifier_le_theme_purge_le_cache(self):
        theme = Theme.objects.first() or Theme.objects.create()
        self._remplir_le_cache()
        theme.accent = "rgb(1, 2, 3)"
        theme.save(update_fields=["accent"])
        self.assertIsNone(cache.get(WEBSITE_DATA_KEY))

    def test_modifier_un_jeu_de_polices_purge_le_cache(self):
        jeu = Fonts.objects.first()
        if jeu is None:
            self.skipTest("Aucun jeu de polices en base.")
        self._remplir_le_cache()
        jeu.save()
        self.assertIsNone(cache.get(WEBSITE_DATA_KEY))

    def test_modifier_le_site_purge_le_cache(self):
        """Il l'était déjà : la correction ne doit pas le lui retirer."""
        site = WebSite.objects.first()
        self._remplir_le_cache()
        site.save(update_fields=["name"])
        self.assertIsNone(cache.get(WEBSITE_DATA_KEY))

    def test_supprimer_une_police_purge_aussi(self):
        police = Font.objects.create(size="10px", family="Essai")
        self._remplir_le_cache()
        police.delete()
        self.assertIsNone(cache.get(WEBSITE_DATA_KEY))
