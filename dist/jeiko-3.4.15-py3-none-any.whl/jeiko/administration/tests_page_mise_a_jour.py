# jeiko/administration/tests_page_mise_a_jour.py
"""
La page de mise à jour doit dire QUELLE version est disponible.

Ce qui manquait
---------------
Le job `cron_24h` relève la version publiée sur le canal et l'enregistre dans
`WebSite.update_available_version`. La donnée était donc là — et la page de
mise à jour ne l'affichait nulle part. On lisait « Version installée : 3.4.9 »
et un bouton, sans savoir ce qu'on allait installer, ni même s'il y avait
quelque chose à installer.

Trois états, et pas deux
------------------------
La distinction qui compte n'est pas « à jour / pas à jour » mais :

* une version est disponible — on dit laquelle ;
* la vérification a ÉCHOUÉ — on le dit, parce qu'un site coupé de son canal
  de publication avait exactement la même apparence qu'un site à jour, et
  restait donc à l'écart des correctifs sans que rien ne le signale ;
* la vérification a abouti et il n'y a rien — on rassure.

Confondre les deux derniers est le défaut qu'on ferme ici.
"""

import pathlib
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import SimpleTestCase, TestCase
from django.urls import reverse
from django.utils import timezone

from jeiko.administration.models import WebSite


class PageDeMiseAJourTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.admin = User.objects.create_superuser(
            "chef", "chef@exemple.fr", "Un-Mot-De-Passe-42"
        )
        self.client.force_login(self.admin)
        self.url = reverse("jeiko_administration:update_jeiko")
        self.site = WebSite.objects.first()

    def _regler(self, **champs):
        WebSite.objects.filter(pk=self.site.pk).update(**champs)

    def test_une_version_disponible_est_annoncee(self):
        self._regler(
            update_available_version="3.5.0",
            update_last_checked_at=timezone.now(),
            update_check_error="",
        )
        reponse = self.client.get(self.url)
        self.assertContains(reponse, "3.5.0")
        self.assertContains(reponse, "est")
        self.assertContains(reponse, "disponible")

    def test_un_echec_de_verification_ne_passe_pas_pour_un_site_a_jour(self):
        """
        Le défaut central : les deux cas donnaient la même page muette, et un
        site coupé de son canal avait l'air à jour.
        """
        self._regler(
            update_available_version="",
            update_last_checked_at=timezone.now(),
            update_check_error="Canal injoignable (timeout)",
        )
        reponse = self.client.get(self.url)
        self.assertContains(reponse, "Canal injoignable")
        self.assertNotContains(reponse, "Vous êtes à jour")

    def test_un_site_a_jour_le_dit(self):
        self._regler(
            update_available_version="",
            update_last_checked_at=timezone.now(),
            update_check_error="",
        )
        self.assertContains(self.client.get(self.url), "à jour")

    def test_sans_verification_aucune_annonce_n_est_faite(self):
        """
        Tant que le cron n'est pas passé, on ne sait rien — et affirmer « à
        jour » serait une affirmation sans fondement.
        """
        self._regler(
            update_available_version="",
            update_last_checked_at=None,
            update_check_error="",
        )
        reponse = self.client.get(self.url)
        self.assertNotContains(reponse, "Vous êtes à jour")


class PastilleApresLaMiseAJourTests(TestCase):
    """
    Q-13 — la pastille restait allumée après la mise à jour.

    Le scénario, en une phrase : le cron relève « le canal publie 3.4.6 »,
    l'administrateur clique, `jeiko-client-update` installe 3.4.6 — et
    `update_available_version` contient toujours « 3.4.6 ». Tous les lecteurs
    en déduisaient qu'une mise à jour attendait. Elle disparaissait au
    prochain passage du cron, jusqu'à vingt-quatre heures plus tard.

    Le défaut appartient à la famille de ceux qui ne lèvent rien : la donnée
    était exacte au moment où on l'a écrite, c'est le monde qui a bougé
    autour. On refait donc la comparaison à la lecture.
    """

    def setUp(self):
        # L'installation en crée un ; on ne veut surtout pas d'un second.
        self.site = WebSite.objects.first() or WebSite.objects.create()

    def _avec_version_installee(self, version):
        return patch(
            "jeiko.administration.update_check.installed_version",
            return_value=version,
        )

    def test_la_pastille_s_eteint_quand_la_version_est_installee(self):
        self.site.update_available_version = "3.4.6"
        with self._avec_version_installee("3.4.6"):
            self.assertEqual(self.site.mise_a_jour_disponible, "")

    def test_la_pastille_reste_allumee_tant_que_la_version_est_anterieure(self):
        self.site.update_available_version = "3.4.6"
        with self._avec_version_installee("3.4.5"):
            self.assertEqual(self.site.mise_a_jour_disponible, "3.4.6")

    def test_une_version_installee_plus_recente_eteint_aussi(self):
        """Mise à jour manuelle en avance sur le canal : rien à proposer."""
        self.site.update_available_version = "3.4.6"
        with self._avec_version_installee("3.5.0"):
            self.assertEqual(self.site.mise_a_jour_disponible, "")

    def test_une_version_installee_illisible_n_allume_rien(self):
        """`is_newer` refuse de trancher dans le doute — on n'invente pas."""
        self.site.update_available_version = "3.4.6"
        with self._avec_version_installee(None):
            self.assertEqual(self.site.mise_a_jour_disponible, "")

    def test_le_champ_perime_est_efface_une_fois(self):
        self.site.update_available_version = "3.4.6"
        self.site.save(update_fields=["update_available_version"])
        with self._avec_version_installee("3.4.6"):
            self.assertTrue(self.site.oublier_la_mise_a_jour_appliquee())
        self.site.refresh_from_db()
        self.assertEqual(self.site.update_available_version, "")

    def test_le_champ_encore_valide_n_est_pas_efface(self):
        self.site.update_available_version = "3.4.6"
        self.site.save(update_fields=["update_available_version"])
        with self._avec_version_installee("3.4.5"):
            self.assertFalse(self.site.oublier_la_mise_a_jour_appliquee())
        self.site.refresh_from_db()
        self.assertEqual(self.site.update_available_version, "3.4.6")


class AucunAffichageNeLitLeChampBrutTests(SimpleTestCase):
    """
    Le verrou de fond : plus personne ne décide d'un affichage sur le champ.

    Les tests ci-dessus prouvent que la propriété répond juste. Celui-ci
    prouve qu'on la CONSULTE — sans quoi un sixième lecteur écrit demain
    ramènerait le défaut intact, et aucun test ne le verrait.

    Le champ reste lisible là où c'est légitime : `update_check.py` l'écrit,
    le modèle et ces tests le manipulent, et `oublier_la_mise_a_jour_appliquee`
    le nettoie.
    """

    RACINE = pathlib.Path(__file__).resolve().parent.parent

    #: Fichiers autorisés à nommer le champ brut, avec la raison.
    DEROGATIONS = {
        "administration/models.py": "le déclare et porte la propriété",
        "administration/update_check.py": "l'écrit depuis le canal",
        "administration/tests_page_mise_a_jour.py": "le vérifie",
        "administration/management/commands/cron_24h.py": "le documente",
    }

    def test_les_gabarits_et_les_vues_passent_par_la_propriete(self):
        coupables = []
        for motif in ("*.py", "*.html"):
            for fichier in sorted(self.RACINE.rglob(motif)):
                if "__pycache__" in fichier.parts or "migrations" in fichier.parts:
                    continue
                relatif = str(fichier.relative_to(self.RACINE))
                if relatif in self.DEROGATIONS:
                    continue
                for numero, ligne in enumerate(
                    fichier.read_text(errors="ignore").splitlines(), 1
                ):
                    if "update_available_version" in ligne:
                        coupables.append(f"{relatif}:{numero} — {ligne.strip()}")

        self.assertEqual(
            coupables, [],
            "Lecture directe de update_available_version :\n  "
            + "\n  ".join(coupables)
            + "\nCe champ est un instantané du canal, pas la réponse à « une "
              "mise à jour existe-t-elle ». Utiliser "
              "« site.mise_a_jour_disponible », qui recompare à la version "
              "installée (Q-13).",
        )
