# jeiko/administration/tests_feuille_de_style_valide.py
"""
La feuille de style générée doit être VALIDE, et pas seulement présente.

Ce qui s'est passé
------------------
Une insertion dans `base_style.html` a coupé une règle en plein milieu d'une
variable Django : `font-size: {{font.size}` au lieu de `{{font.size}}`. La
page continuait de se rendre, le gabarit compilait, les tests passaient — et
le navigateur, lui, abandonnait le bloc `<style>` à la première accolade
manquante. **Toute la typographie du site tombait aux valeurs par défaut du
navigateur.**

Le défaut a été publié. Il ne s'est vu qu'en mesurant les styles calculés dans
un vrai navigateur : ni `manage.py check`, ni la compilation des gabarits, ni
aucun test existant ne regardait si le CSS produit tenait debout.

Ce que ces tests vérifient
--------------------------
Trois signes qu'une feuille générée est cassée, tous observables sans
navigateur :

* une variable de gabarit non rendue — `{{` ou `{%` dans la sortie ;
* un nombre d'accolades ouvrantes et fermantes qui ne s'équilibre pas ;
* une déclaration vide (`font-size: ;`), signe d'une valeur manquante.

Aucun ne prouve que le CSS est joli. Tous attrapent le cas où il ne se parse
plus du tout — qui est le seul à emporter le site entier.
"""

import re

from django.test import TestCase


class FeuilleGenereeTests(TestCase):
    def _styles_de_la_page(self):
        reponse = self.client.get("/")
        self.assertEqual(reponse.status_code, 200)
        html = reponse.content.decode()
        return "\n".join(re.findall(r"<style[^>]*>(.*?)</style>", html, re.DOTALL))

    def test_aucune_variable_de_gabarit_ne_reste_dans_le_css(self):
        css = self._styles_de_la_page()
        restes = re.findall(r"\{\{[^}]*\}?\}?|\{%[^%]*%\}", css)
        self.assertEqual(
            restes[:5], [],
            "Variable de gabarit non rendue dans le CSS : la règle est coupée, "
            "et le navigateur abandonne le bloc entier.",
        )

    def test_les_accolades_s_equilibrent(self):
        """
        Une accolade manquante fait tomber tout ce qui suit dans le bloc.
        C'est ce qui a emporté la typographie du site.
        """
        css = self._styles_de_la_page()
        self.assertEqual(
            css.count("{"), css.count("}"),
            f"Accolades déséquilibrées : {css.count('{')} ouvrantes pour "
            f"{css.count('}')} fermantes.",
        )

    #: Les propriétés dont une valeur vide trahit une variable mal nommée.
    #:
    #: `margin` et `padding` en sont exclus à dessein : un bloc dont les marges
    #: ne sont pas renseignées produit légitimement `margin: ;`. Le navigateur
    #: écarte la déclaration et poursuit — c'est peu soigné, pas dangereux.
    #: Les inclure ferait échouer le test sur un cas normal, et un test qui
    #: crie pour rien finit désarmé.
    PROPRIETES_SENSIBLES = ("font-size", "font-family", "font-weight",
                            "line-height", "color", "background")

    def test_aucune_propriete_de_police_sans_valeur(self):
        """
        `font-size: ;` signale une valeur absente — souvent une variable mal
        nommée, qui ne lève jamais et se contente de ne rien rendre.
        """
        css = self._styles_de_la_page()
        vides = [
            propriete for propriete in re.findall(r"([a-z-]+)\s*:\s*;", css)
            if propriete in self.PROPRIETES_SENSIBLES
        ]
        self.assertEqual(
            sorted(set(vides)), [],
            "Propriété(s) de police sans valeur : le réglage correspondant est "
            "sans effet, et rien ne le signale.",
        )

    def test_les_roles_de_police_sont_tous_rendus(self):
        """
        Un rôle absent de la feuille est un réglage que l'exploitant croit
        appliqué. On vérifie les sélecteurs, pas les valeurs.
        """
        css = self._styles_de_la_page()
        for selecteur in (".content h1", ".content p", ".content a", ".menu a",
                          "footer .credits"):
            with self.subTest(selecteur=selecteur):
                self.assertIn(selecteur, css)
