# signals.py
from django.db.models import Q, F
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from django.utils import timezone

from .models import (
    Favicon, Font, Fonts, Logo, SiteIdentity, SocialLink, Theme, WebSite,
)
from .website_cache import invalidate_website_data

def _bump_assets_for_websites_using_fonts(fonts_qs):
    # Toute modification de police invalide l'objet de site en cache : son
    # assets_version (bumpé ci-dessous via .update(), qui ne déclenche PAS le
    # post_save de WebSite) sert de buster au fragment site_assets_block du head.
    invalidate_website_data()

    if not fonts_qs.exists():
        return
    # Tous les sites qui pointent vers ces objets Fonts (phone/tablet/computer)
    sites_qs = WebSite.objects.filter(
        Q(fonts_phone__in=fonts_qs) |
        Q(fonts_tablet__in=fonts_qs) |
        Q(fonts_computer__in=fonts_qs)
    ).distinct()
    if sites_qs.exists():
        sites_qs.update(assets_version=F("assets_version") + 1)
        # Self-hosting des Google Fonts : on régénère le bundle woff2 + CSS local
        # des sites concernés. SYNCHRONE (les polices changent rarement) et à
        # erreurs isolées (jamais on ne casse un save si Google est injoignable).
        # La rafale de saves d'une même requête (h1..h6 puis Fonts) est amortie
        # par la mémo-cache CSS2 côté fonts_selfhost. list() fige des objets
        # WebSite frais après le .update() ci-dessus.
        from jeiko.fonts_selfhost import rebuild_for_websites
        rebuild_for_websites(list(sites_qs))

def _fonts_set_from_font(font_obj: Font):
    """Retourne les objets Fonts qui référencent ce Font dans n'importe quel champ."""
    return Fonts.objects.filter(
        Q(links=font_obj) |
        Q(links_hover=font_obj) |
        Q(menu=font_obj) |
        Q(menu_hover=font_obj) |
        Q(sub_menu=font_obj) |
        Q(sub_menu_hover=font_obj) |
        Q(text=font_obj) |
        Q(h1=font_obj) | Q(h2=font_obj) | Q(h3=font_obj) |
        Q(h4=font_obj) | Q(h5=font_obj) | Q(h6=font_obj)
    )

@receiver(post_save, sender=Font)
def bump_assets_on_font_save(sender, instance, **kwargs):
    fonts_qs = _fonts_set_from_font(instance)
    _bump_assets_for_websites_using_fonts(fonts_qs)

@receiver(post_delete, sender=Font)
def bump_assets_on_font_delete(sender, instance, **kwargs):
    fonts_qs = _fonts_set_from_font(instance)
    _bump_assets_for_websites_using_fonts(fonts_qs)

@receiver(post_save, sender=Fonts)
def bump_assets_on_fonts_save(sender, instance, **kwargs):
    _bump_assets_for_websites_using_fonts(Fonts.objects.filter(pk=instance.pk))

@receiver(post_delete, sender=Fonts)
def bump_assets_on_fonts_delete(sender, instance, **kwargs):
    _bump_assets_for_websites_using_fonts(Fonts.objects.filter(pk=instance.pk))


# --- Invalidation du cache de l'objet WebSite (website_cache.py) ---------------
# L'instance est cachée avec identity + logo joints ; toute édition de l'un de
# ces trois modèles doit purger le cache pour que le head (title, updated_at
# servant de buster) reflète la modification.
@receiver(post_save, sender=SocialLink)
@receiver(post_delete, sender=SocialLink)
def refresh_identity_on_social_change(sender, instance, **kwargs):
    """Le `sameAs` du JSON-LD identité dérive des SocialLink. Le fragment
    `site_identity_block` est caché 30 j, sa clé étant `identity.updated_at` :
    on touche donc SiteIdentity.updated_at pour forcer sa régénération, et on
    purge le cache de l'objet WebSite. `.update()` évite de re-déclencher un
    post_save (pas de récursion)."""
    invalidate_website_data()
    SiteIdentity.objects.filter(website_id=instance.website_id).update(
        updated_at=timezone.now()
    )


# Les polices et le thème invalident le cache au même titre que le reste.
#
# Ils en étaient absents, et le défaut ne se voyait pas : les données étaient
# bien enregistrées, la page relue par l'API disait vrai — mais le visiteur
# continuait de recevoir l'ancienne feuille de style jusqu'à l'expiration du
# cache. On changeait une police, rien ne bougeait, et on concluait que le
# réglage ne marchait pas.
#
# La vue du thème appelait `invalidate_website_data()` à la main ; celle des
# polices, non. Brancher le signal règle les deux, et couvre du même coup
# l'API des agents et toute écriture future : c'est le modèle qui décide, pas
# chaque appelant.
for _model in (WebSite, SiteIdentity, Logo, Favicon, Font, Fonts, Theme):
    post_save.connect(
        invalidate_website_data, sender=_model,
        dispatch_uid=f"jeiko_website_cache_save_{_model.__name__}",
    )
    post_delete.connect(
        invalidate_website_data, sender=_model,
        dispatch_uid=f"jeiko_website_cache_delete_{_model.__name__}",
    )
