# jeiko/agents/models.py
"""
Agents : des comptes machine, avec les mêmes droits que les comptes humains.

Le principe
-----------
Un agent **possède un `User`**. Ce n'est pas un détail d'implémentation, c'est
la décision structurante : tout ce qui existe déjà — le système de rôles
(`users/auth_backends.py`), les permissions Django, le journal de sécurité,
l'auteur d'une modification — continue de fonctionner sans une ligne de plus.
Inventer un système de droits parallèle aurait produit deux vérités sur « qui a
le droit de quoi », et l'une des deux aurait fini par mentir.

Ce compte ne peut pas se connecter par le formulaire : son mot de passe est
inutilisable (`set_unusable_password`) et il n'a pas d'adresse confirmée. Il
n'existe que pour porter des rôles et signer des modifications.

Les gardes, et ce que chacune couvre
------------------------------------
Aucune ne suffit seule ; c'est leur empilement qui fait la sécurité.

* **Le jeton haché** (`jetons.py`) — une base lue ne livre pas de quoi entrer.
* **`actif`** — la coupure immédiate, sans supprimer l'historique.
* **`expire_le`** — la coupure qu'on n'a pas besoin de penser à faire. Un agent
  créé pour un chantier de trois semaines devrait toujours en porter une.
* **`ips_autorisees`** — réduit l'usage d'un jeton divulgué à un réseau connu.
  Facultatif : un agent qui tourne chez un hébergeur à IP changeante ne peut
  pas s'en servir, et une garde qu'on désactive « en attendant » ne protège
  personne.
* **Les rôles** — ce que l'agent peut faire une fois entré. C'est là que se
  décide « modifier des pages oui, en supprimer non ».
* **`AppelAgent`** — ce qu'il a fait. Une action d'agent sans trace est une
  action que personne ne peut expliquer trois semaines plus tard.

Ce que cela ne protège pas
--------------------------
Un jeton divulgué reste utilisable jusqu'à sa révocation, depuis une IP
autorisée. Et un agent à qui l'on donne un rôle trop large fera exactement ce
que ce rôle permet : la vraie limite est le rôle, pas le jeton.
"""

from django.conf import settings
from django.db import models
from django.utils import timezone

from . import jetons


class Agent(models.Model):
    """Un consommateur machine de l'API, et le compte qui porte ses droits."""

    nom = models.CharField(
        "Nom",
        max_length=150,
        unique=True,
        help_text="Ce à quoi sert cet agent. Il apparaîtra dans le journal.",
    )
    description = models.TextField("Description", blank=True, default="")

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="agent",
        verbose_name="Compte porteur des droits",
        help_text="Créé automatiquement. C'est à lui qu'on assigne des rôles.",
    )

    actif = models.BooleanField(
        "Actif",
        default=True,
        db_index=True,
        help_text="Décoché, l'agent est refusé immédiatement, jetons compris.",
    )

    expire_le = models.DateTimeField(
        "Expire le",
        null=True,
        blank=True,
        help_text=(
            "Facultatif mais recommandé. Passée cette date, l'agent est refusé "
            "sans qu'on ait à y penser."
        ),
    )

    plafond_horaire = models.PositiveIntegerField(
        "Appels par heure",
        null=True,
        blank=True,
        help_text=(
            "Nombre d'appels autorisés par heure pour cet agent. Laisser vide "
            "pour le plafond du site. Un agent qui CONSTRUIT un site en "
            "consomme plusieurs centaines en une session — chaque bloc coûte "
            "deux ou trois appels ; un agent qui l'entretient en demande bien "
            "moins."
        ),
    )

    ips_autorisees = models.TextField(
        "Adresses IP autorisées",
        blank=True,
        default="",
        help_text=(
            "Facultatif. Une adresse par ligne. Laissé vide, l'agent est "
            "accepté depuis n'importe où."
        ),
    )

    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="agents_crees",
        verbose_name="Créé par",
    )
    cree_le = models.DateTimeField("Créé le", auto_now_add=True)
    maj_le = models.DateTimeField("Modifié le", auto_now=True)

    derniere_utilisation_le = models.DateTimeField(
        "Dernier appel", null=True, blank=True
    )
    derniere_ip = models.GenericIPAddressField(
        "Dernière adresse IP", null=True, blank=True
    )

    class Meta:
        verbose_name = "Agent"
        verbose_name_plural = "Agents"
        ordering = ("nom",)

    def __str__(self):
        return self.nom

    # ------------------------------------------------------------------ #
    #  État
    # ------------------------------------------------------------------ #
    @property
    def expire(self):
        return bool(self.expire_le and self.expire_le <= timezone.now())

    @property
    def utilisable(self):
        """Actif, non expiré, et son compte porteur n'est pas désactivé."""
        return bool(self.actif and not self.expire and self.user and self.user.is_active)

    @property
    def raison_de_refus(self):
        """
        Pourquoi cet agent serait refusé, en clair, pour l'écran d'administration.

        Ce texte ne sort JAMAIS par l'API : dire à un appelant *pourquoi* son
        jeton ne passe pas lui apprend l'état du système.
        """
        if not self.actif:
            return "désactivé"
        if self.expire:
            return "expiré"
        if self.user and not self.user.is_active:
            return "compte porteur désactivé"
        return ""

    def liste_ips(self):
        return [
            ligne.strip()
            for ligne in (self.ips_autorisees or "").splitlines()
            if ligne.strip()
        ]

    def ip_autorisee(self, ip):
        autorisees = self.liste_ips()
        return True if not autorisees else ip in autorisees

    def jetons_actifs(self):
        return self.jetons.filter(revoque_le__isnull=True)


class AgentToken(models.Model):
    """
    Un jeton d'accès. Plusieurs par agent, pour permettre une rotation sans
    coupure : on crée le nouveau, on bascule l'appelant, on révoque l'ancien.
    """

    agent = models.ForeignKey(
        Agent, on_delete=models.CASCADE, related_name="jetons", verbose_name="Agent"
    )

    #: Partie publique, celle qui permet de retrouver la ligne sans balayer la
    #: table — et sans comparer une empreinte contre chaque enregistrement.
    prefixe = models.CharField("Préfixe", max_length=32, unique=True, db_index=True)

    #: SHA-256 du secret. Le secret lui-même n'existe qu'une fois, à l'écran.
    empreinte = models.CharField("Empreinte", max_length=64)

    libelle = models.CharField(
        "Libellé",
        max_length=150,
        blank=True,
        default="",
        help_text="À quoi sert ce jeton — « poste de Guillaume », « CI »…",
    )

    cree_le = models.DateTimeField("Créé le", auto_now_add=True)
    cree_par = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="jetons_agents_crees",
        verbose_name="Créé par",
    )

    revoque_le = models.DateTimeField("Révoqué le", null=True, blank=True)
    derniere_utilisation_le = models.DateTimeField(
        "Dernier appel", null=True, blank=True
    )

    class Meta:
        verbose_name = "Jeton d'agent"
        verbose_name_plural = "Jetons d'agent"
        ordering = ("-cree_le",)

    def __str__(self):
        return f"{self.agent.nom} — {self.prefixe}"

    @property
    def revoque(self):
        return self.revoque_le is not None

    def revoquer(self):
        if not self.revoque:
            self.revoque_le = timezone.now()
            self.save(update_fields=["revoque_le"])

    @classmethod
    def creer(cls, agent, *, libelle="", cree_par=None):
        """
        Fabrique un jeton et renvoie `(objet, jeton_en_clair)`.

        Le jeton en clair est la SEULE occasion de le lire. L'appelant doit le
        montrer à l'exploitant et ne pas l'enregistrer.

        La boucle sur la collision de préfixe est théorique — 48 bits — mais
        une contrainte d'unicité qui lève en production sur un tirage au sort
        est exactement le genre de panne qu'on ne sait pas reproduire.
        """
        from django.db import IntegrityError

        for _ in range(5):
            prefixe, secret, en_clair = jetons.fabriquer()
            try:
                objet = cls.objects.create(
                    agent=agent,
                    prefixe=prefixe,
                    empreinte=jetons.empreinte(secret),
                    libelle=libelle,
                    cree_par=cree_par,
                )
            except IntegrityError:
                continue
            return objet, en_clair

        raise RuntimeError("Impossible de tirer un préfixe de jeton libre.")


class AppelAgent(models.Model):
    """
    Journal des appels. Un agent qui modifie un site sans laisser de trace est
    un agent dont on ne peut pas expliquer le travail après coup.

    On enregistre ce qui a été demandé et ce qui a été répondu — jamais le
    corps de la requête, qui peut être volumineux et contenir n'importe quoi.
    """

    agent = models.ForeignKey(
        Agent,
        on_delete=models.CASCADE,
        related_name="appels",
        null=True,
        blank=True,
        verbose_name="Agent",
    )
    prefixe_jeton = models.CharField(
        "Préfixe du jeton", max_length=32, blank=True, default=""
    )

    methode = models.CharField("Méthode", max_length=10)
    chemin = models.CharField("Chemin", max_length=300)
    statut = models.PositiveSmallIntegerField("Code de réponse")

    #: Renseigné quand l'appel est refusé. Codé, pas rédigé : il sert à
    #: l'exploitant, jamais à l'appelant.
    motif_refus = models.CharField(
        "Motif de refus", max_length=60, blank=True, default=""
    )

    ip = models.GenericIPAddressField("Adresse IP", null=True, blank=True)
    horodatage = models.DateTimeField("Le", default=timezone.now, db_index=True)

    class Meta:
        verbose_name = "Appel d'agent"
        verbose_name_plural = "Appels d'agents"
        ordering = ("-horodatage",)
        indexes = [models.Index(fields=["agent", "-horodatage"])]

    def __str__(self):
        return f"{self.methode} {self.chemin} → {self.statut}"
