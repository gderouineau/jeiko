# jeiko/agents/tests_style_formulaire.py
"""
L'apparence d'un formulaire doit être réglable par l'API.

Ce qui manquait
---------------
`ContentFormulaire.style` porte la couleur du bouton, celle du titre, le rayon
des angles. Il n'était pas exposé : tout formulaire posé par l'API gardait le
bleu par défaut (`#2563eb`), qui jure sur un site aux couleurs de la maison.

Un bouton d'envoi qui ne ressemble à aucun autre bouton de la page ressemble à
une erreur, pas à un choix — et c'est le dernier élément que voit quelqu'un
avant de nous écrire.

La validation reste au modèle
-----------------------------
`validate_form_style` impose des couleurs hexadécimales et borne les tailles.
On l'appelle plutôt que de recopier ses règles : une seconde validation
divergerait au premier réglage ajouté, et c'est toujours la copie qui a tort.

Conséquence à connaître : `var(--jk-accent)` n'est pas accepté. Il faut la
valeur — « #b45309 ».
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Bloc, Line, Page, Section

from .tests import SocleMixin, donner_le_role


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class StyleDuFormulaireTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent formulaires",
        )
        page = Page.objects.create(title="Contact", url_tag="contact-style")
        section = Section.objects.create(page=page, position=0)
        ligne = Line.objects.create(
            section=section, position=0, columns_type="12", columns_number=1
        )
        self.bloc = Bloc.objects.create(
            line=ligne, position=1, position_in_column=0
        )

    def _poser(self, formulaire):
        return self.client.put(
            f"/api/agent/v1/blocs/{self.bloc.id}/contenu/",
            data=json.dumps({"type": "FORM", "formulaire": formulaire}),
            content_type="application/json", **self.entetes(self.jeton),
        )

    def _relire(self):
        return self.client.get(
            f"/api/agent/v1/blocs/{self.bloc.id}/", **self.entetes(self.jeton)
        ).json()["bloc"]["contenu"]["formulaire"]

    def test_la_couleur_du_bouton_se_regle(self):
        reponse = self._poser({
            "nom": "Contact",
            "style": {"couleur_du_bouton": "#b45309",
                      "couleur_du_bouton_survol": "#92400e"},
        })
        self.assertEqual(reponse.status_code, 200, reponse.content[:200])

        self.bloc.refresh_from_db()
        style = self.bloc.content.content_formulaire.style
        self.assertEqual(style["button_bg_color"], "#b45309")
        self.assertEqual(style["button_hover_bg_color"], "#92400e")

    def test_la_relecture_rend_le_style(self):
        """Sans relecture, on ne peut pas corriger ce qu'on a posé."""
        self._poser({"nom": "Contact", "style": {"couleur_du_bouton": "#b45309"}})
        self.assertEqual(self._relire()["style"]["couleur_du_bouton"], "#b45309")

    def test_un_reglage_partiel_conserve_les_autres(self):
        self._poser({"nom": "Contact", "style": {
            "couleur_du_bouton": "#b45309", "rayon_du_bouton": 8}})
        self._poser({"nom": "Contact", "style": {"couleur_du_titre": "#181c26"}})

        style = self._relire()["style"]
        self.assertEqual(style["couleur_du_bouton"], "#b45309")
        self.assertEqual(style["rayon_du_bouton"], 8)
        self.assertEqual(style["couleur_du_titre"], "#181c26")

    def test_une_variable_css_est_refusee_avec_une_explication(self):
        """
        Le réflexe naturel est d'écrire `var(--jk-accent)`. Le modèle ne
        l'accepte pas ; le message doit le dire, sinon on essaie trois fois.
        """
        reponse = self._poser({
            "nom": "Contact", "style": {"couleur_du_bouton": "var(--jk-accent)"}})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("hexadécimal", reponse.json()["erreur"].lower())

    def test_un_rayon_hors_bornes_est_refuse(self):
        reponse = self._poser({"nom": "Contact", "style": {"rayon_du_bouton": 99}})
        self.assertEqual(reponse.status_code, 400)

    def test_une_cle_de_style_inconnue_est_refusee(self):
        reponse = self._poser({"nom": "Contact", "style": {"ombre": "grande"}})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("couleur_du_bouton", reponse.json()["erreur"])
