# jeiko/agents/tests_champs_de_page.py
"""
Tous les champs d'une page, y compris son classement et ses métadonnées.

Ce qui manquait
---------------
Un agent pouvait créer une page et en écrire le contenu, mais pas la CLASSER
(catégorie, sous-catégorie) ni déclarer sa nature (page d'accueil, gabarit de
fiche). Il s'arrêtait donc au milieu, laissant le reste à faire à la main —
et les pages qu'il créait restaient hors de tout classement, donc invisibles
des blocs qui filtrent par catégorie.

Les métadonnées, elles, n'étaient écrivables qu'APRÈS coup. Une page publiée
sans titre ni description de recherche part avec un handicap que personne ne
revient corriger : le bon moment pour les écrire est la création, pendant
qu'on sait de quoi la page parle.

Ce qui reste fermé, et pourquoi
--------------------------------
`is_protected` gouverne l'ACCÈS à la page, pas son contenu. Le confier à un
jeton reviendrait à laisser un agent retirer la protection d'une page réservée
— ou en protéger une par erreur, ce qui la ferait disparaître pour les
visiteurs sans que rien ne l'explique.
"""

import json

from django.test import TestCase, override_settings

from jeiko.administration_pages.models import Category, Page

from .tests import SocleMixin, donner_le_role

PAGES = "/api/agent/v1/pages/"
CATEGORIES = "/api/agent/v1/categories/"


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class ChampsDePageTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent pages",
        )
        self.categorie = Category.objects.create(name="Services", slug="services")
        self.sous = Category.objects.create(
            name="Électricité", slug="electricite", main_category=self.categorie
        )

    def _patch(self, page, corps):
        return self.client.patch(
            f"{PAGES}{page.id}/", data=json.dumps(corps),
            content_type="application/json", **self.entetes(self.jeton),
        )

    # --- Classement ----------------------------------------------------- #
    def test_une_page_se_classe_par_slug(self):
        page = Page.objects.create(title="Essai", url_tag="essai-classement")
        reponse = self._patch(page, {"categorie": "services",
                                     "sous_categorie": "electricite"})
        self.assertEqual(reponse.status_code, 200)

        page.refresh_from_db()
        self.assertEqual(page.category, self.categorie)
        self.assertEqual(page.sub_category, self.sous)

    def test_la_relecture_rend_les_slugs(self):
        page = Page.objects.create(
            title="Essai", url_tag="essai-relecture", category=self.categorie
        )
        lu = self.client.get(f"{PAGES}{page.id}/", **self.entetes(self.jeton)).json()
        self.assertEqual(lu["page"]["categorie"], "services")
        self.assertIsNone(lu["page"]["sous_categorie"])

    def test_une_categorie_inconnue_est_refusee_en_listant_les_connues(self):
        page = Page.objects.create(title="Essai", url_tag="essai-inconnue")
        reponse = self._patch(page, {"categorie": "plomberie"})
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("services", reponse.json()["erreur"])

    def test_on_peut_declasser_une_page(self):
        page = Page.objects.create(
            title="Essai", url_tag="essai-declassement", category=self.categorie
        )
        self._patch(page, {"categorie": None})
        page.refresh_from_db()
        self.assertIsNone(page.category)

    # --- Nature de la page ---------------------------------------------- #
    def test_les_drapeaux_de_nature_sont_ouverts(self):
        page = Page.objects.create(title="Essai", url_tag="essai-nature")
        self._patch(page, {"racine": True, "gabarit_de_fiche": True})
        page.refresh_from_db()
        self.assertTrue(page.is_root)
        self.assertTrue(page.is_custom_object_template)

    def test_la_protection_reste_fermee(self):
        """
        `protegee` se lit, ne s'écrit pas : c'est un contrôle d'accès.
        """
        page = Page.objects.create(title="Essai", url_tag="essai-protection")
        reponse = self._patch(page, {"protegee": True})
        self.assertEqual(reponse.status_code, 400)
        page.refresh_from_db()
        self.assertFalse(page.is_protected)

    # --- Métadonnées ---------------------------------------------------- #
    def test_les_metadonnees_s_ecrivent_des_la_creation(self):
        reponse = self.json_post(f"{PAGES}creer/", {
            "titre": "Nos formules",
            "url_tag": "nos-formules-test",
            "metadonnees": {"titre": "Nos formules — JEIKO",
                            "description": "Trois formules, le même outil."},
            "categorie": "services",
        }, self.jeton)
        self.assertEqual(reponse.status_code, 201)

        page = Page.objects.get(url_tag="nos-formules-test")
        self.assertEqual(page.metadata.title, "Nos formules — JEIKO")
        self.assertEqual(page.category, self.categorie)
        self.assertFalse(page.active, "Une page créée par un agent naît en brouillon.")


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class CategoriesTests(SocleMixin, TestCase):
    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent pages",
        )

    def test_la_liste_donne_les_slugs_et_la_hierarchie(self):
        parente = Category.objects.create(name="Services", slug="services")
        Category.objects.create(name="Électricité", slug="electricite",
                                main_category=parente)

        lu = self.client.get(CATEGORIES, **self.entetes(self.jeton)).json()
        par_slug = {c["slug"]: c for c in lu["categories"]}
        self.assertEqual(par_slug["electricite"]["categorie_parente"], "services")
        self.assertIsNone(par_slug["services"]["categorie_parente"])

    def test_une_categorie_se_cree_sous_une_autre(self):
        self.json_post(f"{CATEGORIES}creer/", {"nom": "Services"}, self.jeton)
        reponse = self.json_post(
            f"{CATEGORIES}creer/",
            {"nom": "Plomberie", "categorie_parente": "services"},
            self.jeton,
        )
        self.assertEqual(reponse.status_code, 201)
        self.assertEqual(
            Category.objects.get(slug="plomberie").main_category.slug, "services"
        )

    def test_un_slug_deja_pris_est_refuse(self):
        self.json_post(f"{CATEGORIES}creer/", {"nom": "Services"}, self.jeton)
        reponse = self.json_post(f"{CATEGORIES}creer/", {"nom": "Services"}, self.jeton)
        self.assertEqual(reponse.status_code, 400)


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class HierarchieEtRacineTests(SocleMixin, TestCase):
    """
    Deux cas que la base accepte et qui n'ont pourtant pas de sens.

    **Une sous-catégorie qui n'appartient pas à sa catégorie.** `category` et
    `sub_category` sont deux clés étrangères indépendantes : rien n'empêche de
    classer une page dans « Services » avec la sous-catégorie « Résultats de
    questionnaire ». Le classement devient incohérent, et personne ne le voit
    avant qu'un listage filtré revienne vide ou trop plein.

    **Une deuxième page racine.** Là, au contraire, la base refuse
    (`only_one_is_root_page`) — mais elle refuse par une `UniqueViolation`,
    c'est-à-dire une erreur 500 : un défaut de l'API rendu comme une panne du
    serveur. On transfère, parce que c'est ce que veut dire la demande.
    """

    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent pages",
        )
        self.services = Category.objects.create(name="Services", slug="services")
        self.elec = Category.objects.create(
            name="Électricité", slug="electricite", main_category=self.services
        )
        self.gabarits = Category.objects.create(name="Gabarits", slug="gabarits")
        self.sous_gabarit = Category.objects.create(
            name="Résultats", slug="resultats", main_category=self.gabarits
        )
        # Une catégorie de REGROUPEMENT : pas de slug, elle n'est dans aucune URL.
        self.regroupement = Category.objects.create(name="Interne", slug=None)

    def _patch(self, page, corps):
        return self.client.patch(
            f"{PAGES}{page.id}/", data=json.dumps(corps),
            content_type="application/json", **self.entetes(self.jeton),
        )

    def test_une_sous_categorie_d_une_autre_branche_est_refusee(self):
        page = Page.objects.create(title="Essai", url_tag="essai-branche")
        reponse = self._patch(page, {"categorie": "services",
                                     "sous_categorie": "resultats"})
        self.assertEqual(reponse.status_code, 400)
        message = reponse.json()["erreur"]
        self.assertIn("gabarits", message)
        page.refresh_from_db()
        self.assertIsNone(page.category, "Rien ne doit être écrit sur un refus.")

    def test_la_bonne_branche_passe(self):
        page = Page.objects.create(title="Essai", url_tag="essai-bonne-branche")
        self.assertEqual(
            self._patch(page, {"categorie": "services",
                               "sous_categorie": "electricite"}).status_code,
            200,
        )

    def test_la_categorie_deja_posee_est_prise_en_compte(self):
        """
        Envoyer la seule sous-catégorie doit se vérifier contre la catégorie
        DÉJÀ enregistrée — sinon le contrôle ne servirait qu'au premier appel.
        """
        page = Page.objects.create(
            title="Essai", url_tag="essai-partiel", category=self.services
        )
        reponse = self._patch(page, {"sous_categorie": "resultats"})
        self.assertEqual(reponse.status_code, 400)

    def test_une_categorie_de_regroupement_s_utilise_par_son_nom(self):
        """
        Sans slug, il reste le nom exact et l'identifiant. Refuser reviendrait
        à rendre inutilisables des catégories parfaitement légitimes.
        """
        page = Page.objects.create(title="Essai", url_tag="essai-regroupement")
        self.assertEqual(
            self._patch(page, {"categorie": "Interne"}).status_code, 200
        )
        page.refresh_from_db()
        self.assertEqual(page.category, self.regroupement)

        autre = Page.objects.create(title="Autre", url_tag="essai-par-id")
        self.assertEqual(
            self._patch(autre, {"categorie": str(self.regroupement.id)}).status_code,
            200,
        )

    def test_declarer_une_nouvelle_racine_transfere_l_ancienne(self):
        # Une page racine existe déjà — posée par une migration. C'est
        # justement la situation réelle : on ne part jamais d'un site sans
        # accueil.
        Page.objects.filter(is_root=True).update(is_root=False)
        ancienne = Page.objects.create(
            title="Accueil", url_tag="accueil-ancien", is_root=True
        )
        nouvelle = Page.objects.create(title="Nouvel accueil", url_tag="accueil-neuf")

        reponse = self._patch(nouvelle, {"racine": True})
        self.assertEqual(
            reponse.status_code, 200,
            "Une deuxième page racine levait une UniqueViolation — donc un 500.",
        )
        ancienne.refresh_from_db()
        nouvelle.refresh_from_db()
        self.assertFalse(ancienne.is_root)
        self.assertTrue(nouvelle.is_root)


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class CategoriesDansLUrlTests(SocleMixin, TestCase):
    """
    Une catégorie doit pouvoir organiser les ADRESSES, pas seulement classer.

    Ce qui manquait
    ---------------
    `Category.show_cat_in_url` décide si la catégorie apparaît dans l'adresse
    des pages qu'elle contient — `/documentation/api/` plutôt que `/api/`. Il
    vaut `False` par défaut et n'était pas exposé : une catégorie créée par
    l'API ne servait donc qu'au classement, jamais à l'organisation du site.

    Le défaut ne se voyait qu'en regardant l'adresse d'une page qu'on venait de
    classer — rien dans la réponse de l'API n'en parlait.

    Le second manque
    ----------------
    L'unicité du `url_tag` était vérifiée sur TOUT le site. La base, elle, ne
    l'impose qu'aux pages sans catégorie (`uniq_url_tag_when_no_category`).
    Deux pages « editeur-de-pages », l'une dans « Fonctionnalités » et l'autre
    dans « Documentation », étaient donc refusées — alors que leurs adresses
    diffèrent et que c'est exactement ce que demande une organisation en
    catégories.
    """

    def setUp(self):
        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent pages et catégories",
        )
        donner_le_role(
            self.agent.user, "view_category", "change_category",
            app="administration_pages", nom="Agent catégories url",
        )

    def _creer_categorie(self, **corps):
        return self.json_post("/api/agent/v1/categories/creer/", corps, self.jeton)

    def test_une_categorie_apparait_dans_l_url_par_defaut(self):
        """
        Une catégorie créée POUR ranger des pages est presque toujours
        destinée à se voir. Le défaut du modèle (`False`) produisait l'inverse.
        """
        self._creer_categorie(nom="Documentation", slug="documentation")
        reponse = self.json_post("/api/agent/v1/pages/creer/", {
            "titre": "API", "url_tag": "api", "categorie": "documentation",
        }, self.jeton)
        self.assertEqual(reponse.status_code, 201)
        self.assertEqual(reponse.json()["page"]["url"], "/documentation/api/")

    def test_une_categorie_de_regroupement_reste_hors_des_url(self):
        self._creer_categorie(nom="Interne", slug="interne",
                              afficher_dans_l_url=False)
        reponse = self.json_post("/api/agent/v1/pages/creer/", {
            "titre": "Notes", "url_tag": "notes", "categorie": "interne",
        }, self.jeton)
        self.assertEqual(reponse.json()["page"]["url"], "/notes/")

    def test_deux_pages_peuvent_partager_un_tag_dans_deux_categories(self):
        self._creer_categorie(nom="Fonctionnalités", slug="fonctionnalites")
        self._creer_categorie(nom="Documentation", slug="documentation")

        premiere = self.json_post("/api/agent/v1/pages/creer/", {
            "titre": "Éditeur", "url_tag": "editeur",
            "categorie": "fonctionnalites",
        }, self.jeton)
        seconde = self.json_post("/api/agent/v1/pages/creer/", {
            "titre": "Éditeur", "url_tag": "editeur",
            "categorie": "documentation",
        }, self.jeton)

        self.assertEqual(premiere.status_code, 201)
        self.assertEqual(
            seconde.status_code, 201,
            "Deux adresses distinctes étaient refusées : l'unicité était "
            "vérifiée sur tout le site alors que la base la porte par "
            "catégorie.",
        )
        self.assertNotEqual(
            premiere.json()["page"]["url"], seconde.json()["page"]["url"]
        )

    def test_un_doublon_dans_la_meme_categorie_reste_refuse(self):
        self._creer_categorie(nom="Documentation", slug="documentation")
        self.json_post("/api/agent/v1/pages/creer/", {
            "titre": "API", "url_tag": "api", "categorie": "documentation",
        }, self.jeton)
        reponse = self.json_post("/api/agent/v1/pages/creer/", {
            "titre": "API bis", "url_tag": "api", "categorie": "documentation",
        }, self.jeton)
        self.assertEqual(reponse.status_code, 409)
        self.assertIn("documentation", reponse.json()["erreur"])

    def test_une_sous_categorie_ne_se_montre_pas_sans_son_parent(self):
        """
        Le modèle l'interdit (`clean`). L'API doit le dire avant, sinon c'est
        une erreur de validation opaque au moment de l'enregistrement.
        """
        self._creer_categorie(nom="Interne", slug="interne",
                              afficher_dans_l_url=False)
        reponse = self._creer_categorie(
            nom="Notes", slug="notes-internes",
            categorie_parente="interne", afficher_dans_l_url=True,
        )
        self.assertEqual(reponse.status_code, 400)
        self.assertIn("parent", reponse.json()["erreur"])

    def test_une_categorie_se_corrige(self):
        creation = self._creer_categorie(
            nom="Documentation", slug="doc", afficher_dans_l_url=False
        )
        identifiant = creation.json()["categorie"]["id"]

        reponse = self.client.patch(
            f"/api/agent/v1/categories/{identifiant}/",
            data=json.dumps({"afficher_dans_l_url": True}),
            content_type="application/json", **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 200)
        self.assertTrue(reponse.json()["categorie"]["afficher_dans_l_url"])

    def test_le_slug_d_une_categorie_ne_se_modifie_pas(self):
        """Il est dans l'adresse de chaque page qu'elle contient."""
        creation = self._creer_categorie(nom="Documentation", slug="doc")
        identifiant = creation.json()["categorie"]["id"]
        reponse = self.client.patch(
            f"/api/agent/v1/categories/{identifiant}/",
            data=json.dumps({"slug": "autre"}),
            content_type="application/json", **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 400)


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class RepartitionDesColonnesTests(SocleMixin, TestCase):
    """
    Une répartition doit décrire TOUS les blocs de la ligne.

    Le piège, rencontré en montant jeiko.fr
    ----------------------------------------
    Pour empiler trois blocs sur téléphone, on écrit spontanément « 12 » — une
    colonne pleine largeur. Or « 12 » décrit une ligne d'UN bloc. Les deux
    suivants ne reçoivent aucune largeur : ils tombent à trente pixels, soit
    trois ou quatre caractères par ligne.

    Rien ne le signalait. La valeur figure dans les choix du modèle, elle
    s'enregistre, la page se rend — et le défaut ne se voit qu'en réduisant la
    fenêtre. Sur un site en service, il se voit surtout chez les visiteurs.

    La bonne valeur est « 12-12-12 » : autant de segments que de blocs.
    """

    def setUp(self):
        from jeiko.administration_pages.models import Bloc, Line, Section

        self.agent, self.jeton = self.creer()
        donner_le_role(
            self.agent.user, "view_page", "add_page", "change_page",
            nom="Agent répartitions",
        )
        page = Page.objects.create(title="Essai", url_tag="essai-repartition")
        section = Section.objects.create(page=page, position=0)
        self.ligne = Line.objects.create(
            section=section, position=0, columns_type="4-4-4", columns_number=3
        )
        for colonne in range(3):
            Bloc.objects.create(
                line=self.ligne, position=colonne + 1, position_in_column=0
            )

    def _patch(self, corps):
        return self.client.patch(
            f"/api/agent/v1/lignes/{self.ligne.id}/",
            data=json.dumps(corps), content_type="application/json",
            **self.entetes(self.jeton),
        )

    def test_une_repartition_trop_courte_est_refusee(self):
        reponse = self._patch({"columns_type_phone": "12"})
        self.assertEqual(reponse.status_code, 400)
        message = reponse.json()["erreur"]
        self.assertIn("12-12-12", message, "Le message doit donner la bonne valeur.")
        self.assertIn("écrasés", message)

    def test_la_bonne_repartition_passe(self):
        self.assertEqual(self._patch({"columns_type_phone": "12-12-12"}).status_code, 200)
        self.assertEqual(self._patch({"columns_type_tablet": "4-4-4"}).status_code, 200)

    def test_le_controle_vaut_pour_les_trois_appareils(self):
        for champ in ("columns_type", "columns_type_tablet", "columns_type_phone"):
            with self.subTest(champ=champ):
                self.assertEqual(self._patch({champ: "6-6"}).status_code, 400)

    def test_une_ligne_vide_n_est_pas_contrainte(self):
        """
        Une ligne se crée avant d'être remplie : refuser à ce moment-là
        interdirait de préparer la mise en page.
        """
        from jeiko.administration_pages.models import Line, Section

        section = Section.objects.get(pk=self.ligne.section_id)
        vide = Line.objects.create(
            section=section, position=1, columns_type="12", columns_number=1
        )
        reponse = self.client.patch(
            f"/api/agent/v1/lignes/{vide.id}/",
            data=json.dumps({"columns_type_phone": "12-12-12"}),
            content_type="application/json", **self.entetes(self.jeton),
        )
        self.assertEqual(reponse.status_code, 200)
