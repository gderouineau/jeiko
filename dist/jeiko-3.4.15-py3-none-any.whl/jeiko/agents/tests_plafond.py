# jeiko/agents/tests_plafond.py
"""
Le plafond d'appels doit se régler par agent.

Ce qui s'est passé
------------------
En montant jeiko.fr de zéro, l'agent a épuisé les six cents appels horaires du
défaut, puis s'est vu refuser — avec le même message que pour un jeton
invalide, puisque les refus ne se distinguent pas.

Le plafond n'était pas mal choisi : il est large pour un agent qui ENTRETIENT
un site. Il est trop juste pour un agent qui en CONSTRUIT un, parce que les
deux usages n'ont pas le même coût — monter une dizaine de pages demande
plusieurs centaines d'appels, chaque bloc en valant deux ou trois.

Un réglage unique ne peut pas servir les deux, et c'est l'usage initial — le
plus légitime, celui qu'on veut encourager — qui se trouvait empêché.

Ce que ces tests gardent
------------------------
* le plafond de l'agent l'emporte sur celui du site ;
* un agent sans plafond suit le site, et non une valeur figée — un site qui
  relève le sien doit emmener ceux qui n'ont rien demandé ;
* le compteur reste porté par le PRÉFIXE du jeton, pas par l'agent : deux
  jetons d'un même agent ne doivent pas se voler leur quota.
"""

import json

from django.test import TestCase, override_settings

from jeiko.agents.models import Agent
from jeiko.users.testing import reinitialiser_les_plafonds

from .tests import SocleMixin

QUI = "/api/agent/v1/qui-suis-je/"


@override_settings(JEIKO_AGENTS_AUTORISER_HTTP=True)
class PlafondParAgentTests(SocleMixin, TestCase):
    def setUp(self):
        reinitialiser_les_plafonds()
        self.agent, self.jeton = self.creer()

    def _appeler(self):
        return self.client.get(QUI, **self.entetes(self.jeton)).status_code

    def _regler(self, plafond):
        Agent.objects.filter(pk=self.agent.pk).update(plafond_horaire=plafond)

    @override_settings(JEIKO_AGENTS_LIMITS={"jeton": (2, 3600),
                                            "echecs_ip": (20, 900)})
    def test_sans_plafond_propre_on_suit_le_site(self):
        self.assertEqual(self._appeler(), 200)
        self.assertEqual(self._appeler(), 200)
        self.assertEqual(
            self._appeler(), 401,
            "Le plafond du site doit s'appliquer à un agent qui n'en a pas.",
        )

    @override_settings(JEIKO_AGENTS_LIMITS={"jeton": (2, 3600),
                                            "echecs_ip": (20, 900)})
    def test_le_plafond_de_l_agent_l_emporte(self):
        self._regler(5)
        for essai in range(5):
            with self.subTest(appel=essai + 1):
                self.assertEqual(
                    self._appeler(), 200,
                    "L'agent porte un plafond plus large que le site : c'est "
                    "le sien qui doit valoir.",
                )
        self.assertEqual(self._appeler(), 401)

    @override_settings(JEIKO_AGENTS_LIMITS={"jeton": (50, 3600),
                                            "echecs_ip": (20, 900)})
    def test_un_plafond_plus_bas_que_le_site_vaut_aussi(self):
        """Le réglage de l'agent tranche dans les deux sens."""
        self._regler(1)
        self.assertEqual(self._appeler(), 200)
        self.assertEqual(self._appeler(), 401)

    @override_settings(JEIKO_AGENTS_LIMITS={"jeton": (2, 3600),
                                            "echecs_ip": (20, 900)})
    def test_deux_jetons_du_meme_agent_ne_se_volent_pas_leur_quota(self):
        """
        Le compteur est porté par le préfixe du jeton. Le porter par l'agent
        ferait qu'un jeton de secours serait déjà épuisé au moment où on en a
        besoin.
        """
        from jeiko.agents.models import AgentToken

        second = AgentToken.emettre(self.agent)[1] if hasattr(
            AgentToken, "emettre") else None
        if second is None:
            self.skipTest("Pas d'émission de second jeton exposée.")

        self.assertEqual(self._appeler(), 200)
        self.assertEqual(self._appeler(), 200)
        self.assertEqual(self._appeler(), 401)

        autre = self.client.get(QUI, HTTP_AUTHORIZATION=f"Bearer {second}")
        self.assertEqual(autre.status_code, 200)


class ChampDuFormulaireTests(TestCase):
    def test_le_plafond_est_reglable_sur_la_fiche(self):
        """
        Sans champ au formulaire, le réglage n'existerait que pour qui sait
        écrire du SQL — c'est-à-dire pour personne.
        """
        from jeiko.agents.formulaires import AgentForm

        self.assertIn("plafond_horaire", AgentForm().fields)

    def test_vide_signifie_le_plafond_du_site(self):
        from jeiko.agents.formulaires import AgentForm

        champ = AgentForm().fields["plafond_horaire"]
        self.assertFalse(
            champ.required,
            "Le champ doit rester facultatif : vide = plafond du site.",
        )
