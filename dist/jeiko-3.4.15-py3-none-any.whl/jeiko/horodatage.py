"""
Un `save(update_fields=…)` ne bouge pas les champs `auto_now`.

Le problème que ça résout
-------------------------
Django renseigne un champ `auto_now` dans son `pre_save`. Mais quand on
passe `update_fields`, l'ORM n'écrit QUE les colonnes nommées : le
`pre_save` a beau calculer la nouvelle date, elle ne part pas en base. Une
sauvegarde partielle laisse donc l'horodatage figé, silencieusement.

Ce qui n'est d'ordinaire pas grave — sauf quand cet horodatage sert de clé
de cache.

Ce que ça a coûté
-----------------
`base.html` met le `<head>` en cache trente jours, sous une clé qui contient
`metadata.updated_at`. L'API des agents écrivait le titre et la description
par `save(update_fields=["title", "description"])`. La base était donc juste,
l'écriture confirmée, l'agent satisfait — et la page continuait de servir
l'ANCIEN titre et l'ANCIENNE description dans les résultats de recherche,
pendant trente jours. Rien ne levait, rien ne le montrait : il fallait
comparer le contenu de la base au HTML servi pour s'en apercevoir.

C'est la même famille que les autres défauts de ce paquet : une écriture qui
réussit et ne produit rien.

Ce que ça ne résout pas
-----------------------
Rien n'oblige un nouveau modèle à hériter d'ici. Le garde-fou est ailleurs :
`administration_pages/tests_horodatage.py` tient la liste des modèles dont
l'horodatage sert de clé de cache et vérifie que chacun survit à une
sauvegarde partielle.
"""

from django.db import models


class HorodatageFiable(models.Model):
    """Force les champs `auto_now` dans toute sauvegarde partielle.

    À poser sur tout modèle dont un `auto_now` sert de clé de cache. Le coût
    est d'une colonne de plus dans l'UPDATE — c'est-à-dire rien, puisqu'on
    écrivait déjà.
    """

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        champs = kwargs.get("update_fields")
        if champs is not None:
            champs = set(champs)
            champs.update(
                f.name for f in self._meta.fields
                if getattr(f, "auto_now", False)
            )
            kwargs["update_fields"] = champs
        return super().save(*args, **kwargs)
