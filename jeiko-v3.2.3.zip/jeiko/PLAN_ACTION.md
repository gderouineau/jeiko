# JEIKO — état des lieux et plan d'action

*Constat du 17/08/2026, tenu à jour au fil des correctifs.*

Ce document est la mémoire du chantier : il porte les constats, ce qui est
livré, ce qui reste, et les décisions prises. Les identifiants (`S-01`, `A-12`,
`Q-11`…) sont ceux cités dans les commentaires du code.

Légende : `[x]` fait · `[~]` partiel · `[ ]` à faire

Pour les conventions de travail (où éditer, comment vérifier, les pièges) :
voir `CLAUDE.md` à la racine de `Documents/Projects`.

---

## Où en est-on

Publié en **3.2.2** le 21/08/2026. À cette date :

| | |
|---|---|
| Tests | **637 passent** (558 avant le chantier) |
| Gabarits | 283, **0 erreur de compilation** |
| `check` / migrations | aucun problème, aucune migration manquante |

---

## 1. Livré

### Défauts visibles par les visiteurs

- `[x]` **A-12 — le menu mobile ne s'ouvrait sur aucun layout.** Le binding
  Alpine était décomposé : `mobile ? 'is-open' : ''` se trouvait *à l'intérieur*
  de l'attribut `class`, avec un `:` orphelin à la place de `:class`. La classe
  `is-open` n'était jamais posée, et `toggle_menu.html` laissait donc le panneau
  en `display:none`. **Le site public était sans navigation sur mobile.**
  Verrouillé par `administration_menu/tests_layouts.py`.

- `[x]` **Q-11 — le CSS de production avait neuf à onze mois de retard.**
  L'éditeur chargeait `main.css`, le site public `main.min.css`, maintenu à la
  main : 175 sélecteurs sur 370 manquaient en ligne. C'est l'origine des écarts
  observés entre l'éditeur et le rendu réel. La minification se fait désormais à
  `collectstatic` (`jeiko/staticfiles.py`), les `.min.css` ont disparu du paquet.

- `[x]` **Q-11 bis — deux défauts de mon propre correctif, corrigés après la
  première mise en production.** Le balayage portait sur tout `STATIC_ROOT`, donc
  sur des fichiers périmés que `collectstatic` n'efface jamais ; et le filtre
  « déjà minifié » testait le suffixe `.min.css`, que l'empreinte
  (`main.min.<hash>.css`) fait échouer. D'où dix traces `csscompressor` par
  déploiement, sans conséquence mais bruyantes.

- `[x]` **S-05 — le bloc graphique était mort dès qu'on le configurait.**
  `options_json` est un `JSONField` rendu en repr Python dans `x-data` :
  `{'beginAtZero': True}` sortait avec `True`, inexistant en JavaScript, d'où une
  `ReferenceError` et aucun graphique. Toute option contenant un booléen ou un
  `null` cassait l'affichage. Les options passent par un bloc
  `<script type="application/json">`.

- `[x]` **Le bandeau cookies était partiellement non stylé en ligne.** La branche
  non-DEBUG de `base.html` ne chargeait ni `menu.css`, ni `consent.css` — seule
  la branche DEBUG était complète, ce qui rendait l'écart invisible en
  développement.

- `[x]` **Les leurres anti-robots étaient visibles.** `.cf-hp` n'était stylé
  nulle part : le champ « Société » du formulaire de contact s'affichait, les
  visiteurs le remplissaient de bonne foi, et leur message était rejeté.

### Inscription et comptes

- `[x]` **S-15 — confirmation d'adresse obligatoire.**
  `ACCOUNT_EMAIL_VERIFICATION = "mandatory"`. Le compte ne sert qu'une fois le
  lien suivi.
- `[x]` **Bienvenue et alerte à l'exploitant déplacées** de `user_signed_up` vers
  `email_confirmed` : plus de « Bienvenue » avant confirmation, et l'exploitant
  n'est prévenu que des comptes qui existent vraiment.
- `[x]` **Antispam à l'inscription** — leurre + trois plafonds par IP
  (`users/throttling.py`). Le formulaire reçoit la requête par
  `CustomSignupView.get_form_kwargs` : `SignupForm` d'allauth ne la prend pas, et
  sans elle le plafond serait global.
- `[x]` **Purge des comptes non confirmés à 30 jours** (`users/purge.py`, inscrite
  dans `cron_24h`). Protège le personnel et tout compte porteur d'une commande,
  d'une formation ou d'un rendez-vous.
- `[x]` **Migration `users/0010`** — marque vérifiés les comptes antérieurs.
  **Indispensable et non réversible** : sans elle, le passage en `mandatory`
  enfermait dehors la totalité des comptes existants.
- `[x]` **Suppression de comptes** — unitaire et en masse, avec refus motivé.
  À distinguer de l'effacement RGPD : `Supprimer` retire la ligne (faux comptes),
  `Effacer les données` anonymise et conserve les commandes (demande d'un client).

### E-mails

- `[x]` **Logo dédié aux e-mails** (`Logo.mail_logo`, facultatif). Sa présence
  vaut activation ; vide, on retombe sur le logo du site.
- `[x]` **Correction du logo servi.** `_logo_url` prenait `computer_size`, une
  variante **WebP** — format qu'Outlook pour Windows n'affiche pas. Tous les
  e-mails partaient avec un logo cassé chez une partie des destinataires.
  L'ordre est maintenant : logo dédié → original (PNG/JPEG) → variantes WebP.
- `[x]` **Absence d'URL de site journalisée.** Sans elle, toutes les images de
  tous les e-mails sont relatives donc cassées — et invisible depuis
  l'administration, puisque le site les affiche parfaitement.

### Sécurité et conformité

- `[x]` **S-04** — les trois générateurs JSON échappent `<`, `>`, `&`
  (identité du site, boutique, questionnaires).
- `[x]` **S-13** — les deux fragments d'éditeur exigent `change_page`.
- `[x]` **S-17** — `X_FRAME_OPTIONS = "DENY"`, avec
  `@xframe_options_sameorigin` sur la seule vue d'aperçu d'e-mail.
- `[x]` **S-18** — `css_vars` nettoie avant d'interpoler dans un attribut `style`.
- `[x]` **R-03** — l'avatar est effacé du disque à l'effacement RGPD.
- `[x]` **R-04** — `stats_purge` et `jeiko_calendars_purge` inscrites dans
  `cron_24h` : elles existaient et n'étaient appelées nulle part.
- `[x]` **Q-03** — file d'écriture des statistiques plafonnée (1000).
- `[x]` **Q-01** — écran d'arborescence des profils de questionnaire, et
  suppression des deux gabarits qui ne compilaient pas.
- `[x]` **E-04, A-10a, D-04, Q-10** — cache du `<title>`, `<h1>` sur les pages
  d'erreur, page 500 autonome, fichiers morts.

### Corrections d'audits antérieurs

`AUDIT_EDITOR.md` est à réviser sur trois points :

- **C3** y est marqué « volontairement non fait » : il **a été fait** depuis, via
  `administration_pages/page_cache.py`.
- **F5** affirme que `menu_design_1.css` « est bien utilisé » : **non**.
- **B11** décrit une redéfinition d'`addInline` dans un gabarit : il y en a
  **sept**.

`AUDIT_COURSES.md` — ses quatre points sont bien corrigés.

**E-01 était un faux positif** : produits et formations sont déjà correctement
traités (`CustomObject.get_absolute_url()` renvoie l'URL boutique ; l'espace
formation est volontairement en `noindex`).

---

## 2. Reste à faire, par ordre proposé

### Phase 1 — sécurité, correctifs ponctuels · ~1 j

- `[ ]` **S-01 — chiffrer `credentials_json`** (`calendars/models.py:51`).
  Le JSON de compte de service Google, clé privée RSA comprise, est en clair.
  `EncryptedJSONField` existe et sert déjà dans `courses/models.py:325`.
  Migration de données nécessaire pour rechiffrer l'existant.
- `[ ]` **S-11 / S-10** — validateurs sur le PDF de formation ;
  `Image.MAX_IMAGE_PIXELS` à 25 Mpx et plafond de 10 Mo par image *(validé)*.
- `[ ]` **S-12** — valider les 6 redirections, sur le modèle de
  `administration_pages/views.py:3091`.
- `[ ]` **S-14** — `PaymentCheckView` : vérifier le `client_secret`, ajouter
  `LoginRequiredMixin`.
- `[ ]` **S-06** — `clean_svg` : couvrir les balises auto-fermantes
  (`<animate/>`, `<set/>`) et les entités encodées.

### Phase 2 — RGPD · ~1 j

- `[ ]` **R-01 — le bandeau promet un réglage qui n'existe pas.**
  `window.jeikoStartAnalytics` n'est défini nulle part, et `stats/middleware.py`
  mesure sans consulter le consentement. Votre décision « aucun cookie non
  obligatoire » simplifie sans supprimer : l'écart entre ce que le bandeau
  annonce et ce que le site fait reste à refermer.
- `[ ]` **R-02** — les six `except Exception: pass` de l'effacement RGPD
  (`users/rgpd.py`) : journaliser et remonter l'échec partiel.
- `[ ]` **R-05** — rétention sur `SecurityEvent` et `UserSession`.
- `[ ]` **R-06** — auto-héberger FontAwesome (page publique !) et Inter (admin).

### Phase 3 — référencement · ~1 j

- `[ ]` **E-05 / D-06 — un seul chantier.** `SocialLink` n'a ni formulaire ni
  écran, *donc* le `sameAs` du JSON-LD reste vide. **Priorité 1 SEO.**
- `[ ]` **E-06** — image de partage par défaut + `og:image:width/height/alt`.
- `[ ]` **E-03** — `robots.txt` ne doit plus lister les pages dépubliées.
- `[ ]` **S-09** — `ACCOUNT_RATE_LIMITS` sur un cache dédié : aujourd'hui
  publier une page remet à zéro le compteur anti-force-brute d'allauth.
- `[ ]` **S-07 / S-08** — jeton CSRF sur la réservation publique ; plafond et
  leurre sur le questionnaire.
- `[~]` **E-02** — multilingue, reporté (dépend de Q-07).

### Phase 4 — responsive de l'administration · ~2,5 j · **urgent**

Chantier commencé puis laissé. `.jk-filters` (admin_ui.css) vient d'être adopté
par la liste des utilisateurs : cinq filtres passent de dix lignes à deux.

- `[ ]` **A-14** — généraliser `.jk-filters` aux autres écrans à filtres.
- `[ ]` **A-15** — tableaux en cartes sous 768 px. *À trancher* : défilement
  latéral (peu coûteux, se lit de travers) ou bascule en cartes (recommandé,
  commencer par utilisateurs / commandes / rendez-vous).
- `[ ]` **A-16** — cibles tactiles d'au moins 44 px.

### Phase 5 — accessibilité, le socle · ~2 j

- `[ ]` **A-01** — `<main>` et lien d'évitement. Aucun écran d'administration
  n'a de repère principal.
- `[ ]` **A-02** — `aria-describedby` vers l'aide, `aria-invalid` sur les
  erreurs. `includes/field.html` pose déjà l'`id`, aucun champ ne le référence.
- `[ ]` **A-03** — 135 `<label>` sans `for`, dont
  `product_form.html:447` où le `=` manque.
- `[ ]` **A-04** — retirer `role="menu"`/`menuitem`, ajouter `aria-haspopup`.
- `[ ]` **A-05** — sous-menus ouvrables au clic et au clavier (desktop
  uniquement : sur mobile ils sont déjà `display:block`).
- `[ ]` **A-06** — `aria-current="page"`.
- `[ ]` **D-07** — reprendre les designs de menu abandonnés (mêmes fichiers).

### Phase 6 — accessibilité, finition · ~1,5 j

- `[ ]` **A-07** — contrastes : onglet actif à 1,05:1, bordures de champ à
  1,3:1, anneau de focus à 20 % d'opacité.
- `[ ]` **A-08** — `@media (forced-colors: active)`.
- `[ ]` **A-09** — alt obligatoire avec case « image décorative ».
  *Attention* : un alt par défaut automatique est **contre-productif** — le
  lecteur d'écran annonce « image, image ». Il faut un alt écrit, ou vide.
- `[ ]` **A-10** — 404 et 403 éditables. *La 500 ne peut pas l'être* (elle
  s'affiche quand la base est tombée) : la rendre éditable en administration,
  puis en écrire une copie statique sur disque.
- `[ ]` **D-03** — paginer les 14 listes d'administration.

### Phase 7 — thème de l'administration · ~1,5 j

- `[ ]` **A-13** — palette d'accent au choix (6-7 teintes validées en
  contraste), stockée sur `WebSite`.
- `[ ]` **A-11** — mode sombre (`prefers-color-scheme`). *Distinct de A-13* :
  l'un suit le système, l'autre est un choix de couleur.
- `[ ]` **D-09** — unifier les cinq `:root` concurrents (préalable aux deux).

### Phase 8 — robustesse et nettoyage · ~1,5 j

- `[ ]` **Q-05** — sept redéfinitions d'`addInline` en collision avec
  `formsets.js`.
- `[ ]` **Q-02** — journaliser les 28 `except Exception: pass` restants.
- `[ ]` **Q-08** — classifier `Django :: 5.1` faux dans
  `packages/jeiko/pyproject.toml` (hors du périmètre habituel).
- `[ ]` **D-08** — Cookies, Pages légales et Identité sous le système de rôles.
- `[ ]` **D-02** — généraliser `includes/field.html` aux 30 écrans les plus vus.

### Phase 9 — génération de PDF · ~4 j

`Page.is_pdf` **existe déjà** (`models.py:202`) et ne sert qu'à exclure ces pages
du sitemap : le concept était prévu, jamais construit. `emailing/render.py`
(620 lignes, une `Page` → du HTML d'e-mail) est le patron exact à décliner.

- `[ ]` **D-10** — moteur de rendu PDF (WeasyPrint).
- `[ ]` **D-11** — écran des gabarits PDF.
- `[ ]` **D-05** — certificat de formation (aujourd'hui `# TODO`).
- `[ ]` **D-12** — restitution de questionnaire en PDF.

### Phase 10 — rapports périodiques · ~3 j

`envoyer_le_recapitulatif_quotidien()` existe (`emailing/admin_alerts.py`) mais
est figé : une cadence, des indicateurs en dur, aucun réglage.

- `[ ]` **D-13** — préférences par destinataire, cadences cumulables.
- `[ ]` **D-14** — rapport d'inscriptions (quotidien / hebdo / mensuel).
- `[ ]` **D-15** — rapport d'activité en **compteurs** : questionnaires,
  commandes, rendez-vous, prospects, visites. Jusqu'à l'annuel.
- `[ ]` **D-16** — écran de réglage et gabarits au catalogue.

*Deux points à trancher avant d'écrire* : les cadences longues ne peuvent pas
passer par `cron_24h` seul — mémoriser la dernière période envoyée, sur le
modèle de `GoogleCalendarConfig.last_digest_sent_on`. Et il faut des compteurs
avec comparaison à la période précédente, pas des listes : sur un mois, une
liste ne dit rien.

### Phase 11 — tests · ~2 j

- `[ ]` **Q-04a** — `templatetags` : 1 459 lignes, **aucun test**, et c'est là
  que vivent `sanitize`, `css_value`, `tojson`. Le code le plus sensible du
  paquet est le moins couvert.
- `[ ]` **Q-04b** — `administration` (2 %) et `administration_menu`.

### Phase 12 — accompagnement · ~4 j · reporté

- `[ ]` **D-01** — assistant de mise en route, relançable, plus tableau de bord
  d'installation. `walkthrough.md` fait 0 octet ; c'est le manque fonctionnel le
  plus lourd pour un produit vendu à des non-techniciens.

### Phase 13 — CSP · ~3,5 j · à terme

- `[ ]` **S-03** — la CSP est en `Report-Only`, donc n'empêche rien. Son
  passage en application est bloqué par **129 `onclick=` inline dans 35
  gabarits** et 40 exports `window.*`. Sortir les `onclick` d'abord.
- `[ ]` **S-02** — Quill servi en local avec SRI (indépendant, peut être avancé).

### Phase 14 — bibliothèque de modèles · ~3 j · à terme

- `[ ]` **Q-06** — `model_source` est écrit et jamais lu. Aperçu, renommage,
  compteur d'usages, suppression avertie : E1 à E6 de `AUDIT_EDITOR.md`.

---

## 3. Hors plan, à connaître

- **S-16 — l'intégrité de la chaîne de mise à jour repose sur un sha256 publié
  par le même canal que le wheel.** Cela protège d'un téléchargement corrompu,
  pas d'un dépôt compromis. Une signature détachée serait la vraie réponse.
- **Q-07 — l'internationalisation est structurellement absente** : 11 marquages
  `gettext`, aucun `.po`. Ce n'est pas une dette, c'est un plafond à connaître
  avant de promettre du multilingue. Compter 5 à 8 jours.
- **Q-09 — `site-packages` est dans un dossier synchronisé iCloud**, d'où les
  doublons « fichier 2.py ». À sortir de la synchronisation.
