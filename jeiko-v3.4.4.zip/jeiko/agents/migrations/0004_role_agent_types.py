# jeiko/agents/migrations/0004_role_agent_types.py
"""
Le rôle « Agent fiches et boutique » ne pouvait pas DÉFINIR un type de fiche.

Il savait remplir des fiches et créer des produits, mais pas déclarer le type
« Formule » et ses champs : il fallait passer par l'administration à mi-chemin.
Un agent à qui on demande « fais-moi trois formules » s'arrêtait donc au
milieu du travail, et l'obstacle n'était pas une règle de sécurité — c'était un
oubli.

Ce que cette migration ajoute, et ce qu'elle continue de refuser
----------------------------------------------------------------
Ajouté : créer et modifier un type de fiche, ses champs, et un type de produit.

Toujours refusé : **toute suppression.** Supprimer un type de fiche emporte ses
champs, ses fiches et leurs valeurs — et `page_template` est en PROTECT, donc
l'échec serait au mieux brutal, au pire partiel. C'est la même règle que pour
les pages : un agent crée et corrige, il n'efface pas.

La migration est idempotente et réversible : elle ne fait qu'ajouter des
permissions à un rôle existant, et le retour les retire sans toucher au reste.
"""

from django.db import migrations

NOM_DU_ROLE = "Agent fiches et boutique"

#: (app_label, codename) — écrits en clair pour que la migration reste lisible
#: sans aller chercher les modèles concernés.
PERMISSIONS = [
    ("custom_objects", "add_customobjectmodel"),
    ("custom_objects", "change_customobjectmodel"),
    ("custom_objects", "add_customobjectfield"),
    ("custom_objects", "change_customobjectfield"),
    ("shop", "add_producttype"),
    ("shop", "change_producttype"),
]


def ajouter(apps, schema_editor):
    Group = apps.get_model("auth", "Group")
    Permission = apps.get_model("auth", "Permission")

    role = Group.objects.filter(name=NOM_DU_ROLE).first()
    if role is None:
        # Le rôle est créé par 0003. Son absence signifie une base montée
        # autrement : on ne la devine pas, on ne casse pas la migration.
        return

    for app_label, codename in PERMISSIONS:
        permission = Permission.objects.filter(
            content_type__app_label=app_label, codename=codename
        ).first()
        if permission is not None:
            role.permissions.add(permission)


def retirer(apps, schema_editor):
    Group = apps.get_model("auth", "Group")
    Permission = apps.get_model("auth", "Permission")

    role = Group.objects.filter(name=NOM_DU_ROLE).first()
    if role is None:
        return

    for app_label, codename in PERMISSIONS:
        permission = Permission.objects.filter(
            content_type__app_label=app_label, codename=codename
        ).first()
        if permission is not None:
            role.permissions.remove(permission)


class Migration(migrations.Migration):

    dependencies = [
        ("jeiko_agents", "0003_role_agent_boutique"),
        ("custom_objects", "0001_initial"),
        ("shop", "0001_initial"),
    ]

    operations = [migrations.RunPython(ajouter, retirer)]
