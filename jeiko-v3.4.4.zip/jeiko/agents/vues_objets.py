# jeiko/agents/vues_objets.py
"""
Objets personnalisés et produits — l'API qui remplit les gabarits.

À quoi cela sert vraiment
-------------------------
Un `CustomObjectModel` est un **type de fiche** : « Produit », « Réalisation »,
« Membre de l'équipe ». Il déclare des champs (`CustomObjectField`) et désigne
une `Page` qui lui sert de gabarit. Cette page contient des jetons `[%code%]`
qui seront remplacés par les valeurs de chaque fiche.

Autrement dit : **une page dessinée une fois, autant de pages publiées qu'il y
a de fiches.** C'est le cas d'usage central de cette API — un agent ne construit
pas trente pages produit à la main, il crée trente fiches.

Un `Product` ajoute à une fiche ce qui relève de la vente : référence, prix,
TVA, stock. La fiche porte le contenu, le produit porte le commerce ; les deux
sont liés par `Product.content`.

Le point d'entrée qui compte
----------------------------
`GET /modeles/` liste les types de fiches **avec leurs champs, leurs codes et
leurs types**. Sans lui, un agent devrait deviner que le champ s'appelle
`prix_barre` et qu'il attend du texte court. Avec lui, il lit le contrat puis
le remplit. C'est le pendant du guide pour les pages.

Ce qui est délibérément absent
------------------------------
**La suppression**, comme pour les pages : un agent crée et corrige, il
n'efface pas. Une fiche supprimée emporte ses valeurs, et souvent le produit
qui la référence.

**Le téléversement d'images.** Les champs image acceptent l'identifiant d'une
image déjà présente dans la médiathèque. Le fichier passe par l'administration,
où s'appliquent les validateurs de S-10 — plafond de poids et garde
anti-bombe de décompression.
"""

from django.db import transaction
from django.shortcuts import get_object_or_404
from django.utils.text import slugify

from jeiko.administration_pages.models import ImageContent, Page
from jeiko.custom_objects.models import (
    CustomObject, CustomObjectField, CustomObjectModel, CustomObjectValue,
)
from jeiko.shop.models import Product, ProductType

from .vues_api import CorpsInvalide, VueAgent, erreur, ok

VOIR_OBJET = "custom_objects.view_customobject"
AJOUTER_OBJET = "custom_objects.add_customobject"
MODIFIER_OBJET = "custom_objects.change_customobject"
VOIR_PRODUIT = "shop.view_product"
AJOUTER_PRODUIT = "shop.add_product"
MODIFIER_PRODUIT = "shop.change_product"
AJOUTER_MODELE = "custom_objects.add_customobjectmodel"
MODIFIER_MODELE = "custom_objects.change_customobjectmodel"
VOIR_TYPE_PRODUIT = "shop.view_producttype"
AJOUTER_TYPE_PRODUIT = "shop.add_producttype"


# --------------------------------------------------------------------------- #
#  Sérialisation
# --------------------------------------------------------------------------- #
def _champ_en_dict(champ):
    return {
        "code": champ.code,
        "libelle": champ.label,
        "type": champ.field_type,
        "obligatoire": champ.required,
        "aide": champ.help_text or "",
    }


def _type_de_produit_en_dict(type_produit):
    return {
        "id": type_produit.id,
        "nom": type_produit.name,
        "code": type_produit.code,
        "nature": type_produit.kind,
        "modele_de_fiche": (
            type_produit.content_model.slug
            if type_produit.content_model_id else None
        ),
    }


def _modele_en_dict(modele):
    return {
        "id": modele.id,
        "nom": modele.name,
        "slug": modele.slug,
        "est_un_produit": modele.is_product,
        "gabarit_de_page": (
            {"id": modele.page_template_id, "titre": modele.page_template.title}
            if modele.page_template_id else None
        ),
        "champs": [
            _champ_en_dict(c)
            for c in modele.fields.all().order_by("position", "id")
        ],
    }


def _valeur_en_dict(valeur):
    """La valeur d'un champ, réduite à ce qui a du sens pour son type."""
    champ = valeur.field
    rendu = {"code": champ.code, "type": champ.field_type}

    if champ.field_type in ("text", "rich_text"):
        rendu["valeur"] = valeur.value_text or ""
    elif champ.field_type == "image":
        rendu["image_id"] = valeur.image_id
    elif champ.field_type == "video":
        rendu["url"] = valeur.video_url or ""
    elif champ.field_type == "button":
        rendu["bouton"] = {
            "libelle": valeur.button_label or "",
            "page_id": valeur.button_page_id,
            "url_externe": valeur.button_external_url or "",
            "questionnaire": valeur.button_test_slug or "",
        }
    return rendu


def _objet_en_dict(objet):
    return {
        "id": objet.id,
        "titre": objet.title,
        "slug": objet.slug,
        "publie": objet.is_published,
        "modele": {"id": objet.model_id, "nom": objet.model.name},
        "image_principale_id": objet.main_image_id,
        "valeurs": [
            _valeur_en_dict(v)
            for v in objet.values.select_related("field").order_by("field__position")
        ],
        "url": objet.get_absolute_url() if hasattr(objet, "get_absolute_url") else "",
    }


def _produit_en_dict(produit):
    return {
        "id": produit.id,
        "sku": produit.sku,
        "actif": produit.is_active,
        "prix_ht": str(produit.price_ht),
        "taux_tva": str(produit.tax_rate),
        "devise": produit.currency,
        "stock": produit.stock_quantity,
        "type": {"id": produit.type_id, "nom": produit.type.name if produit.type else ""},
        "fiche": (
            {"id": produit.content_id, "titre": produit.content.title}
            if produit.content_id else None
        ),
    }


# --------------------------------------------------------------------------- #
#  Écriture d'une valeur
# --------------------------------------------------------------------------- #
def _ecrire_valeur(objet, champ, donnee):
    """
    Pose la valeur d'un champ, selon son type.

    Chaque type a sa colonne : mettre une URL de vidéo dans `value_text` la
    rendrait invisible au gabarit, sans qu'aucune erreur ne le signale. On
    refuse donc explicitement ce qui ne correspond pas au type déclaré.
    """
    valeur, _ = CustomObjectValue.objects.get_or_create(obj=objet, field=champ)
    modifies = []

    if champ.field_type in ("text", "rich_text"):
        valeur.value_text = str(donnee if donnee is not None else "")
        modifies.append("value_text")

    elif champ.field_type == "image":
        if donnee in (None, "", 0):
            valeur.image = None
        else:
            image = ImageContent.objects.filter(pk=donnee).first()
            if image is None:
                raise CorpsInvalide(
                    f"« {champ.code} » : aucune image nº {donnee} dans la "
                    f"médiathèque. Les images se téléversent depuis "
                    f"l'administration."
                )
            valeur.image = image
        modifies.append("image")

    elif champ.field_type == "video":
        valeur.video_url = str(donnee or "")[:500]
        modifies.append("video_url")

    elif champ.field_type == "button":
        if not isinstance(donnee, dict):
            raise CorpsInvalide(
                f"« {champ.code} » est un bouton : un objet est attendu, avec "
                f"« libelle » et l'une des destinations « page_id », "
                f"« url_externe » ou « questionnaire »."
            )
        valeur.button_label = str(donnee.get("libelle", ""))[:200]
        valeur.button_external_url = str(donnee.get("url_externe", ""))[:500]
        valeur.button_test_slug = str(donnee.get("questionnaire", ""))[:200]
        page_id = donnee.get("page_id")
        if page_id:
            page = Page.objects.filter(pk=page_id).first()
            if page is None:
                raise CorpsInvalide(f"« {champ.code} » : page nº {page_id} inconnue.")
            valeur.button_page = page
        elif "page_id" in donnee:
            valeur.button_page = None
        modifies.extend([
            "button_label", "button_external_url", "button_test_slug", "button_page",
        ])

    valeur.save(update_fields=modifies)
    return champ.code


def _appliquer_valeurs(objet, valeurs):
    """
    Écrit les champs présents. Ceux qu'on ne mentionne pas ne bougent pas.

    Un code inconnu est refusé AVEC la liste des codes valides : un agent qui
    se trompe de nom doit l'apprendre du premier coup, pas deviner.
    """
    if not isinstance(valeurs, dict):
        raise CorpsInvalide("« valeurs » doit être un objet {code: valeur}.")

    champs = {c.code: c for c in objet.model.fields.all()}
    inconnus = sorted(set(valeurs) - set(champs))
    if inconnus:
        raise CorpsInvalide(
            f"Champ(s) inconnu(s) pour le modèle « {objet.model.name} » : "
            f"{', '.join(inconnus)}. Codes acceptés : "
            f"{', '.join(sorted(champs)) or '(aucun)'}."
        )

    return [_ecrire_valeur(objet, champs[code], valeurs[code]) for code in valeurs]


# --------------------------------------------------------------------------- #
#  Modèles de fiche
# --------------------------------------------------------------------------- #
class ListeDesModeles(VueAgent):
    """
    Le contrat : quels types de fiches existent, et quels champs les composent.

    À lire AVANT toute création : c'est là qu'un agent apprend qu'un champ
    s'appelle `prix_barre` et qu'il attend du texte court.
    """

    permission_requise = VOIR_OBJET

    def get(self, request):
        modeles = CustomObjectModel.objects.prefetch_related("fields").select_related(
            "page_template"
        )
        return ok({"modeles": [_modele_en_dict(m) for m in modeles]})


# --------------------------------------------------------------------------- #
#  Fiches
# --------------------------------------------------------------------------- #
class ListeDesObjets(VueAgent):
    permission_requise = VOIR_OBJET

    def get(self, request):
        objets = CustomObject.objects.select_related("model").prefetch_related(
            "values__field"
        )
        modele = request.GET.get("modele")
        if modele:
            objets = objets.filter(model__slug=modele)
        return ok({"objets": [_objet_en_dict(o) for o in objets.order_by("-id")[:200]]})


class CreationObjet(VueAgent):
    permission_requise = AJOUTER_OBJET

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)

        slug_modele = str(corps.get("modele") or "").strip()
        if not slug_modele:
            raise CorpsInvalide(
                "« modele » est obligatoire : le slug du type de fiche. "
                "Voir /modeles/ pour la liste."
            )
        modele = CustomObjectModel.objects.filter(slug=slug_modele).first()
        if modele is None:
            connus = ", ".join(
                CustomObjectModel.objects.values_list("slug", flat=True)
            )
            raise CorpsInvalide(
                f"Modèle « {slug_modele} » inconnu. Connus : {connus or '(aucun)'}."
            )

        titre = str(corps.get("titre") or "").strip()
        if not titre:
            raise CorpsInvalide("Un « titre » est obligatoire.")

        slug = str(corps.get("slug") or "").strip() or slugify(titre)
        if CustomObject.objects.filter(model=modele, slug=slug).exists():
            return erreur(
                f"Une fiche « {slug} » existe déjà pour ce modèle.",
                statut=409, slug=slug,
            )

        objet = CustomObject.objects.create(
            model=modele,
            title=titre[:200],
            slug=slug[:200],
            # Comme une page créée par un agent : non publiée. La mise en ligne
            # est une décision éditoriale, pas un effet de bord de la création.
            is_published=False,
        )

        if "valeurs" in corps:
            _appliquer_valeurs(objet, corps["valeurs"])

        return ok({"objet": _objet_en_dict(objet)}, statut=201)


class DetailObjet(VueAgent):
    permission_requise = VOIR_OBJET

    def get(self, request, objet_id):
        objet = get_object_or_404(
            CustomObject.objects.select_related("model"), id=objet_id
        )
        return ok({"objet": _objet_en_dict(objet)})

    @transaction.atomic
    def patch(self, request, objet_id):
        if not request.user.has_perm(MODIFIER_OBJET):
            return erreur("Modification de fiche non autorisée.", statut=403)

        objet = get_object_or_404(
            CustomObject.objects.select_related("model"), id=objet_id
        )
        corps = self.corps(request)
        modifies = []

        if "titre" in corps:
            objet.title = str(corps["titre"]).strip()[:200]
            modifies.append("title")
        if "publie" in corps:
            objet.is_published = bool(corps["publie"])
            modifies.append("is_published")
        if "image_principale_id" in corps:
            identifiant = corps["image_principale_id"]
            if identifiant in (None, "", 0):
                objet.main_image = None
            else:
                image = ImageContent.objects.filter(pk=identifiant).first()
                if image is None:
                    raise CorpsInvalide(f"Aucune image nº {identifiant}.")
                objet.main_image = image
            modifies.append("main_image")

        if modifies:
            objet.save(update_fields=modifies)

        champs = _appliquer_valeurs(objet, corps["valeurs"]) if "valeurs" in corps else []

        return ok({
            "objet": _objet_en_dict(objet),
            "modifies": modifies + [f"valeurs.{c}" for c in champs],
        })


# --------------------------------------------------------------------------- #
#  Produits
# --------------------------------------------------------------------------- #
class ListeDesProduits(VueAgent):
    permission_requise = VOIR_PRODUIT

    def get(self, request):
        produits = Product.objects.select_related("type", "content").order_by("-id")
        return ok({"produits": [_produit_en_dict(p) for p in produits[:200]]})


class CreationProduit(VueAgent):
    permission_requise = AJOUTER_PRODUIT

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)

        code_type = str(corps.get("type") or "").strip()
        type_produit = ProductType.objects.filter(code=code_type).first()
        if type_produit is None:
            connus = ", ".join(ProductType.objects.values_list("code", flat=True))
            raise CorpsInvalide(
                f"Type de produit « {code_type or 'absent'} » inconnu. "
                f"Connus : {connus or '(aucun)'}."
            )

        fiche_id = corps.get("fiche_id")
        fiche = CustomObject.objects.filter(pk=fiche_id).first() if fiche_id else None
        if fiche is None:
            raise CorpsInvalide(
                "« fiche_id » est obligatoire : un produit porte le commerce, "
                "la fiche porte le contenu. Créer la fiche d'abord."
            )

        sku = str(corps.get("sku") or "").strip()
        if not sku:
            raise CorpsInvalide("Une référence « sku » est obligatoire.")
        if Product.objects.filter(sku=sku).exists():
            return erreur(f"La référence « {sku} » est déjà prise.", statut=409)

        produit = Product.objects.create(
            type=type_produit,
            content=fiche,
            sku=sku[:100],
            price_ht=corps.get("prix_ht", 0) or 0,
            tax_rate=corps.get("taux_tva", type_produit.default_tax_rate or 0) or 0,
            currency=str(corps.get("devise") or type_produit.default_currency or "EUR"),
            stock_quantity=int(corps.get("stock", 0) or 0),
            # Comme les pages et les fiches : inactif à la création.
            is_active=False,
        )
        return ok({"produit": _produit_en_dict(produit)}, statut=201)


class DetailProduit(VueAgent):
    permission_requise = VOIR_PRODUIT

    def get(self, request, produit_id):
        produit = get_object_or_404(
            Product.objects.select_related("type", "content"), id=produit_id
        )
        return ok({"produit": _produit_en_dict(produit)})

    def patch(self, request, produit_id):
        if not request.user.has_perm(MODIFIER_PRODUIT):
            return erreur("Modification de produit non autorisée.", statut=403)

        produit = get_object_or_404(
            Product.objects.select_related("type", "content"), id=produit_id
        )
        corps = self.corps(request)

        correspondances = {
            "sku": "sku", "actif": "is_active", "prix_ht": "price_ht",
            "taux_tva": "tax_rate", "devise": "currency", "stock": "stock_quantity",
        }
        modifies = []
        for cle, champ in correspondances.items():
            if cle not in corps:
                continue
            valeur = corps[cle]
            if champ == "sku":
                valeur = str(valeur).strip()[:100]
                if Product.objects.filter(sku=valeur).exclude(id=produit.id).exists():
                    return erreur(f"La référence « {valeur} » est déjà prise.", statut=409)
            if champ == "stock_quantity":
                valeur = int(valeur or 0)
            if champ == "is_active":
                valeur = bool(valeur)
            setattr(produit, champ, valeur)
            modifies.append(champ)

        if modifies:
            produit.save(update_fields=modifies)

        return ok({"produit": _produit_en_dict(produit), "modifies": modifies})


# --------------------------------------------------------------------------- #
#  Types de fiches — la définition, pas le remplissage
# --------------------------------------------------------------------------- #
#
# Jusqu'ici l'API savait REMPLIR des fiches, pas créer leur type : il fallait
# passer par l'administration pour déclarer « Formule » et ses six champs, puis
# revenir à l'API pour les remplir. Un agent à qui on demande « fais-moi trois
# formules » ne pouvait donc pas aller au bout tout seul.
#
# Créer un type engage plus qu'une fiche : le `slug` entre dans les URL
# (`/co/<slug>/…`), les `code` de champs entrent dans les gabarits sous la
# forme `[%code%]`. Les renommer plus tard casse des pages publiées. D'où deux
# précautions : les codes sont normalisés à la création, et **jamais modifiés
# ensuite** — un PATCH peut ajouter un champ, pas rebaptiser un existant.

#: Types de champ acceptés, lus sur le modèle : la liste ne peut pas dériver.
TYPES_DE_CHAMP = [code for code, _ in CustomObjectField.FIELD_TYPES]


def _lire_les_champs(corps, obligatoire):
    """
    Valide la liste de champs d'un type de fiche et la rend prête à créer.

    On valide tout avant d'écrire quoi que ce soit : un type à moitié déclaré,
    dont le quatrième champ a été refusé, serait plus pénible à réparer qu'un
    refus franc.
    """
    champs = corps.get("champs")
    if champs is None:
        if obligatoire:
            raise CorpsInvalide(
                "« champs » est obligatoire : un type de fiche sans champ ne "
                "peut rien porter. Chaque champ attend « code », « libelle » "
                f"et « type » parmi {', '.join(TYPES_DE_CHAMP)}."
            )
        return []

    if not isinstance(champs, list):
        raise CorpsInvalide("« champs » doit être une liste.")

    prepares, vus = [], set()
    for rang, brut in enumerate(champs, 1):
        if not isinstance(brut, dict):
            raise CorpsInvalide(f"Champ nº {rang} : un objet est attendu.")

        code = slugify(str(brut.get("code") or "").strip()).replace("-", "_")
        if not code:
            raise CorpsInvalide(
                f"Champ nº {rang} : « code » est obligatoire. C'est lui qui "
                f"s'écrit [%code%] dans le gabarit."
            )
        if code in vus:
            raise CorpsInvalide(
                f"Champ nº {rang} : le code « {code} » apparaît deux fois. "
                f"Un jeton [%{code}%] ne saurait pas lequel rendre."
            )
        vus.add(code)

        type_de_champ = str(brut.get("type") or "").strip()
        if type_de_champ not in TYPES_DE_CHAMP:
            raise CorpsInvalide(
                f"Champ nº {rang} : type « {type_de_champ} » inconnu. "
                f"Acceptés : {', '.join(TYPES_DE_CHAMP)}."
            )

        prepares.append({
            "code": code,
            "label": str(brut.get("libelle") or code).strip(),
            "field_type": type_de_champ,
            "required": bool(brut.get("obligatoire", False)),
            "help_text": str(brut.get("aide") or "").strip()[:255],
            "position": rang,
        })
    return prepares


class CreationModele(VueAgent):
    """
    Crée un type de fiche, ses champs, et marque sa page gabarit.

    Le marquage de la page (`is_custom_object_template`) est fait ici plutôt
    que laissé à l'appelant : `CustomObjectModel.page_template` n'accepte que
    des pages ainsi marquées, et une page qui ne l'est pas produirait une
    erreur de validation opaque. Le faire au moment où l'on sait pourquoi
    évite un aller-retour que rien ne justifie.
    """

    permission_requise = AJOUTER_MODELE

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)

        nom = str(corps.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide("« nom » est obligatoire.")

        slug = slugify(str(corps.get("slug") or nom).strip())
        if not slug:
            raise CorpsInvalide("« slug » ne donne rien d'utilisable.")
        if CustomObjectModel.objects.filter(slug=slug).exists():
            raise CorpsInvalide(
                f"Le slug « {slug} » est déjà pris. Il entre dans les URL "
                f"(/co/{slug}/…), il ne peut pas être partagé."
            )

        gabarit_id = corps.get("gabarit_de_page")
        if not gabarit_id:
            raise CorpsInvalide(
                "« gabarit_de_page » est obligatoire : l'identifiant de la page "
                "qui sert de modèle, celle où figurent les jetons [%code%]."
            )
        gabarit = Page.objects.filter(pk=gabarit_id).first()
        if gabarit is None:
            raise CorpsInvalide(f"Aucune page nº {gabarit_id}.")

        prepares = _lire_les_champs(corps, obligatoire=True)

        # La page devient un gabarit. C'est une modification de page, mais qui
        # découle directement de la création demandée : la refuser ici
        # obligerait à un second appel dont le seul effet serait de rendre
        # celui-ci possible.
        if not gabarit.is_custom_object_template:
            gabarit.is_custom_object_template = True
            gabarit.save(update_fields=["is_custom_object_template"])

        modele = CustomObjectModel.objects.create(
            name=nom,
            slug=slug,
            page_template=gabarit,
            is_product=bool(corps.get("est_un_produit", False)),
        )
        for valeurs in prepares:
            CustomObjectField.objects.create(model=modele, **valeurs)

        return ok({"modele": _modele_en_dict(modele)}, statut=201)


class DetailModele(VueAgent):
    """
    Lit un type de fiche, ou lui AJOUTE des champs.

    Ajouter seulement : un code de champ est écrit dans les gabarits sous la
    forme `[%code%]`, et dans les fiches déjà remplies. Le renommer casserait
    les deux, silencieusement — le jeton ne serait plus reconnu et resterait
    affiché en clair sur la page publique. Un champ devenu inutile se laisse
    vide ; le retirer se fait depuis l'administration, en connaissance de cause.
    """

    permission_requise = VOIR_OBJET

    def get(self, request, modele_id):
        modele = get_object_or_404(
            CustomObjectModel.objects.prefetch_related("fields"), pk=modele_id
        )
        return ok({"modele": _modele_en_dict(modele)})

    @transaction.atomic
    def patch(self, request, modele_id):
        if not request.user.has_perm(MODIFIER_MODELE):
            return erreur("Modification de type de fiche non autorisée.", statut=403)

        modele = get_object_or_404(CustomObjectModel, pk=modele_id)
        corps = self.corps(request)
        touches = []

        if "nom" in corps:
            modele.name = str(corps["nom"]).strip() or modele.name
            modele.save(update_fields=["name"])
            touches.append("nom")

        existants = set(modele.fields.values_list("code", flat=True))
        for valeurs in _lire_les_champs(corps, obligatoire=False):
            if valeurs["code"] in existants:
                raise CorpsInvalide(
                    f"Le champ « {valeurs['code']} » existe déjà. Un code de "
                    f"champ ne se renomme pas : il est écrit dans le gabarit "
                    f"et dans les fiches remplies."
                )
            CustomObjectField.objects.create(model=modele, **valeurs)
            touches.append(f"champ:{valeurs['code']}")

        modele.refresh_from_db()
        return ok({"modele": _modele_en_dict(modele), "modifie": touches})


# --------------------------------------------------------------------------- #
#  Types de produit
# --------------------------------------------------------------------------- #
class ListeDesTypesDeProduit(VueAgent):
    permission_requise = VOIR_TYPE_PRODUIT

    def get(self, request):
        types = ProductType.objects.select_related("content_model")
        return ok({"types": [_type_de_produit_en_dict(t) for t in types]})


class CreationTypeDeProduit(VueAgent):
    """
    Crée le type métier d'un produit, et le relie à son type de fiche.

    Deux couches, et c'est voulu : `CustomObjectModel` porte le CONTENU (les
    champs, le gabarit), `ProductType` porte le COMMERCE (la nature du produit,
    physique ou service). Un même modèle de fiche peut servir plusieurs types
    de produit.
    """

    permission_requise = AJOUTER_TYPE_PRODUIT

    @transaction.atomic
    def post(self, request):
        corps = self.corps(request)

        nom = str(corps.get("nom") or "").strip()
        if not nom:
            raise CorpsInvalide("« nom » est obligatoire.")

        code = slugify(str(corps.get("code") or nom).strip()).replace("-", "_")
        if not code:
            raise CorpsInvalide("« code » ne donne rien d'utilisable.")
        if ProductType.objects.filter(code=code).exists():
            raise CorpsInvalide(f"Le code « {code} » est déjà pris.")

        natures = [c for c, _ in ProductType.KIND_CHOICES]
        nature = str(corps.get("nature") or ProductType.KIND_PHYSICAL).strip()
        if nature not in natures:
            raise CorpsInvalide(
                f"« nature » inconnue. Acceptées : {', '.join(natures)}."
            )

        modele = None
        if corps.get("modele"):
            modele = CustomObjectModel.objects.filter(
                slug=str(corps["modele"]).strip()
            ).first()
            if modele is None:
                raise CorpsInvalide(
                    f"Aucun type de fiche « {corps['modele']} ». Voir /modeles/."
                )

        type_produit = ProductType.objects.create(
            name=nom, code=code, kind=nature, content_model=modele,
            is_physical=(nature == ProductType.KIND_PHYSICAL),
        )
        return ok({"type": _type_de_produit_en_dict(type_produit)}, statut=201)
