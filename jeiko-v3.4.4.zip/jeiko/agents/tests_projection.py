# jeiko/agents/tests_projection.py
"""
Un bloc dynamique écrit par l'API doit s'AFFICHER, pas seulement exister.

Le défaut
---------
`contenus_dynamiques.appliquer()` créait bien les lignes filles — trois offres
de tarifs, correctement ordonnées, relisibles par l'API elle-même. Et la page
publique affichait une table de prix **vide**.

Parce que treize des quatorze gabarits `content/dyn/*.html` ne lisent pas les
lignes filles : ils sérialisent `Content.data` dans un
`<script type="application/json">` et laissent Alpine construire le DOM. Le
formulaire de l'éditeur, lui, appelle `_snapshot_for_content()` après chaque
`formset.save()` pour recopier les filles dans `data`. L'API ne le faisait pas.

Aucune erreur, aucun avertissement : la relecture par l'API confirmait des
données justes, puisqu'elle interrogeait les filles — c'est-à-dire précisément
la moitié de l'état que le rendu n'utilise pas.

Ce que ces tests verrouillent
-----------------------------
1. Après écriture, `data` contient les éléments (le rendu a de quoi travailler).
2. Écrire les seules options ne détruit pas la projection existante — le piège
   qui vient juste après le premier, `content.data = options` étant un
   remplacement complet.
3. Le rendu public contient réellement les libellés — le seul contrôle qui
   aurait attrapé le défaut d'origine.
"""

from django.test import TestCase

from jeiko.administration_pages import models as M
from jeiko.agents import contenus_dynamiques as CD


#: `Page.url_tag` est unique en base hors catégorie, et l'un des tests monte un
#: arbre par type dynamique.
_compteur = [0]


def _contenu(type_dyn):
    """Un contenu rattaché à un vrai bloc — `Content.bloc` est obligatoire."""
    _compteur[0] += 1
    page = M.Page.objects.create(
        title="Essai", url_tag=f"t-essai-{_compteur[0]}", active=True
    )
    section = M.Section.objects.create(page=page, position=0)
    line = M.Line.objects.create(
        section=section, position=0, columns_type="12", columns_number=1
    )
    bloc = M.Bloc.objects.create(line=line, position=1, position_in_column=0)
    return M.Content.objects.create(bloc=bloc, content_type=type_dyn, data={})


def _element_minimal(modele, correspondances):
    """
    Le plus petit élément que la base accepte pour ce modèle.

    On ne cherche pas un contenu réaliste — seulement de quoi franchir les
    contraintes, pour que le test porte sur la projection et non sur la
    validation. D'où l'introspection : coder « la première clé, valeur
    "Essai" » plantait sur les champs numériques et booléens.

    Les images obligatoires sont fournies d'office : la galerie et le filtre
    vivant refusent un élément sans visuel, et c'est légitime — une vignette
    sans image n'a pas de sens.
    """
    element = {}
    for cle, champ in sorted(correspondances.items()):
        if champ in CD.CHAMPS_IMAGE and not modele._meta.get_field(champ).null:
            element[cle] = M.ImageContent.objects.create().pk

    for cle, champ in sorted(correspondances.items()):
        if cle in element:
            continue
        interne = modele._meta.get_field(champ).get_internal_type()
        if interne in ("CharField", "TextField", "URLField", "SlugField"):
            element[cle] = "Essai"
        elif interne in ("IntegerField", "PositiveIntegerField", "SmallIntegerField"):
            element[cle] = 1
        elif interne in ("DecimalField", "FloatField"):
            element[cle] = "1"
        elif interne == "BooleanField":
            element[cle] = True
        else:
            continue
        break

    if not element:
        raise AssertionError(f"{modele.__name__} : aucun champ simple à renseigner.")
    return element


class ProjectionDesBlocsDynamiquesTests(TestCase):
    def setUp(self):
        self.content = _contenu("DYN_PRICING_TABLE")

    def _ecrire(self, donnees):
        CD.appliquer(self.content, donnees)
        self.content.refresh_from_db()

    def test_les_elements_arrivent_dans_data(self):
        self._ecrire({
            "options": {"yearly": False},
            "elements": [
                {"nom": "Essentiel", "prix_mensuel": "19"},
                {"nom": "Équipe", "prix_mensuel": "39"},
            ],
        })

        self.assertEqual(self.content.pricing_plans.count(), 2)  # les filles
        noms = [offre.get("name") for offre in self.content.data.get("plans", [])]
        self.assertEqual(
            noms, ["Essentiel", "Équipe"],
            "Les offres ne sont pas dans Content.data : le gabarit rendra une "
            "table vide, sans la moindre erreur.",
        )

    def test_ecrire_les_options_ne_detruit_pas_la_projection(self):
        """
        `content.data = options` remplace le dictionnaire ENTIER.

        Sans reprojection derrière, régler une option — passer la facturation
        en annuel, par exemple — viderait la table de ses offres.
        """
        self._ecrire({"elements": [{"nom": "Essentiel", "prix_mensuel": "19"}]})
        self._ecrire({"options": {"yearly": True}})

        self.assertTrue(self.content.data.get("yearly"))
        self.assertEqual(
            [offre.get("name") for offre in self.content.data.get("plans", [])],
            ["Essentiel"],
            "Régler une option a effacé les offres de la projection.",
        )

    def test_toutes_les_ecritures_projettent(self):
        """
        Le même contrôle, sur chaque type dynamique à éléments.

        Un type ajouté plus tard sans reprojection tomberait ici, plutôt que
        sur la page d'un client.
        """
        for type_dyn, (modele, lien, correspondances) in CD.TYPES.items():
            with self.subTest(type=type_dyn):
                content = _contenu(type_dyn)
                CD.appliquer(content, {"elements": [_element_minimal(modele,
                                                                    correspondances)]})
                content.refresh_from_db()

                listes = [v for v in content.data.values() if isinstance(v, list)]
                self.assertTrue(
                    any(len(liste) == 1 for liste in listes),
                    f"{type_dyn} : l'élément écrit n'apparaît nulle part dans "
                    f"Content.data — le bloc sera vide à l'écran.",
                )


class CatalogueDuGuideTests(TestCase):
    """
    Le guide doit décrire TOUT ce que l'API sait faire.

    Un agent découvre JEIKO par ce document et par lui seul. Un type de bloc
    ouvert mais absent du catalogue est un outil qu'il n'utilisera jamais — et
    une route dont la permission n'est pas dite l'oblige à découvrir ses droits
    sur un 403.

    Ces contrôles ne relisent pas une liste écrite à la main : ils comparent le
    guide aux constantes que le code applique. C'est ce qui garantit qu'un type
    ajouté demain fasse échouer le test plutôt que de disparaître de la doc.
    """

    def setUp(self):
        from jeiko.agents import guide

        self.guide = guide
        self.document = guide.construire()

    def test_chaque_bloc_ouvert_est_decrit(self):
        muets = [
            type_ for type_, fiche in self.document["catalogue_des_blocs"].items()
            if not fiche.get("role")
        ]
        self.assertEqual(
            muets, [],
            "Types ouverts à l'API mais sans description dans le guide : un "
            "agent les verra sans savoir à quoi ils servent. Compléter "
            "guide.ROLE_DES_BLOCS.",
        )

    def test_le_catalogue_couvre_tous_les_types_ouverts(self):
        from jeiko.agents.vues_pages import TYPES_OUVERTS

        self.assertEqual(
            set(self.document["catalogue_des_blocs"]), set(TYPES_OUVERTS)
        )

    def test_chaque_route_dit_sa_permission_et_son_role(self):
        incomplets = [
            entree["nom"] for entree in self.document["points_d_entree"]
            if entree["permission"] == "?" or not entree["role"]
        ]
        self.assertEqual(
            incomplets, [],
            "Routes montées mais non documentées. La permission se lit sur la "
            "vue ; le rôle s'ajoute dans guide._points_d_entree().",
        )

    def test_chaque_contenu_simple_annonce_ses_champs(self):
        """
        Un type dont les champs ne sont pas dits est un type inutilisable.

        La grille de ressources en est l'exemple : sans « type_de_produit »
        au catalogue, un agent ne peut que lister « des produits » en général,
        et n'écrira jamais la page qui liste les formules.
        """
        from jeiko.agents.vues_pages import CONTENUS_SIMPLES

        muets = [
            type_ for type_ in CONTENUS_SIMPLES
            if not self.document["catalogue_des_blocs"].get(type_, {}).get("champs")
        ]
        self.assertEqual(muets, [])

    def test_les_elements_ne_sont_pas_presentes_comme_des_options(self):
        """
        `DYNAMIC_DEFAULTS` range les éléments à côté des options.

        Les recopier tels quels ferait croire qu'on peut écrire
        `{"options": {"plans": [...]}}` — ce qui enregistrerait, puis serait
        écrasé par la reprojection au premier appel suivant.
        """
        for type_, fiche in self.document["catalogue_des_blocs"].items():
            with self.subTest(type=type_):
                for cle, valeur in fiche.get("options", {}).items():
                    self.assertNotIsInstance(
                        valeur, list,
                        f"« {cle} » est une liste d'éléments, pas une option.",
                    )
